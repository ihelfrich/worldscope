# WORLDSCOPE morning brief — 2026-05-31

## Headline
2315 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 30 total
  (no new items today)

### State Legislative Action — 115 new of 181 total
  - (2026-05-30) [California AB 2448] Medical information: confidentiality.
      Existing law, the Confidentiality of Medical Information Act (CMIA) , generally prohibits a provider of health care, a health care service plan, or a contractor from disclosing medical information regarding a patient, en
  - (2026-05-30) [California AB 1641] Postsecondary education: segments: tribal colleges and universities.
      Existing law establishes the California Community Colleges, the California State University, the University of California, independent institutions of higher education, and private postsecondary educational institutions 
  - (2026-05-30) [California ACR 145] Relative to Women in Construction Week.
      This measure would proclaim the week of March 1, 2026, to March 7, 2026, inclusive, as Women in Construction Week.
  - (2026-05-30) [California SB 1440] Validations.
      This bill would enact the First Validating Act of 2026, which would validate the organization, boundaries, acts, proceedings, and bonds of the state and counties, cities, and specified districts, agencies, and entities.

  - (2026-05-30) [California AB 1956] Suicide prevention.
      Existing law authorizes the State Department of Public Health to establish the Office of Suicide Prevention within the department. Existing law authorizes the office, if established, to perform certain functions, includi
  - (2026-05-30) [California ACR 163] Relative to Missing and Murdered Indigenous People Awareness Month.
      This measure would designate the month of May 2026 as California's Missing and Murdered Indigenous People Awareness Month.
  - (2026-05-30) [California ACR 211] Relative to the Zoot Suit Riots.
      This measure would commemorate every June as the annual anniversary of the Zoot Suit Riots.
  - (2026-05-30) [California SCR 164] Relative to Black Health Equity Advocacy Week.
      This measure would recognize May 4, 2026, to May 8, 2026, inclusive, and every first full week of May thereafter, as Black Health Equity Advocacy Week and commend the California Black Health Network and other organizatio

### State-Level News — 95 new of 444 total
  - (2026-05-30) [California] Homelessness is down in California and across the country, says new federal report
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/012726-PIT-Count-Fresno-LV-24-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-30) [California] A chemical tank nearly exploded. Did California’s regulators miss the signs?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052226-Garden-Grove-Leak-AP-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-30) [California] Governor Newsom proclaims Asian American and Pacific Islander Heritage Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-31) [Connecticut] Baffling. Frustrating. Frightening. What it’s like to be sued over medical debt in Connecticut
      <figure><img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/03/2026_0303_SR_MedicalDebt_011-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="
  - (2026-05-31) [Connecticut] The Great Speed Camera Debate of ’26
      <figure><img width="633" height="477" src="https://ctmirror.org/wp-content/uploads/2026/05/school-speed-camera-sign.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading
  - (2026-05-30) [Delaware] Get Involved: Charter school bonds, Sussex development reforms, more
      <figure><img width="1000" height="800" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/05/Get-Involved-Artwork-Template-1000x800-9.png?fit=1000%2C800&amp;ssl=1" class="attachment-rss-image-size size-
  - (2026-05-30) [Colorado] How Trump’s giant ‘slush fund’ sparked lawsuits, roiled Republicans and revived Jan. 6
      WASHINGTON — The Trump administration’s nearly $1.8 billion “anti-weaponization” fund has attracted scrutiny for its corruption potential, even splitting congressional Republicans who rarely confront President Donald Tru
  - (2026-05-30) [Colorado] The feds have embraced medical marijuana. Now what?
      The U.S. Department of Justice’s recent decision to downgrade the drug classification for medical cannabis will help medical marijuana businesses. Companies will be able to claim some federal tax benefits. New research c

### Local News: St. Louis + Atlanta — 117 new of 231 total
  - (2026-05-31) [St. Louis] Nearly 150 passengers forced to jump into sea as pirate tour boat sinks in Turkey
      All passengers were safely taken to shore and no injuries were reported.
  - (2026-05-31) [St. Louis] Claude Lemieux's brain is being donated to Boston University's CTE Center, his family says
      The family said it gave the CTE Center permission to publicly share any findings with Lemieux's name.
  - (2026-05-31) [St. Louis] Mystery boom that shook New England was a 3-foot meteor, expert says
      NASA said the meteor fragmented around 40 miles in the sky and the energy breakup was "estimated to be equivalent to about 300 tons of TNT.
  - (2026-05-31) [St. Louis] Rare 'blue micromoon' happening Sunday morning — here's what time to look up
      Astronomers call the unique event a “blue micromoon.”
  - (2026-05-30) [St. Louis] United flight bound for Minneapolis diverted to Wisconsin because of an unruly passenger
      Law enforcement officials on the flight restrained the passenger quickly, airport authorities said.
  - (2026-05-30) [St. Louis] Man dies after being hit by multiple vehicles in south St. Louis
      A man was killed after being struck by multiple vehicles Friday night on Gravois. Police said the first vehicle that hit him fled the scene.
  - (2026-05-30) [St. Louis] President Trump set to headline 'Great American State Fair' after performers drop out
      Musical guests withdrew from America's 250th anniversary fair due to ties to the president, but he is now headlining the June event.
  - (2026-05-30) [St. Louis] Kelly Curtis, sister of Jamie Lee Curtis and daughter of Tony Curtis, has died
      Actress Kelly Curtis, sister of Jamie Lee Curtis, died at her California home. She was 69.

### International News + Multilateral Institutions — 569 new of 832 total
  - (2026-05-31) [Global] Trump tightens terms on Iran war deal, US media say
      US officials indicate Tehran may take days to respond to Trump&#039;s tougher terms on a potential peace agreement.
  - (2026-05-31) [Global] Israel issues more displacement orders in Lebanon, seizes strategic castle
      Israeli Defence Minister Israel Katz describes the capture of Beaufort Castle as a significant tactical victory.
  - (2026-05-31) [Global] The strait may reopen, but global confidence may not return
      The next phase of the Strait of Hormuz crisis may be defined less by its closure than by conditional access.
  - (2026-05-31) [Global] Iran war day 93: Trump won’t ‘rush’ deal; Israel expands Lebanon invasion
      Donald Trump says talks with Iran are progressing &#039;slowly but surely&#039;, as Israel intensifies operations in Lebanon.
  - (2026-05-31) [Global] Holder Gauff beaten by Potapova; Sabalenka solid at French Open
      Gauff&#039;s exit leaves four-time champion Swiatek and world number one Sabalenka as top contenders for the women&#039;s title.
  - (2026-05-31) [Global] Missing Syrian chess champion’s children likely dead, authorities say
      Syrian commission confirms deaths of Rania al-Abbasi&#039;s six children, missing since 2013 under Bashar al-Assad&#039;s rule.
  - (2026-05-31) [Global] Panic on beach in northern Israel during Hezbollah strikes
      Videos show people on a beach in Nahariya, Israel running for shelter as Hezbollah rockets are launched.
  - (2026-05-31) [Global] France arrests hundreds of rioters nationwide as PSG win Champions League
      French Ministry of Interior says 416 people detained nationwide, including 283 in Paris, after PSG&#039;s win over Arsenal.

### Chinese Internal News — 204 new of 261 total
  - (2026-05-30) [TITLE: 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9vMWdOQXA1MHgzU01zWERzSjRnUm1pNjBMLXU1cEVDLTlOZi1BSHJESHF1WVlQT2JaNVlVLWI4UUVfMjRVbUlMNGVJRW92WG4tbGwxMlRENjE3SS1] (zh: 商品详情 - 财新商城)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9vMWdOQXA1MHgzU01zWERzSjRnUm1pNjBMLXU1cEVDLTlOZi1BSHJESHF1WVlQT2JaNVlVLWI4UUVfMjRVbUlMNGVJRW92WG4tbGwxMlRENjE3SS1nY1IyZTVB?oc=5" target="_blank">商品详情</a>&nbsp;&
  - (2026-05-31) [TITLE: 5月统计局制造业PMI微降至50 新旧产业分化明显 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1QaF8yd0tkZjYxRnJlRVBZTXNKYm1rb1RsXzhZUUpCUXZQSlpHX3FFWFhPb1J1Um40Ry10R1E1cGdDek80UG5CT2VONFA0] (zh: 5月统计局制造业PMI微降至50 新旧产业分化明显 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1QaF8yd0tkZjYxRnJlRVBZTXNKYm1rb1RsXzhZUUpCUXZQSlpHX3FFWFhPb1J1Um40Ry10R1E1cGdDek80UG5CT2VONFA0NXcyTkpLeHh6YnF3bmIxSFFqSkVR?oc=5" target="_blank">5月统计局制造业PMI微降至5
  - (2026-05-30) [TITLE: 5月日元贬值2.6% 日本近一个月动用11万亿日元干预汇率 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE11VVVtNllud1J3YXEzOFpwdmdGRXFaUnk4eEdEOU5jNjNmUGJHaGlGdGZJckZZb0ZGdjd2MjRkTDV3VURyR0NTMnJK] (zh: 5月日元贬值2.6% 日本近一个月动用11万亿日元干预汇率 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE11VVVtNllud1J3YXEzOFpwdmdGRXFaUnk4eEdEOU5jNjNmUGJHaGlGdGZJckZZb0ZGdjd2MjRkTDV3VURyR0NTMnJKT3Ftc2hLUk9ISUY5d2w3VmI5OE5Cd2d3?oc=5" target="_blank">5月日元贬值2.6% 日本近一
  - (2026-05-29) [TITLE: 视线｜埃博拉病例破千：病毒、战乱与饥饿绞杀中非 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9KdWxZbDVHb01XUWJZUnRPZG9vUGs5NGgzTUJmaDRHOGhkOXRLWW8xZjk1OUdtcXBJTGFTT1BMUTF1TFZ0WDZGZXBYYkd4TD] (zh: 视线｜埃博拉病例破千：病毒、战乱与饥饿绞杀中非 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9KdWxZbDVHb01XUWJZUnRPZG9vUGs5NGgzTUJmaDRHOGhkOXRLWW8xZjk1OUdtcXBJTGFTT1BMUTF1TFZ0WDZGZXBYYkd4TDNlSU9nakdIalpsMVgzVmdBUQ?oc=5" target="_blank">视线｜埃博拉病例破千：病毒、战乱与
  - (2026-05-30) [TITLE: 最新财新周刊｜“AI牛”席卷韩国 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE41US0wRFNyVFNQVFczRjdkZm03VjNBczNBVDlneGk3X0F0MmxxaV9ZRTJZOGZYN3ViWWFkZUZtMUI1STc5MXpTVEVtczh4WTFFVzY] (zh: 最新财新周刊｜“AI牛”席卷韩国 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE41US0wRFNyVFNQVFczRjdkZm03VjNBczNBVDlneGk3X0F0MmxxaV9ZRTJZOGZYN3ViWWFkZUZtMUI1STc5MXpTVEVtczh4WTFFVzY3dEhraC1uVUxaaUtFNw?oc=5" target="_blank">最新财新周刊｜“AI牛”席卷韩国<
  - (2026-05-31) [TITLE: 朱学东：胖头鱼，从丑小鸭到白天鹅｜饮食 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFA2N1N5RWhTczd0WWpHdnRLR2Q0MzJLeHQ0VzEtSXhFQTc5cVVvOHdpdXdfb0tCb040VUFFVHhZa0czUXVZUkNUUTlOcm1WTnNNbz] (zh: 朱学东：胖头鱼，从丑小鸭到白天鹅｜饮食 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFA2N1N5RWhTczd0WWpHdnRLR2Q0MzJLeHQ0VzEtSXhFQTc5cVVvOHdpdXdfb0tCb040VUFFVHhZa0czUXVZUkNUUTlOcm1WTnNNbzJWWWg5dmlxVzBBYVE?oc=5" target="_blank">朱学东：胖头鱼，从丑小鸭到白天鹅｜饮食<
  - (2026-05-30) [TITLE: 最新财新周刊｜围堵违规跨境炒股 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE52N2V5QTY4Zks0NFpsemc4eHhwcF9RUER6V0RJcHY4V0N0YmcyV18wUGlOY0RrNUtfWWpYeGVwR1RlQ29pbmFEQjFWVV90M1U4Nm9z] (zh: 最新财新周刊｜围堵违规跨境炒股 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE52N2V5QTY4Zks0NFpsemc4eHhwcF9RUER6V0RJcHY4V0N0YmcyV18wUGlOY0RrNUtfWWpYeGVwR1RlQ29pbmFEQjFWVV90M1U4Nm9zcEc1Q2JqWlpLY0pGaQ?oc=5" target="_blank">最新财新周刊｜围堵违规跨境炒股</
  - (2026-05-30) [TITLE: 公募基金引“新登”入场 基金经理密集调整 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE43LWZ2ckpCYUk1Sk1xUVJoTWJjZjQ3dE01Z0VMa2F4VldIVkJvbjVEQXBXeGJkMnlzdHNidDU0SXkxYVJKZTF4VjBrRExjS0FrR] (zh: 公募基金引“新登”入场 基金经理密集调整 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE43LWZ2ckpCYUk1Sk1xUVJoTWJjZjQ3dE01Z0VMa2F4VldIVkJvbjVEQXBXeGJkMnlzdHNidDU0SXkxYVJKZTF4VjBrRExjS0FrRlVwWTB5WTVCa0pfWFJlVFBR?oc=5" target="_blank">公募基金引“新登”入场 基金经

### Russian Internal News (state + in-exile) — 533 new of 838 total
  - (2026-05-31) [TITLE: Горящие машины и баррикады, столкновения с полицией и сотни задержанных. Что происходило в Париже после победы ПСЖ в Лиге чемпионов | LEDE: <p>30 мая французский ПСЖ второй раз подряд стал побе] (ru: Горящие машины и баррикады, столкновения с полицией и сотни задержанных. Что про)
      <p>30 мая французский ПСЖ второй раз подряд стал победителем Лиге чемпионов, обыграв в финале турнира лондонский «Арсенал». После завершения матча, который проходил в Будапеште, тысячи фанатов ПСЖ вышли на улицы Парижа и
  - (2026-05-31) [TITLE: В Севастополе ввели продажу бензина по талонам | LEDE: <p>В Севастополе продажа бензина марок АИ-92 и АИ-95 будет производиться 31 мая только по талонам. Об этом сообщил назначенный Россией губ] (ru: В Севастополе ввели продажу бензина по талонам)
      <p>В Севастополе продажа бензина марок АИ-92 и АИ-95 будет производиться 31 мая только по талонам. Об этом сообщил назначенный Россией губернатор Михаил Развожаев. <p>
  - (2026-05-31) [TITLE: «Неделя как неделя» — книга советской писательницы Натальи Баранской о жизни простой сотрудницы НИИ. За границей этот текст изучают уже 40 лет. Никогда о нем не слышали? Переиздание — повод про] (ru: «Неделя как неделя» — книга советской писательницы Натальи Баранской о жизни про)
      <p>Издательство «Носорог» выпустило новое издание повести «Неделя как неделя» Натальи Баранской. Впервые этот текст опубликовал журнал «Новый мир» в 1969 году — в СССР за тиражами этих выпусков выстраивались очереди, поз
  - (2026-05-31) [TITLE: Во Франции задержали больше 400 человек после победы ПСЖ в Лиге чемпионов | LEDE: <p>Во Франции задержаны 416 человек в результате столкновений между полицейскими и футбольными фанатами после ф] (ru: Во Франции задержали больше 400 человек после победы ПСЖ в Лиге чемпионов)
      <p>Во Франции задержаны 416 человек в результате столкновений между полицейскими и футбольными фанатами после финального матча Лиги чемпионов, в котором «Пари Сен-Жермен» (ПСЖ) обыграл лондонский «Арсенал». Об этом сообщ
  - (2026-05-31) [TITLE: Падение ребенка из окна — страшный сон любого родителя. Увы, это случается не так уж редко. Даже с заботливыми и внимательными родителями. Инструкция о том, как снизить риски опасного инцидента] (ru: Падение ребенка из окна — страшный сон любого родителя. Увы, это случается не та)
      <p>В России каждый год из окон выпадают около тысячи детей. Около 100 из них умирают. Остальные либо выздоравливают, либо всю жизнь имеют проблемы, вызванные травмами. Обычно такие инциденты происходят с детьми до пяти л
  - (2026-05-31) [TITLE: Украинские дроны атаковали несколько регионов России. В Саратове горит НПЗ, в Ростовской области — топливное хранилище | LEDE: <p>Украинские беспилотники в ночь на 31 мая атаковали Саратовскую ] (ru: Украинские дроны атаковали несколько регионов России. В Саратове горит НПЗ, в Ро)
      <p>Украинские беспилотники в ночь на 31 мая атаковали Саратовскую область, повреждены объекты гражданской инфраструктуры, сообщил глава региона Роман Бусаргин. <p>
  - (2026-05-31) [TITLE: Власти и не думают прекращать войну против телеграма. На всякий случай мы еще раз собрали известные альтернативы в одном материале. Где общаться, если VPN не спасает? imo, WeChat, KakaoTalk и в] (ru: Власти и не думают прекращать войну против телеграма. На всякий случай мы еще ра)
      <p>Роскомнадзор усиливает борьбу со средствами обхода блокировок. Телеграм медленно, но верно теряет российскую аудиторию. А ФСБ продолжает говорить об опасности цифровых «инструментов манипулятивного воздействия» Запада
  - (2026-05-30) [TITLE: ПСЖ во второй раз подряд выиграл Лигу чемпионов | LEDE: <p>ПСЖ стал победителем Лиги чемпионов. В финале французский клуб по пенальти выиграл у лондонского «Арсенала».<p>] (ru: ПСЖ во второй раз подряд выиграл Лигу чемпионов)
      <p>ПСЖ стал победителем Лиги чемпионов. В финале французский клуб по пенальти выиграл у лондонского «Арсенала».<p>

### Ukrainian Internal News (national + local Kyiv) — 53 new of 120 total
  - (2026-05-31) [TITLE: ССО уразили ключовий вузол найбільших нафтопроводів РФ із Сибіру до Європи | LEDE: Безпілотники Сил спеціальних операцій уразили потужну виробничо-диспетчерську станцію великого нафтопроводу у ] (uk: ССО уразили ключовий вузол найбільших нафтопроводів РФ із Сибіру до Європи)
      Безпілотники Сил спеціальних операцій уразили потужну виробничо-диспетчерську станцію великого нафтопроводу у Кіровській області, а також нафтобазу у Ростовській області РФ у ніч на неділю.
  - (2026-05-31) [TITLE: ЗМІ: ЄС обмірковує тимчасове заморожування обмеження на ціни на російську нафту | LEDE: ] (uk: ЗМІ: ЄС обмірковує тимчасове заморожування обмеження на ціни на російську нафту)
  - (2026-05-31) [TITLE: У Фінляндії проведуть нове тестування систем громадського оповіщення | LEDE: ] (uk: У Фінляндії проведуть нове тестування систем громадського оповіщення)
  - (2026-05-31) [TITLE: Росіяни вдарили по непрацюючому підприємству на Рівненщині та атакували Дніпро: вирують пожежі | LEDE: Окупанти 31 травня вдарили по Рівненщині та Дніпру, спалахнули пожежі. Жертв немає, працюю] (uk: Росіяни вдарили по непрацюючому підприємству на Рівненщині та атакували Дніпро: )
      Окупанти 31 травня вдарили по Рівненщині та Дніпру, спалахнули пожежі. Жертв немає, працюють екстрені служби.
  - (2026-05-31) [TITLE: NYT: у Білому домі порадили Венсу взяти перерву від соцмереж | LEDE: ] (uk: NYT: у Білому домі порадили Венсу взяти перерву від соцмереж)
  - (2026-05-31) [TITLE: Зеленський: Україна отримала від Німеччини нову пускову установку IRIS-T | LEDE: У суботу, 30 травня, Україна отримала від Німеччини пускову установку зенітно-ракетного комплексу IRIS-T.] (uk: Зеленський: Україна отримала від Німеччини нову пускову установку IRIS-T)
      У суботу, 30 травня, Україна отримала від Німеччини пускову установку зенітно-ракетного комплексу IRIS-T.
  - (2026-05-31) [TITLE: У Кіровській області РФ горить вузол транспортування нафти | LEDE: У Кіровській області Росії атакували лінійну виробничо-диспетчерську станцію "Лазарєво", яка була створена для транзиту нафти ] (uk: У Кіровській області РФ горить вузол транспортування нафти)
      У Кіровській області Росії атакували лінійну виробничо-диспетчерську станцію "Лазарєво", яка була створена для транзиту нафти в центральну частину РФ.
  - (2026-05-31) [TITLE: В РФ після атаки дронів загорілось паливне сховище | LEDE: У Ростовській області РФ після атаки дронів спалахнула пожежа на паливному сховищі. Проводиться евакуація мешканців.] (uk: В РФ після атаки дронів загорілось паливне сховище)
      У Ростовській області РФ після атаки дронів спалахнула пожежа на паливному сховищі. Проводиться евакуація мешканців.

### Ukraine Theater (total-war monitoring) — 113 new of 290 total
  - (2026-05-31) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-30) [FIRMS] thermal anomaly 51.341, 34.380 (FRP 6.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-30 1043Z, FRP 6.03 MW
  - (2026-05-30) [FIRMS] thermal anomaly 51.377, 34.467 (FRP 3.62 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-30 1043Z, FRP 3.62 MW
  - (2026-05-30) [FIRMS] thermal anomaly 51.376, 34.461 (FRP 3.24 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-30 1043Z, FRP 3.24 MW
  - (2026-05-30) [FIRMS] thermal anomaly 51.108, 24.997 (FRP 3.27 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-30 1223Z, FRP 3.27 MW
  - (2026-05-30) [FIRMS] thermal anomaly 51.427, 34.302 (FRP 2.79 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-30 2257Z, FRP 2.79 MW
  - (2026-05-30) [FIRMS] thermal anomaly 51.064, 34.872 (FRP 1.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-30 2257Z, FRP 1.04 MW
  - (2026-05-30) [FIRMS] thermal anomaly 50.456, 34.113 (FRP 1.14 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-30 2257Z, FRP 1.14 MW

### Paper Trading Scorecard — 21 new of 136 total
  - (2026-05-31) [Polymarket] Will Elon Musk post 220-239 tweets from May 26 to June 2, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from May 26 12:00 PM ET to June 2, 2026 12:00 PM ET.

For the purposes of this market, only main feed posts, quote posts and rep
  - (2026-05-31) [Polymarket] Will the Fed Pause–Pause–Cut in the next three decisions (Mar–Apr–Jun)?
      The FED interest rates are defined in this market by the upper bound of the target federal funds rate. The decisions on the target federal funds rate are made by the Federal Open Market Committee (FOMC) meetings.

This m
  - (2026-05-31) [Polymarket] Will Elon Musk post 920-959 tweets in May 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X during the month of May 2026.

For the purposes of this market, only main feed posts, quote posts and reposts will count.

Repli
  - (2026-05-31) [Polymarket] Will Solana dip to $60 by December 31, 2026?
      This market will immediately resolve to “Yes” if any Binance 1-minute candle for Solana (SOL/USDT) between November 24, 2025, 14:30 and December 31, 2026, 23:59 in the ET timezone has a final “Low” price equal to or lowe
  - (2026-05-31) [Polymarket] US x Cuba diplomatic meeting by June 30?
      This market will resolve to "Yes" if there is a diplomatic meeting between representatives of the United States and Cuba between market creation and the listed date, 11:59 PM ET. Otherwise, this market will resolve to “N
  - (2026-05-31) [Polymarket] Will Bitcoin dip to $45,000 in May?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa
  - (2026-05-31) [Polymarket] Iran agrees to surrender enriched uranium stockpile by July 31, 2026?
      This market will resolve to "Yes" if Iran publicly agrees to surrender its enriched uranium stockpile by July 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to “No”.

An official pledge by Iran to surrender i
  - (2026-05-31) [Polymarket] Will Russia capture all of Prymorske by May 31, 2026?
      This market will resolve to “Yes” if, according to the ISW map, Russia captures the entirety of Prymorske, Zaporizhzhia Oblast, by May 31, 2026, 11:59 PM ET.

Prymorske will be considered captured if the entirety of the 

### U.S. Weather + Severe / Climate Outlooks — 98 new of 100 total
  - (2026-05-31) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-31) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued May 31 at 4:18AM CDT until May 31 at 9:00AM CDT by NWS Memphis TN
      * WHAT...Visibility one-quarter mile or less in dense fog.

* WHERE...Portions of North Mississippi and West Tennessee.

* WHEN...Until 9 AM CDT this morning.

* IMPACTS...Low visibility could make driving conditions haz
  - (2026-05-31) [Severe] High Wind Watch: High Wind Watch issued May 31 at 3:11AM MDT until May 31 at 3:00PM MDT by NWS Cheyenne WY
      * WHAT...West winds 30 to 40 mph with gusts up to 60 mph possible.

* WHERE...South Laramie Range and Foothills including the Interstate
80 Summit between Cheyenne and Laramie, and Bordeaux area along
Interstate 25 betwe
  - (2026-05-31) [Severe] High Wind Warning: High Wind Warning issued May 31 at 3:11AM MDT until May 31 at 9:00AM MDT by NWS Cheyenne WY
      * WHAT...West winds 25 to 40 mph with gusts up to 65 mph expected.

* WHERE...North Snowy Range Foothills including Arlington and Elk
Mountain along Interstate 80.

* WHEN...Until 9 AM MDT this morning.

* IMPACTS...Main
  - (2026-05-31) [Moderate] Gale Warning: Gale Warning issued May 31 at 1:37AM PDT until May 31 at 11:00PM PDT by NWS Medford OR
      * WHAT...North winds 20 to 30 kt with gusts up to 40 kt and
steep to very steep and hazardous seas 8 to 11 ft. North winds
increase to gales on Sunday, 25 to 35 kt with gusts to 45 kt
and seas increase to 10 to 14 ft.

*
  - (2026-05-31) [Moderate] Hazardous Seas Warning: Hazardous Seas Warning issued May 31 at 1:37AM PDT until May 31 at 11:00AM PDT by NWS Medford OR
      * WHAT...North winds 20 to 30 kt with gusts up to 40 kt and
steep to very steep and hazardous seas 8 to 11 ft. North winds
increase to gales on Sunday, 25 to 35 kt with gusts to 45 kt
and seas increase to 10 to 14 ft.

*
  - (2026-05-31) [Moderate] Gale Warning: Gale Warning issued May 31 at 1:37AM PDT until May 31 at 11:00PM PDT by NWS Medford OR
      * WHAT...North winds 20 to 30 kt with gusts up to 40 kt and
steep to very steep and hazardous seas 8 to 11 ft. North winds
increase to gales on Sunday, 25 to 35 kt with gusts to 45 kt
and seas increase to 9 to 13 ft.

* 
  - (2026-05-31) [Moderate] Hazardous Seas Warning: Hazardous Seas Warning issued May 31 at 1:37AM PDT until May 31 at 11:00PM PDT by NWS Medford OR
      * WHAT...North winds 20 to 30 kt with gusts up to 40 kt and
steep to very steep and hazardous seas 7 to 10 ft.

* WHERE...All areas. Very steep and hazardous seas are expected
south of Bandon.

* WHEN...From 11 AM to 11 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 1 new of 79 total
  - (2026-05-29) [commodity] Gold: 4593.0
      open=4527.6  high=4627.1  low=4519.5  close=4593  vol=

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 101 total
  - (2026-05-31) [USASpending] $41,068,913,544 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy.  Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHA
  - (2026-05-31) [USASpending] $35,063,605,649 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy.  Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-05-31) [USASpending] $25,752,009,752 → BATTELLE ENERGY ALLIANCE, LLC: MANAGEMENT AND OPERATIONS OF THE INL
      Agency: Department of Energy.  Description: MANAGEMENT AND OPERATIONS OF THE INL
  - (2026-05-31) [USASpending] $17,432,021,006 → HONEYWELL FEDERAL MANUFACTURING & TECHNOLOGIES, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SEC
      Agency: Department of Energy.  Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SECURITY CAMPUS -- CONTRACT NO. DE-NA0002839
  - (2026-05-31) [USASpending] $14,781,032,587 → FLUOR MARINE PROPULSION, LLC: MANAGEMENT AND OPERATION OF THE NAVAL NUCLEAR LABORATORY AND
      Agency: Department of Energy.  Description: MANAGEMENT AND OPERATION OF THE NAVAL NUCLEAR LABORATORY AND NAVAL NUCLEAR PROPULSION PROGRAM SUPPORT

### Congressional STOCK Act Trades (House + Senate) — 0 new of 1 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 0 new of 40 total
  (no new items today)

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - (2026-05-31) [Top] PLATNER, GRAHAM (DEM, Senate ME): $16.31M raised
      cycle 2026 receipts $16.31M · disbursements $14.13M · net $+2.18M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 15 new of 15 total
  - (2026-05-31) NCR8821 (United States)
      icao24: ad3c48 · position: (8.0008, 78.8339) · alt: 10652m · 911km/h
  - (2026-05-31) JAF50T (Bulgaria)
      on ground · 21km/h
  - (2026-05-31) RRR4152 (United Kingdom)
      icao24: 43c5ef · position: (51.3849, -0.3694) · alt: 1912m · 470km/h
  - (2026-05-31) JAF7LD (Belgium)
      icao24: 449682 · position: (49.2746, 1.9735) · alt: 10058m · 829km/h
  - (2026-05-31) JAF2WA (Belgium)
      icao24: 449683 · position: (42.9718, 17.1506) · alt: 12192m · 770km/h
  - (2026-05-31) RRR9964 (United Kingdom)
      on ground · 9km/h
  - (2026-05-31) JAF9CK (Belgium)
      icao24: 44d1ba · position: (51.0664, 3.1192) · alt: 2461m · 555km/h
  - (2026-05-31) JAF99Y (Belgium)
      icao24: 44d1a6 · position: (46.6895, -1.4701) · alt: 10363m · 878km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 15 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-31) Will Ivory Coast win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,519,169 · resolves 2026-07-20
  - (2026-05-31) Roland Garros WTA: Marta Kostyuk vs Iga Swiatek
      yes price: 32% · 24h volume: $1,364,831 · resolves 2026-06-07
  - (2026-05-31) Will Australia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,149,775 · resolves 2026-07-20
  - (2026-05-31) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,115,780 · resolves 2026-07-20
  - (2026-05-31) Will the San Antonio Spurs win the 2026 NBA Finals?
      yes price: 64% · 24h volume: $1,002,819 · resolves 2026-07-01
  - (2026-05-31) Will Satoshi's identity be revealed by December 31?
      yes price: 6% · 24h volume: $907,069 · resolves 2026-12-31
  - (2026-05-31) Will the New York Knicks win the 2026 NBA Finals?
      yes price: 35% · 24h volume: $878,074 · resolves 2026-07-01
  - (2026-05-31) Will Barack Obama win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $848,354 · resolves 2028-11-07

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-05-31) [Marginal Revolution] Sunday assorted links
      1. A new theory of galaxy formation? 2. Using AI to sell your house (NYT). 3. Ryan Graves. 4. Henry Oliver on reading Proust and also The Golden Bowl, an excellent essay. 5. On Spotify and Apple Music, are now about half
  - (2026-05-31) [Marginal Revolution] Lifestyle and living standards arbitrage
      Since the Eisenhower administration, the U.S. hasn’t collected comprehensive statistics on the number of citizens leaving. Yet data on residence permits, foreign home purchases, student enrollments and other metrics from
  - (2026-05-30) [Marginal Revolution] Saturday assorted links
      1. Which foreign food chains have made it in NYC? 2. Testing products on AI-generated buyers. 3. Are Vatican pronouncements rising in status? 4. A saner Argentina take.  I notice that PTDS is spreading. 5. Yupsy-dupsy. 6

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-31) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=30, 14d-median=30; carrying terms: issued, environmental, designated, captain, national, coast, order, service, directives, amendment, needed, temporary
- state_bills: today=181, 7d-median=155, 14d-median=155
- state_news: today=444, 7d-median=722, 14d-median=722; carrying terms: penitentiary, economic, increases, pregnant, critics, reflects, launch, westbrook, gubernatorial, leaders, version, charged
- local_news: today=231, 7d-median=248, 14d-median=248; carrying terms: block, osdyyegpbevhlbennbk, fetchpriority, roswell, leaders, death, charged, police, building, vehicle, tornado, makes
- foreign_news: today=832, 7d-median=868, 14d-median=868; carrying terms: ebola, economic, casualties, towards, temperatures, launch, reflects, sight, kindergarten, leaders, luxury, police
- chinese_internal: today=261, 7d-median=277, 14d-median=277; carrying terms: caixin, cbmidefvx, launches, cbmickfvx, cbmiyefvx, record, politics, cbmib, cbmiw, cbmibefvx, color, cbmibkfvx
- russian_internal: today=838, 7d-median=1021, 14d-median=1021; carrying terms: ntech, origin, spiegel, europe, centcom, tasnim, times, httperror, bloomberg, stellantis, telegram, russian
- ukrainian_internal: today=120, 7d-median=123, 14d-median=123; carrying terms: issued, regions, economic, pushed, casualties, defenses, launch, leaders, nuclear, living, belarusian, launches
- ukraine_theater: today=290, 7d-median=365, 14d-median=365; carrying terms: yesterday, hwzwjvmze, cuxoyji, wdffux, veunhwhgznty, kuwlxx, denys, hcxzwnzdwn, pvckldn, buhic, police, qzhrnle
- paper_bets: today=136, 7d-median=141, 14d-median=141; carrying terms: missiles, powell, initiated, colonize, largest, minister, count, formally, leaders, debut, above, released
- weather: today=100, 7d-median=112, 14d-median=112; carrying terms: issued, afdffc, scattered, temperatures, firerating, moving, level, cooler, above, saturday, flooding, begins
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: index, nasdaq, canada, india, mexico, australia, crypto, kospi, silver, coffee, copper, italy
- sanctions_procurement: today=101, 7d-median=97, 14d-median=97; carrying terms: council, lockheed, science, economic, threatening, independence, counter, mufswgh, haiti, myanmar, launch, mediterranean
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quiverquant, quantitative, unauthorized, httperror, client, https, quiver, error
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: docks, crespo, concesionaria, havana, solutions, khalil, blanche, scotus, webuild, trustees, starkey, bondi
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, holdings, david, financial, brian, group
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, friends, robinson, receipts, graham, cycle, alexandria, jonathan, lindsey, joseph, sherrod, michael
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=15, 7d-median=0, 14d-median=0
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=15, 7d-median=16, 14d-median=16; carrying terms: injection, overwrite, product, origin, based, error, validation, remediation, drupal, explorer, defender, vendor
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: hormuz, permanent, continue, peace, resolves, ceasefire, world, strait, volume, price, returns, bitcoin
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: policy, conversable, revolution, story, https, economist, marginal, class, links, marginalrevolution, assorted, recipients
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: katherine, boebert, doris, stevens, economic, bessent, ogles, carlos, harriet, graves, tiffany, jasmine
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, evidence, today, sufficient, unavailable, market, decision, markets, either, placed, paper, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] ECB press: Financial stability vulnerabilities remain elevated as geoeconomic shock unfolds
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*