# WORLDSCOPE morning brief — 2026-08-29

## Headline
2311 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (486) · Russian Internal News (state + in-exile) (387) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (263) · Chinese Internal News (209) · State-Level News (116) · Local News: St. Louis + Atlanta (115) · State Legislative Action (104) · U.S. Weather + Severe / Climate Outlooks (68) · Ukrainian Internal News (national + local Kyiv) (42) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 486 new of 1030 total
  - (2026-08-28) [Global] Trump announces new US oil agreement with Venezuela
  - (2026-08-29) [Global] Search continues as number missing in Nepal-Tibet floods rises to 2,478 – as it happened
  - (2026-08-29) [Global] Statins can safely cut risk of heart attacks or strokes in healthy people aged over 70, world-first clinical trial shows
  - (2026-08-29) [Global] Plug-in solar panels could save households up to $370 a year – if Australia made them legal as in the UK
  - (2026-08-29) [Global] What we know about the Australians missing in the Nepal floods
  - (2026-08-28) [Global] Controversial plans for a Daniel Andrews sculpture officially scrapped by Victorian government

### Russian Internal News (state + in-exile) — 387 new of 1053 total
  - (2026-08-29) Москвичи выступили против переноса памятника Пушкину. Михалков предлагал установить его на другой стороне Тверской улицы | LEDE: Большинство жителей Москвы проголосовали за то, чтобы оставит] (ru: Мос…
      Большинство жителей Москвы проголосовали за то, чтобы оставить памятник Александру Пушкину на прежнем месте. Об этом сообщила пресс-служба московской мэрии.
  - (2026-08-29) В результате российской атаки по складам под Киевом погибли 27 человек | LEDE: В результате атаки по складам в Бучанском районе Киевской области погибли 27 человек. Еще 42 человека, в том чи] (ru: В р…
      В результате атаки по складам в Бучанском районе Киевской области погибли 27 человек. Еще 42 человека, в том числе четверо детей, получили ранения разной степени тяжести, сообщил глава местной областной военной администр…
  - (2026-08-29) В Ростовской области ввели режим ЧС. Из-за беспилотников регион не может отправлять зерно на экспорт | LEDE: В Ростовской области с 28 августа введен режим чрезвычайной ситуации региональног] (ru: В Р…
      В Ростовской области с 28 августа введен режим чрезвычайной ситуации регионального уровня. Соответствующее распоряжение губернатора Юрия Слюсаря опубликовано на портале правовой информации региона.
  - (2026-08-29) В Подмосковье зарезали 12-летнего школьника. Подозреваемые в убийстве — две старшеклассницы. По одной из версий, они вдохновились сериалом «Игра в кальмара» | LEDE: Полиция Московской област] (ru: В П…
      Полиция Московской области сообщила о задержании двух несовершеннолетних девушек, которые подозреваются в убийстве школьника в городском округе Орехово-Зуево.
  - (2026-08-29) США заключили с Венесуэлой «крупнейшую нефтяную сделку в истории» | LEDE: Дональд Трамп объявил о заключении соглашения, в рамках которого США получат контроль над более чем 65 миллиардами б] (ru: США…
      Дональд Трамп объявил о заключении соглашения, в рамках которого США получат контроль над более чем 65 миллиардами баррелей доказанных запасов нефти в Венесуэле.
  - (2026-08-29) Украинские беспилотники атаковали склады Ozon и DNS в Ростовской области | LEDE: Украина нанесла удар беспилотниками по Ростовской области, сообщил губернатор Юрий Слюсарь. По его словам, по] (ru: Укр…
      Украина нанесла удар беспилотниками по Ростовской области, сообщил губернатор Юрий Слюсарь. По его словам, пострадали семь человек. Четверо из них, в том числе двое детей, госпитализированы.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 263 new of 468 total
  - (2026-08-28) [FIRMS] thermal anomaly 52.849, 29.990 (FRP 1.57 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-28 0109Z, FRP 1.57 MW
  - (2026-08-28) [FIRMS] thermal anomaly 51.029, 34.929 (FRP 0.88 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-28 0109Z, FRP 0.88 MW
  - (2026-08-28) [FIRMS] thermal anomaly 51.893, 29.340 (FRP 6.54 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-28 0109Z, FRP 6.54 MW
  - (2026-08-28) [FIRMS] thermal anomaly 50.419, 33.949 (FRP 2.21 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-28 0109Z, FRP 2.21 MW
  - (2026-08-28) [FIRMS] thermal anomaly 50.578, 31.208 (FRP 0.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-28 0109Z, FRP 0.41 MW
  - (2026-08-28) [FIRMS] thermal anomaly 50.577, 31.212 (FRP 0.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-28 0109Z, FRP 0.41 MW

### Chinese Internal News — 209 new of 305 total
  - (2026-08-28) China Raises Threshold for New-Home Presales Under New National Standard - Caixin Global
      China Raises Threshold for New-Home Presales Under New National Standard Caixin Global
  - (2026-08-28) AI Chipmaker Sunrise Doubles Valuation After Raising 2 Billion Yuan - Caixin Global
      AI Chipmaker Sunrise Doubles Valuation After Raising 2 Billion Yuan Caixin Global
  - (2026-08-28) China Overhauls Real Estate Credit Rules in Shift Away From Presale Model - Caixin Global
      China Overhauls Real Estate Credit Rules in Shift Away From Presale Model Caixin Global
  - (2026-08-29) 江苏南通： 船舶海工企业生产忙 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5BTGtOR3FCTXpxQ0dvYzFHdTM5Tzg4bGVzcXlMbm94R3JvRDA3MkFyM2Q4RmpCVXk3eGpiQmpsYXRtc2FlT05uRm0zdDhVeFVyS3Ni] (zh:…
      江苏南通： 船舶海工企业生产忙 人民图片
  - (2026-08-28) 山东烟台：3300 米车道高性能清洁能源滚装船投运 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE4tdFNNSHVsYnRQZUNURk1vaXlyMUFzYUxCMmpaYXBjNmRyaElJX25XenBYaUdxMERwLWltWGptVXA5RnBXam5vd29xTH] (zh:…
      山东烟台：3300 米车道高性能清洁能源滚装船投运 人民图片
  - (2026-08-28) 河北围场： 坝上草原饲草收割忙 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE00X3FubkJUbllPWkhSMzhFdklRRWFQSV9qQWp4Qk5HREtnZ211UWtkazFuZHZpajJOUWdBc1FmaGpuSmpjRU8zY18xSWF4bEc0dnQ0] (zh:…
      河北围场： 坝上草原饲草收割忙 人民图片

### State-Level News — 116 new of 632 total
  - (2026-08-28) [Alabama] Flags Lowered Honoring Former State Representative Charles Wiley Whatley
      Download
  - (2026-08-28) [California] What to know about the new California privacy law that became a flashpoint over free speech
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/061625-Farm-Visit-Rural-Mobile-Health-LV-CM-30.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-siz…
  - (2026-08-28) [California] Will lawmakers water down data center rules?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/091225_End-Of-Session_FG_CM_35.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-08-28) [California] California’s budget is so convoluted that even experts are perplexed at what it contains
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/051426_May-Budget-Revise_MG_CM_17.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-08-28) [California] The data center backlash is here — and Big Tech is spending big to combat it
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/091225_End-Of-Session_FG_CM_26.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-08-28) [California] California Democrats race to ban electric shock gloves before ICE buys them
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082726-Shock-Gloves-DL-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### Local News: St. Louis + Atlanta — 115 new of 245 total
  - (2026-08-29) [St. Louis] See the Aug. 29, 1926, front page: Blue law of 1794 is invoked to stop Sunday baseball
      Headlines from the Aug. 29, 1926, front page include: 2 formally charged with Doss murder
  - (2026-08-29) [St. Louis] Meyer, Mary
      Meyer, Mary
  - (2026-08-29) [St. Louis] Meyer, Mary
      Mary "Carol" Meyer (maiden Leach) passed away into the arms of Jesus on May 9, 2026, in Calhoun, GA at the age of 89. As her daughter writing this I hope you get to know my mother. Mary, better known…
  - (2026-08-29) [St. Louis] Wagner, Maureen
      Wagner, Maureen
  - (2026-08-29) [St. Louis] Wagner, Maureen
      Maureen Ann Wagner, age 86, of Glendale, Missouri, beloved mother and friend passed away surrounded by love 8/27/26.
  - (2026-08-29) [St. Louis] Wolff, Norman
      Wolff, Norman

### State Legislative Action — 104 new of 188 total
  - (2026-08-29) [Alaska SB 162] An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
      An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
  - (2026-08-29) [Alaska SB 236] An Act creating a veteran sentencing program; relating to release procedures; amending Rules 35 and 43, Alaska Rules of Criminal Procedure; and providing for an effective date.
      An Act creating a veteran sentencing program; relating to release procedures; amending Rules 35 and 43, Alaska Rules of Criminal Procedure; and providing for an effective date.
  - (2026-08-29) [Alaska SB 219] An Act relating to perfluoroalkyl and polyfluoroalkyl substances; relating to thermal remediation of perfluoroalkyl and polyfluoroalkyl substance contamination; and providing for an ef…
      An Act relating to perfluoroalkyl and polyfluoroalkyl substances; relating to thermal remediation of perfluoroalkyl and polyfluoroalkyl substance contamination; and providing for an effective date.
  - (2026-08-27) [District of Columbia B 26-0463] Judith Heumann Memorial Workers with Disabilities Act of 2025
      Judith Heumann Memorial Workers with Disabilities Act of 2025
  - (2026-08-27) [District of Columbia B 26-0356] Prenatal and Postpartum Remote Patient Monitoring Clarification Amendment Act of 2025
      Prenatal and Postpartum Remote Patient Monitoring Clarification Amendment Act of 2025
  - (2026-08-27) [District of Columbia B 26-0327] Schools First Amendment Act of 2025
      Schools First Amendment Act of 2025

### U.S. Weather + Severe / Climate Outlooks — 68 new of 83 total
  - (2026-08-29) [Moderate] Special Weather Statement: Special Weather Statement issued August 29 at 4:32AM CDT by NWS Grand Forks ND
      At 430 AM CDT, Numerous thunderstorms with very heavy rain were over the northern parts of Otter Tail county. 1 to 3 inches of rain has fallen in the last 3 hours in these areas. Gusty winds as well. The storms were movi…
  - (2026-08-29) [Moderate] Special Weather Statement: Special Weather Statement issued August 29 at 5:30AM EDT by NWS Marquette MI
      Patchy dense fog is being seen from Gwinn eastward early this morning as observations are reporting visibilities down to a quarter mile or less at times. Drivers should remain aware of their surroundings and keep their l…
  - (2026-08-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-29) [Severe] Special Marine Warning: Special Marine Warning issued August 29 at 5:24AM EDT until August 29 at 6:30AM EDT by NWS Tallahassee FL
      For the following areas... Apalachee Bay or Coastal Waters From Keaton Beach to Ochlockonee River Fl out to 20 Nm... Coastal Waters From Ochlockonee River to Apalachicola FL out to 20 Nm... Waters from Suwannee River to…
  - (2026-08-29) [Moderate] Special Weather Statement: Special Weather Statement issued August 29 at 2:02AM PDT by NWS Elko NV
      At 158 AM PDT, Doppler radar was tracking a cluster of strong thunderstorms 9 miles southwest of Schellbourne, moving northeast at 45 mph. These cells have a history of producing cloud to ground lightning strikes and cou…
  - (2026-08-29) [Unknown] Air Quality Alert: Air Quality Alert issued August 29 at 4:00AM CDT by NWS Memphis TN
      AQAMEG The Shelby County Health Department has issued a Code Orange Ozone Forecast effective for Shelby County Tennessee, Crittenden County Arkansas, and DeSoto County Mississippi, including the city of Memphis for today…

### Ukrainian Internal News (national + local Kyiv) — 42 new of 112 total
  - (2026-08-29) Зеленський про удар по Бучанському району: Боєприпасів поруч із житловою забудовою бути не може | LEDE: У Бучанському районі детонація складу після російського удару зруйнувала будинки й пансіо] (uk:…
      У Бучанському районі детонація складу після російського удару зруйнувала будинки й пансіонат, 27 загиблих. Слідство триває, винні понесуть покарання.
  - (2026-08-29) У Лондоні масштабна пожежа спричинила перебої у роботі метро та залізничного транспорту | LEDE: ] (uk: У Лондоні масштабна пожежа спричинила перебої у роботі метро та залізничного тра)
  - (2026-08-29) ОВА: 27 людей загинули унаслідок атаки РФ в Бучанському районі | LEDE: Кількість загиблих унаслідок російської атаки та подальшої детонації в Бучанському районі Київщини зросла до 27, ще 42 люд] (uk:…
      Кількість загиблих унаслідок російської атаки та подальшої детонації в Бучанському районі Київщини зросла до 27, ще 42 людини постраждали.
  - (2026-08-29) Молодіжне крило ультраправої "АдН" проти закликів вивести Німеччину з єврозони | LEDE: ] (uk: Молодіжне крило ультраправої "АдН" проти закликів вивести Німеччину з єврозони)
  - (2026-08-29) Поліція Непалу: Зросла кількість зниклих українців | LEDE: Кількість зниклих у зоні стихійного лиха в Непалі громадян України зросла з 56 до 64, заявила місцева поліція.] (uk: Поліція Непалу: Зросла к…
      Кількість зниклих у зоні стихійного лиха в Непалі громадян України зросла з 56 до 64, заявила місцева поліція.
  - (2026-08-29) Іспанія просить ЄС про допомогу з мігрантами у Сеуті | LEDE: ] (uk: Іспанія просить ЄС про допомогу з мігрантами у Сеуті)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-29) [HANDLER RICHARD B] Form 4 (Reporting)
      filed 2026-08-29 01:53 UTC · role: Reporting — Filed: 2026-08-28 AccNo: 0001214659-26-011109 Size: 13 KB
  - (2026-08-29) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-08-29 01:53 UTC · role: Issuer — Filed: 2026-08-28 AccNo: 0001214659-26-011109 Size: 13 KB
  - (2026-08-29) [FRIEDMAN BRIAN P] Form 4 (Reporting)
      filed 2026-08-29 01:53 UTC · role: Reporting — Filed: 2026-08-28 AccNo: 0001214659-26-011108 Size: 8 KB
  - (2026-08-29) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-08-29 01:53 UTC · role: Issuer — Filed: 2026-08-28 AccNo: 0001214659-26-011108 Size: 8 KB
  - (2026-08-29) [Larson Matthew Scott] Form 4 (Reporting)
      filed 2026-08-29 01:52 UTC · role: Reporting — Filed: 2026-08-28 AccNo: 0001214659-26-011107 Size: 5 KB
  - (2026-08-29) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-08-29 01:52 UTC · role: Issuer — Filed: 2026-08-28 AccNo: 0001214659-26-011107 Size: 5 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 29 new of 29 total
  - (2026-08-31) [No title available]
  - (2026-08-31) Further Ensuring Affordable Beef for the American Consumer
  - (2026-08-31) Affirmative Asylum Referrals Without Interview
  - (2026-08-31) Declaring a National Emergency To Secure the United States Bulk-Power System
  - (2026-08-31) [No title available]
  - (2026-08-31) Fifth Anniversary of the Attack at Abbey Gate

### Government & military aircraft airborne (OpenSky) — 23 new of 26 total
  - (2026-08-29) INDIA2 (India)
      icao24: 8002fb · position: (11.7558, 77.2115) · alt: 5181m · 737km/h
  - (2026-08-29) RFF07 (Portugal)
      icao24: 496ca7 · position: (37.0125, -7.9624) · on ground · 38km/h
  - (2026-08-29) JAF3MJ (Belgium)
      icao24: 44d1a7 · position: (49.3798, 2.2281) · alt: 9692m · 859km/h
  - (2026-08-29) JAF66L (Belgium)
      icao24: 44d1a5 · position: (50.9086, 4.1603) · alt: 2628m · 627km/h
  - (2026-08-29) JAF3NE (Belgium)
      icao24: 44d1b3 · position: (46.0363, -0.1191) · alt: 10363m · 911km/h
  - (2026-08-29) JAF99Y (Belgium)
      icao24: 44d1c2 · position: (45.8232, -2.0784) · alt: 11582m · 910km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 18 new of 108 total
  - (2026-08-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] 1268 - Office of Foreign Assets Control (.gov)
      1268 Office of Foreign Assets Control (.gov)
  - (2026-08-29) [USASpending] $42,436,211,928 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-08-29) [USASpending] $34,654,023,639 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS
  - (2026-08-29) [USASpending] $26,444,741,720 → BATTELLE ENERGY ALLIANCE, LLC: MANAGEMENT AND OPERATIONS OF THE INL
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATIONS OF THE INL
  - (2026-08-29) [USASpending] $19,921,172,460 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…

### IT, InfoSys & cybersecurity news (last 7 days) — 14 new of 56 total
  - (2026-08-29) [The Register] Xbox respawns IKEA furniture with gaming range
      At last, somewhere comfy to sit while your PlayStation 5 game loads
  - (2026-08-28) [BleepingComputer] McKesson discloses breach after ShinyHunters claims patient data theft
      Healthcare and pharmaceutical distribution giant McKesson has disclosed a cybersecurity incident involving unauthorized access to third-party applications and data theft, with the ShinyHunters extortion group claiming it…
  - (2026-08-28) [The Hacker News] Berlin Refuses to Pay Hackers Who Stole Data From the City's State Network
      Berlin's state government has confirmed that it is the target of an extortion attempt following the August compromise of the city's state administrative network, and said it will not meet the extortionists' demands. The…
  - (2026-08-28) [The Hacker News] Cosmos EVM Flaw Exploited After Cosmos Labs Knew Every Blockchain Running It Was Vulnerable
      Cosmos Labs has warned that a critical balance-handling flaw in the shared Cosmos EVM module was exploited to drain funds from six blockchains between August 20 and August 25, 2026. The vulnerability, designated GHSA-7g4…
  - (2026-08-28) [Schneier on Security] Friday Squid Blogging: Truckload of Squid Spills in Rhode Island
      Ugh: A tractor-trailer rollover sent a truckload of squid spilling into a Rhode Island roadway, leaving a stench as they sat in the road for hours in the summer heat. Local authorities have dubbed it the “Squidpocalypse…
  - (2026-08-28) [The Register] Researcher shows how Claude Code can be tricked simply by asking it to summarize a website
      More prompt-injection hijinks from wunderwuzzi

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-29) Will Pete Hegseth win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,446,743 · resolves 2028-11-07
  - (2026-08-29) LoL: T1 vs BNK FEARX - Game 2 Winner
      yes price: 0% · 24h volume: $1,052,680 · resolves 2026-08-29
  - (2026-08-29) Will Liverpool FC win on 2026-08-29?
      yes price: 68% · 24h volume: $1,008,124 · resolves 2026-08-29
  - (2026-08-29) LoL: T1 vs BNK FEARX - Game 1 Winner
      yes price: 100% · 24h volume: $970,647 · resolves 2026-08-29
  - (2026-08-29) LoL: T1 vs BNK FEARX (BO5) - LCK Playoffs
      yes price: 78% · 24h volume: $599,356 · resolves 2026-08-29
  - (2026-08-29) LoL: Top Esports vs LGD Gaming (BO5) - LPL Playoffs
      yes price: 62% · 24h volume: $579,801 · resolves 2026-08-29

### Paper Trading Scorecard — 12 new of 130 total
  - (2026-08-29) [Polymarket] Will the Fed increase interest rates by 50+ bps after the September 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-08-29) [Kalshi] MacAskill–Moll AI growth challenge · Who will win?
      Q3 2026 through Q4 2033
  - (2026-08-29) [Manifold] What lasting peace deal will come first? Russia's or Iran's?
  - (2026-08-29) [Manifold] Will Valve release a new VR game before the end of 2026?
  - (2026-08-29) [Manifold] Week 2 EPL- Aston Villa vs Arsenal (August 31 2026) Will Arsenal WIN @ Aston Villa?
  - (2026-08-29) [Manifold] "Spider-Man: Brand New Day" passes "Avengers: Endgame"? (>$2.8B worldwide)

### USGS earthquakes (M4.5+, past day) — 10 new of 15 total
  - (2026-08-29) M 5.1 - Southwest Indian Ridge
      M5.1 · Southwest Indian Ridge · depth 10 km
  - (2026-08-29) M 5.0 - 64 km W of Labuha, Indonesia
      M5.0 · 64 km W of Labuha, Indonesia · depth 41.899 km
  - (2026-08-28) M 5.0 - 191 km ESE of Kimbe, Papua New Guinea
      M5.0 · 191 km ESE of Kimbe, Papua New Guinea · depth 10 km
  - (2026-08-29) M 4.9 - South Sandwich Islands region
      M4.9 · South Sandwich Islands region · depth 89.886 km
  - (2026-08-28) M 4.9 - 124 km N of Aksu, China
      M4.9 · 124 km N of Aksu, China · depth 10 km
  - (2026-08-29) M 4.8 - 85 km W of Petrolia, CA
      M4.84 · 85 km W of Petrolia, CA · depth 10 km

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-08-28) U.S. Court of Appeals, 7th Cir.: Randy Talley v. Carl Gloede
  - (2026-08-28) U.S. Court of Appeals, 7th Cir.: Amanda Sima v. Benesch, Friedlander, Coplan & Aronoff LLP
  - (2026-08-28) U.S. Court of Appeals, 5th Cir.: M. v. Aledo
  - (2026-08-28) U.S. Court of Appeals, 5th Cir.: Pena v. Starr County, Texas
  - (2026-08-26) U.S. Court of Appeals, 7th Cir.: Central States SE & SW Areas Health & Welfare Fund v. Alan McClain

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-08-29) [Marginal Revolution] Costco facts of the day
      Costco sold 157.4mn rotisserie chickens worldwide last year, almost double the number of a decade ago. “It’s $4.99 and for Costco members, that’s one fantastic deal. I don’t think you can produce it for that,” said Walt…
  - (2026-08-29) [Marginal Revolution] *Visions from San Francisco Bay*
      European and American capitalism were different. The violence of human clashes in America took place on the surface, in the open. The violence in Europe became formalized, coalesced with class divions hallowed by centuri…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=25, 14d-median=20; carrying terms: certain, establish, public, national, management, proposed, action, service, unless, temporary, specifically, safety
- state_bills: today=188, 7d-median=137, 14d-median=136; carrying terms: persons, providing, administered, support, prescribed, practices, officer, years, application, state, financial, enter
- state_news: today=632, 7d-median=632, 14d-median=614; carrying terms: possible, still, support, license, received, statewide, related, toomanyredirects, though, officer, shirt, exceeded
- local_news: today=245, 7d-median=245, 14d-median=240; carrying terms: years, flock, injured, morning, state, shooting, alert, north, children, falcons, faces, headlines
- foreign_news: today=1030, 7d-median=1030, 14d-median=1012; carrying terms: jinping, possible, still, loans, market, support, ministers, trips, related, powder, officer, london
- chinese_internal: today=305, 7d-median=289, 14d-median=286; carrying terms: market, lxtfb, politics, cbmix, cbmiw, cbmiaefvx, lxtfa, cbmibkfvx, cbmib, title, global, cbmiakfvx
- russian_internal: today=1053, 7d-median=1053, 14d-median=1042; carrying terms: telegraph, https, gazeta, times, forbidden, novayagazeta, httperror, error, politico, istories, bloomberg, europe
- ukrainian_internal: today=112, 7d-median=112, 14d-median=112; carrying terms: support, ministers, ukrinform, vladimir, attacks, years, country, august, europe, secure, elections, injured
- ukraine_theater: today=468, 7d-median=841, 14d-median=860; carrying terms: cbmiwkfvx, cuxnzghps, deployment, cbmingfbvv, armor, nmekdymwzfwxywzlj, diqjrvyuxluxrfzf, tghtd, xsfhntktxmhy, ynldfzvvwqzftu, vadvxvtnowm, support
- paper_bets: today=130, 7d-median=131, 14d-median=132; carrying terms: jinping, johnson, growth, republican, nuclear, market, inflation, population, manifold, official, goals, anthropic
- weather: today=83, 7d-median=135, 14d-median=145; carrying terms: service, boston, possible, cramps, south, holly, afdtbw, center, lower, afdilx, southeast, related
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexjpus, personal, growth, nonfarm, cpiaucsl, funds, treasury, balance, dexchus, total, inflation, money
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, crypto, close, range, equities, nasdaq, futures, agriculture, rates, treasury, credit, china
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=105, 14d-median=100; carrying terms: proliferation, yemen, latinscript, stability, protecting, south, hfufrmmg, guinea, support, february, chemical, office
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quiver, congresstrading, quiverquant, httperror, unauthorized, quantitative, error, client
- billionaires: today=0, 7d-median=30, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, california, appeals, connecticut, center, company, america, delaware, thomas, county
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, scott, robert, financial, david, group, richard, brian, joseph
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: robert, filing, johnson, krishnamoorthi, booker, platner, committee, ossoff, ocasio, cortez, alexandria, james
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan, defense, china
- gdelt_gkg: today=0, 7d-median=25, 14d-median=45; carrying terms: english, trump, keywords, russia, perimeter, themes, russian, sanctions, ukrainian, spanish, business, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: onset, largest, italy, announcing, resurgence, routine, implicated, bulape, coinci, patient, intensive, verified
- cisa_kev: today=20, 7d-median=13, 14d-median=12; carrying terms: vendor, remediation, function, injection, vulnerability, authentication, command, microsoft, product, missing, project, service
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=15, 7d-median=14, 14d-median=18; carrying terms: depth, indonesia, islands, japan, russia, region, south, philippines, chile, papua, ridge, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: champions, price, september, championship, volume, shakhtar, donetsk, resolves, interest, rates, league, august
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, class, economist, revolution, conversable, marginal, demand, number, marginalrevolution, together, center, construction
- tech_news: today=56, 7d-median=55, 14d-median=56; carrying terms: models, attacks, world, patch, techcrunch, https, agents, hacker, around, breach, technology, bleepingcomputer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: comptroller, johnson, julia, pettersen, schakowsky, boston, coleman, booker, warsh, richard, susan, nikki
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, markets, sufficient, claude, placement, evidence, paper, converges, unavailable, market, either, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*