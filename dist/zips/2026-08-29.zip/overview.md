# WORLDSCOPE morning brief — 2026-08-29

## Headline
2282 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (561) · Russian Internal News (state + in-exile) (467) · World leaders & government officials (324) · Chinese Internal News (219) · State-Level News (134) · Local News: St. Louis + Atlanta (132) · U.S. Weather + Severe / Climate Outlooks (73) · State Legislative Action (59) · Ukrainian Internal News (national + local Kyiv) (58) · SEC Form 4 insider transactions (recent) (40) · Ukraine Theater (total-war monitoring) (37) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 561 new of 1027 total
  - (2026-08-29) [Global] Footage of Tibet floods isn't being shown in China - and we know little about victims there
      Some of the most dramatic footage from the deadly flash flooding is hidden from public view in China.
  - (2026-08-29) [Global] At least 37 dead and hundreds evacuated after strike on Kyiv warehouse
      An investigation has been launched into the storage of weapons in the deopt near a residential area.
  - (2026-08-29) [Global] Trump hails 'historic' deal for US to control 65bn barrels of Venezuela's oil
      Venezuelan interim president says the unusual agreement will help revive her country's economy.
  - (2026-08-29) [Global] Landlady to 9/11 hijackers reveals their links to alleged Saudi spy
      A woman who rented out homes to two al-Qaeda members speaks publicly for the first time - to the BBC.
  - (2026-08-29) [Global] Close race as Iceland votes on whether to restart talks on joining EU
      Turbulent international affairs have brought the vote forward, but the campaign has focused more on Iceland's vital fishing industry.
  - (2026-08-29) [Global] Ex-White House teleprompter operator ordered to pay $172,000 for Trump speech bets
      The staffer was found to have used his prior knowledge of the president's speeches to place lucrative bets.

### Russian Internal News (state + in-exile) — 467 new of 1074 total
  - (2026-08-29) «Предлагали найти нового мужа среди своих». Адвокат рассказала, что жену акциониста Павла Крисевича унижали и шантажировали сотрудники ФСБ | LEDE: Адвокат Наталия Тихонова сообщила детали за] (ru: «Пр…
      Адвокат Наталия Тихонова сообщила детали задержания Елены Моргуновой, жены художника и акциониста Павла Крисевича. По ее словам, женщине угрожали, «шантажировали родителями», а также издевались над ее собакой, дергая за…
  - (2026-08-29) «Яростная» — редчайший детектив о серийной убийце-женщине. Ничего общего с напыщенными драмами о преступниках-мужчинах! Как ни странно, создательнице шоу пригодился опыт в ситкомах | LEDE: Н] (ru: «Яр…
      На стриминге Hulu выходит детективный сериал «Яростная» — о женщине, которая преследует и убивает людей, вероятно, причастных к смерти ее подруги. Ее дело расследует сотрудница ФБР, у которой больше общего с преступницей…
  - (2026-08-29) Война. 1648-й день. Россия ударила по складу боеприпасов под Киевом. Из-за детонации загорелись жилые дома и пансионат для людей с инвалидностью. Десятки человек погибли | LEDE: «Медуза» с 2] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-08-29) Екатеринбургская компания заморозила строительство завода по производству ноутбуков. Вместо этого она будет делать школьные тренажеры для управления дронами | LEDE: Компания LIGA Group замор] (ru: Ека…
      Компания LIGA Group заморозила проект строительства завода по производству ноутбуков в Екатеринбурге. Об этом РБК рассказал ее генеральный директор Алексей Лежнин. Завод планировали запустить на территории индустриальног…
  - (2026-08-29) Москвичи выступили против переноса памятника Пушкину. Михалков предлагал установить его на другой стороне Тверской улицы | LEDE: Жители Москвы проголосовали за то, чтобы оставить памятник Ал] (ru: Мос…
      Жители Москвы проголосовали за то, чтобы оставить памятник Александру Пушкину на прежнем месте. Об этом сообщила пресс-служба московской мэрии.
  - (2026-08-29) В результате российской атаки по складу под Киевом погибли 27 человек | LEDE: В результате атаки по складу в Бучанском районе Киевской области погибли 27 человек. Еще 42 человека, в том числ] (ru: В р…
      В результате атаки по складу в Бучанском районе Киевской области погибли 27 человек. Еще 42 человека, в том числе четверо детей, получили ранения разной степени тяжести, сообщил глава местной областной военной администра…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 219 new of 309 total
  - (2026-08-28) China Raises Threshold for New-Home Presales Under New National Standard - Caixin Global
      China Raises Threshold for New-Home Presales Under New National Standard Caixin Global
  - (2026-08-28) AI Chipmaker Sunrise Doubles Valuation After Raising 2 Billion Yuan - Caixin Global
      AI Chipmaker Sunrise Doubles Valuation After Raising 2 Billion Yuan Caixin Global
  - (2026-08-28) China Overhauls Real Estate Credit Rules in Shift Away From Presale Model - Caixin Global
      China Overhauls Real Estate Credit Rules in Shift Away From Presale Model Caixin Global
  - (2026-08-27) 热搜第一！孙宇晨起诉要求退还3000万彩礼，景甜方回应-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1XNl9xYUU2QU1SRmlxQnd1b3JXZDBhekFzMEJacUZrZV9PMkxzX1NUaC1LMGZmeE85cXJOcE0zVHpLekNBTkRz] (zh:…
      热搜第一！孙宇晨起诉要求退还3000万彩礼，景甜方回应-观察者网 观察者
  - (2026-08-27) 女子为独享空调，用椅子卡死电梯门致全楼无法使用，谁在为“巨婴”买单？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBCb3lJX1E0eTRXekdhVHpGUlFWUUkxWUpQZG9qc3ViQWtMTm42Q1B6enZBOVNsYXVFSTJMY0tBcVFnOENPc2] (zh:…
      女子为独享空调，用椅子卡死电梯门致全楼无法使用，谁在为“巨婴”买单？ 观察者
  - (2026-08-28) 景甜发声：不会为钱出卖爱情与灵魂-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1ldDZUaDdqUUFTMFVxRnFFSGpENGFhMWE1RFRRMmtzSnUxQnBJQTJib2lJWnlKU0tBSEN6YXh2UHFIelZJb2VTRFhMWmpfdEp] (zh:…
      景甜发声：不会为钱出卖爱情与灵魂-观察者网 观察者

### State-Level News — 134 new of 648 total
  - (2026-08-28) [Alabama] Flags Lowered Honoring Former State Representative Charles Wiley Whatley
      Download
  - (2026-08-29) [Arkansas] After firefighting deaths, advocates alarmed by ‘deepening wildfire crisis,’ agencies’ strategies
      Help was on the way. Five firefighters were about to be flown to safety after a new wildfire broke out on rugged terrain at the Utah-Colorado border in June, whipped by furious, dry winds. But it was too smoky for the he…
  - (2026-08-29) [Arkansas] This Washington town is burning. That’s the plan.
      ROSLYN, Wash. — Francisco Martinez hefts a canister filled with a mixture of diesel fuel and gasoline. A tongue of flame dances above the nozzle. He tips the drip torch forward — whoosh — and a stream of blazing liquid r…
  - (2026-08-29) [Arkansas] Researchers expect ‘biggest year yet’ for energy siting bills in 2027
      An analysis of renewable energy siting bills across the U.S. during 2026 legislative sessions found the majority of introduced bills were aimed at restricting renewable energy infrastructure, though most of the enacted b…
  - (2026-08-29) [Arkansas] After decades of overhunting, black bears are slowly recolonizing the lower Mississippi River basin
      On the Fourth of July, a picture of a black bear sitting on the edge of a Tennessee cornfield sparked a social media flurry. It was the beginning of a deluge. Over the next month, bears would be recorded running through…
  - (2026-08-28) [Arkansas] Tennessee governor backs plan to name Nashville airport for Dolly Parton
      Tennessee Gov. Bill Lee and Nashville International Airport officials announced plans Friday to rename the airport in Dolly Parton’s honor. Lee discussed the idea this week with Parton’s team after the legendary singer,…

### Local News: St. Louis + Atlanta — 132 new of 249 total
  - (2026-08-29) [St. Louis] Missouri boys wrestling championships
      Francis Howell Central's Noah Keen does a flip after winning the Class 4 championship at 138 pounds at the Missouri boys wrestling state championships on Saturday, February 24, 2024 at Mizzou Arena in Columbia, Mo. Paul…
  - (2026-08-29) [St. Louis] Seventh-rounder Colin Fitzgerald wants to prove to Blues, NHL that he was 'a steal'
  - (2026-08-29) [St. Louis] Worthy: So the Power 4 conferences can take a stand and hold their ground?
  - (2026-08-29) [St. Louis] 'That One Guy' Todd Thomas says he's stepping back as Cardinals' in-game emcee at Busch
  - (2026-08-29) [St. Louis] McClellan: Missouri politics could use a class clown
      Columnist Bill McClellan writes: I have great respect for class clowns, and I felt a certain pride when Sen. Eric Schmitt played class clown at a Senate hearing.
  - (2026-08-29) [St. Louis] What the US trade war with Canada and new tariffs mean for prices
      A reignited trade war between the United States and Canada means some prices are likely to rise for consumers in both countries.

### U.S. Weather + Severe / Climate Outlooks — 73 new of 85 total
  - (2026-08-29) [Severe] Special Marine Warning: Special Marine Warning issued August 29 at 8:54AM EDT until August 29 at 10:00AM EDT by NWS Wilmington NC
      SMWILM The National Weather Service in Wilmington has issued a * Special Marine Warning for... Waters from Surf City NC to Little River Inlet SC from 20 to 60 NM... * Until 1000 AM EDT. * At 853 AM EDT, a severe thunders…
  - (2026-08-29) [Severe] Special Marine Warning: Special Marine Warning issued August 29 at 7:51AM CDT until August 29 at 9:00AM CDT by NWS Mobile AL
      SMWMOB The National Weather Service in Mobile has issued a * Special Marine Warning for... Waters from Okaloosa-Walton County Line to Pensacola FL from 20 to 60 NM... Waters from Pensacola FL to Pascagoula MS from 20 to…
  - (2026-08-29) [Moderate] Special Weather Statement: Special Weather Statement issued August 29 at 5:51AM PDT by NWS Elko NV
      At 550 AM PDT, Doppler radar was tracking a strong thunderstorm 14 miles west of Cherry Creek, moving northeast at 40 mph. These cells are producing a lot of cloud to ground lightning strikes as well as heavy rain and co…
  - (2026-08-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-29) [Severe] Special Marine Warning: Special Marine Warning issued August 29 at 7:29AM CDT until August 29 at 8:15AM CDT by NWS Tallahassee FL
      For the following areas... Coastal Waters from Mexico Beach to Apalachicola out 20 NM... Coastal waters from Okaloosa-Walton County Line to Mexico Beach out 20 NM... At 729 AM CDT, severe thunderstorms capable of produci…
  - (2026-08-29) [Severe] Flood Watch: Flood Watch issued August 29 at 5:26AM MST until August 31 at 5:00AM MST by NWS Tucson AZ
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Tucson Metro Area, Southeast Pinal County, Tohono O'odham Nation, Upper San Pedro River Valley Upper Santa Cruz River Valley/Altar…

### State Legislative Action — 59 new of 80 total
  - (2026-08-29) [Alaska SB 162] An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
      An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
  - (2026-08-29) [Alaska SB 236] An Act creating a veteran sentencing program; relating to release procedures; amending Rules 35 and 43, Alaska Rules of Criminal Procedure; and providing for an effective date.
      An Act creating a veteran sentencing program; relating to release procedures; amending Rules 35 and 43, Alaska Rules of Criminal Procedure; and providing for an effective date.
  - (2026-08-29) [Alaska SB 219] An Act relating to perfluoroalkyl and polyfluoroalkyl substances; relating to thermal remediation of perfluoroalkyl and polyfluoroalkyl substance contamination; and providing for an ef…
      An Act relating to perfluoroalkyl and polyfluoroalkyl substances; relating to thermal remediation of perfluoroalkyl and polyfluoroalkyl substance contamination; and providing for an effective date.
  - (2026-08-29) [California AB 1974] Firearms: voluntary firearm storage program.
      Existing law requires a person, who claims title to a firearm that is in the custody of a court or law enforcement agency and wishes to have it returned, to make an application for a determination by the Department of Ju…
  - (2026-08-29) [California AB 2129] State employees: compensation: firefighters.
      Existing law provides that in order for the state to recruit skilled firefighters for the Department of Forestry and Fire Protection, it is the policy of the state to consider prevailing salaries and benefits prior to ma…
  - (2026-08-29) [California AB 2469] Data centers: water use disclosures.
      The Planning and Zoning Law authorizes the legislative body of any county or city to adopt ordinances that, among other things, regulate the use of buildings, structures, and land as between industry, businesses, residen…

### Ukrainian Internal News (national + local Kyiv) — 58 new of 125 total
  - (2026-08-29) Фінляндія про удар РФ по Бучанському району: Асоціація з березнем 2022 року | LEDE: Міністерка закордонних справ Фінляндії Еліна Валтонен прокоментувала російську атаку на Бучанський район Київ] (uk:…
      Міністерка закордонних справ Фінляндії Еліна Валтонен прокоментувала російську атаку на Бучанський район Київської області, жертвами якої стали щонайменше 27 осіб.
  - (2026-08-29) ЗМІ: В Угорщині розслідують економічні операції компанії батька Орбана | LEDE: ] (uk: ЗМІ: В Угорщині розслідують економічні операції компанії батька Орбана)
  - (2026-08-29) Генштаб нагадав жителям Бучанщини, що першопричина трагедії – Росія | LEDE: Генштаб ЗСУ заявив, що російський удар по селу Мила спричинив загибель 37 осіб. Заборонено зберігати боєприпаси біля ] (uk:…
      Генштаб ЗСУ заявив, що російський удар по селу Мила спричинив загибель 37 осіб. Заборонено зберігати боєприпаси біля житлових будинків.
  - (2026-08-29) ОВА: 37 людей загинули унаслідок атаки РФ в Бучанському районі | LEDE: Кількість загиблих унаслідок російської атаки та подальшої детонації в Бучанському районі Київщини зросла до 37, ще 42 люд] (uk:…
      Кількість загиблих унаслідок російської атаки та подальшої детонації в Бучанському районі Київщини зросла до 37, ще 42 людини постраждали.
  - (2026-08-29) ОП заявляє про "обмежений оптимізм" на певних ділянках фронту | LEDE: Заступник керівника Офісу президента Павло Паліса заявив про тенденцію до зниження темпів просування російських військ та "] (uk:…
      Заступник керівника Офісу президента Павло Паліса заявив про тенденцію до зниження темпів просування російських військ та "обмежений оптимізм" щодо ситуації на окремих ділянках фронту.
  - (2026-08-29) Генштаб заявив про знищення російського "Бук-М3" та ураження місця запуску дронів | LEDE: Генеральний штаб підтвердив знищення російського зенітного ракетного комплексу "Бук-М3" у Брянській обл] (uk:…
      Генеральний штаб підтвердив знищення російського зенітного ракетного комплексу "Бук-М3" у Брянській області РФ. Крім того, Сили оборони уразили місця підготовки та запуску ударних безпілотників у Донецьку й окупованому К…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-29) [HANDLER RICHARD B] Form 4 (Reporting)
      filed 2026-08-29 01:53 UTC · role: Reporting — Filed: 2026-08-28 AccNo: 0001214659-26-011109 Size: 13 KB
  - (2026-08-29) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-08-29 01:53 UTC · role: Issuer — Filed: 2026-08-28 AccNo: 0001214659-26-011109 Size: 13 KB
  - (2026-08-29) [FRIEDMAN BRIAN P] Form 4 (Reporting)
      filed 2026-08-29 01:53 UTC · role: Reporting — Filed: 2026-08-28 AccNo: 0001214659-26-011108 Size: 8 KB
  - (2026-08-29) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-08-29 01:53 UTC · role: Issuer — Filed: 2026-08-28 AccNo: 0001214659-26-011108 Size: 8 KB
  - (2026-08-29) [Larson Matthew Scott] Form 4 (Reporting)
      filed 2026-08-29 01:52 UTC · role: Reporting — Filed: 2026-08-28 AccNo: 0001214659-26-011107 Size: 5 KB
  - (2026-08-29) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-08-29 01:52 UTC · role: Issuer — Filed: 2026-08-28 AccNo: 0001214659-26-011107 Size: 5 KB

### Ukraine Theater (total-war monitoring) — 37 new of 234 total
  - (2026-08-29) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-29) [Liveuamap] Fires in Askay of Rostov region after explosions - Liveuamap
      Fires in Askay of Rostov region after explosions Liveuamap
  - (2026-08-28) [Liveuamap] Violent explosion reported in Bucha district after drone strike - Liveuamap
      Violent explosion reported in Bucha district after drone strike Liveuamap
  - (2026-08-27) [Liveuamap] Another explosion was reported in Kharkiv - Liveuamap
      Another explosion was reported in Kharkiv Liveuamap
  - (2026-08-29) [Liveuamap] At Orikhiv direction clashes yesterday near Krasnohirske, Novopavlivka, - General Staff of Armed Forces of Ukraine reports Zaporizhia Oblast, Ukraine - Ukraine Interactive map - Ukraine La…
      At Orikhiv direction clashes yesterday near Krasnohirske, Novopavlivka, - General Staff of Armed Forces of Ukraine reports Zaporizhia
  - (2026-08-20) [Liveuamap] Reports of explosions in the Strait of Hormuz caused by Iran firing anti-ship missiles at violating vessels. - iran.liveuamap.com
      Reports of explosions in the Strait of Hormuz caused by Iran firing anti-ship missiles at violating vessels. &nb

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 29 new of 29 total
  - (2026-08-31) [No title available]
  - (2026-08-31) Further Ensuring Affordable Beef for the American Consumer
  - (2026-08-31) Affirmative Asylum Referrals Without Interview
  - (2026-08-31) Declaring a National Emergency To Secure the United States Bulk-Power System
  - (2026-08-31) [No title available]
  - (2026-08-31) Fifth Anniversary of the Attack at Abbey Gate

### Government & military aircraft airborne (OpenSky) — 21 new of 21 total
  - (2026-08-29) JAF42N (Belgium)
      icao24: 44d1a6 · position: (44.0619, 17.0392) · alt: 11277m · 889km/h
  - (2026-08-29) JAF2XD (Belgium)
      icao24: 44d1a7 · position: (46.4533, 13.5849) · alt: 10668m · 955km/h
  - (2026-08-29) JAF5EA (Belgium)
      icao24: 44d1a5 · position: (40.5315, -3.3505) · alt: 11277m · 841km/h
  - (2026-08-29) JAF5HJ (Belgium)
      icao24: 44d1b3 · position: (45.6067, -3.2572) · alt: 11277m · 723km/h
  - (2026-08-29) JAF12M (Belgium)
      icao24: 44d1b4 · position: (48.3807, 0.5129) · alt: 10972m · 915km/h
  - (2026-08-29) JAF4AB (Belgium)
      icao24: 44d1c2 · position: (49.2625, 14.8266) · alt: 11277m · 908km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 18 new of 108 total
  - (2026-08-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] 1268 - Office of Foreign Assets Control (.gov)
      1268 Office of Foreign Assets Control (.gov)
  - (2026-08-29) [USASpending] $42,436,211,928 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-08-29) [USASpending] $34,654,023,639 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS
  - (2026-08-29) [USASpending] $26,444,741,720 → BATTELLE ENERGY ALLIANCE, LLC: MANAGEMENT AND OPERATIONS OF THE INL
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATIONS OF THE INL
  - (2026-08-29) [USASpending] $19,921,172,460 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…

### IT, InfoSys & cybersecurity news (last 7 days) — 17 new of 56 total
  - (2026-08-29) [The Register] Startup bags $7M to build drone-interceptor-in-a-backpack systems
      Spike drone defense system is designed to be carried in a rucksack or mounted on top of a vehicle
  - (2026-08-29) [The Register] Xbox respawns IKEA furniture with gaming range
      At last, somewhere comfy to sit while your PlayStation 5 game loads
  - (2026-08-29) [Ars Technica] I asked 100 companies for my data. Some deleted it instead.
      Testing 100 companies found privacy requests often led to confusion and dead ends.
  - (2026-08-29) [TechCrunch] Nvidia’s AI advantage is moving beyond the GPU
      The new generation of data center systems is increasing efficiency with smarter traffic control instead of just more processor cycles.
  - (2026-08-28) [BleepingComputer] McKesson discloses breach after ShinyHunters claims patient data theft
      Healthcare and pharmaceutical distribution giant McKesson has disclosed a cybersecurity incident involving unauthorized access to third-party applications and data theft, with the ShinyHunters extortion group claiming it…
  - (2026-08-28) [The Hacker News] Berlin Refuses to Pay Hackers Who Stole Data From the City's State Network
      Berlin's state government has confirmed that it is the target of an extortion attempt following the August compromise of the city's state administrative network, and said it will not meet the extortionists' demands. The…

### Paper Trading Scorecard — 16 new of 134 total
  - (2026-08-29) [Polymarket] Counter-Strike: Inner Circle Esports vs MOUZ - Map 2 Winner
      This market refers to the Counter-Strike Upper bracket semifinal 1 match between Inner Circle Esports and MOUZ in the BLAST Open Porto Group B, initially scheduled for August 29, 2026 at 7:30 AM ET. This market will reso…
  - (2026-08-29) [Polymarket] Will the Fed increase interest rates by 50+ bps after the September 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-08-29) [Polymarket] Strait of Hormuz traffic returns to normal by December 31?
      This market will resolve to “Yes” if IMF Portwatch publishes a 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz equal to or above 60 for any date between market creation and December 3…
  - (2026-08-29) [Kalshi] MacAskill–Moll AI growth challenge · Who will win?
      Q3 2026 through Q4 2033
  - (2026-08-29) [Manifold] Will Eth price hit 2.5k dollars by 30 aug ?
  - (2026-08-29) [Manifold] Will BTC Price hit 80k in 30 Aug ?

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-08-28) U.S. Court of Appeals, 7th Cir.: Randy Talley v. Carl Gloede
  - (2026-08-28) U.S. Court of Appeals, 7th Cir.: Amanda Sima v. Benesch, Friedlander, Coplan & Aronoff LLP
  - (2026-08-28) U.S. Court of Appeals, 9th Cir.: Jacques v. Blanche
  - (2026-08-28) U.S. Court of Appeals, 9th Cir.: Kalshiex, LLC v. Assad
  - (2026-08-28) U.S. Court of Appeals, 9th Cir.: La International Corp. v. Prestige Brands Holdings, Inc.
  - (2026-08-28) U.S. Court of Appeals, 9th Cir.: Mbueno-Vita v. Blanche

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-29) Will Liverpool FC win on 2026-08-29?
      yes price: 44% · 24h volume: $2,445,925 · resolves 2026-08-29
  - (2026-08-29) LoL: T1 vs BNK FEARX (BO5) - LCK Playoffs
      yes price: 100% · 24h volume: $2,341,724 · resolves 2026-08-29
  - (2026-08-29) LoL: Top Esports vs LGD Gaming (BO5) - LPL Playoffs
      yes price: 60% · 24h volume: $1,633,839 · resolves 2026-08-29
  - (2026-08-29) LoL: T1 vs BNK FEARX - Game 4 Winner
      yes price: 100% · 24h volume: $1,604,778 · resolves 2026-08-29
  - (2026-08-29) LoL: T1 vs BNK FEARX - Game 3 Winner
      yes price: 0% · 24h volume: $1,487,415 · resolves 2026-08-29
  - (2026-08-29) Will Nottingham Forest FC win on 2026-08-29?
      yes price: 14% · 24h volume: $1,453,664 · resolves 2026-08-29

### USGS earthquakes (M4.5+, past day) — 12 new of 14 total
  - (2026-08-29) M 5.1 - Southwest Indian Ridge
      M5.1 · Southwest Indian Ridge · depth 10 km
  - (2026-08-29) M 5.0 - 64 km W of Labuha, Indonesia
      M5.0 · 64 km W of Labuha, Indonesia · depth 41.899 km
  - (2026-08-28) M 5.0 - 191 km ESE of Kimbe, Papua New Guinea
      M5.0 · 191 km ESE of Kimbe, Papua New Guinea · depth 10 km
  - (2026-08-29) M 4.9 - South Sandwich Islands region
      M4.9 · South Sandwich Islands region · depth 89.886 km
  - (2026-08-28) M 4.9 - 124 km N of Aksu, China
      M4.9 · 124 km N of Aksu, China · depth 10 km
  - (2026-08-29) M 4.8 - 85 km W of Petrolia, CA
      M4.84 · 85 km W of Petrolia, CA · depth 10 km

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-29) [Marginal Revolution] Scholar Data
      In our paper, A Skeptical View of the National Science Foundation’s Role in Economic Research, Tyler and I point out that if the NSF is doing what it should it ought to be doing very different things than other funders:…
  - (2026-08-29) [Marginal Revolution] Costco facts of the day
      Costco sold 157.4mn rotisserie chickens worldwide last year, almost double the number of a decade ago. “It’s $4.99 and for Costco members, that’s one fantastic deal. I don’t think you can produce it for that,” said Walt…
  - (2026-08-29) [Marginal Revolution] *Visions from San Francisco Bay*
      European and American capitalism were different. The violence of human clashes in America took place on the surface, in the open. The violence in Europe became formalized, coalesced with class divions hallowed by centuri…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=25, 14d-median=20; carrying terms: public, certain, establish, national, action, management, proposed, unless, temporary, service, safety, specifically
- state_bills: today=80, 7d-median=92, 14d-median=134; carrying terms: policy, public, program, general, community, years, issue, request, licensure, civil, financial, administered
- state_news: today=648, 7d-median=648, 14d-median=632; carrying terms: seeking, policy, illinois, uploads, public, social, comes, nebraska, however, general, flock, private
- local_news: today=249, 7d-median=249, 14d-median=243; carrying terms: public, flock, metro, court, articles, local, following, google, louis, target, officers, state
- foreign_news: today=1027, 7d-median=1027, 14d-median=1023; carrying terms: greener, public, champion, conclude, businessnews, selected, realize, peaceful, countryside, comes, resulted, anadolu
- chinese_internal: today=309, 7d-median=289, 14d-median=289; carrying terms: cbmizefvx, china, articles, cbmickfvx, google, target, lxtfa, cbmib, caixin, cbmiw, chinese, https
- russian_internal: today=1074, 7d-median=1074, 14d-median=1066; carrying terms: times, istories, russian, netflix, politico, found, bloomberg, europe, client, media, telegraph, https
- ukrainian_internal: today=125, 7d-median=115, 14d-median=114; carrying terms: comes, kremlin, refinery, injured, general, range, germany, offensive, launched, years, damaged, critical
- ukraine_theater: today=234, 7d-median=841, 14d-median=841; carrying terms: oennuqkpot, ewtywtlyehbqc, yxzrxzw, piddhmznjmzg, pbrgd, uhvnvnj, jnfhxbllhefv, nxztnk, ozbvbkn, wxpgazfdthvkzw, response, wtnvbepezmfxmf
- paper_bets: today=134, 7d-median=132, 14d-median=133; carrying terms: become, jpmorgan, miami, resolve, state, lifetime, johnson, nominee, supervolcano, career, standing, johnny
- weather: today=85, 7d-median=135, 14d-median=145; carrying terms: chances, illinois, twoat, memphis, lower, rainfall, moderate, return, normal, humidity, tucson, norton
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: pcepilfe, dcoilwtico, unrate, commodities, nonfarm, cpilfesl, payrolls, dexjpus, crude, openings, balance, walcl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, rates, china, agriculture, russell, natural, futures, crypto, commodities, bitcoin, large, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=108, 7d-median=105, 14d-median=101; carrying terms: sevastopol, network, cbmiqkfvx, systems, public, undermining, prohibited, mufswgh, ukraine, actions, burma, transactions
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, client, https, unauthorized, quiverquant, httperror, error, quiver, quantitative
- billionaires: today=0, 7d-median=30, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, supreme, court, california, appeals, center, connecticut, delaware, america, company, county, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, group, scott, joseph, robert, brian, david, financial, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ocasio, cooper, lindsey, raised, platner, filing, shawn, warner, receipts, robert, ossoff, disbursements
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=41; carrying terms: english, trump, keywords, russian, sanctions, perimeter, ukrainian, themes, russia, against, attack, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=30, 14d-median=30; carrying terms: belgium, position, kingdom, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: seasonal, regional, eight, recombinant, bundibugyo, rapidly, public, occur, associated, illness, manifestations, additi
- cisa_kev: today=20, 7d-median=13, 14d-median=12; carrying terms: vulnerability, product, remediation, injection, command, function, microsoft, authentication, vendor, project, internet, broadcom
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=14, 7d-median=14, 14d-median=18; carrying terms: indonesia, depth, japan, islands, south, russia, region, philippines, ridge, chile, kuril, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, donetsk, resolves, meeting, championship, shakhtar, price, rates, league, interest, september, august
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, economist, https, revolution, conversable, class, demand, number, together, marginalrevolution, construction, point
- tech_news: today=56, 7d-median=55, 14d-median=56; carrying terms: systems, weekly, computer, critical, world, https, record, multiple, security, spectrum, government, techcrunch
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: roger, cantwell, adriano, joseph, stefanik, glenn, cornyn, donald, alsobrooks, owens, desaulnier, kavanaugh
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, converges, unavailable, sufficient, claude, markets, placed, placement, decision, today, identify, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*