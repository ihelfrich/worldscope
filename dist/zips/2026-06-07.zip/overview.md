# WORLDSCOPE morning brief — 2026-06-07

## Headline
2684 new items across 23 active section(s) (of 41 tracked).

## Top movers today
International News + Multilateral Institutions (551) · Russian Internal News (state + in-exile) (548) · World leaders & government officials (324) · State Legislative Action (229) · Chinese Internal News (188) · Ukraine Theater (total-war monitoring) (187) · U.S. Weather + Severe / Climate Outlooks (148) · Local News: St. Louis + Atlanta (108) · State-Level News (95) · GDELT GKG — themes / entities / watch areas (75) · Paper Trading Scorecard (69) · Ukrainian Internal News (national + local Kyiv) (52)

## What changed today
### International News + Multilateral Institutions — 551 new of 847 total
  - (2026-06-07) [Global] Hegseth attacks Europe over migration with beach 'invasion' D-Day speech
      The US defence secretary was speaking in Normandy, 82 years after allied forces launched their operation to liberate Nazi-occupied north-western Europe.
  - (2026-06-07) [Global] Steve Rosenberg: Russia's economic forum overshadowed by drone attacks on St Petersburg
      The BBC's Russia editor saw Putin's flagship economic event overshadowed by Ukrainian drones attacks.
  - (2026-06-07) [Global] Huge crowds throng Madrid streets for Pope's open-air mass
      The pontiff waved at those gathered from his popemobile as he arrived at the Plaza de Cibeles.
  - (2026-06-06) [Global] Iran says staff blocked from entering US after players given World Cup visas
      Iranian officials say technical staff have been denied visas, hours after the US said players could enter the country.
  - (2026-06-06) [Global] Insecurity and instability drive voters in Peru's tight presidential race
      After eight presidents in 10 years, many voters are looking for stability so the next president can focus on tackling crime and inequality.
  - (2026-06-06) [Global] Funeral held for baby shot dead by Israeli troops in occupied West Bank
      The seven-month-old boy's shrouded body was wrapped in a Palestinian flag and carried by his father to the graveyard.

### Russian Internal News (state + in-exile) — 548 new of 924 total
  - (2026-06-07) В Израиле произошла стрельба. Один человек погиб, есть раненые | LEDE: В Израиле днем 7 июня произошла серия инцидентов со стрельбой, власти назвали произошедшее террористической атакой. По ] (ru: В И…
      В Израиле днем 7 июня произошла серия инцидентов со стрельбой, власти назвали произошедшее террористической атакой. По последним данным, один человек погиб, пятеро получили ранения, сообщает израильская служба скорой пом…
  - (2026-06-07) Китай начал свою «специальную операцию» в водах к востоку от Тайваня. Это ответ на территориальный спор с Японией и Филиппинами. Что важно знать? | LEDE: Китай пошел на эскалацию отношений с] (ru: Кит…
      Китай пошел на эскалацию отношений с Японией и Филиппинами: в ответ на договор двух стран о разграничении морских границ, затрагивающих зоны к востоку от Тайваня, которые Пекин считает своими, КНР направила в район неско…
  - (2026-06-07) «Неживые» — роман Светланы Сачковой о российской режиссерке, которую судят за фильм про Ленина-зомби. Он вышел на английском языке. «Медуза» публикует фрагмент в авторском переводе на русский |] (ru:…
      В 2026 году в американском издательстве Melville House вышел роман журналистки и писательницы Светланы Сачковой «Неживые. Роман о современной России» (The Undead: A Novel of Modern Russia). Его события разворачиваются в…
  - (2026-06-07) В Казахстане не стали заводить дело о наемничестве против Нурлана Сабурова | LEDE: Комитет национальной безопасности (КНБ) Казахстана не нашел в действиях комика Нурлана Сабурова «признаков ] (ru: В К…
      Комитет национальной безопасности (КНБ) Казахстана не нашел в действиях комика Нурлана Сабурова «признаков правонарушения». Об этом сообщило издание Tengrinews со ссылкой на ответ ведомства.
  - (2026-06-07) Украина заявила, что российский беспилотник атаковал хранилище отработанного ядерного топлива в Чернобыле | LEDE: Российский беспилотник в ночь на 7 июня попал в здание Централизованного хра] (ru: Укр…
      Российский беспилотник в ночь на 7 июня попал в здание Централизованного хранилища отработанного ядерного топлива в Чернобыле, сообщает украинская компания «Энергоатом».
  - (2026-06-07) Что вам помогло перестать залипать в телефоне? Отвечают читатели «Медузы». Среди вариантов — рождение ребенка, покупка наручных часов и попытки брать на слабо | LEDE: Множество людей пытаютс] (ru: Что…
      Множество людей пытаются справиться с желанием постоянно тянуться к телефону и листать соцсети — но у них ничего не получается. В мае кооператив независимых журналистов «Берег» опубликовал чек-лист с научно обоснованными…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State Legislative Action — 229 new of 276 total
  - (2026-06-06) [Arizona HB 2032] statewide assessment; testing window; revisions
      statewide assessment; testing window; revisions
  - (2026-06-06) [Arizona HB 2342] homeowners' associations; shade structures
      homeowners' associations; shade structures
  - (2026-06-06) [Arizona HB 2109] distracted driving; penalties; motorcycles
      distracted driving; penalties; motorcycles
  - (2026-06-06) [Arizona SB 1254] real property conveyances; formal requirements
      real property conveyances; formal requirements
  - (2026-06-06) [Arizona HB 2078] reclamation plans; aggregate mining; notice
      reclamation plans; aggregate mining; notice
  - (2026-06-06) [Arizona HB 2195] nursing facilities; records; surveys; timelines
      nursing facilities; records; surveys; timelines

### Chinese Internal News — 188 new of 248 total
  - (2026-06-05) “太疯狂了”，中国机器人在《美国达人秀》炸场 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9FM094ejlOdVB4TXRHbnd0S3BLTHNkRmFWUGJ3QURpWlQ3N0JCWDZiOFBuWm1rUlJZT1Z3bXJoNUdyb0tfbEF1ODNRUWp5a] (zh:…
      “太疯狂了”，中国机器人在《美国达人秀》炸场 观察者网
  - (2026-06-06) 探宝上博·因AI而生㉜“笑谈间气吐霓虹”石章-观察者网 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5Dc3lFQTBncVRxbUlIUUVxcUdSajRHT0JPYXpHeVpxODViQjZwUk5UVmtsa21RRUVQM3lmRzQ1Z0phdDV4YzNhOVJU] (zh:…
      探宝上博·因AI而生㉜“笑谈间气吐霓虹”石章-观察者网 观察者网
  - (2026-06-06) 在飞机上如此追星，管不了吗？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5CRHRoTlZ2LWtTVkk2eEhrZW80bnprVVVjY0Q3dUhleFVOdjVvZGVZNHVRSmxCVXo1X2NFV21pY1hUal9UUi1MWG10V0xGMTFRejRMd1l] (zh:…
      在飞机上如此追星，管不了吗？ 风闻
  - (2026-06-05) 算法向善 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiV0FVX3lxTE1JMVpGUnk5VFdKTnZGeGFTeUxnZFhyYjNDZWpHYnI2VVRtYzVZMC1zb1BubHBTNWQwTll5U3pxNHhpLXhySVFHOFIxeWFESHB0VG8tV3J0OA?oc=5] (zh:…
      算法向善 观察者网
  - (2026-06-06) 巡查组现场要求：你把手机拿出来我看看 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1JWXNHRXN2OG1HeGhfVDhwTE4taW5TX08wNy1PbnlpcVQtWTNhNWRXaTRqMEw0TGJNdk9fRWR2ZXduWmJ2cmxnTWgxaXNaTmxCL] (zh:…
      巡查组现场要求：你把手机拿出来我看看 观察者网
  - (2026-06-06) 上头了？欧盟高官：制裁俄罗斯那套，拿来对付中国 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5KSWhCR21fRmVIUTNROGxkUGRYWVo5VjBBMFU0S0FTTDVpeEVkbjhMYjBydGZuVUNTLVFsQlhQaE1WcEF6SFplNmNYbXBk] (zh:…
      上头了？欧盟高官：制裁俄罗斯那套，拿来对付中国 观察者网

### Ukraine Theater (total-war monitoring) — 187 new of 345 total
  - (2026-06-07) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-06) [FIRMS] thermal anomaly 45.257, 31.676 (FRP 7.88 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-06 1011Z, FRP 7.88 MW
  - (2026-06-06) [FIRMS] thermal anomaly 46.632, 32.883 (FRP 3.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-06 1013Z, FRP 3.9 MW
  - (2026-06-06) [FIRMS] thermal anomaly 46.636, 32.881 (FRP 3.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-06 1013Z, FRP 3.9 MW
  - (2026-06-06) [FIRMS] thermal anomaly 46.636, 32.884 (FRP 5.11 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-06 1013Z, FRP 5.11 MW
  - (2026-06-06) [FIRMS] thermal anomaly 46.635, 32.879 (FRP 4.27 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-06 1013Z, FRP 4.27 MW

### U.S. Weather + Severe / Climate Outlooks — 148 new of 150 total
  - (2026-06-07) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 7 at 4:57AM CDT until June 7 at 5:30AM CDT by NWS Norman OK
      At 456 AM CDT, severe thunderstorms were located along a line extending from 3 miles east of Sheppard AFB to near Lake Arrowhead to 13 miles south of Windthorst, moving east at 35 mph. HAZARD...60 mph wind gusts. SOURCE.…
  - (2026-06-07) [Moderate] Special Weather Statement: Special Weather Statement issued June 7 at 4:54AM CDT by NWS Norman OK
      At 454 AM CDT, Doppler radar was tracking a strong thunderstorm near Red Springs, moving east at 25 mph. HAZARD...Wind gusts of 40 mph and penny size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down…
  - (2026-06-07) [Severe] Special Marine Warning: Special Marine Warning issued June 7 at 4:53AM CDT until June 7 at 5:00AM CDT by NWS Brownsville TX
      The affected areas were... Coastal waters from Baffin Bay to Port Mansfield TX out 20 NM... Laguna Madre From 5 nm North Of Port Mansfield To Baffin Bay TX... The thunderstorm has weakened and no longer poses a significa…
  - (2026-06-07) [Severe] Special Marine Warning: Special Marine Warning issued June 7 at 4:52AM CDT until June 7 at 5:00AM CDT by NWS Brownsville TX
      The affected areas were... Laguna Madre From The Arroyo Colorado To 5 NM North Of Port Mansfield TX... Laguna Madre From the Port Of Brownsville to the Arroyo Colorado... The thunderstorm has weakened and no longer poses…
  - (2026-06-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-07) [Moderate] Special Weather Statement: Special Weather Statement issued June 7 at 4:40AM CDT by NWS Fort Worth TX
      At 440 AM CDT, Doppler radar was tracking a strong thunderstorm over Campbell, or near Commerce, moving northeast at 35 mph. HAZARD...Winds in excess of 40 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty…

### Local News: St. Louis + Atlanta — 108 new of 201 total
  - (2026-06-05) [St. Louis] Photos: St. Louis' Circus Flora flies high to kick off 40th season at the Big Top
  - (2026-06-05) [St. Louis] Aided by a ‘Clown Boss,’ Circus Flora’s 40th season goes back to high school
  - (2026-06-05) [St. Louis] Maplewood Richmond Heights school janitor deported despite community outcry
  - (2026-06-05) [St. Louis] Legionella bacteria closes St. Louis Public Schools headquarters
  - (2026-06-05) [St. Louis] Illinois Gov. JB Pritzker pauses state tax incentives for new data centers
  - (2026-06-05) [St. Louis] Where to watch the World Cup in the St. Louis region

### State-Level News — 95 new of 394 total
  - (2026-06-06) [California] Californians fighting addiction need help finding care. Budget cuts threaten a digital lifeline
      <img width="1024" height="684" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2023/07/072023-Shapiro-Drug-Management-ML-CM-11.jpg?fit=1024%2C684&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-po…
  - (2026-06-07) [Connecticut] Amid manufacturing workforce woes, CT bets on youth robotics
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/EventCourtesyPhoto_FIRSTDistrictChampionships_Competition-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-06-07) [Connecticut] PAID POST: Affordable Financing Helps Connecticut Nonprofits Build Stronger Communities
      <img width="1024" height="769" src="https://ctmirror.org/wp-content/uploads/2026/06/CHEFA-1-1024x769.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset=…
  - (2026-06-07) [Connecticut] We built transportation’s future, then got stuck in traffic
      <img width="802" height="401" src="https://ctmirror.org/wp-content/uploads/2026/06/Dynamixion_car_by_Buckminster_Fuller_1933_side_views.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" deco…
  - (2026-06-06) [Colorado] First-time homebuyers face hurdles despite gradual improvement
      The idea started with a sermon Micah Longmire heard at his Presbyterian church in Ogden, Utah, about the importance of grandparents in a child’s life. Longmire, now 31, exchanged a look with his mother-in-law. “We were l…
  - (2026-06-06) [Hawaii] News Release – DOH Authorizes Reopening of Ohana Sub & Deli, Inc. After Being Closed for Multiple Food Safety Violations
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA DEPARTMENT OF HEALTH KA ʻOIHANA OLAKINO KENNETH S. FINK, M.D., MGA, MPH DIRECTOR KA LUNA […]

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-06-07) [Israel-Iran-Hezbollah axis · themes] On binlerce Arnavut , ülkelerini ele geçiren siyonistlere karşı sokağa döküldü !
      yeniakit.com.tr · Turkish · tone NA
  - (2026-06-07) [Israel-Iran-Hezbollah axis · themes] Los sismólogos lo tienen claro : las fallas sísmicas ocultas bajo esta ciudad de EEUU son más peligrosas de lo esperado
      vozpopuli.com · Spanish · tone NA
  - (2026-06-07) [Israel-Iran-Hezbollah axis · themes] النيابة : التحريات أثبتت تورط صبري نخنوخ في غسل أموال نشاطه الإجرامي
      vetogate.com · Arabic · tone NA
  - (2026-06-07) [Israel-Iran-Hezbollah axis · themes] Guerre en Ukraine : deux morts dans une frappe russe , Poutine choisit la guerre dit
      hyeres.maville.com · French · tone NA
  - (2026-06-07) [Israel-Iran-Hezbollah axis · themes] No rites until justice : Family of Mapusa youth demands action – 7 June 2026
      heraldgoa.in · English · tone NA
  - (2026-06-07) [Israel-Iran-Hezbollah axis · themes] सातै प्रदेश सभामा संघ - प्रदेश समन्वय शाखा स्थापना गरिने
      onlinekhabar.com · Nepali · tone NA

### Paper Trading Scorecard — 69 new of 140 total
  - (2026-06-07) [Polymarket] Will Argentina win Group J in the 2026 FIFA World Cup?
      This market will resolve according to the team that wins Group J in the 2026 FIFA World Cup group stage, scheduled for June 11-27, 2026. If multiple teams tie as group winners, this market will resolve according to the o…
  - (2026-06-07) [Polymarket] Counter-Strike: Monte vs Legacy (BO1) - IEM Cologne Major Stage 2
      This market refers to the Counter-Strike Round 3 match between Monte and Legacy in the IEM Cologne Major Stage 2, initially scheduled for June 7 at 8:30AM ET. This market will resolve to "Monte" if Monte win the match ag…
  - (2026-06-07) [Polymarket] Will Elon Musk win his case against Sam Altman?
      This market will resolve to “Yes” if the U.S. District Court in the Northern District of California sides with Elon Musk in Elon Musk v. Sam Altman et al by December 31, 2026, 11:59 PM ET. Otherwise, this market will res…
  - (2026-06-07) [Polymarket] Pedro Sánchez out as PM of Spain by December 31, 2026?
      This market will resolve to “Yes” if Pedro Sánchez ceases to be Prime Minister of Spain for any period of time between market creation and the specified date (ET). Otherwise, this market will resolve to “No”. An announce…
  - (2026-06-07) [Kalshi] Will Elon Musk visit Mars in his lifetime?
      Before 2099
  - (2026-06-07) [Kalshi] Who will the next Pope be?
      Before 2070

### Ukrainian Internal News (national + local Kyiv) — 52 new of 119 total
  - (2026-06-07) Russian Drone Strike Damages Chornobyl Nuclear Waste Storage Facility
      A Russian strike drone targeted the Central Spent Nuclear Fuel Storage Facility (CSFSF) in the Chornobyl Exclusion Zone Saturday night into Sunday morning, June 7. State nuclear operator Energoatom reported that the atta…
  - (2026-06-07) How Much Will Trump's Confusion About US Troops in Europe Cost Americans?
      Donald Trump’s conflicting directives on US troop levels in Europe have disrupted military planning, confused NATO allies, and triggered millions in unplanned costs. Canceled rotations, sudden reversals, and unclear guid…
  - (2026-06-07) China Launches Maritime Enforcement Operation East of Taiwan
      The Chinese government announced a special maritime traffic control and patrol operation in the waters east of Taiwan on Saturday, June 6. The deployment aims to assert Beijing’s maritime administrative jurisdiction, ste…
  - (2026-06-07) Ukraine’s Unmanned Systems Forces Hit 26 Russian Logistics and Energy Targets
      The Unmanned Systems Forces (SBS) of Ukraine launched a massive drone operation on June 7, 2026, striking 26 Russian military, energy, and logistics targets. According to SBS Commander Robert “Magyar” Brovdi, the coordin…
  - (2026-06-07) Off-Site Power Restored to Zaporizhzhia Nuclear Plant After 15-Hour Blackout
      The International Atomic Energy Agency (IAEA) confirmed that off-site electrical power was restored to the Russian-occupied Zaporizhzhia Nuclear Power Plant (ZNPP) on Saturday, June 6, concluding a dangerous 15-hour blac…
  - (2026-06-07) Russia’s Summer Offensive: Barbaric Civilian Slaughter Reveals the Death Throes of a Weak Aggressor
      History will record this not as a Russian resurgence, but as the death spiral of a failing dictatorship – purchasing temporary headlines with innocent blood while its foundations crumble.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 22 new of 60 total
  - (2026-06-05) U.S. Court of Appeals, 4th Cir.: Deque Systems Inc. v. Browserstack, Inc.
  - (2026-06-05) U.S. Court of Appeals, 4th Cir.: Emmanuel Shaw v. T. Foreman
  - (2026-06-05) U.S. Court of Appeals, 4th Cir.: Md Uddin v. Todd Blanche
  - (2026-06-05) U.S. Court of Appeals, 4th Cir.: Sligo Creek Center v. HHS
  - (2026-06-05) U.S. Court of Appeals, 4th Cir.: United States v. Aaron Goode
  - (2026-06-05) Hawaii Supreme Court: Bellamy v. City and County of Honolulu

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-06-07) Roland Garros ATP: Flavio Cobolli vs Alexander Zverev
      yes price: 20% · 24h volume: $2,813,066 · resolves 2026-06-14
  - (2026-06-07) Will Iran win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,075,155 · resolves 2026-07-20
  - (2026-06-07) Will Mexico win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,739,752 · resolves 2026-07-20
  - (2026-06-07) Will USA win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,688,346 · resolves 2026-07-20
  - (2026-06-07) Will Morocco win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,508,294 · resolves 2026-07-20
  - (2026-06-07) Will Germany win the 2026 FIFA World Cup?
      yes price: 6% · 24h volume: $1,383,238 · resolves 2026-07-20

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-06-07) MOVER ▼ Changpeng Zhao — $107.51B ($-2.12B since yesterday)
      Canada · Finance & Investments · source: Cryptocurrency exchange
  - (2026-06-07) MOVER ▼ Bernard Arnault & family — $148.27B ($-0.91B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-06-07) MOVER ▼ Amancio Ortega — $140.96B ($-0.86B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-06-07) MOVER ▲ Gautam Adani — $89.98B (+$0.80B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-06-07) MOVER ▲ Mukesh Ambani — $88.84B (+$0.79B since yesterday)
      India · Diversified · source: Diversified
  - (2026-06-07) MOVER ▼ Francoise Bettencourt Meyers & family — $93.34B ($-0.58B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### U.S. Federal Action — 8 new of 8 total
  - (2026-06-08) Establishment of Class E Airspace; Dover, OH
      This action establishes Class E airspace at Cleveland Clinic, Union Hospital Heliport, Dover, OH. This action supports new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-06-08) Airworthiness Directives; The Boeing Company Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for certain The Boeing Company Model 747-8 series airplanes. This proposed AD was prompted by a report of cracks in the fuselage skin lap splice at the upper f…
  - (2026-06-08) Rescission of Policy Relating to the Acceptance of Settlements in Administrative and Civil Proceedings
      The Commodity Futures Trading Commission ("CFTC" or "Commission") is rescinding a policy contained in an appendix to its regulations concerning acceptance of settlements in administrative and civil proceedings. This poli…
  - (2026-06-08) Approval and Promulgation of Air Quality Implementation Plans; Wyoming; Regional Haze Federal Implementation Plan
      The U.S. Environmental Protection Agency (EPA) is proposing revisions to the Federal Implementation Plan (FIP) addressing regional haze in the State of Wyoming. The EPA is proposing revisions to the FIP's nitrogen oxides…
  - (2026-06-08) Anchorages; Port of New York
      The Coast Guard is proposing to amend regulations to conform to requirements in the National Defense Authorization Act for Fiscal Year 2026, which required the Commandant to prohibit any vessel anchoring on the reach of…
  - (2026-06-08) Air Plan Approval; Minnesota; Revision to Taconite Federal Implementation Plan
      The U.S. Environmental Protection Agency (EPA) is revising the Original 2013 Federal Implementation Plan (FIP) by finalizing nitrogen oxide (NO X ) emission limits for the indurating furnace at United States Steel's (U.S…

### USGS earthquakes (M4.5+, past day) — 8 new of 8 total
  - (2026-06-07) M 5.4 - south of the Fiji Islands
      M5.4 · south of the Fiji Islands · depth 506.648 km
  - (2026-06-06) M 5.3 - 221 km ENE of Neiafu, Tonga
      M5.3 · 221 km ENE of Neiafu, Tonga · depth 10 km
  - (2026-06-06) M 5.2 - 22 km E of Venilale, Timor Leste
      M5.2 · 22 km E of Venilale, Timor Leste · depth 10 km
  - (2026-06-06) M 5.2 - 100 km ESE of Modisi, Indonesia
      M5.2 · 100 km ESE of Modisi, Indonesia · depth 35 km
  - (2026-06-07) M 5.1 - 196 km NE of Lospalos, Timor Leste
      M5.1 · 196 km NE of Lospalos, Timor Leste · depth 161.221 km
  - (2026-06-06) M 4.7 - 44 km ENE of Noda, Japan
      M4.7 · 44 km ENE of Noda, Japan · depth 47.118 km

### Campaign finance (FEC: top fundraisers + recent filings) — 6 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### World News (by country, top stories) — 6 new of 6 total
  - (2026-06-07) [Germany] Peru votes for new president ninth time in 10 years
      dw.com · English
  - (2026-06-07) [Germany] Germany news : Far - right AfD makes push in district elections
      dw.com · English
  - (2026-06-07) [Germany] Kosovo holds third election in 18 months
      dw.com · English
  - (2026-06-07) [Germany] India news : CJP demands minister removal in seven days
      dw.com · English
  - (2026-06-07) [Germany] Funky Taurus Media - Music Photo Agency & Products
      funkytaurusmedia.com · English
  - (2026-06-07) [Germany] Funky Taurus Media - Music Photo Agency & Products - Funky Taurus & George Clinton - UFO Brooklyn
      funkytaurusmedia.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 109 total
  - (2026-06-07) [USASpending] $2,530,079,189 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2026-06-07) [USASpending] $1,930,675,317 → AMENTUM TECHNOLOGY, INC.: ENGINEERING SERVICES AND SCIENCE CAPABILITY AUGMENTATION (ES
      Agency: National Aeronautics and Space Administration. Description: ENGINEERING SERVICES AND SCIENCE CAPABILITY AUGMENTATION (ESSCA)
  - (2026-06-07) [USASpending] $1,402,431,081 → AUSTAL USA, LLC: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESI
      Agency: Department of Homeland Security. Description: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESIGN AND PRODUCTION (DD&P) OF 11 OPCS.
  - (2026-06-07) [USASpending] $708,737,651 → ORACLE HEALTH GOVERNMENT SERVICES, INC.: EHRM OPERATIONS
      Agency: Department of Veterans Affairs. Description: EHRM OPERATIONS
  - (2026-06-07) [UN Sanctions] page checksum 1bd12e7cb6e6
      Active UN Security Council sanctions committees page snapshot

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-06-07) [Marginal Revolution] Why drugs are here to stay (from my email)
      This is anonymized, I can vouch that the person is very smart and has excellent taste: Some thoughts [referring to my recent Free Press piece on marijuana]. My feeling is that you read quickly enough that I can dump word…
  - (2026-06-06) [Marginal Revolution] Is work from home bad for your mental health?
      From the “Results” section: Relative to those in nonremotable jobs, workers in remotable jobs spent approximately one additional hour alone per workday after the pandemic. Those in remotable jobs also differentially incr…
  - (2026-06-06) [Marginal Revolution] Saturday assorted links
      1. “A little noticed thread in @Pontifex encyclical. “Innovation” appears at least 15 times.” Link here. 2. The (other) man who reads books for a living. 3. Did the credibility revolution skip public management? 4. Excel…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=8, 7d-median=30, 14d-median=30; carrying terms: vessels, captain, coast, provide, action, safety, persons, certain, waters, public, authorized, guard
- state_bills: today=276, 7d-median=141, 14d-median=148; carrying terms: vehicles, family, assessments, volumetric, beginning, approval, parks, impact, alaska, request, january, payment
- state_news: today=394, 7d-median=651, 14d-median=708; carrying terms: wyofile, brought, democratic, market, believe, wednesday, image, announced, think, fetchpriority, beginning, going
- local_news: today=201, 7d-median=227, 14d-median=242; carrying terms: family, cbminafbvv, state, fatal, cbmiqafbvv, injuries, health, found, since, shooting, decoding, summer
- foreign_news: today=847, 7d-median=847, 14d-median=860; carrying terms: brought, democratic, market, factors, delhi, tackles, example, deadly, depict, wednesday, image, announced
- chinese_internal: today=248, 7d-median=270, 14d-median=270; carrying terms: politics, cbmickfvx, cbmia, people, cbmib, articles, title, china, target, cbmiakfvx, lxtfb, cbmizefvx
- russian_internal: today=924, 7d-median=1014, 14d-median=1018; carrying terms: https, times, error, reuters, httperror, title, russian, roland, politico, garros, client, centcom
- ukrainian_internal: today=119, 7d-median=121, 14d-median=122; carrying terms: error, hmarochos, kyivindependent, found, ukrinform, vechirniy, forbidden, censor, economic, httperror, title, babel
- ukraine_theater: today=345, 7d-median=279, 14d-median=325; carrying terms: zuclnxymn, xwyvdjqv, ktvtjtvxnubhztegpcajfjn, tavlzflupendkxekxxdernatvqbxf, havlsbkzqyzzlt, drhpvavg, rsekwwogzvyvyxzuf, vsodv, rexlrnwnqnepscmzvtkp, cbmicefvx, fedorov, cuxnm
- paper_bets: today=140, 7d-median=147, 14d-median=142; carrying terms: democratic, market, party, midterm, trained, california, announced, house, defined, republican, openai, kansas
- weather: today=150, 7d-median=131, 14d-median=119; carrying terms: afdmeg, memphis, areas, streams, include, wednesday, prone, outlook, showers, peachtree, unknown, sweep
- macro: today=21, 7d-median=21, 14d-median=5; carrying terms: latest, rates, funds, labor, recession, unrate, unemployment, indicator, spread, effective, treasury, commodities
- markets: today=21, 7d-median=21, 14d-median=10; carrying terms: commodities, credit, nasdaq, natural, agriculture, corporate, silver, range, large, rates, proxy, yield
- markets_global: today=47, 7d-median=79, 14d-median=79; carrying terms: crypto, price
- sanctions_procurement: today=109, 7d-median=110, 14d-median=106; carrying terms: democratic, effects, projects, areas, target, yemen, taliban, sectoral, jjmudpzw, detect, russian, control
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quiver, congresstrading, error, quiverquant, client, quantitative, httperror, unauthorized
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: commodities, sergey, mukesh, jensen, family, carlos, peterffy, retail, buffett, india, meyers, amazon
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=60, 14d-median=45; carrying terms: blanche, collins, robert, alaska, court, state, supreme, appeals, company, connecticut, jonathan, florida
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, david, holdings, michael, finance, american, scott, george, america
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: booker, johnson, alexandria, angels, sherrod, james, joseph, jonathan, robert, cooper, senate, talarico
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=75, 7d-median=75, 14d-median=0; carrying terms: against, israel, ukrainian, taiwan, russian, special, themes, strike, keywords, trump, english, lebanon
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=30, 14d-median=20; carrying terms: position, ground, belgium, bulgaria, france, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: geographical, distributed, sometimes, democratic, ingredient, different, prevention, regarding, acute, representing, india, additional
- cisa_kev: today=10, 7d-median=12, 14d-median=15; carrying terms: bypass, vendor, remediation, authentication, product, vulnerability, overflow, malicious, litespeed, daemon, unspecified, tools
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=92, 7d-median=126, 14d-median=126; carrying terms: green, speed, congo, democratic, islamic, flood, serbia, slovakia, angola, madagascar, pakistan, poland
- usgs_quakes: today=8, 7d-median=16, 14d-median=16; carrying terms: indonesia, depth, islands, tonga, japan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, world, resolves, ceasefire, announces, extension, south, roland, garros, spurs, korea
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: https, conversable, class, revolution, marginal, economist, links, assorted, policy, marginalrevolution, economy, times
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: moran, heinrich, vance, lamonica, donald, thanedar, ruben, corporation, relations, ayanna, hoyer, christopher
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, sufficient, evidence, placed, converges, market, paper, either, identify, today, placement, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline
- [2026-06-06] Fed speeches: Barr, Deregulating in a Financial Boom: What Could Go Wrong?

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*