# WORLDSCOPE morning brief — 2026-07-29

## Headline
3862 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (770) · Russian Internal News (state + in-exile) (743) · State-Level News (401) · Ukraine Theater (total-war monitoring) (386) · World leaders & government officials (324) · Chinese Internal News (243) · Local News: St. Louis + Atlanta (202) · State Legislative Action (195) · U.S. Weather + Severe / Climate Outlooks (152) · GDELT GKG — themes / entities / watch areas (75) · Ukrainian Internal News (national + local Kyiv) (61) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 770 new of 1021 total
  - (2026-07-29) [Global] Kenya investigating unexpected deaths of 15 elephants in national park
  - (2026-07-28) [Global] Canadians spent $3.3bn less on travel to US in 2025 after Trump’s return to office
  - (2026-07-28) [Global] Past fires suggest effects of Europe and North America wildfires may linger for years
  - (2026-07-29) [Global] Rescue teams face ‘race against time’ in search for trapped survivors as death toll in Japan rises to at least 13 – live updates
  - (2026-07-29) [Global] ‘The shaking was terrifying’: stories of survival and loss emerge after Japan earthquake
  - (2026-07-29) [Global] Shares in Asian chip firms plunge further as AI sell-off continues

### Russian Internal News (state + in-exile) — 743 new of 1142 total
  - (2026-07-29) В России, по словам пользователей, перестали работать мессенджеры KakaoTalk и BiP (стали популярны после блокировки телеграма) | LEDE: Пользователи мессенджеров KakaoTalk и BiP второй день ж] (ru: В Р…
      Пользователи мессенджеров KakaoTalk и BiP второй день жалуются на перебои в их работе, сообщил телеграм-канал «Осторожно, Москва» 29 июля.
  - (2026-07-29) Война. 1617-й день. Итоги поездки Зеленского в США: президенту, похоже, удалось убедить Трампа и сенат в том, что Украина может выиграть войну, пишут американские СМИ | LEDE: «Медуза» с 24 ф] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-29) Финляндия прекратит обслуживать опоры линий связи с Россией. На них подвешены интернет-кабели | LEDE: Финская энергетическая компания Fingrid объявила российским операторам связи, что с 2027] (ru: Фин…
      Финская энергетическая компания Fingrid объявила российским операторам связи, что с 2027 года прекратит обслуживать опоры линий электропередачи, на которых подвешены волоконно-оптические линии связи, рассказали источники…
  - (2026-07-29) «Человек-паук: Новый день» — тот самый фильм, в котором есть песня Монеточки. Но это далеко не единственное его достоинство! | LEDE: В мировой прокат вышла новая часть франшизы о Человеке-па] (ru: «Че…
      В мировой прокат вышла новая часть франшизы о Человеке-пауке с подзаголовком «Новый день». Предыдущую часть «Нет пути домой» — зрители увидели пять лет назад, в ней супергерой в исполнении Тома Холланда пожертвовал всем,…
  - (2026-07-29) Пакет акций «Петербургского нефтяного терминала», изъятый у владельцев, передали компании Ротенбергов | LEDE: Росимущество передало 55% акций «Петербургского нефтяного терминала» (ПНТ), изъя] (ru: Пак…
      Росимущество передало 55% акций «Петербургского нефтяного терминала» (ПНТ), изъятые судом у владельцев, компании «Росхим», пишет «Фонтанка» со ссылкой на выписку из реестра акционеров.
  - (2026-07-29) Джареда Лето обвинили в сексуализированном насилии. Четыре женщины заявили, что на тот момент им было 16-19 лет | LEDE: Несколько женщин обвинили вокалиста группы 30 Seconds To Mars и актера] (ru: Джа…
      Несколько женщин обвинили вокалиста группы 30 Seconds To Mars и актера Джареда Лето в домогательствах и сексуализированном насилии, пишет «Би-би-си».

### State-Level News — 401 new of 787 total
  - (2026-07-28) [Alabama] Governor Ivey Highlights Alabama Success at Farnborough International Airshow
      MONTGOMERY – Governor Kay Ivey on Tuesday announced that Alabama’s strong showing in the Farnborough International Airshow last week resulted in two major industry announcements and more than 50 meetings between the Alab…
  - (2026-07-28) [California] Vehicle theft in California dropped nearly 25% in 2025
      Source
  - (2026-07-28) [California] Governor Newsom expands statewide partnerships with additional cities to clean up encampments on highways
      Source
  - (2026-07-29) [California] Kaiser used an algorithm — not clinicians — to triage mental health patients, a union alleges
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/121224-Kaiser-JAH-CM-23.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="M…
  - (2026-07-29) [California] CA’s privatized public defense leads to caseloads 3x the most basic standards, report finds
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072726-Kings-County-Superior-Court-LV-CM-08.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size w…
  - (2026-07-29) [California] Healthcare costs are surging. Taxing billionaires will help Californians keep their coverage
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/03/031326-Billionaire-Tax-JC-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### Ukraine Theater (total-war monitoring) — 386 new of 618 total
  - (2026-07-29) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-29) [Liveuamap] Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting group&039;s headquarters in several provinces Amerli, Saladin Governorat…
      Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting gro
  - (2026-07-28) [Liveuamap] General Staff of Armed Forces of Ukraine confirmed attack at the Prioritet oil depot in Udmurtiya - Liveuamap
      General Staff of Armed Forces of Ukraine confirmed attack at the Prioritet oil depot in Udmurtiya <font color
  - (2026-07-26) [Liveuamap] Bulk carrier Golden Leo (Guinea-Bissau flagged, Mumbai-owned, carrying corn from Odesa) capsized in shallow water off the Ukrainian coast today, a week after being hit by three Russian cru…
      Bulk carrier Golden Leo (Guinea-Bissau flagged, Mumbai-owned, carrying corn from Odesa) capsized in shallow water
  - (2026-07-29) [Liveuamap] Drones have attacked oil refinery in Ryazan - Liveuamap
      Drones have attacked oil refinery in Ryazan Liveuamap
  - (2026-07-29) [Liveuamap] US Central Command: Our forces and Saudi armed forces conducted precision strikes in Iraq against Iranian proxies. US and Saudi fighter jets launched raids targeting logistics sites and we…
      US Central Command: Our forces and Saudi armed forces conducted precision strikes in Iraq against Iranian proxies. US and Sa

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 243 new of 307 total
  - (2026-07-28) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1CVWt2RG1NeUtPSk5ncnpQS1NnOER4SzJGZkxqa3VGMFVwaUpnNktlc3M4d3NQdGVIMUtfMjh6NXFwQkJmR3NTN2dLUnRzM3] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-07-29) 今日开盘：沪指报3823.29点 涨幅0.26% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5OMTFkYnhGTWtKRFRoNWZKcGhNMFBOTlZERHVIemZXY3NMd1JwOUFZOV96UUZtaElrUFFJSENOX1B1S0NHR1JlelY5VzhTe] (zh:…
      今日开盘：沪指报3823.29点 涨幅0.26% 财新
  - (2026-07-28) 财经早知道｜从豪宅到普宅，“全款买房”成流行 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE41TS1WVi0xd291WlZOSUJ2YzVKUUVHMlgwN0tQcVpRbFdlc3JoS2haaXlINGNqcmVRakFXUDJGSEtCY3picktyUm15STQyZkE] (zh:…
      财经早知道｜从豪宅到普宅，“全款买房”成流行 财新
  - (2026-07-29) 海南终止第二轮赤潮应急响应 海洋牧场安全生产敲响警钟 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1yVXNsaTAwMmFDTVh5VE9qQjdDQW92VGdBa1pxYmEwS3VpR0N6dkxnbnFlc3pjSU1FVHhGWVlYbThHellxZVpfN3htcU0] (zh:…
      海南终止第二轮赤潮应急响应 海洋牧场安全生产敲响警钟 财新
  - (2026-07-29) 信贷投向结构优化 上半年深圳民营经济贷款贡献近八成增量 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBnTFplZTZRWDhMZk5qamFqR1Y0WVpUVEE0LTJ6bTEyT3dEM3VSTk9rNGgxX1MwaW5XQ3R0T3hDNWFNdld6N3ZMS1BsNE] (zh:…
      信贷投向结构优化 上半年深圳民营经济贷款贡献近八成增量 财新
  - (2026-07-28) 英伟达CDS暴涨 AI基建循环融资引债市担忧 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5EZlpaR1VDbFVYTW9WMjNWM0dTOWVfYmNCV2gwUklEN3YtaThOYTV1V3k3SE1RaDJEenU2UW1fTjlOc1ZPREhQNDJzSWp4V1l] (zh:…
      英伟达CDS暴涨 AI基建循环融资引债市担忧 财新

### Local News: St. Louis + Atlanta — 202 new of 229 total
  - (2026-07-29) [St. Louis] FEMA denies wildfire aid for 2 major Oregon fires, prompting criticism from lawmakers
      Oregon's congressional delegation says FEMA denied firefighting grants for two major wildfires despite approving aid for three others.
  - (2026-07-29) [St. Louis] Multiple women accuse Jared Leto of sexual misconduct in new BBC documentary
      Among those accusing the Academy Award-winning actor, three of the women said they had been under 18.
  - (2026-07-29) [St. Louis] Oscar-winning musician Glen Hansard dies at age 56, Irish media report
      Oscar-winning musician Glen Hansard has died in a motorcycle crash, according to Irish media outlets. He was 56.
  - (2026-07-29) [St. Louis] Federal Reserve expected to keep rates unchanged despite 'persistent inflation'
      Federal Reserve policymakers are losing patience with inflation, which has been stuck above their 2% target for more than five years.
  - (2026-07-29) [St. Louis] Crash on Interstate 44 kills 1, injures another
      The crash closed the highway for about four hours. It has since reopened.
  - (2026-07-29) [St. Louis] Downtown motorcycle crash leaves 1 dead
      St. Louis police said the motorcycle and a second vehicle crashed at 4:38 a.m. at the intersection of South 14th and Market streets.

### State Legislative Action — 195 new of 195 total
  - (2026-07-29) [Alaska SB 86] An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing sy…
      An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing system; relating to the use of virtua…
  - (2026-07-29) [Alaska SB 64] An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating t…
      An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating to write-in candidates for President…
  - (2026-07-28) [Alaska SB 140] An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
      An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
  - (2026-07-28) [Alaska HB 283] An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and provid…
      An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and providing for an effective date.
  - (2026-07-28) [Alaska HB 133] An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements t…
      An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements to nonprofit organizations, municipal…
  - (2026-07-28) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.

### U.S. Weather + Severe / Climate Outlooks — 152 new of 154 total
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 8:40AM EDT until July 29 at 2:45PM EDT by NWS Albany NY
      FFWALY The National Weather Service in Albany has issued a * Flash Flood Warning for... North Central Ulster County in east central New York... * Until 245 PM EDT Wednesday. * At 840 AM EDT, Doppler radar indicated heavy…
  - (2026-07-29) [Severe] Flood Warning: Flood Warning issued July 29 at 8:37AM EDT until July 29 at 11:19PM EDT by NWS Albany NY
      * WHAT...Minor flooding is occurring and minor flooding is forecast. * WHERE...Esopus Creek at Cold Brook. * WHEN...From this morning to late this evening. * IMPACTS...At 11.0 feet, Flood stage. Water begins to overflow…
  - (2026-07-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-29) [Severe] Flood Warning: Flood Warning issued July 29 at 8:35AM EDT until July 29 at 9:46PM EDT by NWS Albany NY
      * WHAT...Minor flooding is forecast. * WHERE...Schoharie Creek at Prattsville. * WHEN...Until late this evening. * IMPACTS...At 13.0 feet, Minor flooding of basements. * ADDITIONAL DETAILS... - At 8:15 AM EDT Wednesday t…
  - (2026-07-29) [Moderate] Heat Advisory: Heat Advisory issued July 29 at 6:30AM MDT until July 31 at 9:00PM MDT by NWS El Paso Tx/Santa Teresa NM
      * WHAT...Temperatures up to 106 expected. * WHERE...Portions of Far West Texas, including El Paso County and the Rio Grande Valley in Hudspeth County. * WHEN...From noon today to 9 PM MDT Friday. * IMPACTS...Hot temperat…
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 8:16AM EDT until July 29 at 2:15PM EDT by NWS Albany NY
      FFWALY The National Weather Service in Albany has issued a * Flash Flood Warning for... North Central Rensselaer County in east central New York... Southeastern Saratoga County in east central New York... Southwestern Wa…

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-07-29) [Russia oil sanctions perimeter · keywords] Carefully crafted to hit India and China : US Senator explains why new Russia sanctions bill targets both countries
      moneycontrol.com · English · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · keywords] Graham Sanctions Bill Passes Senate Procedural Vote
      whyn.iheart.com · English · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · keywords] Graham Sanctions Bill Passes Senate Procedural Vote
      wlac.iheart.com · English · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · keywords] Graham Sanctions Bill Passes Senate Procedural Vote
      wmmbam.iheart.com · English · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · keywords] Graham Sanctions Bill Passes Senate Procedural Vote
      knst.iheart.com · English · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · keywords] Graham Sanctions Bill Passes Senate Procedural Vote
      jetradio1400.iheart.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 61 new of 119 total
  - (2026-07-29) Zelensky Asks Trump for 300 Patriot Missiles Before Winter
      In an interview with Axios, Zelensky said he asked Trump for an emergency package of 300 Patriot missiles before the winter season, as Ukraine's stockpiles are almost depleted and the country cannot defend against Russia…
  - (2026-07-29) Majority of Poles Oppose Backing Ukraine’s EU Bid, Poll Finds
      The survey found that 52% of Poles oppose supporting Ukraine’s EU membership efforts, while 65% reject sending Polish troops to oversee a postwar ceasefire. On military assistance, 44% favored suspending support over the…
  - (2026-07-29) Iran Considered Missile Strike on Ukrainian Port After Caspian Sea Ship Attack – NYT
      Iran reportedly considered launching a symbolic ballistic missile strike on a Ukrainian seaport after Ukraine hit an Iranian vessel in the Caspian Sea, but backed down following diplomatic pressure. Tehran later said it…
  - (2026-07-29) Russia Weighs State Support for Wildberries After Ukraine Strikes
      The Kremlin is exploring financial support for Wildberries after Ukrainian drone attacks damaged its warehouses, disrupting operations and affecting thousands of businesses that rely on the retailer.
  - (2026-07-29) Russia Hints at Mobile Catapult Launchers for S8000 'AliExpress' Cruise Missiles
      Photos circulating in Russian media show what appears to be a Banderol missile mounted on a catapult launcher on display, with the missile previously known only to be air-launched by the Orion drone and Mi-28 attack heli…
  - (2026-07-29) ‘More Air Strikes on Russian Forces for Victory’ Drapaty Tells NATO Chief in 1st Call
      Ukraine's Commander-in-Chief Mykhailo Drapaty spoke with NATO's Supreme Allied Commander Europe, outlining battlefield priorities and thanking the United States for continued military assistance.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-29) [Briggs Andrew J] Form 4 (Reporting)
      filed 2026-07-29 12:29 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001193125-26-322253 Size: 5 KB
  - (2026-07-29) [FARMERS & MERCHANTS BANCORP INC] Form 4 (Issuer)
      filed 2026-07-29 12:29 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001193125-26-322253 Size: 5 KB
  - (2026-07-29) 425 - STANDARD BIOTOOLS INC. (0001162194) (Subject)
      filed 2026-07-29 12:16 UTC — Filed: 2026-07-29 AccNo: 0001140361-26-029965 Size: 659 KB
  - (2026-07-29) [Freye Theodor Werner] Form 4 (Reporting)
      filed 2026-07-29 12:14 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001644373-26-000004 Size: 4 KB
  - (2026-07-29) [VALMONT INDUSTRIES INC] Form 4 (Issuer)
      filed 2026-07-29 12:14 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001644373-26-000004 Size: 4 KB
  - (2026-07-29) 424B5 - Atlantic Union Bankshares Corp (0000883948) (Filer)
      filed 2026-07-29 12:12 UTC — Filed: 2026-07-29 AccNo: 0001104659-26-087840 Size: 1 MB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-29) [United States] California State Teachers Retirement System Has $575 . 88 Million Stock Position in Micron Technology , Inc . $MU
      domain: themarketsdaily.com · language: English · tone:
  - (2026-07-29) [Pakistan] PTI leader killed in Lahore gun attack
      domain: arynews.tv · language: English · tone:
  - (2026-07-29) [United States] Tech stocks plunge further but London market hits record high
      domain: finance.yahoo.com · language: English · tone:
  - (2026-07-29) [United States] Fed is expected to keep rates unchanged for now despite high prices
      domain: journal-advocate.com · language: English · tone:
  - (2026-07-29) [] Police regret Benue killings , say two bandits neutralized
      domain: thesun.ng · language: English · tone:
  - (2026-07-29) [United States] 1 dead , 1 hurt in east Charlotte apartment shooting
      domain: wsoctv.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 50 total
  - (2026-07-29) [BleepingComputer] These near-mint ASUS Chromebook refurbs are only $145
      Buying a new computer in 2026 is a unique experience. Rather than deal with incredibly high tech prices, more shoppers are opting for high-quality refurbished tech. This ASUS Chromebook CM30 refurb is in near-mint condit…
  - (2026-07-29) [The Hacker News] Mythos Asks the Right Question. It Doesn't Answer It.
      AI is compressing exploit timelines. The real question isn't whether your vulnerability management playbook needs to change, it's which part of it you've been getting wrong all along. The conversation happening in securi…
  - (2026-07-29) [The Hacker News] Researchers Show a Single Malicious Webpage Visit Can Compromise Tor Browser
      Nebula Security says a patched Firefox JIT flaw could be triggered by simply visiting a malicious webpage and was also used to compromise Tor Browser. Tracked as CVE-2026-10702, the bug provides arbitrary code execution…
  - (2026-07-29) [The Hacker News] 73% of Organizations Say They Are Not Fully Ready for a Major Cyberattack
      Most organizations have incident response plans, security tools, and technical teams in place. Yet new research suggests that many still lack the coordination, visibility, and executive alignment needed to withstand a se…
  - (2026-07-29) [The Hacker News] Russia Charges Telegram Founder Pavel Durov With Aiding Terrorist Activity
      The Federal Security Service of the Russian Federation (FSB) on Wednesday said it charged Telegram founder Pavel Durov for allegedly facilitating terrorist activities and for failing to remove prohibited information in v…
  - (2026-07-29) [The Hacker News] Public PoC Released for Exploited Check Point SmartConsole Authentication Bypass
      Cybersecurity researchers have shared additional technical details about a recently patched critical security flaw impacting Check Point Security Management Server and Multi-Domain Security Management Server (MDS) that h…

### Court opinions of consequence (federal & state) — 31 new of 60 total
  - (2026-07-28) U.S. Court of Appeals, 3rd Cir.: Alecto Healthcare Services LLC v.
  - (2026-07-28) U.S. Court of Appeals, D.C. Cir.: Environmental Defense Fund v. EPA
  - (2026-07-28) U.S. Court of Appeals, D.C. Cir.: The Estate of Stephen M. Jennions v. CFTC
  - (2026-07-28) U.S. Court of Appeals, 2nd Cir.: In Re: Laura Charlene Goebel
  - (2026-07-28) U.S. Court of Appeals, 6th Cir.: Socorro Perez-Hernandez v. Todd Blanche
  - (2026-07-28) U.S. Court of Appeals, 6th Cir.: United States v. Cody Dewayne King

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 27 new of 30 total
  - (2026-07-29) JAF50T (Bulgaria)
      icao24: 4520d0 · position: (40.2324, -4.3531) · alt: 11277m · 829km/h
  - (2026-07-29) GAF606 (Germany)
      icao24: 3f6533 · position: (50.9054, 7.2773) · alt: 1470m · 513km/h
  - (2026-07-29) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (34.1049, -6.5857) · alt: 11277m · 850km/h
  - (2026-07-29) CFC01 (Canada)
      icao24: c2b373 · position: (46.8343, -80.1832) · alt: 10363m · 806km/h
  - (2026-07-29) PAT483 (United States)
      icao24: adfe99 · position: (36.7994, -82.6016) · alt: 8229m · 524km/h
  - (2026-07-29) JEDI52 (United States)
      icao24: ae1eab · position: (30.6036, -87.7931) · alt: 4183m · 380km/h

### USGS earthquakes (M4.5+, past day) — 19 new of 19 total
  - (2026-07-29) M 5.4 - 153 km NE of Neiafu, Tonga
      M5.4 · 153 km NE of Neiafu, Tonga · depth 10 km
  - (2026-07-28) M 5.4 - 211 km SE of Kokopo, Papua New Guinea
      M5.4 · 211 km SE of Kokopo, Papua New Guinea · depth 10 km
  - (2026-07-28) M 5.2 - 151 km WSW of Puerto Santa, Peru
      M5.2 · 151 km WSW of Puerto Santa, Peru · depth 9.709 km
  - (2026-07-29) M 5.1 - Kermadec Islands region
      M5.1 · Kermadec Islands region · depth 35 km
  - (2026-07-28) M 5.1 - south of the Fiji Islands
      M5.1 · south of the Fiji Islands · depth 575.128 km
  - (2026-07-29) M 5.0 - South Sandwich Islands region
      M5.0 · South Sandwich Islands region · depth 60.675 km

### Paper Trading Scorecard — 18 new of 140 total
  - (2026-07-29) [Polymarket] LoL: Kiwoom DRX vs Nongshim Red Force - Game 1 Winner
      This market refers to the LoL match between Kiwoom DRX and Nongshim Red Force in the LCK Round 3-4 Rise Group, initially scheduled for July 29 at 4:00AM ET. This market will resolve to "Kiwoom DRX" if Kiwoom DRX win Game…
  - (2026-07-29) [Polymarket] Will the Dallas Cowboys win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-29) [Polymarket] Bank of Japan increases interest rates by 50+ bps after the July 2026 meeting?
      The Statement on Monetary Policy for the Bank of Japan's Monetary Policy meeting for July is scheduled to be released on July 31, 2026 (https://www.boj.or.jp/en/mopo/mpmsche_minu/index.htm). This market will resolve to t…
  - (2026-07-29) [Polymarket] Romanian parliament dissolved by July 31?
      This market will resolve to "Yes" if the sitting Romanian Chamber of Deputies and Senate are dissolved by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No". The primary resolution source for th…
  - (2026-07-29) [Manifold] Will Jason Arday's 'Great and Unfortunate Things' be available for purchase in the UK on or before August 27, 2026?
  - (2026-07-29) [Manifold] T Coronae Borealis reaches magnitude 5.0 before November 11th, 2026?

### Government Action: Sanctions + Procurement + Foreign Agents — 17 new of 161 total
  - (2026-07-29) [DSCA Arms Sale] DSCA Director Signs FMF Guaranteed Loan - dsca.mil
      DSCA Director Signs FMF Guaranteed Loan dsca.mil
  - (2026-07-29) [USASpending] $2,833,494,612 → FISHER SAND & GRAVEL CO: CONSTRUCT VERTICAL BORDER BARRIER
      Agency: Department of Homeland Security. Description: CONSTRUCT VERTICAL BORDER BARRIER
  - (2026-07-29) [USASpending] $2,032,829,135 → LOCKHEED MARTIN CORP: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONAR
      Agency: National Aeronautics and Space Administration. Description: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) SERIES TO CONTINUE ITS MISSION THROUGH NEW REQ…
  - (2026-07-29) [USASpending] $1,598,641,181 → BATTELLE SAVANNAH RIVER ALLIANCE, LLC: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING
      Agency: Department of Energy. Description: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING (M&O) CONTRACT
  - (2026-07-29) [USASpending] $1,058,337,519 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-07-29) [USASpending] $1,029,024,846 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-29) LoL: T1 vs KT Rolster - Game 2 Winner
      yes price: 0% · 24h volume: $1,513,056 · resolves 2026-07-29
  - (2026-07-29) LoL: T1 vs KT Rolster (BO3) - LCK Round 3-4 Legend Group
      yes price: 0% · 24h volume: $1,509,735 · resolves 2026-07-29
  - (2026-07-29) LoL: Kiwoom DRX vs Nongshim Red Force - Game 2 Winner
      yes price: 0% · 24h volume: $1,203,120 · resolves 2026-07-29
  - (2026-07-29) LoL: T1 vs KT Rolster - Game 1 Winner
      yes price: 0% · 24h volume: $1,126,929 · resolves 2026-07-29
  - (2026-07-29) Will Tulsi Gabbard win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,114,448 · resolves 2028-11-07
  - (2026-07-29) LoL: Top Esports vs Anyone's Legend (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $1,054,140 · resolves 2026-07-29

### U.S. Federal Action — 12 new of 19 total
  - (2026-07-29) Allocation of Assets in Single-Employer Plans; Interest Assumptions for Valuing Benefits
  - (2026-07-29) Continuation of the National Emergency With Respect to Brazil
  - (2026-07-29) Restoring Trust in the Smithsonian Institution
  - (2026-07-29) Amendment of Jet Routes J-190 and J-584 and Very High Frequency Omnidirectional Range Federal Airways V-170 and V-188 in the Vicinity of Slate Run, Pennsylvania
      This action corrects a notice of proposed rulemaking (NPRM) that the FAA published in the Federal Register on July 20, 2026, proposing to amend Jet Routes J-190 and J-584 and Very High Frequency Omnidirectional Range (VO…
  - (2026-07-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2025-16- 12, which applied to all Airbus SAS Model A319-151N, -153N, -171N, and -173N airplanes; Model A320-251N, -252N, -253N, -271N, -272N, and -273N airplanes; and M…
  - (2026-07-29) Medical Devices; Radiology Devices; Classification of the Phase-Changing Fiducial Marker for Radiation Therapy
      The Food and Drug Administration (FDA) is classifying the phase-changing fiducial marker for radiation therapy into class II (special controls). The special controls that apply to the device type are identified in this o…

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-29) [Japan] Remember Those Epic Bowser Crocs ? Theyre On Sale Now , Alongside More Mushroom Kingdom Clogs
      nintendolife.com · English
  - (2026-07-29) [Japan] Ball x Pit Final Free Update Bounces Onto Switch Next Month
      nintendolife.com · English
  - (2026-07-29) [Japan] Hot Take , Hear Me Out - Nintendo Switch 2 Forum
      nintendolife.com · English
  - (2026-07-29) [Japan] Popular Game About Dying Is Now Dead Due To Roblox Rule Changes
      kotaku.com · English
  - (2026-07-29) [Japan] Three Dead , Four Missing After Explosion Devastates Aeon Mall Kumamoto
      newsonjapan.com · English
  - (2026-07-29) [Japan] Stone Walls Collapse at Kumamoto Castle
      newsonjapan.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 6 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-29) [Marginal Revolution] Data on Chinese innovation
      China’s technological progress in recent decades has been viewed with admiration, alarm, and (in some cases) doubt. To better understand the Chinese innovation ecosystem, we compile a dataset of almost 14 million domesti…
  - (2026-07-29) [Marginal Revolution] You will learn to love AI writing
      That is the theme of my latest Free Press article, excerpt: But do I wish to eschew AI writing for the rest of my life? Absolutely not. Most of all, I want AI writing to get better, so it does not irritate me with its cl…
  - (2026-07-28) [Marginal Revolution] Congratulations to Ross D. and others
      Ross Douthat, an opinion columnist at The New York Times, is leaving to join the CBS News program “60 Minutes” as a correspondent, the show’s executive producer said in a memo to staff on Tuesday. Mr. Douthat is among a…

### GDACS — global disaster alerts — 2 new of 289 total
  - (2026-05-21) [Green] Drought in Democratic Republic of Congo, Kenya, Tanzania, Uganda
      Drought · Green alert · Democratic Republic of Congo, Kenya, Tanzania, Uganda · Minor impact for agricultural drought in 184570 km2
  - (2026-05-21) [Green] Drought in Democratic Republic of Congo, Kenya, Tanzania, Uganda
      Drought · Green alert · Democratic Republic of Congo, Kenya, Tanzania, Uganda · Minor impact for agricultural drought in 184570 km2

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=18, 14d-median=18; carrying terms: management, revising, airplanes, security, provide, action, directives, model, coast, august, applicable, final
- state_bills: today=195, 7d-median=117, 14d-median=117; carrying terms: public, private, services, address, subject, defines, unfair, rates, development, childhood, issue, agency
- state_news: today=787, 7d-median=602, 14d-median=602; carrying terms: coming, donation, carry, track, asked, bring, across, seats, officially, western, childcare, thumbnail
- local_news: today=229, 7d-median=229, 14d-median=229; carrying terms: locations, across, times, leaving, dining, college, being, content, charles, three, national, async
- foreign_news: today=1021, 7d-median=1014, 14d-median=1014; carrying terms: asked, expanding, visited, xianghe, yunnan, improper, thumbnail, needs, haidian, videos, highlighting, investigation
- chinese_internal: today=307, 7d-median=288, 14d-median=288; carrying terms: cbmiakfvx, cbmib, funds, color, china, blank, target, lxtfb, articles, cbmix, cbmibkfvx, cbmiykfvx
- russian_internal: today=1142, 7d-median=894, 14d-median=894; carrying terms: centcom, laquo, raquo, guardian, title, reuters, times, client, gazeta, httperror, russian, europe
- ukrainian_internal: today=119, 7d-median=134, 14d-median=134; carrying terms: attack, sanctions, public, refineries, ministers, technology, unlikely, hmarochos, footage, across, disrupt, called
- ukraine_theater: today=618, 7d-median=602, 14d-median=602; carrying terms: cuxpzvvmvhz, requests, zquywdnvjdzvcbknfqllhaul, cxbfzhdpny, zlewhfcmlua, asked, dthxmtq, wkpcutrtzfnsumnpajvtbvr, rhdmmtbvow, durzmi, fcjnqeghuua, oennvsjvovvhlmgjrz
- paper_bets: today=140, 7d-median=139, 14d-median=139; carrying terms: andrew, experience, artist, humanoid, emerson, presidential, miami, officially, seats, award, alaska, named
- weather: today=154, 7d-median=173, 14d-median=173; carrying terms: tuesday, peachtree, experience, hours, interior, locations, extending, moderate, bring, outlook, across, grand
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexjpus, openings, payrolls, cpiaucsl, cpilfesl, supply, pcepilfe, rates, spread, dexuseu, jolts, recession
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, silver, yield, futures, china, corporate, bitcoin, rates, agriculture, crypto, large, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=161, 7d-median=119, 14d-median=119; carrying terms: qaida, sanctions, public, asked, islamic, territorial, services, prohibited, resolution, guatemala, somalia, yemen
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, congresstrading, quantitative, quiver, unauthorized, https, quiverquant, client, httperror
- billionaires: today=33, 7d-median=34, 14d-median=34; carrying terms: ballmer, family, euronext, ortega, fashion, microsoft, infrastructure, mukesh, finance, huang, technology, walton
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, robert, trade, school, services, international, district, appeals, supreme, california, court, board
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: platner, disbursements, ocasio, pinkston, alexandria, cooper, robert, lindsey, trone, colorado, cortez, receipts
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=75, 7d-median=47, 14d-median=47; carrying terms: israel, trump, english, hezbollah, sanctions, market, israeli, russia, chinese, perimeter
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: australia, language, domain, found, crash, india, killed, police, english, killing
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=24, 14d-median=24; carrying terms: belgium, canada, position, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: internationally, passengers, public, tristan, mainly, locations, infected, watery, outbreaks, institut, seven, hondius
- cisa_kev: today=13, 7d-median=16, 14d-median=16; carrying terms: protocol, business, lockout, suite, product, sharepoint, command, microsoft, option, connection, association, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=289, 7d-median=272, 14d-median=272; carrying terms: venezuela, earthquake, czech, slovakia, costa, philippines, marino, green, bosnia, brazil, papua, agricultural
- usgs_quakes: today=19, 7d-median=23, 14d-median=23; carrying terms: region, islands, depth, south, philippines, indonesia, mexico, guinea, papua
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, prime, resolves, ethiopia, minister, interest, volume, meeting, price, abiebie, decrease, adanech
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: benefit, marginalrevolution, conversable, marginal, class, revolution, economist, https, looking, quality, college, dentist
- tech_news: today=50, 7d-median=57, 14d-median=57; carrying terms: attack, technology, plants, called, major, spectrum, leadership, policy, weekly, model, computer, server
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: lucas, william, danny, justice, tiffany, interior, mariannette, kamlager, moore, carey, veronica, graham
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, evidence, claude, markets, placed, paper, today, converges, either, placement, market, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*