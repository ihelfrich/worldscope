# WORLDSCOPE morning brief — 2026-07-29

## Headline
3191 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (726) · Russian Internal News (state + in-exile) (681) · State-Level News (336) · World leaders & government officials (324) · Chinese Internal News (228) · Local News: St. Louis + Atlanta (179) · U.S. Weather + Severe / Climate Outlooks (153) · State Legislative Action (117) · GDELT GKG — themes / entities / watch areas (70) · Ukraine Theater (total-war monitoring) (63) · Ukrainian Internal News (national + local Kyiv) (52) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 726 new of 1005 total
  - (2026-07-29) [Global] US and Saudi Arabia strike ‘Iran-aligned’ groups in Iraq
      The US and Saudi Arabia launched joint air strikes on Iraq, targeting ‘Iran-aligned’ groups.
  - (2026-07-29) [Global] Jayden Seales takes five wickets as West Indies beat Pakistan in first Test
      West Indies take a 1-0 lead in the two-Test series after Jayden Seales dominates with the ball on day 4 in Trinidad.
  - (2026-07-29) [Global] Iran and Oman swap proposals to manage Strait of Hormuz: What we know
      Iran is proposing a deal that would see it have significantly more control than Oman.
  - (2026-07-29) [Global] Will Germany bring back mandatory military conscription next year?
      A voluntary recruitment drive has only drawn 500 people so far this year, with many more eager to opt out.
  - (2026-07-29) [Global] Why is Uganda experiencing a food crisis?
      At least 19 people have died of starvation in the country and 1.5 million are at risk of malnutrition, experts warn.
  - (2026-07-29) [Global] Russian industrial sites on fire after Ukrainian drone attacks
      Russia's top online retailer Wildberries says it has evacuated warehouses in Ryazan.

### Russian Internal News (state + in-exile) — 681 new of 1092 total
  - (2026-07-29) Умер диджей Kavinsky — автор трека Nightcall из фильма «Драйв» | LEDE: В Париже умер Венсан Пьер Клод Белорже, известный как диджей Kavinsky, сообщают Le Parisien и France24. ] (ru: Умер диджей Kavins…
      В Париже умер Венсан Пьер Клод Белорже, известный как диджей Kavinsky, сообщают Le Parisien и France24.
  - (2026-07-29) Путин уволил Александра Бречалова с поста главы Удмуртии | LEDE: Президент РФ Владимир Путин отправил в отставку главу Удмуртии Александра Бречалова. ] (ru: Путин уволил Александра Бречалова с поста г…
      Президент РФ Владимир Путин отправил в отставку главу Удмуртии Александра Бречалова.
  - (2026-07-29) Песня Монеточки попала в саундтрек фильма «Человек-паук: Новый день» | LEDE: В новом фильме Marvel «Человек-паук: Новый день» звучит песня «Монополия» российской певицы Лизы Монеточки. Об эт] (ru: Пес…
      В новом фильме Marvel «Человек-паук: Новый день» звучит песня «Монополия» российской певицы Лизы Монеточки. Об этом рассказали зрители, побывавшие на пресс-показах.
  - (2026-07-29) Reuters: Китай продал Ирану партию переносных зенитно-ракетных комплексов для восстановления ПВО после американских ударов | LEDE: Иран ожидает первую партию из 400 переносных зенитно-ракетн] (ru: Reu…
      Иран ожидает первую партию из 400 переносных зенитно-ракетных комплексов (ПЗРК), купленных им у Китая, пишет Reuters со ссылкой на три источника.
  - (2026-07-29) В Екатеринбурге задержали подозреваемого в избиении ученого РАН Никиты Зезина. Вскоре после нападения он умер | LEDE: По делу об избиении ученого РАН Никиты Зезина задержан 38-летний житель ] (ru: В Е…
      По делу об избиении ученого РАН Никиты Зезина задержан 38-летний житель Екатеринбурга. Об этом сообщили в Следственном комитете.
  - (2026-07-29) The New York Times: Иран рассматривал возможность нанести удар по морскому порту Украины в ответ на атаку на свое торговое судно | LEDE: Иран рассматривал возможность нанести удар по морском] (ru: The…
      Иран рассматривал возможность нанести удар по морскому порту в Украине в ответ на украинскую атаку на иранское торговое судно в Каспийском море, пишет The New York Times со ссылкой на иранских и западных чиновников.

### State-Level News — 336 new of 742 total
  - (2026-07-28) [Alabama] Governor Ivey Highlights Alabama Success at Farnborough International Airshow
      MONTGOMERY – Governor Kay Ivey on Tuesday announced that Alabama’s strong showing in the Farnborough International Airshow last week resulted in two major industry announcements and more than 50 meetings between the Alab…
  - (2026-07-28) [California] A judge sent a doctor to evaluate California’s largest ICE detention center. What he found
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/012026-California-City-Immigration-Processing-Center-AP-CM-04.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size siz…
  - (2026-07-28) [California] Antes enseñaban sobre un héroe. Ahora profesores reconsideran las lecciones sobre César Chávez tras acusaciones
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/031926_Cesar-Chavez-LA_TS_CM_18.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-07-28) [California] Brasil permite a los padres controlar el uso de las redes sociales por parte de sus hijos. ¿Por qué California no?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/08/083024_Santa-Monica-Construction_-ZS-32_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp…
  - (2026-07-28) [California] What Brazil can teach CA when it comes to kids and tech
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/083024-Cellphone-Ban-DD-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-28) [California] Vehicle theft in California dropped nearly 25% in 2025
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 228 new of 299 total
  - (2026-07-28) Covid-19 Infections Surge Across China as Virus Reclaims Dominance - Caixin Global
      Covid-19 Infections Surge Across China as Virus Reclaims Dominance Caixin Global
  - (2026-07-28) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1CVWt2RG1NeUtPSk5ncnpQS1NnOER4SzJGZkxqa3VGMFVwaUpnNktlc3M4d3NQdGVIMUtfMjh6NXFwQkJmR3NTN2dLUnRzM3] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-07-29) 今日开盘：沪指报3823.29点 涨幅0.26% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5OMTFkYnhGTWtKRFRoNWZKcGhNMFBOTlZERHVIemZXY3NMd1JwOUFZOV96UUZtaElrUFFJSENOX1B1S0NHR1JlelY5VzhTe] (zh:…
      今日开盘：沪指报3823.29点 涨幅0.26% 财新
  - (2026-07-28) 财经早知道｜从豪宅到普宅，“全款买房”成流行 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE41TS1WVi0xd291WlZOSUJ2YzVKUUVHMlgwN0tQcVpRbFdlc3JoS2haaXlINGNqcmVRakFXUDJGSEtCY3picktyUm15STQyZkE] (zh:…
      财经早知道｜从豪宅到普宅，“全款买房”成流行 财新
  - (2026-07-29) 海南终止第二轮赤潮应急响应 海洋牧场安全生产敲响警钟 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1yVXNsaTAwMmFDTVh5VE9qQjdDQW92VGdBa1pxYmEwS3VpR0N6dkxnbnFlc3pjSU1FVHhGWVlYbThHellxZVpfN3htcU0] (zh:…
      海南终止第二轮赤潮应急响应 海洋牧场安全生产敲响警钟 财新
  - (2026-07-28) 英伟达CDS暴涨 AI基建循环融资引债市担忧 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5EZlpaR1VDbFVYTW9WMjNWM0dTOWVfYmNCV2gwUklEN3YtaThOYTV1V3k3SE1RaDJEenU2UW1fTjlOc1ZPREhQNDJzSWp4V1l] (zh:…
      英伟达CDS暴涨 AI基建循环融资引债市担忧 财新

### Local News: St. Louis + Atlanta — 179 new of 220 total
  - (2026-07-28) [St. Louis] KSDK’s Art Holliday celebrates Chuck Berry’s pianist Johnnie Johnson in upcoming documentary ‘Johnnie Be Good’
      Despite being a Rock & Roll Hall of Fame inductee, most people do not know his name. Despite being the man who hired an unknown guitarist named Chuck Berry to be in his band for a performance on New Year’s Eve 1952, most…
  - (2026-07-28) [St. Louis] Free 4 All STL announces 2026 dates, opens for artist submissions
      The inaugural Free 4 All music showcase took over the streets of Grand Center in September 2025, bringing 100 St. Louis-based acts of every conceivable genre to nine stages throughout the district, with droves of local m…
  - (2026-07-28) [St. Louis] G’Ra Asim tackles love, identity, and culture in new book ‘99 Problems Finding the 1’
      Jay-Z said he had 99 problems, but a (rather choice word for a) woman wasn’t one. St. Louis–born Washington University professor and musician G’Ra Asim has 99 problems as well—but his problems revolve around exactly what…
  - (2026-07-28) [St. Louis] New St. Louis experience lets kids excavate a life-size dinosaur skeleton
      Wearing field vests and armed with excavation tools, a group of young paleontologists carefully brushes away sand until the first fossil appears. One by one, they uncover buried bones, match each discovery to a field map…
  - (2026-07-28) [St. Louis] Top things to do in St. Louis this weekend: July 31–August 2
      Ain’t Too Proud | July 27–August 2 The Broadway hit follows The Temptations from Detroit to the pinnacle of the charts. See website for times and prices. The Muny, 1 Theatre Dr., Forest Park. St. Charles County Fair | Ju…
  - (2026-07-28) [St. Louis] Found and Formed arts pop-ups let parents and kids create side by side
      Parallel play isn’t just a milestone for toddlers. Found and Formed creates a space where parents can flex their creative muscles right alongside their kiddos, each working on age-appropriate crafts while fueled by coffe…

### U.S. Weather + Severe / Climate Outlooks — 153 new of 156 total
  - (2026-07-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 5:28AM EDT until July 29 at 9:00AM EDT by NWS Albany NY
      FFWALY The National Weather Service in Albany has extended the * Flash Flood Warning for... Southwestern Albany County in east central New York... Northeastern Greene County in east central New York... * Until 900 AM EDT…
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 5:23AM EDT until July 29 at 9:00AM EDT by NWS Albany NY
      FFWALY The National Weather Service in Albany has extended the * Flash Flood Warning for... South Central Greene County in east central New York... Northeastern Ulster County in east central New York... * Until 900 AM ED…
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 5:22AM EDT until July 29 at 9:00AM EDT by NWS Albany NY
      FFWALY The National Weather Service in Albany has extended the * Flash Flood Warning for... Southwestern Greene County in east central New York... * Until 900 AM EDT. * At 522 AM EDT, Doppler radar indicated heavy rain a…
  - (2026-07-29) [Severe] Special Marine Warning: Special Marine Warning issued July 29 at 5:12AM EDT until July 29 at 6:00AM EDT by NWS Newport/Morehead City NC
      SMWMHX The National Weather Service in Newport has issued a * Special Marine Warning for... Waters from Cape Hatteras to Ocracoke Inlet NC from 20 to 60 NM... Waters from Cape Lookout to Surf City NC from 20 to 60 NM...…
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 5:07AM EDT until July 29 at 8:15AM EDT by NWS Upton NY
      FFWOKX The National Weather Service in Upton has issued a * Flash Flood Warning for... Southern Fairfield County in southern Connecticut... Southwestern New Haven County in southern Connecticut... * Until 815 AM EDT. * A…

### State Legislative Action — 117 new of 117 total
  - (2026-07-29) [Alaska SB 86] An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing sy…
      An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing system; relating to the use of virtua…
  - (2026-07-29) [Alaska SB 64] An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating t…
      An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating to write-in candidates for President…
  - (2026-07-28) [Alaska SB 140] An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
      An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
  - (2026-07-28) [Alaska HB 283] An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and provid…
      An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and providing for an effective date.
  - (2026-07-28) [Alaska HB 133] An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements t…
      An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements to nonprofit organizations, municipal…
  - (2026-07-28) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.

### GDELT GKG — themes / entities / watch areas — 70 new of 70 total
  - (2026-07-29) [Russia oil sanctions perimeter · themes] Rritja e çmimeve / Limonët , kafeja dhe gazi produktet bazë shtrenjtohen mbi mesataren
      albeu.com · Albanian · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] 哪些地方易发山洪 ？ 露营如何选址 ？ 安全指南请收 _ 央广网
      news.cnr.cn · Chinese · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] Рязанський НПЗ та база катерів РФ атаковані ЗСУ 29 липня
      rbc.ua · Ukrainian · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] CSD Berlin : Prien will mehr Geld für Angebote gegen Radikalisierung bereitstellen
      sueddeutsche.de · German · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] Иран закроет пролив для стран , использующих замороженные активы ABC . AZ
      abc.az · Russian · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] Потужний землетрус відбувся в Японії : є загиблі і багато поранених
      fakty.ua · Ukrainian · tone NA

### Ukraine Theater (total-war monitoring) — 63 new of 240 total
  - (2026-07-29) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-29) [Liveuamap] General Staff of Armed Forces of Ukraine confirmed attack at the Prioritet oil depot in Udmurtiya - Liveuamap
      General Staff of Armed Forces of Ukraine confirmed attack at the Prioritet oil depot in Udmurtiya <font color
  - (2026-07-26) [Liveuamap] Bulk carrier Golden Leo (Guinea-Bissau flagged, Mumbai-owned, carrying corn from Odesa) capsized in shallow water off the Ukrainian coast today, a week after being hit by three Russian cru…
      Bulk carrier Golden Leo (Guinea-Bissau flagged, Mumbai-owned, carrying corn from Odesa) capsized in shallow water
  - (2026-07-29) [Liveuamap] News Live - iraq.liveuamap.com
      News Live iraq.liveuamap.com
  - (2026-07-29) [Liveuamap] The Israeli army: Over the past few days, we found and destroyed dozens of Hezbollah weapons and ammunition in southern Lebanon. Tel Aviv-Yafo, Tel Aviv District - Lebanon news on live map…
      The Israeli army: Over the past few days, we found and destroyed dozens of Hezbollah weapons and ammunition in so
  - (2026-07-25) [Liveuamap] Several airstrikes target Yemen's Hodeidah port. Al-Mayadeen reports the strikes were carried out by Saudi forces - Liveuamap
      Several airstrikes target Yemen's Hodeidah port. Al-Mayadeen reports the strikes were carried out by Saudi forces &nbs

### Ukrainian Internal News (national + local Kyiv) — 52 new of 113 total
  - (2026-07-29) ЗМІ: Після зустрічі Зеленського з Трампом у США Віткофф і Кушнер вперше погодились приїхати в Київ | LEDE: Спеціальний посланник США Стів Віткофф та зять Трампа Джаред Кушнер вперше погодились ] (uk:…
      Спеціальний посланник США Стів Віткофф та зять Трампа Джаред Кушнер вперше погодились відвідати Київ у рамках зусиль, спрямованих на припинення війни.
  - (2026-07-29) Серпень прийде зі спекою до +37° | LEDE: Останні дні липня та початок серпня в Україні будуть без опадів, на вихідних повернеться спека до +37°.] (uk: Серпень прийде зі спекою до +37°)
      Останні дні липня та початок серпня в Україні будуть без опадів, на вихідних повернеться спека до +37°.
  - (2026-07-29) З Донечични вирішили евакуювати частину автомобілів швидкої допомоги | LEDE: З Донеччини до Дніпра через обстріли евакуюють машини швидкої, які не використовують.] (uk: З Донечични вирішили евакуювати…
      З Донеччини до Дніпра через обстріли евакуюють машини швидкої, які не використовують.
  - (2026-07-29) У Києві оголосили підозру 19-річному студенту: поранив трьох людей ножем | LEDE: У Києві 19-річному студенту повідомили про підозру в замаху на вбивство та завданні тяжких тілесних ушкоджень дв] (uk:…
      У Києві 19-річному студенту повідомили про підозру в замаху на вбивство та завданні тяжких тілесних ушкоджень двом людям.
  - (2026-07-29) Трамп змінює риторику щодо України: головні підсумки візиту Зеленського у США | LEDE: ] (uk: Трамп змінює риторику щодо України: головні підсумки візиту Зеленського у США)
  - (2026-07-29) У організаторів схеми фейкової інвалідності вилучили 14 мільйонів готівки – прокуратура | LEDE: Прокуратура та СБУ вилучили понад 14 млн грн у підозрюваних у схемі відстрочки від мобілізації за] (uk:…
      Прокуратура та СБУ вилучили понад 14 млн грн у підозрюваних у схемі відстрочки від мобілізації за фейковою інвалідністю.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-29) [Vincent Ron] Form 4 (Reporting)
      filed 2026-07-29 01:48 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000075 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:48 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000075 Size: 19 KB
  - (2026-07-29) [KORN JEFFREY G] Form 4 (Reporting)
      filed 2026-07-29 01:48 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000074 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:48 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000074 Size: 19 KB
  - (2026-07-29) [Gaylor Douglas Walter] Form 4 (Reporting)
      filed 2026-07-29 01:46 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000071 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:46 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000071 Size: 19 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 55 total
  - (2026-07-29) [The Hacker News] Public PoC Released for Exploited Check Point SmartConsole Authentication Bypass
      Cybersecurity researchers have shared additional technical details about a recently patched critical security flaw impacting Check Point Security Management Server and Multi-Domain Security Management Server (MDS) that h…
  - (2026-07-29) [The Hacker News] OpenAI Agent Used Exposed Credentials Across Four Services During Hugging Face Breach
      OpenAI on Tuesday revealed the rogue artificial intelligence (AI) agent that escaped its sealed evaluation environment and broke into Hugging Face's production environment also hacked multiple third-party accounts and se…
  - (2026-07-29) [The Hacker News] New Gitea RCE Lets Repository Writers Plant a Git Hook to Run Shell Commands
      Gitea, the self-hosted Git platform, has patched a critical remote code execution vulnerability. A user with ordinary repository write access can turn attacker-controlled patch content into a live Git hook and run shell…
  - (2026-07-29) [The Hacker News] Flying Eagle Android RAT Traces Found on 170 Servers as Source Code Circulates
      Source code for the Flying Eagle Android remote access trojan (RAT) framework is circulating through criminal Telegram channels. Hunt.io and independent researcher NetAskari traced matching control panels and certificate…
  - (2026-07-29) [The Hacker News] Two Compromised joyfill npm Packages Run RAT When Imported Into Node.js
      Beta release versions of two npm packages in the @joyfill namespace have been compromised to deliver a remote access trojan (RAT) associated with the DEV#POPPER malware family. The list of affected packages is as follows…
  - (2026-07-29) [Schneier on Security] Measuring LLMs’ Ability to Perform Cryptanalysis
      There’s new benchmark measuring AI’s ability to perform mathematical cryptanalysis. Anthropic’s frontier model actually found new attacks. The benchmark: “CryptanalysisBench: Can LLMs do Cryptanalysis?” The idea is to be…

### Court opinions of consequence (federal & state) — 32 new of 60 total
  - (2026-07-28) U.S. Court of Appeals, 11th Cir.: Michael Davis v. Lockheed Martin Corporation
  - (2026-07-28) U.S. Court of Appeals, 3rd Cir.: Alecto Healthcare Services LLC v.
  - (2026-07-28) U.S. Court of Appeals, 6th Cir.: Socorro Perez-Hernandez v. Todd Blanche
  - (2026-07-28) U.S. Court of Appeals, 6th Cir.: United States v. Cody Dewayne King
  - (2026-07-28) U.S. Court of Appeals, 7th Cir.: Alice Stills v. Mead Johnson & Company LLC
  - (2026-07-28) U.S. Court of Appeals, 7th Cir.: Gina Wieger v. Mead Johnson & Company LLC

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 30 total
  - (2026-07-29) SAMU05 (France)
      icao24: 39ca81 · position: (44.5289, 6.0507) · alt: 1310m · 171km/h
  - (2026-07-29) PUMA52 (Slovenia)
      icao24: 506e19 · position: (46.335, 15.4617) · alt: 1463m · 168km/h
  - (2026-07-29) SAMU59 (France)
      icao24: 39b5d1 · position: (50.8217, 2.6796) · alt: 441m · 250km/h
  - (2026-07-29) CFC2977 (Canada)
      icao24: c2b585 · position: (53.2859, -0.0249) · alt: 8229m · 633km/h
  - (2026-07-29) CNA26 (Spain)
      icao24: 34650e · position: (27.7923, -15.1598) · alt: 487m · 134km/h
  - (2026-07-29) JAF5KH (Belgium)
      icao24: 44d1ba · position: (40.44, 23.6654) · alt: 11582m · 822km/h

### USGS earthquakes (M4.5+, past day) — 19 new of 19 total
  - (2026-07-29) M 5.4 - 153 km NE of Neiafu, Tonga
      M5.4 · 153 km NE of Neiafu, Tonga · depth 10 km
  - (2026-07-28) M 5.4 - 211 km SE of Kokopo, Papua New Guinea
      M5.4 · 211 km SE of Kokopo, Papua New Guinea · depth 10 km
  - (2026-07-28) M 5.2 - 151 km WSW of Puerto Santa, Peru
      M5.2 · 151 km WSW of Puerto Santa, Peru · depth 9.709 km
  - (2026-07-29) M 5.1 - Kermadec Islands region
      M5.1 · Kermadec Islands region · depth 35 km
  - (2026-07-28) M 5.1 - south of the Fiji Islands
      M5.1 · south of the Fiji Islands · depth 575.128 km
  - (2026-07-29) M 5.0 - south of Tonga
      M5.0 · south of Tonga · depth 10 km

### Paper Trading Scorecard — 17 new of 142 total
  - (2026-07-29) [Polymarket] Will Gold (XAUUSD) hit (HIGH) $4,400 in July?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of July 2026, any 1-minute candle for Gold (XAUUSD) has a final "High" or "Low" price equal to or beyond (above for ↑…
  - (2026-07-29) [Polymarket] Will the Dallas Cowboys win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-29) [Polymarket] Bank of Japan increases interest rates by 50+ bps after the July 2026 meeting?
      The Statement on Monetary Policy for the Bank of Japan's Monetary Policy meeting for July is scheduled to be released on July 31, 2026 (https://www.boj.or.jp/en/mopo/mpmsche_minu/index.htm). This market will resolve to t…
  - (2026-07-29) [Polymarket] Romanian parliament dissolved by July 31?
      This market will resolve to "Yes" if the sitting Romanian Chamber of Deputies and Senate are dissolved by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No". The primary resolution source for th…
  - (2026-07-29) [Manifold] T Coronae Borealis reaches magnitude 5.0 before November 11th, 2026?
  - (2026-07-29) [Manifold] Will Spiderman: Brand New Day beat Spiderman: No Way Home's opening weekend?

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 160 total
  - (2026-07-29) [DSCA Arms Sale] DSCA Director Signs FMF Guaranteed Loan - dsca.mil
      DSCA Director Signs FMF Guaranteed Loan dsca.mil
  - (2026-07-29) [USASpending] $2,833,494,612 → FISHER SAND & GRAVEL CO: CONSTRUCT VERTICAL BORDER BARRIER
      Agency: Department of Homeland Security. Description: CONSTRUCT VERTICAL BORDER BARRIER
  - (2026-07-29) [USASpending] $2,032,829,135 → LOCKHEED MARTIN CORP: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONAR
      Agency: National Aeronautics and Space Administration. Description: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) SERIES TO CONTINUE ITS MISSION THROUGH NEW REQ…
  - (2026-07-29) [USASpending] $1,598,641,181 → BATTELLE SAVANNAH RIVER ALLIANCE, LLC: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING
      Agency: Department of Energy. Description: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING (M&O) CONTRACT
  - (2026-07-29) [USASpending] $1,058,337,519 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-07-29) [USASpending] $1,029,024,846 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### U.S. Federal Action — 13 new of 20 total
  - (2026-07-29) CONTENTS
  - (2026-07-29) Allocation of Assets in Single-Employer Plans; Interest Assumptions for Valuing Benefits
  - (2026-07-29) Continuation of the National Emergency With Respect to Brazil
  - (2026-07-29) Restoring Trust in the Smithsonian Institution
  - (2026-07-29) Amendment of Jet Routes J-190 and J-584 and Very High Frequency Omnidirectional Range Federal Airways V-170 and V-188 in the Vicinity of Slate Run, Pennsylvania
      This action corrects a notice of proposed rulemaking (NPRM) that the FAA published in the Federal Register on July 20, 2026, proposing to amend Jet Routes J-190 and J-584 and Very High Frequency Omnidirectional Range (VO…
  - (2026-07-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2025-16- 12, which applied to all Airbus SAS Model A319-151N, -153N, -171N, and -173N airplanes; Model A320-251N, -252N, -253N, -271N, -272N, and -273N airplanes; and M…

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-29) [China] With ten - nation anti - ballistic missile coalition taking shape , how close is Europe to strategic autonomy ?
      eng.chinamil.com.cn · English
  - (2026-07-29) [China] Newspaper features on Chinese mathematician Fields Medal win spark rare print - media craze , inspiring young Chinese
      globaltimes.cn · English
  - (2026-07-29) [China] Google Pixel 11 Pro vs . Pixel 10 Pro : Should you bump your Pixel Pro to the newest one when it comes out ?
      androidcentral.com · English
  - (2026-07-29) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-29) [China] FCC ban on imports of Chinese advanced robots , power inverters a counterproductive , self - defeating move : expert
      globaltimes.cn · English
  - (2026-07-29) [China] China expels Tibetan monks and nuns from Larung Gar and demolished their dwellings
      thetibetpost.com · English

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-07-29) Los Cabos Open: Dalibor Svrcina vs Adam Walton
      yes price: 100% · 24h volume: $1,388,553 · resolves 2026-08-03
  - (2026-07-29) LoL: Kiwoom DRX vs Nongshim Red Force - Game 2 Winner
      yes price: 0% · 24h volume: $1,169,134 · resolves 2026-07-29
  - (2026-07-29) Will Tulsi Gabbard win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,109,608 · resolves 2028-11-07
  - (2026-07-29) LoL: Kiwoom DRX vs Nongshim Red Force - Game 1 Winner
      yes price: 0% · 24h volume: $908,571 · resolves 2026-07-29
  - (2026-07-29) LoL: Kiwoom DRX vs Nongshim Red Force (BO3) - LCK Round 3-4 Rise Group
      yes price: 0% · 24h volume: $871,577 · resolves 2026-07-29
  - (2026-07-29) US x Iran Effective Ceasefire by July 24?
      yes price: 36% · 24h volume: $717,260 · resolves 2026-07-24

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-29) [Marginal Revolution] Data on Chinese innovation
      China’s technological progress in recent decades has been viewed with admiration, alarm, and (in some cases) doubt. To better understand the Chinese innovation ecosystem, we compile a dataset of almost 14 million domesti…
  - (2026-07-29) [Marginal Revolution] You will learn to love AI writing
      That is the theme of my latest Free Press article, excerpt: But do I wish to eschew AI writing for the rest of my life? Absolutely not. Most of all, I want AI writing to get better, so it does not irritate me with its cl…
  - (2026-07-28) [Marginal Revolution] Congratulations to Ross D. and others
      Ross Douthat, an opinion columnist at The New York Times, is leaving to join the CBS News program “60 Minutes” as a correspondent, the show’s executive producer said in a memo to staff on Tuesday. Mr. Douthat is among a…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 37 total
  - (2026-07-29) MOVER ▼ Tadashi Yanai & family — $66.67B ($-0.46B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-29) MOVER ▼ Carlos Slim Helu & family — $126.14B ($-0.16B since yesterday)
      Mexico · Telecom · source: Telecom

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=18, 14d-median=18; carrying terms: directives, review, airworthiness, published, special, proposes, provide, additional, airspace, management, airplanes, safety
- state_bills: today=117, 7d-median=117, 14d-median=117; carrying terms: grants, title, pursuant, compliance, protection, adopt, resources, among, colorado, amend, county, authorizes
- state_news: today=742, 7d-median=602, 14d-median=602; carrying terms: massachusetts, seeking, third, opener, grand, permit, opposition, governor, attorneys, though, helps, special
- local_news: today=220, 7d-median=228, 14d-median=228; carrying terms: grand, husband, leaves, inside, general, figure, little, async, loading, county, vehicle, power
- foreign_news: today=1005, 7d-median=1006, 14d-median=1006; carrying terms: russia, watchdog, defending, feeds, third, title, emojis, internet, canada, special, general, winner
- chinese_internal: today=299, 7d-median=288, 14d-median=288; carrying terms: title, chinese, markets, cbmiaefvx, color, cbmizkfvx, cbmiykfvx, https, global, cbmickfvx, lxtfb, cbmia
- russian_internal: today=1092, 7d-median=894, 14d-median=894; carrying terms: found, telegram, title, httperror, times, media, novaya, research, bloomberg, group, street, reuters
- ukrainian_internal: today=113, 7d-median=134, 14d-median=134; carrying terms: talks, russia, refineries, hromadske, storage, change, zaporizhzhia, odesa, large, destroyed, title, httperror
- ukraine_theater: today=240, 7d-median=558, 14d-median=558; carrying terms: wlotalcytmlrmxq, xbhlszujdtm, russia, ynhsqnn, dnwfrmweo, third, oegybzrlddbsc, jcsmizdy, vkvuvmz, zkmynxvmz, utjhxzfqxemdgx, jqamsyoepen
- paper_bets: today=142, 7d-median=140, 14d-median=140; carrying terms: performing, review, emerson, award, information, washington, sachs, netanyahu, title, virginia, officially, caribbean
- weather: today=156, 7d-median=173, 14d-median=173; carrying terms: humid, increased, rivers, afddtx, strong, grand, basin, includes, large, caribbean, boston, special
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: balance, vixcls, dexuseu, latest, indicator, inflation, assets, supply, commodities, nonfarm, cpiaucsl, spread
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, equities, close, natural, futures, agriculture, corporate, range, commodities, russell, china, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=160, 7d-median=119, 14d-median=119; carrying terms: actions, russia, chains, general, somalia, manufacture, operations, libya, docket, unreasonable, oblasts, chemical
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, https, quiver, quiverquant, client, httperror, congresstrading, unauthorized, quantitative
- billionaires: today=37, 7d-median=34, 14d-median=34; carrying terms: technologies, euronext, walton, finance, yiming, changpeng, meyers, arnault, japan, buffett, carlos, france
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: school, robert, douglas, blanche, california, services, district, supreme, court, trade, international, holdings
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, therapeutics
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: warner, graham, shawn, brown, platner, talarico, michael, ossoff, filing, lindsey, colorado, jonathan
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan, china
- gdelt_gkg: today=70, 7d-median=47, 14d-median=47; carrying terms: english, israel, hezbollah, trump, russia, chinese, perimeter, sanctions
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=24, 14d-median=24; carrying terms: france, canada, position, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: found, increased, identification, organs, brands, rabies, information, fever, temporally, observed, syndrome, onboard
- cisa_kev: today=13, 7d-median=16, 14d-median=16; carrying terms: command, overly, authentication, suite, product, connection, protocol, microsoft, vendor, authorization, remediation, management
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=287, 7d-median=272, 14d-median=272; carrying terms: slovakia, orange, north, russia, czech, sweden, costa, salvador, monaco, impact, magnitude, france
- usgs_quakes: today=19, 7d-median=23, 14d-median=23; carrying terms: region, depth, islands, south, philippines, indonesia, papua, mexico, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: meeting, minister, resolves, rates, interest, ethiopia, prime, price, volume, adanech, abiebie, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, benefit, class, marginalrevolution, https, conversable, marginal, economist, quality, looking, nurse, certain
- tech_news: today=55, 7d-median=57, 14d-median=57; carrying terms: covered, vulnerability, company, again, field, major, blogging, download, unauthenticated, edition, attack, leadership
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: zachary, scholten, norcross, wilson, sanford, hickenlooper, marie, steny, veronica, kagan, scalise, stauber
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, identify, converges, today, claude, decision, paper, unavailable, market, module, markets, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*