# WORLDSCOPE morning brief — 2026-07-29

## Headline
3238 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (626) · Russian Internal News (state + in-exile) (587) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (291) · State-Level News (290) · State Legislative Action (258) · Chinese Internal News (205) · Local News: St. Louis + Atlanta (182) · U.S. Weather + Severe / Climate Outlooks (145) · Ukrainian Internal News (national + local Kyiv) (40) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 626 new of 1007 total
  - (2026-07-28) [Global] Burnham has no scope to increase borrowing, think tank warns
      The Prime Minister has announced a series of cost-of-living measure since taking office but is facing questions about how he will fund them.
  - (2026-07-28) [Global] Brits urged to avoid dangerous plug adaptors this summer - what to watch out for
      Campaign group Electrical Safety First has urged those "heading abroad this summer to think before they buy".
  - (2026-07-28) [Global] Sloppy and clumsy but overwhelming - inside the rogue ChatGPT hack
      Details have been released of an emergency call with hundreds of cyber-security experts after the ChatGPT hack of a tech company.
  - (2026-07-29) [Global] Trump administration bans new Chinese humanoid robots
      The US and China are locked in a race to the lead the world in robotics and artificial intelligence.
  - (2026-07-28) [Global] eBay agrees $56m settlement with bloggers over harassment case
      Former eBay executives carried out "unprecedented" harassment over a critical newsletter.
  - (2026-07-28) [Global] 'Don't wait until you want revenge' - why prenups are on the rise
      Around one in three young couples are now signing prenups to set out who gets what in the event of divorce.

### Russian Internal News (state + in-exile) — 587 new of 1022 total
  - (2026-07-28) На границе Литвы нашли подземный туннель из Беларуси. Его могли построить для переправки нелегальных мигрантов в страну | LEDE: Литовские пограничники обнаружили на юго-востоке страны подзем] (ru: На…
      Литовские пограничники обнаружили на юго-востоке страны подземный туннель из Беларуси. Об этом сообщает LRT со ссылкой на Службу охраны государственной границы Литвы.
  - (2026-07-28) Медведев опроверг слухи о грядущей мобилизации в России, назвав их «пургой» и «лживой провокацией» | LEDE: Заместитель председателя Совбеза РФ Дмитрий Медведев заявил, что слухи о возможной ] (ru: Мед…
      Заместитель председателя Совбеза РФ Дмитрий Медведев заявил, что слухи о возможной мобилизации в России ближайшей осенью не соответствуют действительности. Публикации на эту тему, которые распространяются в СМИ и соцсетя…
  - (2026-07-28) Капитализация Apple превысила пять триллионов долларов. Это вторая компания в истории (после Nvidia) с такой рыночной стоимостью | LEDE: Акции Apple во вторник, 28 июля, подорожали на 1,8%, ] (ru: Кап…
      Акции Apple во вторник, 28 июля, подорожали на 1,8%, почти до 343 долларов за ценную бумагу. Благодаря этому капитализация компании превысила пять триллионов долларов, пишет Bloomberg.
  - (2026-07-28) В России из-за топливного кризиса вырос спрос на электромобили и гибриды | LEDE: В России вырос спрос на электромобили и гибридные автомобили. На некоторые модели образовался дефицит, пишет ] (ru: В Р…
      В России вырос спрос на электромобили и гибридные автомобили. На некоторые модели образовался дефицит, пишет «Коммерсант» со ссылкой на дилеров и дистрибуторов.
  - (2026-07-28) «Важно активизировать дипломатический процесс». Зеленский — об итогах встречи с Трампом | LEDE: Президенты США и Украины Дональд Трамп и Владимир Зеленский провели встречу в Белом доме. ] (ru: «Важно…
      Президенты США и Украины Дональд Трамп и Владимир Зеленский провели встречу в Белом доме.
  - (2026-07-28) Сенаторы США согласовали поддержку законопроекта о 100%-ных пошлинах для покупателей российской нефти | LEDE: Сенаторы от Республиканской и Демократической партии достигли межпартийного согл] (ru: Сен…
      Сенаторы от Республиканской и Демократической партии достигли межпартийного соглашения по законопроекту о новых санкциях против России, соавтором которого выступал покойный Линдси Грэм, пишет Bloomberg.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 291 new of 767 total
  - (2026-07-29) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-28) [Liveuamap] Drones raid in Koledino of Moscow region - Liveuamap
      Drones raid in Koledino of Moscow region Liveuamap
  - (2026-07-29) [Liveuamap] News Live - iraq.liveuamap.com
      News Live iraq.liveuamap.com
  - (2026-07-24) [Liveuamap] A point outside the city of Khandab was targeted by an projectile. The political, security and social assistant to the central governor said: "A point outside the city of Khandab was targe…
      A point outside the city of Khandab was targeted by an projectile. The political, security and social assistant to the
  - (2026-07-25) [Liveuamap] Several airstrikes target Yemen's Hodeidah port. Al-Mayadeen reports the strikes were carried out by Saudi forces - Liveuamap
      Several airstrikes target Yemen's Hodeidah port. Al-Mayadeen reports the strikes were carried out by Saudi forces &nbs
  - (2026-07-29) [Liveuamap] An explosion carried out by the Israeli army in the town of Hadatha - Liveuamap
      An explosion carried out by the Israeli army in the town of Hadatha Liveuamap</

### State-Level News — 290 new of 710 total
  - (2026-07-28) [Alabama] Governor Ivey Highlights Alabama Success at Farnborough International Airshow
      MONTGOMERY – Governor Kay Ivey on Tuesday announced that Alabama’s strong showing in the Farnborough International Airshow last week resulted in two major industry announcements and more than 50 meetings between the Alab…
  - (2026-07-28) [California] A judge sent a doctor to evaluate California’s largest ICE detention center. What he found
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/012026-California-City-Immigration-Processing-Center-AP-CM-04.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size siz…
  - (2026-07-28) [California] Antes enseñaban sobre un héroe. Ahora profesores reconsideran las lecciones sobre César Chávez tras acusaciones
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/031926_Cesar-Chavez-LA_TS_CM_18.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-07-28) [California] Brasil permite a los padres controlar el uso de las redes sociales por parte de sus hijos. ¿Por qué California no?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/08/083024_Santa-Monica-Construction_-ZS-32_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp…
  - (2026-07-28) [California] What Brazil can teach CA when it comes to kids and tech
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/083024-Cellphone-Ban-DD-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-29) [Connecticut] What if there were no trash to pick up?
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/IMG_0683-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high"…

### State Legislative Action — 258 new of 258 total
  - (2026-07-29) [Alaska SB 86] An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing sy…
      An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing system; relating to the use of virtua…
  - (2026-07-29) [Alaska SB 64] An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating t…
      An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating to write-in candidates for President…
  - (2026-07-28) [Alaska SB 140] An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
      An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
  - (2026-07-28) [Alaska HB 283] An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and provid…
      An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and providing for an effective date.
  - (2026-07-28) [Alaska HB 133] An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements t…
      An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements to nonprofit organizations, municipal…
  - (2026-07-28) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.

### Chinese Internal News — 205 new of 288 total
  - (2026-07-28) Covid-19 Infections Surge Across China as Virus Reclaims Dominance - Caixin Global
      Covid-19 Infections Surge Across China as Virus Reclaims Dominance Caixin Global
  - (2026-07-28) 责编：任成琦 金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxQeEdjNTB2Q3dTWjRDYlV1R2ZBMUprbV9Fc3BuNElPZzVxQUFmTnR5Vkw3X2xidmVBaGFCMnBpN0dxeUFfY3BrR] (zh:…
      责编：任成琦 金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-07-27) 北京中轴线各遗产点庆祝申遗成功两周年【20】 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE1TVWl0OXJNU1VUR01uWEZSUHo1NnN0Q0lfelhleG0wWlpCdDZzZ0VnLVltazRyai1yVWhLVWlzWmotTV9jMC1oeVhQY] (zh:…
      北京中轴线各遗产点庆祝申遗成功两周年【20】 人民网-图片频道
  - (2026-07-28) 唐山大地震50周年：纪念墙下致哀思 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE03cUd2M2FJdVBMT0JsSjR0azV4Uy1iT1NZcXYyTDBGWnBjVThLMEF3ZDJOR2lVWWs5SmFnOS1CYXBFY0VwSmU2c19QVmdHMX] (zh:…
      唐山大地震50周年：纪念墙下致哀思 人民网-图片频道
  - (2026-07-29) 健全完善新时代高校“大美育”格局 - 人民网教育 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE5YYnQyd1E2RHhBUUJ5bjU2R2tlMm1NUVhtNE53a3ZlRkpZUE9PZXl2M0J4REVNRWRfVGQtSGIzSTNWLThoX192VFpBRkZRQ3Y3OD] (zh:…
      健全完善新时代高校“大美育”格局 人民网教育
  - (2026-07-29) 行进中国｜激活中试动能 “细胞工厂”赋能天津合成生物产业跃升 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBiZWZSQXRHeGE3eVlWUFcwaE9ZdFdsb2ZSU0hDc0ZjemRBbTE4Z3hTeG10ZmItbWRQSTJXU09aOEV0N2ZrRUJJNG] (zh:…
      行进中国｜激活中试动能 “细胞工厂”赋能天津合成生物产业跃升 人民网

### Local News: St. Louis + Atlanta — 182 new of 225 total
  - (2026-07-28) [St. Louis] KSDK’s Art Holliday celebrates Chuck Berry’s pianist Johnnie Johnson in upcoming documentary ‘Johnnie Be Good’
      Despite being a Rock & Roll Hall of Fame inductee, most people do not know his name. Despite being the man who hired an unknown guitarist named Chuck Berry to be in his band for a performance on New Year’s Eve 1952, most…
  - (2026-07-28) [St. Louis] Free 4 All STL announces 2026 dates, opens for artist submissions
      The inaugural Free 4 All music showcase took over the streets of Grand Center in September 2025, bringing 100 St. Louis-based acts of every conceivable genre to nine stages throughout the district, with droves of local m…
  - (2026-07-28) [St. Louis] G’Ra Asim tackles love, identity, and culture in new book ‘99 Problems Finding the 1’
      Jay-Z said he had 99 problems, but a (rather choice word for a) woman wasn’t one. St. Louis–born Washington University professor and musician G’Ra Asim has 99 problems as well—but his problems revolve around exactly what…
  - (2026-07-28) [St. Louis] New St. Louis experience lets kids excavate a life-size dinosaur skeleton
      Wearing field vests and armed with excavation tools, a group of young paleontologists carefully brushes away sand until the first fossil appears. One by one, they uncover buried bones, match each discovery to a field map…
  - (2026-07-28) [St. Louis] Top things to do in St. Louis this weekend: July 31–August 2
      Ain’t Too Proud | July 27–August 2 The Broadway hit follows The Temptations from Detroit to the pinnacle of the charts. See website for times and prices. The Muny, 1 Theatre Dr., Forest Park. St. Charles County Fair | Ju…
  - (2026-07-28) [St. Louis] Found and Formed arts pop-ups let parents and kids create side by side
      Parallel play isn’t just a milestone for toddlers. Found and Formed creates a space where parents can flex their creative muscles right alongside their kiddos, each working on age-appropriate crafts while fueled by coffe…

### U.S. Weather + Severe / Climate Outlooks — 145 new of 158 total
  - (2026-07-29) [Moderate] Heat Advisory: Heat Advisory issued July 29 at 12:31AM EDT until July 29 at 8:00PM EDT by NWS Tallahassee FL
      * WHAT...Heat index values up to 112 expected. * WHERE...Portions of southeast Alabama, Panhandle Florida, and south central and southwest Georgia. * WHEN...From 11 AM EDT /10 AM CDT/ this morning to 8 PM EDT /7 PM CDT/…
  - (2026-07-29) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 29 at 12:31AM EDT until July 29 at 8:00PM EDT by NWS Tallahassee FL
      * WHAT...Dangerously hot conditions with heat index values up to 116 expected. * WHERE...Portions of Big Bend and Panhandle Florida and south central and southwest Georgia. * WHEN...From 11 AM EDT /10 AM CDT/ this mornin…
  - (2026-07-28) [Severe] Flash Flood Warning: Flash Flood Warning issued July 28 at 9:30PM MST until July 29 at 12:30AM MST by NWS Flagstaff AZ
      FFWFGZ The National Weather Service in Flagstaff has issued a * Flash Flood Warning for... Chinle Creek in Apache County in northeastern Arizona... * Until 130 AM MDT. * At 1030 PM MDT, a river gauge on the Chinle Creek…
  - (2026-07-28) [Severe] Flash Flood Warning: Flash Flood Warning issued July 28 at 10:27PM MDT until July 29 at 1:30AM MDT by NWS Grand Junction CO
      FFWGJT The National Weather Service in Grand Junction has issued a * Flash Flood Warning for... Southeastern Grand County in east central Utah... * Until 130 AM MDT. * At 1027 PM MDT, Doppler radar indicated thunderstorm…
  - (2026-07-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-29) [Severe] Flood Watch: Flood Watch issued July 29 at 12:26AM EDT until July 29 at 8:00PM EDT by NWS Mount Holly NJ
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of northern New Jersey, including the following counties, Middlesex, Morris and Somerset. * WHEN...Through this evening.…

### Ukrainian Internal News (national + local Kyiv) — 40 new of 108 total
  - (2026-07-29) Ворог обстріляв 24 населені пункти Сумщини: поранено жінку | LEDE: Протягом минулої доби російські окупаційні війська обстріляли 24 населені пункти Сумської області, поранено жінку, пошкоджено ] (uk:…
      Протягом минулої доби російські окупаційні війська обстріляли 24 населені пункти Сумської області, поранено жінку, пошкоджено інфраструктуру.
  - (2026-07-29) Сили оборони України знешкодили ще 1310 російських окупантів – Генштаб | LEDE: За добу Сили оборони ліквідували 1 310 росіян, загальні втрати РФ у війні перевищили 1 443 450 осіб.] (uk: Сили оборони У…
      За добу Сили оборони ліквідували 1 310 росіян, загальні втрати РФ у війні перевищили 1 443 450 осіб.
  - (2026-07-29) США та Саудівська Аравія завдали ударів по об'єктах в Іраку | LEDE: Винищувачі США та Саудівської Аравії атакували об'єкти, підтримувані Іраном, у відповідь на атаки безпілотників.] (uk: США та Саудів…
      Винищувачі США та Саудівської Аравії атакували об'єкти, підтримувані Іраном, у відповідь на атаки безпілотників.
  - (2026-07-29) Трамп заявив, що зустріч із Зеленським пройшла дуже добре | LEDE: Трамп повідомив про успішну зустріч із Зеленським у Білому домі.] (uk: Трамп заявив, що зустріч із Зеленським пройшла дуже добре)
      Трамп повідомив про успішну зустріч із Зеленським у Білому домі.
  - (2026-07-29) СЕО для президента. Як Корецький очолив уряд і чого йому слід боятись | LEDE: Ввечері 12 липня з кабінету президента швидкою ходою вийшла емоційно розбита прем'єр-міністерка Юлія Свириденко.] (uk: СЕО…
      Ввечері 12 липня з кабінету президента швидкою ходою вийшла емоційно розбита прем'єр-міністерка Юлія Свириденко.
  - (2026-07-29) Санкції проти Росії є сигналом для Європи – Зеленський | LEDE: Зеленський подякував сенаторам США за санкції Грема, які обмежують РФ та підтримують Україну] (uk: Санкції проти Росії є сигналом для Євр…
      Зеленський подякував сенаторам США за санкції Грема, які обмежують РФ та підтримують Україну

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-29) [Vincent Ron] Form 4 (Reporting)
      filed 2026-07-29 01:48 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000075 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:48 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000075 Size: 19 KB
  - (2026-07-29) [KORN JEFFREY G] Form 4 (Reporting)
      filed 2026-07-29 01:48 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000074 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:48 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000074 Size: 19 KB
  - (2026-07-29) [Gaylor Douglas Walter] Form 4 (Reporting)
      filed 2026-07-29 01:46 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000071 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:46 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000071 Size: 19 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-29) [United States] Parolee Suspected of Fatally Striking Motorist While Fleeing Police Arrested
      domain: mynewsla.com · language: English · tone:
  - (2026-07-29) [United States] Commentary : Data center issue can empower rural areas
      domain: shorelinemedia.net · language: English · tone:
  - (2026-07-29) [United States] Forgiving , and Freeing Ourselves
      domain: bobandsheri.com · language: English · tone:
  - (2026-07-29) [United States] Fatal Crash Response in Brookby by NZ Police
      domain: miragenews.com · language: English · tone:
  - (2026-07-29) [United States] CB & I CONTINUES GROWTH IN MIDDLE EAST WITH NEW ABU DHABI WELLS CONTRACT
      domain: prnewswire.com · language: English · tone:
  - (2026-07-29) [United States] Medal of Honor recipient Leroy Petry speaks to scouts at National Scout Jamboree
      domain: yahoo.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 55 total
  - (2026-07-29) [The Hacker News] Two Compromised joyfill npm Packages Run RAT When Imported Into Node.js
      Beta release versions of two npm packages in the @joyfill namespace have been compromised to deliver a remote access trojan (RAT) associated with the DEV#POPPER malware family. The list of affected packages is as follows…
  - (2026-07-29) [Schneier on Security] Measuring LLMs’ Ability to Perform Cryptanalysis
      There’s new benchmark measuring AI’s ability to perform mathematical cryptanalysis. Anthropic’s frontier model actually found new attacks. The benchmark: “CryptanalysisBench: Can LLMs do Cryptanalysis?” The idea is to be…
  - (2026-07-29) [The Register] America bans imported robots due to supply chain and security risks
      Docs point to China’s Unitree as prime example of the foreign clanker threat
  - (2026-07-29) [Ars Technica] Audi has a new flagship designed with the US in mind: The 2027 Q9
      The new full-size flagship SUV starts at $87,700 when it goes on sale in Q4.
  - (2026-07-29) [TechCrunch] Cyera agrees to acquire Oasis Security for $1B to safeguard proliferating AI agents
      The deal is Cyera's third acquisition this year.
  - (2026-07-28) [BleepingComputer] CubePilot drone software dev hit by DNS hijacking to intercept traffic
      CubePilot, an Australian firm that designs flight controllers for drones (UAVs), announced a severe operational disruption caused by a DNS hijacking attack. [...]

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 28 new of 60 total
  - (2026-07-28) U.S. Court of Appeals, 2nd Cir.: In Re: Laura Charlene Goebel
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: Anthony Knight v. Cambria Company, LLC
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: Matthew Goforth v. Transform Holdco, LLC
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: United States v. Benjamin Striplin
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: United States v. Lance Longie
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: United States v. Rasheem Bogan

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-29) [Taiwan Strait + South China Sea · themes] Lido delle Nazioni ormai ci siamo Il ritorno del carnevale di Pitoch
      zazoom.it · Italian · tone NA
  - (2026-07-29) [Taiwan Strait + South China Sea · themes] Thủ đô Hà Nội có mưa rào và dông , đề phòng lốc sét
      daidoanket.vn · Vietnamese · tone NA
  - (2026-07-29) [Taiwan Strait + South China Sea · themes] ( 影 ) 熊本7 . 1強震13死多人失蹤 ！ 永旺爆炸 、 古城石垣崩塌 、 道路斷裂 多地滿目瘡痍 | 國際
      newtalk.tw · Chinese · tone NA
  - (2026-07-29) [Taiwan Strait + South China Sea · themes] Warga Anambas Siaga Malam , Takut Tongkang Lepas saat Tugboat Tenggelam Hantam Rumah di Pesisir
      batam.tribunnews.com · Indonesian · tone NA
  - (2026-07-29) [Taiwan Strait + South China Sea · themes] Japón reporta 13 muertos tras terremoto magnitud 7 . 1 ; sigue búsqueda en centro comercial colapsado
      eleconomista.com.mx · Spanish · tone NA
  - (2026-07-29) [Taiwan Strait + South China Sea · themes] At least 13 dead in Japan earthquake after shopping centre collapses
      nzherald.co.nz · English · tone NA

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-07-29) JAF62J (Belgium)
      icao24: 44d1ba · position: (50.289, 5.4986) · alt: 6614m · 747km/h
  - (2026-07-29) JAF88H (Belgium)
      icao24: 44d1a6 · position: (49.2819, 2.2891) · alt: 10058m · 750km/h
  - (2026-07-29) JAF1DY (Belgium)
      icao24: 44d1a5 · position: (50.8983, 4.4872) · on ground
  - (2026-07-29) JAF2JW (Belgium)
      icao24: 44d1b3 · position: (48.7977, 2.5099) · alt: 11277m · 794km/h
  - (2026-07-29) JAF2PK (Belgium)
      icao24: 44d1b4 · position: (50.7981, 4.167) · alt: 2049m · 505km/h
  - (2026-07-29) JAF8AL (Belgium)
      icao24: 44d1c2 · position: (50.8011, 4.5204) · alt: 1897m · 528km/h

### USGS earthquakes (M4.5+, past day) — 18 new of 29 total
  - (2026-07-29) M 5.4 - 153 km NE of Neiafu, Tonga
      M5.4 · 153 km NE of Neiafu, Tonga · depth 10 km
  - (2026-07-28) M 5.4 - 211 km SE of Kokopo, Papua New Guinea
      M5.4 · 211 km SE of Kokopo, Papua New Guinea · depth 10 km
  - (2026-07-28) M 5.2 - 151 km WSW of Puerto Santa, Peru
      M5.2 · 151 km WSW of Puerto Santa, Peru · depth 9.709 km
  - (2026-07-29) M 5.1 - Kermadec Islands region
      M5.1 · Kermadec Islands region · depth 35 km
  - (2026-07-28) M 5.1 - south of the Fiji Islands
      M5.1 · south of the Fiji Islands · depth 575.128 km
  - (2026-07-29) M 5.0 - south of Tonga
      M5.0 · south of Tonga · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 159 total
  - (2026-07-29) [DSCA Arms Sale] DSCA Director Signs FMF Guaranteed Loan - dsca.mil
      DSCA Director Signs FMF Guaranteed Loan dsca.mil
  - (2026-07-29) [USASpending] $2,833,494,612 → FISHER SAND & GRAVEL CO: CONSTRUCT VERTICAL BORDER BARRIER
      Agency: Department of Homeland Security. Description: CONSTRUCT VERTICAL BORDER BARRIER
  - (2026-07-29) [USASpending] $2,032,829,135 → LOCKHEED MARTIN CORP: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONAR
      Agency: National Aeronautics and Space Administration. Description: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) SERIES TO CONTINUE ITS MISSION THROUGH NEW REQ…
  - (2026-07-29) [USASpending] $1,598,641,181 → BATTELLE SAVANNAH RIVER ALLIANCE, LLC: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING
      Agency: Department of Energy. Description: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING (M&O) CONTRACT
  - (2026-07-29) [USASpending] $1,058,337,519 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-07-29) [USASpending] $1,029,024,846 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### Paper Trading Scorecard — 15 new of 141 total
  - (2026-07-29) [Polymarket] Will Gold (XAUUSD) hit (HIGH) $4,400 in July?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of July 2026, any 1-minute candle for Gold (XAUUSD) has a final "High" or "Low" price equal to or beyond (above for ↑…
  - (2026-07-29) [Polymarket] Will the Dallas Cowboys win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-29) [Polymarket] Romanian parliament dissolved by July 31?
      This market will resolve to "Yes" if the sitting Romanian Chamber of Deputies and Senate are dissolved by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No". The primary resolution source for th…
  - (2026-07-29) [Polymarket] Will Arc launch a token by December 31 2026?
      This market will resolve to “Yes” if Arc (https://x.com/arc) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token must be active…
  - (2026-07-29) [Manifold] Will Spiderman: Brand New Day beat Spiderman: No Way Home's opening weekend?
  - (2026-07-29) [Manifold] By 2041, will having $10M+ in personal financial wealth provide little or no material lifestyle advantage over 0 wealth?

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-07-29) Seattle Mariners vs. Los Angeles Dodgers
      yes price: 90% · 24h volume: $918,132 · resolves 2026-08-05
  - (2026-07-29) US x Iran Effective Ceasefire by July 24?
      yes price: 35% · 24h volume: $698,513 · resolves 2026-07-24
  - (2026-07-29) Colorado Rockies vs. San Diego Padres
      yes price: 50% · 24h volume: $561,660 · resolves 2026-08-05
  - (2026-07-29) Strait of Hormuz traffic returns to normal by August 31?
      yes price: 10% · 24h volume: $365,343 · resolves 2026-08-31
  - (2026-07-29) Spread: Los Angeles Dodgers (-1.5)
      yes price: 2% · 24h volume: $339,305 · resolves 2026-07-29
  - (2026-07-29) US x Iran Effective Ceasefire by July 31?
      yes price: 44% · 24h volume: $296,777 · resolves 2026-07-31

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-07-29) MOVER ▲ Elon Musk — $729.77B (+$14.18B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-07-29) MOVER ▼ Michael Dell — $223.78B ($-10.67B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-07-29) MOVER ▲ Larry Page — $273.94B (+$5.15B since yesterday)
      United States · Technology · source: Google
  - (2026-07-29) MOVER ▲ Sergey Brin — $252.73B (+$4.74B since yesterday)
      United States · Technology · source: Google
  - (2026-07-29) MOVER ▲ Warren Buffett — $145.35B (+$4.17B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway
  - (2026-07-29) MOVER ▼ Thomas Peterffy — $104.39B ($-1.48B since yesterday)
      United States · Finance & Investments · source: Discount brokerage

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-28) [Marginal Revolution] Congratulations to Ross D. and others
      Ross Douthat, an opinion columnist at The New York Times, is leaving to join the CBS News program “60 Minutes” as a correspondent, the show’s executive producer said in a memo to staff on Tuesday. Mr. Douthat is among a…
  - (2026-07-28) [Marginal Revolution] Tuesday assorted links
      1. The economics of personal holding companies, including in the Nordics. 2. Jongkuch Mach is a good name for a very tall basketball player. 3. Can AI predict who will be the most important philosopher in 2046? For econo…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=18, 14d-median=18; carrying terms: adding, special, final, safety, revising, airspace, pacific, coast, directives, council, published, standard
- state_bills: today=258, 7d-median=117, 14d-median=117; carrying terms: authorizes, amend, title, transparency, commissioner, manner, fiscal, another, county, compliance, person, known
- state_news: today=710, 7d-median=602, 14d-median=602; carrying terms: continue, systems, foreign, agreement, families, announces, arguments, contest, legislation, offering, number, valid
- local_news: today=225, 7d-median=228, 14d-median=228; carrying terms: advisory, stlmag, times, reports, offering, democrats, early, county, another, https, cbmipwfbvv, google
- foreign_news: today=1007, 7d-median=1007, 14d-median=1007; carrying terms: french, systems, foreign, tokyo, legislation, infrastructure, number, suggested, expert, legislate, title, risks
- chinese_internal: today=288, 7d-median=282, 14d-median=282; carrying terms: cbmix, title, google, cbmickfvx, lxtfa, cbmiykfvx, caixin, cbmixkfvx, cbmibefvx, people, cbmizefvx, cbmiaefvx
- russian_internal: today=1022, 7d-median=894, 14d-median=894; carrying terms: times, client, raquo, centcom, title, httperror, novayagazeta, https, telegram, bloomberg, forbidden, russian
- ukrainian_internal: today=108, 7d-median=134, 14d-median=134; carrying terms: minister, continue, systems, foreign, reports, infrastructure, reported, economic, dismissed, title, risks, important
- ukraine_theater: today=767, 7d-median=616, 14d-median=616; carrying terms: cuxovjd, interactive, nkqlzzmmltvlfpqv, gmzlaaddimm, systems, french, foreign, agreement, bznjbgfsowdjvmgxz, rjzcejzmmflls, wklwy, ngogjnay
- paper_bets: today=141, 7d-median=140, 14d-median=140; carrying terms: launch, minister, reserves, colorado, special, prime, debut, approve, lesswrong, alphabetically, december, title
- weather: today=158, 7d-median=173, 14d-median=173; carrying terms: ongoing, advisory, please, northern, continue, likely, sandy, lower, doppler, excess, forecast, saturday
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: jolts, sheet, cpiaucsl, dexjpus, personal, growth, openings, jtsjol, dexuseu, dcoilwtico, latest, funds
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, russell, corporate, crypto, range, yield, proxy, agriculture, futures, natural, rates, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=159, 7d-median=119, 14d-median=119; carrying terms: sheet, representative, xskfisuh, zunvhbvnhyks, foreign, cbmihgjbvv, transportation, legislation, analysis, dxlzz, democratic, recognition
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, https, httperror, error, quiver, quiverquant, congresstrading, quantitative, unauthorized
- billionaires: today=40, 7d-median=34, 14d-median=34; carrying terms: facebook, euronext, tadashi, larry, jensen, ambani, madrid, mexico, technologies, buffett, brokerage, changpeng
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: trade, supreme, robert, ahmed, district, services, delaware, appeals, court, school, holdings, blanche
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, therapeutics
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cooper, colorado, warner, david, michael, elect, congress, ossoff, disbursements, booker, shawn, senate
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=25, 7d-median=47, 14d-median=47; carrying terms: english, hormuz, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: language, india, domain, found, killing, australia, english, crash, police
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=18, 14d-median=18; carrying terms: position, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: ongoing, cereulide, medical, globally, brands, woman, senegal, ituri, rabies, dignified, clade, reaching
- cisa_kev: today=13, 7d-median=16, 14d-median=16; carrying terms: oracle, sharepoint, langflow, lockout, microsoft, product, fortisandbox, connection, account, deserialization, command, suite
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=283, 7d-median=270, 14d-median=270; carrying terms: indonesia, germany, vietnam, australia, brazil, mexico, thailand, nicaragua, papua, green, albania, bulgaria
- usgs_quakes: today=29, 7d-median=24, 14d-median=24; carrying terms: islands, south, depth, region, indonesia, philippines, guinea, mexico, papua, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, meeting, volume, rates, prime, ethiopia, interest, price, resolves, adanech, decrease, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, revolution, economist, class, benefit, marginalrevolution, https, marginal, assorted, looking, links, quality
- tech_news: today=55, 7d-median=57, 14d-median=57; carrying terms: systems, computer, infrastructure, haven, scope, https, company, agencies, schneier, bleepingcomputer, known, cybersecurity
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: mcbride, counsel, representative, mejia, corporation, gregory, blunt, maxine, balart, scalise, adrian, brendan
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, placement, evidence, converges, today, decision, placed, either, sufficient, paper, identify, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*