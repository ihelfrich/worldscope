# WORLDSCOPE morning brief — 2026-07-29

## Headline
3914 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (827) · Russian Internal News (state + in-exile) (721) · State-Level News (635) · Ukraine Theater (total-war monitoring) (395) · World leaders & government officials (324) · State Legislative Action (229) · Local News: St. Louis + Atlanta (175) · U.S. Weather + Severe / Climate Outlooks (171) · Ukrainian Internal News (national + local Kyiv) (78) · IT, InfoSys & cybersecurity news (last 7 days) (50) · Court opinions of consequence (federal & state) (43) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 827 new of 1047 total
  - (2026-07-30) [India] Bihar cabinet gives nod to fill up 22,981 posts of Anganwadi workers
      Nod for creation of 19 posts of District & Additional Sessions Judge for Exclusive Special Courts; Three posts of DASJ created for Additional Special Courts
  - (2026-07-30) [India] OMR residents want foot overbridges to be repaired
  - (2026-07-30) [India] Kerala Tourism to push for driver facilities in star-rating norms for hotels and resorts
  - (2026-07-30) [India] Workshop to draft action plans for welfare of SHGs begins in Kochi
  - (2026-07-30) [India] CJP protest | Fresh reports of detentions, takedown of social media posts emerge
  - (2026-07-30) [India] Bangladeshi national arrested in Kozhikode over illegal stay

### Russian Internal News (state + in-exile) — 721 new of 916 total
  - (2026-07-30) Украина обратилась в Спортивный арбитражный суд из-за того, что МОК снял ограничения с Олимпийского комитета России | LEDE: Национальный олимпийский комитет Украины сообщил о подаче заявлени] (ru: Укр…
      Национальный олимпийский комитет Украины сообщил о подаче заявления в Спортивный арбитражный суд в Лозанне. Украинская сторона намерена обжаловать решение Международного олимпийского комитета (МОК), восстановившего деяте…
  - (2026-07-29) Митрополита Илариона, задержанного из-за наркотиков в Чехии, передумали отправлять в Южную Америку. Он останется служить в России | LEDE: Глава Русской православной церкви патриарх Кирилл вр] (ru: Мит…
      Глава Русской православной церкви патриарх Кирилл временно приостановил действие своего указа о переводе митрополита Илариона (Алфеева) в Бразилию. Об этом сообщается на сайте Московского патриархата.
  - (2026-07-29) Науэро (бывшая Науру) разорвала дипломатические отношения с Абхазией и Южной Осетией. Теперь их независимость признают лишь четыре страны в мире | LEDE: Тихоокеанское государство Науэро (ран] (ru: Нау…
      Тихоокеанское государство Науэро (ранее Науру) разорвало дипломатические отношения с частично признанными Абхазией и Южной Осетией. Такое решение 21 июля принял кабинет министров Науэро, сообщил МИД Грузии.
  - (2026-07-29) Группа BTS отказалась участвовать в «Грэмми» — после того, как организаторы премии ввели категорию азиатской поп-музыки | LEDE: Кей-поп-группа BTS не будет выдвигать cвой новый альбом «Arira] (ru: Гру…
      Кей-поп-группа BTS не будет выдвигать cвой новый альбом «Arirang» на музыкальную премию «Грэмми» 2027 года. Об этом все семь участников BTS рассказали в инстаграме, передает издание Pitchfork.
  - (2026-07-29) Я продаю товары на маркетплейсе. Как мне добиться компенсаций в случае атаки беспилотников? Инструкция «Медузы» для сотен тысяч человек, чей бизнес связан с Wildberries | LEDE: 18 июля ВСУ н] (ru: Я п…
      18 июля ВСУ начали наносить удары по логистическим складам Wildberries. К 29 июля атакованы одиннадцать складов маркетплейса. Многие товары сгорели, и селлеры понесли убытки — некоторые из них потеряли миллионы рублей. М…
  - (2026-07-29) Депутат Свинцов призвал россиян отказаться от платной подписки на телеграм. У него самого нашли такую подписку. Он сказал, что не покупал ее | LEDE: Зампред комитета Госдумы по информационно] (ru: Деп…
      Зампред комитета Госдумы по информационной политике Андрей Свинцов заявил RTVI, что уголовное дело о терроризме против основателя Telegram Павла Дурова не запрещает россиянам пользоваться мессенджером, но от платных подп…

### State-Level News — 635 new of 1014 total
  - (2026-07-29) [California] New court documents expose Trump administration’s political targeting of Governor Newsom
      <a href="https://www.gov.ca.gov/2026/07/29/new-court-documents-exp
  - (2026-07-29) [California] California accelerates and modernizes state hiring process, saving thousands of hours of staff time
      <a href="https://www.gov.ca.gov/2026/07/29/california-accelerates-an
  - (2026-07-28) [California] Vehicle theft in California dropped nearly 25% in 2025
      Source
  - (2026-07-28) [California] Governor Newsom expands statewide partnerships with additional cities to clean up encampments on highways
      <a href="https://www.gov.ca.gov/2026/07/28/g
  - (2026-07-29) [Alabama] Governor Ivey Proclaims Will Roberts Day in Honor of His Bravery and Inspiration to be Strong, Keep Hope and Have Faith
      MONTGOMERY – Governor Kay Ivey on Wednesday issued a proclamation in honor of William “Will” Roberts, son of ALEA SBI Captain Jason Roberts and his wife Brittney. At just 15 years old, Will passed away on Thursday, July…
  - (2026-07-29) [Alabama] Will Roberts Day
      Download

### Ukraine Theater (total-war monitoring) — 395 new of 463 total
  - (2026-07-29) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-28) [FIRMS] thermal anomaly 45.258, 31.677 (FRP 7.3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-28 1038Z, FRP 7.3 MW
  - (2026-07-28) [FIRMS] thermal anomaly 45.356, 30.902 (FRP 2.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-28 1038Z, FRP 2.64 MW
  - (2026-07-28) [FIRMS] thermal anomaly 44.974, 27.802 (FRP 4.99 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-28 1038Z, FRP 4.99 MW
  - (2026-07-28) [FIRMS] thermal anomaly 45.254, 28.751 (FRP 6.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-28 1038Z, FRP 6.19 MW
  - (2026-07-28) [FIRMS] thermal anomaly 45.252, 28.751 (FRP 6.34 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-28 1038Z, FRP 6.34 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State Legislative Action — 229 new of 229 total
  - (2026-07-29) [Alaska SB 23] An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
      An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
  - (2026-07-29) [Alaska SB 86] An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing sy…
      An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing system; relating to the use of virtua…
  - (2026-07-29) [Alaska SB 64] An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating t…
      An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating to write-in candidates for President…
  - (2026-07-28) [Alaska SB 140] An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
      An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
  - (2026-07-28) [Alaska HB 283] An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and provid…
      An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and providing for an effective date.
  - (2026-07-28) [Alaska HB 133] An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements t…
      An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements to nonprofit organizations, municipal…

### Local News: St. Louis + Atlanta — 175 new of 182 total
  - (2026-07-29) [St. Louis] Amendment 5 would reshape Missouri’s economy, but the benefit to workers isn’t clear
      If you’re a St. Louisan out there hustling—trying to get a better job, higher pay, a nicer home, or bigger savings—then you may glance at Amendment 5, the ballot measure to phase out Missouri’s state income tax, and wond…
  - (2026-07-29) [St. Louis] Where to find menopause care in St. Louis, according to local experts
      Some women seem to breeze through menopause. Then there’s the rest of us. Hot flashes, night sweats, mood swings, joint pain, dry skin…it’s a perfect storm of discomfort. That’s why it’s so important to find a trusted he…
  - (2026-07-29) [St. Louis] Where in the Lou? – 7/30/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-07-29) [St. Louis] August garden tips for St. Louisans
      1. Consistent watering equals beautiful fall colors Even though August is a segue into the fall season, we’re still experiencing the unforgiving heat of July. “Watch out for anything that has been planted within the last…
  - (2026-07-29) [St. Louis] The St. Louis team that helped change women’s professional basketball
      Vince Gennaro touched down at O’Hare International Airport after returning from a trip to St. Louis. He boarded a shuttle to his apartment in Chicago’s Streeterville neighborhood and found a window seat. A few moments la…
  - (2026-07-29) [St. Louis] A house in Clayton hits the market
      Contemporary Town HouseClad in light-colored brick, this town home was built in 1995 and features three levels of finished living. Luxurious LivingEnter the open-floor plan through an arched window doorframe and into the…

### U.S. Weather + Severe / Climate Outlooks — 171 new of 173 total
  - (2026-07-29) [Moderate] Special Weather Statement: Special Weather Statement issued July 29 at 6:34PM CDT by NWS Tulsa OK
      At 633 PM CDT, Doppler radar indicated a strong thunderstorm near Lake Wister State Park, moving east at 5 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down small tree…
  - (2026-07-29) [Moderate] Special Weather Statement: Special Weather Statement issued July 29 at 5:34PM MDT by NWS Grand Junction CO
      At 534 PM MDT, Doppler radar was tracking a strong thunderstorm 27 miles northwest of Parachute, or 46 miles north of Grand Junction, moving northeast at 20 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURC…
  - (2026-07-29) [Moderate] Special Weather Statement: Special Weather Statement issued July 29 at 7:33PM EDT by NWS Jacksonville FL
      At 732 PM EDT, Doppler radar was tracking a strong thunderstorm near Thalmann, or 9 miles west of Dock Junction, moving east at 20 mph. HAZARD...Wind gusts up to 50 mph and pea size hail. SOURCE...Radar indicated. IMPACT…
  - (2026-07-29) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 29 at 5:33PM MDT until July 29 at 6:15PM MDT by NWS Pueblo CO
      SVRPUB The National Weather Service in Pueblo has issued a * Severe Thunderstorm Warning for... South central Fremont County in central Colorado... North central Custer County in southeastern Colorado... * Until 615 PM M…
  - (2026-07-29) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 29 at 4:33PM MST until July 29 at 5:00PM MST by NWS Flagstaff AZ
      SVRFGZ The National Weather Service in Flagstaff has issued a * Severe Thunderstorm Warning for... Coconino County in north central Arizona... * Until 500 PM MST /600 PM MDT/. * At 433 PM MST /533 PM MDT/, a severe thund…
  - (2026-07-29) [Moderate] Special Weather Statement: Special Weather Statement issued July 29 at 5:33PM MDT by NWS Pocatello ID
      At 532 PM MDT, Doppler radar was tracking a strong thunderstorm 7 miles northeast of Chesterfield Reservoir, moving northeast at 30 mph. HAZARD...Wind gusts in excess of 45 mph and nickel size hail. SOURCE...Radar indica…

### Ukrainian Internal News (national + local Kyiv) — 78 new of 136 total
  - (2026-07-30) Росіяни вдарили по Києву ракетами: є падіння уламків та загоряння | LEDE: Російська ракетна атака на Київ: уламки впали в Святошинському та Оболонському районах, виникли загоряння.] (uk: Росіяни вдари…
      Російська ракетна атака на Київ: уламки впали в Святошинському та Оболонському районах, виникли загоряння.
  - (2026-07-30) 100%: Федоров про те, чи готовий повернутись до Міністерства оборони | LEDE: Федоров заявив про готовність повернутися до Міноборони] (uk: 100%: Федоров про те, чи готовий повернутись до Міністерства…
      Федоров заявив про готовність повернутися до Міноборони
  - (2026-07-30) Трамп заявив, що хотів би, щоб Зеленський закінчив війну | LEDE: Трамп заявив, що бажає завершення війни в Україні та підтримує контакт із Зеленським і Путіним.] (uk: Трамп заявив, що хотів би, щоб Зе…
      Трамп заявив, що бажає завершення війни в Україні та підтримує контакт із Зеленським і Путіним.
  - (2026-07-29) Генштаб: Росіяни 191 раз атакували позиції Сил оборони від початку доби | LEDE: Від початку 29 липня на фронті відбулося 191 бойове зіткнення. Найбільше атак російські війська здійснили на Покр] (uk:…
      Від початку 29 липня на фронті відбулося 191 бойове зіткнення. Найбільше атак російські війська здійснили на Покровському, Костянтинівському та Слов'янському напрямках.
  - (2026-07-29) Федоров пов’язав своє звільнення з реформами в Міноборони: "Наступив на інтереси багатьох людей і компаній" | LEDE: Колишній міністр оборони Михайло Федоров вважає, що одним із чинників його зв] (uk:…
      Колишній міністр оборони Михайло Федоров вважає, що одним із чинників його звільнення став спротив реформам у Міністерстві оборони, зокрема змінам у сфері закупівель і тендерів, які зачепили інтереси багатьох людей та ко…
  - (2026-07-29) Федоров: Реформу мобілізації планували запустити в серпні, щоб у вересні розв’язати проблему | LEDE: Колишній міністр оборони Михайло Федоров заявив, що реформу мобілізації планували представит] (uk:…
      Колишній міністр оборони Михайло Федоров заявив, що реформу мобілізації планували представити у липні, запустити в серпні, а вже у вересні вона мала суттєво змінити ситуацію з комплектуванням війська.

### IT, InfoSys & cybersecurity news (last 7 days) — 50 new of 55 total
  - (2026-07-29) [BleepingComputer] Anthropic confirms Claude is down worldwide
      Claude is down for some users, with Anthropic confirming elevated errors across multiple AI models. The disruption is causing requests to fail with a "529 Overloaded" message, including in Claude and tools that rely on i…
  - (2026-07-29) [BleepingComputer] Cisco warns of FMC static credential flaw exploited in zero-day attacks
      Cisco is warning that a high-severity Secure Firewall Management Center (FMC) static credential vulnerability, tracked as CVE-2026-20316, was actively exploited in zero-day attacks to gain unauthorized access to vulnerab…
  - (2026-07-29) [BleepingComputer] Health-ISAC warns of rising ShinyHunters data theft attacks on healthcare
      Health-ISAC, a cybersecurity information-sharing organization for the health sector, is warning healthcare and medical technology organizations of an observed increase in successful attacks by ShinyHunters. [...]
  - (2026-07-29) [BleepingComputer] OpenAI agent used exposed credentials at 4 services in Hugging Face breach
      In a new update, OpenAI says its AI models also used publicly exposed credentials to compromise accounts on four third-party services during the recent attack on Hugging Face, expanding the scope of the four-day security…
  - (2026-07-29) [BleepingComputer] Hackers disrupt over 30 Minnesota water utilities in coordinated OT attack
      The Minnesota IT Services (MNIT) agency activated its cybersecurity incident response capabilities across the entire state after hackers targeted more than 30 community water systems in "a coordinated cyberattack." [...]
  - (2026-07-29) [The Hacker News] Critical Rails Flaw Could Let Unauthenticated Attackers Read Server Files via Image Uploads
      Ruby on Rails has released fixes for a critical Active Storage vulnerability that could let unauthenticated attackers read arbitrary files from application servers through crafted image uploads. Tracked as CVE-2026-66066…

### Court opinions of consequence (federal & state) — 43 new of 60 total
  - (2026-07-29) Arizona Supreme Court: GALLERY v. K HOVNANIAN
  - (2026-07-29) U.S. Court of Appeals, 6th Cir.: Bonfiglioli USA, Inc. v. Midwest Engineered Components, Inc.
  - (2026-07-29) U.S. Court of Appeals, 6th Cir.: United States v. Saruba Asante Smith
  - (2026-07-29) U.S. Court of Appeals, 3rd Cir.: Karen Cornish-Adebiyi v. Caesars Entertainment Inc
  - (2026-07-29) U.S. Court of International Trade: Ningxia Guanghua Cherishmet Activated Carbon Co. v. United States
  - (2026-07-29) U.S. Court of International Trade: Tube Forgings of Am., Inc. v. United States

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-29) [Cole Martin I] Form 4 (Reporting)
      filed 2026-07-29 23:32 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001266824-26-000164 Size: 7 KB
  - (2026-07-29) [WESTERN DIGITAL CORP] Form 4 (Issuer)
      filed 2026-07-29 23:32 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001266824-26-000164 Size: 7 KB
  - (2026-07-29) [Cole Martin I] Form 4 (Reporting)
      filed 2026-07-29 23:31 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001266824-26-000163 Size: 60 KB
  - (2026-07-29) [WESTERN DIGITAL CORP] Form 4 (Issuer)
      filed 2026-07-29 23:31 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001266824-26-000163 Size: 60 KB
  - (2026-07-29) [Tick Lyle] Form 4 (Reporting)
      filed 2026-07-29 23:28 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001193125-26-324397 Size: 6 KB
  - (2026-07-29) [BJs RESTAURANTS INC] Form 4 (Issuer)
      filed 2026-07-29 23:28 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001193125-26-324397 Size: 6 KB

### Paper Trading Scorecard — 36 new of 134 total
  - (2026-07-29) [Polymarket] Will the Dallas Cowboys win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-29) [Polymarket] Romanian parliament dissolved by July 31?
      This market will resolve to "Yes" if the sitting Romanian Chamber of Deputies and Senate are dissolved by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No". The primary resolution source for th…
  - (2026-07-29) [Polymarket] Will the price of Bitcoin be above $56,000 on July 30?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-07-29) [Polymarket] Will Vancouver Whitecaps FC win on 2026-07-16?
      In the upcoming game, scheduled for July 16, 2026 If Vancouver Whitecaps FC wins, this market will resolve to "Yes". Otherwise, this market will resolve to "No". If the game is postponed, this market will remain open unt…
  - (2026-07-29) [Polymarket] Will OpenAI's valuation hit (LOW) $750B by December 31?
      This market will resolve to "Yes" if OpenAI's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or exc…
  - (2026-07-29) [Kalshi] US headline CPI inflation in December 2036
      December 2036

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-29) [Israel-Iran-Hezbollah axis · keywords] UN , partners step up efforts to reduce health risks in Gaza - Xinhua
      english.news.cn · English · tone NA
  - (2026-07-29) [Israel-Iran-Hezbollah axis · keywords] Man convicted in terrorism trial over the 2022 stabbing of author Salman Rushdie
      ksat.com · English · tone NA
  - (2026-07-29) [Israel-Iran-Hezbollah axis · keywords] Watch : Hurt Feelings After John Fetterman Gives Two Pro - Hamas Outlets the Treatment They Deserve
      redstate.com · English · tone NA
  - (2026-07-29) [Israel-Iran-Hezbollah axis · keywords] Amanda Vanstone | Voters have tuned out and it a dangerous | The Advocate - Hepburn
      hepburnadvocate.com.au · English · tone NA
  - (2026-07-29) [Israel-Iran-Hezbollah axis · keywords] Iran pressure , Syria stance and Saudi nuclear deal : Inside Netanyahu White House pitch to Trump , reveals Axios report
      middleeaststar.com · English · tone NA
  - (2026-07-29) [Israel-Iran-Hezbollah axis · keywords] US - Iran conflict enters new phase as Saudi Arabia helps hit proxies
      pilotonline.com · English · tone NA

### Chinese Internal News — 24 new of 44 total
  - (2026-07-29) HKMA maintains base rate at 4% as US Fed keeps rate unchanged
  - (2026-07-29) Powering Hong Kong’s Future
  - (2026-07-29) ‘Explosive demand’ for cooling continues as Europe swelters, China’s Midea says
  - (2026-07-29) Hong Kong expands CMU’s global reach with Swiss, Spanish securities link
  - (2026-07-29) The CXMT shock: how China’s viable alternatives punch Nvidia, Micron, SK Hynix shares
  - (2026-07-29) Chinese MLCC firms’ profits and stock prices fatten on hunger for electronic ‘rice’

### USGS earthquakes (M4.5+, past day) — 23 new of 23 total
  - (2026-07-29) M 5.9 - Kermadec Islands region
      M5.9 · Kermadec Islands region · depth 10 km
  - (2026-07-29) M 5.6 - Pacific-Antarctic Ridge
      M5.6 · Pacific-Antarctic Ridge · depth 10 km
  - (2026-07-29) M 5.4 - 53 km E of Rapu-Rapu, Philippines
      M5.4 · 53 km E of Rapu-Rapu, Philippines · depth 46.281 km
  - (2026-07-29) M 5.4 - 11 km N of Tsunagi, Japan
      M5.4 · 11 km N of Tsunagi, Japan · depth 10 km
  - (2026-07-29) M 5.4 - 153 km NE of Neiafu, Tonga
      M5.4 · 153 km NE of Neiafu, Tonga · depth 10 km
  - (2026-07-29) M 5.2 - Kermadec Islands region
      M5.2 · Kermadec Islands region · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-07-29) Will Berhanu Nega be the next Prime Minister of Ethiopia?
      yes price: 1% · 24h volume: $8,448,203 · resolves 2026-06-01
  - (2026-07-29) Will Hassan Shariatmadari be head of state in Iran end of 2026?
      yes price: 0% · 24h volume: $1,364,340 · resolves 2026-12-31
  - (2026-07-29) US x Iran Effective Ceasefire by July 24?
      yes price: 0% · 24h volume: $1,187,792 · resolves 2026-07-24
  - (2026-07-29) Will Tulsi Gabbard win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,114,896 · resolves 2028-11-07
  - (2026-07-29) Will CR Flamengo win on 2026-07-29?
      yes price: 14% · 24h volume: $693,348 · resolves 2026-07-29
  - (2026-07-29) Fed rate hike in 2026?
      yes price: 62% · 24h volume: $510,260 · resolves 2026-12-09

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 87 total
  - (2026-07-29) [BIS Entity List] page checksum 50c8997bcf9e
      Page content hash: 50c8997bcf9e. Compare with prior day's hash to detect updates.
  - (2026-07-29) [USASpending] $2,833,494,612 → FISHER SAND & GRAVEL CO: CONSTRUCT VERTICAL BORDER BARRIER
      Agency: Department of Homeland Security. Description: CONSTRUCT VERTICAL BORDER BARRIER
  - (2026-07-29) [USASpending] $2,032,829,135 → LOCKHEED MARTIN CORP: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONAR
      Agency: National Aeronautics and Space Administration. Description: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) SERIES TO CONTINUE ITS MISSION THROUGH NEW REQ…
  - (2026-07-29) [USASpending] $1,598,641,181 → BATTELLE SAVANNAH RIVER ALLIANCE, LLC: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING
      Agency: Department of Energy. Description: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING (M&O) CONTRACT
  - (2026-07-29) [USASpending] $1,058,337,519 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-07-29) [USASpending] $1,029,024,846 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### Government & military aircraft airborne (OpenSky) — 15 new of 15 total
  - (2026-07-29) PAT319 (United States)
      icao24: adfe4b · position: (64.6616, -147.0892) · on ground
  - (2026-07-29) SAMU37 (France)
      icao24: 39ca87 · position: (47.3136, 0.9645) · alt: 541m · 242km/h
  - (2026-07-29) CFC4503 (Canada)
      icao24: c07703 · position: (49.9422, -125.254) · alt: 1844m · 205km/h
  - (2026-07-29) RCH433 (United States)
      icao24: ae07ab · position: (44.8192, -80.8143) · alt: 11582m · 873km/h
  - (2026-07-29) NCR903 (United States)
      icao24: acb84d · position: (17.0711, 94.1931) · alt: 11887m · 861km/h
  - (2026-07-29) EAGLE3 (United Kingdom)
      icao24: 43eed2 · position: (35.4856, 14.1327) · alt: 2301m · 322km/h

### U.S. Federal Action — 12 new of 19 total
  - (2026-07-29) Allocation of Assets in Single-Employer Plans; Interest Assumptions for Valuing Benefits
  - (2026-07-29) Continuation of the National Emergency With Respect to Brazil
  - (2026-07-29) Restoring Trust in the Smithsonian Institution
  - (2026-07-29) Amendment of Jet Routes J-190 and J-584 and Very High Frequency Omnidirectional Range Federal Airways V-170 and V-188 in the Vicinity of Slate Run, Pennsylvania
      This action corrects a notice of proposed rulemaking (NPRM) that the FAA published in the Federal Register on July 20, 2026, proposing to amend Jet Routes J-190 and J-584 and Very High Frequency Omnidirectional Range (VO…
  - (2026-07-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2025-16- 12, which applied to all Airbus SAS Model A319-151N, -153N, -171N, and -173N airplanes; Model A320-251N, -252N, -253N, -271N, -272N, and -273N airplanes; and M…
  - (2026-07-29) Medical Devices; Radiology Devices; Classification of the Phase-Changing Fiducial Marker for Radiation Therapy
      The Food and Drug Administration (FDA) is classifying the phase-changing fiducial marker for radiation therapy into class II (special controls). The special controls that apply to the device type are identified in this o…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-07-29) #30 Zhong Shanshan — $63.46B
      China · Food & Beverage · source: Beverages, pharmaceuticals · holdings: 603392-CN(SHANGHAI), 9633-HK(HONG KONG)
  - (2026-07-29) MOVER ▼ Elon Musk — $706.41B ($-23.36B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-07-29) MOVER ▼ Michael Dell — $215.22B ($-8.56B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-07-29) MOVER ▼ Jensen Huang — $164.47B ($-5.95B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-07-29) MOVER ▼ Thomas Peterffy — $99.32B ($-5.07B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-07-29) MOVER ▼ Jeff Bezos — $238.43B ($-3.71B since yesterday)
      United States · Technology · source: Amazon

### Campaign finance (FEC: top fundraisers + recent filings) — 6 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### GDACS — global disaster alerts — 6 new of 305 total
  - (2026-07-29) [Green] Earthquake in Pacific-Antarctic Ridge
      Earthquake · Green alert · Pacific-Antarctic Ridge · Magnitude 5.6M, Depth:10km
  - (2026-07-29) [Green] Earthquake in Pacific-Antarctic Ridge
      Earthquake · Green alert · Pacific-Antarctic Ridge · Magnitude 5.6M, Depth:10km
  - (2026-07-29) [Green] Earthquake in Kermadec Islands Region
      Earthquake · Green alert · Kermadec Islands Region · Magnitude 5.9M, Depth:10km
  - (2026-07-29) [Green] Earthquake in Kermadec Islands Region
      Earthquake · Green alert · Kermadec Islands Region · Magnitude 5.9M, Depth:10km
  - (2026-05-21) [Green] Drought in Democratic Republic of Congo, Kenya, Tanzania, Uganda
      Drought · Green alert · Democratic Republic of Congo, Kenya, Tanzania, Uganda · Minor impact for agricultural drought in 184570 km2
  - (2026-05-21) [Green] Drought in Democratic Republic of Congo, Kenya, Tanzania, Uganda
      Drought · Green alert · Democratic Republic of Congo, Kenya, Tanzania, Uganda · Minor impact for agricultural drought in 184570 km2

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-29) [Marginal Revolution] Reforms to the PhD?
      The Trump administration is pairing top universities with corporate giants in an effort to steer traditional PhD programs toward national scientific priorities. Today, the White House and National Science Foundation are…
  - (2026-07-29) [Marginal Revolution] What should I ask Jared Diamond?
      Yes, I will be doing a Conversation with him. His whole career is fair game, though many of my questions will cover his forthcoming book Profits, Prophets, Coaches, and Kings (When) Do Leaders Matter? From the Amazon sum…
  - (2026-07-29) [Marginal Revolution] Wednesday assorted links
      1. Mark Zuckerberg on our AI future (WSJ). 2. Claims about beauty (recommended). 3. 26 charts of Australia in trouble. 4. Hans Moravec interview (right now ungated?). 5. Those new service sector therapist jobs end the fe…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 14 total
  - (2026-07-29) CVE-2026-20316 · Cisco Secure Firewall Management Center (FMC): Cisco Secure Firewall Management Center Use of Hard-coded Password Vulnerability
      vendor: Cisco · product: Secure Firewall Management Center (FMC) · CISA remediation by 2026-08-01

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=18, 14d-median=18; carrying terms: august, national, safety, existing, certain, security, airspace, published, proposes, review, directives, class
- state_bills: today=229, 7d-median=117, 14d-median=117; carrying terms: housing, member, agency, policy, constitution, issue, alaska, transactions, safety, abuse, framework, projects
- state_news: today=1014, 7d-median=602, 14d-median=602; carrying terms: housing, economy, ferry, decade, charges, parks, banks, election, finds, medium, oregonians, debate
- local_news: today=182, 7d-median=228, 14d-median=228; carrying terms: suspect, following, charges, mother, election, battle, missing, skills, faces, medical, dining, officials
- foreign_news: today=1047, 7d-median=1016, 14d-median=1016; carrying terms: connectionerror, heats, elpais, topics, rescued, marked, shangri, economy, yongning, decade, coercive, charges
- chinese_internal: today=44, 7d-median=270, 14d-median=270; carrying terms: markets, beijing, giant, google, chinese, caixin, shein, market, funds, people, china, https
- russian_internal: today=916, 7d-median=894, 14d-median=894; carrying terms: novayagazeta, centcom, found, istories, bloomberg, axios, guardian, gazeta, novaya, laquo, russian, reuters
- ukrainian_internal: today=136, 7d-median=136, 14d-median=136; carrying terms: sanctions, warehouse, following, route, demand, striking, officials, remain, operation, however, diplomacy, people
- ukraine_theater: today=463, 7d-median=558, 14d-median=558; carrying terms: firms, cartography, takeaways, polygons, token, frontline, deepstatemap, acquired, httperror, anomaly, google, liveuamap
- paper_bets: today=134, 7d-median=136, 14d-median=136; carrying terms: transferable, humans, winner, according, announced, nomination, polymarket, erupt, romania, republican, scheduled, governance
- weather: today=173, 7d-median=174, 14d-median=174; carrying terms: lincoln, putnam, western, following, indices, little, rivers, period, health, atlantic, changed, continue
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, total, recession, payems, jolts, cpiaucsl, payrolls, openings, energy, commodities, assets, vixcls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, proxy, corporate, close, crypto, credit, range, russell, yield, commodities, silver, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=87, 7d-median=118, 14d-median=118; carrying terms: bosnia, sanctions, transnistrian, stability, daesh, protecting, activities, republic, satisfying, entities, terrorist, member
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quantitative, quiver, unauthorized, quiverquant, https, congresstrading, httperror, error
- billionaires: today=40, 7d-median=34, 14d-median=34; carrying terms: infrastructure, facebook, devasini, jensen, india, amazon, commodities, googl, euronext, microsoft, exchange, tiktok
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, appeals, district, california, court, robert, delaware, international, services, blanche, trade, school
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, therapeutics
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: robert, lindsey, johnson, graham, james, elect, warner, committee, michael, platner, alexandria, disbursements
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=25, 7d-median=47, 14d-median=47; carrying terms: israel, english, hezbollah, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=15, 7d-median=16, 14d-median=16; carrying terms: belgium, france, canada, position
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: brands, mechanical, epizootics, total, humans, prevention, patient, timor, western, confirmation, according, india
- cisa_kev: today=14, 7d-median=16, 14d-median=16; carrying terms: authorization, protocol, association, suite, business, privilege, microsoft, control, restrictive, deserialization, connection, sharepoint
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=305, 7d-median=272, 14d-median=272; carrying terms: bulgaria, congo, bosnia, somalia, liechtenstein, green, czech, depth, cyclone, ecuador, nicaragua, republic
- usgs_quakes: today=23, 7d-median=23, 14d-median=23; carrying terms: atlantic, islands, depth, south, region, ridge, philippines, indonesia, mexico, papua, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, volume, price, ethiopia, interest, prime, minister, resolves, meeting, adanech, change, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, revolution, benefit, marginal, economist, conversable, https, marginalrevolution, assorted, quality, links, looking
- tech_news: today=55, 7d-median=57, 14d-median=57; carrying terms: again, working, attackers, techcrunch, exposed, hacker, source, groups, hackers, schneier, systems, exploitation
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: baird, jason, morelle, chrissy, boebert, babin, frederica, yakym, deposit, housing, ayanna, laura
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, today, either, markets, paper, placed, module, decision, claude, market, converges, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*