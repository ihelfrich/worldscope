# WORLDSCOPE morning brief — 2026-07-29

## Headline
3023 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (725) · Russian Internal News (state + in-exile) (678) · State-Level News (336) · World leaders & government officials (324) · Chinese Internal News (229) · Local News: St. Louis + Atlanta (178) · U.S. Weather + Severe / Climate Outlooks (152) · Ukraine Theater (total-war monitoring) (61) · Ukrainian Internal News (national + local Kyiv) (52) · SEC Form 4 insider transactions (recent) (40) · GDELT GKG — themes / entities / watch areas (39) · IT, InfoSys & cybersecurity news (last 7 days) (39)

## What changed today
### International News + Multilateral Institutions — 725 new of 1005 total
  - (2026-07-29) [Global] US and Saudi Arabia strike ‘Iran-aligned’ groups in Iraq
      The US and Saudi Arabia launched joint air strikes on Iraq, targeting ‘Iran-aligned’ groups.
  - (2026-07-29) [Global] Jayden Seales takes five wickets as West Indies beat Pakistan in first Test
      West Indies take a 1-0 lead in the two-Test series after Jayden Seales dominates with the ball on day 4 in Trinidad.
  - (2026-07-29) [Global] Iran and Oman swap proposals to manage Strait of Hormuz: What we know
      Iran is proposing a deal that would see it have significantly more control than Oman.
  - (2026-07-29) [Global] Will Germany bring back mandatory military conscription next year?
      A voluntary recruitment drive has only drawn 500 people so far this year, with many more eager to opt out.
  - (2026-07-29) [Global] Why is Uganda experiencing a food crisis?
      At least 19 people have died of starvation in the country and 1.5 million are at risk of malnutrition, experts warn.
  - (2026-07-29) [Global] Russian industrial sites on fire after Ukrainian drone attacks
      Russia's top online retailer Wildberries says it has evacuated warehouses in Ryazan.

### Russian Internal News (state + in-exile) — 678 new of 1089 total
  - (2026-07-29) Умер диджей Kavinsky — автор трека Nightcall из фильма «Драйв» | LEDE: В Париже умер Венсан Пьер Клод Белорже, известный как диджей Kavinsky, сообщают Le Parisien и France24. ] (ru: Умер диджей Kavins…
      В Париже умер Венсан Пьер Клод Белорже, известный как диджей Kavinsky, сообщают Le Parisien и France24.
  - (2026-07-29) Путин уволил Александра Бречалова с поста главы Удмуртии | LEDE: Президент РФ Владимир Путин отправил в отставку главу Удмуртии Александра Бречалова. ] (ru: Путин уволил Александра Бречалова с поста г…
      Президент РФ Владимир Путин отправил в отставку главу Удмуртии Александра Бречалова.
  - (2026-07-29) Песня Монеточки попала в саундтрек фильма «Человек-паук: Новый день» | LEDE: В новом фильме Marvel «Человек-паук: Новый день» звучит песня «Монополия» российской певицы Лизы Монеточки. Об эт] (ru: Пес…
      В новом фильме Marvel «Человек-паук: Новый день» звучит песня «Монополия» российской певицы Лизы Монеточки. Об этом рассказали зрители, побывавшие на пресс-показах.
  - (2026-07-29) Reuters: Китай продал Ирану партию переносных зенитно-ракетных комплексов для восстановления ПВО после американских ударов | LEDE: Иран ожидает первую партию из 400 переносных зенитно-ракетн] (ru: Reu…
      Иран ожидает первую партию из 400 переносных зенитно-ракетных комплексов (ПЗРК), купленных им у Китая, пишет Reuters со ссылкой на три источника.
  - (2026-07-29) В Екатеринбурге задержали подозреваемого в избиении ученого РАН Никиты Зезина. Вскоре после нападения он умер | LEDE: По делу об избиении ученого РАН Никиты Зезина задержан 38-летний житель ] (ru: В Е…
      По делу об избиении ученого РАН Никиты Зезина задержан 38-летний житель Екатеринбурга. Об этом сообщили в Следственном комитете.
  - (2026-07-29) The New York Times: Иран рассматривал возможность нанести удар по морскому порту Украины в ответ на атаку на свое торговое судно | LEDE: Иран рассматривал возможность нанести удар по морском] (ru: The…
      Иран рассматривал возможность нанести удар по морскому порту в Украине в ответ на украинскую атаку на иранское торговое судно в Каспийском море, пишет The New York Times со ссылкой на иранских и западных чиновников.

### State-Level News — 336 new of 742 total
  - (2026-07-28) [Alabama] Governor Ivey Highlights Alabama Success at Farnborough International Airshow
      MONTGOMERY – Governor Kay Ivey on Tuesday announced that Alabama’s strong showing in the Farnborough International Airshow last week resulted in two major industry announcements and more than 50 meetings between the Alab…
  - (2026-07-28) [California] Vehicle theft in California dropped nearly 25% in 2025
      Source
  - (2026-07-28) [California] Governor Newsom expands statewide partnerships with additional cities to clean up encampments on highways
      Source
  - (2026-07-28) [California] A judge sent a doctor to evaluate California’s largest ICE detention center. What he found
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/012026-California-City-Immigration-Processing-Center-AP-CM-04.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size siz…
  - (2026-07-28) [California] Antes enseñaban sobre un héroe. Ahora profesores reconsideran las lecciones sobre César Chávez tras acusaciones
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/031926_Cesar-Chavez-LA_TS_CM_18.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-07-28) [California] Brasil permite a los padres controlar el uso de las redes sociales por parte de sus hijos. ¿Por qué California no?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/08/083024_Santa-Monica-Construction_-ZS-32_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 229 new of 299 total
  - (2026-07-28) Covid-19 Infections Surge Across China as Virus Reclaims Dominance - Caixin Global
      Covid-19 Infections Surge Across China as Virus Reclaims Dominance Caixin Global
  - (2026-07-28) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1CVWt2RG1NeUtPSk5ncnpQS1NnOER4SzJGZkxqa3VGMFVwaUpnNktlc3M4d3NQdGVIMUtfMjh6NXFwQkJmR3NTN2dLUnRzM3] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-07-29) 今日开盘：沪指报3823.29点 涨幅0.26% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5OMTFkYnhGTWtKRFRoNWZKcGhNMFBOTlZERHVIemZXY3NMd1JwOUFZOV96UUZtaElrUFFJSENOX1B1S0NHR1JlelY5VzhTe] (zh:…
      今日开盘：沪指报3823.29点 涨幅0.26% 财新
  - (2026-07-28) 财经早知道｜从豪宅到普宅，“全款买房”成流行 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE41TS1WVi0xd291WlZOSUJ2YzVKUUVHMlgwN0tQcVpRbFdlc3JoS2haaXlINGNqcmVRakFXUDJGSEtCY3picktyUm15STQyZkE] (zh:…
      财经早知道｜从豪宅到普宅，“全款买房”成流行 财新
  - (2026-07-29) 海南终止第二轮赤潮应急响应 海洋牧场安全生产敲响警钟 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1yVXNsaTAwMmFDTVh5VE9qQjdDQW92VGdBa1pxYmEwS3VpR0N6dkxnbnFlc3pjSU1FVHhGWVlYbThHellxZVpfN3htcU0] (zh:…
      海南终止第二轮赤潮应急响应 海洋牧场安全生产敲响警钟 财新
  - (2026-07-28) 英伟达CDS暴涨 AI基建循环融资引债市担忧 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5EZlpaR1VDbFVYTW9WMjNWM0dTOWVfYmNCV2gwUklEN3YtaThOYTV1V3k3SE1RaDJEenU2UW1fTjlOc1ZPREhQNDJzSWp4V1l] (zh:…
      英伟达CDS暴涨 AI基建循环融资引债市担忧 财新

### Local News: St. Louis + Atlanta — 178 new of 219 total
  - (2026-07-28) [St. Louis] KSDK’s Art Holliday celebrates Chuck Berry’s pianist Johnnie Johnson in upcoming documentary ‘Johnnie Be Good’
      Despite being a Rock & Roll Hall of Fame inductee, most people do not know his name. Despite being the man who hired an unknown guitarist named Chuck Berry to be in his band for a performance on New Year’s Eve 1952, most…
  - (2026-07-28) [St. Louis] Free 4 All STL announces 2026 dates, opens for artist submissions
      The inaugural Free 4 All music showcase took over the streets of Grand Center in September 2025, bringing 100 St. Louis-based acts of every conceivable genre to nine stages throughout the district, with droves of local m…
  - (2026-07-28) [St. Louis] G’Ra Asim tackles love, identity, and culture in new book ‘99 Problems Finding the 1’
      Jay-Z said he had 99 problems, but a (rather choice word for a) woman wasn’t one. St. Louis–born Washington University professor and musician G’Ra Asim has 99 problems as well—but his problems revolve around exactly what…
  - (2026-07-28) [St. Louis] New St. Louis experience lets kids excavate a life-size dinosaur skeleton
      Wearing field vests and armed with excavation tools, a group of young paleontologists carefully brushes away sand until the first fossil appears. One by one, they uncover buried bones, match each discovery to a field map…
  - (2026-07-28) [St. Louis] Top things to do in St. Louis this weekend: July 31–August 2
      Ain’t Too Proud | July 27–August 2 The Broadway hit follows The Temptations from Detroit to the pinnacle of the charts. See website for times and prices. The Muny, 1 Theatre Dr., Forest Park. St. Charles County Fair | Ju…
  - (2026-07-28) [St. Louis] Found and Formed arts pop-ups let parents and kids create side by side
      Parallel play isn’t just a milestone for toddlers. Found and Formed creates a space where parents can flex their creative muscles right alongside their kiddos, each working on age-appropriate crafts while fueled by coffe…

### U.S. Weather + Severe / Climate Outlooks — 152 new of 155 total
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 5:28AM EDT until July 29 at 9:00AM EDT by NWS Albany NY
      FFWALY The National Weather Service in Albany has extended the * Flash Flood Warning for... Southwestern Albany County in east central New York... Northeastern Greene County in east central New York... * Until 900 AM EDT…
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 5:23AM EDT until July 29 at 9:00AM EDT by NWS Albany NY
      FFWALY The National Weather Service in Albany has extended the * Flash Flood Warning for... South Central Greene County in east central New York... Northeastern Ulster County in east central New York... * Until 900 AM ED…
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 5:22AM EDT until July 29 at 9:00AM EDT by NWS Albany NY
      FFWALY The National Weather Service in Albany has extended the * Flash Flood Warning for... Southwestern Greene County in east central New York... * Until 900 AM EDT. * At 522 AM EDT, Doppler radar indicated heavy rain a…
  - (2026-07-29) [Severe] Special Marine Warning: Special Marine Warning issued July 29 at 5:12AM EDT until July 29 at 6:00AM EDT by NWS Newport/Morehead City NC
      SMWMHX The National Weather Service in Newport has issued a * Special Marine Warning for... Waters from Cape Hatteras to Ocracoke Inlet NC from 20 to 60 NM... Waters from Cape Lookout to Surf City NC from 20 to 60 NM...…
  - (2026-07-29) [Severe] Flash Flood Warning: Flash Flood Warning issued July 29 at 5:07AM EDT until July 29 at 8:15AM EDT by NWS Upton NY
      FFWOKX The National Weather Service in Upton has issued a * Flash Flood Warning for... Southern Fairfield County in southern Connecticut... Southwestern New Haven County in southern Connecticut... * Until 815 AM EDT. * A…
  - (2026-07-29) [Moderate] Gale Warning: Gale Warning issued July 29 at 2:00AM PDT until July 29 at 9:00PM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 15 to 25 kt with gusts up to 35 kt. * WHERE...Coastal Waters from Point Pinos to Point Piedras Blancas California out to 10 NM. * WHEN...Until 9 PM PDT this evening. * IMPACTS...Strong winds will…

### Ukraine Theater (total-war monitoring) — 61 new of 240 total
  - (2026-07-29) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-29) [Liveuamap] General Staff of Armed Forces of Ukraine confirmed attack at the Prioritet oil depot in Udmurtiya - Liveuamap
      General Staff of Armed Forces of Ukraine confirmed attack at the Prioritet oil depot in Udmurtiya <font color
  - (2026-07-27) [Liveuamap] President Zelensky: Ukrainian long range weapons targeted export terminal in Rostov region, oil infrastructure in Yaroslavl region and Udmurtiya Republic 1300 kms from Ukraine - Liveuamap
      President Zelensky: Ukrainian long range weapons targeted export terminal in Rostov region, oil infrastructure in Yaroslavl regio
  - (2026-07-26) [Liveuamap] Bulk carrier Golden Leo (Guinea-Bissau flagged, Mumbai-owned, carrying corn from Odesa) capsized in shallow water off the Ukrainian coast today, a week after being hit by three Russian cru…
      Bulk carrier Golden Leo (Guinea-Bissau flagged, Mumbai-owned, carrying corn from Odesa) capsized in shallow water
  - (2026-07-29) [Liveuamap] The Israeli army: Over the past few days, we found and destroyed dozens of Hezbollah weapons and ammunition in southern Lebanon. Tel Aviv-Yafo, Tel Aviv District - Lebanon news on live map…
      The Israeli army: Over the past few days, we found and destroyed dozens of Hezbollah weapons and ammunition in so
  - (2026-07-29) [Liveuamap] News Live - iraq.liveuamap.com
      News Live iraq.liveuamap.com

### Ukrainian Internal News (national + local Kyiv) — 52 new of 113 total
  - (2026-07-29) У Києві оголосили підозру 19-річному студенту: поранив трьох людей ножем | LEDE: У Києві 19-річному студенту повідомили про підозру в замаху на вбивство та завданні тяжких тілесних ушкоджень дв] (uk:…
      У Києві 19-річному студенту повідомили про підозру в замаху на вбивство та завданні тяжких тілесних ушкоджень двом людям.
  - (2026-07-29) Трамп змінює риторику щодо України: головні підсумки візиту Зеленського у США | LEDE: ] (uk: Трамп змінює риторику щодо України: головні підсумки візиту Зеленського у США)
  - (2026-07-29) У організаторів схеми фейкової інвалідності вилучили 14 мільйонів готівки – прокуратура | LEDE: Прокуратура та СБУ вилучили понад 14 млн грн у підозрюваних у схемі відстрочки від мобілізації за] (uk:…
      Прокуратура та СБУ вилучили понад 14 млн грн у підозрюваних у схемі відстрочки від мобілізації за фейковою інвалідністю.
  - (2026-07-29) Зеленський: Повернення Криму поки не на порядку денному мирних переговорів | LEDE: Президент Володимир Зеленський каже, що питання повернення окупованого Росією Криму наразі не обговорюється в ] (uk:…
      Президент Володимир Зеленський каже, що питання повернення окупованого Росією Криму наразі не обговорюється в межах переговорного процесу, однак він залишається невід'ємною частиною України.
  - (2026-07-29) Зеленський у США. Головне про зустріч з Трампом, нову риторику та сигнали для України | LEDE: Президент України Володимир Зеленський 28 липня відвідав США. Офіційним приводом стала церемонія пр] (uk:…
      Президент України Володимир Зеленський 28 липня відвідав США. Офіційним приводом стала церемонія прощання із давнім другом України сенатором Ліндсі Гремом, який раптово помер ввечері 11 липня. Втім, як це було і на похор…
  - (2026-07-29) Сенат пробиває санкційну стіну: яке покарання для Росії готують США і якою буде роль Трампа | LEDE: Тривалий час американський президент вірив у готовність Москви вести конструктивні переговори] (uk:…
      Тривалий час американський президент вірив у готовність Москви вести конструктивні переговори про завершення війни.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-29) [Vincent Ron] Form 4 (Reporting)
      filed 2026-07-29 01:48 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000075 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:48 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000075 Size: 19 KB
  - (2026-07-29) [KORN JEFFREY G] Form 4 (Reporting)
      filed 2026-07-29 01:48 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000074 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:48 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000074 Size: 19 KB
  - (2026-07-29) [Gaylor Douglas Walter] Form 4 (Reporting)
      filed 2026-07-29 01:46 UTC · role: Reporting — Filed: 2026-07-28 AccNo: 0001075736-26-000071 Size: 19 KB
  - (2026-07-29) [Crexendo, Inc.] Form 4 (Issuer)
      filed 2026-07-29 01:46 UTC · role: Issuer — Filed: 2026-07-28 AccNo: 0001075736-26-000071 Size: 19 KB

### GDELT GKG — themes / entities / watch areas — 39 new of 39 total
  - (2026-07-29) [Russia oil sanctions perimeter · themes] IDI Kaltim Siap Bersinergi dengan Pemkab Paser , Dukung Program Kesehatan dan Muswil 2028
      kaltim.tribunnews.com · Indonesian · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] After the quake came the blast : Inside Japan shopping mall disaster
      tribune.com.pk · English · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] It is all about networks - Newsday Zimbabwe
      newsday.co.zw · English · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] 宁德时代的焦虑 ， 和英伟达一模一样 _ 财富号 _ 东方财富网
      caifuhao.eastmoney.com · Chinese · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] Dettol and Durex boss warns united kingdom shoppers prices will rise
      malverngazette.co.uk · English · tone NA
  - (2026-07-29) [Russia oil sanctions perimeter · themes] Tahap Pertama Ludes , Areum Parc Kembali Luncurkan Dua Klaster Baru di Bogor
      wartakota.tribunnews.com · Indonesian · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 55 total
  - (2026-07-29) [The Hacker News] Public PoC Released for Exploited Check Point SmartConsole Authentication Bypass
      Cybersecurity researchers have shared additional technical details about a recently patched critical security flaw impacting Check Point Security Management Server and Multi-Domain Security Management Server (MDS) that h…
  - (2026-07-29) [The Hacker News] OpenAI Agent Used Exposed Credentials Across Four Services During Hugging Face Breach
      OpenAI on Tuesday revealed the rogue artificial intelligence (AI) agent that escaped its sealed evaluation environment and broke into Hugging Face's production environment also hacked multiple third-party accounts and se…
  - (2026-07-29) [The Hacker News] New Gitea RCE Lets Repository Writers Plant a Git Hook to Run Shell Commands
      Gitea, the self-hosted Git platform, has patched a critical remote code execution vulnerability. A user with ordinary repository write access can turn attacker-controlled patch content into a live Git hook and run shell…
  - (2026-07-29) [The Hacker News] Flying Eagle Android RAT Traces Found on 170 Servers as Source Code Circulates
      Source code for the Flying Eagle Android remote access trojan (RAT) framework is circulating through criminal Telegram channels. Hunt.io and independent researcher NetAskari traced matching control panels and certificate…
  - (2026-07-29) [The Hacker News] Two Compromised joyfill npm Packages Run RAT When Imported Into Node.js
      Beta release versions of two npm packages in the @joyfill namespace have been compromised to deliver a remote access trojan (RAT) associated with the DEV#POPPER malware family. The list of affected packages is as follows…
  - (2026-07-29) [Schneier on Security] Measuring LLMs’ Ability to Perform Cryptanalysis
      There’s new benchmark measuring AI’s ability to perform mathematical cryptanalysis. Anthropic’s frontier model actually found new attacks. The benchmark: “CryptanalysisBench: Can LLMs do Cryptanalysis?” The idea is to be…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 30 total
  - (2026-07-29) PUMA52 (Slovenia)
      icao24: 506e19 · position: (46.4787, 15.6554) · alt: 518m · 178km/h
  - (2026-07-29) CFC2977 (Canada)
      icao24: c2b585 · position: (53.7728, -1.6811) · alt: 8221m · 612km/h
  - (2026-07-29) JAF5KH (Belgium)
      icao24: 44d1ba · position: (39.3068, 24.8898) · alt: 11582m · 825km/h
  - (2026-07-29) JAF3NE (Belgium)
      icao24: 44d1a6 · position: (45.5318, -2.8377) · alt: 10363m · 910km/h
  - (2026-07-29) JAF7CB (Belgium)
      icao24: 44d1b3 · position: (48.2247, 0.3259) · alt: 10363m · 886km/h
  - (2026-07-29) JAF6YV (Belgium)
      icao24: 44d1b4 · position: (44.7861, -0.8841) · alt: 11582m · 912km/h

### Court opinions of consequence (federal & state) — 25 new of 60 total
  - (2026-07-28) U.S. Court of Appeals, 11th Cir.: Michael Davis v. Lockheed Martin Corporation
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: Anthony Knight v. Cambria Company, LLC
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: Matthew Goforth v. Transform Holdco, LLC
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: United States v. Benjamin Striplin
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: United States v. Lance Longie
  - (2026-07-28) U.S. Court of Appeals, 8th Cir.: United States v. Rasheem Bogan

### USGS earthquakes (M4.5+, past day) — 19 new of 20 total
  - (2026-07-29) M 5.4 - 153 km NE of Neiafu, Tonga
      M5.4 · 153 km NE of Neiafu, Tonga · depth 10 km
  - (2026-07-28) M 5.4 - 211 km SE of Kokopo, Papua New Guinea
      M5.4 · 211 km SE of Kokopo, Papua New Guinea · depth 10 km
  - (2026-07-28) M 5.2 - 151 km WSW of Puerto Santa, Peru
      M5.2 · 151 km WSW of Puerto Santa, Peru · depth 9.709 km
  - (2026-07-29) M 5.1 - Kermadec Islands region
      M5.1 · Kermadec Islands region · depth 35 km
  - (2026-07-28) M 5.1 - south of the Fiji Islands
      M5.1 · south of the Fiji Islands · depth 575.128 km
  - (2026-07-29) M 5.0 - south of Tonga
      M5.0 · south of Tonga · depth 10 km

### Paper Trading Scorecard — 17 new of 142 total
  - (2026-07-29) [Polymarket] Will Gold (XAUUSD) hit (HIGH) $4,400 in July?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of July 2026, any 1-minute candle for Gold (XAUUSD) has a final "High" or "Low" price equal to or beyond (above for ↑…
  - (2026-07-29) [Polymarket] Will the Dallas Cowboys win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-29) [Polymarket] Bank of Japan increases interest rates by 50+ bps after the July 2026 meeting?
      The Statement on Monetary Policy for the Bank of Japan's Monetary Policy meeting for July is scheduled to be released on July 31, 2026 (https://www.boj.or.jp/en/mopo/mpmsche_minu/index.htm). This market will resolve to t…
  - (2026-07-29) [Polymarket] Romanian parliament dissolved by July 31?
      This market will resolve to "Yes" if the sitting Romanian Chamber of Deputies and Senate are dissolved by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No". The primary resolution source for th…
  - (2026-07-29) [Manifold] T Coronae Borealis reaches magnitude 5.0 before November 11th, 2026?
  - (2026-07-29) [Manifold] Will Spiderman: Brand New Day beat Spiderman: No Way Home's opening weekend?

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 160 total
  - (2026-07-29) [DSCA Arms Sale] DSCA Director Signs FMF Guaranteed Loan - dsca.mil
      DSCA Director Signs FMF Guaranteed Loan dsca.mil
  - (2026-07-29) [USASpending] $2,833,494,612 → FISHER SAND & GRAVEL CO: CONSTRUCT VERTICAL BORDER BARRIER
      Agency: Department of Homeland Security. Description: CONSTRUCT VERTICAL BORDER BARRIER
  - (2026-07-29) [USASpending] $2,032,829,135 → LOCKHEED MARTIN CORP: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONAR
      Agency: National Aeronautics and Space Administration. Description: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) SERIES TO CONTINUE ITS MISSION THROUGH NEW REQ…
  - (2026-07-29) [USASpending] $1,598,641,181 → BATTELLE SAVANNAH RIVER ALLIANCE, LLC: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING
      Agency: Department of Energy. Description: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING (M&O) CONTRACT
  - (2026-07-29) [USASpending] $1,058,337,519 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-07-29) [USASpending] $1,029,024,846 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### U.S. Federal Action — 13 new of 20 total
  - (2026-07-29) CONTENTS
  - (2026-07-29) Allocation of Assets in Single-Employer Plans; Interest Assumptions for Valuing Benefits
  - (2026-07-29) Continuation of the National Emergency With Respect to Brazil
  - (2026-07-29) Restoring Trust in the Smithsonian Institution
  - (2026-07-29) Amendment of Jet Routes J-190 and J-584 and Very High Frequency Omnidirectional Range Federal Airways V-170 and V-188 in the Vicinity of Slate Run, Pennsylvania
      This action corrects a notice of proposed rulemaking (NPRM) that the FAA published in the Federal Register on July 20, 2026, proposing to amend Jet Routes J-190 and J-584 and Very High Frequency Omnidirectional Range (VO…
  - (2026-07-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2025-16- 12, which applied to all Airbus SAS Model A319-151N, -153N, -171N, and -173N airplanes; Model A320-251N, -252N, -253N, -271N, -272N, and -273N airplanes; and M…

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-07-29) Los Cabos Open: Dalibor Svrcina vs Adam Walton
      yes price: 100% · 24h volume: $1,338,121 · resolves 2026-08-03
  - (2026-07-29) LoL: Kiwoom DRX vs Nongshim Red Force - Game 2 Winner
      yes price: 0% · 24h volume: $1,126,650 · resolves 2026-07-29
  - (2026-07-29) Will Tulsi Gabbard win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,107,833 · resolves 2028-11-07
  - (2026-07-29) LoL: Kiwoom DRX vs Nongshim Red Force - Game 1 Winner
      yes price: 0% · 24h volume: $892,340 · resolves 2026-07-29
  - (2026-07-29) LoL: Kiwoom DRX vs Nongshim Red Force (BO3) - LCK Round 3-4 Rise Group
      yes price: 0% · 24h volume: $864,859 · resolves 2026-07-29
  - (2026-07-29) US x Iran Effective Ceasefire by July 24?
      yes price: 36% · 24h volume: $716,881 · resolves 2026-07-24

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-29) [South Korea] Nana Renews Contract With Agency
      soompi.com · English
  - (2026-07-29) [South Korea] Lee Kwang Soo Joins Lee Byung Hun , Go Youn Jung , Lee Do Hyun , WOODZ , And Park Hae Joon In Upcoming Historical Action Film
      soompi.com · English
  - (2026-07-29) [South Korea] Watch : Lee Jung Eun , Kong Hyo Jin , Park So Dam , And Lee Yeon Unite For A Family Revenge Mission In The Journey To Gyeongju
      soompi.com · English
  - (2026-07-29) [South Korea] Go Ji Yong Revealed To Have Divorced 2 Years Ago
      soompi.com · English
  - (2026-07-29) [South Korea] Kim Hye Joon Learns The Truth About Yoo Hyun Soo In A Shop For Killers 2
      soompi.com · English
  - (2026-07-29) [South Korea] QUIZ : Which ILLIT Member Are You Most Like ?
      soompi.com · English

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-29) [Marginal Revolution] Data on Chinese innovation
      China’s technological progress in recent decades has been viewed with admiration, alarm, and (in some cases) doubt. To better understand the Chinese innovation ecosystem, we compile a dataset of almost 14 million domesti…
  - (2026-07-29) [Marginal Revolution] You will learn to love AI writing
      That is the theme of my latest Free Press article, excerpt: But do I wish to eschew AI writing for the rest of my life? Absolutely not. Most of all, I want AI writing to get better, so it does not irritate me with its cl…
  - (2026-07-28) [Marginal Revolution] Congratulations to Ross D. and others
      Ross Douthat, an opinion columnist at The New York Times, is leaving to join the CBS News program “60 Minutes” as a correspondent, the show’s executive producer said in a memo to staff on Tuesday. Mr. Douthat is among a…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 36 total
  - (2026-07-29) MOVER ▼ Tadashi Yanai & family — $66.67B ($-0.46B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-29) MOVER ▼ Carlos Slim Helu & family — $126.13B ($-0.16B since yesterday)
      Mexico · Telecom · source: Telecom

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=18, 14d-median=18; carrying terms: august, final, certain, model, management, airplanes, applicable, airworthiness, coast, directive, security, amending
- state_bills: today=258, 7d-median=117, 14d-median=117; carrying terms: school, death, schools, credit, trade, currency, fiscal, instead, medicaid, increases, service, adopt
- state_news: today=742, 7d-median=602, 14d-median=602; carrying terms: scheduled, institute, crowd, foreign, kansas, ground, school, trail, dcist, southern, discuss, making
- local_news: today=219, 7d-median=228, 14d-median=228; carrying terms: south, probe, husband, school, restaurants, cbmipafbvv, accused, killed, gunman, grand, students, illinois
- foreign_news: today=1005, 7d-median=1006, 14d-median=1006; carrying terms: scheduled, developing, package, foreign, improvements, school, committed, demands, making, prize, urgent, palestinians
- chinese_internal: today=299, 7d-median=288, 14d-median=288; carrying terms: lxtfa, cbmiakfvx, global, cbmia, funds, china, politics, cbmickfvx, color, cbmiz, articles, shein
- russian_internal: today=1089, 7d-median=894, 14d-median=894; carrying terms: times, gazeta, found, russian, novayagazeta, guardian, istories, research, openai, novaya, httperror, raquo
- ukrainian_internal: today=113, 7d-median=134, 14d-median=134; carrying terms: institute, injuring, civilians, foreign, donald, pentagon, warehouse, risks, saying, changes, technology, diplomacy
- ukraine_theater: today=240, 7d-median=558, 14d-median=558; carrying terms: cudwdf, developing, cuxnndvjlte, foreign, qwhxu, ground, school, esmrowhi, ufdbvgfztwg, nurgms, cuxnnvnaatbvv, airstrikes
- paper_bets: today=142, 7d-median=140, 14d-median=140; carrying terms: event, prime, polymarket, award, scheduled, fuentes, leave, approve, north, kansas, depleted, baker
- weather: today=155, 7d-median=173, 14d-median=173; carrying terms: south, above, lower, small, illnesses, threat, severe, southern, beach, miami, francisco, level
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: effective, dexjpus, labor, cpilfesl, payems, indicator, recession, assets, nonfarm, dexchus, rates, spread
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, large, china, agriculture, range, equities, nasdaq, proxy, silver, crypto, russell, close
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=160, 7d-median=119, 14d-median=119; carrying terms: south, cbmiqefvx, institute, issuance, assets, foreign, imposing, transition, schools, construction, belarus, license
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, quiverquant, quantitative, quiver, congresstrading, client, https, error, unauthorized
- billionaires: today=36, 7d-median=34, 14d-median=34; carrying terms: family, telecom, discount, technologies, yiming, mexico, larry, tadashi, paris, meyers, gautam, tesla
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, services, school, douglas, trade, group, court, robert, district, supreme, blanche, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, therapeutics
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: warner, ocasio, krishnamoorthi, cycle, cortez, filing, graham, elect, pinkston, disbursements, platner, robert
- gdelt_regions: today=6, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=39, 7d-median=47, 14d-median=47; carrying terms: english, russia, perimeter, sanctions, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=24, 14d-median=24; carrying terms: belgium, canada, france, position
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: event, sometimes, jinka, south, november, epidemiological, batch, internationally, institute, elements, international, above
- cisa_kev: today=13, 7d-median=16, 14d-median=16; carrying terms: suite, product, improper, injection, vulnerability, sharepoint, control, lockout, restrictive, remediation, privilege, fortinet
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=287, 7d-median=272, 14d-median=272; carrying terms: germany, herzegovina, mexico, switzerland, thailand, alert, philippines, venezuela, north, croatia, austria, vietnam
- usgs_quakes: today=20, 7d-median=23, 14d-median=23; carrying terms: south, region, depth, islands, philippines, indonesia, guinea, mexico, papua
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, resolves, ethiopia, rates, price, minister, interest, meeting, volume, abiebie, decrease, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, economist, marginalrevolution, benefit, revolution, https, conversable, marginal, quality, looking, international, graduates
- tech_news: today=55, 7d-median=57, 14d-median=57; carrying terms: current, companies, world, technology, online, light, request, record, government, schneier, https, almost
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: kiggans, pramila, nikki, vargas, kansas, murphy, jacobs, doggett, banks, whitehouse, correa, donald
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, consensus, markets, identify, claude, placed, evidence, today, market, module, placement, converges

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*