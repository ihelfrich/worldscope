# WORLDSCOPE morning brief — 2026-08-26

## Headline
3720 new items across 24 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (765) · International News + Multilateral Institutions (764) · Ukraine Theater (total-war monitoring) (558) · State-Level News (336) · World leaders & government officials (324) · Chinese Internal News (248) · Local News: St. Louis + Atlanta (208) · U.S. Weather + Severe / Climate Outlooks (131) · State Legislative Action (72) · Ukrainian Internal News (national + local Kyiv) (56) · IT, InfoSys & cybersecurity news (last 7 days) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 765 new of 1174 total
  - (2026-08-26) Склад Wildberries в Тамбовской области полностью уничтожен после атаки украинских дронов. Ранены два человека | LEDE: Логистический центр Wildberries в городе Котовск в Тамбовской области, к] (ru: Скл…
      Логистический центр Wildberries в городе Котовск в Тамбовской области, который ночью 26 августа атаковали украинские беспилотники, полностью сгорел, сообщил губернатор региона Евгений Первышов.
  - (2026-08-26) Зеленский наградил Маска орденом Свободы — одной из высших наград Украины | LEDE: Илон Маск награжден украинским орденом Свободы. Указ о награждении «предпринимателя, инженера, руководителя ] (ru: Зел…
      Илон Маск награжден украинским орденом Свободы. Указ о награждении «предпринимателя, инженера, руководителя компаний SpaceX и Tesla» подписал 26 августа президент Владимир Зеленский.
  - (2026-08-26) Правительство РФ утвердило меры поддержки бизнеса, пострадавшего от ударов ВСУ по складам Wildberries. Продавцы получат отсрочку по налогам | LEDE: Премьер-министр Михаил Мишустин подписал п] (ru: Пра…
      Премьер-министр Михаил Мишустин подписал постановление о поддержке бизнеса, пострадавшего в результате атак украинских беспилотников на логистические комплексы Wildberries.
  - (2026-08-26) В дополнении к игре «Ведьмак 3» не будет русской озвучки | LEDE: В дополнении к игре «Ведьмак 3: Дикая Охота — Баллады прошлого» не будет русской озвучки, объявила польская игровая студия CD] (ru: В д…
      В дополнении к игре «Ведьмак 3: Дикая Охота — Баллады прошлого» не будет русской озвучки, объявила польская игровая студия CD Projekt RED, выпускающая игру.
  - (2026-08-26) «Ведомости»: Леонид Слуцкий может потерять пост главы комитета по международным делам в Госдуме нового созыва | LEDE: В Госдуме нового созыва может смениться глава комитета по международным ] (ru: «Ве…
      В Госдуме нового созыва может смениться глава комитета по международным делам — вместо Леонида Слуцкого из ЛДПР этот пост займет представитель «Единой России».
  - (2026-08-26) Минюст США заявил, что без опыта Трампа Кеннеди-центр придется снести. Ранее суд запретил добавить в название центра имя Трампа | LEDE: Центр исполнительских искусств имени Джона Ф. Кеннеди ] (ru: Мин…
      Центр исполнительских искусств имени Джона Ф. Кеннеди придется снести, если президенту Дональду Трампу не разрешат его сохранить, заявили юристы министерства юстиции США, представляющие центр.

### International News + Multilateral Institutions — 764 new of 1041 total
  - (2026-08-25) [Global] Canada announces 'dollar-for-dollar' retaliatory tariffs on US as high as 50%
      The latest escalation in an ongoing trade war between the US and Canada will see new levies on goods from steel to furniture, fresh tuna and makeup.
  - (2026-08-25) [Global] China hits out at 'illegal' new US sanctions on Iran and trading partners
      The US has threatened to isolate nations that continue to do business with Tehran, which sells much of its oil to Beijing.
  - (2026-08-25) [Global] CIA chief travels to Moscow for unannounced talks, US media reports
      Flight tracking data confirms an American military aircraft travelled to Russia from the US via Latvia on Tuesday.
  - (2026-08-25) [Global] Mass arrests in global crackdown on West African cyber-crime networks
      The operation included the arrest of 39 people in South Africa for romance and investment scams.
  - (2026-08-25) [Global] Brain disease in dead NFL players 'higher than previously shown'
      A new study says at least one in four ex-NFL players who died between 2016 and 2021 had a degenerative brain disease but the true figure could be much higher.
  - (2026-08-25) [Global] Tornado tears through French village, leaving dozens hurt and homes ravaged
      The south-western village of Pomas was hardest hit, with hundreds of homes damaged and fifteen people taken to hospital.

### Ukraine Theater (total-war monitoring) — 558 new of 841 total
  - (2026-08-26) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-25) [FIRMS] thermal anomaly 44.532, 34.130 (FRP 17.68 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1011Z, FRP 17.68 MW
  - (2026-08-25) [FIRMS] thermal anomaly 44.531, 34.125 (FRP 4.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1011Z, FRP 4.97 MW
  - (2026-08-25) [FIRMS] thermal anomaly 44.533, 34.132 (FRP 11.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1011Z, FRP 11.08 MW
  - (2026-08-25) [FIRMS] thermal anomaly 44.532, 34.128 (FRP 10.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1011Z, FRP 10.51 MW
  - (2026-08-25) [FIRMS] thermal anomaly 45.866, 34.224 (FRP 2.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1013Z, FRP 2.89 MW

### State-Level News — 336 new of 700 total
  - (2026-08-26) [California] Surprise Solano County vote kills California Forever’s shipyard bill for this year
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082526_Solano-County-Board-of-Supervisors_AHK_CM_03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-imag…
  - (2026-08-26) [California] With clock ticking, California lawmakers reject key parts of Newsom’s wildfire plan
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082426-Eaton-Fire-Survivors-MG-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-08-25) [California] CalMatters sues UCLA over refusal to disclose athlete payments
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/110825_UCLA-Football_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-08-25) [California] Counting votes quickly and accurately are not mutually exclusive. Here’s how California can do it
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/04/110525_Election-Counting-Fresno_LV_CM_15.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…
  - (2026-08-25) [California] Federal wildfire crews are stretched thin. California is stepping in to help
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/072226_Diablo-Canyon-Fire-Gaps_LV_CM_02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-po…
  - (2026-08-25) [California] Help CalMatters report on what happens to drivers after they cause a serious car crash
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/092425_DUI-DeathsMemorial_JAH_CM_10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 248 new of 289 total
  - (2026-08-25) China’s Advanced Chip Supply to Surge 46% Annually Through 2035, Goldman Says - Caixin Global
      China’s Advanced Chip Supply to Surge 46% Annually Through 2035, Goldman Says Caixin Global
  - (2026-08-26) 美国威胁对伊朗史无前例制裁纯属吆喝，美非刀枪不入霸主 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5xdTV5eFpWbTBJT28wMzVkdm4xeFl6Z0RWbzV2MUJ6ME4tOWF1ZUpMM0hKMHdxSE45aG5KWmJwT1BwWGcyTThBalNjanR] (zh:…
      美国威胁对伊朗史无前例制裁纯属吆喝，美非刀枪不入霸主 风闻
  - (2026-08-26) 原定开放参观的日本海自秋月号进港过程中大幅横摇“险触礁”，取消开发活动 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE9acmo2SVFaX2Jxbl9CSmd1dTlmalVBWDRFQVRwNlJxREFjaHZQQ0c0WVQ3U0FBVVJ3bGtVZ1dnVW5GNXp3TD] (zh:…
      原定开放参观的日本海自秋月号进港过程中大幅横摇“险触礁”，取消开发活动 风闻
  - (2026-08-26) 海排长：我每天的工作之一，就是与五角大楼的官僚体制展开一场“战争” - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBFR3JPazdpZjZXemlVUld2TnNXZHZsRmExaFROd2J0MjBmc3J1ODVqZTRuR1g0ZXhWanJqdzhXV2s3TVNQUVlh] (zh:…
      海排长：我每天的工作之一，就是与五角大楼的官僚体制展开一场“战争” 风闻
  - (2026-08-26) 百度搜索AI重构，带来更大想象空间 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE8tNDhzVTJ1RjdLbFNGbTFzbC1DWUFyelFfZ2F4V0NmNnl6Wk1jZFctTURDdGJYdHE5MFd5Wk9JejFlTXdxOHd3b1RoeVdmek5fYjdf] (zh:…
      百度搜索AI重构，带来更大想象空间 风闻
  - (2026-08-26) “趁男友不在与暧昧对象分享”？德芙致歉广告价值导向不当 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1TOU1ybkp0T1R2VmxuSk9YTDRpY1lsdlpqc3VOajAta3VGTi1HdzVfcU91NWQzWGgxQlpTc0x5QUJZdXVZY3h4WUlPN] (zh:…
      “趁男友不在与暧昧对象分享”？德芙致歉广告价值导向不当 观察者

### Local News: St. Louis + Atlanta — 208 new of 255 total
  - (2026-08-25) [St. Louis] South City favorite Stan’s Bar suffers major fire
      A South City bar described as a second home to many patrons had its insides gutted by a daytime fire. Bystanders say that Stan’s Bar caught fire around noon on Tuesday. Normally, they would have been open at the time. Fo…
  - (2026-08-25) [St. Louis] How to parent your college student without hovering
      For 18 years, parenting often involves keeping track of seemingly everything for your child: scheduling doctor appointments, sharing deadline reminders, and tracking how much clean underwear remains in their dresser. The…
  - (2026-08-25) [St. Louis] Festival of Nations returns to Tower Grove Park this weekend
      Calling the annual Festival of Nations “beloved” doesn’t quite cover it. The annual event, sponsored by the International Institute of St. Louis, has been bringing the world to Tower Grove Park since 1934. People plan th…
  - (2026-08-25) [St. Louis] Platypus co-founder Tony Saputo pleads guilty to defrauding his business partner
      The two co-founders of acclaimed bar Platypus were in federal court Monday—but they were on opposite sides of the courtroom. Anthony “Tony” Saputo was there to enter a guilty plea. Meredith Barry was there as the victim…
  - (2026-08-25) [St. Louis] City won’t release some texts to Don Roe, saying they are ‘privileged communications’
      The St. Louis City Planning and Urban Design Agency won’t release Don Roe’s mystery texts, assuming those texts exist at all. For over a week now, there’s been a guessing game among City Hall watchers regarding which sup…
  - (2026-08-25) [St. Louis] OpsCompanion is building fences in the ‘Wild West’ of artificial intelligence
      Kenneth Eversole holds a bit of a rare perspective when it comes to artificial intelligence. The CEO and co-founder of OpsCompanion, a St. Louis-based AI-focused startup, doesn’t parrot the same unrelenting hype about th…

### U.S. Weather + Severe / Climate Outlooks — 131 new of 133 total
  - (2026-08-26) [Severe] Special Marine Warning: Special Marine Warning issued August 26 at 5:21AM EDT until August 26 at 5:45AM EDT by NWS Key West FL
      SMWKEY The National Weather Service in Key West has issued a * Special Marine Warning for... Straits of Florida from Ocean Reef to Craig Key 20 to 60 nm out... * Until 545 AM EDT. * At 521 AM EDT, a strong thunderstorm w…
  - (2026-08-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-26) [Severe] Special Marine Warning: Special Marine Warning issued August 26 at 5:13AM EDT until August 26 at 5:45AM EDT by NWS Miami FL
      SMWMFL The National Weather Service in Miami has issued a * Special Marine Warning for... Waters from Deerfield Beach to Ocean Reef FL from 20 to 60 NM excluding the territorial waters of Bahamas... * Until 545 AM EDT. *…
  - (2026-08-26) [Moderate] Heat Advisory: Heat Advisory issued August 26 at 2:11AM PDT until August 26 at 9:00PM PDT by NWS Spokane WA
      * WHAT...High temperatures 97 to 102F in the Lewiston-Clarkston Valley resulting in moderate to locally major HeatRisk. * WHERE...Culdesac, Lapwai, Clarkston, Lewiston, and Peck. * WHEN...Until 9 PM PDT this evening. * I…
  - (2026-08-26) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 26 at 2:02AM MST until August 29 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with high temperatures ranging between 104 to 111 degrees and low temperatures 79 to 85 degrees. Major to Extreme HeatRisk today through Saturday. * WHERE...Pinal County, Tohono O'odha…
  - (2026-08-26) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 26 at 2:02AM MST until August 29 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with temperatures 98 to 105 degrees expected. Overnight lows 71 to 78 degrees. Major HeatRisk is expected today through Saturday with isolated Extreme HeatRisk. * WHERE...Eastern Cochi…

### State Legislative Action — 72 new of 92 total
  - (2026-08-26) [Alaska SB 140] An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
      An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
  - (2026-08-26) [Alaska HB 1] An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
      An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
  - (2026-08-26) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-08-26) [Alaska SB 104] An Act relating to the transfer of a title on the death of the owner; relating to the transferability of common interest community ownership interests; and providing for an effective d…
      An Act relating to the transfer of a title on the death of the owner; relating to the transferability of common interest community ownership interests; and providing for an effective date.
  - (2026-08-26) [Alaska HB 193] An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training…
      An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training program account; relating to unempl…
  - (2026-08-26) [Alaska HB 138] An Act establishing a behavioral health crisis services surcharge; establishing the behavioral health crisis services fund; and providing for an effective date.
      An Act establishing a behavioral health crisis services surcharge; establishing the behavioral health crisis services fund; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 56 new of 112 total
  - (2026-08-26) МЗС Росії викликало повірену Румунії | LEDE: ] (uk: МЗС Росії викликало повірену Румунії)
  - (2026-08-26) За допомогу з отриманням фейкової інвалідності затримали екснардепа | LEDE: Двом мешканцям Миколаєва, один з яких колишній народний депутат, повідомили про підозру в отриманні грошей від військ] (uk:…
      Двом мешканцям Миколаєва, один з яких колишній народний депутат, повідомили про підозру в отриманні грошей від військовозобов'язаного за допомогу у вирішенні питання відстрочки від мобілізації.
  - (2026-08-26) Зеленський: Сили оборони за добу уразили 16 об'єктів у РФ, зокрема ракетний підрозділ та аеродроми | LEDE: За добу українські військові уразили 16 об'єктів на території Росії, зокрема нафтову і] (uk:…
      За добу українські військові уразили 16 об'єктів на території Росії, зокрема нафтову інфраструктуру, аеродроми, ракетний підрозділ, військове підприємство та об'єкти логістики, які РФ використовує для ведення війни проти…
  - (2026-08-26) За Мудру вже внесли частину застави: адвокат не назвав, хто дав гроші | LEDE: Адвокат повідомив, що за ексзаступницю ОП Ірину Мудру внесли частину застави. Точна сума і заставодавці — не розгол] (uk:…
      Адвокат повідомив, що за ексзаступницю ОП Ірину Мудру внесли частину застави. Точна сума і заставодавці — не розголошуються.
  - (2026-08-26) Операція "Рубікон": силовики вилучили наркотиків і прекурсорів на понад 540 млн грн | LEDE: В Україні завершили спецоперацію "Рубікон": вилучено наркотиків та прекурсорів на 540 млн грн, ліквід] (uk:…
      В Україні завершили спецоперацію "Рубікон": вилучено наркотиків та прекурсорів на 540 млн грн, ліквідовано 42 нарколабораторії.
  - (2026-08-26) Окупанти повторно вдарили по Чернігову: 4 постраждалих, під завалами можуть бути люди | LEDE: У Чернігові росіяни повторно вдарили по складу: поранено двох, під завалами можуть залишатися люди.] (uk:…
      У Чернігові росіяни повторно вдарили по складу: поранено двох, під завалами можуть залишатися люди.

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 55 total
  - (2026-08-26) [The Hacker News] INTERPOL Operation Jackal IV Arrests 58, Identifies 263 in Global Cyber Fraud Crackdown
      An eight-month INTERPOL operation targeting West African organized crime groups has led to arrests of 58 people and the identification of 263 suspects. "The operation, which brought together 22 countries from six contine…
  - (2026-08-26) [The Hacker News] Newly SLEEPWALKER Backdoor Waits for One Crafted Packet, Then Runs Its Own Bytecode
      An independent malware researcher has documented a previously unreported Windows backdoor, dubbed SLEEPWALKER, that stays inert in memory until a specifically crafted network packet reaches the machine and then runs comm…
  - (2026-08-26) [The Hacker News] Critical Gitea RCE Actively Exploited as Reported Attack Drops Miner-Like Payload
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Tuesday warned of active exploitation efforts targeting a recently patched critical security flaw impacting Gitea. The vulnerability in question is CVE-…
  - (2026-08-26) [The Hacker News] Fake Apple Support AI Calls Target Stolen-Device Owners for Passcodes and 2FA Codes
      Cybersecurity researchers have disclosed details of a phishing-as-a-service (PhaaS) platform built to strip Apple's Activation Lock from stolen devices, using rented AI voice agents that call theft victims posing as Appl…
  - (2026-08-26) [The Register] Debian polls its developers on whether to burn the bots, tame the bots, or let 'em loose
      Eight-way ballot on AI code puts the distro's fractious democracy through its paces
  - (2026-08-26) [The Register] Sopra Steria's £370M Capita spat heads for 2028 courtroom showdown
      French SI still crying foul over shared services contract, alleges bid was 42% under DWP's own cost model

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-26) [Schaffner Brian Paul] Form 4 (Reporting)
      filed 2026-08-26 01:57 UTC · role: Reporting — Filed: 2026-08-25 AccNo: 0001903596-26-000324 Size: 5 KB
  - (2026-08-26) [Expion Energy, Inc.] Form 4 (Issuer)
      filed 2026-08-26 01:57 UTC · role: Issuer — Filed: 2026-08-25 AccNo: 0001903596-26-000324 Size: 5 KB
  - (2026-08-26) [Expion Energy, Inc.] Form 4 (Issuer)
      filed 2026-08-26 01:57 UTC · role: Issuer — Filed: 2026-08-25 AccNo: 0001903596-26-000323 Size: 13 KB
  - (2026-08-26) [Shum Steve] Form 4 (Reporting)
      filed 2026-08-26 01:57 UTC · role: Reporting — Filed: 2026-08-25 AccNo: 0001903596-26-000323 Size: 13 KB
  - (2026-08-26) [Expion Energy, Inc.] Form 4 (Issuer)
      filed 2026-08-26 01:56 UTC · role: Issuer — Filed: 2026-08-25 AccNo: 0001903596-26-000322 Size: 13 KB
  - (2026-08-26) [Lefevre George] Form 4 (Reporting)
      filed 2026-08-26 01:56 UTC · role: Reporting — Filed: 2026-08-25 AccNo: 0001903596-26-000322 Size: 13 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 30 new of 60 total
  - (2026-08-25) U.S. Court of Appeals, 11th Cir.: Schrade Jones v. USA
  - (2026-08-25) U.S. Court of Appeals, 11th Cir.: Jane Doe v. Carnival Corporation
  - (2026-08-25) U.S. Court of Appeals, 11th Cir.: Jeremy Ellis v. Sheriff, Hillsborough County Florida
  - (2026-08-25) U.S. Court of Appeals, 11th Cir.: Jonathan Michael Burton v. Dr. G. Espino
  - (2026-08-25) U.S. Court of Appeals, 5th Cir.: Black v. Unibank
  - (2026-08-25) U.S. Court of Appeals, 5th Cir.: United States v. Luna

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-26) PUMA58 (Slovenia)
      icao24: 506e1d · position: (45.9492, 15.4556) · alt: 1341m · 217km/h
  - (2026-08-26) PUMA22 (Slovenia)
      icao24: 506e1c · position: (45.9558, 15.4878) · alt: 609m · 158km/h
  - (2026-08-26) CFC2978 (Canada)
      icao24: c2b585 · position: (57.7224, 13.638) · alt: 7383m · 410km/h
  - (2026-08-26) RCH277 (United States)
      icao24: ae08e3 · position: (53.3713, -1.0122) · alt: 6111m · 756km/h
  - (2026-08-26) KAF3210 (Kuwait)
      icao24: 7061f6 · position: (35.6555, 22.2925) · alt: 6705m · 547km/h
  - (2026-08-26) JAF6YV (Belgium)
      icao24: 44d1ba · position: (43.4315, -1.726) · alt: 10972m · 964km/h

### Paper Trading Scorecard — 23 new of 133 total
  - (2026-08-26) [Polymarket] Will SPD win the most seats in the 2026 Mecklenburg-Vorpommern parliamentary elections?
      Parliamentary elections to elect the Landtag of Mecklenburg-Vorpommern are scheduled to take place on September 20, 2026. This market will resolve to the political party that wins the greatest number of seats in the stat…
  - (2026-08-26) [Polymarket] Trump meets with Putin by December 31?
      This market will resolve to "Yes" if Donald Trump meets with Vladimir Putin between market creation and the listed date, 11:59 PM ET. Otherwise, this market will resolve to "No". A meeting is defined as any encounter whe…
  - (2026-08-26) [Polymarket] Will Tom Cotton win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-08-26) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-08-26) [Manifold] Will Eva Marie Saint be alive for all of 2026?
  - (2026-08-26) [Manifold] Will Iran strike anything before October 2026?

### U.S. Federal Action — 21 new of 25 total
  - (2026-08-26) Presidential Determination on Provision of Atomic Information to Finland and Sweden
  - (2026-08-26) List of Approved Spent Fuel Storage Casks: TN Americas, LLC Standardized NUHOMS® Horizontal Modular Storage System for Irradiated Nuclear Fuel, Certificate of Compliance No. 1004, Renewed Amendment No…
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its spent fuel regulations by revising the TN Americas, LLC Standardized NUHOMS[supreg] Horizontal Modular Storage System for Irradiated Nuclear Fuel lis…
  - (2026-08-26) List of Approved Spent Fuel Storage Casks: TN Americas, LLC Standardized NUHOMS® Horizontal Modular Storage System for Irradiated Nuclear Fuel, Certificate of Compliance No. 1004, Renewed Amendment No…
      The U.S. Nuclear Regulatory Commission (NRC) is amending its spent fuel storage regulations by revising the TN Americas, LLC Standardized NUHOMS[supreg] Horizontal Modular Storage System for Irradiated Nuclear Fuel listi…
  - (2026-08-26) Critical Position Pay Authority
      The Office of Personnel Management (OPM) is amending its regulations governing the critical position pay (CPP) authority to establish level I of the Executive Schedule as the default maximum critical pay rate, with highe…
  - (2026-08-26) Loan Performance Categories and Financial Reporting
      The Farm Credit Administration (FCA, we, or our) amends our regulatory high-risk loan performance categories by removing "Formally restructured loans (TDR)," also known as troubled debt restructurings. In 2022, changes i…
  - (2026-08-26) International Trademark Classification Changes
      The United States Patent and Trademark Office (USPTO) issues this final rule to incorporate classification changes adopted by the Nice Agreement Concerning the International Classification of Goods and Services for the P…

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-08-25) M 5.5 - south of the Fiji Islands
      M5.5 · south of the Fiji Islands · depth 528.283 km
  - (2026-08-25) M 5.2 - 243 km SE of Hihifo, Tonga
      M5.2 · 243 km SE of Hihifo, Tonga · depth 10 km
  - (2026-08-25) M 5.0 - 54 km NNE of Ruteng, Indonesia
      M5.0 · 54 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-25) M 4.9 - 47 km NE of Ruteng, Indonesia
      M4.9 · 47 km NE of Ruteng, Indonesia · depth 9.418 km
  - (2026-08-25) M 4.9 - 94 km W of Ambon, Indonesia
      M4.9 · 94 km W of Ambon, Indonesia · depth 10 km
  - (2026-08-26) M 4.8 - 147 km E of Miyako, Japan
      M4.8 · 147 km E of Miyako, Japan · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-26) LoL: KT Rolster vs HANJIN BRION - Game 1 Winner
      yes price: 100% · 24h volume: $1,253,356 · resolves 2026-08-26
  - (2026-08-26) Strait of Hormuz traffic returns to normal by September 30?
      yes price: 10% · 24h volume: $850,336 · resolves 2026-09-30
  - (2026-08-26) Counter-Strike: Aurora Gaming vs G2 (BO3) - BLAST Open Porto Group A
      yes price: 48% · 24h volume: $820,372 · resolves 2026-08-26
  - (2026-08-26) LoL: KT Rolster vs HANJIN BRION (BO5) - LCK Play-In
      yes price: 90% · 24h volume: $471,786 · resolves 2026-08-26
  - (2026-08-26) Will Real Madrid CF win on 2026-08-26?
      yes price: 76% · 24h volume: $357,568 · resolves 2026-08-26
  - (2026-08-26) Strait of Hormuz traffic returns to normal by December 31?
      yes price: 38% · 24h volume: $333,200 · resolves 2026-12-31

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 102 total
  - (2026-08-20) [OFAC] Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions - Office of Fore…
      Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-08-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 62 Authorizing Negotiation - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 62 Authorizing Negotiation Office of Foreign Assets Control (.gov)
  - (2026-08-26) [USASpending] $2,533,788,480 → ASSOCIATION OF UNIVERSITIES FOR RESEARCH IN ASTRONOMY, INC.: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT INCLUDE THE FI
      Agency: National Aeronautics and Space Administration. Description: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT INCLUDE THE FINAL SERVICING MISSION AND SUBSEQUENT OPERATIONS THROUGH END-OF-MISSION. THESE ACTIVITIES INC…
  - (2026-08-26) [USASpending] $1,611,506,001 → BATTELLE SAVANNAH RIVER ALLIANCE, LLC: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING
      Agency: Department of Energy. Description: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING (M&O) CONTRACT
  - (2026-08-26) [USASpending] $1,336,720,376 → THE BOEING COMPANY: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS
      Agency: National Aeronautics and Space Administration. Description: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS
  - (2026-08-26) [USASpending] $1,238,659,207 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-26) [Marginal Revolution] Overreaching causal language in the social sciences
      Across the social sciences, many studies use cross-sectional designs that reveal associations but are generally unable to support direct causal claims, yet authors of such articles may make or imply causal claims anyway.…
  - (2026-08-26) [Marginal Revolution] Emergent Ventures winners, 58th cohort
      Jethro Elsden, London area, to study the regulatory structure of the UK using AI. Paula Benedetti, Buenos Aires, marine biology work in Brazil. Nyida Gyal, 17, northern Virginia, AI and data. Gabe Sekeres, Cornell, what…
  - (2026-08-25) [Marginal Revolution] Dolly Parton, RIP
      The post Dolly Parton, RIP appeared first on Marginal REVOLUTION.

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 11 total
  - (2026-08-25) CVE-2026-60004 · Gitea Gitea: Gitea Code Injection Vulnerability
      vendor: Gitea · product: Gitea · CISA remediation by 2026-08-28

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=19, 14d-median=20; carrying terms: action, national, establishing, navigable, management, proposes, establish, within, certain, proposed, coast, public
- state_bills: today=92, 7d-median=118, 14d-median=129; carrying terms: issue, district, employees, notify, persons, service, corporation, violence, request, defined, until, provision
- state_news: today=700, 7d-median=597, 14d-median=585; carrying terms: presidential, prison, srcset, possible, called, though, measure, illinois, cities, status, cameras, release
- local_news: today=255, 7d-median=238, 14d-median=235; carrying terms: morning, family, crash, being, found, center, people, county, driver, trump, murder, camera
- foreign_news: today=1041, 7d-median=1023, 14d-median=1002; carrying terms: presidential, xuejun, statement, syria, tasks, called, takes, measure, spokesperson, communist, changsha, setting
- chinese_internal: today=289, 7d-median=284, 14d-median=280; carrying terms: lxtfa, china, people, market, cbmizefvx, cbmiykfvx, cbmibefvx, caixin, blank, google, cbmibkfvx, cbmidefvx
- russian_internal: today=1174, 7d-median=1030, 14d-median=1030; carrying terms: wildberries, novaya, client, reuters, error, blank, target, gazeta, journal, europe, httperror, politico
- ukrainian_internal: today=112, 7d-median=114, 14d-median=109; carrying terms: nearly, censor, error, black, babel, overnight, europe, allies, three, ahead, hmarochos, offensive
- ukraine_theater: today=841, 7d-median=880, 14d-median=945; carrying terms: cuxnbi, ngodfxy, zocum, syria, additional, vkhqr, mxjjeng, hyuzbxeuw, cuxoeulwwvlvbgzhzetbtkflvmdszfzun, stmnmr, cxvyy, meftwfh
- paper_bets: today=133, 7d-median=133, 14d-median=139; carrying terms: virginia, achieved, presidential, leaders, polymarket, special, playoff, israel, rippling, theme, remain, erupt
- weather: today=133, 7d-median=144, 14d-median=159; carrying terms: afdmeg, statement, mount, additional, illnesses, special, tampa, southern, hills, heatrisk, possible, include
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: energy, nonfarm, crude, vixcls, money, labor, payrolls, pcepilfe, growth, treasury, cpiaucsl, funds
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: futures, crude, bitcoin, proxy, corporate, natural, agriculture, credit, silver, large, russell, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=102, 7d-median=101, 14d-median=96; carrying terms: embargo, areas, controlled, middle, syria, agreement, square, against, hfufrmmg, involvement, bissau, administration
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, congresstrading, quantitative, client, httperror, error, quiverquant, unauthorized, quiver
- billionaires: today=0, 7d-median=30, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, court, supreme, appeals, connecticut, america, general, attorney, california, delaware, arizona, washington
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, holdings, robert, david, richard, ronald, francisco
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: alexandria, committee, graham, michael, james, raised, platner, trone, ocasio, shawn, krishnamoorthi, cooper
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense, china
- gdelt_gkg: today=0, 7d-median=25, 14d-median=33; carrying terms: english, trump, keywords, themes, russian, ukrainian, russia, sanctions, spanish, perimeter, business, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, ground, germany, canada, spain
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: early, contact, regarding, areas, bloody, unusual, institut, exposure, middle, operator, increasing, bangladesh
- cisa_kev: today=11, 7d-median=12, 14d-median=10; carrying terms: function, remediation, microsoft, injection, product, vendor, command, vulnerability, authentication, missing, project, service
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=315, 14d-median=315
- usgs_quakes: today=14, 7d-median=19, 14d-median=19; carrying terms: indonesia, depth, ruteng, islands, japan, russia, region, south, tonga, vanuatu, labuan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: interest, price, meeting, donetsk, resolves, shakhtar, champions, winner, volume, september, rates, league
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, conversable, marginal, https, economist, class, wrote, conversableeconomist, impossible, around, point, because
- tech_news: today=55, 7d-median=55, 14d-median=55; carrying terms: still, hackers, bleepingcomputer, called, schneier, around, computer, review, companies, computerweekly, systems, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: delaney, valerie, virginia, carey, rollins, fulcher, michael, sonderling, communications, delia, blumenthal, sheri
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, decision, either, sufficient, markets, market, paper, evidence, identify, consensus, placed, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*