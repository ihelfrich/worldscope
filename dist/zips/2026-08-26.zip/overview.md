# WORLDSCOPE morning brief — 2026-08-26

## Headline
3589 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (742) · Russian Internal News (state + in-exile) (725) · Ukraine Theater (total-war monitoring) (553) · World leaders & government officials (324) · State-Level News (312) · Chinese Internal News (243) · Local News: St. Louis + Atlanta (197) · U.S. Weather + Severe / Climate Outlooks (130) · State Legislative Action (84) · Ukrainian Internal News (national + local Kyiv) (50) · IT, InfoSys & cybersecurity news (last 7 days) (44) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 742 new of 1030 total
  - (2026-08-26) [Global] Premier League: Cameroon's Carlos Baleba transferred to Manchester United
      Cameroonian midfielder Carlos Baleba has moved from Brighton to Manchester United for around 75 million euros.
  - (2026-08-26) [Global] Middle East live: Iran says Hormuz strait still closed despite transit corridor talks with Oman
      Tehran warned on Wednesday that the Strait of Hormuz will remain closed unless the United States ends the war, despite discussions with Oman on a temporary transit corridor in the vital waterway. Washington had earlier a…
  - (2026-08-26) [Global] Iceland to vote on reopening EU membership talks in close referendum
      Icelanders will vote in a referendum on Saturday whether to resume entry talks with the European Union amid growing global insecurity. Voters are not being asked to decide just yet if they want to join the 27-member bloc…
  - (2026-08-26) [Global] Trump sends Saudi civil nuclear agreement to Congress for review
      US President Donald Trump has submitted a civilian nuclear cooperation agreement with Saudi Arabia to Congress for review, an administration official said. The classified pact, sent to Capitol Hill on Monday, is aimed at…
  - (2026-08-26) [Global] SpaceX to build $100 billion rocket launch facility in southern Louisiana
      SpaceX unveiled plans on Tuesday for a $100 billion rocket launch complex in southern Louisiana, its largest yet, aimed at supporting Starship and AI satellite missions. The 125,000-acre Starbase Louisiana site on Pecan…
  - (2026-08-25) [Global] Oil prices fall for second day as US shifts from Iran strikes to sanctions
      Oil prices fell for a second straight day on Tuesday as traders saw a reduced risk of renewed US military strikes on Iran after Washington instead threatened broader economic sanctions. Treasury Secretary Scott Bessent d…

### Russian Internal News (state + in-exile) — 725 new of 1140 total
  - (2026-08-26) В дополнении к игре «Ведьмак 3» не будет русской озвучки | LEDE: В дополнении к игре «Ведьмак 3: Дикая Охота — Баллады прошлого» не будет русской озвучки, объявила польская игровая студия CD] (ru: В д…
      В дополнении к игре «Ведьмак 3: Дикая Охота — Баллады прошлого» не будет русской озвучки, объявила польская игровая студия CD Projekt RED, выпускающая игру.
  - (2026-08-26) «Ведомости»: Леонид Слуцкий может потерять пост главы комитета по международным делам в Госдуме нового созыва | LEDE: В Госдуме нового созыва может смениться глава комитета по международным ] (ru: «Ве…
      В Госдуме нового созыва может смениться глава комитета по международным делам — вместо Леонида Слуцкого из ЛДПР этот пост займет представитель «Единой России».
  - (2026-08-26) Минюст США заявил, что без опыта Трампа Кеннеди-центр придется снести. Ранее суд запретил добавить в название центра имя Трампа | LEDE: Центр исполнительских искусств имени Джона Ф. Кеннеди ] (ru: Мин…
      Центр исполнительских искусств имени Джона Ф. Кеннеди придется снести, если президенту Дональду Трампу не разрешат его сохранить, заявили юристы министерства юстиции США, представляющие центр.
  - (2026-08-26) В результате пожара на Амурском газохимическом комплексе погибли семь человек. Девять граждан Китая пропали без вести | LEDE: При пожаре на строительной площадке готовящегося к запуску Амурс] (ru: В р…
      При пожаре на строительной площадке готовящегося к запуску Амурского газохимического комплекса (АГХК) погибли, по уточненным данным, семь человек: шесть граждан Китая и россиянка, сообщила пресс-служба предприятия. Девят…
  - (2026-08-26) Песков заявил, что директор ЦРУ приезжал в Москву для «контактов между спецслужбами» | LEDE: Директор ЦРУ Джон Рэтклифф приезжал в Москву для «контактов между спецслужбами», сказал пресс-сек] (ru: Пес…
      Директор ЦРУ Джон Рэтклифф приезжал в Москву для «контактов между спецслужбами», сказал пресс-секретарь президента России Дмитрий Песков газете The Washington Post в ответ на вопрос об этом визите.
  - (2026-08-26) Украинские беспилотники атаковали Липецкую область, погибли два человека. В Тамбовской области после удара вновь горит склад Wildberries | LEDE: В Липецком округе в результате атаки украинск] (ru: Укр…
      В Липецком округе в результате атаки украинских беспилотников загорелся частный жилой дом, погибли два человека, сообщил губернатор Липецкой области Игорь Артамонов.

### Ukraine Theater (total-war monitoring) — 553 new of 841 total
  - (2026-08-26) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-25) [FIRMS] thermal anomaly 44.532, 34.130 (FRP 17.68 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1011Z, FRP 17.68 MW
  - (2026-08-25) [FIRMS] thermal anomaly 44.531, 34.125 (FRP 4.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1011Z, FRP 4.97 MW
  - (2026-08-25) [FIRMS] thermal anomaly 44.533, 34.132 (FRP 11.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1011Z, FRP 11.08 MW
  - (2026-08-25) [FIRMS] thermal anomaly 44.532, 34.128 (FRP 10.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1011Z, FRP 10.51 MW
  - (2026-08-25) [FIRMS] thermal anomaly 45.866, 34.224 (FRP 2.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-25 1013Z, FRP 2.89 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 312 new of 681 total
  - (2026-08-26) [California] Governor Newsom announces appointments 8.25.2026
      Source
  - (2026-08-25) [California] Governor, First Partner statement on the passing of Dolly Parton
      Source
  - (2026-08-25) [California] ICYMI: The nation’s economic engine, California, continues to lead in job creation and raising wages
      Source
  - (2026-08-25) [California] California becomes first state to offer same-day and ongoing opioid treatment support
      Source
  - (2026-08-25) [Alabama] Flags Lowered for Dolly Parton
      Download
  - (2026-08-25) [Alabama] Governor Ivey Announces Activation of Statewide Notification System
      MONTGOMERY – Governor Kay Ivey on Tuesday announced the activation of a statewide notification system to more quickly alert the public in the event of floods and other disasters. The action follows the governor’s January…

### Chinese Internal News — 243 new of 285 total
  - (2026-08-25) China’s Advanced Chip Supply to Surge 46% Annually Through 2035, Goldman Says - Caixin Global
      China’s Advanced Chip Supply to Surge 46% Annually Through 2035, Goldman Says Caixin Global
  - (2026-08-26) 今日开盘：沪指报3881.74点 跌幅0.20% - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1YcE9FblloX2dXWlRJMGxMcFZBakgtQnRYM25iQTNPRzlCM2RPcEZNZGFCQzZxSnFPTWFMb0V2SjR1bi1sZU] (zh:…
      今日开盘：沪指报3881.74点 跌幅0.20% Caixin Global
  - (2026-08-25) 最新财新周刊｜AI大调仓 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5qREJQNjI2VEt2MGpaTlZDd3VUN09DbDZ0OENnRVhFOHQ0eVRxOGpJUTFQajhXcjJlMVE1QTQ0MDVOTVJvUTd6dTlMek5IWUVuVlJ4QWl] (zh:…
      最新财新周刊｜AI大调仓 财新周刊
  - (2026-08-24) 最新财新周刊｜自动驾驶关键一跃 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1FOHhvZVZyREZuS01qUnd5RWtvTFFFVVlheDBINnR2Qnk5LXo3aU5xWkE5d0VUYmhaakI3ajJleG50U1RoQUZ4YjVfU25WRWdsbkFZ] (zh:…
      最新财新周刊｜自动驾驶关键一跃 财新周刊
  - (2026-08-24) 最新财新周刊｜婚外冷冻胚胎争议 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9yZVRQU01aQTZTRmRBVF9McVprX2RIUE9FUU53RTdWZEh2Wk1ySGYtU0IyVFVrZXdTS1NOZ1ZnUW93M01aX2lBdWd3dlhSN0tqN1o4] (zh:…
      最新财新周刊｜婚外冷冻胚胎争议 财新周刊
  - (2026-08-25) 最新封面报道｜AI基建：得东南亚者得天下 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBRenNhcmtmRlVyQkVLY2RxMjNuZ1NhdC1TTFBHR1NvRktwNWZ0ZzhYXzNNLW1LNDVqQWFic2I5cl9jb1RkUDlZSkNoNEVlbWt] (zh:…
      最新封面报道｜AI基建：得东南亚者得天下 财新周刊

### Local News: St. Louis + Atlanta — 197 new of 246 total
  - (2026-08-25) [St. Louis] South City favorite Stan’s Bar suffers major fire
      A South City bar described as a second home to many patrons had its insides gutted by a daytime fire. Bystanders say that Stan’s Bar caught fire around noon on Tuesday. Normally, they would have been open at the time. Fo…
  - (2026-08-25) [St. Louis] How to parent your college student without hovering
      For 18 years, parenting often involves keeping track of seemingly everything for your child: scheduling doctor appointments, sharing deadline reminders, and tracking how much clean underwear remains in their dresser. The…
  - (2026-08-25) [St. Louis] Festival of Nations returns to Tower Grove Park this weekend
      Calling the annual Festival of Nations “beloved” doesn’t quite cover it. The annual event, sponsored by the International Institute of St. Louis, has been bringing the world to Tower Grove Park since 1934. People plan th…
  - (2026-08-25) [St. Louis] Platypus co-founder Tony Saputo pleads guilty to defrauding his business partner
      The two co-founders of acclaimed bar Platypus were in federal court Monday—but they were on opposite sides of the courtroom. Anthony “Tony” Saputo was there to enter a guilty plea. Meredith Barry was there as the victim…
  - (2026-08-25) [St. Louis] City won’t release some texts to Don Roe, saying they are ‘privileged communications’
      The St. Louis City Planning and Urban Design Agency won’t release Don Roe’s mystery texts, assuming those texts exist at all. For over a week now, there’s been a guessing game among City Hall watchers regarding which sup…
  - (2026-08-25) [St. Louis] OpsCompanion is building fences in the ‘Wild West’ of artificial intelligence
      Kenneth Eversole holds a bit of a rare perspective when it comes to artificial intelligence. The CEO and co-founder of OpsCompanion, a St. Louis-based AI-focused startup, doesn’t parrot the same unrelenting hype about th…

### U.S. Weather + Severe / Climate Outlooks — 130 new of 134 total
  - (2026-08-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-26) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 26 at 2:34AM CDT until August 26 at 2:45AM CDT by NWS La Crosse WI
      At 234 AM CDT, a severe thunderstorm was located near Muscoda, or 12 miles south of Richland Center, moving southeast at 30 mph. HAZARD...Quarter size hail. SOURCE...Radar indicated. IMPACT...Damage to vehicles is expect…
  - (2026-08-26) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 26 at 2:28AM CDT until August 26 at 3:15AM CDT by NWS Milwaukee/Sullivan WI
      SVRMKX The National Weather Service in Milwaukee/Sullivan has issued a * Severe Thunderstorm Warning for... Northwestern Iowa County in south central Wisconsin... * Until 315 AM CDT. * At 227 AM CDT, a severe thunderstor…
  - (2026-08-26) [Moderate] Special Weather Statement: Special Weather Statement issued August 26 at 2:25AM CDT by NWS La Crosse WI
      At 225 AM CDT, Doppler radar was tracking a strong thunderstorm over Muscoda, or 11 miles south of Richland Center, moving southeast at 30 mph. HAZARD...Wind gusts up to 50 mph and nickel size hail. SOURCE...Radar indica…
  - (2026-08-26) [Moderate] Special Weather Statement: Special Weather Statement issued August 26 at 1:24AM MDT by NWS Cheyenne WY
      At 124 AM MDT, Doppler radar was tracking strong thunderstorms along a line extending from near Wildcat Hills State Recreation Area to near Oliver Reservoir to near Grover to 13 miles north of Purcell. Movement was south…
  - (2026-08-26) [Moderate] Heat Advisory: Heat Advisory issued August 26 at 2:23AM CDT until August 26 at 7:00PM CDT by NWS Houston/Galveston TX
      * WHAT...Heat index values 107 to 112. * WHERE...Portions of south central and southeast Texas. * WHEN...Until 7 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity may cause heat illnesses. * ADDITIONAL…

### State Legislative Action — 84 new of 104 total
  - (2026-08-26) [Alaska SB 140] An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
      An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
  - (2026-08-26) [Alaska HB 1] An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
      An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
  - (2026-08-26) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-08-26) [Alaska SB 104] An Act relating to the transfer of a title on the death of the owner; relating to the transferability of common interest community ownership interests; and providing for an effective d…
      An Act relating to the transfer of a title on the death of the owner; relating to the transferability of common interest community ownership interests; and providing for an effective date.
  - (2026-08-26) [Alaska HB 193] An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training…
      An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training program account; relating to unempl…
  - (2026-08-26) [Alaska HB 138] An Act establishing a behavioral health crisis services surcharge; establishing the behavioral health crisis services fund; and providing for an effective date.
      An Act establishing a behavioral health crisis services surcharge; establishing the behavioral health crisis services fund; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 50 new of 106 total
  - (2026-08-26) Трамп втрачає підтримку американців: що стоїть за падінням рейтингу | LEDE: ] (uk: Трамп втрачає підтримку американців: що стоїть за падінням рейтингу)
  - (2026-08-26) Рейтинг Трампа падатиме, але він не програє. У чому парадокс президента США | LEDE: Рейтинг президента США Дональда Трампа впав до історичного мінімуму – лише 33% опитаних американців схвалюють] (uk:…
      Рейтинг президента США Дональда Трампа впав до історичного мінімуму – лише 33% опитаних американців схвалюють його дії.
  - (2026-08-26) В уряді Іспанії виник скандал через попередження про кризу в Сеуті | LEDE: ] (uk: В уряді Іспанії виник скандал через попередження про кризу в Сеуті)
  - (2026-08-26) В ЄС вперше визнали, що їхні посадовці стали ціллю кібератак "іноземних урядів" – ЗМІ | LEDE: Уперше в ЄС офіційно підтвердили кібератаки іноземних урядів на акаунти чиновників у месенджерах.] (uk: В…
      Уперше в ЄС офіційно підтвердили кібератаки іноземних урядів на акаунти чиновників у месенджерах.
  - (2026-08-26) У Кремлі розповіли, з чим пов’язаний візит глави ЦРУ до Москви | LEDE: Пєсков підтвердив візит глави ЦРУ до Москви для контактів між спецслужбами РФ і США.] (uk: У Кремлі розповіли, з чим пов’язаний в…
      Пєсков підтвердив візит глави ЦРУ до Москви для контактів між спецслужбами РФ і США.
  - (2026-08-26) Армія Фінляндії закупить FPV-дрони для навчань на 14 млн євро | LEDE: ] (uk: Армія Фінляндії закупить FPV-дрони для навчань на 14 млн євро)

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 55 total
  - (2026-08-26) [The Hacker News] Critical Gitea RCE Actively Exploited as Reported Attack Drops Miner-Like Payload
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Tuesday warned of active exploitation efforts targeting a recently patched critical security flaw impacting Gitea. The vulnerability in question is CVE-…
  - (2026-08-26) [The Hacker News] Fake Apple Support AI Calls Target Stolen-Device Owners for Passcodes and 2FA Codes
      Cybersecurity researchers have disclosed details of a phishing-as-a-service (PhaaS) platform built to strip Apple's Activation Lock from stolen devices, using rented AI voice agents that call theft victims posing as Appl…
  - (2026-08-26) [The Register] India’s crewed space program will fly this year, after missing 2022 and 2025 targets
      A space station by 2035 is ISRO’s new mission
  - (2026-08-26) [The Register] Self-hosted email is in steep decline, Microsoft and Google are taking over
      Oh great, Big Tech is now in prime position to decide which messages get through
  - (2026-08-26) [Computer Weekly] CW@60: My computers and me
      On 22 September 2026, Computer Weekly turns 60. To mark the milestone, we asked some of our friends - experts, parliamentarians, IT leaders and suppliers
  - (2026-08-26) [MIT Technology Review] Bill Gates says we’ve passed AI’s danger thresholds. Now what?
      It’s a glorious day in Kirkland, Washington, an affluent Seattle suburb on the eastern shore of Lake Washington. The temperature is in the mid-80s, and the sky is incapable of being any more blue. The view from the Gates…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-26) [Schaffner Brian Paul] Form 4 (Reporting)
      filed 2026-08-26 01:57 UTC · role: Reporting — Filed: 2026-08-25 AccNo: 0001903596-26-000324 Size: 5 KB
  - (2026-08-26) [Expion Energy, Inc.] Form 4 (Issuer)
      filed 2026-08-26 01:57 UTC · role: Issuer — Filed: 2026-08-25 AccNo: 0001903596-26-000324 Size: 5 KB
  - (2026-08-26) [Expion Energy, Inc.] Form 4 (Issuer)
      filed 2026-08-26 01:57 UTC · role: Issuer — Filed: 2026-08-25 AccNo: 0001903596-26-000323 Size: 13 KB
  - (2026-08-26) [Shum Steve] Form 4 (Reporting)
      filed 2026-08-26 01:57 UTC · role: Reporting — Filed: 2026-08-25 AccNo: 0001903596-26-000323 Size: 13 KB
  - (2026-08-26) [Expion Energy, Inc.] Form 4 (Issuer)
      filed 2026-08-26 01:56 UTC · role: Issuer — Filed: 2026-08-25 AccNo: 0001903596-26-000322 Size: 13 KB
  - (2026-08-26) [Lefevre George] Form 4 (Reporting)
      filed 2026-08-26 01:56 UTC · role: Reporting — Filed: 2026-08-25 AccNo: 0001903596-26-000322 Size: 13 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 29 new of 60 total
  - (2026-08-25) U.S. Court of Appeals, 9th Cir.: County of King v. Turner
  - (2026-08-25) U.S. Court of Appeals, 10th Cir.: United States v. Phillips
  - (2026-08-25) U.S. Court of Appeals, 10th Cir.: United States v. Barker
  - (2026-08-25) Connecticut Supreme Court: Lasa Extract, LLC v. Zoning Board of Appeals
  - (2026-08-25) Connecticut Supreme Court: State v. Sellers
  - (2026-08-25) Delaware Supreme Court: Sheadrick Richards v. Shipwright SPAC I, LLC

### Government & military aircraft airborne (OpenSky) — 26 new of 26 total
  - (2026-08-26) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (42.8467, -4.6577) · alt: 10972m · 957km/h
  - (2026-08-26) JAF3LC (Bulgaria)
      icao24: 4520aa · position: (41.1098, 6.2905) · alt: 10972m · 956km/h
  - (2026-08-26) PAT322 (United States)
      icao24: adfe51 · position: (38.6759, -77.5212) · alt: 563m · 304km/h
  - (2026-08-26) GAF433 (Germany)
      icao24: 3ea653 · position: (50.8216, 6.6286) · alt: 563m · 257km/h
  - (2026-08-26) SAMU05 (France)
      icao24: 39ca81 · position: (44.6324, 6.0702) · alt: 1562m · 227km/h
  - (2026-08-26) FAF7813 (France)
      icao24: 39a858 · position: (46.491, 0.1923) · alt: 2034m · 285km/h

### Paper Trading Scorecard — 22 new of 133 total
  - (2026-08-26) [Polymarket] Will Julian Alvarez join Arsenal?
      This market will resolve to the next team Julian Alvarez officially joins by September 1, 2026, 11:59 PM ET. If Julian Alvarez does not officially join a new team by September 1, 2026, 11:59 PM ET, this market will resol…
  - (2026-08-26) [Polymarket] Trump meets with Putin by December 31?
      This market will resolve to "Yes" if Donald Trump meets with Vladimir Putin between market creation and the listed date, 11:59 PM ET. Otherwise, this market will resolve to "No". A meeting is defined as any encounter whe…
  - (2026-08-26) [Polymarket] Will Tom Cotton win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-08-26) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-08-26) [Polymarket] Will the Washington Commanders win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-08-26) [Manifold] Will Iran strike anything before October 2026?

### USGS earthquakes (M4.5+, past day) — 13 new of 14 total
  - (2026-08-25) M 5.5 - south of the Fiji Islands
      M5.5 · south of the Fiji Islands · depth 528.283 km
  - (2026-08-25) M 5.2 - 243 km SE of Hihifo, Tonga
      M5.2 · 243 km SE of Hihifo, Tonga · depth 10 km
  - (2026-08-25) M 5.0 - 54 km NNE of Ruteng, Indonesia
      M5.0 · 54 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-25) M 4.9 - 47 km NE of Ruteng, Indonesia
      M4.9 · 47 km NE of Ruteng, Indonesia · depth 9.418 km
  - (2026-08-25) M 4.9 - 94 km W of Ambon, Indonesia
      M4.9 · 94 km W of Ambon, Indonesia · depth 10 km
  - (2026-08-26) M 4.8 - 147 km E of Miyako, Japan
      M4.8 · 147 km E of Miyako, Japan · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-26) Strait of Hormuz traffic returns to normal by September 30?
      yes price: 12% · 24h volume: $890,098 · resolves 2026-09-30
  - (2026-08-26) Chicago Cubs vs. Arizona Diamondbacks
      yes price: 87% · 24h volume: $636,953 · resolves 2026-09-02
  - (2026-08-26) Cleveland Guardians vs. Los Angeles Angels
      yes price: 34% · 24h volume: $493,224 · resolves 2026-09-02
  - (2026-08-26) US announces end of Iranian blockade by September 30, 2026?
      yes price: 40% · 24h volume: $347,890 · resolves 2026-10-01
  - (2026-08-26) Strait of Hormuz traffic returns to normal by December 31?
      yes price: 38% · 24h volume: $335,808 · resolves 2026-12-31
  - (2026-08-26) Will Tucker Carlson win the 2028 Republican presidential nomination?
      yes price: 3% · 24h volume: $300,794 · resolves 2028-11-07

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 102 total
  - (2026-08-20) [OFAC] Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions - Office of Fore…
      Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-08-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 62 Authorizing Negotiation - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 62 Authorizing Negotiation Office of Foreign Assets Control (.gov)
  - (2026-08-26) [USASpending] $2,533,788,480 → ASSOCIATION OF UNIVERSITIES FOR RESEARCH IN ASTRONOMY, INC.: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT INCLUDE THE FI
      Agency: National Aeronautics and Space Administration. Description: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT INCLUDE THE FINAL SERVICING MISSION AND SUBSEQUENT OPERATIONS THROUGH END-OF-MISSION. THESE ACTIVITIES INC…
  - (2026-08-26) [USASpending] $1,611,506,001 → BATTELLE SAVANNAH RIVER ALLIANCE, LLC: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING
      Agency: Department of Energy. Description: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING (M&O) CONTRACT
  - (2026-08-26) [USASpending] $1,336,720,376 → THE BOEING COMPANY: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS
      Agency: National Aeronautics and Space Administration. Description: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS
  - (2026-08-26) [USASpending] $1,238,659,207 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-26) [Marginal Revolution] Overreaching causal language in the social sciences
      Across the social sciences, many studies use cross-sectional designs that reveal associations but are generally unable to support direct causal claims, yet authors of such articles may make or imply causal claims anyway.…
  - (2026-08-26) [Marginal Revolution] Emergent Ventures winners, 58th cohort
      Jethro Elsden, London area, to study the regulatory structure of the UK using AI. Paula Benedetti, Buenos Aires, marine biology work in Brazil. Nyida Gyal, 17, northern Virginia, AI and data. Gabe Sekeres, Cornell, what…
  - (2026-08-25) [Marginal Revolution] Dolly Parton, RIP
      The post Dolly Parton, RIP appeared first on Marginal REVOLUTION.

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 11 total
  - (2026-08-25) CVE-2026-60004 · Gitea Gitea: Gitea Code Injection Vulnerability
      vendor: Gitea · product: Gitea · CISA remediation by 2026-08-28

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=19, 14d-median=19; carrying terms: proposes, proposed, establish, action, certain, national, specifically, airworthiness, management, navigable, model, service
- state_bills: today=104, 7d-median=118, 14d-median=129; carrying terms: provision, known, order, enforcement, application, others, prescribed, purposes, administered, licensure, safety, agency
- state_news: today=681, 7d-median=597, 14d-median=591; carrying terms: since, third, amendment, against, enforcement, opinion, though, management, fight, others, release, indiana
- local_news: today=246, 7d-median=238, 14d-median=232; carrying terms: driver, family, children, arrested, blank, district, taken, suspect, woman, another, charged, atlanta
- foreign_news: today=1030, 7d-median=1023, 14d-median=1004; carrying terms: climbed, since, third, photos, trust, known, delegation, against, traffic, fiercely, driver, approach
- chinese_internal: today=285, 7d-median=284, 14d-median=280; carrying terms: cbmix, cbmixkfvx, blank, cbmibkfvx, cbmickfvx, cbmizkfvx, cbmib, cbmiaefvx, politics, cbmiw, caixin, https
- russian_internal: today=1140, 7d-median=1030, 14d-median=1035; carrying terms: journal, istories, street, title, error, media, gazeta, times, novayagazeta, wildberries, client, telegram
- ukrainian_internal: today=106, 7d-median=114, 14d-median=108; carrying terms: least, civilian, against, assessment, volodymyr, update, security, support, government, month, hromadske, including
- ukraine_theater: today=841, 7d-median=880, 14d-median=985; carrying terms: delegat, hftwzpbdi, zjlxofbtlwdbbjdkue, ujkznknfzw, known, ugvhdvpumzz, delegation, tlzacujyrndwlw, maintenance, dszjc, ntrhym, assessment
- paper_bets: today=133, 7d-median=133, 14d-median=137; carrying terms: world, human, jpmorgan, least, lifetime, rippling, congress, presidential, headline, speaker, majors, israel
- weather: today=134, 7d-median=144, 14d-median=162; carrying terms: detroit, minor, include, mount, likely, valley, particularly, participating, unknown, monitoring, north, updated
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: payems, pcepilfe, treasury, vixcls, crude, dexuseu, assets, walcl, dexchus, commodities, dcoilwtico, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, large, rates, treasury, futures, close, natural, crude, credit, range, crypto, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=102, 7d-median=101, 14d-median=96; carrying terms: transactions, human, science, tiananmen, crimea, enable, latinscript, nonprofit, services, proliferation, order, imposed
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, unauthorized, quiver, quiverquant, client, https, quantitative, httperror
- billionaires: today=0, 7d-median=30, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: company, supreme, appeals, state, court, connecticut, james, center, america, general, california, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, holdings, robert, david, francisco, richard, ronald
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: warner, raised, james, receipts, robert, lindsey, cortez, johnson, trone, filing, sherrod, ocasio
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, china, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=41; carrying terms: english, trump, keywords, russian, themes, ukrainian, sanctions, perimeter, russia, spanish, business, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=30, 14d-median=30; carrying terms: position, belgium, ground, france, germany, kingdom, bulgaria, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: symptom, fatal, additi, world, human, among, ventilation, traceability, leste, since, rwampara, dicale
- cisa_kev: today=11, 7d-median=12, 14d-median=10; carrying terms: vendor, microsoft, command, remediation, authentication, product, function, injection, vulnerability, missing, project, broadcom
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=315, 14d-median=315
- usgs_quakes: today=14, 7d-median=19, 14d-median=18; carrying terms: indonesia, depth, ruteng, islands, japan, region, south, tonga, vanuatu, labuan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, meeting, interest, august, championship, volume, september, shakhtar, rates, donetsk, resolves, champions
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, revolution, https, marginal, economist, conversable, conversableeconomist, wrote, impossible, point, around, writing
- tech_news: today=55, 7d-median=55, 14d-median=56; carrying terms: world, spectrum, known, breach, security, vulnerability, government, including, digital, bleepingcomputer, computer, august
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: components, chicago, aguilar, jefferson, nydia, cisneros, nellie, senior, cohen, letlow, danny, stefanik
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, decision, either, consensus, markets, evidence, today, identify, unavailable, paper, module, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*