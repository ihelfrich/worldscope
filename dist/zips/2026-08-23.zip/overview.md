# WORLDSCOPE morning brief — 2026-08-23

## Headline
3112 new items across 22 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (923) · International News + Multilateral Institutions (606) · Russian Internal News (state + in-exile) (517) · World leaders & government officials (324) · Chinese Internal News (181) · U.S. Weather + Severe / Climate Outlooks (135) · Local News: St. Louis + Atlanta (118) · State-Level News (88) · State Legislative Action (59) · Ukrainian Internal News (national + local Kyiv) (46) · Sanctions & Designations (recent) (30) · Prediction Markets — most-traded (Polymarket) (14)

## What changed today
### Ukraine Theater (total-war monitoring) — 923 new of 1144 total
  - (2026-08-22) [FIRMS] thermal anomaly 46.644, 33.189 (FRP 14.26 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-22 0930Z, FRP 14.26 MW
  - (2026-08-22) [FIRMS] thermal anomaly 47.172, 34.670 (FRP 20.89 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-22 0930Z, FRP 20.89 MW
  - (2026-08-22) [FIRMS] thermal anomaly 47.170, 34.663 (FRP 14.12 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-22 0930Z, FRP 14.12 MW
  - (2026-08-22) [FIRMS] thermal anomaly 47.314, 34.843 (FRP 3.26 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-22 0930Z, FRP 3.26 MW
  - (2026-08-22) [FIRMS] thermal anomaly 47.312, 34.837 (FRP 3.26 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-22 0930Z, FRP 3.26 MW
  - (2026-08-22) [FIRMS] thermal anomaly 47.265, 34.368 (FRP 7.3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-22 0930Z, FRP 7.3 MW

### International News + Multilateral Institutions — 606 new of 972 total
  - (2026-08-23) [Global] Infantino defies FIFA vice president, makes appearance in the Caribbean
      FIFA boss turns up at event after CONCACAF chief Montagliani asked him to reconsider amid the body’s governance crisis.
  - (2026-08-23) [Global] Serena Williams teams up with Carlos Alcaraz in US Open mixed doubles
      The 23-time Grand Slam champion will not be playing singles, but could team up with her older sister Venus for doubles.
  - (2026-08-23) [Global] Starc takes 10 as Australia hand Bangladesh innings defeat in second Test
      Australia bounce back after losing first Test, bowling out the visitors for 64 and 95 to win by an innings and 51 runs.
  - (2026-08-23) [Global] Pegula dethrones Swiatek to book Cincinnati final against Gauff
      The women’s all-American final will be followed by a men's title clash between Frances Tiafoe and Arthur Fils of France.
  - (2026-08-23) [Global] Kazakhstan parliamentary elections begin: What’s at stake?
      The Central Asian country heads to the polls on August 23.
  - (2026-08-23) [Global] Ex-Colombian president: Restoring Israeli ties applauds Gaza genocide
      Ex-Colombian President, Gustavo Petro, says restoring ties with Israel amounts to applauding the Gaza genocide.

### Russian Internal News (state + in-exile) — 517 new of 856 total
  - (2026-08-23) Скоро в школу! Эта мысль вызывает у вас ужас и тревогу? У нас есть множество инструкций, которые помогут справиться с самыми разными проблемами. Вот краткий пересказ этих текстов | LEDE: Ког] (ru: Ско…
      Когда ребенок идет в школу, родители сталкиваются с большим количеством тревог. А вдруг его будут травить? А вдруг он сам будет травить? А вдруг их заставят плести маскировочные сети для российских военных? Или убедят в…
  - (2026-08-23) В Казахстане начались парламентские выборы. Их проводят впервые после принятия новой Конституции | LEDE: В Казахстане 23 августа началось голосование на выборах депутатов однопалатного парла] (ru: В К…
      В Казахстане 23 августа началось голосование на выборах депутатов однопалатного парламента — курултая. Парламентские выборы в республике проходят впервые после вступления 1 июля в силу новой Конституции.
  - (2026-08-23) Украинские дроны атаковали второй склад Ozon — в Оренбурге | LEDE: Украинские военные в ночь на 23 августа вновь нанесли удар по складу Ozon — атакован логистический комплекс этого маркетпле] (ru: Укр…
      Украинские военные в ночь на 23 августа вновь нанесли удар по складу Ozon — атакован логистический комплекс этого маркетплейса в Оренбурге.
  - (2026-08-22) Суд в США отменил запрет Госдепа на выдачу иммиграционных виз гражданам 75 стран (в том числе России) | LEDE: Федеральный суд штата Нью-Йорк признал незаконным и отменил решение Государствен] (ru: Суд…
      Федеральный суд штата Нью-Йорк признал незаконным и отменил решение Государственного департамента о запрете на выдачу иммиграционных виз гражданам 75 стран, в том числе России.
  - (2026-08-22) В США в 101 год умер Фрэнсис Клиффорд Смит. Он отбыл самый долгий срок заключения в американской истории — более 70 лет — и восемь раз избежал смертной казни. Смит всегда настаивал на своей нев] (ru:…
      Фрэнсис Клиффорд Смит — бывший заключенный, отбывший, вероятно, самый длительный тюремный срок в истории США — умер в возрасте 101 года. Он скончался во сне в конце июня в специализированном центре для бывших заключенных…
  - (2026-08-22) Цель Киева — нанести ущерб нашей экономике и логистике. Они сами выпустили джинна из бутылки. Получите ответ. Путин — об ударах Украины по России. Кратчайший пересказ | LEDE: Россия нарастил] (ru: Цел…
      Россия нарастила удары по Украине в ответ на украинскую 40-дневную «операцию влияния». ВСУ наносили массированные удары по российским гражданским объектам и логистике. Но для Украины конечный результат оказался прямо про…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 181 new of 251 total
  - (2026-08-22) 最新财新周刊｜自动驾驶关键一跃 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1FOHhvZVZyREZuS01qUnd5RWtvTFFFVVlheDBINnR2Qnk5LXo3aU5xWkE5d0VUYmhaakI3ajJleG50U1RoQUZ4YjVfU25WRWdsbkFZ] (zh:…
      最新财新周刊｜自动驾驶关键一跃 财新周刊
  - (2026-08-22) 最新财新周刊｜破产重整投资人怎么选 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1fYWRQR1lkTUNmUU14NDQ0UzgyMUVnOFlMNXdKem5NazFoTTJMck54bzBDRElQem44cGtIb0dOWHZ1STZoN2JrY2NpaXY3R1o4WX] (zh:…
      最新财新周刊｜破产重整投资人怎么选 财新周刊
  - (2026-08-22) 陈燕妮：睡列侬他们睡过的床｜纪行 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5WdVBhV0I5djNIVzYxOWVuYWtXWC1pWGQxOGhCdmdYbGFFQ3VOeXlfWWZsd3U3cl9XUVNneHI4V3hRV0dvNkhlYXpwc2VCcWg0Mmotc] (zh:…
      陈燕妮：睡列侬他们睡过的床｜纪行 财新
  - (2026-08-22) 最新财新周刊｜婚外冷冻胚胎争议 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9yZVRQU01aQTZTRmRBVF9McVprX2RIUE9FUU53RTdWZEh2Wk1ySGYtU0IyVFVrZXdTS1NOZ1ZnUW93M01aX2lBdWd3dlhSN0tqN1o4] (zh:…
      最新财新周刊｜婚外冷冻胚胎争议 财新周刊
  - (2026-08-22) 南京银行2026年上半年利息净收入高增40% 原因何在？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9uSnRfMHVfM3JENGt0dUJiUFhlcW1fMXY5Z0hqVkNxLUlrYmFndXVpdGJtS3Uzbms1UXhjdVFDRWs3aTVXNTlzT2tzd] (zh:…
      南京银行2026年上半年利息净收入高增40% 原因何在？ 财新
  - (2026-08-22) 美加关税磋商最后关头流局 美国新关税即时生效 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9nN1pJdzVUUGdKX2VVbzFDMW1ZNkpZclltSFc0c25CM3BaY3NTc25mOGdEWC1tTHBsd0VLV0Rjb25PQ2luV0VucHBTTm0wdFF] (zh:…
      美加关税磋商最后关头流局 美国新关税即时生效 财新

### U.S. Weather + Severe / Climate Outlooks — 135 new of 141 total
  - (2026-08-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-23) [Severe] Special Marine Warning: Special Marine Warning issued August 23 at 3:27AM EDT until August 23 at 4:30AM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Tarpon Springs to Suwannee River FL out 20 NM... * Until 430 AM EDT. * At 325 AM EDT, a strong thunderstorm w…
  - (2026-08-23) [Moderate] Heat Advisory: Heat Advisory issued August 23 at 3:27AM AST until August 23 at 4:00PM AST by NWS San Juan PR
      * WHAT...This level of heat affects most individuals sensitive to heat, especially those without effective cooling and/or adequate hydration. expected. * WHERE...Portions of Puerto Rico and Virgin Islands. * WHEN...From…
  - (2026-08-23) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 23 at 12:26AM PDT until August 23 at 12:30AM PDT by NWS Spokane WA
      The storm which prompted the warning has weakened below severe limits, and has exited the warned area. Therefore, the warning will be allowed to expire.
  - (2026-08-23) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 23 at 3:22AM EDT until August 24 at 12:00AM EDT by NWS Gaylord MI
      * WHAT...Dangerous swimming conditions. Waves as high as 5 to 8 feet. * WHERE...Emmet, Presque Isle, Leelanau, Antrim, Alpena, Benzie, Manistee and Charlevoix Counties, and Beaver Island and surrounding islands. * WHEN..…
  - (2026-08-23) [Severe] Special Marine Warning: Special Marine Warning issued August 23 at 3:19AM EDT until August 23 at 5:15AM EDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Coastal waters from Suwannee River to Keaton Beach out 20 NM... * Until 515 AM EDT. * At 319 AM EDT, a strong thunderstorm w…

### Local News: St. Louis + Atlanta — 118 new of 228 total
  - (2026-08-23) [St. Louis] Survivor of North St. Louis County house explosion turns recovery into inspiration through sneaker ball
      5 On Your Side's Melanie Johnson hosted the event on Friday that highlighted Anthony's recovery and celebrated others making a difference in the community.
  - (2026-08-23) [St. Louis] Viral curbside futon photo fuels panhandling debate in St. Louis County
      A viral photo of a futon set up on a St. Louis County curb is fueling debate as leaders pass a new ordinance targeting aggressive panhandling.
  - (2026-08-23) [St. Louis] Idaho woman swims solo across the English Channel: 'It just sounded like such an epic challenge'
      Christine Turpin became one of just 2,100 people and the first ever from her home state to accomplish the feat.
  - (2026-08-23) [St. Louis] Hawaii braces for Tropical Storm Moke, but cleanup from Hurricane Lala is just beginning
      Tropical Storm Moke advanced toward Hawaii on Saturday, likely bringing more heavy rainfall and strong gusts to the Big Island.
  - (2026-08-23) [St. Louis] Buffalo Bills offer condolences, support to defensive tackle Ed Oliver following death of his 2-year-old son
      “It’s an unthinkable tragedy for any parent. We will continue to support Ed and his family as we grieve this tragic loss,” Bills general manager Brandon Beane said.
  - (2026-08-23) [St. Louis] Foodies Eat First Festival brings St. Louis food scene, community together
      Organizers say food is a powerful way to bring people together and celebrate the city's story.

### State-Level News — 88 new of 399 total
  - (2026-08-22) [California] Governor Newsom signs legislation 8.22.2026
  - (2026-08-21) [Alaska] Governor Dunleavy and Alaska’s Congressional Delegation Welcome Trump Administration’s Historic Investment in Rural Ferry Program
      Aug. 21, 2026 (Anchorage, AK) – Today Governor Mike Dunleavy announced that the Trump Administration has awarded more than $410 million to support the Alaska Marine Highway System with key resources targeted for rural So…
  - (2026-08-22) [Delaware] Photo Gallery: Dover struck by tornado
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/08/Dover-Tornado-Superlodge-2.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-08-22) [Arkansas] USDA wants to revive the cotton industry. Experts aren’t sure that’s possible.
      A denim-clad rancher poses on horseback, crimson-red shirt against a hazy blue sky. A farmer in a T-shirt stands surrounded by his crop, leaves bending toward weathered hands. “Real Americans wear cotton,” reads bold tex…
  - (2026-08-22) [Arkansas] Experts skewer new Trump administration analysis claiming 24,000 noncitizens voted in 2020
      This article was originally published by Votebeat, a nonprofit news organization covering local election administration and voting access. President Donald Trump this week unveiled another effort by his administration to…
  - (2026-08-22) [Arkansas] Trump’s court workarounds push limits but are within legal bounds, experts say
      WASHINGTON — President Donald Trump has not slowed his pursuit of central policy goals and personal passions, even after major setbacks at the U.S. Supreme Court and other federal courts. The high court in its 2026 term…

### State Legislative Action — 59 new of 100 total
  - (2026-08-22) [California AB 280] Health care coverage: provider directories.
      Existing law, the Knox-Keene Health Care Service Plan Act of 1975, provides for the licensure and regulation of health care service plans by the Department of Managed Health Care, and makes a willful violation of the act…
  - (2026-08-22) [California AB 1707] Electricians: certification application, examination, and renewal.
      Existing law establishes the Division of Labor Standards Enforcement, under the direction of the Labor Commissioner, within the Department of Industrial Relations, for the purpose of enforcing labor laws. Existing law re…
  - (2026-08-22) [California AB 2030] Dietary supplements for weight loss and over-the-counter diet pills.
      Existing law regulates the safety of various consumer products, including, among other things, specific additives in foods, chemicals in products for young children, and lead in tableware. This bill would prohibit a pers…
  - (2026-08-22) [California AB 2212] Postsecondary education: sexual harassment, harassment, intimidation, and bullying policies: student training.
      The Equity in Higher Education Act provides, among other things, that all students have the right to participate fully in the educational process, free from discrimination and harassment. Existing law provides that sexua…
  - (2026-08-22) [California AB 2253] Solid waste: products: recycled content claims.
      Existing law requires a manufacturer or supplier making an environmental marketing claim relating to the recycled content of a plastic food container product to maintain specified information and documentation in written…
  - (2026-08-22) [California AB 2439] Common Interest Developments: governing documents: assessments.
      Existing law, the Davis-Stirling Common Interest Development Act, governs the management and operation of common interest developments. Existing law limits the authority of the governing documents, as defined, to regulat…

### Ukrainian Internal News (national + local Kyiv) — 46 new of 109 total
  - (2026-08-23) Прем'єри Естонії та Норвегії у Києві наголосили на підтримці України | LEDE: ] (uk: Прем'єри Естонії та Норвегії у Києві наголосили на підтримці України)
  - (2026-08-23) Реактивний "Шахед" влучив у пасажирський поїзд на Одещині – УЗ | LEDE: На Одещині дрон РФ влучив у локомотив поїзда Житомир–Одеса. Постраждалих немає, пасажирів вчасно евакуювали.] (uk: Реактивний "Ша…
      На Одещині дрон РФ влучив у локомотив поїзда Житомир–Одеса. Постраждалих немає, пасажирів вчасно евакуювали.
  - (2026-08-23) У Норвегії через страйк авіадиспетчерів скасували майже 150 рейсів | LEDE: ] (uk: У Норвегії через страйк авіадиспетчерів скасували майже 150 рейсів)
  - (2026-08-23) РФ запустила 127 безпілотників, є влучання та падіння на 25 локаціях – ПС | LEDE: У ніч на 23 серпня Росія атакувала Україну 127 безпілотниками різних типів, зафіксовано влучання та падіння ула] (uk:…
      У ніч на 23 серпня Росія атакувала Україну 127 безпілотниками різних типів, зафіксовано влучання та падіння уламків на 25 локаціях.
  - (2026-08-23) Депутат: У Львові стався вибух в аптеці, є загиблий | LEDE: У Львові вибухнула аптека на Тракті Глинянському, загинув аптекар. Причини встановлюються.] (uk: Депутат: У Львові стався вибух в аптеці, є…
      У Львові вибухнула аптека на Тракті Глинянському, загинув аптекар. Причини встановлюються.
  - (2026-08-23) У Сербії заговорили про зміну конституції для нового балотування Вучича | LEDE: ] (uk: У Сербії заговорили про зміну конституції для нового балотування Вучича)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-08-23) Dota 2: TEAM VISION vs Team Spirit (BO5) - The International Playoffs
      yes price: 38% · 24h volume: $7,083,577 · resolves 2026-08-23
  - (2026-08-23) Dota 2: TEAM VISION vs Team Spirit - Game 1 Winner
      yes price: 0% · 24h volume: $2,015,943 · resolves 2026-08-23
  - (2026-08-23) Will Josh Stein win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $712,149 · resolves 2028-11-07
  - (2026-08-23) Will Liverpool FC win on 2026-08-23?
      yes price: 48% · 24h volume: $491,158 · resolves 2026-08-23
  - (2026-08-23) Will TEAM VISION Win The International 2026?
      yes price: 38% · 24h volume: $424,600
  - (2026-08-23) Will Ethereum dip to $1,000 by December 31, 2026?
      yes price: 6% · 24h volume: $395,247 · resolves 2027-01-01

### Government & military aircraft airborne (OpenSky) — 13 new of 14 total
  - (2026-08-23) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (44.8103, -1.0753) · alt: 10980m · 930km/h
  - (2026-08-23) JAF76T (Bulgaria)
      icao24: 4520aa · position: (44.399, -1.3883) · alt: 10972m · 924km/h
  - (2026-08-23) SAMU44 (France)
      icao24: 39ca84 · position: (47.3359, -1.0662) · alt: 480m · 279km/h
  - (2026-08-23) JAF62J (Belgium)
      icao24: 44d1a5 · position: (37.9458, 26.0731) · alt: 10759m · 836km/h
  - (2026-08-23) RCH160 (United States)
      icao24: ae080e · position: (18.6665, 119.7439) · alt: 10668m · 842km/h
  - (2026-08-23) RCH244 (United States)
      icao24: ae1449 · position: (52.3264, 3.6108) · alt: 10058m · 856km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 54 total
  - (2026-08-23) [TechCrunch] Two years after launch, Walmart’s Flipkart is closing in on India’s quick-commerce leaders
      Flipkart's quick-commerce venture is delivering 1.1 million to 1.2 million orders a day, nearly triple its November volume.
  - (2026-08-22) [BleepingComputer] Hackers infect Android car head units with proxy botnet malware
      A supply-chain attack targeting Android-based car head units is using a legitimate device-update app to spread malware that enlists compromised devices in a proxy botnet or uses them for ad fraud. [...]
  - (2026-08-22) [BleepingComputer] Named Pipes Under Attack: Securing Windows Interprocess Communication
      Windows named pipes provide fast interprocess communication, but weak access controls can expose privileged services to untrusted processes. ThreatLocker explains how endpoint verification, command authorization, strict…
  - (2026-08-22) [The Hacker News] TikTok Agrees to $400 Million Settlement in U.S. Child Privacy Lawsuit
      The U.S. Department of Justice (DoJ) announced on Friday that ByteDance-owned TikTok will pay $400 million to settle a 2024 lawsuit accusing the company of violating child privacy laws in the country. As part of the sett…
  - (2026-08-22) [The Register] If you're not using AI to attack your own systems, your adversaries will
      Agents are also the new attack surface - cue defenders' existential angst
  - (2026-08-22) [The Register] AI slop is good for business if you know what you're doing
      Your irresponsibility is someone else's opportunity

### Paper Trading Scorecard — 11 new of 130 total
  - (2026-08-23) [Polymarket] 0 ships transit Hormuz on any date by August 31?
      This market will resolve to “Yes” if IMF PortWatch publishes a daily number of transit calls (“Arrivals of Ships”) for the Strait of Hormuz equal to 0 for any date between market creation and the specified date, 2026. Ot…
  - (2026-08-23) [Polymarket] Will Gold (GC) hit (HIGH) $6,000 by end of December?
      This market will resolve to "Yes" if, on any trading day, the official CME settlement price for the Active Month (front month) of Gold (GC) futures is equal to or above the listed price by the final trading day of Decemb…
  - (2026-08-23) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-08-23) [Manifold] Democrats win Alaska and Michigan US Senate elections in 2026?
  - (2026-08-23) [Manifold] Will Tadej Pogacar hold the red jersey for the entire 2026 Vuelta a Espana?
  - (2026-08-23) [Manifold] Coca-Cola's 2026 Christmas Commercial Substantially AI Generated?

### USGS earthquakes (M4.5+, past day) — 10 new of 14 total
  - (2026-08-22) M 5.8 - 4 km N of Toride, Japan
      M5.8 · 4 km N of Toride, Japan · depth 61 km
  - (2026-08-22) M 4.9 - 78 km S of Gorontalo, Indonesia
      M4.9 · 78 km S of Gorontalo, Indonesia · depth 116.29 km
  - (2026-08-22) M 4.7 - 170 km SW of Sungai Penuh, Indonesia
      M4.7 · 170 km SW of Sungai Penuh, Indonesia · depth 26.342 km
  - (2026-08-23) M 4.6 - 273 km E of Levuka, Fiji
      M4.6 · 273 km E of Levuka, Fiji · depth 571.282 km
  - (2026-08-23) M 4.6 - 26 km E of Letpandan, Burma (Myanmar)
      M4.6 · 26 km E of Letpandan, Burma (Myanmar) · depth 10 km
  - (2026-08-22) M 4.6 - 32 km NNE of Calama, Chile
      M4.6 · 32 km NNE of Calama, Chile · depth 105.494 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 37 total
  - (2026-08-23) MOVER ▲ Changpeng Zhao — $112.83B (+$1.16B since yesterday)
      Canada · Finance & Investments · source: Cryptocurrency exchange
  - (2026-08-23) MOVER ▼ Dieter Schwarz — $63.84B ($-0.69B since yesterday)
      Germany · Fashion & Retail · source: Retail
  - (2026-08-23) MOVER ▲ Germán Larrea Mota Velasco & family — $73.19B (+$0.17B since yesterday)
      Mexico · Metals & Mining · source: Mining
  - (2026-08-23) MOVER ▼ Amancio Ortega — $149.32B ($-0.14B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-23) MOVER ▼ Bernard Arnault & family — $141.98B ($-0.13B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-23) MOVER ▲ Carlos Slim Helu & family — $124.35B (+$0.12B since yesterday)
      Mexico · Telecom · source: Telecom

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-23) [South Korea] Why is BOK buying gold again ?
      koreaherald.com · English
  - (2026-08-23) [South Korea] Kakao spin - off plan faces lingering investor distrust
      koreatimes.co.kr · English
  - (2026-08-23) [South Korea] Seoul cultural facilities to extend nighttime opening starting September
      koreaherald.com · English
  - (2026-08-23) [South Korea] Seoul to connect local medical providers with overseas buyers
      koreaherald.com · English
  - (2026-08-23) [South Korea] Regaining pounds after weight loss medication linked to 4 - fold rise in suicidal thoughts : study
      koreatimes.co.kr · English
  - (2026-08-23) [South Korea] Kakao Talk message reader was disabled for days , inconveniencing visually impaired users
      koreaherald.com · English

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-08-21) U.S. Court of Appeals, 4th Cir.: Christopher Billesdon v. Wells Fargo Securities, LLC
  - (2026-08-20) U.S. Court of Appeals, 10th Cir.: United States v. Kahn
  - (2026-08-20) U.S. Court of Appeals, 4th Cir.: Central Appalachian Coal Company v. DOWCP
  - (2026-08-20) U.S. Court of Appeals, 4th Cir.: Fareed Hayat v. Casey Diaz
  - (2026-08-20) U.S. Court of International Trade: Inspired Ventures, LLC v. United States

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-23) [Marginal Revolution] My recent visit to Anthropic
      I very recently participated in a two-day session to offer guidance on rewriting the constitution for Claude. The small group invited was uniformly excellent, we received serious time with key decision-makers, and the di…
  - (2026-08-23) [Marginal Revolution] The new agentic O-ring world
      But because agents often require guidance or additional context as they move through their tasks, Sharma, 27, finds himself wanting to be available to them around the clock and forgoing a regular sleep schedule as a resu…
  - (2026-08-22) [Marginal Revolution] Has the European turnaround finally arrived?
      Europe just had its best reporting season in years. Companies in the benchmark Stoxx Europe 600 index boosted earnings per share by 18% on average in the second quarter compared with a year earlier. Earnings barely grew…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=15, 14d-median=20; carrying terms: proposing, national, establish, proposes, action, proposed, certain, public, within, service, coast, establishing
- state_bills: today=100, 7d-median=134, 14d-median=129; carrying terms: prescribed, university, forth, governor, provided, adopt, district, general, employees, employee, persons, business
- state_news: today=399, 7d-median=597, 14d-median=597; carrying terms: districts, university, early, nebraska, uploads, oregon, employees, request, current, being, democratic, billion
- local_news: today=228, 7d-median=235, 14d-median=230; carrying terms: killed, taken, district, murder, being, missouri, woman, atlanta, falcons, camera, morning, charles
- foreign_news: today=972, 7d-median=978, 14d-median=1007; carrying terms: bouteflika, university, coalition, progress, brand, beneath, greener, overseas, enough, scene, disaster, improved
- chinese_internal: today=251, 7d-median=284, 14d-median=271; carrying terms: politics, cbmiaefvx, cbmibefvx, cbmib, google, people, cbmiw, color, blank, global, cbmizefvx, chinese
- russian_internal: today=856, 7d-median=1030, 14d-median=1040; carrying terms: europe, politico, istories, reuters, times, novayagazeta, title, https, russian, target, wildberries, httperror
- ukrainian_internal: today=109, 7d-median=109, 14d-median=109; carrying terms: killed, europe, foreign, officials, latest, energy, cabinet, general, refinery, zelensky, border, russian
- ukraine_theater: today=1144, 7d-median=887, 14d-median=1001; carrying terms: killed, dvnht, yuvevtdvmnppmu, rfjyckzranluc, rvlotmwwum, zuwwnor, euhnyvbtvwttvg, bahrain, coalition, ektxwhblafvut, cuxpnkuxv, ntounjuwc
- paper_bets: today=130, 7d-median=135, 14d-median=135; carrying terms: zohran, fuentes, drought, virginia, chair, nebraska, governor, prime, pirates, openai, michigan, district
- weather: today=141, 7d-median=159, 14d-median=177; carrying terms: afdokx, short, early, activities, atlantic, central, northeast, counties, white, afdlsx, oregon, above
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: implied, cpiaucsl, unrate, jtsjol, inflation, commodities, treasury, latest, unemployment, consumption, effective, vixcls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: futures, close, large, proxy, credit, yield, nasdaq, natural, crude, crypto, equities, range
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=100, 7d-median=95, 14d-median=96; carrying terms: sudan, annexation, authorities, related, rights, niger, company, resolutions, destabilisation, usaspending, myanmar, activities
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, https, httperror, quantitative, quiver, quiverquant, congresstrading, client, unauthorized
- billionaires: today=37, 7d-median=34, 14d-median=34; carrying terms: infrastructure, huang, retail, tesla, alice, nasdaq, madrid, mining, fashion, mukesh, spain, family
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: company, state, supreme, appeals, court, connecticut, trust, international, trade, america, general, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed, holdings, management, partners, michael, technology
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: committee, james, cycle, elect, lindsey, cooper, booker, michael, disbursements, trone, warner, shawn
- gdelt_regions: today=6, 7d-median=6, 14d-median=12; carrying terms: english, korea, south, koreaherald, seoul
- gdelt_gkg: today=0, 7d-median=41, 14d-median=31; carrying terms: english, trump, israel, hezbollah, keywords, netanyahu, israeli, benjamin, attacks, military, india, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=14, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: health, addition, previously, leste, confined, investigations, authorities, brands, negative, related, mongbwalu, initiated
- cisa_kev: today=12, 7d-median=10, 14d-median=9; carrying terms: vulnerability, firewall, authentication, remediation, product, command, secure, injection, vendor, cisco, ancillary, defense
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=300, 14d-median=300
- usgs_quakes: today=14, 7d-median=21, 14d-median=18; carrying terms: depth, indonesia, islands, ruteng, japan, levuka, mexico, northern
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: september, champions, resolves, shakhtar, league, interest, championship, august, winner, donetsk, price, volume
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, class, conversable, marginal, https, economist, conversableeconomist, impossible, marginalrevolution, wrote, writing, because
- tech_news: today=54, 7d-median=56, 14d-median=56; carrying terms: models, microsoft, target, infrastructure, techcrunch, called, hacker, society, world, weekly, agents, companies
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jimmy, moolenaar, howard, stauber, courtney, stefanik, carol, maloy, dingell, alsobrooks, newhouse, angus
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, placed, converges, claude, decision, today, module, either, sufficient, market, markets, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*