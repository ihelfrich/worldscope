# WORLDSCOPE morning brief — 2026-08-23

## Headline
3284 new items across 22 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (931) · International News + Multilateral Institutions (640) · Russian Internal News (state + in-exile) (539) · World leaders & government officials (324) · Chinese Internal News (189) · U.S. Weather + Severe / Climate Outlooks (133) · Local News: St. Louis + Atlanta (109) · State Legislative Action (96) · State-Level News (92) · Ukrainian Internal News (national + local Kyiv) (54) · GDELT GKG — themes / entities / watch areas (50) · Sanctions & Designations (recent) (30)

## What changed today
### Ukraine Theater (total-war monitoring) — 931 new of 1144 total
  - (2026-08-23) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-21) [Liveuamap] Death toll of Russian strike at the shopping mall in Kryvyi Rih increased to 15 killed, 130 wounded - Liveuamap
      Death toll of Russian strike at the shopping mall in Kryvyi Rih increased to 15 killed, 130 wounded <font color="#6f6
  - (2026-08-22) [Liveuamap] Drones have attacked Ozon warehouses in Chapaevsk, Samara region - Liveuamap
      Drones have attacked Ozon warehouses in Chapaevsk, Samara region Liveuamap
  - (2026-08-20) [Liveuamap] Explosions were reported near Feodosiya, Crimea - Liveuamap
      Explosions were reported near Feodosiya, Crimea Liveuamap
  - (2026-08-20) [Liveuamap] Qalibaf: The Strait of Hormuz will not be opened until the United States meets Iran's demands. - iran.liveuamap.com
      Qalibaf: The Strait of Hormuz will not be opened until the United States meets Iran's demands. <font c
  - (2026-08-20) [Liveuamap] Yemeni Armed Forces: Houthis targeted residential areas and displaced persons camps in Marib - Liveuamap
      Yemeni Armed Forces: Houthis targeted residential areas and displaced persons camps in Marib <font

### International News + Multilateral Institutions — 640 new of 976 total
  - (2026-08-23) [Global] Israeli wounded in occupied West Bank stabbing
      Israeli forces launch wide search in Jordan Valley after a stabbing incident in the occupied West Bank village of al-Auja.
  - (2026-08-23) [Global] Flooding across Caracas, Venezuela, after heavy rains
      Flooding across Caracas, Venezuela, after heavy rains
  - (2026-08-23) [Global] Photos: Russia celebrates National Flag Day amid war and tensions with the West
      Participants in St Petersburg honour Russia’s tricolour with patriotic events and ribbon distributions across the city.
  - (2026-08-23) [Global] DR Congo, M23 rebels agree on roadmap for peace talks
      Roadmap sets out steps, timelines for talks to end fighting that has killed thousands and displaced millions.
  - (2026-08-23) [Global] Kazakhstan holds parliamentary election expected to cement president’s grip
      Only state-approved parties loyal to President Tokayev permitted to take part amid a sweeping constitutional overhaul.
  - (2026-08-23) [Global] Infantino defies FIFA vice president, makes appearance in the Caribbean
      FIFA boss turns up at event after CONCACAF chief Montagliani asked him to reconsider amid the body’s governance crisis.

### Russian Internal News (state + in-exile) — 539 new of 873 total
  - (2026-08-23) 12 немецких церквей принимают биеннале «Манифеста». В одном храме играют в баскетбол, в другой висит ковер с изображением намаза, в третьей — турецкий амулет. Закат Европы, не иначе! Сейчас рас] (ru:…
      В Рурской области на западе Германии идет «Манифеста» — кочующая биеннале современного искусства. Выставка стартовала в июне и продлится до 10 октября. Нынешняя, 16-я «Манифеста» — юбилейная: ее проводят уже 30 лет в раз…
  - (2026-08-23) В Москве полиция устроила рейд в клубе Simach. Одного из посетителей, по словам очевидцев, ударили электрошокером | LEDE: Полиция в ночь на 23 августа устроила рейд в московском клубе-рестор] (ru: В М…
      Полиция в ночь на 23 августа устроила рейд в московском клубе-ресторане «Simach в Недальнем».
  - (2026-08-23) В Харькове восемь человек пострадали в результате удара российского дрона | LEDE: Российские войска в ночь на 23 августа атаковали дронами Харьков. В результате попадания беспилотника в жило] (ru: В Х…
      Российские войска в ночь на 23 августа атаковали дронами Харьков. В результате попадания беспилотника в жилой дом в Основянском районе пострадали семь человек, в том числе 79-летняя женщина, сообщил глава областной админ…
  - (2026-08-23) Скоро в школу! Эта мысль вызывает у вас ужас и тревогу? У нас есть множество инструкций, которые помогут справиться с самыми разными проблемами. Вот краткий пересказ этих текстов | LEDE: Ког] (ru: Ско…
      Когда ребенок идет в школу, родители сталкиваются с большим количеством тревог. А вдруг его будут травить? А вдруг он сам будет травить? А вдруг их заставят плести маскировочные сети для российских военных? Или убедят в…
  - (2026-08-23) В Казахстане начались парламентские выборы. Их проводят впервые после принятия новой Конституции | LEDE: В Казахстане 23 августа началось голосование на выборах депутатов однопалатного парла] (ru: В К…
      В Казахстане 23 августа началось голосование на выборах депутатов однопалатного парламента — курултая. Парламентские выборы в республике проходят впервые после вступления 1 июля в силу новой Конституции.
  - (2026-08-23) Украинские дроны атаковали второй склад Ozon — в Оренбурге | LEDE: Украинские военные в ночь на 23 августа вновь нанесли удар по складу Ozon — атакован логистический комплекс этого маркетпле] (ru: Укр…
      Украинские военные в ночь на 23 августа вновь нанесли удар по складу Ozon — атакован логистический комплекс этого маркетплейса в Оренбурге.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 189 new of 250 total
  - (2026-08-21) DeepSeek Enters the Multimodal AI Race with Experimental Vision Model - Caixin Global
      DeepSeek Enters the Multimodal AI Race with Experimental Vision Model Caixin Global
  - (2026-08-23) 责编：金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxPUW9Lam5mcjNZNEJDRmhJRVdQSmozVlk2MnR2bHA3cm00UDkwWGZnNm1uaW0zSy00alg3ZkFEQ2tmUkpzdW5XUF91W] (zh:…
      责编：金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-08-21) 青海省民宗委以跨省研学深化“三项计划” 有形有感有效铸牢中华民族共同体意识 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5LSWtjLUhueXppUVU3ODZHZjEwSkgzb055ZkFkbFZTNzc5bzNmQ3hKZVVJQy03Y183aUJ6Z1p0QW1rVlp] (zh:…
      青海省民宗委以跨省研学深化“三项计划” 有形有感有效铸牢中华民族共同体意识 人民网
  - (2026-08-22) 甘肃合作： 油菜花开引客来 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFA1Q3ptNXhzQjBoOVhsRkdCV0lqQmwtS2tIX3Yxbnk2XzU5QVViOUxKRHlmMUlSY21yVHZxUHFOeUx6TWxYcUNKQkFWX1JyaV84VkppMn] (zh:…
      甘肃合作： 油菜花开引客来 人民图片
  - (2026-08-23) 四川安岳： 成渝中线高铁挑灯夜战铺轨忙 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9CNGwzN1hyVFh4VHBNSktpQkQxUnJQRnh2emtSLWtEUnkwS0hJYW1fWlpSYmZYNzQxbFJpX2xvVnlCSEN5SjNBUGk4NTFBTGNl] (zh:…
      四川安岳： 成渝中线高铁挑灯夜战铺轨忙 人民图片
  - (2026-08-23) 山东烟台： 桨板逐浪展风采 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFBucVBLQm9fZ0ZWZkQ5YmVhSmM5Z1UxQmhQNlRoWXF0TUxnN2xEZkVWZTFHS0o5Z3VUaEJBQkhkd2NIbFlxTTNTWGZYbldLTFUxOHU1dl] (zh:…
      山东烟台： 桨板逐浪展风采 人民图片

### U.S. Weather + Severe / Climate Outlooks — 133 new of 135 total
  - (2026-08-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-23) [Moderate] Special Weather Statement: Special Weather Statement issued August 23 at 5:15AM EDT by NWS Caribou ME
      Patchy dense fog is expected through 8AM this morning. Visibility one quarter to one half mile at times. If traveling, remain alert for rapid changes in visibility and allow extra following distance. In order to make you…
  - (2026-08-23) [Severe] Special Marine Warning: Special Marine Warning issued August 23 at 5:14AM EDT until August 23 at 7:15AM EDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Coastal waters from Suwannee River to Keaton Beach out 20 NM... Waters from Suwannee River to Apalachicola FL from 20 to 60…
  - (2026-08-23) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 23 at 2:10AM MST until August 29 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with high temperatures ranging between 103 to 111 degrees and low temperatures 79 to 85 degrees. Major HeatRisk is expected through Tuesday and then widespread Major to Extreme HeatRis…
  - (2026-08-23) [Severe] Flash Flood Warning: Flash Flood Warning issued August 23 at 5:07AM EDT until August 23 at 8:00AM EDT by NWS Mount Holly NJ
      At 507 AM EDT, Thunderstorms that produced heavy rain resulted in 1 to 2 inches of rain. While the rain has ended, flash flooding is ongoing or expected to begin shortly. HAZARD...Flash flooding caused by thunderstorms.…
  - (2026-08-23) [Severe] Flash Flood Warning: Flash Flood Warning issued August 23 at 4:56AM EDT until August 23 at 7:45AM EDT by NWS Mount Holly NJ
      At 456 AM EDT, Thunderstorms produced heavy rain in the warned area, with flash flooding reported in Chester. Between 1 and 2 inches of rain have fallen. While the heavy rain has ended, flash flooding is occurring. HAZAR…

### Local News: St. Louis + Atlanta — 109 new of 218 total
  - (2026-08-23) [St. Louis] Survivor of north St. Louis County home explosion turns recovery into inspiration through sneaker ball
      5 On Your Side's Melanie Johnson hosted the event Friday, highlighting Anthony's recovery and celebrating others making a difference in the community.
  - (2026-08-23) [St. Louis] Viral curbside futon photo fuels panhandling debate in St. Louis County
      A viral photo of a futon set up on a St. Louis County curb is fueling debate as leaders pass a new ordinance targeting aggressive panhandling.
  - (2026-08-23) [St. Louis] Idaho woman swims solo across the English Channel: 'It just sounded like such an epic challenge'
      Christine Turpin became one of just 2,100 people and the first ever from her home state to accomplish the feat.
  - (2026-08-23) [St. Louis] Hawaii braces for Tropical Storm Moke, but cleanup from Hurricane Lala is just beginning
      Tropical Storm Moke advanced toward Hawaii on Saturday, likely bringing more heavy rainfall and strong gusts to the Big Island.
  - (2026-08-23) [St. Louis] Buffalo Bills offer condolences, support to defensive tackle Ed Oliver following death of his 2-year-old son
      “It’s an unthinkable tragedy for any parent. We will continue to support Ed and his family as we grieve this tragic loss,” Bills general manager Brandon Beane said.
  - (2026-08-23) [St. Louis] Foodies Eat First Festival brings St. Louis food scene, community together
      Organizers say food is a powerful way to bring people together and celebrate the city's story.

### State Legislative Action — 96 new of 137 total
  - (2026-08-22) [California AB 280] Health care coverage: provider directories.
      Existing law, the Knox-Keene Health Care Service Plan Act of 1975, provides for the licensure and regulation of health care service plans by the Department of Managed Health Care, and makes a willful violation of the act…
  - (2026-08-22) [California AB 1707] Electricians: certification application, examination, and renewal.
      Existing law establishes the Division of Labor Standards Enforcement, under the direction of the Labor Commissioner, within the Department of Industrial Relations, for the purpose of enforcing labor laws. Existing law re…
  - (2026-08-22) [California AB 2030] Dietary supplements for weight loss and over-the-counter diet pills.
      Existing law regulates the safety of various consumer products, including, among other things, specific additives in foods, chemicals in products for young children, and lead in tableware. This bill would prohibit a pers…
  - (2026-08-22) [California AB 2212] Postsecondary education: sexual harassment, harassment, intimidation, and bullying policies: student training.
      The Equity in Higher Education Act provides, among other things, that all students have the right to participate fully in the educational process, free from discrimination and harassment. Existing law provides that sexua…
  - (2026-08-22) [California AB 2253] Solid waste: products: recycled content claims.
      Existing law requires a manufacturer or supplier making an environmental marketing claim relating to the recycled content of a plastic food container product to maintain specified information and documentation in written…
  - (2026-08-22) [California AB 2439] Common Interest Developments: governing documents: assessments.
      Existing law, the Davis-Stirling Common Interest Development Act, governs the management and operation of common interest developments. Existing law limits the authority of the governing documents, as defined, to regulat…

### State-Level News — 92 new of 403 total
  - (2026-08-21) [Alaska] Governor Dunleavy and Alaska’s Congressional Delegation Welcome Trump Administration’s Historic Investment in Rural Ferry Program
      Aug. 21, 2026 (Anchorage, AK) – Today Governor Mike Dunleavy announced that the Trump Administration has awarded more than $410 million to support the Alaska Marine Highway System with key resources targeted for rural So…
  - (2026-08-22) [California] Governor Newsom signs legislation 8.22.2026
  - (2026-08-22) [Delaware] Photo Gallery: Dover struck by tornado
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/08/Dover-Tornado-Superlodge-2.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-08-23) [Connecticut] UConn’s puppetry program is famous. John Bell played a big part in that
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/08/UCONN-PUPPETRY-0806-JL-008-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fet…
  - (2026-08-23) [Connecticut] The traffic calming illusion
      <img width="500" height="400" src="https://ctmirror.org/wp-content/uploads/2026/08/Chicane-Wikipedia.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset=…
  - (2026-08-23) [Hawaii] GOVERNOR GREEN REQUESTS PRESIDENTIAL EMERGENCY DECLARATION FOLLOWING HURRICANE LALA
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA DEPARTMENT OF DEFENSE KA ʻOIHANA PILI KAUA HAWAI‘I EMERGENCY MANAGEMENT AGENCY KE‘ENA HO‘OMALU PŌULIA O HAWAI‘I […]

### Ukrainian Internal News (national + local Kyiv) — 54 new of 115 total
  - (2026-08-23) Україна восени отримає від Франції нові радари для ППО - президент | LEDE: ] (uk: Україна восени отримає від Франції нові радари для ППО - президент)
  - (2026-08-23) Зеленський: Росія може виробляти до 1300 балістичних ракет на рік, а зараз має близько 600 | LEDE: Зеленський повідомив, що РФ має 600-630 ракет і може досягти виробництва 1300 ракет на рік.] (uk: Зел…
      Зеленський повідомив, що РФ має 600-630 ракет і може досягти виробництва 1300 ракет на рік.
  - (2026-08-23) Президент: Цього року вийдемо на однакову кількість окупованої та деокупованої території | LEDE: Зеленський заявив: Україна прагне до паритету звільнених та окупованих територій до кінця 2026 р] (uk:…
      Зеленський заявив: Україна прагне до паритету звільнених та окупованих територій до кінця 2026 року.
  - (2026-08-23) Зеленський назвав вибори у цей час "цунамі, яке розколе Україну" | LEDE: Президент Зеленський заявив, що вибори під час війни несуть великі ризики та можуть розколоти Україну.] (uk: Зеленський назвав…
      Президент Зеленський заявив, що вибори під час війни несуть великі ризики та можуть розколоти Україну.
  - (2026-08-23) У Львові стався вибух в аптеці, є загиблий | LEDE: У Львові вибухнула аптека на Тракті Глинянському, загинув аптекар. Причини встановлюються.] (uk: У Львові стався вибух в аптеці, є загиблий)
      У Львові вибухнула аптека на Тракті Глинянському, загинув аптекар. Причини встановлюються.
  - (2026-08-23) Сибіга зустрів у Києві лідерів шести європейських країн | LEDE: ] (uk: Сибіга зустрів у Києві лідерів шести європейських країн)

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-23) [Russia oil sanctions perimeter · themes] 國際金價創三個月以來新高 原因為何 ？
      hkcd.com · Chinese · tone NA
  - (2026-08-23) [Russia oil sanctions perimeter · themes] РФ не готова до мирних угод : пояснення ISW
      1tv.com.ua · Ukrainian · tone NA
  - (2026-08-23) [Russia oil sanctions perimeter · themes] La energia está más cara que nunca este 2026 por alza de combustibles y la guerra en Oriente Medio
      listindiario.com · Spanish · tone NA
  - (2026-08-23) [Russia oil sanctions perimeter · themes] Ganadores y perdedores en la guerra de Irán
      listindiario.com · Spanish · tone NA
  - (2026-08-23) [Russia oil sanctions perimeter · themes] President Donald Trump Claims Fuel Prices Are Tumbling Down , but Trumpflation Has Become a Broad - Based Problem
      finance.yahoo.com · English · tone NA
  - (2026-08-23) [Russia oil sanctions perimeter · themes] تراجع في الأداء والخطاب .. التصعيد الحوثي يدخل شهره الثاني دون نتائج
      newsyemen.net · Arabic · tone NA

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 21 new of 21 total
  - (2026-08-23) JAF2WA (Belgium)
      icao24: 44d1ba · position: (41.289, 17.6879) · alt: 10972m · 824km/h
  - (2026-08-23) JAF9CK (Belgium)
      icao24: 44d1a6 · position: (51.1767, 2.7227) · alt: 396m · 329km/h
  - (2026-08-23) JAF99Y (Belgium)
      icao24: 44d1a7 · position: (44.4329, -3.8649) · alt: 11582m · 947km/h
  - (2026-08-23) JAF7CB (Belgium)
      icao24: 44d1b3 · position: (47.5423, 0.6694) · alt: 10363m · 893km/h
  - (2026-08-23) JAF66L (Belgium)
      icao24: 44d1b4 · position: (50.0923, 2.7928) · alt: 7726m · 819km/h
  - (2026-08-23) JAF3EM (Belgium)
      icao24: 44d1c2 · position: (47.5805, 10.4845) · alt: 11582m · 721km/h

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-08-23) Dota 2: TEAM VISION vs Team Spirit (BO5) - The International Playoffs
      yes price: 57% · 24h volume: $7,827,649 · resolves 2026-08-23
  - (2026-08-23) LoL: Hanwha Life Esports vs T1 - Game 1 Winner
      yes price: 100% · 24h volume: $1,066,455 · resolves 2026-08-23
  - (2026-08-23) LoL: ThunderTalk Gaming vs LGD Gaming - Game 2 Winner
      yes price: 0% · 24h volume: $831,061 · resolves 2026-08-23
  - (2026-08-23) Will Josh Stein win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $712,149 · resolves 2028-11-07
  - (2026-08-23) LoL: Hanwha Life Esports vs T1 - Game 2 Winner
      yes price: 100% · 24h volume: $653,280 · resolves 2026-08-23
  - (2026-08-23) LoL: Hanwha Life Esports vs T1 (BO3) - LCK Round 3-4 Legend Group
      yes price: 100% · 24h volume: $557,915 · resolves 2026-08-23

### Paper Trading Scorecard — 14 new of 131 total
  - (2026-08-23) [Polymarket] 0 ships transit Hormuz on any date by August 31?
      This market will resolve to “Yes” if IMF PortWatch publishes a daily number of transit calls (“Arrivals of Ships”) for the Strait of Hormuz equal to 0 for any date between market creation and the specified date, 2026. Ot…
  - (2026-08-23) [Polymarket] US obtains Iranian enriched uranium by September 30?
      This market will resolve to “Yes” if the US government or military officially announces or confirms that it has gained possession of any quantity of enriched uranium previously controlled by Iran by September 30, 2026, 1…
  - (2026-08-23) [Polymarket] Will Gold (GC) hit (HIGH) $6,000 by end of December?
      This market will resolve to "Yes" if, on any trading day, the official CME settlement price for the Active Month (front month) of Gold (GC) futures is equal to or above the listed price by the final trading day of Decemb…
  - (2026-08-23) [Polymarket] US announces end of Iranian blockade by September 21, 2026?
      On July 13, 2026, Trump announced the United States would reinstate its naval blockade of Iran, targeting Iranian ships and customers. This market will resolve to “Yes” if the United States government, or an authorized r…
  - (2026-08-23) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-08-23) [Manifold] Will James Talarico win Starr County in the 2026 Texas Senate election?

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 54 total
  - (2026-08-23) [TechCrunch] Two years after launch, Walmart’s Flipkart is closing in on India’s quick-commerce leaders
      Flipkart's quick-commerce venture is delivering 1.1 million to 1.2 million orders a day, nearly triple its November volume.
  - (2026-08-22) [BleepingComputer] Hackers infect Android car head units with proxy botnet malware
      A supply-chain attack targeting Android-based car head units is using a legitimate device-update app to spread malware that enlists compromised devices in a proxy botnet or uses them for ad fraud. [...]
  - (2026-08-22) [BleepingComputer] Named Pipes Under Attack: Securing Windows Interprocess Communication
      Windows named pipes provide fast interprocess communication, but weak access controls can expose privileged services to untrusted processes. ThreatLocker explains how endpoint verification, command authorization, strict…
  - (2026-08-22) [The Hacker News] TikTok Agrees to $400 Million Settlement in U.S. Child Privacy Lawsuit
      The U.S. Department of Justice (DoJ) announced on Friday that ByteDance-owned TikTok will pay $400 million to settle a 2024 lawsuit accusing the company of violating child privacy laws in the country. As part of the sett…
  - (2026-08-22) [The Register] If you're not using AI to attack your own systems, your adversaries will
      Agents are also the new attack surface - cue defenders' existential angst
  - (2026-08-22) [The Register] AI slop is good for business if you know what you're doing
      Your irresponsibility is someone else's opportunity

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-08-22) M 5.8 - 4 km N of Toride, Japan
      M5.8 · 4 km N of Toride, Japan · depth 61 km
  - (2026-08-23) M 5.2 - 124 km ESE of Kirakira, Solomon Islands
      M5.2 · 124 km ESE of Kirakira, Solomon Islands · depth 120.328 km
  - (2026-08-22) M 4.9 - 78 km S of Gorontalo, Indonesia
      M4.9 · 78 km S of Gorontalo, Indonesia · depth 116.29 km
  - (2026-08-22) M 4.7 - 170 km SW of Sungai Penuh, Indonesia
      M4.7 · 170 km SW of Sungai Penuh, Indonesia · depth 26.342 km
  - (2026-08-23) M 4.6 - 273 km E of Levuka, Fiji
      M4.6 · 273 km E of Levuka, Fiji · depth 571.282 km
  - (2026-08-23) M 4.6 - 26 km E of Letpandan, Burma (Myanmar)
      M4.6 · 26 km E of Letpandan, Burma (Myanmar) · depth 10 km

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-08-21) U.S. Court of Appeals, 4th Cir.: Christopher Billesdon v. Wells Fargo Securities, LLC
  - (2026-08-20) U.S. Court of International Trade: Inspired Ventures, LLC v. United States
  - (2026-08-20) U.S. Court of Appeals, 4th Cir.: Central Appalachian Coal Company v. DOWCP
  - (2026-08-20) U.S. Court of Appeals, 4th Cir.: Fareed Hayat v. Casey Diaz
  - (2026-08-20) U.S. Court of Appeals, 9th Cir.: Rios v. City of Azusa
  - (2026-08-20) U.S. Court of Appeals, 9th Cir.: Pacific Maritime Association v. National Labor Relations Board

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-23) [Japan] Tepco begins removal of radioactive spent fuel from Fukushima No . 2 reactor
      nuclear-news.net · English
  - (2026-08-23) [Japan] Jared Kushner : US will back Israeli resumption of war if Hamas fails to honor disarmament commitments
      nuclear-news.net · English
  - (2026-08-23) [Japan] Why are we militarising Space ?
      nuclear-news.net · English
  - (2026-08-23) [Japan] SMRs and microreactors in the military
      nuclear-news.net · English
  - (2026-08-23) [Japan] Today In Dystopia : Burning Books For Israel , Burning Books For AI
      nuclear-news.net · English
  - (2026-08-23) [Japan] Private investors are not rushing into nuclear . The Netherlands has chosen another path
      nuclear-news.net · English

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-23) [Marginal Revolution] My recent visit to Anthropic
      I very recently participated in a two-day session to offer guidance on rewriting the constitution for Claude. The small group invited was uniformly excellent, we received serious time with key decision-makers, and the di…
  - (2026-08-23) [Marginal Revolution] The new agentic O-ring world
      But because agents often require guidance or additional context as they move through their tasks, Sharma, 27, finds himself wanting to be available to them around the clock and forgoing a regular sleep schedule as a resu…
  - (2026-08-22) [Marginal Revolution] Has the European turnaround finally arrived?
      Europe just had its best reporting season in years. Companies in the benchmark Stoxx Europe 600 index boosted earnings per share by 18% on average in the second quarter compared with a year earlier. Earnings barely grew…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=15, 14d-median=20; carrying terms: establish, proposed, action, national, proposing, certain, proposes, establishing, specifically, navigable, service, management
- state_bills: today=137, 7d-median=137, 14d-median=129; carrying terms: specified, private, insurance, social, including, among, maintain, planning, financial, education, known, mental
- state_news: today=403, 7d-median=597, 14d-median=597; carrying terms: meeting, start, private, insurance, among, oversight, thought, legislative, notice, tribune, license, study
- local_news: today=218, 7d-median=235, 14d-median=230; carrying terms: including, driver, police, woman, georgia, august, color, following, injured, charged, three, found
- foreign_news: today=976, 7d-median=978, 14d-median=1007; carrying terms: younes, suggested, private, sustainable, moscow, platforms, rescue, among, israeli, epileptic, wowed, seized
- chinese_internal: today=250, 7d-median=284, 14d-median=271; carrying terms: cbmiw, global, color, cbmiykfvx, china, google, cbmia, cbmixkfvx, cbmiyefvx, cbmickfvx, https, chinese
- russian_internal: today=873, 7d-median=1030, 14d-median=1040; carrying terms: istories, client, blank, forbidden, bloomberg, novaya, httperror, gazeta, target, europe, title, telegram
- ukrainian_internal: today=115, 7d-median=114, 14d-median=114; carrying terms: moscow, including, study, officials, kremlin, hmarochos, kills, increasingly, august, strikes, following, injured
- ukraine_theater: today=1144, 7d-median=887, 14d-median=1001; carrying terms: cuxpsevquelpmmg, mzytr, emfpttl, dovelxcxvuakftmtjqohrfde, lymmzid, flauj, nqzfjwjlmmemztwjottd, icnjjt, pjedbzudnnvuuxdgt, uhvnvnj, nonjhfwe, xwyvdjqv
- paper_bets: today=131, 7d-median=135, 14d-median=135; carrying terms: jpmorgan, arizona, primary, fuentes, approve, growth, supreme, experience, nebraska, trump, openai, pennsylvania
- weather: today=135, 7d-median=159, 14d-median=177; carrying terms: advisory, disregard, normal, afdilx, caused, showers, including, afdmtr, prone, humidity, evening, western
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: indicator, headline, openings, consumption, money, walcl, dexchus, supply, assets, labor, pcepilfe, sheet
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, nasdaq, equities, china, futures, bitcoin, commodities, treasury, natural, large, range, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=100, 7d-median=95, 14d-median=96; carrying terms: comments, terrorist, aeronautics, unauthorised, rights, burundi, blank, latinscript, eastern, usaspending, space, science
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, unauthorized, https, quantitative, quiver, congresstrading, error, httperror, client
- billionaires: today=0, 7d-median=34, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, appeals, court, company, state, connecticut, international, america, trade, alabama, general, james
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, holdings, management, partners, michael, technology
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, graham, james, david, talarico, raised, platner, trone, booker, shawn, brown, warner
- gdelt_regions: today=6, 7d-median=6, 14d-median=12; carrying terms: japan, english
- gdelt_gkg: today=50, 7d-median=41, 14d-median=37; carrying terms: english, trump, themes, russian, perimeter, sanctions, russia, greek, chinese, german, spanish, ukrainian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=30, 14d-median=30; carrying terms: position, belgium, ground, france, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: average, mainly, received, hygiene, cambodia, substantial, transmitted, netherlands, divisions, acute, barisal, initiated
- cisa_kev: today=12, 7d-median=10, 14d-median=9; carrying terms: vulnerability, injection, vendor, cisco, firewall, remediation, product, secure, authentication, command, windows, driver
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=300, 14d-median=300
- usgs_quakes: today=11, 7d-median=21, 14d-median=18; carrying terms: indonesia, depth, islands, ruteng, japan, mexico, levuka
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, september, meeting, price, donetsk, league, august, winner, rates, championship, shakhtar, resolves
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, economist, revolution, conversable, marginal, https, conversableeconomist, marginalrevolution, impossible, wrote, writing, point
- tech_news: today=54, 7d-median=56, 14d-median=56; carrying terms: cybersecurity, attackers, publicly, including, computer, companies, edition, download, target, known, hackers, vulnerability
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: nathaniel, lankford, britt, suhas, elena, jamie, suzan, anomaly, schultz, burgum, titus, courtney
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, market, converges, evidence, claude, today, identify, consensus, either, sufficient, unavailable, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*