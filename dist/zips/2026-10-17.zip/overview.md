# WORLDSCOPE morning brief — 2026-10-17

## Headline
3136 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (723) · Russian Internal News (state + in-exile) (603) · World leaders & government officials (324) · State-Level News (297) · Chinese Internal News (205) · Local News: St. Louis + Atlanta (189) · U.S. Weather + Severe / Climate Outlooks (141) · State Legislative Action (98) · Ukraine Theater (total-war monitoring) (77) · GDELT GKG — themes / entities / watch areas (75) · Ukrainian Internal News (national + local Kyiv) (68) · GDACS — global disaster alerts (42)

## What changed today
### International News + Multilateral Institutions — 723 new of 978 total
  - (2026-10-17) [Global] Mexican judge sentences three men to 158 years in prison for murders of Australian and US surfers​
  - (2026-10-16) [Global] Brazilian Amazon deforestation falls to lowest on record as pivotal vote looms
  - (2026-10-16) [Global] Brazil’s Lula says he now backs lowering age of criminal responsibility to 16
  - (2026-10-16) [Global] No 10 leaves option open to impose Chinese EV tariffs if UK joins EU scheme
  - (2026-10-17) [Global] Mimicking populists will not ease cost of living or boost productivity, Mathias Cormann warns
  - (2026-10-16) [Global] Gone to the dogs: racing fans mourn closure of ‘Wenty’, Sydney’s historic greyhound track

### Russian Internal News (state + in-exile) — 603 new of 1022 total
  - (2026-10-17) Путин поручил утвердить программу «восстановления объектов торговой и логистической инфраструктуры» после украинских ударов | LEDE: Президент России Владимир Путин поручил правительству утве] (ru: Пут…
      Президент России Владимир Путин поручил правительству утвердить программу «восстановления объектов торговой и логистической инфраструктуры», поврежденных в результате украинских ударов.
  - (2026-10-17) Анкета эмигранта: преподавательница английского Эльмира Драу. Она уехала из Геленджика в Ереван без работы и накоплений (зато с мужем и котом). Теперь у нее своя языковая школа, и она успевает ] (ru:…
      Недавно «Медуза» запустила рубрику «Анкета эмигранта», посвященную жизни россиян за границей. Мы собираемся рассказывать истории эмигрантов известных и не очень. Первую анкету заполнила Монеточка. Вторая досталась 32-лет…
  - (2026-10-17) В Конгресс США внесли законопроект, блокирующий «дизельную сделку» Трампа и Путина | LEDE: В Палату представителей Конгресса США внесен законопроект «О запрете коррумпированных нефтяных сдел] (ru: В К…
      В Палату представителей Конгресса США внесен законопроект «О запрете коррумпированных нефтяных сделок с Россией». Его автор — конгрессмен-демократ, член комитета по иностранным делам Грегори Микс. Соавторы законопроекта…
  - (2026-10-17) Telegraph: ограничить работу Starlink в Украине предложил Илон Маск, Трамп с ним согласился | LEDE: Ограничить работу Starlink в Украине предложил президенту США Дональду Трампу глава SpaceX] (ru: Tel…
      Ограничить работу Starlink в Украине предложил президенту США Дональду Трампу глава SpaceX Илон Маск, сообщили The Telegraph четыре источника, знакомых с ходом обсуждения.
  - (2026-10-17) Московские аэропорты опять закрывали из-за угрозы атаки украинских дронов. Задержаны и отменены более 350 рейсов | LEDE: Аэропорты Москвы вечером и в ночь на 17 октября из-за угрозы атаки ук] (ru: Мос…
      Аэропорты Москвы вечером и в ночь на 17 октября из-за угрозы атаки украинских дронов снова вводили ограничений на прием и отправление рейсов. Всего, следует из данных онлайн-табло, задержаны или отменены более 350 рейсов…
  - (2026-10-17) «Я был свидетелем невероятных разрушений и потерь, которые останутся со мной на всю жизнь». Дон Маккалин сделал самые знаменитые снимки войны во Вьетнаме. Посмотрите на них в его последней книг] (ru:…
      Сэр Дон Маккалин — знаменитый военный фотограф, обладатель множества престижных наград, командор ордена Британской империи. Почти 70 лет Маккалин снимал войны и конфликты по всему миру — в Конго и Израиле, на Кипре и в С…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 297 new of 688 total
  - (2026-10-16) [Alabama] Earth Science Week
      Download
  - (2026-10-16) [Alabama] Italian American Heritage Month
      Download
  - (2026-10-16) [Alabama] Governor Ivey Introduces a CHOOSE Act Family: Meet the Ratcliffe Family
      MONTGOMERY – Governor Kay Ivey on Friday introduced the Ratcliffes, an Alabama family utilizing the CHOOSE Act, the governor’s education savings account (ESA) program. Mother Tricia Ratcliffe has one child: Rossalyn, or…
  - (2026-10-17) [California] California secures federal assistance to support response to Norte Fire in Orange County
      Source
  - (2026-10-16) [California] A commitment to serve: 3,200 CHP officers sworn in since 2019
      Source
  - (2026-10-16) [California] First Partner Siebel Newsom celebrates California’s nation-leading Farm to School program at statewide summit
      Source

### Chinese Internal News — 205 new of 282 total
  - (2026-10-15) Expanded U.S. Curbs on Electronics Using Huawei, ZTE Parts Take Effect - Caixin Global
      Expanded U.S. Curbs on Electronics Using Huawei, ZTE Parts Take Effect Caixin Global
  - (2026-10-16) 财新闻｜婴幼儿纸尿裤甲酰胺问题调查核实情况公布后，山东省卫健委通报 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9JVXNZY25QMkVQQkRKbE4yVjFzMnEwbTRmZVJsWkFEQlRCQ3h3V1RVSXFUZ3RoYm40VjJkZG56c1dCQThDbG91] (zh:…
      财新闻｜婴幼儿纸尿裤甲酰胺问题调查核实情况公布后，山东省卫健委通报 财新
  - (2026-10-17) 【周刊提前读】险企减持权益投资 股票配置如何平衡？ - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9nOFFqTTlQRUVpNjFMWkRkb1dwQjhzVDFveVBXY2JqNFc5aE5xZl9uQ0Y5ZlBOMnM4aXRFQU5nZ0x3b1U0aEdxUTFvNk] (zh:…
      【周刊提前读】险企减持权益投资 股票配置如何平衡？ 财新数据
  - (2026-10-17) 【周刊提前读】银行股修复分化 股份行缘何承压？ - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE5nYWpIQWxNUkZ2QlllYWstLXdYbndDQ0RIVWNBV2p3dHBjOVlWeGVFMExSMVh6NVU0M1lzeFZFNFExbzJjdG1RcGpnUlVN] (zh:…
      【周刊提前读】银行股修复分化 股份行缘何承压？ 财新数据
  - (2026-10-17) 【周刊提前读】商业项目土地使用权开启续期 定价方式与制度安排影响深远 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTFBZMXZkdXdOQ1FoSW9hZFNnSklZQjRYQ0N0WENDOUhQRWxVSmtPLVUzc2Rld29wdnZXczZLVk9DaEtjcUZJb] (zh:…
      【周刊提前读】商业项目土地使用权开启续期 定价方式与制度安排影响深远 财新数据
  - (2026-10-17) 大西洋观察｜尾大不掉的英国福利开支 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5oTmVOSVN4aDBvMWJibmlydG1ObjR6WUd3QnJnLWlCejdxX0tUTnlxaWtvX3VIMW4zOVlBbnJTNXpZOXYyX0ota3E4MFNrNHpfTkRp] (zh:…
      大西洋观察｜尾大不掉的英国福利开支 财新

### Local News: St. Louis + Atlanta — 189 new of 239 total
  - (2026-10-17) [St. Louis] Did anyone win Mega Millions' $403M jackpot? Here are the winning numbers for Friday, Oct. 16, 2026
      The Mega Millions jackpot has grown to $403 million after a ticket sold in Florida won a massive $803 million prize in July.
  - (2026-10-17) [St. Louis] Coastal homes burn as hot winds fuel California fires
      High winds are fueling a fast-moving fire that has burned homes in Southern California. At least six homes burned on Friday.
  - (2026-10-17) [St. Louis] 16-year-old remains in critical condition after shooting near N. Euclid Avenue
      The victim, believed to be in his late teens, was taken to the hospital with life-threatening injuries.
  - (2026-10-17) [St. Louis] Trump puts new Russia sanctions passed by Congress on hold, saying waiver is in US national interest
      President Donald Trump signed an executive order that puts on hold a sanctions package targeting the Russian economy.
  - (2026-10-17) [St. Louis] At least 10 more Congressional offices report receiving suspicious white powder, threatening letters
      Members of Congress in several states reported receiving packages containing white powder Friday.
  - (2026-10-17) [St. Louis] New Mexico judge tosses charges against actor Timothy Busfield, citing prosecutor misconduct
      A New Mexico judge dismissed a grand jury indictment that accused actor Timothy Busfield of four counts of criminal sexual contact with a child.

### U.S. Weather + Severe / Climate Outlooks — 141 new of 143 total
  - (2026-10-17) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-17) [Moderate] Gale Warning: Gale Warning issued October 17 at 6:40AM EDT until October 18 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...North winds 20 to 30 kt with gusts up to 40 kt and waves 3 to 6 ft. * WHERE...Chesapeake Bay from Smith Point to Windmill Point VA and Chesapeake Bay from Windmill Point to New Point Comfort VA. * WHEN...Until 7…
  - (2026-10-17) [Moderate] Gale Warning: Gale Warning issued October 17 at 6:40AM EDT until October 20 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...North to northeast winds 25 to 35 kt with gusts up to 45 kt and seas 11 to 16 ft. * WHERE...Coastal Waters from Cape Charles Light to Virginia- North Carolina border out 20 NM and Coastal waters from NC VA borde…
  - (2026-10-17) [Moderate] Gale Warning: Gale Warning issued October 17 at 6:40AM EDT until October 18 at 1:00PM EDT by NWS Wakefield VA
      * WHAT...For the Gale Warning, north to northeast winds 25 to 30 kt with gusts up to 35 kt and seas 7 to 10 ft. For the Gale Watch, north to northeast winds 25 to 35 kt with gusts up to 40 kt and seas 9 to 14 ft possible…
  - (2026-10-17) [Moderate] Gale Warning: Gale Warning issued October 17 at 6:40AM EDT until October 20 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...North to northeast winds 25 to 30 kt with gusts up to 40 kt and waves 6 to 9 ft. * WHERE...Chesapeake Bay from New Point Comfort to Little Creek VA and Chesapeake Bay from Little Creek VA to Cape Henry VA includ…
  - (2026-10-17) [Moderate] Gale Warning: Gale Warning issued October 17 at 6:40AM EDT until October 18 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...For the Small Craft Advisory, north winds 15 to 25 kt with gusts up to 30 kt and waves 1 to 3 ft. For the Gale Warning, north winds 20 to 30 kt with gusts up to 35 kt and waves 2 to 3 ft expected. * WHERE...Rapp…

### State Legislative Action — 98 new of 120 total
  - (2026-10-17) [Alaska HJR 14] Supporting the completion of the Port MacKenzie Rail Extension and the Northern Rail Extension; supporting the increase in defensive capabilities at Fort Greely, Alaska; encouraging a…
      Supporting the completion of the Port MacKenzie Rail Extension and the Northern Rail Extension; supporting the increase in defensive capabilities at Fort Greely, Alaska; encouraging a renewed commitment by the Alaska Rai…
  - (2026-10-17) [Alaska HJR 4] Urging the President of the United States, the United States Secretary of the Interior, the United States Board on Geographic Names, and the members of the state's delegation in Congres…
      Urging the President of the United States, the United States Secretary of the Interior, the United States Board on Geographic Names, and the members of the state's delegation in Congress to maintain Denali as the officia…
  - (2026-10-17) [Alaska SJR 30] Expressing gratitude for the United States military and supporting increased defense readiness through infrastructure development and public-military partnerships.
      Expressing gratitude for the United States military and supporting increased defense readiness through infrastructure development and public-military partnerships.
  - (2026-10-17) [Alaska HB 93] An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.
      An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.
  - (2026-10-17) [Alaska HB 130] An Act relating to flexible time credit for classified employees in the executive branch who are not eligible for overtime compensation.
      An Act relating to flexible time credit for classified employees in the executive branch who are not eligible for overtime compensation.
  - (2026-10-17) [Alaska SB 272] An Act relating to the electronic health information exchange system; and providing for an effective date.
      An Act relating to the electronic health information exchange system; and providing for an effective date.

### Ukraine Theater (total-war monitoring) — 77 new of 384 total
  - (2026-10-17) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-16) [FIRMS] thermal anomaly 45.967, 30.255 (FRP 13.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-16 1041Z, FRP 13.93 MW
  - (2026-10-16) [FIRMS] thermal anomaly 45.971, 30.254 (FRP 13.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-16 1041Z, FRP 13.93 MW
  - (2026-10-16) [FIRMS] thermal anomaly 45.974, 30.252 (FRP 17.09 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-16 1041Z, FRP 17.09 MW
  - (2026-10-16) [FIRMS] thermal anomaly 44.265, 23.068 (FRP 2.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-16 1041Z, FRP 2.37 MW
  - (2026-10-16) [FIRMS] thermal anomaly 51.568, 25.075 (FRP 3.12 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-16 1041Z, FRP 3.12 MW

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-10-17) [Russia oil sanctions perimeter · keywords] Trump signs executive order waiving new Russia sanctions , tariffs
      ewn.co.za · English · tone NA
  - (2026-10-17) [Russia oil sanctions perimeter · keywords] Trump Waives Graham Act Sanctions On Russia Before They Take Effect
      iranherald.com · English · tone NA
  - (2026-10-17) [Russia oil sanctions perimeter · keywords] Oil at $110 per barrel , its highest since May | The Arkansas Democrat - Gazette
      arkansasonline.com · English · tone NA
  - (2026-10-17) [Russia oil sanctions perimeter · keywords] RAF jets report mystery drones over Britain
      lbc.co.uk · English · tone NA
  - (2026-10-17) [Russia oil sanctions perimeter · keywords] Trump blocks new Russia sanctions days before they take effect
      helsinkitimes.fi · English · tone NA
  - (2026-10-17) [Russia oil sanctions perimeter · keywords] India Russian crude binge to continue after Trump waives new sanctions law
      thehindu.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 68 new of 130 total
  - (2026-10-17) ЗСУ спростували заяви РФ про наближення до Запоріжжя та захоплення міст на Донеччині | LEDE: Генеральний штаб Збройних сил України заперечив заяви РФ про захоплення Костянтинівки, Добропілля та] (uk:…
      Генеральний штаб Збройних сил України заперечив заяви РФ про захоплення Костянтинівки, Добропілля та наближення до Запоріжжя.
  - (2026-10-17) "Кличку пізно метатися, пора прощатися": на Хрещатику проходить акція за відставку мера | LEDE: На Хрещатику біля КМДА відбувається акція за відставку мера Києва Віталія Кличка. В акції беруть ] (uk:…
      На Хрещатику біля КМДА відбувається акція за відставку мера Києва Віталія Кличка. В акції беруть участь орієнтовно 200 людей.
  - (2026-10-17) "Санкційний блекаут": Зеленський вважає, що "закон Грема" було повністю проігноровано | LEDE: Президент Зеленський назвав скасування санкцій США «санкційним блекаутом» та закликав зберігати тис] (uk:…
      Президент Зеленський назвав скасування санкцій США «санкційним блекаутом» та закликав зберігати тиск на Росію після підписання закону Трампом.
  - (2026-10-17) У Польщі військові потренуються розгортати сили в Україні на випадок перемир’я з РФ – ЗМІ | LEDE: У листопаді 1500 військових із Франції, Німеччини, Британії та Польщі візьмуть участь у навчанн] (uk:…
      У листопаді 1500 військових із Франції, Німеччини, Британії та Польщі візьмуть участь у навчаннях у Польщі для підготовки до можливої миротворчої місії в Україні.
  - (2026-10-17) На адмінмежі з Молдовою виник інцидент із порушником і нарядом прикордонників України | LEDE: При затриманні порушника на кордоні з Молдовою виник інцидент, проводиться службове розслідування.] (uk: Н…
      При затриманні порушника на кордоні з Молдовою виник інцидент, проводиться службове розслідування.
  - (2026-10-17) Київ та область вкрив густий туман: оголошено 1-й рівень небезпечності | LEDE: У Києві та області оголосили жовтий рівень небезпечності через густий туман і низьку видимість. Можливі ускладненн] (uk:…
      У Києві та області оголосили жовтий рівень небезпечності через густий туман і низьку видимість. Можливі ускладнення руху транспорту.

### GDACS — global disaster alerts — 42 new of 100 total
  - (2026-10-17) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.6M, Depth:90.844km
  - (2026-10-17) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.8M, Depth:10km
  - (2026-10-17) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.5M, Depth:145.265km
  - (2026-10-17) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.5M, Depth:10km
  - (2026-10-17) [Green] Earthquake in Pakistan
      Earthquake · Green alert · Pakistan · Magnitude 5.7M, Depth:10km
  - (2026-10-17) [Green] Earthquake in Fiji Islands Region
      Earthquake · Green alert · Fiji Islands Region · Magnitude 4.8M, Depth:439.394km

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-17) [Ainscow Robert] Form 4 (Reporting)
      filed 2026-10-17 01:57 UTC · role: Reporting — Filed: 2026-10-16 AccNo: 0001477932-26-006312 Size: 5 KB
  - (2026-10-17) [ASP Isotopes Inc.] Form 4 (Issuer)
      filed 2026-10-17 01:57 UTC · role: Issuer — Filed: 2026-10-16 AccNo: 0001477932-26-006312 Size: 5 KB
  - (2026-10-17) [Singleton Nicole Marie] Form 4 (Reporting)
      filed 2026-10-17 01:56 UTC · role: Reporting — Filed: 2026-10-16 AccNo: 0001801661-26-000124 Size: 8 KB
  - (2026-10-17) [Firy Inc.] Form 4 (Issuer)
      filed 2026-10-17 01:56 UTC · role: Issuer — Filed: 2026-10-16 AccNo: 0001801661-26-000124 Size: 8 KB
  - (2026-10-17) [Paradise Andrew] Form 4 (Reporting)
      filed 2026-10-17 01:56 UTC · role: Reporting — Filed: 2026-10-16 AccNo: 0001801661-26-000123 Size: 8 KB
  - (2026-10-17) [Firy Inc.] Form 4 (Issuer)
      filed 2026-10-17 01:56 UTC · role: Issuer — Filed: 2026-10-16 AccNo: 0001801661-26-000123 Size: 8 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-10-17) [United Kingdom] Boy aged 16 and 80 - year - old man killed in light aircraft crash
      domain: dailyecho.co.uk · language: English · tone:
  - (2026-10-17) [United States] A No Vote On Virginia Amendment 2 Is A Vote for Marriage
      domain: americanthinker.com · language: English · tone:
  - (2026-10-17) [China] Trump Waives Graham Act Sanctions On Russia Before They Take Effect
      domain: beijingbulletin.com · language: English · tone:
  - (2026-10-17) [United States] Ukraine : Civilian casualty rates among deadliest in years , as energy attacks intensify Global Issues
      domain: globalissues.org · language: English · tone:
  - (2026-10-17) [United States] Trump Suspends New Russia Sanctions as Tensions With Ukraine Deepen
      domain: kvor.com · language: English · tone:
  - (2026-10-17) [United Kingdom] BBC confirms DIY SOS will be rested in 2027 amid ongoing savings challenges
      domain: timesandstar.co.uk · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 36 new of 58 total
  - (2026-10-17) [The Hacker News] Hackers Use Compromised ConnectWise Credential to Sign In to 173 Microsoft 365 Tenants
      Cybersecurity researchers are sounding the alarm related to an active campaign in which unknown threat actors are abusing a compromised Microsoft 365 (M365) credential belonging to ConnectWise Cloud Backup (formerly SkyK…
  - (2026-10-17) [The Register] Amazon wants you to Bee-lieve wearable AI can recall it all for you
      Would you like personalized shopping recommendations based on that conversation you just had?
  - (2026-10-17) [The Register] Get in the bin! UK Space Agency wants public to name its debris removal mission
      ClearSpace UK aims to be operational in 2029 with public's suggestion etched on the side of the spacecraft
  - (2026-10-17) [TechCrunch] Mark Wahlberg wants to take on the longevity-startup crowd with an affordable gym concept
      Mark Wahlberg, who once sank money into a gym chain that got kicked off the NYSE, is now building his own, and he promises you’ll get a cold plunge, a blood panel and a protein muffin without needing a trust fund.
  - (2026-10-16) [BleepingComputer] Critical BlockStrap flaw lets hackers run code on Magento servers
      Researchers warn that hackers could soon exploit a maximum-severity vulnerability (CVE-2026-103849) affecting Magento and Adobe Commerce, potentially allowing them to execute arbitrary PHP code on store servers. [...]
  - (2026-10-16) [BleepingComputer] Targeted ads installed Candiru spyware in zero-click attacks
      Candiru spyware was delivered to devices at Al Jazeera Media Network via targeted online advertisements in a zero-click attack that required only rendering the malicious ads on the victim's device. [...]

### U.S. Federal Action — 33 new of 33 total
  - (2026-10-19) Fee Schedules; Fee Recovery for Fiscal Year 2026
  - (2026-10-19) Continuation of the National Emergency With Respect to the Democratic Republic of the Congo
  - (2026-10-19) Continuation of the National Emergency With Respect to Sudan
  - (2026-10-19) Continuation of the National Emergency With Respect to Significant Narcotics Traffickers Centered in Colombia
  - (2026-10-19) Airworthiness Directives; Airbus Helicopters
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus Helicopters Model AS350B3, AS355F, AS355F1, AS355F2, AS355N, AS355NP, EC130B4, and EC130T2 helicopters. This proposed AD was prompted by a repor…
  - (2026-10-19) New Source Performance Standards and National Emission Standards for Hazardous Air Pollutants; Delegation of Authority to Northwest Clean Air Agency, Washington State
      The Northwest Clean Air Agency (NWCAA), located in Washington State, submitted updated regulations for receiving delegation and approval of its program for the implementation and enforcement of newly issued or revised Ne…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 20 new of 60 total
  - (2026-10-16) Alaska Supreme Court: Scott King v. Courtenay Carty
  - (2026-10-16) U.S. Court of Appeals, 8th Cir.: Momodou Jatta v. Todd Blanche
  - (2026-10-16) U.S. Court of Appeals, 6th Cir.: Appalachian Voices v. TVA
  - (2026-10-16) U.S. Court of Appeals, 6th Cir.: United States v. Antoine Cook
  - (2026-10-16) U.S. Court of Appeals, 1st Cir.: Morillo v. United States
  - (2026-10-16) U.S. Court of Appeals, 9th Cir.: Whitfield v. Mullin

### USGS earthquakes (M4.5+, past day) — 20 new of 20 total
  - (2026-10-17) M 5.7 - 48 km WNW of Khuzdar, Pakistan
      M5.7 · 48 km WNW of Khuzdar, Pakistan · depth 10 km · PAGER yellow
  - (2026-10-16) M 5.2 - off the coast of Ecuador
      M5.2 · off the coast of Ecuador · depth 10 km
  - (2026-10-16) M 5.0 - Auckland Islands, New Zealand region
      M5.0 · Auckland Islands, New Zealand region · depth 10 km
  - (2026-10-17) M 4.9 - 115 km SW of Puerto Madero, Mexico
      M4.9 · 115 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-10-16) M 4.9 - 119 km SSW of Merizo Village, Guam
      M4.9 · 119 km SSW of Merizo Village, Guam · depth 10 km
  - (2026-10-17) M 4.8 - 110 km NE of Norsup, Vanuatu
      M4.8 · 110 km NE of Norsup, Vanuatu · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 18 new of 103 total
  - (2026-10-16) [OFAC] Issuance of Amended Venezuela-related General License and Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Issuance of Amended Venezuela-related General License and Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-10-16) [OFAC] Recent Actions - Office of Foreign Assets Control (.gov)
      Recent Actions Office of Foreign Assets Control (.gov)
  - (2026-10-16) [OFAC] Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-10-16) [OFAC] Recent Actions - Office of Foreign Assets Control (.gov)
      Recent Actions Office of Foreign Assets Control (.gov)
  - (2026-10-16) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 60A Authorizing Transactio - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 60A Authorizing Transactio Office of Foreign Assets Control (.gov)
  - (2026-10-17) [USASpending] $41,607,031,194 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…

### Paper Trading Scorecard — 15 new of 69 total
  - (2026-10-17) [Polymarket] Will Anthropic's market cap be $3.0T or greater at market close on IPO day?
      This market will resolve based on Anthropic's market capitalization at the closing price on its first day of trading. If no IPO occurs by December 31, 2027, 11:59 PM ET, the market will resolve to "No IPO by December 31,…
  - (2026-10-17) [Manifold] Daily Coinflip
  - (2026-10-17) [Manifold] Will Ilhan Omar be a US House member on 1 Feb 2029?
  - (2026-10-17) [Manifold] Will the party with the highest party vote %, supply the Prime Minister after the NZ election?
  - (2026-10-17) [Manifold] Will there be a serious attempt by the GOP to overturn the election?
  - (2026-10-17) [Manifold] Will Troy Jackson win his hometown?

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-10-17) Valorant: Team Vitality vs 100 Thieves (BO5) - VCT Champions Playoffs
      yes price: 62% · 24h volume: $1,126,222 · resolves 2026-10-17
  - (2026-10-17) Shanghai Rolex Masters: Alexander Zverev vs Alejandro Davidovich Fokina
      yes price: 0% · 24h volume: $1,017,192 · resolves 2026-10-24
  - (2026-10-17) LoL: BNK FEARX vs Team WE (BO5) - Demacia Cup Global Invitational Playoffs
      yes price: 94% · 24h volume: $996,316 · resolves 2026-10-17
  - (2026-10-17) LoL: BNK FEARX vs Team WE - Game 1 Winner
      yes price: 100% · 24h volume: $784,728 · resolves 2026-10-17
  - (2026-10-17) LoL: BNK FEARX vs Team WE - Game 2 Winner
      yes price: 100% · 24h volume: $777,006 · resolves 2026-10-17
  - (2026-10-17) Will Chelsea FC win on 2026-10-17?
      yes price: 40% · 24h volume: $489,196 · resolves 2026-10-17

### Government & military aircraft airborne (OpenSky) — 14 new of 15 total
  - (2026-10-17) JAF4KN (Bulgaria)
      icao24: 4520ce · position: (42.9778, -1.5252) · alt: 11277m · 791km/h
  - (2026-10-17) JAF95J (Bulgaria)
      icao24: 4520aa · position: (47.863, -1.7289) · alt: 11269m · 845km/h
  - (2026-10-17) JAF5NB (Belgium)
      icao24: 44d1a5 · position: (50.854, 4.478) · alt: 144m · 265km/h
  - (2026-10-17) JAF3LV (Belgium)
      icao24: 44d1c2 · position: (48.0505, 6.0463) · alt: 10972m · 818km/h
  - (2026-10-17) RCH419 (United States)
      icao24: ae07da · position: (45.933, -66.3766) · alt: 9753m · 606km/h
  - (2026-10-17) NCR610 (United States)
      icao24: aabbef · position: (43.6691, 17.4131) · alt: 12496m · 950km/h

### World News (by country, top stories) — 6 new of 6 total
  - (2026-10-17) [Japan] North Korea tests new AI - equipped torpedo , KCNA says
      asia.nikkei.com · English
  - (2026-10-17) [Japan] Taiwan bulks up on protein - packed bentos as obesity rates rise
      asia.nikkei.com · English
  - (2026-10-17) [Japan] Trump waives key Russia - related sanctions , tariffs under new law
      asia.nikkei.com · English
  - (2026-10-17) [Japan] Surprise ! Aspyr Is Remastering A Shrek Game
      nintendolife.com · English
  - (2026-10-17) [Japan] Reminder : Sonic Racing : CrossWorlds Final Content Drop Of Year One Is Now Available
      nintendolife.com · English
  - (2026-10-17) [Japan] Resident Evil 2 , 3 and 4 Remake Are Now Available on Nintendo Switch 2
      gamingbolt.com · English

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-17) [Marginal Revolution] Solving for the equilibrium?
      Sixteen AI agents were each ha‍nded 1,000 satoshi⁠s of real b‌itcoin and told nothing about how to use​ it. A hund‍red rounds l‌at‍er⁠, four of them had roughly doubled⁠ th‍eir money, tw‍o h‌a‍d​ been wiped out, and the‍…
  - (2026-10-17) [Marginal Revolution] New Matt Faherty study of the NSF
      From the Executive Summary: Therefore, the NSF, NIH, and the federal government should put far more resources and effort into developing metascience. With proper metascience efforts, the NSF could run experiments on scie…
  - (2026-10-16) [Marginal Revolution] Friday assorted links
      1. Can Dybantsa (and others) turn around the Wizards? (NYT) 2. Claims about interpretability. I have to say I do not quite “get it”…? Here is some exposition. 3. “90% of Americans’ working hours are spent on tasks not co…
  - (2026-10-16) [Conversable Economist] How to Keep Global Agricultural Output Rising
      Global population is expected to keep rising for the next 50-60 years, because it will take awhile for the demographic force of declining birthrates to overcome the life expectancies. In addition, the world still has lot…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 15 total
  - (2026-10-16) CVE-2026-102764 · BeyondTrust Remote Support: BeyondTrust Remote Support Authentication Bypass by Spoofing Vulnerability
      vendor: BeyondTrust · product: Remote Support · CISA remediation by 2026-10-19
  - (2026-10-16) CVE-2025-61624 · Fortinet Multiple Products: Fortinet Multiple Products Path Traversal Vulnerability
      vendor: Fortinet · product: Multiple Products · CISA remediation by 2026-10-19

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-17) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=33, 7d-median=26, 14d-median=26; carrying terms: national, final, certain, action, proposing, require, public, period, proposes, safety, proposed, regulatory
- state_bills: today=120, 7d-median=73, 14d-median=82; carrying terms: providing, school, state, effective, administration, powers, relating, district, education, alaska, provides, until
- state_news: today=688, 7d-median=688, 14d-median=688; carrying terms: potential, continues, connecticut, approved, university, office, rhode, working, virginia, board, prices, resources
- local_news: today=239, 7d-median=235, 14d-median=233; carrying terms: georgia, killed, dekalb, officer, games, three, injured, house, around, woman, arrested, missouri
- foreign_news: today=978, 7d-median=1018, 14d-median=1018; carrying terms: potential, fired, continues, killed, focus, working, launch, prices, cbspeeches, until, including, midterm
- chinese_internal: today=282, 7d-median=296, 14d-median=284; carrying terms: cbmibkfvx, cbmickfvx, https, blank, cbmiakfvx, cbmizkfvx, investors, cbmiyefvx, cbmibefvx, cbmigwfbvv, articles, cbmib
- russian_internal: today=1022, 7d-median=1029, 14d-median=1061; carrying terms: title, error, server, https, laquo, novaya, istories, europe, russian, telegram, openai, politico
- ukrainian_internal: today=130, 7d-median=130, 14d-median=133; carrying terms: foreign, killed, missile, previous, building, including, kharkiv, since, military, study, energy, campaign
- ukraine_theater: today=384, 7d-median=393, 14d-median=494; carrying terms: utbkflzhfdbjhsd, accreditation, aexebv, xyxpnn, cuxontjgzzzvtgleagrsnevlwe, killed, vxdldldvbnnxm, jgoephzddna, cuxpn, dmzzvvr, cuxpmzlcuudosc, launch
- paper_bets: today=69, 7d-median=69, 14d-median=88; carrying terms: speed, become, resolved, general, leaders, total, secretary, henry, patrick, jinping, kylian, goals
- weather: today=143, 7d-median=142, 14d-median=142; carrying terms: night, level, october, rainfall, continues, tonight, norton, lincoln, message, bring, houston, until
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, cpiaucsl, consumption, openings, indicator, assets, total, treasury, dcoilwtico, unrate, dexuseu, money
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, equities, bitcoin, natural, range, rates, yield, silver, large, treasury, proxy, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=103, 7d-median=107, 14d-median=111; carrying terms: tiananmen, laboratory, involvement, mediterranean, application, foreign, controlled, funds, office, integrity, myanmar, company
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quantitative, congresstrading, error, quiver, https, httperror, client, unauthorized
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, company, court, appeals, james, state, corporation, international, board, county, alabama, arkansas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, robert, holdings, matthew, natera, justin, rabinowitz, jonathan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, congress, james, angels, senate, disbursements, david, elect, robert, committee, brown, talarico
- gdelt_regions: today=6, 7d-median=2, 14d-median=2; carrying terms: english
- gdelt_gkg: today=75, 7d-median=25, 14d-median=25; carrying terms: themes, english, chinese, italian, french, russia, perimeter, russian, spanish, sanctions, business, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: kingdom, india, killed, domain, future, language, america, warns, english, china
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=15, 7d-median=28, 14d-median=30; carrying terms: belgium, position, ground, canada, bulgaria, aabbef, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: kingdom, laboratory, recommendations, batch, dignified, general, identified, increasingly, carrying, total, parganas, clusters
- cisa_kev: today=15, 7d-median=13, 14d-median=15; carrying terms: bounds, improper, injection, operations, vulnerability, remediation, citrix, vendor, cisco, product, restriction, memory
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: speed, cyclone, flood, orange, depression, forest, impact, green, papua, tropical, australia, maximum
- usgs_quakes: today=20, 7d-median=20, 14d-median=17; carrying terms: depth, russia, region, islands, philippines, indonesia, south, panama, vilyuchinsk, tonga, vanuatu, mexico
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, presidential, resolves, league, october, shakhtar, championship, donetsk, volume, champions, election, brazilian
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, https, revolution, conversable, economist, class, money, conversableeconomist, remember, funding, economic, track
- tech_news: today=58, 7d-median=59, 14d-median=58; carrying terms: provides, company, engineers, vulnerability, cybersecurity, daily, software, including, across, download, technica, schneier
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: carter, clarke, chicago, bentz, mullin, celeste, veronica, ritchie, minneapolis, patrick, cotton, wagner
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, placement, today, markets, consensus, identify, placed, either, module, market, converges, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-10-07] Fed press (events + announcements): Minutes of the Federal Open Market Committee, September 15-16, 2026
- [2026-10-08] ECB press: Piero Cipollone: Interview with Corriere della Sera
- [2026-10-08] Fed speeches: Waller, The Signaling Value of the Summary of Economic Projections
- [2026-10-08] ECB press: Meeting of 9-10 September 2026
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-13] ECB press: Philip R. Lane: The AI opportunity for Europe
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-17] ECB press: Christine Lagarde: IMFC Statement

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*