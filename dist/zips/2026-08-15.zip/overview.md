# WORLDSCOPE morning brief — 2026-08-15

## Headline
2423 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (513) · Russian Internal News (state + in-exile) (394) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (312) · U.S. Weather + Severe / Climate Outlooks (229) · Chinese Internal News (152) · Local News: St. Louis + Atlanta (94) · State-Level News (78) · Ukrainian Internal News (national + local Kyiv) (41) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Court opinions of consequence (federal & state) (31)

## What changed today
### International News + Multilateral Institutions — 513 new of 1007 total
  - (2026-08-15) [Global] Powerful 7.7-magnitude earthquake kills at least 38 in Indonesia
      A search and rescue operation is under way to find survivors in Flores, an island in eastern Indonesia.
  - (2026-08-14) [Global] 'I shot Mr Thompson'- What it was like inside court as Mangione pleaded guilty
      It marked the first time a court had heard Mangione describe how he committed a crime that garnered worldwide attention.
  - (2026-08-15) [Global] BBC seeks to subpoena Trump's family members in Panorama lawsuit
      The BBC's lawyers argue Trump's family members "have personal knowledge" of his intentions in the speech he gave outside the US Capitol on 6 January 2021.
  - (2026-08-14) [Global] US aircraft carrier on way to relieve USS Lincoln after issues reported aboard
      Thousands of sailors on the Lincoln have reportedly faced food shortages and broken plumbing, with some considering jumping overboard.
  - (2026-08-14) [Global] Dozens injured and thousands evacuated in Croatia wildfire
      Officials say the blaze, near the port town of Omis, is one of the worst in Croatia's history.
  - (2026-08-14) [Global] The Polygamist's creator says women see themselves reflected in her Netflix hit
      Zimbabwean novelist Sue Nyathi self-funded her debut novel and now asks who can afford to write at all.

### Russian Internal News (state + in-exile) — 394 new of 1040 total
  - (2026-08-15) В Италии нашли украденные картины Ренуара, Сезанна и Матисса. По подозрению в краже задержаны девять граждан Молдовы | LEDE: Итальянская полиция нашла три картины Ренуара, Сезанна и Матисса,] (ru: В И…
      Итальянская полиция нашла три картины Ренуара, Сезанна и Матисса, которые в марте похитили из музея Фонда Маньяни-Рокка под Пармой, сообщает Reuters.
  - (2026-08-15) Полиция начала рассылать предостережения тем, кто пришел поддержать «Яблоко» у здания Верховного суда | LEDE: Полиция разослала предостережения о недопустимости участия в несанкционированных] (ru: Пол…
      Полиция разослала предостережения о недопустимости участия в несанкционированных митингах нескольким людям, которые 10 августа поддерживали партию «Яблоко» у здания Верховного суда РФ в Москве.
  - (2026-08-15) WSJ: Маск снова сблизился с Трампом и готов потратить 100 миллионов долларов на поддержку республиканцев на выборах | LEDE: Миллиардер Илон Маск и президент США Дональд Трамп восстановили от] (ru: WSJ…
      Миллиардер Илон Маск и президент США Дональд Трамп восстановили отношения спустя почти год после громкой публичной ссоры, сообщают источники The Wall Street Journal.
  - (2026-08-15) Россия атаковала Днепропетровскую и Одесскую области. В городе Марганец после удара дрона по жилому дому погиб трехмесячный ребенок | LEDE: Россия нанесла удар по Днепропетровской области бе] (ru: Рос…
      Россия нанесла удар по Днепропетровской области беспилотниками, артиллерией и авиабомбами, сообщил глава местной администрации Александр Ганжа.
  - (2026-08-15) ВСУ атаковали Самарскую область ракетами. Телеграм-каналы сообщают о пожаре на космическом предприятии РКЦ «Прогресс». В Нижегородской области под удар попал аэродром | LEDE: Украина провела] (ru: ВСУ…
      Украина провела массированную ракетную атаку Самарской области, сообщают местные чиновники. Глава региона Вячеслав Федорищев заявил, что под удар попало промышленное предприятие. Информацию о пострадавших и последствиях…
  - (2026-08-15) Антибиотики работают все хуже и хуже — но почти никому нет до этого дела. Почему? И опасно ли их принимать без повода, скажем, при ОРВИ? Отвечает биохимик Дмитрий Гиляров | LEDE: Люди все ча] (ru: Ант…
      Люди все чаще умирают из-за бактерий, с которыми не могут справиться антибиотики. При этом новые препараты для борьбы с такими инфекциями почти не появляются. Почему так происходит? Кто виноват в том, что антибиотикорези…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 312 new of 1152 total
  - (2026-08-15) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-14) [FIRMS] thermal anomaly 46.824, 34.646 (FRP 2.26 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-14 2233Z, FRP 2.26 MW
  - (2026-08-14) [FIRMS] thermal anomaly 46.825, 34.641 (FRP 1.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-14 2233Z, FRP 1.61 MW
  - (2026-08-14) [FIRMS] thermal anomaly 46.010, 34.828 (FRP 1.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-14 2233Z, FRP 1.01 MW
  - (2026-08-14) [FIRMS] thermal anomaly 46.010, 34.823 (FRP 1.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-14 2233Z, FRP 1.03 MW
  - (2026-08-15) [FIRMS] thermal anomaly 52.580, 33.745 (FRP 3.96 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-15 0013Z, FRP 3.96 MW

### U.S. Weather + Severe / Climate Outlooks — 229 new of 236 total
  - (2026-08-15) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-15) [Severe] Flash Flood Watch: Flash Flood Watch issued August 15 at 3:26AM MDT until August 15 at 9:00PM MDT by NWS Pocatello ID
      * WHAT...Flash flooding and debris flows caused by excessive rainfall continue to be possible over the Wapiti burn scar. * WHERE...Wapiti Burn Scar west of Stanley. * WHEN...Through this evening. * IMPACTS...Heavy rainfa…
  - (2026-08-15) [Severe] Flash Flood Warning: Flash Flood Warning issued August 15 at 4:24AM CDT until August 15 at 6:45AM CDT by NWS Chicago IL
      At 424 AM CDT, Doppler radar and automated rain gauges indicated thunderstorms producing heavy rain across the warned area. Up to 1.5 inches of rain have fallen. Additional rainfall amounts up to 1 inch are possible in t…
  - (2026-08-15) [Severe] Flash Flood Warning: Flash Flood Warning issued August 15 at 4:23AM CDT until August 15 at 8:15AM CDT by NWS Chicago IL
      At 423 AM CDT, Doppler radar and automated gauges indicated thunderstorms producing heavy rain across the warned area. 1.5 to 3 inches of rain have fallen on already saturated soils. Additional rainfall amounts up to 1.5…
  - (2026-08-15) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued August 15 at 4:18AM CDT until August 15 at 9:00AM CDT by NWS Sioux Falls SD
      * WHAT...Visibility one quarter to one half mile in dense fog. * WHERE...Portions of central, east central, south central, and southeast South Dakota. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility coul…
  - (2026-08-15) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 15 at 4:16AM CDT until August 15 at 4:45AM CDT by NWS Lincoln IL
      At 416 AM CDT, severe thunderstorms were located along a line extending from Manito to near Chandlerville, moving east at 40 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, sid…

### Chinese Internal News — 152 new of 271 total
  - (2026-08-14) 武大靖执教，中国短道速滑能否弯道超车？｜体坛 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFAzOFhSbWhQRnBHVlE1V0JhUVpnWHdySENyLUxldThKX0VyTGc4SFR2RUlQSGpXek15RU5uOGZBSzE3OHVZdl] (zh:…
      武大靖执教，中国短道速滑能否弯道超车？｜体坛 mini.caixin.com
  - (2026-08-15) 旅行最大的乐趣之一，其实是回家｜生命情感对话⑧ - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBrT0tHQWctdWFyZWEzRllINzdjY0NkeHg3dFVxT2pSNlhOeUl3dDg1dmhzbXlDYUNBQVNfOFNNTmZabUJud] (zh:…
      旅行最大的乐趣之一，其实是回家｜生命情感对话⑧ mini.caixin.com
  - (2026-08-15) 朱学东：夏日当家菜咸菜｜饮食 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE52OVZHV1E0Z04xVVRHV2NWQnVXX1liQ0FoeTA0NXgtT2xYVGplTXM3bnlxQWthd2x5YzBOVGx2OUxxaE1NMXVWTV95Zl] (zh:…
      朱学东：夏日当家菜咸菜｜饮食 mini.caixin.com
  - (2026-08-14) 我没有真正理解格鲁吉亚｜纪行 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1WcnJpNWdyc3R2YTRMLWJybV9KQmNrd0k1YjlNUm9OLS1iNEdLODRiaVp2SEIxSGExdXhUTThtSWI4U3pnWmYzU3c4SD] (zh:…
      我没有真正理解格鲁吉亚｜纪行 mini.caixin.com
  - (2026-08-15) 旺旺董事长发内部信：公司面临“重大经营危机” - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBhSzN6d0ZsTlhmQUw4N3RaT04zb2FZcXhEeWZ3anlCMGlOeXJxSU9KYXRWN2ROOENWWlM3WFpzeHZ0RlBGYU] (zh:…
      旺旺董事长发内部信：公司面临“重大经营危机” mini.caixin.com
  - (2026-08-15) 英国今夏高温相关死亡近2900例 或成史上最热夏季 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBvMTNxTUNzUUhKSUJHaFZEbk4tVFVWeW14ay1GRGoxUnZ6WFNISHpwcEdSNTZGTnlNeFNEUE1wVkItQlk5ck96bkdheFdq] (zh:…
      英国今夏高温相关死亡近2900例 或成史上最热夏季 财新

### Local News: St. Louis + Atlanta — 94 new of 211 total
  - (2026-08-14) [St. Louis] Photos: St. Louis Kids Book Club at Clark Family Branch
      On August 13, 2026, families gathered at the St. Louis County Library’s Clark Family Branch for St. Louis Magazine’s Kids Book Club, presented by PNC and The Clark Family and hosted by St. Louis County Library. The month…
  - (2026-08-14) [St. Louis] St. Louis city jail loses power as heat wave shocks the region
  - (2026-08-15) [St. Louis] Pixar gives first look at 'Coco 2,' announces 'Ghost Market' at D23
      The animation studio released concept art for its upcoming projects at Disney's fan event.
  - (2026-08-15) [St. Louis] Good Samaritan helps Texas police officer rescue child from burning vehicle
      The driver suffered a medical emergency and drove off the road, police said.
  - (2026-08-15) [St. Louis] St. Louis Blues hosts second annual Icebreaker Invitational for top girls hockey programs
      The event will feature appearances from local Olympians Joy and Jincy Dunne, who will participate in sessions with the young players.
  - (2026-08-15) [St. Louis] Small town, big footprint: Sauget celebrates 100 years in the Metro East
      The Metro East village has only about 120 residents, but its population swells into the thousands each workday.

### State-Level News — 78 new of 585 total
  - (2026-08-14) [California] Juez federal se dispone a restringir las tácticas de detención de inmigrantes en las redadas de Los Ángeles
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/08/081525_Immigration-Detain_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-08-14) [California] Ella se declaró culpable de un cargo de tráfico de drogas. Luego visitó México sin saber que no podría regresar.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/01/010720_CA-Supreme-Court_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-08-15) [California] Governor Newsom announces appointments 8.14.2026
      Source
  - (2026-08-14) [Colorado] Colorado Rep. Mandy Lindsay defends caucus payments during ethics hearing
      Colorado Rep. Mandy Lindsay told lawmakers on Friday that she did not fully understand the level of financial responsibility involved when she became co-chair of the House Democratic Caucus, and that there was an unset e…
  - (2026-08-14) [Connecticut] Gender-affirming care, Russia sanctions and Kalshi: CT politics news
      <img width="870" height="584" src="https://ctmirror.org/wp-content/uploads/2026/01/ct-childrens-hosp.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high" s…
  - (2026-08-15) [Alaska] After Alaska’s ‘final four’ primary, a silent primary may decide who’s on the ballot in November
      Alaska’s two leading Democratic candidates for governor have quietly been discussing whether one of them should quit the race if both are among the top four vote-getters in Tuesday’s primary election. Jonathan Kreiss-Tom…

### Ukrainian Internal News (national + local Kyiv) — 41 new of 107 total
  - (2026-08-15) ЗМІ: Прикордонники попереджали про загрозу напливу мігрантів до Сеути | LEDE: Іспанський уряд і ЄС реагують на масовий наплив мігрантів до Сеути та дезінформацію у соцмережах.] (uk: ЗМІ: Прикордонники…
      Іспанський уряд і ЄС реагують на масовий наплив мігрантів до Сеути та дезінформацію у соцмережах.
  - (2026-08-15) На Запоріжжі росіяни атакували комбайн у полі: двоє поранених | LEDE: У Запорізькому районі РФ атакувала агротехніку дроном: двоє чоловіків поранені, надається допомога.] (uk: На Запоріжжі росіяни ата…
      У Запорізькому районі РФ атакувала агротехніку дроном: двоє чоловіків поранені, надається допомога.
  - (2026-08-15) Блощинський: Уроки незалежності України через 35 років | LEDE: ] (uk: Блощинський: Уроки незалежності України через 35 років)
  - (2026-08-15) Водій УЧХ, якого затримали під час евакуації, був волонтером і не мав бронювання | LEDE: Волонтеру Червоного Хреста без бронювання завадили завершити евакуацію вразливих цивільних із Херсона.] (uk: Во…
      Волонтеру Червоного Хреста без бронювання завадили завершити евакуацію вразливих цивільних із Херсона.
  - (2026-08-15) Російський дрон атакував цивільне авто на Херсонщині: четверо поранених | LEDE: На Херсонщині дрон РФ поцілив у цивільний авто: 4 постраждалих, усім надають допомогу.] (uk: Російський дрон атакував ци…
      На Херсонщині дрон РФ поцілив у цивільний авто: 4 постраждалих, усім надають допомогу.
  - (2026-08-15) В Ірані відповіли Трампу: Ормузьку протоку неможливо захопити за допомогою твіту | LEDE: Іран відкинув наміри Трампа оголосити Ормузьку протоку територією США, назвавши це неможливим.] (uk: В Ірані ві…
      Іран відкинув наміри Трампа оголосити Ормузьку протоку територією США, назвавши це неможливим.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-15) [Ondas Inc.] Form 4 (Issuer)
      filed 2026-08-15 01:54 UTC · role: Issuer — Filed: 2026-08-14 AccNo: 0001213900-26-090424 Size: 15 KB
  - (2026-08-15) [COHEN RICHARD M] Form 4 (Reporting)
      filed 2026-08-15 01:54 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001213900-26-090424 Size: 15 KB
  - (2026-08-15) [Snyderman David J.] Form 4 (Reporting)
      filed 2026-08-15 01:54 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001104659-26-097436 Size: 55 KB
  - (2026-08-15) [CoreWeave, Inc.] Form 4 (Issuer)
      filed 2026-08-15 01:54 UTC · role: Issuer — Filed: 2026-08-14 AccNo: 0001104659-26-097436 Size: 55 KB
  - (2026-08-15) [Supernova Management LLC] Form 4 (Reporting)
      filed 2026-08-15 01:54 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001104659-26-097436 Size: 55 KB
  - (2026-08-15) [Magnetar Capital Partners LP] Form 4 (Reporting)
      filed 2026-08-15 01:54 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001104659-26-097436 Size: 55 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-15) [Iceland] Platform of the Government – Report from the Prime Minister | IceNews
      domain: icenews.is · language: English · tone:
  - (2026-08-15) [United States] Cellebrite DI ( NASDAQ : CLBT ) Price Target Cut to $12 . 50 by Analysts at Needham & Company LLC
      domain: themarketsdaily.com · language: English · tone:
  - (2026-08-15) [United States] Arizona senators demand Pentagon answers over USS Lincoln conditions
      domain: azfamily.com · language: English · tone:
  - (2026-08-15) [Somalia] August 15 , 2026 - Raxanreeb Online
      domain: raxanreeb.com · language: English · tone:
  - (2026-08-15) [United States] NYT : Government Investigated Left - Leaning Groups Amid Minnesota Unrest
      domain: talkradio1059.iheart.com · language: English · tone:
  - (2026-08-15) [United States] Everett Harris & Co . CA Takes $3 . 18 Million Position in Yum ! Brands , Inc . $YUM
      domain: themarketsdaily.com · language: English · tone:

### Court opinions of consequence (federal & state) — 31 new of 60 total
  - (2026-08-14) U.S. Court of Appeals, 3rd Cir.: Jose Aristy-Rosa v. Attorney General United States of America
  - (2026-08-14) U.S. Court of Appeals, 1st Cir.: Dorcas International Institute of Rhode Island v. United States Citizenship and Immigration Services
  - (2026-08-14) U.S. Court of Appeals, 1st Cir.: Dorcas International Institute of Rhode Island v. United States Citizenship and Immigration Services
  - (2026-08-14) U.S. Court of Appeals, 7th Cir.: Johnnie Savory v. Allen Andrews
  - (2026-08-14) U.S. Court of Appeals, 7th Cir.: Johnnie Savory v. Allen Andrews
  - (2026-08-14) U.S. Court of Appeals, 7th Cir.: Lynnette Kaiser v. Alcoa USA Corp.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 29 new of 34 total
  - (2026-08-14) M 7.7 - 68 km NNW of Ende, Indonesia
      M7.7 · 68 km NNW of Ende, Indonesia · depth 10 km · PAGER orange
  - (2026-08-14) M 6.1 - 58 km N of Ende, Indonesia
      M6.1 · 58 km N of Ende, Indonesia · depth 10 km
  - (2026-08-14) M 5.9 - 36 km NE of Labuan Bajo, Indonesia
      M5.9 · 36 km NE of Labuan Bajo, Indonesia · depth 10 km
  - (2026-08-14) M 5.6 - 61 km NNW of Ende, Indonesia
      M5.6 · 61 km NNW of Ende, Indonesia · depth 10 km
  - (2026-08-14) M 5.5 - 49 km NE of Labuan Bajo, Indonesia
      M5.5 · 49 km NE of Labuan Bajo, Indonesia · depth 10 km
  - (2026-08-15) M 5.4 - 38 km SSE of Severo-Kuril’sk, Russia
      M5.4 · 38 km SSE of Severo-Kuril’sk, Russia · depth 78.982 km

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-15) [Israel-Iran-Hezbollah axis · themes] 抗战馆举办 八 · 一五 主题社教活动 重温峥嵘岁月 _ 新闻频道 _ 中华网
      news.china.com · Chinese · tone NA
  - (2026-08-15) [Israel-Iran-Hezbollah axis · themes] Korban Gempa Maumere NTT Bertambah , 3 Orang Tewas Tertimpa Reruntuhan di Pelabuhan
      lampung.tribunnews.com · Indonesian · tone NA
  - (2026-08-15) [Israel-Iran-Hezbollah axis · themes] La asunción de la Virgen María : el misterio de su final , la promesa de la eternidad y por qué es un dogma que sigue interpelando
      infobae.com · Spanish · tone NA
  - (2026-08-15) [Israel-Iran-Hezbollah axis · themes] Trump amenință că va declara Strâmtoarea Ormuz „ teritoriu al Statelor Unite : „ Nicio navă nu trece decât dacă vrem noi
      adevarul.ro · Romanian · tone NA
  - (2026-08-15) [Israel-Iran-Hezbollah axis · themes] Ογδόντα έξι χρόνια από τον τορπιλισμό της Έλλης στην Τήνο - Η διαταγή και ...
      thetoc.gr · Greek · tone NA
  - (2026-08-15) [Israel-Iran-Hezbollah axis · themes] Zakaz wyburzania ścian w mieszkaniu . Połączenie kuchni z salonem lub wydzielenie pokoi bez pozwolenia na budowę może słono kosztować
      forsal.pl · Polish · tone NA

### Government & military aircraft airborne (OpenSky) — 22 new of 22 total
  - (2026-08-15) NCR361 (United States)
      icao24: ab4ec6 · position: (37.2669, -82.3356) · alt: 11277m · 874km/h
  - (2026-08-15) JAF5KH (Belgium)
      icao24: 44d1ba · position: (38.015, 26.1677) · alt: 8709m · 771km/h
  - (2026-08-15) JAF9WL (Belgium)
      icao24: 44d1a7 · position: (48.336, 2.1132) · alt: 9753m · 829km/h
  - (2026-08-15) JAF3MJ (Belgium)
      icao24: 44d1a5 · position: (39.9904, -2.5076) · alt: 10972m · 876km/h
  - (2026-08-15) JAF74C (Belgium)
      icao24: 44d1b3 · position: (36.4041, 28.0906) · on ground
  - (2026-08-15) JAF3LV (Belgium)
      icao24: 44d1c2 · position: (39.9797, 7.6249) · alt: 11582m · 824km/h

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-08-15) Dota 2: TEAM VISION vs Team Spirit - Game 2 Winner
      yes price: 100% · 24h volume: $1,553,696 · resolves 2026-08-15
  - (2026-08-15) Dota 2: Iron Wing vs Team Liquid (BO3) - The International Group Stage
      yes price: 62% · 24h volume: $1,379,014 · resolves 2026-08-15
  - (2026-08-15) LoL: Hanwha Life Esports vs KT Rolster - Game 1 Winner
      yes price: 0% · 24h volume: $906,378 · resolves 2026-08-15
  - (2026-08-15) LoL: Ninjas in Pyjamas vs LNG Esports - Game 1 Winner
      yes price: 100% · 24h volume: $790,716 · resolves 2026-08-15
  - (2026-08-15) Dota 2: Iron Wing vs Team Liquid - Game 2 Winner
      yes price: 0% · 24h volume: $756,796 · resolves 2026-08-15
  - (2026-08-15) Dota 2: TEAM VISION vs Team Spirit (BO3) - The International Group Stage
      yes price: 100% · 24h volume: $741,701 · resolves 2026-08-15

### U.S. Federal Action — 14 new of 20 total
  - (2026-08-17) National Substance Use Primary Prevention Month, 2026
  - (2026-08-17) Revocation of Class E Airspace; Santa Elena, TX
      This action proposes to revoke the Class E airspace at Diamond "O" Ranch Airport, Santa Elena, TX. The FAA is proposing this action due to the instrument procedures being cancelled and the decommissioning of the Santa El…
  - (2026-08-17) Proposed Removal of a Reporting Requirement for Trusts Whose Charitable Contribution Deductions Are Solely for Contributions Made by Passthrough Entities
      This document contains proposed regulations that would amend existing regulations that require certain trusts to report all charitable contributions and amounts permanently set aside for a charitable purpose on Form 1041…
  - (2026-08-17) Supplemental Nutrition Assistance Program: Changes in Federal-State Administrative Cost Sharing; Extension of Comment Period
      The U.S. Department of Agriculture's (USDA) Food and Nutrition Administration (FNA) is extending the public comment period on the proposed rule, "Supplemental Nutrition Assistance Program: Changes in Federal-State Admini…
  - (2026-08-17) Safety Zone; Fox River, Green Bay, WI
      The Coast Guard is establishing a temporary safety zone for navigable waters on the Fox River, in Green Bay, WI. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards…
  - (2026-08-17) Establishment of Class E Airspace; DeKalb, IL
      This action proposes to establish Class E airspace at Northwestern Memorial Healthcare Heliport, DeKalb, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operatio…

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 93 total
  - (2026-08-15) [USASpending] $2,968,313,532 → CALIFORNIA INSTITUTE OF TECHNOLOGY: EUROPA CLIPPER PROJECT THE CONTRACT IS THE SPONSORING AGREE
      Agency: National Aeronautics and Space Administration. Description: EUROPA CLIPPER PROJECT THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION NASA AND THE CALIFORNIA INSTIT…
  - (2026-08-15) [USASpending] $2,744,085,731 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2026-08-15) [USASpending] $2,593,013,819 → SAVANNAH RIVER MISSION COMPLETION, LLC: THIS AWARD IS FOR THE SAVANNAH RIVER INTEGRATED MISSION COMP
      Agency: Department of Energy. Description: THIS AWARD IS FOR THE SAVANNAH RIVER INTEGRATED MISSION COMPLETION CONTRACT - TASK ORDER 6 (LIQUID WASTE OPERATIONS).
  - (2026-08-15) [USASpending] $1,605,134,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-08-15) [USASpending] $1,576,702,409 → HANFORD TANK WASTE OPERATIONS & CLOSURE, LLC: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITI
      Agency: Department of Energy. Description: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITION CONTRACT VIA THE IMPLEMENTATION TASK ORDER, TO-02.
  - (2026-08-15) [USASpending] $1,396,333,903 → AT&T ENTERPRISES, LLC: ENTERPRISE DATA NETWORK SERVICES CARRIER B
      Agency: Department of Veterans Affairs. Description: ENTERPRISE DATA NETWORK SERVICES CARRIER B

### IT, InfoSys & cybersecurity news (last 7 days) — 10 new of 58 total
  - (2026-08-15) [The Register] Lego's supersized Hubble deserves a little more shine
      Excellent internal detail cannot entirely disguise some penny-pinching choices
  - (2026-08-15) [The Register] Anthropic says text watermarking scheme relies on inconsequential words
      'Shall I compare thee to a summer's afternoon' is the sort of thing this will make, and others look likely to adopt it
  - (2026-08-14) [BleepingComputer] How Anthropic plans to watermark Claude's AI-generated text
      It could soon become easier to identify AI-generated content, even if it's not the usual "It's Not X, it's Y" type of post you'd come across on LinkedIn and other socials. [...]
  - (2026-08-14) [The Record] Investigation of banking hack leads to arrests in Germany, Brazil
      Germany’s federal police agency, the BKA, said three suspects were picked up in Europe and charged with fraud, and Brazil’s federal police said four others were arrested on similar charges.
  - (2026-08-14) [Schneier on Security] Friday Squid Blogging: Searching for the Colossal Squid
      Fascinating video about searching for life undersea. The video basically makes the point that our bright white searchlights are scaring everything away, and that red light is more neutral. That, plus bait to attract sea…
  - (2026-08-14) [The Register] DeepSeek's innovative harness treats everything as a plug-in
      Chinese AI labs keep moving forward while US labs play defense

### Paper Trading Scorecard — 8 new of 143 total
  - (2026-08-15) [Manifold] Will Bitcoin hit $100.000 before 34000$?
  - (2026-08-15) [Manifold] Will OpenAI Astra beat Opus 5 on Artificial Analysis
  - (2026-08-15) [Manifold] Mitch McConnell alive all of October 2026?
  - (2026-08-15) [Manifold] Strait of Hormuz is an American territory before start of 2030?
  - (2026-08-15) [Manifold] Выйдет ли Subtransit Drive в сентябре
  - (2026-08-15) [Manifold] 🇺🇸🇨🇦 Will the U.S. and Canada reach a deal to prevent new 50% U.S. tariffs on Canadian imports by August 19, 2026?

### State Legislative Action — 4 new of 129 total
  - (2026-08-14) [Alaska SB 158] An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
      An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
  - (2026-08-14) [Alaska HB 10] An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
      An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
  - (2026-08-14) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-08-14) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-08-15) [Marginal Revolution] A Conservative Case for Liberal Immigration
      That is the title of my latest Free Press piece, here is one excerpt: Or look at the AI revolution, another area where America is leading the world and also using its AI models to exert soft power. Dario Amodei of Anthro…
  - (2026-08-15) [Marginal Revolution] That was then, this is now
      I very much like the new Michael Khodarkovsky book The Steppe and its Empires: The Russian Empire & its Eurasian Counterparts. Excerpt: Russia presented the most remarkable contrast to both Eurasian and Western empires.…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-15) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: provide, special, remove, proposing, program, action, procedures, certain, service, final, proposed, proposes
- state_bills: today=129, 7d-median=129, 14d-median=129; carrying terms: things, residential, every, related, supplemental, education, certified, facilities, necessary, vehicle, taxation, prior
- state_news: today=585, 7d-median=585, 14d-median=686; carrying terms: hampshire, senators, attempt, bipartisan, continues, network, lawmakers, massachusetts, previous, maine, press, spending
- local_news: today=211, 7d-median=229, 14d-median=234; carrying terms: alert, charged, scaled, inside, morning, mother, found, concerns, south, child, medical, saturday
- foreign_news: today=1007, 7d-median=1007, 14d-median=1022; carrying terms: winner, rsquo, scheme, parked, survivors, attempt, continues, clash, worker, press, buildings, towards
- chinese_internal: today=271, 7d-median=269, 14d-median=270; carrying terms: cbmibefvx, cbmizkfvx, cbmiakfvx, global, cbmia, cbmiaefvx, google, cbmibkfvx, lxtfb, cbmiykfvx, china, target
- russian_internal: today=1040, 7d-median=1040, 14d-median=1060; carrying terms: politico, novayagazeta, axios, russian, title, street, wildberries, reuters, europe, laquo, guardian, found
- ukrainian_internal: today=107, 7d-median=107, 14d-median=107; carrying terms: warns, strikes, continues, court, across, region, russian, winter, senior, operations, ukrainian, several
- ukraine_theater: today=1152, 7d-median=1001, 14d-median=810; carrying terms: fkofcyq, fnsxi, cuxpdxvzsdnyqvn, pjqlbmc, edrorvhnqxrpvnd, nvcwd, staff, tzwfjbuxdvfvmmgg, oddhvvfyrzjzt, hewljiugrgx, xujlrdmv, press
- paper_bets: today=143, 7d-median=129, 14d-median=138; carrying terms: california, hampshire, election, earthquake, mbappe, mexico, supreme, maine, james, district, goals, court
- weather: today=236, 7d-median=182, 14d-median=190; carrying terms: alert, howard, portions, include, norton, continues, along, elevated, afdokx, aviation, clark, weekend
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, consumption, pcepilfe, unrate, supply, rates, jtsjol, openings, nonfarm, energy, latest, money
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: agriculture, silver, rates, crude, proxy, russell, credit, natural, close, yield, bitcoin, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=93, 7d-median=99, 14d-median=99; carrying terms: representative, russia, sudan, february, concerning, legislation, destabilising, areas, content, federation, protecting, economic
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiver, quiverquant, https, congresstrading, error, quantitative, unauthorized, httperror
- billionaires: today=30, 7d-median=34, 14d-median=35; carrying terms: exchange, technology, microsoft, finance, buffett, investments, tesla, retail, canada, zuckerberg, thomas, walton
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, connecticut, state, appeals, blanche, international, group, trade, company, health, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, financial, robert, richard, partners
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: warner, senate, disbursements, house, filing, raised, krishnamoorthi, booker, ossoff, david, receipts, elect
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, korea, south, japan, koreaherald
- gdelt_gkg: today=25, 7d-median=25, 14d-median=42; carrying terms: english, themes, russian, trump, chinese, hezbollah, spanish, israel, china, arabic, german, indonesian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: language, kingdom, english, iheart, india, domain
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=30, 14d-median=28; carrying terms: position, belgium, ground, france, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: alert, months, netherlands, regio, valley, batches, patient, kozhikode, transmission, point, internationally, received
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: product, using, injection, secure, sensitive, authentication, vendor, untrusted, firewall, langflow, cisco, alternate
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=251; carrying terms: alert, papua, maximum, montenegro, canada, green, russia, ukraine, earthquake, cyclone, belize, marino
- usgs_quakes: today=34, 7d-median=13, 14d-median=13; carrying terms: depth, islands, russia, indonesia, region, japan, severo, kuril, vanuatu, solomon
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: winner, rates, donetsk, traffic, september, strait, league, august, normal, meeting, interest, price
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, marginal, economist, revolution, conversable, https, marginalrevolution, conversableeconomist, believe, future, young, impossible
- tech_news: today=58, 7d-median=58, 14d-median=56; carrying terms: researchers, across, companies, problems, weekday, computer, edition, program, infrastructure, safety, vulnerabilities, cloud
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: cleaver, letlow, banks, wyden, sharice, susie, thomas, krishnamoorthi, stefanik, scalise, gallego, julie
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, evidence, market, placement, today, consensus, converges, identify, module, decision, sufficient, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*