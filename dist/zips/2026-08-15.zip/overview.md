# WORLDSCOPE morning brief — 2026-08-15

## Headline
2058 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (439) · Russian Internal News (state + in-exile) (337) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (230) · Chinese Internal News (137) · Local News: St. Louis + Atlanta (106) · GDELT GKG — themes / entities / watch areas (97) · State-Level News (69) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (34) · Court opinions of consequence (federal & state) (32)

## What changed today
### International News + Multilateral Institutions — 439 new of 1011 total
  - (2026-08-15) [Global] South Korea’s president wants talks with North to end Korean War
      South Korean President Lee Jae Myung has proposed talks with North Korea to formally end the Korean War.
  - (2026-08-15) [Global] Small-scale projects offer hope for Gaza farmers rebuilding lives
      Greenhouses and rented plots are lifelines for Gaza's farmers, helping them grow crops despite the extensive destruction
  - (2026-08-15) [Global] How a Sudanese refugee became a head teacher in a Chadian camp
      Displaced by Sudan’s war, Sahra now leads a refugee school where education offers children safety and hope.
  - (2026-08-15) [Global] Morocco boosts Ceuta security amid calls for mass migrant crossing
      Morocco has added barbed wire and more police near Spain’s Ceuta enclave after online calls for another mass crossing.
  - (2026-08-15) [Global] On the ground in Indonesia following 7.7 magnitude earthquake
      A powerful 7.7 magnitude earthquake struck off eastern Indonesia early Saturday, killing at least five people.
  - (2026-08-15) [Global] Taiwan passes defence budget after record delay, retains drone funding
      Taiwan parliament ends deadlock, ensuring vital drone programme funding amid rising cross-strait tensions with Beijing.

### Russian Internal News (state + in-exile) — 337 new of 1017 total
  - (2026-08-15) ВСУ атаковали Самарскую область ракетами. Телеграм-каналы сообщают о пожаре на космическом предприятии РКЦ «Прогресс». В Нижегородской области под удар попал аэродром | LEDE: Украина провела] (ru: ВСУ…
      Украина провела массированную ракетную атаку Самарской области, сообщают местные чиновники. Глава региона Вячеслав Федорищев заявил, что под удар попало промышленное предприятие. Информацию о пострадавших и последствиях…
  - (2026-08-15) Антибиотики работают все хуже и хуже — но почти никому нет до этого дела. Почему? И опасно ли их принимать без повода, скажем, при ОРВИ? Отвечает биохимик Дмитрий Гиляров | LEDE: Люди все ча] (ru: Ант…
      Люди все чаще умирают из-за бактерий, с которыми не могут справиться антибиотики. При этом новые препараты для борьбы с такими инфекциями почти не появляются. Почему так происходит? Кто виноват в том, что антибиотикорези…
  - (2026-08-15) «Оглядываясь на всю его карьеру, я в шоке от этого прогресса». Спецкор «Медузы» Андрей Перцев рассказывает о Николае Рыбакове — главе «Яблока» и новом любимом политике российской антивоенной мо] (ru:…
      10 августа у здания Верховного суда, где рассматривался иск о снятии с выборов в Госдуму партии «Яблоко», собралась толпа в несколько сотен человек — в основном, около 20 лет и младше. Аплодисментами и одобрительными кри…
  - (2026-08-14) Из Google Play удалили приложения Ozon | LEDE: Приложения Ozon, Ozon Fresh, Ozon Seller, Ozon Job и Ozon Travel пропали из Google Play — магазина приложений для Android-устройств. Причины уд] (ru: Из…
      Приложения Ozon, Ozon Fresh, Ozon Seller, Ozon Job и Ozon Travel пропали из Google Play — магазина приложений для Android-устройств. Причины удаления приложений неизвестны.
  - (2026-08-14) Бывшего профессора Кембриджа Джейсона Ардея нашли мертвым. Он уволился из университета после обвинений в плагиате | LEDE: Бывший профессор социологии Кембриджского университета Джейсон Ардей] (ru: Быв…
      Бывший профессор социологии Кембриджского университета Джейсон Ардей был найден мертвым на юге Лондона, сообщает BBC News.
  - (2026-08-15) В Казани запретили объявления о сдаче жилья в аренду только славянам | LEDE: ] (ru: В Казани запретили объявления о сдаче жилья в аренду только славянам)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 230 new of 237 total
  - (2026-08-15) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 15 at 2:23AM CDT until August 15 at 3:15AM CDT by NWS Lincoln IL
      SVRILX The National Weather Service in Lincoln has issued a * Severe Thunderstorm Warning for... Tazewell County in central Illinois... Southern Peoria County in central Illinois... * Until 315 AM CDT. * At 223 AM CDT, s…
  - (2026-08-15) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 15 at 2:21AM CDT until August 15 at 2:30AM CDT by NWS Lincoln IL
      At 221 AM CDT, a severe thunderstorm was located near Easton, or 9 miles northwest of Mason City, moving east at 35 mph. HAZARD...60 mph wind gusts and penny size hail. SOURCE...Radar indicated. IMPACT...Expect damage to…
  - (2026-08-15) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 15 at 2:20AM CDT until August 15 at 2:30AM CDT by NWS Hastings NE
      The storms which prompted the warning have moved out of the area. Therefore, the warning will be allowed to expire.
  - (2026-08-15) [Severe] Flash Flood Warning: Flash Flood Warning issued August 15 at 2:19AM CDT until August 15 at 5:30AM CDT by NWS Lincoln IL
      FFWILX The National Weather Service in Lincoln has issued a * Flash Flood Warning for... Southeastern McLean County in central Illinois... * Until 530 AM CDT. * At 218 AM CDT, Doppler radar indicated thunderstorms produc…
  - (2026-08-15) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-15) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued August 15 at 3:14AM EDT until August 15 at 9:00AM EDT by NWS Pittsburgh PA
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Portions of east central Ohio, southwest and western Pennsylvania and northern and the northern panhandle of West Virginia. * WHEN...Until 9 AM EDT thi…

### Chinese Internal News — 137 new of 268 total
  - (2026-08-14) 武大靖执教，中国短道速滑能否弯道超车？｜体坛 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFAzOFhSbWhQRnBHVlE1V0JhUVpnWHdySENyLUxldThKX0VyTGc4SFR2RUlQSGpXek15RU5uOGZBSzE3OHVZdl] (zh:…
      武大靖执教，中国短道速滑能否弯道超车？｜体坛 mini.caixin.com
  - (2026-08-15) 旅行最大的乐趣之一，其实是回家｜生命情感对话⑧ - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBrT0tHQWctdWFyZWEzRllINzdjY0NkeHg3dFVxT2pSNlhOeUl3dDg1dmhzbXlDYUNBQVNfOFNNTmZabUJud] (zh:…
      旅行最大的乐趣之一，其实是回家｜生命情感对话⑧ mini.caixin.com
  - (2026-08-14) 我没有真正理解格鲁吉亚｜纪行 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1WcnJpNWdyc3R2YTRMLWJybV9KQmNrd0k1YjlNUm9OLS1iNEdLODRiaVp2SEIxSGExdXhUTThtSWI4U3pnWmYzU3c4SD] (zh:…
      我没有真正理解格鲁吉亚｜纪行 mini.caixin.com
  - (2026-08-15) 朱学东：夏日当家菜咸菜｜饮食 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE52OVZHV1E0Z04xVVRHV2NWQnVXX1liQ0FoeTA0NXgtT2xYVGplTXM3bnlxQWthd2x5YzBOVGx2OUxxaE1NMXVWTV95Zl] (zh:…
      朱学东：夏日当家菜咸菜｜饮食 mini.caixin.com
  - (2026-08-15) 旺旺董事长发内部信：公司面临“重大经营危机” - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBhSzN6d0ZsTlhmQUw4N3RaT04zb2FZcXhEeWZ3anlCMGlOeXJxSU9KYXRWN2ROOENWWlM3WFpzeHZ0RlBGYU] (zh:…
      旺旺董事长发内部信：公司面临“重大经营危机” mini.caixin.com
  - (2026-08-15) 育有二孩后特朗普发言人决定离职 29岁莱维特如何改变白宫政媒生态 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9STHJMbUhhcVRUNGFhaDR6bmlBbFF4VExkUWYxZTNmaXZWNUZqM0Fab1ozZTNNclJubzdZSUx1aks3QXNEV3Z2R] (zh:…
      育有二孩后特朗普发言人决定离职 29岁莱维特如何改变白宫政媒生态 财新

### Local News: St. Louis + Atlanta — 106 new of 229 total
  - (2026-08-14) [St. Louis] Photos: St. Louis Kids Book Club at Clark Family Branch
      On August 13, 2026, families gathered at the St. Louis County Library’s Clark Family Branch for St. Louis Magazine’s Kids Book Club, presented by PNC and The Clark Family and hosted by St. Louis County Library. The month…
  - (2026-08-15) [St. Louis] Pixar gives first look at 'Coco 2,' announces 'Ghost Market' at D23
      The animation studio released concept art for its upcoming projects at Disney's fan event.
  - (2026-08-15) [St. Louis] Good Samaritan helps Texas police officer rescue child from burning vehicle
      The driver suffered a medical emergency and drove off the road, police said.
  - (2026-08-15) [St. Louis] St. Louis Blues hosts second annual Icebreaker Invitational for top girls hockey programs
      The event will feature appearances from local Olympians Joy and Jincy Dunne, who will participate in sessions with the young players.
  - (2026-08-15) [St. Louis] Small town, big footprint: Sauget celebrates 100 years in the Metro East
      The Metro East village has only about 120 residents, but its population swells into the thousands each workday.
  - (2026-08-15) [St. Louis] 6 dead, including suspect, in series of killings in Michigan
      Michigan State Police said the shooting victims were found in three locations.

### GDELT GKG — themes / entities / watch areas — 97 new of 97 total
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Oil climbs over US$1 on tanker attacks , no progress on peace
      businesstimes.com.sg · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Scott McKay The Necessary Men Episode 2 : The Faraway Plans | The American Spectator
      spectator.org · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Britains forgotten proxy war against Russia
      iraqsun.com · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Russian retribution , Islamic NATO , showdown in the West Bank , the German spy machine : RT stories that shaped the week
      iraqsun.com · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Worse is coming for Ukraine Lavrov
      europesun.com · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Worse is coming for Ukraine
      europesun.com · English · tone NA

### State-Level News — 69 new of 584 total
  - (2026-08-15) [California] Governor Newsom announces appointments 8.14.2026
      Source
  - (2026-08-14) [Colorado] Colorado Rep. Mandy Lindsay defends caucus payments during ethics hearing
      Colorado Rep. Mandy Lindsay told lawmakers on Friday that she did not fully understand the level of financial responsibility involved when she became co-chair of the House Democratic Caucus, and that there was an unset e…
  - (2026-08-14) [California] Juez federal se dispone a restringir las tácticas de detención de inmigrantes en las redadas de Los Ángeles
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/08/081525_Immigration-Detain_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-08-14) [California] Ella se declaró culpable de un cargo de tráfico de drogas. Luego visitó México sin saber que no podría regresar.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/01/010720_CA-Supreme-Court_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-08-14) [Arkansas] Arkansas panel revises proposal restricting access to ‘sexually explicit’ library materials
      The Arkansas State Library Board on Friday revised its proposed rule limiting access to “sexually explicit” materials over concerns its original proposal could unfairly punish libraries that accidentally place restricted…
  - (2026-08-14) [Arizona] Abuse victims ask Arizona high court to reconsider its clergy-shield ruling
      Attorneys representing the children of a father who sexually abused them and reported that abuse to church leaders are asking the Arizona Supreme Court to reconsider its unanimous ruling last month siding with religious…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-15) [Ondas Inc.] Form 4 (Issuer)
      filed 2026-08-15 01:54 UTC · role: Issuer — Filed: 2026-08-14 AccNo: 0001213900-26-090424 Size: 15 KB
  - (2026-08-15) [COHEN RICHARD M] Form 4 (Reporting)
      filed 2026-08-15 01:54 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001213900-26-090424 Size: 15 KB
  - (2026-08-15) [Snyderman David J.] Form 4 (Reporting)
      filed 2026-08-15 01:54 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001104659-26-097436 Size: 55 KB
  - (2026-08-15) [CoreWeave, Inc.] Form 4 (Issuer)
      filed 2026-08-15 01:54 UTC · role: Issuer — Filed: 2026-08-14 AccNo: 0001104659-26-097436 Size: 55 KB
  - (2026-08-15) [Supernova Management LLC] Form 4 (Reporting)
      filed 2026-08-15 01:54 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001104659-26-097436 Size: 55 KB
  - (2026-08-15) [Magnetar Capital Partners LP] Form 4 (Reporting)
      filed 2026-08-15 01:54 UTC · role: Reporting — Filed: 2026-08-14 AccNo: 0001104659-26-097436 Size: 55 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-15) [Azerbaijan] EU has no moral standing to lecture Iran on human rights , Araghchi says
      domain: news.az · language: English · tone:
  - (2026-08-15) [India] The torn screen of Partition
      domain: newindianexpress.com · language: English · tone:
  - (2026-08-15) [India] Kashmiri diaspora holds black day protest in Bradford , demands end to Pakistani presence
      domain: aninews.in · language: English · tone:
  - (2026-08-15) [Singapore] US to tell partners they must pick sides in AI race with China
      domain: asiaone.com · language: English · tone:
  - (2026-08-15) [Canada] BEER : Railway City back under local ownership
      domain: whitecourtstar.com · language: English · tone:
  - (2026-08-15) [India] Who were Deontre Huey , Seth Olmstead ? Salado helicopter crash pilots identified by Fort Hood
      domain: hindustantimes.com · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 34 new of 102 total
  - (2026-08-15) В Ірані відповіли Трампу: Ормузьку протоку неможливо захопити за допомогою твіту | LEDE: Іран відкинув наміри Трампа оголосити Ормузьку протоку територією США, назвавши це неможливим.] (uk: В Ірані ві…
      Іран відкинув наміри Трампа оголосити Ормузьку протоку територією США, назвавши це неможливим.
  - (2026-08-15) Качинський заявив про "незаконні розкопки" в Україні | LEDE: Лідер партії "Право і справедливість" Ярослав Качинський заявив про нібито незаконні розкопки на місцях колишніх польських сіл на те] (uk:…
      Лідер партії "Право і справедливість" Ярослав Качинський заявив про нібито незаконні розкопки на місцях колишніх польських сіл на території України.
  - (2026-08-15) Британці отримали попередження через ризик пожеж | LEDE: ] (uk: Британці отримали попередження через ризик пожеж)
  - (2026-08-15) РФ запустила по Україні понад 150 дронів: є влучання на 16 локаціях – ПС | LEDE: 15 серпня Повітряні сили збили 124 російські дрони та три “Бандеролі” під час масованої атаки.] (uk: РФ запустила по Ук…
      15 серпня Повітряні сили збили 124 російські дрони та три “Бандеролі” під час масованої атаки.
  - (2026-08-15) Дві сили. Хто насправді вибудовував Незалежність | LEDE: Колонка Дениса Блощинського: до чого нас вчить співпраця Степу і Республіки в історії України.] (uk: Дві сили. Хто насправді вибудовував Незале…
      Колонка Дениса Блощинського: до чого нас вчить співпраця Степу і Республіки в історії України.
  - (2026-08-15) РФ звітує про майже 600 "збитих" українських дронів за ніч | LEDE: Міноборони РФ повідомило про знищення 598 безпілотників, але доказів цьому не надало.] (uk: РФ звітує про майже 600 "збитих" українсь…
      Міноборони РФ повідомило про знищення 598 безпілотників, але доказів цьому не надало.

### Court opinions of consequence (federal & state) — 32 new of 60 total
  - (2026-08-14) U.S. Court of Appeals, 1st Cir.: Dorcas International Institute of Rhode Island v. United States Citizenship and Immigration Services
  - (2026-08-14) U.S. Court of Appeals, 1st Cir.: Dorcas International Institute of Rhode Island v. United States Citizenship and Immigration Services
  - (2026-08-14) U.S. Court of Appeals, 7th Cir.: Johnnie Savory v. Allen Andrews
  - (2026-08-14) U.S. Court of Appeals, 7th Cir.: Johnnie Savory v. Allen Andrews
  - (2026-08-14) U.S. Court of Appeals, 7th Cir.: Lynnette Kaiser v. Alcoa USA Corp.
  - (2026-08-14) U.S. Court of Appeals, 7th Cir.: Irma Herrera v. United States

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Ukraine Theater (total-war monitoring) — 29 new of 234 total
  - (2026-08-15) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-15) [Liveuamap] Smoke is rising after missile strike in Samara - Liveuamap
      Smoke is rising after missile strike in Samara Liveuamap
  - (2026-08-14) [Liveuamap] Poland said its security services prevented the assassination of a US citizen originally from Ukraine that was ordered by Russian intelligence. The country&039;s Internal Security Agency,…
      Poland said its security services prevented the assassination of a US citizen originally from Ukraine that was ordered by Russian int
  - (2026-08-15) [Liveuamap] IRGC Aerospace Force Major Abolfazl Heidari was critically wounded today (August 13, 2026), in an assassination attempt carried out by motorcycle-borne attackers in Zabol, Iran Sistan and…
      IRGC Aerospace Force Major Abolfazl Heidari was critically wounded today (August 13, 2026), in an assassination attempt carr
  - (2026-08-13) [Liveuamap] Scenes from the strategic port of Mocha on the Red Sea after it was targeted by Houthis. - Liveuamap
      Scenes from the strategic port of Mocha on the Red Sea after it was targeted by Houthis. <font color="#6
  - (2026-08-12) [Liveuamap] Day of news on live map - August, 10 2026 - Ukraine Interactive map - Ukraine Latest news on live map - Liveuamap
      Day of news on live map - August, 10 2026 - Ukraine Interactive map - Ukraine Latest news on live map Liveuamap

### USGS earthquakes (M4.5+, past day) — 28 new of 33 total
  - (2026-08-14) M 7.7 - 68 km NNW of Ende, Indonesia
      M7.7 · 68 km NNW of Ende, Indonesia · depth 10 km · PAGER orange
  - (2026-08-14) M 6.1 - 58 km N of Ende, Indonesia
      M6.1 · 58 km N of Ende, Indonesia · depth 10 km
  - (2026-08-14) M 5.9 - 36 km NE of Labuan Bajo, Indonesia
      M5.9 · 36 km NE of Labuan Bajo, Indonesia · depth 10 km
  - (2026-08-14) M 5.6 - 61 km NNW of Ende, Indonesia
      M5.6 · 61 km NNW of Ende, Indonesia · depth 10 km
  - (2026-08-14) M 5.5 - 49 km NE of Labuan Bajo, Indonesia
      M5.5 · 49 km NE of Labuan Bajo, Indonesia · depth 10 km
  - (2026-08-15) M 5.4 - 38 km SSE of Severo-Kuril’sk, Russia
      M5.4 · 38 km SSE of Severo-Kuril’sk, Russia · depth 78.982 km

### Government & military aircraft airborne (OpenSky) — 15 new of 16 total
  - (2026-08-15) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (43.7301, -1.8036) · alt: 10972m · 883km/h
  - (2026-08-15) JAF56C (Bulgaria)
      icao24: 4520aa · position: (41.8098, -3.1865) · alt: 10980m · 878km/h
  - (2026-08-15) GAF666 (Germany)
      icao24: 3e0f77 · position: (51.0946, 7.4997) · alt: 777m · 229km/h
  - (2026-08-15) JAF62J (Belgium)
      icao24: 44d1ba · position: (37.2905, 26.3902) · alt: 6309m · 740km/h
  - (2026-08-15) JAF13J (Belgium)
      icao24: 44d1a5 · position: (37.6068, -1.8739) · alt: 5448m · 565km/h
  - (2026-08-15) JAF40J (Belgium)
      icao24: 44d1b3 · position: (36.4803, 28.0082) · alt: 1889m · 513km/h

### U.S. Federal Action — 14 new of 20 total
  - (2026-08-17) National Substance Use Primary Prevention Month, 2026
  - (2026-08-17) Revocation of Class E Airspace; Santa Elena, TX
      This action proposes to revoke the Class E airspace at Diamond "O" Ranch Airport, Santa Elena, TX. The FAA is proposing this action due to the instrument procedures being cancelled and the decommissioning of the Santa El…
  - (2026-08-17) Proposed Removal of a Reporting Requirement for Trusts Whose Charitable Contribution Deductions Are Solely for Contributions Made by Passthrough Entities
      This document contains proposed regulations that would amend existing regulations that require certain trusts to report all charitable contributions and amounts permanently set aside for a charitable purpose on Form 1041…
  - (2026-08-17) Supplemental Nutrition Assistance Program: Changes in Federal-State Administrative Cost Sharing; Extension of Comment Period
      The U.S. Department of Agriculture's (USDA) Food and Nutrition Administration (FNA) is extending the public comment period on the proposed rule, "Supplemental Nutrition Assistance Program: Changes in Federal-State Admini…
  - (2026-08-17) Safety Zone; Fox River, Green Bay, WI
      The Coast Guard is establishing a temporary safety zone for navigable waters on the Fox River, in Green Bay, WI. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards…
  - (2026-08-17) Establishment of Class E Airspace; DeKalb, IL
      This action proposes to establish Class E airspace at Northwestern Memorial Healthcare Heliport, DeKalb, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operatio…

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 93 total
  - (2026-08-15) [USASpending] $2,968,313,532 → CALIFORNIA INSTITUTE OF TECHNOLOGY: EUROPA CLIPPER PROJECT THE CONTRACT IS THE SPONSORING AGREE
      Agency: National Aeronautics and Space Administration. Description: EUROPA CLIPPER PROJECT THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION NASA AND THE CALIFORNIA INSTIT…
  - (2026-08-15) [USASpending] $2,744,085,731 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2026-08-15) [USASpending] $2,593,013,819 → SAVANNAH RIVER MISSION COMPLETION, LLC: THIS AWARD IS FOR THE SAVANNAH RIVER INTEGRATED MISSION COMP
      Agency: Department of Energy. Description: THIS AWARD IS FOR THE SAVANNAH RIVER INTEGRATED MISSION COMPLETION CONTRACT - TASK ORDER 6 (LIQUID WASTE OPERATIONS).
  - (2026-08-15) [USASpending] $1,605,134,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-08-15) [USASpending] $1,576,702,409 → HANFORD TANK WASTE OPERATIONS & CLOSURE, LLC: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITI
      Agency: Department of Energy. Description: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITION CONTRACT VIA THE IMPLEMENTATION TASK ORDER, TO-02.
  - (2026-08-15) [USASpending] $1,396,333,903 → AT&T ENTERPRISES, LLC: ENTERPRISE DATA NETWORK SERVICES CARRIER B
      Agency: Department of Veterans Affairs. Description: ENTERPRISE DATA NETWORK SERVICES CARRIER B

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-15) Dota 2: LGD Gaming vs Xtreme Gaming (BO3) - The International Group Stage
      yes price: 100% · 24h volume: $1,504,066 · resolves 2026-08-15
  - (2026-08-15) Dota 2: Iron Wing vs Team Liquid - Game 1 Winner
      yes price: 100% · 24h volume: $734,202 · resolves 2026-08-15
  - (2026-08-15) Dota 2: Nigma Galaxy vs Vici Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $725,488 · resolves 2026-08-15
  - (2026-08-15) Dota 2: TEAM VISION vs Team Spirit - Game 1 Winner
      yes price: 100% · 24h volume: $676,526 · resolves 2026-08-15
  - (2026-08-15) Dota 2: OG vs HULIGANI (BO3) - The International Group Stage
      yes price: 100% · 24h volume: $625,463 · resolves 2026-08-15
  - (2026-08-15) Dota 2: BoomBoys vs Aurora - Game 1 Winner
      yes price: 0% · 24h volume: $602,622 · resolves 2026-08-15

### IT, InfoSys & cybersecurity news (last 7 days) — 9 new of 58 total
  - (2026-08-15) [The Register] Anthropic says text watermarking scheme relies on inconsequential words
      'Shall I compare thee to a summer's afternoon' is the sort of thing this will make, and others look likely to adopt it
  - (2026-08-14) [BleepingComputer] How Anthropic plans to watermark Claude's AI-generated text
      It could soon become easier to identify AI-generated content, even if it's not the usual "It's Not X, it's Y" type of post you'd come across on LinkedIn and other socials. [...]
  - (2026-08-14) [The Record] Investigation of banking hack leads to arrests in Germany, Brazil
      Germany’s federal police agency, the BKA, said three suspects were picked up in Europe and charged with fraud, and Brazil’s federal police said four others were arrested on similar charges.
  - (2026-08-14) [Schneier on Security] Friday Squid Blogging: Searching for the Colossal Squid
      Fascinating video about searching for life undersea. The video basically makes the point that our bright white searchlights are scaring everything away, and that red light is more neutral. That, plus bait to attract sea…
  - (2026-08-14) [The Register] DeepSeek's innovative harness treats everything as a plug-in
      Chinese AI labs keep moving forward while US labs play defense
  - (2026-08-14) [The Register] 1.6M RingCentral accounts' data dumped after ShinyHunters extortion attack
      Another one bites the dust

### Paper Trading Scorecard — 8 new of 145 total
  - (2026-08-15) [Manifold] Will Bitcoin hit $100.000 before 34000$?
  - (2026-08-15) [Manifold] Will OpenAI Astra beat Opus 5 on Artificial Analysis
  - (2026-08-15) [Manifold] Mitch McConnell alive all of October 2026?
  - (2026-08-15) [Manifold] Strait of Hormuz is an American territory before start of 2030?
  - (2026-08-15) [Manifold] Выйдет ли Subtransit Drive в сентябре
  - (2026-08-15) [Manifold] 🇺🇸🇨🇦 Will the U.S. and Canada reach a deal to prevent new 50% U.S. tariffs on Canadian imports by August 19, 2026?

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-15) [South Korea] US Threatens Measures for Iran Unprecedented Economic Isolation
      world.kbs.co.kr · English
  - (2026-08-15) [South Korea] Japanese PM Sends Offering to Yasukuni Shrine on War Surrender Anniversary
      world.kbs.co.kr · English
  - (2026-08-15) [South Korea] Lee Presents Blueprint for Peace on Korean Peninsula , Developing Ties with Japan on Liberation Day
      world.kbs.co.kr · English
  - (2026-08-15) [South Korea] Sogang University hit by personal information breach of 180 , 000
      koreaherald.com · English
  - (2026-08-15) [South Korea] Lee underscores peace with N . Korea , trust with Japan
      koreaherald.com · English
  - (2026-08-15) [South Korea] MC Mong returns to stage with first solo concert in four years
      allkpop.com · English

### State Legislative Action — 4 new of 129 total
  - (2026-08-14) [Alaska SB 158] An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
      An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
  - (2026-08-14) [Alaska HB 10] An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
      An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
  - (2026-08-14) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-08-14) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-08-15) [Marginal Revolution] A Conservative Case for Liberal Immigration
      That is the title of my latest Free Press piece, here is one excerpt: Or look at the AI revolution, another area where America is leading the world and also using its AI models to exert soft power. Dario Amodei of Anthro…
  - (2026-08-15) [Marginal Revolution] That was then, this is now
      I very much like the new Michael Khodarkovsky book The Steppe and its Empires: The Russian Empire & its Eurasian Counterparts. Excerpt: Russia presented the most remarkable contrast to both Eurasian and Western empires.…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-15) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: proposing, provide, special, action, remove, final, proposes, program, service, procedures, certain, proposed
- state_bills: today=129, 7d-median=129, 14d-median=124; carrying terms: submit, terms, business, implement, providers, social, using, actions, known, statewide, community, personal
- state_news: today=584, 7d-median=584, 14d-median=681; carrying terms: called, continues, research, attachment, former, providers, social, using, share, actions, filed, attempts
- local_news: today=229, 7d-median=229, 14d-median=230; carrying terms: class, attachment, former, million, louis, image, charged, accused, fetchpriority, people, august, families
- foreign_news: today=1011, 7d-median=1011, 14d-median=1011; carrying terms: resistance, variables, called, nanking, remembrance, continues, banque, infantino, outlets, connectionerror, jakarta, former
- chinese_internal: today=268, 7d-median=268, 14d-median=268; carrying terms: chinese, lxtfb, cbmiw, cbmiykfvx, cbmia, china, people, cbmiyefvx, cbmib, cbmiaefvx, cbmizkfvx, cbmickfvx
- russian_internal: today=1017, 7d-median=1017, 14d-median=1056; carrying terms: reuters, gazeta, error, russian, journal, times, found, istories, novaya, europe, telegram, novayagazeta
- ukrainian_internal: today=102, 7d-median=106, 14d-median=107; carrying terms: crimea, hmarochos, error, called, killing, across, officials, times, continues, former, strikes, trump
- ukraine_theater: today=234, 7d-median=780, 14d-median=776; carrying terms: cuxoymdfdjjoytlyx, cthiqkvamwfzyju, zunnjsbu, zizedhcmjuyk, blenfuamt, maintenance, smlnnvtvxa, tonga, dhvldvs, dthxmtq, mlczuvbwyk, rdmhbrxdhdf
- paper_bets: today=145, 7d-median=129, 14d-median=138; carrying terms: world, performing, koivun, romania, magnitude, mexico, anthropic, named, general, supreme, president, michigan
- weather: today=237, 7d-median=182, 14d-median=182; carrying terms: changed, houston, magnitude, increasing, eastern, mountains, synopsis, across, county, montgomery, hurricane, afdilx
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: labor, latest, cpilfesl, treasury, rates, dcoilwtico, funds, commodities, walcl, balance, payems, pcepilfe
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, equities, yield, corporate, range, treasury, rates, russell, crypto, natural, commodities, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=93, 7d-median=99, 14d-median=99; carrying terms: contractor, beirut, schools, crimea, russia, council, eastern, guatemala, entity, qaida, detect, daesh
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, https, quantitative, client, congresstrading, httperror, error, quiver, unauthorized
- billionaires: today=34, 7d-median=34, 14d-median=36; carrying terms: spacex, bettencourt, gautam, thomas, infrastructure, walmart, oracle, finance, buffett, bezos, mexico, london
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, appeals, connecticut, state, international, blanche, company, group, trade, california, trust
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, financial, robert, richard, capital, david, partners
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cortez, angels, booker, senate, raised, ossoff, cooper, ocasio, james, platner, krishnamoorthi, pinkston
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, korea, south, japan, koreaherald
- gdelt_gkg: today=97, 7d-median=25, 14d-median=48; carrying terms: english, trump, spanish, themes, hezbollah, russian, israel, russia, chinese, strait, keywords, sanctions
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: iheart, domain, kingdom, language, english, india
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=16, 7d-median=30, 14d-median=26; carrying terms: position, ground, belgium, france, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: received, among, world, strain, increase, confined, increasing, senegal, nigeria, hondius, mosquitoes, traceability
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: remediation, sensitive, product, authentication, channel, alternate, cisco, vulnerability, using, central, untrusted, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=244; carrying terms: macedonia, tanzania, liechtenstein, montenegro, orange, vietnam, philippines, romania, magnitude, minor, colombia, russia
- usgs_quakes: today=33, 7d-median=13, 14d-median=13; carrying terms: depth, russia, islands, indonesia, region, japan, kuril, severo, solomon, vanuatu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: meeting, rates, volume, price, winner, traffic, returns, strait, september, august, normal, interest
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, conversable, revolution, economist, marginal, https, conversableeconomist, marginalrevolution, believe, future, impossible, young
- tech_news: today=58, 7d-median=58, 14d-median=56; carrying terms: software, techcrunch, across, using, technica, critical, million, daily, record, weekday, already, hackers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: frost, jerome, stutzman, sorensen, marilyn, titus, balart, tuberville, palmer, cynthia, marlin, kiley
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, market, either, markets, placement, sufficient, claude, converges, placed, decision, paper, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*