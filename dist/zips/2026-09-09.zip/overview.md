# WORLDSCOPE morning brief — 2026-09-09

## Headline
3487 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (792) · Russian Internal News (state + in-exile) (747) · State-Level News (328) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (305) · Chinese Internal News (240) · Local News: St. Louis + Atlanta (203) · U.S. Weather + Severe / Climate Outlooks (123) · State Legislative Action (88) · Ukrainian Internal News (national + local Kyiv) (65) · IT, InfoSys & cybersecurity news (last 7 days) (47) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 792 new of 1004 total
  - (2026-09-09) [Global] Republican midterm convention 2026: What to know about Trump’s Dallas event
      Trump and JD Vance headline the unusual two-day Republican convention before the November midterm elections.
  - (2026-09-09) [Global] Troubled league LIV Golf files for bankruptcy protection in US
      LIV Golf says it intends to restructure its business with a $49.6m bankruptcy loan provided by the Saudi PIF.
  - (2026-09-09) [Global] What are the holes in the UK’s ban on imports from Israeli settlements?
      Over a year, the UK imported just £6m ($8.1m) in goods recorded as Palestinian, including Israeli settlement goods.
  - (2026-09-09) [Global] Video: RSF drone attack on Sudan court kills at least 13 people
      An RSF drone attack on a court in Sudan’s North Kordofan state has killed at least 13 people and wounded more than 20.
  - (2026-09-09) [Global] Did Iran capture a US submarine? What we know about the underwater drone
      Tehran lauds capturing Dive-LD vessel, while Washington insists that the submersible 'had malfunctioned a day ago'.
  - (2026-09-09) [Global] The losers of the US-Canada trade war
      The losers of the US-Canada trade war

### Russian Internal News (state + in-exile) — 747 new of 1159 total
  - (2026-09-09) В Москве резервистов привлекут к перехвату беспилотников | LEDE: В Московском военном округе будут созданы подразделения перехватчиков дронов из числа резервистов. ] (ru: В Москве резервистов привлеку…
      В Московском военном округе будут созданы подразделения перехватчиков дронов из числа резервистов.
  - (2026-09-09) «Единая Россия» и Путин, бывает, проигрывают выборы! Правда, только на отдельных участках за рубежом. Как можно там проголосовать? Инструкция для наших читателей не из России | LEDE: С 18 по] (ru: «Ед…
      С 18 по 20 сентября 2026 года в России пройдут выборы депутатов Государственной Думы IX созыва. Самым ярким событием предвыборного периода стало снятие «Яблока» — единственной партии с антивоенной позицией, которую горяч…
  - (2026-09-09) США возобновили обработку заявлений на иммиграционные визы. Но пока только для Венгрии и Польши (почему именно для них — неясно) | LEDE: Администрация Дональда Трампа возобновила обработку з] (ru: США…
      Администрация Дональда Трампа возобновила обработку заявлений на иммиграционные визы, но только из двух стран — Венгрии и Польши, рассказали четыре источника Reuters.
  - (2026-09-09) Дефицит российского бюджета превысил план на весь 2026 год уже за восемь месяцев. В Кремле говорят, что это «подвижная цифра» | LEDE: Дефицит российского бюджета за январь-август 2026 достиг] (ru: Деф…
      Дефицит российского бюджета за январь-август 2026 достиг 5,8 триллиона рублей, или 2,5% ВВП, предварительную оценку опубликовал Минфин. Это в полтора раза больше, чем за тот же период прошлого года. На весь 2026 год влас…
  - (2026-09-09) Война. 1659-й день. Марко Рубио: в ближайшие недели будет возможность разработать «дорожную карту» для переговоров | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о росси] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-09) В Кабардино-Балкарии при сходе лавины погибли 13 человек. В основном — бойцы Росгвардии, приехавшие на сборы. Это крупнейшее происшествие в горах с 2002 года | LEDE: По меньшей мере 13 челов] (ru: В К…
      По меньшей мере 13 человек погибли после схода лавины в ущелье Безенги в Кабардино-Балкарии. Лавина сошла с горы Мижирги вечером 6 сентября и накрыла группу из 33 альпинистов, находившуюся на склоне. Десять человек смогл…

### State-Level News — 328 new of 549 total
  - (2026-09-08) [Alabama] Citizens with Intellectual Disabilities Awareness Month
      Download
  - (2026-09-09) [California] Medicaid expanded beyond the population it was meant to serve. Its cost needs scrutiny, too
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/01/07262022_MLKHospital_PU_CM_04.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-09-09) [California] Will Gavin Newsom raise public safety pensions? It may hinge on his presidential hopes
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/07/072624-Park-Fire-REUTERS-FG-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-09-09) [California] What California’s insurance commissioner does — and how it affects your wallet
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082526-Ricardo-Lara-CS-GETTY-CM-01.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-09-09) [California] California sanctions insurer after it cut assisted living coverage to thousands
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/090826-Assisted-Living-IS-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-09-08) [California] Time to lock in, California voters
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Primary-Election-San-Diego_AH_CM_44.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 305 new of 486 total
  - (2026-09-09) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-08) [FIRMS] thermal anomaly 51.422, 34.218 (FRP 15.82 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-08 0911Z, FRP 15.82 MW
  - (2026-09-08) [FIRMS] thermal anomaly 51.422, 34.218 (FRP 12.92 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-08 0911Z, FRP 12.92 MW
  - (2026-09-08) [FIRMS] thermal anomaly 51.767, 34.360 (FRP 3.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-08 0911Z, FRP 3.03 MW
  - (2026-09-08) [FIRMS] thermal anomaly 52.237, 33.396 (FRP 6.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-08 0911Z, FRP 6.37 MW
  - (2026-09-08) [FIRMS] thermal anomaly 52.316, 32.707 (FRP 9.37 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-08 0913Z, FRP 9.37 MW

### Chinese Internal News — 240 new of 284 total
  - (2026-09-07) 白博文（Paul Bateman）： 资管在中国经济转型中发挥基础性作用_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBfRjc4aVNHV1cxYk9PbkRyMVdhbDB2cFhuLVp6bWNqcTBBNllsY2NHdXhOZ25ma0tna1JORF] (zh:…
      白博文（Paul Bateman）： 资管在中国经济转型中发挥基础性作用_特别呈现_手机财新网 财新
  - (2026-09-07) 顾苏君（Scott Geary）： 打破资产类别壁垒，重构投资“生态系统”_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9uOFRUZGE4aXB3YXhzdXU3MGh4SVgyTDkyU1VreWJJdllSdy1ROWNFZXpwMXJzVk05dDNZN] (zh:…
      顾苏君（Scott Geary）： 打破资产类别壁垒，重构投资“生态系统”_特别呈现_手机财新网 财新
  - (2026-09-08) 谷歌 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE5LM1VKRnNWelJQNkhzak9BdUdLb2NWalV2cjRCVGpjUjRtcVl4WmZ5bVRoU3ljSnRQTWJFNUJHVEVCTXY2STdXUXczV0JlZmZXak] (zh:…
      谷歌 deepview.caixin.com
  - (2026-09-08) “AI复活逝者”现象怎么看？最高法回应 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBBclpxNElRRGVDcUdEdmMtUFU3UmtiS1BCZVdjRE96MlJjSzVnT1J3NjZWODZ0X20zOUI1Ql9mSHRIbHNwaWh6dVpyN3ItTWxWck] (zh:…
      “AI复活逝者”现象怎么看？最高法回应 财新
  - (2026-09-08) 受贿1208万余元 工行许海被判十年半 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE91anpfTnJLUThuUmpoYnI5T0JUU1NUWEhsZktoMnhoRGlzT2tQV1VKbVBBLVdfMXRlQVFXb0NGNXZ5NHp1MFF3ZkZveFJhZ2cxeV] (zh:…
      受贿1208万余元 工行许海被判十年半 财新
  - (2026-09-08) 中金“三合一”后跻身万亿券商 多项风险指标好转 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBDelNPcy1YbUc0Z0t1eDE5cllFSm03Z3BpLVNRQ1NVUnBtdmRUXzRXWVVFWnJiRmhPRmcyRk5tbldpUmVES1dWdV9mOHZQMF] (zh:…
      中金“三合一”后跻身万亿券商 多项风险指标好转 财新

### Local News: St. Louis + Atlanta — 203 new of 226 total
  - (2026-09-09) [St. Louis] Orange cones bedevil patrons at beloved Frontenac eatery
      Grassi’s Ristorante and Deli has, for good reason, been called a hidden gem. It sits tucked behind the Forshaw furniture store on German Boulevard in Frontenac, across the street from property that not long ago belonged…
  - (2026-09-09) [St. Louis] SLU-based workforce academy gets caught in Missouri budget cuts
      When Missouri Gov. Mike Kehoe cut $53 million earlier this summer in an attempt to balance the state’s budget, a St. Louis-based initiative was among those left reeling. The Transformative Workforce Academy, which is hou…
  - (2026-09-09) [St. Louis] How a move to St. Louis saved the agtech startup Agragene
      In late 2021, things were not looking good for Agragene. The startup behind a new gene-editing technique that produces sterile flies as a form of chemical-free insect control had promising technology but was struggling t…
  - (2026-09-08) [St. Louis] Great Harvest Bread Co.’s Maplewood location to close after 25 years
      After 25 years of baking bread in St. Louis, franchisees Steve and Alecia Jawor are retiring and closing Great Harvest Bread Co. (7360 Manchester) in Maplewood. The bakery’s final day of service is September 19. The clos…
  - (2026-09-08) [St. Louis] Ask Veronica: What’s with all the new bumpouts in my neighborhood?
      If you live in the city of St. Louis or have recently visited one of its neighborhoods, you may have noticed the presence of concrete bumpouts on residential streets. For some residents, bumpouts are a welcome addition,…
  - (2026-09-08) [St. Louis] How Zach Zengue’s global upbringing shaped his path to St. Louis CITY SC
      Zach Zengue spent several years on the radar of St. Louis CITY SC sporting director Corey Wray. Wray played a large role in the Columbus Crew’s decision to draft Zengue out of Georgetown in the 2024 MLS Superdraft. Their…

### U.S. Weather + Severe / Climate Outlooks — 123 new of 125 total
  - (2026-09-09) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-09) [Moderate] Gale Warning: Gale Warning issued September 9 at 3:48AM AKDT until September 10 at 5:00AM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-09) [Moderate] Gale Warning: Gale Warning issued September 9 at 3:48AM AKDT until September 10 at 5:00AM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-09) [Moderate] Gale Warning: Gale Warning issued September 9 at 3:48AM AKDT until September 10 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-09) [Moderate] Gale Warning: Gale Warning issued September 9 at 3:48AM AKDT until September 10 at 5:00PM AKDT by NWS Anchorage AK
      Offshore Waters Forecast for the Bering Sea Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. .TO…
  - (2026-09-09) [Moderate] Gale Warning: Gale Warning issued September 9 at 3:48AM AKDT until September 10 at 5:00PM AKDT by NWS Anchorage AK
      Offshore Waters Forecast for the Bering Sea Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. .TO…

### State Legislative Action — 88 new of 88 total
  - (2026-09-09) [Alaska HB 73] An Act relating to complex care residential homes; and providing for an effective date.
      An Act relating to complex care residential homes; and providing for an effective date.
  - (2026-09-09) [Alaska HB 195] An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to th…
      An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to the prescription of opioid overdose dr…
  - (2026-09-09) [Alaska SB 104] An Act relating to the transfer of a title on the death of the owner; relating to the transferability of common interest community ownership interests; and providing for an effective d…
      An Act relating to the transfer of a title on the death of the owner; relating to the transferability of common interest community ownership interests; and providing for an effective date.
  - (2026-09-09) [Alaska HB 246] An Act relating to allocations for the special education service agency; and providing for an effective date.
      An Act relating to allocations for the special education service agency; and providing for an effective date.
  - (2026-09-09) [Alaska HB 262] An Act increasing the number of superior court judges in the third judicial district; and providing for an effective date.
      An Act increasing the number of superior court judges in the third judicial district; and providing for an effective date.
  - (2026-09-09) [Alaska HB 27] An Act relating to cardiopulmonary resuscitation education in public schools; relating to the duties of the Department of Education and Early Development; relating to medical care for m…
      An Act relating to cardiopulmonary resuscitation education in public schools; relating to the duties of the Department of Education and Early Development; relating to medical care for major emergencies; and providing for…

### Ukrainian Internal News (national + local Kyiv) — 65 new of 132 total
  - (2026-09-09) Затримали колишніх правоохоронців, які підкинули наркотики екскомбату Ширшину | LEDE: Працівники ДБР у взаємодії з ДВБ Нацполіції викрили трьох колишніх правоохоронців, нині –військових окремог] (uk:…
      Працівники ДБР у взаємодії з ДВБ Нацполіції викрили трьох колишніх правоохоронців, нині –військових окремого штурмового полку, які, за даними слідства організували провокацію та підкинули наркотичні засоби й психотропні…
  - (2026-09-09) У Кремлі заявили, що плану щодо завершення війни проти України наразі немає | LEDE: РФ не має "дорожньої карти" для врегулювання своєї війни проти України, але сподівається на відновлення трист] (uk:…
      РФ не має "дорожньої карти" для врегулювання своєї війни проти України, але сподівається на відновлення тристоронніх переговорів – Пєсков.
  - (2026-09-09) У Львові військовий ТЦК штовхав жінку, у ОТЦК кажуть: вона перешкоджала оповіщенню і розпилила газ | LEDE: У Львові стався конфлікт між військовими ТЦК і цивільною жінкою. Поліція розпочала слу] (uk:…
      У Львові стався конфлікт між військовими ТЦК і цивільною жінкою. Поліція розпочала службове розслідування щодо дій правоохоронця
  - (2026-09-09) Атака РФ на пункт пропуску "Старокозаче": серед постраждалих – громадянин Молдови | LEDE: Унаслідок атаки російського безпілотника по КПП "Старокозаче" поранено громадянина Молдови, загинули дв] (uk:…
      Унаслідок атаки російського безпілотника по КПП "Старокозаче" поранено громадянина Молдови, загинули двоє українців. МЗС уточнює дані щодо транспорту.
  - (2026-09-09) У Києві БпЛА впав у Дніпровському районі: кількість постраждалих в столиці зросла до 9 | LEDE: У Дніпровському районі Києва 9 вересня російський безпілотник впав на склади, виникла пожежа – дет] (uk:…
      У Дніпровському районі Києва 9 вересня російський безпілотник впав на склади, виникла пожежа – деталі інциденту біля ЖК "Комфорт-Таун".
  - (2026-09-09) ЗМІ: У Черкасах звільнили двох прокурорів, які фігурували на плівках розслідування НАБУ "Карфаген" | LEDE: З Черкаської обласної прокуратури 8 вересня звільнили Вікторію Дидич та Максима Штомпе] (uk:…
      З Черкаської обласної прокуратури 8 вересня звільнили Вікторію Дидич та Максима Штомпеля, які фігурували на плівках, оприлюднених НАБУ і САП у межах спецоперації "Карфаген".

### IT, InfoSys & cybersecurity news (last 7 days) — 47 new of 57 total
  - (2026-09-09) [BleepingComputer] Over 36,000 exposed Plex servers vulnerable to recent flaws
      Over 36,000 Plex Media servers exposed online remain unpatched against multiple security vulnerabilities and are vulnerable to attacks. [...]
  - (2026-09-09) [BleepingComputer] Man gets 15 years for extorting women with AI-generated porn videos
      An Ohio man was sentenced to 15 years in prison for multiple cybercrimes, including sextortion and cyberstalking of numerous victims using AI-generated sexually explicit content. [...]
  - (2026-09-09) [BleepingComputer] New Microsoft Defender 'ShieldCrash' zero-day grants SYSTEM access
      An anonymous security researcher known as Nightmare Eclipse has released a new Microsoft Defender zero-day exploit named "ShieldCrash" right after Microsoft rolled out its September 2026 Patch Tuesday security updates. […
  - (2026-09-09) [BleepingComputer] Google warns of new Chrome zero-day bug exploited in attacks
      Google has patched 230 vulnerabilities on Tuesday, including another actively exploited Chrome zero-day bug, the seventh such vulnerability patched since the start of the year. [...]
  - (2026-09-09) [BleepingComputer] Microsoft adds age-awareness APIs that can tell if users are children, teens, or adults
      Microsoft is adding new age-awareness APIs to Windows 11 that will allow apps to determine whether someone is a child, teenager, or adult without exposing their exact date of birth. [...]
  - (2026-09-09) [The Hacker News] DeepSeek Harness Flaw Let AI Agents Disable Their Own File Sandbox Without Approval
      A flaw in DeepSeek Harness, DeepSeek's open-source tool for running AI coding agents on a developer's machine, let a sandboxed agent turn off its own sandbox with a single command. The tool runs an agent's commands insid…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-09) 424B3 - T. Rowe Price Active Crypto ETF (0002089855) (Filer)
      filed 2026-09-09 12:00 UTC — Filed: 2026-09-09 AccNo: 0001999371-26-020168 Size: 65 KB
  - (2026-09-09) 425 - VerifyMe, Inc. (0001104038) (Subject)
      filed 2026-09-09 12:00 UTC — Filed: 2026-09-09 AccNo: 0001214659-26-011488 Size: 27 KB
  - (2026-09-09) 424B7 - LifeStance Health Group, Inc. (0001845257) (Filer)
      filed 2026-09-09 11:35 UTC — Filed: 2026-09-09 AccNo: 0001193125-26-385902 Size: 418 KB
  - (2026-09-09) [Gould Craig] Form 4 (Reporting)
      filed 2026-09-09 11:07 UTC · role: Reporting — Filed: 2026-09-09 AccNo: 0001104659-26-106127 Size: 4 KB
  - (2026-09-09) [Binah Capital Group, Inc.] Form 4 (Issuer)
      filed 2026-09-09 11:07 UTC · role: Issuer — Filed: 2026-09-09 AccNo: 0001104659-26-106127 Size: 4 KB
  - (2026-09-09) 425 - INDEPENDENCE REALTY TRUST, INC. (0001466085) (Filed by)
      filed 2026-09-09 10:49 UTC — Filed: 2026-09-09 AccNo: 0001437749-26-029905 Size: 7 MB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-09) JAF50T (Bulgaria)
      icao24: 4520ce · position: (37.6576, -5.3256) · alt: 11879m · 883km/h
  - (2026-09-09) GAF629 (Germany)
      icao24: 3f6533 · position: (52.2095, 5.0856) · alt: 12496m · 918km/h
  - (2026-09-09) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (36.9494, -2.3382) · alt: 11887m · 782km/h
  - (2026-09-09) GAF133 (Germany)
      icao24: 3f62fc · position: (45.9258, 17.1379) · alt: 6393m · 492km/h
  - (2026-09-09) PAT034 (United States)
      icao24: adfe94 · position: (41.1744, -99.7645) · alt: 8534m · 377km/h
  - (2026-09-09) PAT670 (United States)
      icao24: adfec1 · position: (38.4641, -77.4969) · alt: 4480m · 590km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 28 new of 108 total
  - (2026-09-08) [OFAC] Counter Terrorism Designations; Updates to Iran-related General Licenses - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Updates to Iran-related General Licenses Office of Foreign Assets Control (.gov)
  - (2026-09-04) [OFAC] Iran-related Designations; Issuance of Iran-related General License - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Iran-related General License Office of Foreign Assets Control (.gov)
  - (2026-09-03) [OFAC] Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License - Office of Foreign Assets Control (.gov)
      Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License Office of Foreign Assets Control (.gov)
  - (2026-09-04) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se Office of Foreign Assets Control (.gov)
  - (2026-09-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)
  - (2026-09-08) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR Part 560 GENERAL LICENSE DD Authorizing - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR Part 560 GENERAL LICENSE DD Authorizing Office of Foreign Assets Control (.gov)

### Court opinions of consequence (federal & state) — 21 new of 60 total
  - (2026-09-08) Connecticut Supreme Court: State v. Angel A.
  - (2026-09-08) Connecticut Supreme Court: State v. Guerrero
  - (2026-09-08) U.S. Court of Appeals, 3rd Cir.: National Shooting Sports Foundation v. Attorney General New Jersey
  - (2026-09-08) U.S. Court of Appeals, 3rd Cir.: Natural Resources Defense Council Inc v. New Jersey Department of Environmental Protection
  - (2026-09-08) U.S. Court of Appeals, 5th Cir.: I F G Port v. Lake Charles Harbor
  - (2026-09-08) U.S. Court of Appeals, 10th Cir.: Spiehs v. Morgan

### Paper Trading Scorecard — 19 new of 126 total
  - (2026-09-09) [Manifold] Will YES have fewer holders than NO? (24hr quick fuse)
  - (2026-09-09) [Manifold] Will Barcelona beat Feyenoord?
  - (2026-09-09) [Manifold] Will Bitcoin be higher than $77,777 at the end of 2026?
  - (2026-09-09) [Manifold] Will aging be solved by EOY 2035?
  - (2026-09-09) [Manifold] Will bitcoin go below 9.000$ at the end of this month?
  - (2026-09-09) [Manifold] OpenAI is sued over Navier-Stokes?

### U.S. Federal Action — 16 new of 16 total
  - (2026-09-09) Fisheries of the Exclusive Economic Zone Off Alaska; Pacific Ocean Perch in the Western Aleutian District of the Bering Sea and Aleutian Islands Management Area
      NMFS is prohibiting directed fishing for Pacific ocean perch in the Western Aleutian district (WAI) of the Bering Sea and Aleutian Islands management area (BSAI) by vessels participating in the BSAI trawl limited access…
  - (2026-09-09) Federal Motor Vehicle Safety Standard No. 213a; Child Restraint Systems-Side Impact Protection; Federal Motor Vehicle Safety Standard No. 213; Child Restraint Systems, Federal Motor Vehicle Safety Sta…
      This final rule amends the safety standards for child restraint systems (CRSs). NHTSA is amending Federal motor vehicle safety standard (FMVSS) No. 213a, "Child restraint systems--side impact protection," to exempt schoo…
  - (2026-09-09) Airworthiness Directives; Bombardier, Inc. Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for certain Bombardier, Inc., Model BD-700-2A12 airplanes. This proposed AD was prompted by reports of fuel leakage near rib 6 during production pressure testi…
  - (2026-09-09) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for certain Airbus SAS Model A350-941 and A350-1041 airplanes. This proposed AD was prompted by reports of failure of hydraulic engine driven pumps (EDPs) of t…
  - (2026-09-09) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to supersede Airworthiness Directive (AD) 2023-07-02, which applies to all Airbus SAS Model A330-200, -300, -800, and -900 series airplanes; and Model A340-200, -300, -500, and -600 series airplanes. AD…
  - (2026-09-09) Labels 888, 889, 891, and 892, Discontinued
      The Postal Service is proposing to amend Mailing Standards of the United States Postal Service, Domestic Mail Manual (DMM[supreg]) to discontinue the use of Label 888 and Label 889 respectively. Revisions to the DMM conc…

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-09-09) Counter-Strike: TYLOO vs GamerLegion (BO3) - FISSURE PLAYGROUND Group B
      yes price: 98% · 24h volume: $653,351 · resolves 2026-09-09
  - (2026-09-09) Will Sporting CP win on 2026-09-09?
      yes price: 56% · 24h volume: $555,171 · resolves 2026-09-09
  - (2026-09-09) LoL: DN SOOPers Challengers vs Nongshim Esports Academy - Game 3 Winner
      yes price: 100% · 24h volume: $540,789 · resolves 2026-09-09
  - (2026-09-09) Will Feyenoord Rotterdam win on 2026-09-09?
      yes price: 3% · 24h volume: $476,452 · resolves 2026-09-09
  - (2026-09-09) LoL: DN SOOPers Challengers vs Nongshim Esports Academy - Game 2 Winner
      yes price: 0% · 24h volume: $411,866 · resolves 2026-09-09
  - (2026-09-09) LoL: DN SOOPers Challengers vs Nongshim Esports Academy - Game 4 Winner
      yes price: 100% · 24h volume: $373,761 · resolves 2026-09-09

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-09-08) M 5.2 - 123 km NNE of Ruteng, Indonesia
      M5.2 · 123 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-09-09) M 5.0 - 53 km W of Cafayate, Argentina
      M5.0 · 53 km W of Cafayate, Argentina · depth 10 km
  - (2026-09-09) M 5.0 - 154 km S of Sarangani, Philippines
      M5.0 · 154 km S of Sarangani, Philippines · depth 10 km
  - (2026-09-08) M 4.9 - Mariana Islands region
      M4.9 · Mariana Islands region · depth 10 km
  - (2026-09-08) M 4.9 - 211 km ENE of Neiafu, Tonga
      M4.9 · 211 km ENE of Neiafu, Tonga · depth 10 km
  - (2026-09-08) M 4.9 - 97 km NNE of Chitre, Nepal
      M4.9 · 97 km NNE of Chitre, Nepal · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 40 total
  - (2026-09-09) MOVER ▲ Elon Musk — $942.04B (+$33.81B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-09-09) MOVER ▲ Larry Ellison — $208.76B (+$6.36B since yesterday)
      United States · Technology · source: Oracle
  - (2026-09-09) MOVER ▲ Michael Dell — $267.75B (+$4.64B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-09-09) MOVER ▼ Jensen Huang — $195.46B ($-3.94B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-09-09) MOVER ▲ Bill Gates — $115.26B (+$3.03B since yesterday)
      United States · Technology · source: Microsoft

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 23 total
  - (2026-09-08) CVE-2026-75650 · Adobe Commerce and Magento: Adobe Commerce and Magento Improper Neutralization of Special Elements Used in a Template Engine Vulnerability
      vendor: Adobe · product: Commerce and Magento · CISA remediation by 2026-09-11
  - (2026-09-08) CVE-2026-81963 · Microsoft Windows: Microsoft Windows Link Following Vulnerability
      vendor: Microsoft · product: Windows · CISA remediation by 2026-09-22
  - (2026-09-08) CVE-2026-86218 · N-able N-central: N-able N-central Static Code Injection Vulnerability
      vendor: N-able · product: N-central · CISA remediation by 2026-09-11
  - (2026-09-08) CVE-2026-85880 · Microsoft Windows: Microsoft Windows Heap-Based Buffer Overflow Vulnerability
      vendor: Microsoft · product: Windows · CISA remediation by 2026-09-22

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-09) [Marginal Revolution] Next Wins Appeal
      A spot of good news for Britain. Next has won its appeal and may go on paying warehouse workers more than “equal value” retail workers. I’ve written about this case in Equality Act 2010, The Equal Pay Madness Just Got Ma…
  - (2026-09-09) [Marginal Revolution] Reading sentences to ponder
      In 2015, 6 of the top 25 bestselling hardcover books—this is a not-perfect but useful proxy for new books published—were fiction. In 2025, 18 of the top 25 hardcover books were fiction, meaning only 7 were nonfiction, al…
  - (2026-09-09) [Marginal Revolution] Reasons to go to college
      That is the topic of my latest Free Press column, here is one excerpt: …college is a great place to make friends, date, and possibly meet a spouse. Those features are ever more important as America suffers a crisis of lo…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-09) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=16, 7d-median=11, 14d-median=18; carrying terms: national, proposed, final, commission, applicable, program, changes, unless, certain, safety, technical, service
- state_bills: today=88, 7d-median=82, 14d-median=79; carrying terms: state, county, member, develop, funds, grant, provided, officers, vests, budget, qualified, housing
- state_news: today=549, 7d-median=549, 14d-median=586; carrying terms: imports, center, justice, county, build, released, august, summer, washington, redirects, elected, short
- local_news: today=226, 7d-median=226, 14d-median=230; carrying terms: state, later, center, officer, county, scene, former, dekalb, season, atlanta, being, drive
- foreign_news: today=1004, 7d-median=1049, 14d-median=1048; carrying terms: committed, moment, center, palestinian, build, removal, unable, august, tensions, boost, disease, weapons
- chinese_internal: today=284, 7d-median=280, 14d-median=285; carrying terms: cbmia, lxtfa, cbmidefvx, title, cbmizefvx, cbmibefvx, cbmiw, property, blank, cbmib, cbmickfvx, global
- russian_internal: today=1159, 7d-median=1042, 14d-median=1058; carrying terms: raquo, laquo, novaya, found, russian, istories, forbidden, journal, bloomberg, gazeta, httperror, truth
- ukrainian_internal: today=132, 7d-median=132, 14d-median=128; carrying terms: kremlin, invasion, security, missiles, critical, august, caused, group, aircraft, former, military, preparing
- ukraine_theater: today=486, 7d-median=570, 14d-median=451; carrying terms: havlsbkzqyzzlt, center, vznxvjjrnfd, jcsmizdy, cjzyt, vmjlqmw, cuxnbi, zbwnnvelyq, strglxvoveg, edzscg, august, dhvldvs
- paper_bets: today=126, 7d-median=131, 14d-median=132; carrying terms: achieved, chair, office, state, total, speaker, virginia, leader, colonize, successor, trump, industrial
- weather: today=125, 7d-median=120, 14d-median=122; carrying terms: afdhgx, afdmeg, center, lincoln, statement, winds, galveston, impacts, county, isolated, rainfall, develop
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, walcl, dexuseu, total, pcepilfe, rates, recession, consumption, dexjpus, balance, openings, commodities
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, yield, corporate, futures, close, china, range, silver, rates, credit, treasury, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=104, 14d-median=108; carrying terms: african, state, square, palestinian, cbmiqkfvx, activities, bosnia, prohibited, paeez, security, member, haitian
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, error, unauthorized, https, quiverquant, quiver, client, congresstrading, httperror
- billionaires: today=40, 7d-median=33, 14d-median=30; carrying terms: charles, london, cryptocurrency, france, peterffy, amazon, technologies, retail, carlos, spain, berkshire, bezos
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, court, supreme, company, insurance, appeals, connecticut, williams, health, group, energy, blanche
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, group, filer, trust, financial, technology, isotopes
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: committee, brown, congress, angels, raised, ossoff, sherrod, shawn, platner, alexandria, cycle, talarico
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, kingdom, france, bulgaria, canada, ground, germany, kuwait, adfec
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: african, oecusse, temporally, state, respiratory, products, negative, epidemic, timor, release, rabies, critically
- cisa_kev: today=23, 7d-median=21, 14d-median=21; carrying terms: escalation, injection, restricted, limitation, improper, netscaler, vendor, jfrog, condition, vulnerability, untrusted, forgery
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=11, 7d-median=11, 14d-median=12; carrying terms: depth, islands, indonesia, region, chile, russia, ruteng, kuril, philippines, ollag, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, rates, change, championship, league, interest, september, donetsk, decrease, volume, shakhtar, meeting
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, marginal, conversable, economist, revolution, class, current, recent, government, years, economists, conversableeconomist
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: computer, security, become, industry, critical, released, group, technica, record, openai, https, download
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: richmond, janelle, state, brendan, nehls, rubio, lalota, counsel, virginia, menendez, hoyer, smith
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, consensus, placed, either, today, identify, module, sufficient, unavailable, evidence, decision, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-08] ECB press: Frank Elderson: Fireside chat

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*