# WORLDSCOPE morning brief — 2026-10-09

## Headline
3784 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (849) · Russian Internal News (state + in-exile) (759) · Ukraine Theater (total-war monitoring) (372) · State-Level News (356) · World leaders & government officials (324) · Chinese Internal News (250) · U.S. Weather + Severe / Climate Outlooks (201) · Local News: St. Louis + Atlanta (185) · State Legislative Action (135) · Ukrainian Internal News (national + local Kyiv) (63) · IT, InfoSys & cybersecurity news (last 7 days) (42) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 849 new of 1086 total
  - (2026-10-09) [Global] ICJ judge Navi Pillay wins Nobel peace prize for promoting international law
  - (2026-10-09) [Global] Isaias strengthens to become first Atlantic hurricane of 2026 season
  - (2026-10-09) [Global] Egyptian journalists plan weekend protest over detention of six colleagues
  - (2026-10-08) [Global] Scientists discover 180,000 giant tortoises on one Seychelles island
  - (2026-10-08) [Global] Ethiopia launches drone attack against Eritrean troops who crossed into Tigray
  - (2026-10-09) [Global] How a plant selfie in Colombian jungle led to ‘jaw dropping’ giant waterlily find

### Russian Internal News (state + in-exile) — 759 new of 1219 total
  - (2026-10-09) В США впервые с 1945 года расстреляют военного. Администрация Трампа хочет транслировать казнь в прямом эфире. Приговоренный Нидаль Хасан — приверженец радикального ислама — в 2009 году убил 13] (ru:…
      В США на 3 декабря запланирована казнь военнослужащего Нидала Хасана, который в 2009 году убил 13 сослуживцев на военной базе Форт-Худ. Пентагон объявил, что казнь будет публичной — такое произойдет впервые за много деся…
  - (2026-10-09) «Все уезжают, и никто не хочет возвращаться». ЖК «Новые Котельники» в Подмосковье дважды подвергался атакам украинских дронов. Жители одних квартир уже уехали, другие убеждены, что их защитит П] (ru:…
      20 сентября 2026 года Московская область в очередной раз оказалась под массированным ударом украинских беспилотников. Один из дронов попал в многоэтажку в городе Котельники к юго-востоку от Москвы. В июне в тот же дом уж…
  - (2026-10-09) The Kyiv Independent: Россия хочет отмены санкций в обмен на отказ от ударов по украинской энергетике | LEDE: Власти России просили США снять санкции в рамках переговоров об «энергетическом ] (ru: The…
      Власти России просили США снять санкции в рамках переговоров об «энергетическом перемирии», пишет The Kyiv Independent, ссылаясь на украинские и американские источники. Также снятие санкций, по словам собеседников издани…
  - (2026-10-09) Anthropic и OpenAI проводят учения на случай, если искусственный интеллект выйдет из-под контроля | LEDE: Руководители Anthropic, OpenAI и других ИИ-компаний обсуждают действия на случай кат] (ru: Ant…
      Руководители Anthropic, OpenAI и других ИИ-компаний обсуждают действия на случай катастрофического инцидента с участием искусственного интеллекта, который вызовет широкую общественную реакцию, пишет Axios.
  - (2026-10-09) Председателя «Яблока» Николая Рыбакова оштрафовали на тысячу рублей из-за надписи «За мир» на бюллетене | LEDE: Выборгский районный суд Санкт-Петербурга оштрафовал на одну тысячу рублей пред] (ru: Пре…
      Выборгский районный суд Санкт-Петербурга оштрафовал на одну тысячу рублей председателя партии «Яблоко» Николая Рыбакова по административному протоколу о мелком хулиганстве (часть 1 статьи 20.1 КоАП).
  - (2026-10-09) Война. 1689-й день. Украина второй день бьет по дата-центрам «Яндекса». В Майами начинаются новые переговоры о прекращении войны с участием Киева, Вашингтона и Европы | LEDE: «Медуза» с 24 ф] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…

### Ukraine Theater (total-war monitoring) — 372 new of 621 total
  - (2026-10-08) [FIRMS] thermal anomaly 50.546, 26.262 (FRP 1.05 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-08 0141Z, FRP 1.05 MW
  - (2026-10-08) [FIRMS] thermal anomaly 50.541, 26.258 (FRP 0.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-08 0141Z, FRP 0.97 MW
  - (2026-10-08) [FIRMS] thermal anomaly 51.140, 23.553 (FRP 0.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-08 0141Z, FRP 0.35 MW
  - (2026-10-08) [FIRMS] thermal anomaly 45.347, 22.234 (FRP 1.21 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-08 0143Z, FRP 1.21 MW
  - (2026-10-08) [FIRMS] thermal anomaly 45.340, 22.236 (FRP 0.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-08 0143Z, FRP 0.89 MW
  - (2026-10-08) [FIRMS] thermal anomaly 44.912, 22.477 (FRP 1.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-08 0143Z, FRP 1.71 MW

### State-Level News — 356 new of 763 total
  - (2026-10-09) [Alabama] Governor Kay Ivey Provides Update Ahead of Hurricane Isaias
      Governor Ivey on Thursday released a video message urging Alabamians to prepare for Hurricane Isaias and announcing coastal visitor evacuations and state office closures ahead of potential impacts. (Governor’s Office, Gi…
  - (2026-10-08) [Alabama] Governor Ivey Urges Alabamians to Prepare for Hurricane Isaias, Provides Update
      MONTGOMERY – Governor Kay Ivey on Thursday released a video message urging Alabamians to prepare for Hurricane Isaias and announcing state office closures and coastal visitor evacuations ahead of potential impact. Govern…
  - (2026-10-08) [Alabama] Supplemental State of Emergency: Hurricane Isaias
      Download
  - (2026-10-08) [Alabama] Mediation Week
      Download
  - (2026-10-08) [Alabama] White Cane Day
      Download
  - (2026-10-08) [Alabama] National Arts & Humanities Month
      Download

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 250 new of 310 total
  - (2026-10-08) Analysis: China Pushes LGFVs Beyond ‘Fake’ Transformation - Caixin Global
      Analysis: China Pushes LGFVs Beyond ‘Fake’ Transformation Caixin Global
  - (2026-10-08) Chinese Firms Are Gutting Middle-Management as AI Reshapes Work, Execs Say - Caixin Global
      Chinese Firms Are Gutting Middle-Management as AI Reshapes Work, Execs Say Caixin Global
  - (2026-10-08) 责编：任成琦 张 盼 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxPcFFvcHpLME9HTENQcU5NbnNtbVJjS1d2eUVFcnBWOWh4YllPUEdPem1DWUpsX0l4YkdrdHlZYVRRREExMW9wR] (zh:…
      责编：任成琦 张 盼 邮箱：gtbhwb@people.cn 人民日报
  - (2026-10-09) 青春华章丨壹时评：把论文写在大地上，把根扎在泥土里--观点 - 人民网观点 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTFBRZ1dIMk50UVpCb1ZrMWlPd2RkUkNlRFgzZUg3N3g1dUxwdGt1VHZxXzVDMVI1M1JIUC14WW5uX29tSVBSU1BxM] (zh:…
      青春华章丨壹时评：把论文写在大地上，把根扎在泥土里--观点 人民网观点
  - (2026-10-08) 假日经济升腾活力开放中国共享机遇（和音） --观点 - 人民网观点 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE4ycWZsMUhXZzF2LWxxMTNnLWEtR0ZoOU5acjhmZWhiZUlrVUdmazdzLVMwcnlXOVVPakNrTDBCYVJHT0dIa1B5NDhLQ] (zh:…
      假日经济升腾活力开放中国共享机遇（和音） --观点 人民网观点
  - (2026-10-08) 北京“十五五”优化营商环境29项举措出台 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE4yNXppQnB6TVcxTzNfWjdYcDNhV2FCMC1KblhrWFQtVVNKdUhQd1F1SE1xelhTVEpKZmFKemtjUXlmcFY1NVdFMjRLbngtemlx] (zh:…
      北京“十五五”优化营商环境29项举措出台 人民网

### U.S. Weather + Severe / Climate Outlooks — 201 new of 206 total
  - (2026-10-09) [Moderate] Rip Current Statement: Rip Current Statement issued October 9 at 10:02AM EDT until October 10 at 8:00PM EDT by NWS Miami FL
      * WHAT...For the High Rip Current Risk, dangerous rip currents. For the Coastal Flood Statement, isolated minor coastal flooding. * WHERE...Coastal Collier County. * WHEN...For the Coastal Flood Statement, through Saturd…
  - (2026-10-09) [Moderate] Rip Current Statement: Rip Current Statement issued October 9 at 10:02AM EDT until October 10 at 8:00PM EDT by NWS Miami FL
      * WHAT...For the Coastal Flood Statement, isolated minor coastal flooding. For the High Rip Current Risk, dangerous rip currents expected. * WHERE...Coastal Palm Beach County. * WHEN...For the Coastal Flood Statement, th…
  - (2026-10-09) [Severe] Special Marine Warning: Special Marine Warning issued October 9 at 9:02AM CDT until October 9 at 10:30AM CDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Waters from Mexico Beach to Apalachicola FL from 20 to 60 NM... Waters from Okaloosa-Walton County Line to Mexico Beach from…
  - (2026-10-09) [Moderate] Rip Current Statement: Rip Current Statement issued October 9 at 9:00AM CDT until October 9 at 7:00PM CDT by NWS Corpus Christi TX
      * WHAT...For the Coastal Flood Advisory, minor coastal flooding. For the High Rip Current Risk, dangerous rip currents. * WHERE...Aransas Islands, Kleberg Islands, Nueces Islands and Calhoun Islands Counties. * WHEN...Fo…
  - (2026-10-09) [Severe] Red Flag Warning: Red Flag Warning issued October 9 at 8:59AM CDT until October 9 at 7:00PM CDT by NWS Lake Charles LA
      ...RED FLAG WARNING FOR PORTIONS OF SOUTHEAST TEXAS AND CENTRAL AND SOUTHWEST LOUISIANA TODAY... .Breezy and dry conditions on the outer periphery of Hurricane Isaias combined with very dry fuels will produce red flag co…
  - (2026-10-09) [Severe] Red Flag Warning: Red Flag Warning issued October 9 at 8:59AM CDT until October 9 at 7:00PM CDT by NWS Lake Charles LA
      ...RED FLAG WARNING FOR PORTIONS OF SOUTHEAST TEXAS AND CENTRAL AND SOUTHWEST LOUISIANA TODAY... .Breezy and dry conditions on the outer periphery of Hurricane Isaias combined with very dry fuels will produce red flag co…

### Local News: St. Louis + Atlanta — 185 new of 217 total
  - (2026-10-09) [St. Louis] Ask George: Why aren’t more independent restaurants opening in South County?
      While the reader acknowledged that South County has plenty of restaurants, what’s often missing are new, independent places. Restaurateurs considering the metro area study demographics, but its layout also matters: Busy…
  - (2026-10-09) [St. Louis] The Boo Cat Club is back, 17 months after the tornado nearly destroyed it
      One year and five months after finding itself in the path of a deadly tornado, the Boo Cat Club is looking sharp. Last weekend, staffers hosted the first event on site—a wedding—since 100-mph winds sent a giant sycamore…
  - (2026-10-09) [St. Louis] St. Louis mayor outlines new criteria for assessing—and disbanding—homeless camps
      St. Louis Mayor Cara Spencer is trying to get ahead of a question that seems to pop up regularly in the city: When to clear a homeless encampment. She met with a few reporters yesterday to share the 17-page draft set of…
  - (2026-10-09) [St. Louis] St. Louis Ukrainians beg for a reprieve as protected status expires Oct. 19
      Four years ago, Dmytro Hrynchyshyn, his wife Taisiia, and their three-year-old son fled Ukraine and wound up in St. Louis. He had three master’s degrees—in law, economics, and engineering, he says. But those degrees didn…
  - (2026-10-09) [St. Louis] What’s True in the Lou? – 10/9/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-10-08) [St. Louis] Celebrate Filipino American History Month at these St. Louis spots
      October is Filipino American History Month, and if you’ve never explored Filipino food in St. Louis, there’s no better time to start. Filipino cuisine is a reflection of the Philippines’ complicated history, blending Ind…

### State Legislative Action — 135 new of 149 total
  - (2026-10-09) [Alaska HB 367] An Act relating to the privacy of consumer personal information; establishing the Consumer Personal Information Privacy Act; establishing data broker registration requirements; relatin…
      An Act relating to the privacy of consumer personal information; establishing the Consumer Personal Information Privacy Act; establishing data broker registration requirements; relating to social security numbers; making…
  - (2026-10-09) [Alaska HB 157] An Act relating to the effect of a decree of adoption or termination of parental rights on the legal relationship between a person and the person's siblings; and providing for an effec…
      An Act relating to the effect of a decree of adoption or termination of parental rights on the legal relationship between a person and the person's siblings; and providing for an effective date.
  - (2026-10-09) [Alaska SB 252] An Act relating to the Uniform Commercial Code; relating to secured transactions; relating to controllable accounts, controllable electronic records, and controllable payment intangibl…
      An Act relating to the Uniform Commercial Code; relating to secured transactions; relating to controllable accounts, controllable electronic records, and controllable payment intangibles; relating to sales; relating to n…
  - (2026-10-09) [California AB 58] University of California, Merced: medical school.
      The California Constitution provides that the University of California constitutes a public trust administered by the Regents of the University of California, a corporation in the form of a board, with full powers of org…
  - (2026-10-09) [California AB 244] Quick-Service Restaurant Young Workforce Apprenticeship Program: tax credits.
      Existing law provides for the establishment of apprenticeship programs in various trades, to be approved by the Chief of the Division of Apprenticeship Standards within the Department of Industrial Relations in any trade…
  - (2026-10-09) [California AB 63] Loitering with intent to commit prostitution.
      Existing law, until January 1, 2023, prohibited loitering in a public place with the intent to commit prostitution, as defined, and made that crime a misdemeanor. This bill would reinstate those provisions and would proh…

### Ukrainian Internal News (national + local Kyiv) — 63 new of 136 total
  - (2026-10-09) NBC News: перемовники України і США обговорять нову пропозицію для припинення війни | LEDE: Українські перемовники під час нового раунду переговорів у США про припинення війни з Росією обговоря] (uk:…
      Українські перемовники під час нового раунду переговорів у США про припинення війни з Росією обговорять комплексний новий план, покликаний допомогти подолати нинішній глухий кут у мирних зусиллях.
  - (2026-10-09) Росія полює "вусатими" шахедами на ЛЕП. Чи є загроза залишитись без світла | LEDE: ] (uk: Росія полює "вусатими" шахедами на ЛЕП. Чи є загроза залишитись без світла)
  - (2026-10-09) Затримання журналіста УП Ткача та оператора Бондаренка: Міжнародний інститут преси закликав Австрію до пояснень | LEDE: Міжнародний інститут преси (IPI) закликав австрійську владу пояснити підс] (uk:…
      Міжнародний інститут преси (IPI) закликав австрійську владу пояснити підстави затримання журналіста "Української правди" Михайла Ткача та оператора Ярослава Бондаренка у Відні й провести повне та прозоре розслідування об…
  - (2026-10-09) Росія полює "вусатими" шахедами на ЛЕП. Чи є загроза залишитись без світла? | LEDE: Напередодні зими Росія посилила удари по енергетичній інфраструктурі України. Тепер не лише по ТЕЦ, а й по ви] (uk:…
      Напередодні зими Росія посилила удари по енергетичній інфраструктурі України. Тепер не лише по ТЕЦ, а й по високовольтних лініях електропередач (ЛЕП), через які українці й отримують електрику у свої домівки.
  - (2026-10-09) У трьох районах Києва розгортають пункти незламності через блекаут | LEDE: Столична влада вирішила розгорнути пункти незламності у 3 районах Києва у зв'язку з відключенням електроенергії після ] (uk:…
      Столична влада вирішила розгорнути пункти незламності у 3 районах Києва у зв'язку з відключенням електроенергії після російських атак.
  - (2026-10-09) Росія хоче скасування санкцій США в обмін на "енергетичне перемир’я" – ЗМІ | LEDE: Росія висунула вимогу про скасування американських санкцій в обмін на схвалення перемир'я в енергетиці.] (uk: Росія х…
      Росія висунула вимогу про скасування американських санкцій в обмін на схвалення перемир'я в енергетиці.

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 60 total
  - (2026-10-09) [BleepingComputer] How to keep AI agents within their permissions
      AI agents can use valid credentials to perform actions beyond their assigned permissions, creating risks that traditional access controls may not prevent. Token Security explains how organizations can enforce agent-speci…
  - (2026-10-09) [BleepingComputer] Max severity SonicWall SMA1000 flaw now exploited in attacks
      Attackers are exploiting a maximum-severity vulnerability in SonicWall SMA1000 appliances (CVE-2026-102255) that was patched on Tuesday, three days ago. [...]
  - (2026-10-09) [BleepingComputer] Man admits to running network of 15,000 money mules for cybercriminals
      ​A Ukrainian-Russian dual citizen has pleaded guilty to running a massive money laundering operation that laundered millions for cybercriminals worldwide. [...]
  - (2026-10-09) [BleepingComputer] Microsoft: Outdated Windows devices will stop receiving security updates
      Microsoft says devices running unsupported versions of Windows will stop receiving security updates after next year's Windows Update certificate rotation. [...]
  - (2026-10-09) [BleepingComputer] Citrix warns admins to patch new NetScaler RCE flaw immediately
      Citrix has warned IT administrators to patch systems immediately against a new critical vulnerability affecting NetScaler ADC networking appliances and NetScaler Gateway secure remote access solutions. [...]
  - (2026-10-09) [The Hacker News] Flax Typhoon Exploits Five Flaws as CISA Sets October 11 Deadline for Federal Agencies
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Thursday added five security flaws to its Known Exploited Vulnerabilities (KEV) catalog, following their abuse by a China-linked threat actor known as F…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-09) [PIMCO Dynamic Income Strategy Fund] Form 4 (Issuer)
      filed 2026-10-09 14:03 UTC · role: Issuer — Filed: 2026-10-09 AccNo: 0001510281-26-000336 Size: 5 KB
  - (2026-10-09) [Saba Capital Management, L.P.] Form 4 (Reporting)
      filed 2026-10-09 14:03 UTC · role: Reporting — Filed: 2026-10-09 AccNo: 0001510281-26-000336 Size: 5 KB
  - (2026-10-09) [Saba Capital Management, L.P.] Form 4 (Reporting)
      filed 2026-10-09 14:01 UTC · role: Reporting — Filed: 2026-10-09 AccNo: 0001510281-26-000335 Size: 5 KB
  - (2026-10-09) [Gabelli Healthcare & WellnessRx Trust] Form 4 (Issuer)
      filed 2026-10-09 14:01 UTC · role: Issuer — Filed: 2026-10-09 AccNo: 0001510281-26-000335 Size: 5 KB
  - (2026-10-09) 497J - FT 13282 (0002147050) (Filer)
      filed 2026-10-09 14:01 UTC — Filed: 2026-10-09 AccNo: 0001445546-26-007535 Size: 2 KB
  - (2026-10-09) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-10-09 14:01 UTC — Filed: 2026-10-09 AccNo: 0001918704-26-031106 Size: 677 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-09) PAT135 (United States)
      icao24: adfeda · position: (31.6844, -85.3338) · alt: 2362m · 494km/h
  - (2026-10-09) PAT473 (United States)
      icao24: adfe48 · position: (39.9711, -77.9491) · alt: 6096m · 391km/h
  - (2026-10-09) AF2 (United States)
      icao24: adfeb8 · position: (39.8719, -78.9659) · alt: 7924m · 736km/h
  - (2026-10-09) CFC4508 (United States)
      icao24: a37b7e · position: (44.0525, -77.4011) · alt: 518m · 231km/h
  - (2026-10-09) SAMU06 (France)
      icao24: 39c901 · position: (43.7243, 7.2824) · on ground · 0km/h
  - (2026-10-09) FNY5560 (France)
      icao24: 39a408 · position: (48.5339, -4.1334) · alt: 68m · 179km/h

### Court opinions of consequence (federal & state) — 27 new of 60 total
  - (2026-10-08) U.S. Court of Appeals, 5th Cir.: Mieco v. Pioneer Natural Resources
  - (2026-10-08) U.S. Court of Appeals, 5th Cir.: Navejas v. City of El Paso
  - (2026-10-08) U.S. Court of Appeals, 6th Cir.: Jennifer Byrum v. Knox County, Tenn.
  - (2026-10-08) U.S. Court of Appeals, 6th Cir.: United States v. Charles Mixon
  - (2026-10-08) U.S. Court of Appeals, 11th Cir.: United States v. Antonio Brown
  - (2026-10-08) U.S. Court of International Trade: Freestyle World, Inc. v. United States

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-10-08) [Israel-Iran-Hezbollah axis · themes] 读 《 羽蛇的天空 》： 科幻不只有未来维度 ， 更有回望过往 、 重构文明的强大力量
      163.com · Chinese · tone NA
  - (2026-10-08) [Israel-Iran-Hezbollah axis · themes] Trumps Kampf um Texas : « Es ist entscheidend »
      berchtesgadener-anzeiger.de · German · tone NA
  - (2026-10-08) [Israel-Iran-Hezbollah axis · themes] Nana Patekar : కార్గిల్‌ యుద్ధంలో సైనికుడిగా నానా పటేకర్‌ .. మీకీ ఆసక్తికర విషయం తెలుసా ?
      eenadu.net · Telugu · tone NA
  - (2026-10-08) [Israel-Iran-Hezbollah axis · themes] UPS員工漏看郵件 致F - 35零件誤運至香港
      epochtimes.com · Chinese · tone NA
  - (2026-10-08) [Israel-Iran-Hezbollah axis · themes] Data centre operators on board with energy rules
      goulburnpost.com.au · English · tone NA
  - (2026-10-08) [Israel-Iran-Hezbollah axis · themes] NSW Police Commissioner Mal Lanyon moved to block public watchdog hearings into police violence
      smh.com.au · English · tone NA

### Paper Trading Scorecard — 22 new of 138 total
  - (2026-10-09) [Polymarket] Will Brad Bradford win the 2026 Toronto mayoral election?
      The 2026 Toronto mayoral election is currently scheduled to be held on October 26, 2026. This market will resolve according to the candidate who becomes the next mayor of Toronto as a result of this election. Temporary,…
  - (2026-10-09) [Polymarket] Israel x Iran ceasefire continues through October 15?
      This market will resolve to "Yes" if a state of ceasefire remains in effect between Israel and Iran through the listed date, 11:59 PM Iran Standard Time (IRST). Otherwise this market will resolve to “No”. A state of ceas…
  - (2026-10-09) [Manifold] Trump wins Nobel Peace Prize 2027?
  - (2026-10-09) [Manifold] Daily Coinflip
  - (2026-10-09) [Manifold] Will Nidal Hasans execution be livestreamed in 2026?
  - (2026-10-09) [Manifold] ElevenLabs Acquired before 2028

### Government Action: Sanctions + Procurement + Foreign Agents — 19 new of 111 total
  - (2026-10-08) [OFAC] Iran-related Designations; Issuance of Iran-related General License; Issuance of Amended Russia-related General License - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Iran-related General License; Issuance of Amended Russia-related General License Office of Foreign Assets Control (.gov)
  - (2026-10-08) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-10-08) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13846 of August 6, 2018 (“Reimposing Certain Sanctions With Respect to Iran - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13846 of August 6, 2018 (“Reimposing Certain Sanctions With Respect to Iran Office of Foreign Assets Control (.gov)
  - (2026-10-09) [BIS Entity List] page checksum 114633e99031
      Page content hash: 114633e99031. Compare with prior day's hash to detect updates.
  - (2026-10-06) [FARA] Criminal Division | Whistleblower Awards Pilot Program - Department of Justice (.gov)
      Criminal Division | Whistleblower Awards Pilot Program Department of Justice (.g
  - (2026-10-09) [USASpending] $900,485,187 → TRIWEST HEALTHCARE ALLIANCE CORP: EXPRESS REPORT: FY26 SEPTEMBER
      Agency: Department of Veterans Affairs. Description: EXPRESS REPORT: FY26 SEPTEMBER

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-10-09) Counter-Strike: FURIA vs MOUZ (BO3) - ESL Pro League Playoffs
      yes price: 42% · 24h volume: $1,572,776 · resolves 2026-10-09
  - (2026-10-09) Shanghai Rolex Masters: Yi Zhou vs Lorenzo Musetti
      yes price: 33% · 24h volume: $1,190,001 · resolves 2026-10-17
  - (2026-10-09) Will the Fed decrease interest rates by 50+ bps after the October 2026 meeting?
      yes price: 0% · 24h volume: $834,851 · resolves 2026-10-29
  - (2026-10-09) Will Flávio Bolsonaro win the 2026 Brazilian presidential election?
      yes price: 86% · 24h volume: $719,357 · resolves 2026-10-05
  - (2026-10-09) Counter-Strike: GamerLegion vs Sinners (BO3) - 1win Private Club #2: Closed Qualifier Playoffs
      yes price: 100% · 24h volume: $336,952 · resolves 2026-10-09
  - (2026-10-09) Counter-Strike: Team Falcons vs Spirit (BO3) - ESL Pro League Playoffs
      yes price: 42% · 24h volume: $334,984 · resolves 2026-10-09

### U.S. Federal Action — 13 new of 15 total
  - (2026-10-09) Fisheries of the Exclusive Economic Zone Off Alaska; Groundfish Reserves in the Bering Sea and Aleutian Islands Management Area
  - (2026-10-09) Emergency Tax Relief on Diesel Fuel
  - (2026-10-09) Raisins Produced From Grapes Grown in California; Order Amending Marketing Order No. 989
      This final rule amends Marketing Order No. 989, which regulates the handling of raisins produced from grapes grown in California. The Department of Agriculture approves and adopts amendments proposed by the Raisin Admini…
  - (2026-10-09) Application of the Personal Responsibility and Work Opportunity Reconciliation Act of 1996 to the Refunded Portion of Certain Federal Refundable Tax Credits; Hearing Cancellation
      This document cancels a public hearing on proposed regulations (REG-119882-25) published in the Federal Register on August 20, 2026. The proposed regulations would provide that the refunded portion of certain refundable…
  - (2026-10-09) Schedules of Controlled Substances; Removal of Exemption Status for Inactive Butalbital Products
      The Drug Enforcement Administration (DEA) is revoking the exempted status for certain nonnarcotic prescription products that are currently on DEA's Table of Exempted Prescription Products, but whose National Drug Codes (…
  - (2026-10-09) Schedules of Controlled Substances: Placement of O-Desmethyltramadol in Schedule I; Correction
      On August 12, 2026, the Drug Enforcement Administration (DEA) published a temporary order placing O-desmethyltramadol (other names: O-DSMT; desmetramadol; 3-[(1R,2R)-2-[(dimethylamino)methyl]-1- hydroxycyclohexyl]phenol)…

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-10-09) M 5.2 - 117 km SE of Bitung, Indonesia
      M5.2 · 117 km SE of Bitung, Indonesia · depth 40.049 km
  - (2026-10-09) M 5.1 - 72 km SSW of Colchane, Chile
      M5.1 · 72 km SSW of Colchane, Chile · depth 123.835 km
  - (2026-10-09) M 4.9 - 77 km ENE of Tuapejat, Indonesia
      M4.9 · 77 km ENE of Tuapejat, Indonesia · depth 40.817 km
  - (2026-10-09) M 4.9 - south of the Fiji Islands
      M4.9 · south of the Fiji Islands · depth 130.36 km
  - (2026-10-08) M 4.9 - 113 km NW of Baa, Indonesia
      M4.9 · 113 km NW of Baa, Indonesia · depth 10 km
  - (2026-10-09) M 4.8 - 17 km S of Nandaime, Nicaragua
      M4.8 · 17 km S of Nandaime, Nicaragua · depth 165.662 km

### CISA Known Exploited Vulnerabilities (last 14d) — 5 new of 16 total
  - (2026-10-08) CVE-2015-5477 · ISC BIND: ISC BIND Data Processing Errors Vulnerability
      vendor: ISC · product: BIND · CISA remediation by 2026-10-11
  - (2026-10-08) CVE-2016-3081 · Apache Struts: Apache Struts Command Injection Vulnerability
      vendor: Apache · product: Struts · CISA remediation by 2026-10-11
  - (2026-10-08) CVE-2023-22894 · Strapi Strapi: Strapi Cleartext Storage of Sensitive Information Vulnerability
      vendor: Strapi · product: Strapi · CISA remediation by 2026-10-11
  - (2026-10-08) CVE-2021-3199 · ONLYOFFICE Docs: ONLYOFFICE Docs Server Path Traversal Vulnerability
      vendor: ONLYOFFICE · product: Docs · CISA remediation by 2026-10-11
  - (2026-10-08) CVE-2015-3306 · ProFTPD ProFTPD: ProFTPD Improper Access Control Vulnerability
      vendor: ProFTPD · product: ProFTPD · CISA remediation by 2026-10-11

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-09) [Marginal Revolution] A Sentiment Analysis of Cowen, Hanson, Caplan, and Krugman
      Supplied by Bryan Caplan, performed by ChatGPT, excerpt: So Cowen isn’t well described as either “positive” or “negative.” A much better description is: High appreciation + high concern + very low emotional agitation. He…
  - (2026-10-09) [Marginal Revolution] On *Stubborn Attachments* and religion (from my email)
      Hey Tyler I consider Stubborn Attachments your most dogmatic and religious book. Pondering on it, here are my Abrahamic readings of it: Jewish: Ten Commandments, obviously. While the bigger canon of Jewish laws tend to b…
  - (2026-10-08) [Marginal Revolution] Predictions for economics, given AI
      From Ingar Haaland: With math essentially being delegated to OpenAI, here’s what I predict for economics and the social sciences more generally: The top tier of research will just become better and it will be normal huma…
  - (2026-10-08) [Conversable Economist] A Tax-Side Agenda for Addressing US Budget Deficits
      Om 2026, the federal government is on track to spend $7.4 trillion, and $1.9 trillion–about one-quarter of the total–will be newly borrowed money. It’s one thing to have deficit spending during a pandemic or a recession,…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### World News (by country, top stories) — 2 new of 2 total
  - (2026-10-08) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-10-08) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-10-08) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo
      On 5 October 2026, WHO was informed about a laboratory-confirmed imported case of Bundibugyo virus disease (BVD) in Kenya with travel history from the Democratic Republic of the Congo. The patient travelled from the Demo…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-09) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=26, 14d-median=22; carrying terms: certain, safety, action, regulatory, model, proposed, standards, final, national, amending, issuing, document
- state_bills: today=149, 7d-median=111, 14d-median=106; carrying terms: funding, certain, license, prevention, safety, general, institutions, transportation, enter, public, authorizes, officer
- state_news: today=763, 7d-median=698, 14d-median=651; carrying terms: total, families, campaign, police, statewide, funding, candidate, group, seeking, market, numbers, republican
- local_news: today=217, 7d-median=225, 14d-median=228; carrying terms: families, police, night, officials, incident, color, public, leads, officer, georgia, saportareport, braves
- foreign_news: today=1086, 7d-median=1012, 14d-median=1015; carrying terms: scale, families, vnecdn, rising, double, cities, funding, soldiers, tells, candidate, group, worst
- chinese_internal: today=310, 7d-median=253, 14d-median=266; carrying terms: cbmibefvx, cbmiakfvx, cbmib, investors, cbmigwfbvv, cbmia, lxtfa, cbmiy, cbmickfvx, cbmiw, china, articles
- russian_internal: today=1219, 7d-median=1074, 14d-median=1036; carrying terms: error, istories, russian, blank, server, target, forbidden, reuters, times, politico, europe, found
- ukrainian_internal: today=136, 7d-median=136, 14d-median=131; carrying terms: european, scale, campaign, funding, capital, building, officials, pressure, kremlin, authorities, poland, power
- ukraine_theater: today=621, 7d-median=584, 14d-median=572; carrying terms: pivnichnyi, pnzfomdngcw, results, ftetjvs, legalization, cxnnzjaej, pqyze, vyedbidjhjcldnbxgxwkzjq, tulrd, uzztyty, vestvetnj, classification
- paper_bets: today=138, 7d-median=128, 14d-median=122; carrying terms: midterms, seats, fuentes, total, leave, riemann, pennsylvania, world, become, industrial, fusion, lifetime
- weather: today=206, 7d-median=141, 14d-median=142; carrying terms: flood, holly, continues, synopsis, early, message, center, waters, oxnard, pontiac, forecasts, lower
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: walcl, unemployment, labor, cpiaucsl, funds, assets, total, effective, inflation, payrolls, nonfarm, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, nasdaq, china, credit, futures, range, proxy, equities, natural, silver, crypto, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=120, 14d-median=112; carrying terms: plant, beirut, effects, campaign, sectoral, entities, crimea, foreign, guinea, state, protecting, assets
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quantitative, quiver, https, congresstrading, quiverquant, client, httperror, error
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: union, appeals, supreme, court, roman, william, corporation, state, howard, international, company, phillips
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, financial, chase, finance, jpmorgan, filer, trust, scotia, stanley
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, trone, disbursements, angels, cortez, ocasio, raised, filing, lindsey, james, robert, talarico
- gdelt_regions: today=2, 7d-median=6, 14d-median=6; carrying terms: english, china
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, themes, chinese, spanish, romanian, hezbollah, french, israel, german, italian, putin, online
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, ground, germany, eagle, kuwait, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: resulting, developed, arabia, hondius, current, total, confirmation, representing, infecting, chikungunya, middle, world
- cisa_kev: today=16, 7d-median=17, 14d-median=17; carrying terms: inclusion, bounds, remote, vulnerability, microsoft, behavioral, improper, multiple, wordpress, validation, product, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=13, 7d-median=16, 14d-median=16; carrying terms: depth, indonesia, islands, south, japan, region, philippines, chile, ridge, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, shakhtar, price, champions, resolves, donetsk, league, championship, october, interest, meeting, presidential
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, conversable, class, conversableeconomist, https, revolution, marginal, taxes, income, because, property, think
- tech_news: today=60, 7d-median=56, 14d-median=57; carrying terms: technica, theft, campaign, download, state, today, infrastructure, bleepingcomputer, going, hacker, review, engineers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: maxine, meuser, melanie, clarke, julia, sykes, ratcliffe, trent, cassidy, lucas, flood, quigley
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, placed, claude, identify, module, placement, either, evidence, today, decision, paper, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] ECB press: Philip R. Lane: Diagnostic Challenges for ECB Monetary Policy
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*