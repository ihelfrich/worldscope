# WORLDSCOPE morning brief — 2026-06-05

## Headline
3329 new items across 25 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (720) · International News + Multilateral Institutions (672) · State-Level News (378) · World leaders & government officials (324) · Chinese Internal News (231) · Local News: St. Louis + Atlanta (196) · U.S. Weather + Severe / Climate Outlooks (150) · Ukraine Theater (total-war monitoring) (138) · State Legislative Action (93) · GDELT GKG — themes / entities / watch areas (83) · Ukrainian Internal News (national + local Kyiv) (69) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 720 new of 1125 total
  - (2026-06-05) МИД Азербайджана: пятеро моряков погибли в результате ударов беспилотников по грузовым судам в Азовском море | LEDE: Грузовые суда «Натра» и «Зиркон», на борту которых находились 25 граждан ] (ru: МИД…
      Грузовые суда «Натра» и «Зиркон», на борту которых находились 25 граждан Азербайджана, в ночь на 5 июля были атакованы беспилотниками в Таганрогском заливе в Азовском море.
  - (2026-06-05) На ПМЭФ депутат Макаров раскритиковал произвол российских силовиков. А еще произнес слово «война» | LEDE: Глава комитета Госдумы по бюджету и налогам Андрей Макаров назвал произволом действи] (ru: На…
      Глава комитета Госдумы по бюджету и налогам Андрей Макаров назвал произволом действия российских силовых структур во время войны. Об этом депутат заявил во время делового завтрака «Сбера» в рамках Петербургского междунар…
  - (2026-06-05) В порту на юго-востоке Румынии взорвался морской дрон | LEDE: В порту города Констанца, расположенного на юго-востоке Румынии, взорвался морской беспилотник. ] (ru: В порту на юго-востоке Румынии взор…
      В порту города Констанца, расположенного на юго-востоке Румынии, взорвался морской беспилотник.
  - (2026-06-05) Российские страховые компании стали предлагать полисы с покрытием риска «военных действий», включая падение обломков дронов и работу ПВО | LEDE: Крупные российские страховые компании стали п] (ru: Рос…
      Крупные российские страховые компании стали предлагать частным лицам полисы с покрытием риска «военных действий». пишет «Коммерсант».
  - (2026-06-05) Почему нам тесно жить в такой большой стране? Читайте новую книгу издательства «Медузы» — «Люди за забором» журналиста Максима Трудолюбова. Это исследование о том, как в России развивался и тра] (ru:…
      «Люди за забором. Частное пространство, власть и собственность в России» — новая книга издательства «Медузы». Ее написал Максим Трудолюбов, журналист, научный сотрудник Института Кеннана и главный редактор издания The Ru…
  - (2026-06-05) «Фонтанка»: Захар Прилепин станет проректором Горного университета в Петербурге. Его возглавляет научный руководитель Путина | LEDE: Писатель и общественный деятель Захар Прилепин займет пос] (ru: «Фо…
      Писатель и общественный деятель Захар Прилепин займет пост проректора Горного университета в Санкт-Петербурге. Он будет курировать идеологическую и воспитательную работу в вузе, пишет «Фонтанка» со ссылкой на источники.

### International News + Multilateral Institutions — 672 new of 884 total
  - (2026-06-05) [Global] ‘Family values’ African charter condemned by rights groups as regressive and dangerous
  - (2026-06-04) [Global] Experts criticise plan for American-only Ebola quarantine centre in Kenya
  - (2026-06-04) [Global] Civilians flee as Somali troops and opposition-allied militias trade fire in Mogadishu
  - (2026-06-05) [Global] US imposes new sanctions on Cuban president and Castro family members
  - (2026-06-04) [Global] Canada endorses embattled marine park’s plan to relocate 30 beluga whales
  - (2026-06-04) [Global] Outrage in Argentina after two teen girls murdered as femicide crisis endures

### State-Level News — 378 new of 782 total
  - (2026-06-05) [California] Governor Newsom announces appointments 6.4.2026
      Source
  - (2026-06-04) [California] Governor Newsom announces expansion of the world’s largest civilian aerial firefighting fleet: deployment of fourth C-130 H airtanker and new helitack base
      Source
  - (2026-06-04) [California] California charts smarter path to support farmers and ranchers while maintaining food safety and clean water
      Source
  - (2026-06-04) [California] Trump data confirms that Governor Newsom’s strategies have led to the largest reduction in homelessness nationwide
      Source
  - (2026-06-04) [California] California continues aggressive fight against organized retail theft, recovering nearly $260 million in stolen merchandise
      Source
  - (2026-06-04) [California] The top-two primary was supposed to change California politics. Did it flop?
      <img width="1024" height="707" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Chico-Elections_SO_CM_12.jpg?fit=1024%2C707&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 231 new of 272 total
  - (2026-06-05) “史上最大IPO”，上市时间定了 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Wd3Q1T3lUWGo4U1ZmdlR5Y1JfdHl3Z2NxMVFTZkxzdHBLX2NiaHgtV0FnWnJrcjlTU3BQQndTVXpOZk90WGhlYmlwd2lVT09aMzFEd] (zh:…
      “史上最大IPO”，上市时间定了 财新
  - (2026-06-04) 内地投资者涌入香港银行和券商开户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5IYkVubnJWMWZNa1J6cFl6d3MwTHppOXk1dDk3QXdPSkRCcTdLRm1NcEV6QW9Ub0pPaWF3alp5MmM1MHBZWjRYTkJLenJHUkN4QVF4Y] (zh:…
      内地投资者涌入香港银行和券商开户 财新
  - (2026-06-04) 从国企副总“捞”到副省级 62岁浙江本土高官高兴夫将在江西宜春受审 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE1kQmFXMmptSkZmZ2t0RUIzQU91YmZwZW9Ca2x5NzdKcTN2RlhXZ2hycFN4blcyeFhPQW93SV] (zh:…
      从国企副总“捞”到副省级 62岁浙江本土高官高兴夫将在江西宜春受审 china.caixin.com
  - (2026-06-04) 退休公职人员诉请分割近亿元夫妻财产 法院称涉犯罪移送公安和纪检 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE4xWlpIaW8zd0RxYktFYzZZMVk2VGcyV1c2aVh4Yy02SHR4bHN4ZEFXV3JNQVlOU3hJdFV4NDd2] (zh:…
      退休公职人员诉请分割近亿元夫妻财产 法院称涉犯罪移送公安和纪检 china.caixin.com
  - (2026-06-04) 央行逆回购连续两天操作量为零 是在收紧流动性吗？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5BRlFrNGczZlRkQnlZazEzOWFhMnptNGo2OFNGZnNsMWthM0tfM0hOYVF6NEsxTUk0QWxHNGluUzVnNUlrNWMtU29ERUVMW] (zh:…
      央行逆回购连续两天操作量为零 是在收紧流动性吗？ 财新
  - (2026-06-04) SpaceX即将登陆纳斯达克 指数调整将重塑市场 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5zRDFtUzZlUE5jS0JISXVoeTlMU2F0Z0hrNEpVak5UaWR0M0Z3V1ZCRXkzUlp6bTVMXzdrcURuRnBwYVl6WFc3RzI5S3l3M] (zh:…
      SpaceX即将登陆纳斯达克 指数调整将重塑市场 财新

### Local News: St. Louis + Atlanta — 196 new of 225 total
  - (2026-06-05) [St. Louis] What’s True in the Lou? – 6/5/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-06-05) [St. Louis] Excellence in Nursing Awards 2026
      For the 17th year in a row, St. Louis Magazine is honoring the remarkable efforts of nurses across the region by hosting the annual Excellence in Nursing Awards, presented by BJC HealthCare and Barnes-Jewish College Gold…
  - (2026-06-04) [St. Louis] Farotto’s Pasta & Pizzeria celebrates its 70th anniversary
      One of St. Louis’ longest-running pizzerias recently celebrated its 70th anniversary. Farotto’s Pasta & Pizzeria (9525 Manchester) marked the occasion with a private party for its loyal patrons. The family-owned and -ope…
  - (2026-06-04) [St. Louis] Ask Veronica: Traveling this summer? 7 St. Louis-style gifts your host will love
      A few weeks ago, I received a late-night text from a neighbor. She’s traveling to Italy later this month to visit family she hasn’t seen in 20 years, and was struggling to figure out what gift to take them. “I can’t thin…
  - (2026-06-04) [St. Louis] All Punks Meet In St. Louis Under the Arch convenes this weekend
      On June 6, punk music devotees from the river city and all around the country will gather under the St. Louis Arch for one big group portrait. The snapshot serves as a focal point for an all-ages DIY festival dubbed All…
  - (2026-06-04) [St. Louis] YoungLiars gets wild with Emily Dickinson
      The poet Emily Dickinson was known for asking the big questions: pondering the nature of God, death, beauty, and the infinite. It turns out that Dr. Pepper–guzzling millennial teenagers in pajamas have a lot of the same…

### U.S. Weather + Severe / Climate Outlooks — 150 new of 152 total
  - (2026-06-05) [Severe] Flash Flood Warning: Flash Flood Warning issued June 5 at 5:39AM CDT until June 5 at 5:45AM CDT by NWS Omaha/Valley NE
      The heavy rain has ended. Please continue to heed remaining road closures.
  - (2026-06-05) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-05) [Severe] Flood Warning: Flood Warning issued June 5 at 5:24AM CDT until June 5 at 9:15AM CDT by NWS Kansas City/Pleasant Hill MO
      * WHAT...Flooding caused by excessive rainfall is expected. * WHERE...Doniphan County in northeastern Kansas... Western Andrew County in northwestern Missouri... North Central Buchanan County in northwestern Missouri...…
  - (2026-06-05) [Severe] Flood Warning: Flood Warning issued June 5 at 5:17AM CDT until June 6 at 4:30PM CDT by NWS Omaha/Valley NE
      ...The Flood Warning continues for the following rivers in Nebraska... Big Nemaha River at Falls City affecting Richardson County. * WHAT...Moderate flooding is occurring and moderate flooding is forecast. This approache…
  - (2026-06-05) [Severe] Flash Flood Warning: Flash Flood Warning issued June 5 at 5:15AM CDT until June 5 at 7:15AM CDT by NWS Midland/Odessa TX
      At 515 AM CDT, Doppler radar and automated rain gauges indicated thunderstorms producing heavy rain across the warned area. Between 1 and 2 inches of rain have fallen. Additional rainfall amounts of 0.5 to 1 inch are pos…
  - (2026-06-05) [Severe] Flash Flood Warning: Flash Flood Warning issued June 5 at 5:14AM CDT until June 5 at 7:15AM CDT by NWS Kansas City/Pleasant Hill MO
      FFWEAX The National Weather Service in Pleasant Hill has extended the * Flash Flood Warning for... Northeastern Andrew County in northwestern Missouri... Northwestern DeKalb County in northwestern Missouri... Southwester…

### Ukraine Theater (total-war monitoring) — 138 new of 320 total
  - (2026-06-04) [FIRMS] thermal anomaly 45.257, 31.675 (FRP 9.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1047Z, FRP 9.61 MW
  - (2026-06-04) [FIRMS] thermal anomaly 45.356, 30.904 (FRP 2.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1047Z, FRP 2.53 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.573, 32.304 (FRP 7.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 7.91 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.627, 32.621 (FRP 2.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 2.38 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.578, 32.292 (FRP 3.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 3.56 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.698, 32.914 (FRP 3.6 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 3.6 MW

### State Legislative Action — 93 new of 127 total
  - (2026-06-05) [Alaska SB 275] An Act relating to natural gas and natural gas projects; relating to the Alaska Gasline Development Corporation; relating to the powers and duties of the Legislative Budget and Audit C…
      An Act relating to natural gas and natural gas projects; relating to the Alaska Gasline Development Corporation; relating to the powers and duties of the Legislative Budget and Audit Committee; relating to the value of c…
  - (2026-06-05) [Alaska HJR 10] Proposing amendments to the Constitution of the State of Alaska relating to the Alaska permanent fund and to appropriations from the Alaska permanent fund.
      Proposing amendments to the Constitution of the State of Alaska relating to the Alaska permanent fund and to appropriations from the Alaska permanent fund.
  - (2026-06-05) [Alaska HCR 2] Proposing an amendment to the Uniform Rules of the Alaska State Legislature relating to voting and abstention from voting.
      Proposing an amendment to the Uniform Rules of the Alaska State Legislature relating to voting and abstention from voting.
  - (2026-06-05) [Alaska HB 152] An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on indiv…
      An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on individuals under the Alaska Net Income T…
  - (2026-06-05) [Alaska SB 23] An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
      An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
  - (2026-06-05) [Alaska SB 164] An Act eliminating deductions for the remittance of the motor fuel tax, tobacco taxes, and tire fees; relating to discounts on cigarette stamps; and providing for an effective date.
      An Act eliminating deductions for the remittance of the motor fuel tax, tobacco taxes, and tire fees; relating to discounts on cigarette stamps; and providing for an effective date.

### GDELT GKG — themes / entities / watch areas — 83 new of 83 total
  - (2026-06-05) [Russia oil sanctions perimeter · themes] 记者手记丨中国电动汽车风靡印尼街头
      k.sina.com.cn · Chinese · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] Brexit miał rozwiązać problemy Brytyjczyków . 10 lat od referendum widzimy prawdę . Kraj został oszukany [ OPINIA ]
      wiadomosci.onet.pl · Polish · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] RBI hits pause button again ! Repo rate remains unchanged at 5 . 25 % amid global turmoil | Indiablooms
      indiablooms.com · English · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] Diario HOY | Argentina preadjudica la concesión de la hidrovía Paraná - Paraguay
      hoy.com.py · Spanish · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] Trump Open to Meeting Ayatollah for Iran Deal | Newsradio 92 . 7 WBEX
      wbex.iheart.com · English · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] Jedna ima 280 stanova i vilu , druga uživa na jahti bogatog očuha : Ovo su najbogatije naslednice estrade
      telegraf.rs · Serbian · tone NA

### Ukrainian Internal News (national + local Kyiv) — 69 new of 126 total
  - (2026-06-05) Молоді українці з ТОТ зможуть отримати документи у 5 країнах – МЗС | LEDE: Україна запустила експериментальний порядок отримання документів для українців з тимчасово окупованих територій – моло] (uk:…
      Україна запустила експериментальний порядок отримання документів для українців з тимчасово окупованих територій – молоді люди, які ще не мали паспорта України, зможуть отримати посвідчення особи в українських дипмісіях у…
  - (2026-06-05) Атака на судна РФ в Азовському морі: в Азербайджані заявили про смерть 5 своїх громадян | LEDE: Прессекретар МЗС Азербайджану повідомив, що п'ятеро громадян країни загинули, ще троє отримали по] (uk:…
      Прессекретар МЗС Азербайджану повідомив, що п'ятеро громадян країни загинули, ще троє отримали поранення через атаку безпілотників на два іноземні вантажні судна в Азовському морі.
  - (2026-06-05) Хто в Офісі генпрокурора тримає контроль над ключовими напрямками – розслідування "Межі" | LEDE: ] (uk: Хто в Офісі генпрокурора тримає контроль над ключовими напрямками – розслідуванн)
  - (2026-06-05) РФ вдарила по підприємству та автостоянці в Чернігові: 6 людей постраждали, 37 авто понівечені | LEDE: Вдень 5 червня окупанти влучили по підприємству та автостоянці в Чернігові, поранивши шіст] (uk:…
      Вдень 5 червня окупанти влучили по підприємству та автостоянці в Чернігові, поранивши шістьох людей і пошкодивши десятки автомобілів.
  - (2026-06-05) Вештались нелегально: СБС поцілили у 5 російських суден за ніч | LEDE: Українські безпілотники атакували 5 російських суден у портах Маріуполя і Бердянська вночі 5 червня – "Мадяр"] (uk: Вештались нел…
      Українські безпілотники атакували 5 російських суден у портах Маріуполя і Бердянська вночі 5 червня – "Мадяр"
  - (2026-06-05) На Харківщині перекинувся автобус зі школярами: серед дітей є травмовані | LEDE: У ДТП під Харковом травмовано трьох дітей і двох дорослих. Інцидент стався на трасі Р-58 під час екскурсії.] (uk: На Ха…
      У ДТП під Харковом травмовано трьох дітей і двох дорослих. Інцидент стався на трасі Р-58 під час екскурсії.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-05) [Jazic Annemarie] Form 4 (Reporting)
      filed 2026-06-05 10:35 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001104659-26-070716 Size: 13 KB
  - (2026-06-05) [DILLARD'S, INC.] Form 4 (Issuer)
      filed 2026-06-05 10:35 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001104659-26-070716 Size: 13 KB
  - (2026-06-05) [DILLARD MIKE] Form 4 (Reporting)
      filed 2026-06-05 10:35 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001104659-26-070714 Size: 14 KB
  - (2026-06-05) [DILLARD'S, INC.] Form 4 (Issuer)
      filed 2026-06-05 10:35 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001104659-26-070714 Size: 14 KB
  - (2026-06-05) [Lucie Denise Alexandra] Form 4 (Reporting)
      filed 2026-06-05 10:34 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001104659-26-070713 Size: 11 KB
  - (2026-06-05) [DILLARD'S, INC.] Form 4 (Issuer)
      filed 2026-06-05 10:34 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001104659-26-070713 Size: 11 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-05) [United Kingdom] Stop cleaning duvets and pillows in washing machines when alternative is easier and faster
      domain: mirror.co.uk · language: English · tone:
  - (2026-06-05) [United Kingdom] Jury continues deliberations in trial of two teenagers accused of beach murder
      domain: burytimes.co.uk · language: English · tone:
  - (2026-06-05) [Australia] Elicia Tjong : extended care paramedics ease pressure on busy EDs | The Advertiser - Cessnock
      domain: cessnockadvertiser.com.au · language: English · tone:
  - (2026-06-05) [Australia] Origin - of - life oxygen exhibit a scientific experiment
      domain: cessnockadvertiser.com.au · language: English · tone:
  - (2026-06-05) [United States] Trump Open to Meeting Ayatollah for Iran Deal | Newsradio 92 . 7 WBEX
      domain: wbex.iheart.com · language: English · tone:
  - (2026-06-05) [India] Police detain BJP MLA Yatnal during protest against Karnataka govt Hijab ban withdrawal in schools
      domain: calcuttanews.net · language: English · tone:

### Paper Trading Scorecard — 31 new of 148 total
  - (2026-06-05) [Polymarket] Will Flavio Cobolli win the 2026 Men's French Open?
      The 2026 French Open is scheduled for May 18 - June 7, 2026. This market will resolve to the player that wins the 2026 French Open Men’s Singles Tournament. If at any point it becomes impossible for a listed player to wi…
  - (2026-06-05) [Polymarket] Will Ethereum reach $2,100 in June?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for ETH/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…
  - (2026-06-05) [Polymarket] Will Harry Kane be the top goalscorer at the 2026 FIFA World Cup?
      This market will resolve to the player who scores the most goals through all main tournament rounds of the 2026 FIFA World Cup competition. In the event of a tie, this market will resolve according to the official leader…
  - (2026-06-05) [Polymarket] Will the Fed decrease interest rates by 50+ bps after the July 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-06-05) [Polymarket] Will Russia enter Zaporizhia by June 30?
      This market will resolve to “Yes” if, according to the ISW map, Russia captures any territory of the city of Zaporizhia (https://maps.app.goo.gl/Gezpp2b4SDnefJ5s9) by June 30, 2026, at 11:59 PM ET. Territory will be cons…
  - (2026-06-05) [Polymarket] Will Türkiye win Group D in the 2026 FIFA World Cup?
      This market will resolve according to the team that wins Group D in the 2026 FIFA World Cup group stage, scheduled for June 11-27, 2026. If multiple teams tie as group winners, this market will resolve according to the o…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 27 new of 60 total
  - (2026-06-04) U.S. Supreme Court: FCC v. AT&T
  - (2026-06-04) U.S. Supreme Court: Hikma Pharmaceuticals USA Inc. v. Amarin Pharma, Inc.
  - (2026-06-04) U.S. Supreme Court: Sripetch v. SEC
  - (2026-06-04) Delaware Supreme Court: Tomales Bay Capital Anduril III, L.P. v. Pro Publica, Inc.
  - (2026-06-04) U.S. Court of Appeals, Federal Cir.: Ollnova Technologies Ltd. v. Ecobee Technologies Ulc
  - (2026-06-04) U.S. Court of Appeals, 9th Cir.: Welsh v. Loudbear

### U.S. Federal Action — 26 new of 35 total
  - (2026-06-05) Promoting Advanced Artificial Intelligence Innovation and Security
  - (2026-06-05) Proposed Waiver and Extension of the Project Period With Funding-Elementary and Secondary Education Act of 1965, as Amended, Title VI, Part B, Native Hawaiian Education
      The Secretary proposes to waive the requirements in the Education Department General Administrative Regulations (EDGAR) that generally prohibit project period extensions involving the obligation of additional Federal fun…
  - (2026-06-05) Exceptions From Foreign Ownership, Control, or Domination
      The U.S. Nuclear Regulatory Commission (NRC) is confirming the effective date of July 7, 2026, for the direct final rule that was published in the Federal Register on April 23, 2026. This direct final rule amended the NR…
  - (2026-06-05) Extending the Reporting Deadline Under the Greenhouse Gas Reporting Rule for 2025; Correction
      The Environmental Protection Agency (EPA) is correcting the preamble of a final rule published in the Federal Register on February 27, 2026. The final rule extended the reporting deadline under the Greenhouse Gas Reporti…
  - (2026-06-05) Reforming the High-Cost Program for an All-IP Future, Connect America Fund: A National Broadband Plan for Our Future High-Cost Universal Support
      In this document, the Federal Communications Commission (FCC or Commission) adopted a Notice of Proposed Rulemaking (NPRM) that kicks off a process to examine how the Commission can make some of its high-cost mechanisms…
  - (2026-06-05) Trump Accounts; Hearing
      This document provides a notice of public hearing on the notice of proposed rulemaking (REG-117270-25) published in the Federal Register on March 9, 2026. The proposed regulations provide guidance on making an election t…

### Government & military aircraft airborne (OpenSky) — 25 new of 29 total
  - (2026-06-05) PAT720 (United States)
      icao24: adfecb · position: (39.5829, -79.7426) · alt: 7383m · 512km/h
  - (2026-06-05) GAF136 (Germany)
      icao24: 3e8b41 · position: (52.2329, 22.8085) · alt: 8526m · 716km/h
  - (2026-06-05) CFC2952 (Canada)
      icao24: c2b585 · position: (53.7737, -2.6155) · alt: 2880m · 526km/h
  - (2026-06-05) PAT475 (United States)
      icao24: ae08fa · position: (40.9676, -75.912) · alt: 4411m · 501km/h
  - (2026-06-05) JAF2HN (Belgium)
      icao24: 44d1ba · position: (36.5727, 23.3148) · alt: 8763m · 670km/h
  - (2026-06-05) JAF12M (Belgium)
      icao24: 44d1a6 · position: (36.4626, -13.3303) · alt: 12192m · 819km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 17 new of 116 total
  - (2026-06-04) [OFAC] Cuba Designations; Issuance of Cuba-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Cuba Designations; Issuance of Cuba-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-06-04) [OFAC] 1258 - Office of Foreign Assets Control (.gov)
      1258 Office of Foreign Assets Control (.gov)
  - (2026-06-05) [OFAC] Test - for publishing issue - Office of Foreign Assets Control (.gov)
      Test - for publishing issue Office of Foreign Assets Control (.gov)
  - (2026-06-05) [USASpending] $35,002,991,770 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-06-05) [USASpending] $1,594,955,955 → NORTHROP GRUMMAN SYSTEMS CORPORATION: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUI
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUILDS UPON THE SUCCESS OF COMMERCIAL ORBITAL TRANSPORTATION SERVICES SPACE ACT AGREEMENT DEVELO…
  - (2026-06-05) [USASpending] $1,420,888,745 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-05) [China] Gas tank blast kills two and injures 13 at Liaoning shop
      africa.chinadaily.com.cn · English
  - (2026-06-05) [China] Delicate , multi - faceted relations between India and China : Russian Prez Putin says external interference
      asiabulletin.com · English
  - (2026-06-05) [China] News for Airlines , Airports and the Aviation Industry
      centreforaviation.com · English
  - (2026-06-05) [China] China Airlines Unveils All - New Premium Economy Class Aboard the 787 for Flying with
      centreforaviation.com · English
  - (2026-06-05) [China] European Cargo Airline Profile
      centreforaviation.com · English
  - (2026-06-05) [China] RAVE Aerospace Supplier Profile
      centreforaviation.com · English

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-06-04) M 5.2 - 77 km S of Gorontalo, Indonesia
      M5.2 · 77 km S of Gorontalo, Indonesia · depth 128.812 km
  - (2026-06-05) M 5.1 - 103 km NNW of Villa General Roca, Argentina
      M5.1 · 103 km NNW of Villa General Roca, Argentina · depth 135.979 km
  - (2026-06-05) M 4.9 - 126 km SE of Vilyuchinsk, Russia
      M4.9 · 126 km SE of Vilyuchinsk, Russia · depth 35 km
  - (2026-06-04) M 4.9 - 70 km SW of Modisi, Indonesia
      M4.9 · 70 km SW of Modisi, Indonesia · depth 99.482 km
  - (2026-06-04) M 4.9 - 57 km NNW of Huocheng, China
      M4.9 · 57 km NNW of Huocheng, China · depth 10 km
  - (2026-06-04) M 4.8 - 32 km WSW of El Tocuyo, Venezuela
      M4.8 · 32 km WSW of El Tocuyo, Venezuela · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-06-05) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $3,539,640 · resolves 2026-07-20
  - (2026-06-05) Will Hunter Biden win the 2028 Democratic presidential nomination?
      yes price: 3% · 24h volume: $2,586,638 · resolves 2028-11-07
  - (2026-06-05) Knicks vs. Spurs
      yes price: 34% · 24h volume: $1,884,790 · resolves 2026-06-06
  - (2026-06-05) Dota 2: Team Falcons vs BetBoom Team - Game 1 Winner
      yes price: 0% · 24h volume: $1,296,782 · resolves 2026-06-05
  - (2026-06-05) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,236,113 · resolves 2026-07-20
  - (2026-06-05) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,125,232 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-05) [Marginal Revolution] Western hemisphere fact of the day
      Overall, the Western Hemisphere now produces more oil than the Middle East did before the crisis. Canada is the world’s fourth-largest oil producer. Brazil produces four times as much oil as Venezuela; and in Guyana, whe…
  - (2026-06-05) [Marginal Revolution] Rubber rationing in World War II
      When during the meetings the Americans offered that at most they could convert 15 percent of U.S. auto plants to military production, Beaverbrook replies that 100 percent of British automobile factories had been converte…
  - (2026-06-04) [Marginal Revolution] My twenty-minute AI talk for the Swedish company Sana
      The post My twenty-minute AI talk for the Swedish company Sana appeared first on Marginal REVOLUTION.
  - (2026-06-04) [Conversable Economist] Is GDP Failing to Capture AI?
      Gross domestic product measures the economic transaction in an economy, according to quantities bought and sold and market prices. But does this method work for AI? Anton Korinek and Patrick McKelvey work through the que…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: persons, provide, proposed, events, action, program, enforcement, captain, personnel, event, vessels, public
- state_bills: today=127, 7d-median=155, 14d-median=148; carrying terms: facilities, claims, among, committee, creates, technology, provisions, throughput, permit, reports, regarding, provide
- state_news: today=782, 7d-median=722, 14d-median=722; carrying terms: claims, graham, republished, governor, called, finding, visit, provide, scaled, organization, because, azgovernor
- local_news: today=225, 7d-median=231, 14d-median=247; carrying terms: among, atlantamagazine, content, people, restaurant, times, victim, accused, police, missing, major, history
- foreign_news: today=884, 7d-median=861, 14d-median=864; carrying terms: claims, meeting, macroeconomic, pagoda, worth, footage, governor, regarding, surveillance, called, struck, finding
- chinese_internal: today=272, 7d-median=271, 14d-median=272; carrying terms: people, title, cbmizefvx, cbmizkfvx, china, lxtfa, rally, lxtfb, cbmiyefvx, cbmidefvx, color, cbmibkfvx
- russian_internal: today=1125, 7d-median=964, 14d-median=1036; carrying terms: financial, tasnim, client, bloomberg, press, reuters, forbidden, garros, media, politico, centcom, russian
- ukrainian_internal: today=126, 7d-median=121, 14d-median=122; carrying terms: client, title, censor, hmarochos, president, independent, forbidden, vechirniy, ukraine, ukrinform, https, found
- ukraine_theater: today=320, 7d-median=279, 14d-median=299; carrying terms: jmvxlhv, shyzuvztugu, volunteers, bxbux, cuxqlwzknxznx, bszvpsmdwa, cuxqae, hrwhkc, cuxoov, cbmipwfbvv, nqedfpnmktnfd, additional
- paper_bets: today=148, 7d-median=147, 14d-median=144; carrying terms: seats, netanyahu, provisions, named, house, powell, company, creation, governor, georgia, visit, above
- weather: today=152, 7d-median=100, 14d-median=110; carrying terms: worth, tonight, sweep, above, afdlsx, additional, below, pattern, afdsew, strong, oxnard, locations
- macro: today=21, 7d-median=10, 14d-median=0; carrying terms: latest, labor, rates, treasury, unemployment, funds, recession, effective, spread, indicator, unrate, total
- markets: today=21, 7d-median=21, 14d-median=0; carrying terms: commodities, russell, close, equities, crude, natural, range, nasdaq, agriculture, futures, yield, silver
- markets_global: today=63, 7d-median=79, 14d-median=79; carrying terms: kospi, india, index, close, germany, price, france, australia, commodity, equity, mexico, copper
- sanctions_procurement: today=116, 7d-median=108, 14d-median=102; carrying terms: claims, description, imposed, rkiye, technology, congo, mission, updates, provide, activities, tunisia, sovereignty
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quantitative, httperror, https, quiverquant, unauthorized, error, quiver, client
- billionaires: today=33, 7d-median=34, 14d-median=34; carrying terms: gates, source, technologies, buffett, zhang, brokerage, nasdaq, warren, technology, michael, giancarlo, charles
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=60, 14d-median=30; carrying terms: blanche, america, smith, group, veterans, ortiz, collins, whitton, director, company, state, society
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, filer, technology, james, services
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, joseph, sherrod, ocasio, booker, robert, committee, receipts, krishnamoorthi, cortez, michael, house
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=83, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: language, domain, kingdom, india, english, cancer
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=29, 7d-median=29, 14d-median=20; carrying terms: position, ground, belgium, germany, canada, kingdom, france, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: surges, published, consecutive, morocco, outbreaks, among, majority, haemorrhage, broader, diphtheria, infecting, local
- cisa_kev: today=10, 7d-median=15, 14d-median=15; carrying terms: injection, product, overflow, authentication, bypass, drupal, remediation, vulnerability, vendor, litespeed, embedded, cpanel
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=141, 7d-median=126, 14d-median=126; carrying terms: minor, angola, ukraine, russia, lithuania, australia, romania, democratic, congo, cambodia, gabon, agricultural
- usgs_quakes: today=11, 7d-median=14, 14d-median=14; carrying terms: indonesia, depth
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, world, resolves, peace, volume, permanent, ceasefire, coast, ivory, announces, extension, turkiye
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: revolution, economist, class, marginal, conversable, https, policy, economy, times, crisis, company, economic
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: graham, jefferson, rutherford, booker, stansbury, derrick, krishnamoorthi, scanlon, espaillat, coney, higgins, rouzer
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, placed, today, unavailable, module, either, consensus, market, placement, converges, markets, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*