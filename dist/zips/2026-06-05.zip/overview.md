# WORLDSCOPE morning brief — 2026-06-05

## Headline
3654 new items across 26 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (820) · International News + Multilateral Institutions (675) · State-Level News (537) · World leaders & government officials (324) · Chinese Internal News (245) · Local News: St. Louis + Atlanta (216) · U.S. Weather + Severe / Climate Outlooks (176) · Ukraine Theater (total-war monitoring) (170) · State Legislative Action (94) · Ukrainian Internal News (national + local Kyiv) (83) · Paper Trading Scorecard (43) · Court opinions of consequence (federal & state) (41)

## What changed today
### Russian Internal News (state + in-exile) — 820 new of 1210 total
  - (2026-06-05) Банк России изменил метод расчета официального курса евро к рублю | LEDE: Банк России ввел новый порядок расчета официального курса евро к рублю, сообщается на сайте регулятора. ] (ru: Банк России изм…
      Банк России ввел новый порядок расчета официального курса евро к рублю, сообщается на сайте регулятора.
  - (2026-06-05) Доносчик Виталий Бородин проиграл суд Алле Пугачевой | LEDE: Пресненский районный суд Москвы в полном объеме отказал в удовлетворении иска доносчика Виталия Бородина к певице Алле Пугачевой ] (ru: Дон…
      Пресненский районный суд Москвы в полном объеме отказал в удовлетворении иска доносчика Виталия Бородина к певице Алле Пугачевой о защите чести, достоинства и деловой репутации. Об этом сообщили «Медузе» юристы, представ…
  - (2026-06-05) На войне в Украине погиб Наран Очир-Горяев — Герой России, который участвовал в прямой линии Путина | LEDE: Российский военнослужащий Наран Очир-Горяев погиб «при выполнении боевых задач» на] (ru: На…
      Российский военнослужащий Наран Очир-Горяев погиб «при выполнении боевых задач» на войне с Украиной. Об этом сообщил глава Калмыкии Бату Хасиков.
  - (2026-06-05) «Российская сторона снова выбирает войну». Зеленский — об отказе Путина встретиться с ним | LEDE: Президент Украины Владимир Зеленский заявил, что Владимир Путин не хочет заканчивать войну. ] (ru: «Ро…
      Президент Украины Владимир Зеленский заявил, что Владимир Путин не хочет заканчивать войну. Так он прокомментировал ответ российского президента на его открытое письмо.
  - (2026-06-05) Путин заявил, что Зеленский просил о личной встрече еще несколько недель назад — через российского бизнесмена, приезжавшего в Киев | LEDE: Владимир Путин утверждает, что Владимир Зеленский п] (ru: Пут…
      Владимир Путин утверждает, что Владимир Зеленский просил его о личной встрече через одного из российских бизнесменов — еще за несколько недель до того, как опубликовал открытое письмо с предложением завершить войну. Об э…
  - (2026-06-05) Дуров заявил, что России не достичь «цифрового суверенитета» с помощью блокировок. И предложил выдать медаль чиновнику, который сломал Рунет | LEDE: Блокировки интернета только отдалили Росс] (ru: Дур…
      Блокировки интернета только отдалили Россию от «цифрового суверенитета», заявил основатель Telegram Павел Дуров.

### International News + Multilateral Institutions — 675 new of 874 total
  - (2026-06-05) [Global] ‘Family values’ African charter condemned by rights groups as regressive and dangerous
  - (2026-06-04) [Global] Experts criticise plan for American-only Ebola quarantine centre in Kenya
  - (2026-06-04) [Global] Civilians flee as Somali troops and opposition-allied militias trade fire in Mogadishu
  - (2026-06-05) [Global] US imposes new sanctions on Cuban president and Castro family members
  - (2026-06-04) [Global] Canada endorses embattled marine park’s plan to relocate 30 beluga whales
  - (2026-06-04) [Global] Outrage in Argentina after two teen girls murdered as femicide crisis endures

### State-Level News — 537 new of 926 total
  - (2026-06-04) [Alabama] Governor Ivey Approves Request for Alabama National Guard to Support America 250 Events in Nation’s Capital
      MONTGOMERY – Governor Kay Ivey on Thursday announced she approved a request for the Alabama National Guard (ALNG) to support operations surrounding the America 250 events in Washington, D.C. “One month from today, our na…
  - (2026-06-05) [California] Cinco cosas que debes saber sobre la nueva política de tarjetas de residencia de la administración Trump
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/082124_Naturalization-Ceremony_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-po…
  - (2026-06-05) [California] Juez federal ordena que centro de detención de inmigrantes permita inspección sanitaria del condado de San Diego
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/03/022026_Padilla-Otay-Mesa_AH_02_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-06-05) [California] Why CA’s top-two primary isn’t working the way voters intended
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Primary-Election-Fresno_LV_CM_11.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-po…
  - (2026-06-05) [California] This anti-tax ballot measure could sap local housing funds. California lawmakers need to act
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/09/091225_End-Of-Session_FG_CM_08.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-06-05) [California] If California’s race for governor is a stress test for democracy, it’s failing
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Becerra-Primary_JWH_CM_10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 245 new of 286 total
  - (2026-06-05) 习近平同老挝人革党中央总书记、国家主席通伦会谈 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFB4SE5XckhLX293VW5SY2VwWnB2ZGdDZXR6S2l1ZmpySi11dXJ1d3p1TEx2bFZqaXRydkh2SU4tNW5qX21QVmZkOXpI] (zh:…
      习近平同老挝人革党中央总书记、国家主席通伦会谈 人民网-图片频道
  - (2026-06-04) 盐宜高铁长江隧道“奋楫号”盾构机刀盘顺利下井 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE0yVWg0SnZSdmJvZm9UZVRtZTA2X3lUN3FJVUZ0NXVrTnhKNVAyTlZQNFFPeFpVa1VqWExfUThMcHR1VGNfVGQ5cVM3T] (zh:…
      盐宜高铁长江隧道“奋楫号”盾构机刀盘顺利下井 人民网-图片频道
  - (2026-06-04) 乌拉圭宣布对中国公民免签--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFB1SFVGWVluOVNrRmtxcm1RUGE2dHFlTnpGZklmU0NnNDZhQXp3bkQyMmExYUMyMFZlUHJoTl9ocFhudEJuamFxWVM3OXNYazYycjRP] (zh:…
      乌拉圭宣布对中国公民免签--国际 人民网
  - (2026-06-05) 国务院任免国家工作人员 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFBhV3ZJcEdvWldDdk9BTy05SHlZMHRKSmk2RXJEa3pKUVM0VFB4c3ZjblZpVUxwTFBhYjFWdTkwU1pyZGhPRjdyV3] (zh:…
      国务院任免国家工作人员 politics.people.com.cn
  - (2026-06-05) 学习新语｜执绿色画笔 绘美丽中国 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTE56NzRVNGpjTnZDUENIQ0xDck1lV1FlVlg3b05XSVhoN01CamlRSlVYdmo5dzNBR3N4RDRiRC1zRG04N1NfM] (zh:…
      学习新语｜执绿色画笔 绘美丽中国 politics.people.com.cn
  - (2026-06-05) 美国制裁古巴国家主席古巴外长回应--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE5KVnNpdGdmS2JVem5VdHlmcDZDTEdBdXhOMWtTNWZ0UVVaSHpycXhPUDVUZmdIYkZuSkVvNHFvVUozZGcwOERYV1FKSWFUODZr] (zh:…
      美国制裁古巴国家主席古巴外长回应--国际 人民网

### Local News: St. Louis + Atlanta — 216 new of 237 total
  - (2026-06-05) [St. Louis] Ben Poremba’s Del Bono to bring wood-fired pizza to the Delmar Maker District
      This summer, Ben Poremba’s Bengelina Hospitality Group will debut its latest concept, Del Bono (5232-B Delmar). Featuring wood-fired pizza, the new concept is slated to open June 18 at the Maker’s Yard, a part of the Del…
  - (2026-06-05) [St. Louis] Ask George: Are any local restaurants using AI to help manage their day-to-day operations?
      I hope you, dear reader, aren’t growing weary of hearing about AI. I’m reminded of the famous courtroom scene in Scent of a Woman when Al Pacino’s character bellows, “Naw, I’m just getting warmed up.” Like most industrie…
  - (2026-06-05) [St. Louis] St. Peters man’s victory will give many more people the right to a jury trial
      A St. Peters man and his sunflowers have changed the way that many Missourians found guilty in municipal courts can seek new trials in the higher circuit court system. “Now the game has changed, the balance of power has…
  - (2026-06-05) [St. Louis] What’s True in the Lou? – 6/5/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-06-05) [St. Louis] Excellence in Nursing Awards 2026
      For the 17th year in a row, St. Louis Magazine is honoring the remarkable efforts of nurses across the region by hosting the annual Excellence in Nursing Awards, presented by BJC HealthCare and Barnes-Jewish College Gold…
  - (2026-06-04) [St. Louis] Farotto’s Pasta & Pizzeria celebrates its 70th anniversary
      One of St. Louis’ longest-running pizzerias recently celebrated its 70th anniversary. Farotto’s Pasta & Pizzeria (9525 Manchester) marked the occasion with a private party for its loyal patrons. The family-owned and -ope…

### U.S. Weather + Severe / Climate Outlooks — 176 new of 178 total
  - (2026-06-05) [Moderate] Special Weather Statement: Special Weather Statement issued June 5 at 4:13PM EDT by NWS Marquette MI
      At 412 PM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Au Train to 6 miles north of Rapid River. Movement was east at 40 mph. HAZARD...Wind gusts up to 40 mph and half inch hail.…
  - (2026-06-05) [Severe] Flash Flood Warning: Flash Flood Warning issued June 5 at 3:13PM CDT until June 5 at 4:15PM CDT by NWS Lubbock TX
      FFWLUB The National Weather Service in Lubbock has issued a * Flash Flood Warning for... Northeastern Briscoe County in the panhandle of Texas... Northwestern Hall County in the panhandle of Texas... * Until 415 PM CDT.…
  - (2026-06-05) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 5 at 3:13PM CDT until June 5 at 3:45PM CDT by NWS Twin Cities/Chanhassen MN
      At 313 PM CDT, a severe thunderstorm was located near Hancock, or 11 miles southeast of Morris, moving southeast at 20 mph. HAZARD...Half dollar size hail. SOURCE...Radar indicated. IMPACT...Damage to vehicles is expecte…
  - (2026-06-05) [Moderate] Special Weather Statement: Special Weather Statement issued June 5 at 2:11PM MDT by NWS Albuquerque NM
      At 211 PM MDT, Doppler radar was tracking a strong thunderstorm 12 miles south of Lingo, or 42 miles south of Portales, moving north at 10 mph. HAZARD...Wind gusts up to 50 mph and nickel size hail. SOURCE...Radar indica…
  - (2026-06-05) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 5 at 3:09PM CDT until June 5 at 3:45PM CDT by NWS Lubbock TX
      SVRLUB The National Weather Service in Lubbock Texas has issued a * Severe Thunderstorm Warning for... Bailey County in northwestern Texas... Northwestern Cochran County in northwestern Texas... West central Lamb County…
  - (2026-06-05) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.

### Ukraine Theater (total-war monitoring) — 170 new of 342 total
  - (2026-06-05) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-04) [FIRMS] thermal anomaly 45.257, 31.675 (FRP 9.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1047Z, FRP 9.61 MW
  - (2026-06-04) [FIRMS] thermal anomaly 45.356, 30.904 (FRP 2.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1047Z, FRP 2.53 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.573, 32.304 (FRP 7.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 7.91 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.627, 32.621 (FRP 2.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 2.38 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.578, 32.292 (FRP 3.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 3.56 MW

### State Legislative Action — 94 new of 128 total
  - (2026-06-05) [Alaska SB 174] An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
      An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
  - (2026-06-05) [Alaska SB 275] An Act relating to natural gas and natural gas projects; relating to the Alaska Gasline Development Corporation; relating to the powers and duties of the Legislative Budget and Audit C…
      An Act relating to natural gas and natural gas projects; relating to the Alaska Gasline Development Corporation; relating to the powers and duties of the Legislative Budget and Audit Committee; relating to the value of c…
  - (2026-06-05) [Alaska HJR 10] Proposing amendments to the Constitution of the State of Alaska relating to the Alaska permanent fund and to appropriations from the Alaska permanent fund.
      Proposing amendments to the Constitution of the State of Alaska relating to the Alaska permanent fund and to appropriations from the Alaska permanent fund.
  - (2026-06-05) [Alaska HCR 2] Proposing an amendment to the Uniform Rules of the Alaska State Legislature relating to voting and abstention from voting.
      Proposing an amendment to the Uniform Rules of the Alaska State Legislature relating to voting and abstention from voting.
  - (2026-06-05) [Alaska HB 152] An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on indiv…
      An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on individuals under the Alaska Net Income T…
  - (2026-06-05) [Alaska SB 23] An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
      An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 83 new of 138 total
  - (2026-06-05) Zelensky Says Putin Does Not Want Peace After Rejecting Meeting Proposal
      President Volodymyr Zelensky has sent an open letter to the Kremlin leader Vladimir Putin, late Wednesday, demanding a direct meeting between the leaders, on neutral ground and security guarantees to end Russia’s war. Pu…
  - (2026-06-05) Armenia Threatens 25-Day Military Camp for Russia-Based Election Voters
      The Armenian government has warned that citizens traveling from Russia to “vote for bribes” in the June 7 parliamentary elections could be sent to a 25-day military training camp, with those who refuse facing possible pr…
  - (2026-06-05) Stalin’s Playbook: Why Putin’s Insiders Keep Dying
      Putin’s Russia is bleeding out on the outside—and now, it is devouring itself from the inside.
  - (2026-06-05) Zelensky Signs Cinematography Reform Law Securing Stable Funding
      President Volodymyr Zelensky has signed a new law that reshapes how the state supports cinema in Ukraine by changing funding rules, adding new support tools for filmmakers and digitalizing contacts with the film regulato…
  - (2026-06-05) Putin Responds to Zelensky’s Letter, Says Meeting Would Be Pointless
      Speaking at the St. Petersburg International Economic Forum on June 5, Vladimir Putin said he had read Zelensky’s open letter that morning. He addressed comments about his age and time in office, criticized Ukraine’s ele…
  - (2026-06-05) CNN: Israel Secretly Operated Military, Intelligence Bases in Azerbaijan
      Israel secretly deployed military and intelligence units to Azerbaijan during its war with Iran, CNN reported on Friday, citing sources familiar with the operation. The network reportedly included covert sites in Iraq, t…

### Paper Trading Scorecard — 43 new of 157 total
  - (2026-06-05) [Polymarket] Will both candidates advancing to the general election for Governor of California from the June 2, 2026 primary be affiliated with the Democratic Party?
      The non-partisan primary election for Governor of California is scheduled to take place on June 2, 2026. The top two candidates in this election by number of votes won will advance to the general election for Governor of…
  - (2026-06-05) [Polymarket] Will Daniil Medvedev be the 2026 Men’s Wimbledon winner?
      Wimbledon 2026 is scheduled for June 29 - July 12, 2026. This market will resolve to the player that wins the 2026 Wimbledon Men’s Singles Tournament. If at any point it becomes impossible for a listed player to win the…
  - (2026-06-05) [Polymarket] Will Bitcoin dip to $59,000 on June 5?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) on the date specified in the title, between 12:00 AM ET and 11:59 PM ET has a final "Low" price equal to or lower than t…
  - (2026-06-05) [Polymarket] Will Elon Musk post 60-79 tweets from June 5 to June 12, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from June 5 12:00 PM ET to June 12, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and rep…
  - (2026-06-05) [Polymarket] Will Elon Musk post 440-459 tweets from June 5 to June 12, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from June 5 12:00 PM ET to June 12, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and rep…
  - (2026-06-05) [Polymarket] LoL: Team Heretics Academy vs UCAM Esports Club (BO5) - LES Playoffs
      This market refers to the LoL Grand final match between Team Heretics Academy and UCAM Esports Club in the LES Playoffs, initially scheduled for June 5 at 11:00AM ET. This market will resolve to "Team Heretics Academy" i…

### Court opinions of consequence (federal & state) — 41 new of 60 total
  - (2026-06-09) Connecticut Supreme Court: TOV Realty, LLC v. Suarez
  - (2026-06-05) U.S. Court of Appeals, 9th Cir.: Ciria v. Gerrans
  - (2026-06-05) U.S. Court of Appeals, 9th Cir.: Pizzuto v. Valley
  - (2026-06-05) U.S. Court of Appeals, 7th Cir.: Anqi Liu v. Markwayne Mullin
  - (2026-06-05) U.S. Court of Appeals, 7th Cir.: Joshua Harris v. W6LS, Inc.
  - (2026-06-05) U.S. Court of Appeals, 7th Cir.: Joshua Harris v. W6LS, Inc.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-05) 424B2 - GS Finance Corp. (0001419828) (Filer)
      filed 2026-06-05 20:14 UTC — Filed: 2026-06-05 AccNo: 0001193125-26-259591 Size: 591 KB
  - (2026-06-05) 424B2 - GOLDMAN SACHS GROUP INC (0000886982) (Filer)
      filed 2026-06-05 20:14 UTC — Filed: 2026-06-05 AccNo: 0001193125-26-259591 Size: 591 KB
  - (2026-06-05) [Smith Michael Alexander] Form 4 (Reporting)
      filed 2026-06-05 20:14 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001870278-26-000017 Size: 4 KB
  - (2026-06-05) [INSMED Inc] Form 4 (Issuer)
      filed 2026-06-05 20:14 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001870278-26-000017 Size: 4 KB
  - (2026-06-05) [Orvidas Laura] Form 4 (Reporting)
      filed 2026-06-05 20:13 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0002030095-26-000002 Size: 5 KB
  - (2026-06-05) [NETGEAR, INC.] Form 4 (Issuer)
      filed 2026-06-05 20:13 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0002030095-26-000002 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-05) [Israel] Secular man attacked by ultra - Orthadox protesters in Jerusalem
      domain: jpost.com · language: English · tone:
  - (2026-06-05) [Israel] After years of hostile relations with Israel , Slovenia new prime minister signals diplomatic reset | JTA
      domain: clevelandjewishnews.com · language: English · tone:
  - (2026-06-05) [United States] Innocent Woman Killed By Gunmen Who Fired 70 To 80 Shots At Wrong Target
      domain: b101.iheart.com · language: English · tone:
  - (2026-06-05) [United States] Netflix New 3 - Part Michael Jackson Series Fuels Rotten Tomatoes Review Bomb After $855M Movie
      domain: screenrant.com · language: English · tone:
  - (2026-06-05) [United States] Person dies in crash on Highway 26 in Clatsop County
      domain: kgw.com · language: English · tone:
  - (2026-06-05) [United States] US employers likely added 105 , 000 jobs in May with labor market stable despite costly Iran war
      domain: timesfreepress.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-06-05) EAGLE24 (United States)
      icao24: adffaa · position: (33.9411, -87.9989) · alt: 4366m · 731km/h
  - (2026-06-05) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (39.5152, -0.4724) · alt: 11285m · 792km/h
  - (2026-06-05) PAT453 (United States)
      icao24: adfe4c · position: (36.5357, -83.9651) · alt: 6705m · 432km/h
  - (2026-06-05) PAT917 (United States)
      icao24: adfe94 · position: (35.3057, -120.8044) · alt: 7010m · 490km/h
  - (2026-06-05) PAT639 (United States)
      icao24: adfe93 · position: (35.9303, -86.4188) · alt: 5791m · 521km/h
  - (2026-06-05) PAT705 (United States)
      icao24: adfe92 · position: (34.1987, -118.9712) · alt: 1097m · 268km/h

### U.S. Federal Action — 26 new of 35 total
  - (2026-06-05) Promoting Advanced Artificial Intelligence Innovation and Security
  - (2026-06-05) Proposed Waiver and Extension of the Project Period With Funding-Elementary and Secondary Education Act of 1965, as Amended, Title VI, Part B, Native Hawaiian Education
      The Secretary proposes to waive the requirements in the Education Department General Administrative Regulations (EDGAR) that generally prohibit project period extensions involving the obligation of additional Federal fun…
  - (2026-06-05) Exceptions From Foreign Ownership, Control, or Domination
      The U.S. Nuclear Regulatory Commission (NRC) is confirming the effective date of July 7, 2026, for the direct final rule that was published in the Federal Register on April 23, 2026. This direct final rule amended the NR…
  - (2026-06-05) Extending the Reporting Deadline Under the Greenhouse Gas Reporting Rule for 2025; Correction
      The Environmental Protection Agency (EPA) is correcting the preamble of a final rule published in the Federal Register on February 27, 2026. The final rule extended the reporting deadline under the Greenhouse Gas Reporti…
  - (2026-06-05) Reforming the High-Cost Program for an All-IP Future, Connect America Fund: A National Broadband Plan for Our Future High-Cost Universal Support
      In this document, the Federal Communications Commission (FCC or Commission) adopted a Notice of Proposed Rulemaking (NPRM) that kicks off a process to examine how the Commission can make some of its high-cost mechanisms…
  - (2026-06-05) Trump Accounts; Hearing
      This document provides a notice of public hearing on the notice of proposed rulemaking (REG-117270-25) published in the Federal Register on March 9, 2026. The proposed regulations provide guidance on making an election t…

### Government Action: Sanctions + Procurement + Foreign Agents — 18 new of 117 total
  - (2026-06-04) [OFAC] Cuba Designations; Issuance of Cuba-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Cuba Designations; Issuance of Cuba-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-06-05) [OFAC] Iran-related Designations; Counter Terrorism Designations Updates - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Counter Terrorism Designations Updates Office of Foreign Assets Control (.gov)
  - (2026-06-04) [OFAC] 1258 - Office of Foreign Assets Control (.gov)
      1258 Office of Foreign Assets Control (.gov)
  - (2026-06-05) [OFAC] Test - for publishing issue - Office of Foreign Assets Control (.gov)
      Test - for publishing issue Office of Foreign Assets Control (.gov)
  - (2026-06-05) [USASpending] $35,002,991,770 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-06-05) [USASpending] $1,594,955,955 → NORTHROP GRUMMAN SYSTEMS CORPORATION: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUI
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUILDS UPON THE SUCCESS OF COMMERCIAL ORBITAL TRANSPORTATION SERVICES SPACE ACT AGREEMENT DEVELO…

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-06-05) M 5.3 - 97 km NNE of Lospalos, Timor Leste
      M5.3 · 97 km NNE of Lospalos, Timor Leste · depth 154.139 km
  - (2026-06-05) M 5.3 - 7 km NNW of Manito, Philippines
      M5.3 · 7 km NNW of Manito, Philippines · depth 10 km
  - (2026-06-05) M 5.3 - Pacific-Antarctic Ridge
      M5.3 · Pacific-Antarctic Ridge · depth 10 km
  - (2026-06-04) M 5.2 - 77 km S of Gorontalo, Indonesia
      M5.2 · 77 km S of Gorontalo, Indonesia · depth 128.812 km
  - (2026-06-05) M 5.1 - 103 km NNW of Villa General Roca, Argentina
      M5.1 · 103 km NNW of Villa General Roca, Argentina · depth 135.979 km
  - (2026-06-05) M 4.9 - 37 km WSW of Kyelang, India
      M4.9 · 37 km WSW of Kyelang, India · depth 22.49 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-06-05) MOVER ▼ Larry Ellison — $261.87B ($-25.02B since yesterday)
      United States · Technology · source: Oracle
  - (2026-06-05) MOVER ▼ Elon Musk — $803.33B ($-18.93B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-06-05) MOVER ▼ Michael Dell — $226.67B ($-12.93B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-06-05) MOVER ▼ Mark Zuckerberg — $203.97B ($-11.35B since yesterday)
      United States · Technology · source: Facebook
  - (2026-06-05) MOVER ▼ Jensen Huang — $178.24B ($-10.60B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-06-05) MOVER ▼ Jeff Bezos — $255.95B ($-6.42B since yesterday)
      United States · Technology · source: Amazon

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-06-05) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $5,971,959 · resolves 2026-07-20
  - (2026-06-05) Knicks vs. Spurs
      yes price: 32% · 24h volume: $2,888,600 · resolves 2026-06-06
  - (2026-06-05) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,240,205 · resolves 2026-07-20
  - (2026-06-05) Counter-Strike: NRG vs BIG (BO3) - IEM Cologne Major Stage 1
      yes price: 7% · 24h volume: $2,088,257 · resolves 2026-06-05
  - (2026-06-05) Will Hunter Biden win the 2028 Democratic presidential nomination?
      yes price: 3% · 24h volume: $1,822,815 · resolves 2028-11-07
  - (2026-06-05) Will the Fed increase interest rates by 50+ bps after the June 2026 meeting?
      yes price: 0% · 24h volume: $1,407,283 · resolves 2026-06-17

### World News (by country, top stories) — 6 new of 6 total
  - (2026-06-05) [South Korea] Park Bo Gum takes on first animation voice role in David
      allkpop.com · English
  - (2026-06-05) [South Korea] Byeon Woo Seok returns to social media after two - week hiatus , shares Jae - seok B & B Rules ! photos
      allkpop.com · English
  - (2026-06-05) [South Korea] New Samsung Notes update brings three useful features
      sammobile.com · English
  - (2026-06-05) [South Korea] SECRET Announces First Comeback in Nearly 12 Years with New Three - Member Lineup
      kpopstarz.com · English
  - (2026-06-05) [South Korea] Niall Horan Praises BTS While Comparing K - Pop and One Direction Eras
      kpopstarz.com · English
  - (2026-06-05) [South Korea] Navy service member dies after being found unconscious during combat drill in Yellow Sea
      koreaherald.com · English

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-05) [Marginal Revolution] Friday assorted links
      1. Rob Wiblin interviews Rohin Shah, who leads AGI alignment/safety at DeepMind. 2. Books Arnold Kling has reread. 3. Wemby and Star Wars. 4. Even (especially?) for ontologists, supply is elastic. 5. SSRN is getting wors…
  - (2026-06-05) [Marginal Revolution] Tyler and Alex Speak to OpenAI
      We were honored to speak to OpenAI about the economics of AI. Lots of good material here. Self-recommending. The post Tyler and Alex Speak to OpenAI appeared first on Marginal REVOLUTION.
  - (2026-06-05) [Marginal Revolution] Western hemisphere fact of the day
      Overall, the Western Hemisphere now produces more oil than the Middle East did before the crisis. Canada is the world’s fourth-largest oil producer. Brazil produces four times as much oil as Venezuela; and in Guyana, whe…
  - (2026-06-04) [Conversable Economist] Is GDP Failing to Capture AI?
      Gross domestic product measures the economic transaction in an economy, according to quantities bought and sold and market prices. But does this method work for AI? Anton Korinek and Patrick McKelvey work through the que…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 11 total
  - (2026-06-05) CVE-2026-28318 · SolarWinds Serv-U: SolarWinds Serv-U Uncontrolled Resource Consumption Vulnerability
      vendor: SolarWinds · product: Serv-U · CISA remediation by 2026-06-19

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: persons, action, enforcement, vessels, coast, authorized, public, proposed, event, provide, guard, safety
- state_bills: today=128, 7d-median=155, 14d-median=148; carrying terms: homeowners, members, relating, persons, board, institutions, taxes, emergency, create, american, contributions, funds
- state_news: today=926, 7d-median=722, 14d-median=722; carrying terms: members, detained, connecticut, nebraska, deputy, newsletter, professor, visit, oppose, officers, emergency, massachusetts
- local_news: today=237, 7d-median=237, 14d-median=247; carrying terms: board, officers, killing, season, investigators, being, stars, accused, station, project, prices, years
- foreign_news: today=874, 7d-median=861, 14d-median=864; carrying terms: sparks, nigerian, members, applauded, wooden, targeted, naughty, xuejun, achieve, deputy, professor, computer
- chinese_internal: today=286, 7d-median=271, 14d-median=274; carrying terms: people, https, cbmizkfvx, cbmiykfvx, politics, cbmizefvx, cbmickfvx, china, property, articles, title, cbmia
- russian_internal: today=1210, 7d-median=964, 14d-median=1036; carrying terms: title, centcom, roland, novayagazeta, europe, found, https, novaya, reuters, garros, media, associated
- ukrainian_internal: today=138, 7d-median=121, 14d-median=122; carrying terms: kyivindependent, independent, babel, vechirniy, https, hromadske, forbidden, httperror, forum, found, title, economic
- ukraine_theater: today=342, 7d-median=279, 14d-median=299; carrying terms: members, zadbqaks, sgvfv, swvnrvaxtdz, targeted, dhdmnbrxjgoxe, juddrjmm, hztefitvvybee, deputy, gwrevwoffxbtuzamdqyxdb, buhic, zfawg
- paper_bets: today=157, 7d-median=147, 14d-median=144; carrying terms: polymarket, manifold, nebraska, achieved, achieve, anthropic, lifetime, colorado, visit, presidential, following, control
- weather: today=178, 7d-median=100, 14d-median=110; carrying terms: winds, including, point, lying, aviation, afdlox, oxnard, please, continue, afdlwx, strong, weather
- macro: today=21, 7d-median=10, 14d-median=0; carrying terms: funds, rates, spread, indicator, recession, unrate, unemployment, labor, treasury, latest, effective, money
- markets: today=21, 7d-median=21, 14d-median=0; carrying terms: close, proxy, large, rates, agriculture, crypto, corporate, crude, futures, equities, natural, range
- markets_global: today=65, 7d-median=79, 14d-median=79; carrying terms: canada, australia, close, crypto, shanghai, japan, price, cotton, natural, nasdaq, france, china
- sanctions_procurement: today=117, 7d-median=108, 14d-median=102; carrying terms: engineering, integrity, armed, member, sectoral, tiananmen, sanctions, google, herzegovina, award, foreign, effects
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, httperror, quiver, error, client, quantitative, unauthorized, quiverquant, congresstrading
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: masayoshi, exchange, telecom, huang, amancio, julia, ellison, china, spain, india, tadashi, mukesh
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=60, 14d-median=30; carrying terms: blanche, america, collins, robert, schulz, connecticut, services, company, appeals, state, wilmington, savings
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, financial, holdings, david, group, jpmorgan, chase, filer, trust
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, committee, jonathan, joshua, raised, ocasio, congress, cooper, angels, warner, filing, brown
- gdelt_regions: today=6, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=83, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: israel, canada, india, cancer, language, english, domain
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=20; carrying terms: position, ground, belgium, bulgaria, france, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: sometimes, elements, onboard, including, point, exposure, seasonal, reference, however, municipalities, taken, hemorrhagic
- cisa_kev: today=11, 7d-median=15, 14d-median=15; carrying terms: vulnerability, product, authentication, bypass, remediation, vendor, injection, drupal, overflow, privilege, console, tanstack
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=141, 7d-median=126, 14d-median=126; carrying terms: sweden, madagascar, jangmi, turkmenistan, drought, tajikistan, ukraine, finland, austria, china, czech, germany
- usgs_quakes: today=14, 7d-median=16, 14d-median=16; carrying terms: depth, indonesia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, resolves, volume, world, price, peace, ceasefire, coast, ivory, announces, extension, south
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: conversable, marginal, https, class, economist, revolution, links, assorted, policy, economy, times, crisis
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: scholten, ellzey, mejia, clarke, carson, emanuel, graves, representative, torres, beatty, murphy, elfreth
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, market, unavailable, evidence, either, placement, identify, claude, consensus, paper, module, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*