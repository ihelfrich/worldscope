# WORLDSCOPE morning brief — 2026-06-05

## Headline
3199 new items across 27 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (696) · International News + Multilateral Institutions (673) · State-Level News (355) · World leaders & government officials (324) · Chinese Internal News (227) · Local News: St. Louis + Atlanta (205) · U.S. Weather + Severe / Climate Outlooks (148) · Ukraine Theater (total-war monitoring) (130) · Ukrainian Internal News (national + local Kyiv) (65) · Congressional STOCK Act Trades (House + Senate) (52) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### Russian Internal News (state + in-exile) — 696 new of 1104 total
  - (2026-06-05) Почему нам тесно жить в такой большой стране? Читайте новую книгу издательства «Медузы» — «Люди за забором» журналиста Максима Трудолюбова. Это исследование о том, как в России развивался и тра] (ru:…
      «Люди за забором. Частное пространство, власть и собственность в России» — новая книга издательства «Медузы». Ее написал Максим Трудолюбов, журналист, научный сотрудник Института Кеннана и главный редактор издания The Ru…
  - (2026-06-05) «Фонтанка»: Захар Прилепин станет проректором Горного университета в Петербурге. Его возглавляет научный руководитель Путина | LEDE: Писатель и общественный деятель Захар Прилепин займет пос] (ru: «Фо…
      Писатель и общественный деятель Захар Прилепин займет пост проректора Горного университета в Санкт-Петербурге. Он будет курировать идеологическую и воспитательную работу в вузе, пишет «Фонтанка» со ссылкой на источники.
  - (2026-06-05) Politico: США не станут размещать Tomahawk в Германии из-за опасений, что Россия воспримет это как эскалацию | LEDE: Пентагон не будет размещать комплексы Tomahawk в Германии в том числе из ] (ru: Pol…
      Пентагон не будет размещать комплексы Tomahawk в Германии в том числе из опасений, что Россия может воспринять это как эскалацию. Об этом пишет Politico со ссылкой на источники.
  - (2026-06-05) Apple объяснила исчезновение мессенджера «Макс» из App Store санкциями | LEDE: Apple прокомментировала исчезновение российского «национального» мессенджера «Макс» из магазина приложений App ] (ru: App…
      Apple прокомментировала исчезновение российского «национального» мессенджера «Макс» из магазина приложений App Store.
  - (2026-06-05) В Киеве демонтировали памятник Михаилу Булгакову. Он стоял у музея писателя на Андреевском спуске | LEDE: В Киеве 4 июня демонтировали памятник Михаилу Булгакову. Скульптура работы Николая Р] (ru: В К…
      В Киеве 4 июня демонтировали памятник Михаилу Булгакову. Скульптура работы Николая Рапая стояла у музея писателя на Андреевском спуске.
  - (2026-06-05) В Лос-Анджелесе убили 81-летнего актера Джеймса Хэнди, игравшего в «Логане», «Законе и порядке» и «Секретных материалах» | LEDE: В Лос-Анджелесе убит актер Джеймс Хэнди, пишет Los Angeles Ti] (ru: В Л…
      В Лос-Анджелесе убит актер Джеймс Хэнди, пишет Los Angeles Times.

### International News + Multilateral Institutions — 673 new of 888 total
  - (2026-06-05) [Global] The price of passion: World Cup fans face soaring costs
      Football: a force for social cohesion and unity among peoples. But to fully experience that passion and those emotions, World Cup fans making the trip should expect a hefty bill. Airfare prices are skyrocketing during th…
  - (2026-06-05) [Global] In open letter to Putin, Zelensky calls for meeting and ceasefire
      Ukraine's Volodymyr Zelensky proposed a face-to-face meeting with Vladimir Putin in a rare open letter to the Russian leader Thursday, shortly after the Kremlin chief had conceded Moscow needed to strengthen its air defe…
  - (2026-06-05) [Global] War in Ukraine: Zelensky proposes face-to-face meeting with Putin to end years-long war
      Ukrainian President Volodymyr Zelensky proposed a face-to-face meeting with Vladimir Putin in a rare open letter to the Russian leader Thursday, saying he was also ready for a "full ceasefire". "Ukraine proposes ending t…
  - (2026-06-05) [Global] The hidden front: How disinformation is targeting Armenian voters
      One ballot box, two competing battles: In Armenia, voters are heading to the polls to decide the future direction of their country. But beneath the political campaigns lies a far more insidious warfare. Analysts warn tha…
  - (2026-06-05) [Global] Israel continues deadly attacks on Lebanon as Hezbollah rejects ceasefire agreement
      Israeli strikes overnight in the historic south Lebanon city of Tyre killed seven people, a source from the civil defence told AFP on Friday, despite a ceasefire in the Israel-Hezbollah war. A conditional truce was annou…
  - (2026-06-05) [Global] War in Middle East Live: Israeli military continues strikes in southern Lebanon despite ceasefire
      Israel continued its strikes on southern Lebanon on Friday killing seven overnight in the city of Tyre, including in an attack near a hospital. This despite a ceasefire agreement signed between Israel and Lebanon, which…

### State-Level News — 355 new of 762 total
  - (2026-06-04) [Alabama] Governor Ivey Approves Request for Alabama National Guard to Support America 250 Events in Nation’s Capital
      MONTGOMERY – Governor Kay Ivey on Thursday announced she approved a request for the Alabama National Guard (ALNG) to support operations surrounding the America 250 events in Washington, D.C. “One month from today, our na…
  - (2026-06-05) [California] Governor Newsom announces appointments 6.4.2026
      Source
  - (2026-06-04) [California] Governor Newsom announces expansion of the world’s largest civilian aerial firefighting fleet: deployment of fourth C-130 H airtanker and new helitack base
      Source
  - (2026-06-04) [California] California charts smarter path to support farmers and ranchers while maintaining food safety and clean water
      Source
  - (2026-06-04) [California] Trump data confirms that Governor Newsom’s strategies have led to the largest reduction in homelessness nationwide
      Source
  - (2026-06-04) [California] California continues aggressive fight against organized retail theft, recovering nearly $260 million in stolen merchandise
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 227 new of 267 total
  - (2026-06-04) Analysis: Huawei’s Chip Design Vision Faces Reality Check - Caixin Global
      Analysis: Huawei’s Chip Design Vision Faces Reality Check Caixin Global
  - (2026-06-05) “史上最大IPO”，上市时间定了 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Wd3Q1T3lUWGo4U1ZmdlR5Y1JfdHl3Z2NxMVFTZkxzdHBLX2NiaHgtV0FnWnJrcjlTU3BQQndTVXpOZk90WGhlYmlwd2lVT09aMzFEd] (zh:…
      “史上最大IPO”，上市时间定了 财新
  - (2026-06-04) 内地投资者涌入香港银行和券商开户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5IYkVubnJWMWZNa1J6cFl6d3MwTHppOXk1dDk3QXdPSkRCcTdLRm1NcEV6QW9Ub0pPaWF3alp5MmM1MHBZWjRYTkJLenJHUkN4QVF4Y] (zh:…
      内地投资者涌入香港银行和券商开户 财新
  - (2026-06-04) 从国企副总“捞”到副省级 62岁浙江本土高官高兴夫将在江西宜春受审 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE1kQmFXMmptSkZmZ2t0RUIzQU91YmZwZW9Ca2x5NzdKcTN2RlhXZ2hycFN4blcyeFhPQW93SV] (zh:…
      从国企副总“捞”到副省级 62岁浙江本土高官高兴夫将在江西宜春受审 china.caixin.com
  - (2026-06-04) 退休公职人员诉请分割近亿元夫妻财产 法院称涉犯罪移送公安和纪检 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE4xWlpIaW8zd0RxYktFYzZZMVk2VGcyV1c2aVh4Yy02SHR4bHN4ZEFXV3JNQVlOU3hJdFV4NDd2] (zh:…
      退休公职人员诉请分割近亿元夫妻财产 法院称涉犯罪移送公安和纪检 china.caixin.com
  - (2026-06-04) 央行逆回购连续两天操作量为零 是在收紧流动性吗？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5BRlFrNGczZlRkQnlZazEzOWFhMnptNGo2OFNGZnNsMWthM0tfM0hOYVF6NEsxTUk0QWxHNGluUzVnNUlrNWMtU29ERUVMW] (zh:…
      央行逆回购连续两天操作量为零 是在收紧流动性吗？ 财新

### Local News: St. Louis + Atlanta — 205 new of 239 total
  - (2026-06-05) [St. Louis] Taylor Swift returns to country roots for 'Toy Story 5' soundtrack midnight release
      The movie's release date, June 19, is exactly 20 years to the day from the release of Swift's debut single "Tim McGraw."
  - (2026-06-05) [St. Louis] Fatal police shooting under investigation in Eureka neighborhood; no officers injured
      Neighbors reported hearing more than a dozen gunshots before one person was fatally shot by officers in Eureka. Police continued investigating Thursday night.
  - (2026-06-05) [St. Louis] ‘The Super Bowl of marathons’: St. Louis secures 2028 US Olympic Trials
      Elite athletes will pack the Gateway City to compete for six spots on Team USA, an event expected to generate a massive economic boost for St. Louis.
  - (2026-06-05) [St. Louis] 'You should be ashamed of yourself': Surveillance video shows autism therapist kicking 5-year-old child in face
      An Arizona autism therapy center employee was arrested and fired after surveillance footage captured him allegedly kicking a nonverbal 5-year-old boy in the face.
  - (2026-06-05) [St. Louis] Actor James Handy reportedly stabbed to death by girlfriend's son
      Handy was a character actor known for films like “Jumanji,” “Top Gun: Maverick” and “Arachnophobia.”
  - (2026-06-05) [St. Louis] ‘It's like losing a member of your family’: Steve's Hot Dogs owner mourns dog killed in Tower Grove Park attack
      Animal Control is investigating after Steve Ewing says two loose pit bulls attacked his wife and killed the family's 4-year-old dog, Emmi.

### U.S. Weather + Severe / Climate Outlooks — 148 new of 150 total
  - (2026-06-05) [Severe] Flood Warning: Flood Warning issued June 5 at 4:26AM CDT until June 5 at 9:00AM CDT by NWS Topeka KS
      * WHAT...Flooding caused by excessive rainfall is expected. * WHERE...A portion of northeast Kansas, including the following county, Nemaha. * WHEN...Until 900 AM CDT. * IMPACTS...Flooding of rivers, creeks, streams, and…
  - (2026-06-05) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-05) [Severe] Flash Flood Warning: Flash Flood Warning issued June 5 at 4:15AM CDT until June 5 at 7:15AM CDT by NWS Midland/Odessa TX
      FFWMAF The National Weather Service in Midland/Odessa has issued a * Flash Flood Warning for... North Central Pecos County in southwestern Texas... * Until 715 AM CDT. * At 415 AM CDT, Doppler radar and automated rain ga…
  - (2026-06-05) [Severe] Flood Watch: Flood Watch issued June 5 at 4:00AM CDT until June 5 at 7:00AM CDT by NWS Des Moines IA
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of central, north central, northeast, and south central Iowa. * WHEN...Until 7 AM CDT this morning. * IMPACTS...Excessive…
  - (2026-06-05) [Severe] Flood Watch: Flood Watch issued June 5 at 4:00AM CDT until June 5 at 7:00AM CDT by NWS Des Moines IA
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of south central Iowa, including the following counties, Appanoose, Lucas, Monroe and Wayne. * WHEN...Until 7 AM CDT this…
  - (2026-06-05) [Severe] Flood Warning: Flood Warning issued June 5 at 3:59AM CDT until June 5 at 9:00AM CDT by NWS Topeka KS
      * WHAT...Flooding caused by excessive rainfall is expected. * WHERE...A portion of northeast Kansas, including the following county, Brown. * WHEN...Until 900 AM CDT. * IMPACTS...Flooding of rivers, creeks, streams, and…

### Ukraine Theater (total-war monitoring) — 130 new of 320 total
  - (2026-06-05) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-04) [FIRMS] thermal anomaly 45.257, 31.675 (FRP 9.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1047Z, FRP 9.61 MW
  - (2026-06-04) [FIRMS] thermal anomaly 45.356, 30.904 (FRP 2.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1047Z, FRP 2.53 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.573, 32.304 (FRP 7.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 7.91 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.627, 32.621 (FRP 2.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 2.38 MW
  - (2026-06-04) [FIRMS] thermal anomaly 46.578, 32.292 (FRP 3.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-04 1049Z, FRP 3.56 MW

### Ukrainian Internal News (national + local Kyiv) — 65 new of 122 total
  - (2026-06-05) Є хлопці, які надихаються аніме та роблять круті справи – інтерв’ю з азовцем Олександром Лаптієм | LEDE: ] (uk: Є хлопці, які надихаються аніме та роблять круті справи – інтерв’ю з азовцем Оле)
  - (2026-06-05) В Румунії евакуювали порт через дрон, який вибухнув біля нафтового термінала | LEDE: Порт Констанци в Румунії було терміново евакуйовано після того, як там стався вибух морського безпілотника.] (uk: В…
      Порт Констанци в Румунії було терміново евакуйовано після того, як там стався вибух морського безпілотника.
  - (2026-06-05) Дощі і грози – прогноз погоди на вихідні | LEDE: На вихідних в Україні очікується нестійка погода, дощі та грози. Температура: вдень до +29°.] (uk: Дощі і грози – прогноз погоди на вихідні)
      На вихідних в Україні очікується нестійка погода, дощі та грози. Температура: вдень до +29°.
  - (2026-06-05) Колишня суддя з Бердянська отримала 15 років за роботу на ФСБ і передачу даних про бійців "Азову" | LEDE: Колишню суддю Бердянського районного суду Запорізької області Ларису Богомолову засудил] (uk:…
      Колишню суддю Бердянського районного суду Запорізької області Ларису Богомолову засудили до 15 років позбавлення волі з конфіскацією майна за державну зраду.
  - (2026-06-05) Керівник Луцького ТЦК попався на хабарі за документ про непридатність до служби – джерело | LEDE: Державне бюро розслідувань затримало виконувача обов'язків начальника Луцького міського ТЦК на ] (uk:…
      Державне бюро розслідувань затримало виконувача обов'язків начальника Луцького міського ТЦК на хабарі у 7 тисяч доларів за оформлення документу про непридатність до військової служби.
  - (2026-06-05) Більшість німців незадоволені роботою Мерца і уряду | LEDE: Більшість німців продовжують висловлювати невдоволення роботою уряду і канцлера Фрідріха Мерца, свідчать дані опитування, проведеного] (uk:…
      Більшість німців продовжують висловлювати невдоволення роботою уряду і канцлера Фрідріха Мерца, свідчать дані опитування, проведеного німецьким телеканалом ZDF.

### Congressional STOCK Act Trades (House + Senate) — 52 new of 52 total
  - (2026-06-01) [House] Tim Walberg (R): Sale FSSL ($15,001 - $50,000) (excess -1.2% vs SPY)
      Member: Tim Walberg (R, house). BioGuide: W000798. Asset: FSSL (ST). Type: Sale. Amount range: $15,001 - $50,000. Transaction date: 2026-06-01. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: -1.17%.
  - (2026-05-27) [House] Josh Gottheimer (D): Sale ABT ($1,001 - $15,000) (excess +5.1% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: ABT (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-05-27. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: +5.07%…
  - (2026-05-22) [House] Josh Gottheimer (D): Purchase LITE ($1,001 - $15,000) (excess -1.7% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: LITE (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-22. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: -…
  - (2026-05-22) [House] Josh Gottheimer (D): Sale INTU ($1,001 - $15,000) (excess -7.1% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: INTU (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-05-22. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: -7.15…
  - (2026-05-21) [House] Josh Gottheimer (D): Purchase MU ($1,001 - $15,000) (excess +28.8% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: MU (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-21. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: +28…
  - (2026-05-19) [House] Josh Gottheimer (D): Purchase MSFT ($500,001 - $1,000,000) (excess -0.6% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: MSFT (OP). Type: Purchase. Amount range: $500,001 - $1,000,000. Transaction date: 2026-05-19. Disclosure date: 2026-06-03. Excess return vs SPY since disclosu…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-05) [Lafargue Rell Q. Jr.] Form 4 (Reporting)
      filed 2026-06-05 01:59 UTC · role: Reporting — Filed: 2026-06-04 AccNo: 0001865887-26-000003 Size: 6 KB
  - (2026-06-05) [Reservoir Media, Inc.] Form 4 (Issuer)
      filed 2026-06-05 01:59 UTC · role: Issuer — Filed: 2026-06-04 AccNo: 0001865887-26-000003 Size: 6 KB
  - (2026-06-05) [Heindlmeyer James A] Form 4 (Reporting)
      filed 2026-06-05 01:57 UTC · role: Reporting — Filed: 2026-06-04 AccNo: 0001864346-26-000004 Size: 6 KB
  - (2026-06-05) [Reservoir Media, Inc.] Form 4 (Issuer)
      filed 2026-06-05 01:57 UTC · role: Issuer — Filed: 2026-06-04 AccNo: 0001864346-26-000004 Size: 6 KB
  - (2026-06-05) [Wulf John William] Form 4 (Reporting)
      filed 2026-06-05 01:57 UTC · role: Reporting — Filed: 2026-06-04 AccNo: 0001628280-26-041025 Size: 5 KB
  - (2026-06-05) [agilon health, inc.] Form 4 (Issuer)
      filed 2026-06-05 01:57 UTC · role: Issuer — Filed: 2026-06-04 AccNo: 0001628280-26-041025 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-05) [India] BHEL shares jump over 2 pc on bagging Rs 21 , 000 crore power project order
      domain: prokerala.com · language: English · tone:
  - (2026-06-05) [United States] Platner Denies Allegations From Ex - Girlfriends
      domain: kprcradio.iheart.com · language: English · tone:
  - (2026-06-05) [United States] Selena Gomez Unveils Bold Red Hair Transformation While Filming in London
      domain: 975wabd.com · language: English · tone:
  - (2026-06-05) [United Kingdom] Carnage as Tesla ploughs into house in Wigan as 999 crews scrambled | united kingdom | News
      domain: express.co.uk · language: English · tone:
  - (2026-06-05) [India] BJP : INDIA alliance exists only on paper and TV screens
      domain: siasat.com · language: English · tone:
  - (2026-06-05) [United States] As Ebola spreads in Congo , a radio station tries to stop health misinformation
      domain: news4jax.com · language: English · tone:

### State Legislative Action — 36 new of 127 total
  - (2026-06-05) [Alaska SB 275] An Act relating to natural gas and natural gas projects; relating to the Alaska Gasline Development Corporation; relating to the powers and duties of the Legislative Budget and Audit C…
      An Act relating to natural gas and natural gas projects; relating to the Alaska Gasline Development Corporation; relating to the powers and duties of the Legislative Budget and Audit Committee; relating to the value of c…
  - (2026-06-05) [Alaska HJR 10] Proposing amendments to the Constitution of the State of Alaska relating to the Alaska permanent fund and to appropriations from the Alaska permanent fund.
      Proposing amendments to the Constitution of the State of Alaska relating to the Alaska permanent fund and to appropriations from the Alaska permanent fund.
  - (2026-06-05) [Alaska HCR 2] Proposing an amendment to the Uniform Rules of the Alaska State Legislature relating to voting and abstention from voting.
      Proposing an amendment to the Uniform Rules of the Alaska State Legislature relating to voting and abstention from voting.
  - (2026-06-05) [Alaska HB 152] An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on indiv…
      An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on individuals under the Alaska Net Income T…
  - (2026-06-05) [Alaska SB 23] An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
      An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
  - (2026-06-05) [Alaska SB 164] An Act eliminating deductions for the remittance of the motor fuel tax, tobacco taxes, and tire fees; relating to discounts on cigarette stamps; and providing for an effective date.
      An Act eliminating deductions for the remittance of the motor fuel tax, tobacco taxes, and tire fees; relating to discounts on cigarette stamps; and providing for an effective date.

### Paper Trading Scorecard — 31 new of 152 total
  - (2026-06-05) [Polymarket] Will Flavio Cobolli win the 2026 Men's French Open?
      The 2026 French Open is scheduled for May 18 - June 7, 2026. This market will resolve to the player that wins the 2026 French Open Men’s Singles Tournament. If at any point it becomes impossible for a listed player to wi…
  - (2026-06-05) [Polymarket] Will Ethereum reach $2,100 in June?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for ETH/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…
  - (2026-06-05) [Polymarket] Will Harry Kane be the top goalscorer at the 2026 FIFA World Cup?
      This market will resolve to the player who scores the most goals through all main tournament rounds of the 2026 FIFA World Cup competition. In the event of a tie, this market will resolve according to the official leader…
  - (2026-06-05) [Polymarket] Will the Fed decrease interest rates by 50+ bps after the July 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-06-05) [Polymarket] Will Russia enter Zaporizhia by June 30?
      This market will resolve to “Yes” if, according to the ISW map, Russia captures any territory of the city of Zaporizhia (https://maps.app.goo.gl/Gezpp2b4SDnefJ5s9) by June 30, 2026, at 11:59 PM ET. Territory will be cons…
  - (2026-06-05) [Polymarket] Will Türkiye win Group D in the 2026 FIFA World Cup?
      This market will resolve according to the team that wins Group D in the 2026 FIFA World Cup group stage, scheduled for June 11-27, 2026. If multiple teams tie as group winners, this market will resolve according to the o…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 26 new of 35 total
  - (2026-06-05) Promoting Advanced Artificial Intelligence Innovation and Security
  - (2026-06-05) Proposed Waiver and Extension of the Project Period With Funding-Elementary and Secondary Education Act of 1965, as Amended, Title VI, Part B, Native Hawaiian Education
      The Secretary proposes to waive the requirements in the Education Department General Administrative Regulations (EDGAR) that generally prohibit project period extensions involving the obligation of additional Federal fun…
  - (2026-06-05) Exceptions From Foreign Ownership, Control, or Domination
      The U.S. Nuclear Regulatory Commission (NRC) is confirming the effective date of July 7, 2026, for the direct final rule that was published in the Federal Register on April 23, 2026. This direct final rule amended the NR…
  - (2026-06-05) Extending the Reporting Deadline Under the Greenhouse Gas Reporting Rule for 2025; Correction
      The Environmental Protection Agency (EPA) is correcting the preamble of a final rule published in the Federal Register on February 27, 2026. The final rule extended the reporting deadline under the Greenhouse Gas Reporti…
  - (2026-06-05) Reforming the High-Cost Program for an All-IP Future, Connect America Fund: A National Broadband Plan for Our Future High-Cost Universal Support
      In this document, the Federal Communications Commission (FCC or Commission) adopted a Notice of Proposed Rulemaking (NPRM) that kicks off a process to examine how the Commission can make some of its high-cost mechanisms…
  - (2026-06-05) Trump Accounts; Hearing
      This document provides a notice of public hearing on the notice of proposed rulemaking (REG-117270-25) published in the Federal Register on March 9, 2026. The proposed regulations provide guidance on making an election t…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-06-05) [Russia oil sanctions perimeter · themes] Ескалація deep strike : Україна розширила географію та відстань ударів по РФ
      for-ua.com · Ukrainian · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] RBI projects hike in FY27 Consumer Price Index inflation at 5 . 1 % amid elevated global crude prices
      shanghainews.net · English · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] Alertă în Portul Constanța : zona a fost evacuată după ce o dronă marină cu timer a explodat
      bihon.ro · Romanian · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] İsrail , İran Savaşı nda Azerbaycana Gizli Asker Gönderdi
      haberaktuel.com · Turkish · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] Malestar entre la militancia socialista de Almería por los resultados del 17M
      ideal.es · Spanish · tone NA
  - (2026-06-05) [Russia oil sanctions perimeter · themes] 15 दिन में बाल झड़ना होगा कम , ग्रोथ दिखेगी ज्यादा ! घर पर बनाएं ये हेयर टोनर
      livehindustan.com · Hindi · tone NA

### Court opinions of consequence (federal & state) — 21 new of 60 total
  - (2026-06-04) U.S. Court of Appeals, 9th Cir.: Welsh v. Loudbear
  - (2026-06-04) U.S. Court of Appeals, 9th Cir.: Coffey v. Fast Easy Offer, LLC
  - (2026-06-04) U.S. Court of Appeals, 9th Cir.: People of the State of Cal. v. Fmcsa
  - (2026-06-04) U.S. Court of Appeals, 7th Cir.: United States v. Jesse Mickles
  - (2026-06-04) Arkansas Supreme Court: In RE ARKANSAS SUPREME COURT COMMITTEE ON CIVIL PRACTICE - RECOMMENDATION TO AMEND RULE 6(d) OF THE ARKANSAS RULES OF CIVIL PROCEDURE
  - (2026-06-04) Arkansas Supreme Court: In RE ARKANSAS SUPREME COURT COMMITTEE ON CIVIL PRACTICE - RECOMMENDATIONS TO ADOPT RULE 11(d); TO AMEND RULE 26(b); 26(c)(1) AND (2); 26(f)(1) AND (2); 26(f)1) AND (2); AND TO…

### Government Action: Sanctions + Procurement + Foreign Agents — 17 new of 116 total
  - (2026-06-04) [OFAC] Cuba Designations; Issuance of Cuba-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Cuba Designations; Issuance of Cuba-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-06-04) [OFAC] 1258 - Office of Foreign Assets Control (.gov)
      1258 Office of Foreign Assets Control (.gov)
  - (2026-06-05) [OFAC] Test - for publishing issue - Office of Foreign Assets Control (.gov)
      Test - for publishing issue Office of Foreign Assets Control (.gov)
  - (2026-06-05) [USASpending] $35,002,991,770 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-06-05) [USASpending] $1,594,955,955 → NORTHROP GRUMMAN SYSTEMS CORPORATION: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUI
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUILDS UPON THE SUCCESS OF COMMERCIAL ORBITAL TRANSPORTATION SERVICES SPACE ACT AGREEMENT DEVELO…
  - (2026-06-05) [USASpending] $1,420,888,745 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-05) [China] Strategic Investment Signals Growing Confidence in India Drone Economy with Investment in Innquete
      shanghainews.net · English
  - (2026-06-05) [China] RBI projects hike in FY27 Consumer Price Index inflation at 5 . 1 % amid elevated global crude prices
      shanghainews.net · English
  - (2026-06-05) [China] Momento tenerissimo tra autista e passeggero non udenti
      italian.cri.cn · English
  - (2026-06-05) [China] Alla scoperta del fascino di liuli
      italian.cri.cn · English
  - (2026-06-05) [China] Xi Jinping to pay state visit to North Korea
      shanghainews.net · English
  - (2026-06-05) [China] Experts see RBI rate pause as move to protect economy , currency amid rising global risks
      shanghainews.net · English

### GDACS — global disaster alerts — 12 new of 141 total
  - (2026-06-02) [Green] Flood in Honduras
      Flood · Green alert · Honduras · Magnitude 0
  - (2026-06-02) [Green] Flood in Honduras
      Flood · Green alert · Honduras · Magnitude 0
  - (2026-06-02) [Green] Flood in Honduras
      Flood · Green alert · Honduras · Magnitude 0
  - (2026-06-03) [Green] Flood in South Africa
      Flood · Green alert · South Africa · Magnitude 0
  - (2026-06-03) [Green] Flood in South Africa
      Flood · Green alert · South Africa · Magnitude 0
  - (2026-06-03) [Green] Flood in South Africa
      Flood · Green alert · South Africa · Magnitude 0

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-06-04) M 5.2 - 77 km S of Gorontalo, Indonesia
      M5.2 · 77 km S of Gorontalo, Indonesia · depth 128.812 km
  - (2026-06-05) M 5.1 - 103 km NNW of Villa General Roca, Argentina
      M5.1 · 103 km NNW of Villa General Roca, Argentina · depth 135.979 km
  - (2026-06-05) M 4.9 - 126 km SE of Vilyuchinsk, Russia
      M4.9 · 126 km SE of Vilyuchinsk, Russia · depth 35 km
  - (2026-06-04) M 4.9 - 70 km SW of Modisi, Indonesia
      M4.9 · 70 km SW of Modisi, Indonesia · depth 99.482 km
  - (2026-06-04) M 4.9 - 57 km NNW of Huocheng, China
      M4.9 · 57 km NNW of Huocheng, China · depth 10 km
  - (2026-06-04) M 4.8 - 32 km WSW of El Tocuyo, Venezuela
      M4.8 · 32 km WSW of El Tocuyo, Venezuela · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 40 total
  - (2026-06-05) MOVER ▼ Michael Dell — $239.60B ($-10.84B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-06-05) MOVER ▲ Larry Page — $303.32B (+$10.47B since yesterday)
      United States · Technology · source: Google
  - (2026-06-05) MOVER ▲ Sergey Brin — $279.74B (+$9.63B since yesterday)
      United States · Technology · source: Google
  - (2026-06-05) MOVER ▲ Larry Ellison — $286.89B (+$6.38B since yesterday)
      United States · Technology · source: Oracle
  - (2026-06-05) MOVER ▼ Elon Musk — $822.26B ($-3.76B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-06-05) MOVER ▲ Jensen Huang — $188.84B (+$3.54B since yesterday)
      United States · Technology · source: Semiconductors

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-06-05) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $3,531,210 · resolves 2026-07-20
  - (2026-06-05) Will Hunter Biden win the 2028 Democratic presidential nomination?
      yes price: 3% · 24h volume: $2,587,579 · resolves 2028-11-07
  - (2026-06-05) Knicks vs. Spurs
      yes price: 34% · 24h volume: $1,973,324 · resolves 2026-06-06
  - (2026-06-05) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,265,186 · resolves 2026-07-20
  - (2026-06-05) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,098,595 · resolves 2026-07-20
  - (2026-06-05) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $904,684 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-05) [Marginal Revolution] Western hemisphere fact of the day
      Overall, the Western Hemisphere now produces more oil than the Middle East did before the crisis. Canada is the world’s fourth-largest oil producer. Brazil produces four times as much oil as Venezuela; and in Guyana, whe…
  - (2026-06-05) [Marginal Revolution] Rubber rationing in World War II
      When during the meetings the Americans offered that at most they could convert 15 percent of U.S. auto plants to military production, Beaverbrook replies that 100 percent of British automobile factories had been converte…
  - (2026-06-04) [Marginal Revolution] My twenty-minute AI talk for the Swedish company Sana
      The post My twenty-minute AI talk for the Swedish company Sana appeared first on Marginal REVOLUTION.
  - (2026-06-04) [Conversable Economist] Is GDP Failing to Capture AI?
      Gross domestic product measures the economic transaction in an economy, according to quantities bought and sold and market prices. But does this method work for AI? Anton Korinek and Patrick McKelvey work through the que…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: program, guard, certain, address, waters, vessels, action, events, proposed, public, personnel, enforcement
- state_bills: today=127, 7d-median=155, 14d-median=148; carrying terms: impact, policy, declare, license, years, violation, removal, facilities, investment, relating, permanent, purchase
- state_news: today=762, 7d-median=722, 14d-median=722; carrying terms: policy, pressherald, sports, years, universities, senate, century, released, trustees, saturday, services, error
- local_news: today=239, 7d-median=239, 14d-median=247; carrying terms: restaurants, years, students, weekend, victim, according, local, center, along, runoff, atlantamagazine, school
- foreign_news: today=888, 7d-median=861, 14d-median=864; carrying terms: impact, damaging, policy, players, newsroom, provincial, republic, flames, passengers, publication, taiwan, sparks
- chinese_internal: today=267, 7d-median=270, 14d-median=270; carrying terms: lxtfa, caixin, property, cbmib, china, target, cbmiyefvx, color, cbmidefvx, people, https, cbmizefvx
- russian_internal: today=1104, 7d-median=964, 14d-median=1036; carrying terms: press, title, bloomberg, found, group, gazeta, associated, garros, euroclear, https, times, roland
- ukrainian_internal: today=122, 7d-median=121, 14d-median=122; carrying terms: error, hmarochos, hromadske, httperror, vechirniy, https, ukrinform, economic, president, censor, babel, found
- ukraine_theater: today=320, 7d-median=279, 14d-median=299; carrying terms: kynjzknu, cepsawx, setrruphvwi, mnetaeng, wwvuz, cuxpendda, clperwlpsm, years, operations, nhogtfagrqd, wgvqtdljtf, pisjnfs
- paper_bets: today=152, 7d-median=147, 14d-median=144; carrying terms: jones, lifetime, north, energy, signed, pennsylvania, nuclear, predictit, cruise, netanyahu, results, office
- weather: today=150, 7d-median=100, 14d-median=110; carrying terms: drier, little, service, localized, disregard, deeper, afdhgx, coastal, thursday, capsize, flooding, issued
- macro: today=21, 7d-median=10, 14d-median=0; carrying terms: latest, recession, unemployment, indicator, labor, treasury, funds, spread, unrate, rates, effective, money
- markets: today=21, 7d-median=21, 14d-median=0; carrying terms: crude, bitcoin, commodities, large, russell, credit, close, crypto, range, nasdaq, natural, agriculture
- markets_global: today=66, 7d-median=79, 14d-median=79; carrying terms: australia, lumber, commodity, crypto, close, france, copper, sugar, germany, japan, cotton, index
- sanctions_procurement: today=116, 7d-median=108, 14d-median=102; carrying terms: belarus, policy, energy, schools, republic, middle, weapons, attacks, libya, operations, office, illegal
- congressional_trades: today=52, 7d-median=40, 14d-median=20; carrying terms: acquired, jacobs, moreno, googl, disclosure, return, tcnnf, member, excess, compensation, asset, since
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: google, tokyo, technology, retail, bezos, walton, oracle, spain, devasini, nasdaq, fashion, giancarlo
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=60, 14d-median=30; carrying terms: blanche, america, smith, castillo, ortiz, gregory, andrew, schulz, wilmington, society, state, connecticut
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, holdings, technology, james
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: warner, cooper, jonathan, committee, booker, ocasio, disbursements, house, alexandria, receipts, sherrod, james
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=25, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: canada, kingdom, india, language, cancer, english, domain, israel
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=26, 14d-median=15; carrying terms: position, ground, belgium, canada, kingdom, bulgaria, germany, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: variant, jinka, press, isolates, north, multi, although, collaboration, illness, discontinued, mediterranean, developments
- cisa_kev: today=10, 7d-median=15, 14d-median=15; carrying terms: product, authentication, vendor, bypass, drupal, overflow, vulnerability, injection, remediation, embedded, cpanel, plugin
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=141, 7d-median=126, 14d-median=126; carrying terms: impact, democratic, belarus, drought, storm, angola, malaysia, germany, sweden, czech, republic, tropical
- usgs_quakes: today=11, 7d-median=14, 14d-median=14; carrying terms: depth, indonesia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, world, volume, price, peace, resolves, ceasefire, ivory, coast, announces, extension, turkiye
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: conversable, revolution, economist, https, marginal, class, policy, economy, times, crisis, economic, company
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: composite, press, mullin, tammy, ogles, bennet, cline, booker, cuellar, jahana, balderson, energy
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, placed, decision, markets, either, today, placement, claude, module, unavailable, paper, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*