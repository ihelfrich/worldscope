# WORLDSCOPE morning brief — 2026-09-21

## Headline
3327 new items across 24 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (860) · International News + Multilateral Institutions (799) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (276) · Chinese Internal News (240) · State-Level News (160) · Local News: St. Louis + Atlanta (149) · U.S. Weather + Severe / Climate Outlooks (116) · State Legislative Action (80) · GDELT GKG — themes / entities / watch areas (50) · Ukrainian Internal News (national + local Kyiv) (41) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 860 new of 904 total
  - (2026-09-21) «Единая Россия» проиграла «Новым людям» в большинстве центров антивоенной эмиграции | LEDE: Партия «Единая Россия» не заняла первое место на большинстве зарубежных участков в городах, которы] (ru: «Ед…
      Партия «Единая Россия» не заняла первое место на большинстве зарубежных участков в городах, которые после начала полномасштабной войны стали крупными центрами российской эмиграции. К такому выводу пришло «Агентство», про…
  - (2026-09-21) Четыре года назад в России объявили мобилизацию — и именно тогда сотни тысяч россиян решили уехать из страны. Как за это время сложилась ваша жизнь? Расскажите «Медузе» | LEDE: Конец сентябр] (ru: Чет…
      Конец сентября 2022 года стал для тысяч россиян началом новой жизни — за пределами России. После объявления мобилизации люди экстренно уезжали из страны: кто-то тратил огромные деньги на авиабилеты, кто-то несколько суто…
  - (2026-09-21) Трамп заявил, что Россия «потеряла контроль» над своей нефтеперерабатывающей отраслью | LEDE: Президент США Дональд Трамп заявил, что Россия не контролирует свою нефтеперерабатывающую отрасл] (ru: Тра…
      Президент США Дональд Трамп заявил, что Россия не контролирует свою нефтеперерабатывающую отрасль из-за постоянных украинских атак на заводы.
  - (2026-09-21) Путин передал во временное управление активы еще одной иностранной компании — производителя пластиковой упаковки Aptar | LEDE: Владимир Путин подписал указ, который передает во временное упр] (ru: Пут…
      Владимир Путин подписал указ, который передает во временное управление 100% компании, принадлежащих французской Aptar Europe Holding. «Аптар Владимир» владеет российским заводом по производству пластиковой упаковки.
  - (2026-09-21) «От демократии в России осталась лишь видимость». Евросоюз пообещал новые санкции после выборов в Госдуму | LEDE: Евросоюз готовит новые санкции после прошедших в России выборов в Госдуму. П] (ru: «От…
      Евросоюз готовит новые санкции после прошедших в России выборов в Госдуму. Под ограничения попадут организаторы голосования и кандидаты на оккупированных территориях Украины, а также те, кого Европа считает причастными к…
  - (2026-09-21) Новый владелец «Ашана» и Leroy Merlin потребовал сохранить магазины и пообещал обеспечить защиту от атак беспилотников | LEDE: Фирма «Л.Е.В. Менеджмент», которая получила во временное управл] (ru: Нов…
      Фирма «Л.Е.В. Менеджмент», которая получила во временное управление российские активы «Ашана» и «Лемана ПРО» (бывшая Leroy Merlin), обратилась к руководству этих компаний с просьбой сохранить торговую сеть и персонал.

### International News + Multilateral Institutions — 799 new of 975 total
  - (2026-09-21) [Global] What are my rights if my flight is cancelled or delayed?
      Flights are affected again owing to air traffic control problems, so what are your rights if you're affected?
  - (2026-09-21) [Global] Tories pledge to bring back tax-free shopping for tourists
      The party says scrapping the scheme in 2021 left the UK less competitive than European destinations.
  - (2026-09-21) [Global] UK should 'team up' with Canada in new Europe alliance, Canadian minister tells BBC
      It comes after European Commission President proposed "opening the door" for Canada to become an associate member of the EU.
  - (2026-09-21) [Global] US and China discuss AI safety plan ahead of Trump-Xi summit
      Top US and Chinese officials held talks in New York on Sunday ahead of a Trump-Xi summit this week.
  - (2026-09-21) [Global] Will you get £13,000 a year when you stop working? Here's how to check
      How to find out how much state pension you're likely to receive - and what you can do about it now.
  - (2026-09-21) [Global] Nvidia boss rejects AI extinction fears as 'doomsday narratives'
      Jensen Huang's comments come after warnings from AI researchers that the technology could lead to human extinction.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 276 new of 502 total
  - (2026-09-21) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-20) [FIRMS] thermal anomaly 45.531, 34.720 (FRP 3.34 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-20 1026Z, FRP 3.34 MW
  - (2026-09-20) [FIRMS] thermal anomaly 45.751, 34.422 (FRP 6.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-20 1026Z, FRP 6.69 MW
  - (2026-09-20) [FIRMS] thermal anomaly 45.259, 31.674 (FRP 6.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-20 1026Z, FRP 6.9 MW
  - (2026-09-20) [FIRMS] thermal anomaly 44.205, 27.173 (FRP 2.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-20 1026Z, FRP 2.39 MW
  - (2026-09-20) [FIRMS] thermal anomaly 44.208, 27.172 (FRP 1.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-20 1026Z, FRP 1.51 MW

### Chinese Internal News — 240 new of 265 total
  - (2026-09-20) 铁人三项男子运动员张玺瑞夺得第20届亚运会中国代表团首枚奖牌 - sports.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1HM2Q0X3NrckVud2ZIaFJGU0JnUGF0cUJwZzZITzJyR3RCYkcxMElnclF6NGEyVXgtVDVUS] (zh:…
      铁人三项男子运动员张玺瑞夺得第20届亚运会中国代表团首枚奖牌 sports.people.com.cn
  - (2026-09-21) 小区排水防水不达标 安全隐患多（身边事） - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9mME8zaThJR3kydWF3UTlBbVExajlRUWZiUXRHZUlxcjFueUlqeGZqS2xMUmpubG5vMkFta1VFdkwxX1pEbUpfZGlnNEZRVjdK] (zh:…
      小区排水防水不达标 安全隐患多（身边事） 人民网
  - (2026-09-21) 闲置公租房完成盘活（反馈） - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE53bEpYZlZnRG51ejdfSUc4aktXTUNNeHF5ZDZ6NDRsTVdyUDQ2ZVNEelgzZDQ3SUpyT0s4cFJRM0FQVmFEZEJ1ajN4V3NKUG9URjQ2d1p] (zh:…
      闲置公租房完成盘活（反馈） 人民网
  - (2026-09-21) 江苏兴化：秋收好“丰” 景 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1RWUlFSzdtS2lueWt2NWx3dGFlb2RzaGpSRmFnT2JlMndveXFiWUsxTTZFaW5GakR5alFMS1NVVmdzckdpbTNnRkRBV2ZlcS1uam1qOD] (zh:…
      江苏兴化：秋收好“丰” 景 人民图片
  - (2026-09-21) 江苏南通：政务服务“提档升级” 群众办事“触手可及” - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1xQURZQ0NCeVphOVF2Z1hWVFlkSURTUkluVk1iSEhWaGZUVlpiR0lNU2JBT2FhU3JBRUhfVzM3b0ZuR0dnSXI2M3B3W] (zh:…
      江苏南通：政务服务“提档升级” 群众办事“触手可及” 人民图片
  - (2026-09-20) 江苏泗洪： 铁骑飞驰燃动洪泽湖 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFByXzhfRmNLcUhabUg1ME9BZUF5cS1GbFFwRElScDlHY20xQ2FZdkpjRmh6Zmd2T3ctQUZsczlhaDl1U1hKdHhoU1lzRFEyNmZBTEZU] (zh:…
      江苏泗洪： 铁骑飞驰燃动洪泽湖 人民图片

### State-Level News — 160 new of 281 total
  - (2026-09-20) [Alaska] Employ Older Workers Week 2026
      WHEREAS, older workers play an increasingly important role in maintaining Alaska’s economy and leadership in the global marketplace, by adding depth in perspective, social networks, and talent; and WHEREAS, seniors repre…
  - (2026-09-20) [Alaska] Forensic Science Week 2026
      WHEREAS, quality forensic science plays an essential role in the criminal justice system by providing impartial, scientific information that assists in solving crimes, from exonerating the innocent to identifying the gui…
  - (2026-09-21) [California] Newsom signs voting laws to counter Trump’s feared interference
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/091026_Newsom-Kids-Tech_AHK_CM_26.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-09-21) [California] Independent voters can be heard in California. The top-two primary is worth defending
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/03/030524-SF-Primary-Voting-JY-07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-09-21) [California] Anti-abortion advocates say it’s possible to ‘reverse’ an abortion. California wants them to stop
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/031025-Abortion-Pills-GETTY-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-09-21) [California] Newsom again vetoes bill to allow undocumented college students to work on campus
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2022/06/051723-UCLARALLY-PU-CM-02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…

### Local News: St. Louis + Atlanta — 149 new of 207 total
  - (2026-09-21) [St. Louis] As free book access shrinks in Missouri, St. Louis’ Book Lady hopes to expand her literacy mission to fill the gaps
      Linda Mitchell doesn’t judge a book by its cover. But after more than 1,000 home visits, St. Louis’ “Book Lady” learned that a family’s bookshelves can tell quite a story. During her years as a parent educator with St. L…
  - (2026-09-21) [St. Louis] Where to eat, play, and stay in Nashville’s Gulch neighborhood
      EAT Start your day at Killebrew Coffee, conveniently located in the Thompson Nashville hotel. It offers a traditional coffee menu and some creative concoctions, including a lavender haze latte. For a heartier breakfast,…
  - (2026-09-21) [St. Louis] Judge denies bond for Lilly Belfield, driver accused of killing WashU student
      A 22-year-old accused in the drunk driving crash that killed a WashU grad student was denied bond on Friday, during her first hearing in court. Associate Circuit Judge Brooke Hurst called the case “an extremely sad situa…
  - (2026-09-21) [St. Louis] As Ferguson reconsiders $1.5B data center tax break, nonprofit donation faces scrutiny
      This Tuesday, the Ferguson City Council will revisit a plan to put a data center on the old Emerson campus, a development spearheaded by lawyer-turned-real estate mogul Jim Onder. The council narrowly rejected the $1.5 b…
  - (2026-09-21) [St. Louis] How Frizz Fest has become a launching pad for local Black-owned businesses
      Since Frizz Fest first began nearly a decade ago, the St. Louis festival that celebrates the joy, culture, creativity, and entrepreneurship in the local Black community has grown into an essential event, with live music,…
  - (2026-09-21) [St. Louis] WashU professor G’Ra Asim’s ‘99 Problems’ explores race, rock and relationships

### U.S. Weather + Severe / Climate Outlooks — 116 new of 117 total
  - (2026-09-21) [Moderate] Lake Wind Advisory: Lake Wind Advisory issued September 21 at 6:28AM PDT until September 22 at 5:00AM PDT by NWS Hanford CA
      * WHAT...West winds 10 to 20 mph with gusts up to 35 mph. * WHERE...West Side Mountains north of 198, including San Luis Reservoir. * WHEN...Until 5 AM PDT Tuesday. * IMPACTS...Strong winds and rough waves on area lakes…
  - (2026-09-21) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued September 21 at 9:26AM EDT until September 22 at 11:00PM EDT by NWS Cleveland OH
      * WHAT...High risk of rip currents. * WHERE...Northern Erie County. * WHEN...Through Tuesday evening. * IMPACTS...Wind and wave action will cause currents on the lakeshore. Swimmers should not enter the water. Currents c…
  - (2026-09-21) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued September 21 at 9:26AM EDT until September 23 at 10:00PM EDT by NWS Cleveland OH
      * WHAT...High risk of rip currents. * WHERE...Lake and Ashtabula Lakeshore Counties. * WHEN...Through Wednesday evening. * IMPACTS...Wind and wave action will cause currents on the lakeshore. Swimmers should not enter th…
  - (2026-09-21) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued September 21 at 9:26AM EDT until September 23 at 10:00PM EDT by NWS Cleveland OH
      * WHAT...High risk of rip currents. * WHERE...Lucas, Ottawa, Erie, Lorain and Cuyahoga Counties. * WHEN...Through Wednesday evening. * IMPACTS...Wind and wave action will cause currents on the lakeshore. Swimmers should…
  - (2026-09-21) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-21) [Moderate] Special Weather Statement: Special Weather Statement issued September 21 at 8:19AM CDT by NWS Shreveport LA
      At 819 AM CDT, Doppler radar was tracking a line of strong thunderstorms extending from 6 miles northeast of Manchester to 9 miles southwest of Hagansport, or extending from 21 miles north of Clarksville to 9 miles south…

### State Legislative Action — 80 new of 81 total
  - (2026-09-21) [California AB 2674] State Air Resources Board: internet website: methane emissions data.
      The California Global Warming Solutions Act of 2006 designates the State Air Resources Board as the state agency charged with monitoring and regulating sources of emissions of greenhouse gases. Existing law requires the…
  - (2026-09-21) [California AB 2312] State property: tidelands transfer: City of Martinez: leases.
      Existing law grants to the City of Martinez all right, title, and interest of the state to 4 specified parcels of land in the County of Contra Costa, to be held in trust by the city, as trustee, for the benefit of all th…
  - (2026-09-21) [California AB 2594] Voluntary employees' beneficiary association pilot program.
      Existing law, the Knox-Keene Health Care Service Plan Act of 1975, provides for the licensure and regulation of health care service plans by the Department of Managed Health Care. Existing law authorizes the Director of…
  - (2026-09-21) [California SB 1360] Elections: translation of election materials.
      The federal Voting Rights Act of 1965 requires a state or political subdivision in which more than 5% of voting-age citizens, or more than 10,000 voting-age citizens, are members of a single language minority and limited…
  - (2026-09-21) [California AB 1235] California State University: skilled and trained workforce requirement.
      Existing law establishes requirements that apply when a public entity is required by statute or regulation to obtain an enforceable commitment that a bidder, contractor, or other entity will use a skilled and trained wor…
  - (2026-09-21) [California AB 2631] Criminal procedure: prohibited violations.
      Existing law authorizes a court to issue various orders relating to criminal investigations, including the interception of wire or electronic communications, the installation and use of a pen register or trap and trace d…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-09-21) [Russia oil sanctions perimeter · themes] OpenAI还没 「 赚钱 」， 软银却得还债
      163.com · Chinese · tone NA
  - (2026-09-21) [Russia oil sanctions perimeter · themes] Blickpunkt Zins : Energie bleibt teuer . Was bedeutet das für die Zinsen ?
      finanzen.net · German · tone NA
  - (2026-09-21) [Russia oil sanctions perimeter · themes] Mbi 86 mijë jemenas të zhvendosur kanë mbërritur në Taiz që nga fillimi i përshkallëzimit
      24-ore.com · Albanian · tone NA
  - (2026-09-21) [Russia oil sanctions perimeter · themes] Стеклопластик и бурение : Калауи и Акчулаков пообещали Атырау современный септик
      azh.kz · Russian · tone NA
  - (2026-09-21) [Russia oil sanctions perimeter · themes] La Nación / La presidenta de Venezuela irá a la ONU y perfila una reunión con Trump
      lanacion.com.py · Spanish · tone NA
  - (2026-09-21) [Russia oil sanctions perimeter · themes] Paisley artist creates four - storey mural marking Sma Shot anniversary
      heraldscotland.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 41 new of 108 total
  - (2026-09-21) EU Threatens Sanctions Over Russia’s Sham Elections in Occupied Ukraine
      The EU condemned Russia’s parliamentary elections in occupied parts of Ukraine as a violation of international law and pledged sanctions against those involved in staging the vote.
  - (2026-09-21) US Army Buys Battle-Tested Ukraine Observation Drone
      The US Army awarded Skyeton $10.64 million for Raybird reconnaissance drones, Ukraine’s first major military-drone export to the US. The Raybird is combat-proven, while another Ukrainian UAV, the F10, underwent US Army t…
  - (2026-09-21) Russia Hits 2 Gas Stations on Kyiv-Lviv M06 Highway
      The highway served as an artery between Kyiv and the country’s western border, with both gas stations hit on the section within the Zhytomyr region west of Kyiv. The attacks followed Russia’s escalated campaign against U…
  - (2026-09-21) Moscow Fortifies Power Plant After Record Ukrainian Attack
      Moscow’s CHP-8 power plant is being surrounded with concrete blocks that could support anti-drone netting, according to eyewitnesses cited by ASTRA. The work follows the largest reported Ukrainian aerial attack on Moscow…
  - (2026-09-21) After State Elections: Can Merz Keep His Job?
      Germany’s CDU suffered major losses in state elections in Berlin and Mecklenburg-Western Pomerania, while Die Linke and AfD gained ground. The results have intensified questions over Chancellor Friedrich Merz’s leadershi…
  - (2026-09-21) Ukraine Urges Europe to Send Patriot Missiles Now, Replenish Stocks With Future Production, Chernev Says
      Ukraine is proposing that European countries transfer Patriot missiles from existing stockpiles and replace them later with newly produced interceptors. Kyiv is also seeking faster access to bilateral funding commitments…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-21) 424B3 - OptimumBank Holdings, Inc. (0001288855) (Filer)
      filed 2026-09-21 13:29 UTC — Filed: 2026-09-21 AccNo: 0001493152-26-043496 Size: 717 KB
  - (2026-09-21) 497 - VegaShares ETF Trust (0002068712) (Filer)
      filed 2026-09-21 13:29 UTC — Filed: 2026-09-21 AccNo: 0001213900-26-101681 Size: 2 MB
  - (2026-09-21) 424B2 - TORONTO DOMINION BANK (0000947263) (Filer)
      filed 2026-09-21 13:28 UTC — Filed: 2026-09-21 AccNo: 0001193125-26-396173 Size: 120 KB
  - (2026-09-21) 424B5 - Digital Currency X Technology Inc. (0001957413) (Filer)
      filed 2026-09-21 13:27 UTC — Filed: 2026-09-21 AccNo: 0001493152-26-043493 Size: 867 KB
  - (2026-09-21) 424B2 - TORONTO DOMINION BANK (0000947263) (Filer)
      filed 2026-09-21 13:26 UTC — Filed: 2026-09-21 AccNo: 0001193125-26-396169 Size: 120 KB
  - (2026-09-21) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-09-21 13:25 UTC — Filed: 2026-09-21 AccNo: 0001839882-26-046362 Size: 1 MB

### IT, InfoSys & cybersecurity news (last 7 days) — 32 new of 57 total
  - (2026-09-21) [BleepingComputer] Microsoft reminds admins to migrate Entra ID users to passkeys
      Microsoft has reminded admins to migrate Entra ID users to phishing-resistant authentication methods to avoid sign-in disruptions after it retires SMS first-factor sign-in starting in February 2027. [...]
  - (2026-09-21) [BleepingComputer] Microsoft: September updates break File History backup feature
      Microsoft warned that the built-in File History backup feature in Windows may stop working on some systems after installing the September 2026 security updates. [...]
  - (2026-09-21) [The Hacker News] ClickFix Lures Deploy ChainScript RAT Using Polygon to Rotate C2 Infrastructure
      Threat actors are leveraging ClickFix-like lures to deliver a previously undocumented remote access trojan (RAT) called ChainScript. "ChainScript has appeared under multiple build names, including ComponentTask33, Update…
  - (2026-09-21) [The Hacker News] Jade Sleet Linked to Indian IT Provider Breach With FLATROOF and ROOFDECK Backdoors
      The North Korean threat actor known as Jade Sleet has been attributed to the compromise of an India-based "much smaller organization" in the information technology (IT) services industry, once again highlighting how the…
  - (2026-09-21) [The Record] LinkedIn wins court order blocking mass scraping of user data
      The agreement between LinkedIn, ProAPIs and joint business operator Netswift also requires the firms to stop selling and transferring the data, no longer access LinkedIn through fake accounts and delete the data that was…
  - (2026-09-21) [The Record] Google says Gemini breached three companies during security test
      Google’s artificial intelligence model Gemini accessed computer systems belonging to three real companies without authorization during a cybersecurity test in May — the latest in a string of similar incidents.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-09-21) GAF649 (Germany)
      icao24: 3f6533 · position: (52.0365, 13.2698) · alt: 4671m · 727km/h
  - (2026-09-21) CFC3112 (Canada)
      icao24: c2b369 · position: (46.3353, -74.1631) · alt: 9265m · 927km/h
  - (2026-09-21) PAT322 (United States)
      icao24: adfe51 · position: (37.2209, -79.4763) · alt: 1592m · 376km/h
  - (2026-09-21) PAT970 (United States)
      icao24: adfe4d · position: (38.4907, -77.7143) · alt: 2072m · 508km/h
  - (2026-09-21) PAT990 (United States)
      icao24: adfe53 · position: (47.4609, -98.4716) · alt: 6705m · 478km/h
  - (2026-09-21) JEDI75 (United States)
      icao24: ae1eab · position: (30.5493, -88.1869) · alt: 586m · 342km/h

### Paper Trading Scorecard — 22 new of 129 total
  - (2026-09-21) [Manifold] Will The Odyssey receive the most Oscar nominations?
  - (2026-09-21) [Manifold] Japan vs India T20 cricket match
  - (2026-09-21) [Manifold] Bitcoin $87,500 in September 2026?
  - (2026-09-21) [Manifold] US Average Gas Price Is $4.3500 or more on September 28 2026?
  - (2026-09-21) [Manifold] US Average Gas Price Is $4.4500 or more on September 24 2026?
  - (2026-09-21) [Manifold] Will Trump, any of his cabinet, or any official government account mention aella by name in a tweet by January 1 2028?

### Prediction Markets — most-traded (Polymarket) — 19 new of 20 total
  - (2026-09-21) Dota 2: Conventus Stellarum vs 1win (BO3) - PGL Wallachia Group Stage
      yes price: 0% · 24h volume: $1,306,457 · resolves 2026-09-21
  - (2026-09-21) Will Shakhtar Donetsk win the 2026-27 UEFA Champions League Championship?
      yes price: 0% · 24h volume: $460,015 · resolves 2027-05-30
  - (2026-09-21) Counter-Strike: Astralis vs Sangal (BO3) - Stake Pulse Beat II Group A
      yes price: 100% · 24h volume: $421,578 · resolves 2026-09-21
  - (2026-09-21) LoL: ZSK vs Saigon Warriors (BO1) - World Star Challengers Invitational Group D
      yes price: 0% · 24h volume: $380,065 · resolves 2026-09-21
  - (2026-09-21) Friedrich Merz out as Chancellor of Germany before December 31, 2026?
      yes price: 18% · 24h volume: $317,246 · resolves 2027-01-01
  - (2026-09-21) Will the US confirm that aliens exist before 2027?
      yes price: 3% · 24h volume: $291,955 · resolves 2027-01-01

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-09-15) U.S. Court of Appeals, 2nd Cir.: Bergin v. N.Y. State Unified Court System
  - (2026-09-15) U.S. Court of Appeals, 2nd Cir.: Defending Education v. Croton-Harmon Union Free School District
  - (2026-09-15) U.S. Court of Appeals, 1st Cir.: Doe v. Smith
  - (2026-09-15) Delaware Supreme Court: Stinson v. State
  - (2026-09-15) U.S. Court of International Trade: Stupp Corp. v. United States
  - (2026-09-15) U.S. Court of Appeals, 3rd Cir.: United States v. Davone Walker

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-09-20) M 5.7 - south of Africa
      M5.7 · south of Africa · depth 10 km
  - (2026-09-21) M 5.5 - 35 km NNE of Ruteng, Indonesia
      M5.5 · 35 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-09-21) M 5.2 - 167 km WNW of Mejillones, Chile
      M5.2 · 167 km WNW of Mejillones, Chile · depth 10 km
  - (2026-09-21) M 5.0 - 34 km WNW of Luwuk, Indonesia
      M5.0 · 34 km WNW of Luwuk, Indonesia · depth 9.863 km
  - (2026-09-20) M 5.0 - 248 km SSE of False Pass, Alaska
      M5.0 · 248 km SSE of False Pass, Alaska · depth 10 km
  - (2026-09-21) M 4.9 - 26 km SE of Saimbeyli, Turkey
      M4.9 · 26 km SE of Saimbeyli, Turkey · depth 10 km

### U.S. Federal Action — 15 new of 19 total
  - (2026-09-21) Restoring Reciprocity in Government Procurement
  - (2026-09-21) Providing Meaningful Water Quality Improvements Through Collaboration and Oversight of Federal Support
  - (2026-09-21) National POW/MIA Recognition Day, 2026
  - (2026-09-21) Constitution Day, Citizenship Day, and Constitution Week, 2026
  - (2026-09-21) Privacy Act Regulations
      On May 6, 2026, the Commodity Futures Trading Commission published in the Federal Register a notice of proposed rulemaking ("NPRM"), titled Privacy Act Regulations, to amend its Privacy Act regulations to exempt the CFTC…
  - (2026-09-21) Safety Zone; Illinois River, Morris, IL
      The Coast Guard is establishing a temporary safety zone in Morris, IL, for the Corn Festival Fireworks on September 26, 2026, to provide for the safety of life on navigable waterways during this fireworks display. The sa…

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-09-21) [Marginal Revolution] The Tragedy of Nikole Hannah-Jones
      Nikole Hannah-Jones famously sent her child to a predominantly black/lower-income public school in New York City. Now her child says she shouldn’t have been used as political fodder. The essay makes for hard reading and…
  - (2026-09-21) [Marginal Revolution] Obama on agentic AI
      Obama recently said: “If we are thinking about AI just in terms of how do we cure cancer or get better energy, you can do that without having agentic AI and having it just roaming free in the internet.” As Roon noted: “t…
  - (2026-09-20) [Marginal Revolution] Sunday assorted links
      1. Nobel Laureates in support of the California billionaire wealth tax include Krugman, Acemoglu, Diamond, Stiglitz, Banerjee, and Duflo (FT). 2. Secretariat as GOAT. 3. Dead brains and the piano?? 4. “A real contributio…
  - (2026-09-18) [Conversable Economist] Energy and Carbon Emissions: Some Global Ground Truths
      Amidst all the policy proposals, claims, and counterclaims about energy use and carbon emissions, it’s useful to touch base from time to time with basic current facts. One of my starting points is the Statistical Review…
  - (2026-09-16) [Conversable Economist] Adam Smith: Rule of Law as the Backbone for Markets
      Adam Smith’s 1776 book, An Inquiry into the Nature and Causes of the Wealth of Nations, is often described in casual conversation (at least by noneconomists) as a manifesto for the benefits and power of free markets. Tha…
  - (2026-09-15) [Conversable Economist] The Dominance of Aquaculture over Capture Fishing
      Aquaculture refers to farming the water: that is, growing fish or shrimp or other aquatic animals in a controlled space, rather than capturing them in open water. I’ve tended to think of aquaculture as an interesting sid…

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 108 total
  - (2026-09-21) [UN Sanctions] page checksum 5d62b6553bc0
      Active UN Security Council sanctions committees page snapshot

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-21) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=18, 14d-median=18; carrying terms: navigable, proposed, proposing, management, proposes, program, final, certain, special, address, document, national
- state_bills: today=81, 7d-median=79, 14d-median=88; carrying terms: administered, environmental, maintain, regulates, existing, vests, providing, within, provides, property, reporting, consumer
- state_news: today=281, 7d-median=683, 14d-median=549; carrying terms: centers, multi, environmental, natural, failed, voted, dollars, media, loading, officials, georgia, sizes
- local_news: today=207, 7d-median=236, 14d-median=227; carrying terms: google, around, restaurant, games, officials, georgia, according, family, atlantamagazine, public, missouri, charged
- foreign_news: today=975, 7d-median=1045, 14d-median=995; carrying terms: elpais, belgium, saying, margin, protest, indonesia, seeking, official, cooperation, paris, timed, media
- chinese_internal: today=265, 7d-median=282, 14d-median=282; carrying terms: google, cbmizefvx, global, lxtfa, target, cbmiykfvx, cbmia, china, cbmix, cbmigwfbvv, title, politics
- russian_internal: today=904, 7d-median=1067, 14d-median=1059; carrying terms: https, openai, russian, novayagazeta, target, httperror, telegram, ukraina, raquo, istories, error, laquo
- ukrainian_internal: today=108, 7d-median=136, 14d-median=135; carrying terms: ukraine, failed, sanctions, missiles, hmarochos, officials, september, strike, aerial, defense, killing, according
- ukraine_theater: today=502, 7d-median=450, 14d-median=450; carrying terms: ukpjegkzq, google, wxrnrzlfau, mission, ukraine, flash, intercepted, lpnez, wkrxnjzud, cbmir, vadvxvtnowm, syrian
- paper_bets: today=129, 7d-median=126, 14d-median=128; carrying terms: nominal, humans, levels, supervolcano, chuck, special, experience, theme, jpmorgan, california, earthquake, openai
- weather: today=117, 7d-median=114, 14d-median=114; carrying terms: craft, miami, weekend, waters, afddtx, unknown, southeast, highest, watch, miles, scattered, around
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexchus, energy, effective, supply, pcepilfe, treasury, assets, commodities, personal, implied, vixcls, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, close, equities, range, large, russell, china, bitcoin, agriculture, corporate, proxy, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=107, 14d-median=107; carrying terms: zimbabwe, haiti, entities, google, stability, ukraine, haitian, annexation, cbmizefvx, entity, cbmixkfvx, resolution
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, congresstrading, error, quantitative, unauthorized, https, quiverquant, quiver, httperror
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, state, court, supreme, company, delaware, international, connecticut, blanche, trade, robert, arizona
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, issuer, filed, holdings, filer, trust, tidal, technology, financial, technologies, finance
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, ossoff, senate, cortez, platner, graham, krishnamoorthi, trone, alexandria, filing, house, cooper
- gdelt_regions: today=0, 7d-median=0, 14d-median=6
- gdelt_gkg: today=50, 7d-median=50, 14d-median=50; carrying terms: sanctions, english, minister
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, germany, ground, france, canada, adfec, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: valley, epizootics, index, regio, situation, separated, release, hygiene, process, largest, india, welfare
- cisa_kev: today=21, 7d-median=21, 14d-median=21; carrying terms: microsoft, function, google, authentication, critical, chromium, jfrog, command, bounds, improper, remediation, buffer
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=16, 7d-median=15, 14d-median=12; carrying terms: depth, indonesia, islands, japan, ruteng, south, chile, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, shakhtar, championship, champions, league, interest, rates, meeting, donetsk, september
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, class, revolution, conversable, marginal, conversableeconomist, economist, lower, benefits, report, school, makes
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: years, latest, written, computer, vulnerability, september, newsletter, computerweekly, according, companies, against, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: ralph, crawford, gosar, insurance, gdelt, howard, chuck, cleaver, mciver, weber, hoeven, waters
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, evidence, today, consensus, identify, unavailable, paper, placed, placement, claude, module, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-14] ECB press: Isabel Schnabel: Macroeconomic, fiscal and financial stability in a shock-prone world
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI
- [2026-09-16] ECB press: ECB wage tracker at 2.7% in H1 2027, pointing to a modest uptick in negotiated wage growth
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] ECB press: Boris Vujčić: Interview with Reuters
- [2026-09-18] ECB press: ECB Consumer Expectations Survey results – August 2026
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-21] ECB press: ECB to invest part of own funds in tokenised securities, with settlement via Pontes
- [2026-09-21] ECB press: Eurosystem brings central bank money to tokenised finance

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*