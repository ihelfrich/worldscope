# WORLDSCOPE morning brief — 2026-11-27

## Headline
3726 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (867) · Russian Internal News (state + in-exile) (725) · Ukraine Theater (total-war monitoring) (391) · World leaders & government officials (324) · Chinese Internal News (299) · U.S. Weather + Severe / Climate Outlooks (148) · GDELT GKG — themes / entities / watch areas (144) · Local News: St. Louis + Atlanta (142) · State Legislative Action (128) · State-Level News (127) · World News (by country, top stories) (103) · Ukrainian Internal News (national + local Kyiv) (68)

## What changed today
### International News + Multilateral Institutions — 867 new of 1076 total
  - (2026-11-27) [Global] Costa Rica denies entry to UN’s Albanese over ‘links to terrorist acts’
      Authorities said the UN special rapporteur was blocked from entering the country due to 'national security' risks.
  - (2026-11-27) [Global] ‘Will I get taller?’: Gaza’s children suffer stunting amid war, blockade
      One in eight children is stunted. Many have bones that have not matured the way they should. Treatment is elusive.
  - (2026-11-27) [Global] Police bodycam shows rescue of man from burning car in US
      Dramatic police bodycam video shows the moment an officer and a passing motorist rescued a man inside a burning car
  - (2026-11-27) [Global] Deadly floods leave parts of Ecuador under water
      Deadly floods have submerged homes, businesses and roads across Ecuador.
  - (2026-11-27) [Global] New Zealand election results set up tricky talks for conservative incumbent
      Conservative PM Luxon and populist coalition partners face negotiations with centrist kingmaker.
  - (2026-11-27) [Global] ‘Borrowing to make ends meet’: The rising cost of living in Europe
      Prices are climbing again across Europe as energy costs surge.

### Russian Internal News (state + in-exile) — 725 new of 1168 total
  - (2026-11-27) Лариса Долина (уже в третий раз) выступила в КНДР. Послушать про «Погоду в доме» пришел Ким Чен Ын | LEDE: Лариса Долина выступила на концерте в Пхеньяне. ] (ru: Лариса Долина (уже в третий раз) высту…
      Лариса Долина выступила на концерте в Пхеньяне.
  - (2026-11-27) Бывший глава Тамбовской области Максим Егоров приговорен к 11 годам колонии строгого режима по делу о взятках | LEDE: Суд в Тамбове приговорил бывшего главу региона Максима Егорова к 11 года] (ru: Быв…
      Суд в Тамбове приговорил бывшего главу региона Максима Егорова к 11 годам заключения по обвинения в получении взяток. Наказание Егоров должен будет отбывать в колонии строгого режима. Суд также оштрафовал бывшего губерна…
  - (2026-11-27) ФСБ расширила список сведений, передача которых иностранцам угрожает безопасности России. К ним отнесли зарплаты военных и сотрудников ОПК | LEDE: ФСБ выпустила приказ, расширяющий перечень ] (ru: ФСБ…
      ФСБ выпустила приказ, расширяющий перечень сведений, которые могут быть использованы против безопасности России.
  - (2026-11-27) «Яндекс» запустит доставку человекоподобными роботами | LEDE: До конца 2026 года «Яндекс» планирует запустить пилотный проект по доставке человекоподобными роботам, рассказали «Коммерсанту» ] (ru: «Ян…
      До конца 2026 года «Яндекс» планирует запустить пилотный проект по доставке человекоподобными роботам, рассказали «Коммерсанту» два источника в IT-отрасли.
  - (2026-11-27) «Вояджер-1» перестал передавать научные и технические данные. Он отдалился от Земли дальше всех космических аппаратов — на один световой день | LEDE: Космический аппарат «Вояджер-1» больше н] (ru: «Во…
      Космический аппарат «Вояджер-1» больше не передает на Землю научные и технические данные, посылая лишь «пустой» радиосигнал, сообщили в NASA. Передача прекратилась 14 ноября — всего за несколько дней до того, как зонд до…
  - (2026-11-27) «Это как если бы кто-то сказал о Гитлере во время войны, что он хороший друг». Зеленский — о словах Трампа, назвавшего Путина своим другом | LEDE: Владимир Зеленский заявил, что считает стра] (ru: «Эт…
      Владимир Зеленский заявил, что считает странными слова Дональда Трампа, дважды назвавшего Владимира Путина своим другом.

### Ukraine Theater (total-war monitoring) — 391 new of 393 total
  - (2026-11-27) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-26) [ISW] Russian Offensive Campaign Assessment, November 25, 2026 - Institute for the Study of War
      Russian Offensive Campaign Assessment, November 25, 2026 I
  - (2026-11-25) [ISW] Russian Offensive Campaign Assessment, November 24, 2026 - Institute for the Study of War
      Russian Offensive Campaign Assessment, November 24, 2026 I
  - (2026-11-25) [ISW] Iran Update, November 24, 2026 - Institute for the Study of War
      Iran Update, November 24, 2026 Institute for the Study of War
  - (2026-11-24) [ISW] Russian Offensive Campaign Assessment, November 23, 2026 - Institute for the Study of War
      Russian Offensive Campaign Assessment, November 23, 2026 I
  - (2026-11-23) [ISW] Russian Offensive Campaign Assessment, November 22, 2026 - Institute for the Study of War
      Russian Offensive Campaign Assessment, November 22, 2026 I

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 299 new of 322 total
  - (2026-11-25) Boeing Scores First China Bulk Deal in Years With Xiamen Airlines Order - Caixin Global
      Boeing Scores First China Bulk Deal in Years With Xiamen Airlines Order Caixin Global
  - (2026-11-27) Analysis: China’s Insurers Seek to Close Gap in Innovative Drug Coverage - Caixin Global
      Analysis: China’s Insurers Seek to Close Gap in Innovative Drug Coverage Caixin Global
  - (2026-11-26) Vanke Seeks Second Extension on 1.2 Billion Yuan Bond - Caixin Global
      Vanke Seeks Second Extension on 1.2 Billion Yuan Bond Caixin Global
  - (2026-11-27) Apple Pulls MiniMax’s Chatbot From App Store Over Child Safety Concerns - Caixin Global
      Apple Pulls MiniMax’s Chatbot From App Store Over Child Safety Concerns Caixin Global
  - (2026-11-26) Analysis: Why China’s Banks Struggle to Finance Low-Carbon Transition - Caixin Global
      Analysis: Why China’s Banks Struggle to Finance Low-Carbon Transition Caixin Global
  - (2026-11-25) Hong Kong IPO Proceeds Set to Decline in 2027, EY Says - Caixin Global
      Hong Kong IPO Proceeds Set to Decline in 2027, EY Says Caixin Global

### U.S. Weather + Severe / Climate Outlooks — 148 new of 150 total
  - (2026-11-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-27) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 27 at 4:03AM EST until November 27 at 7:00AM EST by NWS Burlington VT
      * WHAT...Freezing rain. Additional ice accumulations of a glaze expected. * WHERE...Northern Franklin and Northern St. Lawrence Counties. * WHEN...Until 7 AM EST this morning. * IMPACTS...Difficult travel conditions are…
  - (2026-11-27) [Severe] Flood Warning: Flood Warning issued November 27 at 3:55AM EST until November 29 at 3:36AM EST by NWS Wakefield VA
      ...The Flood Warning continues for the following rivers in Virginia... Meherrin River At Lawrenceville affecting Brunswick and Greensville Counties. For the Chowan Basin...including Lawrenceville...Minor flooding is fore…
  - (2026-11-27) [Severe] Flood Warning: Flood Warning issued November 27 at 3:35AM EST until November 28 at 7:18PM EST by NWS Raleigh NC
      ...The Flood Warning continues for the following rivers in North Carolina... Neuse River Near Clayton affecting Johnston County. Neuse River At Smithfield affecting Johnston County. * WHAT...Minor flooding is occurring a…
  - (2026-11-27) [Severe] Flood Warning: Flood Warning issued November 27 at 3:35AM EST until November 27 at 8:53PM EST by NWS Raleigh NC
      ...The Flood Warning continues for the following rivers in North Carolina... Neuse River Near Clayton affecting Johnston County. Neuse River At Smithfield affecting Johnston County. * WHAT...Minor flooding is occurring a…
  - (2026-11-27) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 27 at 12:31AM PST until November 27 at 12:00PM PST by NWS Hanford CA
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...The San Joaquin Valley. * WHEN...Until noon PST today. * IMPACTS...Low visibility could make driving conditions hazardous. * ADDITIONAL DETAILS...Highw…

### GDELT GKG — themes / entities / watch areas — 144 new of 144 total
  - (2026-11-27) [Russia oil sanctions perimeter · themes] Russia 'preparing new mass strike soon': Zelenskiy
      westernadvocate.com.au · English · tone -6.29669156883671 · 8 other outlets
  - (2026-11-27) [Russia oil sanctions perimeter · themes] UNCTAD forecasts flat global maritime trade in 2026 as route disruptions raise costs
      kenya-today.com · English · tone -2.8169014084507
  - (2026-11-27) [Russia oil sanctions perimeter · themes] Ukraine Invasion Day 1,738: dead turkey day was yesterday in US, Trump whines about 17 windows
      dailykos.com · English · tone -6.06741573033708
  - (2026-11-27) [Russia oil sanctions perimeter · themes] Zelenskyy warns of major Russian attack as Trump urges Putin to 'pull back' - Grenada Chronicle – Daily Grenada And Caribbean News
      grenadachronicle.com · English · tone -2.65957446808511
  - (2026-11-27) [Russia oil sanctions perimeter · themes] Ukraine war briefing: Kyiv launched more long-range strikes in 2026 than rest of war combined, data shows
      theguardian.com · English · tone -4.46043165467626
  - (2026-11-27) [Russia oil sanctions perimeter · keywords] US-led consortium strikes $10bn deal for Lukoil international assets
      splash247.com · English · tone 0.704225352112676

### Local News: St. Louis + Atlanta — 142 new of 217 total
  - (2026-11-27) [St. Louis] World Bird Sanctuary closes indefinitely due to snowstorm damage
  - (2026-11-26) [St. Louis] Thanksgiving snowstorm collapses Wentzville Ice Arena, mayor calls it a 'total loss'
  - (2026-11-26) [St. Louis] Lost power on Thanksgiving? What to know as 125,000 homes in St. Louis region wait for crews
  - (2026-11-27) [St. Louis] Nearly 96,000 Ameren Missouri customers remain without power after Thanksgiving snowstorm
      Ameren said restoration could take multiple days as hundreds of additional workers arrive from across the Midwest to assist with repairs.
  - (2026-11-27) [St. Louis] Gordon Ramsay's daughter, Holly Ramsay-Peaty, gives birth to first child
      Holly Ramsay, daughter of celebrity chef Gordon Ramsay, and Olympic swimmer Adam Peaty welcomed their first child Wednesday.
  - (2026-11-27) [St. Louis] Missouri officials warn shoppers of holiday scams ahead of Black Friday
      Missouri officials and the Better Business Bureau urge holiday shoppers to beware of fake websites, fraudulent QR codes and gift card scams.

### State Legislative Action — 128 new of 134 total
  - (2026-11-25) [Alabama SB 28] Retired state employees; work as law enforcement officer or assistant district attorney authorized
      State & State Officers
  - (2026-11-25) [Alabama HB 182] Health department; to require acceptance of military education or training as credit towards EMS licensure
      Public Safety & Emergencies
  - (2026-11-25) [Alabama HB 430] Montgomery County; judge of probate, fundraising activities authorized
      Montgomery County
  - (2026-11-25) [Alabama SB 214] Amend the Sweet Home Alabama Tourism Investment Act; increase supplemental tax rebate; require certification of project costs
      Economic Development; Taxation & Revenue
  - (2026-11-25) [Alabama SB 20] Crimes and offenses; assault of public officials established
      Crimes & Offenses
  - (2026-11-25) [Alabama SB 26] Libraries; further provides for the appointment of local library boards
      Counties & Municipalities

### State-Level News — 127 new of 501 total
  - (2026-11-26) [California] Governor Newsom proclaims Thanksgiving Day
      Source
  - (2026-11-26) [Alabama] Tuscaloosa library pays $46K to settle lawsuit with conservative advocacy group
  - (2026-11-26) [Alabama] Tuberville plans statewide inaugural week ahead of January 18 swearing-in
  - (2026-11-26) [Alabama] Jesse Battles wins Alabama Senate District 10 recount
  - (2026-11-26) [Alabama] Better Business Bureau warns Alabama shoppers about 12 holiday scams
  - (2026-11-26) [Alabama] Not an ounce of shame

### World News (by country, top stories) — 103 new of 103 total
  - (2026-11-27) [Brazil] Milei not invited to Lula inauguration
      cp24.com · English · 2 other outlets ran this story
  - (2026-11-27) [Brazil] Biocon gets Brazilian regulator nod for biosimilar Pertuzumab for breast cancer treatment
      thehindubusinessline.com · English · 1 other outlets ran this story
  - (2026-11-27) [Brazil] Brazil-China meeting of young researchers opens in central Brazil
      en.people.cn · English
  - (2026-11-27) [Brazil] Calleri brace fires Sao Paulo past Remo
      bignewsnetwork.com · English
  - (2026-11-27) [Brazil] South Africa: Prosus - The Long Game in Brazil, First Flicker At Jet and New Earnings Yardstick
      allafrica.com · English
  - (2026-11-27) [Brazil] Embraer Responds to Proposed 10% Duty on Brazilian Aircraft
      flyingmag.com · English

### Ukrainian Internal News (national + local Kyiv) — 68 new of 134 total
  - (2026-11-27) EXPLAINER: Protecting the Skies: How Poland’s Proposed No-Fly Zone Could Work
      Poland plans to establish a no-fly zone along its eastern borders with Ukraine and Belarus after Russian missiles and drones entered its airspace. The restrictions could help its military respond to incursions, while aut…
  - (2026-11-27) Trump Appears to Confuse Israel With Iran, Says ‘Their Military Is Decimated’
      Trump appeared to confuse Israel with Iran while answering a question about Israeli PM Netanyahu and the country’s next leadership. He described a military as “decimated” before turning to Iran’s nuclear facilities.
  - (2026-11-27) Ukraine Strikes Rocket Fuel Plant in Russia’s Tula Region as Drones Hit St. Petersburg
      Ukrainian drones targeted energy and industrial facilities in Russia’s Tula region and struck areas of St. Petersburg, where a residential building was reportedly damaged. Moscow claimed its air defenses intercepted 318…
  - (2026-11-27) British-Ukrainian Defense Tech Startup Pai Defence Raises $5M for Drone Detection System
      British-Ukrainian defense startup Pai Defence has secured $5 million in pre-seed funding led by Nordic venture fund Gardar, alongside nine Ukraine-focused venture capitalists. The company will use the funds to expand fro…
  - (2026-11-27) UK to Invest £9.5 Million in Ukraine Wind Farm to Be Built by Elementum Energy
      The UK is to invest £9.5 million ($12.4 million) in a 200 MW wind farm in Ukraine capable of powering 300,000 households. Elementum Energy, a renewable power producer belonging to Richard Deitz’s VR Global Partners, is e…
  - (2026-11-27) ISW Russian Offensive Campaign Assessment, November 26, 2026
      War in Ukraine - Latest update, key takeaways and map from the Institute for the Study of War on November 26, 2026.

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-27) [Russia] Trump calls on Putin to halt Europe's military aggression immediately - Jowhar News Leader
      domain: jowhar.com · language: English · tone: -2.82805429864253 · 51 other outlets ran this story
  - (2026-11-27) [United States] Who was Strobe Talbott? Former Time magazine reporter, once roommates with Bill Clinton and later his deputy secretary of state, has died at age 80
      domain: indiatimes.com · language: English · tone: 0.50761421319797 · 34 other outlets ran this story
  - (2026-11-27) [Australia] Murderer Erin Patterson launches High Court challenge
      domain: bluemountainsgazette.com.au · language: English · tone: -6.68449197860963 · 32 other outlets ran this story
  - (2026-11-27) [Australia] Jail call 'sound basis' for keeping Sam Wood jailed
      domain: queanbeyanage.com.au · language: English · tone: -5.2143684820394 · 32 other outlets ran this story
  - (2026-11-27) [Australia] 'Monster' jailed for life over wife's lawnmower death
      domain: ulladullatimes.com.au · language: English · tone: -7.50246791707799 · 31 other outlets ran this story
  - (2026-11-27) [United States] Trump addresses death of detective killed in Thanksgiving Day wrong-way crash
      domain: cedarnews.net · language: English · tone: -12.280701754386 · 31 other outlets ran this story

### IT, InfoSys & cybersecurity news (last 7 days) — 31 new of 59 total
  - (2026-11-27) [BleepingComputer] New NFS2ROOT Linux flaw can let attackers gain root privileges
      ​A 12-year-old critical vulnerability in the Linux kernel's Network File System (NFS) server, tracked as CVE-2026-99362, allows remote attackers to gain root privileges. [...]
  - (2026-11-27) [The Hacker News] Switzerland Confirms AI-Assisted Cyberattacks Breached Critical Infrastructure Operators
      Attackers using AI agents have broken into computer systems at Swiss organizations in four of five confirmed attacks, the first such cases in the country, the country's cybersecurity agency said yesterday. Three of the a…
  - (2026-11-27) [The Hacker News] Unpatched Cacti Zero-Day Enables RCE in Just Four HTTP Requests via Guest Access
      Details have emerged about a new zero-day vulnerability in Cacti, an open-source network monitoring tool, that could be exploited to achieve remote code execution. The proof-of-concept (PoC) exploit, which has yet to be…
  - (2026-11-27) [The Register] Support team put in an emergency order for vodka – lots of vodka – to bring PCs back online
      Some clean-up jobs need powerful stuff
  - (2026-11-27) [The Register] AWS adds virtual iPhones to its cloud
      Emulating Android, too, but offers just two handsets and one tablet
  - (2026-11-27) [The Register] Free e-government platform that serves two billion people in ten countries has critical SQL injection bug
      India’s Digital Infrastructure for Governance Impact and Transformation tool can leak data

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Wikidata leader-roster changes (48h) — 26 new of 57 total
  - (2026-11-27) [Dominican Republic] Luis Abinader (Q16594097) edited
      /* wbsetreference-add:2| */ [[Property:P19]]: [[Q34820]], [[:toollabs:quickstatements/#/batch/297345|batch #297345]]
  - (2026-11-27) [El Salvador] Nayib Bukele (Q17712353) edited
      /* wbsetclaim-update:1||1 */ [[Property:P140]]: [[Q5043]]
  - (2026-11-27) [Lithuania] Gitanas Nausėda (Q9268379) edited
      /* wbeditentity-statements-multiple-properties-update:0||2 */ source for date of birth, source for place of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])
  - (2026-11-27) [Guatemala] Bernardo Arévalo de León (Q107254030) edited
      /* wbsetclaim-create:1||1 */ [[Property:P945]]: [[Q801]]
  - (2026-11-27) [North Macedonia] Gordana Siljanovska-Davkova (Q12277168) edited
      /* wbeditentity-update-languages-and-other-short:0||da */ other names, source for date of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])
  - (2026-11-27) [Poland] Karol Nawrocki (Q17704749) edited
      /* wbsetsitelink-add:1|azwiki */ Karol Navrotski

### Government Action: Sanctions + Procurement + Foreign Agents — 25 new of 102 total
  - (2026-11-23) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-11-20) [OFAC] Iran Designations; Issuance of Cuba Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran Designations; Issuance of Cuba Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-11-20) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-11-21) [OFAC] 1278 - Office of Foreign Assets Control (.gov)
      1278 Office of Foreign Assets Control (.gov)
  - (2026-11-27) [USASpending] $44,093,914,875 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-11-27) [USASpending] $35,106,991,747 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS

### Government & military aircraft airborne (OpenSky) — 22 new of 23 total
  - (2026-11-27) GAF527 (Germany)
      icao24: 3dbc00 · position: (53.8525, 10.8583) · alt: 1402m · 215km/h
  - (2026-11-27) GAF220 (Germany)
      icao24: 3ea541 · position: (47.7697, 2.2806) · alt: 10660m · 780km/h
  - (2026-11-27) CFC2928 (Canada)
      icao24: c2b5cb · position: (51.7994, 3.9172) · alt: 6858m · 678km/h
  - (2026-11-27) GAF017 (Germany)
      icao24: 3f717c · position: (53.3215, 19.1366) · alt: 7612m · 533km/h
  - (2026-11-27) KAF716 (United States)
      icao24: a00000 · position: (-1.2157, 36.8355) · alt: 1897m · 277km/h
  - (2026-11-27) JAF9JH (Belgium)
      icao24: 44d1ba · position: (40.5155, 0.9606) · alt: 10972m · 734km/h

### Paper Trading Scorecard — 17 new of 81 total
  - (2026-11-27) [Polymarket] Will the average Ornn H100 rental price in December 2026 be above $3.00?
      This market will resolve to "Yes" if the average Ornn H100 index value in December 2026 is above the specified price. Otherwise, this market will resolve to "No". The average Ornn H100 index value in December 2026 is the…
  - (2026-11-27) [Polymarket] FAA outage attributed to AI?
      This market will resolve to “Yes” if the U.S. government officially attributes the November 13, 2026, FAA outage to artificial intelligence between market creation and November 30, 2026, 11:59 PM ET. Otherwise, this mark…
  - (2026-11-27) [Manifold] Polynomial time factorization (factoring in P) proven by the end of 2026?
  - (2026-11-27) [Manifold] New NVIDIA CEO named by December 31, 2026?
  - (2026-11-27) [Manifold] Free lottery (Hawking 1998)
  - (2026-11-27) [Manifold] Maximum percentage Ro Khanna wins in any 2028 Presidential primary

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-25) [F99] (unknown)
      cycle 2026 · filing #2049625
  - (2026-11-25) [F3X] INNOVATION OHIO PAC
      cycle 2026 · filing #2049818
  - (2026-11-25) [F3X] FREEDOM FOR ALL PAC
      cycle 2026 · filing #2049656 · receipts $0.00M
  - (2026-11-25) [F3X] DAO FOR AMERICA
      cycle 2026 · filing #2049778
  - (2026-11-25) [F1] VIRGINIA PATRIOT PAC
      cycle 2026 · filing #2049808
  - (2026-11-25) [F99] PARENTAL, DOMESTIC RELATIONS, AND FAMILY TRANSFORMATION LPAC
      cycle 2026 · filing #

### Court opinions of consequence (federal & state) — 14 new of 36 total
  - (2026-11-25) U.S. Court of Appeals, 4th Cir.: Chantilly Auto Body, Inc. v. Truist Bank
  - (2026-11-24) Delaware Supreme Court: Townsend v. State
  - (2026-11-23) Colorado Supreme Court: Charles James Crabtree v. The People of the State of Colorado
  - (2026-11-23) Colorado Supreme Court: David J. Gottorff, Plaintiff-Appellant: v. Executive Director of the Colorado Department of Corrections and Bryan Coleman, Warden of Buena Vista Minimum Center, Defendants-Appe…
  - (2026-11-23) Colorado Supreme Court: In Re Javier De Leon Cabral v. Chan Law Firm PC, Catherine Chan, and Joshua H. Russcol.
  - (2026-11-23) Colorado Supreme Court: In Re The People of the State of Colorado v. Jose Antonio Rodriguez Estrada

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-11-27) Will the price of Bitcoin be between $60,000 and $62,000 on November 27?
      yes price: 50% · 24h volume: $2,031,226 · resolves 2026-11-27
  - (2026-11-27) Counter-Strike: Imperial vs Wildcard (BO3) - PGL Major Singapore Stage 1
      yes price: 38% · 24h volume: $830,891 · resolves 2026-11-27
  - (2026-11-27) Counter-Strike: Imperial vs Wildcard - Map 1 Winner
      yes price: 6% · 24h volume: $362,907 · resolves 2026-11-27
  - (2026-11-27) Will the average Ornn B200 rental price in March 2027 be above $8.00?
      yes price: 72% · 24h volume: $319,211 · resolves 2027-04-01
  - (2026-11-27) Spread: Broncos (-4.5)
      yes price: 50% · 24h volume: $242,675 · resolves 2026-11-27
  - (2026-11-27) Will Benjamin Netanyahu be the next Prime Minister of Israel?
      yes price: 15% · 24h volume: $238,862 · resolves 2026-10-28

### USGS earthquakes (M4.5+, past day) — 8 new of 8 total
  - (2026-11-26) M 5.7 - Revilla Gigedo Islands region
      M5.7 · Revilla Gigedo Islands region · depth 10 km
  - (2026-11-26) M 5.2 - 265 km WNW of Houma, Tonga
      M5.2 · 265 km WNW of Houma, Tonga · depth 493.861 km
  - (2026-11-27) M 5.1 - 107 km SSE of Auki, Solomon Islands
      M5.1 · 107 km SSE of Auki, Solomon Islands · depth 74.064 km
  - (2026-11-26) M 5.1 - Bonin Islands, Japan region
      M5.1 · Bonin Islands, Japan region · depth 84.59 km
  - (2026-11-27) M 5.0 - Off the coast of Aisen, Chile
      M5.0 · Off the coast of Aisen, Chile · depth 10 km
  - (2026-11-27) M 5.0 - 89 km SSE of Sola, Vanuatu
      M5.0 · 89 km SSE of Sola, Vanuatu · depth 8.982 km

### EPSS — highest exploit-probability CVEs — 7 new of 40 total
  - (2026-11-26) CVE-2026-99811: 0% exploit probability (p14.7)
      EPSS 0.003 · percentile 0.147
  - (2026-11-26) CVE-2026-99810: 0% exploit probability (p14.7)
      EPSS 0.003 · percentile 0.147
  - (2026-11-26) CVE-2026-99809: 0% exploit probability (p14.7)
      EPSS 0.003 · percentile 0.147
  - (2026-11-26) CVE-2026-99808: 0% exploit probability (p16.5)
      EPSS 0.003 · percentile 0.165
  - (2026-11-26) CVE-2026-99807: 0% exploit probability (p16.5)
      EPSS 0.003 · percentile 0.165
  - (2026-11-26) CVE-2026-99806: 0% exploit probability (p16.5)
      EPSS 0.003 · percentile 0.165

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 38 total
  - (2026-11-27) MOVER ▼ Francoise Bettencourt Meyers & family — $101.48B ($-1.24B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-11-27) MOVER ▼ Zhong Shanshan — $65.67B ($-1.11B since yesterday)
      China · Food & Beverage · source: Beverages, pharmaceuticals
  - (2026-11-27) MOVER ▲ Mukesh Ambani — $96.88B (+$0.87B since yesterday)
      India · Diversified · source: Diversified
  - (2026-11-27) MOVER ▼ Gautam Adani — $82.73B ($-0.47B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-11-27) MOVER ▲ Amancio Ortega — $147.30B (+$0.39B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-11-27) MOVER ▼ Tadashi Yanai & family — $72.24B ($-0.15B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-27) [Marginal Revolution] The mental illness theory of politics is modestly underrated
      Using a large national panel dataset, we find that receiving counseling from mental health professionals decreases the likelihood of protesting in subsequent weeks by 34%–39%. Experimental results are broadly consistent…
  - (2026-11-27) [Marginal Revolution] My podcast with Hasan
      Excellent questions, mostly fresh material, and interesting throughout. Here is the basic info: Watch on Substack or YouTube Listen on Apple Podcasts or Spotify Read the full transcript on Substack Here is one excerpt: H…
  - (2026-11-26) [Marginal Revolution] HumanFish — Predicting Who Actually Wins a Human Chess Game
      The eval bar on a chess broadcast answers the wrong question. It tells you what happens if two 3600-Elo engines play perfectly with infinite time. What you actually want to know while watching humans play is: who is goin…
  - (2026-11-26) [Conversable Economist] A Thanksgiving Holiday: Needs and Origins
      We live in a time with considerable emphasis on evaluating and judging others, whether they are politicians, businesses, billionaires, AI, historical figures, managers, cable TV companies, baristas, lovers, parents, chil…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=23, 7d-median=17, 14d-median=20; carrying terms: published, certain, airplanes, directives, applicable, proposed, safety, action, public, rulemaking, provide, airworthiness
- state_bills: today=134, 7d-median=134, 14d-median=73; carrying terms: relating, health, state, providing, school, local, program, district, emergency, alaska, medical, including
- state_news: today=501, 7d-median=501, 14d-median=651; carrying terms: reform, planned, congressional, executive, dozen, takes, letter, always, built, coalition, notice, following
- local_news: today=217, 7d-median=212, 14d-median=248; carrying terms: dining, business, south, custody, trump, judge, killed, following, million, november, local, louis
- foreign_news: today=1076, 7d-median=1024, 14d-median=1012; carrying terms: outlook, order, seized, accuses, maverick, shenzhen, related, announcement, price, theeastafrican, approach, urging
- chinese_internal: today=322, 7d-median=271, 14d-median=293; carrying terms: https, investors, sales, china, google, global, nvidia, chinese, caixin, market, firms, jensen
- russian_internal: today=1168, 7d-median=943, 14d-median=943; carrying terms: journal, httperror, politico, bloomberg, title, street, telegram, spacex, anthropic, https, media, russian
- ukrainian_internal: today=134, 7d-median=129, 14d-median=129; carrying terms: international, kyivindependent, support, winter, censor, talks, trump, european, reported, region, regions, germany
- ukraine_theater: today=393, 7d-median=273, 14d-median=273; carrying terms: maintained, credentials, known, acled, google, error, polygon, exception, ianthelfrich, snapshot, gmail, rejected
- paper_bets: today=81, 7d-median=77, 14d-median=77; carrying terms: patrick, israeli, either, henry, polymarket, public, drought, break, chair, minister, another, lifetime
- weather: today=150, 7d-median=142, 14d-median=130; carrying terms: temperatures, vessels, accumulations, until, afdlox, please, outlook, total, beaches, south, updated, winter
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexuseu, payrolls, labor, energy, pcepilfe, funds, cpiaucsl, supply, dexchus, implied, inflation, personal
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: china, russell, futures, natural, commodities, proxy, range, treasury, large, silver, close, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=102, 7d-median=102, 14d-median=100; carrying terms: aggression, guatemala, member, hamilton, african, savannah, contract, order, qaida, venezuela, integrity, south
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, client, quiver, httperror, error, congresstrading, quiverquant, https, quantitative
- billionaires: today=38, 7d-median=40, 14d-median=40; carrying terms: finance, nvidia, family, japan, ortega, trading, bernard, pharmaceuticals, amazon, zhong, charles, india
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=36, 7d-median=60, 14d-median=60; carrying terms: court, state, blanche, appeals, charles, martin, supreme, smith, miller, people, reynolds, county
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, holdings, filed, accno, reporting, william, brian, joseph, reeves, poppic, kevin, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, cooper, sayed, peltola, cortez, house, sherrod, brown, robert, warner, david, senate
- gdelt_regions: today=103, 7d-median=103, 14d-median=103; carrying terms: south, trump, outlets, arabia, germany, israel, nigeria, colombia, portugal, china, kingdom, italy
- gdelt_gkg: today=144, 7d-median=134, 14d-median=133; carrying terms: hezbollah, south, trump, sahel, taiwan, outlets, netanyahu, israel, nigeria, punchng, earths, jihadist
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: story, trump, crash, outlets, killed, australia, injured, domain, english, shooting, language, police
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=23, 7d-median=17, 14d-median=19; carrying terms: position, belgium, germany, france, ground, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: mortality, division, among, disease, institute, syndrome, brands, onboard, notification, continues, probable, confined
- cisa_kev: today=26, 7d-median=21, 14d-median=18; carrying terms: products, injection, vulnerability, resource, critical, external, bypass, using, vendor, product, channel, cisco
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=57, 7d-median=57, 14d-median=54; carrying terms: batch, republic, quickstatements, toollabs, wbsetdescription, wbsetclaim, property, wbsetsitelink, wbeditentity, update, edited, create
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=100, 14d-median=100; carrying terms: magnitude, forest, islands, earthquake, indonesia, india, burkina, wildfire, african, republic, sudan, fires
- usgs_quakes: today=8, 7d-median=10, 14d-median=12; carrying terms: depth, islands, indonesia, region, japan, philippines, chile, vanuatu, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: december, price, volume, november, resolves, donetsk, interest, champions, rates, shakhtar, championship, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, marginal, revolution, marginalrevolution, economist, conversable, years, human, policy, class, whether, global
- tech_news: today=59, 7d-median=63, 14d-median=63; carrying terms: spectrum, versions, affected, including, hackers, personal, stories, three, following, computerweekly, based, november
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: darren, tulsi, chellie, madeleine, nikki, susie, sullivan, delbene, jamieson, sessions, fedorchak, tiffany
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, converges, either, identify, paper, unavailable, module, sufficient, consensus, placed, claude, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-18] Fed speeches: Barr, Investing in America’s Underserved Communities
- [2026-11-18] Fed press (events + announcements): Minutes of the Federal Open Market Committee, October 27-28, 2026
- [2026-11-19] Fed speeches: Jefferson, Monetary Policy amid Frequent and Complex Shocks
- [2026-11-19] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of First Security Bancorp
- [2026-11-20] ECB press: Christine Lagarde: Acting in time
- [2026-11-20] Fed speeches: Waller, Opening Remarks
- [2026-11-20] Fed press (events + announcements): Federal Reserve Board releases results from survey of senior financial officers at banks about their strategies and practices for managing reserve balances
- [2026-11-20] Fed speeches: Cook, The U.S. Economy in Global Context
- [2026-11-20] Fed press (events + announcements): Federal Reserve announces College Fed Challenge winners
- [2026-11-23] ECB press: ECB expands acceptance of DLT-based assets as eligible Eurosystem collateral
- [2026-11-23] ECB press: Philip R. Lane: Climate change and monetary policy
- [2026-11-24] ECB press: Boris Vujčić: Resilience in an age of shocks: lessons from central and eastern Europe
- [2026-11-24] Fed press (events + announcements): Minutes of the Board's discount rate meetings on October 19 and October 28, 2026
- [2026-11-25] ECB press: Card payments edge past cash in shops; euro area consumers want both

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*