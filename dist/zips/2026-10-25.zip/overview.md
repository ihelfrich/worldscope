# WORLDSCOPE morning brief — 2026-10-25

## Headline
2452 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (700) · Russian Internal News (state + in-exile) (543) · World leaders & government officials (324) · Chinese Internal News (165) · U.S. Weather + Severe / Climate Outlooks (147) · Local News: St. Louis + Atlanta (110) · State-Level News (100) · GDACS — global disaster alerts (93) · Ukraine Theater (total-war monitoring) (81) · Ukrainian Internal News (national + local Kyiv) (52) · Sanctions & Designations (recent) (30) · USGS earthquakes (M4.5+, past day) (29)

## What changed today
### International News + Multilateral Institutions — 700 new of 960 total
  - (2026-10-25) [Global] More than 1,300 arrested as clashes follow another day of mass protests across France
      Hundreds of thousands took part in demonstrations in France, with protests also taking place in other European countries.
  - (2026-10-25) [Global] Israel to close West Bank crossings on election day as crackdown escalates
      The Israeli Defense Forces announces restrictions on the movement of Palestinian workers in the run-up to Tuesday's election.
  - (2026-10-25) [Global] Voters in Brazil head to polls as Lula goes up against Bolsonaro's son
      Flávio Bolsonaro, the son of Brazil's imprisoned ex-president, is challenging Lula, who is seeking a fourth term in office.
  - (2026-10-25) [Global] Musk says SpaceX restricted Ukraine's Starlink connection as service restored
      The tech billionaire accuses Ukraine of violating its terms of service by using the network for military activity.
  - (2026-10-25) [Global] Gunmen kill at least 10 villagers and loot shops in north-east Nigeria
      Police are searching for other casualties, with officials warning the actual death toll could rise further.
  - (2026-10-24) [Global] Man arrested after fire at Hitler's mountaintop Eagle's Nest retreat
      Some 200 emergency personnel were deployed to fight the blaze at the Nazi dictator's Alpine residence in Germany.

### Russian Internal News (state + in-exile) — 543 new of 871 total
  - (2026-10-25) На свободу вышел последний из пяти полицейский, осужденных по делу о подбросе наркотиков журналисту Ивану Голунову | LEDE: Кирово-Чепецкий суд Кировской области заменил бывшему полицейскому ] (ru: На…
      Кирово-Чепецкий суд Кировской области заменил бывшему полицейскому Игорю Ляховцу, которого осудили по делу о подбросе наркотиков журналисту Ивану Голунову, часть срока принудительными работами, пишет «Коммерсант».
  - (2026-10-25) «Глиноликий» — боди-хоррор студии DC, где есть Готэм, но нет Бэтмена. Получилась мужская версия «Субстанции» (довольно страшная) | LEDE: В мировой прокат вышел «Глиноликий» (Clayface) — филь] (ru: «Гл…
      В мировой прокат вышел «Глиноликий» (Clayface) — фильм об одном из злодеев Готэма. Вслед за независимыми студиями супергигант DC тоже вступает на территорию самого модного жанра последних нескольких сезонов — хоррора. Ка…
  - (2026-10-25) Украинские беспилотники атаковали Пермский край. Под удар попало предприятие «ВСМПО-Ависма», утверждают мониторинговые каналы | LEDE: Украинские беспилотники атаковали Пермский край, «незнач] (ru: Укр…
      Украинские беспилотники атаковали Пермский край, «незначительные повреждения» получил промышленный объект на севере региона, заявил губернатор Дмитрий Махонин.
  - (2026-10-25) В Кремле утверждают, что подготовка встречи Путина, Трампа и Си Цзиньпина «уже началась». Она может пройти в середине ноября | LEDE: Подготовка встречи Владимира Путина, Дональда Трампа и Си] (ru: В К…
      Подготовка встречи Владимира Путина, Дональда Трампа и Си Цзиньпина уже началась, сообщил помощник российского президента Юрий Ушаков корреспонденту «Вестей» Павлу Зарубину.
  - (2026-10-25) В Стамбуле отменили концерт Максима Галкина. К этому призывали турецкие СМИ и общественные организации, обвинившие шоумена в поддержке Израиля | LEDE: Концерт Максима Галкина в Стамбуле, кот] (ru: В С…
      Концерт Максима Галкина в Стамбуле, который должен был пройти 25 октября в Istanbul Congress Center, отменен по решению местных властей.
  - (2026-10-25) Умер Миша Маваши — бывший рэпер и основатель националистического движения «Северный человек» | LEDE: Основатель движения «Северный человек» и бывший рэпер Миша Маваши (Михаил Ниц) умер в воз] (ru: Уме…
      Основатель движения «Северный человек» и бывший рэпер Миша Маваши (Михаил Ниц) умер в возрасте 41 года.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 165 new of 261 total
  - (2026-10-23) In Depth: China Bets Green Hydrogen’s Future on Industrial Demand - Caixin Global
      In Depth: China Bets Green Hydrogen’s Future on Industrial Demand Caixin Global
  - (2026-10-23) Chinese Vehicles Become More Popular With British Consumers - Caixin Global
      Chinese Vehicles Become More Popular With British Consumers Caixin Global
  - (2026-10-23) Evergrande’s Recovery Efforts Span Art Sales and a Harvard Donation Claim - Caixin Global
      Evergrande’s Recovery Efforts Span Art Sales and a Harvard Donation Claim Caixin Global
  - (2026-10-23) China’s Luxury Slowdown Weighs on Global Brands - Caixin Global
      China’s Luxury Slowdown Weighs on Global Brands Caixin Global
  - (2026-10-24) 人事观察｜新疆党委换届 喀什书记等新晋常委 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFB3VVhyX1g5UldWeVN5dXAwdUNCcjZXWWRuTWM1ZkJjMGUwQ0lZZEc5ZFR3T1B4T2RyekFmSVhQLVk2S0VVOXZvbWxXZ2sxcXk3] (zh:…
      人事观察｜新疆党委换届 喀什书记等新晋常委 财新
  - (2026-10-24) 环境部：39城试点深化气候适应型城市建设 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VNnhEa1ZBczBnLVJRSGNmM3BGWGtYc21fc1FST2c4TDBndmR2ZjJ2UWlzRlR5eHVWN2JlZmE0R1hhemQ0S0MwZjBHNmRXSzd6Q] (zh:…
      环境部：39城试点深化气候适应型城市建设 财新

### U.S. Weather + Severe / Climate Outlooks — 147 new of 149 total
  - (2026-10-25) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-25) [Severe] High Wind Watch: High Wind Watch issued October 25 at 2:45AM AKDT until October 27 at 4:00PM AKDT by NWS Fairbanks AK
      * WHAT...South to southeast winds 30 to 40 mph with gusts up to 60 mph possible. * WHERE...Bering Strait Coast and St Lawrence Island. * WHEN...From Monday afternoon through Tuesday afternoon. * IMPACTS...High winds may…
  - (2026-10-25) [Severe] High Wind Watch: High Wind Watch issued October 25 at 2:43AM AKDT until October 27 at 10:00PM AKDT by NWS Fairbanks AK
      * WHAT...South winds 25 to 35 mph with gusts up to 60 mph possible. * WHERE...Lisburne Peninsula. * WHEN...From Monday evening through Tuesday evening. * IMPACTS...High winds may move loose debris, damage property and ca…
  - (2026-10-25) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued October 25 at 2:38AM AKDT until October 27 at 4:00PM AKDT by NWS Fairbanks AK
      * WHAT...Snow and blowing snow expected. Total snow accumulations between 3 and 7 inches. Winds gusting as high as 40 mph. Visibility could be reduced to less than a mile at times. * WHERE...Dalton Highway Summits, Forty…
  - (2026-10-25) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued October 25 at 2:38AM AKDT until October 26 at 4:00AM AKDT by NWS Fairbanks AK
      * WHAT...Snow and freezing rain expected. Total snow accumulations up to 3 inches and 0.01 inch of ice possible. * WHERE...Central Interior. * WHEN...Until 4 AM AKDT Monday. * IMPACTS...Travel could be very difficult. *…
  - (2026-10-25) [Severe] Winter Storm Warning: Winter Storm Warning issued October 25 at 2:38AM AKDT until October 26 at 10:00PM AKDT by NWS Fairbanks AK
      * WHAT...Heavy snow expected. Total snow accumulations between 8 to 16 inches. Winds could gust as high as 35 mph. * WHERE...South Slopes of the Central Brooks Range. * WHEN...Until 10 PM AKDT Monday. * IMPACTS...Travel…

### Local News: St. Louis + Atlanta — 110 new of 211 total
  - (2026-10-25) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-10-24) [St. Louis] Statue being installed at Rung for Women triggers complaint from Missouri AG
      A sculpture titled “Witness” won’t begin installation at its new home in Fox Park until later this week, but it’s already caused a stir, even getting the attention of Missouri’s top law enforcement officer, Attorney Gene…
  - (2026-10-24) [St. Louis] Oh London closes today in Creve Coeur
      Less than a month after earning major national recognition, Oh London (11411 Olive Boulevard) is closing. Raj Pandey, who owns the restaurant along with his wife Shweta, confirmed that the final day of service is Saturda…
  - (2026-10-25) [St. Louis] At least 12 people injured in shooting near a football stadium in Florida
      At least 12 people, including six children, were injured in a shooting near Florida A&M University during homecoming weekend in Tallahassee.
  - (2026-10-25) [St. Louis] High Ridge water district will stop adding fluoride to its water in 2027
      Public Water Supply District No. 2 plans to stop adding fluoride to its water in January, citing higher costs and concerns about handling the chemical.
  - (2026-10-25) [St. Louis] Motorcyclist killed in I-70 crash in Maryland Heights
      A 24-year-old man from St. Louis died after his motorcycle crashed into the back of a car on I-70 early Saturday, troopers said.

### State-Level News — 100 new of 423 total
  - (2026-10-24) [California] Why are there so many bonds on the California ballot? Here’s what $44 billion would buy
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/080326_EATON_FIRE_REBUILD_CM_35.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-10-24) [California] LA chemical plant on short leash from state regulators as neighbors continue to protest its operations
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/102126-PHIBRO-TECH-AD-CM-05.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-10-25) [Arkansas] Faith leaders unite across religions to counter voter intimidation on Election Day
      Come Election Day, a Quaker leader will travel from the nation’s capital to her home state of Ohio. A Christian minister and a Jewish rabbi will stand vigil outside a polling place in Arizona. A Buddhist nun will offer s…
  - (2026-10-25) [Arkansas] Commentary: Arkansas Democrats have their best opening in years. What if they still can’t win?
      Long before it was Trump country, Arkansas was the Democratic holdout among Southern states, a lonely bluish island surrounded by red. Heading into Election Day, state Democrats may have to grapple with the inverse situa…
  - (2026-10-25) [Arkansas] These White suburban moms regret voting for Trump — but aren’t sold on Democrats
      This story was originally reported by Grace Panetta of The 19th. Meet Grace and read more of their reporting on gender, politics and policy. Two years ago, six White suburban mothers were among the more than 77 million A…
  - (2026-10-24) [Alaska] Gubernatorial candidates make their pitch at the Alaska Federation of Natives convention
      The three gubernatorial candidates who spoke Friday at the Alaska Federation of Natives convention found plenty of common ground on education, fisheries, public safety and other subjects. But some divides emerged in what…

### GDACS — global disaster alerts — 93 new of 100 total
  - (2026-10-25) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 5.4M, Depth:72.349km
  - (2026-10-25) [Green] Earthquake in Volcano Islands, Japan Region
      Earthquake · Green alert · Volcano Islands, Japan Region · Magnitude 4.6M, Depth:133.076km
  - (2026-10-21) [Green] Tropical Cyclone VANCE-26
      Tropical Cyclone · Green alert · · Hurricane/Typhoon > 74 mph (maximum wind speed of 139 km/h)
  - (2026-10-25) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 5.4M, Depth:10km
  - (2026-10-25) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 4.5M, Depth:19.7km
  - (2026-10-25) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 4.6M, Depth:35.068km

### Ukraine Theater (total-war monitoring) — 81 new of 392 total
  - (2026-10-25) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-21) [Liveuamap] Russian forces struck a METRO retail store in Rivne, Ukraine, according to the regional military administration - Liveuamap
      Russian forces struck a METRO retail store in Rivne, Ukraine, according to the regional military administration <font
  - (2026-10-23) [Liveuamap] Moment of a missile strike at the Proton military plant in Oryol today – Oryol,Orlovskaya oblast&039 - Liveuamap
      Moment of a missile strike at the Proton military plant in Oryol today – Oryol,Orlovskaya oblast&039 <font
  - (2026-10-24) [Liveuamap] Explosions were reported in Omsk – Omsk Oblast, Russia - Liveuamap
      Explosions were reported in Omsk – Omsk Oblast, Russia Liveuamap
  - (2026-10-23) [Liveuamap] Power supply issues in Dnipro city after Russian strike – Dnipropetrovsk Oblast, Ukraine - Liveuamap
      Power supply issues in Dnipro city after Russian strike – Dnipropetrovsk Oblast, Ukraine <font color="#6f6f6
  - (2026-10-20) [Liveuamap] Iranian National Security Council chief meets with Pakistani Army chief: No negotiations until Washington takes steps and implements our conditions – Tehran Province, Iran - Liveuamap
      Iranian National Security Council chief meets with Pakistani Army chief: No negotiations until Washington takes steps a

### Ukrainian Internal News (national + local Kyiv) — 52 new of 130 total
  - (2026-10-25) На Київщині внаслідок атаки дронів поранена жінка, є пошкодження | LEDE: Унаслідок російського удару дронами по Київській області постраждала жінка, пошкоджено житлові будинки та автомобілі. По] (uk:…
      Унаслідок російського удару дронами по Київській області постраждала жінка, пошкоджено житлові будинки та автомобілі. Подробиці від Київської ОВА.
  - (2026-10-25) Протестувальники влаштували безлади в Барселоні, понад сотня затриманих | LEDE: ] (uk: Протестувальники влаштували безлади в Барселоні, понад сотня затриманих)
  - (2026-10-25) Перша леді США допускає свій візит до України | LEDE: Перша леді США заявила про свою роль у перемир'ї для Олешок і натякнула на поїздку в Україну. Деталі домовленостей і заяви — у матеріалі.] (uk: Пе…
      Перша леді США заявила про свою роль у перемир'ї для Олешок і натякнула на поїздку в Україну. Деталі домовленостей і заяви — у матеріалі.
  - (2026-10-25) На Житомирщині дрони пошкодили енергооб'єкт, амбулаторію та будинок | LEDE: Внаслідок атаки російських дронів у Житомирській області пошкоджено енергооб'єкт, амбулаторію та будівлі. Жертв немає] (uk:…
      Внаслідок атаки російських дронів у Житомирській області пошкоджено енергооб'єкт, амбулаторію та будівлі. Жертв немає.
  - (2026-10-25) Британія та Франція відпрацювали швидку висадку десанту для захисту НАТО | LEDE: ] (uk: Британія та Франція відпрацювали швидку висадку десанту для захисту НАТО)
  - (2026-10-25) Генштаб заявив про ураження російських РЛС на Бєлгородщині та пунктів управління | LEDE: Сили оборони України 24 жовтня та в ніч на 25 жовтня уразили російські радіолокаційні станції у Бєлгород] (uk:…
      Сили оборони України 24 жовтня та в ніч на 25 жовтня уразили російські радіолокаційні станції у Бєлгородській області РФ, а також пункти управління окупантів на Запоріжжі та Херсонщині.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 29 new of 29 total
  - (2026-10-25) M 6.5 - Bonin Islands, Japan region
      M6.5 · Bonin Islands, Japan region · depth 492.376 km · TSUNAMI
  - (2026-10-25) M 6.1 - 25 km ENE of Port-Olry, Vanuatu
      M6.1 · 25 km ENE of Port-Olry, Vanuatu · depth 116 km
  - (2026-10-24) M 5.8 - Bouvet Island region
      M5.8 · Bouvet Island region · depth 12.486 km
  - (2026-10-25) M 5.4 - 33 km ESE of Ambunti, Papua New Guinea
      M5.4 · 33 km ESE of Ambunti, Papua New Guinea · depth 72.349 km
  - (2026-10-25) M 5.4 - 205 km NW of Port-Olry, Vanuatu
      M5.4 · 205 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-24) M 5.3 - 44 km ESE of Miyazaki, Japan
      M5.3 · 44 km ESE of Miyazaki, Japan · depth 10 km

### Government & military aircraft airborne (OpenSky) — 16 new of 17 total
  - (2026-10-25) JAF9FN (Bulgaria)
      icao24: 452179 · position: (42.1345, -3.9242) · alt: 10668m · 760km/h
  - (2026-10-25) JAF2HE (Bulgaria)
      icao24: 452135 · position: (40.2633, -5.1077) · alt: 10668m · 833km/h
  - (2026-10-25) JAF2JT (Belgium)
      icao24: 44d1b4 · position: (50.8943, 4.5032) · on ground · 112km/h
  - (2026-10-25) JAF34G (Belgium)
      icao24: 44d1c2 · position: (40.1174, 9.2103) · alt: 11582m · 732km/h
  - (2026-10-25) BAF648 (Belgium)
      icao24: 44f686 · position: (43.2024, 0.2284) · alt: 2948m · 471km/h
  - (2026-10-25) NCR4859 (United States)
      icao24: a7488c · position: (38.9794, -77.5176) · alt: 10363m · 1033km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 57 total
  - (2026-10-25) [The Hacker News] OpenAI AI Agents Demonstrate VM Escapes and Secret Cross-Sandbox Communication
      OpenAI has announced plans to conduct frontier model training with no live internet access, as it resumes reinforcement learning (RL) training and internal inference of its most advanced AI models. "Based on the current…
  - (2026-10-25) [The Register] Want to build a UK datacenter? Please hold while Whitehall transfers you
      Minister insists responsibilities are clear as construction, telecoms, and energy fall under separate departments
  - (2026-10-25) [The Register] Reg readers land on 'Binface' as name for UK space cleanup mission
      Intergalactic Space Warrior, or a bin in orbit?
  - (2026-10-24) [BleepingComputer] BlackX UEFI bootkit exploits Baton Drop flaw to bypass Secure Boot
      A new UEFI bootkit named BlackX, deployed in an espionage campaign in early 2026, exploited the old Baton Drop vulnerability to bypass Secure Boot and load a malicious driver designed to interfere with security solutions…
  - (2026-10-24) [The Hacker News] Leaked LiteLLM Master Key Let Attackers Steal GitHub Tokens and Hijack Release Pipeline
      LiteLLM on Friday revealed that an Agent Platform master key accidentally published to a public GitHub repository in late May 2026 ultimately allowed the threat actor to push a malicious version of the popular Python pac…
  - (2026-10-24) [The Hacker News] Google Says Gmail and Photos Data Shared With AI Search Could Be Used for Targeted Ads
      Google has updated its privacy policy to spell out that using personalized artificial intelligence (AI) features in Search or Gemini could allow the company to serve targeted ads to users based on their activity on other…

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-10-25) Will Real Madrid CF win on 2026-10-25?
      yes price: 24% · 24h volume: $1,218,495 · resolves 2026-10-25
  - (2026-10-25) Will FC Barcelona win on 2026-10-25?
      yes price: 62% · 24h volume: $977,236 · resolves 2026-10-25
  - (2026-10-25) 2026 Balance of Power: R Senate, R House
      yes price: 8% · 24h volume: $840,461 · resolves 2026-11-04
  - (2026-10-25) Dota 2: Team Liquid vs OG - Game 2 Winner
      yes price: 100% · 24h volume: $638,760 · resolves 2026-10-25
  - (2026-10-25) Counter-Strike: BetBoom Team vs Nemiga (BO3) - PGL Masters Bucharest Group Stage
      yes price: 82% · 24h volume: $638,562 · resolves 2026-10-25
  - (2026-10-25) Counter-Strike: Vitality vs TheMongolz (BO3) - PGL Masters Bucharest Group Stage
      yes price: 100% · 24h volume: $541,804 · resolves 2026-10-25

### Paper Trading Scorecard — 11 new of 63 total
  - (2026-10-25) [Manifold] Daily Coinflip
  - (2026-10-25) [Manifold] Will the address for math.eg.rego.re receive more than $50 before Nov 1 UTC?
  - (2026-10-25) [Manifold] Will Vivek Ramaswamy pull the Amy Acton mother ad? [Polymarket]
  - (2026-10-25) [Manifold] Do you like 31% odds?
  - (2026-10-25) [Manifold] Will Lula win the October 25, 2026 presidential runoff in Brazil?
  - (2026-10-25) [Manifold] Will the first commercially successful personal robot use legs?

### World News (by country, top stories) — 6 new of 6 total
  - (2026-10-25) [Ukraine] 🇽🇰 Kosovo : Broadcast Junior Eurovision for the First Time Since 2013
      eurovoix.com · English
  - (2026-10-25) [Ukraine] Drones Hit Omsky Kauchuk Deep in Russia , Belgorod Targeted
      kyivpost.com · English
  - (2026-10-25) [Ukraine] Ukraine , Russia Agree Ceasefire Timetable for Oleshky Mission
      kyivpost.com · English
  - (2026-10-25) [Ukraine] Rubio Defends Trump Diesel Sanctions Relief as Very Wise
      kyivpost.com · English
  - (2026-10-25) [Ukraine] Sikorski Says Russia Running Out of Resources if Ukraine Survives Winter
      kyivpost.com · English
  - (2026-10-25) [Ukraine] 4 Killed in Synelnykove Strike , Rescuers Hit in Kharkiv
      kyivpost.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 102 total
  - (2026-10-25) [USASpending] $22,657,326,734 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-10-25) [USASpending] $3,549,243,793 → SPACE EXPLORATION TECHNOLOGIES CORP.: IGF::OT::IGF THE COMMERCIAL CREW PROGRAM (CCP) COMMERCIAL CR
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF THE COMMERCIAL CREW PROGRAM (CCP) COMMERCIAL CREW TRANSPORTATION CAPABILITY (CCTCAP) CONTRACT WILL PROVIDE COMPLETION OF THE DESIGN, DEVELO…
  - (2026-10-25) [USASpending] $2,753,683,081 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2026-10-25) [USASpending] $2,226,122,975 → THE TRUSTEES OF PRINCETON UNIVERSITY: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE P
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE PRINCETON PLASMA PHYSICS LABORATORY (PPPL)
  - (2026-10-25) [USASpending] $725,122,279 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-10-23) U.S. Court of Appeals, 4th Cir.: South Carolina Coastal Conservation League v. United States Army Corps of Engineers
  - (2026-10-23) Alaska Supreme Court: Beachcomber, LLC v. Bilben
  - (2026-10-19) U.S. Court of Appeals, 11th Cir.: Pen American Center, Inc. v. Kevin Adams
  - (2026-10-19) D.C. Court of Appeals: Amended Judgment: Allen v. Whitehead
  - (2026-10-19) U.S. Court of Appeals, 4th Cir.: United States v. Andrew Chafin

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-25) [Marginal Revolution] The Panic Patrol
      The Panic Patrol, a division of the department of future corrections, reminds us of past panics. Here’s one case in point I wasn’t aware of: The post The Panic Patrol appeared first on Marginal REVOLUTION.
  - (2026-10-25) [Marginal Revolution] Facts about breastfeeding
      We produce a numerical estimate of the value of unpaid breastfeeding relative to national income spanning five centuries and integrating historical and bioarchaeological data. The relative economic contribution of matern…
  - (2026-10-25) [Marginal Revolution] How central bankers spend their time
      How leaders allocate their limited time and attention is an important question in economics. This paper constructs and analyzes a novel data set covering the daily calendars of three Federal Reserve Chairs, Ben Bernanke,…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=15, 14d-median=22; carrying terms: enforcement, action, proposing, certain, proposed, protection, regulatory, final, procedures, control, safety, document
- state_bills: today=55, 7d-median=108, 14d-median=108; carrying terms: alaska, district, administration, school, providing, relating, state, education, provides, january, funds, specified
- state_news: today=423, 7d-median=678, 14d-median=678; carrying terms: people, pressure, economy, because, maine, dcist, earlier, available, midterm, ruling, recently, funds
- local_news: today=211, 7d-median=238, 14d-median=235; carrying terms: people, atlanta, georgia, police, crash, child, dining, arrested, constitution, stlmag, target, brings
- foreign_news: today=960, 7d-median=1011, 14d-median=1011; carrying terms: people, pressure, yemen, clash, presidential, ddeutsche, defense, midterm, police, ruling, funds, indian
- chinese_internal: today=261, 7d-median=270, 14d-median=282; carrying terms: cbmiykfvx, google, chinese, china, cbmibefvx, cbmiakfvx, cbmickfvx, investors, title, articles, cbmizefvx, cbmia
- russian_internal: today=871, 7d-median=1010, 14d-median=1019; carrying terms: telegram, europe, httperror, politico, https, gazeta, times, novaya, server, reuters, raquo, russian
- ukrainian_internal: today=130, 7d-median=136, 14d-median=134; carrying terms: people, since, europe, presidential, earlier, defense, patriot, starlink, infrastructure, missile, poland, client
- ukraine_theater: today=392, 7d-median=413, 14d-median=398; carrying terms: people, fvewdvdzrjowzlbvbzvnhhuhp, sxakj, xyxpnn, nitzvfyvblsk, fagjabznox, botanical, yemen, dptnb, cbmiigfbvv, bvzbzkhiek, methodius
- paper_bets: today=63, 7d-median=66, 14d-median=68; carrying terms: kalshi, leaders, mamdani, israel, chair, derrick, chase, koivun, labor, starts, leave, yards
- weather: today=149, 7d-median=138, 14d-median=138; carrying terms: pressure, dangerous, baltimore, outlook, capsize, details, weekend, hazardous, flood, afdlsx, mountains, statement
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: effective, jtsjol, commodities, personal, cpilfesl, consumption, unemployment, sheet, recession, nonfarm, unrate, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, commodities, corporate, close, large, futures, natural, credit, crude, china, treasury, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=102, 7d-median=105, 14d-median=107; carrying terms: unauthorised, lockheed, acronym, research, yemen, specific, concerning, licenses, bissau, adopted, laboratory, systems
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, congresstrading, quiverquant, quantitative, quiver, httperror, error, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, board, state, supreme, court, trade, delaware, blanche, international, arkansas, alabama, company
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, holdings, robert, jonathan, natera, estate, technologies, bluerock, holding
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, krishnamoorthi, david, committee, james, house, talarico, booker, trone, angels, elect, cortez
- gdelt_regions: today=6, 7d-median=12, 14d-median=10; carrying terms: english
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, israel, keywords, security, world
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=17, 7d-median=23, 14d-median=28; carrying terms: position, bulgaria, belgium, ground, france, kingdom, germany, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: increasing, addition, seven, situation, representing, result, includ, since, natural, phase, children, increasingly
- cisa_kev: today=17, 7d-median=17, 14d-median=15; carrying terms: vendor, command, vulnerability, remediation, control, server, injection, cisco, traversal, product, improper, fortinet
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: guinea, earthquake, typhoon, islands, impact, indonesia, maximum, speed, forestfire, magnitude, forest, cyclone
- usgs_quakes: today=29, 7d-median=23, 14d-median=21; carrying terms: depth, russia, indonesia, philippines, vanuatu, guinea, papua, region, alaska, islands, japan, china
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, october, price, presidential, volume, brazilian, election, bolsonaro, rates, meeting, interest, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, economist, https, revolution, marginal, conversable, government, world, economic, money, economists, recession
- tech_news: today=57, 7d-median=57, 14d-median=58; carrying terms: research, according, systems, cybersecurity, infrastructure, software, today, researchers, power, computerweekly, record, download
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: tammy, mitch, powell, gabbard, william, derrick, mannion, susan, jamieson, atlanta, carbajal, jamie
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, decision, markets, converges, consensus, either, evidence, sufficient, placed, paper, identify, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-17] ECB press: Christine Lagarde: IMFC Statement
- [2026-10-19] ECB press: Frank Elderson: From climate and nature risks to economic resilience and competitiveness
- [2026-10-20] ECB press: Frank Elderson: Interview with Die Presse
- [2026-10-21] ECB press: Philip R. Lane: Euro liquidity lines and the international monetary system
- [2026-10-21] ECB press: Piero Cipollone: Pontes and Appia: unlocking opportunities for banks
- [2026-10-23] ECB press: ECB Consumer Expectations Survey results – September 2026
- [2026-10-24] ECB press: Piero Cipollone: Interview with Milano Finanza

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*