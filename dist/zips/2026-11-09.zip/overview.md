# WORLDSCOPE morning brief — 2026-11-09

## Headline
3050 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (779) · Russian Internal News (state + in-exile) (646) · World leaders & government officials (324) · Chinese Internal News (247) · Local News: St. Louis + Atlanta (188) · State-Level News (184) · U.S. Weather + Severe / Climate Outlooks (157) · Ukraine Theater (total-war monitoring) (74) · Ukrainian Internal News (national + local Kyiv) (71) · GDACS — global disaster alerts (53) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 779 new of 976 total
  - (2026-11-09) [Global] 'Sexual predator' Russell Brand jailed for 10 years for rape, assault
      British comedian and TV star Russell Brand was Monday jailed for more than 10 years for a string of sex offences including rape as the judge told him he had been a "sexual predator" whose fame had protected him.
  - (2026-11-09) [Global] COP31 climate summit: Can we electrify the world?
      The UN's annual climate change summit, known as COP31, opens this Monday in Turkey amid deep concern following deadly heatwaves in Europe and deadly floods in Nepal. A "super El Niño" in the Pacific is also expected to d…
  - (2026-11-09) [Global] 'Such an extraordinary story': What we know so far about Nvidia spying claims
      Shares of artificial intelligence leader Nvidia tumbled early Monday after the chip company said it launched an investigation of CEO Jensen Huang following reports he was targeted by Chinese intelligence. The internal pr…
  - (2026-11-09) [Global] Spain's right holds poll lead over Sanchez's Socialists ahead of November 29 snap election
      Spain's ruling Socialists have narrowed the gap but continue to trail the conservative People's Party, who would need to team up with the far-right Vox party to secure a majority of seats in parliament, pollsters say wit…
  - (2026-11-09) [Global] Russian network used social media to blame French riots on immigration, EU report says
      An internal EU assessment has uncovered a Russian network that aimed to exploit ​last month's riots in France by using social media to blame the unrest on uncontrolled immigration. The assessment, seen by Reuters, offers…
  - (2026-11-09) [Global] Melanie C: From Sporty Spice to dance DJ with 'Sweat'
      Melanie Chisholm rose to fame in the 1990s with one of the world's biggest girl bands: the Spice Girls. "Melanie C", "Mel C" and "Sporty Spice" were her nicknames. She went on to have a successful solo career with severa…

### Russian Internal News (state + in-exile) — 646 new of 816 total
  - (2026-11-09) Правительство РФ разрешило продавать клотримазол и ибупрофен в почтовых отделениях | LEDE: Правительство России утвердило список лекарственных препаратов, которые можно будет продавать в поч] (ru: Пра…
      Правительство России утвердило список лекарственных препаратов, которые можно будет продавать в почтовых отделениях, сообщает «Фармацевтический вестник».
  - (2026-11-09) Одного из задержанных во время рейда на Китай-городе арестовали на 13 суток. Его обвинили в неповиновении полиции | LEDE: Таганский суд Москвы назначил 13 суток административного ареста 21-л] (ru: Одн…
      Таганский суд Москвы назначил 13 суток административного ареста 21-летнему местному жителю по обвинению в неповиновении требованию сотрудников полиции (статья 19.3 КоАП), сообщают «Осторожно, новости».
  - (2026-11-09) Британского комика Рассела Брэнда приговорили к 10 годам тюрьмы за изнасилование и домогательства | LEDE: Королевский суд лондонского района Саутуарк приговорил актера и стендапера Рассела Б] (ru: Бри…
      Королевский суд лондонского района Саутуарк приговорил актера и стендапера Рассела Брэнда к 10 годам и шести месяцам лишения свободы по обвинению в изнасиловании и домогательствах.
  - (2026-11-09) Война. 1720-й день. В Абу-Даби пройдут переговоры о мире между Россией и Украиной при участии США. Что о них известно | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о ро] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-11-09) Компания из Пензы пообещала в день выхода GTA VI дать выходной всем сотрудникам, которые хотят поиграть | LEDE: Пензенская компания Benza, занимающаяся производством оборудования для АЗС, по] (ru: Ком…
      Пензенская компания Benza, занимающаяся производством оборудования для АЗС, пообещала дополнительный выходной своим сотрудникам в день выхода игры GTA VI.
  - (2026-11-09) Евросоюз подал в суд на IBM из-за проблем с системой пограничного контроля. Ее запуск вызвал нарушения в работе аэропортов 15 стран | LEDE: Евросоюз подал в суд на американскую компанию IBM,] (ru: Евр…
      Евросоюз подал в суд на американскую компанию IBM, французскую Atos и итальянскую Leonardo в связи с разработкой системы пограничного контроля (Entry/Exit System, EES), сообщает Financial Times 9 ноября.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 247 new of 291 total
  - (2026-11-09) Beijing Slams Nvidia ‘Spy’ Claims as CEO Jensen Huang Admits to Affair - Caixin Global
      Beijing Slams Nvidia ‘Spy’ Claims as CEO Jensen Huang Admits to Affair Caixin Global
  - (2026-11-09) China Adopts Cross-Border Anti-Corruption Law, Mandates Corporate Compliance - Caixin Global
      China Adopts Cross-Border Anti-Corruption Law, Mandates Corporate Compliance Caixin Global
  - (2026-11-09) In Profile: How a Pioneering TV Host Built a Cosmetics Brand for Chinese Women - Caixin Global
      In Profile: How a Pioneering TV Host Built a Cosmetics Brand for Chinese Women Caixin Global
  - (2026-11-09) China Extends Gold-Buying Streak to Two Years Despite Falling Prices - Caixin Global
      China Extends Gold-Buying Streak to Two Years Despite Falling Prices Caixin Global
  - (2026-11-09) Opinion: Building a Virtuous Cycle Between Consumption and Investment - Caixin Global
      Opinion: Building a Virtuous Cycle Between Consumption and Investment Caixin Global
  - (2026-11-09) Business Brief (Nov. 9): China Moves to Stabilize Stock Markets - Caixin Global
      Business Brief (Nov. 9): China Moves to Stabilize Stock Markets Caixin Global

### Local News: St. Louis + Atlanta — 188 new of 222 total
  - (2026-11-09) [St. Louis] The Ritz-Carlton St. Louis expands its dining lineup with a new Wine Room and chef’s counter
      Beginning this fall, The Ritz-Carlton, St. Louis (100 Carondelet Plaza) is giving diners new reasons to make a night of it. The lineup includes a newly renovated Wine Room tucked behind the hotel’s main kitchen, a six-se…
  - (2026-11-09) [St. Louis] Top family-friendly events this week in St. Louis
      St. Louis Kids Book Club | November 12Get into the Thanksgiving spirit with a little storytime! This month’s St. Louis Kids Book Club is reading Balloons Over Broadway: The True Story of the Puppeteer of Macy’s Parade by…
  - (2026-11-09) [St. Louis] What to see at the 2026 Flyover Comedy Festival
      The Flyover Comedy Festival returns this week for its ninth year, this time taking over the Delmar Loop, the Improv Shop, and more from November 11-15. This year’s festival features exciting performers such as David Cros…
  - (2026-11-09) [St. Louis] Lou’s Clues – 11/9/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-11-09) [St. Louis] Gold couriers who helped swindle the elderly will be in court in St. Louis today
      Two couriers who allegedly transported gold bars swindled from elderly victims will be at the federal courthouse in St. Louis today, where they will become the latest to be arraigned on charges related to a conspiracy th…
  - (2026-11-09) [St. Louis] Your favorite Procter & Gamble household supplies were probably made in St. Louis
      If your daily routine has you loading the dishwasher, there’s a good chance your detergent was made right here in St. Louis, at Procter & Gamble’s 17-acre manufacturing campus in the Near North Riverfront neighborhood. T…

### State-Level News — 184 new of 292 total
  - (2026-11-09) [Alaska] Veterans Small Business Week 2026
      WHEREAS, from Main Street storefronts to high-tech startups, over 1.6 million veteran-owned small businesses across the United States stand as pillars of our economy and greatly contribute to the success and wellbeing of…
  - (2026-11-09) [Alaska] Women Veterans Day 2026
      WHEREAS, women have served honorably and courageously in every war and conflict of the United States since the American Revolution, yet their service was traditionally left unrecognized; and WHEREAS, permanent military s…
  - (2026-11-09) [Alabama] New nonprofit aims to explain data centers’ effects on local communities
  - (2026-11-09) [Alabama] Alabama leaders react to Trump naming Stephen Miller as Chief of Staff
  - (2026-11-09) [Alabama] Alabama Republicans held power. Their margin for error shrank
  - (2026-11-09) [Alabama] A fair trial is owed even to a judge accused of denying one

### U.S. Weather + Severe / Climate Outlooks — 157 new of 159 total
  - (2026-11-09) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-09) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued November 9 at 7:41AM PST until November 10 at 12:00PM PST by NWS Los Angeles/Oxnard CA
      * WHAT...Dangerous rip currents and breaking waves due to elevated surf up to 4 to 6 feet expected. Minor tidal overflow possible during morning high tides, especially across west facing beaches. * WHERE...Santa Barbara…
  - (2026-11-09) [Severe] Flood Warning: Flood Warning issued November 9 at 9:39AM CST until November 10 at 5:00AM CST by NWS Quad Cities IA IL
      ...The Flood Warning continues for the following rivers in Iowa... Iowa River at Marengo affecting Benton and Iowa Counties. * WHAT...Minor flooding is occurring. * WHERE...Iowa River at Marengo. * WHEN...Until late toni…
  - (2026-11-09) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 9 at 7:01AM PST until November 9 at 9:00AM PST by NWS San Francisco CA
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...San Francisco and San Francisco Bay Shoreline. * WHEN...Until 9 AM PST this morning. * IMPACTS...Hazardous driving conditions due to low visibility.
  - (2026-11-09) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 9 at 7:01AM PST until November 9 at 9:00AM PST by NWS San Francisco CA
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...North Bay Interior Valleys. * WHEN...Until 9 AM PST this morning. * IMPACTS...Hazardous driving conditions due to low visibility.
  - (2026-11-09) [Moderate] Gale Warning: Gale Warning issued November 9 at 5:52AM AKST until November 10 at 6:00PM AKST by NWS Juneau AK
      * WHAT...For the Storm Warning, southeast winds 35 to 55 kt with gusts up to 70 kt and seas 26 to 31 ft expected. For the first Gale Warning, southeast winds 35 to 45 kt with gusts up to 65 kt and seas 24 to 29 ft expect…

### Ukraine Theater (total-war monitoring) — 74 new of 271 total
  - (2026-11-09) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-07) [Liveuamap] Overnight, Russia launched multiple Iskander-M, Tsirkon, KN-23 and S-400 ballistic missiles, along with 172 attack drones of various types, according to the Ukrainian Air Force – Kyiv, Kyi…
      Overnight, Russia launched multiple Iskander-M, Tsirkon, KN-23 and S-400 ballistic missiles, along with
  - (2026-11-06) [Liveuamap] Several ballistic missiles were launched towards Kyiv region – Kyiv,Kyiv city - Liveuamap
      Several ballistic missiles were launched towards Kyiv region – Kyiv,Kyiv city Liveuama
  - (2026-11-06) [Liveuamap] Explosion was reported in Samar – Dnipropetrovsk Oblast, Ukraine - Liveuamap
      Explosion was reported in Samar – Dnipropetrovsk Oblast, Ukraine Liveuamap
  - (2026-11-09) [Liveuamap] At Pokrovsk direction clashes yesterday near Serhiyivka, Molodetske, Vilne, Dobropillya, Novofedorivka, - General Staff of Armed Forces of Ukraine reports – Donetsk Oblast, Ukraine - Liveu…
      At Pokrovsk direction clashes yesterday near Serhiyivka, Molodetske, Vilne, Dobropillya, Novofedorivka, - General Staff of Armed
  - (2026-11-09) [Liveuamap] At Kostiantynivka direction clashes yesterday near Kostyantynivka, Novoselivka, Mykolaypillya, - General Staff of Armed Forces of Ukraine reports – Donetsk Oblast, Ukraine - Liveuamap
      At Kostiantynivka direction clashes yesterday near Kostyantynivka, Novoselivka, Mykolaypillya, - General Staff of Armed Forces o

### Ukrainian Internal News (national + local Kyiv) — 71 new of 134 total
  - (2026-11-09) Спецпредставники Трампа проведуть зустріч з європейськими представниками перед перемовинами в Абу-Дабі | LEDE: Спецпредставники американського президента Дональда Трампа – Джаред Кушнер та Стів] (uk:…
      Спецпредставники американського президента Дональда Трампа – Джаред Кушнер та Стів Віткофф – проведуть зустріч з європейськими представниками перед початком тристоронніх перемовин Україна-США-Росія в Абу-Дабі.
  - (2026-11-09) Мерц пригрозив заблокувати бюджет ЄС без згоди всіх країн фінансувати Україну – FT | LEDE: Канцлер Німеччини Фрідріх Мерц пов'язав схвалення Берліном бюджету ЄС на 2028–2034 роки із зобов'язанн] (uk:…
      Канцлер Німеччини Фрідріх Мерц пов'язав схвалення Берліном бюджету ЄС на 2028–2034 роки із зобов'язанням усіх держав-членів фінансово підтримувати Україну у 2027 році та надалі.
  - (2026-11-09) 41 випадок за перші 9 місяців 2026: в які країни Європи найчастіше залітали дрони – інфографіка | LEDE: ] (uk: 41 випадок за перші 9 місяців 2026: в які країни Європи найчастіше залітали дрон)
  - (2026-11-09) Як часто дрони порушували повітряний простір Європи у 2026 році: інфографіка | LEDE: З початку 2026 року безпекова ситуація в Європі стала особливо напруженою: дрони дедалі частіше порушують по] (uk:…
      З початку 2026 року безпекова ситуація в Європі стала особливо напруженою: дрони дедалі частіше порушують повітряний простір країн регіону. На початку жовтня Єврокомісія навіть виділила додаткові 130 мільйонів євро держа…
  - (2026-11-09) 7 корпус ДШВ: На Гуляйпільському напрямку окупанти втричі частіше штурмують, почали ходити по одному | LEDE: Кількість штурмів на Гуляйпільському напрямку зросла у жовтні втричі. Окупанти зміню] (uk:…
      Кількість штурмів на Гуляйпільському напрямку зросла у жовтні втричі. Окупанти змінюють тактику через вогневі втрати Сил оборони.
  - (2026-11-09) Росіяни з безпілотника атакували Харків: постраждали 5 людей, дитина – в реанімації | LEDE: Унаслідок удару дрона росіян по Харкову постраждали 2-річний хлопчик і дві жінки, пошкоджено п’ять ав] (uk:…
      Унаслідок удару дрона росіян по Харкову постраждали 2-річний хлопчик і дві жінки, пошкоджено п’ять авто та магазин.

### GDACS — global disaster alerts — 53 new of 100 total
  - (2026-11-09) [Green] Earthquake in Mid-Indian Ridge
      Earthquake · Green alert · Mid-Indian Ridge · Magnitude 4.9M, Depth:10km
  - (2026-11-09) [Green] Earthquake in Turkey
      Earthquake · Green alert · Turkey · Magnitude 4.7M, Depth:10km
  - (2026-11-09) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.7M, Depth:98.292km
  - (2026-11-09) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.3M, Depth:11.49km
  - (2026-11-09) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.8M, Depth:10km
  - (2026-11-09) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.4M, Depth:10km

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-09) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-11-09 16:21 UTC — Filed: 2026-11-09 AccNo: 0001918704-26-035020 Size: 324 KB
  - (2026-11-09) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-11-09 16:21 UTC — Filed: 2026-11-09 AccNo: 0001839882-26-055649 Size: 548 KB
  - (2026-11-09) [Gonzalez Matt] Form 4 (Reporting)
      filed 2026-11-09 16:21 UTC · role: Reporting — Filed: 2026-11-09 AccNo: 0001171200-26-000021 Size: 7 KB
  - (2026-11-09) [Marygold Companies, Inc.] Form 4 (Issuer)
      filed 2026-11-09 16:21 UTC · role: Issuer — Filed: 2026-11-09 AccNo: 0001171200-26-000021 Size: 7 KB
  - (2026-11-09) [Harris Joya] Form 4 (Reporting)
      filed 2026-11-09 16:20 UTC · role: Reporting — Filed: 2026-11-09 AccNo: 0001171200-26-000020 Size: 4 KB
  - (2026-11-09) [Marygold Companies, Inc.] Form 4 (Issuer)
      filed 2026-11-09 16:20 UTC · role: Issuer — Filed: 2026-11-09 AccNo: 0001171200-26-000020 Size: 4 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-09) [India] Rape - murder accused killed in police firing , fourth case in West Bengal since BJP came to power
      domain: hindustantimes.com · language: English · tone:
  - (2026-11-09) [India] Parliament Monsoon Session Remains Unprorogued For Record 88 Days
      domain: dailyexcelsior.com · language: English · tone:
  - (2026-11-09) [United States] U2 Defends Macklemore Amid Ed Sheeran Tour Controversy Over Political Expression
      domain: 931thebeat.com · language: English · tone:
  - (2026-11-09) [Egypt] Karl Mattar The Weather of the World Documents Wartime Beirut
      domain: cairoscene.com · language: English · tone:
  - (2026-11-09) [United States] Trump says Vance was right that Iran war cost GOP midterms
      domain: inquisitr.com · language: English · tone:
  - (2026-11-09) [Israel] Farmers fight to adapt as droughts loom in COP31 host Turkey
      domain: al-monitor.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 61 total
  - (2026-11-09) [BleepingComputer] Binance denies data breach after alleged ShinyHunters claims
      Binance, the world's largest crypto exchange, has denied claims of a new security breach made by a threat actor using the 'ShinyHunters' handle on a newly emerged underground cybercrime forum. [...]
  - (2026-11-09) [BleepingComputer] Hackers exploit SSHole OpenSSH flaw to breach Linux systems
      Hackers are actively exploiting the "SSHole" vulnerability (CVE-2026-123158) in OpenSSH to execute commands, steal credentials, and establish persistent access. [...]
  - (2026-11-09) [BleepingComputer] The Biggest Threat to Your GRC Job Isn’t AI. It’s Ignoring AI.
      AI agents are taking over routine governance, risk, and compliance tasks, forcing GRC professionals to rethink the skills needed to stay relevant. Anecdotes examines three essential skills for the AI-driven GRC workplace…
  - (2026-11-09) [BleepingComputer] FBI agent stole $2.5 million in crypto from hackers under investigation
      A former FBI agent has pleaded guilty to stealing nearly $2.5 million from the wallets of fraud victims and nation-state hackers under investigation. [...]
  - (2026-11-09) [BleepingComputer] US bans MEXC crypto exchange over sanctions evasion, cybercrime links
      The US Department of the Treasury has cut off the MEXC Global crypto exchange from the US financial system over sanctions evasion and links with cybercrime gangs. [...]
  - (2026-11-09) [The Hacker News] Bitter Hackers Deploy New PapRAT Backdoor in Cyberespionage Campaign Targeting South Asia
      The South Asian cyber espionage group known as Bitter (aka APT-C-08, APT-Q-37, Hazy Tiger, Orange Yali, T-APT-17, and TA397) has been observed targeting South Asian organizations with a previously unreported remote acces…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-11-09) JAF94P (Bulgaria)
      icao24: 4520ce · position: (40.078, 5.2642) · alt: 11582m · 972km/h
  - (2026-11-09) PAT236 (United States)
      icao24: adfee0 · position: (39.6973, -104.6762) · alt: 7307m · 419km/h
  - (2026-11-09) CFC3373 (Canada)
      icao24: c2b37d · position: (43.9751, -97.4298) · alt: 8221m · 763km/h
  - (2026-11-09) SAMU71 (France)
      icao24: 398c4e · position: (46.836, 4.7863) · alt: 609m · 229km/h
  - (2026-11-09) PAT060 (United States)
      icao24: adfe4b · position: (47.2899, -121.6758) · alt: 5433m · 394km/h
  - (2026-11-09) PAT422 (United States)
      icao24: adfe53 · position: (43.1196, -100.6059) · alt: 7315m · 393km/h

### Paper Trading Scorecard — 27 new of 78 total
  - (2026-11-09) [Polymarket] Will Gavin Newsom announce a Presidential run before 2027?
      This market will resolve to “Yes” if the listed individual officially announces that they are running for U.S. President in the 2028 United States presidential election by December 31, 2026, 11:59 PM ET. Otherwise, this…
  - (2026-11-09) [Polymarket] Will an international court find Israel or its leaders guilty of Genocide by December 31, 2027?
      This market will resolve to "Yes" if he International Criminal Court ("ICC"), the International Court of Justice ("ICJ"), or any ad hoc international tribunal with recognized legal standing, issues a judgment or convicti…
  - (2026-11-09) [Polymarket] Epic Games IPO before 2027?
      This market will resolve to "Yes" if the listed company completes an Initial Public Offering (IPO) by December 31, 2026, 11:59 PM ET, as confirmed by official company announcements or credible news sources. The IPO refer…
  - (2026-11-09) [Polymarket] Will Xi Jinping be the next leader out before 2027?
      This market will resolve according to the first listed individual who ceases to occupy their listed office. An announcement of a resignation/removal, or a scheduled departure from office due to the outcome of an election…
  - (2026-11-09) [Polymarket] Will Scott Jennings be the next White House Press Secretary?
      This market will resolve according to the next individual who the White House announces has been picked to be the White House Press Secretary who replaces Katie Zacharia by December 31, 2027, 11:59 PM ET. A person being…
  - (2026-11-09) [Polymarket] Will Ethereum reach $2,350 on November 9?
      This market will immediately resolve to "Yes" if any Binance 1-minute candle for Ethereum (ETH/USDT) on the date specified in the title, between 12:00 AM ET and 11:59 PM ET has a final "High" price equal to or greater th…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-11-09) [Israel-Iran-Hezbollah axis · keywords] What did RFK Jr . former advisor say about Trump administration
      themarysue.com · English · tone NA
  - (2026-11-09) [Israel-Iran-Hezbollah axis · keywords] Exclusive - Covert Russian network exploited French riots on social media , EU report says
      internazionale.it · English · tone NA
  - (2026-11-09) [Israel-Iran-Hezbollah axis · keywords] Explainer : Can Eisenkot form Israeli govt after getting mandate ?-- China Economic Net
      en.ce.cn · English · tone NA
  - (2026-11-09) [Israel-Iran-Hezbollah axis · keywords] Israel President Tasks Eisenkot With Forming New Government
      algemeiner.com · English · tone NA
  - (2026-11-09) [Israel-Iran-Hezbollah axis · keywords] Arab News | Trump asked Netanyahu to move on Gaza peace plan in post - election call – Axios
      arabnews.com · English · tone NA
  - (2026-11-09) [Israel-Iran-Hezbollah axis · keywords] An era of Zionism , solidarity , friendship : Eisenkot after he receives mandate to form Israel next govt
      arabherald.com · English · tone NA

### U.S. Federal Action — 23 new of 25 total
  - (2026-11-09) Television Broadcasting Services Odessa, Texas
      This document proposes to amend the Table of TV Allotments (Table) of the Federal Communications Commission's (Commission) rules in response to a petition for rulemaking filed by Gray Television Licensee, LLC (Gray), the…
  - (2026-11-09) Security Zones; Protection of Military Cargo, Captain of the Port Zone Puget Sound, WA
      The Coast Guard will enforce security zones for the Protection of Military Cargo from November 8 through November 12, 2026, to provide for the security of life and vessels on navigable waterways during this event. Our re…
  - (2026-11-09) Amendment of Class D and Establishment of Class E Airspace; Chandler and Phoenix, AZ
      This action corrects a final rule published by the FAA in the Federal Register on October 30, 2026, amending the Class D airspace and establishing Class E airspace at Chandler and Phoenix, AZ. Specifically, this action c…
  - (2026-11-09) Pecans Grown in the States of Alabama, Arkansas, Arizona, California, Florida, Georgia, Kansas, Louisiana, Missouri, Mississippi, North Carolina, New Mexico, Oklahoma, South Carolina, and Texas; Chang…
      This proposed rule would implement recommendations from the American Pecan Council (Council) to eliminate regional and size designations for sheller members, modify the nomination process for sheller members, adjust the…
  - (2026-11-09) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain The Boeing Company Model 787-8, 787-9, and 787-10 airplanes. This AD was prompted by reports that the low range radio altimeter (LRRA) system has an incr…
  - (2026-11-09) Pacific Island Fisheries; Commercial Fishing in the Pacific Remote Islands Marine National Monument Expansion
      NMFS proposes to amend regulations that prohibit commercial fishing in the Pacific Remote Islands Marine National Monument Expansion (PRIMNM Expansion), which comprises waters of the U.S. exclusive economic zone (EEZ) be…

### Prediction Markets — most-traded (Polymarket) — 19 new of 20 total
  - (2026-11-09) Will the U.S. invade Iran before 2027?
      yes price: 10% · 24h volume: $677,656 · resolves 2027-01-01
  - (2026-11-09) US announces end of Iranian blockade by November 15, 2026?
      yes price: 5% · 24h volume: $473,362 · resolves 2026-11-16
  - (2026-11-09) Spread: Bills (-3.5)
      yes price: 48% · 24h volume: $431,866 · resolves 2026-11-10
  - (2026-11-09) Will the US confirm that aliens exist before 2027?
      yes price: 2% · 24h volume: $416,079 · resolves 2027-01-01
  - (2026-11-09) Israel x Iran ceasefire continues through November 15?
      yes price: 94% · 24h volume: $397,798 · resolves 2026-11-16
  - (2026-11-09) US announces end of Iranian blockade by November 30, 2026?
      yes price: 22% · 24h volume: $386,200 · resolves 2026-12-01

### State Legislative Action — 18 new of 37 total
  - (2026-11-07) [District of Columbia B 26-0822] Understanding the Cost of Housing Regulations Act of 2026
      Understanding the Cost of Housing Regulations Act of 2026
  - (2026-11-07) [District of Columbia B 26-0819] Ownership and Wealth-building for our Neighbors (OWN) Omnibus Amendment Act of 2026
      Ownership and Wealth-building for our Neighbors (OWN) Omnibus Amendment Act of 2026
  - (2026-11-07) [District of Columbia B 26-0820] Affordable Housing Tax Assessment Alignment Act of 2026
      Affordable Housing Tax Assessment Alignment Act of 2026
  - (2026-11-07) [District of Columbia B 26-0829] Shared Housing Agreements and Resolution Effort Pilot Program Amendment Act of 2026
      Shared Housing Agreements and Resolution Effort Pilot Program Amendment Act of 2026
  - (2026-11-07) [District of Columbia B 26-0597] Housing Production Omnibus Amendment Act of 2026
      Housing Production Omnibus Amendment Act of 2026
  - (2026-11-07) [District of Columbia B 26-0495] Condominium Insurance Amendment Act of 2025
      Condominium Insurance Amendment Act of 2025

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-11-09) M 6.4 - 30 km WSW of Lata, Solomon Islands
      M6.4 · 30 km WSW of Lata, Solomon Islands · depth 17 km
  - (2026-11-09) M 5.7 - 106 km ENE of Hasaki, Japan
      M5.7 · 106 km ENE of Hasaki, Japan · depth 24.173 km
  - (2026-11-09) M 5.4 - 160 km E of Masohi, Indonesia
      M5.4 · 160 km E of Masohi, Indonesia · depth 10 km
  - (2026-11-09) M 5.3 - 80 km ENE of Lagunas, Peru
      M5.3 · 80 km ENE of Lagunas, Peru · depth 11.49 km
  - (2026-11-09) M 5.1 - south of the Fiji Islands
      M5.1 · south of the Fiji Islands · depth 535.494 km
  - (2026-11-09) M 4.9 - Mid-Indian Ridge
      M4.9 · Mid-Indian Ridge · depth 10 km

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-08) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046774
  - (2026-11-08) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046755
  - (2026-11-08) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046772
  - (2026-11-08) [FRQ] CLIMER FOR CONGRESS
      cycle 2026 · filing #
  - (2026-11-08) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046756
  - (2026-11-08) [FRQ] BLACK & VEATCH POLITICAL ACTION COMMITTEE (BLACK & VEATCH PAC)
      cycle 2026 · filing #

### Court opinions of consequence (federal & state) — 4 new of 60 total
  - (2026-11-09) U.S. Court of Appeals, 8th Cir.: Wilbur-Ellis Company LLC v. Cody Downing
  - (2026-11-06) Alaska Supreme Court: State v. Albertsons Companies, Inc
  - (2026-11-02) U.S. Court of Appeals, 10th Cir.: Blum v. CIR
  - (2026-11-02) U.S. Court of Appeals, 10th Cir.: Mostafa v. Blanche

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-11-09) [Marginal Revolution] End the State Veto on Power Lines
      It’s one of the peculiarities of American regulatory history that a natural gas pipeline can cross state lines with a single federal permit, but oil and electricity must run a gauntlet of state approvals. When a power li…
  - (2026-11-09) [Marginal Revolution] The economics of honeypots
      Of course as an economist I am always wondering what the equilibrium is. And, in this case, what is the scarce factor? It seems that in the case under current consideration, the returns to honeypotting are very high for…
  - (2026-11-09) [Marginal Revolution] Seb Krier, Ricardian?
      Here is the initial post. In the comments Michael Wiebe notes: “So progress per R&D dollar fell by 63%, even while progress per year doubled.” File under: David Ricardo, underrated. The post Seb Krier, Ricardian? appeare…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-09) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=25, 14d-median=17; carrying terms: action, safety, certain, commission, regulatory, final, rulemaking, agency, provide, published, flight, necessary
- state_bills: today=37, 7d-median=72, 14d-median=90; carrying terms: vehicle, establishing, relating, review, providing, emergency, insurance, enforcement, person, licensing, office, health
- state_news: today=292, 7d-median=675, 14d-median=675; carrying terms: prices, elections, enforcement, races, management, group, democracy, power, background, history, natural, offices
- local_news: today=222, 7d-median=256, 14d-median=256; carrying terms: election, google, ahead, georgia, atlantamagazine, found, missouri, arrested, friday, house, football, constitution
- foreign_news: today=976, 7d-median=992, 14d-median=992; carrying terms: continue, group, history, strikes, later, strike, things, threats, nigerians, giant, fighting, found
- chinese_internal: today=291, 7d-median=334, 14d-median=294; carrying terms: google, cbmia, cbmiaefvx, lxtfa, cbmiykfvx, blank, title, global, cbmib, cbmix, articles, target
- russian_internal: today=816, 7d-median=938, 14d-median=946; carrying terms: https, istories, telegram, group, reuters, novaya, error, title, gazeta, europe, times, street
- ukrainian_internal: today=134, 7d-median=139, 14d-median=132; carrying terms: elections, power, drones, strikes, toward, attack, european, strike, cabinet, client, warned, including
- ukraine_theater: today=271, 7d-median=269, 14d-median=329; carrying terms: vcluxgmxpzekvotjlstglba, qtknft, continue, rmppemhzdw, cbmilafbvv, cuxpnexctu, mxfpv, xzrodgpnakh, rhitnjzkaec, email, ddnsrzniverxc, lxmgdfegfkrw
- paper_bets: today=78, 7d-median=67, 14d-median=66; carrying terms: human, millennium, colonize, leaders, majors, labor, problem, magnitude, levels, visit, total, goldman
- weather: today=159, 7d-median=103, 14d-median=130; carrying terms: norton, continue, river, holly, result, angeles, afdilx, afdlsx, details, advisory, gusts, rainfall
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: supply, assets, jolts, indicator, balance, dexuseu, crude, nonfarm, dexchus, rates, unemployment, commodities
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, china, range, proxy, russell, large, yield, crypto, nasdaq, treasury, crude, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=100, 7d-median=99, 14d-median=100; carrying terms: https, target, management, related, contract, homeland, mission, google, activities, nuclear, comments, program
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, congresstrading, unauthorized, quiver, error, quiverquant, client, quantitative, httperror
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, state, international, florida, appeals, blanche, alabama, secretary, connecticut, company, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, financial, filer, finance, group, america, chase, funds, jpmorgan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, cortez, jonathan, sayed, senate, cooper, trone, talarico, james, david, raised
- gdelt_regions: today=0, 7d-median=0, 14d-median=0
- gdelt_gkg: today=25, 7d-median=27, 14d-median=27; carrying terms: english, russian, trump, french, keywords, china, netanyahu, hezbollah, election, israeli, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, kingdom, france, germany, canada, eagle, bulgaria, netherlands, adfee
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: given, links, provinces, human, months, active, authorities, institut, september, initiated, related, confined
- cisa_kev: today=13, 7d-median=13, 14d-median=17; carrying terms: secure, vendor, product, remediation, request, vulnerability, software, edition, authentication, improper, memory, internal
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: tropical, australia, forestfire, fires, south, sudan, brazil, speed, botswana, maximum, wildfire, nigeria
- usgs_quakes: today=17, 7d-median=11, 14d-median=15; carrying terms: depth, islands, japan, indonesia, south, ridge, russia, guinea, papua, indian, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, presidential, israel, democratic, shakhtar, donetsk, championship, champions, league, interest
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, class, economist, conversable, revolution, marginal, marginalrevolution, being, published, economic, economists, since
- tech_news: today=61, 7d-median=61, 14d-median=57; carrying terms: https, group, software, computerweekly, schneier, daily, state, technica, bleepingcomputer, blogging, squid, friday
- political_figures: today=0, 7d-median=613, 14d-median=613; carrying terms: carson, housing, moore, angus, norton, atlanta, emily, nanette, enforcement, salazar, robin, arrington
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, evidence, unavailable, placement, market, paper, consensus, decision, markets, today, identify, converges

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*