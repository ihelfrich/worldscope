# WORLDSCOPE morning brief — 2026-09-26

## Headline
3089 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (707) · Russian Internal News (state + in-exile) (616) · World leaders & government officials (324) · State-Level News (236) · Chinese Internal News (222) · Local News: St. Louis + Atlanta (182) · State Legislative Action (174) · U.S. Weather + Severe / Climate Outlooks (173) · Ukraine Theater (total-war monitoring) (139) · Ukrainian Internal News (national + local Kyiv) (59) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (38)

## What changed today
### International News + Multilateral Institutions — 707 new of 971 total
  - (2026-09-26) [Global] Lula bans fixed-odds sports betting a week before Brazilian elections
  - (2026-09-25) [Global] Michigan CEO loses job after posting AI-made image of her family in ‘Lake America’ sweaters
  - (2026-09-25) [Global] Alberta’s self-image as world’s only rat-free region shattered by discovery of rat
  - (2026-09-25) [Global] Pomp over progress in Xi’s US summit with Trump is a win for China
  - (2026-09-26) [Global] Free the Strip! Melburnians fight back against outlawing of much-loved picnic spot
  - (2026-09-25) [Global] OpenAI hack on Australian government reveals anxiety at heart of global artificial intelligence dilemma

### Russian Internal News (state + in-exile) — 616 new of 1011 total
  - (2026-09-26) Спустя 40 лет после открытия «Русский дом» в Берлине прекращает работу. Чем он вообще занимался? . И кто в Германии выступает за его сохранение? | LEDE: В начале сентября МИД Германии объяви] (ru: Спу…
      В начале сентября МИД Германии объявил о закрытии крупнейшего российского культурного центра за рубежом — «Русского дома» в Берлине. Учреждение проработало в центре немецкой столицы больше четырех десятилетий и не закрыл…
  - (2026-09-26) Минэнерго предложило ввести внешнее управление на сети АЗС «Трасса». Это первое применение указа Путина о защите «объектов критической инфраструктуры» | LEDE: Министерство энергетики РФ пред] (ru: Мин…
      Министерство энергетики РФ предложило ввести внешнее управление на сети АЗС «Трасса», впервые задействовав механизм, предусмотренный указом о защите «объектов критической инфраструктуры», пишет РБК со ссылкой на источник…
  - (2026-09-26) Билл Гейтс предупредил о риске гибели миллиарда людей из-за ИИ | LEDE: Основатель Microsoft Билл Гейтс вновь заявил о рисках, которые несет неконтролируемое развитие искусственного интеллект] (ru: Бил…
      Основатель Microsoft Билл Гейтс вновь заявил о рисках, которые несет неконтролируемое развитие искусственного интеллекта (ИИ).
  - (2026-09-26) Группе U2 — 50 лет. Музыканты отметили юбилей секретным концертом в родной школе в Дублине | LEDE: Ирландская рок-группа U2 сыграла 25 сентября специальный секретный концерт для учеников сре] (ru: Гру…
      Ирландская рок-группа U2 сыграла 25 сентября специальный секретный концерт для учеников средней школы Mount Temple в Дублине. Таким образом музыканты отметили полувековой юбилей коллектива — в стенах учебного заведения,…
  - (2026-09-26) Хакерская группировка ShinyHunters украла медицинские данные сотрудников ФБР | LEDE: Хакеры из группировки ShinyHunters, взломавшие Федеральное бюро расследований США, продемонстрировали жур] (ru: Хак…
      Хакеры из группировки ShinyHunters, взломавшие Федеральное бюро расследований США, продемонстрировали журналистам часть данных, к которым им удалось получить доступ. Как пишут Reuters и BBC News, речь идет о файлах с мед…
  - (2026-09-26) На крупнейшем в России угольном месторождении произошел взрыв. Погибли четыре человека | LEDE: На Эльгинском угольном месторождении в Якутии — крупнейшем в России — произошел взрыв, сообщает] (ru: На…
      На Эльгинском угольном месторождении в Якутии — крупнейшем в России — произошел взрыв, сообщает «Интерфакс» со ссылкой на региональную прокуратуру.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 236 new of 604 total
  - (2026-09-25) [Alabama] Governor Ivey Proclaims September 25 as Dolly Day in Alabama
      MONTGOMERY – Governor Kay Ivey on Friday proclaimed September 25, 2026, as Dolly Day in Alabama, joining communities across the nation in celebrating Dolly Parton’s extraordinary life, enduring legacy and lifelong commit…
  - (2026-09-25) [Alabama] Dolly Day
      Download
  - (2026-09-25) [California] California delegation wraps historic participation at Climate Week NYC — demonstrating strong climate and economic leadership on the world stage
      Source
  - (2026-09-25) [California] Governor Newsom proclaims Dolly Parton Day
      Source
  - (2026-09-25) [California] Governor Newsom signs legislation supporting California Native Americans
      Source
  - (2026-09-25) [California] Governor Newsom proclaims Native American Day
      Source

### Chinese Internal News — 222 new of 270 total
  - (2026-09-25) 最高人民法院 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9EN2tneVJtZURBUlA2dmMyc1hrV3REUHgyU3NsOFlnbTZvN2lEMWpUWVhESXBvZm5DZUxiUmVXTTJVYzBkYWZRcVV6WGxtSj] (zh:…
      最高人民法院 deepview.caixin.com
  - (2026-09-26) 恩格斯停顿会重演吗？人工智能时代的资本、劳动与分配（三） - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE41NUZfVk82ajhKV0lPVnc1SmJsMkpUeWFOM1UxcjQ3THcwNjFHQUZLelhLUzRpc2RibEtMUGM2Rm5odWdPZG0xZFBzU] (zh:…
      恩格斯停顿会重演吗？人工智能时代的资本、劳动与分配（三） 财新
  - (2026-09-26) 《醒来》：一场风花雪月的谍战剧｜影视 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBibWxBZV9PM0YwU1kzNUxnQS1xaUZEckU1UUY4RGhMVVZVRlNpUURlZTZRZEtKeERuM1FCRGJ0RWw5cXhmeEYxYldVU3RIM205bVp] (zh:…
      《醒来》：一场风花雪月的谍战剧｜影视 财新
  - (2026-09-26) 朱学东：唇角空余雪菜香｜饮食 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBnekNkOGNaZnRCYTVmWUNBbkZvd3o1MzdRV0hhS21RMlFQWmNBRTh3dWx3SlJ5UlpYdDQ0cnZtSWNjWWdXUUY2SWhyMjZOVmVRRGEzQTJ] (zh:…
      朱学东：唇角空余雪菜香｜饮食 财新
  - (2026-09-24) 中国红牛湖北生产基地获DCMM“稳健级”认证，以数据治理守护食品安全_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0xUDZNYXFNbEVlTGhNYjZzWEJKUFpUbTRYZGZERFhyeVNQUzA0TVB0Ui0tN1J4Wi1FNkpRWnEx] (zh:…
      中国红牛湖北生产基地获DCMM“稳健级”认证，以数据治理守护食品安全_特别呈现_手机财新网 财新
  - (2026-09-26) 大西洋观察│国政之抉：以英国与以色列为例 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9XSkRVY1liLUFkbVRsckt4WlRGQmZCOHFUSldwYVhyY1JrcGpaNnlLdEMxTHpQdVBleFgza2dyZi1ZNFQ5dWlIanY1TFQtbEZCb] (zh:…
      大西洋观察│国政之抉：以英国与以色列为例 财新

### Local News: St. Louis + Atlanta — 182 new of 231 total
  - (2026-09-25) [St. Louis] City Museum introduces ‘The Itty Bitty City Museum,’ a new exhibition featuring the tiny artwork of McKay Lenker Bayer
      The City Museum is hosting Utah-based artist McKay Lenker Bayer and her miniature works of art in its new exhibition The Itty Bitty City Museum, on display starting September 25. Bayer is known for her Tiny Art Shows, wh…
  - (2026-09-25) [St. Louis] Photos: St. Louis Business 500 Live – Leading What’s Next
      On September 23, St. Louis Magazine hosted St. Louis Business 500 Live, presented by WashU Olin Business School and sponsored by Guarantee Electrical Company. The second session in the series, Leading What’s Next, explor…
  - (2026-09-25) [St. Louis] Ask George: How common are cash-only restaurants and bars in St. Louis these days?
      Pre-pandemic, cash was still king at local restaurants and bars—until it became the pariah. When contactless payments and online ordering took off, fewer customers carried bills, and many cash-only establishments began a…
  - (2026-09-25) [St. Louis] U.S. Supreme Court again blocks Missouri from using Trump-backed congressional map
  - (2026-09-25) [St. Louis] Shake Shack founder Danny Meyer draws on his St. Louis roots in new book
  - (2026-09-25) [St. Louis] The Regional Arts Commission of St. Louis to scale back — but grants will continue

### State Legislative Action — 174 new of 219 total
  - (2026-09-26) [Alaska HB 261] An Act relating to education funding; providing for an effective date by amending the effective date of secs. 10, 11, 13, and 15, ch. 5, SLA 2025; and providing for an effective date.
      An Act relating to education funding; providing for an effective date by amending the effective date of secs. 10, 11, 13, and 15, ch. 5, SLA 2025; and providing for an effective date.
  - (2026-09-25) [Alaska HB 221] An Act establishing the first Friday of every October as Alaska Arts and Culture Day; and providing for an effective date.
      An Act establishing the first Friday of every October as Alaska Arts and Culture Day; and providing for an effective date.
  - (2026-09-25) [Alaska SB 178] An Act relating to early intervention services for certain children; relating to optional services under the medical assistance program; and providing for an effective date.
      An Act relating to early intervention services for certain children; relating to optional services under the medical assistance program; and providing for an effective date.
  - (2026-09-25) [Alaska HB 314] An Act relating to registered interior designers and interior design; relating to project costs for the construction, enlargement, or improvement of airports; extending the termination…
      An Act relating to registered interior designers and interior design; relating to project costs for the construction, enlargement, or improvement of airports; extending the termination date of the State Board of Registra…
  - (2026-09-25) [Alaska HB 226] An Act increasing the loan amount that is eligible for lower interest rates on certain Alaska Housing Finance Corporation loans.
      An Act increasing the loan amount that is eligible for lower interest rates on certain Alaska Housing Finance Corporation loans.
  - (2026-09-25) [Alaska HB 48] An Act relating to appropriations to the civil legal services fund.
      An Act relating to appropriations to the civil legal services fund.

### U.S. Weather + Severe / Climate Outlooks — 173 new of 174 total
  - (2026-09-26) [Moderate] Gale Warning: Gale Warning issued September 26 at 7:55AM EDT until September 27 at 8:00PM EDT by NWS Caribou ME
      * WHAT...Northeast winds 20 to 30 kt with gusts up to 40 kt and seas 6 to 11 ft. * WHERE...Waters from Eastport ME to Schoodic Point ME from 25 to 60 NM or the Hague Line and Waters from Schoodic Point ME to Stonington M…
  - (2026-09-26) [Moderate] Gale Warning: Gale Warning issued September 26 at 7:55AM EDT until September 27 at 8:00PM EDT by NWS Caribou ME
      * WHAT...Northeast winds 20 to 30 kt with gusts up to 40 kt and seas 6 to 9 ft expected. * WHERE...Coastal Waters from Eastport, ME to Schoodic Point, ME out 25 NM and Coastal Waters from Schoodic Point, ME to Stonington…
  - (2026-09-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-26) [Moderate] Gale Warning: Gale Warning issued September 26 at 7:45AM EDT until September 26 at 10:00PM EDT by NWS Baltimore MD/Washington DC
      * WHAT...North winds 20 to 25 kt with gusts up to 35 kt and waves 2 to 4 ft. * WHERE...Chesapeake Bay north of North Beach MD, Chester River to Queenstown MD, Eastern Bay, and Choptank River to Cambridge MD and the Littl…
  - (2026-09-26) [Moderate] Gale Warning: Gale Warning issued September 26 at 7:45AM EDT until September 26 at 10:00PM EDT by NWS Baltimore MD/Washington DC
      * WHAT...North winds 20 to 30 kt with gusts up to 40 kt and waves 3 to 6 ft. * WHERE...Chesapeake Bay from North Beach MD to Smith Point VA, Tidal Potomac from Cobb Island MD to Smith Point VA, Patuxent River to Broomes…
  - (2026-09-26) [Moderate] Gale Warning: Gale Warning issued September 26 at 2:59AM AKDT until September 26 at 6:00PM AKDT by NWS Juneau AK
      * WHAT...East winds 25 to 35 kt with gusts up to 45 kt and seas 9 to 14 ft. * WHERE...Icy Cape to Cape Suckling out to 15 NM. * WHEN...Until 6 PM AKDT this evening. * IMPACTS...Strong winds will cause hazardous seas whic…

### Ukraine Theater (total-war monitoring) — 139 new of 330 total
  - (2026-09-25) [FIRMS] thermal anomaly 48.520, 34.633 (FRP 7.83 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-25 1034Z, FRP 7.83 MW
  - (2026-09-25) [FIRMS] thermal anomaly 45.260, 31.670 (FRP 5.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-25 2248Z, FRP 5.5 MW
  - (2026-09-25) [FIRMS] thermal anomaly 45.260, 31.666 (FRP 4.45 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-25 2248Z, FRP 4.45 MW
  - (2026-09-26) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-24) [Liveuamap] Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com - Liveuamap
      Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com Liveuamap
  - (2026-09-26) [Liveuamap] Drone strike at the Perm oil refinery Perm Krai, Russia - Ukraine Interactive map - Ukraine Latest news on live map - Liveuamap
      Drone strike at the Perm oil refinery Perm Krai, Russia - Ukraine Interactive map - Ukraine Latest news on live map <font co

### Ukrainian Internal News (national + local Kyiv) — 59 new of 129 total
  - (2026-09-26) Зеленський запровадив санкції проти 44 осіб, причетних до "виборів" на ТОТ | LEDE: Президент Володимир Зеленський увів у дію санкції проти 44 осіб, причетних до проведення незаконних "виборів" ] (uk:…
      Президент Володимир Зеленський увів у дію санкції проти 44 осіб, причетних до проведення незаконних "виборів" до Держдуми РФ на тимчасово окупованих територіях України.
  - (2026-09-26) Вибух у будинку в центрі Афін: одна людина загинула, п’ятьох ще шукають | LEDE: У туристичному районі Плака в Афінах обвалився будинок після вибуху. Загинула жінка, п'ятеро людей зникли, троє п] (uk:…
      У туристичному районі Плака в Афінах обвалився будинок після вибуху. Загинула жінка, п'ятеро людей зникли, троє поранені. Причиною міг бути витік газу.
  - (2026-09-26) Аеропорт Сицилії обмежив роботу через попіл з Етни | LEDE: ] (uk: Аеропорт Сицилії обмежив роботу через попіл з Етни)
  - (2026-09-26) Польща готова платити $15 тисяч на рік за кожного військового США на постійній базі | LEDE: Заступник міністра оборони Польщі Павел Залевський: Варшава готова покривати $15 тисяч на рік за війс] (uk:…
      Заступник міністра оборони Польщі Павел Залевський: Варшава готова покривати $15 тисяч на рік за військового та витрати на інфраструктуру для бази США.
  - (2026-09-26) Зеленський: Лише за ніч через атаки РФ поранені 14 людей, двоє загинули | LEDE: Внаслідок обстрілів по Україні пошкоджено житло і об’єкти освіти, Зеленський закликає до нових санкцій проти Росі] (uk:…
      Внаслідок обстрілів по Україні пошкоджено житло і об’єкти освіти, Зеленський закликає до нових санкцій проти Росії.
  - (2026-09-26) В одному з воєводств Польщі тестуватимуть сирени | LEDE: ] (uk: В одному з воєводств Польщі тестуватимуть сирени)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-26) [Bernes Marshall] Form 4 (Reporting)
      filed 2026-09-26 01:57 UTC · role: Reporting — Filed: 2026-09-25 AccNo: 0002045034-26-000009 Size: 6 KB
  - (2026-09-26) [GigaCloud Technology Inc] Form 4 (Issuer)
      filed 2026-09-26 01:57 UTC · role: Issuer — Filed: 2026-09-25 AccNo: 0002045034-26-000009 Size: 6 KB
  - (2026-09-26) [Sheena Jonathan] Form 4 (Reporting)
      filed 2026-09-26 01:35 UTC · role: Reporting — Filed: 2026-09-25 AccNo: 0001646649-26-000033 Size: 27 KB
  - (2026-09-26) [Natera, Inc.] Form 4 (Issuer)
      filed 2026-09-26 01:35 UTC · role: Issuer — Filed: 2026-09-25 AccNo: 0001646649-26-000033 Size: 27 KB
  - (2026-09-26) [Todd Christopher Michael] Form 4 (Reporting)
      filed 2026-09-26 01:30 UTC · role: Reporting — Filed: 2026-09-25 AccNo: 0001437749-26-031270 Size: 4 KB
  - (2026-09-26) [Safe Pro Group Inc.] Form 4 (Issuer)
      filed 2026-09-26 01:30 UTC · role: Issuer — Filed: 2026-09-25 AccNo: 0001437749-26-031270 Size: 4 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 38 new of 57 total
  - (2026-09-26) [The Hacker News] Elementor CSRF Flaw Lets Attackers Take Over Sites After Admin Clicks Crafted Link
      Details have emerged about a high-severity security flaw in the Elementor Website Builder WordPress plugin that could be exploited by an unauthenticated attacker to create rogue administrator accounts and take control of…
  - (2026-09-26) [The Hacker News] SharePoint RCE and MikroTik RouterOS Flaws Actively Exploited in the Wild
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Friday added two security flaws impacting Microsoft SharePoint and Mikrotik RouterOS to its Known Exploited Vulnerabilities (KEV) catalog, citing eviden…
  - (2026-09-26) [The Hacker News] Kiteworks Urges Customers to Shut Down Systems for 9 Hours Over Possible Cyber Attack
      Kiteworks (formerly Accellion) is urging customers to shut down their systems as a precautionary measure for nine hours over the weekend after it received threat intelligence about an imminent cyber attack. "Kiteworks re…
  - (2026-09-26) [The Register] How Samsung turned months of inactivity into a very attention-seeking smartphone
      Your spare Android won’t come back to life in a hurry but – like neglected PCs – it really should
  - (2026-09-26) [The Register] Space Jam: UK debuts space squadron to protect satellites
      Number III Space Effects Squadron likely to use electronic warfare rather than lobbing missiles at hostile orbiting threats
  - (2026-09-26) [TechCrunch] At Meta Connect, the company’s smart glasses were everywhere
      The company behind Facebook and Instagram wants to keep consumers connected to the digital world via its ever-growing line of smart glasses.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 26 new of 26 total
  - (2026-09-25) M 6.6 - 80 km ENE of Tadine, New Caledonia
      M6.6 · 80 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-25) M 5.5 - 61 km ENE of Tadine, New Caledonia
      M5.5 · 61 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-25) M 5.4 - 69 km ENE of Tadine, New Caledonia
      M5.4 · 69 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-26) M 5.3 - 58 km ENE of Tadine, New Caledonia
      M5.3 · 58 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-25) M 5.2 - 62 km SW of San Antonio, Chile
      M5.2 · 62 km SW of San Antonio, Chile · depth 29.072 km
  - (2026-09-26) M 5.1 - 68 km NE of Tadine, New Caledonia
      M5.1 · 68 km NE of Tadine, New Caledonia · depth 10 km

### Government & military aircraft airborne (OpenSky) — 24 new of 25 total
  - (2026-09-26) JAF95J (Bulgaria)
      icao24: 4520aa · position: (38.2465, -5.8131) · alt: 11269m · 774km/h
  - (2026-09-26) SAMU13 (France)
      icao24: 39c902 · position: (43.4094, 5.5019) · alt: 716m · 247km/h
  - (2026-09-26) KAF3212 (Kuwait)
      icao24: 7061f6 · position: (43.1335, 23.8072) · alt: 7612m · 585km/h
  - (2026-09-26) JAF5HJ (Belgium)
      icao24: 44d1ba · position: (49.6586, 3.1515) · alt: 8747m · 774km/h
  - (2026-09-26) JAF2JW (Belgium)
      icao24: 44d1a6 · position: (50.7986, 3.6309) · alt: 4442m · 701km/h
  - (2026-09-26) JAF2VJ (Belgium)
      icao24: 44d1a7 · position: (50.3848, 5.342) · alt: 6004m · 732km/h

### Court opinions of consequence (federal & state) — 21 new of 60 total
  - (2026-09-25) U.S. Supreme Court: People Not Politicians v. Onder
  - (2026-09-25) U.S. Supreme Court: Department of Homeland Security v. League of Women Voters
  - (2026-09-25) Alaska Supreme Court: SCOTT RILEY DICKERSON and v. STEPHANIE LYNNE DICKERSON And
  - (2026-09-25) U.S. Court of Appeals, 7th Cir.: United States v. Gary Howard
  - (2026-09-25) U.S. Court of Appeals, 2nd Cir.: Barbosa Da Cunha v. Freden
  - (2026-09-25) U.S. Court of Appeals, 2nd Cir.: United States v. Ceasar

### U.S. Federal Action — 18 new of 18 total
  - (2026-09-28) Information Reporting Regarding Qualified Opportunity Zones and Updated Qualified Opportunity Fund Certification and Decertification Procedures
  - (2026-09-28) Notice of Policy Change and Rescission of Single-Pilot Training Exemptions for Certain Cessna Aircraft
      Based on safety concerns and a review that revealed widespread non-compliance with the exemptions, the FAA is announcing its decision to cease issuing exemptions that allow certain Cessna aircraft that require two pilots…
  - (2026-09-28) Establishment, Modification, and Revocation of Class E Airspace; Alaska, AK
      This action supplements a notice of proposed rulemaking (NPRM) published by the FAA in the Federal Register on June 17, 2025, which proposed to establish Class E domestic en route airspace (Class E6) within a designated…
  - (2026-09-28) Fisheries Off West Coast States; West Coast Salmon Fisheries; Rebuilding Plan for the Overfished Queets River Spring/Summer Chinook Salmon Stock
      This final rule will implement the rebuilding plan recommended by the Pacific Fishery Management Council (Council) for the overfished Queets River Spring/Summer Chinook salmon stock (Queets sp/su Chinook salmon). This fi…
  - (2026-09-28) Fisheries of the Caribbean, Gulf of America, and South Atlantic; Snapper-Grouper Fishery of the South Atlantic; Regulatory Amendment 36
      NMFS issues regulations to implement Regulatory Amendment 36 under the Fishery Management Plan for the Snapper-Grouper Fishery of the South Atlantic (Snapper-Grouper FMP). This final rule revises the recreational vessel…
  - (2026-09-28) Capital Construction Fund Revision; Correction
      MARAD published a document in the Federal Register on Tuesday, September 22, 2026, concerning requests for comments to the proposed revision of its Capital Construction Fund (CCF) program regulations and an associated pr…

### Paper Trading Scorecard — 17 new of 120 total
  - (2026-09-26) [Polymarket] Will Ethereum dip to $2,000 in September?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for ETH/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa…
  - (2026-09-26) [Polymarket] Iran full airspace closure by September 30?
      This market will resolve to “Yes” if Iran initiates a general closure of its airspace, that is not solely due to weather conditions, between market creation and the specified date, 11:59 PM ET. Otherwise, this market wil…
  - (2026-09-26) [Kalshi] Patrick Mahomes Career Regular Season Passing Yards
      Patrick Mahomes
  - (2026-09-26) [Manifold] Daily Coinflip
  - (2026-09-26) [Manifold] Will I get a positive pregnancy test in the next two weeks?
  - (2026-09-26) [Manifold] Will somebody use my Bilt referral link before end of Sep 2026?

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-09-26) Dota 2: Aurora vs Natus Vincere - Game 2 Winner
      yes price: 0% · 24h volume: $1,229,165 · resolves 2026-09-26
  - (2026-09-26) Valorant: Global Esports vs Team Vitality (BO3) - VCT Champions Group B
      yes price: 0% · 24h volume: $574,704 · resolves 2026-09-26
  - (2026-09-26) Singapore Open: Leylah Fernandez vs Maja Chwalinska
      yes price: 99% · 24h volume: $490,154 · resolves 2026-10-03
  - (2026-09-26) Will Manchester City win the 2026-27 English Premier League (EPL) Championship?
      yes price: 22% · 24h volume: $476,385 · resolves 2027-05-30
  - (2026-09-26) Will Spain win on 2026-09-26?
      yes price: 44% · 24h volume: $458,433 · resolves 2026-09-26
  - (2026-09-26) Spread: Lions (-6.5)
      yes price: 50% · 24h volume: $434,161 · resolves 2026-09-27

### Government Action: Sanctions + Procurement + Foreign Agents — 10 new of 102 total
  - (2026-09-19) [FARA] Short Form Registrauon Statement Sample OMB_1124_0005B_SF - justice.gov
      Short Form Registrauon Statement Sample OMB_1124_0005B_SF justice.gov
  - (2026-09-19) [FARA] Exhibit A to Registration Statement SampleOMB_1124_0006B_EA - justice.gov
      Exhibit A to Registration Statement SampleOMB_1124_0006B_EA justice.gov
  - (2026-09-19) [FARA] Supplemental Statement SampleOMB_1124_0002B_SS - justice.gov
      Supplemental Statement SampleOMB_1124_0002B_SS justice.gov
  - (2026-09-19) [FARA] Amendment to Registration Statement SampleOMB_1124_0003B_AM - justice.gov
      Amendment to Registration Statement SampleOMB_1124_0003B_AM justice.gov
  - (2026-09-21) [FARA] Office of Privacy and Civil Liberties | DOJ Privacy Impact Assessments - justice.gov
      Office of Privacy and Civil Liberties | DOJ Privacy Impact Assessments justice.gov
  - (2026-09-26) [USASpending] $2,120,623,738 → ORACLE HEALTH GOVERNMENT SERVICES, INC.: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
      Agency: Department of Veterans Affairs. Description: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-26) [Marginal Revolution] Should you text more?
      Here, in five waves of panel data (N = 1,966 US adults), we examined associations between life satisfaction and self-reported use of ten common social technologies measured every 3 months on a six-point frequency scale f…
  - (2026-09-26) [Marginal Revolution] A doomsday scenario for American AI
      That is the title of my latest Free Press column, here is the closing bit: Sick and elderly Americans will go to Chinese companies for their AI-invented and AI-tested medical devices and drugs. America still will be a we…
  - (2026-09-25) [Marginal Revolution] Good points from James Gilliland
      It pains me to say this, but if we actually “get AGI,” the resulting boom in industrial capacity from robotics and massive society-wide wealth creation will look like a total vindication of neoliberalism. The discourse a…
  - (2026-09-25) [Conversable Economist] S-Shaped Utility Curves, Poverty, and Risk-Taking
      When economists think about how much utility is gained from additional economic resources the basic assumption is that an additional amount of income or wealth increases utility, but by a diminishing amount–because addit…

### GDELT GKG — themes / entities / watch areas — 3 new of 3 total
  - (2026-09-25) [Russia oil sanctions perimeter · keywords] Russia Expands Flagged Fleet as Sanctioned Tankers Seek Shelter
      slguardian.org · English · tone NA
  - (2026-09-25) [Russia oil sanctions perimeter · keywords] Azerbaijani oil price approaches $126
      trend.az · English · tone NA
  - (2026-09-25) [Russia oil sanctions perimeter · keywords] Ukraine Invasion Day 1 , 674 : more civilian casualties
      dailykos.com · English · tone NA

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 17 total
  - (2026-09-25) CVE-2026-67279 · MikroTik RouterOS: Mikrotik RouterOS Improper Enforcement of Behavioral Workflow Vulnerability
      vendor: MikroTik · product: RouterOS · CISA remediation by 2026-09-28
  - (2026-09-25) CVE-2026-65660 · Microsoft SharePoint: Microsoft SharePoint Code Injection Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-09-28
  - (2026-09-25) CVE-2026-87902 · WordPress Core: WordPress Core Remote File Inclusion Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-09-28

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-09-25) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo
      Since the last Disease Outbreak News was published on 11 September 2026, the Bundibugyo virus outbreak in the Democratic Republic of the Congo has expanded further, with two additional health zones affected. These includ…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=19, 14d-median=19; carrying terms: state, certain, proposed, final, program, proposes, directives, regulatory, specifically, model, office, action
- state_bills: today=219, 7d-median=120, 14d-median=105; carrying terms: effective, programs, project, offer, licensure, legislature, state, facilities, request, establish, safety, governor
- state_news: today=604, 7d-median=604, 14d-median=683; carrying terms: concerned, doctors, newsletter, congress, project, children, across, proposal, washington, companies, turned, capital
- local_news: today=231, 7d-median=227, 14d-median=231; carrying terms: injured, state, following, weekend, county, people, trump, stlmag, night, district, woman, restaurant
- foreign_news: today=971, 7d-median=994, 14d-median=994; carrying terms: bangkok, project, httpsconnection, children, across, banco, coast, result, washington, holding, offer, targets
- chinese_internal: today=270, 7d-median=270, 14d-median=274; carrying terms: lxtfb, cbmib, lxtfa, cbmidefvx, people, cbmixkfvx, cbmix, cbmickfvx, google, blank, articles, politics
- russian_internal: today=1011, 7d-median=1029, 14d-median=1059; carrying terms: blank, telegram, laquo, times, anthropic, server, novayagazeta, target, httperror, client, media, found
- ukrainian_internal: today=129, 7d-median=134, 14d-median=136; carrying terms: officials, ballistic, across, httperror, sanctions, capital, reportedly, injured, cabinet, state, threat, continued
- ukraine_theater: today=330, 7d-median=426, 14d-median=417; carrying terms: shyzuvztugu, ughlntvywffsr, cbmirwfbvv, vtdmuzywnfl, dlvvlwnhpbnrcslnpamlxuevzvelaodkwqxqzvlp, lxtfb, cwsehumnnpdkxjs, tjrhmtrfv, diqjrvyuxluxrfzf, accreditation, cuxonk, dtqujwrkrhluhfqljnq
- paper_bets: today=120, 7d-median=125, 14d-median=126; carrying terms: millennium, alaska, funds, general, lifetime, california, democratic, schumer, headline, virginia, magnitude, anthropic
- weather: today=174, 7d-median=146, 14d-median=119; carrying terms: louis, america, norton, creeks, pressure, ruskin, tampa, forecast, across, changed, washington, messages
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, sheet, cpiaucsl, crude, commodities, balance, energy, dcoilwtico, indicator, effective, headline, openings
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, china, range, large, close, russell, equities, credit, treasury, corporate, crude, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=102, 7d-median=104, 14d-median=106; carrying terms: russia, libya, cyber, destabilisation, drilling, economic, illegal, herzegovina, acronym, against, occupation, trade
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, error, unauthorized, quantitative, quiverquant, client, https, quiver, congresstrading
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, court, arizona, state, supreme, delaware, international, trade, company, robert, association, commissioner
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, holdings, group, therapeutics, technology, michael, natera, scott, andrew
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, krishnamoorthi, johnson, disbursements, james, ocasio, committee, filing, cortez, cooper, michael, trone
- gdelt_regions: today=0, 7d-median=0, 14d-median=6; carrying terms: english
- gdelt_gkg: today=3, 7d-median=50, 14d-median=50; carrying terms: sanctions, english, perimeter, russia, ukraine, keywords
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=25, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, kingdom, france, bulgaria, kuwait, aabbef
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: march, isolates, initiated, general, transmission, genomic, sylvatic, early, initially, hemorrhagic, critically, influenza
- cisa_kev: today=17, 7d-median=21, 14d-median=21; carrying terms: vendor, authorization, remediation, product, buffer, overflow, traversal, engine, based, injection, cisco, incorrect
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=26, 7d-median=14, 14d-median=13; carrying terms: depth, indonesia, islands, colombia, region, ruteng, south, china, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, champions, shakhtar, meeting, interest, league, rates, championship, donetsk, september
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, https, economist, marginal, revolution, class, conversableeconomist, points, decline, basic, showing, patterns
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: newsletter, anthropic, hacker, bleepingcomputer, models, companies, schneier, leaders, safety, techcrunch, intelligence, critical
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: salazar, espaillat, elena, louis, hagerty, clyde, turner, warnock, markwayne, donalds, peters, mccollum
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, unavailable, claude, placed, sufficient, market, evidence, module, converges, consensus, decision, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-21] ECB press: ECB to invest part of own funds in tokenised securities, with settlement via Pontes
- [2026-09-21] ECB press: Eurosystem brings central bank money to tokenised finance
- [2026-09-22] ECB press: Philip R. Lane: Interview with Le Temps
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-23] ECB press: Almost ten million people took part in ECB survey on new euro banknotes
- [2026-09-23] Fed speeches: Barr, A Long-Term View on the Costs of Shelter
- [2026-09-23] ECB press: The digitalisation of money, payments and finance
- [2026-09-23] ECB press: Philip R. Lane: The Outlook for the Euro Area Economy
- [2026-09-24] ECB press: Philip R. Lane: The outlook for the euro area economy
- [2026-09-24] ECB press: ECB Executive Board member Isabel Schnabel to resign to take senior role at IMF
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*