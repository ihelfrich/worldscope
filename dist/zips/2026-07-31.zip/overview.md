# WORLDSCOPE morning brief — 2026-07-31

## Headline
4072 new items across 26 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (764) · International News + Multilateral Institutions (762) · Russian Internal News (state + in-exile) (615) · State-Level News (365) · World leaders & government officials (324) · Chinese Internal News (286) · Local News: St. Louis + Atlanta (265) · U.S. Weather + Severe / Climate Outlooks (186) · State Legislative Action (86) · Ukrainian Internal News (national + local Kyiv) (64) · IT, InfoSys & cybersecurity news (last 7 days) (41) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Ukraine Theater (total-war monitoring) — 764 new of 1140 total
  - (2026-07-31) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-30) [FIRMS] thermal anomaly 52.805, 32.221 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 2354Z, FRP 0.87 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.804, 32.227 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 2354Z, FRP 0.8 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.649, 32.533 (FRP 0.68 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 2354Z, FRP 0.68 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.847, 29.989 (FRP 8.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 2354Z, FRP 8.41 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.134, 34.467 (FRP 0.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 2354Z, FRP 0.77 MW

### International News + Multilateral Institutions — 762 new of 1081 total
  - (2026-07-31) [Global] Snapchat joins other popular platforms in fight against 'AI slop'
      Snapchat, YouTube, LinkedIn, and Substack are trying to combat the proliferation of fake AI content.
  - (2026-07-31) [Global] Passenger on British Airways mayday flight describes fear and shout of 'I don't want to die'
      Edward Killiwick was on the flight that issued a distress call, before it landed safely at Heathrow earlier this month.
  - (2026-07-31) [Global] AI firms must answer for rogue bots, says boss of hacked company
      Clement Delangue said he didn't want cyber attacks on other companies to become "normalised".
  - (2026-07-31) [Global] Sainsbury's agrees to sell Argos for £120m
      Under the terms of the deal, Argos will still operate in Sainsbury's shops, sell Habitat products, and offer Nectar points.
  - (2026-07-31) [Global] Budget to be held in October, Healey announces
      The new chancellor pledged to move money and power out of Westminster, and into every postcode around Britain.
  - (2026-07-31) [Global] UK petrol prices hit highest level since Iran war began
      The price of unleaded hits 160p a litre, according to motoring group the RAC, as oil prices remain elevated.

### Russian Internal News (state + in-exile) — 615 new of 937 total
  - (2026-07-31) Латвия закрыла границу с Беларусью | LEDE: Латвийско-белорусская граница закрыта «по техническим причинам», сообщил в соцсетях министр внутренних дел Латвии Янис Домбрава. ] (ru: Латвия закрыла границ…
      Латвийско-белорусская граница закрыта «по техническим причинам», сообщил в соцсетях министр внутренних дел Латвии Янис Домбрава.
  - (2026-07-31) Правительство запретило майнинг криптовалют в Москве и Московской области до 2033 года | LEDE: В Москве, Подмосковье и в восьми приграничных районах Курской области запретили майнинг криптов] (ru: Пра…
      В Москве, Подмосковье и в восьми приграничных районах Курской области запретили майнинг криптовалют. Запрет будет действовать с 15 августа 2026 до 31 декабря 2032 года. Такое постановление подписал премьер-министр России…
  - (2026-07-31) «Помочь вам можем только мы и государство». Татьяна Ким обратилась к продавцам Wildberries после двух недель украинских ударов по складам маркетплейса. Вот что она сказала — максимально коротко] (ru:…
      Уже две недели наша компания подвергается террористическим атакам. Почему именно мы? Террористы говорят, что мы продаем товары военного назначения. Но вы можете открыть хоть Amazon, хоть Alibaba и посмотреть, есть ли у н…
  - (2026-07-31) Издание «Код Дурова» убрало из названия фамилию Дурова | LEDE: Российское издание о технологиях «Код Дурова» сменило название на «Код.ру». Сообщение о ребрендинге опубликовано на сайте и в с] (ru: Изд…
      Российское издание о технологиях «Код Дурова» сменило название на «Код.ру». Сообщение о ребрендинге опубликовано на сайте и в соцсетях издания.
  - (2026-07-31) Италия приостановит Шенгенское соглашение с Испанией из-за наплыва мигрантов в Сеуту | LEDE: Италия приостановит действие Шенгенского соглашения с Испанией из-за массового притока нелегальны] (ru: Ита…
      Италия приостановит действие Шенгенского соглашения с Испанией из-за массового притока нелегальных иммигрантов в испанский эксклав Сеуту. Такое решение приняло министерство внутренних дел Италии, сообщили местные издания…
  - (2026-07-31) Офис Зеленского попросил генпрокурора Украины завести уголовное дело на Лукашенко | LEDE: Офис президента Украины Владимира Зеленского попросил офис генерального прокурора рассмотреть возмож] (ru: Офи…
      Офис президента Украины Владимира Зеленского попросил офис генерального прокурора рассмотреть возможность возбудить уголовное дело против Александра Лукашенко. Эту информацию «Укринформу» подтвердила спикер офиса генпрок…

### State-Level News — 365 new of 1022 total
  - (2026-07-31) [California] Universidad de California rompe relaciones con la Patrulla Fronteriza tras protestas estudiantiles
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/020426_UCSD-Police_AH_003.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-07-31) [California] Tribunal: La política de detención masiva de inmigrantes de Trump contradice 30 años de precedentes
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/03/022026_Padilla-Otay-Mesa_AH_08_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-31) [California] Why federal court struck down Trump’s mass detention policy
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072026-Otay-Mesa-GB-AP-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-07-31) [California] David Valadao lost in the last anti-Trump blue wave. Will farmers help him win this time?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/030626-David-Valadao-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-07-31) [California] This embattled consumer agency went 2 years without a director. Newsom finally appointed one
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072926-PFB-MG-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="A gra…
  - (2026-07-31) [California] A California university is cutting ties with the Border Patrol after student outcry
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/020426_UCSD-Police_AH_003.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 286 new of 317 total
  - (2026-07-30) 伊朗将接收中国造肩扛式防空导弹？外交部：不符合事实-观察者网 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5Vd3hCcTZiTkZWSmwtUUV4Qm1NTm9CZkNhaC1uNkUtXzlsQ3lSSHZ5OWhSSXk3MTZST1FmZjRIRE1CUzN] (zh:…
      伊朗将接收中国造肩扛式防空导弹？外交部：不符合事实-观察者网 guancha.cn
  - (2026-07-31) 美卫生部长小罗伯特·肯尼迪：美国人改吃肝脏而不是牛肉，就能更容易负担得起食品杂货 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBiOUtnYUlxcHUzUXp4MWVyY2duN1lOWUYyb2xMeXBCQ3NQWEIyam91SzljblFJQVBTMzAyYlFsNnpUV] (zh:…
      美卫生部长小罗伯特·肯尼迪：美国人改吃肝脏而不是牛肉，就能更容易负担得起食品杂货 风闻
  - (2026-07-31) 中国留学生遭两女子袭击，澳大利亚种族歧视为何抬头？-观察者网 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5MaHpmWEdWc1F2ekxjdGxVck15UEhMbkwyTzAwWndNUDY1MEk0YlpDZ0d2TUJwdkJjOUN4T0I4Ml9ILVk] (zh:…
      中国留学生遭两女子袭击，澳大利亚种族歧视为何抬头？-观察者网 guancha.cn
  - (2026-07-31) 核爆纪念日前夕，日媒将播出双重原子弹受害者纪录片 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5VenZZVTNJcHJPaXdGMVlfdXVaTmNNU0NXMjQ2aWx5ZXdEcGliRWp5RHRnRnd1Mk93WXZoU2NFaTI4cU1fR1hZY1J2RnF4Z] (zh:…
      核爆纪念日前夕，日媒将播出双重原子弹受害者纪录片 风闻
  - (2026-07-31) “1988元可与美女亲亲抱抱，其他服务私下谈”？当地通报 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5vT1JUc3U3MzdfOXBsYkI3Q3BmZzVPUE94MjZ4V3IwTHdMS1FwS2JnNkZ3SnhNbVc2WWdIYmlobmNVYzZTN] (zh:…
      “1988元可与美女亲亲抱抱，其他服务私下谈”？当地通报 guancha.cn
  - (2026-07-31) 中央军委主席习近平签署通令，给1名个人记功 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE00bGFDQ0g2OTdYV2RyeUpjZ3dIbDU5T29HMl9kY0RiODBWWC1nSkplWGNPUGQ4N3RveHgwUzJMNUdfazBITmdQQ0Z6] (zh:…
      中央军委主席习近平签署通令，给1名个人记功 guancha.cn

### Local News: St. Louis + Atlanta — 265 new of 282 total
  - (2026-07-31) [St. Louis] Meet the Metro East preschooler whose love of lawn care became an internet sensation
      A landscaper pulls into the parking lot, unloads a zero-turn mower, and starts trimming the grass. Most preschoolers barely notice. Grant Wymer doesn’t miss a thing. He studies every movement, watches every turn of the s…
  - (2026-07-31) [St. Louis] The St. Louis beer lover’s guide to American pales ales and IPAs
      Walk into almost any St. Louis brewery, and you’ll find both an American pale ale and an IPA on tap. At first glance, the two styles seem remarkably similar. Both feature American hop varieties known for citrus, pine, an…
  - (2026-07-31) [St. Louis] Ask George: Where in St. Louis can I get a fresh peach sundae?
      As a kid, I lived near a Bettendorf’s grocery store (later a Schnucks), and one of summer’s greatest pleasures was the fresh peach sundae at its soda fountain. After lunch, my buddies and I would claim a row of swivel st…
  - (2026-07-31) [St. Louis] Inside St. Charles County’s war on apartments
      Zack Stahr comes from a long line of St. Charles County residents. He grew up there; his parents and grandparents did, too. “Left and came back, left and came back,” he says of the generations of his family that have liv…
  - (2026-07-31) [St. Louis] WashU professor’s new book ‘The Small Stuff’ advocates finding joy in the sensory
      Washington University professor Ian Bogost has a theory that focusing on sensorial and tactile pleasures—“small stuff,” in his words—can help us be more present in our lives, leading to greater enjoyment. He says his adv…
  - (2026-07-31) [St. Louis] AI, data centers get a warm reception from St. Louis County executive candidates
      Data centers may be a bipartisan target of antipathy, but you’d never know it to listen to the three leading candidates for St. Louis County executive. The three agreed that large data centers, like those needed to run A…

### U.S. Weather + Severe / Climate Outlooks — 186 new of 188 total
  - (2026-07-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 31 at 5:32PM MDT until July 31 at 6:00PM MDT by NWS Albuquerque NM
      SVRABQ The National Weather Service in Albuquerque has issued a * Severe Thunderstorm Warning for... South Central Quay County in east central New Mexico... * Until 600 PM MDT. * At 532 PM MDT, a severe thunderstorm was…
  - (2026-07-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 31 at 6:31PM CDT until July 31 at 7:00PM CDT by NWS St Louis MO
      At 631 PM CDT, a severe thunderstorm was located near Mount Sterling, or 12 miles north of Owensville, moving east at 30 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hail dama…
  - (2026-07-31) [Moderate] Special Weather Statement: Special Weather Statement issued July 31 at 6:31PM CDT by NWS Quad Cities IA IL
      At 630 PM CDT, Doppler radar was tracking heavy rain producing thunderstorms along a line extending from near Bennett to near Rozetta. Movement was northeast at 30 mph. HAZARD...Minor flooding. SOURCE...Radar indicated.…
  - (2026-07-31) [Moderate] Special Weather Statement: Special Weather Statement issued July 31 at 5:30PM MDT by NWS El Paso Tx/Santa Teresa NM
      At 528 PM MDT, Thunderstorms were beginning to develop around the greater Las Cruces area as an outflow boundary pushed in from the north. Expect thunderstorms to increase in coverage over the next couple of hours, slowl…
  - (2026-07-31) [Severe] Flash Flood Warning: Flash Flood Warning issued July 31 at 7:29PM EDT until July 31 at 9:30PM EDT by NWS Gaylord MI
      At 729 PM EDT, Doppler radar indicated thunderstorms producing heavy rain across the warned area. Between 2 and 4 inches of rain have fallen. The expected rainfall rate is 0.25 to 0.5 inches in 1 hour. Additional rainfal…
  - (2026-07-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 31 at 5:27PM MDT until July 31 at 5:45PM MDT by NWS Rapid City SD
      At 527 PM MDT, a severe thunderstorm was located over Cascade Falls, or 11 miles south of Hot Springs, moving south at 25 mph. HAZARD...Half dollar size hail. SOURCE...Radar indicated. IMPACT...Damage to vehicles is expe…

### State Legislative Action — 86 new of 152 total
  - (2026-07-31) [Alaska HB 222] An Act relating to workplace violence protective orders; relating to attorney fees; relating to the crime of violating a protective order; relating to the powers of district judges and…
      An Act relating to workplace violence protective orders; relating to attorney fees; relating to the crime of violating a protective order; relating to the powers of district judges and magistrates; amending Rules 4 and 6…
  - (2026-07-31) [Alaska HJR 31] Proposing amendments to the Constitution of the State of Alaska relating to whose rights are protected under the Constitution and prohibiting corporate contributions and expenditures i…
      Proposing amendments to the Constitution of the State of Alaska relating to whose rights are protected under the Constitution and prohibiting corporate contributions and expenditures in state and local elections.
  - (2026-07-31) [Alaska HJR 43] Affirming the Alaska State Legislature's commitment to voter privacy, election integrity, and the right to vote; expressing concern regarding disclosure of confidential voter informati…
      Affirming the Alaska State Legislature's commitment to voter privacy, election integrity, and the right to vote; expressing concern regarding disclosure of confidential voter information to the United States Department o…
  - (2026-07-31) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-07-31) [Alaska HB 211] An Act relating to prepaid legal plans.
      An Act relating to prepaid legal plans.
  - (2026-07-31) [Alaska HB 78] An Act relating to the public employees' retirement system and the teachers' retirement system; and providing certain employees an opportunity to choose between the defined benefit and…
      An Act relating to the public employees' retirement system and the teachers' retirement system; and providing certain employees an opportunity to choose between the defined benefit and defined contribution plans of the p…

### Ukrainian Internal News (national + local Kyiv) — 64 new of 136 total
  - (2026-08-01) "Можемо взяти практично все, що захочемо" – Трамп про угоду з Україною про надра | LEDE: Президент США Дональд Трамп зробив заяву з приводу угоди про рідкісноземельні ресурси, яка, за його слов] (uk:…
      Президент США Дональд Трамп зробив заяву з приводу угоди про рідкісноземельні ресурси, яка, за його словами, забезпечує Сполученим Штатам доступ до українських надр і може виявитися вигіднішою за обсяг наданої американсь…
  - (2026-08-01) Ворог атакує Київ балістикою: в місті пролунали вибухи, виникли пожежі | LEDE: У ніч на 1 серпня росіяни атакували Київ балістичними ракетами.] (uk: Ворог атакує Київ балістикою: в місті пролунали виб…
      У ніч на 1 серпня росіяни атакували Київ балістичними ракетами.
  - (2026-08-01) Росіяни атакували дронами мирних жителів на Сумщині: троє поранених у важкому стані | LEDE: Через атаку ворожих дронів на Сумщині троє людей отримали важкі поранення.] (uk: Росіяни атакували дронами м…
      Через атаку ворожих дронів на Сумщині троє людей отримали важкі поранення.
  - (2026-08-01) На Херсонщині через детонацію невідомого вибуховою пристрою зазнав поранень підліток | LEDE: У Херсонській області підліток отримав травми через детонацію невідомого вибуховою пристрою.] (uk: На Херсо…
      У Херсонській області підліток отримав травми через детонацію невідомого вибуховою пристрою.
  - (2026-07-31) Трамп лякає, що у разі перемоги демократів у США буде гірше, ніж в іспанській Сеуті | LEDE: Трамп заявив, що США зіткнуться з гіршою міграційною кризою, ніж у Сеуті, у разі перемоги демократів.] (uk:…
      Трамп заявив, що США зіткнуться з гіршою міграційною кризою, ніж у Сеуті, у разі перемоги демократів.
  - (2026-07-31) Росіяни зруйнували сортувальний термінал "Нової пошти" у Полтаві | LEDE: Атака РФ зруйнувала термінал Нової пошти у Полтаві. Потерпілих немає, затримки мінімізують, компенсації клієнтам забезпе] (uk:…
      Атака РФ зруйнувала термінал Нової пошти у Полтаві. Потерпілих немає, затримки мінімізують, компенсації клієнтам забезпечать.

### IT, InfoSys & cybersecurity news (last 7 days) — 41 new of 57 total
  - (2026-07-31) [BleepingComputer] Amgen says cloud data breach exposed patient health, proprietary info
      Pharmaceutical company Amgen says it suffered a data breach after threat actors stole corporate data and patient information stored in multiple cloud systems operated by third-party service providers. [...]
  - (2026-07-31) [BleepingComputer] Arch Linux disables AUR package adoption to stop malware flood
      The Arch Linux project has temporarily disabled adoption of Arch User Repository (AUR) packages after a surge in malicious takeovers of existing packages. [...]
  - (2026-07-31) [BleepingComputer] Online ad firm Adform’s script compromised to steal cryptocurrency
      Online advertising firm Adform suffered a supply-chain attack that delivered cryptocurrency-stealing scripts to websites using its ad platform, replacing wallet addresses copied to visitors' clipboards with ones controll…
  - (2026-07-31) [BleepingComputer] OpenAI says its new GPT 5.6 models are becoming more cost-efficient
      OpenAI says it has reduced the price of two GPT-5.6 models, cutting Luna's API price by 80% and Terra's by 20% as it works to make its models more efficient. [...]
  - (2026-07-31) [BleepingComputer] Hacker uses DeepSeek AI to autonomously attack vulnerable servers
      A Chinese-speaking threat actor is using the DeepSeek AI model and the open-source Hermes Agent to conduct autonomous cyberattacks on exposed servers with limited human involvement. [...]
  - (2026-07-31) [The Hacker News] Suspected Chinese-Speaking Hackers Target Central Asian Governments With OctLurk and SilkLurk
      A Chinese-speaking threat actor is suspected to be behind a fresh wave of cyber attacks targeting government organizations mainly located in Central Asia, including Afghanistan, Kyrgyzstan, Tajikistan, Uzbekistan, Kazakh…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-31) [Coleman Richard Kenneth Jr.] Form 4/A (Reporting)
      filed 2026-07-31 23:32 UTC · amended · role: Reporting — Filed: 2026-07-31 AccNo: 0001556224-26-000006 Size: 5 KB
  - (2026-07-31) [Star Equity Holdings, Inc.] Form 4/A (Issuer)
      filed 2026-07-31 23:32 UTC · amended · role: Issuer — Filed: 2026-07-31 AccNo: 0001556224-26-000006 Size: 5 KB
  - (2026-07-31) [Sun Richard] Form 4 (Reporting)
      filed 2026-07-31 23:10 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001437749-26-025265 Size: 15 KB
  - (2026-07-31) [CATHAY GENERAL BANCORP] Form 4 (Issuer)
      filed 2026-07-31 23:10 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001437749-26-025265 Size: 15 KB
  - (2026-07-31) [Owens Angela] Form 4 (Reporting)
      filed 2026-07-31 23:02 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001193125-26-329074 Size: 5 KB
  - (2026-07-31) [American Airlines Group Inc.] Form 4 (Issuer)
      filed 2026-07-31 23:02 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001193125-26-329074 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-31) [United States] Liam Payne Girlfriend Reveals Real Reason Behind Removing Tattoo Tributes
      domain: 961kissonline.iheart.com · language: English · tone:
  - (2026-07-31) [United States] Third St . Jude Dream Home breaks ground in Serenity Oaks
      domain: news4sanantonio.com · language: English · tone:
  - (2026-07-31) [United States] Amid cyclospora concerns , how have California farming communities been impacted ?
      domain: capradio.org · language: English · tone:
  - (2026-07-31) [United States] Nervous About Wildfires ? Sisters Therapist Offers Tips for Staying Calm : Carry on - The Source
      domain: bendsource.com · language: English · tone:
  - (2026-07-31) [United States] Two men charged after brawl at Sea Isle City bar
      domain: nj1015.com · language: English · tone:
  - (2026-07-31) [United States] Coronation Street star Vicky Meyers reveals she is secretly engaged
      domain: dailymail.com · language: English · tone:

### U.S. Federal Action — 39 new of 39 total
  - (2026-07-31) Continuation of the National Emergency With Respect to Lebanon
  - (2026-07-31) Qualification and Certification of Locomotive Engineers and Conductors; English Language Proficiency and Other Requirements
      FRA proposes to amend its regulations governing the qualification and certification of locomotive engineers and conductors to establish English language proficiency as a requirement for a railroad carrier to certify and…
  - (2026-07-31) Amendment of United States Area Navigation Routes (RNAV) T-285 and T-286 in the Vicinity of Thedford, NE
      This action amends the published coordinates of the Thedford, NE, Very High Frequency Omnidirectional Range/Distance Measuring Equipment (VOR/DME) in the legal descriptions of Area Navigation (RNAV) routes T-285 and T-28…
  - (2026-07-31) Amendment of Jet Route J-24 and Very High Frequency Omnidirectional Range Federal Airways V-244, V-508 and Revocation of Very High Frequency Omnidirectional Range Federal Airway V-255 in the Vicinity…
      This action proposes to amend Jet Route J-24 and Very High Frequency Omnidirectional Range Federal (VOR) Airways V-244 and V-508 and revoke VOR Federal Airway V-255 in the vicinity of Hays, Kansas. The FAA is proposing t…
  - (2026-07-31) Modernization of the Nation's Alerting Systems; Protecting the Nation's Communications Systems From Cybersecurity Threats
      In the Report and Order, the Federal Communications Commission (the FCC or the Commission) seeks to preserve the public's trust in the Emergency Alert System (EAS) by requiring targeted cybersecurity improvements that wi…
  - (2026-07-31) Wireless Emergency Alerts; The Emergency Alert System; Modernization of the Nation's Alerting Systems
      In this document, the Federal Communications Commission ("FCC" or "Commission") adopted a Further Notice of Proposed Rulemaking that seeks comment on proposed rules intended to make the Emergency Alert System (EAS) and W…

### Government Action: Sanctions + Procurement + Foreign Agents — 34 new of 111 total
  - (2026-07-30) [OFAC] Counter Terrorism Designations; Non-Proliferation Designation Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Non-Proliferation Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-07-27) [OFAC] Sanctions List Removals; Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Sanctions List Removals; Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions; Issuance of Amended Venezuela-related Frequently Asked Question; Publication of Reg…
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions; Issuance of Amended Venezuela-related Frequently Asked Question; Publication of Regulatory Amendments Office o…
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 26 new of 60 total
  - (2026-07-31) Alaska Supreme Court: In RE: THE MEEKER REVOCABLE TRUST U/A/D July 15, 2014, THE HELEN S. MEEKER SURVIVORS' TRUST, Established by July 28, 2018 and FIRST AMENDMENT Thereto Dated September 3, 2018
  - (2026-07-31) U.S. Court of Appeals, D.C. Cir.: Adele Ruppe v. Marco Rubio
  - (2026-07-31) U.S. Court of Appeals, D.C. Cir.: Advanced Energy United v. FERC
  - (2026-07-31) U.S. Court of Appeals, D.C. Cir.: Arthur Sookra v. Pfizer Inc.
  - (2026-07-31) U.S. Court of Appeals, D.C. Cir.: Ralph de la Torre v. Bill Cassidy
  - (2026-07-31) U.S. Court of Appeals, D.C. Cir.: United States v. Antonio Payne

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-31) [Israel-Iran-Hezbollah axis · themes] Liam Payne Girlfriend Reveals Real Reason Behind Removing Tattoo Tributes
      961kissonline.iheart.com · English · tone NA
  - (2026-07-31) [Israel-Iran-Hezbollah axis · themes] Amid cyclospora concerns , how have California farming communities been impacted ?
      capradio.org · English · tone NA
  - (2026-07-31) [Israel-Iran-Hezbollah axis · themes] Hijo de puta Pedro Sanchez ! con queste parole è stato accolto il premier Spagnolo
      strettoweb.com · Italian · tone NA
  - (2026-07-31) [Israel-Iran-Hezbollah axis · themes] Aeronautica , cambio al comando del 37esimo stormo di Trapani
      tp24.it · Italian · tone NA
  - (2026-07-31) [Israel-Iran-Hezbollah axis · themes] Coronation Street star Vicky Meyers reveals she is secretly engaged
      dailymail.com · English · tone NA
  - (2026-07-31) [Israel-Iran-Hezbollah axis · themes] Rapper marroquino Mehdi Black Wind libertado sob fiança
      sapo.pt · Portuguese · tone NA

### Paper Trading Scorecard — 20 new of 145 total
  - (2026-07-31) [Polymarket] Will Bitcoin reach $68,000 July 27-August 2?
      This market will immediately resolve to "Yes" if any Binance 1-minute candle for BTC/USDT during the date range specified in the title (from 12:00 AM ET on the first date to 11:59 PM ET on the last) has a final "High" pr…
  - (2026-07-31) [Polymarket] Will the Fed decrease interest rates by 50+ bps after the October 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-07-31) [Polymarket] Will there be no change in Fed interest rates after the October 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-07-31) [Manifold] Will AWS S3 globally have more downtime 2027 than 2026?
  - (2026-07-31) [Manifold] Will Situational Awareness be bigger than Citadel by EOY 2029?
  - (2026-07-31) [Manifold] "Spider-Man: Brand New Day" breaks the record for the biggest opening weekend of all time?

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-07-31) M 5.6 - 13 km ENE of San Fernando, Peru
      M5.6 · 13 km ENE of San Fernando, Peru · depth 154.355 km
  - (2026-07-31) M 5.2 - 141 km ENE of Masohi, Indonesia
      M5.2 · 141 km ENE of Masohi, Indonesia · depth 10 km
  - (2026-07-31) M 5.2 - 85 km SW of El Arenal, Mexico
      M5.2 · 85 km SW of El Arenal, Mexico · depth 10 km
  - (2026-07-31) M 5.1 - 153 km ENE of Masohi, Indonesia
      M5.1 · 153 km ENE of Masohi, Indonesia · depth 10 km
  - (2026-07-31) M 5.1 - South Sandwich Islands region
      M5.1 · South Sandwich Islands region · depth 70.706 km
  - (2026-07-31) M 5.1 - 69 km W of Coquimbo, Chile
      M5.1 · 69 km W of Coquimbo, Chile · depth 21.344 km

### Government & military aircraft airborne (OpenSky) — 15 new of 16 total
  - (2026-07-31) PAT417 (United States)
      icao24: adfe4c · position: (36.9535, -88.7202) · alt: 7924m · 411km/h
  - (2026-07-31) PAT415 (United States)
      icao24: adfe95 · position: (35.9723, -91.65) · alt: 6408m · 523km/h
  - (2026-07-31) RCH525 (United States)
      icao24: ae08e3 · position: (47.9959, -62.6609) · alt: 8839m · 891km/h
  - (2026-07-31) PAT410A (United States)
      icao24: ae08fb · position: (33.8734, -98.5569) · alt: 6400m · 475km/h
  - (2026-07-31) CFC4503 (Canada)
      icao24: c07703 · position: (55.3298, -118.7228) · alt: 4488m · 199km/h
  - (2026-07-31) NCR850 (United States)
      icao24: acfc26 · position: (33.7708, -109.1198) · alt: 9448m · 909km/h

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-07-31) Will Hamas agree to disarm by December 31?
      yes price: 66% · 24h volume: $805,100 · resolves 2026-12-31
  - (2026-07-31) Will WTI Crude Oil (WTI) hit (HIGH) $90 in July?
      yes price: 0% · 24h volume: $542,827 · resolves 2026-08-01
  - (2026-07-31) Israel x Iran ceasefire continues through July 31?
      yes price: 100% · 24h volume: $475,636 · resolves 2026-07-31
  - (2026-07-31) Pittsburgh Pirates vs. Cincinnati Reds
      yes price: 36% · 24h volume: $414,131 · resolves 2026-08-07
  - (2026-07-31) Israel x Iran ceasefire continues through August 2?
      yes price: 78% · 24h volume: $313,358 · resolves 2026-08-02
  - (2026-07-31) Kharg Island no longer under Iranian control by July 31?
      yes price: 0% · 24h volume: $301,731 · resolves 2026-06-30

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 37 total
  - (2026-07-31) #30 Germán Larrea Mota Velasco & family — $63.47B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-31) MOVER ▲ Larry Page — $292.11B (+$0.11B since yesterday)
      United States · Technology · source: Google
  - (2026-07-31) MOVER ▼ Carlos Slim Helu & family — $125.83B ($-0.11B since yesterday)
      Mexico · Telecom · source: Telecom
  - (2026-07-31) MOVER ▲ Sergey Brin — $269.43B (+$0.10B since yesterday)
      United States · Technology · source: Google
  - (2026-07-31) MOVER ▼ Warren Buffett — $145.09B ($-0.09B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway
  - (2026-07-31) MOVER ▼ Germán Larrea Mota Velasco & family — $63.47B ($-0.06B since yesterday)
      Mexico · Metals & Mining · source: Mining

### Campaign finance (FEC: top fundraisers + recent filings) — 6 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-07-31) [Marginal Revolution] *Redefining Global Health in the 21st Century*
      While donor-driven programs undoubtedly saved millions of lives, they also created unintended distortions in national health priorities. Many governments in sub-Saharan Africa and parts of Asia actually scaled back domes…
  - (2026-07-31) [Marginal Revolution] Friday assorted links
      1. Tokenizing the value from compute? 2. Will they ruin the look of Dulles airport? 3. Pathways into homelessness. 4. Defensible valuations for AI companies. 5. Further reasons why very rapid economic growth is very diff…
  - (2026-07-31) [Marginal Revolution] An unprecedented weapon?
      I wonder if England had a “pause” movement back then: Trebuchets reached the peak of their development in medieval times, probably the most famous example being Edward I’s massive machine, Warwolf. This terrifying device…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-31) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=39, 7d-median=20, 14d-median=20; carrying terms: certain, proposes, action, airworthiness, requires, final, directives, model, national, provide, security, published
- state_bills: today=152, 7d-median=138, 14d-median=138; carrying terms: person, operating, access, appropriate, unless, allows, based, private, district, income, include, authorizes
- state_news: today=1022, 7d-median=711, 14d-median=842; carrying terms: making, oversight, government, recent, person, decided, dozen, fifty, elsewhere, image, access, chief
- local_news: today=282, 7d-median=228, 14d-median=228; carrying terms: louis, image, major, residents, against, court, election, officials, based, following, district, evening
- foreign_news: today=1081, 7d-median=1022, 14d-median=1023; carrying terms: making, linked, government, scratched, recent, india, warned, heatwave, recovered, deputy, spread, diversion
- chinese_internal: today=317, 7d-median=265, 14d-median=270; carrying terms: china, chinese, https, caixin, people, google, giant, global, demand, stock, firms, investment
- russian_internal: today=937, 7d-median=916, 14d-median=912; carrying terms: guardian, russian, client, httperror, error, group, gazeta, wildberries, openai, found, forbidden, axios
- ukrainian_internal: today=136, 7d-median=136, 14d-median=136; carrying terms: linked, government, recent, russian, deputy, international, operating, foreign, warehouse, major, against, network
- ukraine_theater: today=1140, 7d-median=627, 14d-median=606; carrying terms: nominal, alerts, anomaly, client, coverage, https, known, deepstatemap, google, extra, cartography, firms
- paper_bets: today=145, 7d-median=138, 14d-median=140; carrying terms: koivun, leave, florida, lesswrong, retirement, pirates, manifold, determined, james, miami, alaska, event
- weather: today=188, 7d-median=175, 14d-median=174; carrying terms: ongoing, louis, frequent, warned, moderate, degrees, statement, morning, short, sunday, flooding, period
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: sheet, dexuseu, dexjpus, rates, dcoilwtico, funds, energy, jolts, payems, cpiaucsl, consumption, inflation
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: large, range, silver, futures, rates, bitcoin, equities, natural, china, corporate, credit, crypto
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=115, 14d-median=116; carrying terms: misappropriation, government, detect, cyber, lebanon, concerning, russian, manufacturing, specific, haitian, myanmar, human
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, https, error, quantitative, unauthorized, congresstrading, client, httperror, quiverquant
- billionaires: today=37, 7d-median=37, 14d-median=36; carrying terms: peterffy, michael, zuckerberg, bettencourt, tesla, googl, ellison, india, jensen, madrid, francoise, tiktok
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: trade, international, appeals, delaware, supreme, court, california, blanche, services, group, johnson, arizona
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, michael, amended, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, alexandria, robert, michael, angels, pinkston, david, booker, committee, krishnamoorthi, cycle, senate
- gdelt_regions: today=6, 7d-median=12, 14d-median=12; carrying terms: english, japan, switch
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, chinese, black
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: english, domain, language, strike, kingdom, trump, years, iheart, crash
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=16, 7d-median=16, 14d-median=16; carrying terms: position, canada, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: jerusalem, ongoing, country, linked, ethiopian, different, hospitalized, government, leste, resulting, tested, separated
- cisa_kev: today=9, 7d-median=16, 14d-median=16; carrying terms: improper, vulnerability, remediation, authentication, untrusted, sharepoint, control, fortinet, microsoft, deserialization, vendor, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=311, 7d-median=287, 14d-median=286; carrying terms: marino, liechtenstein, monaco, brazil, belarus, denmark, minor, tropical, madagascar, republic, australia, papua
- usgs_quakes: today=17, 7d-median=23, 14d-median=23; carrying terms: islands, region, depth, south, indonesia, mexico, kermadec, japan, chile, china, puerto
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: interest, rates, resolves, meeting, minister, volume, price, prime, ethiopia, abiebie, increase, change
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: marginal, revolution, conversable, marginalrevolution, class, https, economist, assorted, looking, links, certain, students
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: government, cyber, spectrum, article, openai, exposed, against, network, weekday, daily, model, called
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: palmer, louis, conaway, robert, walkinshaw, turner, gimenez, defense, fetterman, christopher, richmond, components
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, market, paper, today, decision, consensus, placed, module, markets, identify, placement, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*