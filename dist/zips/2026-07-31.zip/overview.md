# WORLDSCOPE morning brief — 2026-07-31

## Headline
3915 new items across 26 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (764) · International News + Multilateral Institutions (739) · Russian Internal News (state + in-exile) (655) · World leaders & government officials (324) · Chinese Internal News (283) · State-Level News (279) · Local News: St. Louis + Atlanta (245) · U.S. Weather + Severe / Climate Outlooks (190) · Ukrainian Internal News (national + local Kyiv) (62) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · U.S. Federal Action (39)

## What changed today
### Ukraine Theater (total-war monitoring) — 764 new of 1140 total
  - (2026-07-31) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-29) [Liveuamap] Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting group&039;s headquarters in several provinces Amerli, Saladin Governorat…
      Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting gro
  - (2026-07-29) [Liveuamap] US Central Command: Our forces and Saudi armed forces conducted precision strikes in Iraq against Iranian proxies. US and Saudi fighter jets launched raids targeting logistics sites and we…
      US Central Command: Our forces and Saudi armed forces conducted precision strikes in Iraq against Iranian proxies. US and Sa
  - (2026-07-30) [Liveuamap] Ukrainian Air Force: Several waves of Kh-101 cruise missile launches from strategic aircraft: Tu-95MS and Tu-160 - liveuamap.com
      Ukrainian Air Force: Several waves of Kh-101 cruise missile launches from strategic aircraft: Tu-95MS and Tu-160
  - (2026-07-30) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - syria.liveuamap.com
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com syria.liveuamap.com
  - (2026-07-31) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - yemen.liveuamap.com
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com yemen.liveuamap.com

### International News + Multilateral Institutions — 739 new of 1077 total
  - (2026-07-31) [Global] Spain's PM blames traffickers after 60,000 migrants reach Ceuta from Morocco
      Spain said most had returned to Morocco by Friday evening, as Italy suspended its Schengen agreement on free movement with Madrid.
  - (2026-07-31) [Global] Bowen: Plan for Hamas to disarm faces big obstacles, yet it offers rare hope for Gaza
      The realities of politics, war, zero trust, the deaths of thousands and the destruction of Gaza will make any agreement very complicated.
  - (2026-07-31) [Global] Two bodies located and search ongoing after avalanche hits Nirmal Purja's team
      Two bodies have been recovered from Pakistan's Broad Peak and seven spotted by drones - though their condition remains unclear.
  - (2026-07-31) [Global] Peru's ex-president has 15-year jail sentence for corruption charges overturned
      Ollanta Humala had been convicted of money laundering offences alongside his wife in 2025.
  - (2026-07-31) [Global] Hundreds escape Greek wildfire by sea as blazes continue across Europe
      Around 500 people, mostly tourists, are evacuated by boat from Agios Vasileios after becoming trapped.
  - (2026-07-31) [Global] Fifa says 'nobody selling football' as plan continues
      Football's governing body Fifa plans to continue the consultation process after Uefa threatens to boycott World Cups.

### Russian Internal News (state + in-exile) — 655 new of 1206 total
  - (2026-07-31) Правительство запретило майнинг криптовалют в Москве и Московской области до 2033 года | LEDE: В Москве, Подмосковье и в восьми приграничных районах Курской области запретили майнинг криптов] (ru: Пра…
      В Москве, Подмосковье и в восьми приграничных районах Курской области запретили майнинг криптовалют. Запрет будет действовать с 15 августа 2026 до 31 декабря 2032 года. Такое постановление подписал премьер-министр России…
  - (2026-07-31) «Помочь вам можем только мы и государство». Татьяна Ким обратилась к продавцам Wildberries после двух недель украинских ударов по складам маркетплейса. Вот что она сказала — максимально коротко] (ru:…
      Уже две недели наша компания подвергается террористическим атакам. Почему именно мы? Террористы говорят, что мы продаем товары военного назначения. Но вы можете открыть хоть Amazon, хоть Alibaba и посмотреть, есть ли у н…
  - (2026-07-31) Издание «Код Дурова» убрало из названия фамилию Дурова | LEDE: Российское издание о технологиях «Код Дурова» сменило название на «Код.ру». Сообщение о ребрендинге опубликовано на сайте и в с] (ru: Изд…
      Российское издание о технологиях «Код Дурова» сменило название на «Код.ру». Сообщение о ребрендинге опубликовано на сайте и в соцсетях издания.
  - (2026-07-31) Италия закроет границы с Испанией из-за наплыва мигрантов в Сеуту | LEDE: Италия приостановит действие Шенгенского соглашения с Испанией из-за наплыва нелегальных иммигрантов в испанский экс] (ru: Ита…
      Италия приостановит действие Шенгенского соглашения с Испанией из-за наплыва нелегальных иммигрантов в испанский эксклав Сеуту. Такое решение приняло министерство внутренних дел Италии, сообщили местные издания ANSA и La…
  - (2026-07-31) Офис Зеленского попросил генпрокурора Украины завести уголовное дело на Лукашенко | LEDE: Офис президента Украины Владимира Зеленского попросил офис генерального прокурора рассмотреть возмож] (ru: Офи…
      Офис президента Украины Владимира Зеленского попросил офис генерального прокурора рассмотреть возможность возбудить уголовное дело против Александра Лукашенко. Эту информацию «Укринформу» подтвердила спикер офиса генпрок…
  - (2026-07-31) Президент ФИФА хочет продать долю в чемпионате мира и отдать контроль над финансами родственнику Трампа. Футбольные чиновники со всего мира против — их даже не предупредили | LEDE: Президент] (ru: Пре…
      Президент ФИФА Джанни Инфантино решил продать доли в чемпионатах мира частным инвесторам. Если этот проект будет одобрен, каждая из 211 национальных ассоциаций, входящих в состав Международной федерации футбола, получит…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 283 new of 314 total
  - (2026-07-30) 《自然》回应“耿同学”打假 两篇论文撤稿一篇论文更正(含视频) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMigAFBVV95cUxQTHF4ekw1X045YTJrTTFoNWJ4MjFLaGxrQ3pHT0gweFpCN3F1bWVhWVhMd3V4VFFQMUFyZlZQZGRReGs3c0dfaF] (zh:…
      《自然》回应“耿同学”打假 两篇论文撤稿一篇论文更正(含视频) 财新
  - (2026-07-29) 日本熊本地震已致12人死亡 商场为何在震后发生爆炸成焦点 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5PdmRKNXljeVB4UHJkOTBjVjhkWllIVG91bFJLeUc2TmpEQXdNVTRxeWNIbnI2dHVrMzRPVmVUTFRHZ2tGNHJGQVZUd] (zh:…
      日本熊本地震已致12人死亡 商场为何在震后发生爆炸成焦点 财新
  - (2026-07-29) 就王虹推荐信，北大数院发声 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE92YTh2Vmw3Q3I4V3JMc29GcVlCdnZsaWExcVdKQW85TXc0MUkyQlhQamx6b3NIaVBUeVlwbl9iTFQ4aUNneUZHc19PQ3NhRTdKTmtfYi1p] (zh:…
      就王虹推荐信，北大数院发声 财新
  - (2026-07-30) 今日开盘：两市双双低开 沪指跌幅0.43% - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE40bFk5Um0wQUdVOEl2TGlweld5TWtxd1NFUm9IUmIzUzFIajhQMFdYWFRqclJPX194YXBsQWlwMEc5YWls] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.43% finance.caixin.com
  - (2026-07-31) 工业绿色低碳发展“十五五”规划发布 2030年实现工业领域“碳达峰” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5pczZWeVlIMjUyYUNCRjlGa24yRjA3UlhKT0l5M0xpMXdkRzJRNjNWSmUtWjJycFV3V1FpM2syVEdnOWV4WkF] (zh:…
      工业绿色低碳发展“十五五”规划发布 2030年实现工业领域“碳达峰” 财新
  - (2026-07-31) 今日开盘：两市双双高开 沪指涨幅0.76% - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1XUU5XLWpnVUpGRV9jZWZzSmhWQTk0TnBkSjcwVnpBWjliMkRFdmpnRnZ3TmJFSFo3bFVyNGRsNENiUXRU] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.76% finance.caixin.com

### State-Level News — 279 new of 948 total
  - (2026-07-31) [California] California launches next phase of state cybersecurity plan as AI changes threat landscape
      Source
  - (2026-07-31) [California] California se moviliza para proteger a las comunidades mientras el calor del verano afecta al oeste del país
      Source
  - (2026-07-31) [California] California mobilizes to protect communities as summer heat builds across the West
      Source
  - (2026-07-31) [California] Governor Newsom announces California will raise statewide minimum wage
      Source
  - (2026-07-31) [California] Why federal court struck down Trump’s mass detention policy
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072026-Otay-Mesa-GB-AP-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-07-31) [California] David Valadao lost in the last anti-Trump blue wave. Will farmers help him win this time?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/030626-David-Valadao-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### Local News: St. Louis + Atlanta — 245 new of 276 total
  - (2026-07-31) [St. Louis] Why St. Louis is poised to lead a ragtime renaissance
  - (2026-07-31) [St. Louis] Madison County Board Chairman Slusser defends Fauci hanging post as 'rhetorical hyperbole'
  - (2026-07-31) [St. Louis] Making it harder to amend the Missouri Constitution is facing strong pushback
  - (2026-07-31) [St. Louis] Aldermanic committee calls on St. Louis Public Schools to delay vote for school closures
  - (2026-07-31) [St. Louis] Former pandemic-era health chief to return as St. Louis health director
  - (2026-07-31) [St. Louis] Meet the Metro East preschooler whose love of lawn care became an internet sensation
      A landscaper pulls into the parking lot, unloads a zero-turn mower, and starts trimming the grass. Most preschoolers barely notice. Grant Wymer doesn’t miss a thing. He studies every movement, watches every turn of the s…

### U.S. Weather + Severe / Climate Outlooks — 190 new of 195 total
  - (2026-07-31) [Severe] Special Marine Warning: Special Marine Warning issued July 31 at 3:14PM CDT until July 31 at 4:15PM CDT by NWS Mobile AL
      SMWMOB The National Weather Service in Mobile has issued a * Special Marine Warning for... North Mobile Bay... * Until 415 PM CDT. * At 313 PM CDT, a strong thunderstorm capable of producing waterspouts was located over…
  - (2026-07-31) [Moderate] Special Weather Statement: Special Weather Statement issued July 31 at 2:14PM MDT by NWS Pueblo CO
      At 214 PM MDT, Doppler radar was tracking a strong thunderstorm near Red Wing, or 39 miles northeast of Alamosa, moving southeast at 20 mph. HAZARD...Wind gusts up to 50 mph and nickel size hail. SOURCE...Radar indicated…
  - (2026-07-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 31 at 3:13PM CDT until July 31 at 4:00PM CDT by NWS Memphis TN
      SVRMEG The National Weather Service in Memphis has issued a * Severe Thunderstorm Warning for... Fayette County in west Tennessee... Western Hardeman County in west Tennessee... Southeastern Haywood County in west Tennes…
  - (2026-07-31) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 31 at 1:12PM MST until August 3 at 8:00PM MST by NWS Phoenix AZ
      * WHAT...Dangerously hot conditions. Afternoon temperatures 110 to 117. Major to Extreme Heat Risk. * WHERE...The Phoenix metropolitan area. * WHEN...Until 8 PM MST Monday. * IMPACTS...Increase in heat related illnesses,…
  - (2026-07-31) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 31 at 1:12PM MST until August 3 at 8:00PM MST by NWS Phoenix AZ
      * WHAT...Dangerously hot conditions. Afternoon temperatures 112 to 120. Major to Extreme Heat Risk. * WHERE...In Arizona, Parker Valley and Yuma. In California, Imperial Valley, and Palo Verde Valley. * WHEN...Until 8 PM…
  - (2026-07-31) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 31 at 1:12PM MST until August 3 at 8:00PM MST by NWS Phoenix AZ
      * WHAT...Dangerously hot conditions. Afternoon temperatures 109 to 119. Major to Extreme Heat Risk. * WHERE...Aguila Valley, Apache Junction/Gold Canyon, Cave Creek/New River, Fountain Hills/East Mesa, Gila Bend, Northwe…

### Ukrainian Internal News (national + local Kyiv) — 62 new of 134 total
  - (2026-07-31) Росіяни зруйнували сортувальний термінал "Нової пошти" у Полтаві | LEDE: Внаслідок атаки РФ у п'ятницю зруйновано сортувальний термінал "Нової пошти" у Полтаві.] (uk: Росіяни зруйнували сортувальний т…
      Внаслідок атаки РФ у п'ятницю зруйновано сортувальний термінал "Нової пошти" у Полтаві.
  - (2026-07-31) Росіяни атакували три райони Харкова: пошкоджено будинок, є постраждалі | LEDE: Внаслідок атаки дронів 31 липня у Харкові поранено трьох жінок, госпіталізовано, зафіксовано удари по кількох рай] (uk:…
      Внаслідок атаки дронів 31 липня у Харкові поранено трьох жінок, госпіталізовано, зафіксовано удари по кількох районах міста.
  - (2026-07-31) На фронті понад 200 боїв, найбільше на Покровському напрямку – Генштаб | LEDE: ЗСУ відбили понад 200 атак на Покровському, Костянтинівському, Лиманському та інших напрямках.] (uk: На фронті понад 200…
      ЗСУ відбили понад 200 атак на Покровському, Костянтинівському, Лиманському та інших напрямках.
  - (2026-07-31) В Іспанії заявили, що майже всі нелегальні мігранти вже повернулися з Сеути до Марокко | LEDE: Понад 48 тисяч мігрантів, які потрапили до Сеути, вже повернулися до Марокко, заявив уряд Іспанії.] (uk:…
      Понад 48 тисяч мігрантів, які потрапили до Сеути, вже повернулися до Марокко, заявив уряд Іспанії.
  - (2026-07-31) Нові прем'єри України та Молдови провели першу розмову | LEDE: ] (uk: Нові прем'єри України та Молдови провели першу розмову)
  - (2026-07-31) На Київщині через атаку ворожих БпЛА постраждав чоловік | LEDE: У Броварському районі Київщини у п'ятницю ввечері через атаку ворожих БпЛА постраждав чоловік.] (uk: На Київщині через атаку ворожих БпЛ…
      У Броварському районі Київщини у п'ятницю ввечері через атаку ворожих БпЛА постраждав чоловік.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-31) 497J - WISCONSIN CAPITAL FUNDS INC (0001395397) (Filer)
      filed 2026-07-31 20:14 UTC — Filed: 2026-07-31 AccNo: 0001580642-26-004766 Size: 28 KB
  - (2026-07-31) [Nienhuis Jeremiah] Form 4 (Reporting)
      filed 2026-07-31 20:13 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001628280-26-051410 Size: 5 KB
  - (2026-07-31) [LiveWire Group, Inc.] Form 4 (Issuer)
      filed 2026-07-31 20:13 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001628280-26-051410 Size: 5 KB
  - (2026-07-31) [Saunders Richard] Form 4 (Reporting)
      filed 2026-07-31 20:13 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001653242-26-000067 Size: 4 KB
  - (2026-07-31) [Bank of N.T. Butterfield & Son Ltd] Form 4 (Issuer)
      filed 2026-07-31 20:13 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001653242-26-000067 Size: 4 KB
  - (2026-07-31) 424B3 - XCF Global, Inc. (0002019793) (Filer)
      filed 2026-07-31 20:13 UTC — Filed: 2026-07-31 AccNo: 0001213900-26-083973 Size: 33 MB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-31) [United States] Were going to get every answer on teen Modoc death , attorney says
      domain: wrdw.com · language: English · tone:
  - (2026-07-31) [Niger] Xenophobia : Oborevwori approves ₦2m grant for evacuated Deltans – Daily Trust
      domain: dailytrust.com · language: English · tone:
  - (2026-07-31) [United States] Camp David , the president rustic Maryland mountain retreat , through the years
      domain: news4jax.com · language: English · tone:
  - (2026-07-31) [United States] State AGs expand consumer work as prices rise and Trump guts federal protections
      domain: montereyherald.com · language: English · tone:
  - (2026-07-31) [Ireland] Jail for man , 20s , who told pregnant wife he didnt care if the baby was dead during attack
      domain: irishmirror.ie · language: English · tone:
  - (2026-07-31) [United States] A Senate Committee Voted 22 to 0 to Cover the Health Data That HIPAA Was Never Written to Protect
      domain: medicaldaily.com · language: English · tone:

### U.S. Federal Action — 39 new of 39 total
  - (2026-07-31) Continuation of the National Emergency With Respect to Lebanon
  - (2026-07-31) Qualification and Certification of Locomotive Engineers and Conductors; English Language Proficiency and Other Requirements
      FRA proposes to amend its regulations governing the qualification and certification of locomotive engineers and conductors to establish English language proficiency as a requirement for a railroad carrier to certify and…
  - (2026-07-31) Amendment of United States Area Navigation Routes (RNAV) T-285 and T-286 in the Vicinity of Thedford, NE
      This action amends the published coordinates of the Thedford, NE, Very High Frequency Omnidirectional Range/Distance Measuring Equipment (VOR/DME) in the legal descriptions of Area Navigation (RNAV) routes T-285 and T-28…
  - (2026-07-31) Amendment of Jet Route J-24 and Very High Frequency Omnidirectional Range Federal Airways V-244, V-508 and Revocation of Very High Frequency Omnidirectional Range Federal Airway V-255 in the Vicinity…
      This action proposes to amend Jet Route J-24 and Very High Frequency Omnidirectional Range Federal (VOR) Airways V-244 and V-508 and revoke VOR Federal Airway V-255 in the vicinity of Hays, Kansas. The FAA is proposing t…
  - (2026-07-31) Modernization of the Nation's Alerting Systems; Protecting the Nation's Communications Systems From Cybersecurity Threats
      In the Report and Order, the Federal Communications Commission (the FCC or the Commission) seeks to preserve the public's trust in the Emergency Alert System (EAS) by requiring targeted cybersecurity improvements that wi…
  - (2026-07-31) Wireless Emergency Alerts; The Emergency Alert System; Modernization of the Nation's Alerting Systems
      In this document, the Federal Communications Commission ("FCC" or "Commission") adopted a Further Notice of Proposed Rulemaking that seeks comment on proposed rules intended to make the Emergency Alert System (EAS) and W…

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 57 total
  - (2026-07-31) [BleepingComputer] OpenAI says its new GPT 5.6 models are becoming more cost-efficient
      OpenAI says it has reduced the price of two GPT-5.6 models, cutting Luna's API price by 80% and Terra's by 20% as it works to make its models more efficient. [...]
  - (2026-07-31) [BleepingComputer] Hacker uses DeepSeek AI to autonomously attack vulnerable servers
      A Chinese-speaking threat actor is using the DeepSeek AI model and the open-source Hermes Agent to conduct autonomous cyberattacks on exposed servers with limited human involvement. [...]
  - (2026-07-31) [BleepingComputer] CISA warns of cyberattacks disrupting U.S. water utilities
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) is warning of a significant increase in attacks targeting internet-exposed programmable logic controllers (PLCs) in the water and wastewater systems sector…
  - (2026-07-31) [BleepingComputer] ESET tracks rise in malicious AI skills and adaptable malware
      Attackers are adapting established techniques to AI platforms, emerging technologies, and changing user behavior. ESET's new threat report examines the rise of malicious AI skills, AI-assisted malware, ClickFix attacks,…
  - (2026-07-31) [BleepingComputer] Anthropic's Claude breached 3 orgs, uploaded PyPI malware during tests
      One of Anthropic's Claude models built and uploaded a malicious Python package to PyPI during a botched security evaluation, where it ran on 15 real systems and stole credentials from a security vendor. It was one of thr…
  - (2026-07-31) [The Hacker News] Suspected Chinese-Speaking Hackers Target Central Asian Governments With OctLurk and SilkLurk
      A Chinese-speaking threat actor is suspected to be behind a fresh wave of cyber attacks targeting government organizations mainly located in Central Asia, including Afghanistan, Kyrgyzstan, Tajikistan, Uzbekistan, Kazakh…

### Government Action: Sanctions + Procurement + Foreign Agents — 34 new of 111 total
  - (2026-07-30) [OFAC] Counter Terrorism Designations; Non-Proliferation Designation Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Non-Proliferation Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-07-27) [OFAC] Sanctions List Removals; Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Sanctions List Removals; Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions; Issuance of Amended Venezuela-related Frequently Asked Question; Publication of Reg…
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions; Issuance of Amended Venezuela-related Frequently Asked Question; Publication of Regulatory Amendments Office o…
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)

### State Legislative Action — 30 new of 95 total
  - (2026-07-31) [Alaska HB 78] An Act relating to the public employees' retirement system and the teachers' retirement system; and providing certain employees an opportunity to choose between the defined benefit and…
      An Act relating to the public employees' retirement system and the teachers' retirement system; and providing certain employees an opportunity to choose between the defined benefit and defined contribution plans of the p…
  - (2026-07-31) [Alaska HB 194] An Act establishing an income tax on certain entities producing or transporting oil or gas in the state; approving and ratifying the sale of royalty oil by the State of Alaska to Marat…
      An Act establishing an income tax on certain entities producing or transporting oil or gas in the state; approving and ratifying the sale of royalty oil by the State of Alaska to Marathon Petroleum Supply and Trading Com…
  - (2026-07-31) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-07-31) [Alaska SB 237] An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Departm…
      An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Department of Administration; relating to e…
  - (2026-07-30) [Alaska SB 174] An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
      An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
  - (2026-07-30) [Alaska SB 24] An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco,…
      An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco, a product containing nicotine, or…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-31) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (42.7025, -2.9179) · alt: 11277m · 854km/h
  - (2026-07-31) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (40.4208, 0.7912) · alt: 10652m · 755km/h
  - (2026-07-31) PAT877 (United States)
      icao24: adfe49 · position: (36.1642, -78.7714) · alt: 1562m · 442km/h
  - (2026-07-31) PAT850 (United States)
      icao24: adfe4b · position: (59.0847, -151.5092) · alt: 7010m · 501km/h
  - (2026-07-31) PAT415 (United States)
      icao24: adfe95 · position: (37.8746, -87.2686) · alt: 8031m · 361km/h
  - (2026-07-31) PAT413 (United States)
      icao24: adfebc · position: (32.5065, -104.9983) · alt: 7498m · 690km/h

### Court opinions of consequence (federal & state) — 25 new of 60 total
  - (2026-07-31) Alaska Supreme Court: In RE: THE MEEKER REVOCABLE TRUST U/A/D July 15, 2014, THE HELEN S. MEEKER SURVIVORS' TRUST, Established by July 28, 2018 and FIRST AMENDMENT Thereto Dated September 3, 2018
  - (2026-07-31) Alaska Supreme Court: In RE: THE MEEKER REVOCABLE TRUST U/A/D July 15, 2014, THE HELEN S. MEEKER SURVIVORS' TRUST, Established by July 28, 2018 and FIRST AMENDMENT Thereto Dated September 3, 2018
  - (2026-07-31) U.S. Court of Appeals, 7th Cir.: Jimia Stokes v. Illinois Department of Corrections
  - (2026-07-31) U.S. Court of Appeals, 7th Cir.: Maureen Fox v. DuPage Township
  - (2026-07-31) U.S. Court of Appeals, 7th Cir.: Thomas H. Hooper v. Jill R. Crawford
  - (2026-07-31) U.S. Court of Appeals, 7th Cir.: United States v. Mona Ghosh

### Paper Trading Scorecard — 18 new of 146 total
  - (2026-07-31) [Polymarket] Will Bitcoin reach $68,000 July 27-August 2?
      This market will immediately resolve to "Yes" if any Binance 1-minute candle for BTC/USDT during the date range specified in the title (from 12:00 AM ET on the first date to 11:59 PM ET on the last) has a final "High" pr…
  - (2026-07-31) [Polymarket] Will Liverpool win the 2026-27 English Premier League (EPL) Championship?
      This market will resolve according to the team that wins the 2026-27 English Premier League (EPL) Championship. If at any point it becomes impossible for a listed team to win the 2026-27 English Premier League (EPL) Cham…
  - (2026-07-31) [Manifold] Will Situational Awareness be bigger than Citadel by EOY 2029?
  - (2026-07-31) [Manifold] "Spider-Man: Brand New Day" breaks the record for the biggest opening weekend of all time?
  - (2026-07-31) [Manifold] Will I leave the house every day in August? (Ṁ10 Bonus)
  - (2026-07-31) [Manifold] Will any newly elected representatives be denied a seat in congress?

### USGS earthquakes (M4.5+, past day) — 13 new of 16 total
  - (2026-07-31) M 5.6 - 13 km ENE of San Fernando, Peru
      M5.6 · 13 km ENE of San Fernando, Peru · depth 154.355 km
  - (2026-07-31) M 5.2 - 85 km SW of El Arenal, Mexico
      M5.2 · 85 km SW of El Arenal, Mexico · depth 10 km
  - (2026-07-31) M 5.1 - 69 km W of Coquimbo, Chile
      M5.1 · 69 km W of Coquimbo, Chile · depth 21.344 km
  - (2026-07-31) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 37.846 km
  - (2026-07-31) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 35 km
  - (2026-07-31) M 4.9 - 287 km SW of Banda Aceh, Indonesia
      M4.9 · 287 km SW of Banda Aceh, Indonesia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-31) Counter-Strike: paiN vs Astralis (BO3) - BLAST Bounty Playoffs
      yes price: 0% · 24h volume: $1,896,053 · resolves 2026-07-31
  - (2026-07-31) Counter-Strike: paiN vs Astralis - Map 2 Winner
      yes price: 0% · 24h volume: $1,096,683 · resolves 2026-07-31
  - (2026-07-31) New York Yankees vs. Chicago Cubs
      yes price: 88% · 24h volume: $1,016,464 · resolves 2026-08-07
  - (2026-07-31) Dota 2: Xtreme Gaming vs LGD Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $868,159 · resolves 2026-07-31
  - (2026-07-31) Mubadala Citi DC Open: Alex de Minaur vs Brandon Nakashima
      yes price: 0% · 24h volume: $841,204 · resolves 2026-08-07
  - (2026-07-31) LoL: Movistar KOI vs Shifters - Game 1 Winner
      yes price: 0% · 24h volume: $786,753 · resolves 2026-07-31

### GDACS — global disaster alerts — 8 new of 311 total
  - (2026-07-31) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.6M, Depth:154.355km
  - (2026-07-31) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.6M, Depth:154.355km
  - (2026-07-30) [Green] Forest fires in Greece
      Wildfire · Green alert · Greece · Green impact for forestfire in 1420 ha
  - (2026-07-30) [Green] Forest fires in Greece
      Wildfire · Green alert · Greece · Green impact for forestfire in 1420 ha
  - (2026-07-30) [Green] Forest fires in Angola
      Wildfire · Green alert · Angola · Green impact for forestfire in 11164 ha
  - (2026-07-30) [Green] Forest fires in Angola
      Wildfire · Green alert · Angola · Green impact for forestfire in 11164 ha

### Campaign finance (FEC: top fundraisers + recent filings) — 6 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 40 total
  - (2026-07-31) #30 Germán Larrea Mota Velasco & family — $63.52B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-31) MOVER ▼ Elon Musk — $690.09B ($-18.70B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-07-31) MOVER ▲ Larry Page — $292.00B (+$17.65B since yesterday)
      United States · Technology · source: Google
  - (2026-07-31) MOVER ▲ Sergey Brin — $269.33B (+$16.23B since yesterday)
      United States · Technology · source: Google
  - (2026-07-31) MOVER ▲ Tadashi Yanai & family — $66.86B (+$1.85B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-07-31) [Marginal Revolution] *Redefining Global Health in the 21st Century*
      While donor-driven programs undoubtedly saved millions of lives, they also created unintended distortions in national health priorities. Many governments in sub-Saharan Africa and parts of Asia actually scaled back domes…
  - (2026-07-31) [Marginal Revolution] Friday assorted links
      1. Tokenizing the value from compute? 2. Will they ruin the look of Dulles airport? 3. Pathways into homelessness. 4. Defensible valuations for AI companies. 5. Further reasons why very rapid economic growth is very diff…
  - (2026-07-31) [Marginal Revolution] An unprecedented weapon?
      I wonder if England had a “pause” movement back then: Trebuchets reached the peak of their development in medieval times, probably the most famous example being Edward I’s massive machine, Warwolf. This terrifying device…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-31) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=39, 7d-median=20, 14d-median=20; carrying terms: directive, security, provide, proposes, proposing, model, airworthiness, action, management, safety, directives, certain
- state_bills: today=95, 7d-median=117, 14d-median=117; carrying terms: children, circumstances, board, existing, county, products, limits, including, alaska, defined, state, project
- state_news: today=948, 7d-median=711, 14d-median=830; carrying terms: opinion, order, longer, officers, protect, times, massachusetts, application, museum, children, press, democrat
- local_news: today=276, 7d-median=228, 14d-median=228; carrying terms: times, children, traffic, killed, figure, class, scene, missouri, years, local, tuesday, court
- foreign_news: today=1077, 7d-median=1022, 14d-median=1023; carrying terms: warned, longer, officers, rsshub, times, supporting, becomes, press, destination, pineline, plays, virtual
- chinese_internal: today=314, 7d-median=265, 14d-median=270; carrying terms: chinese, https, google, caixin, china, giant, global, people, markets, stock, beijing, investment
- russian_internal: today=1206, 7d-median=916, 14d-median=912; carrying terms: times, media, russian, reuters, istories, bloomberg, client, httperror, axios, guardian, error, centcom
- ukrainian_internal: today=134, 7d-median=136, 14d-median=136; carrying terms: ordered, protect, three, claimed, warning, including, killed, state, following, refineries, crisis, million
- ukraine_theater: today=1140, 7d-median=627, 14d-median=606; carrying terms: coverage, polygons, client, https, google, token, unauthorized, daily, cartography, error, maintained, httperror
- paper_bets: today=146, 7d-median=138, 14d-median=140; carrying terms: california, starts, longer, republican, winners, humanoid, market, performing, chase, annual, robot, goldman
- weather: today=195, 7d-median=175, 14d-median=174; carrying terms: warned, minor, continues, county, swell, warning, degrees, including, mount, upper, statement, tropical
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: energy, cpilfesl, headline, jtsjol, commodities, balance, rates, funds, treasury, latest, supply, sheet
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, nasdaq, credit, futures, yield, commodities, rates, russell, silver, equities, treasury, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=115, 14d-median=116; carrying terms: technology, detect, daesh, restrictive, order, weapons, annexation, sectoral, haiti, application, embargo, maintenance
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quantitative, httperror, error, congresstrading, quiver, unauthorized, https, quiverquant
- billionaires: today=40, 7d-median=40, 14d-median=38; carrying terms: technology, ambani, charles, brokerage, buffett, zuckerberg, facebook, commodities, tokyo, cryptocurrency, oracle, finance
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: california, blanche, supreme, court, services, appeals, trade, international, johnson, state, group, county
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, capital
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: david, congress, warner, platner, graham, james, jonathan, johnson, booker, robert, cooper, pinkston
- gdelt_regions: today=6, 7d-median=12, 14d-median=12; carrying terms: english, japan, switch
- gdelt_gkg: today=97, 7d-median=47, 14d-median=47; carrying terms: english, hezbollah, trump, israel, keywords, perimeter, graham, lindsey, sanctions, russia, russian, attacks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: police, india, english, language, found, domain, killing, killed, years, death, trump, australia
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=16, 14d-median=16; carrying terms: canada, position, belgium, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: aboard, related, reported, identification, mauritania, monthly, among, bulape, increasing, disembarked, rates, thailand
- cisa_kev: today=9, 7d-median=16, 14d-median=16; carrying terms: vulnerability, control, improper, injection, management, deserialization, remediation, command, untrusted, product, microsoft, sharepoint
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=311, 7d-median=287, 14d-median=286; carrying terms: switzerland, costa, alert, ukraine, australia, kazakhstan, papua, thailand, indonesia, czech, minor, colombia
- usgs_quakes: today=16, 7d-median=23, 14d-median=23; carrying terms: depth, islands, region, indonesia, mexico, kermadec, russia, japan, puerto, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, meeting, prime, rates, resolves, minister, interest, price, ethiopia, abiebie, adanech, decrease
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: conversable, revolution, marginal, https, marginalrevolution, class, economist, links, assorted, looking, conversableeconomist, students
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: technology, vulnerability, scope, techcrunch, campaign, models, state, systems, article, today, exposed, going
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: crank, mcdonald, donald, joseph, hassan, wicker, mullin, bradley, latimer, underwood, shontel, schweikert
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, unavailable, either, placement, evidence, identify, sufficient, claude, consensus, paper, decision, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*