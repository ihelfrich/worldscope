# WORLDSCOPE morning brief — 2026-07-31

## Headline
2692 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (563) · Russian Internal News (state + in-exile) (483) · Ukraine Theater (total-war monitoring) (347) · World leaders & government officials (324) · Chinese Internal News (277) · U.S. Weather + Severe / Climate Outlooks (128) · Local News: St. Louis + Atlanta (122) · GDELT GKG — themes / entities / watch areas (97) · State-Level News (81) · SEC Form 4 insider transactions (recent) (40) · U.S. Federal Action (39) · Ukrainian Internal News (national + local Kyiv) (36)

## What changed today
### International News + Multilateral Institutions — 563 new of 1055 total
  - (2026-07-31) [Global] Ebola outbreak in DRC the fastest growing in the history of the virus
  - (2026-07-31) [Global] At least 18 die as 49,000 cross to Spanish enclave of Ceuta from Morocco
  - (2026-07-31) [Global] UK petrol prices expected to rise to highest this year as US attacks Iran – business live
  - (2026-07-31) [Global] Icac hears of friendship breakdown between Reformers members – as it happened
  - (2026-07-31) [Global] ‘Rob has the bucks cash’: NSW Liberals used Reformers funds to pay for ‘personal expenditure’, Icac hears
  - (2026-07-31) [Global] Gina Rinehart threatens ABC with legal action over Race Around the World program

### Russian Internal News (state + in-exile) — 483 new of 1083 total
  - (2026-07-31) Жители Пензенской области (где военкоматы проводят облавы) рассказали, что их пытались похитить люди в штатском. Они приехали на машинах местных властей | LEDE: В Пензенской области продолжа] (ru: Жит…
      В Пензенской области продолжаются облавы на мужчин призывного возраста. Теперь их устраивают люди в штатском, связанные с местными властями, сообщает «Агентство».
  - (2026-07-31) Мобильные операторы сделают доступ к мессенджеру «Макс» бесплатным. Им можно будет пользоваться, «даже если гигабайты закончились» | LEDE: С 1 августа мобильные операторы «большой четверки» ] (ru: Моб…
      С 1 августа мобильные операторы «большой четверки» (МТС, «Билайн», Мегафон и T2) перестанут тарифицировать трафик мессенджера «Макс» и дадут абонентам возможность пользоваться им без ограничений.
  - (2026-07-31) Блогеру Соне Мармеладовой дали три года условно по делу о распространении порно | LEDE: Мещанский суд Москвы приговорил блогера Соню Мармеладову (настоящее имя — Софья Вершинина) к трем года] (ru: Бло…
      Мещанский суд Москвы приговорил блогера Соню Мармеладову (настоящее имя — Софья Вершинина) к трем годам лишения свободы условно по делу о распространении порнографии через интернет. Суд также назначил Вершининой штраф в…
  - (2026-07-31) The Guardian: Россия во время атаки по Киеву разрушила американский завод по производству дронов | LEDE: В результате российского удара по Киеву 26 июля было разрушено предприятие американск] (ru: The…
      В результате российского удара по Киеву 26 июля было разрушено предприятие американской компании Terminal Autonomy, которая занимается производством высокоточных беспилотников. Об этом сообщает The Guardian со ссылкой на…
  - (2026-07-31) В Anthropic (вслед за OpenAI) заявили, что ИИ-модели Claude во время тестов трижды «сбежали» в интернет и устроили хакерские атаки | LEDE: Три модели искусственного интеллекта Claude вышли в] (ru: В A…
      Три модели искусственного интеллекта Claude вышли в интернет из тестовой среды платформы Irregular и взломали системы трех организаций, сообщила компания-разработчик Anthropic.
  - (2026-07-31) В Екатеринбурге впервые с 2022 года включили надпись «Кто мы, откуда, куда мы идем?» | LEDE: В Екатеринбурге вечером 30 июля включили подсветку у надписи «Кто мы, откуда, куда мы идем?» на к] (ru: В Е…
      В Екатеринбурге вечером 30 июля включили подсветку у надписи «Кто мы, откуда, куда мы идем?» на крыше приборостроительного завода. Об этом сообщает издание Itʼs my city.

### Ukraine Theater (total-war monitoring) — 347 new of 729 total
  - (2026-07-31) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-29) [Liveuamap] Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting group&039;s headquarters in several provinces Amerli, Saladin Governorat…
      Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting gro
  - (2026-07-29) [Liveuamap] US Central Command: Our forces and Saudi armed forces conducted precision strikes in Iraq against Iranian proxies. US and Saudi fighter jets launched raids targeting logistics sites and we…
      US Central Command: Our forces and Saudi armed forces conducted precision strikes in Iraq against Iranian proxies. US and Sa
  - (2026-07-31) [Liveuamap] Ukrainian Air Force: Several waves of Kh-101 cruise missile launches from strategic aircraft: Tu-95MS and Tu-160 - Liveuamap
      Ukrainian Air Force: Several waves of Kh-101 cruise missile launches from strategic aircraft: Tu-95MS and Tu-160
  - (2026-07-30) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap
  - (2026-07-29) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 277 new of 308 total
  - (2026-07-30) 《自然》回应“耿同学”打假 两篇论文撤稿一篇论文更正(含视频) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMigAFBVV95cUxQTHF4ekw1X045YTJrTTFoNWJ4MjFLaGxrQ3pHT0gweFpCN3F1bWVhWVhMd3V4VFFQMUFyZlZQZGRReGs3c0dfaF] (zh:…
      《自然》回应“耿同学”打假 两篇论文撤稿一篇论文更正(含视频) 财新
  - (2026-07-29) 日本熊本地震已致12人死亡 商场为何在震后发生爆炸成焦点 - international.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5PdmRKNXljeVB4UHJkOTBjVjhkWllIVG91bFJLeUc2TmpEQXdNVTRxeWNIbnI2dHVrMzR] (zh:…
      日本熊本地震已致12人死亡 商场为何在震后发生爆炸成焦点 international.caixin.com
  - (2026-07-29) 就王虹推荐信，北大数院发声 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE92YTh2Vmw3Q3I4V3JMc29GcVlCdnZsaWExcVdKQW85TXc0MUkyQlhQamx6b3NIaVBUeVlwbl9iTFQ4aUNneUZHc19PQ3NhRTdKTmtfYi1p] (zh:…
      就王虹推荐信，北大数院发声 财新
  - (2026-07-30) 今日开盘：两市双双低开 沪指跌幅0.43% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE40bFk5Um0wQUdVOEl2TGlweld5TWtxd1NFUm9IUmIzUzFIajhQMFdYWFRqclJPX194YXBsQWlwMEc5YWlsX1NHenp2RjR3UU9J] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.43% 财新
  - (2026-07-31) 今日开盘：两市双双高开 沪指涨幅0.76% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1XUU5XLWpnVUpGRV9jZWZzSmhWQTk0TnBkSjcwVnpBWjliMkRFdmpnRnZ3TmJFSFo3bFVyNGRsNENiUXRUWmdDdW1McUQyWUFn] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.76% 财新
  - (2026-07-29) 今日开盘：沪指报3823.29点 涨幅0.26% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5OMTFkYnhGTWtKRFRoNWZKcGhNMFBOTlZERHVIemZXY3NMd1JwOUFZOV96UUZtaElrUFFJSENOX1B1S0NHR1JlelY5VzhTe] (zh:…
      今日开盘：沪指报3823.29点 涨幅0.26% 财新

### U.S. Weather + Severe / Climate Outlooks — 128 new of 161 total
  - (2026-07-31) [Severe] Fire Weather Watch: Fire Weather Watch issued July 31 at 2:43AM PDT until August 1 at 11:00PM PDT by NWS Pendleton OR
      ...WINDY AND BREEZY WITH CRITICAL RELATIVE HUMIDITY SATURDAY... .Windy conditions will develop with overlapping low relative humidity values Saturday across the Columbia Basin, Eastern Mountains, and Central Oregon. * AF…
  - (2026-07-31) [Moderate] Wind Advisory: Wind Advisory issued July 31 at 2:40AM PDT until August 1 at 11:00PM PDT by NWS Pendleton OR
      * WHAT...West winds 25 to 35 mph with gusts up to 50 mph expected. * WHERE...Kittitas Valley. * WHEN...From 11 AM to 11 PM PDT Saturday. * IMPACTS...Gusty winds will blow around unsecured objects. Tree limbs could be blo…
  - (2026-07-31) [Moderate] Heat Advisory: Heat Advisory issued July 31 at 3:38AM MDT until July 31 at 8:00PM MDT by NWS Albuquerque NM
      * WHAT...Temperatures of 100 to 105 expected with the hottest readings found in the Rio Grande valley near Socorro. * WHERE...Middle Rio Grande Valley including the Albuquerque Metro Area, Northwest Plateau, Lower Rio Gr…
  - (2026-07-31) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-31) [Moderate] Special Weather Statement: Special Weather Statement issued July 31 at 4:25AM CDT by NWS Mobile AL
      At 425 AM CDT, Doppler radar was tracking a cluster of strong thunderstorms 4 miles northwest of Mary Esther, moving east at 10 mph. HAZARD...Winds in excess of 30 mph. SOURCE...Radar indicated. IMPACT...Gusty winds coul…
  - (2026-07-31) [Severe] High Wind Watch: High Wind Watch issued July 31 at 1:19AM AKDT until August 5 at 4:00AM AKDT by NWS Fairbanks AK
      * WHAT...South winds 30 to 40 mph with gusts up to 70 mph possible. * WHERE...Delta Junction, Eastern Alaska Range North of Trims Camp, and Windy Pass. * WHEN...From Sunday evening through late Tuesday night. * IMPACTS..…

### Local News: St. Louis + Atlanta — 122 new of 244 total
  - (2026-07-31) [St. Louis] Anthropic says its AI models hacked 3 organizations during testing
      The AI company behind Claude, posted on its website Thursday that it discovered the three incidents after reviewing more than 141,000 evaluation runs.
  - (2026-07-31) [St. Louis] Death toll from Japan earthquake climbs to 34 as rescuers search damaged mall again
      The disaster also left thousands of households without electricity and tens of thousands without tap water in nearly 100-degree heat.
  - (2026-07-31) [St. Louis] Italian World Cup winner Franco Baresi dies at 66
      In August 2025, Baresi underwent surgery to remove a pulmonary nodule and subsequently began a course of immunotherapy.
  - (2026-07-31) [St. Louis] Colorado woman fights to keep her home as it's listed on Zillow — with her still in it
      The home went viral after hitting the market with a warning most listings don't carry: no showings, no inspections and an occupant who says she isn't leaving.
  - (2026-07-31) [St. Louis] Missouri’s Amendment 4 sparks a battle over the power of the citizen ballot initiative
      Missourians face a pivotal decision on Amendment 4, which seeks to tighten the rules for citizen-led constitutional changes.
  - (2026-07-31) [St. Louis] Fountain Park neighbors protest tornado repair delays and outcomes
      Residents report shabby contractor work as city officials cite learning curves in the recovery program.

### GDELT GKG — themes / entities / watch areas — 97 new of 97 total
  - (2026-07-31) [Russia oil sanctions perimeter · themes] A股7月收官 ： 沪指跌6 . 4 % 回吐年内所有涨幅 ， 创业板指跌23 % 创历史第二大单月跌幅 _ 市场分析 _ 港股 _ 中金在线
      hkstock.cnfol.com · Chinese · tone NA
  - (2026-07-31) [Russia oil sanctions perimeter · themes] 中國海軍 「 2新兵 」 入列 ！ 強化垂直投送 、 遠洋反潛 台海威脅直線升溫 | 中國
      newtalk.tw · Chinese · tone NA
  - (2026-07-31) [Russia oil sanctions perimeter · themes] Paser Digelontor Dana Transfer ke Daerah 2026 Rp 1 . 096 , 63 Miliar , DAU Terbesar
      batam.tribunnews.com · Indonesian · tone NA
  - (2026-07-31) [Russia oil sanctions perimeter · themes] Panssarilaiva Ilmarisen hylystä poistettiin 60 000 litraa öljyä – tyhjennys jatkuu ensi vuonna
      esaimaa.fi · Finnish · tone NA
  - (2026-07-31) [Russia oil sanctions perimeter · themes] Muğladaki yangının bilançosu : 5 bin hektardan fazla alan zarar gördü
      birgun.net · Turkish · tone NA
  - (2026-07-31) [Russia oil sanctions perimeter · themes] Mesir dan Spanyol bahas serangan drone terhadap pelabuhan di Mesir
      antaranews.com · Indonesian · tone NA

### State-Level News — 81 new of 801 total
  - (2026-07-31) [Connecticut] After losing SNAP benefits, some CT refugees are struggling to afford food
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/REFUGEE-SNAP-072226-JL-017-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fet…
  - (2026-07-31) [Connecticut] A CT sheep farmer’s view from the solar field
      <img width="1024" height="736" src="https://ctmirror.org/wp-content/uploads/2026/07/Hillview-Farm-Natalie-Cohen-1024x736.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" lo…
  - (2026-07-31) [Connecticut] Before you vote, learn Duverger’s Law
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/ap-gore-bush-nader-ballot.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy…
  - (2026-07-31) [Alabama] History does not belong to power
  - (2026-07-31) [Hawaii] Office of the Governor — News Release — Gov. Green Celebrates Completion of Hoʻokahi Leo Kauhale
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA GOVERNOR GREEN CELEBRATES COMPLETION OF HOʻOKAHI LEO KAUHALE Phase Two Completes the 50-Home Community, Expanding Deeply […]
  - (2026-07-31) [Hawaii] News Release – DOH Closes Baan Thai Family Cuisine For a Rodent Infestation and Multiple Food Safety Violations
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIA‘ĀINA DEPARTMENT OF HEALTH KA ʻOIHANA OLAKINO KENNETH S. FINK, MD, MGA, MPH DIRECTOR […]

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-31) [GUJRATHI SHEILA] Form 4 (Reporting)
      filed 2026-07-31 01:49 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001575202-26-000011 Size: 10 KB
  - (2026-07-31) [Processa Pharmaceuticals, Inc.] Form 4 (Issuer)
      filed 2026-07-31 01:49 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001575202-26-000011 Size: 10 KB
  - (2026-07-31) [Tempus AI, Inc.] Form 4 (Issuer)
      filed 2026-07-31 01:42 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001114357-26-000027 Size: 28 KB
  - (2026-07-31) [LEFKOFSKY ERIC P] Form 4 (Reporting)
      filed 2026-07-31 01:42 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001114357-26-000027 Size: 28 KB
  - (2026-07-31) [Controladora Vuela Compania de Aviacion, S.A.B. de C.V.] Form 4 (Issuer)
      filed 2026-07-31 01:37 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001361096-26-000005 Size: 14 KB
  - (2026-07-31) [Maldonado Yanez Ricardo] Form 4 (Reporting)
      filed 2026-07-31 01:37 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001361096-26-000005 Size: 14 KB

### U.S. Federal Action — 39 new of 39 total
  - (2026-07-31) Continuation of the National Emergency With Respect to Lebanon
  - (2026-07-31) Qualification and Certification of Locomotive Engineers and Conductors; English Language Proficiency and Other Requirements
      FRA proposes to amend its regulations governing the qualification and certification of locomotive engineers and conductors to establish English language proficiency as a requirement for a railroad carrier to certify and…
  - (2026-07-31) Amendment of United States Area Navigation Routes (RNAV) T-285 and T-286 in the Vicinity of Thedford, NE
      This action amends the published coordinates of the Thedford, NE, Very High Frequency Omnidirectional Range/Distance Measuring Equipment (VOR/DME) in the legal descriptions of Area Navigation (RNAV) routes T-285 and T-28…
  - (2026-07-31) Amendment of Jet Route J-24 and Very High Frequency Omnidirectional Range Federal Airways V-244, V-508 and Revocation of Very High Frequency Omnidirectional Range Federal Airway V-255 in the Vicinity…
      This action proposes to amend Jet Route J-24 and Very High Frequency Omnidirectional Range Federal (VOR) Airways V-244 and V-508 and revoke VOR Federal Airway V-255 in the vicinity of Hays, Kansas. The FAA is proposing t…
  - (2026-07-31) Modernization of the Nation's Alerting Systems; Protecting the Nation's Communications Systems From Cybersecurity Threats
      In the Report and Order, the Federal Communications Commission (the FCC or the Commission) seeks to preserve the public's trust in the Emergency Alert System (EAS) by requiring targeted cybersecurity improvements that wi…
  - (2026-07-31) Wireless Emergency Alerts; The Emergency Alert System; Modernization of the Nation's Alerting Systems
      In this document, the Federal Communications Commission ("FCC" or "Commission") adopted a Further Notice of Proposed Rulemaking that seeks comment on proposed rules intended to make the Emergency Alert System (EAS) and W…

### Ukrainian Internal News (national + local Kyiv) — 36 new of 114 total
  - (2026-07-31) У Хмельницькому пролунали вибухи без оголошення тривоги | LEDE: Вдень 31 липня у Хмельницькому пролунали кілька вибухів. В ОВА повідомили, що на місці працюють відповідні служби, за інформацією] (uk:…
      Вдень 31 липня у Хмельницькому пролунали кілька вибухів. В ОВА повідомили, що на місці працюють відповідні служби, за інформацією "Суспільного", повітряну тривогу в області не оголошували.
  - (2026-07-31) У "Скелі" підтвердили: Наразі поповнення новобранцями поставили на паузу | LEDE: Поповнення 425-го полку "Скеля" поставлено на паузу. Генштаб перевіряє комплектування частин ЗСУ та розподіл люд] (uk:…
      Поповнення 425-го полку "Скеля" поставлено на паузу. Генштаб перевіряє комплектування частин ЗСУ та розподіл людей.
  - (2026-07-31) Міноборони Польщі: Український пілот слідкував за російською ракетою аж до кордону | LEDE: Заступник міністра оборони Польщі Цезарій Томчик заявив, що український пілот до останнього відстежува] (uk:…
      Заступник міністра оборони Польщі Цезарій Томчик заявив, що український пілот до останнього відстежував російську ракету Х-101, яка 30 липня впала на території Польщі, але не встиг її збити і був змушений розвернутись за…
  - (2026-07-31) Правоохоронці викрили шахрайську схему з товарами для військових: волонтера ошукали на майже 900 тис. грн | LEDE: 25-річному одеситу загрожує до 8 років за шахрайство з продажем деталей для дро] (uk:…
      25-річному одеситу загрожує до 8 років за шахрайство з продажем деталей для дронів через Telegram.
  - (2026-07-31) ГУР та Сили оборони атакували НПЗ у російському Волгограді | LEDE: У ніч на 31 липня ГУР і Сили оборони вразили нафтопереробний завод у російскьому Волгограді, один з найбільших у регіоні.] (uk: ГУР т…
      У ніч на 31 липня ГУР і Сили оборони вразили нафтопереробний завод у російскьому Волгограді, один з найбільших у регіоні.
  - (2026-07-31) Окупанти атакували дроном авто в Запорізькому районі – убили водія | LEDE: Удар російського дрона по цивільній автівці біля Новосолоного: водій загинув] (uk: Окупанти атакували дроном авто в Запорізьк…
      Удар російського дрона по цивільній автівці біля Новосолоного: водій загинув

### Government Action: Sanctions + Procurement + Foreign Agents — 33 new of 110 total
  - (2026-07-30) [OFAC] Counter Terrorism Designations; Non-Proliferation Designation Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Non-Proliferation Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-07-27) [OFAC] Sanctions List Removals; Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Sanctions List Removals; Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-31) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (48.7325, 2.3795) · on ground · 11km/h
  - (2026-07-31) JAF5GA (Bulgaria)
      icao24: 4520aa · position: (48.727, 2.3722) · on ground
  - (2026-07-31) GAF123 (Germany)
      icao24: 3f6219 · position: (43.145, 14.9392) · alt: 10050m · 783km/h
  - (2026-07-31) PUMA52 (Slovenia)
      icao24: 506e19 · position: (45.7916, 14.6873) · alt: 1493m · 208km/h
  - (2026-07-31) PUMA20 (Slovenia)
      icao24: 506e1c · position: (45.9774, 15.648) · alt: 1219m · 152km/h
  - (2026-07-31) CNA22 (Spain)
      icao24: 3475cb · position: (27.9134, -15.4133) · alt: 304m · 166km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 11 new of 57 total
  - (2026-07-31) [BleepingComputer] Anthropic's Claude breached 3 orgs, uploaded PyPI malware during tests
      One of Anthropic's Claude models built and uploaded a malicious Python package to PyPI during a botched security evaluation, where it ran on 15 real systems and stole credentials from a security vendor. It was one of thr…
  - (2026-07-31) [The Register] UK wants datacenters to pay a fee for grid connection requests
      Refundable charge intended to discourage time wasters from filing applications that will never be realized
  - (2026-07-31) [The Register] Airport sign fails to boot, officers already on the scene
      Bork! Bork! That's the sound of the police
  - (2026-07-31) [The Register] Techie lured out of retirement to support software only he remembered
      The first job was lucrative and went well, but a pension was preferable to rolling projects
  - (2026-07-31) [The Register] Anthropic’s Claude escaped test sandbox to attack three organizations
      Wrote and published malware during tests, which is apparently OK because leaky test environments were the real problem
  - (2026-07-31) [The Register] Amazon's Q2 was great, but the earnings release is packed with baloney
      "Tell me lies, tell me sweet little lies"

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-31) LoL: Gen.G vs T1 - Game 1 Winner
      yes price: 0% · 24h volume: $1,332,628 · resolves 2026-07-31
  - (2026-07-31) LoL: Gen.G vs T1 - Game 2 Winner
      yes price: 0% · 24h volume: $1,047,014 · resolves 2026-07-31
  - (2026-07-31) LoL: Gen.G vs T1 (BO3) - LCK Round 3-4 Legend Group
      yes price: 0% · 24h volume: $726,939 · resolves 2026-07-31
  - (2026-07-31) LoL: Anyone's Legend vs EDward Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $704,096 · resolves 2026-07-31
  - (2026-07-31) LoL: Team WE vs Bilibili Gaming - Game 1 Winner
      yes price: 0% · 24h volume: $604,692 · resolves 2026-07-31
  - (2026-07-31) LoL: Anyone's Legend vs EDward Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $477,406 · resolves 2026-07-31

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-07-28) U.S. Court of Appeals, 9th Cir.: United States v. Lopez
  - (2026-07-28) U.S. Court of Appeals, 11th Cir.: Michael Davis v. Lockheed Martin Corporation
  - (2026-07-27) U.S. Court of Appeals, Federal Cir.: Board of Regents of the University of Texas v. Boston Scientific Corp.
  - (2026-07-27) U.S. Court of Appeals, 2nd Cir.: United States v. Gendron
  - (2026-07-27) U.S. Court of International Trade: Gov't of Canada v. United States
  - (2026-07-27) U.S. Court of International Trade: Qatar Melamine Co. v. United States

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 37 total
  - (2026-07-31) #30 Germán Larrea Mota Velasco & family — $64.26B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-31) MOVER ▼ Zhong Shanshan — $62.26B ($-2.15B since yesterday)
      China · Food & Beverage · source: Beverages, pharmaceuticals
  - (2026-07-31) MOVER ▼ Francoise Bettencourt Meyers & family — $94.14B ($-1.68B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-31) MOVER ▲ Mukesh Ambani — $89.59B (+$0.92B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-31) MOVER ▲ Bernard Arnault & family — $144.71B (+$0.47B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-31) MOVER ▲ Gautam Adani — $84.70B (+$0.43B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Paper Trading Scorecard — 7 new of 144 total
  - (2026-07-31) [Polymarket] Will Alphabet be the largest company in the world by market cap on July 31?
      This market will resolve to the largest company in the world by market cap on July 31, 2026, as of market close. The resolution source for this market will be a consensus of credible reporting.
  - (2026-07-31) [Manifold] Will Lindsay Clancy be convicted of murder of her 3 children?
  - (2026-07-31) [Manifold] Daily Coinflip
  - (2026-07-31) [Manifold] Spider-Man: Brand New Day grosses over $2B?
  - (2026-07-31) [Manifold] Is Mitch McConnell on life support and/or brain dead?
  - (2026-07-31) [Manifold] MLB: Will the Tampa Bay Rays sweep the Chicago White Sox OR will the 3-game series total 27 or more runs?

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-31) [Japan] Video Game News , Reviews , Walkthroughs And Guides | GamingBolt
      gamingbolt.com · English
  - (2026-07-31) [Japan] TOPIA 14 : Shibuya Indie Music Night | Ruby Room
      metropolisjapan.com · English
  - (2026-07-31) [Japan] Kyushu Shinkansen Reopens Northern Section as Southern Damage Persists
      newsonjapan.com · English
  - (2026-07-31) [Japan] BOJ Keeps Policy Rate Steady at Around 1 . 0 %
      newsonjapan.com · English
  - (2026-07-31) [Japan] PlayStation Lego Set Is Rumored And The Jokes Write Themselves
      kotaku.com · English
  - (2026-07-31) [Japan] The Most Polarizing Mario Game Is About To Come To Switch 2
      kotaku.com · English

### USGS earthquakes (M4.5+, past day) — 6 new of 15 total
  - (2026-07-31) M 5.6 - 13 km ENE of San Fernando, Peru
      M5.6 · 13 km ENE of San Fernando, Peru · depth 154.355 km
  - (2026-07-31) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 37.846 km
  - (2026-07-31) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 35 km
  - (2026-07-31) M 4.9 - 287 km SW of Banda Aceh, Indonesia
      M4.9 · 287 km SW of Banda Aceh, Indonesia · depth 10 km
  - (2026-07-31) M 4.6 - Kermadec Islands region
      M4.6 · Kermadec Islands region · depth 44.986 km
  - (2026-07-31) M 4.5 - Fiji region
      M4.5 · Fiji region · depth 581.048 km

### GDACS — global disaster alerts — 2 new of 299 total
  - (2026-07-31) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.6M, Depth:154.355km
  - (2026-07-31) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.6M, Depth:154.355km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-31) [Marginal Revolution] An unprecedented weapon?
      I wonder if England had a “pause” movement back then: Trebuchets reached the peak of their development in medieval times, probably the most famous example being Edward I’s massive machine, Warwolf. This terrifying device…
  - (2026-07-31) [Marginal Revolution] The wisdom of Eli Dourado
      How do “international efforts” work? Unlike most of the signatories of the letter, I have been a State Department advisor and have participated in multiple treaty negotiations. I have also been a member of technical comm…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-31) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=39, 7d-median=20, 14d-median=20; carrying terms: final, airworthiness, requires, action, model, proposes, safety, security, provide, directives, proposing, national
- state_bills: today=0, 7d-median=128, 14d-median=128; carrying terms: retail, utilities, pursuant, whose, colorado, circumstances, environmental, appropriations, projects, death, constitution, board
- state_news: today=801, 7d-median=711, 14d-median=756; carrying terms: brown, wearing, remain, lakes, bipartisan, experts, closures, asked, trees, farmers, position, because
- local_news: today=244, 7d-median=228, 14d-median=228; carrying terms: against, magazine, least, class, local, shows, https, project, traffic, based, scaled, years
- foreign_news: today=1055, 7d-median=1022, 14d-median=1023; carrying terms: upholding, undergraduate, minister, experts, resignation, unveiled, xuejun, response, confirmed, venture, foreign, rsshub
- chinese_internal: today=308, 7d-median=265, 14d-median=270; carrying terms: https, giant, people, chinese, global, china, google, caixin, sources, firms, beijing, build
- russian_internal: today=1083, 7d-median=916, 14d-median=912; carrying terms: openai, bloomberg, forbidden, group, russian, client, times, guardian, europe, found, istories, title
- ukrainian_internal: today=114, 7d-median=136, 14d-median=136; carrying terms: remain, minister, president, fighter, troops, recent, channels, confirmed, aerial, asset, ukrainian, russia
- ukraine_theater: today=729, 7d-median=627, 14d-median=606; carrying terms: httperror, token, https, coverage, firms, polygon, viirs, frontline, extra, nominal, known, liveuamap
- paper_bets: today=144, 7d-median=138, 14d-median=140; carrying terms: manifold, starts, achieved, humanoid, whose, mayfield, minister, netanyahu, president, colorado, midterm, virginia
- weather: today=161, 7d-median=173, 14d-median=173; carrying terms: discussion, lower, rivers, remain, colorado, rocks, advisories, interstate, florida, worth, environmental, portions
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: balance, nonfarm, supply, implied, walcl, payems, indicator, personal, headline, dcoilwtico, payrolls, inflation
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: china, yield, range, bitcoin, natural, large, close, nasdaq, credit, crypto, commodities, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=110, 7d-median=115, 14d-median=116; carrying terms: oblasts, adopted, updates, february, concerning, bissau, relation, response, russia, environmental, technologies, manufacturing
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, client, httperror, unauthorized, error, https, congresstrading, quiver, quiverquant
- billionaires: today=37, 7d-median=37, 14d-median=36; carrying terms: discount, spacex, retail, ballmer, hathaway, adani, ambani, gcarsoa, mexico, mukesh, devasini, ortega
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, california, international, delaware, services, trade, blanche, appeals, group, arizona, state
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, therapeutics, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: jonathan, brown, alexandria, lindsey, angels, raised, ossoff, sherrod, cooper, booker, congress, cycle
- gdelt_regions: today=6, 7d-median=12, 14d-median=12; carrying terms: english, japan, switch
- gdelt_gkg: today=97, 7d-median=47, 14d-median=47; carrying terms: english, israel, hezbollah, trump, russia, sanctions, lindsey, keywords, perimeter, graham, black, russian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=16, 14d-median=16; carrying terms: position, belgium, canada, ground, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: senegal, declared, sligh, globally, person, analyzed, affecting, bengal, distributed, mauritania, since, isolates
- cisa_kev: today=9, 7d-median=16, 14d-median=16; carrying terms: command, management, improper, sharepoint, remediation, vendor, microsoft, injection, product, langflow, vulnerability, deserialization
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=299, 7d-median=287, 14d-median=286; carrying terms: germany, honduras, kazakhstan, flood, medium, tropical, herzegovina, orange, maximum, drought, mexico, cambodia
- usgs_quakes: today=15, 7d-median=23, 14d-median=23; carrying terms: depth, islands, region, indonesia, mexico, japan, kermadec, russia, puerto, madero, taiwan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, minister, rates, meeting, prime, ethiopia, interest, abiebie, increase, adanech
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, benefit, revolution, conversable, economist, class, https, quality, looking, level, courses, license
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: users, updates, going, today, edition, model, against, using, vulnerability, article, technology, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jimmy, brown, wasserman, chellie, cornyn, garamendi, langworthy, stefanik, brandon, desaulnier, reschenthaler, gorsuch
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, sufficient, evidence, claude, either, module, unavailable, decision, markets, converges, paper, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*