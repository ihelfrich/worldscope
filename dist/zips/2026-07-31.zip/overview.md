# WORLDSCOPE morning brief — 2026-07-31

## Headline
2638 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (553) · Russian Internal News (state + in-exile) (470) · Ukraine Theater (total-war monitoring) (346) · World leaders & government officials (324) · Chinese Internal News (277) · U.S. Weather + Severe / Climate Outlooks (129) · Local News: St. Louis + Atlanta (121) · State-Level News (78) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · U.S. Federal Action (39) · Ukrainian Internal News (national + local Kyiv) (35)

## What changed today
### International News + Multilateral Institutions — 553 new of 1054 total
  - (2026-07-31) [Global] Hamas says it has agreed to disarm after Trump announces Board of Peace plan
      A senior Hamas official has told the BBC they have agreed to the Board of Peace's plan. Israel has not commented.
  - (2026-07-31) [Global] If Hamas disarmament plan holds, it could mark first credible step to ending Gaza war
      The plan - if successful - potentially removes the most significant obstacle to advancing the Trump-backed peace initiative in Gaza.
  - (2026-07-31) [Global] About 49,000 migrants enter Spanish enclave of Ceuta, officials say
      This comes after thousands of migrants were reported to have illegally crossed into the territory on Thursday and Friday.
  - (2026-07-31) [Global] AC Milan and Italy great Baresi dies aged 66
      AC Milan and Italy great Franco Baresi has died at the age of 66, the Italian club announces.
  - (2026-07-31) [Global] UK rapper Yung Filly found not guilty of raping woman after Australian show
      The YouTuber has been found guilty for two counts of assault over the 2024 incident in Perth.
  - (2026-07-31) [Global] Fifa says 'nobody selling football' as plan continues
      Football's governing body Fifa plans to continue the consultation process after Uefa threatens to boycott World Cups.

### Russian Internal News (state + in-exile) — 470 new of 1080 total
  - (2026-07-31) Жители Пензенской области (где военкоматы проводят облавы) рассказали, что их пытались похитить люди в штатском. Они приехали на машинах местных властей | LEDE: В Пензенской области продолжа] (ru: Жит…
      В Пензенской области продолжаются облавы на мужчин призывного возраста. Теперь их устраивают люди в штатском, связанные с местными властями, сообщает «Агентство».
  - (2026-07-31) Мобильные операторы сделают доступ к мессенджеру «Макс» бесплатным. Им можно будет пользоваться, «даже если гигабайты закончились» | LEDE: С 1 августа мобильные операторы «большой четверки» ] (ru: Моб…
      С 1 августа мобильные операторы «большой четверки» (МТС, «Билайн», Мегафон и T2) перестанут тарифицировать трафик мессенджера «Макс» и дадут абонентам возможность пользоваться им без ограничений.
  - (2026-07-31) Блогеру Соне Мармеладовой дали три года условно по делу о распространении порно | LEDE: Мещанский суд Москвы приговорил блогера Соню Мармеладову (настоящее имя — Софья Вершинина) к трем года] (ru: Бло…
      Мещанский суд Москвы приговорил блогера Соню Мармеладову (настоящее имя — Софья Вершинина) к трем годам лишения свободы условно по делу о распространении порнографии через интернет. Суд также назначил Вершининой штраф в…
  - (2026-07-31) The Guardian: Россия во время атаки по Киеву разрушила американский завод по производству дронов | LEDE: В результате российского удара по Киеву 26 июля было разрушено предприятие американск] (ru: The…
      В результате российского удара по Киеву 26 июля было разрушено предприятие американской компании Terminal Autonomy, которая занимается производством высокоточных беспилотников. Об этом сообщает The Guardian со ссылкой на…
  - (2026-07-31) В Anthropic (вслед за OpenAI) заявили, что ИИ-модели Claude во время тестов трижды «сбежали» в интернет и устроили хакерские атаки | LEDE: Три модели искусственного интеллекта Claude вышли в] (ru: В A…
      Три модели искусственного интеллекта Claude вышли в интернет из тестовой среды платформы Irregular и взломали системы трех организаций, сообщила компания-разработчик Anthropic.
  - (2026-07-31) В Екатеринбурге впервые с 2022 года включили надпись «Кто мы, откуда, куда мы идем?» | LEDE: В Екатеринбурге вечером 30 июля включили подсветку у надписи «Кто мы, откуда, куда мы идем?» на к] (ru: В Е…
      В Екатеринбурге вечером 30 июля включили подсветку у надписи «Кто мы, откуда, куда мы идем?» на крыше приборостроительного завода. Об этом сообщает издание Itʼs my city.

### Ukraine Theater (total-war monitoring) — 346 new of 729 total
  - (2026-07-31) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-29) [Liveuamap] Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting group&039;s headquarters in several provinces Amerli, Saladin Governorat…
      Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting gro
  - (2026-07-29) [Liveuamap] US Central Command: Our forces and Saudi armed forces conducted precision strikes in Iraq against Iranian proxies. US and Saudi fighter jets launched raids targeting logistics sites and we…
      US Central Command: Our forces and Saudi armed forces conducted precision strikes in Iraq against Iranian proxies. US and Sa
  - (2026-07-30) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap
  - (2026-07-29) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap
  - (2016-05-01) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - iraq.liveuamap.com
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com iraq.liveuamap.com

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 277 new of 308 total
  - (2026-07-30) 《自然》回应“耿同学”打假 两篇论文撤稿一篇论文更正(含视频) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMigAFBVV95cUxQTHF4ekw1X045YTJrTTFoNWJ4MjFLaGxrQ3pHT0gweFpCN3F1bWVhWVhMd3V4VFFQMUFyZlZQZGRReGs3c0dfaF] (zh:…
      《自然》回应“耿同学”打假 两篇论文撤稿一篇论文更正(含视频) 财新
  - (2026-07-29) 日本熊本地震已致12人死亡 商场为何在震后发生爆炸成焦点 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5PdmRKNXljeVB4UHJkOTBjVjhkWllIVG91bFJLeUc2TmpEQXdNVTRxeWNIbnI2dHVrMzRPVmVUTFRHZ2tGNHJGQVZUd] (zh:…
      日本熊本地震已致12人死亡 商场为何在震后发生爆炸成焦点 财新
  - (2026-07-29) 就王虹推荐信，北大数院发声 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE92YTh2Vmw3Q3I4V3JMc29GcVlCdnZsaWExcVdKQW85TXc0MUkyQlhQamx6b3NIaVBUeVlwbl9iTFQ4aUNneUZHc19PQ3NhRTdKTmtfYi1p] (zh:…
      就王虹推荐信，北大数院发声 财新
  - (2026-07-30) 今日开盘：两市双双低开 沪指跌幅0.43% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE40bFk5Um0wQUdVOEl2TGlweld5TWtxd1NFUm9IUmIzUzFIajhQMFdYWFRqclJPX194YXBsQWlwMEc5YWlsX1NHenp2RjR3UU9J] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.43% 财新
  - (2026-07-31) 今日开盘：两市双双高开 沪指涨幅0.76% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1XUU5XLWpnVUpGRV9jZWZzSmhWQTk0TnBkSjcwVnpBWjliMkRFdmpnRnZ3TmJFSFo3bFVyNGRsNENiUXRUWmdDdW1McUQyWUFn] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.76% 财新
  - (2026-07-29) 今日开盘：沪指报3823.29点 涨幅0.26% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5OMTFkYnhGTWtKRFRoNWZKcGhNMFBOTlZERHVIemZXY3NMd1JwOUFZOV96UUZtaElrUFFJSENOX1B1S0NHR1JlelY5VzhTe] (zh:…
      今日开盘：沪指报3823.29点 涨幅0.26% 财新

### U.S. Weather + Severe / Climate Outlooks — 129 new of 162 total
  - (2026-07-31) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-31) [Moderate] Special Weather Statement: Special Weather Statement issued July 31 at 4:25AM CDT by NWS Mobile AL
      At 425 AM CDT, Doppler radar was tracking a cluster of strong thunderstorms 4 miles northwest of Mary Esther, moving east at 10 mph. HAZARD...Winds in excess of 30 mph. SOURCE...Radar indicated. IMPACT...Gusty winds coul…
  - (2026-07-31) [Severe] High Wind Watch: High Wind Watch issued July 31 at 1:19AM AKDT until August 5 at 4:00AM AKDT by NWS Fairbanks AK
      * WHAT...South winds 30 to 40 mph with gusts up to 70 mph possible. * WHERE...Delta Junction, Eastern Alaska Range North of Trims Camp, and Windy Pass. * WHEN...From Sunday evening through late Tuesday night. * IMPACTS..…
  - (2026-07-31) [Severe] Fire Weather Watch: Fire Weather Watch issued July 31 at 2:16AM PDT until August 1 at 9:00PM PDT by NWS Medford OR
      The National Weather Service in Medford has issued a Fire Weather Watch, which is in effect from Saturday afternoon through Saturday evening. * IMPACTS...Any fires that develop will likely spread rapidly. * AFFECTED AREA…
  - (2026-07-31) [Moderate] Gale Warning: Gale Warning issued July 31 at 2:09AM PDT until August 1 at 9:00PM PDT by NWS San Francisco CA
      * WHAT...For the Small Craft Advisory, northwest winds 15 to 25 kt with gusts up to 35 kt. For the Gale Warning, northwest winds 20 to 30 kt with gusts up to 40 kt and seas 8 to 10 ft expected. * WHERE...Coastal Waters f…
  - (2026-07-31) [Moderate] Gale Warning: Gale Warning issued July 31 at 2:09AM PDT until August 1 at 9:00PM PDT by NWS San Francisco CA
      * WHAT...For the Small Craft Advisory, northwest winds 20 to 30 kt with gusts up to 35 kt and seas 8 to 10 ft. For the Gale Warning, northwest winds 25 to 35 kt with storm force gusts up to 50 kt and seas 8 to 12 ft expe…

### Local News: St. Louis + Atlanta — 121 new of 243 total
  - (2026-07-31) [St. Louis] Where in St Charles 7/31/2026
      Let’s see how well you know St. Charles. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess”…
  - (2026-07-31) [St. Louis] What’s True in the Lou? – 7/31/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-07-31) [St. Louis] Former pandemic-era health chief to return as St. Louis health director
  - (2026-07-31) [St. Louis] Anthropic says its AI models hacked 3 organizations during testing
      The AI company behind Claude, posted on its website Thursday that it discovered the three incidents after reviewing more than 141,000 evaluation runs.
  - (2026-07-31) [St. Louis] Death toll from Japan earthquake climbs to 34 as rescuers search damaged mall again
      The disaster also left thousands of households without electricity and tens of thousands without tap water in nearly 100-degree heat.
  - (2026-07-31) [St. Louis] Italian World Cup winner Franco Baresi dies at 66
      In August 2025, Baresi underwent surgery to remove a pulmonary nodule and subsequently began a course of immunotherapy.

### State-Level News — 78 new of 798 total
  - (2026-07-31) [Connecticut] After losing SNAP benefits, some CT refugees are struggling to afford food
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/REFUGEE-SNAP-072226-JL-017-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fet…
  - (2026-07-31) [Connecticut] A CT sheep farmer’s view from the solar field
      <img width="1024" height="736" src="https://ctmirror.org/wp-content/uploads/2026/07/Hillview-Farm-Natalie-Cohen-1024x736.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" lo…
  - (2026-07-31) [Connecticut] Before you vote, learn Duverger’s Law
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/ap-gore-bush-nader-ballot.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy…
  - (2026-07-31) [Hawaii] Office of the Governor — News Release — Gov. Green Celebrates Completion of Hoʻokahi Leo Kauhale
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA GOVERNOR GREEN CELEBRATES COMPLETION OF HOʻOKAHI LEO KAUHALE Phase Two Completes the 50-Home Community, Expanding Deeply […]
  - (2026-07-31) [Hawaii] News Release – DOH Closes Baan Thai Family Cuisine For a Rodent Infestation and Multiple Food Safety Violations
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIA‘ĀINA DEPARTMENT OF HEALTH KA ʻOIHANA OLAKINO KENNETH S. FINK, MD, MGA, MPH DIRECTOR […]
  - (2026-07-31) [Hawaii] DLNR News Release – PĀLĀʻAU STATE WAYSIDE PARK REOPENS FOLLOWING MAJOR PARK IMPROVEMENTS, July 30, 2026
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA DEPARTMENT OF LAND AND NATURAL RESOURCES KA ‘OIHANA KUMUWAIWAI ‘ĀINA RYAN K.P. KANAKA‘OLE […]

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-31) [GUJRATHI SHEILA] Form 4 (Reporting)
      filed 2026-07-31 01:49 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001575202-26-000011 Size: 10 KB
  - (2026-07-31) [Processa Pharmaceuticals, Inc.] Form 4 (Issuer)
      filed 2026-07-31 01:49 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001575202-26-000011 Size: 10 KB
  - (2026-07-31) [Tempus AI, Inc.] Form 4 (Issuer)
      filed 2026-07-31 01:42 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001114357-26-000027 Size: 28 KB
  - (2026-07-31) [LEFKOFSKY ERIC P] Form 4 (Reporting)
      filed 2026-07-31 01:42 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001114357-26-000027 Size: 28 KB
  - (2026-07-31) [Controladora Vuela Compania de Aviacion, S.A.B. de C.V.] Form 4 (Issuer)
      filed 2026-07-31 01:37 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001361096-26-000005 Size: 14 KB
  - (2026-07-31) [Maldonado Yanez Ricardo] Form 4 (Reporting)
      filed 2026-07-31 01:37 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001361096-26-000005 Size: 14 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-31) [United States] Trump Announces Hamas Disarmament Deal | Talk Radio 1080
      domain: talkradio1080.iheart.com · language: English · tone:
  - (2026-07-31) [China] North Korea Needs China and Russia – But Doesnt Want Its People Admiring Them – The Diplomat
      domain: thediplomat.com · language: English · tone:
  - (2026-07-31) [United States] Ive tested hundreds of phone accessories this year and these are the 9 that you wont regret buying
      domain: tomsguide.com · language: English · tone:
  - (2026-07-31) [Canada] In the news today : WestJet strike looms , alert reforms , who let the dogs out ? – Winnipeg Free Press
      domain: winnipegfreepress.com · language: English · tone:
  - (2026-07-31) [Myanmar] Can India give the Global South a voice in the Arctic
      domain: myanmarnews.net · language: English · tone:
  - (2026-07-31) [United States] Company Dissolved ? Legal And Financial Consequences To Expect
      domain: mondaq.com · language: English · tone:

### U.S. Federal Action — 39 new of 39 total
  - (2026-07-31) Continuation of the National Emergency With Respect to Lebanon
  - (2026-07-31) Qualification and Certification of Locomotive Engineers and Conductors; English Language Proficiency and Other Requirements
      FRA proposes to amend its regulations governing the qualification and certification of locomotive engineers and conductors to establish English language proficiency as a requirement for a railroad carrier to certify and…
  - (2026-07-31) Amendment of United States Area Navigation Routes (RNAV) T-285 and T-286 in the Vicinity of Thedford, NE
      This action amends the published coordinates of the Thedford, NE, Very High Frequency Omnidirectional Range/Distance Measuring Equipment (VOR/DME) in the legal descriptions of Area Navigation (RNAV) routes T-285 and T-28…
  - (2026-07-31) Amendment of Jet Route J-24 and Very High Frequency Omnidirectional Range Federal Airways V-244, V-508 and Revocation of Very High Frequency Omnidirectional Range Federal Airway V-255 in the Vicinity…
      This action proposes to amend Jet Route J-24 and Very High Frequency Omnidirectional Range Federal (VOR) Airways V-244 and V-508 and revoke VOR Federal Airway V-255 in the vicinity of Hays, Kansas. The FAA is proposing t…
  - (2026-07-31) Modernization of the Nation's Alerting Systems; Protecting the Nation's Communications Systems From Cybersecurity Threats
      In the Report and Order, the Federal Communications Commission (the FCC or the Commission) seeks to preserve the public's trust in the Emergency Alert System (EAS) by requiring targeted cybersecurity improvements that wi…
  - (2026-07-31) Wireless Emergency Alerts; The Emergency Alert System; Modernization of the Nation's Alerting Systems
      In this document, the Federal Communications Commission ("FCC" or "Commission") adopted a Further Notice of Proposed Rulemaking that seeks comment on proposed rules intended to make the Emergency Alert System (EAS) and W…

### Ukrainian Internal News (national + local Kyiv) — 35 new of 113 total
  - (2026-07-31) Міноборони Польщі: Український пілот слідкував за російською ракетою аж до кордону | LEDE: Заступник міністра оборони Польщі Цезарій Томчик заявив, що український пілот до останнього відстежува] (uk:…
      Заступник міністра оборони Польщі Цезарій Томчик заявив, що український пілот до останнього відстежував російську ракету Х-101, яка 30 липня впала на території Польщі, але не встиг її збити і був змушений розвернутись за…
  - (2026-07-31) Правоохоронці викрили шахрайську схему з товарами для військових: волонтера ошукали на майже 900 тис. грн | LEDE: 25-річному одеситу загрожує до 8 років за шахрайство з продажем деталей для дро] (uk:…
      25-річному одеситу загрожує до 8 років за шахрайство з продажем деталей для дронів через Telegram.
  - (2026-07-31) ГУР та Сили оборони атакували НПЗ у російському Волгограді | LEDE: У ніч на 31 липня ГУР і Сили оборони вразили нафтопереробний завод у російскьому Волгограді, один з найбільших у регіоні.] (uk: ГУР т…
      У ніч на 31 липня ГУР і Сили оборони вразили нафтопереробний завод у російскьому Волгограді, один з найбільших у регіоні.
  - (2026-07-31) Окупанти атакували дроном авто в Запорізькому районі – убили водія | LEDE: Удар російського дрона по цивільній автівці біля Новосолоного: водій загинув] (uk: Окупанти атакували дроном авто в Запорізьк…
      Удар російського дрона по цивільній автівці біля Новосолоного: водій загинув
  - (2026-07-31) Росіяни вдарили по відділенню "Нової пошти" на Вінниччині: 8 постраждалих, троє – в реанімації | LEDE: 31 липня російські загарбники завдали удару по відділенню "Нової пошти" у Вінницькій облас] (uk:…
      31 липня російські загарбники завдали удару по відділенню "Нової пошти" у Вінницькій області, у результаті чого постраждали 8 людей, троє з них перебувають у реанімації.
  - (2026-07-31) В іспанський анклав у Африці могли прорватися понад 40 тисяч мігрантів | LEDE: Іспанські сили безпеки оцінили, скільки мігрантів могли нелегально потрапити до північноафриканського анклаву Сеут] (uk:…
      Іспанські сили безпеки оцінили, скільки мігрантів могли нелегально потрапити до північноафриканського анклаву Сеута впродовж останніх днів.

### Government Action: Sanctions + Procurement + Foreign Agents — 33 new of 110 total
  - (2026-07-30) [OFAC] Counter Terrorism Designations; Non-Proliferation Designation Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Non-Proliferation Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-07-27) [OFAC] Sanctions List Removals; Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Sanctions List Removals; Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-31) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (48.7587, 2.5726) · alt: 762m · 309km/h
  - (2026-07-31) GAF123 (Germany)
      icao24: 3f6219 · position: (44.5554, 13.2354) · alt: 10050m · 766km/h
  - (2026-07-31) PUMA52 (Slovenia)
      icao24: 506e19 · position: (45.542, 15.1716) · alt: 1493m · 185km/h
  - (2026-07-31) PUMA44 (Slovenia)
      icao24: 506e1f · position: (45.9063, 15.5065) · alt: 335m · 151km/h
  - (2026-07-31) PUMA20 (Slovenia)
      icao24: 506e1c · position: (45.9108, 15.5562) · alt: 365m · 157km/h
  - (2026-07-31) CNA22 (Spain)
      icao24: 3475cb · position: (27.8105, -15.7746) · alt: 1066m · 148km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-31) [Taiwan Strait + South China Sea · themes] Ive tested hundreds of phone accessories this year and these are the 9 that you wont regret buying
      tomsguide.com · English · tone NA
  - (2026-07-31) [Taiwan Strait + South China Sea · themes] TinAI ? - Chiến dịch tạo năng lực thiết yếu cho công dân kỷ nguyên AI
      baophapluat.vn · Vietnamese · tone NA
  - (2026-07-31) [Taiwan Strait + South China Sea · themes] In the news today : WestJet strike looms , alert reforms , who let the dogs out ? – Winnipeg Free Press
      winnipegfreepress.com · English · tone NA
  - (2026-07-31) [Taiwan Strait + South China Sea · themes] Japan quake toll hits 35 as sniffer dogs search wrecked mall
      straitstimes.com · English · tone NA
  - (2026-07-31) [Taiwan Strait + South China Sea · themes] Traģēdija uz upes ! Desmitgadnieks izglābj māsu , bet pats iet bojā
      nra.lv · Latvian · tone NA
  - (2026-07-31) [Taiwan Strait + South China Sea · themes] Informazione Corretta - Raamnon dice che Hamas è unorganizzazione terroristica
      informazionecorretta.com · Italian · tone NA

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-31) [China] North Korea Needs China and Russia – But Doesnt Want Its People Admiring Them – The Diplomat
      thediplomat.com · English
  - (2026-07-31) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-31) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-31) [China] Why the Bangsamoro Peace Process Still Depends on Trust
      thediplomat.com · English
  - (2026-07-31) [China] Singapore private car population falls to lowest since 2019 , as rental car numbers hit record high – Asia News Network
      asianews.network · English
  - (2026-07-31) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English

### IT, InfoSys & cybersecurity news (last 7 days) — 11 new of 57 total
  - (2026-07-31) [BleepingComputer] Anthropic's Claude breached 3 orgs, uploaded PyPI malware during tests
      One of Anthropic's Claude models built and uploaded a malicious Python package to PyPI during a botched security evaluation, where it ran on 15 real systems and stole credentials from a security vendor. It was one of thr…
  - (2026-07-31) [The Register] UK wants datacenters to pay a fee for grid connection requests
      Refundable charge intended to discourage time wasters from filing applications that will never be realized
  - (2026-07-31) [The Register] Airport sign fails to boot, officers already on the scene
      Bork! Bork! That's the sound of the police
  - (2026-07-31) [The Register] Techie lured out of retirement to support software only he remembered
      The first job was lucrative and went well, but a pension was preferable to rolling projects
  - (2026-07-31) [The Register] Anthropic’s Claude escaped test sandbox to attack three organizations
      Wrote and published malware during tests, which is apparently OK because leaky test environments were the real problem
  - (2026-07-31) [The Register] Amazon's Q2 was great, but the earnings release is packed with baloney
      "Tell me lies, tell me sweet little lies"

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 38 total
  - (2026-07-31) #30 Germán Larrea Mota Velasco & family — $64.26B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-31) MOVER ▼ Zhong Shanshan — $62.26B ($-2.15B since yesterday)
      China · Food & Beverage · source: Beverages, pharmaceuticals
  - (2026-07-31) MOVER ▼ Francoise Bettencourt Meyers & family — $94.06B ($-1.75B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-31) MOVER ▲ Mukesh Ambani — $89.39B (+$0.73B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-31) MOVER ▲ Gautam Adani — $84.75B (+$0.48B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-31) MOVER ▼ Amancio Ortega — $143.63B ($-0.42B since yesterday)
      Spain · Fashion & Retail · source: Zara

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-07-31) LoL: Gen.G vs T1 - Game 1 Winner
      yes price: 0% · 24h volume: $965,443 · resolves 2026-07-31
  - (2026-07-31) LoL: Anyone's Legend vs EDward Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $698,321 · resolves 2026-07-31
  - (2026-07-31) LoL: Anyone's Legend vs EDward Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $439,803 · resolves 2026-07-31
  - (2026-07-31) LoL: Gen.G vs T1 (BO3) - LCK Round 3-4 Legend Group
      yes price: 54% · 24h volume: $422,365 · resolves 2026-07-31
  - (2026-07-31) Will Hamas agree to disarm by December 31?
      yes price: 90% · 24h volume: $363,950 · resolves 2026-12-31
  - (2026-07-31) Kharg Island no longer under Iranian control by July 31?
      yes price: 0% · 24h volume: $325,688 · resolves 2026-06-30

### State Legislative Action — 7 new of 93 total
  - (2026-07-31) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-07-31) [Alaska SB 237] An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Departm…
      An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Department of Administration; relating to e…
  - (2026-07-30) [Alaska SB 174] An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
      An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
  - (2026-07-30) [Alaska SB 24] An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco,…
      An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco, a product containing nicotine, or…
  - (2026-07-29) [Alaska SB 23] An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
      An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
  - (2026-07-29) [Alaska SB 86] An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing sy…
      An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing system; relating to the use of virtua…

### Paper Trading Scorecard — 6 new of 143 total
  - (2026-07-31) [Polymarket] Will Alphabet be the largest company in the world by market cap on July 31?
      This market will resolve to the largest company in the world by market cap on July 31, 2026, as of market close. The resolution source for this market will be a consensus of credible reporting.
  - (2026-07-31) [Manifold] Daily Coinflip
  - (2026-07-31) [Manifold] Spider-Man: Brand New Day grosses over $2B?
  - (2026-07-31) [Manifold] Is Mitch McConnell on life support and/or brain dead?
  - (2026-07-31) [Manifold] MLB: Will the Tampa Bay Rays sweep the Chicago White Sox OR will the 3-game series total 27 or more runs?
  - (2026-07-31) [Manifold] Will I make MOP 2027?

### USGS earthquakes (M4.5+, past day) — 6 new of 15 total
  - (2026-07-31) M 5.6 - 13 km ENE of San Fernando, Peru
      M5.6 · 13 km ENE of San Fernando, Peru · depth 154.355 km
  - (2026-07-31) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 37.846 km
  - (2026-07-31) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 35 km
  - (2026-07-31) M 4.9 - 287 km SW of Banda Aceh, Indonesia
      M4.9 · 287 km SW of Banda Aceh, Indonesia · depth 10 km
  - (2026-07-31) M 4.6 - Kermadec Islands region
      M4.6 · Kermadec Islands region · depth 44.986 km
  - (2026-07-31) M 4.5 - Fiji region
      M4.5 · Fiji region · depth 581.048 km

### Court opinions of consequence (federal & state) — 3 new of 60 total
  - (2026-07-28) U.S. Court of Appeals, 9th Cir.: United States v. Lopez
  - (2026-07-28) U.S. Court of Appeals, 11th Cir.: Michael Davis v. Lockheed Martin Corporation
  - (2026-07-28) U.S. Court of Appeals, D.C. Cir.: The Estate of Stephen M. Jennions v. CFTC

### GDACS — global disaster alerts — 2 new of 299 total
  - (2026-07-31) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.6M, Depth:154.355km
  - (2026-07-31) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.6M, Depth:154.355km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-31) [Marginal Revolution] An unprecedented weapon?
      I wonder if England had a “pause” movement back then: Trebuchets reached the peak of their development in medieval times, probably the most famous example being Edward I’s massive machine, Warwolf. This terrifying device…
  - (2026-07-31) [Marginal Revolution] The wisdom of Eli Dourado
      How do “international efforts” work? Unlike most of the signatories of the letter, I have been a State Department advisor and have participated in multiple treaty negotiations. I have also been a member of technical comm…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-31) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=39, 7d-median=20, 14d-median=20; carrying terms: standard, safety, directives, final, published, security, management, directive, provide, action, certain, model
- state_bills: today=93, 7d-median=117, 14d-median=117; carrying terms: program, specific, awarded, constitution, violation, establishes, based, development, project, organization, required, wildlife
- state_news: today=798, 7d-median=711, 14d-median=754; carrying terms: offering, congress, throughout, press, braun, conversation, reports, patients, latest, designed, pressherald, published
- local_news: today=243, 7d-median=228, 14d-median=228; carrying terms: atlanta, wanted, multiple, following, media, fetchpriority, project, appeared, search, evening, officials, image
- foreign_news: today=1054, 7d-median=1022, 14d-median=1023; carrying terms: bringing, tournament, burnham, specific, unbroken, visits, reports, extend, images, latest, cross, nanjing
- chinese_internal: today=308, 7d-median=265, 14d-median=270; carrying terms: china, https, global, google, people, caixin, giant, chinese, beijing, sources, shein, firms
- russian_internal: today=1080, 7d-median=916, 14d-median=912; carrying terms: forbidden, httperror, error, laquo, guardian, openai, gazeta, group, novaya, russian, street, reuters
- ukrainian_internal: today=113, 7d-median=136, 14d-median=136; carrying terms: since, destroyed, launched, vechirniy, according, study, overnight, attack, growing, claimed, reports, russia
- ukraine_theater: today=729, 7d-median=627, 14d-median=606; carrying terms: viirs, thermal, token, httperror, client, error, firms, acquired, https, active, google, liveuamap
- paper_bets: today=143, 7d-median=138, 14d-median=140; carrying terms: israel, colorado, manifold, according, colonize, annual, determined, california, event, mexico, carolina, cancelled
- weather: today=162, 7d-median=173, 14d-median=173; carrying terms: mountains, metro, overnight, locally, lower, oxnard, include, monitoring, especially, water, debris, tonight
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: spread, unemployment, total, jolts, labor, payrolls, supply, dexuseu, unrate, dexchus, growth, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, agriculture, equities, close, rates, corporate, large, crude, treasury, natural, proxy, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=110, 7d-median=115, 14d-median=116; carrying terms: misappropriation, square, belarus, specific, venezuela, human, haiti, democratic, rkiye, russia, energy, bissau
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, httperror, error, client, quiverquant, quantitative, congresstrading, unauthorized, https
- billionaires: today=38, 7d-median=38, 14d-median=36; carrying terms: peterffy, bernard, telecom, alice, italy, tiktok, source, euronext, discount, nasdaq, amancio, giancarlo
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: services, california, court, robert, supreme, blanche, appeals, trade, international, delaware, group, state
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, therapeutics, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, angels, talarico, trone, robert, congress, pinkston, raised, platner, disbursements, johnson, alexandria
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan, china, korea, switch, world
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: domain, language, police, english, india, found, strike, death, crash, iheart, kingdom, trump
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=16, 14d-median=16; carrying terms: canada, position, belgium, ground, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: remained, since, ministry, israel, derived, senegal, releases, according, cause, algeria, private, determined
- cisa_kev: today=9, 7d-median=16, 14d-median=16; carrying terms: remediation, injection, langflow, untrusted, product, fortinet, sharepoint, management, deserialization, authentication, improper, control
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=299, 7d-median=287, 14d-median=286; carrying terms: czech, medium, romania, kenya, vietnam, denmark, marino, monaco, italy, montenegro, belarus, brazil
- usgs_quakes: today=15, 7d-median=23, 14d-median=23; carrying terms: islands, depth, region, indonesia, mexico, japan, kermadec, russia, taiwan, puerto, madero
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, prime, ethiopia, interest, minister, price, rates, volume, meeting, adanech, increase, abiebie
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, conversable, revolution, benefit, class, economist, https, looking, quality, students, level, occupational
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: attack, technica, updates, written, security, researchers, computer, record, companies, edition, report, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: attorney, ratcliffe, hamadeh, nadler, burchett, barrag, eugene, langworthy, claudia, spartz, feenstra, balint
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, paper, converges, module, identify, unavailable, markets, today, sufficient, decision, market, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*