# WORLDSCOPE morning brief — 2026-10-26

## Headline
2954 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (754) · Russian Internal News (state + in-exile) (694) · World leaders & government officials (324) · Chinese Internal News (232) · Ukraine Theater (total-war monitoring) (156) · State-Level News (144) · Local News: St. Louis + Atlanta (125) · U.S. Weather + Severe / Climate Outlooks (111) · GDACS — global disaster alerts (77) · Ukrainian Internal News (national + local Kyiv) (60) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 754 new of 938 total
  - (2026-10-26) [Global] Celebrations in Serbia after veteran ruler Vučić loses election to student-led protest movement
      The populist right-wing leader of 12 years says it is "clear" his party has lost the vote billed as a referendum on the country's future.
  - (2026-10-26) [Global] Venezuelan opposition leader María Machado returns after months in exile
      Machado had left the country just a month before the US government seized Venezuelan President Nicolás Maduro.
  - (2026-10-26) [Global] Australian murderer loses bid to eat Vegemite in prison
      Andre McKechnie, who murdered a property developer, argued it was his right to enjoy Australian culture.
  - (2026-10-26) [Global] Eric Bauza, voice of Bugs Bunny and Daffy Duck, dies aged 46
      Bauza had voiced a number of characters in this summer's animated hit Coyote vs. Acme.
  - (2026-10-25) [Global] Rapper Nicki Minaj joins Trump onstage at Michigan rally
      The Super Bass singer is the latest big name to campaign in Michigan, where a tight Senate race is playing out ahead of the 3 November midterms.
  - (2026-10-26) [Global] Nurse killed in Ebola attack in DR Congo
      Local youths reportedly accused the health workers of contaminating water sources and spreading Ebola.

### Russian Internal News (state + in-exile) — 694 new of 873 total
  - (2026-10-26) Война. 1706-й день. Черное море стало самым опасным судоходным маршрутом в мире. Там гибнет больше моряков, чем в Ормузском проливе | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рас] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-26) «Когда у тебя нет света, воды или отопления, то все дни имеют значение». Украина хочет провести трехсторонние переговоры с Россией и США на неделю раньше | LEDE: Украинская сторона пытается ] (ru: «Ко…
      Украинская сторона пытается добиться проведения трехсторонних переговоров, которые, как ранее сообщали источники, должны состояться в Абу-Даби «в десятых числах ноября», хотя бы на неделю раньше.
  - (2026-10-26) «Яндекс» перевез все три своих суперкомпьютера в новое место после атак украинских беспилотников | LEDE: Все три суперкомпьютера «Яндекса» («Ляпунов», «Галушкин» и «Червоненкис») перевезли в] (ru: «Ян…
      Все три суперкомпьютера «Яндекса» («Ляпунов», «Галушкин» и «Червоненкис») перевезли в новые локации, сообщили в пресс-службе компании.
  - (2026-10-26) Футболисты «Локомотива» ехали в поезде, попавшем под удар ВСУ | LEDE: В одном из вагонов поезда, попавшего под украинский удар в Воронежской области, находились футболисты «Локомотива», сооб] (ru: Фут…
      В одном из вагонов поезда, попавшего под украинский удар в Воронежской области, находились футболисты «Локомотива», сообщают российские СМИ, в том числе Mash и MSK1. Они ссылаются на спортивного журналиста Ивана Карпова.…
  - (2026-10-26) Прокуратура потребовала завести уголовное дело на правозащитницу Анну Каретникову — она много лет сотрудничала с «Мемориалом» | LEDE: Лефортовская межрайонная прокуратура Москвы собрала мате] (ru: Про…
      Лефортовская межрайонная прокуратура Москвы собрала материалы для возбуждения уголовного дела в отношении правозащитницы Анны Каретниковой.
  - (2026-10-26) Умер Александр Кондратов — художник сериала «Ликвидация», арестованный по делу о государственной измене | LEDE: Художник-постановщик российского сериала «Ликвидация» Александр Кондратов, аре] (ru: Уме…
      Художник-постановщик российского сериала «Ликвидация» Александр Кондратов, арестованный по обвинению в госизмене, умер в Боткинской больнице в Москве, сообщает правозащитная организация «Первый отдел».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 232 new of 270 total
  - (2026-10-24) 【周刊提前读】A股并购对赌多发后遗症 事后追偿不如事先防范 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTFBSQkpGS0JPZXRZOU5iNEFuSVNtdE5hQm1fbGg4MDhDZ0JGS196QWVyc01yUmZWN09TMUV0RDBkbDZHYkVydS1HUU] (zh:…
      【周刊提前读】A股并购对赌多发后遗症 事后追偿不如事先防范 财新数据
  - (2026-10-24) 【周刊提前读】法国骚乱极左极右得利 改革缘何走进死胡同 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1TTVpsdkwtdksxNV9nc2lSQThOSlpfc1U5aHB6T1d3aGRiZFQxTmZJZFh3OF9BOWpNQmROSElGcXdMSVVtaXh1c1pJ] (zh:…
      【周刊提前读】法国骚乱极左极右得利 改革缘何走进死胡同 财新数据
  - (2026-10-26) 养老理财五年·中银理财以长期主义作答养老金融大文章_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5OdXFrS2JtRDg1aG9CSEd4b1k1ckh3REZsdEVzZWgtdHJGdmp1dDRTaUFOQ2ozb3ZGUUhvMVdxb0FWaGhUa] (zh:…
      养老理财五年·中银理财以长期主义作答养老金融大文章_特别呈现_手机财新网 财新
  - (2026-10-24) 专栏｜离婚，该动还是该静 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5rN1JjUzd3U0szNmR5akF2bW9JcEVXc1ZnWWo0aXJXTEdHN1Q1UHlvTzhIUTBuR2pTUm95bWxMMEt0UFlFMFlyOFozcnZYamtlenVTNXF] (zh:…
      专栏｜离婚，该动还是该静 财新周刊
  - (2026-10-26) 今日开盘：两市双双低开 沪指跌幅0.53% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE94LVRqc1oyRWVNRGs1YzVHZVRmdS0wUkJEU1FQY2QxYmNUNGpMRnp3aU9iaWpVbTJQaG5MSjhHYURScnlyaXJEVTVqTHpqdHUw] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.53% 财新
  - (2026-10-26) 韩国股市的狂热与焦虑 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1LQ2Qxc3lCa1NxbjBDS2ZJWmNxM1hCc3cyODFMMTNLWFFtWmcwWmU1SGJwT3FUaFFVVXNCNldFc1Qxa084aUVMSjhBSmM1cmdUaXRTbDdiay1] (zh:…
      韩国股市的狂热与焦虑 财新

### Ukraine Theater (total-war monitoring) — 156 new of 390 total
  - (2026-10-25) [FIRMS] thermal anomaly 51.133, 23.546 (FRP 0.88 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-25 0124Z, FRP 0.88 MW
  - (2026-10-25) [FIRMS] thermal anomaly 49.021, 22.901 (FRP 2.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-25 0124Z, FRP 2.89 MW
  - (2026-10-25) [FIRMS] thermal anomaly 49.024, 22.903 (FRP 3.48 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-25 0124Z, FRP 3.48 MW
  - (2026-10-25) [FIRMS] thermal anomaly 45.257, 31.667 (FRP 3.14 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-25 0126Z, FRP 3.14 MW
  - (2026-10-25) [FIRMS] thermal anomaly 45.251, 31.663 (FRP 3.14 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-25 0126Z, FRP 3.14 MW
  - (2026-10-25) [FIRMS] thermal anomaly 45.948, 25.277 (FRP 0.94 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-25 0126Z, FRP 0.94 MW

### State-Level News — 144 new of 258 total
  - (2026-10-26) [California] Governor Newsom proclaims Larry Itliong Day
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/SEO-Thumbnail-Template-2.0-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="Blue background with a white ci…
  - (2026-10-26) [Connecticut] What to know about CT Mirror’s investigation into prison debt
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/09/PRISON-TRACY-0924-SG-02-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-10-26) [Connecticut] Marching to oppose a new gas pipeline in CT
      <img width="1024" height="653" src="https://ctmirror.org/wp-content/uploads/2026/10/gas-pipe-2-1024x653.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctm…
  - (2026-10-26) [Delaware] Beyond the Headlines: Getting the community answers surrounding violence in Wilmington
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/10/Brianna-podcast-web.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-10-26) [Delaware] Get Involved: Georgetown tiny homes, state bonds for Lewes and Sussex land use
      <img width="1000" height="800" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/10/Get-Involved-Artwork-Template-1000x800-18.png?fit=1000%2C800&ssl=1" class="attachment-rss-image-size size-rss-image-s…
  - (2026-10-26) [Delaware] Smyrna couple ‘rescues’ human skeletons, hopes to build a church lined with bones
      <img width="1024" height="669" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/10/Ossuary-17-scaled-e1792966026512.jpg?fit=1024%2C669&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-po…

### Local News: St. Louis + Atlanta — 125 new of 193 total
  - (2026-10-26) [St. Louis] Top family-friendly events this week in St. Louis
      See Also: Fall Family Fun Guide Fall into Economics | October 26–November 2Who says learning about money can’t be fun? The Economy Museum is celebrating fall with activities that make math and economics approachable for…
  - (2026-10-26) [St. Louis] Phelps County Jail says goodbye to ICE detainees—for real this time
      The Phelps County Jail has transferred out its detainees from Immigration and Customs Enforcement. That action comes about 10 days after the Archdiocese of St. Louis filed suit against a different rural Missouri jail, ac…
  - (2026-10-26) [St. Louis] Suit seeking SLPS board member’s removal won’t come to a head until after closure vote
      Even before Robert Harvey was sworn into the Board of Education for the St. Louis Public Schools last February, questions swirled about whether he qualified for the position. State law requires that school board members…
  - (2026-10-25) [St. Louis] Chevys Fresh Mex closes in Olivette
      Chevys Fresh Mex (9119 Olive) in Olivette is closing October 25, ending a run of more than 30 years. As of this writing, no reason for the closure had been publicly announced, no signs at the restaurant indicated that it…
  - (2026-10-26) [St. Louis] Proposition A will determine fate of Missouri’s Trump-backed congressional map
  - (2026-10-26) [St. Louis] Madison County board bars data centers from receiving tax incentives through Illinois program

### U.S. Weather + Severe / Climate Outlooks — 111 new of 113 total
  - (2026-10-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-26) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 26 at 6:37AM MDT until October 26 at 10:00AM MDT by NWS Albuquerque NM
      * WHAT...Visibility below a half mile in dense fog. * WHERE...Espanola Valley, Far Northwest Highlands Including Dulce, Santa Fe Metro Area, Tusas Mountains Including Chama, Northeast Highlands Including Las Vegas, and U…
  - (2026-10-26) [Severe] Flood Warning: Flood Warning issued October 26 at 6:54AM CDT until October 26 at 10:00AM CDT by NWS Amarillo TX
      * WHAT...Flooding caused by excessive rainfall is occurring. * WHERE...Southeastern Dallam County in the panhandle of Texas... Northeastern Hartley County in the panhandle of Texas... * WHEN...Until 1000 AM CDT. * IMPACT…
  - (2026-10-26) [Moderate] Special Weather Statement: Special Weather Statement issued October 26 at 6:50AM CDT by NWS Goodland KS
      Widespread fog is reducing visibility under 3 miles with transient dense patches reducing visibility down to less than 1/4 mile. These conditions are forecast to gradually improve over the next couple of hours. As of 545…
  - (2026-10-26) [Severe] Storm Warning: Storm Warning issued October 26 at 3:42AM AKDT until October 27 at 5:00AM AKDT by NWS Anchorage AK
      Offshore Waters Forecast for the Bering Sea Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. .TO…
  - (2026-10-26) [Extreme] Hurricane Force Wind Warning: Hurricane Force Wind Warning issued October 26 at 3:42AM AKDT until October 26 at 5:00PM AKDT by NWS Anchorage AK
      Offshore Waters Forecast for the Bering Sea Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. .TO…

### GDACS — global disaster alerts — 77 new of 100 total
  - (2026-10-26) [Red] Tropical Cyclone ARNAB-26
      Tropical Cyclone · Red alert · India · Hurricane/Typhoon > 74 mph (maximum wind speed of 204 km/h)
  - (2026-10-14) [Red] Tropical Cyclone CHAMPI-26
      Tropical Cyclone · Red alert · Philippines, Guam, Northern Mariana Islands, Japan, China, South Korea · Tropical Storm (maximum wind speed of 296 km/h)
  - (2026-10-26) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 5.2M, Depth:10km
  - (2026-10-26) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 4.6M, Depth:35km
  - (2026-10-26) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 5M, Depth:10km
  - (2026-10-26) [Green] Earthquake in South Sandwich Islands Region
      Earthquake · Green alert · South Sandwich Islands Region · Magnitude 4.8M, Depth:173.493km

### Ukrainian Internal News (national + local Kyiv) — 60 new of 123 total
  - (2026-10-26) На виборах у Сербії порахували майже всі голоси: "студенти" набирають понад 52% | LEDE: ] (uk: На виборах у Сербії порахували майже всі голоси: "студенти" набирають понад 52%)
  - (2026-10-26) Бригаду першого командувача СБС повернули до Сухопутніх військ | LEDE: 59 окрема штурмова бригада безпілотних систем імені Якова Гандзюка повернеться назад до складу Сухопутних військ ЗСУ.] (uk: Брига…
      59 окрема штурмова бригада безпілотних систем імені Якова Гандзюка повернеться назад до складу Сухопутних військ ЗСУ.
  - (2026-10-26) Росіяни вдарили по Ясногірці: загинула людина, серед поранених – підлітка | LEDE: Щонайменше одна людина загинула і 10 дістали поранення внаслідок ударів по Краматорській громаді. Серед поранен] (uk:…
      Щонайменше одна людина загинула і 10 дістали поранення внаслідок ударів по Краматорській громаді. Серед поранених — 13-річна дівчина.
  - (2026-10-26) У Путіна не збираються припиняти бойові дії в Україні на час мирних переговорів | LEDE: Росія не збирається припиняти бойові дії в Україні, навіть якщо відновлять тристоронні мирні переговори з] (uk:…
      Росія не збирається припиняти бойові дії в Україні, навіть якщо відновлять тристоронні мирні переговори за участю США, РФ та України.
  - (2026-10-26) ЗМІ: "Дорожня карта" передбачає завершення переговорів про вступ України до ЄС в кінці 2029 року | LEDE: "Дорожні карти", які ЄС готує для чотирьох країн, які вважаються лідерами у євроінтеграц] (uk:…
      "Дорожні карти", які ЄС готує для чотирьох країн, які вважаються лідерами у євроінтеграції, міститимуть орієнтовні дати завершення переговорів про вступ – для України це кінець 2029 року.
  - (2026-10-26) Пограбування, катування і захоплення АЕС називають "воєнним злочином": правозахисники пропонують розділити терміни | LEDE: ] (uk: Пограбування, катування і захоплення АЕС називають "воєнним злочином":…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-10-26) [Israel-Iran-Hezbollah axis · keywords] Israel Right Fights Over Who Gets To Rule The Jewish State « nuclear - news
      nuclear-news.net · English · tone NA
  - (2026-10-26) [Israel-Iran-Hezbollah axis · keywords] Israel election : Five key things to know | Israel Election 2026 News
      aljazeera.com · English · tone NA
  - (2026-10-26) [Israel-Iran-Hezbollah axis · keywords] Global polls find Israel is the least popular country on Earth , disliked by 67 % of people
      nuclear-news.net · English · tone NA
  - (2026-10-26) [Israel-Iran-Hezbollah axis · keywords] A look at the main issues in Israeli elections seen as a referendum on Netanyahu
      lancasteronline.com · English · tone NA
  - (2026-10-26) [Israel-Iran-Hezbollah axis · keywords] Trump dials up Islamophobia against Abdul El - Sayed at Michigan Senate rally
      aljazeera.com · English · tone NA
  - (2026-10-26) [Israel-Iran-Hezbollah axis · keywords] ​ Vote for Bibi for PM : Trump Renews Pitch for Netanyahu as Israel Heads to Crucial Post - War Polls
      pragativadi.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-26) [Allot Ltd.] Form 4 (Issuer)
      filed 2026-10-26 13:07 UTC · role: Issuer — Filed: 2026-10-26 AccNo: 0001976408-26-000901 Size: 5 KB
  - (2026-10-26) [Levy Steven D] Form 4 (Reporting)
      filed 2026-10-26 13:07 UTC · role: Reporting — Filed: 2026-10-26 AccNo: 0001976408-26-000901 Size: 5 KB
  - (2026-10-26) 424B5 - TEXAS INSTRUMENTS INC (0000097476) (Filer)
      filed 2026-10-26 13:03 UTC — Filed: 2026-10-26 AccNo: 0001193125-26-431173 Size: 595 KB
  - (2026-10-26) 424B3 - REPUBLIC OF COLOMBIA (0000917142) (Filer)
      filed 2026-10-26 12:53 UTC — Filed: 2026-10-26 AccNo: 0001193125-26-431155 Size: 998 KB
  - (2026-10-26) 424B3 - REPUBLIC OF COLOMBIA (0000917142) (Filer)
      filed 2026-10-26 12:48 UTC — Filed: 2026-10-26 AccNo: 0001193125-26-431145 Size: 1 MB
  - (2026-10-26) 497 - HARTFORD MUTUAL FUNDS, INC (0001006415) (Filer)
      filed 2026-10-26 12:48 UTC — Filed: 2026-10-26 AccNo: 0001193125-26-431144 Size: 60 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-10-26) CFC3414 (Canada)
      icao24: c2c377 · position: (37.4894, -76.6621) · alt: 11582m · 899km/h
  - (2026-10-26) PAT629 (United States)
      icao24: adfe53 · position: (42.9058, -97.0643) · alt: 7620m · 472km/h
  - (2026-10-26) CFC3122 (Canada)
      icao24: c2c1fb · position: (45.3254, -75.6495) · on ground · 37km/h
  - (2026-10-26) JEDI75 (United States)
      icao24: ae1ea7 · position: (30.4799, -87.3867) · alt: 3878m · 358km/h
  - (2026-10-26) JEDI21 (United States)
      icao24: ae1ea9 · position: (30.5786, -88.1537) · alt: 472m · 322km/h
  - (2026-10-26) JAF4MH (Belgium)
      icao24: 44d1ba · position: (33.6358, -9.5943) · alt: 11277m · 769km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 27 new of 57 total
  - (2026-10-26) [BleepingComputer] Kali Linux 2026.3 released with 6 new tools, desktop updates
      Kali Linux has released version 2026.3, its third release this year, featuring six new hacking tools, desktop environment improvements, refreshed build scripts, and more. [...]
  - (2026-10-26) [BleepingComputer] PHP2Shell security flaws now sucessfully exploited in the wild
      Two critical RCE vulnerabilities (CVE-2026-109618 and CVE-2026-109619), collectively tracked as PHP2Shell, have been successfully exploited in the wild. [...]
  - (2026-10-26) [The Hacker News] Two Critical Wasmtime Flaws Could Let Malicious WebAssembly Modules Escape Sandboxes
      Two critical flaws in Wasmtime, a WebAssembly runtime that can be built into other software, could allow a malicious WebAssembly module to escape the sandbox intended to contain it, the project's maintainers say. An atta…
  - (2026-10-26) [The Hacker News] Between alerts: What Attackers Do in the Spaces Ordinary Detection Misses
      Every SOC struggles with a pile of alerts. Very few of those alerts explain how an attack started or how it progressed. Network data, like that from a network detection and response (NDR) platform, connects individual al…
  - (2026-10-26) [The Hacker News] uCreator Android Spyware Can Steal Telegram 2FA Passwords and Clone WeChat Accounts
      A rentable Android spyware kit called uCreator takes over Telegram and WeChat accounts by hiding its code inside working copies of the two apps, researcher Ovi found. It only reaches people who install one of these tampe…
  - (2026-10-26) [The Hacker News] Microsoft 365 Token-Replay Attacks Compromise 97 Accounts at 79 Organizations
      Cybersecurity researchers have disclosed a Microsoft 365 campaign that has been observed leveraging an adversary-in-the-middle (AitM) relay to capture sign-in sessions and then replay the stolen tokens to break into emai…

### State Legislative Action — 23 new of 25 total
  - (2026-10-24) [Alaska SB 239] An Act relating to commercial motor vehicle licensing examinations; relating to the registration and titling of legally imported motor vehicles; relating to proof of financial responsi…
      An Act relating to commercial motor vehicle licensing examinations; relating to the registration and titling of legally imported motor vehicles; relating to proof of financial responsibility for suspension for nonpayment…
  - (2026-10-24) [Alaska HB 176] An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date…
      An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date.
  - (2026-10-24) [Alaska SCR 11] Establishing a legislative commission to review and make recommendations to the legislature relating to the official state seal.
      Establishing a legislative commission to review and make recommendations to the legislature relating to the official state seal.
  - (2026-10-24) [Alaska HB 371] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution discl…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution disclosure requirements; requiring the di…
  - (2026-10-24) [Alaska SB 157] An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date…
      An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date.
  - (2026-10-24) [Alaska HB 13] An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobi…
      An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobile intensive care paramedic service…

### USGS earthquakes (M4.5+, past day) — 18 new of 18 total
  - (2026-10-26) M 5.5 - 283 km E of Levuka, Fiji
      M5.5 · 283 km E of Levuka, Fiji · depth 641.812 km
  - (2026-10-25) M 5.3 - Bonin Islands, Japan region
      M5.3 · Bonin Islands, Japan region · depth 485.13 km
  - (2026-10-26) M 5.2 - 205 km NW of Port-Olry, Vanuatu
      M5.2 · 205 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-25) M 5.2 - 59 km SW of Ashkāsham, Afghanistan
      M5.2 · 59 km SW of Ashkāsham, Afghanistan · depth 110.025 km
  - (2026-10-26) M 5.0 - 218 km NW of Port-Olry, Vanuatu
      M5.0 · 218 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-26) M 5.0 - 45 km NNW of Ende, Indonesia
      M5.0 · 45 km NNW of Ende, Indonesia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-10-26) Will the Republican Party control the House after the 2026 Midterm elections?
      yes price: 8% · 24h volume: $1,140,425 · resolves 2026-11-04
  - (2026-10-26) Will Benjamin Netanyahu be the next Prime Minister of Israel?
      yes price: 26% · 24h volume: $1,080,807 · resolves 2026-10-28
  - (2026-10-26) Dota 2: OG vs GamerLegion (BO3) - PARI Universe Group A
      yes price: 0% · 24h volume: $1,057,849 · resolves 2026-10-26
  - (2026-10-26) Will the Democratic Party control the House after the 2026 Midterm elections?
      yes price: 92% · 24h volume: $1,016,530 · resolves 2026-11-04
  - (2026-10-26) Will Ousmane Dembélé win the 2026 Ballon d'Or?
      yes price: 0% · 24h volume: $1,013,889 · resolves 2026-10-27
  - (2026-10-26) Will Khvicha Kvaratskhelia win the 2026 Ballon d'Or?
      yes price: 0% · 24h volume: $858,205 · resolves 2026-10-27

### Paper Trading Scorecard — 14 new of 65 total
  - (2026-10-26) [Polymarket] Will there be no next German Chancellor before 2028?
      Friedrich Merz has served as Chancellor of Germany since May 6, 2025. This market will resolve to the next individual, other than Friedrich Merz, who assumes the office of Chancellor of Germany. To count for resolution,…
  - (2026-10-26) [Manifold] Will customer service employment fall >5% in 2026?
  - (2026-10-26) [Manifold] Will Manifold Market be shut down for corruption (stealing trades off the books) and swaying outcomes by EOY 2027?
  - (2026-10-26) [Manifold] Will Elon Musk disable Ukraine's access to Starlink before the end of the war?
  - (2026-10-26) [Manifold] Will the linked market have 100 traders before it resolves?
  - (2026-10-26) [Manifold] Will BLS report more than 275,600 data scientist jobs in the United States in 2030?

### World News (by country, top stories) — 12 new of 12 total
  - (2026-10-26) [Japan] Israel Right Fights Over Who Gets To Rule The Jewish State « nuclear - news
      nuclear-news.net · English
  - (2026-10-26) [Japan] Volvo Cars hits record low after steep loss , 2 , 500 job cuts
      japanherald.com · English
  - (2026-10-26) [Japan] Scottish Greens set to vote on whether to support new nuclear power
      nuclear-news.net · English
  - (2026-10-26) [Japan] Campaigners warn Welsh island could be target in nuclear attack amid fears of no safe evacuation « nuclear - news
      nuclear-news.net · English
  - (2026-10-26) [Japan] Global polls find Israel is the least popular country on Earth , disliked by 67 % of people
      nuclear-news.net · English
  - (2026-10-26) [Japan] Rafael Grossi enthusiastic about the future of the nuclear energy industry
      nuclear-news.net · English

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-10-23) Hawaii Supreme Court: McCormick 106, LLC v. Young
  - (2026-10-23) Hawaii Supreme Court: In re: Kumuhone
  - (2026-10-23) Hawaii Supreme Court: In re: Akman
  - (2026-10-22) Hawaii Supreme Court: State v. Gaeta
  - (2026-10-22) Florida Supreme Court: S.H., in the Interest of A.H. and K.W., the Children v. Department of Children and Families and Guardian Ad Litem
  - (2026-10-22) Florida Supreme Court: Daniel Jacob Craven, Jr. v. State of Florida & Daniel Jacob Craven, Jr. v. Secretary, Department of Corrections

### Government Action: Sanctions + Procurement + Foreign Agents — 3 new of 102 total
  - (2026-10-26) [USASpending] $559,230,977 → HANFORD LABORATORY MANAGEMENT AND INTEGRATION LLC: SERVICES DESCRIBED IN SECTION C.2 TO OPERATE AND MAINTAIN TH
      Agency: Department of Energy. Description: SERVICES DESCRIBED IN SECTION C.2 TO OPERATE AND MAINTAIN THE 222-S LABORATORY COMPLEX.
  - (2026-10-26) [USASpending] $547,729,109 → BOOZ ALLEN HAMILTON INC: ENGINEERING DEVELOPMENT INTEGRATION AND TECHNOLOGYBASED SOLU
      Agency: General Services Administration. Description: ENGINEERING DEVELOPMENT INTEGRATION AND TECHNOLOGYBASED SOLUTIONS EDITS
  - (2026-10-25) [EU Sanctions] Restrictive measures with respect to ISIL (Da'esh) and Al-Qaida
      Last amended: 2026-10-25. Acronym: ISIL/Daesh & Al-Qaida.

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-26) [Marginal Revolution] The MR Archive!
      The Marginal Revolution archive is now live at https://marginalrevolution.com/ai-archive/. You can also find it from the “Download Full Archive” link in the left menu. The purpose of the archive is twofold, first as Tyle…
  - (2026-10-26) [Marginal Revolution] Tyler Cowen’s Strongest Book Recommendations, 2003-2026
      From the Archive–these posts are written by AI. Cowen’s strongest recommendations include 1491, The Power Broker, Knausgaard’s first two My Struggle volumes, Fuchsia Dunlop’s Chinese cookbooks, and Meetings with Remarkab…
  - (2026-10-26) [Marginal Revolution] Brazil’s economic problems, in a nutshell
      It would take true Milei-like ardour to slice through Brazil’s economic troubles. These are caused by a gnarly mix of high public spending, stubborn inflation and low saving. The result is a crippling cost of capital. So…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=14, 14d-median=17; carrying terms: proposed, final, regulatory, protection, certain, enforcement, proposing, action, rulemaking, national, document, period
- state_bills: today=25, 7d-median=70, 14d-median=108; carrying terms: relating, district, providing, state, school, alaska, specified, insurance, vehicles, assistance, contracts, california
- state_news: today=258, 7d-median=678, 14d-median=678; carrying terms: congress, community, local, families, senator, plant, bottom, wisconsin, vermont, residents, commonwealthbeacon, decoding
- local_news: today=193, 7d-median=238, 14d-median=235; carrying terms: health, louis, police, target, following, murder, death, appeared, missing, suspect, finals, color
- foreign_news: today=938, 7d-median=1011, 14d-median=1011; carrying terms: return, congress, sales, families, senator, bottom, theeastafrican, swissinfo, defend, thejakartapost, potential, wanted
- chinese_internal: today=270, 7d-median=270, 14d-median=278; carrying terms: cbmibefvx, cbmiykfvx, cbmickfvx, china, title, cbmiw, cbmiy, lxtfa, articles, lxtfb, target, color
- russian_internal: today=873, 7d-median=1010, 14d-median=1019; carrying terms: title, telegram, istories, forbidden, error, europe, russian, media, starlink, street, politico, server
- ukrainian_internal: today=123, 7d-median=136, 14d-median=130; carrying terms: preparing, patriot, strikes, russian, campaign, following, independent, critical, putin, nearly, censor, facility
- ukraine_theater: today=390, 7d-median=397, 14d-median=397; carrying terms: pmzhdu, jblvzt, sgxmcgwzdxbrqzjzvzfzwmxub, ycfdbqktzrl, community, curyvkvlsfhnujhsmm, plant, zxlvrwei, tkzxpfy, ujkznknfzw, rgvvyzzrwhz, repeater
- paper_bets: today=65, 7d-median=65, 14d-median=68; carrying terms: named, earthquake, break, chair, visit, goldman, henry, manifold, season, millennium, unemployment, israel
- weather: today=113, 7d-median=138, 14d-median=138; carrying terms: beach, watch, afddtx, afternoon, craft, hazardous, along, louis, northeast, national, issued, mount
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, total, supply, jtsjol, walcl, labor, payems, openings, implied, sheet, effective, dexjpus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, close, agriculture, corporate, china, range, treasury, russell, futures, natural, commodities, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=102, 7d-median=105, 14d-median=107; carrying terms: agency, mission, extra, energy, transnistrian, republic, political, protecting, herzegovina, specific, measures, harmful
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quiver, error, congresstrading, https, quantitative, httperror, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: board, state, supreme, court, appeals, trade, blanche, international, delaware, arkansas, alabama, company
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed, holdings, filer, financial, subject, estate, funds, bluerock, global
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ocasio, receipts, senate, warner, booker, congress, pinkston, jonathan, robert, alexandria, sherrod, cycle
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan, japanherald, china
- gdelt_gkg: today=50, 7d-median=25, 14d-median=25; carrying terms: english, israel, themes, sanctions, keywords, chinese, spanish, vietnamese, trump, china, world, greek
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=23, 14d-median=28; carrying terms: position, belgium, ground, germany, kingdom, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: measles, traceability, yellow, geographically, third, burial, round, november, social, unaffected, virology, local
- cisa_kev: today=17, 7d-median=17, 14d-median=15; carrying terms: injection, vendor, traversal, product, remediation, server, improper, cisco, vulnerability, command, control, fortinet
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: earthquake, impact, tropical, magnitude, speed, green, cyclone, forest, hurricane, alert, depth, islands
- usgs_quakes: today=18, 7d-median=22, 14d-median=21; carrying terms: depth, russia, vanuatu, indonesia, alaska, region, islands, china, kuril, japan, south, nagqu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, october, resolves, price, shakhtar, election, donetsk, champions, interest, meeting, rates, championship
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, class, revolution, marginal, https, economist, marginalrevolution, government, world, economic, economists, money
- tech_news: today=57, 7d-median=57, 14d-median=58; carrying terms: krebs, report, ransomware, services, spectrum, behind, control, intelligence, disclosed, takes, sensitive, artificial
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: fedorchak, deposit, crapo, nanette, jason, summer, andrea, madeleine, hegseth, virginia, foushee, ketanji
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, placement, converges, markets, identify, today, either, consensus, paper, claude, decision, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-19] ECB press: Frank Elderson: From climate and nature risks to economic resilience and competitiveness
- [2026-10-20] ECB press: Frank Elderson: Interview with Die Presse
- [2026-10-21] ECB press: Philip R. Lane: Euro liquidity lines and the international monetary system
- [2026-10-21] ECB press: Piero Cipollone: Pontes and Appia: unlocking opportunities for banks
- [2026-10-23] ECB press: ECB Consumer Expectations Survey results – September 2026
- [2026-10-24] ECB press: Piero Cipollone: Interview with Milano Finanza
- [2026-10-26] ECB press: Frank Elderson: Taking action for nature – investing in economic resilience and prosperity
- [2026-10-26] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*