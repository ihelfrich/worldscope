# WORLDSCOPE morning brief — 2026-07-19

## Headline
1750 new items across 20 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (393) · World leaders & government officials (324) · Russian Internal News (state + in-exile) (287) · Chinese Internal News (159) · Ukraine Theater (total-war monitoring) (141) · U.S. Weather + Severe / Climate Outlooks (130) · Local News: St. Louis + Atlanta (62) · State-Level News (56) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (34) · Sanctions & Designations (recent) (30) · GDACS — global disaster alerts (29)

## What changed today
### International News + Multilateral Institutions — 393 new of 981 total
  - (2026-07-19) [Global] US and Iran exchange strikes after two US soldiers killed in Jordan
      US forces target Iranian sites for the eighth night in a row, while Iran says it fired drones at the US military in Kuwait.
  - (2026-07-19) [Global] Andrew Tate and brother arrested in US after more charges laid against them in UK
      The Crown Prosecution Service says it has requested their extradition from the US, while their lawyer says they are innocent.
  - (2026-07-19) [Global] Russia launches major ballistic missile attack on Kyiv
      One death is reported in what President Zelensky calls "one of the most massive ballistic attacks" on Ukraine's capital.
  - (2026-07-19) [Global] Cuban dissident Luis Manuel Otero Alcántara goes into exile in US
      He was arrested in 2021 during Cuba's largest anti-government protests in decades and spent five years ⁠in prison.
  - (2026-07-19) [Global] New EU border system tripling time at passport control, airport boss says
      Ryanair has also warned passengers travelling to Europe this summer to prepare for extended waits.
  - (2026-07-19) [Global] Ferry carrying 116 passengers sinks off Guyana coast, authorities say
      Eight passengers have so far been rescued after the vessel capsized between Georgetown and Port Kaituma.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Russian Internal News (state + in-exile) — 287 new of 780 total
  - (2026-07-19) В работе фейсбука и инстаграма произошел масштабный сбой | LEDE: В работе соцсетей Facebook и Instagram (обе принадлежат компании Meta) произошел масштабный сбой, следует из данных сервиса D] (ru: В р…
      В работе соцсетей Facebook и Instagram (обе принадлежат компании Meta) произошел масштабный сбой, следует из данных сервиса Downdetector (1,2).
  - (2026-07-19) Умер телеведущий Сергей Шолохов | LEDE: В Петербурге умер журналист и телеведущий Сергей Шолохов, сообщил его пасынок Всеволод Москвин. Шолохову было 67 лет. ] (ru: Умер телеведущий Сергей Шолохов)
      В Петербурге умер журналист и телеведущий Сергей Шолохов, сообщил его пасынок Всеволод Москвин. Шолохову было 67 лет.
  - (2026-07-19) Англия обыграла Францию в матче ЧМ за третье место — и впервые за 60 лет стала призером турнира | LEDE: Сборная Англии со счетом 6:4 обыграла команду Франции в матче за третье место чемпиона] (ru: Анг…
      Сборная Англии со счетом 6:4 обыграла команду Франции в матче за третье место чемпионата мира по футболу. Игра проходила в Майами на стадионе «Хард Рок Стэдиум».
  - (2026-07-19) Украинские беспилотники атаковали два танкера в морском терминале Каспийского трубопроводного консорциума в Новороссийске | LEDE: Украинские беспилотники атаковали морской терминал Каспийско] (ru: Укр…
      Украинские беспилотники атаковали морской терминал Каспийского трубопроводного консорциума (КТК) в Новороссийске во время погрузки нефти, сообщили в КТК.
  - (2026-07-19) В Ставропольском крае после атаки украинских беспилотников пожары на промышленных объектах (вероятно, это нефтебазы). В Курске дроны попали в многоэтажные дома | LEDE: Российские ПВО в ночь ] (ru: В С…
      Российские ПВО в ночь на 19 июня перехватили и уничтожили 140 украинских беспилотников над восемью регионами России, аннексированным Крымом, Азовским и Черными морями, отчиталось Минобороны РФ.
  - (2026-07-19) Мир оказался как никогда близок к победе над СПИДом — и ровно в этот момент кончились деньги. Есть ли теперь шанс справиться с эпидемией? | LEDE: За почти полвека с момента первого зарегистр] (ru: Мир…
      За почти полвека с момента первого зарегистрированного случая мир научился эффективно подавлять ВИЧ, добился снижения смертности более чем вдвое и получил профилактику, близкую по эффективности к вакцине. И ровно в этот…

### Chinese Internal News — 159 new of 277 total
  - (2026-07-17) DeepSeek Reaches $52 Billion Valuation in Round Backed by Tencent, CATL - Caixin Global
      DeepSeek Reaches $52 Billion Valuation in Round Backed by Tencent, CATL Caixin Global
  - (2026-07-18) 权威阐释 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE5MNUxzMUJSQzhCTUJJeHBsRUtGVTV5YTRhZmd3R1R1NkRncmUwTG1OWF9WRVpCclB6a0FZRlh3YzZQSUFha3lUVUJtQ3V2OUZyVHNodjVxNml] (zh:…
      权威阐释 中国共产党新闻网
  - (2026-07-19) 荷花香染百年园林 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5YZEZEMld1c1B2M0FOeHM4OVMxNGp3OWRnc2FNMGI0Qlp3N2FobFcydGpGZFNIS3NIdGJ0LVloRHFPMGRyQWxPTVBIazdwaFhURHF2UzN1NktN] (zh:…
      荷花香染百年园林 人民网
  - (2026-07-19) 行进中国丨烟雨丹霞美如画 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBIQVVtWmFOVHRYdm9tTUtOOHFrQTMyeDhkSjVESjljemV3dGlYdnRBV2tjYWd0SXlsdURLV3dUdTdqd0VEWk9NSHhpbjRxWXFWQlh1Nm0w] (zh:…
      行进中国丨烟雨丹霞美如画 人民网
  - (2026-07-19) 开局之年看中国丨秦地山河阔 烟火满人间 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBXU1Z6RW91R1Y3T3ZvT0EwS21lX1BWZ2E4TmF1QWxoNEhFdk5IVFpfZ3ZRTU5xWmgzX0FuN2x5T0FJRF9za1o1SXdjczBTWTJOQ] (zh:…
      开局之年看中国丨秦地山河阔 烟火满人间 人民网
  - (2026-07-19) 经纬线·习主席提出人工智能发展的时代之问 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTE5XWmQ2NkVBanBGZ3NHdmlZT1EzRVhOVkFUN3hRN2V3N1BUUkhscHFicnk4OTYwSmw0eFZrYTZWZHVXS] (zh:…
      经纬线·习主席提出人工智能发展的时代之问 politics.people.com.cn

### Ukraine Theater (total-war monitoring) — 141 new of 576 total
  - (2026-07-19) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-18) [FIRMS] thermal anomaly 48.533, 34.644 (FRP 4.22 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 4.22 MW
  - (2026-07-18) [FIRMS] thermal anomaly 48.534, 34.635 (FRP 3.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 3.38 MW
  - (2026-07-18) [FIRMS] thermal anomaly 48.534, 34.645 (FRP 3.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 3.18 MW
  - (2026-07-18) [FIRMS] thermal anomaly 48.520, 34.626 (FRP 1.17 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 1.17 MW
  - (2026-07-18) [FIRMS] thermal anomaly 47.866, 33.427 (FRP 2.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 2.29 MW

### U.S. Weather + Severe / Climate Outlooks — 130 new of 140 total
  - (2026-07-19) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-19) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued July 19 at 4:17AM CDT until July 19 at 1:00PM CDT by NWS Chicago IL
      * WHAT...High wave action and dangerous currents expected at Lake Michigan beaches. Waves 3 to 5 ft expected. * WHERE...In Illinois, Lake, Northern Cook and Central Cook Counties. In Indiana, Lake and Porter Counties. *…
  - (2026-07-19) [Moderate] Special Weather Statement: Special Weather Statement issued July 19 at 5:15AM EDT by NWS Tampa Bay Ruskin FL
      At 515 AM EDT, Doppler radar was tracking a strong thunderstorm 13 miles south of Gulf Gate Estates, or 17 miles west of North Port, moving north at 35 mph. HAZARD...Wind gusts of 40 to 50 mph. SOURCE...Radar indicated.…
  - (2026-07-19) [Severe] Flash Flood Warning: Flash Flood Warning issued July 19 at 4:14AM CDT until July 19 at 6:30AM CDT by NWS Midland/Odessa TX
      At 414 AM CDT /314 AM MDT/, Doppler radar indicated thunderstorms producing heavy rain across the warned area. Between 1 and 2 inches of rain have fallen. Additional rainfall amounts up to 0.5 inches are possible in the…
  - (2026-07-19) [Moderate] Special Weather Statement: Special Weather Statement issued July 19 at 4:10AM CDT by NWS Duluth MN
      Dry conditions and occasionally breezy winds will lead to near critical fire weather conditions today. Southwest winds of 5 to 10 mph with gusts of 15 to 20 mph are forecast for this afternoon. Minimum relative humidity…
  - (2026-07-19) [Severe] Flood Watch: Flood Watch issued July 19 at 3:07AM MDT until July 19 at 6:00PM MDT by NWS Albuquerque NM
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of central New Mexico, including the following area, South Central Mountains. * WHEN...From noon MDT today through this a…

### Local News: St. Louis + Atlanta — 62 new of 213 total
  - (2026-07-19) [St. Louis] See the July 19, 1926, front page: Augustus Labadie dies at 82 in home of his birth
      Headlines from the July 19, 1926, front page include: Six robbers get $8,000 in holdup of a street car.
  - (2026-07-19) [St. Louis] Banaszek, Ronald
      Banaszek, Ronald Paul
  - (2026-07-19) [St. Louis] Bartnett, Sally
      Bartnett, Sally M. (nee Deevers)
  - (2026-07-19) [St. Louis] Bilodeau, Joseph
      Bilodeau, Joseph M. "Mustang"
  - (2026-07-19) [St. Louis] Boyer, Sara
      Boyer, Sara
  - (2026-07-19) [St. Louis] Boyer, Sara
      Boyer, Sara Bibbs (nee Awalt)

### State-Level News — 56 new of 431 total
  - (2026-07-19) [Connecticut] The stories behind rows of unmarked stones at New Haven paupers’ cemetery
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/PAUPERS-CEMETERY-0702-JL-08-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fe…
  - (2026-07-19) [Connecticut] Hot and bothered – summer’s transportation meltdown
      <img width="694" height="307" src="https://ctmirror.org/wp-content/uploads/2026/07/sunkinks-example.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="…
  - (2026-07-19) [Florida] United Methodist conference to move meeting out of Idaho, citing LGBTQ+, immigrant safety concerns
      This story was first published on July 14, 2026, by FāVS News. Citing dangers to LGBTQ+ and immigrant communities, the Oregon-Idaho Conference of the United Methodist Church voted last month to move next year’s annual co…
  - (2026-07-19) [Georgia] Public health improvements stall amid Trump’s DEI crackdown
      THOMASVILLE, Ga. — As Earl Williams drove through a historic Black neighborhood known as Dewey City in his hometown, he hardly recognized what he saw. Homes that once belonged to friends, family, and neighbors had siding…
  - (2026-07-19) [Maine] Maine ICE death is part of Susan Collins’ legacy | Letter
      So we finally have a death here in Biddeford, Maine — a 26-year-old Colombian with legal working papers — killed at the hands of the ICE goon squad. Our credulous Sen. Susan Collins — who voted for another $70 billion of…
  - (2026-07-19) [Maine] Political consequences should be applied evenly | Letter
      Graham Platner withdrew from a political race because of an alleged scandal. This reflects one set of circumstances. Donald Trump’s political career — despite numerous controversies and allegations over the years — refle…

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-19) [Israel] Iran : Cashing Chips Won in War
      domain: gatestoneinstitute.org · language: English · tone:
  - (2026-07-19) [United Kingdom] Columbo on 5USA : full details and when it on
      domain: tvguide.co.uk · language: English · tone:
  - (2026-07-19) [Philippines] 10 Zamboanga City village receive life - saving medical device
      domain: sunstar.com.ph · language: English · tone:
  - (2026-07-19) [United States] Nigerian children pay the price for the Iran war as malnutrition and poverty surge
      domain: sitkasentinel.com · language: English · tone:
  - (2026-07-19) [Australia] Energy red tape could stall AI data centre boom
      domain: macleayargus.com.au · language: English · tone:
  - (2026-07-19) [United States] US strikes Iran Revolutionary Guard over attack that killed troops in Jordan
      domain: sitkasentinel.com · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 34 new of 114 total
  - (2026-07-19) Молдова після 34 інцидентів із дронами закупить системи виявлення БПЛА | LEDE: Молдова придбає нові системи виявлення та перехоплення дронів за фінансування ЄС. Партнерство зміцнить безпеку кра] (uk:…
      Молдова придбає нові системи виявлення та перехоплення дронів за фінансування ЄС. Партнерство зміцнить безпеку країни.
  - (2026-07-19) Федоров vs Сирський: "чорний лебідь" для влади | LEDE: Відставка Федорова викликала політичну кризу: суспільство реагує та вимагає змін у ЗСУ і владі.] (uk: Федоров vs Сирський: "чорний лебідь" для вл…
      Відставка Федорова викликала політичну кризу: суспільство реагує та вимагає змін у ЗСУ і владі.
  - (2026-07-19) Росіяни влучили у підземний перехід біля метро "Лук’янівська" | LEDE: Під час масованої російської атаки на Київ сталося пряме влучання у підземний перехід біля станції метро "Лук'янівська".] (uk: Рос…
      Під час масованої російської атаки на Київ сталося пряме влучання у підземний перехід біля станції метро "Лук'янівська".
  - (2026-07-19) Російський дрон знову влучив у пасажирський поїзд на Запоріжжі | LEDE: Удар дрона по потягу в Запорізькій області: провідниця поранена, пасажирів евакуйовано, залізниця працює.] (uk: Російський дрон з…
      Удар дрона по потягу в Запорізькій області: провідниця поранена, пасажирів евакуйовано, залізниця працює.
  - (2026-07-19) На тлі протестів командувачі ВМС і ДШВ заступилися за Сирського | LEDE: Командувачі ВМС і ДШВ виступили за підтримку Сирського й засудили політичні суперечки у ЗСУ.] (uk: На тлі протестів командувачі…
      Командувачі ВМС і ДШВ виступили за підтримку Сирського й засудили політичні суперечки у ЗСУ.
  - (2026-07-19) Сибіга закликав Захід до нищівного тиску на РФ після масованого удару по Києву | LEDE: ] (uk: Сибіга закликав Захід до нищівного тиску на РФ після масованого удару по Києву)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDACS — global disaster alerts — 29 new of 131 total
  - (2026-07-19) [Orange] Earthquake in Peru
      Earthquake · Orange alert · Peru · Magnitude 5.5M, Depth:10km
  - (2026-07-19) [Orange] Earthquake in Peru
      Earthquake · Orange alert · Peru · Magnitude 5.5M, Depth:10km
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-07-19) [Green] Tropical Cyclone SIX-E-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 176 km/h)

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-07-17) Hawaii Supreme Court: McAneeley v. Fukushima
  - (2026-07-17) Arizona Supreme Court: REPUBLICAN NATL COMMITTEE v. FONTES
  - (2026-07-17) Arizona Supreme Court: GOLDWATER v. PHOENIX
  - (2026-07-17) Arizona Supreme Court: Gelvin v. Hon. parker/gelvin
  - (2026-07-16) U.S. Court of Appeals, 11th Cir.: Savannah Shoals, LLC v. Commissioner of Internal Revenue
  - (2026-07-16) D.C. Court of Appeals: Brooks v. Mitsubishi Electric & Electronics US, Inc.

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-19) [China] Inside Xishuangbanna : Why are global mayors talking about wild Asian elephants here ?- 南海网
      hinews.cn · English
  - (2026-07-19) [China] ( W . E . Talk ) China has wisdom and foresight and its cooperation with ASEAN nearly Perfect : former Malaysian ambassador - 南海网
      hinews.cn · English
  - (2026-07-19) [China] Shanghai showcases satellites of its space - based computing network for AI
      china.org.cn · English
  - (2026-07-19) [China] Endurance of Belief : Retracing the Long March in Today Sangzhi County - 南海网
      hinews.cn · English
  - (2026-07-19) [China] If Xishuangbanna could fit in a suitcase , what would global mayors take home ?- 南海网
      hinews.cn · English
  - (2026-07-19) [China] China top diplomat meets foreign minister of Dominica
      china.org.cn · English

### USGS earthquakes (M4.5+, past day) — 12 new of 19 total
  - (2026-07-19) M 5.5 - 2 km WSW of Sicaya, Peru
      M5.5 · 2 km WSW of Sicaya, Peru · depth 10 km · PAGER yellow
  - (2026-07-19) M 5.3 - 59 km SW of Puerto Madero, Mexico
      M5.3 · 59 km SW of Puerto Madero, Mexico · depth 19.593 km
  - (2026-07-19) M 5.3 - 85 km SW of Puerto Madero, Mexico
      M5.3 · 85 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-19) M 5.3 - 190 km SSE of Vilyuchinsk, Russia
      M5.3 · 190 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-07-19) M 4.9 - 40 km ENE of Shahrak-e Kūlūrī, Iran
      M4.9 · 40 km ENE of Shahrak-e Kūlūrī, Iran · depth 10 km
  - (2026-07-19) M 4.8 - 83 km S of Pelabuhanratu, Indonesia
      M4.8 · 83 km S of Pelabuhanratu, Indonesia · depth 10 km

### Paper Trading Scorecard — 9 new of 140 total
  - (2026-07-19) [Polymarket] Will Marco Rubio win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-19) [Polymarket] Will Paul Seixas win the 2026 Tour De France?
      This market will resolve to the cyclist that wins the 2026 Tour De France scheduled for July 4, 2026 through July 26, 2026. If at any point it becomes impossible for a listed cyclist to win the 2026 Men Elite at the Tour…
  - (2026-07-19) [Polymarket] Will Bitcoin dip to $25,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "Low" price equal to or low…
  - (2026-07-19) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-19) [Manifold] Will Spain completely shut down Messi and win the World Cup Final within regular 90 minutes?
  - (2026-07-19) [Manifold] Daily Coinflip

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-07-19) Spain vs. Argentina: Both Teams to Score
      yes price: 54% · 24h volume: $1,177,775 · resolves 2026-07-19
  - (2026-07-19) Exact Score: Spain 2 - 2 Argentina?
      yes price: 6% · 24h volume: $980,701 · resolves 2026-07-19
  - (2026-07-19) Exact Score: Spain 2 - 1 Argentina?
      yes price: 10% · 24h volume: $929,059 · resolves 2026-07-19
  - (2026-07-19) Exact Score: Spain 1 - 2 Argentina?
      yes price: 6% · 24h volume: $829,097 · resolves 2026-07-19
  - (2026-07-19) Will Spain win on 2026-07-19?
      yes price: 42% · 24h volume: $747,693 · resolves 2026-07-19
  - (2026-07-19) Spain vs. Argentina: O/U 1.5
      yes price: 69% · 24h volume: $706,118 · resolves 2026-07-19

### IT, InfoSys & cybersecurity news (last 7 days) — 5 new of 58 total
  - (2026-07-19) [The Register] Using AI makes people less likely to admit they don't know something
      Researchers found confidence increased even as accuracy fell
  - (2026-07-18) [The Register] Java was a three-day hotfix away from dying horribly on stage
      Tim Lindholm, Java's original JVM maintainer, shares with El Reg some of the grungy build details the doc glosses over
  - (2026-07-18) [The Register] NextBSD returns to dollop Apple source on FreeBSD
      New maintainer revives the project with Darwin components, Gershwin, and Claude Code
  - (2026-07-17) [The Register] Mozilla speeds Firefox release schedule to biweekly
      And what to expect in Firefox 153 as the next ESR release gets close
  - (2026-07-17) [The Register] Microsoft cuts OneDrive support for older Windows 10 versions next month
      22H2 has until 2028, or there's always Windows 11

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-19) [Marginal Revolution] Cross-ethnic casting
      I complained about the casting of The Odyssey per se (the blind beggar was best), but in general I do not mind cross-ethnic casting. I am glad Elizabeth Taylor played Cleopatra, Dev Patel played David Copperfield, Denzel…
  - (2026-07-19) [Marginal Revolution] How does social media change people?
      I would not trust the results of this (or any) paper on this topic very much, but it is good to see some inquiry along different dimensions than the usual: Past research explored the beneficial and harmful effects of soc…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: plans, approved, being, final, aircraft, security, navigable, temporary, fisheries, change, local, certain
- state_bills: today=0, 7d-median=70, 14d-median=70
- state_news: today=431, 7d-median=445, 14d-median=445; carrying terms: offers, border, string, hands, being, opinion, seats, facility, style, legislatures, infrastructure, tuesday
- local_news: today=213, 7d-median=236, 14d-median=236; carrying terms: sheriff, health, being, launches, access, reports, third, store, saportareport, wanted, ready, since
- foreign_news: today=981, 7d-median=1031, 14d-median=1031; carrying terms: border, crucial, force, deliberations, skyscraper, elephant, football, infrastructure, competitive, specializing, tuesday, disrupt
- chinese_internal: today=277, 7d-median=277, 14d-median=277; carrying terms: global, lxtfa, cbmiw, politics, cbmizkfvx, https, articles, launch, cbmibkfvx, cbmicefvx, cbmixkfvx, cbmiz
- russian_internal: today=780, 7d-median=882, 14d-median=882; carrying terms: insider, street, novaya, group, target, media, style, blank, httperror, technology, laquo, times
- ukrainian_internal: today=114, 7d-median=135, 14d-median=135; carrying terms: outside, serhiy, service, front, operation, accusing, force, facility, infrastructure, disrupt, reports, troop
- ukraine_theater: today=576, 7d-median=576, 14d-median=576; carrying terms: cuxnsgridhqxowvszfh, jzzkxmu, wglibdjbts, uljyynrwyxuzbffblvrb, zgrfm, jiagtncu, blnsn, procurement, kytupucnjrdwdhowf, mykhailo, yzhfkcgo, qyzxz
- paper_bets: today=140, 7d-median=140, 14d-median=140; carrying terms: primary, specified, manifold, votes, trust, kalshi, round, equal, seats, brazilian, magnitude, levels
- weather: today=140, 7d-median=147, 14d-median=147; carrying terms: midnight, health, messages, afdtbw, cooler, service, ridge, front, magnitude, persist, monday, shortly
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, jolts, nonfarm, rates, growth, effective, unemployment, implied, indicator, recession, payrolls, spread
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, yield, rates, equities, silver, range, commodities, proxy, close, agriculture, treasury, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=115, 7d-median=115, 14d-median=115; carrying terms: educational, syria, health, serious, military, operation, political, sponsoring, middle, control, prior, dfbfehlhafb
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quiver, https, congresstrading, error, httperror, quantitative, client, unauthorized
- billionaires: today=30, 7d-median=32, 14d-median=32; carrying terms: italy, tadashi, amazon, michael, carlos, huang, oracle, china, warren, nasdaq, ballmer, walton
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: management, delaware, charles, alaska, company, truck, rhode, holdings, robert, office, district, community
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, issuer, accno, david, thomas, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cooper, angels, johnson, lindsey, michael, action, robert, filing, elect, receipts, disbursements, jonathan
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=0, 7d-median=48, 14d-median=48; carrying terms: trump, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: crash, killed, language, domain, australia, english, india, kingdom
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: verified, elements, comprising, geographic, epizootics, operator, increasing, health, bangladesh, virus, hondius, border
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: improper, product, injection, server, bypass, sharepoint, forgery, authentication, remediation, deserialization, vulnerability, traversal
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=131, 7d-median=131, 14d-median=131; carrying terms: italy, storm, poland, denmark, romania, ethiopia, madagascar, earthquake, guinea, cambodia, vietnam, magnitude
- usgs_quakes: today=19, 7d-median=19, 14d-median=19; carrying terms: depth
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: argentina, rates, minister, resolves, world, ethiopia, spain, meeting, interest, prime, advance, price
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, marginal, marginalrevolution, conversable, economist, https, class, particular, points, links, assorted
- tech_news: today=58, 7d-median=57, 14d-median=57; carrying terms: innovation, technica, cluster, krebsonsecurity, algorithm, includes, service, history, latest, force, control, hackers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: verified, stanton, fulcher, rutherford, coney, health, paulina, hillary, hinson, nikki, warner, minneapolis
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, placed, consensus, sufficient, evidence, unavailable, markets, decision, module, paper, either, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*