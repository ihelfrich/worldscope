# WORLDSCOPE morning brief — 2026-07-19

## Headline
1973 new items across 21 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (473) · Russian Internal News (state + in-exile) (348) · World leaders & government officials (324) · Chinese Internal News (170) · Ukraine Theater (total-war monitoring) (146) · U.S. Weather + Severe / Climate Outlooks (134) · State-Level News (74) · Local News: St. Louis + Atlanta (69) · GDELT GKG — themes / entities / watch areas (65) · Ukrainian Internal News (national + local Kyiv) (45) · Sanctions & Designations (recent) (30) · GDACS — global disaster alerts (29)

## What changed today
### International News + Multilateral Institutions — 473 new of 956 total
  - (2026-07-19) [Global] Chinese firm seeks compensation over British Steel nationalisation
      Jingye said it will take action "through legal means to the very end" after the UK government nationalised British Steel.
  - (2026-07-19) [Global] New EU border system tripling time at passport control, airport boss says
      Ryanair has also warned passengers travelling to Europe this summer to prepare for extended waits.
  - (2026-07-19) [Global] Is Burnham promising a new dawn for North Sea oil and gas?
      The incoming PM is expected to announce fresh support for the North Sea from day one of his premiership.
  - (2026-07-19) [Global] The hidden cost of the night shift and how to sleep it off
      More than three million people in the UK work night shifts, which can greatly impact their health. What can be done to help them?
  - (2026-07-18) [Global] Private jets flock to Montana - but locals can't afford the trailer park
      Rents in Bozeman, Montana have skyrocketed as wealthy out-of-towners flock to the city to experience the American West.
  - (2026-07-19) [Global] US and Iran exchange strikes after two US soldiers killed in Jordan
      Kuwait says an electricity and water plant is on fire after the second such attack in two days. Iran says US strikes hit an under-construction nuclear power plant.

### Russian Internal News (state + in-exile) — 348 new of 796 total
  - (2026-07-19) В США задержали Эндрю и Тристана Тейтов. Великобритания потребует экстрадировать братьев, обвиняемых в сексуализированном насилии | LEDE: Федеральные маршалы США задержали блогера Эндрю Тейт] (ru: В С…
      Федеральные маршалы США задержали блогера Эндрю Тейта, известного женоненавистническими заявлениями, и его брата Тристана. По данным СМИ, братьев задержали в Майами у спорткомплекса Джеймса Найта, где Эндрю Тейт — профес…
  - (2026-07-19) Обычный выходной в Электростали. Как жил город, пока — после украинских ударов — горел склад Wildberries. Фотографии | LEDE: В ночь на 18 июля украинские беспилотники атаковали склад Wildber] (ru: Обы…
      В ночь на 18 июля украинские беспилотники атаковали склад Wildberries в подмосковной Электростали. Дым от пожара растянулся на пять тысяч квадратных километров (это вдвое больше, чем площадь Москвы) и попал на спутниковы…
  - (2026-07-19) В работе фейсбука и инстаграма произошел масштабный сбой | LEDE: В работе соцсетей Facebook и Instagram (обе принадлежат компании Meta) произошел масштабный сбой, следует из данных сервиса D] (ru: В р…
      В работе соцсетей Facebook и Instagram (обе принадлежат компании Meta) произошел масштабный сбой, следует из данных сервиса Downdetector (1,2).
  - (2026-07-19) Умер телеведущий Сергей Шолохов | LEDE: В Петербурге умер журналист и телеведущий Сергей Шолохов, сообщил его пасынок Всеволод Москвин. Шолохову было 67 лет. ] (ru: Умер телеведущий Сергей Шолохов)
      В Петербурге умер журналист и телеведущий Сергей Шолохов, сообщил его пасынок Всеволод Москвин. Шолохову было 67 лет.
  - (2026-07-19) Англия обыграла Францию в матче ЧМ за третье место — и впервые за 60 лет стала призером турнира | LEDE: Сборная Англии со счетом 6:4 обыграла команду Франции в матче за третье место чемпиона] (ru: Анг…
      Сборная Англии со счетом 6:4 обыграла команду Франции в матче за третье место чемпионата мира по футболу. Игра проходила в Майами на стадионе «Хард Рок Стэдиум».
  - (2026-07-19) Украинские беспилотники атаковали два танкера в морском терминале Каспийского трубопроводного консорциума в Новороссийске | LEDE: Украинские беспилотники атаковали морской терминал Каспийско] (ru: Укр…
      Украинские беспилотники атаковали морской терминал Каспийского трубопроводного консорциума (КТК) в Новороссийске во время погрузки нефти, сообщили в КТК.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 170 new of 281 total
  - (2026-07-19) 京剧宗师谭鑫培的“面儿” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBidDdzaGxVTVZremlLaF95OUxybXlqWmN4SHF5Tk04LTJDcE5RNHRCTUR3WmctQVhrR2dsNzl2SHA4ZlBJQ2RvWTJjUTNvWVlFTmtiZTVkc] (zh:…
      京剧宗师谭鑫培的“面儿” 财新
  - (2026-07-19) 世界杯决赛西阿大战，数据一网打尽 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBEclpKYzlpcFlUOXJKZk1jMzBwNDRBeE5fZWt4QnlrYTJyaE1ORnBTY0NaQnB3aUtSZzNmQUlkU040aUQ5ZEM0NWRhdXFOUnl5QWNxZ] (zh:…
      世界杯决赛西阿大战，数据一网打尽 财新
  - (2026-07-19) 最新财新周刊｜复杂局面下如何稳经济 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFA1N2FPTWd0Qm1qTlIwWl9lclNjbTA3SnVQdFFnQm9MUGZWNGFMOUVueDlXc1h4Q2s5WGQtRnowNElTWDFDclI3c2NaWXRTdGJYUz] (zh:…
      最新财新周刊｜复杂局面下如何稳经济 财新周刊
  - (2026-07-19) 最新财新周刊｜热浪侵袭下的动物 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5xanpTMUdIMG1SYW5YSzd4N2x1a1JTNDBJVWRFanV5V3g2YVRid2VaaE1FeEhLd1lIcGdqTzVNX3lsM2lha2Y3SGJQNXlNUWNiUmI3] (zh:…
      最新财新周刊｜热浪侵袭下的动物 财新周刊
  - (2026-07-19) 财新观察｜完善扩大居民消费长效机制 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1EaVF0MVdpTm5CNFZVYi02TWtoU0JDNnVWT1o4V1dNZUk4UWw0ZXE5RE0tWFh6bjJraDZsSUZ6WU1ZZXpsbThjQU1uSGl5M1BlOX] (zh:…
      财新观察｜完善扩大居民消费长效机制 财新周刊
  - (2026-07-18) 显影｜家庭式养老：个性化陪伴与专业照护如何兼得 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBDMzVVeHc1aGtoNmNDbkRWdnlscFU4WTNoVnJuMFFlRE9sUlNRaHVLbVFabFNmcndOc1c0eUZqb24yejdJdXFQdzZoNkU1Mk] (zh:…
      显影｜家庭式养老：个性化陪伴与专业照护如何兼得 财新

### Ukraine Theater (total-war monitoring) — 146 new of 576 total
  - (2026-07-18) [FIRMS] thermal anomaly 48.533, 34.644 (FRP 4.22 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 4.22 MW
  - (2026-07-18) [FIRMS] thermal anomaly 48.534, 34.635 (FRP 3.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 3.38 MW
  - (2026-07-18) [FIRMS] thermal anomaly 48.534, 34.645 (FRP 3.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 3.18 MW
  - (2026-07-18) [FIRMS] thermal anomaly 48.520, 34.626 (FRP 1.17 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 1.17 MW
  - (2026-07-18) [FIRMS] thermal anomaly 47.866, 33.427 (FRP 2.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 2.29 MW
  - (2026-07-18) [FIRMS] thermal anomaly 47.859, 33.447 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-18 2240Z, FRP 1.02 MW

### U.S. Weather + Severe / Climate Outlooks — 134 new of 140 total
  - (2026-07-19) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-19) [Moderate] Heat Advisory: Heat Advisory issued July 19 at 7:06AM CDT until July 19 at 9:00PM CDT by NWS Bismarck ND
      * WHAT...Heat index values around 100 expected. * WHERE...Southwest and south central North Dakota. * WHEN...From 1 PM CDT /noon MDT/ this afternoon to 9 PM CDT /8 PM MDT/ this evening. * IMPACTS...Hot temperatures and h…
  - (2026-07-19) [Moderate] Heat Advisory: Heat Advisory issued July 19 at 4:00AM AKDT until July 20 at 10:00PM AKDT by NWS Fairbanks AK
      * WHAT...Hot temperatures as high as 80 degrees expected. * WHERE...Central Arctic Plains and Western Arctic Plains. * WHEN...From 10 AM to 10 PM AKDT Monday. * IMPACTS...Individuals not accustomed to these unusually hot…
  - (2026-07-19) [Moderate] Wind Advisory: Wind Advisory issued July 19 at 3:57AM AKDT until July 20 at 12:00PM AKDT by NWS Fairbanks AK
      * WHAT...South winds 35 to 45 mph with gusts up to 65 mph expected. * WHERE...Eastern Alaska Range North of Trims Camp. * WHEN...Until noon AKDT Monday. * IMPACTS...Gusty winds will blow around unsecured objects. Tree li…
  - (2026-07-19) [Moderate] Heat Advisory: Heat Advisory issued July 19 at 3:57AM AKDT until July 20 at 10:00PM AKDT by NWS Fairbanks AK
      * WHAT...Hot temperatures between 85 and 90 degrees expected. * WHERE...Yukon Flats. * WHEN...From noon to 10 PM AKDT Monday. * IMPACTS...Individuals not accustomed to these unusually hot temperatures for this region may…
  - (2026-07-19) [Moderate] Wind Advisory: Wind Advisory issued July 19 at 3:57AM AKDT until July 20 at 12:00PM AKDT by NWS Fairbanks AK
      * WHAT...Southeast winds 35 to 45 mph with gusts up to 60 mph expected. * WHERE...Northern Denali Borough. * WHEN...Until noon AKDT Monday. * IMPACTS...Gusty winds will blow around unsecured objects. Tree limbs could be…

### State-Level News — 74 new of 442 total
  - (2026-07-19) [Connecticut] The story behind rows of unmarked stones at New Haven cemetery
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/PAUPERS-CEMETERY-0702-JL-08-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fe…
  - (2026-07-19) [Connecticut] Hot and bothered – summer’s transportation meltdown
      <img width="694" height="307" src="https://ctmirror.org/wp-content/uploads/2026/07/sunkinks-example.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="…
  - (2026-07-19) [Arkansas] Arkansans who banded together to save PBS deserve better than this
      In normal times, a group of citizens banding together and pitching in to save a public institution like PBS would be rewarded. They would be lauded for putting their money where their mouths are. But these aren’t normal…
  - (2026-07-19) [Georgia] Public health improvements stall amid Trump’s DEI crackdown
      THOMASVILLE, Ga. — As Earl Williams drove through a historic Black neighborhood known as Dewey City in his hometown, he hardly recognized what he saw. Homes that once belonged to friends, family, and neighbors had siding…
  - (2026-07-19) [Florida] United Methodist conference to move meeting out of Idaho, citing LGBTQ+, immigrant safety concerns
      This story was first published on July 14, 2026, by FāVS News. Citing dangers to LGBTQ+ and immigrant communities, the Oregon-Idaho Conference of the United Methodist Church voted last month to move next year’s annual co…
  - (2026-07-19) [Kansas] The ‘developer’ of a Kansas data center swore under oath he wasn’t involved. My town is bamboozled.
      The sales pitch for what could be the state’s largest data center is built on a hyperscale whopper. In sworn testimony from a federal bankruptcy proceeding, Gary Pinkston, the businessman touted as the developer of the p…

### Local News: St. Louis + Atlanta — 69 new of 202 total
  - (2026-07-19) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-07-19) [St. Louis] What time is kickoff for World Cup final?
      Spain and Argentina face off in New Jersey on Sunday for international soccer's biggest title.
  - (2026-07-19) [St. Louis] Volunteers work to restore 200-year-old Collinsville cemetery and preserve local history
      Community members are cleaning, repairing and researching one of the region's oldest cemeteries.
  - (2026-07-19) [St. Louis] Viral raccoon 'Jimothy' inspires mural, tattoos and city proclamation in Seattle, Washington
      "I think it's kind of a symbol of resilience," a tattoo artist in Seattle said. "He's dealing with life a little bit differently, and he seems to be fine."
  - (2026-07-19) [St. Louis] Thunderstorms expected to clear wildfire smoke from Northeast ahead of World Cup final
      Smoke from Canadian wildfires that engulfed the Northeast in haze is expected to mostly clear from the New Jersey area just in time for the World Cup final.
  - (2026-07-19) [St. Louis] US strikes Iran's Revolutionary Guard over an attack that killed troops in Jordan
      The U.S. military launched airstrikes targeting Iran's Revolutionary Guard to retaliate for the killing of American troops in Jordan.

### GDELT GKG — themes / entities / watch areas — 65 new of 65 total
  - (2026-07-19) [Russia oil sanctions perimeter · themes] Uzmanından ayak soğukluğu damar hastalığının habercisi olabilir uyarısı
      haber1.com · Turkish · tone NA
  - (2026-07-19) [Russia oil sanctions perimeter · themes] 科创板史上最大IPO遭遇科技股 猛回调 - 经济观察网 － 专业财经新闻网站
      eeo.com.cn · Chinese · tone NA
  - (2026-07-19) [Russia oil sanctions perimeter · themes] „ Zkuste to bez drátů , milý Marconi . BMW s Toyotou nechávají ve Španělsku jezdit auta na olej na vaření , aby dokázaly , že není jen jedné cesty
      autoforum.cz · Czech · tone NA
  - (2026-07-19) [Russia oil sanctions perimeter · themes] Mbikëqyrja e jashtëzakonshme e ushqimit tregon se mbikëqyrja e rregullt po dështon
      koha.mk · Albanian · tone NA
  - (2026-07-19) [Russia oil sanctions perimeter · themes] В Таджикистане на 78 га созданы плантации павловнии
      khovar.tj · Russian · tone NA
  - (2026-07-19) [Russia oil sanctions perimeter · themes] Beunruhigende Szene am Pier : Gigantisches Kreuzfahrtschiff kippt auf einmal um
      nordkurier.de · German · tone NA

### Ukrainian Internal News (national + local Kyiv) — 45 new of 123 total
  - (2026-07-19) Мерц натякає на можливі перестановки в своєму уряді | LEDE: ] (uk: Мерц натякає на можливі перестановки в своєму уряді)
  - (2026-07-19) Зеленський продовжив зустрічі з військовим командуванням, зокрема з Драпатим | LEDE: Президент обговорив із командирами ситуацію на фронті, постачання та пріоритети оборони.] (uk: Зеленський продовжив…
      Президент обговорив із командирами ситуацію на фронті, постачання та пріоритети оборони.
  - (2026-07-19) Алім Алієв: Українські студії за кордоном — питання національної безпеки | LEDE: ] (uk: Алім Алієв: Українські студії за кордоном — питання національної безпеки)
  - (2026-07-19) Литва пообіцяла Латвії технологічну допомогу на тлі напливу мігрантів | LEDE: ] (uk: Литва пообіцяла Латвії технологічну допомогу на тлі напливу мігрантів)
  - (2026-07-19) Удар по парку розваг на Одещині: кількість постраждалих зросла до 12, в тому числі 2-річна дитина | LEDE: Удар РФ по парку в Одеській області: загинув 16-річний хлопець, 12 людей постраждали, с] (uk:…
      Удар РФ по парку в Одеській області: загинув 16-річний хлопець, 12 людей постраждали, серед них діти. Деталі від ОВА.
  - (2026-07-19) Росіяни атакували поштовий термінал біля Харкова: троє загиблих, 20 поранених | LEDE: Російські війська атакували передмістя Харкова, внаслідок чого троє людей загинули, ще 20 постраждали.] (uk: Росія…
      Російські війська атакували передмістя Харкова, внаслідок чого троє людей загинули, ще 20 постраждали.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDACS — global disaster alerts — 29 new of 130 total
  - (2026-07-19) [Orange] Earthquake in Peru
      Earthquake · Orange alert · Peru · Magnitude 5.5M, Depth:10km
  - (2026-07-19) [Orange] Earthquake in Peru
      Earthquake · Orange alert · Peru · Magnitude 5.5M, Depth:10km
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-07-19) [Green] Tropical Cyclone SIX-E-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 176 km/h)

### USGS earthquakes (M4.5+, past day) — 14 new of 18 total
  - (2026-07-19) M 5.5 - 2 km WSW of Sicaya, Peru
      M5.5 · 2 km WSW of Sicaya, Peru · depth 10 km · PAGER yellow
  - (2026-07-19) M 5.3 - 59 km SW of Puerto Madero, Mexico
      M5.3 · 59 km SW of Puerto Madero, Mexico · depth 19.593 km
  - (2026-07-19) M 5.3 - 85 km SW of Puerto Madero, Mexico
      M5.3 · 85 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-19) M 5.3 - 190 km SSE of Vilyuchinsk, Russia
      M5.3 · 190 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-07-19) M 4.9 - 40 km ENE of Shahrak-e Kūlūrī, Iran
      M4.9 · 40 km ENE of Shahrak-e Kūlūrī, Iran · depth 10 km
  - (2026-07-19) M 4.8 - 83 km S of Pelabuhanratu, Indonesia
      M4.8 · 83 km S of Pelabuhanratu, Indonesia · depth 10 km

### Paper Trading Scorecard — 13 new of 138 total
  - (2026-07-19) [Polymarket] Spain vs. Argentina: 1st Half O/U 0.5
      In the upcoming FIFA World Cup game between Spain and Argentina, scheduled for July 19 at 3:00 PM ET: This market will resolve to "Over" if Spain and Argentina combine to score 1 or more goals in the first half (first 45…
  - (2026-07-19) [Polymarket] Will SpaceX Starship Flight Test 13 Superheavy explode?
      This market will resolve to "Yes" if the booster for the 13th Starship-SuperHeavy test explodes at any point during the test from the start of fueling operations to 60 minutes after it makes contact with Earth upon landi…
  - (2026-07-19) [Polymarket] Will Marco Rubio win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-19) [Polymarket] Will Paul Seixas win the 2026 Tour De France?
      This market will resolve to the cyclist that wins the 2026 Tour De France scheduled for July 4, 2026 through July 26, 2026. If at any point it becomes impossible for a listed cyclist to win the 2026 Men Elite at the Tour…
  - (2026-07-19) [Polymarket] Will Bitcoin dip to $25,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "Low" price equal to or low…
  - (2026-07-19) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-19) LoL: T1 vs Gen.G (BO3) - Esports World Cup Playoffs
      yes price: 6% · 24h volume: $3,197,627 · resolves 2026-07-19
  - (2026-07-19) LoL: T1 vs Gen.G - Game 2 Winner
      yes price: 100% · 24h volume: $1,910,211 · resolves 2026-07-19
  - (2026-07-19) LoL: T1 vs Gen.G - Game 1 Winner
      yes price: 0% · 24h volume: $1,820,934 · resolves 2026-07-19
  - (2026-07-19) Will Spain win on 2026-07-19?
      yes price: 42% · 24h volume: $1,757,073 · resolves 2026-07-19
  - (2026-07-19) Spain vs. Argentina: Both Teams to Score
      yes price: 54% · 24h volume: $1,399,953 · resolves 2026-07-19
  - (2026-07-19) Spread: Spain (-1.5)
      yes price: 21% · 24h volume: $1,191,006 · resolves 2026-07-19

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-07-17) Arizona Supreme Court: REPUBLICAN NATL COMMITTEE v. FONTES
  - (2026-07-17) Arizona Supreme Court: GOLDWATER v. PHOENIX
  - (2026-07-17) Arizona Supreme Court: Gelvin v. Hon. parker/gelvin
  - (2026-07-16) D.C. Court of Appeals: Brooks v. Mitsubishi Electric & Electronics US, Inc.
  - (2026-07-16) D.C. Court of Appeals: Carruth v. United States
  - (2026-07-16) D.C. Court of Appeals: Doby v. United States

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-19) [Japan] Russia condemns Japanese cooperation with Ukraine drone developers
      japanherald.com · English
  - (2026-07-19) [Japan] Xinhua Commentary : DPP authoritie ban on ZXMOTO ignores public calls , clings to self - deceit
      japanherald.com · English
  - (2026-07-19) [Japan] Google Will Now Label Ads Made or Edited With AI
      explosion.com · English
  - (2026-07-19) [Japan] FF7 Rebirth PC Mod Overhauls Lighting , Shadows , and Water
      explosion.com · English
  - (2026-07-19) [Japan] Waveform Host David Pierce Fills In at The Verge for 6 Weeks
      explosion.com · English
  - (2026-07-19) [Japan] Troy Baker Defends Live - Service Games Amid Marathon Rough Start
      explosion.com · English

### IT, InfoSys & cybersecurity news (last 7 days) — 6 new of 58 total
  - (2026-07-19) [The Register] Using AI makes people less likely to admit they don't know something
      Researchers found confidence increased even as accuracy fell
  - (2026-07-19) [Ars Technica] As mosquito ranges expand, better monitoring is key to preventing disease
      Monitoring is expensive and labor intensive. But it helps public health officials stop outbreaks.
  - (2026-07-18) [The Register] Java was a three-day hotfix away from dying horribly on stage
      Tim Lindholm, Java's original JVM maintainer, shares with El Reg some of the grungy build details the doc glosses over
  - (2026-07-18) [The Register] NextBSD returns to dollop Apple source on FreeBSD
      New maintainer revives the project with Darwin components, Gershwin, and Claude Code
  - (2026-07-17) [The Register] Mozilla speeds Firefox release schedule to biweekly
      And what to expect in Firefox 153 as the next ESR release gets close
  - (2026-07-17) [The Register] Microsoft cuts OneDrive support for older Windows 10 versions next month
      22H2 has until 2028, or there's always Windows 11

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-19) [Marginal Revolution] Building luxury homes is good for the poor
      Tej Parikh writing in the FT: …high-end developments unlock long housing chains. As higher-income households move into newly built units, they free up older properties, raising supply and slashing prices for middle- and…
  - (2026-07-19) [Marginal Revolution] Cross-ethnic casting
      I complained about the casting of The Odyssey per se (the blind beggar was best), but in general I do not mind cross-ethnic casting. I am glad Elizabeth Taylor played Cleopatra, Dev Patel played David Copperfield, Denzel…
  - (2026-07-19) [Marginal Revolution] How does social media change people?
      I would not trust the results of this (or any) paper on this topic very much, but it is good to see some inquiry along different dimensions than the usual: Past research explored the beneficial and harmful effects of soc…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: amendments, model, navigable, airworthiness, published, specifically, within, regulatory, action, plans, proposing, final
- state_bills: today=0, 7d-median=70, 14d-median=70
- state_news: today=442, 7d-median=445, 14d-median=445; carrying terms: nutrition, budget, aaron, residency, session, seats, education, sizes, figure, annual, fined, advocacy
- local_news: today=202, 7d-median=236, 14d-median=236; carrying terms: police, campaign, critical, accused, figure, support, mexico, announced, magazine, highway, organization, traffic
- foreign_news: today=956, 7d-median=1031, 14d-median=1031; carrying terms: budget, teachers, kunshan, session, financiero, islands, carney, education, mimetype, suspicion, figure, speed
- chinese_internal: today=281, 7d-median=281, 14d-median=281; carrying terms: cbmixkfvx, cbmia, cbmibkfvx, china, cbmiykfvx, cbmiz, caixin, launch, people, cbmizkfvx, cbmiw, cbmidefvx
- russian_internal: today=796, 7d-median=882, 14d-median=882; carrying terms: forbidden, financial, times, apple, style, title, laquo, insider, novaya, httperror, media, europe
- ukrainian_internal: today=123, 7d-median=135, 14d-median=135; carrying terms: kremlin, campaign, network, controlled, needs, support, crisis, announcing, plans, fires, according, kerch
- ukraine_theater: today=576, 7d-median=576, 14d-median=576; carrying terms: nfcgy, twzzvguwu, ddzvc, cuxqne, qtfdqurqylo, zfrdqwria, ngogjnay, jvowd, nyjvtamhknud, cuxpvzc, bxbux, cbmiigfbvv
- paper_bets: today=138, 7d-median=138, 14d-median=138; carrying terms: prime, florida, manifold, communicates, withdraw, presidential, seats, title, scheduled, zohran, price, candle
- weather: today=140, 7d-median=147, 14d-median=147; carrying terms: impact, strong, western, persist, islands, tropical, message, cities, extending, creeks, northwest, unhealthy
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, nonfarm, jolts, energy, walcl, dexuseu, funds, balance, dcoilwtico, consumption, cpilfesl, treasury
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, agriculture, yield, rates, range, natural, silver, proxy, credit, close, treasury, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=114, 7d-median=114, 14d-median=114; carrying terms: prohibited, illegal, representative, campaign, exploration, mtjwwxz, economic, activities, chemical, rapid, billing, snapshot
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quiver, quantitative, client, error, congresstrading, https, httperror, unauthorized
- billionaires: today=30, 7d-median=32, 14d-median=32; carrying terms: gcarsoa, spacex, spain, fashion, hathaway, tadashi, walmart, charles, madrid, gates, carlos, meyers
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: america, energy, robert, children, international, rhode, jonathan, truck, community, revenue, state, appeals
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, scott, david, thomas
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: krishnamoorthi, alexandria, angels, lowden, action, ossoff, robert, groom, disbursements, platner, cooper, elect
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=65, 7d-median=48, 14d-median=48; carrying terms: trump, english, hezbollah, ukraine, russia, israel, russian, sanctions, perimeter, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: viruses, comprising, nigeria, barasat, diphtheria, measles, bulape, remaining, detected, children, laboratory, international
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: request, access, microsoft, control, forgery, untrusted, bypass, sharepoint, vendor, remediation, traversal, deserialization
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=130, 7d-median=130, 14d-median=130; carrying terms: impact, cyclone, nicaragua, salvador, islands, tropical, japan, orange, somalia, cambodia, honduras, medium
- usgs_quakes: today=18, 7d-median=18, 14d-median=18; carrying terms: depth
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, volume, argentina, spain, advance, minister, ethiopia, price, world, resolves
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, marginalrevolution, revolution, conversable, marginal, class, https, particular, points
- tech_news: today=58, 7d-median=57, 14d-median=57; carrying terms: model, campaign, activities, instead, includes, attackers, interesting, provide, computer, activity, cloud, technology
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: neguse, delauro, nicole, alexandria, representative, heinrich, aaron, nikki, robert, blumenthal, rivet, strong
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, placement, either, paper, claude, consensus, market, today, sufficient, markets, decision, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*