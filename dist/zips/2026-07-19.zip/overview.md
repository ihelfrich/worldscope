# WORLDSCOPE morning brief — 2026-07-19

## Headline
1464 new items across 18 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (372) · World leaders & government officials (324) · Russian Internal News (state + in-exile) (223) · Chinese Internal News (154) · U.S. Weather + Severe / Climate Outlooks (130) · State-Level News (56) · Local News: St. Louis + Atlanta (50) · Ukraine Theater (total-war monitoring) (43) · Ukrainian Internal News (national + local Kyiv) (32) · Sanctions & Designations (recent) (30) · USGS earthquakes (M4.5+, past day) (12) · Paper Trading Scorecard (8)

## What changed today
### International News + Multilateral Institutions — 372 new of 978 total
  - (2026-07-19) [Global] São Tomé and Príncipe heads to polls in tense presidential election
  - (2026-07-19) [Global] Victoria announces new social media ‘demasking’ powers for accounts accused of vilification
  - (2026-07-19) [Global] Terence Donovan, ‘larger-than-life’ actor and father of Jason, dies aged 90 – as it happened
  - (2026-07-19) [Global] Man dies after cross-border police pursuit ends in NSW northern rivers
  - (2026-07-18) [Global] Conservatives around world at war against ‘leftwing globalists’, Bridget McKenzie tells CPAC London event
  - (2026-07-19) [Global] Dozens of Russian missiles pound Kyiv in major attack

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Russian Internal News (state + in-exile) — 223 new of 725 total
  - (2026-07-19) Умер телеведущий Сергей Шолохов | LEDE: В Петербурге умер журналист и телеведущий Сергей Шолохов, сообщил его пасынок Всеволод Москвин. Шолохову было 67 лет. ] (ru: Умер телеведущий Сергей Шолохов)
      В Петербурге умер журналист и телеведущий Сергей Шолохов, сообщил его пасынок Всеволод Москвин. Шолохову было 67 лет.
  - (2026-07-19) Англия обыграла Францию в матче ЧМ за третье место — и впервые за 60 лет стала призером турнира | LEDE: Сборная Англии со счетом 6:4 обыграла команду Франции в матче за третье место чемпиона] (ru: Анг…
      Сборная Англии со счетом 6:4 обыграла команду Франции в матче за третье место чемпионата мира по футболу. Игра проходила в Майами на стадионе «Хард Рок Стэдиум».
  - (2026-07-19) Украинские беспилотники атаковали два танкера в морском терминале Каспийского трубопроводного консорциума в Новороссийске | LEDE: Украинские беспилотники атаковали морской терминал Каспийско] (ru: Укр…
      Украинские беспилотники атаковали морской терминал Каспийского трубопроводного консорциума (КТК) в Новороссийске во время погрузки нефти, сообщили в КТК.
  - (2026-07-19) В Ставропольском крае после атаки украинских беспилотников пожары на промышленных объектах (вероятно, это нефтебазы). В Курске дроны попали в многоэтажные дома | LEDE: Российские ПВО в ночь ] (ru: В С…
      Российские ПВО в ночь на 19 июня перехватили и уничтожили 140 украинских беспилотников над восемью регионами России, аннексированным Крымом, Азовским и Черными морями, отчиталось Минобороны РФ.
  - (2026-07-19) Мир оказался как никогда близок к победе над СПИДом — и ровно в этот момент кончились деньги. Есть ли теперь шанс справиться с эпидемией? | LEDE: За почти полвека с момента первого зарегистр] (ru: Мир…
      За почти полвека с момента первого зарегистрированного случая мир научился эффективно подавлять ВИЧ, добился снижения смертности более чем вдвое и получил профилактику, близкую по эффективности к вакцине. И ровно в этот…
  - (2026-07-19) Россия нанесла массированный удар по Киеву. Один человек погиб, 16 пострадали | LEDE: Один человек погиб, еще 16 пострадали в результате российского массированного удара по Киеву в ночь на 1] (ru: Рос…
      Один человек погиб, еще 16 пострадали в результате российского массированного удара по Киеву в ночь на 19 июля, сообщил президент Украины Владимир Зеленский. По его словам, это одна из самых массированных атак РФ на Киев…

### Chinese Internal News — 154 new of 277 total
  - (2026-07-17) DeepSeek Reaches $52 Billion Valuation in Round Backed by Tencent, CATL - Caixin Global
      DeepSeek Reaches $52 Billion Valuation in Round Backed by Tencent, CATL Caixin Global
  - (2026-07-19) 世界杯决赛西阿大战，数据一网打尽 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBEclpKYzlpcFlUOXJKZk1jMzBwNDRBeE5fZWt4QnlrYTJyaE1ORnBTY0NaQnB3aUtSZzNmQUlkU040aUQ5ZEM0NWRhdXFOUnl5QWNxZ] (zh:…
      世界杯决赛西阿大战，数据一网打尽 财新
  - (2026-07-19) 最新财新周刊｜复杂局面下如何稳经济 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFA1N2FPTWd0Qm1qTlIwWl9lclNjbTA3SnVQdFFnQm9MUGZWNGFMOUVueDlXc1h4Q2s5WGQtRnowNElTWDFDclI3c2NaWXRTdGJYUz] (zh:…
      最新财新周刊｜复杂局面下如何稳经济 财新周刊
  - (2026-07-19) 最新财新周刊｜热浪侵袭下的动物 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5xanpTMUdIMG1SYW5YSzd4N2x1a1JTNDBJVWRFanV5V3g2YVRid2VaaE1FeEhLd1lIcGdqTzVNX3lsM2lha2Y3SGJQNXlNUWNiUmI3] (zh:…
      最新财新周刊｜热浪侵袭下的动物 财新周刊
  - (2026-07-19) 财新观察｜完善扩大居民消费长效机制 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1EaVF0MVdpTm5CNFZVYi02TWtoU0JDNnVWT1o4V1dNZUk4UWw0ZXE5RE0tWFh6bjJraDZsSUZ6WU1ZZXpsbThjQU1uSGl5M1BlOX] (zh:…
      财新观察｜完善扩大居民消费长效机制 财新周刊
  - (2026-07-18) 显影｜家庭式养老：个性化陪伴与专业照护如何兼得 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBDMzVVeHc1aGtoNmNDbkRWdnlscFU4WTNoVnJuMFFlRE9sUlNRaHVLbVFabFNmcndOc1c0eUZqb24yejdJdXFQdzZoNkU1Mk] (zh:…
      显影｜家庭式养老：个性化陪伴与专业照护如何兼得 财新

### U.S. Weather + Severe / Climate Outlooks — 130 new of 140 total
  - (2026-07-19) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-19) [Severe] Special Marine Warning: Special Marine Warning issued July 19 at 4:56AM EDT until July 19 at 5:30AM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Bonita Beach to Englewood FL out 20 NM... Coastal waters from Englewood to Tarpon Springs FL out 20 NM... * U…
  - (2026-07-19) [Moderate] Heat Advisory: Heat Advisory issued July 19 at 3:33AM CDT until July 19 at 9:00PM CDT by NWS Sioux Falls SD
      * WHAT...Heat index values up to 103 expected. * WHERE...Portions of central, east central, south central, and southeast South Dakota. * WHEN...From 1 PM this afternoon to 9 PM CDT this evening. * IMPACTS...Hot temperatu…
  - (2026-07-19) [Severe] Flood Warning: Flood Warning issued July 19 at 3:32AM CDT until July 20 at 3:04AM CDT by NWS Corpus Christi TX
      ...The Flood Warning is extended for the following rivers in Texas... Rio Grande At Laredo affecting Webb County. ...The Flood Warning continues for the following rivers in Texas... Rio Grande At Columbia Bridge affectin…
  - (2026-07-19) [Severe] Flood Warning: Flood Warning issued July 19 at 3:32AM CDT until July 21 at 6:04AM CDT by NWS Corpus Christi TX
      ...The Flood Warning is extended for the following rivers in Texas... Rio Grande At Laredo affecting Webb County. ...The Flood Warning continues for the following rivers in Texas... Rio Grande At Columbia Bridge affectin…
  - (2026-07-19) [Moderate] Special Weather Statement: Special Weather Statement issued July 19 at 3:28AM CDT by NWS Grand Forks ND
      A bit warmer today with afternoon highs 85 to 90 with lowest RH values in the 35 to 40 percent range. This along with a southwest wind 10 to 15 mph, gusts 20 mph will lead to near critical fire weather conditions once ag…

### State-Level News — 56 new of 431 total
  - (2026-07-19) [Connecticut] The stories behind rows of unmarked stones at New Haven paupers’ cemetery
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/PAUPERS-CEMETERY-0702-JL-08-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fe…
  - (2026-07-19) [Connecticut] Hot and bothered – summer’s transportation meltdown
      <img width="694" height="307" src="https://ctmirror.org/wp-content/uploads/2026/07/sunkinks-example.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="…
  - (2026-07-19) [Georgia] Public health improvements stall amid Trump’s DEI crackdown
      THOMASVILLE, Ga. — As Earl Williams drove through a historic Black neighborhood known as Dewey City in his hometown, he hardly recognized what he saw. Homes that once belonged to friends, family, and neighbors had siding…
  - (2026-07-19) [Florida] United Methodist conference to move meeting out of Idaho, citing LGBTQ+, immigrant safety concerns
      This story was first published on July 14, 2026, by FāVS News. Citing dangers to LGBTQ+ and immigrant communities, the Oregon-Idaho Conference of the United Methodist Church voted last month to move next year’s annual co…
  - (2026-07-19) [Kansas] The ‘developer’ of a Kansas data center swore under oath he wasn’t involved. My town is bamboozled.
      The sales pitch for what could be the state’s largest data center is built on a hyperscale whopper. In sworn testimony from a federal bankruptcy proceeding, Gary Pinkston, the businessman touted as the developer of the p…
  - (2026-07-19) [Maine] Maine ICE death is part of Susan Collins’ legacy | Letter
      So we finally have a death here in Biddeford, Maine — a 26-year-old Colombian with legal working papers — killed at the hands of the ICE goon squad. Our credulous Sen. Susan Collins — who voted for another $70 billion of…

### Local News: St. Louis + Atlanta — 50 new of 203 total
  - (2026-07-19) [St. Louis] US military launches new airstrikes to 'swiftly punish' Iran for deaths of US troops
      The U.S. military has launched airstrikes against Iran's Revolutionary Guard in retaliation for an attack in Jordan that killed two U.S. service members.
  - (2026-07-19) [St. Louis] Winning Powerball numbers for Saturday, July 18, 2026
      Check your numbers! Did you win the $526 million Powerball Jackpot?
  - (2026-07-19) [St. Louis] When is the last time Spain won the World Cup?
      Spain has only one World Cup title under its belt.
  - (2026-07-19) [St. Louis] When is the World Cup final? Here's everything to know from halftime performers to kickoff time
      The World Cup final is finally here with Spain and Argentina battling head-to-head in New Jersey. Here's what to expect.
  - (2026-07-19) [St. Louis] Social media influencers Andrew and Tristan Tate arrested in Miami, US Marshals Service tells AP
      Andrew and Tristan Tate face extradition to the UK on rape and sex trafficking charges, according to British prosecutors.
  - (2026-07-19) [St. Louis] Will Trump be at the World Cup final?
      Presidents from both the U.S. and Mexico are attending the World Cup final on Sunday.

### Ukraine Theater (total-war monitoring) — 43 new of 239 total
  - (2026-07-19) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-17) [Liveuamap] CENTCOM: CENTCOM launched a round of strikes against Iran at 3 p.m. ET today for the seventh consecutive night. The strikes are designed to continue degrading Iranian military capabilities…
      CENTCOM: CENTCOM launched a round of strikes against Iran at 3 p.m. ET today for the seventh consecutive night. T
  - (2026-07-18) [Liveuamap] Large fire at Wildberries warehouse in Elektrostal, Moscow region after drones strikes - Liveuamap
      Large fire at Wildberries warehouse in Elektrostal, Moscow region after drones strikes
  - (2026-07-19) [Liveuamap] Tasnim News Agency, quoting the Iranian Revolutionary Guard: - Targeting a US Navy fueling berth in Kuwait&039;s Al-Ahmadi port - Targeting a US fighter jet site at Sheikh Isa Air Base in…
      Tasnim News Agency, quoting the Iranian Revolutionary Guard: - Targeting a US Navy fueling berth in Kuwait&039;s
  - (2026-07-17) [Liveuamap] The locations of two bridges and one tunnel in the eastern and northern axes of Bandar Abbas, which, according to reports, have been targeted in tonight&039;s attacks up to this moment. Ru…
      The locations of two bridges and one tunnel in the eastern and northern axes of Bandar Abbas, which, according to reports,
  - (2026-07-14) [Liveuamap] Saudi air force raids on Yemen are ongoing. Sana&039;a Governorate, Yemen - Interactive map of Yemen war - Liveuamap
      Saudi air force raids on Yemen are ongoing. Sana&039;a Governorate, Yemen - Interactive map of Yemen war <font co

### Ukrainian Internal News (national + local Kyiv) — 32 new of 113 total
  - (2026-07-19) Росіяни влучили у підземний перехід біля метро "Лук’янівська" | LEDE: Під час масованої російської атаки на Київ сталося пряме влучання у підземний перехід біля станції метро "Лук'янівська".] (uk: Рос…
      Під час масованої російської атаки на Київ сталося пряме влучання у підземний перехід біля станції метро "Лук'янівська".
  - (2026-07-19) Російський дрон знову влучив у пасажирський поїзд на Запоріжжі | LEDE: Удар дрона по потягу в Запорізькій області: провідниця поранена, пасажирів евакуйовано, залізниця працює.] (uk: Російський дрон з…
      Удар дрона по потягу в Запорізькій області: провідниця поранена, пасажирів евакуйовано, залізниця працює.
  - (2026-07-19) На тлі протестів командувачі ВМС і ДШВ заступилися за Сирського | LEDE: Командувачі ВМС і ДШВ виступили за підтримку Сирського й засудили політичні суперечки у ЗСУ.] (uk: На тлі протестів командувачі…
      Командувачі ВМС і ДШВ виступили за підтримку Сирського й засудили політичні суперечки у ЗСУ.
  - (2026-07-19) Сибіга закликав Захід до нищівного тиску на РФ після масованого удару по Києву | LEDE: ] (uk: Сибіга закликав Захід до нищівного тиску на РФ після масованого удару по Києву)
  - (2026-07-19) Зеленський повідомив деталі однієї з наймасованіших балістичних атак на Київ | LEDE: ] (uk: Зеленський повідомив деталі однієї з наймасованіших балістичних атак на Київ)
  - (2026-07-19) США назвали цілі останніх ударів по Ірану | LEDE: Сили США вісім ночей поспіль наносять удари по іранських об'єктах для ослаблення військового потенціалу.] (uk: США назвали цілі останніх ударів по Іра…
      Сили США вісім ночей поспіль наносять удари по іранських об'єктах для ослаблення військового потенціалу.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 12 new of 19 total
  - (2026-07-19) M 5.5 - 2 km WSW of Sicaya, Peru
      M5.5 · 2 km WSW of Sicaya, Peru · depth 10 km · PAGER yellow
  - (2026-07-19) M 5.3 - 59 km SW of Puerto Madero, Mexico
      M5.3 · 59 km SW of Puerto Madero, Mexico · depth 19.593 km
  - (2026-07-19) M 5.3 - 85 km SW of Puerto Madero, Mexico
      M5.3 · 85 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-19) M 5.3 - 190 km SSE of Vilyuchinsk, Russia
      M5.3 · 190 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-07-19) M 4.9 - 40 km ENE of Shahrak-e Kūlūrī, Iran
      M4.9 · 40 km ENE of Shahrak-e Kūlūrī, Iran · depth 10 km
  - (2026-07-19) M 4.8 - 83 km S of Pelabuhanratu, Indonesia
      M4.8 · 83 km S of Pelabuhanratu, Indonesia · depth 10 km

### Paper Trading Scorecard — 8 new of 139 total
  - (2026-07-19) [Polymarket] China x Japan military clash before 2027?
      This market will resolve to "Yes" if there is a military encounter between the military forces of China (People's Republic of China) and Japan between November 17, 2025, and December 31, 2026, 11:59 PM ET. Otherwise, thi…
  - (2026-07-19) [Polymarket] Will Marco Rubio win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-19) [Polymarket] Will Bitcoin dip to $25,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "Low" price equal to or low…
  - (2026-07-19) [Manifold] Will Spain completely shut down Messi and win the World Cup Final within regular 90 minutes?
  - (2026-07-19) [Manifold] Daily Coinflip
  - (2026-07-19) [Manifold] Will Remco Evenepoel be in 2nd place at the conclusion of any stage of the 2026 Tour de France?

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-07-17) Arizona Supreme Court: REPUBLICAN NATL COMMITTEE v. FONTES
  - (2026-07-17) Arizona Supreme Court: GOLDWATER v. PHOENIX
  - (2026-07-17) Arizona Supreme Court: Gelvin v. Hon. parker/gelvin
  - (2026-07-16) U.S. Court of Appeals, 11th Cir.: Savannah Shoals, LLC v. Commissioner of Internal Revenue
  - (2026-07-16) D.C. Court of Appeals: Brooks v. Mitsubishi Electric & Electronics US, Inc.
  - (2026-07-16) D.C. Court of Appeals: Carruth v. United States

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-07-19) Spain vs. Argentina: Both Teams to Score
      yes price: 54% · 24h volume: $1,158,048 · resolves 2026-07-19
  - (2026-07-19) Exact Score: Spain 2 - 2 Argentina?
      yes price: 6% · 24h volume: $985,139 · resolves 2026-07-19
  - (2026-07-19) Exact Score: Spain 2 - 1 Argentina?
      yes price: 10% · 24h volume: $918,864 · resolves 2026-07-19
  - (2026-07-19) Exact Score: Spain 1 - 2 Argentina?
      yes price: 6% · 24h volume: $815,668 · resolves 2026-07-19
  - (2026-07-19) Will Spain win on 2026-07-19?
      yes price: 42% · 24h volume: $730,257 · resolves 2026-07-19
  - (2026-07-19) Spain vs. Argentina: O/U 1.5
      yes price: 69% · 24h volume: $701,378 · resolves 2026-07-19

### GDACS — global disaster alerts — 6 new of 108 total
  - (2026-07-19) [Orange] Earthquake in Peru
      Earthquake · Orange alert · Peru · Magnitude 5.5M, Depth:10km
  - (2026-07-19) [Orange] Earthquake in Peru
      Earthquake · Orange alert · Peru · Magnitude 5.5M, Depth:10km
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-07-19) [Green] Tropical Cyclone SIX-E-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 176 km/h)

### IT, InfoSys & cybersecurity news (last 7 days) — 5 new of 58 total
  - (2026-07-19) [The Register] Using AI makes people less likely to admit they don't know something
      Researchers found confidence increased even as accuracy fell
  - (2026-07-18) [The Register] Java was a three-day hotfix away from dying horribly on stage
      Tim Lindholm, Java's original JVM maintainer, shares with El Reg some of the grungy build details the doc glosses over
  - (2026-07-18) [The Register] NextBSD returns to dollop Apple source on FreeBSD
      New maintainer revives the project with Darwin components, Gershwin, and Claude Code
  - (2026-07-17) [The Register] Mozilla speeds Firefox release schedule to biweekly
      And what to expect in Firefox 153 as the next ESR release gets close
  - (2026-07-17) [The Register] Microsoft cuts OneDrive support for older Windows 10 versions next month
      22H2 has until 2028, or there's always Windows 11

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-19) [Marginal Revolution] Cross-ethnic casting
      I complained about the casting of The Odyssey per se (the blind beggar was best), but in general I do not mind cross-ethnic casting. I am glad Elizabeth Taylor played Cleopatra, Dev Patel played David Copperfield, Denzel…
  - (2026-07-19) [Marginal Revolution] How does social media change people?
      I would not trust the results of this (or any) paper on this topic very much, but it is good to see some inquiry along different dimensions than the usual: Past research explored the beneficial and harmful effects of soc…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: commission, directive, regulatory, flight, proposing, significant, proposes, local, temporary, airworthiness, issuing, amended
- state_bills: today=0, 7d-median=70, 14d-median=70
- state_news: today=431, 7d-median=445, 14d-median=445; carrying terms: enrolled, purchases, coming, products, leadership, hours, efforts, ctmirror, donald, street, leaning, council
- local_news: today=203, 7d-median=236, 14d-median=236; carrying terms: several, coming, products, moment, helped, opens, store, sentenced, street, popular, organization, atlanta
- foreign_news: today=978, 7d-median=1031, 14d-median=1031; carrying terms: coming, hours, efforts, street, upholding, council, service, shares, murdered, indonesia, writes, popular
- chinese_internal: today=277, 7d-median=277, 14d-median=277; carrying terms: cbmia, caixin, color, cbmiz, cbmicefvx, cbmiaefvx, lxtfa, cbmizkfvx, cbmix, cbmidefvx, cbmiakfvx, title
- russian_internal: today=725, 7d-median=882, 14d-median=882; carrying terms: title, bloomberg, blank, insider, media, russian, httperror, raquo, europe, times, gazeta, client
- ukrainian_internal: today=113, 7d-median=135, 14d-median=135; carrying terms: supporting, soldiers, coordinated, helped, hours, efforts, donald, volodymyr, council, service, range, russia
- ukraine_theater: today=239, 7d-median=400, 14d-median=400; carrying terms: wturezzu, noefzuxjwq, ltuzfnmdrrvtlvvelfzmr, products, zgdxvabdhzwtleu, viirs, leadership, zufyymt, cuxqm, jurujzndmwcepjzi, uefpa, tzchvcmtnlcklklurisi
- paper_bets: today=139, 7d-median=139, 14d-median=139; carrying terms: depleted, determined, evans, mamdani, goals, fuentes, reserves, miles, robot, brazilian, republicans, equal
- weather: today=140, 7d-median=147, 14d-median=147; carrying terms: several, hours, little, southwest, angeles, above, local, columbia, service, america, range, areas
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, dexjpus, dcoilwtico, balance, labor, pcepilfe, openings, unemployment, jolts, jtsjol, latest, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, crypto, proxy, natural, range, crude, corporate, commodities, credit, silver, nasdaq, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=115, 7d-median=115, 14d-median=115; carrying terms: exploration, resolutions, actions, laboratory, lander, involvement, chemical, contractor, btdyc, aeronautics, council, removals
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, httperror, https, quiver, client, congresstrading, quiverquant, quantitative, error
- billionaires: today=30, 7d-median=32, 14d-median=32; carrying terms: london, steve, bloomberg, yiming, gates, infrastructure, ballmer, francoise, amancio, finance, exchange, paris
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: office, electric, trade, revenue, california, america, alaska, appeals, blanche, general, delaware, energy
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, david, thomas, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: lindsey, jonathan, cycle, pinkston, sherrod, ossoff, senate, krishnamoorthi, booker, brown, chartered, lowden
- gdelt_regions: today=0, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=0, 7d-median=48, 14d-median=48; carrying terms: trump, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: virology, several, sentinel, divisions, previous, products, determined, different, parganas, institut, genomic, congo
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: product, vulnerability, control, bypass, vendor, forgery, server, injection, authentication, request, untrusted, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=108, 7d-median=108, 14d-median=108; carrying terms: madagascar, green, islands, magnitude, salvador, sweden, minor, congo, eruption, czech, drought, speed
- usgs_quakes: today=19, 7d-median=19, 14d-median=19; carrying terms: depth
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: advance, meeting, volume, ethiopia, resolves, argentina, rates, spain, world, prime, price, minister
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, marginal, marginalrevolution, conversable, economist, revolution, https, points, links, particular, assorted
- tech_news: today=58, 7d-median=57, 14d-median=57; carrying terms: staff, several, policy, force, leadership, krebs, plates, botnet, researchers, service, range, russia
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: walberg, analilia, staff, angie, teresa, houlahan, kennedy, letlow, brian, tuberville, crane, dusty
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, unavailable, consensus, placed, identify, today, market, either, sufficient, claude, converges, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*