# WORLDSCOPE morning brief — 2026-07-19

## Headline
2393 new items across 21 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (640) · Russian Internal News (state + in-exile) (531) · World leaders & government officials (324) · Chinese Internal News (189) · U.S. Weather + Severe / Climate Outlooks (166) · Local News: St. Louis + Atlanta (123) · State-Level News (90) · Ukraine Theater (total-war monitoring) (64) · GDACS — global disaster alerts (58) · Ukrainian Internal News (national + local Kyiv) (50) · Sanctions & Designations (recent) (30) · Paper Trading Scorecard (28)

## What changed today
### International News + Multilateral Institutions — 640 new of 1005 total
  - (2026-07-19) [Global] São Tomé and Príncipe heads to polls in tense presidential election
  - (2026-07-19) [Global] Dozens missing after passenger ferry sinks off coast of Guyana
  - (2026-07-19) [Global] Earthquake in Peru leaves at least six dead
  - (2026-07-19) [Global] News live: Lee Hanson says her mother’s comments about the White Australia policy were ‘misinterpreted’
  - (2026-07-19) [Global] Australia’s life dissatisfaction levels double as ‘wellbeing poverty’ reaches new highs
  - (2026-07-19) [Global] Australian and NZ safety assurances about asbestos in play sand were based on supplier’s own assessment

### Russian Internal News (state + in-exile) — 531 new of 722 total
  - (2026-07-20) 39 дней футбола. Как это было. Лучшие моменты ЧМ-2026 в фотографиях | LEDE: В США, Мексике и Канаде завершился 23-й чемпионат мира по футболу. Чемпионом стала сборная Испании, в финале обыгр] (ru: 39…
      В США, Мексике и Канаде завершился 23-й чемпионат мира по футболу. Чемпионом стала сборная Испании, в финале обыгравшая Аргентину. Прошедший чемпионат был рекордным по количеству участвовавших команд (48), сыгранных матч…
  - (2026-07-20) Испания — чемпион! Чем там закончился ЧМ? Суперкоротко | LEDE: Кто чемпион? Испания! Основное время финала с Аргентиной завершилось нулевой ничьей, единственный гол Ферран Торрес забил на 10] (ru: Исп…
      Кто чемпион? Испания! Основное время финала с Аргентиной завершилось нулевой ничьей, единственный гол Ферран Торрес забил на 106-й минуте. Испания доминировала весь матч: 20 ударов, из них 12 в створ, у Аргентины — ноль…
  - (2026-07-19) В Украине четвертый день подряд проходят протесты из-за смены министра обороны | LEDE: Жители Киева вечером 19 июля снова собрались на возле театра имени Ивана Франко на акцию против отставк] (ru: В У…
      Жители Киева вечером 19 июля снова собрались на возле театра имени Ивана Франко на акцию против отставки Михаила Федорова с должности министра обороны.
  - (2026-07-19) В Украине заявили, что российские военные нанесли удар по сухогрузу с зерном. Пять человек погибли | LEDE: Войска РФ нанесли ракетный удар по гражданскому сухогрузу, который перевозил зерно,] (ru: В У…
      Войска РФ нанесли ракетный удар по гражданскому сухогрузу, который перевозил зерно, заявило командование ВМС Украины.
  - (2026-07-19) Туристка из России рассказала, что в Грузии ее подругу избили «за русскую речь». Нападавшего задержали. По версии полиции, конфликт начался из-за того, что девушки мешали гостям грузинской свад] (ru:…
      В отеле Agarani Estate в Кахетии мужчина ворвался в номер к туристкам и ударил одну из них в лицо. Видео об этом в инстаграме опубликовала подруга пострадавшей Полина Курта. К моменту публикации этой статьи ролик с момен…
  - (2026-07-19) Этот чемпионат мира по футболу окончательно показал: Месси — великий (если не величайший). Причем независимо от того, кто победит в финале | LEDE: Сегодня вечером Лионель Месси сыграет в сво] (ru: Это…
      Сегодня вечером Лионель Месси сыграет в своем очередном, уже третьем в карьере, финале чемпионата мира по футболу. Возможно, это его последний матч за сборную своей страны. У Аргентины есть уникальная возможность защитит…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 189 new of 277 total
  - (2026-07-19) 京剧宗师谭鑫培的“面儿” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBidDdzaGxVTVZremlLaF95OUxybXlqWmN4SHF5Tk04LTJDcE5RNHRCTUR3WmctQVhrR2dsNzl2SHA4ZlBJQ2RvWTJjUTNvWVlFTmtiZTVkc] (zh:…
      京剧宗师谭鑫培的“面儿” 财新
  - (2026-07-19) 世界杯决赛西阿大战，数据一网打尽 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBEclpKYzlpcFlUOXJKZk1jMzBwNDRBeE5fZWt4QnlrYTJyaE1ORnBTY0NaQnB3aUtSZzNmQUlkU040aUQ5ZEM0NWRhdXFOUnl5QWNxZ] (zh:…
      世界杯决赛西阿大战，数据一网打尽 财新
  - (2026-07-19) 最新财新周刊｜复杂局面下如何稳经济 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFA1N2FPTWd0Qm1qTlIwWl9lclNjbTA3SnVQdFFnQm9MUGZWNGFMOUVueDlXc1h4Q2s5WGQtRnowNElTWDFDclI3c2NaWXRTdGJYUz] (zh:…
      最新财新周刊｜复杂局面下如何稳经济 财新周刊
  - (2026-07-19) 最新财新周刊｜热浪侵袭下的动物 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5xanpTMUdIMG1SYW5YSzd4N2x1a1JTNDBJVWRFanV5V3g2YVRid2VaaE1FeEhLd1lIcGdqTzVNX3lsM2lha2Y3SGJQNXlNUWNiUmI3] (zh:…
      最新财新周刊｜热浪侵袭下的动物 财新周刊
  - (2026-07-19) 财新观察｜完善扩大居民消费长效机制 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1EaVF0MVdpTm5CNFZVYi02TWtoU0JDNnVWT1o4V1dNZUk4UWw0ZXE5RE0tWFh6bjJraDZsSUZ6WU1ZZXpsbThjQU1uSGl5M1BlOX] (zh:…
      财新观察｜完善扩大居民消费长效机制 财新周刊
  - (2026-07-19) 反腐记｜蔡赴朝、欧阳卫民落马 马兴瑞被移送司法 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE85NE9WUWdybDRzZEdYVkVYcC1oM0dGTkNCbVdiQldpbHN6aUxuTjBpeEhyd0psay0tS0JzVHVtTXZfWEhT] (zh:…
      反腐记｜蔡赴朝、欧阳卫民落马 马兴瑞被移送司法 china.caixin.com

### U.S. Weather + Severe / Climate Outlooks — 166 new of 167 total
  - (2026-07-19) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 19 at 6:32PM CDT until July 19 at 7:15PM CDT by NWS Bismarck ND
      SVRBIS The National Weather Service in Bismarck has issued a * Severe Thunderstorm Warning for... Southern Burleigh County in south central North Dakota... * Until 715 PM CDT. * At 632 PM CDT, a severe thunderstorm was l…
  - (2026-07-19) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 19 at 6:31PM CDT until July 19 at 7:15PM CDT by NWS Bismarck ND
      At 631 PM CDT /531 PM MDT/, a severe thunderstorm was located 8 miles northwest of Solen, or 26 miles south of Bismarck, moving east at 35 mph. HAZARD...60 mph wind gusts and half dollar size hail. SOURCE...Radar indicat…
  - (2026-07-19) [Moderate] Special Weather Statement: Special Weather Statement issued July 19 at 6:30PM CDT by NWS Lubbock TX
      At 629 PM CDT, Doppler radar was tracking a strong thunderstorm 6 miles northwest of Afton, or 11 miles south of Matador, moving northwest at 20 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...G…
  - (2026-07-19) [Moderate] Special Weather Statement: Special Weather Statement issued July 19 at 7:30PM EDT by NWS Greenville-Spartanburg SC
      At 730 PM EDT, Doppler radar was tracking a strong thunderstorm 4 miles northwest of Pickens, moving east at 10 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree…
  - (2026-07-19) [Moderate] Special Weather Statement: Special Weather Statement issued July 19 at 6:29PM CDT by NWS Norman OK
      At 629 PM CDT, Doppler radar was tracking the leading edge of winds from dissipating showers and thunderstorms along a line extending from near Manitou to 5 miles north of Loveland to 3 miles south of Grandfield. Movemen…
  - (2026-07-19) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 19 at 5:28PM MDT until July 19 at 6:30PM MDT by NWS Billings MT
      SVRBYZ The National Weather Service in Billings has issued a * Severe Thunderstorm Warning for... Southeastern Big Horn County in south central Montana... Central Sheridan County in north central Wyoming... * Until 630 P…

### Local News: St. Louis + Atlanta — 123 new of 214 total
  - (2026-07-19) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-07-19) [St. Louis] No joke: St. Louis comedians are turning punchlines into charity checks
      St. Louis comedians are turning laughs into charitable giving, donating every ticket dollar to local nonprofits through the volunteer group Standup Comedy for Good.
  - (2026-07-19) [St. Louis] Who is the top goal scorer at the World Cup?
      Kylian Mbappé won the award twice in a row, becoming the first to do so.
  - (2026-07-19) [St. Louis] JD and Usha Vance welcome a baby boy, the first child born to a sitting VP in more than 150 years
      Vice President JD Vance and his wife, Usha, announce the birth of their fourth child Sunday.
  - (2026-07-19) [St. Louis] Cardinal Dolan returns to St. Louis for archdiocese's 200th anniversary
      Cardinal Timothy Dolan returned to his hometown to celebrate the Archdiocese of St. Louis' 200th anniversary and reflect on 50 years as a priest.
  - (2026-07-19) [St. Louis] When was the last time a World Cup final match ended in 1-0?
      Spain's tense World Cup final win over Argentina was full of historic firsts, but what about final matches ending in 1-0?

### State-Level News — 90 new of 458 total
  - (2026-07-19) [Connecticut] The story behind rows of unmarked stones at New Haven cemetery
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/PAUPERS-CEMETERY-0702-JL-08-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fe…
  - (2026-07-19) [Connecticut] Hot and bothered – summer’s transportation meltdown
      <img width="694" height="307" src="https://ctmirror.org/wp-content/uploads/2026/07/sunkinks-example.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="…
  - (2026-07-19) [Arkansas] Arkansans who banded together to save PBS deserve better than this
      In normal times, a group of citizens banding together and pitching in to save a public institution like PBS would be rewarded. They would be lauded for putting their money where their mouths are. But these aren’t normal…
  - (2026-07-19) [Florida] At Leadership Blue, Pete Buttigieg says Florida Democrats can win in November
      LAKE BUENA VISTA — A series of special and local election victories over the past year have boosted Florida Democrats’ confidence they’ll continue that winning streak into the November midterm elections. But with more th…
  - (2026-07-19) [Florida] United Methodist conference to move meeting out of Idaho, citing LGBTQ+, immigrant safety concerns
      This story was first published on July 14, 2026, by FāVS News. Citing dangers to LGBTQ+ and immigrant communities, the Oregon-Idaho Conference of the United Methodist Church voted last month to move next year’s annual co…
  - (2026-07-19) [Georgia] Public health improvements stall amid Trump’s DEI crackdown
      THOMASVILLE, Ga. — As Earl Williams drove through a historic Black neighborhood known as Dewey City in his hometown, he hardly recognized what he saw. Homes that once belonged to friends, family, and neighbors had siding…

### Ukraine Theater (total-war monitoring) — 64 new of 240 total
  - (2026-07-19) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-19) [ISW] Russian Offensive Campaign Assessment 2026-07-19
      Key Takeaways Ukrainian forces continued their long-range strike campaign against Russian oil and energy infrastructure and naval vessels on July 18 and 19. Russian forces recently advanced in northern Sumy Oblast. .fanc…
  - (2026-07-18) [Liveuamap] Eilat Municipality Spokesperson: A short time ago, an Israeli army spokesperson reported that launches from Iran were detected towards the city of Aqaba in Jordan, near the territory of th…
      Eilat Municipality Spokesperson: A short time ago, an Israeli army spokesperson reported that launches from Iran were d
  - (2026-07-17) [Liveuamap] CENTCOM: CENTCOM launched a round of strikes against Iran at 3 p.m. ET today for the seventh consecutive night. The strikes are designed to continue degrading Iranian military capabilities…
      CENTCOM: CENTCOM launched a round of strikes against Iran at 3 p.m. ET today for the seventh consecutive night. T
  - (2026-07-18) [Liveuamap] CENTCOM: CENTCOM Statement on Recently Fallen, Missing U.S. Service Members TAMPA, Fla. — On July 17, two U.S. service members in Jordan were killed in action as U.S. Central Command (CENT…
      CENTCOM: CENTCOM Statement on Recently Fallen, Missing U.S. Service Members TAMPA, Fla. — On July 17, two U.S. s
  - (2026-07-18) [Liveuamap] Large fire at Wildberries warehouse in Elektrostal, Moscow region after drones strikes - Liveuamap
      Large fire at Wildberries warehouse in Elektrostal, Moscow region after drones strikes

### GDACS — global disaster alerts — 58 new of 160 total
  - (2026-07-19) [Orange] Earthquake in Peru
      Earthquake · Orange alert · Peru · Magnitude 5.5M, Depth:10km
  - (2026-07-19) [Orange] Earthquake in Peru
      Earthquake · Orange alert · Peru · Magnitude 5.5M, Depth:10km
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-06-28) [Green] Flood in Mexico
      Flood · Green alert · Mexico · Magnitude 0
  - (2026-07-19) [Green] Earthquake in Mexico
      Earthquake · Green alert · Mexico · Magnitude 5.5M, Depth:35km

### Ukrainian Internal News (national + local Kyiv) — 50 new of 128 total
  - (2026-07-20) Ціни на нафту зросли на 3% після 8-денних ударів між США та Іраном | LEDE: ЗМІ повідомили, як змінюється ціна на нафту після відновлення ударів між США та Іраном.] (uk: Ціни на нафту зросли на 3% післ…
      ЗМІ повідомили, як змінюється ціна на нафту після відновлення ударів між США та Іраном.
  - (2026-07-20) Окупанти знову перекрили міст, соцмережі повідомили про атаку дронів на Ялту | LEDE: У соцмережах пишуть про перекриття Кримського моста і вибухи в окупованій Ялті.] (uk: Окупанти знову перекрили міст…
      У соцмережах пишуть про перекриття Кримського моста і вибухи в окупованій Ялті.
  - (2026-07-20) Іран звинуватив США в ударі по АЕС і пообіцяв "відповідну" реакцію | LEDE: У неділю заступник міністра закордонних справ Ірану Казем Гарібабаді попередив про "відповідну" реакцію після того, як] (uk:…
      У неділю заступник міністра закордонних справ Ірану Казем Гарібабаді попередив про "відповідну" реакцію після того, як країна звинуватила США в атаці на атомну електростанцію Darkhovin на півдні Ірану.
  - (2026-07-20) Другу ніч поспіль у Києві та областях лунала повітряна тривога через загрозу балістики | LEDE: У Києві та низці областей другу ніч поспіль оголошують тривогу через загрозу балістики.] (uk: Другу ніч п…
      У Києві та низці областей другу ніч поспіль оголошують тривогу через загрозу балістики.
  - (2026-07-20) У Харкові загинула трирічна дитина, випавши з вікна п'ятого поверху | LEDE: Поліція розслідує факт загибелі дитини, яка випала з 5 поверху.] (uk: У Харкові загинула трирічна дитина, випавши з вікна п'…
      Поліція розслідує факт загибелі дитини, яка випала з 5 поверху.
  - (2026-07-19) Удар РФ по Запоріжжю: 2 загиблих, 42 постраждалих, серед них 8 дітей | LEDE: Внаслідок атаки КАБами на Запоріжжя зруйновано житло, 1 людина загинула, 3 поранені, під завалами — жінка і дитина.] (uk: У…
      Внаслідок атаки КАБами на Запоріжжя зруйновано житло, 1 людина загинула, 3 поранені, під завалами — жінка і дитина.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 28 new of 146 total
  - (2026-07-19) [Polymarket] Putin out as President of Russia by June 30, 2027?
      This market will resolve to “Yes” if Vladimir Putin ceases to be President of Russia for any period of time between market creation and the specified date (ET). Otherwise, this market will resolve to “No”. An announcemen…
  - (2026-07-19) [Polymarket] Will Pat McFadden be the next Chancellor of the Exchequer of the UK in 2026?
      This market will resolve to the next individual who is officially appointed as the next Chancellor of the Exchequer of the United Kingdom by December 31, 2026, 11:59 PM ET. To count for resolution, the individual must be…
  - (2026-07-19) [Polymarket] US announces end of Iranian blockade by July 31, 2026?
      On July 13, 2026, Trump announced the United States would reinstate its naval blockade of Iran, targeting Iranian ships and customers. This market will resolve to “Yes” if the United States government, or an authorized r…
  - (2026-07-19) [Polymarket] Will Marco Rubio win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-19) [Polymarket] Will France send warships through the Strait of Hormuz by July 31, 2026?
      This market will resolve to "Yes" if a national government, its military, or a broad consensus of credible reporting confirms that the listed country's warships transited through the Strait of Hormuz between market creat…
  - (2026-07-19) [Polymarket] Will Bitcoin dip to $25,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "Low" price equal to or low…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-19) [Israel-Iran-Hezbollah axis · themes] Calendario Escolar 2026 - 2027 : ¿ Cuántos puentes marca la SEP ?
      razon.com.mx · Spanish · tone NA
  - (2026-07-19) [Israel-Iran-Hezbollah axis · themes] Video : ¿ Andinistas están dentro de un glaciar ?: Rescatistas regresan de buscar por falta de apoyo logístico por Latina Noticias
      deperu.com · Spanish · tone NA
  - (2026-07-19) [Israel-Iran-Hezbollah axis · themes] FEELING THINGS : 3 Signs Youre Annoying , the Most Millennial Things We Do , | 95 . 3 The Bull
      953bull.iheart.com · English · tone NA
  - (2026-07-19) [Israel-Iran-Hezbollah axis · themes] U . S . service member killed in action in northern Iraq , another wounded
      abc6onyourside.com · English · tone NA
  - (2026-07-19) [Israel-Iran-Hezbollah axis · themes] ВМС : армія Росії атакувала турецький суховантаж , 5 людей загинули
      radiosvoboda.org · Ukrainian · tone NA
  - (2026-07-19) [Israel-Iran-Hezbollah axis · themes] Latest Articles
      freerepublic.com · English · tone NA

### State Legislative Action — 20 new of 124 total
  - (2026-07-17) [Colorado HB 1426] Department of Law Legislative Report
      On January 20, 2026, as part of its reporting duties pursuant to the 'State Measurement for Accountable, Responsive, and Transparent (SMART) Government Act', or 'SMART Act', the department of law (DOL) submitted to the h…
  - (2026-07-17) [Colorado SJR 11] Designate Sergeant John "Jack" Thurman Memorial Highway
      Designate Sergeant John "Jack" Thurman Memorial Highway
  - (2026-07-17) [Colorado HB 1014] Extend Colorado Job Growth Incentive Tax Credit
      Under current law, the Colorado job growth incentive tax credit (credit) may only be allowed by the economic development commission (commission) through state income tax year 2026. The act amends the Colorado job growth…
  - (2026-07-17) [Colorado SB 139] Local Education Provider Workforce Housing
      Section 4 of the bill creates the 'Building Excellent Teacher and Employee Residences Act' (BETER). BETER creates a new school district financing opportunity for the development of housing for teachers and other school d…
  - (2026-07-17) [Colorado HB 1139] Use of Artificial Intelligence in Health Care
      On and after January 1, 2027, when determining coverage for health-care services, the act requires entities that use an artificial intelligence system (AI system) for the purpose of conducting utilization review of healt…
  - (2026-07-17) [Colorado HB 1240] State Earned Income Tax Credit Age Limit
      Under current law, only individuals of certain ages may qualify for the federal or state earned income tax credit. The federal "American Rescue Plan Act of 2021" temporarily lowered the minimum age requirement and remove…

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-07-19) M 5.5 - 81 km SW of Puerto Madero, Mexico
      M5.5 · 81 km SW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-19) M 5.5 - 2 km WSW of Sicaya, Peru
      M5.5 · 2 km WSW of Sicaya, Peru · depth 10 km · PAGER yellow
  - (2026-07-19) M 5.3 - 59 km SW of Puerto Madero, Mexico
      M5.3 · 59 km SW of Puerto Madero, Mexico · depth 19.593 km
  - (2026-07-19) M 5.3 - 85 km SW of Puerto Madero, Mexico
      M5.3 · 85 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-19) M 5.3 - 190 km SSE of Vilyuchinsk, Russia
      M5.3 · 190 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-07-19) M 4.9 - 40 km ENE of Shahrak-e Kūlūrī, Iran
      M4.9 · 40 km ENE of Shahrak-e Kūlūrī, Iran · depth 10 km

### IT, InfoSys & cybersecurity news (last 7 days) — 16 new of 58 total
  - (2026-07-19) [BleepingComputer] Hackers abuse ViPNet software to target Russian govt agencies
      An advanced threat actor is abusing the update mechanism for the ViPNet private networking product suite to target Russian organizations, including government agencies. [...]
  - (2026-07-19) [The Hacker News] Critical NGINX Vulnerability Can Crash Workers and May Allow Remote Code Execution
      F5 has shipped fixes for a critical nginx flaw that lets a remote, unauthenticated attacker trigger a heap buffer overflow in the worker process with crafted HTTP requests. CVE-2026-42533 was patched on July 15 in nginx…
  - (2026-07-19) [The Hacker News] UAC-0145 Uses ClickFix CAPTCHAs to Infect Ukrainian Devices wih Malware
      Russian state-sponsored threat actors have been observed leveraging the infamous ClickFix strategy to trick Ukrainian targets into infecting their own machines with data-stealing malware. According to the Computer Emerge…
  - (2026-07-19) [The Hacker News] SonicWall SMA Zero-Days Exploited Before Disclosure to Gain Root Access
      A previously undocumented threat actor has been attributed to the exploitation of recently disclosed SonicWall Secure Mobile Access (SMA) 1000 series VPN appliances as zero-days prior their public disclosure since June 2…
  - (2026-07-19) [The Register] Connecting AI agents to outside services explodes the risk radius
      Connect all the things and watch what happens
  - (2026-07-19) [The Register] Using AI makes people less likely to admit they don't know something
      Researchers found confidence increased even as accuracy fell

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-07-19) Will Trump be in the WC Champions Photo?
      yes price: 98% · 24h volume: $1,413,588 · resolves 2026-07-20
  - (2026-07-19) Los Angeles Dodgers vs. New York Yankees
      yes price: 42% · 24h volume: $1,289,238 · resolves 2026-07-26
  - (2026-07-19) Will Lionel Messi win the Golden Ball at the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $926,653 · resolves 2026-07-20
  - (2026-07-19) Will Kylian Mbappé win the Golden Ball at the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $890,620 · resolves 2026-07-20
  - (2026-07-19) Will Harry Kane win the Golden Ball at the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $781,183 · resolves 2026-07-20
  - (2026-07-19) Will Lamine Yamal win the Golden Ball at the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $771,182 · resolves 2026-07-20

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-19) [Marginal Revolution] Markets in everything?
      Peter Brook‘s five-hour-plus film adaptation of “The Mahabharata” is set for a BFI Blu-ray release on Aug. 10, presented in high definition from a new 4K restoration of the 1989 production. The release centres on the tri…
  - (2026-07-19) [Marginal Revolution] Sunday assorted links
      1. Female promotions and the academic pipeline. 2. NEW MONKEYS. 3. Those new service sector jobs — “One nanny isn’t cutting it anymore. Some parents are spending upward of $250,000 on teams for their children. Luxury ser…
  - (2026-07-19) [Marginal Revolution] Building luxury homes is good for the poor
      Tej Parikh writing in the FT: …high-end developments unlock long housing chains. As higher-income households move into newly built units, they free up older properties, raising supply and slashing prices for middle- and…

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 117 total
  - (2026-07-15) [FARA] NSD Press Room - Department of Justice (.gov)
      NSD Press Room Department of Justice (.gov)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: fishery, persons, amendment, plans, directive, model, coast, needed, based, amending, guard, limited
- state_bills: today=124, 7d-median=124, 14d-median=124
- state_news: today=458, 7d-median=458, 14d-median=458; carrying terms: sites, removal, nutrition, facilities, designed, church, winning, power, slice, provision, physical, attack
- local_news: today=214, 7d-median=236, 14d-median=236; carrying terms: power, injuries, lionel, night, cbmilwfbvv, ready, party, loading, trump, known, dining, extra
- foreign_news: today=1005, 7d-median=1031, 14d-median=1031; carrying terms: rsshub, thriller, itself, countries, nantong, claimed, designed, provinces, integration, power, fifth, physical
- chinese_internal: today=277, 7d-median=277, 14d-median=277; carrying terms: cbmiw, boost, china, global, cbmibefvx, cbmib, articles, cbmia, market, cbmizkfvx, cbmibkfvx, cbmickfvx
- russian_internal: today=722, 7d-median=882, 14d-median=882; carrying terms: apple, journal, style, forbidden, media, laquo, financial, times, httperror, target, technology, group
- ukrainian_internal: today=128, 7d-median=135, 14d-median=135; carrying terms: sites, facilities, countries, hmarochos, fighting, claimed, damage, turning, power, attacks, attack, party
- ukraine_theater: today=240, 7d-median=400, 14d-median=400; carrying terms: dqewq, cuxnaeuytmzqmelqz, featuring, bwrjn, zbzmtnmknhvljqbuxntwmtego, countries, lelxprv, xjdmq, nvcwd, dxzyvwyymunuvfltx, attack, lwotd
- paper_bets: today=146, 7d-median=143, 14d-median=143; carrying terms: nomination, official, district, erupt, speed, president, place, statement, cancelled, succeed, virginia, tennessee
- weather: today=167, 7d-median=165, 14d-median=165; carrying terms: damage, houston, night, afdlwx, above, craft, southwestern, increased, drainage, illnesses, peachtree, groups
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: supply, labor, vixcls, unemployment, growth, jolts, energy, implied, dexuseu, treasury, cpilfesl, assets
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, proxy, china, treasury, bitcoin, futures, russell, large, equities, yield, silver, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=117, 7d-median=115, 14d-median=115; carrying terms: jjmudpzw, protests, entities, guinea, attacks, yemen, palestinian, resolution, daesh, proliferation, sevastopol, trump
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, client, quiverquant, https, quiver, unauthorized, quantitative, httperror, error
- billionaires: today=30, 7d-median=32, 14d-median=32; carrying terms: warren, carlos, family, tiktok, bernard, amancio, trading, ellison, semiconductors, sergey, italy, france
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, scott, david, thomas
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: groom, brown, ocasio, platner, cooper, jonathan, graham, robert, david, angels, alexandria, ossoff
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=25, 7d-median=47, 14d-median=47; carrying terms: english, israel, russian, chinese, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: internationally, sites, consuming, official, middle, district, developed, children, animals, linked, travel, countries
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: product, deserialization, control, authentication, request, vulnerability, untrusted, vendor, access, sharepoint, forgery, cisco
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=160, 7d-median=151, 14d-median=151; carrying terms: medium, green, hungary, speed, indonesia, italy, france, tropical, republic, denmark, guinea, czech
- usgs_quakes: today=16, 7d-median=16, 14d-median=16; carrying terms: depth
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, prime, ethiopia, argentina, price, volume, spain, world, interest, meeting, minister, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, conversable, economist, revolution, https, marginal, points, assorted, particular, links
- tech_news: today=58, 7d-median=57, 14d-median=57; carrying terms: buying, attack, algorithm, companies, giving, interesting, hacker, based, known, engineers, groups, quantum
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: hageman, emilia, lateefah, hollen, ogles, fitzgerald, howard, sherman, yvette, zquez, casar, ossoff
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, module, consensus, identify, either, claude, placed, decision, sufficient, market, converges, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*