# WORLDSCOPE morning brief — 2026-11-21

## Headline
3473 new items across 32 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (793) · Russian Internal News (state + in-exile) (558) · World leaders & government officials (324) · State-Level News (316) · Local News: St. Louis + Atlanta (213) · Chinese Internal News (192) · State Legislative Action (149) · U.S. Weather + Severe / Climate Outlooks (122) · GDELT GKG — themes / entities / watch areas (118) · World News (by country, top stories) (108) · Ukraine Theater (total-war monitoring) (97) · Ukrainian Internal News (national + local Kyiv) (75)

## What changed today
### International News + Multilateral Institutions — 793 new of 1012 total
  - (2026-11-20) [Global] California’s coastal communities on alert as biggest waves in years hit state
  - (2026-11-20) [Global] ‘Weak and dizzy’: the secretive ICE force-feeding tactics that ended a Cuban father’s hunger strike
  - (2026-11-20) [Global] Trump threatens ‘tremendous penalties’ for US tech firms that build datacenters abroad
  - (2026-11-20) [Global] Nasdaq erases all 2026 gains as AI sell-off dampens Anthropic’s second day of trading
  - (2026-11-20) [Global] California investigates Nvidia over whether chip exports ended up in China
  - (2026-11-21) [Global] Teenager allegedly organised arsons and kidnapping on Signal during Melbourne hospitality wars

### Russian Internal News (state + in-exile) — 558 new of 960 total
  - (2026-11-21) На конференции ООН не смогли договориться об ограничениях на использование «роботов-убийц». Против выступили США, Россия и Израиль | LEDE: Переговоры ООН о регулировании вооружений, применен] (ru: На…
      Переговоры ООН о регулировании вооружений, применение которых почти или полностью не требует контроля человека, завершились тем, что стороны договорились продолжить обсуждения и выработать правила использования «роботов-…
  - (2026-11-21) «Путин должен понять, что мост не устоит». Зеленский — об ударах Украины по Крымскому мосту | LEDE: Крымский мост — законная цель для украинских атак после того, как Россия аннексировала Кры] (ru: «Пу…
      Крымский мост — законная цель для украинских атак после того, как Россия аннексировала Крым, заявил президент Украины Владимир Зеленский в интервью NBC News. По его словам, последние удары по мосту — это ответ на российс…
  - (2026-11-21) Саундтрек к GTA VI писала легендарная группа Justice. А на радио в машине теперь можно выбрать из 22 самых разных станций — все не переслушать! Вот как устроена музыкальная оболочка суперпопуля] (ru:…
      Серия игр Grand Theft Auto знаменита своим музыкальным сопровождением. Например, популярнейший музыкант Weeknd рассказывал, что игра GTA Vice City 2002 года напрямую повлияла на его становление, «открыв ему глаза» на муз…
  - (2026-11-21) В Европе не утихают протесты. Одна из главных причин — недоступность жилья для молодежи. Но правда ли, что нынешнее поколение живет хуже родителей? | LEDE: Многие переезжали в Европу в увере] (ru: В Е…
      Многие переезжали в Европу в уверенности, что жизнь здесь стабильнее и безопаснее. Сильный средний класс, предсказуемая политика, надежная пенсия, ощущение, что о тебе позаботятся, — все эти представления совсем недавно…
  - (2026-11-20) Россия нанесла удар по Кривому Рогу. Ранены больше 50 человек, погибли семилетний ребенок и фельдшер скорой помощи | LEDE: Вечером 20 ноября российские войска нанесли удар по Кривому Рогу. П] (ru: Рос…
      Вечером 20 ноября российские войска нанесли удар по Кривому Рогу. По данным главы Днепропетровской областной администрации Александра Ганжи, в городе повреждены ресторан, гаражи и автомобили.
  - (2026-11-20) FT: в администрации Трампа хотят, чтобы Россия и Украина заключили мирное соглашение к началу января | LEDE: Американские переговорщики сообщили европейским и украинским чиновникам, что Белы] (ru: FT:…
      Американские переговорщики сообщили европейским и украинским чиновникам, что Белый дом хотел бы, чтобы Россия и Украина заключили мирное соглашение к началу января 2027 года — до того, как демократы получат контроль над…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 316 new of 711 total
  - (2026-11-20) [Alabama] Alabama Power files for $160 million rate cut in 2027
  - (2026-11-20) [Alabama] APLS board elects Amy Minton chair, signaling continued support for court-challenged rule
  - (2026-11-20) [Alabama] For gambling legislation to pass, the governor has to be a force
  - (2026-11-20) [Alabama] Britt says Republicans must do more to lower costs after midterms
  - (2026-11-20) [Alabama] Montgomery collects care packages for domestic violence survivors
  - (2026-11-20) [Alabama] $3.8 billion Mobile River Bridge financing wins Southeast Deal of the Year

### Local News: St. Louis + Atlanta — 213 new of 257 total
  - (2026-11-20) [St. Louis] Kingside Diner opens in Lafayette Square
      The Damn Delicious has a tasty new address. The signature breakfast sandwich at Kingside Diner is now on the menu in Lafayette Square, where owner Aaron Teitelbaum recently opened his fifth location in the former Rosé by…
  - (2026-11-20) [St. Louis] New pediatric mental health hospital in Webster Groves prepares to open in December
      A new pediatric mental health hospital in Webster Groves is one step closer to welcoming patients, bringing much-needed treatment options to St. Louis-area children and families. On November 18, St. Louis Children’s Hosp…
  - (2026-11-20) [St. Louis] Ask George: If an entrée costs $40, how much should you expect to pay for a half order?
      With diners watching what they spend and how much they eat, a smaller entrée makes sense. The trick for restaurants is finding a price that makes it worth offering and still keeps the proverbial butts in seats. In realit…
  - (2026-11-20) [St. Louis] Webster Groves’ land trust gears up for its first home sale as other cities aim to follow
      Municipalities across the region are working on a new mechanism for homeownership, promising big results in parts of town that working families may otherwise find unattainable. The “community land trust” model, where a l…
  - (2026-11-20) [St. Louis] Where in St. Charles? – 11/20/2026
      Let’s see how well you know St. Charles. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess”…
  - (2026-11-20) [St. Louis] What’s True in the Lou? – 11/20/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…

### Chinese Internal News — 192 new of 293 total
  - (2026-11-19) 尼泊尔国会议员塔帕：对高山问题没能进入COP31主议程感到失望 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1HYndmcmVrdW1ZZVBfYlQxd3JRNGZ0bHJXbkk3alFRZHhBeWZDOHJWQ2xmVXh4MlNJakE1Vmh6ZndQRnpTVzdqYU] (zh:…
      尼泊尔国会议员塔帕：对高山问题没能进入COP31主议程感到失望 财新
  - (2026-11-20) 黑海边被抛弃的度假天堂｜高加索散记 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBYdzVpQTZzWXoybkFfZ3RfazM0RFd6VkFJSWQ0NGpmQl9ma2NZMFNxY3lzZmNsVFFmNk9SbFJIdVZ2MW9Xc3ZGcnlJY1UwbTVBV1g0] (zh:…
      黑海边被抛弃的度假天堂｜高加索散记 财新
  - (2026-11-21) 相隔大西洋的两个天才｜AI历史① - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9pRHl4M0RvdVEtQXhnMHVXeTByaWd0VV9vTlZTM3k5MGxHajZSdF9ibERDbmRXWndkT0FsamhrdDVobFR3ZjB2ZW5TbkhmdV9aaHU2M] (zh:…
      相隔大西洋的两个天才｜AI历史① 财新
  - (2026-11-20) 下周前瞻：台湾地区“九合一”选举投票；西班牙举行大选 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE1IcXE4ZFpJOG5vOGJwRnpEbkV3a2tJdF9EcVlZNE5XVFl2bVduM3JhWTk2el9ab0hpaFkxY0Mxc1RTbElGQTRKQXZua1k] (zh:…
      下周前瞻：台湾地区“九合一”选举投票；西班牙举行大选 财新
  - (2026-11-20) 重庆信托董事长翁振杰失联(含视频) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5SMXhTNlZUY0RyY0FrLXNpOWJWNEJBNWdETWtYMlptYXowNDFZUC0tNlhibE1ac1RJWENVX1pYb1lVcjJiQWpjSW5Pbmd1NWpkZTFF] (zh:…
      重庆信托董事长翁振杰失联(含视频) 财新
  - (2026-11-20) 图集｜“会干活、能服务” APEC峰会机器人上岗 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1HN0dZb2lSV1oyUHNiU0c2M0dpY2FJTnAySjF4d2FJMmJnSmtjWWJLeC1aMFJTa295YUxFYjItOGcwemJlMGgzY2pJSTEwc] (zh:…
      图集｜“会干活、能服务” APEC峰会机器人上岗 财新

### State Legislative Action — 149 new of 159 total
  - (2026-11-21) [Alaska SB 281] An Act relating to the rural health transformation program; relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating…
      An Act relating to the rural health transformation program; relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating to the interstate medical licensure…
  - (2026-11-20) [Alaska SB 170] An Act relating to gaming; relating to gaming activities on Alaska marine highway system vessels; relating to bingo; relating to pull-tabs and electronic pull-tab systems; relating to…
      An Act relating to gaming; relating to gaming activities on Alaska marine highway system vessels; relating to bingo; relating to pull-tabs and electronic pull-tab systems; relating to the powers of the Department of Tran…
  - (2026-11-21) [Arkansas HB 1009] TO CREATE THE STEP UP ACT; AND TO RAISE THE MINIMUM WAGE RESULTING FROM INITIATED ACT 5 OF 2018.
      TO CREATE THE STEP UP ACT; AND TO RAISE THE MINIMUM WAGE RESULTING FROM INITIATED ACT 5 OF 2018.
  - (2026-11-21) [Arkansas HB 1008] TO AMEND THE MINIMUM WAGE ACT OF THE STATE OF ARKANSAS; TO CREATE THE UPLIFT ACT; AND TO RAISE THE MINIMUM WAGE RESULTING FROM INITIATED ACT 5 OF 2018.
      TO AMEND THE MINIMUM WAGE ACT OF THE STATE OF ARKANSAS; TO CREATE THE UPLIFT ACT; AND TO RAISE THE MINIMUM WAGE RESULTING FROM INITIATED ACT 5 OF 2018.
  - (2026-11-21) [Arkansas HB 1010] TO CREATE THE JUST WAGE ACT; TO AMEND THE LAW RESULTING FROM INITIATED ACT 5 OF 2018; AND TO REPEAL THE AUTHORIZATION TO PAY BELOW MINIMUM WAGE FOR CERTAIN EMPLOYEES AND EMPLOYERS.
      TO CREATE THE JUST WAGE ACT; TO AMEND THE LAW RESULTING FROM INITIATED ACT 5 OF 2018; AND TO REPEAL THE AUTHORIZATION TO PAY BELOW MINIMUM WAGE FOR CERTAIN EMPLOYEES AND EMPLOYERS.
  - (2026-11-20) [Arkansas HB 1006] TO CREATE THE JACKSYN ACT; TO ESTABLISH YOUTH FIREWORK PROTECTION MEASURES IN THIS STATE; TO INCREASE THE AGE TO PURCHASE FIREWORKS; AND TO REQUIRE ADULT SUPERVISION OF MINORS USING…
      TO CREATE THE JACKSYN ACT; TO ESTABLISH YOUTH FIREWORK PROTECTION MEASURES IN THIS STATE; TO INCREASE THE AGE TO PURCHASE FIREWORKS; AND TO REQUIRE ADULT SUPERVISION OF MINORS USING FIREWORKS.

### U.S. Weather + Severe / Climate Outlooks — 122 new of 124 total
  - (2026-11-21) [Severe] Special Marine Warning: Special Marine Warning issued November 21 at 2:45AM EST until November 21 at 4:15AM EST by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Bonita Beach to Englewood FL out 20 NM... Waters from Bonita Beach to Englewood FL out 20 to 60 NM... * Until…
  - (2026-11-21) [Moderate] Rip Current Statement: Rip Current Statement issued November 21 at 2:45AM EST until November 22 at 7:00PM EST by NWS Melbourne FL
      * WHAT...Dangerous rip currents and rough surf. * WHERE...Coastal Volusia, Coastal Indian River, Coastal Saint Lucie, Coastal Martin, Mainland Northern Brevard, Northern Brevard Barrier Islands, Mainland Southern Brevard…
  - (2026-11-21) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-21) [Moderate] Gale Watch: Gale Watch issued November 21 at 2:35AM EST until November 23 at 10:00AM EST by NWS Boston/Norton MA
      * WHAT...South winds 15 to 25 kt with gusts up to 35 kt and seas 4 to 6 feet possible. * WHERE...Nantucket Sound. * WHEN...From Sunday evening through Monday morning. * IMPACTS...Strong winds can cause hazardous seas whi…
  - (2026-11-21) [Moderate] Gale Watch: Gale Watch issued November 21 at 2:35AM EST until November 23 at 10:00AM EST by NWS Boston/Norton MA
      * WHAT...South winds 15 to 25 kt with gusts up to 35 kt and seas 6 to 11 feet possible. * WHERE...Coastal waters from Provincetown MA to Chatham MA to Nantucket MA out 20 NM. * WHEN...From Sunday evening through Monday m…
  - (2026-11-21) [Moderate] Gale Watch: Gale Watch issued November 21 at 2:35AM EST until November 23 at 10:00AM EST by NWS Boston/Norton MA
      * WHAT...South winds 15 to 25 kt with gusts up to 35 kt and seas 9 to 14 feet possible. * WHERE...In Massachusetts coastal waters, Coastal Waters extending out to 25 NM South of Marthas Vineyard and Nantucket. In Rhode I…

### GDELT GKG — themes / entities / watch areas — 118 new of 118 total
  - (2026-11-21) [Russia oil sanctions perimeter · themes] World News: Russia's missile and drone strikes kill eight in Ukraine
      gdnonline.com · English · tone -6.98027314112291
  - (2026-11-21) [Russia oil sanctions perimeter · near] Trump cites good talks with Putin on Ukraine, holds back on security guarantees
      dunyanews.tv · English · tone -1.44578313253012 · 15 other outlets
  - (2026-11-21) [Russia oil sanctions perimeter · near] US offers Ukraine membership in Nato if it gives up land to Russia: report
      independent.co.uk · English · tone -1.44927536231884 · 11 other outlets
  - (2026-11-21) [Russia oil sanctions perimeter · near] Russian missile hits Poland as Ukraine's allies hold military exercise, says Tusk - International
      dailymirror.lk · English · tone -6.14035087719298 · 9 other outlets
  - (2026-11-21) [Russia oil sanctions perimeter · near] Russia Humiliates Kushner Over His Big Claim on Peace Talks
      thedailybeast.com · English · tone -0.70298769771529 · 8 other outlets
  - (2026-11-21) [Russia oil sanctions perimeter · near] 'So what if there's a hole? It hasn't collapsed': Kyiv residents unbothered by Russian attacks on city's bridges | Ukraine
      theguardian.com · English · tone -4.69867211440245 · 4 other outlets

### World News (by country, top stories) — 108 new of 108 total
  - (2026-11-21) [Brazil] Brazil's former president Jair Bolsonaro has been hospitalized again, son says
      abc17news.com · English · 2 other outlets ran this story
  - (2026-11-21) [Brazil] From Custom Builds to Off-Road Test Drives, JETOUR's Fan Festival in Brazil Showcases a Diverse Product Lineup
      manilatimes.net · English
  - (2026-11-21) [Brazil] Storm kills 3, injures dozens in southern Brazil
      brazilsun.com · English
  - (2026-11-21) [Brazil] Arsenal is fighting Tottenham for Brazilian teenager
      justarsenal.com · English
  - (2026-11-21) [Brazil] Brazil Condemns Drone Debris at Kyiv Embassy
      riotimesonline.com · English
  - (2026-11-21) [Brazil] Brazil's Record Sugar Exports And Surging Output Crush Futures Prices To Five-Month Lows
      foreignpolicyjournal.com · English

### Ukraine Theater (total-war monitoring) — 97 new of 280 total
  - (2026-11-21) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-20) [Liveuamap] A medic was killed in a follow-up drone strike… - Liveuamap
      A medic was killed in a follow-up drone strike… Liveuamap
  - (2026-11-20) [Liveuamap] A new wave of… – Chernihiv Oblast, Ukraine - Liveuamap
      A new wave of… – Chernihiv Oblast, Ukraine Liveuamap
  - (2026-11-19) [Liveuamap] Satellite images of the Kerch Bridge – Crimea - Liveuamap
      Satellite images of the Kerch Bridge – Crimea Liveuamap
  - (2026-11-19) [Liveuamap] Trump leaves China after participating in the "APEC" forum and a trilateral summit with Xi and Putin - Liveuamap
      Trump leaves China after participating in the "APEC" forum and a trilateral summit with Xi and Putin <font color="#6f6
  - (2026-11-17) [Liveuamap] 2 people wounded as result of Russian strike in Dnipro city – Dnipropetrovsk Oblast, Ukraine - Liveuamap
      2 people wounded as result of Russian strike in Dnipro city – Dnipropetrovsk Oblast, Ukraine <font color="#6f6f6f

### Ukrainian Internal News (national + local Kyiv) — 75 new of 138 total
  - (2026-11-21) Зеленський очікує єдності у підтримці України від новообраного Конгресу | LEDE: Президент Зеленський висловив сподівання, що наступний Конгрес США збереже двопартійну підтримку України та допом] (uk:…
      Президент Зеленський висловив сподівання, що наступний Конгрес США збереже двопартійну підтримку України та допоможе у питаннях оборони.
  - (2026-11-21) У Києві двоє постраждалих через падіння уламків безпілотника – Кличко | LEDE: Внаслідок атаки 21 листопада у Києві загорілися приватні будинки, двоє людей постраждали. У місті тричі оголошували] (uk:…
      Внаслідок атаки 21 листопада у Києві загорілися приватні будинки, двоє людей постраждали. У місті тричі оголошували повітряну тривогу.
  - (2026-11-21) США оголосили нові санкції проти Ірану, націлені на нафтовий сектор | LEDE: ] (uk: США оголосили нові санкції проти Ірану, націлені на нафтовий сектор)
  - (2026-11-21) З чого починається свобода? | LEDE: Спогади Мирослави Гонгадзе про боротьбу за правду після зникнення чоловіка і роль особистого вибору у суспільних змінах.] (uk: З чого починається свобода?)
      Спогади Мирослави Гонгадзе про боротьбу за правду після зникнення чоловіка і роль особистого вибору у суспільних змінах.
  - (2026-11-21) Я знаю тут кожен очерет. Історія херсонця Верещаки, який просто любив рибалити, а став Героєм України | LEDE: ] (uk: Я знаю тут кожен очерет. Історія херсонця Верещаки, який просто любив рибалити, )
  - (2026-11-21) Росія атакувала Україну трьома балістичними ракетами та 148 дронами – влучила на 19 локаціях | LEDE: У ніч на 21 листопада Повітряні сили повідомили про відбиття 117 із 148 дронів та трьох раке] (uk:…
      У ніч на 21 листопада Повітряні сили повідомили про відбиття 117 із 148 дронів та трьох ракет РФ. Постраждали 19 локацій, є жертви та поранені.

### GDACS — global disaster alerts — 48 new of 100 total
  - (2026-11-21) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.9M, Depth:43.228km
  - (2026-11-21) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5M, Depth:110.928km
  - (2026-11-21) [Green] Earthquake in Reykjanes Ridge
      Earthquake · Green alert · Reykjanes Ridge · Magnitude 4.9M, Depth:10km
  - (2026-11-21) [Green] Earthquake in Reykjanes Ridge
      Earthquake · Green alert · Reykjanes Ridge · Magnitude 4.9M, Depth:10km
  - (2026-11-21) [Green] Earthquake in Chile
      Earthquake · Green alert · Chile · Magnitude 4.7M, Depth:120.01km
  - (2026-11-21) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 6.7M, Depth:107.991km

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 63 total
  - (2026-11-21) [Krebs on Security] CTO of ‘RansomwareHelp’ Indicted for Wire Fraud
      The chief technology officer and co-founder of ransomwarehelp.com, a six year old Florida business that claimed to use "advanced cryptographic tools" to restore data locked by ransomware, has been charged with wire fraud…
  - (2026-11-21) [TechCrunch] Startup sues Apple in India over tap-to-share contacts feature
      A U.S. startup is seeking $162 million in damages and an injunction to impact iPhone and Apple Watch imports to India.
  - (2026-11-20) [BleepingComputer] Bell Canada says 'agentic' hacker stole enterprise customer data
      Bell Canada has confirmed that an "agentic" threat actor breached its systems on November 17, 2026, and stole enterprise customer data, including information from a system used to order and provision telecommunications c…
  - (2026-11-20) [BleepingComputer] Hackers use autonomous AI tool Cairn to find zero-day, take over server
      Threat actors used the open-source AI penetration-testing framework Cairn to find a previously unknown vulnerability in a medical imaging application. [...]
  - (2026-11-20) [BleepingComputer] Vendor data breach exposes Chase, Visa, Mastercard customer info
      J.P. Morgan Chase warned it suffered a data breach after a cyberattack at a third-party service provider exposed customers' personal information and marketing data. [...]
  - (2026-11-20) [BleepingComputer] Still tracking company passwords in spreadsheets? You’re flying blind.
      Tracking company passwords in spreadsheets can leave IT administrators unaware of weak, reused, or compromised credentials stored and shared outside approved systems. NordPass explains how centralized password management…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-21) [Henderson James Dale Jr] Form 4 (Reporting)
      filed 2026-11-21 02:48 UTC · role: Reporting — Filed: 2026-11-20 AccNo: 0001493152-26-053593 Size: 10 KB
  - (2026-11-21) [Brand Engagement Network Inc.] Form 4 (Issuer)
      filed 2026-11-21 02:48 UTC · role: Issuer — Filed: 2026-11-20 AccNo: 0001493152-26-053593 Size: 10 KB
  - (2026-11-21) [Devereaux Terah L] Form 4 (Reporting)
      filed 2026-11-21 02:35 UTC · role: Reporting — Filed: 2026-11-20 AccNo: 0000910606-26-000075 Size: 6 KB
  - (2026-11-21) [REGENCY CENTERS CORP] Form 4 (Issuer)
      filed 2026-11-21 02:35 UTC · role: Issuer — Filed: 2026-11-20 AccNo: 0000910606-26-000075 Size: 6 KB
  - (2026-11-21) [Reeves William Brian Poppic] Form 4 (Reporting)
      filed 2026-11-21 02:30 UTC · role: Reporting — Filed: 2026-11-20 AccNo: 0001193125-26-470741 Size: 6 KB
  - (2026-11-21) [Fold Holdings, Inc.] Form 4 (Issuer)
      filed 2026-11-21 02:30 UTC · role: Issuer — Filed: 2026-11-20 AccNo: 0001193125-26-470741 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-21) [United States] Who is Jonathan Rinderknecht? 30-year-old found guilty of starting the devastating 2025 Palisades fire in Los Angeles that killed 12
      domain: indiatimes.com · language: English · tone: -8.17051509769094 · 137 other outlets ran this story
  - (2026-11-21) [United States] Exam on Fiona, beloved Cincinnati Zoo hippo, reveals details about her cause of death
      domain: fox10phoenix.com · language: English · tone: 0.928381962864722 · 88 other outlets ran this story
  - (2026-11-21) [United Kingdom] The UK and EU hold a rare summit to strengthen ties as Burnham seeks to mend Brexit damage
      domain: independent.co.uk · language: English · tone: 0.390625 · 74 other outlets ran this story
  - (2026-11-21) [United Kingdom] EU, UK to spend year brainstorming future ties
      domain: rte.ie · language: English · tone: -1.49812734082397 · 69 other outlets ran this story
  - (2026-11-21) [United States] Judge approves $7.25bn Bayer settlement for Roundup cancer claims
      domain: bbc.co.uk · language: English · tone: -8.18713450292397 · 65 other outlets ran this story
  - (2026-11-21) [Iran] S&P 500 sinks 3.7% and Nasdaq composite goes negative for the year as tech sell-off worsens
      domain: asiaone.com · language: English · tone: -3.99221032132425 · 61 other outlets ran this story

### Court opinions of consequence (federal & state) — 37 new of 60 total
  - (2026-11-20) U.S. Court of Appeals, 6th Cir.: United States v. Norman Charles Rhodes
  - (2026-11-20) U.S. Court of Appeals, D.C. Cir.: Mercuria Energy Group Limited v. Republic of Poland
  - (2026-11-20) U.S. Court of Appeals, D.C. Cir.: Nicholas Voegeli v. Hung Cao
  - (2026-11-20) Supreme Court of Alabama: In re: Jeremy Pruitt v. National Collegiate Athletic Association
  - (2026-11-20) Supreme Court of Alabama: In re: Steven Burns v. Meta Platforms, Inc.
  - (2026-11-20) Supreme Court of Alabama: In re: Suzanne M. Willmon v. First State Bank of DeKalb County, Casey S. Handrich, and Louis Crowder

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Wikidata leader-roster changes (48h) — 27 new of 54 total
  - (2026-11-21) [Chad] Mahamat Déby (Q16206405) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73576|batch #73576]]: Import P106 from GND
  - (2026-11-21) [El Salvador] Nayib Bukele (Q17712353) edited
      /* wbsetsitelink-add:1|sqwiki */ Nayib Bukele, Connected to a new article created with Article guidance
  - (2026-11-21) [Mozambique] Daniel Chapo (Q97058466) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73576|batch #73576]]: Import P106 from GND
  - (2026-11-21) [Timor-Leste] Xanana Gusmão (Q11509) edited
      /* wblinktitles-connect:2| */ enwiki:Xanana Gusmão, bclwiki:Xanana Gusmão
  - (2026-11-21) [United Arab Emirates] Mohammed bin Rashid Al Maktoum (Q57655) edited
      /* wbsetsitelink-add:1|idwikiquote */ Mohammed bin Rasyid al-Maktoum
  - (2026-11-20) [Cameroon] Paul Biya (Q57272) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73565|batch #73565]]: Import P39 from GND

### Paper Trading Scorecard — 24 new of 77 total
  - (2026-11-21) [Polymarket] Variational FDV above $100M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Variational's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-11-21) [Manifold] Will every team that makes the College Football Playoff outperform their school's basketball team for the 26-27 season?
  - (2026-11-21) [Manifold] Will the Clay Mathematics Institute post a website statement on the claimed Riemann hypothesis proof by Dec 31, 2026?
  - (2026-11-21) [Manifold] US, China, Russia first nuclear-risk meeting before Feb 2027?
  - (2026-11-21) [Manifold] Will the S&P 500 close at or below 6,646.09 (15% under its record close) by January 31, 2027?
  - (2026-11-21) [Manifold] Will P vs NP be resolved by Nov 20, 2027?

### EPSS — highest exploit-probability CVEs — 18 new of 40 total
  - (2026-11-20) CVE-2026-99804: 0% exploit probability (p22.8)
      EPSS 0.003 · percentile 0.228
  - (2026-11-20) CVE-2026-99803: 0% exploit probability (p25.5)
      EPSS 0.003 · percentile 0.255
  - (2026-11-20) CVE-2026-99802: 0% exploit probability (p20.3)
      EPSS 0.003 · percentile 0.203
  - (2026-11-20) CVE-2026-99801: 0% exploit probability (p20.3)
      EPSS 0.003 · percentile 0.203
  - (2026-11-20) CVE-2026-99800: 0% exploit probability (p20.3)
      EPSS 0.003 · percentile 0.203
  - (2026-11-20) CVE-2026-99799: 0% exploit probability (p22.8)
      EPSS 0.003 · percentile 0.228

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 101 total
  - (2026-11-20) [OFAC] Iran Designations; Issuance of Cuba Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran Designations; Issuance of Cuba Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-11-20) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-11-21) [USASpending] $10,518,178,993 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration. Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF…
  - (2026-11-21) [USASpending] $4,429,530,857 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WI
      Agency: National Aeronautics and Space Administration. Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOLID…
  - (2026-11-21) [USASpending] $3,865,509,200 → PANTEXAS DETERRENCE, LLC: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION
      Agency: Department of Energy. Description: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION OF THE PANTEX PLANT
  - (2026-11-21) [USASpending] $2,544,388,480 → ASSOCIATION OF UNIVERSITIES FOR RESEARCH IN ASTRONOMY, INC.: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT INCLUDE THE FI
      Agency: National Aeronautics and Space Administration. Description: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT INCLUDE THE FINAL SERVICING MISSION AND SUBSEQUENT OPERATIONS THROUGH END-OF-MISSION. THESE ACTIVITIES INC…

### USGS earthquakes (M4.5+, past day) — 15 new of 15 total
  - (2026-11-21) M 6.7 - 9 km NE of Carhuamayo, Peru
      M6.7 · 9 km NE of Carhuamayo, Peru · depth 107.991 km · TSUNAMI
  - (2026-11-20) M 5.4 - Carlsberg Ridge
      M5.4 · Carlsberg Ridge · depth 10 km
  - (2026-11-20) M 5.1 - 32 km NE of Port-Olry, Vanuatu
      M5.1 · 32 km NE of Port-Olry, Vanuatu · depth 94.53 km
  - (2026-11-20) M 5.1 - 15 km SSW of Balangonan, Philippines
      M5.1 · 15 km SSW of Balangonan, Philippines · depth 73.392 km
  - (2026-11-21) M 5.0 - 0 km NE of Carhuamayo, Peru
      M5.0 · 0 km NE of Carhuamayo, Peru · depth 110.928 km
  - (2026-11-20) M 5.0 - southeast of the Loyalty Islands
      M5.0 · southeast of the Loyalty Islands · depth 10 km

### Campaign finance (FEC: top fundraisers + recent filings) — 14 new of 27 total
  - (2026-11-19) [F2] BEGICH, NICHOLAS III
      cycle 2026 · filing #2048623
  - (2026-11-19) [F1] FIGHT LIKE HELL PAC
      cycle 2026 · filing #2048527
  - (2026-11-19) [F3] VICIAN FOR CONGRESS
      cycle 2026 · filing #2048522
  - (2026-11-19) [F3] MARK FOR NEBRASKA
      cycle 2026 · filing #2048561 · receipts $0.01M
  - (2026-11-19) [F3X] THE EQUITY ALLIANCE FUND ACTION PAC
      cycle 2026 · filing #2048578 · receipts $0.00M
  - (2026-11-19) [F3] DAVENPORT FOR CONGRESS
      cycle 2026 · filing #2048518

### Government & military aircraft airborne (OpenSky) — 14 new of 16 total
  - (2026-11-21) JAF34G (Belgium)
      icao24: 44d1ba · position: (35.2495, 10.9046) · alt: 8199m · 659km/h
  - (2026-11-21) JAF91T (Belgium)
      icao24: 44d1a6 · position: (36.479, -6.8863) · alt: 11277m · 767km/h
  - (2026-11-21) JAF63D (Belgium)
      icao24: 44d1b4 · position: (44.0699, -0.8618) · alt: 11277m · 754km/h
  - (2026-11-21) JAF95D (Belgium)
      icao24: 44d1a1 · position: (36.7338, -4.6098) · alt: 502m · 276km/h
  - (2026-11-21) NCR872 (United States)
      icao24: a7488c · position: (34.4113, -95.6497) · alt: 10668m · 937km/h
  - (2026-11-21) NCR4880 (United States)
      icao24: ad3c48 · position: (21.3821, 84.3624) · alt: 9753m · 900km/h

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-11-21) Will Bitcoin dip to $55,000 by December 31, 2026?
      yes price: 70% · 24h volume: $700,685 · resolves 2027-01-01
  - (2026-11-21) Will China invade Taiwan by end of 2026?
      yes price: 2% · 24h volume: $506,716 · resolves 2027-01-01
  - (2026-11-21) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 0% · 24h volume: $498,585 · resolves 2027-01-01
  - (2026-11-21) Will Vivek Ramaswamy win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $374,489 · resolves 2028-11-08
  - (2026-11-21) Will Shakhtar Donetsk win the 2026-27 UEFA Champions League Championship?
      yes price: 0% · 24h volume: $301,294 · resolves 2027-05-30
  - (2026-11-21) UFC Fight Night: Aljamain Sterling vs. Kevin Vallejos (Featherweight, Main Card)
      yes price: 46% · 24h volume: $283,697 · resolves 2026-11-22

### U.S. Federal Action — 12 new of 17 total
  - (2026-11-23) Establishment of Class E Airspace; Columbus, TX
      This action proposes to establish Class E airspace at Columbus Community Hospital Heliport, Columbus, TX. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-11-23) Amendment of Class E Airspace; Del Rio, TX
      This action amends the Class E airspace at Del Rio, TX. This action is the result of a biennial review of the airspace associated with Laughlin Air Force Base (AFB), Del Rio, TX. This proposal also updates the name and g…
  - (2026-11-23) Connect America Fund; A National Broadband Plan for Our Future High-Cost Universal Support, Reforming the High-Cost Program for an All-IP Future, Safeguarding Universal Service Funding Through Effecti…
      In this document, the Federal Communications Commission (FCC or Commission) initiates a rulemaking to establish a vetting process for applicants for, and other recipients of, certain new funding awards of high-cost Unive…
  - (2026-11-23) Amendment of Class D and E Airspace and Removal of Class E Airspace Over Lebanon, NH
      This action proposes to amend Class D and Class E airspace over Lebanon, NH. This action would increase the lateral dimensions of the Lebanon, NH, Class D airspace to appropriately contain Instrument Flight Rules (IFR) o…
  - (2026-11-23) Horse Protection Amendments; Extension of Postponement of Regulations
      On May 8, 2024, we published a final rule amending the horse protection regulations. The final rule was initially scheduled to go into effect on February 1, 2025, except for Sec. 11.19, which was effective on June 7, 202…
  - (2026-11-23) Cybersecurity Labeling for Internet of Things
      In this document, the Public Safety and Homeland Security Bureau (Bureau) of the Federal Communications Commission (Commission or FCC) seeks comment on recommendations for the U.S. Cyber Trust Mark (USCTM) program, a vol…

### Commentary & analysis (last 7 days) — 9 new of 9 total
  - (2026-11-21) [Marginal Revolution] *The Great Enrichment*
      The author is my colleague Vincent Geloso and the subtitle is A New History of American Growth and Inequality, 1865-1945. Here is an excerpt from the very beginning: …regardless of what improvements you think occurred du…
  - (2026-11-21) [Marginal Revolution] Emergent Ventures, 60th cohort
      Faris Allafi, Abu Dhabi, 13, train AI models. Eliel Selin, Helsinki, 18, AI agents. Robert Boswall, London area, energy information for the UK. Alex Yang, Harvard, genetics for better organ transplants. Stanislaw Tomasze…
  - (2026-11-20) [Adam Tooze] Top Links 1291 The sovereign debt-hedge fund connection. Eurozone inflation dynamics. Armoured tractors and scraping the paint off a Lamborghini.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze
  - (2026-11-20) [Noah Smith] Does it really matter if there’s an intelligence explosion?
      Maybe this is the wrong frame for the AI safety discussion.
  - (2026-11-20) [Marginal Revolution] What should I ask Walter Isaacson?
      Yes I will be doing a Conversation with him, in part to celebrate the reissue of his earlier book The Innovators: How a Group of Hackers, Geniuses, and Geeks Created the Digital Revolution. And also to celebrate his new…
  - (2026-11-19) [Adam Tooze] Top Links 1290 Chips overtake oil and gas. Deutsche’s troubles. Right Hegelians in the Federal Republic and Ras Tafari at the ILO.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 21 total
  - (2026-11-20) CVE-2026-129448 · Apache Roller: Apache Roller Deserialization of Untrusted Data Vulnerability
      vendor: Apache · product: Roller · CISA remediation by 2026-11-23
  - (2026-11-20) CVE-2026-123890 · Broadcom VMware vCenter: VMWare vCenter Authentication Bypass Using an Alternate Path or Channel Vulnerability
      vendor: Broadcom · product: VMware vCenter · CISA remediation by 2026-11-23
  - (2026-11-20) CVE-2025-42884 · SAP NetWeaver: SAP NetWeaver Improper Neutralization of Special Elements in Data Query Logic Vulnerability
      vendor: SAP · product: NetWeaver · CISA remediation by 2026-11-23
  - (2026-11-20) CVE-2026-76466 · Cisco Expressway Series: Cisco Expressway Series Use of Hard-coded Credentials Vulnerability
      vendor: Cisco · product: Expressway Series · CISA remediation by 2026-11-23

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 40 total
  - (2026-11-21) MOVER ▼ Michael Dell — $181.81B ($-17.17B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-11-21) MOVER ▼ Thomas Peterffy — $83.75B ($-4.86B since yesterday)
      United States · Finance & Investments · source: Discount brokerage

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-11-20) Ebola disease caused by Bundibugyo virus- Democratic Republic of the Congo, Kenya and Nigeria
      Since the publication of the previous Disease Outbreak News on 6 November 2026, additional confirmed cases and deaths have been reported in the Democratic Republic of the Congo. While some areas have seen a slight declin…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-21) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=17, 14d-median=21; carrying terms: action, standards, directives, final, certain, airplanes, applicable, protection, airworthiness, update, safety, provide
- state_bills: today=159, 7d-median=78, 14d-median=88; carrying terms: state, health, local, public, school, including, business, relating, property, consumer, service, development
- state_news: today=711, 7d-median=711, 14d-median=711; carrying terms: death, losses, family, management, black, leaders, elections, robert, calls, thursday, around, ballot
- local_news: today=257, 7d-median=250, 14d-median=257; carrying terms: death, family, black, stlmag, identified, downtown, georgia, state, charged, weekend, target, police
- foreign_news: today=1012, 7d-median=1012, 14d-median=997; carrying terms: death, family, discuss, title, trial, online, indian, turkish, deadly, capital, warns, according
- chinese_internal: today=293, 7d-median=315, 14d-median=321; carrying terms: title, china, investors, lxtfa, target, cbmib, color, articles, caixin, cbmidefvx, global, cbmix
- russian_internal: today=960, 7d-median=947, 14d-median=947; carrying terms: error, title, media, group, reuters, https, times, forbidden, street, nasdaq, axios, client
- ukrainian_internal: today=138, 7d-median=127, 14d-median=134; carrying terms: against, ministry, error, discuss, title, control, group, strikes, leaders, hmarochos, vechirniy, peace
- ukraine_theater: today=280, 7d-median=277, 14d-median=271; carrying terms: byuryufr, cbmitwfbvv, losses, clinical, panjhubmxuowvlz, tfpvnzi, permit, yemen, avpjdlhilwhhovgwzzfpnuhwowvpmew, tawsycvbhvhvwrlr, jjvgnycxjibzdf, lxtfbavunals
- paper_bets: today=77, 7d-median=77, 14d-median=75; carrying terms: fuentes, jackson, passing, zohran, become, total, successor, named, riemann, evans, leaders, decrease
- weather: today=124, 7d-median=127, 14d-median=130; carrying terms: water, severe, details, afdfwd, discussion, afdlox, front, amounts, gusty, afdsew, washington, afdlsx
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: pcepilfe, implied, labor, consumption, dexjpus, unrate, jtsjol, sheet, effective, money, total, unemployment
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, china, treasury, rates, natural, russell, close, agriculture, corporate, silver, credit, range
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=101, 7d-median=100, 14d-median=99; carrying terms: resolutions, tunisia, against, qaida, burundi, haiti, nicaragua, management, protecting, control, application, performance
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, unauthorized, congresstrading, quantitative, quiver, quiverquant, httperror, https, error
- billionaires: today=40, 7d-median=40, 14d-median=34; carrying terms: zhong, changpeng, google, charles, gates, finance, tadashi, warren, amazon, carlos, francoise, family
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: martin, people, court, supreme, state, company, blanche, appeals, charles, miller, thomas, colorado
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, holdings, william, management, capital, technologies, brian, james, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: jackson, house, krishnamoorthi, james, abdul, jonathan, sherrod, sayed, brown, filing, disbursements, alexandria
- gdelt_regions: today=108, 7d-median=106, 14d-median=101; carrying terms: english, south, japan, korea, trump, china, korean, germany, minister, turkey, nvidia, russia
- gdelt_gkg: today=118, 7d-median=132, 14d-median=118; carrying terms: english, russian, sanctions, keywords, israel, hezbollah, against, netanyahu, dollar, perimeter, russia, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: shooting, murder, police, domain, english, trump, australia, killed, language, injured, crash, county
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=16, 7d-median=22, 14d-median=22; carrying terms: position, belgium, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: manifestations, individual, nigeria, death, brain, ministry, informed, total, cluster, rwampara, report, adult
- cisa_kev: today=21, 7d-median=15, 14d-median=15; carrying terms: google, improper, critical, cisco, product, multiple, check, value, vulnerability, remediation, products, missing
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=54, 7d-median=53, 14d-median=46; carrying terms: property, wbeditentity, wbsetdescription, toollabs, wbsetsitelink, wbsetclaim, update, quickstatements, edited, batch, congo, republic
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: earthquake, forest, magnitude, alert, australia, wildfire, forestfire, south, botswana, fires, depth, burkina
- usgs_quakes: today=15, 7d-median=12, 14d-median=14; carrying terms: depth, islands, ridge, chile, philippines, vanuatu, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, champions, championship, november, league, shakhtar, december, presidential, donetsk, rates
- commentary: today=9, 7d-median=6, 14d-median=6; carrying terms: https, marginal, revolution, marginalrevolution, american, links, research, growth, london, excerpt, books, history
- tech_news: today=63, 7d-median=63, 14d-median=63; carrying terms: techcrunch, friday, added, provides, spectrum, vulnerability, intelligence, access, working, weekly, download, according
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jackson, pocan, griffith, agriculture, bacon, sessions, trade, nikki, jahana, deposit, carlos, orden
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, claude, markets, module, paper, unavailable, sufficient, consensus, today, decision, converges, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] ECB press: Boris Vujčić: Risks and resilience in the euro area financial system
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] ECB press: Frank Elderson: Smart supervision for small banks
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-17] ECB press: Philip R. Lane: The practice and science of monetary policy communication: the ECB experience
- [2026-11-18] ECB press: Boris Vujčić: Financial Stability Review - November 2026
- [2026-11-18] ECB press: Risks from AI valuations, fiscal imbalances and geoeconomic tensions weigh on financial stability outlook
- [2026-11-18] Fed speeches: Barr, Investing in America’s Underserved Communities
- [2026-11-18] Fed press (events + announcements): Minutes of the Federal Open Market Committee, October 27-28, 2026
- [2026-11-19] Fed speeches: Jefferson, Monetary Policy amid Frequent and Complex Shocks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*