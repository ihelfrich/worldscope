# WORLDSCOPE morning brief — 2026-09-04

## Headline
3601 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (815) · Russian Internal News (state + in-exile) (726) · Ukraine Theater (total-war monitoring) (347) · State-Level News (330) · World leaders & government officials (324) · Chinese Internal News (255) · Local News: St. Louis + Atlanta (214) · U.S. Weather + Severe / Climate Outlooks (131) · Ukrainian Internal News (national + local Kyiv) (74) · State Legislative Action (67) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 815 new of 1120 total
  - (2026-09-04) [Global] Controversial Jackdaw gas field set to be approved in weeks, sources say
      The government is set to give the go-ahead for the gas field off the coast of Aberdeen, the BBC understands.
  - (2026-09-04) [Global] Stock up on food to prepare for extreme weather, minister warns
      Dame Angela Eagle warns the weather event could lead to extreme storms this winter.
  - (2026-09-04) [Global] US diesel prices hit an all-time-high
      Fuel prices have soared since the Iran conflict began at the end of February, mirroring the surge in wholesale oil prices.
  - (2026-09-04) [Global] Prosecco, cakes and beauty products - how to get birthday freebies and why there's a catch
      Cake, coffee, make-up and burgers are just some of the free things you can get on your birthday.
  - (2026-09-04) [Global] Volkswagen board approves plan to cut another 50,000 jobs
      The group - which includes Audi, Porsche, Skoda as well as the VW brand - plans to cut a total of 100,000 posts by 2030.
  - (2026-09-04) [Global] From 'dog fruit' to darling: India's avocado boom
      Demand for avocados is booming in India and local growers hope to grab more of the market.

### Russian Internal News (state + in-exile) — 726 new of 1203 total
  - (2026-09-04) Россия закроет Гете-институт — главный центр изучения немецкого языка и культуры. «Медуза» поговорила с россиянами, которые благодаря ему смогли выучить язык, сдать экзамены или переехать в Гер] (ru:…
      Гете-институт появился в 1951 году в ФРГ. Сначала его основной задачей была подготовка иностранных преподавателей немецкого языка, затем институт превратился в место, где учить немецкий и погружаться в культуру страны мо…
  - (2026-09-04) The Kyiv Independent: первый визит представителей Трампа в столицу Украины может сорваться — Стив Уиткофф «начал бояться» | LEDE: Визит американских переговорщиков Стива Уиткоффа и Джареда К] (ru: The…
      Визит американских переговорщиков Стива Уиткоффа и Джареда Кушнера в Киев, о котором накануне объявил президент Украины Владимир Зеленский, может сорваться, пишет The Kyiv Independent со ссылкой на осведомленный источник…
  - (2026-09-04) Власти называют чудом обретение мощей князя Донского и хотят отправить их на фронт. А в чем смысл такого поклонения? Почему святых не хоронят? И мощи ли лежат в Мавзолее? Только стыдные вопросы] (ru:…
      В России только и разговоров, что о мощах: в августе в Архангельском соборе Московского Кремля в ходе реставрации «нашли» саркофаг с хорошо сохранившимися останками князя Дмитрия Донского. Само место захоронения командую…
  - (2026-09-04) Реформа лицензирования связи в России, предложенная Минцифры, оставит 27 регионов без местных интернет-провайдеров | LEDE: Инициатива Минцифры по ужесточению требований к операторам связи ос] (ru: Реф…
      Инициатива Минцифры по ужесточению требований к операторам связи оставит 27 регионов без местных интернет-провайдеров, пишет РБК. Такие данные озвучил директор Ассоциации телекоммуникационных операторов (АСТО) Алексей Ле…
  - (2026-09-04) В Сербии на смартфонах 14 активистов и оппозиционеров нашли шпионское ПО | LEDE: В начале 2026 года, перед местными выборами в Сербии, смартфоны как минимум 14 представителей гражданского об] (ru: В С…
      В начале 2026 года, перед местными выборами в Сербии, смартфоны как минимум 14 представителей гражданского общества подверглись атаке с использованием продвинутого шпионского ПО, сообщает организация Share Foundation, за…
  - (2026-09-04) Грузия не будет выдавать властям РФ россиянина Дениса Куланина. Ему позволят добровольно покинуть страну | LEDE: Россиянину Денису Куланину разрешили выехать из Грузии в третью страну. Выдво] (ru: Гру…
      Россиянину Денису Куланину разрешили выехать из Грузии в третью страну. Выдворять в Россию его не будут. Соответствующее решение, пишет Paper Kartuli, вынес Тбилисский городской суд. Куланину дается семь дней на то, чтоб…

### Ukraine Theater (total-war monitoring) — 347 new of 598 total
  - (2026-09-04) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-03) [FIRMS] thermal anomaly 51.506, 34.233 (FRP 9.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 0905Z, FRP 9.71 MW
  - (2026-09-03) [FIRMS] thermal anomaly 51.503, 34.225 (FRP 7.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 0905Z, FRP 7.25 MW
  - (2026-09-03) [FIRMS] thermal anomaly 51.504, 34.224 (FRP 13.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 0905Z, FRP 13.39 MW
  - (2026-09-03) [FIRMS] thermal anomaly 46.429, 32.520 (FRP 9.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 1043Z, FRP 9.08 MW
  - (2026-09-03) [FIRMS] thermal anomaly 45.275, 34.526 (FRP 2.21 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 1043Z, FRP 2.21 MW

### State-Level News — 330 new of 677 total
  - (2026-09-04) [California] Fact check: Is Sam Altman right that almonds use more water than ChatGPT queries?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/030323-FarmLand-LV_CM_19.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="…
  - (2026-09-03) [California] Why Trump’s demand for trucker records sets off CA privacy alarms
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/01/120224_Drumm-Avenue_CS_CM_13.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-09-03) [California] As California debated sharing data on drivers, Homeland Security subpoenaed 17 million records
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2022/06/102622-TRUCKS-AP-NB-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="Tr…
  - (2026-09-03) [California] Clock is ticking as LA Olympics organizers plan massive spending spree to retool venues
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/090226-Reynold-Hoover-TS-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-09-03) [California] California’s top Democrats struggle but can’t resolve the question of wildfire liability
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/09/010825_Eaton-Power-Lines_CM_22.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-09-03) [California] California schools are sitting on arts money. A change in law might get them to spend it
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/02/121223-SanPasqualDistrict-Winterhaven-KC-CM-6.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 255 new of 286 total
  - (2026-09-04) 被通报停职的“人力资源总监”，查无此岗；星宇股份工作人员：具体是谁不方便透露 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE03cEFxX2U2d25lTzY0Vk9qTnZtQ3doTmNIWXczZklISi1FM1Y3UkVmVWVuc3NjVXBDbHU1VkVMRUJQYUV] (zh:…
      被通报停职的“人力资源总监”，查无此岗；星宇股份工作人员：具体是谁不方便透露 风闻
  - (2026-09-04) 欠下近1.5亿港元巨债？古天乐方回应 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1hZGpXSFgxTWFZUi1DNUxUdXZOMFNhY3pUdUNwRDdQZmlYZ3EtSW5mVWR6bEwzV1Ata0J1WjE2RDVfR1lPeHV6YXlTekItRktTRF] (zh:…
      欠下近1.5亿港元巨债？古天乐方回应 观察者
  - (2026-09-04) CCG名家午餐会2026上半年精彩回顾 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBqamxaakx1VVVvS2lQU1pkVWgtZ00xYkpYbXhUSGNIbnpnS3MwaTAzWElzU09zX3drckNwSS1rSkIwTFlKUVRfWl9kczJ4aHVxOW] (zh:…
      CCG名家午餐会2026上半年精彩回顾 风闻
  - (2026-09-04) 我去过两次尼泊尔，雪山徒步/摄影线路还是非常独一无二的 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBBNHpVcGduZ1JhOUtXTmZ0X1d0SVlGWmE4U1RNSGg0TGlWZmtzdWxvWTRfTzhWRFQ4MFZoMmltZ3RXdGl4QjVtTWNYcj] (zh:…
      我去过两次尼泊尔，雪山徒步/摄影线路还是非常独一无二的 风闻
  - (2026-09-04) “荷兰无意率先对华发难，但…”，荷兰政策科学委员会报告勾勒对华贸易政策转向 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBHdUdaVThoZl9LQUIxb0pDMFFMVEN2bFNiZElqOW45RUh3bFVzNzBwQ2MzRzBvS1gzQ3JsOUx6dTdrdlV] (zh:…
      “荷兰无意率先对华发难，但…”，荷兰政策科学委员会报告勾勒对华贸易政策转向 观察者
  - (2026-09-04) 丁铎：靠叙事换威慑，尝到“甜头”的马尼拉扛得住代价吗？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1ZTU52VVBBSVNBUExiZG1kM2FiMEt0Wm4yZlhXSkQ2OHJoWk5tXzNnd0xfd2RwREMya0VhUFNwa0FidWZRUW5RcUxyY] (zh:…
      丁铎：靠叙事换威慑，尝到“甜头”的马尼拉扛得住代价吗？ 观察者

### Local News: St. Louis + Atlanta — 214 new of 235 total
  - (2026-09-04) [St. Louis] 8020 Restaurant now open in the former Rated Test Kitchen space in downtown St. Louis
      Chef Orlando McKinney Jr. can’t help but laugh when he recalls his initial feelings toward cooking. “I hated it,” McKinney recalls. “My dad had a catering business, so as early as 9 I was with him cutting carrots and oni…
  - (2026-09-04) [St. Louis] Good Clean Dog aims to disrupt the grooming industry with convenience and expert care
      Jennifer Ehlen-Albrecht was waiting in the rain to get her dogs groomed when she had an epiphany. She was outside Amanda’s Pet Grooming, the salon in Webster Groves that groomed her Goldendoodles, Rosie and Buddy, over t…
  - (2026-09-04) [St. Louis] As copper thieves target St. Louis’ riverfront, the city calls in the cavalry
      The Mississippi riverfront in downtown St. Louis has become a hotspot in the city’s cat-and-mouse battle with copper wire thieves—with the city struggling to stay one step ahead of increasingly aggressive thefts. The ill…
  - (2026-09-04) [St. Louis] What’s True in the Lou? – 9/4/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-09-03) [St. Louis] Drew Baldridge heads home for The Big Baldridge & Bonfire
      Drew Baldridge loves himself a good county fair. “You can probably hear them pigs right now,” the country music hitmaker joked before his show at the Rock County 4-H Fair in Janesville, Wisconsin. “They opened the gate a…
  - (2026-09-03) [St. Louis] Fleur STL closes in former Eat-Rite Diner space
      Fleur STL (622 Chouteau), a chef’s reimagination of the former Eat-Rite Diner located several blocks south of Busch Stadium, has closed. The acclaimed 14-seat breakfast-and-lunch spot had not operated regularly since ear…

### U.S. Weather + Severe / Climate Outlooks — 131 new of 132 total
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 6:53AM CDT by NWS Green Bay WI
      At 653 AM CDT, Doppler radar was tracking a strong thunderstorm near Napowan Scout Camp, or 11 miles east of Wautoma, moving east at 40 mph. HAZARD...Wind gusts up to 50 mph and pea size hail. SOURCE...Radar indicated. I…
  - (2026-09-04) [Severe] Flash Flood Warning: Flash Flood Warning issued September 4 at 6:51AM CDT until September 4 at 9:00AM CDT by NWS Milwaukee/Sullivan WI
      At 651 AM CDT, Doppler radar indicated thunderstorms producing heavy rain across the warned area. Between 1 and 3 inches of rain have fallen. The expected rainfall rate is 0.5 to 1.5 inches in 1 hour. Additional rainfall…
  - (2026-09-04) [Moderate] Heat Advisory: Heat Advisory issued September 4 at 6:50AM CDT until September 4 at 8:00PM CDT by NWS Amarillo TX
      * WHAT...Temperatures up to 105 degrees expected. * WHERE...Palo Duro Canyon. * WHEN...From 1 PM this afternoon to 8 PM CDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses.
  - (2026-09-04) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-04) [Severe] Special Marine Warning: Special Marine Warning issued September 4 at 7:35AM EDT until September 4 at 9:00AM EDT by NWS Cleveland OH
      SMWCLE The National Weather Service in Cleveland has issued a * Special Marine Warning for... Nearshore waters from Maumee Bay OH to the Islands OH... Open waters from Maumee Bay OH to The Islands OH... * Until 900 AM ED…
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 3:29AM AKDT by NWS Anchorage AK
      Water levels during high tides today and Saturday morning will peak at 1 foot or less above the normal highest tide line, similar to observed water levels on Thursday morning. At these levels, no flooding is expected. Th…

### Ukrainian Internal News (national + local Kyiv) — 74 new of 137 total
  - (2026-09-04) Україна хоче закрити повітряний простір Росії: чи вдасться план та що станеться з економікою ворога | LEDE: ] (uk: Україна хоче закрити повітряний простір Росії: чи вдасться план та що станеться )
  - (2026-09-04) Зеленський призначив тимчасового голову Запорізької ОВА | LEDE: Володимир Зеленський призначив Михайла Семікіна тимчасово виконувати обов'язки голови Запорізької обласної державної адміністраці] (uk:…
      Володимир Зеленський призначив Михайла Семікіна тимчасово виконувати обов'язки голови Запорізької обласної державної адміністрації. Іван Федоров звільнений з посади.
  - (2026-09-04) 1000 дронів на день: чи може Україна закрити небо над Росією та що відомо про операцію M&M's | LEDE: Володимир Зеленський у вечірньому зверненні 1 вересня заявив, що повітряний простір Росії вж] (uk:…
      Володимир Зеленський у вечірньому зверненні 1 вересня заявив, що повітряний простір Росії вже не буде безпечним – хоче цього країна-агресорка чи ні. Президент України насамперед звернувся до міжнародних авіа та страхових…
  - (2026-09-04) Генштаб: Сили оборони уразили базу пального, місце запуску ударних БпЛА та командні пункти росіян | LEDE: ЗСУ вразили командні пункти, радар, БпЛА та базу пального росіян у Донецькій, Харківськ] (uk:…
      ЗСУ вразили командні пункти, радар, БпЛА та базу пального росіян у Донецькій, Харківській, Луганській, Криму та РФ. Ступінь збитків уточнюється.
  - (2026-09-04) На вихідні в Україні очікуються дощі, синоптики попереджають про сильний вітер | LEDE: Укргідрометцентр прогнозує дощі, штормовий вітер 15-20 м/с і зниження температури в Україні 5–6 вересня.] (uk: На…
      Укргідрометцентр прогнозує дощі, штормовий вітер 15-20 м/с і зниження температури в Україні 5–6 вересня.
  - (2026-09-04) З Польщі депортували українця, якого підозрюють у ножовому пораненні свого земляка | LEDE: 32-річного громадянина України, підозрюваного у нападі на співвітчизника, депортували з Польщі та забо] (uk:…
      32-річного громадянина України, підозрюваного у нападі на співвітчизника, депортували з Польщі та заборонили в’їзд у Шенгенську зону на 5 років.

### State Legislative Action — 67 new of 96 total
  - (2026-09-04) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-09-04) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-09-03) [Alaska HB 193] An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training…
      An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training program account; relating to unempl…
  - (2026-09-03) [Alaska HB 242] An Act relating to sexual assault.
      An Act relating to sexual assault.
  - (2026-09-03) [Alaska HB 77] An Act making the theft of mail or an article within mail theft in the second degree.
      An Act making the theft of mail or an article within mail theft in the second degree.
  - (2026-09-03) [Alaska SB 89] An Act relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating to the practice of medicine; relating to health care…
      An Act relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating to the practice of medicine; relating to health care providers; and relating to provisio…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-04) [LYNCH G PATRICK] Form 4 (Reporting)
      filed 2026-09-04 11:54 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001258554-26-000005 Size: 7 KB
  - (2026-09-04) [NORTHERN TECHNOLOGIES INTERNATIONAL CORP] Form 4 (Issuer)
      filed 2026-09-04 11:54 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0001258554-26-000005 Size: 7 KB
  - (2026-09-04) 424B3 - Veraxa Biotech AG - Post de-SPAC (0002079109) (Filer)
      filed 2026-09-04 11:51 UTC — Filed: 2026-09-04 AccNo: 0001829126-26-009754 Size: 154 KB
  - (2026-09-04) 424B3 - Veraxa Biotech AG - Post de-SPAC (0002079109) (Filer)
      filed 2026-09-04 11:48 UTC — Filed: 2026-09-04 AccNo: 0001829126-26-009753 Size: 152 KB
  - (2026-09-04) 40-17G - Horizon Technology Finance Corp (0001487428) (Filer)
      filed 2026-09-04 11:46 UTC — Filed: 2026-09-04 AccNo: 0001487428-26-000001 Size: 2 MB
  - (2026-09-04) [Liu Chang] Form 4 (Reporting)
      filed 2026-09-04 11:39 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001193125-26-382783 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-04) [Nigeria] Malawi : DPP Issues Blistering Rebuke to Speaker Over Competing Center of Power
      domain: allafrica.com · language: English · tone:
  - (2026-09-04) [United States] Bethlehem man climbs Kilimanjaro , raises $55K for Boys & Girls Club
      domain: wfmz.com · language: English · tone:
  - (2026-09-04) [United States] Meteor Missile Remains In The Fight As Successor Takes Shape
      domain: aviationweek.com · language: English · tone:
  - (2026-09-04) [United Kingdom] Britain commitment to Falkland Islands absolute and unshakeable – Streeting
      domain: darlingtonandstocktontimes.co.uk · language: English · tone:
  - (2026-09-04) [Nigeria] Malawi : Portable Water Testing Labs Rolled Out Across Malawi to Catch Deadly Cholera Contamination Before Outbreaks Strike
      domain: allafrica.com · language: English · tone:
  - (2026-09-04) [United States] Trump administration rule would end tax exemption for colleges that keep DEI
      domain: wdbo.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 56 total
  - (2026-09-04) [BleepingComputer] Google warns of new Chrome zero-day flaw exploited in attacks
      Google has updated the Chrome browser to address an actively exploited high-severity zero-day flaw in the V8 engine and 11 other vulnerabilities. [...]
  - (2026-09-04) [The Hacker News] Over 440,000 Exploit Attempts Target Super Forms and Elementor Pro RCE Flaws
      Threat actors are exploiting two critical security flaws in WordPress plugins Super Forms and Elementor Pro, according to findings from Wordfence. The vulnerabilities in question are - CVE-2026-14894 (CVSS score: 9.8) -…
  - (2026-09-04) [The Hacker News] Plex Urges Immediate Updates After Patching Multiple Undisclosed Security Flaws
      Plex is urging users to update their instances to the latest version following the release of an update that patches multiple security flaws. The fixes are available in Plex Media Server 1.43.3 and Plex Desktop 1.115.0.…
  - (2026-09-04) [The Hacker News] Google Releases Chrome Update to Patch Actively Exploited V8 Zero-Day
      Google on Thursday released security updates to patch 12 vulnerabilities, including one that has come under active exploitation in the wild. The high-severity vulnerability, tracked as CVE-2026-85046 (CVSS score: 8.8), h…
  - (2026-09-04) [The Hacker News] GPT-6 Astra Scores 100% on ExploitBench as OpenAI Blocks PoC Exploit Requests
      OpenAI on Thursday officially unveiled GPT‑6 Astra, which it described as the "world's most intelligent and aligned model." The development comes days after the artificial intelligence (AI) company said the model had rea…
  - (2026-09-04) [Schneier on Security] Security Vulnerability in a Voting System
      It’s a vulnerability that allows someone to recover the order of ballots cast, newly exploited with AI tools. Nearly four years since the original vulnerability was disclosed, I was still able to use it to analyze voter…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 30 new of 60 total
  - (2026-09-08) Connecticut Supreme Court: Perez v. Carusillo
  - (2026-09-03) U.S. Court of Appeals, 8th Cir.: BNSF Railway Company v. U.S. Dept. of Labor
  - (2026-09-03) U.S. Court of Appeals, 8th Cir.: Pennsylvania Insurance Company v. Federal Express Corporation
  - (2026-09-03) U.S. Court of Appeals, 8th Cir.: The Iowa Farm Sanctuary v. Univ. of MO Vet Health Center
  - (2026-09-03) U.S. Court of Appeals, 8th Cir.: XTO Energy, Inc. v. Commerce and Industry Ins. Co.
  - (2026-09-03) U.S. Court of Appeals, 11th Cir.: Dominick Russo v. Secretary, U.S. Department of Commerce

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-09-04) JAF4KN (Bulgaria)
      icao24: 4520ce · position: (44.7454, -0.1483) · alt: 11277m · 763km/h
  - (2026-09-04) JAF5GA (Bulgaria)
      icao24: 4520aa · position: (35.6062, -5.3501) · alt: 11894m · 807km/h
  - (2026-09-04) GAF182 (Germany)
      icao24: 3e8b41 · position: (48.3829, 11.2895) · alt: 9745m · 749km/h
  - (2026-09-04) PAT352 (United States)
      icao24: adfe4b · position: (38.9628, -78.2867) · alt: 4556m · 431km/h
  - (2026-09-04) GAF254 (Germany)
      icao24: 3ea653 · position: (53.0301, 0.1493) · alt: 3040m · 539km/h
  - (2026-09-04) SAMU44 (France)
      icao24: 39ca84 · position: (47.096, -1.5277) · alt: 304m · 237km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-09-04) [Russia oil sanctions perimeter · themes] India BoP likely to post USD 60 - 65 bn surplus in FY27 despite wider CAD : HDFC Bank
      asiabulletin.com · English · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] „ Wunderhaus : Hier überlebte eine Familie die Sturzflut von Nepal
      tz.de · German · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] Και η Ενωτική Ομοσπονδία Αγροτοκτηνοτροφικών Συλλόγων Ηρακλείου στο συλλαλητήριο της ΔΕΘ
      cretalive.gr · Greek · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] Britain commitment to Falkland Islands absolute and unshakeable – Streeting
      darlingtonandstocktontimes.co.uk · English · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] 微循环决定大健康 ： 百慕迪Bioboosti R7日常养护理疗方案
      finance.sina.com.cn · Chinese · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] Ukraine - Krieg im Liveticker : +++ 11 : 41 Zwei Tote bei ukrainischem Drohnenangriff in russischer Region Brjansk +++
      n-tv.de · German · tone NA

### Paper Trading Scorecard — 23 new of 134 total
  - (2026-09-04) [Polymarket] Will Faker win a Finals MVP Award at an international event in 2026?
      The market will resolve to "Yes" if Lee "Faker" Sang-hyeok is officially announced as the Finals MVP of any international event in 2026 (such as First Stand, MSI, Esports World Cup, Worlds, or any other officially recogn…
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2036
      December 2036
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2035
      December 2035
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2034
      December 2034
  - (2026-09-04) [Manifold] Nigel Farage out as Reform UK Leader before 1st March 2027?
  - (2026-09-04) [Manifold] 🇮🇷 Will the UN Security Council renew the Iran sanctions Panel of Experts mandate on September 17, 2026?

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-09-03) M 5.5 - 100 km S of Nikolski, Alaska
      M5.5 · 100 km S of Nikolski, Alaska · depth 10 km
  - (2026-09-03) M 5.3 - 104 km SSW of Nikolski, Alaska
      M5.3 · 104 km SSW of Nikolski, Alaska · depth 10 km
  - (2026-09-04) M 5.2 - 28 km S of Cilacap, Indonesia
      M5.2 · 28 km S of Cilacap, Indonesia · depth 10 km
  - (2026-09-03) M 5.2 - 271 km SSE of Dunhuang, China
      M5.2 · 271 km SSE of Dunhuang, China · depth 10 km
  - (2026-09-03) M 5.2 - 100 km SSW of Nikolski, Alaska
      M5.2 · 100 km SSW of Nikolski, Alaska · depth 10 km · TSUNAMI
  - (2026-09-03) M 5.1 - Owen Fracture Zone region
      M5.1 · Owen Fracture Zone region · depth 10 km

### U.S. Federal Action — 14 new of 18 total
  - (2026-09-04) Geographic Targeting Order Imposing Recordkeeping and Reporting Requirements on Certain Money Services Businesses Along the Southwest Border
      FinCEN is issuing this Geographic Targeting Order, requiring certain money services businesses along the southwest border of the United States to report and retain records of transactions in currency of $1,000 or more, b…
  - (2026-09-04) Transfer Agent Rules
      The U.S. Securities and Exchange Commission ("SEC" or "Commission") is proposing to adopt new rules, amend existing rules, amend the existing form for registration with the Commission as a transfer agent (Form TA-1) and…
  - (2026-09-04) Reducing Bureaucracy and Burden for the Repatriation of Mentally Ill Nationals
      The Department of Health and Human Services, Administration for Children and Families proposes to remove the Care and Treatment of Mentally Ill Nationals of the United States, Returned from Foreign Countries regulations…
  - (2026-09-04) Drawbridge Operation Regulation; Savannah River, Clyo, GA
      The Coast Guard is removing the existing drawbridge operation regulation for the CSX Transportation railroad bridge, mile 60.9, near Clyo, GA. The drawbridge was converted to a fixed bridge in August 2026, and the operat…
  - (2026-09-04) Driving Efficiency in Farm Loan Delivery
      The Farm Service Agency (FSA) is amending the Farm Loan Program (FLP) regulations to permanently implement the Application Fast Track (AFT) process, which expedites underwriting for certain direct loan applicants by usin…
  - (2026-09-04) Modernizing Medical Standards for Non-Insulin Dependent Diabetes Mellitus Cases
      FAA proposes to amend its regulations to allow applicants with non-insulin dependent diabetes mellitus to apply for airman medical certification that may be issued at the time of their medical examination instead of requ…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-04) LoL: KT Rolster vs Dplus KIA (BO5) - LCK Playoffs
      yes price: 0% · 24h volume: $2,371,449 · resolves 2026-09-04
  - (2026-09-04) Will John Thune win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $1,204,205 · resolves 2028-11-07
  - (2026-09-04) LoL: KT Rolster vs Dplus KIA - Game 4 Winner
      yes price: 0% · 24h volume: $1,174,679 · resolves 2026-09-04
  - (2026-09-04) LoL: KT Rolster vs Dplus KIA - Game 2 Winner
      yes price: 0% · 24h volume: $959,652 · resolves 2026-09-04
  - (2026-09-04) LoL: KT Rolster vs Dplus KIA - Game 3 Winner
      yes price: 0% · 24h volume: $950,194 · resolves 2026-09-04
  - (2026-09-04) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 12% · 24h volume: $863,350 · resolves 2027-01-01

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 101 total
  - (2026-09-03) [OFAC] Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License - Office of Foreign Assets Control (.gov)
      Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License Office of Foreign Assets Control (.gov)
  - (2026-09-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)
  - (2026-09-04) [USASpending] $4,429,530,857 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WI
      Agency: National Aeronautics and Space Administration. Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOLID…
  - (2026-09-04) [USASpending] $1,282,404,815 → CSI AVIATION, INC: THIS CALL ORDER OBTAINS DEDICATED AND ON-DEMAND CHARTERED FL
      Agency: Department of Homeland Security. Description: THIS CALL ORDER OBTAINS DEDICATED AND ON-DEMAND CHARTERED FLIGHT SERVICES FOR ENFORCEMENT AND REMOVAL OPERATIONS UNDER THE ICE AIR PROGRAM. ICE AIR FACILITATES THE SA…
  - (2026-09-04) [USASpending] $1,061,183,201 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)
  - (2026-09-04) [USASpending] $1,018,396,052 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-04) [Marginal Revolution] Real GDP Per Capita and the Standard of Living
      We are freshening up some of our videos with updated data so now is a good time to remind everyone that Modern Principles of Economics is best principles of economics textbook; great videos, clear writing and excellent a…
  - (2026-09-04) [Marginal Revolution] Shout it from the rooftops (of the data centers)
      Data-center investment has become one of the largest capital-expenditure cycles in financial markets, with U.S. hyperscalers expected to deploy roughly $700 billion in 2026. This investment boom has raised concerns that…
  - (2026-09-04) [Marginal Revolution] Share price numbers for the Hugging Face incident
      …major publicly traded cybersecurity firms lost roughly $65–80 billion, or about 8–10% of their combined value, in the days following disclosure of the Hugging Face/OpenAI incident; by early September they had recovered…
  - (2026-09-03) [Conversable Economist] Gross and Net US Investment
      Each year, more than half of the total or gross investment by US firms just makes up for depreciation in older equipment and knowledge. in recent year, it’s more like 75% of current year investment just offsets depreciat…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 34 total
  - (2026-09-04) #30 Masayoshi Son — $67.31B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-09-04) MOVER ▼ Francoise Bettencourt Meyers & family — $94.30B ($-0.08B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=19, 14d-median=19; carrying terms: proposed, published, safety, national, certain, unless, associated, service, special, commission, action, public
- state_bills: today=96, 7d-median=78, 14d-median=80; carrying terms: general, local, permits, eligible, court, provisions, program, health, pursuant, income, public, required
- state_news: today=677, 7d-median=648, 14d-median=648; carrying terms: signs, children, local, loading, primary, pennsylvania, taken, lawsuit, candidates, inside, housing, forest
- local_news: today=235, 7d-median=235, 14d-median=238; carrying terms: local, taken, owner, court, people, trial, atlantamagazine, class, student, fetchpriority, north, trump
- foreign_news: today=1120, 7d-median=1096, 14d-median=1041; carrying terms: signs, children, colombia, survey, local, means, england, saudi, container, single, strategy, sustainable
- chinese_internal: today=286, 7d-median=286, 14d-median=286; carrying terms: people, cbmiakfvx, politics, cbmixkfvx, cbmibefvx, cbmizefvx, property, title, cbmiw, cbmib, lxtfa, china
- russian_internal: today=1203, 7d-median=1074, 14d-median=1074; carrying terms: times, gazeta, httperror, politico, street, media, social, journal, novaya, novayagazeta, russian, axios
- ukrainian_internal: today=137, 7d-median=122, 14d-median=119; carrying terms: ministers, general, children, elections, group, ahead, international, ground, civilian, volodymyr, people, europe
- ukraine_theater: today=598, 7d-median=598, 14d-median=612; carrying terms: lssmtwrfr, eydllmz, yuvevtdvmnppmu, dvouxtm, cuxos, capabilities, tvjiuze, jmbmzosxbtumzvyxz, cbmijwfbvv, kytupucnjrdwdhowf, zwwytyktpwkpqzwvpxzfgbkdumhbibdzoq, ground
- paper_bets: today=134, 7d-median=134, 14d-median=133; carrying terms: september, general, decrease, minister, succeed, funds, industrial, conviction, either, career, visit, house
- weather: today=132, 7d-median=132, 14d-median=135; carrying terms: southwest, francisco, messages, children, moving, oregon, excessive, heavy, creeks, locally, values, winds
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpilfesl, commodities, dexuseu, inflation, sheet, implied, consumption, recession, jolts, supply, openings, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, nasdaq, range, agriculture, corporate, futures, proxy, bitcoin, russell, crude, close, equities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=101, 7d-median=109, 14d-median=108; carrying terms: chemical, eastern, embargo, general, weapons, ujgxrwtvbs, updates, russia, issuance, yemen, bissau, detect
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, https, error, httperror, quiver, unauthorized, quantitative, client, quiverquant
- billionaires: today=34, 7d-median=0, 14d-median=30; carrying terms: mexico, family, spacex, mining, peterffy, yiming, amancio, retail, semiconductors, amazon, ballmer, hathaway
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, supreme, america, appeals, connecticut, company, county, services, blanche, board, energy
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, group, filer, holdings, finance, america, technologies, global
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, angels, elect, lindsey, brown, cycle, filing, jonathan, cooper, michael, booker, cortez
- gdelt_regions: today=6, 7d-median=9, 14d-median=9; carrying terms: english, japan
- gdelt_gkg: today=25, 7d-median=38, 14d-median=38; carrying terms: english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: india, kingdom, language, trump, english, against, domain, iheart
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, germany, ground, bulgaria, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: ventilatory, operator, interconnected, cvdpv, additi, recommendations, infant, unaffected, border, seasonal, mechanical, general
- cisa_kev: today=21, 7d-median=21, 14d-median=20; carrying terms: vendor, vulnerability, product, synacor, collaboration, injection, function, zimbra, suite, authentication, command, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=17, 7d-median=14, 14d-median=14; carrying terms: depth, islands, indonesia, south, region, chile, alaska, sandwich, vanuatu, china, isangel, nikolski
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, championship, september, interest, meeting, decrease, league, donetsk, volume, presidential, champions, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, class, economist, https, conversable, revolution, economy, recent, conversableeconomist, current, sense, point
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: using, around, today, people, schneier, going, critical, technology, cybersecurity, technica, intelligence, across
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: panetta, haley, wesley, francisco, fernandez, rubio, delaney, general, fitzpatrick, sanders, warsh, mccollum
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, placed, either, today, markets, converges, placement, decision, consensus, paper, evidence, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*