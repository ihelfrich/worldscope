# WORLDSCOPE morning brief — 2026-09-04

## Headline
3389 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (775) · Russian Internal News (state + in-exile) (690) · Ukraine Theater (total-war monitoring) (379) · World leaders & government officials (324) · State-Level News (305) · Chinese Internal News (246) · Local News: St. Louis + Atlanta (188) · U.S. Weather + Severe / Climate Outlooks (146) · Ukrainian Internal News (national + local Kyiv) (64) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (36) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 775 new of 1117 total
  - (2026-09-04) [Global] Controversial Jackdaw gas field set to be approved in weeks, sources say
      The government is set to give the go-ahead for the gas field off the coast of Aberdeen, the BBC understands.
  - (2026-09-04) [Global] Volkswagen board approves plan to cut another 50,000 jobs
      The group - which includes Audi, Porsche, Skoda as well as the VW brand - plans to cut a total of 100,000 posts by 2030.
  - (2026-09-04) [Global] Argentine leader threatens to sanction oil firms and reiterates Falklands claim
      Javier Milei reiterates his country's claim on the British overseas territory, saying the "winds of change" favour it.
  - (2026-09-03) [Global] 'I lost my savings after a job interview scam'
      Jobseekers, especially Gen Z, are being targeted with fake, booby-trapped recruitment apps.
  - (2026-09-04) [Global] Prosecco, cakes and beauty products - how to get birthday freebies and why there's a catch
      Cake, coffee, make-up and burgers are just some of the free things you can get on your birthday.
  - (2026-09-04) [Global] From 'dog fruit' to darling: India's avocado boom
      Demand for avocados is booming in India and local growers hope to grab more of the market.

### Russian Internal News (state + in-exile) — 690 new of 1172 total
  - (2026-09-04) Израильские власти подозревают российского историка, публициста и критика Нетаниягу Артема Кирпиченка в связи с иностранной разведкой. Он уже месяц находится под арестом | LEDE: Историк и пу] (ru: Изр…
      Историк и публицист Артем Кирпиченок прилетел в Тель-Авив 2 августа, чтобы принять участие в международной конференции, сообщала его группа поддержки. Прямо в аэропорту его задержали сотрудники израильской Общей службы б…
  - (2026-09-04) Совет директоров Volkswagen одобрил сокращение 50 тысяч рабочих мест и уменьшение модельного ряда | LEDE: Совет директоров компании Volkswagen утвердил масштабный план сокращения расходов, к] (ru: Сов…
      Совет директоров компании Volkswagen утвердил масштабный план сокращения расходов, который предусматривает сокращение до 2030 года 50 тысяч рабочих мест и уменьшение модельного ряда вдвое. Кроме того, автоконцерн собирае…
  - (2026-09-04) Служба госбезопасности Латвии устроила обыск в сети магазинов Mnogoknig. Там, в числе прочего, продают книги на русском языке | LEDE: Сотрудники Службы госбезопасности (СГБ) Латвии днем 3 се] (ru: Слу…
      Сотрудники Службы госбезопасности (СГБ) Латвии днем 3 сентября провели обыски на четырех объектах сети книжных магазинов Mnogoknig.
  - (2026-09-04) В Германии начали серийное производство ударных беспилотников для Украины. Всего собираются изготовить пять тысяч дронов | LEDE: В районе Мюнхена в Баварии началось массовое производство уда] (ru: В Г…
      В районе Мюнхена в Баварии началось массовое производство ударных беспилотников для украинской армии, сообщили немецко-американская оборонная компания Auterion и ее украинский партнер Airlogix.
  - (2026-09-04) Рассмотрение законопроекта об «адских санкциях» против России затормозилось в Палате представителей США | LEDE: Принятие законопроекта о новых санкциях в отношении России отложено, скорее вс] (ru: Рас…
      Принятие законопроекта о новых санкциях в отношении России отложено, скорее всего, до промежуточных выборов в конгресс США, которые пройдут в ноябре, пишет Bloomberg.
  - (2026-09-04) В торговых центрах в России выросла доля трат на продукты и алкоголь. Эксперты говорят о снижении покупательской способности и перераспределении расходов | LEDE: Основные траты посетителей к] (ru: В т…
      Основные траты посетителей крупных торговых центров европейской части России приходятся на продуктовые магазины и алкомаркеты, пишет «Коммерсант».

### Ukraine Theater (total-war monitoring) — 379 new of 599 total
  - (2026-09-04) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-03-09) [Liveuamap] Exodus from the towns of Maqbana district and Al-Kadha area in Taiz governorate after Houthis took control of them. - Liveuamap
      Exodus from the towns of Maqbana district and Al-Kadha area in Taiz governorate after Houthis took control of them. &nbs
  - (2026-09-03) [Liveuamap] A new restricted airspace zone in eastern Poland. From September 10, aircraft will not be able to fly there from ground level to an altitude of about 3 km Poland, Lublin Voivodeship, Polan…
      A new restricted airspace zone in eastern Poland. From September 10, aircraft will not be able to fly there from ground level to an a
  - (2026-09-03) [Liveuamap] Germany&039;s power grid has suffered a second, major physical attack Saboteurs in North Rhine-Westphalia knocked 4,200 MW of RWE baseload capacity offline, sending intraday power prices s…
      Germany&039;s power grid has suffered a second, major physical attack Saboteurs in North Rhine-Westphalia knocked 4,200 MW of RWE bas
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2016-04-27) [Liveuamap] Israel-Palestine - Liveuamap
      Israel-Palestine Liveuamap

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 305 new of 659 total
  - (2026-09-03) [California] California and the Australian state of Queensland ink new partnership to accelerate climate resilience, agricultural technology, and innovation
      Source
  - (2026-09-03) [California] Governor, First Partner statement on the passing of Gloria Steinem
      Source
  - (2026-09-03) [California] California prioritized fighting organized retail theft, those results are paying off with 36,000 arrests and $293 million in stolen goods recovered
      Source
  - (2026-09-04) [Connecticut] Citizens’ group pledges big ideas to reform CT property tax
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2024/03/download-2-1-1024x682.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="h…
  - (2026-09-04) [Connecticut] ICE tactics in Danbury are wrong
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/09/ap-ice-in-danbury-2.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctm…
  - (2026-09-04) [Connecticut] Parents, we are on your side
      <img width="800" height="534" src="https://ctmirror.org/wp-content/uploads/2026/05/measles-vaccination.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcse…

### Chinese Internal News — 246 new of 284 total
  - (2026-09-03) Chart of the Day: Rising Revenues Mask Profit Hurdles for China’s GPU Quartet - Caixin Global
      Chart of the Day: Rising Revenues Mask Profit Hurdles for China’s GPU Quartet Caixin Global
  - (2026-09-03) 财经早知道｜十部门重磅发布 设立国家中小企业发展基金二期 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9zZFZpblQ3c0MzaFN3M3JRYm80SlRfOWRSRGdOLXJVSEJzMWI2YjVjVXlKbHJ4eUxYRHY4Y0FHMmF2ZH] (zh:…
      财经早知道｜十部门重磅发布 设立国家中小企业发展基金二期 Caixin Global
  - (2026-09-03) 联合国报告：破1.5℃升温阈值在所难免 紧急救灾或挤出长期转型资金 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE05WUotSHRZWHgtWlluaHBjLVhNUzl2XzJaMWZtbXUwYlR6Z0NvYU9WbnBRWkJFTnI5OXRJSV] (zh:…
      联合国报告：破1.5℃升温阈值在所难免 紧急救灾或挤出长期转型资金 china.caixin.com
  - (2026-09-04) 陈燕妮：永远的蒂芙尼｜故事 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE42SDJDdFhLdEtjdVc1LXhHMk5zc29VSGIyVkV6NjdVR3V0NlFDQ3hiMFBwYndSWjZpa3VaM2c1SlRfd1ZZYzMzdEdWVUU1bDE0VU9yTFhx] (zh:…
      陈燕妮：永远的蒂芙尼｜故事 财新
  - (2026-09-03) 莱比锡机场遇袭事件致德俄关系再恶化 俄领馆和文化机构遭关闭 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5sdjg3R1l1YzdwblZFbklCeWVubm9ySEpOalNDek10SGZ1QllFUjVoYkR5aG1pdFFucHpTOGRzUDdPcmMzYWhLbGtB] (zh:…
      莱比锡机场遇袭事件致德俄关系再恶化 俄领馆和文化机构遭关闭 财新
  - (2026-09-03) AI、电气化与资源竞争：全球经济的新逻辑 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9SRlVlMnFZdk0yUXpGRlcwRnhvZ0tYOUpJRmE3RjJrbTYxRHladTA5RWJPT0d5YURpVWNlYlJCRC1YVFF4UVpxV0FNWFhhUTd4d] (zh:…
      AI、电气化与资源竞争：全球经济的新逻辑 财新

### Local News: St. Louis + Atlanta — 188 new of 226 total
  - (2026-09-04) [St. Louis] What’s True in the Lou? – 9/4/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-09-03) [St. Louis] Drew Baldridge heads home for The Big Baldridge & Bonfire
      Drew Baldridge loves himself a good county fair. “You can probably hear them pigs right now,” the country music hitmaker joked before his show at the Rock County 4-H Fair in Janesville, Wisconsin. “They opened the gate a…
  - (2026-09-03) [St. Louis] Fleur STL closes in former Eat-Rite Diner space
      Fleur STL (622 Chouteau), a chef’s reimagination of the former Eat-Rite Diner located several blocks south of Busch Stadium, has closed. The acclaimed 14-seat breakfast-and-lunch spot had not operated regularly since ear…
  - (2026-09-04) [St. Louis] Vice President Vance says Iran fight isn't a 'war' despite escalations
      Vance's assertion came even as Iran fired at U.S. Gulf ally Kuwait on Thursday as it continued to retaliate for rounds of U.S. strikes on Iran earlier in the week.
  - (2026-09-04) [St. Louis] 2 trapped workers rescued alive from a tunnel in Nepal, officials say
      About 900 workers are missing from 12 hydropower projects in Nepal, with roughly 500 believed to be trapped in tunnels.
  - (2026-09-04) [St. Louis] Lawyer who defended Andrea Yates reflects on similarities to Lindsay Clancy trial
      Attorney George Parnham, who represented Andrea Yates after she killed her five children in 2001, said the Clancy case has significant similarities to Yates' case.

### U.S. Weather + Severe / Climate Outlooks — 146 new of 149 total
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 4:30AM CDT by NWS Marquette MI
      At 430 AM CDT, Doppler radar was tracking a strong thunderstorm 9 miles east of Pound, or 11 miles west of Marinette, moving east at 40 mph. HAZARD...Nickel size hail. SOURCE...Radar indicated. IMPACT...Minor hail damage…
  - (2026-09-04) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 4:26AM CDT by NWS La Crosse WI
      At 426 AM CDT, Doppler radar was tracking a strong thunderstorm over Galesville, or 14 miles southeast of Arcadia, moving east at 45 mph. HAZARD...Wind gusts up to 40 mph and penny size hail. SOURCE...Radar indicated. IM…
  - (2026-09-04) [Moderate] Heat Advisory: Heat Advisory issued September 4 at 4:24AM CDT until September 5 at 8:00PM CDT by NWS Hastings NE
      * WHAT...Afternoon heat index values as high as 105 to 110 with overnight low temperatures in the 70s. * WHERE...Portions of north central Kansas and east central and south central Nebraska. * WHEN...Until 8 PM CDT Satur…
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 5:21AM EDT by NWS Cleveland OH
      At 521 AM EDT, Doppler radar was tracking a strong thunderstorm over Holland, or near Toledo, moving southeast at 35 mph. HAZARD...Half inch hail. SOURCE...Radar indicated. IMPACT...Minor hail damage to vegetation is pos…
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 5:18AM EDT by NWS Grand Rapids MI
      At 517 AM EDT, Doppler radar was tracking a strong thunderstorm over Charlotte, moving southeast at 35 mph. HAZARD...Winds in excess of 40 mph and nickel size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could kn…

### Ukrainian Internal News (national + local Kyiv) — 64 new of 129 total
  - (2026-09-04) Затримали військового з дружиною, які передавали росіянам дані про ЗСУ | LEDE: Пара передавала Росії дані про військову техніку та особовий склад у Харківській, Кіровоградській і Полтавській об] (uk:…
      Пара передавала Росії дані про військову техніку та особовий склад у Харківській, Кіровоградській і Полтавській областях. Їх затримали.
  - (2026-09-04) Ченцов про блокування відкриття кластерів для України: В інтересах Угорщини дотримуватись правил | LEDE: Віцепремʼєр-міністр України з питань євроінтеграції Всеволод Ченцов заявив, що Україна м] (uk:…
      Віцепремʼєр-міністр України з питань євроінтеграції Всеволод Ченцов заявив, що Україна має гарний прогрес у співпраці з Угорщиною щодо прав нацменшин, але не хоче пов'язувати це питання з відкриттям перемовних кластерів…
  - (2026-09-04) "Близько тижня промацують нашу оборону": У ДПСУ розповіли про дії росіян у Вовчанській громаді | LEDE: Окупанти намагаються прорвати оборону у Вовчанській і Вільхуватській громадах Харківщини, ] (uk:…
      Окупанти намагаються прорвати оборону у Вовчанській і Вільхуватській громадах Харківщини, але зазнають значних втрат. Заява ДПСУ.
  - (2026-09-04) Окупати засудили до 15 років ув’язнення викрадену журналістку Ірину Левченко | LEDE: Окупаційний Запорізький суд визнав Ірину Левченко винною у «шпигунстві» та призначив 15 років колонії. Детал] (uk:…
      Окупаційний Запорізький суд визнав Ірину Левченко винною у «шпигунстві» та призначив 15 років колонії. Деталі справи та етапування журналістки.
  - (2026-09-04) Покривав побиття цивільних: начальнику відділу ТЦК на Київщині повідомили про підозру | LEDE: Олександра Березовського з Білоцерківського РТЦК підозрюють у приховуванні злочинів підлеглого, яки] (uk:…
      Олександра Березовського з Білоцерківського РТЦК підозрюють у приховуванні злочинів підлеглого, який бив цивільних. Йому загрожує до 10 років ув'язнення.
  - (2026-09-04) Єврокомісія до кінця вересня підготує проєкт механізму обмежень під час розширення ЄС | LEDE: ] (uk: Єврокомісія до кінця вересня підготує проєкт механізму обмежень під час розширен)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-04) [WOLSFELD MATTHEW C] Form 4 (Reporting)
      filed 2026-09-04 01:58 UTC · role: Reporting — Filed: 2026-09-03 AccNo: 0001258563-26-000002 Size: 6 KB
  - (2026-09-04) [NORTHERN TECHNOLOGIES INTERNATIONAL CORP] Form 4 (Issuer)
      filed 2026-09-04 01:58 UTC · role: Issuer — Filed: 2026-09-03 AccNo: 0001258563-26-000002 Size: 6 KB
  - (2026-09-04) [Powelson Robert F] Form 4 (Reporting)
      filed 2026-09-04 01:57 UTC · role: Reporting — Filed: 2026-09-03 AccNo: 0001009759-26-000009 Size: 6 KB
  - (2026-09-04) [Capstone Energy Plus, Inc.] Form 4 (Issuer)
      filed 2026-09-04 01:57 UTC · role: Issuer — Filed: 2026-09-03 AccNo: 0001009759-26-000009 Size: 6 KB
  - (2026-09-04) [Real REMAX Group Inc.] Form 4 (Issuer)
      filed 2026-09-04 01:55 UTC · role: Issuer — Filed: 2026-09-03 AccNo: 0001104659-26-105169 Size: 17 KB
  - (2026-09-04) [Carlson Erik] Form 4 (Reporting)
      filed 2026-09-04 01:55 UTC · role: Reporting — Filed: 2026-09-03 AccNo: 0001104659-26-105169 Size: 17 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 36 new of 56 total
  - (2026-09-04) [The Hacker News] Over 440,000 Exploit Attempts Target Super Forms and Elementor Pro RCE Flaws
      Threat actors are exploiting two critical security flaws in WordPress plugins Super Forms and Elementor Pro, according to findings from Wordfence. The vulnerabilities in question are - CVE-2026-14894 (CVSS score: 9.8) -…
  - (2026-09-04) [The Hacker News] Plex Urges Immediate Updates After Patching Multiple Undisclosed Security Flaws
      Plex is urging users to update their instances to the latest version following the release of an update that patches multiple security flaws. The fixes are available in Plex Media Server 1.43.3 and Plex Desktop 1.115.0.…
  - (2026-09-04) [The Hacker News] Google Releases Chrome Update to Patch Actively Exploited V8 Zero-Day
      Google on Thursday released security updates to patch 12 vulnerabilities, including one that has come under active exploitation in the wild. The high-severity vulnerability, tracked as CVE-2026-85046 (CVSS score: 8.8), h…
  - (2026-09-04) [The Hacker News] GPT-6 Astra Scores 100% on ExploitBench as OpenAI Blocks PoC Exploit Requests
      OpenAI on Thursday officially unveiled GPT‑6 Astra, which it described as the "world's most intelligent and aligned model." The development comes days after the artificial intelligence (AI) company said the model had rea…
  - (2026-09-04) [The Register] US law firm accuses UK AI software firm of unwanted contract renewal when it tried to leave
      Customer alleges AI telco system had frequent issues, did not work as promised, as vendor sues separately for non payment
  - (2026-09-04) [The Register] UK military wants lasers to stop drone swarms without running out of ammo
      Project PANOPTES puts £5M on the table for an autonomous, vehicle-mounted defense

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 29 new of 60 total
  - (2026-09-08) Connecticut Supreme Court: Perez v. Carusillo
  - (2026-09-03) U.S. Court of Appeals, 8th Cir.: BNSF Railway Company v. U.S. Dept. of Labor
  - (2026-09-03) U.S. Court of Appeals, 8th Cir.: Pennsylvania Insurance Company v. Federal Express Corporation
  - (2026-09-03) U.S. Court of Appeals, 8th Cir.: The Iowa Farm Sanctuary v. Univ. of MO Vet Health Center
  - (2026-09-03) U.S. Court of Appeals, 8th Cir.: XTO Energy, Inc. v. Commerce and Industry Ins. Co.
  - (2026-09-03) U.S. Court of Appeals, 7th Cir.: Brian Caraba v. Paul Revere Life Insurance Company

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-09-04) JAF5PW (Bulgaria)
      icao24: 4520ce · position: (48.7226, 2.3759) · on ground · 144km/h
  - (2026-09-04) GAF182 (Germany)
      icao24: 3e8b41 · position: (37.2198, 24.3739) · alt: 9745m · 702km/h
  - (2026-09-04) GAF133 (Germany)
      icao24: 3f62fc · position: (46.136, 16.1349) · alt: 2788m · 603km/h
  - (2026-09-04) SAMU45 (France)
      icao24: 39ca85 · position: (47.8353, 1.9199) · on ground · 2km/h
  - (2026-09-04) SAMU691 (France)
      icao24: 39c994 · position: (45.7243, 4.9411) · on ground · 0km/h
  - (2026-09-04) PUMA71 (United States)
      icao24: a00001 · position: (40.4844, -3.8037) · alt: 579m · 8km/h

### Paper Trading Scorecard — 23 new of 134 total
  - (2026-09-04) [Polymarket] Will Naomi Osaka win the 2026 Women’s US Open?
      The 2026 U.S. Open tennis tournament is scheduled for August 23 - September 13, 2026. This market will resolve to the player that wins the 2026 U.S. Open Women’s Singles Tournament. If at any point it becomes impossible…
  - (2026-09-04) [Polymarket] Will Z.ai have the best AI model at the end of September 2026?
      This market will resolve according to the company which owns the model which has the highest arena rank based on the arena.ai Text Arena (Overall) when the table under the "Leaderboard" tab is checked on September 30, 20…
  - (2026-09-04) [Polymarket] Will Faker win a Finals MVP Award at an international event in 2026?
      The market will resolve to "Yes" if Lee "Faker" Sang-hyeok is officially announced as the Finals MVP of any international event in 2026 (such as First Stand, MSI, Esports World Cup, Worlds, or any other officially recogn…
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2036
      December 2036
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2035
      December 2035
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2034
      December 2034

### USGS earthquakes (M4.5+, past day) — 19 new of 22 total
  - (2026-09-03) M 5.5 - 100 km S of Nikolski, Alaska
      M5.5 · 100 km S of Nikolski, Alaska · depth 10 km
  - (2026-09-03) M 5.3 - 104 km SSW of Nikolski, Alaska
      M5.3 · 104 km SSW of Nikolski, Alaska · depth 10 km
  - (2026-09-04) M 5.2 - 28 km S of Cilacap, Indonesia
      M5.2 · 28 km S of Cilacap, Indonesia · depth 10 km
  - (2026-09-03) M 5.2 - 271 km SSE of Dunhuang, China
      M5.2 · 271 km SSE of Dunhuang, China · depth 10 km
  - (2026-09-03) M 5.2 - 100 km SSW of Nikolski, Alaska
      M5.2 · 100 km SSW of Nikolski, Alaska · depth 10 km · TSUNAMI
  - (2026-09-03) M 5.2 - 97 km SSW of Nikolski, Alaska
      M5.2 · 97 km SSW of Nikolski, Alaska · depth 45.17 km

### U.S. Federal Action — 14 new of 18 total
  - (2026-09-04) Geographic Targeting Order Imposing Recordkeeping and Reporting Requirements on Certain Money Services Businesses Along the Southwest Border
      FinCEN is issuing this Geographic Targeting Order, requiring certain money services businesses along the southwest border of the United States to report and retain records of transactions in currency of $1,000 or more, b…
  - (2026-09-04) Transfer Agent Rules
      The U.S. Securities and Exchange Commission ("SEC" or "Commission") is proposing to adopt new rules, amend existing rules, amend the existing form for registration with the Commission as a transfer agent (Form TA-1) and…
  - (2026-09-04) Reducing Bureaucracy and Burden for the Repatriation of Mentally Ill Nationals
      The Department of Health and Human Services, Administration for Children and Families proposes to remove the Care and Treatment of Mentally Ill Nationals of the United States, Returned from Foreign Countries regulations…
  - (2026-09-04) Drawbridge Operation Regulation; Savannah River, Clyo, GA
      The Coast Guard is removing the existing drawbridge operation regulation for the CSX Transportation railroad bridge, mile 60.9, near Clyo, GA. The drawbridge was converted to a fixed bridge in August 2026, and the operat…
  - (2026-09-04) Driving Efficiency in Farm Loan Delivery
      The Farm Service Agency (FSA) is amending the Farm Loan Program (FLP) regulations to permanently implement the Application Fast Track (AFT) process, which expedites underwriting for certain direct loan applicants by usin…
  - (2026-09-04) Modernizing Medical Standards for Non-Insulin Dependent Diabetes Mellitus Cases
      FAA proposes to amend its regulations to allow applicants with non-insulin dependent diabetes mellitus to apply for airman medical certification that may be issued at the time of their medical examination instead of requ…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-04) LoL: KT Rolster vs Dplus KIA - Game 1 Winner
      yes price: 100% · 24h volume: $1,735,023 · resolves 2026-09-04
  - (2026-09-04) LoL: KT Rolster vs Dplus KIA (BO5) - LCK Playoffs
      yes price: 72% · 24h volume: $1,245,424 · resolves 2026-09-04
  - (2026-09-04) Will John Thune win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $1,122,688 · resolves 2028-11-07
  - (2026-09-04) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 12% · 24h volume: $824,599 · resolves 2027-01-01
  - (2026-09-04) Will Stephen A. Smith win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $575,566 · resolves 2028-11-07
  - (2026-09-04) LoL: KT Rolster vs Dplus KIA - Game 2 Winner
      yes price: 72% · 24h volume: $535,277 · resolves 2026-09-04

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-09-04) #30 Masayoshi Son — $67.31B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-09-04) MOVER ▲ Elon Musk — $926.20B (+$53.86B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-09-04) MOVER ▲ Larry Ellison — $198.25B (+$9.80B since yesterday)
      United States · Technology · source: Oracle
  - (2026-09-04) MOVER ▲ Mark Zuckerberg — $209.59B (+$6.05B since yesterday)
      United States · Technology · source: Facebook
  - (2026-09-04) MOVER ▲ Michael Dell — $255.98B (+$5.26B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-09-04) MOVER ▲ Thomas Peterffy — $107.50B (+$4.16B since yesterday)
      United States · Finance & Investments · source: Discount brokerage

### State Legislative Action — 9 new of 95 total
  - (2026-09-04) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-09-04) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-09-03) [Alaska HB 193] An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training…
      An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training program account; relating to unempl…
  - (2026-09-03) [Alaska HB 242] An Act relating to sexual assault.
      An Act relating to sexual assault.
  - (2026-09-03) [Alaska HB 77] An Act making the theft of mail or an article within mail theft in the second degree.
      An Act making the theft of mail or an article within mail theft in the second degree.
  - (2026-09-03) [Alaska SB 89] An Act relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating to the practice of medicine; relating to health care…
      An Act relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating to the practice of medicine; relating to health care providers; and relating to provisio…

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 101 total
  - (2026-09-03) [OFAC] Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License - Office of Foreign Assets Control (.gov)
      Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License Office of Foreign Assets Control (.gov)
  - (2026-09-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)
  - (2026-09-04) [USASpending] $4,429,530,857 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WI
      Agency: National Aeronautics and Space Administration. Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOLID…
  - (2026-09-04) [USASpending] $1,282,404,815 → CSI AVIATION, INC: THIS CALL ORDER OBTAINS DEDICATED AND ON-DEMAND CHARTERED FL
      Agency: Department of Homeland Security. Description: THIS CALL ORDER OBTAINS DEDICATED AND ON-DEMAND CHARTERED FLIGHT SERVICES FOR ENFORCEMENT AND REMOVAL OPERATIONS UNDER THE ICE AIR PROGRAM. ICE AIR FACILITATES THE SA…
  - (2026-09-04) [USASpending] $1,061,183,201 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)
  - (2026-09-04) [USASpending] $1,018,396,052 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-04) [China] South Korea taps chip windfall for next tech push
      digitimes.com · English
  - (2026-09-04) [China] Samsung turns to chips , OLED for next phase of Vietnam expansion
      digitimes.com · English
  - (2026-09-04) [China] [ SMM Analysis ] Europe Seeks Lithium Supply Chain Independence , Yet Its Projects Attract Asian Investors
      news.metal.com · English
  - (2026-09-04) [China] Japan FOIP 3 . 0 : Is Pragmatism That Delivers Resilience Enough ? – The Diplomat
      thediplomat.com · English
  - (2026-09-04) [China] Vietnam Sentences 11 to Death in Country Largest Ever Drug Trafficking Case – The Diplomat
      thediplomat.com · English
  - (2026-09-04) [China] Securing Navigation for Trans - Caspian Trade
      thediplomat.com · English

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-04) [Marginal Revolution] Shout it from the rooftops (of the data centers)
      Data-center investment has become one of the largest capital-expenditure cycles in financial markets, with U.S. hyperscalers expected to deploy roughly $700 billion in 2026. This investment boom has raised concerns that…
  - (2026-09-04) [Marginal Revolution] Share price numbers for the Hugging Face incident
      …major publicly traded cybersecurity firms lost roughly $65–80 billion, or about 8–10% of their combined value, in the days following disclosure of the Hugging Face/OpenAI incident; by early September they had recovered…
  - (2026-09-03) [Marginal Revolution] Astra, doing poetry
      One prompt, no cherry-picking: TC: “Now a short poem in the style of the very best Rilke, in German:” Die Hand im Schlaf Nun liegt sie offen. Alles, was sie hielt, ist in die eigne Schwere heimgekehrt. Nur eine kleine Hö…
  - (2026-09-03) [Conversable Economist] Gross and Net US Investment
      Each year, more than half of the total or gross investment by US firms just makes up for depreciation in older equipment and knowledge. in recent year, it’s more like 75% of current year investment just offsets depreciat…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=19, 14d-median=19; carrying terms: certain, published, safety, national, unless, proposed, existing, service, regulatory, public, action, associated
- state_bills: today=95, 7d-median=78, 14d-median=84; carrying terms: contract, policy, resources, required, general, beginning, entities, education, purposes, information, until, provides
- state_news: today=659, 7d-median=648, 14d-median=622; carrying terms: water, releases, residents, hampshire, businesses, administration, legal, records, memorial, patients, sites, issues
- local_news: today=226, 7d-median=226, 14d-median=238; carrying terms: school, hospital, attachment, missouri, charged, atlantamagazine, figure, google, august, investigation, appeared, against
- foreign_news: today=1117, 7d-median=1096, 14d-median=1034; carrying terms: chief, water, commentators, release, httpsconnection, annual, residents, healthcare, administration, legal, boost, northern
- chinese_internal: today=284, 7d-median=286, 14d-median=285; carrying terms: cbmiw, google, articles, cbmibkfvx, https, caixin, cbmiakfvx, lxtfa, cbmiykfvx, cbmizefvx, cbmia, lxtfb
- russian_internal: today=1172, 7d-median=1074, 14d-median=1052; carrying terms: europe, politico, forbidden, russian, telegram, media, found, gazeta, https, financial, httperror, social
- ukrainian_internal: today=129, 7d-median=122, 14d-median=120; carrying terms: takeaways, media, plans, transport, general, missiles, client, ukrinform, campaign, additional, sanctions, energy
- ukraine_theater: today=599, 7d-median=599, 14d-median=674; carrying terms: dlzuxzsgxnv, qvhrunjxt, klwrysnfib, cuxnry, sujvrdnf, txsnhkz, wgpdaxjznljlqljsxzj, cbmioefvx, diqjrvyuxluxrfzf, tddtbezsm, archive, fjblvcq
- paper_bets: today=134, 7d-median=134, 14d-median=132; carrying terms: caribbean, humanoid, carolina, primary, midterms, decrease, republicans, democratic, successor, seats, nominee, goldman
- weather: today=149, 7d-median=145, 14d-median=144; carrying terms: miami, afdlsx, water, oxnard, evening, early, increase, message, following, current, upper, gusty
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dcoilwtico, pcepilfe, consumption, latest, indicator, supply, implied, dexjpus, headline, cpilfesl, treasury, cpiaucsl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, equities, corporate, natural, china, range, silver, crude, agriculture, credit, crypto, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=101, 7d-median=109, 14d-median=107; carrying terms: burma, updates, chemical, detect, activities, somalia, prohibited, certain, usaspending, authorizing, company, hybrid
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiverquant, quiver, error, quantitative, unauthorized, https, httperror, congresstrading
- billionaires: today=40, 7d-median=0, 14d-median=30; carrying terms: velasco, gmexicob, facebook, julia, london, china, gates, mexico, bernard, telecom, spacex, changpeng
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, state, court, appeals, america, connecticut, company, county, thomas, board, florida, blanche
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, holdings, group, scott, therapeutics, amended, technologies, robert
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, raised, graham, cooper, alexandria, house, johnson, shawn, brown, committee, booker, elect
- gdelt_regions: today=6, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: keywords, trump, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, ground, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: focus, interconnected, initiated, caused, diphtheria, watery, person, respiratory, viral, conflict, barasat, ituri
- cisa_kev: today=21, 7d-median=21, 14d-median=20; carrying terms: vulnerability, server, product, critical, synacor, authentication, collaboration, injection, zimbra, vendor, forgery, function
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=22, 7d-median=14, 14d-median=14; carrying terms: depth, islands, indonesia, south, region, chile, alaska, sandwich, china, vanuatu, isangel, nikolski
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: september, resolves, champions, meeting, league, decrease, donetsk, championship, rates, interest, volume, price
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, conversable, https, marginal, class, revolution, conversableeconomist, recent, economy, sense, current, point
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: company, devices, openai, threat, world, review, going, attackers, month, attacks, security, recent
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: craig, salinas, chief, austin, thomas, fernandez, barrag, lamonica, daniel, davis, garbarino, carey
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, placement, claude, markets, identify, unavailable, placed, paper, decision, converges, module, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*