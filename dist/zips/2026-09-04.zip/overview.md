# WORLDSCOPE morning brief — 2026-09-04

## Headline
4123 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (835) · Russian Internal News (state + in-exile) (792) · Ukraine Theater (total-war monitoring) (556) · State-Level News (460) · World leaders & government officials (324) · Chinese Internal News (256) · Local News: St. Louis + Atlanta (229) · U.S. Weather + Severe / Climate Outlooks (170) · Ukrainian Internal News (national + local Kyiv) (89) · State Legislative Action (80) · GDELT GKG — themes / entities / watch areas (50) · IT, InfoSys & cybersecurity news (last 7 days) (47)

## What changed today
### International News + Multilateral Institutions — 835 new of 1122 total
  - (2026-09-04) [Global] Europe targeted by spiralling campaign of sabotage - and Russia is the chief suspect
      Germany has blamed Russia for an attack on Leipzig airport but there has been a series of suspicious incidents elsewhere.
  - (2026-09-04) [Global] 'A rare moment of joy': Nepal tunnel rescues bring hope for more flood survivors
      There are still hundreds of workers trapped in a network of tunnels that run along the Trishuli river.
  - (2026-09-04) [Global] UK support for Falkland Islands 'unwavering' after Argentina restates claims, No 10 says
      The comments come as Argentinian president Javier Milei says the "winds of change" favoured his country's claim on the British overseas territory.
  - (2026-09-04) [Global] Russia hits Ukrainian security headquarters in drone attack, Zelensky says
      The unmanned aerial vehicle struck without warning in the heart of the Ukrainian capital.
  - (2026-09-04) [Global] Steve Irwin's family celebrates 'superhero' dad, 20 years after shock death
      The Australian icon was killed in 2006, after a stingray's barb pierced his chest during filming.
  - (2026-09-04) [Global] Trump's peace envoys to visit Moscow and Kyiv over weekend
      Steve Witkoff and Jared Kushner have led President Donald Trump's efforts to end the Russia-Ukraine war - but talks have stalled.

### Russian Internal News (state + in-exile) — 792 new of 1266 total
  - (2026-09-04) В Николаеве вновь прогремел взрыв | LEDE: ] (ru: В Николаеве вновь прогремел взрыв)
  - (2026-09-04) Трамп не знает, когда разрешится конфликт с Ираном | LEDE: ] (ru: Трамп не знает, когда разрешится конфликт с Ираном)
  - (2026-09-04) Трамп заявил, что не боится выхода ИИ из-под контроля | LEDE: ] (ru: Трамп заявил, что не боится выхода ИИ из-под контроля)
  - (2026-09-04) Трамп заявил, что есть хорошие шансы на завершение конфликта на Украине | LEDE: ] (ru: Трамп заявил, что есть хорошие шансы на завершение конфликта на Украине)
  - (2026-09-04) Трамп назвал конфликт с Ираном "пустяком" | LEDE: ] (ru: Трамп назвал конфликт с Ираном "пустяком")
  - (2026-09-04) В США проверят такси Tesla на соответствие стандартам безопасности | LEDE: ] (ru: В США проверят такси Tesla на соответствие стандартам безопасности)

### Ukraine Theater (total-war monitoring) — 556 new of 797 total
  - (2026-09-04) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-03) [FIRMS] thermal anomaly 51.506, 34.233 (FRP 9.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 0905Z, FRP 9.71 MW
  - (2026-09-03) [FIRMS] thermal anomaly 51.503, 34.225 (FRP 7.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 0905Z, FRP 7.25 MW
  - (2026-09-03) [FIRMS] thermal anomaly 51.504, 34.224 (FRP 13.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 0905Z, FRP 13.39 MW
  - (2026-09-03) [FIRMS] thermal anomaly 46.429, 32.520 (FRP 9.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 1043Z, FRP 9.08 MW
  - (2026-09-03) [FIRMS] thermal anomaly 45.275, 34.526 (FRP 2.21 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-03 1043Z, FRP 2.21 MW

### State-Level News — 460 new of 792 total
  - (2026-09-04) [California] California’s public safety strategy works: Governor Newsom’s commitment helps lower crime as new study shows violence prevention saves lives
      <a href="https://www.gov.ca.gov/2026/09/04/californias-public-safety-strategy-works-governor-newsoms-commit
  - (2026-09-04) [California] Six years after Creek Fire, Governor Newsom recognizes historic nighttime CalGuard rescue that saved 242 lives
      <a href="https://www.gov.ca.gov/2026/09/04/six-years-after-creek-fire-governor-newsom-recognizes-historic-nighttime-calguard-rescue-that-saved-242-lives/" rel="nofoll
  - (2026-09-03) [California] California and the Australian state of Queensland ink new partnership to accelerate climate resilience, agricultural technology, and innovation
      Source
  - (2026-09-03) [California] Governor, First Partner statement on the passing of Gloria Steinem
      Source
  - (2026-09-03) [California] California prioritized fighting organized retail theft, those results are paying off with 36,000 arrests and $293 million in stolen goods recovered
      Sou
  - (2026-09-04) [Alabama] Governor Ivey Honors Alabama Workers in Labor Day Message
      MONTGOMERY – Governor Kay Ivey today released a video message honoring the hardworking men and women whose dedication strengthens Alabama and drives America forward. Click here or the above image for VIDEO. Script: The s…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 256 new of 287 total
  - (2026-09-03) Chart of the Day: Rising Revenues Mask Profit Hurdles for China’s GPU Quartet - Caixin Global
      Chart of the Day: Rising Revenues Mask Profit Hurdles for China’s GPU Quartet Caixin Global
  - (2026-09-04) Hong Kong’s Silver Bonds draw record 480,000 bids with higher interest rate
  - (2026-09-04) Bargain sale, collapsed deal reflect Hong Kong’s struggling retail property market
  - (2026-09-04) Can Hong Kong outshine Singapore as central banks rethink gold custody amid global risks?
  - (2026-09-04) China’s AI ‘little giant’ Yunxi Technology files for Hong Kong IPO: sources
  - (2026-09-04) Hong Kong’s 106 billionaires, Treasury yields hit recent highs: the numbers moving markets

### Local News: St. Louis + Atlanta — 229 new of 258 total
  - (2026-09-04) [St. Louis] Ask George: Should you tip restaurant workers more on holidays, such as Labor Day?
      It’s easy to see both sides of this issue. On the one hand, restaurant workers are giving up part of their holiday so others among us can enjoy ours, oftentimes during a hot, busy shift. Adding a few dollars or extra per…
  - (2026-09-04) [St. Louis] Kids Club St. Louis opens with indoor play, ninja classes, and more for kids ages 0–10
      If your toddler has recently decided every couch cushion is a climbing wall and every piece of furniture should be jumped off of, Kids Club St. Louis would like to offer an alternative. The new concept from Cheer St. Lou…
  - (2026-09-04) [St. Louis] 8020 Restaurant now open in the former Rated Test Kitchen space in downtown St. Louis
      Chef Orlando McKinney Jr. can’t help but laugh when he recalls his initial feelings toward cooking. “I hated it,” McKinney recalls. “My dad had a catering business, so as early as 9 I was with him cutting carrots and oni…
  - (2026-09-04) [St. Louis] Good Clean Dog aims to disrupt the grooming industry with convenience and expert care
      Jennifer Ehlen-Albrecht was waiting in the rain to get her dogs groomed when she had an epiphany. She was outside Amanda’s Pet Grooming, the salon in Webster Groves that groomed her Goldendoodles, Rosie and Buddy, over t…
  - (2026-09-04) [St. Louis] As copper thieves target St. Louis’ riverfront, the city calls in the cavalry
      The Mississippi riverfront in downtown St. Louis has become a hotspot in the city’s cat-and-mouse battle with copper wire thieves—with the city struggling to stay one step ahead of increasingly aggressive thefts. The ill…
  - (2026-09-04) [St. Louis] What’s True in the Lou? – 9/4/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…

### U.S. Weather + Severe / Climate Outlooks — 170 new of 171 total
  - (2026-09-04) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 4 at 4:15PM EDT until September 4 at 5:00PM EDT by NWS Baltimore MD/Washington DC
      SVRLWX The National Weather Service in Sterling Virginia has issued a * Severe Thunderstorm Warning for... South central Spotsylvania County in central Virginia... * Until 500 PM EDT. * At 414 PM EDT, a severe thundersto…
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 4:14PM EDT by NWS Wakefield VA
      At 414 PM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Sanderling to near Grandy. Movement was southeast at 10 mph. HAZARD...Wind gusts up to 50 mph, heavy rain, and frequent ligh…
  - (2026-09-04) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 4 at 4:14PM EDT until September 4 at 4:30PM EDT by NWS Blacksburg VA
      At 414 PM EDT, a severe thunderstorm was located near Madison Heights, or 8 miles north of Concord, moving southeast at 25 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, sidin…
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 4:13PM EDT by NWS Wilmington OH
      At 412 PM EDT, strong outflow thunderstorms were located along a line extending from 7 miles east of Waynesville to near Sabina, moving southeast at 35 mph. Winds will occur in advance of any storms. HAZARD...Wind gusts…
  - (2026-09-04) [Moderate] Special Weather Statement: Special Weather Statement issued September 4 at 3:13PM CDT by NWS Amarillo TX
      At 312 PM CDT, Doppler radar was tracking a strong thunderstorm 10 miles northeast of Borger, moving north at 5 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree…
  - (2026-09-04) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 4 at 4:12PM EDT until September 4 at 5:15PM EDT by NWS Blacksburg VA
      SVRRNK The National Weather Service in BLACKSBURG has issued a * Severe Thunderstorm Warning for... Northeastern Surry County in northwestern North Carolina... Northwestern Stokes County in north central North Carolina..…

### Ukrainian Internal News (national + local Kyiv) — 89 new of 139 total
  - (2026-09-04) РФ атакувала ТЦ в Миколаєві: постраждала 17-річна дівчина | LEDE: Російські війська 4 вересня атакували безпілотниками торгівельний центр у Миколаєві, постраждала 17-річна дівчина.] (uk: РФ атакувала…
      Російські війська 4 вересня атакували безпілотниками торгівельний центр у Миколаєві, постраждала 17-річна дівчина.
  - (2026-09-04) У Києві чоловік на вулиці підірвав боєприпас: він і троє людей навколо постраждали | LEDE: У Святошинському районі Києва 4 вересня чоловік привів у дію боєприпас прямо на вулиці. Він і троє люд] (uk:…
      У Святошинському районі Києва 4 вересня чоловік привів у дію боєприпас прямо на вулиці. Він і троє людей поруч постраждали.
  - (2026-09-04) Трамп каже, що його перемовники везуть в Москву і Київ "пропозицію щодо завершення війни" | LEDE: Президент США Дональд Трамп прокоментував майбутні візити його спецпредставників Стіва Віткоффа] (uk:…
      Президент США Дональд Трамп прокоментував майбутні візити його спецпредставників Стіва Віткоффа та Джареда Кушнера до Москви та Києва.
  - (2026-09-04) В Офісі генпрокурора спростували проведення обшуків у Кравченка | LEDE: В Офісі генерального прокурора спростували проведення обшуків у Руслана Кравченка ввечері 4 вересня.] (uk: В Офісі генпрокурора…
      В Офісі генерального прокурора спростували проведення обшуків у Руслана Кравченка ввечері 4 вересня.
  - (2026-09-04) Джерела: Обшуки тривають в генпрокурора, його заступниці та в голови Одеської ОВА | LEDE: За даними джерел "Української правди", НАБУ та САП проводять обшуки в генерального прокурора Руслана Кр] (uk:…
      За даними джерел "Української правди", НАБУ та САП проводять обшуки в генерального прокурора Руслана Кравченка, його заступниці Марії Вдовиченко та в голови Одеської ОВА Олега Кіпера.
  - (2026-09-04) ЗМІ: Адміністрація Трампа готує нову стратегію для Близького Сходу після війни з Іраном | LEDE: Адміністрація американського президента Дональда Трампа працює над післявоєнною стратегією, орієн] (uk:…
      Адміністрація американського президента Дональда Трампа працює над післявоєнною стратегією, орієнтованою на регіональні зусилля щодо стримування Ірану та розширення нормалізації відносин між Ізраїлем та його сусідами.

### State Legislative Action — 80 new of 96 total
  - (2026-09-04) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-09-04) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-09-03) [Alaska HB 193] An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training…
      An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training program account; relating to unempl…
  - (2026-09-03) [Alaska HB 242] An Act relating to sexual assault.
      An Act relating to sexual assault.
  - (2026-09-03) [Alaska HB 77] An Act making the theft of mail or an article within mail theft in the second degree.
      An Act making the theft of mail or an article within mail theft in the second degree.
  - (2026-09-03) [Alaska SB 89] An Act relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating to the practice of medicine; relating to health care…
      An Act relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating to the practice of medicine; relating to health care providers; and relating to provisio…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-09-04) [Russia oil sanctions perimeter · themes] 3 deaths , 68 hours : Repeat Trans - Canada Highway crashes spark safety fears for B . C . Interior
      comoxvalleyrecord.com · English · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] Alias Bendito Menor : fuente humana entregó ubicación del cabecilla antes de ser abatido
      elpais.com.co · Spanish · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] رهان جديد .. هل يتحول اهتمام إنفيديا بعيدًا عن الرقائق ؟
      argaam.com · Arabic · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] Chengdu , Cina : cosa vedere , i panda e le cascate
      viaggi.corriere.it · Italian · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] El acuerdo petrolero entre Venezuela y EEUU , entre grandes promesas e incógnitas
      el-carabobeno.com · Spanish · tone NA
  - (2026-09-04) [Russia oil sanctions perimeter · themes] Κάσος : Αυτοκίνητο με ζευγάρι τουριστών έπεσε στη θάλασσα - Νεκρή η γυναίκα , σώθηκε ο σύζυγός της
      newsit.gr · Greek · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 47 new of 56 total
  - (2026-09-04) [BleepingComputer] IDScan sued over alleged data breach affecting 153 million drivers
      Multiple lawsuits have been filed against identity verification company IDScan after hackers allegedly breached the service and offered to sell more than 153 million driver's licenses. [...]
  - (2026-09-04) [BleepingComputer] Critical Citrix NetScaler auth bypass now leveraged in attacks
      Attackers have begun targeting a critical-severity Citrix NetScaler auth bypass flaw (CVE-2026-19490) in the wild, according to vulnerability intelligence company Previdian. [...]
  - (2026-09-04) [BleepingComputer] Microsoft says some users can’t open the Teams desktop client
      Microsoft is working to resolve a known issue that causes delays or blocks some users from opening the Microsoft Teams desktop client on Windows systems. [...]
  - (2026-09-04) [BleepingComputer] 39 New Methods That Compromise Passkey Authentication
      Passkeys eliminate many password-based attacks, but researchers have documented 39 methods for compromising authentication built around them. Token explains how attackers can abuse authentication prompts, synced credenti…
  - (2026-09-04) [BleepingComputer] New CrowdStrike 'FalconFlank' zero-day grants SYSTEM privileges
      An anonymous security researcher who uses the "Nightmare Eclipse" handle released a CrowdStrike Falcon zero-day exploit named "FalconFlank" that lets attackers escalate privileges on up-to-date Windows systems. [...]
  - (2026-09-04) [The Hacker News] Phishing Campaign Sends Millions of Emails Using Invisible Unicode to Evade Filters
      Microsoft is alerting of a "high-volume phishing campaign" that's using invisible Unicode tag characters to bypass email filters. "Instead of using these characters to hide instructions from people while exposing them to…

### Court opinions of consequence (federal & state) — 42 new of 60 total
  - (2026-09-08) Connecticut Supreme Court: State v. Angel A.
  - (2026-09-08) Connecticut Supreme Court: Perez v. Carusillo
  - (2026-09-04) U.S. Court of Appeals, 1st Cir.: United States v. Gonzalez
  - (2026-09-04) U.S. Court of Appeals, 8th Cir.: Jamestown Villas v. State Farm
  - (2026-09-04) U.S. Court of Appeals, 8th Cir.: Michael Sack v. City of St. Louis
  - (2026-09-04) U.S. Court of Appeals, 8th Cir.: United States v. Francis Dubray

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-04) [Shao Wei-Li] Form 4/A (Reporting)
      filed 2026-09-04 20:14 UTC · amended · role: Reporting — Filed: 2026-09-04 AccNo: 0001610717-26-000404 Size: 5 KB
  - (2026-09-04) [Omada Health, Inc.] Form 4/A (Issuer)
      filed 2026-09-04 20:14 UTC · amended · role: Issuer — Filed: 2026-09-04 AccNo: 0001610717-26-000404 Size: 5 KB
  - (2026-09-04) [Hertzke Patrick Norton] Form 4 (Reporting)
      filed 2026-09-04 20:13 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0002084984-26-000005 Size: 5 KB
  - (2026-09-04) [Sensata Technologies Holding plc] Form 4 (Issuer)
      filed 2026-09-04 20:13 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0002084984-26-000005 Size: 5 KB
  - (2026-09-04) [Vardeman Ryan L.] Form 4 (Reporting)
      filed 2026-09-04 20:13 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001574629-26-000002 Size: 12 KB
  - (2026-09-04) [LIVEPERSON INC] Form 4 (Issuer)
      filed 2026-09-04 20:13 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0001574629-26-000002 Size: 12 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 28 new of 129 total
  - (2026-09-04) [Polymarket] Will Crude Oil reach a new all-time high by December 31?
      This market will resolve to "Yes" if, on any trading day after market creation, the official daily high price published by the CME Group for the Active Month (front month) of CME Crude Oil (CL) futures is greater than $1…
  - (2026-09-04) [Polymarket] Spread: Liverpool FC (-1.5)
      In the upcoming Premier League game, scheduled for September 4 at 3:00 PM ET: This market will resolve to "Liverpool FC" if Liverpool FC win the game by 2 or more goals. Otherwise, this market will resolve to "Ipswich To…
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2036
      December 2036
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2035
      December 2035
  - (2026-09-04) [Kalshi] US labor force participation rate at year-end 2034
      December 2034
  - (2026-09-04) [Manifold] Will Lindsay Clancy stand trial again for killing her three children?

### Government & military aircraft airborne (OpenSky) — 24 new of 25 total
  - (2026-09-04) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (37.5343, -3.4463) · alt: 11277m · 806km/h
  - (2026-09-04) CFC3199 (Canada)
      icao24: c2b373 · position: (49.9492, -101.3398) · alt: 11277m · 934km/h
  - (2026-09-04) PAT929 (United States)
      icao24: adfe4c · position: (43.6273, -84.2137) · alt: 6614m · 406km/h
  - (2026-09-04) SAM934 (United States)
      icao24: adfeb8 · position: (25.8815, -80.1545) · alt: 1584m · 520km/h
  - (2026-09-04) JEDI31 (United States)
      icao24: ae1eaa · position: (37.8839, -93.4692) · alt: 5814m · 444km/h
  - (2026-09-04) CFC4508 (United States)
      icao24: a37b7e · position: (44.1046, -77.2143) · alt: 822m · 256km/h

### U.S. Federal Action — 14 new of 18 total
  - (2026-09-04) Geographic Targeting Order Imposing Recordkeeping and Reporting Requirements on Certain Money Services Businesses Along the Southwest Border
      FinCEN is issuing this Geographic Targeting Order, requiring certain money services businesses along the southwest border of the United States to report and retain records of transactions in currency of $1,000 or more, b…
  - (2026-09-04) Transfer Agent Rules
      The U.S. Securities and Exchange Commission ("SEC" or "Commission") is proposing to adopt new rules, amend existing rules, amend the existing form for registration with the Commission as a transfer agent (Form TA-1) and…
  - (2026-09-04) Reducing Bureaucracy and Burden for the Repatriation of Mentally Ill Nationals
      The Department of Health and Human Services, Administration for Children and Families proposes to remove the Care and Treatment of Mentally Ill Nationals of the United States, Returned from Foreign Countries regulations…
  - (2026-09-04) Drawbridge Operation Regulation; Savannah River, Clyo, GA
      The Coast Guard is removing the existing drawbridge operation regulation for the CSX Transportation railroad bridge, mile 60.9, near Clyo, GA. The drawbridge was converted to a fixed bridge in August 2026, and the operat…
  - (2026-09-04) Driving Efficiency in Farm Loan Delivery
      The Farm Service Agency (FSA) is amending the Farm Loan Program (FLP) regulations to permanently implement the Application Fast Track (AFT) process, which expedites underwriting for certain direct loan applicants by usin…
  - (2026-09-04) Modernizing Medical Standards for Non-Insulin Dependent Diabetes Mellitus Cases
      FAA proposes to amend its regulations to allow applicants with non-insulin dependent diabetes mellitus to apply for airman medical certification that may be issued at the time of their medical examination instead of requ…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-04) US Open ATP: Alexander Bublik vs Tommy Paul
      yes price: 0% · 24h volume: $2,105,377 · resolves 2026-09-11
  - (2026-09-04) Counter-Strike: FURIA vs Vitality (BO3) - BLAST Open Porto Playoffs
      yes price: 0% · 24h volume: $2,089,405 · resolves 2026-09-04
  - (2026-09-04) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 14% · 24h volume: $2,037,454 · resolves 2027-01-01
  - (2026-09-04) US Open ATP: Yibing Wu vs Carlos Alcaraz
      yes price: 2% · 24h volume: $1,971,454 · resolves 2026-09-11
  - (2026-09-04) Will Liverpool FC win on 2026-09-04?
      yes price: 96% · 24h volume: $1,296,199 · resolves 2026-09-04
  - (2026-09-04) Will Real Madrid CF win on 2026-09-04?
      yes price: 64% · 24h volume: $1,284,779 · resolves 2026-09-04

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-09-04) M 5.4 - Kermadec Islands region
      M5.4 · Kermadec Islands region · depth 10 km
  - (2026-09-04) M 5.2 - 28 km S of Cilacap, Indonesia
      M5.2 · 28 km S of Cilacap, Indonesia · depth 10 km
  - (2026-09-04) M 5.1 - 25 km W of Padangsidempuan, Indonesia
      M5.1 · 25 km W of Padangsidempuan, Indonesia · depth 121.712 km
  - (2026-09-04) M 5.0 - South Sandwich Islands region
      M5.0 · South Sandwich Islands region · depth 10 km
  - (2026-09-04) M 5.0 - 236 km ESE of Attu Station, Alaska
      M5.0 · 236 km ESE of Attu Station, Alaska · depth 10 km · TSUNAMI
  - (2026-09-04) M 4.9 - south of the Fiji Islands
      M4.9 · south of the Fiji Islands · depth 76.735 km

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 104 total
  - (2026-09-04) [OFAC] Iran-related Designations; Issuance of Iran-related General License - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Iran-related General License Office of Foreign Assets Control (.gov)
  - (2026-09-03) [OFAC] Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License - Office of Foreign Assets Control (.gov)
      Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License Office of Foreign Assets Control (.gov)
  - (2026-09-04) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se Office of Foreign Assets Control (.gov)
  - (2026-09-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)
  - (2026-09-02) [OFAC] 1247 - Office of Foreign Assets Control (.gov)
      1247 Office of Foreign Assets Control (.gov)
  - (2026-09-04) [USASpending] $4,429,530,857 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WI
      Agency: National Aeronautics and Space Administration. Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOLID…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-09-04) #30 Masayoshi Son — $68.74B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-09-04) MOVER ▼ Elon Musk — $908.35B ($-17.85B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-09-04) MOVER ▲ Larry Ellison — $202.38B (+$4.13B since yesterday)
      United States · Technology · source: Oracle
  - (2026-09-04) MOVER ▼ Larry Page — $276.82B ($-2.90B since yesterday)
      United States · Technology · source: Google
  - (2026-09-04) MOVER ▼ Sergey Brin — $255.38B ($-2.67B since yesterday)
      United States · Technology · source: Google
  - (2026-09-04) MOVER ▲ Michael Dell — $258.25B (+$2.28B since yesterday)
      United States · Technology · source: Dell Technologies

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-04) [Marginal Revolution] How are the market valuations for the U.S: insurers doing?
      U.S. insurance stocks have been doing quite well since the beginning of May 2026, and they have materially outperformed the overall market. I’m using the May 1 close through the September 3 close so that we compare compl…
  - (2026-09-04) [Marginal Revolution] Friday assorted links
      1. “After work, we’ll have each other.” 2. Gloria Steinem, RIP (NYT). 3. Henry Oliver on Finding Emily. 4. Solve for the Russian family squabble equilibrium (short video). 5. New Fuchsia Dunlop book due out October 20. 6…
  - (2026-09-04) [Marginal Revolution] Real GDP Per Capita and the Standard of Living
      We are freshening up some of our videos with updated data so now is a good time to remind everyone that Modern Principles of Economics is best principles of economics textbook; great videos, clear writing and excellent a…
  - (2026-09-03) [Conversable Economist] Gross and Net US Investment
      Each year, more than half of the total or gross investment by US firms just makes up for depreciation in older equipment and knowledge. in recent year, it’s more like 75% of current year investment just offsets depreciat…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 22 total
  - (2026-09-04) CVE-2026-85046 · Google Chromium V8: Google Chromium V8 Type Confusion Vulnerability
      vendor: Google · product: Chromium V8 · CISA remediation by 2026-09-18

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=19, 14d-median=19; carrying terms: published, proposed, safety, unless, national, certain, existing, action, associated, service, regulatory, public
- state_bills: today=96, 7d-median=78, 14d-median=80; carrying terms: agencies, based, conditions, generally, makes, california, civil, pursuant, regulatory, until, quality, providing
- state_news: today=792, 7d-median=648, 14d-median=648; carrying terms: november, based, decoding, forest, republican, campaign, thousands, california, jones, kansas, patients, current
- local_news: today=258, 7d-median=238, 14d-median=238; carrying terms: decoding, atlanta, alert, investigation, north, atlantamagazine, district, stlmag, target, louis, found, local
- foreign_news: today=1122, 7d-median=1096, 14d-median=1041; carrying terms: account, measure, november, sentenced, course, eastern, guizhou, captain, firms, based, nanking, achieve
- chinese_internal: today=287, 7d-median=287, 14d-median=287; carrying terms: cbmiw, cbmibefvx, cbmia, caixin, target, cbmizefvx, cbmixkfvx, lxtfb, cbmizkfvx, cbmiykfvx, global, cbmibkfvx
- russian_internal: today=1266, 7d-median=1074, 14d-median=1074; carrying terms: novayagazeta, forbidden, laquo, social, error, wildberries, financial, gazeta, title, journal, street, telegram
- ukrainian_internal: today=139, 7d-median=122, 14d-median=119; carrying terms: attacks, minister, vechirniy, major, moscow, germany, study, president, zelensky, elections, tensions, children
- ukraine_theater: today=797, 7d-median=612, 14d-median=735; carrying terms: rkxprmx, chain, bvbfjztgqzsjzvtmtpejjnbw, ekvqylj, wltfhszntz, jnfhxbllhefv, nqzfjwjlmmemztwjottd, piafpot, rlqkdzzlk, polygon, cuxqcnhzrmngsnazc, cuxox
- paper_bets: today=129, 7d-median=133, 14d-median=132; carrying terms: mamdani, house, rippling, successor, goals, jackson, artist, december, decrease, north, sachs, succeed
- weather: today=171, 7d-median=145, 14d-median=143; carrying terms: eastern, western, seattle, levels, conditions, afdlsx, afdmfl, impacts, streams, rainfall, synopsis, increasing
- macro: today=20, 7d-median=21, 14d-median=21; carrying terms: money, cpiaucsl, headline, energy, implied, unrate, growth, jolts, pcepilfe, sheet, latest, commodities
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, proxy, equities, yield, bitcoin, futures, china, nasdaq, natural, russell, agriculture, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=109, 14d-median=108; carrying terms: energy, attacks, myanmar, sevastopol, eastern, annexation, nicaragua, venezuela, february, based, adopted, weapons
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, client, error, congresstrading, httperror, quiverquant, quantitative, quiver, https
- billionaires: today=40, 7d-median=0, 14d-median=30; carrying terms: gautam, charles, madrid, infrastructure, arnault, yiming, discount, google, ellison, brokerage, tiktok, nasdaq
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, state, court, america, connecticut, appeals, county, company, energy, board, blanche, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, trust, holdings, group, filer, michael, amended, therapeutics, technologies
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: krishnamoorthi, house, angels, pinkston, jonathan, lindsey, disbursements, raised, cooper, talarico, filing, robert
- gdelt_regions: today=6, 7d-median=9, 14d-median=9; carrying terms: english, japan
- gdelt_gkg: today=50, 7d-median=50, 14d-median=50; carrying terms: english, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=25, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, ground, bulgaria, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: cumulative, organs, ethiopia, november, published, passengers, andes, travel, person, index, developed, early
- cisa_kev: today=22, 7d-median=21, 14d-median=20; carrying terms: authentication, forgery, collaboration, synacor, suite, microsoft, injection, request, improper, command, function, missing
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=12, 7d-median=13, 14d-median=14; carrying terms: depth, islands, indonesia, south, region, chile, alaska, philippines, sandwich, zealand
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: presidential, donetsk, champions, shakhtar, decrease, volume, championship, rates, meeting, september, price, resolves
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, https, class, economist, conversable, revolution, economy, recent, conversableeconomist, current, point, marginalrevolution
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: computerweekly, attacks, schneier, according, openai, review, companies, technology, using, researchers, recent, month
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: charles, paulina, shontel, wiles, energy, chief, sheehy, hollen, coney, webster, mcbride, comptroller
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, unavailable, converges, identify, sufficient, placement, claude, paper, decision, market, today, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*