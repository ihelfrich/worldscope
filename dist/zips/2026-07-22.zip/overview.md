# WORLDSCOPE morning brief — 2026-07-22

## Headline
2226 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (563) · Russian Internal News (state + in-exile) (465) · World leaders & government officials (324) · Chinese Internal News (203) · U.S. Weather + Severe / Climate Outlooks (157) · Ukraine Theater (total-war monitoring) (91) · State-Level News (75) · Local News: St. Louis + Atlanta (74) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (34) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 563 new of 1025 total
  - (2026-07-22) [Global] Ukrainian drones hit more sites of Russian online retailer Wildberries
      Logistics hubs belonging to Wildberries in the Krasnodar and Stavropol regions were struck overnight.
  - (2026-07-22) [Global] Iran war has cost US $37.5bn so far, Hegseth says, as Pentagon seeks billions more
      The hearing was disrupted by protests and a shouting match as Hegseth testified at a pivotal time in the war.
  - (2026-07-22) [Global] India's Modi government under growing pressure as 'cockroach' protests intensify
      The CJP got a boost on Tuesday when the opposition Congress party demonstrated outside the PM's house.
  - (2026-07-22) [Global] France passes law banning under-15s from social media
      The law will require social media platforms in France to verify all users age from January.
  - (2026-07-21) [Global] Tokyo urges men to wear shorts to work, but some women say it's 'leg hair harassment'
      The Tokyo Metropolitan Government wants workers to ditch the suit and tie for t-shirts, trainers - and shorts.
  - (2026-07-22) [Global] Police station opens at Hitler's birthplace in bid to rid site of Nazi link
      The opening follows years of controversy about what to do with the 17th-Century former inn, where the Nazi dictator was born.

### Russian Internal News (state + in-exile) — 465 new of 1060 total
  - (2026-07-22) Во Франции найден мертвым модельный агент, которого подозревали в подборе девушек для Эпштейна | LEDE: Бывшего модельного агента Даниэля Сиада, которого считали предполагаемым сообщником Дже] (ru: Во…
      Бывшего модельного агента Даниэля Сиада, которого считали предполагаемым сообщником Джеффри Эпштейна, нашли мертвым в его доме в городе Коломб недалеко от Парижа. Информацию подтвердили в парижской прокуратуре.
  - (2026-07-22) Росавиация снизила высоту полетов у Москвы и запретила транзитные перелеты через город. Время полета и расходы на топливо вырастут | LEDE: Росавиация снизила предельную высоту полета самолет] (ru: Рос…
      Росавиация снизила предельную высоту полета самолетов в районе московских аэропортов до 4900 метров и запретила транзитные пролеты через него, сообщил «Коммерсант», ссылаясь на извещение пользователей воздушного простран…
  - (2026-07-22) Орнелла Мути собирается получить гражданство России | LEDE: Итальянская певица Найке Ривелли, дочь актрисы Орнеллы Мути, рассказала РИА Новости, что они с матерью собираются получить российс] (ru: Орн…
      Итальянская певица Найке Ривелли, дочь актрисы Орнеллы Мути, рассказала РИА Новости, что они с матерью собираются получить российское гражданство.
  - (2026-07-22) Bloomberg: Кремль передумал возвращать Украине часть оккупированных территорий, так как договоренности Анкориджа сорваны | LEDE: Россия больше не планирует возвращать Украине часть оккупиров] (ru: Blo…
      Россия больше не планирует возвращать Украине часть оккупированных территорий в рамках возможной сделки о прекращении войны, сообщает Bloomberg со ссылкой на источники, близкие к Кремлю.
  - (2026-07-22) Украина второй раз за неделю атаковала склады Wildberries. На Кубани и Ставрополье — масштабные пожары. Фотографии и видео. Материал обновляется | LEDE: Украинские беспилотники в ночь на 22 ] (ru: Укр…
      Украинские беспилотники в ночь на 22 июля атаковали логистические центры Wildberries в Краснодаре и Невинномысске (Ставропольский край). Там начались сильные пожары. К тушению привлекли вертолеты МЧС. По данным властей К…
  - (2026-07-22) Пентагон оценил стоимость войны США с Ираном в 37,5 миллиарда долларов | LEDE: Боевые действия против Ирана обойдутся США в 37,5 миллиарда долларов, заявил глава Пентагона Пит Хегсет на слуш] (ru: Пен…
      Боевые действия против Ирана обойдутся США в 37,5 миллиарда долларов, заявил глава Пентагона Пит Хегсет на слушаниях в конгрессе. По его словам, эта сумма включает в себя как уже потраченные на войну деньги, так и прогно…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 203 new of 307 total
  - (2026-07-21) In Depth: Louis Vuitton’s Trademark Win Sparks Backlash in China - Caixin Global
      In Depth: Louis Vuitton’s Trademark Win Sparks Backlash in China Caixin Global
  - (2026-07-21) PRO专享/数据深度专题 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMie0FVX3lxTE9JbXNhZGtDdnFwZy1Ic2dOQmlkQXVjNmVJSGJxVFlfOVlsaGVqY3ZVd3MybVlJQUtrQng2VFBXc3cwZXhkeDZjVi1J] (zh:…
      PRO专享/数据深度专题 deepview.caixin.com
  - (2026-07-22) 今日开盘：两市双双低开 沪指跌幅0.64% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9nNTY3dWtkLW9zSm9Kbm82LUs4QzVhSGg1R0NmQmkwRVgxd3FQVTRCU2tHQk9XYlF1dWxfb0FRcHc2VUZyQzB5TjJ2cnpyUkNF] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.64% 财新
  - (2026-07-21) 视线｜39天狂欢散场：世界杯球迷众生相 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5zMkM3b2NPOGZOYXI5WW1xMUE1Uy10VkJIMW04TG45MmY0NFNEVFFQeVJ2WFhhbVdYX2J2Z3dJb2w1OXNySC1nNlBERXUwcUV3Sm] (zh:…
      视线｜39天狂欢散场：世界杯球迷众生相 财新
  - (2026-07-22) 继澳大利亚之后 法国将禁止15岁以下未成年人使用社交媒体 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5BQnlfM0s3ZnJKWHVjWEtsYjJFMGl6dUFoNjVoU2hXR0pzQzRYeUtOYzMxbGhWR0Rja1hRSlNRSnRWZ2h3alhPbW9ZT] (zh:…
      继澳大利亚之后 法国将禁止15岁以下未成年人使用社交媒体 财新
  - (2026-07-22) 野村：美中期选举前联储难加息 日元贬值压力年底前或缓解 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE44aWNNbUVJZXpLNUt3MFNiSEdSOXprcm1aYW1vTUpCMTJJamNyYzdLaGhyS1NJWTlNbnNqdm9EZ2VNc2l3c0hhRkY3SV] (zh:…
      野村：美中期选举前联储难加息 日元贬值压力年底前或缓解 财新

### U.S. Weather + Severe / Climate Outlooks — 157 new of 175 total
  - (2026-07-22) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-22) [Moderate] Heat Advisory: Heat Advisory issued July 22 at 4:35AM CDT until July 22 at 8:00PM CDT by NWS New Orleans LA
      * WHAT...Heat index values up to 113 expected. * WHERE...Northern Hancock, Northern Harrison, Northern Jackson, Southern Hancock, Southern Harrison, and Southern Jackson Counties. * WHEN...From 10 AM this morning to 8 PM…
  - (2026-07-22) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 22 at 4:35AM CDT until July 22 at 8:00PM CDT by NWS New Orleans LA
      * WHAT...Dangerously hot conditions with heat index values up to 115 expected. * WHERE...Portions of southeast Louisiana and southern Mississippi. * WHEN...From 10 AM this morning to 8 PM CDT this evening. * IMPACTS...He…
  - (2026-07-22) [Severe] Extreme Heat Watch: Extreme Heat Watch issued July 22 at 2:33AM PDT until July 27 at 9:00PM PDT by NWS Hanford CA
      * WHAT...Dangerously hot conditions with high temperatures between 108 to 112 degrees. * WHERE...Indian Wells Valley and Mojave Desert. * WHEN...From Thursday morning through Monday evening. * IMPACTS...Heat related illn…
  - (2026-07-22) [Severe] Coastal Flood Warning: Coastal Flood Warning issued July 22 at 4:32AM CDT until July 23 at 4:00AM CDT by NWS New Orleans LA
      * WHAT...Significant coastal flooding. * WHERE...In Louisiana, Lower St. Bernard, Southeast St. Tammany, Eastern Orleans and Lower Plaquemines Parishes. In Mississippi, Southern Hancock, Southern Harrison and Southern Ja…
  - (2026-07-22) [Severe] Flood Warning: Flood Warning issued July 22 at 5:30AM EDT until July 22 at 11:00AM EDT by NWS Pittsburgh PA
      * WHAT...Small stream flooding caused by excessive rainfall continues. * WHERE...Southern Monroe County in east central Ohio... Southern Noble County in east central Ohio... Western Wetzel County in northern West Virgini…

### Ukraine Theater (total-war monitoring) — 91 new of 337 total
  - (2026-07-21) [FIRMS] thermal anomaly 48.190, 22.640 (FRP 1.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.92 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.870, 33.434 (FRP 0.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 0.93 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.866, 33.433 (FRP 0.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 0.77 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.860, 33.445 (FRP 1.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.76 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.867, 33.433 (FRP 1.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.52 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.861, 33.445 (FRP 2.59 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 2.59 MW

### State-Level News — 75 new of 772 total
  - (2026-07-22) [Arizona] Voucher oversight fight tilts GOP superintendent primary toward Kimberly Yee over Tom Horne
      Kimberly Yee is maintaining a large lead in the GOP nomination for public schools chief, a victory that would see her unseat GOP incumbent Tom Horne, who is in his second stint as the Superintendent of Public Instruction…
  - (2026-07-22) [Arizona] Trump-backed former NFL kicker Jay Feely wins CD1 GOP primary as Amish Shah leads Dem field
      Republican Jay Feely, a former NFL kicker who played for the Arizona Cardinals, has advanced to the November election, where it seems likely he will face off against former Democratic state lawmaker Amish Shah in one of…
  - (2026-07-22) [Arizona] Warren Petersen poised to win GOP primary for attorney general over Rodney Glassman
      State Sen. Warren Petersen is leading rival Rodney Glassman to become the Republican nominee for Arizona Attorney General. The margin separating Petersen and Rodney Glassman was more than 47,000 votes Tuesday evening. Wh…
  - (2026-07-22) [Arizona] GOP picks election denier Alexander Kolodin to challenge Adrian Fontes for secretary of state
      Far-right state lawmaker and election attorney Alexander Kolodin, who has backed President Donald Trump’s evidence-free election fraud claims, won the GOP nomination for Arizona secretary of state He defeated Gina Swobod…
  - (2026-07-22) [Arizona] Andy Biggs easily defeats David Schweikert, wins GOP nomination for governor
      U.S. Rep. Andy Biggs trounced his chief opponent, fellow Congressman David Schweikert, in the Republican primary for Arizona governor on Tuesday. Biggs, who is endorsed by President Donald Trump, had such a massive lead…
  - (2026-07-22) [California] Governor Newsom signs tribal-state gaming compact 7.21.26
      Source

### Local News: St. Louis + Atlanta — 74 new of 227 total
  - (2026-07-22) [St. Louis] Where in Chesterfield 7/22/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-07-22) [St. Louis] Asador Del Sur owners to return with new restaurant in St. Louis Hills
      When a devastating fire ripped through Asador Del Sur in Maplewood last August, owners Maria Giamportone and Daniel Gonzalez worried that their restaurant dreams may have ended. Less than a year after the that tragic day…
  - (2026-07-22) [St. Louis] President Trump to attend dignified transfer of US service members killed in the Middle East
      President Donald Trump will be at Dover Air Force Base when the remains of the troops killed in action are returned to their families, the White House said.
  - (2026-07-22) [St. Louis] Huge crowd packs Liberty HS to honor hockey player killed in crash
      At least 100 mourners packed the school's football field Tuesday to honor 18-year-old Zachary Pruss.
  - (2026-07-22) [St. Louis] Missouri targets copper infrastructure thieves with harsher penalties amid rising theft rates
      A new state law elevates stealing copper from critical infrastructure to a felony punishable by up to 10 years in prison.
  - (2026-07-22) [St. Louis] 82-year-old north St. Louis County woman still waiting for A/C repair after more than a week
      It's been nearly a week and the north St. Louis County great-grandmother is still fuming because her central air system has not been fixed.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-22) [KIDOZ INC.] Form 4 (Issuer)
      filed 2026-07-22 01:25 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0001278521-26-000011 Size: 12 KB
  - (2026-07-22) [Williams Tryon M] Form 4 (Reporting)
      filed 2026-07-22 01:25 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0001278521-26-000011 Size: 12 KB
  - (2026-07-22) [KIRBY J SCOTT] Form 4 (Reporting)
      filed 2026-07-22 01:16 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0000100517-26-000142 Size: 11 KB
  - (2026-07-22) [United Airlines Holdings, Inc.] Form 4 (Issuer)
      filed 2026-07-22 01:16 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0000100517-26-000142 Size: 11 KB
  - (2026-07-22) [Kim Vyacheslav] Form 4 (Reporting)
      filed 2026-07-22 01:14 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0001193125-26-311001 Size: 13 KB
  - (2026-07-22) [Joint Stock Co Kaspi.kz] Form 4 (Issuer)
      filed 2026-07-22 01:14 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0001193125-26-311001 Size: 13 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-22) [Ireland] Sentenced to five months and banned for eight years - Courts
      domain: carlow-nationalist.ie · language: English · tone:
  - (2026-07-22) [Australia] US still willing to negotiate over Iran crisis : Rubio
      domain: dailyliberal.com.au · language: English · tone:
  - (2026-07-22) [Spain] Malaga police search for perpetrator of murder of 45 - year - old woman with neck cut in Benahavís
      domain: surinenglish.com · language: English · tone:
  - (2026-07-22) [United Kingdom] I was bitten by venomous snake that was hiding under my sofa
      domain: aol.co.uk · language: English · tone:
  - (2026-07-22) [United Kingdom] I visited stunning united kingdom seaside town with quiet beach and the best fish and chips ever
      domain: aol.co.uk · language: English · tone:
  - (2026-07-22) [Taiwan] FTC extends review of Grab - foodpanda Taiwan deal to Oct . 27
      domain: focustaiwan.tw · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 34 new of 107 total
  - (2026-07-22) Канада закликала до постійного припинення вогню на Близькому Сході | LEDE: Міністерка закордонних справ Канади Аніта Ананд закликала до деескалації та постійного припинення вогню на Близькому С] (uk:…
      Міністерка закордонних справ Канади Аніта Ананд закликала до деескалації та постійного припинення вогню на Близькому Сході, оскільки ситуація там є "досить серйозною".
  - (2026-07-22) В МЗС відреагували на "таємну" зустріч експосадовців РФ і Німеччини | LEDE: Речник Міністерства закордонних справ Георгій Тихий висловився щодо "таємної" зустрічі у Баку колишніх високопосадовц] (uk:…
      Речник Міністерства закордонних справ Георгій Тихий висловився щодо "таємної" зустрічі у Баку колишніх високопосадовців Німеччини та Росії.
  - (2026-07-22) Мобілізований прикордонник намагався втекти зі служби за $3 тисячі | LEDE: Підозру оголосили військовослужбовцю Державної прикордонної служби, який запропонував командиру підрозділу 3 тисячі до] (uk:…
      Підозру оголосили військовослужбовцю Державної прикордонної служби, який запропонував командиру підрозділу 3 тисячі доларів США за допомогу у власній втечі зі служби.
  - (2026-07-22) У Варшаві стався технічний збій під час тестування системи повітряної тривоги | LEDE: У Варшаві ввечері 21 липня після офіційного завершення навчань ALARM-26 несподівано знову пролунали сигнали] (uk:…
      У Варшаві ввечері 21 липня після офіційного завершення навчань ALARM-26 несподівано знову пролунали сигнали повітряної тривоги – у польському Урядовому центрі безпеки (RCB) вважають, що причиною стала технічна несправніс…
  - (2026-07-22) У Польщі засудили українця, що керував вантажівкою з 2,5 проміле алкоголю у крові | LEDE: 63-річного водія з України у Польщі засудили за водіння з 2,5 проміле алкоголю у крові.] (uk: У Польщі засудил…
      63-річного водія з України у Польщі засудили за водіння з 2,5 проміле алкоголю у крові.
  - (2026-07-22) 21-й удар по економіці РФ: як працюють санкції ЄС і чому їх так складно ухвалюють | LEDE: ] (uk: 21-й удар по економіці РФ: як працюють санкції ЄС і чому їх так складно ухвалюют)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-22) [Taiwan Strait + South China Sea · themes] DAX kämpft um wichtige Marke - Öl , Iran , 3M , OpenAI , Micron , BTC , Eckert & Ziegler , Airbus , Gea
      boerse-online.de · German · tone NA
  - (2026-07-22) [Taiwan Strait + South China Sea · themes] Temporal en Chile : las autoridades decretaron alerta roja y suspendieron clases en Valparaíso
      infobae.com · Spanish · tone NA
  - (2026-07-22) [Taiwan Strait + South China Sea · themes] С виновника ДТП в Братском районе взыщут 100 тысяч рублей компенсации пострадавшей пассажирке автобуса
      i38.ru · Russian · tone NA
  - (2026-07-22) [Taiwan Strait + South China Sea · themes] US still willing to negotiate over Iran crisis : Rubio
      dailyliberal.com.au · English · tone NA
  - (2026-07-22) [Taiwan Strait + South China Sea · themes] Lutte acharnée contre lincendie du Var qui a parcouru 2 . 550 hectares
      notretemps.com · French · tone NA
  - (2026-07-22) [Taiwan Strait + South China Sea · themes] Insurance critical to solving Nigeria housing deficit
      thesun.ng · English · tone NA

### U.S. Federal Action — 22 new of 22 total
  - (2026-07-22) Methylene Chloride
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Methylene Chloride standard. Following consideration of the rulemaking by OSHA's Advisory Committee on…
  - (2026-07-22) Vinyl Chloride
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Vinyl Chloride standard. Following consideration of the rulemaking by OSHA's Advisory Committee on Con…
  - (2026-07-22) Methylenedianiline
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Methylenedianiline standards. Following consideration of the rulemaking by OSHA's Advisory Committee o…
  - (2026-07-22) Lead
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Lead standards. Following consideration of the rulemaking by OSHA's Advisory Committee on Construction…
  - (2026-07-22) Inorganic Arsenic
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Inorganic Arsenic standard. Following consideration of the rulemaking by OSHA's Advisory Committee on…
  - (2026-07-22) Formaldehyde
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Formaldehyde standard. Following consideration of the rulemaking by OSHA's Advisory Committee on Const…

### IT, InfoSys & cybersecurity news (last 7 days) — 19 new of 57 total
  - (2026-07-22) [Krebs on Security] LG to Ban Residential Proxies from Smart TV Apps
      The home appliance giant LG Electronics USA said this week it plans to suspend any apps built for its smart TVs that turn one's television into an always-on residential proxy node. The move comes less than a month after…
  - (2026-07-22) [BleepingComputer] Chick-fil-A discloses data breach after credential stuffing attacks
      American fast food restaurant chain Chick-fil-A is notifying customers of a data breach after their accounts were hacked in a wave of recent credential stuffing attacks. [...]
  - (2026-07-22) [BleepingComputer] OpenAI says its AI models hacked Hugging Face during testing
      OpenAI says its AI models, including GPT‑5.6 Sol and a pre-release model, hacked into the Hugging Face artificial intelligence repository while being tested in a sandboxed testing environment. [...]
  - (2026-07-22) [The Hacker News] Police Dismantle Kratos Phishing Kit Built to Steal Microsoft 365 Sessions and Bypass MFA
      German and US law enforcement have taken down the core infrastructure of Kratos, described by German investigators as one of the world's most widely used criminal phishing kits, and Indonesian authorities arrested the ma…
  - (2026-07-22) [The Hacker News] Trojanized Newtonsoft.Json Fork Hides Game-Rigging Code in a Working Library
      Cybersecurity researchers have discovered a NuGet typosquat that's unlike the typical information-stealing malware distributed via package registries: usual info-stealers: it's designed to rig live game results on Digita…
  - (2026-07-22) [The Hacker News] Microsoft Azure DevOps MCP Flaw Lets Hidden PR Comments Hijack AI Review Agents
      A single invisible comment in an Azure DevOps pull request can turn a reviewer's own AI coding agent against them, driving it into projects the attacker has no rights to reach and quietly leaking what it finds. The flaw…

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: Exxon Mobil Corp v. OSHC
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: United States v. Fullerton
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: United States v. Palomares
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Jenkins v. Prime Insurance
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Miller v. CNH Industrial America
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: United States v. Threatt

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-22) [China] CATL to deploy first large - scale sodium - ion energy storage project in Central and Eastern Europe · TechNode
      technode.com · English
  - (2026-07-22) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-22) [China] Which brands won the FIFA World Cup : a data analysis
      campaignasia.com · English
  - (2026-07-22) [China] VW targets rollout of L3 capabilities in China in 2027
      europe.chinadaily.com.cn · English
  - (2026-07-22) [China] China hit an oil and gas output record last year – why is Beijing warning of a squeeze ?
      scmp.com · English
  - (2026-07-22) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 111 total
  - (2026-07-22) [USASpending] $15,578,433,008 → LOCKHEED MARTIN CORP: TAS::80 0124::TAS DESIGN, DEVELOPMENT, TEST&EVALUATION OF PR
      Agency: National Aeronautics and Space Administration. Description: TAS::80 0124::TAS DESIGN, DEVELOPMENT, TEST&EVALUATION OF PROJECT ORION
  - (2026-07-22) [USASpending] $8,561,512,218 → BROOKHAVEN SCIENCE ASSOCIATES LLC: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
      Agency: Department of Energy. Description: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
  - (2026-07-22) [USASpending] $2,170,949,215 → THE TRUSTEES OF PRINCETON UNIVERSITY: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE P
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE PRINCETON PLASMA PHYSICS LABORATORY (PPPL)
  - (2026-07-22) [USASpending] $2,121,046,270 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.
  - (2026-07-22) [USASpending] $1,599,628,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-07-22) [USASpending] $1,451,665,745 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-07-22) LoL: LGD Gaming vs EDward Gaming - Game 1 Winner
      yes price: 86% · 24h volume: $778,548 · resolves 2026-07-22
  - (2026-07-22) Will Vivek Ramaswamy win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $556,625 · resolves 2028-11-07
  - (2026-07-22) Segovia: Yi Zhou vs Luka Pavlovic
      yes price: 22% · 24h volume: $426,262 · resolves 2026-07-29
  - (2026-07-22) Will LeBron James play for the Golden State Warriors in 2026-27?
      yes price: 11% · 24h volume: $354,021 · resolves 2026-10-31
  - (2026-07-22) LoL: LGD Gaming vs EDward Gaming (BO3) - LPL Group Ascend
      yes price: 66% · 24h volume: $352,749 · resolves 2026-07-22
  - (2026-07-22) Will Fabian Ruiz win the 2026 Ballon d'Or?
      yes price: 2% · 24h volume: $334,876 · resolves 2026-10-31

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 37 total
  - (2026-07-22) MOVER ▼ Gautam Adani — $88.07B ($-1.66B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-22) MOVER ▼ Tadashi Yanai & family — $65.83B ($-1.65B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-22) MOVER ▼ Mukesh Ambani — $87.37B ($-0.90B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-22) MOVER ▲ Amancio Ortega — $137.85B (+$0.61B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-22) MOVER ▼ Masayoshi Son — $66.95B ($-0.52B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-22) MOVER ▲ Francoise Bettencourt Meyers & family — $93.03B (+$0.23B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Paper Trading Scorecard — 5 new of 143 total
  - (2026-07-22) [Polymarket] Will the US announce withdrawal from MOU negotiations by August 31?
      On June 14, 2026, the United States and Iran announced a memorandum of understanding ending the immediate conflict and establishing a 60-day framework for negotiating a final agreement. This market will resolve to "Yes"…
  - (2026-07-22) [Manifold] Free Lottery (cat & rat)
  - (2026-07-22) [Manifold] Will a consumer AI meaningfully hack something to answer a question for a regular user by eoy 2027?
  - (2026-07-22) [Manifold] Will "How big is the Sun? How could you figure it out?" make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-07-22) [Manifold] Lebron James to sign with a former team?

### USGS earthquakes (M4.5+, past day) — 4 new of 17 total
  - (2026-07-22) M 5.0 - 55 km WSW of Langsa, Indonesia
      M5.0 · 55 km WSW of Langsa, Indonesia · depth 10 km
  - (2026-07-22) M 4.9 - 208 km W of Abepura, Indonesia
      M4.9 · 208 km W of Abepura, Indonesia · depth 21.587 km
  - (2026-07-22) M 4.7 - 12 km SE of Cuya, Chile
      M4.7 · 12 km SE of Cuya, Chile · depth 60.814 km
  - (2026-07-22) M 4.6 - 124 km SE of Kuril’sk, Russia
      M4.6 · 124 km SE of Kuril’sk, Russia · depth 35 km

### GDACS — global disaster alerts — 3 new of 203 total
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-22) [Marginal Revolution] Alec Stapp on the new Science report from Michael Kratsios
      Major new report from the White House Office of Science and Technology Policy. Five things in the report I really liked: 1. Proposes metascience units as a way to advance experimentation in science agencies. IFP recommen…
  - (2026-07-22) [Marginal Revolution] Betting markets in everything
      Alan and Karen Miller’s first dance was a win-or-lose moment for many of their wedding guests. As the couple glided across the floor during their reception in New Rochelle, N.Y., last year, attendees kept track of the ch…

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: remove, fishery, protect, amendments, unless, management, marine, amendment, pacific, published, final, action
- state_bills: today=0, 7d-median=115, 14d-median=115; carrying terms: staff, records, caucus, implementation, state, political, appropriations, component, another, amending, january, consumer
- state_news: today=772, 7d-median=729, 14d-median=729; carrying terms: campaigns, labor, claims, being, hearing, james, wildlife, anticipated, lansing, exemption, church, called
- local_news: today=227, 7d-median=227, 14d-median=227; carrying terms: state, downtown, scaled, health, office, dispatch, responsible, hospitalized, including, announced, community, reports
- foreign_news: today=1025, 7d-median=1024, 14d-median=1024; carrying terms: claims, spacecraft, guarantee, catch, wildlife, warned, forms, drove, today, consumer, messi, mobile
- chinese_internal: today=307, 7d-median=301, 14d-median=301; carrying terms: cbmix, caixin, chinese, title, cbmickfvx, cbmizefvx, cbmibefvx, retail, sources, cbmixkfvx, cbmiykfvx, cbmiw
- russian_internal: today=1060, 7d-median=893, 14d-median=893; carrying terms: error, netflix, novayagazeta, telegram, variety, street, journal, bloomberg, https, financial, forbidden, times
- ukrainian_internal: today=107, 7d-median=126, 14d-median=126; carrying terms: others, state, political, urged, censor, spokesperson, another, reforms, chaos, diplomacy, called, acting
- ukraine_theater: today=337, 7d-median=518, 14d-median=518; carrying terms: archive, ahvqa, cuxoqnfnunjotkxec, counter, shzmwhbra, dtvrrnk, tnvinuzjb, avdblvzemla, rtrtemfczwnvnfjfzfpct, jqamsyoepen, vkvuvmz, oudfezhfqqnhqdg
- paper_bets: today=143, 7d-median=144, 14d-median=144; carrying terms: token, determined, nuclear, emerson, player, miles, number, trust, third, grady, zohran, stafford
- weather: today=175, 7d-median=173, 14d-median=173; carrying terms: strong, threat, miles, basin, ruskin, dangerous, warned, threatening, thunderstorm, producing, angeles, sensitive
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: nonfarm, implied, effective, labor, payrolls, dcoilwtico, supply, jolts, unrate, total, crude, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, proxy, corporate, equities, rates, crypto, yield, nasdaq, agriculture, crude, futures, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=117, 14d-median=117; carrying terms: oefkzxhfy, cbmiqefvx, uywtpdzbcsjdrvxjzvfbnrki, claims, inezudwdeug, research, cbmixkfvx, third, techflow, implementation, counter, state
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, https, client, quantitative, error, httperror, congresstrading, quiver, unauthorized
- billionaires: today=37, 7d-median=36, 14d-median=36; carrying terms: alice, euronext, carlos, giancarlo, gcarsoa, gautam, ambani, nasdaq, investments, oracle, michael, bernard
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: keathley, bruce, trust, state, limited, district, local, court, services, charles, children, investments
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, amended, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, platner, alexandria, warner, ocasio, chartered, trone, congress, booker, ossoff, james, michael
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=25, 7d-median=46, 14d-median=46; carrying terms: chinese, english, themes, russian, spanish, trump, arabic, german, vietnamese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: kingdom, health, australia, language, killed, police, english, trump, domain
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=9, 14d-median=9
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: complications, surges, sequencing, manifestations, determined, separated, includ, critically, alert, global, being, number
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: upload, function, account, cisco, directory, active, sonicwall, request, injection, oracle, vulnerability, mechanism
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=203, 7d-median=162, 14d-median=162; carrying terms: bulgaria, serbia, denmark, impact, alert, equatorial, switzerland, brazil, honduras, croatia, austria, sweden
- usgs_quakes: today=17, 7d-median=18, 14d-median=18; carrying terms: puerto, islands, kermadec, depth, indonesia, philippines, region, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ethiopia, minister, meeting, prime, rates, price, resolves, mekonnen, interest, demeke, volume, boston
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: williams, schrag, particular, overall, conve, toward, campbell, movement, economy, referring, disclosure, economist
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: usual, threat, being, version, today, telling, months, turing, handwriting, initiative, software, bleepingcomputer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: riley, grothman, emily, harriet, cramer, delaney, strong, pressley, labor, staff, kirsten, edwards
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, converges, today, either, identify, placed, decision, placement, markets, sufficient, paper, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*