# WORLDSCOPE morning brief — 2026-07-22

## Headline
2656 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (635) · Russian Internal News (state + in-exile) (528) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (238) · Chinese Internal News (206) · U.S. Weather + Severe / Climate Outlooks (142) · State-Level News (140) · Local News: St. Louis + Atlanta (108) · State Legislative Action (47) · Ukrainian Internal News (national + local Kyiv) (41) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 635 new of 1005 total
  - (2026-07-22) [Global] Iran war’s $37bn price tag: Why does the Pentagon want $67bn more?
      The US must rapidly replenish its stockpiles of weapons as the war on Iran rages on.
  - (2026-07-22) [Global] ‘Creeping death’: Israel weaponises ‘Yellow Line’ to annex Gaza
      Analysts and locals say the move mirrors what happened after the 1967 war with Israel's occupation of the West Bank.
  - (2026-07-22) [Global] Italy makes financial ‘exceptions’ in bid to hire Pep Guardiola as coach
      Italy's football federation chief holds talks with Guardiola over vacant role, but appointment not yet confirmed.
  - (2026-07-22) [Global] Syrian people must not be failed again
      Stabilising Syria means stabilising its economy. It urgently needs international support and a safer investment climate.
  - (2026-07-22) [Global] Trump ally Andy Biggs wins Republican nomination for Arizona governor
      Biggs overwhelmingly defeats David Schweikert and will now face Democratic Governor Katie Hobbs in November.
  - (2026-07-22) [Global] US Secretary of State say Iran is in ‘a lot of trouble’
      US Secretary of State say Iran is in ‘a lot of trouble’

### Russian Internal News (state + in-exile) — 528 new of 1109 total
  - (2026-07-22) Новые ИИ-модели OpenAI вышли из-под контроля и устроили хакерскую атаку | LEDE: Компания OpenAI заявила, что две ее модели искусственного интеллекта во время внутреннего тестирования вышли и] (ru: Нов…
      Компания OpenAI заявила, что две ее модели искусственного интеллекта во время внутреннего тестирования вышли из-под контроля и взломали инфраструктуру платформы Hugging Face, которую используют для тестирования ИИ-моделе…
  - (2026-07-22) «Новому главкому ВСУ будет очень трудно. Но уже никогда не будет стыдно». Что в Украине, России и на Западе говорят о замене Сырского на Драпатого | LEDE: В Украине вечером 21 июля сменился ] (ru: «Но…
      В Украине вечером 21 июля сменился главнокомандующий вооруженными силами — вместо Александра Сырского этот пост занял Михаил Драпатый. Его назначению предшествовал конфликт между Сырским и министром обороны Украины Михаи…
  - (2026-07-22) Ко входу в салон красоты G.Bar в Киеве подбросили свиные головы из-за публичной поддержки ЛГБТК+ людей | LEDE: В Киеве ко входу в салон красоты G.Bar на бульваре Леси Украинки подбросили отр] (ru: Ко…
      В Киеве ко входу в салон красоты G.Bar на бульваре Леси Украинки подбросили отрубленные головы и внутренности свиней, крыльцо здания облили кровью. О случившемся администрация салона рассказала в инстаграме. Инцидент про…
  - (2026-07-22) Московская журналистка рассказала, что ее паспорт признали недействительным — возможно, из-за ошибки отеля в Дагестане | LEDE: Журналистка московского издания Msk1.ru Иветта Авраамова расска] (ru: Мос…
      Журналистка московского издания Msk1.ru Иветта Авраамова рассказала, что ее паспорт признали недействительным по неизвестной причине.
  - (2026-07-22) Госдума приняла закон против россиян, уехавших из страны и осужденных заочно. Им запретили получать консульские услуги и продавать недвижимость в РФ | LEDE: Госдума сразу во втором и третьем] (ru: Гос…
      Госдума сразу во втором и третьем чтениях приняла закон «о временных ограничительных мерах» в отношении тех, кто находится за пределами России и «уклоняется» от исполнения наказания, сообщает ТАСС.
  - (2026-07-22) Вслед за главкомом ВСУ Зеленский сменил начальника Генштаба | LEDE: Новым начальником Генерального штаба Вооруженных сил Украины назначен генерал-майор Игорь Скибюк, сообщил президент Украин] (ru: Всл…
      Новым начальником Генерального штаба Вооруженных сил Украины назначен генерал-майор Игорь Скибюк, сообщил президент Украины Владимир Зеленский.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 238 new of 443 total
  - (2026-07-22) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-21) [FIRMS] thermal anomaly 48.190, 22.640 (FRP 1.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.92 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.870, 33.434 (FRP 0.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 0.93 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.866, 33.433 (FRP 0.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 0.77 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.860, 33.445 (FRP 1.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.76 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.867, 33.433 (FRP 1.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.52 MW

### Chinese Internal News — 206 new of 308 total
  - (2026-07-21) In Depth: Louis Vuitton’s Trademark Win Sparks Backlash in China - Caixin Global
      In Depth: Louis Vuitton’s Trademark Win Sparks Backlash in China Caixin Global
  - (2026-07-21) PRO专享/数据深度专题 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMie0FVX3lxTE9JbXNhZGtDdnFwZy1Ic2dOQmlkQXVjNmVJSGJxVFlfOVlsaGVqY3ZVd3MybVlJQUtrQng2VFBXc3cwZXhkeDZjVi1J] (zh:…
      PRO专享/数据深度专题 deepview.caixin.com
  - (2026-07-22) 今日开盘：两市双双低开 沪指跌幅0.64% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9nNTY3dWtkLW9zSm9Kbm82LUs4QzVhSGg1R0NmQmkwRVgxd3FQVTRCU2tHQk9XYlF1dWxfb0FRcHc2VUZyQzB5TjJ2cnpyUkNF] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.64% 财新
  - (2026-07-21) 视线｜39天狂欢散场：世界杯球迷众生相 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5zMkM3b2NPOGZOYXI5WW1xMUE1Uy10VkJIMW04TG45MmY0NFNEVFFQeVJ2WFhhbVdYX2J2Z3dJb2w1OXNySC1nNlBERXUwcUV3Sm] (zh:…
      视线｜39天狂欢散场：世界杯球迷众生相 财新
  - (2026-07-22) 继澳大利亚之后 法国将禁止15岁以下未成年人使用社交媒体 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5BQnlfM0s3ZnJKWHVjWEtsYjJFMGl6dUFoNjVoU2hXR0pzQzRYeUtOYzMxbGhWR0Rja1hRSlNRSnRWZ2h3alhPbW9ZT] (zh:…
      继澳大利亚之后 法国将禁止15岁以下未成年人使用社交媒体 财新
  - (2026-07-22) 野村：美中期选举前联储难加息 日元贬值压力年底前或缓解 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE44aWNNbUVJZXpLNUt3MFNiSEdSOXprcm1aYW1vTUpCMTJJamNyYzdLaGhyS1NJWTlNbnNqdm9EZ2VNc2l3c0hhRkY3SV] (zh:…
      野村：美中期选举前联储难加息 日元贬值压力年底前或缓解 财新

### U.S. Weather + Severe / Climate Outlooks — 142 new of 156 total
  - (2026-07-22) [Moderate] Special Weather Statement: Special Weather Statement issued July 22 at 8:21AM EDT by NWS Wakefield VA
      At 821 AM EDT, Doppler radar was tracking a strong thunderstorm over Hampden Sydney College, moving east at 40 mph. HAZARD...Wind gusts up to 40 mph and heavy rain. SOURCE...Radar indicated. IMPACT...Gusty winds could kn…
  - (2026-07-22) [Severe] Flood Warning: Flood Warning issued July 22 at 8:17AM EDT until July 22 at 10:30AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Barbour County in northeastern West Virginia... Northwestern Randolph County in northeastern West Virginia... Northeastern Upshur County in northeastern…
  - (2026-07-22) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-22) [Severe] Flood Warning: Flood Warning issued July 22 at 8:14AM EDT until July 22 at 10:00AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Southeastern Barbour County in northeastern West Virginia... Northwestern Randolph County in northeastern West Virginia... Southern Upshur County in nor…
  - (2026-07-22) [Severe] Flood Warning: Flood Warning issued July 22 at 8:11AM EDT until July 22 at 10:00AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Southwestern Barbour County in northeastern West Virginia... West Central Randolph County in northeastern West Virginia... Central Upshur County in nort…
  - (2026-07-22) [Severe] Tropical Storm Watch: Tropical Storm Watch issued July 22 at 7:06AM CDT by NWS Lake Charles LA
      * LOCATIONS AFFECTED - Burns Point - Cypremort Point * WIND - LATEST LOCAL FORECAST: Below tropical storm force wind - Peak Wind Forecast: 10-20 mph with gusts to 30 mph - THREAT TO LIFE AND PROPERTY THAT INCLUDES TYPICA…

### State-Level News — 140 new of 817 total
  - (2026-07-22) [California] Newsom’s populist act: Oppose state billionaire tax, embrace federal one
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/020226-Newsom-Housing-MO-CM-26.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-07-22) [California] Californians have a right to know about 911 calls from ICE detention centers
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072026-Adelanto-CC-AP-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-07-22) [California] Four myths about insurance in California
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/01/010824_Eaton-Fire_JH_28.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="A…
  - (2026-07-22) [California] Trump’s new immigration strategy revealed in purchase of 2 ICE detention centers in California
      <img width="1024" height="671" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092225-CalCity-Detention-MV-CM-09.jpg?fit=1024%2C671&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-22) [Connecticut] What the wildfire smoke is telling us
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/07/AP-wildfire-smoke.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high"…
  - (2026-07-22) [Connecticut] Before CT families pay more, Eversource must prove its worth
      <img width="545" height="300" src="https://ctmirror.org/wp-content/uploads/2026/07/Electric-bill.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctmirror.o…

### Local News: St. Louis + Atlanta — 108 new of 227 total
  - (2026-07-22) [St. Louis] Fox’s Finest Meats, Seafood & Marketplace now open in Kirkwood
      Fresh fish, prime meat, and a gourmet grocer has arrived in Kirkwood, and it’s all under one roof. On July 22, Fox’s Finest, Meats, Seafood & Marketplace (159 W. Argonne) officially opens its doors with a ribbon-cutting…
  - (2026-07-22) [St. Louis] Ask Veronica: Where local designers love to spend time at home during the summer
      My favorite place to spend time in the summer is my garden, which I realize sounds a little crazy considering the heat. But there’s something peaceful about stepping outside in the evening, pouring a glass of wine, and e…
  - (2026-07-22) [St. Louis] A log cabin home in Wildwood hits the market
      Nature’s BestSurrounded by more than nine acres, this equestrian property measuring approximately 3,600 square feet, sits gracefully at the top of a ridge in the Caulks Creek Ridge neighborhood. A charming flagstone side…
  - (2026-07-22) [St. Louis] St. Louis leaders look to Detroit for pointers on how to build a lasting resurgence
      For years, Detroit served as the go-to example of the kind of American city to avoid turning into. The Michigan city suffered blow after blow—the 2008 financial crisis threatened to topple its dominant car manufacturing…
  - (2026-07-22) [St. Louis] Chesterfield rejects Old House at Hog Hollow’s plan to stay open for dinner
      The Old House at Hog Hollow’s latest attempt to expand its dining hours fell short this week, but the Chesterfield restaurant is not giving up. Owners Scott and Shelley Ririe, who operate the eatery out of a building con…
  - (2026-07-22) [St. Louis] Where in Chesterfield 7/22/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…

### State Legislative Action — 47 new of 158 total
  - (2026-07-22) [Alaska HB 193] An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training…
      An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training program account; relating to unempl…
  - (2026-07-22) [California SB 754] Menstrual products: disposable tampons and pad products: concerning chemicals.
      Existing law prohibits any person from manufacturing, distributing, selling, or offering for sale in the state any menstrual products that contain regulated perfluoroalkyl and polyfluoroalkyl substances, as defined. Exis…
  - (2026-07-22) [California SB 79] Housing development: transit-oriented development.
      (1) Existing law, the Planning and Zoning Law, requires each county and city to adopt a comprehensive, long-term general plan for the physical development of the county or city, and specified land outside its boundaries,…
  - (2026-07-22) [California SB 47] February 2025 bar exam: audit.
      The State Bar Act provides for the licensure and regulation of attorneys by the State Bar of California (State Bar) , a public corporation governed by a board of trustees. The act sets forth the requirements for a licens…
  - (2026-07-22) [California SB 81] Health and care facilities: information sharing.
      (1) The Confidentiality of Medical Information Act (CMIA) prohibits a provider of health care, a health care service plan, a contractor, or a corporation and its subsidiaries and affiliates from intentionally sharing, se…
  - (2026-07-22) [California SB 80] Energy: Fusion Research and Development Innovation Initiative.
      Existing law establishes the State Energy Resources Conservation and Development Commission, with various responsibilities with respect to developing and implementing the state's energy policies. Existing law requires, a…

### Ukrainian Internal News (national + local Kyiv) — 41 new of 111 total
  - (2026-07-22) З'явили укази Зеленського про зміну головкома ЗСУ й начальника Генштабу | LEDE: На сайті президента оприлюднили укази Володимира Зеленського про зміну головнокомандувача Збройних сил України та] (uk:…
      На сайті президента оприлюднили укази Володимира Зеленського про зміну головнокомандувача Збройних сил України та Генерального штабу ЗСУ.
  - (2026-07-22) Понад 50% українців виступали за відставку Сирського | LEDE: Опитування показало: 55% українців за відставку Сирського з ЗСУ, 72% — проти звільнення Федорова.] (uk: Понад 50% українців виступали за ві…
      Опитування показало: 55% українців за відставку Сирського з ЗСУ, 72% — проти звільнення Федорова.
  - (2026-07-22) Орбан оголосив про боротьбу з "автократичним режимом" партії прем'єра | LEDE: Колишній угорський прем'єр-міністр Віктор Орбан, що у квітні після 16 років перебування при владі втратив посаду в ] (uk:…
      Колишній угорський прем'єр-міністр Віктор Орбан, що у квітні після 16 років перебування при владі втратив посаду в результаті виборів, закликав своїх прихильників "відновити демократію" в країні, яка, на його думку, була…
  - (2026-07-22) Електоральні симпатії українців: Федоров майже наздогнав Залужного | LEDE: У першому турі гіпотетичних виборів президента 22,3% опитаних українців проголосували б за чинного главу держави Волод] (uk:…
      У першому турі гіпотетичних виборів президента 22,3% опитаних українців проголосували б за чинного главу держави Володимира Зеленського, 14,9% – за ексголовкома Валерія Залужного, 13,4% – за Михайла Федорова, чия відстав…
  - (2026-07-22) Після пограбування Лувр знову відкрив Галерею Аполлона без королівських коштовностей | LEDE: У Луврі після дев'яти місяців перерви відкрили Галерею Аполлона, яку торік пограбували. Королівські ] (uk:…
      У Луврі після дев'яти місяців перерви відкрили Галерею Аполлона, яку торік пограбували. Королівські реліквії відтепер експонуватимуть в іншому залі музею, де, за словами керівництва, вони будуть краще захищені.
  - (2026-07-22) Росія вдарила по житловому будинку в Одесі: постраждали двоє людей | LEDE: Внаслідок російської атаки на Одесу вдень 22 липня постраждали вже двоє людей та пошкоджено об'єкти цивільної інфрастр] (uk:…
      Внаслідок російської атаки на Одесу вдень 22 липня постраждали вже двоє людей та пошкоджено об'єкти цивільної інфраструктури.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-22) 424B5 - EUDA Health Holdings Ltd (0001847846) (Filer)
      filed 2026-07-22 11:00 UTC — Filed: 2026-07-22 AccNo: 0001493152-26-034161 Size: 8 KB
  - (2026-07-22) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-07-22 10:54 UTC — Filed: 2026-07-22 AccNo: 0001213900-26-080174 Size: 667 KB
  - (2026-07-22) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-07-22 10:54 UTC — Filed: 2026-07-22 AccNo: 0001213900-26-080174 Size: 667 KB
  - (2026-07-22) 424B2 - HSBC USA INC /MD/ (0000083246) (Filer)
      filed 2026-07-22 10:25 UTC — Filed: 2026-07-22 AccNo: 0001104659-26-085575 Size: 1 MB
  - (2026-07-22) [Lin Shyue-Shyh] Form 4 (Reporting)
      filed 2026-07-22 10:17 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001046179-26-000455 Size: 8 KB
  - (2026-07-22) [TAIWAN SEMICONDUCTOR MANUFACTURING CO LTD] Form 4 (Issuer)
      filed 2026-07-22 10:17 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001046179-26-000455 Size: 8 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-22) GAF527 (Germany)
      icao24: 3dbc00 · position: (54.0887, 12.4545) · alt: 1531m · 311km/h
  - (2026-07-22) JAF50T (Bulgaria)
      icao24: 4520d0 · position: (36.9596, -5.6486) · alt: 11285m · 824km/h
  - (2026-07-22) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (36.8418, -4.3338) · alt: 11277m · 799km/h
  - (2026-07-22) GAF154 (Germany)
      icao24: 3e9daf · position: (41.429, 16.9708) · alt: 8831m · 867km/h
  - (2026-07-22) PAT656 (United States)
      icao24: adfe4c · position: (42.2497, -85.039) · alt: 7620m · 431km/h
  - (2026-07-22) PAT620 (United States)
      icao24: adfec9 · position: (39.9883, -83.7623) · alt: 6400m · 555km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 28 new of 57 total
  - (2026-07-22) [Krebs on Security] LG to Ban Residential Proxies from Smart TV Apps
      The home appliance giant LG Electronics USA said this week it plans to suspend any apps built for its smart TVs that turn one's television into an always-on residential proxy node. The move comes less than a month after…
  - (2026-07-22) [BleepingComputer] CISA orders urgent action on actively exploited Langflow RCE flaw
      The Cybersecurity and Infrastructure Security Agency (CISA) on Tuesday ordered U.S. government agencies to prioritize patching an actively exploited vulnerability in the Langflow visual framework for building AI agents.…
  - (2026-07-22) [BleepingComputer] Stop renting storage space — this lifetime 2TB plan is yours for $59
      Cloud storage costs tend to creep up over time, since most services charge monthly or annually for as long as you use them. FileJump's Lifetime Plan skips that model entirely, offering 2TB of cloud storage for a single p…
  - (2026-07-22) [BleepingComputer] Microsoft to stop Exchange 2016 / 2019 security updates in October
      Microsoft has reminded customers that it will stop shipping security updates for Exchange 2016 and 2019 through the Extended Security Update (ESU) program in October. [...]
  - (2026-07-22) [BleepingComputer] Chick-fil-A discloses data breach after credential stuffing attacks
      American fast food restaurant chain Chick-fil-A is notifying customers of a data breach after their accounts were hacked in a wave of recent credential stuffing attacks. [...]
  - (2026-07-22) [BleepingComputer] OpenAI says its AI models hacked Hugging Face during testing
      OpenAI says its AI models, including GPT‑5.6 Sol and a pre-release model, hacked into the Hugging Face artificial intelligence repository while being tested in a sandboxed testing environment. [...]

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-22) [Israel-Iran-Hezbollah axis · keywords] Report : Netanyahu fails to arrange Trump meeting as US pushes for Lebanon withdrawal
      naharnet.com · English · tone NA
  - (2026-07-22) [Israel-Iran-Hezbollah axis · keywords] Francesca Albanese Wont Back Down
      thenation.com · English · tone NA
  - (2026-07-22) [Israel-Iran-Hezbollah axis · keywords] Lebanese President Outlines Conditions for Hezbollah Disarmament
      sputnikglobe.com · English · tone NA
  - (2026-07-22) [Israel-Iran-Hezbollah axis · keywords] Latest Articles
      freerepublic.com · English · tone NA
  - (2026-07-22) [Israel-Iran-Hezbollah axis · keywords] US - Iran strikes : Latest developments
      naharnet.com · English · tone NA
  - (2026-07-22) [Israel-Iran-Hezbollah axis · keywords] Lebanese - American who stabbed Rushdie to go on trial again
      naharnet.com · English · tone NA

### U.S. Federal Action — 22 new of 22 total
  - (2026-07-22) Methylene Chloride
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Methylene Chloride standard. Following consideration of the rulemaking by OSHA's Advisory Committee on…
  - (2026-07-22) Vinyl Chloride
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Vinyl Chloride standard. Following consideration of the rulemaking by OSHA's Advisory Committee on Con…
  - (2026-07-22) Methylenedianiline
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Methylenedianiline standards. Following consideration of the rulemaking by OSHA's Advisory Committee o…
  - (2026-07-22) Lead
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Lead standards. Following consideration of the rulemaking by OSHA's Advisory Committee on Construction…
  - (2026-07-22) Inorganic Arsenic
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Inorganic Arsenic standard. Following consideration of the rulemaking by OSHA's Advisory Committee on…
  - (2026-07-22) Formaldehyde
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Formaldehyde standard. Following consideration of the rulemaking by OSHA's Advisory Committee on Const…

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Jenkins v. Prime Insurance
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Miller v. CNH Industrial America
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: United States v. Threatt
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Spiehs v. Morgan
  - (2026-07-21) U.S. Court of Appeals, 1st Cir.: Recchia v. Campbell
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: Exxon Mobil Corp v. OSHC

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 112 total
  - (2026-07-22) [USASpending] $15,578,433,008 → LOCKHEED MARTIN CORP: TAS::80 0124::TAS DESIGN, DEVELOPMENT, TEST&EVALUATION OF PR
      Agency: National Aeronautics and Space Administration. Description: TAS::80 0124::TAS DESIGN, DEVELOPMENT, TEST&EVALUATION OF PROJECT ORION
  - (2026-07-22) [USASpending] $8,561,512,218 → BROOKHAVEN SCIENCE ASSOCIATES LLC: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
      Agency: Department of Energy. Description: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
  - (2026-07-22) [USASpending] $2,170,949,215 → THE TRUSTEES OF PRINCETON UNIVERSITY: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE P
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE PRINCETON PLASMA PHYSICS LABORATORY (PPPL)
  - (2026-07-22) [USASpending] $2,121,046,270 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.
  - (2026-07-22) [USASpending] $1,599,628,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-07-22) [USASpending] $1,451,665,745 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-22) LoL: LGD Gaming vs EDward Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $1,309,495 · resolves 2026-07-22
  - (2026-07-22) LoL: LGD Gaming vs EDward Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $1,135,464 · resolves 2026-07-22
  - (2026-07-22) Hamburg European Open: Simona Waltert vs Mayar Sherif
      yes price: 0% · 24h volume: $1,117,474 · resolves 2026-07-28
  - (2026-07-22) LoL: Top Esports vs Team WE - Game 1 Winner
      yes price: 100% · 24h volume: $936,167 · resolves 2026-07-22
  - (2026-07-22) LoL: LGD Gaming vs EDward Gaming (BO3) - LPL Group Ascend
      yes price: 100% · 24h volume: $640,153 · resolves 2026-07-22
  - (2026-07-22) Counter-Strike: EYEBALLERS vs FaZe (BO3) - BLAST Bounty Qualifier
      yes price: 0% · 24h volume: $630,104 · resolves 2026-07-22

### Paper Trading Scorecard — 9 new of 145 total
  - (2026-07-22) [Polymarket] Will Elon Musk post 140-159 tweets from July 17 to July 24, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 17 12:00 PM ET to July 24, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-22) [Polymarket] Will the Bank of Russia decrease the key rate after the July Meeting?
      This market will resolve according to the change in the key rate resulting from the Bank of Russia’s July meeting, relative to the level it was prior to this meeting. The resolution source for this market is information…
  - (2026-07-22) [Polymarket] Will the US announce withdrawal from MOU negotiations by August 31?
      On June 14, 2026, the United States and Iran announced a memorandum of understanding ending the immediate conflict and establishing a 60-day framework for negotiating a final agreement. This market will resolve to "Yes"…
  - (2026-07-22) [Manifold] Free Lottery (cat & rat)
  - (2026-07-22) [Manifold] Will a consumer AI meaningfully hack something to answer a question for a regular user by eoy 2027?
  - (2026-07-22) [Manifold] Will "How big is the Sun? How could you figure it out?" make the top fifty posts in LessWrong's 2026 Annual Review?

### USGS earthquakes (M4.5+, past day) — 8 new of 17 total
  - (2026-07-22) M 5.1 - 121 km NW of Vallenar, Chile
      M5.1 · 121 km NW of Vallenar, Chile · depth 10 km
  - (2026-07-22) M 5.0 - 55 km WSW of Langsa, Indonesia
      M5.0 · 55 km WSW of Langsa, Indonesia · depth 10 km
  - (2026-07-22) M 4.9 - 11 km NW of Sugal, Philippines
      M4.9 · 11 km NW of Sugal, Philippines · depth 64.477 km
  - (2026-07-22) M 4.9 - 208 km W of Abepura, Indonesia
      M4.9 · 208 km W of Abepura, Indonesia · depth 21.587 km
  - (2026-07-22) M 4.7 - 89 km NW of Finschhafen, Papua New Guinea
      M4.7 · 89 km NW of Finschhafen, Papua New Guinea · depth 106.527 km
  - (2026-07-22) M 4.7 - 12 km SE of Cuya, Chile
      M4.7 · 12 km SE of Cuya, Chile · depth 60.814 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-22) [Japan] Armadillo Racing is this week Arcade Archives game on Nintendo Switch 2 , Switch
      nintendoeverything.com · English
  - (2026-07-22) [Japan] Star Fox ( NS2 )
      vgchartz.com · English
  - (2026-07-22) [Japan] Google Images Turns 25 With a Personalized Redesign
      explosion.com · English
  - (2026-07-22) [Japan] OpenAI AI Models Broke Free and Hacked Hugging Face
      explosion.com · English
  - (2026-07-22) [Japan] Star Trek : Strange New World Fourth Season Takes Big Swings
      engadget.com · English
  - (2026-07-22) [Japan] Samsung Galaxy Unpacked July 2026 : Live Updates From The Z Fold 8 And Flip 8 Launch Event
      engadget.com · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 36 total
  - (2026-07-22) MOVER ▲ Francoise Bettencourt Meyers & family — $93.35B (+$0.32B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-22) MOVER ▼ Mukesh Ambani — $87.24B ($-0.13B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-22) MOVER ▼ Amancio Ortega — $137.72B ($-0.13B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-22) MOVER ▲ Bill Gates — $105.29B (+$0.08B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-07-22) MOVER ▲ Gautam Adani — $88.13B (+$0.06B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### GDACS — global disaster alerts — 5 new of 205 total
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-18) [Green] Forest fires in Algeria
      Wildfire · Green alert · Algeria · Green impact for forestfire in 11068 ha
  - (2026-07-18) [Green] Forest fires in Algeria
      Wildfire · Green alert · Algeria · Green impact for forestfire in 11068 ha

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-22) [Marginal Revolution] An OpenAI Model Escaped Its Sandbox and Hacked Hugging Face
      AI has just had what I considered to be the first truly concerning security breach. The facts, as we know them so far, are wild. On July 16, Hugging Face, a vast repository housing over a million open-source AI models an…
  - (2026-07-22) [Marginal Revolution] Alec Stapp on the new Science report from Michael Kratsios
      Major new report from the White House Office of Science and Technology Policy. Five things in the report I really liked: 1. Proposes metascience units as a way to advance experimentation in science agencies. IFP recommen…
  - (2026-07-22) [Marginal Revolution] Betting markets in everything
      Alan and Karen Miller’s first dance was a win-or-lose moment for many of their wedding guests. As the couple glided across the floor during their reception in New Rochelle, N.Y., last year, attendees kept track of the ch…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: commission, remove, based, provide, specifically, protect, temporary, center, fisheries, guard, regulatory, authorized
- state_bills: today=158, 7d-median=120, 14d-median=120; carrying terms: ideology, civil, practices, quarter, access, reform, governmental, change, registration, disability, individual, community
- state_news: today=817, 7d-median=729, 14d-median=729; carrying terms: international, mullin, women, mountain, civil, practices, quarter, sabotage, incumbent, registration, string, followed
- local_news: today=227, 7d-median=227, 14d-median=227; carrying terms: issued, sexual, georgia, community, jackson, afternoon, fetchpriority, children, class, death, responsible, width
- foreign_news: today=1005, 7d-median=1022, 14d-median=1022; carrying terms: tibetan, quarter, naval, bensebaa, restrictions, afternoon, children, class, straits, drone, articleimages, percent
- chinese_internal: today=308, 7d-median=301, 14d-median=301; carrying terms: cbmidefvx, cbmiakfvx, cbmia, google, capital, caixin, sources, cbmiykfvx, cbmiyefvx, target, title, global
- russian_internal: today=1109, 7d-median=893, 14d-median=893; carrying terms: europe, street, social, truth, httperror, novayagazeta, journal, telegram, variety, media, wildberries, forbidden
- ukrainian_internal: today=111, 7d-median=126, 14d-median=126; carrying terms: international, ministry, casualties, reform, naval, focus, potential, joint, members, countries, government, broader
- ukraine_theater: today=443, 7d-median=540, 14d-median=540; carrying terms: cwzggxvwf, xrtbquvmznvr, tyeevvltc, civil, quarter, vdjjb, xzkzqwdbsfjvqi, restoring, ulpfdg, yzegwnghcrjrtntdvoejrcfe, vwwxdmfmx, rhdmmtbvow
- paper_bets: today=145, 7d-median=144, 14d-median=144; carrying terms: johnson, decision, social, florida, climate, second, benefits, andrew, mayfield, diabetes, johnny, withdraw
- weather: today=156, 7d-median=169, 14d-median=169; carrying terms: anchorage, clouds, issued, nearly, message, afdphi, atlantic, greater, miami, georgia, sensitive, streams
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: spread, jolts, unrate, vixcls, cpilfesl, cpiaucsl, crude, recession, rates, payems, supply, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, crude, equities, rates, corporate, nasdaq, agriculture, bitcoin, futures, china, commodities, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=112, 7d-median=117, 14d-median=117; carrying terms: international, nxdzz, burma, practices, manufacturers, implementation, embargo, ofnptvdvzhbmeev, moldova, bfzkdxe, checksum, joint
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, error, httperror, quiver, quantitative, unauthorized, https, quiverquant, congresstrading
- billionaires: today=36, 7d-median=35, 14d-median=35; carrying terms: madrid, technology, facebook, warren, giancarlo, retail, devasini, india, euronext, nasdaq, gcarsoa, china
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, steel, rifle, trust, romero, limited, blanche, jersey, children, corona, greatbanc, pennsylvania
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, johnson, pinkston, group, david, warner, platner, brown, cycle, senate, alexandria, cortez
- gdelt_regions: today=6, 7d-median=9, 14d-median=9; carrying terms: english, japan
- gdelt_gkg: today=25, 7d-median=46, 14d-median=46; carrying terms: israel, hezbollah, english, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=9, 14d-median=9
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: substantial, international, complications, chikungunya, senegal, routine, proportion, conflict, vaccine, ministry, deteriorate, blood
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: lockout, insufficient, protocol, fortinet, sharepoint, overly, federation, deserialization, upload, improper, access, cross
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=205, 7d-median=162, 14d-median=162; carrying terms: earthquake, green, hungary, costa, vietnam, montenegro, venezuela, brazil, papua, mexico, minor, albania
- usgs_quakes: today=17, 7d-median=18, 14d-median=18; carrying terms: puerto, depth, indonesia, philippines, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ethiopia, rates, interest, prime, minister, price, meeting, volume, resolves, change, boston, traffic
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: interview, economy, congressional, schrag, budget, toward, heidi, wroblewski, refer, sheila, campbell, positive
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: international, daily, sabotage, computer, friday, potential, voice, government, schneier, exploitation, really, dollars
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jayapal, speech, mullin, commission, armstrong, yassamin, torres, spartz, jasmine, doris, nadler, collins
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, placed, markets, evidence, consensus, module, converges, decision, paper, identify, unavailable, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*