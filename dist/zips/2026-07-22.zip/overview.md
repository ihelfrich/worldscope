# WORLDSCOPE morning brief — 2026-07-22

## Headline
2261 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (534) · Russian Internal News (state + in-exile) (453) · World leaders & government officials (324) · Chinese Internal News (202) · U.S. Weather + Severe / Climate Outlooks (154) · State Legislative Action (144) · Ukraine Theater (total-war monitoring) (91) · Local News: St. Louis + Atlanta (81) · State-Level News (73) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (34) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 534 new of 1000 total
  - (2026-07-22) [Global] Trump announces new tariffs on generic drugs to take effect in 2028 – as it happened
  - (2026-07-22) [Global] Canada cancels joint bridge-opening celebration with US amid trade tensions
  - (2026-07-22) [Global] Japan records its first ‘cruelly hot day’ as cities swelter in 40-degree heat
  - (2026-07-22) [Global] Court win for low-paid Domino’s workers in underpayment class action – as it happened
  - (2026-07-22) [Global] People with secret ‘safe phones’ advised to turn off devices during national test of AusAlert emergency warning
  - (2026-07-22) [Global] Brittany Higgins accuses Pauline Hanson of victim-blaming for calling domestic violence a ‘two-way street’

### Russian Internal News (state + in-exile) — 453 new of 1056 total
  - (2026-07-22) Росавиация снизила высоту полетов у Москвы и запретила транзитные перелеты через город. Время полета и расходы на топливо вырастут | LEDE: Росавиация снизила предельную высоту полета самолет] (ru: Рос…
      Росавиация снизила предельную высоту полета самолетов в районе московских аэропортов до 4900 метров и запретила транзитные пролеты через него, сообщил «Коммерсант», ссылаясь на извещение пользователей воздушного простран…
  - (2026-07-22) Орнелла Мути собирается получить гражданство России | LEDE: Итальянская певица Найке Ривелли, дочь актрисы Орнеллы Мути, рассказала РИА Новости, что они с матерью собираются получить российс] (ru: Орн…
      Итальянская певица Найке Ривелли, дочь актрисы Орнеллы Мути, рассказала РИА Новости, что они с матерью собираются получить российское гражданство.
  - (2026-07-22) Bloomberg: Кремль передумал возвращать Украине часть оккупированных территорий, так как договоренности Анкориджа сорваны | LEDE: Россия больше не планирует возвращать Украине часть оккупиров] (ru: Blo…
      Россия больше не планирует возвращать Украине часть оккупированных территорий в рамках возможной сделки о прекращении войны, сообщает Bloomberg со ссылкой на источники, близкие к Кремлю.
  - (2026-07-22) Украина второй раз за неделю атаковала склады Wildberries. На Кубани и Ставрополье — масштабные пожары. Фотографии и видео. Материал обновляется | LEDE: Украинские беспилотники в ночь на 22 ] (ru: Укр…
      Украинские беспилотники в ночь на 22 июля атаковали логистические центры Wildberries в Краснодаре и Невинномысске (Ставропольский край). Там начались сильные пожары. К тушению привлекли вертолеты МЧС. По данным властей К…
  - (2026-07-22) Пентагон оценил стоимость войны США с Ираном в 37,5 миллиарда долларов | LEDE: Боевые действия против Ирана обойдутся США в 37,5 миллиарда долларов, заявил глава Пентагона Пит Хегсет на слуш] (ru: Пен…
      Боевые действия против Ирана обойдутся США в 37,5 миллиарда долларов, заявил глава Пентагона Пит Хегсет на слушаниях в конгрессе. По его словам, эта сумма включает в себя как уже потраченные на войну деньги, так и прогно…
  - (2026-07-22) Франция (первой в ЕС) запретила социальные сети для детей до 15 лет | LEDE: Парламент Франции одобрил закон, который подразумевает запрет на пользование социальными сетями для детей младше 1] (ru: Фра…
      Парламент Франции одобрил закон, который подразумевает запрет на пользование социальными сетями для детей младше 15 лет. Франция стала первой страной Евросоюза, где появится такое ограничение.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 202 new of 307 total
  - (2026-07-21) PRO专享/数据深度专题 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMie0FVX3lxTE9JbXNhZGtDdnFwZy1Ic2dOQmlkQXVjNmVJSGJxVFlfOVlsaGVqY3ZVd3MybVlJQUtrQng2VFBXc3cwZXhkeDZjVi1J] (zh:…
      PRO专享/数据深度专题 deepview.caixin.com
  - (2026-07-22) 今日开盘：两市双双低开 沪指跌幅0.64% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9nNTY3dWtkLW9zSm9Kbm82LUs4QzVhSGg1R0NmQmkwRVgxd3FQVTRCU2tHQk9XYlF1dWxfb0FRcHc2VUZyQzB5TjJ2cnpyUkNF] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.64% 财新
  - (2026-07-21) 视线｜39天狂欢散场：世界杯球迷众生相 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5zMkM3b2NPOGZOYXI5WW1xMUE1Uy10VkJIMW04TG45MmY0NFNEVFFQeVJ2WFhhbVdYX2J2Z3dJb2w1OXNySC1nNlBERXUwcUV3Sm] (zh:…
      视线｜39天狂欢散场：世界杯球迷众生相 财新
  - (2026-07-22) 继澳大利亚之后 法国将禁止15岁以下未成年人使用社交媒体 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5BQnlfM0s3ZnJKWHVjWEtsYjJFMGl6dUFoNjVoU2hXR0pzQzRYeUtOYzMxbGhWR0Rja1hRSlNRSnRWZ2h3alhPbW9ZT] (zh:…
      继澳大利亚之后 法国将禁止15岁以下未成年人使用社交媒体 财新
  - (2026-07-22) 野村：美中期选举前联储难加息 日元贬值压力年底前或缓解 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE44aWNNbUVJZXpLNUt3MFNiSEdSOXprcm1aYW1vTUpCMTJJamNyYzdLaGhyS1NJWTlNbnNqdm9EZ2VNc2l3c0hhRkY3SV] (zh:…
      野村：美中期选举前联储难加息 日元贬值压力年底前或缓解 财新
  - (2026-07-22) 交易商协会规范熊猫债信用评级 与国际主流信用等级如何映射？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1hTTYxTnhIV2FlYVFiX3AwYnhicmQ3Nk5XY2xvdENyTThPN2xLV3BSOVM1SGRqVUlxVW5ybTRRYmhicG9BN2pWZlNr] (zh:…
      交易商协会规范熊猫债信用评级 与国际主流信用等级如何映射？ 财新

### U.S. Weather + Severe / Climate Outlooks — 154 new of 172 total
  - (2026-07-22) [Severe] Flood Warning: Flood Warning issued July 22 at 5:27AM EDT until July 22 at 9:30AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Southeastern Barbour County in northeastern West Virginia... Northeastern Pocahontas County in northeastern West Virginia... Randolph County in northeas…
  - (2026-07-22) [Severe] Flood Warning: Flood Warning issued July 22 at 5:27AM EDT until July 22 at 9:30AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Barbour County in northeastern West Virginia... Northwestern Randolph County in northeastern West Virginia... Northeastern Upshur County in northeastern…
  - (2026-07-22) [Severe] Tropical Storm Watch: Tropical Storm Watch issued July 22 at 4:26AM CDT by NWS New Orleans LA
      * WHAT...Southwest winds 10 to 20 kt with gusts up to 30 kt. * WHERE...Lake Maurepas. * WHEN...Tropical Storm force winds possible until Wednesday night. * IMPACTS...Tropical storm force winds and hazardous seas could ca…
  - (2026-07-22) [Severe] Tropical Storm Warning: Tropical Storm Warning issued July 22 at 4:26AM CDT by NWS New Orleans LA
      * WHAT...Southwest winds 25 to 35 kt with gusts up to 50 kt and seas 7 to 12 ft. * WHERE...Portions of Gulf of America. * WHEN...Tropical Storm force winds possible until late this afternoon. * IMPACTS...Tropical storm f…
  - (2026-07-22) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 22 at 5:26AM EDT until July 22 at 6:15AM EDT by NWS Wakefield VA
      SVRAKQ The National Weather Service in Wakefield has issued a * Severe Thunderstorm Warning for... Chesterfield County in central Virginia... The City of Colonial Heights in central Virginia... The City of Hopewell in so…
  - (2026-07-22) [Severe] Flood Warning: Flood Warning issued July 22 at 5:26AM EDT until July 22 at 10:00AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Northeastern Washington County in southeastern Ohio... Northwestern Doddridge County in northern West Virginia... Tyler County in northern West Virginia…

### State Legislative Action — 144 new of 227 total
  - (2026-07-22) [Alaska HB 193] An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training…
      An Act relating to minimum paid sick leave requirements; establishing a paid parental leave program; relating to employer surcharges; relating to the employment assistance and training program account; relating to unempl…
  - (2026-07-22) [District of Columbia B 26-0526] Leading Education Access for Reentry and Necessary Success (LEARNS) Amendment Act of 2025
      Leading Education Access for Reentry and Necessary Success (LEARNS) Amendment Act of 2025
  - (2026-07-22) [District of Columbia B 26-0355] Juvenile Curfew Congressional Review Emergency Amendment Act of 2025
      Juvenile Curfew Congressional Review Emergency Amendment Act of 2025
  - (2026-07-22) [District of Columbia B 26-0714] Personal Delivery Device Weight Limit Congressional Review Emergency Amendment Act of 2026
      Personal Delivery Device Weight Limit Congressional Review Emergency Amendment Act of 2026
  - (2026-07-22) [District of Columbia B 26-0090] Neighborhood Management Authority Act of 2025
      Neighborhood Management Authority Act of 2025
  - (2026-07-22) [District of Columbia B 26-0660] Fiscal Year 2027 Local Budget Emergency Act of 2026
      Fiscal Year 2027 Local Budget Emergency Act of 2026

### Ukraine Theater (total-war monitoring) — 91 new of 337 total
  - (2026-07-21) [FIRMS] thermal anomaly 48.190, 22.640 (FRP 1.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.92 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.870, 33.434 (FRP 0.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 0.93 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.866, 33.433 (FRP 0.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 0.77 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.860, 33.445 (FRP 1.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.76 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.867, 33.433 (FRP 1.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 1.52 MW
  - (2026-07-21) [FIRMS] thermal anomaly 47.861, 33.445 (FRP 2.59 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-21 2324Z, FRP 2.59 MW

### Local News: St. Louis + Atlanta — 81 new of 236 total
  - (2026-07-22) [St. Louis] Where in Chesterfield 7/22/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-07-22) [St. Louis] Asador Del Sur owners to return with new restaurant in St. Louis Hills
      When a devastating fire ripped through Asador Del Sur in Maplewood last August, owners Maria Giamportone and Daniel Gonzalez worried that their restaurant dreams may have ended. Less than a year after the that tragic day…
  - (2026-07-22) [St. Louis] See the July 22, 1926, front page: Cop who failed to shoot accused of hiding in store
      Headlines from the July 22, 1926, front page include: Lavish spending by US tourists irritates Paris.
  - (2026-07-22) [St. Louis] How do you improve St. Louis-area schools? A task force wants to find out
      Plus: Ladue to reconsider ban on apartments
  - (2026-07-22) [St. Louis] Illini lineman Brandon Henderson of East St. Louis talks about the year ahead
      University of Illinois offensive lineman Brandon Henderson talks about the year ahead as he enters his senior year with the Fighting Illini program. He visited as part of Illini night at a St. Louis Cardinals game on Fri…
  - (2026-07-22) [St. Louis] Aach, Susan
      Aach, Susan Emily

### State-Level News — 73 new of 770 total
  - (2026-07-22) [Alaska] Seventeen governor candidates vie for votes in Alaska’s primary election
      The first two votes in Alaska’s Aug. 18 primary election have already been cast. According to records published by the absentee and petition office of the Alaska Division of Elections, two voters — one in South Carolina…
  - (2026-07-22) [California] Governor Newsom signs tribal-state gaming compact 7.21.26
      Source
  - (2026-07-22) [California] Governor Newsom highlights robust investments in fire prevention and cutting-edge firefighting technology to combat wildfire and save lives
      Source
  - (2026-07-22) [California] Governor Newsom announces appointments 7.21.2026
      Source
  - (2026-07-22) [Arizona] Voucher oversight fight tilts GOP superintendent primary toward Kimberly Yee over Tom Horne
      Kimberly Yee is maintaining a large lead in the GOP nomination for public schools chief, a victory that would see her unseat GOP incumbent Tom Horne, who is in his second stint as the Superintendent of Public Instruction…
  - (2026-07-22) [Arizona] Trump-backed former NFL kicker Jay Feely wins CD1 GOP primary as Amish Shah leads Dem field
      Republican Jay Feely, a former NFL kicker who played for the Arizona Cardinals, has advanced to the November election, where it seems likely he will face off against former Democratic state lawmaker Amish Shah in one of…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-22) [KIDOZ INC.] Form 4 (Issuer)
      filed 2026-07-22 01:25 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0001278521-26-000011 Size: 12 KB
  - (2026-07-22) [Williams Tryon M] Form 4 (Reporting)
      filed 2026-07-22 01:25 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0001278521-26-000011 Size: 12 KB
  - (2026-07-22) [KIRBY J SCOTT] Form 4 (Reporting)
      filed 2026-07-22 01:16 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0000100517-26-000142 Size: 11 KB
  - (2026-07-22) [United Airlines Holdings, Inc.] Form 4 (Issuer)
      filed 2026-07-22 01:16 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0000100517-26-000142 Size: 11 KB
  - (2026-07-22) [Kim Vyacheslav] Form 4 (Reporting)
      filed 2026-07-22 01:14 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0001193125-26-311001 Size: 13 KB
  - (2026-07-22) [Joint Stock Co Kaspi.kz] Form 4 (Issuer)
      filed 2026-07-22 01:14 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0001193125-26-311001 Size: 13 KB

### Ukrainian Internal News (national + local Kyiv) — 34 new of 107 total
  - (2026-07-22) В МЗС відреагували на "таємну" зустріч експосадовців РФ і Німеччини | LEDE: Речник Міністерства закордонних справ Георгій Тихий висловився щодо "таємної" зустрічі у Баку колишніх високопосадовц] (uk:…
      Речник Міністерства закордонних справ Георгій Тихий висловився щодо "таємної" зустрічі у Баку колишніх високопосадовців Німеччини та Росії.
  - (2026-07-22) Мобілізований прикордонник намагався втекти зі служби за $3 тисячі | LEDE: Підозру оголосили військовослужбовцю Державної прикордонної служби, який запропонував командиру підрозділу 3 тисячі до] (uk:…
      Підозру оголосили військовослужбовцю Державної прикордонної служби, який запропонував командиру підрозділу 3 тисячі доларів США за допомогу у власній втечі зі служби.
  - (2026-07-22) У Варшаві стався технічний збій під час тестування системи повітряної тривоги | LEDE: У Варшаві ввечері 21 липня після офіційного завершення навчань ALARM-26 несподівано знову пролунали сигнали] (uk:…
      У Варшаві ввечері 21 липня після офіційного завершення навчань ALARM-26 несподівано знову пролунали сигнали повітряної тривоги – у польському Урядовому центрі безпеки (RCB) вважають, що причиною стала технічна несправніс…
  - (2026-07-22) У Польщі засудили українця, що керував вантажівкою з 2,5 проміле алкоголю у крові | LEDE: 63-річного водія з України у Польщі засудили за водіння з 2,5 проміле алкоголю у крові.] (uk: У Польщі засудил…
      63-річного водія з України у Польщі засудили за водіння з 2,5 проміле алкоголю у крові.
  - (2026-07-22) 21-й удар по економіці РФ: як працюють санкції ЄС і чому їх так складно ухвалюють | LEDE: ] (uk: 21-й удар по економіці РФ: як працюють санкції ЄС і чому їх так складно ухвалюют)
  - (2026-07-22) Буданов запевнив Драпатого у повній підтримці | LEDE: Буданов підтримав новопризначеного головнокомандувача ЗСУ Драпатого та подякував Сирському.] (uk: Буданов запевнив Драпатого у повній підтримці)
      Буданов підтримав новопризначеного головнокомандувача ЗСУ Драпатого та подякував Сирському.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 22 new of 22 total
  - (2026-07-22) Methylene Chloride
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Methylene Chloride standard. Following consideration of the rulemaking by OSHA's Advisory Committee on…
  - (2026-07-22) Vinyl Chloride
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Vinyl Chloride standard. Following consideration of the rulemaking by OSHA's Advisory Committee on Con…
  - (2026-07-22) Methylenedianiline
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Methylenedianiline standards. Following consideration of the rulemaking by OSHA's Advisory Committee o…
  - (2026-07-22) Lead
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Lead standards. Following consideration of the rulemaking by OSHA's Advisory Committee on Construction…
  - (2026-07-22) Inorganic Arsenic
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Inorganic Arsenic standard. Following consideration of the rulemaking by OSHA's Advisory Committee on…
  - (2026-07-22) Formaldehyde
      OSHA is providing an additional comment period to allow interested people to comment on OSHA's proposal to revise the Formaldehyde standard. Following consideration of the rulemaking by OSHA's Advisory Committee on Const…

### IT, InfoSys & cybersecurity news (last 7 days) — 19 new of 57 total
  - (2026-07-22) [Krebs on Security] LG to Ban Residential Proxies from Smart TV Apps
      The home appliance giant LG Electronics USA said this week it plans to suspend any apps built for its smart TVs that turn one's television into an always-on residential proxy node. The move comes less than a month after…
  - (2026-07-22) [BleepingComputer] Chick-fil-A discloses data breach after credential stuffing attacks
      American fast food restaurant chain Chick-fil-A is notifying customers of a data breach after their accounts were hacked in a wave of recent credential stuffing attacks. [...]
  - (2026-07-22) [BleepingComputer] OpenAI says its AI models hacked Hugging Face during testing
      OpenAI says its AI models, including GPT‑5.6 Sol and a pre-release model, hacked into the Hugging Face artificial intelligence repository while being tested in a sandboxed testing environment. [...]
  - (2026-07-22) [The Hacker News] Police Dismantle Kratos Phishing Kit Built to Steal Microsoft 365 Sessions and Bypass MFA
      German and US law enforcement have taken down the core infrastructure of Kratos, described by German investigators as one of the world's most widely used criminal phishing kits, and Indonesian authorities arrested the ma…
  - (2026-07-22) [The Hacker News] Trojanized Newtonsoft.Json Fork Hides Game-Rigging Code in a Working Library
      Cybersecurity researchers have discovered a NuGet typosquat that's unlike the typical information-stealing malware distributed via package registries: usual info-stealers: it's designed to rig live game results on Digita…
  - (2026-07-22) [The Hacker News] Microsoft Azure DevOps MCP Flaw Lets Hidden PR Comments Hijack AI Review Agents
      A single invisible comment in an Azure DevOps pull request can turn a reviewer's own AI coding agent against them, driving it into projects the attacker has no rights to reach and quietly leaking what it finds. The flaw…

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-22) [China] CATL to deploy first large - scale sodium - ion energy storage project in Central and Eastern Europe · TechNode
      technode.com · English
  - (2026-07-22) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-22) [China] Which brands won the FIFA World Cup : a data analysis
      campaignasia.com · English
  - (2026-07-22) [China] VW targets rollout of L3 capabilities in China in 2027
      europe.chinadaily.com.cn · English
  - (2026-07-22) [China] China hit an oil and gas output record last year – why is Beijing warning of a squeeze ?
      scmp.com · English
  - (2026-07-22) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 111 total
  - (2026-07-22) [USASpending] $15,578,433,008 → LOCKHEED MARTIN CORP: TAS::80 0124::TAS DESIGN, DEVELOPMENT, TEST&EVALUATION OF PR
      Agency: National Aeronautics and Space Administration. Description: TAS::80 0124::TAS DESIGN, DEVELOPMENT, TEST&EVALUATION OF PROJECT ORION
  - (2026-07-22) [USASpending] $8,561,512,218 → BROOKHAVEN SCIENCE ASSOCIATES LLC: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
      Agency: Department of Energy. Description: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
  - (2026-07-22) [USASpending] $2,170,949,215 → THE TRUSTEES OF PRINCETON UNIVERSITY: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE P
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE PRINCETON PLASMA PHYSICS LABORATORY (PPPL)
  - (2026-07-22) [USASpending] $2,121,046,270 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.
  - (2026-07-22) [USASpending] $1,599,628,076 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
  - (2026-07-22) [USASpending] $1,451,665,745 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, 1st Cir.: Recchia v. Campbell
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: Exxon Mobil Corp v. OSHC
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: United States v. Fullerton
  - (2026-07-21) U.S. Court of Appeals, 5th Cir.: United States v. Palomares
  - (2026-07-17) U.S. Court of Appeals, 1st Cir.: Rhode Island Truck Ctr., LLC v. Daimler Trucks North America, LLC
  - (2026-07-17) Alaska Supreme Court: Alyeska International Inc. v. State

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-07-22) LoL: LGD Gaming vs EDward Gaming - Game 1 Winner
      yes price: 50% · 24h volume: $573,211 · resolves 2026-07-22
  - (2026-07-22) Will Vivek Ramaswamy win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $556,000 · resolves 2028-11-07
  - (2026-07-22) Will LeBron James play for the Golden State Warriors in 2026-27?
      yes price: 11% · 24h volume: $353,258 · resolves 2026-10-31
  - (2026-07-22) Will Pau Cubarsi win the 2026 Ballon d'Or?
      yes price: 1% · 24h volume: $333,959 · resolves 2026-10-31
  - (2026-07-22) Will Fabian Ruiz win the 2026 Ballon d'Or?
      yes price: 2% · 24h volume: $333,547 · resolves 2026-10-31
  - (2026-07-22) LoL: LGD Gaming vs EDward Gaming (BO3) - LPL Group Ascend
      yes price: 50% · 24h volume: $331,175 · resolves 2026-07-22

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 37 total
  - (2026-07-22) MOVER ▼ Tadashi Yanai & family — $65.83B ($-1.65B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-22) MOVER ▼ Gautam Adani — $88.47B ($-1.26B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-22) MOVER ▼ Mukesh Ambani — $87.36B ($-0.91B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-22) MOVER ▲ Amancio Ortega — $137.94B (+$0.69B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-22) MOVER ▼ Masayoshi Son — $66.95B ($-0.52B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-22) MOVER ▲ Francoise Bettencourt Meyers & family — $92.94B (+$0.15B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Paper Trading Scorecard — 5 new of 143 total
  - (2026-07-22) [Polymarket] Will the US announce withdrawal from MOU negotiations by August 31?
      On June 14, 2026, the United States and Iran announced a memorandum of understanding ending the immediate conflict and establishing a 60-day framework for negotiating a final agreement. This market will resolve to "Yes"…
  - (2026-07-22) [Manifold] Free Lottery (cat & rat)
  - (2026-07-22) [Manifold] Will a consumer AI meaningfully hack something to answer a question for a regular user by eoy 2027?
  - (2026-07-22) [Manifold] Will "How big is the Sun? How could you figure it out?" make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-07-22) [Manifold] Lebron James to sign with a former team?

### USGS earthquakes (M4.5+, past day) — 4 new of 17 total
  - (2026-07-22) M 5.0 - 55 km WSW of Langsa, Indonesia
      M5.0 · 55 km WSW of Langsa, Indonesia · depth 10 km
  - (2026-07-22) M 4.9 - 208 km W of Abepura, Indonesia
      M4.9 · 208 km W of Abepura, Indonesia · depth 21.587 km
  - (2026-07-22) M 4.7 - 12 km SE of Cuya, Chile
      M4.7 · 12 km SE of Cuya, Chile · depth 60.814 km
  - (2026-07-22) M 4.6 - 124 km SE of Kuril’sk, Russia
      M4.6 · 124 km SE of Kuril’sk, Russia · depth 35 km

### GDACS — global disaster alerts — 3 new of 203 total
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-22) [Marginal Revolution] Alec Stapp on the new Science report from Michael Kratsios
      Major new report from the White House Office of Science and Technology Policy. Five things in the report I really liked: 1. Proposes metascience units as a way to advance experimentation in science agencies. IFP recommen…
  - (2026-07-22) [Marginal Revolution] Betting markets in everything
      Alan and Karen Miller’s first dance was a win-or-lose moment for many of their wedding guests. As the couple glided across the floor during their reception in New Rochelle, N.Y., last year, attendees kept track of the ch…

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: review, special, amendments, fisheries, fishery, service, provide, regulated, persons, certain, public, safety
- state_bills: today=227, 7d-median=120, 14d-median=120; carrying terms: common, located, covered, permits, identity, grant, community, establish, factor, provide, prohibited, second
- state_news: today=770, 7d-median=729, 14d-median=729; carrying terms: activity, streets, summit, rejected, efforts, covered, three, injunction, stricter, grant, indigenous, continued
- local_news: today=236, 7d-median=232, 14d-median=232; carrying terms: cbmipafbvv, three, community, content, combination, florida, srcset, weekend, award, injuries, president, around
- foreign_news: today=1000, 7d-median=1022, 14d-median=1022; carrying terms: activity, streets, rejected, kingdom, launch, damaging, continued, dailystar, reportedly, level, suspended, second
- chinese_internal: today=307, 7d-median=301, 14d-median=301; carrying terms: target, people, articles, cbmiw, google, global, cbmizefvx, politics, cbmibkfvx, cbmib, cbmicefvx, blank
- russian_internal: today=1056, 7d-median=893, 14d-median=893; carrying terms: financial, title, laquo, raquo, gazeta, apple, client, istories, journal, bloomberg, variety, https
- ukrainian_internal: today=107, 7d-median=126, 14d-median=126; carrying terms: critic, information, called, stability, three, region, damaging, parliament, continued, targeted, multiple, reportedly
- ukraine_theater: today=337, 7d-median=518, 14d-median=518; carrying terms: afbvv, wzoeqwumh, rjmwb, nemdjuwlqmxjqukl, cbmipafbvv, resistance, ahvqznbuoelwx, ycfdbqktzrl, uljyynrwyxuzbffblvrb, cuxoeulwwvlvbgzhzetbtkflvmdszfzun, ppcxh, lfuhfougp
- paper_bets: today=143, 7d-median=144, 14d-median=144; carrying terms: using, information, specified, finish, resolve, special, general, successor, playoffs, listed, annual, launch
- weather: today=172, 7d-median=172, 14d-median=172; carrying terms: information, kermadec, northeast, tropical, creek, portions, located, eastern, region, short, currents, afddtx
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dcoilwtico, growth, labor, total, personal, walcl, latest, sheet, effective, implied, headline, unrate
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, rates, yield, crypto, large, treasury, agriculture, equities, bitcoin, nasdaq, proxy, close
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=111, 7d-median=117, 14d-median=117; carrying terms: hpztrtswjpmf, information, stability, operational, review, owned, rkjnserfwk, misappropriation, agreement, cbmie, burundi, eastern
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, https, quiverquant, client, error, quantitative, httperror, congresstrading, quiver
- billionaires: today=37, 7d-median=36, 14d-median=36; carrying terms: telecom, finance, changpeng, ambani, nasdaq, amancio, bezos, ellison, thomas, technology, holdings, brokerage
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: abbey, scioto, pennsylvania, chester, association, general, pistol, community, cline, crisp, jersey, family
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, issuer, filed, amended, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, alexandria, robert, booker, congress, cooper, groom, elect, pinkston, ossoff, chartered, brown
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan, japanherald
- gdelt_gkg: today=0, 7d-median=46, 14d-median=46; carrying terms: chinese, english, israel, hezbollah, perimeter, russia, spanish, themes, russian, senate, trump, sanctions
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=9, 14d-median=9
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: caused, remains, coronavirus, early, information, western, notification, reaching, activity, monkeypox, sequencing, seasonal
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: authentication, product, remediation, lockout, overly, dangerous, icagenda, restrictive, account, langflow, sonicwall, services
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=203, 7d-median=162, 14d-median=162; carrying terms: vietnam, congo, kazakhstan, tropical, elida, marino, indonesia, papua, switzerland, austria, belarus, ecuador
- usgs_quakes: today=17, 7d-median=18, 14d-median=18; carrying terms: kermadec, islands, puerto, depth, indonesia, philippines, region, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: demeke, meeting, ethiopia, prime, rates, interest, price, resolves, mekonnen, minister, volume, boston
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: paper, effects, editor, roles, estimating, assorted, conversable, jaeger, healthier, economist, vibes, lecture
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: information, contains, review, digital, covered, maintain, multiple, stories, service, almost, artificial, haven
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: haridopolos, edwards, vasquez, stauber, hoeven, keith, elizabeth, susie, carbajal, salazar, reserved, kennedy
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, consensus, sufficient, market, today, paper, evidence, decision, placement, markets, claude, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*