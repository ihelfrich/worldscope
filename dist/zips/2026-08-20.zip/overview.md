# WORLDSCOPE morning brief — 2026-08-20

## Headline
3486 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (763) · Russian Internal News (state + in-exile) (700) · World leaders & government officials (324) · State-Level News (257) · Chinese Internal News (239) · State Legislative Action (225) · Ukraine Theater (total-war monitoring) (198) · Local News: St. Louis + Atlanta (197) · U.S. Weather + Severe / Climate Outlooks (170) · Ukrainian Internal News (national + local Kyiv) (67) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 763 new of 1021 total
  - (2026-08-20) [Global] At least 12 killed in Kyiv as Ukraine grapples with air defence shortages
      Apartment blocks and warehouses were targeted in the "massive attack" on Thursday, officials say.
  - (2026-08-20) [Global] Founder of collapsed Chinese property giant Evergrande sentenced to life in prison
      Hui's sentencing marks a key moment in the fallout from Evergrande's collapse, which shook China's property sector.
  - (2026-08-20) [Global] Australia 'outraged' after Israel decides not to open criminal investigation into killing of aid worker in Gaza
      Australia's foreign minister summoned the Israeli ambassador over "insulting" Zomi Frankcom decision.
  - (2026-08-20) [Global] Trump vows tougher economic measures on Iran and supporting countries
      It comes after a 60-day ceasefire expired on Monday, with no sign of a diplomatic or military off-ramp to the conflict.
  - (2026-08-20) [Global] Mushroom killer must stay in jail forever for 'truly dreadful' crime, appeal court told
      Prosecutors say Erin Patterson's sentence was "manifestly inadequate" as it allows for the possibility of parole.
  - (2026-08-20) [Global] Missing teen hiker found dead in Australian bush after eight-day search
      The state premier initially said Lily Hooper had been found alive before police confirmed her death.

### Russian Internal News (state + in-exile) — 700 new of 1089 total
  - (2026-08-20) Axios: США создали секретный маршрут в Ормузском проливе, через который перевозятся миллионы баррелей нефти | LEDE: Американские военные тайно создали судоходный коридор в Ормузском проливе,] (ru: Axi…
      Американские военные тайно создали судоходный коридор в Ормузском проливе, через который ежедневно перевозятся миллионы баррелей нефти. Об этом пишет Axios со ссылкой на двух американских чиновников.
  - (2026-08-20) Немецкое издание LTO: украинца, подозреваемого в подрыве «Северных потоков», арестовали на съемках фильма о «Северных потоках» | LEDE: Арест гражданина Украины Владимира Журавлева, подозрева] (ru: Нем…
      Арест гражданина Украины Владимира Журавлева, подозреваемого в причастности к взрывам на «Северных потоках», произошел в Хорватии во время съемок фильма, посвященного этой диверсии. Об этом пишет немецкое издание LTO.
  - (2026-08-20) Проект «Идите лесом» рассказал о насильственных задержаниях и принуждении мужчин к контракту в шести регионах России. За девять дней получено 14 обращений | LEDE: Проект «Идите лесом» с 10 п] (ru: Про…
      Проект «Идите лесом» с 10 по 18 августа получил 14 обращений о людях, которых задерживали и заставляли подписать контракт с Минобороны России. Обращения получены из Ижевска, Новороссийска, Омска, Архангельской области, Б…
  - (2026-08-20) Принц Гарри и Меган Маркл решили вернуться в Великобританию | LEDE: Герцог и герцогиня Сассекские, принц Гарри и Меган Маркл планируют уехать из США и вернуться в Великобританию. Об этом соо] (ru: При…
      Герцог и герцогиня Сассекские, принц Гарри и Меган Маркл планируют уехать из США и вернуться в Великобританию. Об этом сообщают The Telegraph и BBC News.
  - (2026-08-20) Трамп объявил о начале «самой сокрушительной экономической операции» против Ирана | LEDE: Президент США Дональд Трамп заявил, что начинает «экономическую войну» против Ирана. Об этом он напи] (ru: Тра…
      Президент США Дональд Трамп заявил, что начинает «экономическую войну» против Ирана. Об этом он написал в соцсети Truth Social.
  - (2026-08-20) Россия нанесла удар по Киеву. Погибли 12 человек, более 30 пострадали | LEDE: Российские войска в ночь на 20 августа атаковали Киев баллистическими ракетами, сообщил мэр украинской столицы В] (ru: Рос…
      Российские войска в ночь на 20 августа атаковали Киев баллистическими ракетами, сообщил мэр украинской столицы Виталий Кличко.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 257 new of 615 total
  - (2026-08-20) [California] Governor Newsom announces appointments 8.19.26
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/SEO-Thumbnail-Template-2.0-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="Blue background with a white ci…
  - (2026-08-19) [California] As school begins, California launches universal Transitional Kindergarten, free meals for EVERY student and historic supports for kids
      Source
  - (2026-08-19) [California] Las ciudades penitenciarias de California buscan desesperadamente nuevos empleos tras los cierres: ‘Nadie vendrá a salvarnos’
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/041026-Susanville-LV-CM-05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-08-19) [California] Los incendios forestales se propagan por las carreteras. La administración Trump quiere construir más en áreas protegidas
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/080425-Gifford-Fire-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-08-19) [California] Exclusive records show California Forever’s intense lobbying
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/02/021624-California-Forever-LE-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-08-19) [California] Five California propositions ask the same question: Who should pay billions in taxes?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/070325-Luxury-Homes-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### Chinese Internal News — 239 new of 296 total
  - (2026-08-19) Chinese Robot-Maker Unitree Soars 629% in Shanghai Debut - Caixin Global
      Chinese Robot-Maker Unitree Soars 629% in Shanghai Debut Caixin Global
  - (2026-08-18) China’s Green Energy Exports Jump in July as EV Shipments Surge - Caixin Global
      China’s Green Energy Exports Jump in July as EV Shipments Surge Caixin Global
  - (2026-08-18) China to Let Mainland Insurers Buy Hong Kong ETFs Through Stock Connect - Caixin Global
      China to Let Mainland Insurers Buy Hong Kong ETFs Through Stock Connect Caixin Global
  - (2026-08-19) 谁在看“烂片”《牛来》？票房超2400万元 一二线城市、青少年观众占比高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1Zenk0TXhEUkhlYi1jbWlBeXdBWkg3MFRsZXNJRUkxQmE2NHhybU9YX3Y3VUp1YzVSd2N6bkxoZEFDRGt1V] (zh:…
      谁在看“烂片”《牛来》？票房超2400万元 一二线城市、青少年观众占比高 财新
  - (2026-08-19) PRO专享/数据深度专题 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMie0FVX3lxTFBTV1lhbklCc1k0Y2FxMzQ2bEdqcVRHM3I5Tl9oOGRiRUxQSXVNSUE4RVg4d3ZWbnN3VFQ2NXdjc3BGWThjd2RUNUky] (zh:…
      PRO专享/数据深度专题 deepview.caixin.com
  - (2026-08-20) 今日开盘：两市双双高开 沪指涨幅0.33% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE4zMWxGTmJ4UlhBa1dmbi1TUURHQzlqXzN6ZFhIRnhPdmVYSGoxdzl0b1NvOTA5cEdaR1kxb2Jaa1Y5RmE3LTZOSUlzVXRHQzVX] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.33% 财新

### State Legislative Action — 225 new of 251 total
  - (2026-08-19) [Alaska SB 226] An Act relating to the sale of homemade food.
      An Act relating to the sale of homemade food.
  - (2026-08-19) [Alaska SB 111] An Act relating to the diagnosis, maintenance, and repair of consumer products that use digital electronics to operate; adding an unlawful act to the Alaska Unfair Trade Practices and…
      An Act relating to the diagnosis, maintenance, and repair of consumer products that use digital electronics to operate; adding an unlawful act to the Alaska Unfair Trade Practices and Consumer Protection Act; and providi…
  - (2026-08-19) [Alaska SB 185] An Act relating to the business of insurance; relating to exceptions to prohibited rebates; relating to the powers of the director of the division of insurance; relating to prohibited…
      An Act relating to the business of insurance; relating to exceptions to prohibited rebates; relating to the powers of the director of the division of insurance; relating to prohibited practices in the advertisement of in…
  - (2026-08-19) [Alaska SB 196] An Act establishing a behavioral health crisis services surcharge; establishing the behavioral health crisis services fund; and providing for an effective date.
      An Act establishing a behavioral health crisis services surcharge; establishing the behavioral health crisis services fund; and providing for an effective date.
  - (2026-08-19) [Alaska SB 244] An Act relating to travel insurance.
      An Act relating to travel insurance.
  - (2026-08-19) [Alaska SB 150] An Act relating to a net metering program; relating to reduced rates in the form of credits for consumer-generators; establishing a net metering reimbursement fund; and providing for a…
      An Act relating to a net metering program; relating to reduced rates in the form of credits for consumer-generators; establishing a net metering reimbursement fund; and providing for an effective date.

### Ukraine Theater (total-war monitoring) — 198 new of 411 total
  - (2026-08-20) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-19) [Liveuamap] Israeli airstrike targeted Deir al-Zahrani Nabatiyeh Governorate, Lebanon - Lebanon news on live map - Liveuamap
      Israeli airstrike targeted Deir al-Zahrani Nabatiyeh Governorate, Lebanon - Lebanon news on live map <font c
  - (2026-08-18) [Liveuamap] At Kostiantynivka direction clashes yesterday near Kostyantynivka, Ivanopillya, Illinivka, Novoselivka, Sofiyivka, Rusyn Yar, Vilne, Kucheriv Yar, Novopavlivka, - General Staff of Armed Fo…
      At Kostiantynivka direction clashes yesterday near Kostyantynivka, Ivanopillya, Illinivka, Novoselivka, Sofiyivka, Rusyn Yar, Vil
  - (2026-08-11) [Liveuamap] Interactive map of Yemen war - Yemen news live map - Liveuamap
      Interactive map of Yemen war - Yemen news live map Liveuamap
  - (2026-08-19) [Liveuamap] Day of news on live map - August, 18 2026 - News live map of conflicts in Asia - live incidents reports - Liveuamap
      Day of news on live map - August, 18 2026 - News live map of conflicts in Asia - live incidents reports Liveuamap
  - (2026-08-18) [Liveuamap] Day of news on live map - August, 03 2026 - Map of News from Egypt - War on Islamic State group at Sinai - Liveuamap
      Day of news on live map - August, 03 2026 - Map of News from Egypt - War on Islamic State group at Sinai Liveuamap

### Local News: St. Louis + Atlanta — 197 new of 226 total
  - (2026-08-20) [St. Louis] Where in the Lou? – 8/20/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-08-19) [St. Louis] The Magic House reimagines Trike Town with new Route 66 exhibit
      If your household has spent any amount of time watching Cars, you already know the appeal of Route 66: quirky roadside stops, wide-open-road adventure, and the idea that sometimes the best part of a road trip is everythi…
  - (2026-08-19) [St. Louis] Room to grow—Abode by Parklyn finds a bigger home in Webster Groves
      For anyone who has spent hours scrolling through home décor websites or wandering the endless aisles of an antique mall in search of the perfect piece, interior designer Danielle Kalish understands the struggle. Finding…
  - (2026-08-19) [St. Louis] Mikey Wehling bids a fond farewell to his family’s rural homestead on ‘Camp Scout Vol. 4’
      Mikey Wehling grins as he turns off Krenning Road and drives onto his family’s homestead in Beaufort, Missouri, a rural community of just over 1,100 residents. For four generations of Wehling’s family, the Franklin Count…
  - (2026-08-19) [St. Louis] Inside a rescued midcentury modern house museum in Belleville, Illinois
      In 1952, Terry and Thelma Blazier commissioned architect Charles E. King to design a new home for them in the Oak Knoll neighborhood in Belleville. The couple, who were empty nesters, loved to throw parties and designed…
  - (2026-08-19) [St. Louis] Where in Clayton 8/20/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…

### U.S. Weather + Severe / Climate Outlooks — 170 new of 173 total
  - (2026-08-20) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 20 at 2:34AM CDT until August 20 at 3:15AM CDT by NWS Memphis TN
      SVRMEG The National Weather Service in Memphis has issued a * Severe Thunderstorm Warning for... Northeastern Mississippi County in eastern Arkansas... Southeastern Pemiscot County in southeastern Missouri... Crockett Co…
  - (2026-08-20) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 20 at 2:34AM CDT until August 20 at 2:45AM CDT by NWS Memphis TN
      At 234 AM CDT, a severe thunderstorm was located near Bradleytown, or 7 miles west of Dyersburg, moving east at 40 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hail damage to…
  - (2026-08-20) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 20 at 3:32AM EDT until August 20 at 4:00AM EDT by NWS Indianapolis IN
      SVRIND The National Weather Service in Indianapolis has issued a * Severe Thunderstorm Warning for... Southeastern Shelby County in central Indiana... Southeastern Rush County in central Indiana... Decatur County in cent…
  - (2026-08-20) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 20 at 2:32AM CDT until August 20 at 3:00AM CDT by NWS Paducah KY
      At 232 AM CDT, severe thunderstorms were located along a line from near Lovelaceville to near Olive Branch, or along a line from 8 miles northeast of Bardwell to 9 miles southeast of Scott City, moving southeast at 40 mp…
  - (2026-08-20) [Moderate] Special Weather Statement: Special Weather Statement issued August 20 at 2:29AM CDT by NWS Memphis TN
      At 228 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from near Waverly to near Huntingdon to near Bradford. Movement was east at 20 mph. HAZARD...Wind gusts of 50 to 55 mph. SOURCE...Rada…
  - (2026-08-20) [Moderate] Rip Current Statement: Rip Current Statement issued August 20 at 3:28AM EDT until August 21 at 2:00AM EDT by NWS Tallahassee FL
      * WHAT...Dangerous rip currents expected. * WHERE...Gulf County Beaches. * WHEN...From noon EDT /11 AM CDT/ today through late tonight. * IMPACTS...Rip currents can sweep even the best swimmers away from shore into deepe…

### Ukrainian Internal News (national + local Kyiv) — 67 new of 113 total
  - (2026-08-20) Держборг США за менш як 10 років подвоївся і перевищив 40 трлн доларів | LEDE: Держборг США вперше сягнув 40 трлн доларів, що вдвічі більше ніж на початку каденції Трампа у 2017 році.] (uk: Держборг С…
      Держборг США вперше сягнув 40 трлн доларів, що вдвічі більше ніж на початку каденції Трампа у 2017 році.
  - (2026-08-20) Які запаси ракет у Росії та навіщо їм новий ракетний підрозділ КНДР: що кажуть експерти і ГУР | LEDE: У серпні 2026 року Росія розпочала розгортання північнокорейського ракетного підрозділу у В] (uk:…
      У серпні 2026 року Росія розпочала розгортання північнокорейського ракетного підрозділу у Воронезькій області РФ, що межує з Луганською. Йдеться про 6 пускових установок КНДР, які матимуть 120 балістичних ракет. Співпрац…
  - (2026-08-20) Армія РФ атакувала ринок у Херсоні: 5 людей дістали поранення | LEDE: 20 серпня росіяни обстріляли ринок у Корабельному районі Херсона, п’ятеро людей отримали поранення.] (uk: Армія РФ атакувала ринок…
      20 серпня росіяни обстріляли ринок у Корабельному районі Херсона, п’ятеро людей отримали поранення.
  - (2026-08-20) Слідом за ТЦК ДБР взялося перевіряти військові частини: заплановано понад 70 обшуків | LEDE: Державне бюро розслідувань розпочало нову масштабну спецоперацію перевірок у військовій сфері.] (uk: Слідом…
      Державне бюро розслідувань розпочало нову масштабну спецоперацію перевірок у військовій сфері.
  - (2026-08-20) Безпілотники атакували НПЗ у Татарстані, нафтотермінал та підстанцію у Краснодарському краї | LEDE: Дрони атакували НПЗ у Татарстані, нафтовий термінал і підстанцію у Краснодарському краї 20 се] (uk:…
      Дрони атакували НПЗ у Татарстані, нафтовий термінал і підстанцію у Краснодарському краї 20 серпня.
  - (2026-08-20) РФ вдарила "Оніксами", "Цирконами", "Іскандерами", "Калібрами" та 168 дронами: основний удар – по Київщині | LEDE: У ніч на 20 серпня Росія атакувала Україну ракетами та дронами, ППО знищила 18] (uk:…
      У ніч на 20 серпня Росія атакувала Україну ракетами та дронами, ППО знищила 186 цілей, основний удар припав на Київщину.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-20) [TENG SONG-YUAN] Form 4 (Reporting)
      filed 2026-08-20 01:59 UTC · role: Reporting — Filed: 2026-08-19 AccNo: 0001683168-26-006619 Size: 5 KB
  - (2026-08-20) [NOCERA, INC.] Form 4 (Issuer)
      filed 2026-08-20 01:59 UTC · role: Issuer — Filed: 2026-08-19 AccNo: 0001683168-26-006619 Size: 5 KB
  - (2026-08-20) [JIN ANDY CHING-AN] Form 4 (Reporting)
      filed 2026-08-20 01:59 UTC · role: Reporting — Filed: 2026-08-19 AccNo: 0001683168-26-006618 Size: 5 KB
  - (2026-08-20) [NOCERA, INC.] Form 4 (Issuer)
      filed 2026-08-20 01:59 UTC · role: Issuer — Filed: 2026-08-19 AccNo: 0001683168-26-006618 Size: 5 KB
  - (2026-08-20) [Mazarakis John] Form 4 (Reporting)
      filed 2026-08-20 01:56 UTC · role: Reporting — Filed: 2026-08-19 AccNo: 0001193125-26-357420 Size: 7 KB
  - (2026-08-20) [Chicago Atlantic BDC, Inc.] Form 4 (Issuer)
      filed 2026-08-20 01:56 UTC · role: Issuer — Filed: 2026-08-19 AccNo: 0001193125-26-357420 Size: 7 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-20) [United Kingdom] BBC war film hailed master class in suspense with acting royalty
      domain: manchestereveningnews.co.uk · language: English · tone:
  - (2026-08-20) [United States] Judge will consider new trial for Karmelo Anthony in Texas track meet killing
      domain: dailygazette.com · language: English · tone:
  - (2026-08-20) [United States] US Airports Remain Busy Despite Surging Prices
      domain: zerohedge.com · language: English · tone:
  - (2026-08-20) [United States] Telpi , Promising People partner to expand VR career training for skilled trades
      domain: wtov9.com · language: English · tone:
  - (2026-08-20) [United Kingdom] Ex - church leader : Farage using Christianity to channel anti - Muslim feeling
      domain: times-series.co.uk · language: English · tone:
  - (2026-08-20) [United Kingdom] Powys : Public Notices Portal round - up with claim over meadow
      domain: countytimes.co.uk · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 37 new of 56 total
  - (2026-08-20) [BleepingComputer] Microsoft says August Windows updates may cause gaming issues
      Microsoft is investigating a potential issue with the August 2026 updates that may prevent some games from launching or cause them to crash on affected Windows 11 systems. [...]
  - (2026-08-20) [BleepingComputer] OpenAI confirms ChatGPT is down as logins and signups fail
      ChatGPT is experiencing a major outage, and users are unable to sign in, create accounts, or load chats, including previous conversations. [...]
  - (2026-08-20) [The Hacker News] Elementor Pro Flaw Could Let Unauthenticated Attackers Upload PHP and Execute Code
      Cybersecurity researchers have disclosed details of a critical flaw in the Elementor Pro WordPress plugin that, if successfully exploited, could lead to remote code execution. The vulnerability, tracked as CVE-2026-32475…
  - (2026-08-20) [The Register] AI agent suggested installing a malware package. Engineer almost took its advice
      Fortunately, the company had a policy of checking source code on GitHub first
  - (2026-08-20) [The Register] China marches towards re-usable rockets with successful first-stage landing
      Red alert for rivals as LandSpace nails it after December disaster
  - (2026-08-20) [The Register] IBM says super-chill boxes that connect through 'cryogenic tunnels' will get quantum computers scaling
      Absolute zero inside is much cooler than Intel inside

### Court opinions of consequence (federal & state) — 32 new of 60 total
  - (2026-08-19) U.S. Court of Appeals, 6th Cir.: Laurel Hill Mgmt. Servs., Inc v. La-Z-Boy Inc.
  - (2026-08-19) U.S. Court of Appeals, 6th Cir.: United States v. Frank Clay, Jr.
  - (2026-08-19) U.S. Court of Appeals, 6th Cir.: United States v. Steven Randall Neal
  - (2026-08-19) U.S. Court of Appeals, Federal Cir.: Vdpp, LLC v. Volkswagen Group of America, Inc.
  - (2026-08-19) U.S. Court of Appeals, 2nd Cir.: Fonden v. FDIC
  - (2026-08-19) U.S. Court of Appeals, 2nd Cir.: Wong v. Blanche

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 26 new of 139 total
  - (2026-08-20) [Polymarket] Will the price of Bitcoin be above $62,000 on August 21?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-08-20) [Polymarket] Will Radu Burnete be the next Prime Minister of Romania?
      This market will resolve to the next individual who officially assumes the office of Prime Minister of Romania by December 31, 2027, 11:59 PM ET. To count for resolution, the individual must be formally appointed by the…
  - (2026-08-20) [Polymarket] Will Donald Trump win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-08-20) [Kalshi] Who will be the next Prime Minister of the United Kingdom?
      Before Jan 1, 2035
  - (2026-08-20) [Manifold] Will Ghent fire Nathan Cofnas before 2028?
  - (2026-08-20) [Manifold] Trump meets Kim Jong Un in 2026?

### Government & military aircraft airborne (OpenSky) — 26 new of 26 total
  - (2026-08-20) JAF1TA (Bulgaria)
      icao24: 4520d0 · position: (48.4928, 1.8788) · alt: 9753m · 953km/h
  - (2026-08-20) JAF56C (Bulgaria)
      icao24: 4520aa · position: (44.4337, -1.1025) · alt: 10972m · 892km/h
  - (2026-08-20) FAF7813 (France)
      icao24: 39a842 · position: (45.6646, -0.6682) · alt: 1211m · 277km/h
  - (2026-08-20) PUMA22 (Slovenia)
      icao24: 506e18 · position: (45.9427, 14.5512) · alt: 853m · 185km/h
  - (2026-08-20) PUMA42 (Slovenia)
      icao24: 506e1d · position: (45.9949, 15.3993) · alt: 1341m · 194km/h
  - (2026-08-20) PUMA23 (Slovenia)
      icao24: 506e1c · position: (46.0427, 15.515) · alt: 1158m · 143km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-20) [Russia oil sanctions perimeter · themes] MPC minutes signal hawkish tilt ; rate hikes may come sooner if inflation broadens
      massachusettssun.com · English · tone NA
  - (2026-08-20) [Russia oil sanctions perimeter · themes] Opilý pekař z Titaniku . Přežil ledový Atlantik a stal se jednou z největších záhad slavné katastrofy
      zpravy.tiscali.cz · Czech · tone NA
  - (2026-08-20) [Russia oil sanctions perimeter · themes] US Airports Remain Busy Despite Surging Prices
      zerohedge.com · English · tone NA
  - (2026-08-20) [Russia oil sanctions perimeter · themes] 監委被提名人徐光蓉 ： 核安要堅持 2年內重啟核電有困難 | 政治
      cna.com.tw · Chinese · tone NA
  - (2026-08-20) [Russia oil sanctions perimeter · themes] 高膽固醇恐中風 ！ 研究揭 「 這2種運動 」 搭配做 降壞膽固醇最有效 | 健康 | 三立新聞網 SETN . COM
      setn.com · Chinese · tone NA
  - (2026-08-20) [Russia oil sanctions perimeter · themes] Mâm cơm cúng rằm tháng 7 không cần cao sang nhưng phải có 5 món này để cả năm giữ lộc lành
      vietgiaitri.com · Vietnamese · tone NA

### U.S. Federal Action — 24 new of 24 total
  - (2026-08-20) Airworthiness Directives; The Boeing Company Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for certain The Boeing Company Model 787-8 airplanes. This proposed AD was prompted by a report that large forward cargo door (LFCD) split frames may have been…
  - (2026-08-20) Small Business Size Standards
      The U.S. Small Business Administration (SBA or the Agency) is proposing new size standards for 338 industry groups and industries. The new size standards are designed to better reflect the nature of the markets in which…
  - (2026-08-20) Small Business Size Standards: Revised Size Standards Methodology
      The U.S. Small Business Administration (SBA or Agency) advises the public that it has revised its white paper explaining how it establishes, reviews, and modifies small business size standards. The revised white paper pr…
  - (2026-08-20) Determination of Target Normal Cost and Funding Target for Single-Employer Defined Benefit Plans
      This document contains proposed regulations that would modify rules in the existing regulations relating to the minimum funding requirement applicable to single-employer defined benefit pension plans. The modifications i…
  - (2026-08-20) Application of Section 250(b)(3)(A)(i)(VII) to Sales or Other Dispositions of Property
      This document contains proposed regulations under section 250 of the Internal Revenue Code (Code) that provide guidance on certain income of a domestic corporation that is excluded in the determination of deduction eligi…
  - (2026-08-20) Special Local Regulation; North East, North East, MD
      The Coast Guard is establishing a temporary special local regulation (SLR) for certain waters of the North East River, near North East, MD. This action is necessary to provide for the safety of life on these navigable wa…

### USGS earthquakes (M4.5+, past day) — 19 new of 19 total
  - (2026-08-19) M 5.8 - 25 km NNE of Ruteng, Indonesia
      M5.8 · 25 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-20) M 5.7 - 32 km NNE of Ruteng, Indonesia
      M5.7 · 32 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-19) M 5.5 - 52 km NNE of Ruteng, Indonesia
      M5.5 · 52 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-19) M 5.4 - 215 km E of Levuka, Fiji
      M5.4 · 215 km E of Levuka, Fiji · depth 556.753 km
  - (2026-08-19) M 5.4 - 134 km S of Severo-Kuril’sk, Russia
      M5.4 · 134 km S of Severo-Kuril’sk, Russia · depth 41.176 km
  - (2026-08-19) M 5.2 - 33 km N of Ruteng, Indonesia
      M5.2 · 33 km N of Ruteng, Indonesia · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 92 total
  - (2026-08-20) [BIS Entity List] page checksum 71c5c4961d51
      Page content hash: 71c5c4961d51. Compare with prior day's hash to detect updates.
  - (2026-08-20) [USASpending] $42,774,168,231 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-08-20) [USASpending] $30,691,741,338 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-08-20) [USASpending] $19,868,865,110 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…
  - (2026-08-20) [USASpending] $17,457,615,881 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy. Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-08-20) [USASpending] $14,933,400,228 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE
      Agency: Department of Energy. Description: OPERATION AND MAINTENANCE LINEAR ACCELLERATOR

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-08-20) Dota 2: TEAM VISION vs BoomBoys - Game 1 Winner
      yes price: 100% · 24h volume: $2,026,473 · resolves 2026-08-20
  - (2026-08-20) Will the Fed decrease interest rates by 25 bps after the September 2026 meeting?
      yes price: 1% · 24h volume: $1,001,006 · resolves 2026-09-16
  - (2026-08-20) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 26% · 24h volume: $446,533 · resolves 2026-09-16
  - (2026-08-20) Will there be no change in Fed interest rates after the September 2026 meeting?
      yes price: 72% · 24h volume: $409,578 · resolves 2026-09-16
  - (2026-08-20) LoL: Dplus KIA vs Hanwha Life Esports (BO3) - LCK Round 3-4 Legend Group
      yes price: 48% · 24h volume: $304,381 · resolves 2026-08-20
  - (2026-08-20) Will Bitcoin reach $72,500 in August?
      yes price: 46% · 24h volume: $285,467 · resolves 2026-09-01

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 40 total
  - (2026-08-20) MOVER ▼ Elon Musk — $865.96B ($-13.24B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-20) MOVER ▼ Michael Dell — $233.76B ($-12.38B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-20) MOVER ▲ Jeff Bezos — $273.00B (+$5.64B since yesterday)
      United States · Technology · source: Amazon
  - (2026-08-20) MOVER ▼ Jensen Huang — $187.90B ($-1.85B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-08-20) MOVER ▲ Larry Ellison — $185.94B (+$1.62B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-20) MOVER ▲ Tadashi Yanai & family — $65.35B (+$0.89B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-20) [Marginal Revolution] My excellent Conversation with Luke Burgis
      Here is the audio, video, and transcript. Here is the episode summary: Luke Burgis left Wall Street after two years, founded a few successful companies in his twenties, then walked away to spend three years in a Roman se…
  - (2026-08-19) [Marginal Revolution] Declining Occupations and Career Outcomes in the United States
      This strikes me as somewhat less of a problem than I might have thought: We study long-run career consequences of initial employment in an occupation that subsequently declines. Linking the 2000 Decennial Census to US ad…
  - (2026-08-19) [Marginal Revolution] Wednesday assorted links
      1. Human lawyer for AI agents. And more. Come on, all you agents, you need a guy like this! 2. Saloni’s TED talk on medical cures. 3. Has there been a collapse in British pride? 4. Those new service sector jobs? (solving…
  - (2026-08-19) [Conversable Economist] “Syntax often breaks down just at the point where a new or significant meaning is beginning to break out”
      When writing feels hard, perhaps it is because you are on the cusp of saying something significant or interesting? The thought is oddly comforting to me. Donald Murray originally described this connection in his essay “M…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 10 total
  - (2026-08-19) CVE-2026-64849 · MLflow MLflow: MLflow Server-Side Request Forgery Vulnerability
      vendor: MLflow · product: MLflow · CISA remediation by 2026-09-02

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=20, 14d-median=20; carrying terms: establish, proposed, proposing, state, proposes, provide, certain, program, final, action, national, implementation
- state_bills: today=251, 7d-median=129, 14d-median=129; carrying terms: education, planning, transfer, financial, health, establish, every, justice, training, support, income, prohibit
- state_news: today=615, 7d-median=585, 14d-median=585; carrying terms: media, releases, thing, still, three, results, rising, preparing, columbia, appears, every, justice
- local_news: today=226, 7d-median=216, 14d-median=226; carrying terms: dekalb, three, following, public, trump, former, million, night, falcons, alert, taken, https
- foreign_news: today=1021, 7d-median=978, 14d-median=980; carrying terms: media, mimetype, votes, staff, venture, brings, hardware, three, africa, results, rising, allegations
- chinese_internal: today=296, 7d-median=280, 14d-median=269; carrying terms: cbmixkfvx, cbmib, lxtfa, cbmizefvx, https, cbmiakfvx, cbmickfvx, cbmidefvx, cbmix, cbmiykfvx, color, blank
- russian_internal: today=1089, 7d-median=1040, 14d-median=1040; carrying terms: media, bloomberg, journal, world, found, politico, novayagazeta, raquo, istories, telegram, wildberries, laquo
- ukrainian_internal: today=113, 7d-median=107, 14d-median=107; carrying terms: three, country, institute, client, error, refinery, support, allies, following, hmarochos, offensive, increasingly
- ukraine_theater: today=411, 7d-median=1151, 14d-median=887; carrying terms: uzuptz, zwdja, staff, cbmirwfbvv, nffqakhtv, vhdtc, southern, hiohnmbzv, vlpia, stnirlaxzvq, jubjrhmwlowjnln, thzhpyy
- paper_bets: today=139, 7d-median=141, 14d-median=139; carrying terms: earthquake, nuclear, supreme, district, chair, kylian, succeed, seats, bitcoin, midterm, speed, drought
- weather: today=173, 7d-median=173, 14d-median=173; carrying terms: evening, advisory, montgomery, indonesia, extreme, swimmers, early, normal, storms, southern, illnesses, remain
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: vixcls, growth, jolts, dexchus, pcepilfe, latest, jtsjol, personal, funds, nonfarm, unemployment, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, nasdaq, corporate, china, yield, futures, proxy, russell, treasury, agriculture, rates, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=92, 7d-median=93, 14d-median=97; carrying terms: restrictive, economic, enable, tunisia, mediterranean, legislation, effects, development, independence, unauthorised, trade, corporation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, https, quantitative, client, unauthorized, quiver, quiverquant, error, httperror
- billionaires: today=40, 7d-median=34, 14d-median=34; carrying terms: microsoft, discount, hathaway, gates, devasini, francoise, changpeng, madrid, walton, sergey, bloomberg, telecom
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, state, appeals, company, connecticut, international, court, group, blanche, trade, trust, village
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, capital, holdings, management
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: sherrod, house, ocasio, brown, cortez, booker, robert, disbursements, angels, pinkston, shawn, david
- gdelt_regions: today=0, 7d-median=6, 14d-median=9; carrying terms: english, japan, surge
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, russian, themes, chinese, trump, spanish, indonesian, russia, sanctions, greek, perimeter, german
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: military, english, india, israeli, language, kingdom, australia, domain
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=29, 14d-median=29; carrying terms: belgium, position, ground, france, germany, bulgaria, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: carrying, discharged, ministry, activity, broader, early, acute, district, private, accordance, seasonal, fever
- cisa_kev: today=10, 7d-median=9, 14d-median=9; carrying terms: secure, authentication, progress, vulnerability, command, injection, loadmaster, firewall, vendor, remediation, cisco, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=269, 14d-median=269; carrying terms: austria, agricultural, vietnam, earthquake, indonesia, solomon, romania, medium, wildfire, minor, japan, impact
- usgs_quakes: today=19, 7d-median=19, 14d-median=17; carrying terms: indonesia, depth, russia, philippines, vanuatu, kuril, ruteng, severo, tonga, levuka
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: interest, championship, normal, september, meeting, resolves, champions, traffic, returns, donetsk, august, hormuz
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, class, https, conversable, economist, revolution, marginalrevolution, social, seems, assorted, links, interview
- tech_news: today=56, 7d-median=58, 14d-median=56; carrying terms: world, google, technica, point, group, weekly, years, techcrunch, across, government, navigate, researchers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: castro, aguilar, rollins, lloyd, spartz, nanette, levin, staff, timmons, nydia, cuellar, crenshaw
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, placed, evidence, module, placement, identify, converges, market, consensus, either, unavailable, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*