# WORLDSCOPE morning brief — 2026-08-20

## Headline
3431 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (796) · Russian Internal News (state + in-exile) (734) · World leaders & government officials (324) · State-Level News (281) · Chinese Internal News (243) · Local News: St. Louis + Atlanta (200) · Ukraine Theater (total-war monitoring) (200) · U.S. Weather + Severe / Climate Outlooks (174) · State Legislative Action (127) · Ukrainian Internal News (national + local Kyiv) (68) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (39)

## What changed today
### International News + Multilateral Institutions — 796 new of 1041 total
  - (2026-08-20) [Global] At least 13 killed in Kyiv as Ukraine grapples with air defence shortages
      Apartment blocks and warehouses were targeted in the "massive attack" on Thursday, officials say.
  - (2026-08-20) [Global] Founder of collapsed Chinese property giant Evergrande sentenced to life in prison
      Hui's sentencing marks a key moment in the fallout from Evergrande's collapse, which shook China's property sector.
  - (2026-08-20) [Global] Trump vows tougher economic measures on Iran and supporting countries
      It comes after a 60-day ceasefire expired on Monday, with no sign of a diplomatic or military off-ramp to the conflict.
  - (2026-08-20) [Global] Mushroom killer must stay in jail forever for 'truly dreadful' crime, appeal court told
      Prosecutors say Erin Patterson's sentence was "manifestly inadequate" as it allows for the possibility of parole.
  - (2026-08-20) [Global] Australia 'outraged' after Israel decides not to open criminal investigation into killing of aid worker in Gaza
      Australia's foreign minister summoned the Israeli ambassador over "insulting" Zomi Frankcom decision.
  - (2026-08-20) [Global] Missing teen hiker found dead in Australian bush after eight-day search
      The state premier initially said Lily Hooper had been found alive before police confirmed her death.

### Russian Internal News (state + in-exile) — 734 new of 1116 total
  - (2026-08-20) Последствия российского удара по Киеву. Фотографии | LEDE: В ночь на 20 августа российские военные атаковали Украину с использованием крылатых и баллистических ракет и ударных дронов. Основн] (ru: Пос…
      В ночь на 20 августа российские военные атаковали Украину с использованием крылатых и баллистических ракет и ударных дронов. Основной целью атаки стал Киев. По данным властей, в городе погибли 12 человек, более 30 получи…
  - (2026-08-20) В Тульской области ребенок нарисовал на детской площадке героев «Смешариков». Власти пригрозили ему и его родителям уголовным делом | LEDE: В Тульской области администрация города Болохово о] (ru: В Т…
      В Тульской области администрация города Болохово обратилась в полицию из-за рисунка персонажей из «Смешариков» на резиновом покрытии детской площадки. Об этом сообщается на официальной странице городской администрации.
  - (2026-08-20) Война. 1639-й день. Новый удар России по Киеву: 12 человек погибли, более 30 ранены. Целями атаки были военные заводы, утверждает Минобороны РФ | LEDE: «Медуза» с 24 февраля 2022 года в прям] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-08-20) Украинские дроны атаковали Татарстан. Власти сообщили о пострадавших, нарушена работа промышленного кластера | LEDE: Украинские беспилотники утром 20 августа атаковали Татарстан, сообщает «И] (ru: Укр…
      Украинские беспилотники утром 20 августа атаковали Татарстан, сообщает «Интерфакс» со ссылкой на пресс-службу главы республики Рустама Минниханова.
  - (2026-08-20) Axios: США создали секретный маршрут в Ормузском проливе, через который перевозятся миллионы баррелей нефти | LEDE: Американские военные тайно создали судоходный коридор в Ормузском проливе,] (ru: Axi…
      Американские военные тайно создали судоходный коридор в Ормузском проливе, через который ежедневно перевозятся миллионы баррелей нефти. Об этом пишет Axios со ссылкой на двух американских чиновников.
  - (2026-08-20) Немецкое издание LTO: украинца, подозреваемого в подрыве «Северных потоков», арестовали на съемках фильма о «Северных потоках» | LEDE: Арест гражданина Украины Владимира Журавлева, подозрева] (ru: Нем…
      Арест гражданина Украины Владимира Журавлева, подозреваемого в причастности к взрывам на «Северных потоках», произошел в Хорватии во время съемок фильма, посвященного этой диверсии. Об этом пишет немецкое издание LTO.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 281 new of 632 total
  - (2026-08-20) [California] Governor Newsom announces appointments 8.19.26
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/SEO-Thumbnail-Template-2.0-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="Blue background with a white ci…
  - (2026-08-19) [California] As school begins, California launches universal Transitional Kindergarten, free meals for EVERY student and historic supports for kids
      Source
  - (2026-08-19) [California] Las ciudades penitenciarias de California buscan desesperadamente nuevos empleos tras los cierres: ‘Nadie vendrá a salvarnos’
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/041026-Susanville-LV-CM-05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-08-19) [California] Los incendios forestales se propagan por las carreteras. La administración Trump quiere construir más en áreas protegidas
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/080425-Gifford-Fire-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-08-19) [California] Exclusive records show California Forever’s intense lobbying
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/02/021624-California-Forever-LE-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-08-19) [California] Five California propositions ask the same question: Who should pay billions in taxes?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/070325-Luxury-Homes-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### Chinese Internal News — 243 new of 298 total
  - (2026-08-19) Chinese Robot-Maker Unitree Soars 629% in Shanghai Debut - Caixin Global
      Chinese Robot-Maker Unitree Soars 629% in Shanghai Debut Caixin Global
  - (2026-08-18) China’s Green Energy Exports Jump in July as EV Shipments Surge - Caixin Global
      China’s Green Energy Exports Jump in July as EV Shipments Surge Caixin Global
  - (2026-08-18) China to Let Mainland Insurers Buy Hong Kong ETFs Through Stock Connect - Caixin Global
      China to Let Mainland Insurers Buy Hong Kong ETFs Through Stock Connect Caixin Global
  - (2026-08-20) 王毅将访问韩国、印尼 - 人民网韩国频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFBseUs1VnFUT3pIdUNaMDNIdXdLaWdYXzVPVWktUzBqYm1LQnQ1SWhDTWRFQ2JhNkZfQnE3RXdHRy1OdlFxYklVWk5rYnEtY3pHdVBsQ2] (zh:…
      王毅将访问韩国、印尼 人民网韩国频道
  - (2026-08-20) 江苏宿迁： 走访问需护民安 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5SX2F0V0pqdmRoRjhuaGR5TzQ1SnlCWVI4UVdIaDVVdkhnWEZXcVZGaWFEQ2FMcC1nQWdkc3pkUFk5OFc1SDhjV0I3RnJ0aUt5RGNpN1] (zh:…
      江苏宿迁： 走访问需护民安 人民图片
  - (2026-08-19) 北京：2026 世界机器人大会开幕 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9ZWkJObXRubTZYYXlnU3F6MDZicUlTZzZuWm4xSGk1RUpkZ1NnalVjY3QxbjJlM0c0RF9fSndhVkZZYVBnb0hkSGY4N3FIbUljcE] (zh:…
      北京：2026 世界机器人大会开幕 人民图片

### Local News: St. Louis + Atlanta — 200 new of 235 total
  - (2026-08-20) [St. Louis] Where in the Lou? – 8/20/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-08-19) [St. Louis] The Magic House reimagines Trike Town with new Route 66 exhibit
      If your household has spent any amount of time watching Cars, you already know the appeal of Route 66: quirky roadside stops, wide-open-road adventure, and the idea that sometimes the best part of a road trip is everythi…
  - (2026-08-19) [St. Louis] Room to grow—Abode by Parklyn finds a bigger home in Webster Groves
      For anyone who has spent hours scrolling through home décor websites or wandering the endless aisles of an antique mall in search of the perfect piece, interior designer Danielle Kalish understands the struggle. Finding…
  - (2026-08-19) [St. Louis] Mikey Wehling bids a fond farewell to his family’s rural homestead on ‘Camp Scout Vol. 4’
      Mikey Wehling grins as he turns off Krenning Road and drives onto his family’s homestead in Beaufort, Missouri, a rural community of just over 1,100 residents. For four generations of Wehling’s family, the Franklin Count…
  - (2026-08-19) [St. Louis] Inside a rescued midcentury modern house museum in Belleville, Illinois
      In 1952, Terry and Thelma Blazier commissioned architect Charles E. King to design a new home for them in the Oak Knoll neighborhood in Belleville. The couple, who were empty nesters, loved to throw parties and designed…
  - (2026-08-19) [St. Louis] Where in Clayton 8/20/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…

### Ukraine Theater (total-war monitoring) — 200 new of 411 total
  - (2026-08-20) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-19) [FIRMS] thermal anomaly 46.839, 31.731 (FRP 4.2 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-19 1026Z, FRP 4.2 MW
  - (2026-08-19) [FIRMS] thermal anomaly 44.779, 23.104 (FRP 3.21 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-19 1026Z, FRP 3.21 MW
  - (2026-08-19) [FIRMS] thermal anomaly 47.660, 29.261 (FRP 26.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-19 1026Z, FRP 26.98 MW
  - (2026-08-19) [FIRMS] thermal anomaly 47.664, 29.259 (FRP 26.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-19 1026Z, FRP 26.98 MW
  - (2026-08-19) [FIRMS] thermal anomaly 47.663, 29.253 (FRP 26.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-19 1026Z, FRP 26.98 MW

### U.S. Weather + Severe / Climate Outlooks — 174 new of 177 total
  - (2026-08-20) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-20) [Moderate] Special Weather Statement: Special Weather Statement issued August 20 at 5:27AM EDT by NWS Jackson KY
      At 526 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from 9 miles southeast of Columbia to 6 miles west of Cabell to near Albany. Movement was east at 40 mph. HAZARD...Wind gusts up to 50…
  - (2026-08-20) [Moderate] Special Weather Statement: Special Weather Statement issued August 20 at 2:26AM MST by NWS Phoenix AZ
      At 226 AM MST, Doppler radar was tracking a strong thunderstorm over Camp Creek, or 17 miles north of Scottsdale, moving west at 10 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated. IMPA…
  - (2026-08-20) [Moderate] Special Weather Statement: Special Weather Statement issued August 20 at 4:26AM CDT by NWS Memphis TN
      At 425 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from 13 miles south of Hurricane Mills to 7 miles northwest of Linden to near Darden. Movement was southeast at 40 mph. HAZARD...Wind…
  - (2026-08-20) [Moderate] Special Weather Statement: Special Weather Statement issued August 20 at 2:20AM MST by NWS Phoenix AZ
      At 220 AM MST, Doppler radar was tracking a strong thunderstorm over Cotton Center, or 11 miles northeast of Gila Bend, moving southwest at 15 mph. HAZARD...Wind gusts of 50 to 55 mph and half inch hail. SOURCE...Radar i…
  - (2026-08-20) [Severe] Flash Flood Warning: Flash Flood Warning issued August 20 at 4:17AM CDT until August 20 at 8:15AM CDT by NWS Paducah KY
      FFWPAH The National Weather Service in Paducah has issued a * Flash Flood Warning for... Marshall County in western Kentucky... * Until 815 AM CDT. * At 417 AM CDT, Doppler radar indicated thunderstorms producing heavy r…

### State Legislative Action — 127 new of 139 total
  - (2026-08-19) [Alaska SB 226] An Act relating to the sale of homemade food.
      An Act relating to the sale of homemade food.
  - (2026-08-19) [Alaska SB 111] An Act relating to the diagnosis, maintenance, and repair of consumer products that use digital electronics to operate; adding an unlawful act to the Alaska Unfair Trade Practices and…
      An Act relating to the diagnosis, maintenance, and repair of consumer products that use digital electronics to operate; adding an unlawful act to the Alaska Unfair Trade Practices and Consumer Protection Act; and providi…
  - (2026-08-19) [Alaska SB 185] An Act relating to the business of insurance; relating to exceptions to prohibited rebates; relating to the powers of the director of the division of insurance; relating to prohibited…
      An Act relating to the business of insurance; relating to exceptions to prohibited rebates; relating to the powers of the director of the division of insurance; relating to prohibited practices in the advertisement of in…
  - (2026-08-19) [Alaska SB 196] An Act establishing a behavioral health crisis services surcharge; establishing the behavioral health crisis services fund; and providing for an effective date.
      An Act establishing a behavioral health crisis services surcharge; establishing the behavioral health crisis services fund; and providing for an effective date.
  - (2026-08-19) [Alaska SB 244] An Act relating to travel insurance.
      An Act relating to travel insurance.
  - (2026-08-19) [Alaska SB 150] An Act relating to a net metering program; relating to reduced rates in the form of credits for consumer-generators; establishing a net metering reimbursement fund; and providing for a…
      An Act relating to a net metering program; relating to reduced rates in the form of credits for consumer-generators; establishing a net metering reimbursement fund; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 68 new of 114 total
  - (2026-08-20) Ukraine Strikes Major Oil Refinery in Tatarstan as Drone Barrage Hits Russia
      Ukraine struck the TANЕCO oil refinery in Nizhnekamsk, Tatarstan, with Ukrainian-made FP-1 drones, according to defense company Fire Point. Russian monitoring channels reported at least 12 deaths. The overnight barrage a…
  - (2026-08-20) Russia Targets Ukraine-Moldova Border Checkpoint as Moscow Unleashes a Multi-Layered Attack
      Russia launched a massive overnight attack involving ballistic and cruise missiles and 168 Shahed-type drones. Ukraine’s Air Force said it intercepted most cruise missiles and drones, while Zelensky called for more Patri…
  - (2026-08-20) Ukraine May Have Left 2 Russian Frigates Unable to Launch Missiles After Novorossiysk Strike
      Satellite imagery reportedly shows serious damage to Russia’s Admiral Makarov and Admiral Essen after Ukraine’s Aug. 12 strike on Novorossiysk. Russian and Ukrainian OSINT sources claim both frigates suffered damage to t…
  - (2026-08-20) Fedorov vs Zelensky? Ukraine Entering a New Political Season?
      The Verkhovna Rada has appointed a defense minister, and, as expected, Mykhailo Fedorov was not returned to the post. He has recorded a video address criticizing the current system and, conroversially, calling for electi…
  - (2026-08-20) ‘People, Not Robots’: Ukraine’s Soldiers Justify Human Role Amid Drone Revolution
      Drones now destroy about 90% of targets in Ukraine, making traditional airborne assaults increasingly impractical. Yet newly trained paratroopers say demanding physical and psychological training remains vital because te…
  - (2026-08-20) Ukraine: A Dismissed Innovative Defense Minister Calls for Elections
      Fedorov has called for a secure way to hold elections during the war, warning democracy cannot depend on Russia. Critics see the move as a potential campaign launch and warn political turmoil could threaten Ukraine’s def…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-20) [TENG SONG-YUAN] Form 4 (Reporting)
      filed 2026-08-20 01:59 UTC · role: Reporting — Filed: 2026-08-19 AccNo: 0001683168-26-006619 Size: 5 KB
  - (2026-08-20) [NOCERA, INC.] Form 4 (Issuer)
      filed 2026-08-20 01:59 UTC · role: Issuer — Filed: 2026-08-19 AccNo: 0001683168-26-006619 Size: 5 KB
  - (2026-08-20) [JIN ANDY CHING-AN] Form 4 (Reporting)
      filed 2026-08-20 01:59 UTC · role: Reporting — Filed: 2026-08-19 AccNo: 0001683168-26-006618 Size: 5 KB
  - (2026-08-20) [NOCERA, INC.] Form 4 (Issuer)
      filed 2026-08-20 01:59 UTC · role: Issuer — Filed: 2026-08-19 AccNo: 0001683168-26-006618 Size: 5 KB
  - (2026-08-20) [Mazarakis John] Form 4 (Reporting)
      filed 2026-08-20 01:56 UTC · role: Reporting — Filed: 2026-08-19 AccNo: 0001193125-26-357420 Size: 7 KB
  - (2026-08-20) [Chicago Atlantic BDC, Inc.] Form 4 (Issuer)
      filed 2026-08-20 01:56 UTC · role: Issuer — Filed: 2026-08-19 AccNo: 0001193125-26-357420 Size: 7 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 56 total
  - (2026-08-20) [BleepingComputer] Microsoft says August Windows updates may cause gaming issues
      Microsoft is investigating a potential issue with the August 2026 updates that may prevent some games from launching or cause them to crash on affected Windows 11 systems. [...]
  - (2026-08-20) [BleepingComputer] OpenAI confirms ChatGPT is down as logins and signups fail
      ChatGPT is experiencing a major outage, and users are unable to sign in, create accounts, or load chats, including previous conversations. [...]
  - (2026-08-20) [The Hacker News] Elementor Pro Flaw Could Let Unauthenticated Attackers Upload PHP and Execute Code
      Cybersecurity researchers have disclosed details of a critical flaw in the Elementor Pro WordPress plugin that, if successfully exploited, could lead to remote code execution. The vulnerability, tracked as CVE-2026-32475…
  - (2026-08-20) [The Register] SparkyLinux 8.4 rekindles support for 32-bit PCs
      Debian 13 derivative offers minimal x86 images and lets CDE ride again
  - (2026-08-20) [The Register] AI agent suggested installing a malware package. Engineer almost took its advice
      Fortunately, the company had a policy of checking source code on GitHub first
  - (2026-08-20) [The Register] China marches towards re-usable rockets with successful first-stage landing
      Red alert for rivals as LandSpace nails it after December disaster

### Court opinions of consequence (federal & state) — 32 new of 60 total
  - (2026-08-19) U.S. Court of Appeals, 5th Cir.: Vertigo Vapor, L.L.C. v. FDA
  - (2026-08-19) U.S. Court of Appeals, 5th Cir.: Hamm v. Ochsner-Acadia
  - (2026-08-19) Delaware Supreme Court: Penn v. State
  - (2026-08-19) U.S. Court of Appeals, 1st Cir.: 5-Star General Store v. American Express Company
  - (2026-08-19) U.S. Court of Appeals, 1st Cir.: In Re: Apellis Pharm., Inc. Securities Litigation v.
  - (2026-08-19) U.S. Court of Appeals, 1st Cir.: Nicholls v. Veolia Water Contract Operations USA, Inc.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-20) JAF9XT (Bulgaria)
      icao24: 4520d0 · position: (48.9991, 6.0256) · alt: 2689m · 492km/h
  - (2026-08-20) GAF154 (Germany)
      icao24: 3f727c · position: (59.2663, 10.2622) · alt: 10355m · 753km/h
  - (2026-08-20) CFC2979 (Canada)
      icao24: c2b5b7 · position: (42.6086, -1.419) · alt: 8534m · 659km/h
  - (2026-08-20) RCH694 (United States)
      icao24: ae7797 · position: (46.2898, 4.9362) · alt: 8526m · 603km/h
  - (2026-08-20) JAF7CB (Belgium)
      icao24: 44d1a6 · position: (45.3403, -0.4946) · alt: 10363m · 867km/h
  - (2026-08-20) JAF29J (Belgium)
      icao24: 44d1a7 · position: (41.2784, 19.252) · alt: 10972m · 851km/h

### Paper Trading Scorecard — 27 new of 140 total
  - (2026-08-20) [Polymarket] US announces end of Iranian blockade by September 30, 2026?
      On July 13, 2026, Trump announced the United States would reinstate its naval blockade of Iran, targeting Iranian ships and customers. This market will resolve to “Yes” if the United States government, or an authorized r…
  - (2026-08-20) [Polymarket] Will Radu Burnete be the next Prime Minister of Romania?
      This market will resolve to the next individual who officially assumes the office of Prime Minister of Romania by December 31, 2027, 11:59 PM ET. To count for resolution, the individual must be formally appointed by the…
  - (2026-08-20) [Polymarket] Will Donald Trump win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-08-20) [Kalshi] Who will be the next Prime Minister of the United Kingdom?
      Before Jan 1, 2035
  - (2026-08-20) [Manifold] Will Ghent fire Nathan Cofnas before 2028?
  - (2026-08-20) [Manifold] Will at least 3 American cities reach a population of 1 million for the first time before 2030?

### U.S. Federal Action — 24 new of 24 total
  - (2026-08-20) Airworthiness Directives; The Boeing Company Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for certain The Boeing Company Model 787-8 airplanes. This proposed AD was prompted by a report that large forward cargo door (LFCD) split frames may have been…
  - (2026-08-20) Small Business Size Standards
      The U.S. Small Business Administration (SBA or the Agency) is proposing new size standards for 338 industry groups and industries. The new size standards are designed to better reflect the nature of the markets in which…
  - (2026-08-20) Small Business Size Standards: Revised Size Standards Methodology
      The U.S. Small Business Administration (SBA or Agency) advises the public that it has revised its white paper explaining how it establishes, reviews, and modifies small business size standards. The revised white paper pr…
  - (2026-08-20) Determination of Target Normal Cost and Funding Target for Single-Employer Defined Benefit Plans
      This document contains proposed regulations that would modify rules in the existing regulations relating to the minimum funding requirement applicable to single-employer defined benefit pension plans. The modifications i…
  - (2026-08-20) Application of Section 250(b)(3)(A)(i)(VII) to Sales or Other Dispositions of Property
      This document contains proposed regulations under section 250 of the Internal Revenue Code (Code) that provide guidance on certain income of a domestic corporation that is excluded in the determination of deduction eligi…
  - (2026-08-20) Special Local Regulation; North East, North East, MD
      The Coast Guard is establishing a temporary special local regulation (SLR) for certain waters of the North East River, near North East, MD. This action is necessary to provide for the safety of life on these navigable wa…

### USGS earthquakes (M4.5+, past day) — 21 new of 21 total
  - (2026-08-19) M 5.8 - 25 km NNE of Ruteng, Indonesia
      M5.8 · 25 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-20) M 5.7 - 32 km NNE of Ruteng, Indonesia
      M5.7 · 32 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-19) M 5.5 - 52 km NNE of Ruteng, Indonesia
      M5.5 · 52 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-19) M 5.4 - 215 km E of Levuka, Fiji
      M5.4 · 215 km E of Levuka, Fiji · depth 556.753 km
  - (2026-08-19) M 5.4 - 134 km S of Severo-Kuril’sk, Russia
      M5.4 · 134 km S of Severo-Kuril’sk, Russia · depth 41.176 km
  - (2026-08-19) M 5.2 - 33 km N of Ruteng, Indonesia
      M5.2 · 33 km N of Ruteng, Indonesia · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 92 total
  - (2026-08-20) [BIS Entity List] page checksum 71c5c4961d51
      Page content hash: 71c5c4961d51. Compare with prior day's hash to detect updates.
  - (2026-08-20) [USASpending] $42,774,168,231 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-08-20) [USASpending] $30,691,741,338 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-08-20) [USASpending] $19,868,865,110 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…
  - (2026-08-20) [USASpending] $17,457,615,881 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy. Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-08-20) [USASpending] $14,933,400,228 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE
      Agency: Department of Energy. Description: OPERATION AND MAINTENANCE LINEAR ACCELLERATOR

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-08-20) Dota 2: TEAM VISION vs BoomBoys - Game 2 Winner
      yes price: 0% · 24h volume: $2,395,713 · resolves 2026-08-20
  - (2026-08-20) LoL: Dplus KIA vs Hanwha Life Esports - Game 1 Winner
      yes price: 0% · 24h volume: $1,229,052 · resolves 2026-08-20
  - (2026-08-20) LoL: Dplus KIA vs Hanwha Life Esports (BO3) - LCK Round 3-4 Legend Group
      yes price: 16% · 24h volume: $1,119,056 · resolves 2026-08-20
  - (2026-08-20) Will the Fed decrease interest rates by 25 bps after the September 2026 meeting?
      yes price: 1% · 24h volume: $1,049,485 · resolves 2026-09-16
  - (2026-08-20) LoL: Dplus KIA vs Hanwha Life Esports - Game 2 Winner
      yes price: 32% · 24h volume: $907,146 · resolves 2026-08-20
  - (2026-08-20) Will there be no change in Fed interest rates after the September 2026 meeting?
      yes price: 72% · 24h volume: $510,788 · resolves 2026-09-16

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-20) [Marginal Revolution] My excellent Conversation with Luke Burgis
      Here is the audio, video, and transcript. Here is the episode summary: Luke Burgis left Wall Street after two years, founded a few successful companies in his twenties, then walked away to spend three years in a Roman se…
  - (2026-08-19) [Marginal Revolution] Declining Occupations and Career Outcomes in the United States
      This strikes me as somewhat less of a problem than I might have thought: We study long-run career consequences of initial employment in an occupation that subsequently declines. Linking the 2000 Decennial Census to US ad…
  - (2026-08-19) [Marginal Revolution] Wednesday assorted links
      1. Human lawyer for AI agents. And more. Come on, all you agents, you need a guy like this! 2. Saloni’s TED talk on medical cures. 3. Has there been a collapse in British pride? 4. Those new service sector jobs? (solving…
  - (2026-08-19) [Conversable Economist] “Syntax often breaks down just at the point where a new or significant meaning is beginning to break out”
      When writing feels hard, perhaps it is because you are on the cusp of saying something significant or interesting? The thought is oddly comforting to me. Donald Murray originally described this connection in his essay “M…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 34 total
  - (2026-08-20) MOVER ▼ Steve Ballmer — $149.26B ($-0.23B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-08-20) MOVER ▼ Carlos Slim Helu & family — $123.21B ($-0.06B since yesterday)
      Mexico · Telecom · source: Telecom

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 10 total
  - (2026-08-19) CVE-2026-64849 · MLflow MLflow: MLflow Server-Side Request Forgery Vulnerability
      vendor: MLflow · product: MLflow · CISA remediation by 2026-09-02

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=20, 14d-median=20; carrying terms: certain, state, national, action, proposes, program, provide, proposed, establish, proposing, final, existing
- state_bills: today=139, 7d-median=129, 14d-median=129; carrying terms: private, relating, establishes, general, county, report, registration, practice, administration, forth, executive, residential
- state_news: today=632, 7d-median=585, 14d-median=531; carrying terms: private, lawmakers, market, january, little, search, passed, wednesday, forbidden, according, advocates, mother
- local_news: today=235, 7d-median=216, 14d-median=222; carrying terms: mother, august, media, shooting, flock, month, crash, atlanta, years, inside, house, falcons
- foreign_news: today=1041, 7d-median=978, 14d-median=979; carrying terms: suspended, private, beneath, drivers, syria, peace, stunt, partly, natural, starting, mobilized, trying
- chinese_internal: today=298, 7d-median=280, 14d-median=270; carrying terms: cbmia, cbmizkfvx, cbmibefvx, color, cbmizefvx, cbmickfvx, politics, articles, cbmixkfvx, chinese, lxtfb, target
- russian_internal: today=1116, 7d-median=1040, 14d-median=1024; carrying terms: novaya, times, error, target, world, europe, reuters, istories, client, russian, guardian, title
- ukrainian_internal: today=114, 7d-median=107, 14d-median=106; carrying terms: region, refinery, general, drones, incident, forces, forbidden, trump, https, august, against, comes
- ukraine_theater: today=411, 7d-median=1151, 14d-median=944; carrying terms: lrgjwvwfovwvbugjrnw, jctexhsu, zrqjbptzd, vyedbidjhjcldnbxgxwkzjq, overview, zzdmthlrmvjlwvl, uxsudorgvdbdlieekzrhczqvzvskw, cuxqyjblyufluld, rfjyckzranluc, mmxtt, kuwlxx, rumuhlzuxfoev
- paper_bets: today=140, 7d-median=141, 14d-median=138; carrying terms: headline, otherwise, russell, nomination, resolve, zohran, district, drought, market, world, manifold, koivun
- weather: today=177, 7d-median=177, 14d-median=172; carrying terms: potential, evening, humidity, region, gusty, expected, deeper, outlook, extreme, little, portion, develop
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, headline, labor, cpilfesl, commodities, pcepilfe, jtsjol, sheet, crude, vixcls, dcoilwtico, walcl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, natural, commodities, russell, crude, agriculture, yield, corporate, futures, proxy, crypto, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=92, 7d-median=93, 14d-median=96; carrying terms: groups, prior, controlled, weapons, btdyc, mtjwwxz, international, protests, management, chemical, region, facilitate
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, unauthorized, quantitative, quiver, error, client, https, httperror, quiverquant
- billionaires: today=34, 7d-median=34, 14d-median=34; carrying terms: retail, family, france, bernard, commodities, microsoft, velasco, sergey, alice, nasdaq, discount, gautam
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, state, company, appeals, court, group, supreme, trust, trade, blanche, village, america
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, capital, management, holdings
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, david, brown, sherrod, disbursements, cycle, jonathan, ossoff, cortez, platner, cooper, graham
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, japan, surge
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, russian, themes, spanish, indonesian, chinese, trump, greek, german, russia, sanctions, vietnamese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, ground, kingdom, germany, canada, bulgaria, netherlands, spain
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: documented, bivalent, prior, recalls, returning, cambodia, cvdpv, evolve, internationally, international, parganas, associated
- cisa_kev: today=10, 7d-median=9, 14d-median=9; carrying terms: injection, remediation, cisco, progress, vulnerability, loadmaster, secure, firewall, authentication, command, product, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=277, 14d-median=277; carrying terms: mongolia, tanzania, dolphin, north, forestfire, cyclone, france, cambodia, forest, macedonia, islands, brazil
- usgs_quakes: today=21, 7d-median=21, 14d-median=18; carrying terms: indonesia, depth, russia, vanuatu, ruteng, philippines, kuril, levuka, severo
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: traffic, volume, hormuz, league, august, normal, price, interest, strait, championship, donetsk, september
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, https, revolution, economist, marginal, class, marginalrevolution, seems, social, links, assorted, possible
- tech_news: today=56, 7d-median=58, 14d-median=57; carrying terms: download, navigate, september, spectrum, computer, according, https, hackers, technica, problems, already, companies
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: treasury, robin, houchin, bennie, brown, russell, brittany, warnock, randy, angie, vance, jonathan
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, decision, paper, placed, either, claude, unavailable, module, consensus, markets, today, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*