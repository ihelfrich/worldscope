# WORLDSCOPE morning brief — 2026-07-30

## Headline
2623 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (565) · Russian Internal News (state + in-exile) (475) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (323) · Chinese Internal News (274) · U.S. Weather + Severe / Climate Outlooks (126) · Local News: St. Louis + Atlanta (110) · State-Level News (76) · GDELT GKG — themes / entities / watch areas (74) · Government Action: Sanctions + Procurement + Foreign Agents (50) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (33)

## What changed today
### International News + Multilateral Institutions — 565 new of 1020 total
  - (2026-07-30) [Global] Photos: Zelenskyy urges ‘protection of life’ amid deadly Russian attacks
      Russia launches more than 70 missiles and 280 drones in a major attack on Ukraine that kills at least 14 people.
  - (2026-07-30) [Global] Protest group says 30 dead in Pakistan-administered Kashmir vote unrest
      Deadly clashes reported in Pakistan-administered Kashmir amid first round of voting for regional elections on July 27.
  - (2026-07-30) [Global] Saudi Arabia confirmed to host Asian Champions League Elite finals
      Saudi Arabia has hosted the last two Asian Champions League Elite finals and has now been confirmed for the next three.
  - (2026-07-30) [Global] Infantino insists FIFA’s World Cup plan is proposal and not ‘obligation’
      Football governing bodies hit out at plans to sell World Cup stakes, as FIFA insist proposal is not an 'obligation'.
  - (2026-07-30) [Global] US strikes cause extensive damage on Iran’s Qeshm Island
      Video from Iran's Qeshm Island shows widespread damage following US attacks.
  - (2026-07-30) [Global] Is Israel repeating the Crusaders’ fatal mistake?
      Deja Vu explores why the Crusader kingdom fell and asks: could Israel be next?

### Russian Internal News (state + in-exile) — 475 new of 1104 total
  - (2026-07-30) Война. 1618-й день. Россия нанесла массированный удар по Украине: восемь погибших, десятки раненых. Украинские беспилотники за одно утро атаковали три склада Wildberries | LEDE: «Медуза» с 2] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-30) В Ленинградской области из-за атак на склад Wildberries свои товары потеряли около 1500 предпринимателей. Губернатор пообещал им поддержку | LEDE: В Ленинградской области около полутора тыся] (ru: В Л…
      В Ленинградской области около полутора тысяч продавцов Wildberries потеряли свои товары из-за пожара на складе после атак украинских беспилотников, заявил глава региона Александр Дрозденко.
  - (2026-07-30) Украинские дроны атаковали третий склад Wildberries за день. Теперь — в Пермском крае | LEDE: Украинские беспилотники утром 30 июля атаковали склад Wildberries в Пермском крае. Первыми об эт] (ru: Укр…
      Украинские беспилотники утром 30 июля атаковали склад Wildberries в Пермском крае. Первыми об этом сообщили украинские телеграм-каналы, в частности, Exilenova+, который опубликовал фотографии и видео пожара.
  - (2026-07-30) «Это мировоззренческий конфликт». Бывший министр обороны Украины Федоров заявил, что у него не было личного конфликта с бывшим главкомом ВСУ Сырским | LEDE: Бывший министр обороны Украины Ми] (ru: «Эт…
      Бывший министр обороны Украины Михаил Федоров рассказал в большом интервью «Украинской правде», что у него не было личного конфликта с бывшим главнокомандующим ВСУ Александром Сырским.
  - (2026-07-30) «Коммерсант»: из Генпрокуратуры уволили «главного специалиста» по конфискации активов. Он готовил иски об изъятиях Домодедово и «Макфы» | LEDE: Из Генпрокуратуры уволили начальника главного ] (ru: «Ко…
      Из Генпрокуратуры уволили начальника главного гражданско-судебного управления Сергея Бочкарева, пишет «Коммерсант» со ссылкой на несколько источников. Газета называет его «главным специалистом» по изъятию активов бизнеса…
  - (2026-07-30) Владельцев иностранных сайтов хотят обязать авторизовывать пользователей в России только по номеру телефона | LEDE: Минцифры разработало новые поправки, которые могут обязать владельцев инос] (ru: Вла…
      Минцифры разработало новые поправки, которые могут обязать владельцев иностранных сайтов и приложений авторизовывать пользователей в России только по номеру телефона, пишут «Ведомости» со ссылкой на документ.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 323 new of 552 total
  - (2026-07-30) [FIRMS] thermal anomaly 52.807, 32.224 (FRP 0.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 0.85 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.849, 29.990 (FRP 1.09 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 1.09 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.846, 29.989 (FRP 5.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 5.08 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.304, 32.650 (FRP 0.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 0.28 MW
  - (2026-07-30) [FIRMS] thermal anomaly 51.893, 29.343 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 1.95 MW
  - (2026-07-30) [FIRMS] thermal anomaly 51.890, 29.336 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 1.95 MW

### Chinese Internal News — 274 new of 301 total
  - (2026-07-29) 责编：任成琦 金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxPM0xuUFNVTmJUbXVwXzJHSng4UlVjZWZHVHZBT1B0cnlGcWl2UjdzLXZPLUl2dmVoS1o1bU1oOWF2S3kySjlBW] (zh:…
      责编：任成琦 金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-07-28) 国别频道 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE5uajFGZkNRSDBqNGd4LTFPVFExVlFqelk5MnRpMXNZa19sbkQ2WEJ1bXc0STFNWG9jcjdlclJKTGFsTmY4ZEhUS2xOZVcybUhycHc0dlAzdml0TG4w] (zh:…
      国别频道 人民网
  - (2026-07-29) 通苏嘉甬高铁跨张家港河斜拉桥合龙 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE9sZXl5bHF2MTU3dkhtMlBfNldJcEtYME9PZE1KY0RnLUFsV1RJWW1GLXRneE1sTzliMXhIRU1QMDBXX0ZzZk92UGZSSDBhMlV] (zh:…
      通苏嘉甬高铁跨张家港河斜拉桥合龙 人民网-图片频道
  - (2026-07-28) 唐山大地震50周年：纪念墙下致哀思【6】 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFBpY1BfZV81ampoZG9JeFRoaDRGcEJuSl9idnN6YlpWQkJtVDFoYkU2WGlTeDlXd0dTbVpCNVphNUVkV2ZzakR6VU1tSTF] (zh:…
      唐山大地震50周年：纪念墙下致哀思【6】 人民网-图片频道
  - (2026-07-28) 重要评论 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE14MVNFaWN4T2paOTZRYUVLQnRGWXc4WXJabGxTcXNnOWFXcU05Wm9FczQ0c0tadzRCNUhBaUROWVR2ejk4eFptRlcxZXdhWWhyQi1QM21Vam5] (zh:…
      重要评论 中国共产党新闻网
  - (2026-07-29) 劳动者之歌——弧光下的“攻坚手” - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBSWlVUSnRkQ1dPYnItb2plN2w1WFc5ZmNHWEt0cElLX2FWVk4tdUo1eHVLb2pwbTMwczlfV2VKQjBZMHkwUTdVRS1mWFhvWHllZmJB] (zh:…
      劳动者之歌——弧光下的“攻坚手” 人民网

### U.S. Weather + Severe / Climate Outlooks — 126 new of 159 total
  - (2026-07-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-30) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 30 at 2:26AM PDT until August 3 at 11:00PM PDT by NWS Hanford CA
      * WHAT...Dangerously hot conditions with several days of Major to Extreme heat risk. * WHERE...Indian Wells Valley, Mojave Desert, and Mojave Desert Slopes. * WHEN...From 11 AM this morning to 11 PM PDT Monday. * IMPACTS…
  - (2026-07-30) [Severe] Extreme Heat Watch: Extreme Heat Watch issued July 30 at 3:24AM MDT until August 2 at 9:00PM MDT by NWS Salt Lake City UT
      * WHAT...Dangerously hot conditions with temperatures up to 105 possible and overnight lows in the low to mid-70s. * WHERE...Northern Wasatch Front, Salt Lake Valley, Tooele and Rush Valleys, Utah Valley, and Western Uin…
  - (2026-07-30) [Moderate] Heat Advisory: Heat Advisory issued July 30 at 3:24AM MDT until August 2 at 9:00PM MDT by NWS Salt Lake City UT
      * WHAT...Temperatures up to 106 expected, with warm overnight lows in the upper 60s to low 70s offering little relief. * WHERE...Castle Country, Eastern Juab/Millard Counties, San Rafael Swell, and Great Salt Lake Desert…
  - (2026-07-30) [Moderate] Heat Advisory: Heat Advisory issued July 30 at 3:24AM MDT until August 2 at 9:00PM MDT by NWS Salt Lake City UT
      * WHAT...Temperatures up to 105 expected. Overnight temperatures are expected to recover into the mid- to upper-60s, providing temporary relief from daytime heat. * WHERE...Western Millard and Juab Counties and Southwest…
  - (2026-07-30) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 30 at 3:24AM MDT until August 2 at 9:00PM MDT by NWS Salt Lake City UT
      * WHAT...Dangerously hot conditions with temperatures up to 107 expected. Warm overnight lows in the upper 60s to mid 70s will offer little relief. * WHERE...Capitol Reef National Park and Vicinity, Glen Canyon Recreatio…

### Local News: St. Louis + Atlanta — 110 new of 227 total
  - (2026-07-29) [St. Louis] St. Louis County health officials ask patients for help in cyclospora parasite investigations
  - (2026-07-30) [St. Louis] See the July 30, 1926, front page: Bender on stand denies trying to free Rutherford
      Headlines from the July 30, 1926, front page include: Nassau, beauty spot of Bahamas, hard hit by storm.
  - (2026-07-30) [St. Louis] 53 years: From Rich Stadium to the Ralph and beyond
      The Buffalo Bills have enthralled and enraged fans on this playing field for 53 years, first when it was called Rich Stadium, then from 1998 to 2015 as Ralph Wilson Stadium, followed by New Era Field from 2016 to 2020.…
  - (2026-07-30) [St. Louis] Missouri sees drop in food stamp use one year after 'Big Beautiful Bill'
      Plus: Have you seen this kangaroo?
  - (2026-07-30) [St. Louis] Heitman, Edgar
      Heitman, Edgar Roy Jr. 'Ed'
  - (2026-07-30) [St. Louis] Strifler, Paul
      Strifler, Paul J.

### State-Level News — 76 new of 786 total
  - (2026-07-30) [Alaska] Alaska National Guard Day 2026
      WHEREAS, since before World War II, the Alaska National Guard has acted as a first line of defense for the United States of America; and WHEREAS, the Alaska National Guard serves our Nation when called by federal service…
  - (2026-07-30) [California] Governor Newsom deploys elite wildfire team to Washington State as western fires surge
      Source
  - (2026-07-30) [Connecticut] Thank you, Hartford, for letting me teach. Now save your public schools
      <img width="1024" height="681" src="https://ctmirror.org/wp-content/uploads/2026/07/teachers-demonstrate-hartford-1024x681.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-07-30) [Connecticut] We all can act for CT’s greater good
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/AMERICA-LIBRARY-0701-JL-020-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" lo…
  - (2026-07-30) [Connecticut] The U.S.-imposed fuel crisis in Cuba is inhumane and immoral
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/07/ap-cuba-blackout.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset=…
  - (2026-07-30) [Connecticut] 1st Congressional District candidates square off in final debate
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/SRR_9255-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" s…

### GDELT GKG — themes / entities / watch areas — 74 new of 74 total
  - (2026-07-30) [Russia oil sanctions perimeter · themes] Як розігріти вже варену кукурудзу , щоб вона була смачною – лайфхаки
      unian.ua · Ukrainian · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · themes] US unleashes heavy wave of strikes against Iran
      goulburnpost.com.au · English · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · themes] Konteynerin altında kalan işçi yaşamını yitirdi
      bursadabugun.com · Turkish · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · themes] Масована атака 30 липня РФ вбила батьків і дітей багатодітної родини в Радушному Фокус
      focus.ua · Ukrainian · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · themes] Chuyên gia thuế : Việt Nam lập kỷ lục với 2 , 65 triệu tỷ đồng , một khoản thu bất thường xuất hiện trong tổng thu ngân sách cao nhất lịch sử
      cafef.vn · Vietnamese · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · themes] Infosan : Peste un milion de români cu diabet sunt expuși riscului de a - și pierde vederea din cauza retinopatiei diabetice
      agerpres.ro · Romanian · tone NA

### Government Action: Sanctions + Procurement + Foreign Agents — 50 new of 122 total
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-07-27) [OFAC] Sanctions List Removals; Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Sanctions List Removals; Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses - Office of Foreign Assets Cont…
      Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-30) [Ashiya Mona] Form 4 (Reporting)
      filed 2026-07-30 01:36 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001104659-26-088371 Size: 6 KB
  - (2026-07-30) [Yarrow Bioscience, Inc.] Form 4 (Issuer)
      filed 2026-07-30 01:36 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001104659-26-088371 Size: 6 KB
  - (2026-07-30) [Sheena Jonathan] Form 4 (Reporting)
      filed 2026-07-30 01:35 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001646649-26-000025 Size: 8 KB
  - (2026-07-30) [Natera, Inc.] Form 4 (Issuer)
      filed 2026-07-30 01:35 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001646649-26-000025 Size: 8 KB
  - (2026-07-30) [Rabinowitz Matthew] Form 4 (Reporting)
      filed 2026-07-30 01:35 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001646382-26-000014 Size: 5 KB
  - (2026-07-30) [Natera, Inc.] Form 4 (Issuer)
      filed 2026-07-30 01:35 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001646382-26-000014 Size: 5 KB

### Ukrainian Internal News (national + local Kyiv) — 33 new of 119 total
  - (2026-07-30) Усе свідчить про те, що в Польщі впала російська ракета Х-101 – Туск | LEDE: Премʼєр-міністр Польщі Дональд Туск заявив, що наразі все вказує на те, що уночі в Люблінському воєводстві впала рос] (uk:…
      Премʼєр-міністр Польщі Дональд Туск заявив, що наразі все вказує на те, що уночі в Люблінському воєводстві впала російська крилата ракета Х-101.
  - (2026-07-30) На Одещині затримали посадовця ТЦК, який за 500 л дизпалива обіцяв зняти з розшуку | LEDE: На Одещині правоохоронці затримали начальника одного з відділів територіального центру комплектування ] (uk:…
      На Одещині правоохоронці затримали начальника одного з відділів територіального центру комплектування та соціальної підтримки, якого підозрюють у вимаганні талонів на 500 літрів дизельного пального за зняття військовозоб…
  - (2026-07-30) Уночі в метро Києва укривалися понад 56 тисяч людей – у підземці спростували обмеження доступу | LEDE: Під час повітряної тривоги всі станції метро Києва були відкриті як укриття — КМДА] (uk: Уночі в…
      Під час повітряної тривоги всі станції метро Києва були відкриті як укриття — КМДА
  - (2026-07-30) Рада ЄС внесла зміни у план реформ України, необхідних для виділення 8,3 млрд євро | LEDE: 30 липня Рада ЄС схвалила зміни до механізму підтримки України Ukraine Facility та пов'язаного з ним "] (uk:…
      30 липня Рада ЄС схвалила зміни до механізму підтримки України Ukraine Facility та пов'язаного з ним "Плану України" (Ukraine Plan), що визначає необхідні для отримання фінансування реформи.
  - (2026-07-30) У Польщі показали момент падіння об’єкта, який Україна називає ракетою Х-101 | LEDE: Польський портал оприлюднив запис із камери спостереження, на якому зафіксовано падіння об'єкта, що вночі 30] (uk:…
      Польський портал оприлюднив запис із камери спостереження, на якому зафіксовано падіння об'єкта, що вночі 30 липня порушив повітряний простір країни та впав у Люблінському воєводстві. Українська сторона стверджує, що це…
  - (2026-07-30) У Кривому Розі оголосили день жалоби | LEDE: У Кривому Розі 31 липня день жалоби: загинули шестеро людей, серед них троє дітей, внаслідок російського удару.] (uk: У Кривому Розі оголосили день жалоби)
      У Кривому Розі 31 липня день жалоби: загинули шестеро людей, серед них троє дітей, внаслідок російського удару.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-07-30) GAF111 (Germany)
      icao24: 3f7588 · position: (54.7009, -2.3042) · alt: 9745m · 681km/h
  - (2026-07-30) PUMA52 (Slovenia)
      icao24: 506e19 · position: (45.8983, 15.4167) · alt: 548m · 172km/h
  - (2026-07-30) GAF191 (Germany)
      icao24: 3f727c · position: (49.6741, 9.8419) · alt: 2743m · 459km/h
  - (2026-07-30) CNA11 (Spain)
      icao24: 3475ca · position: (27.7977, -15.9762) · alt: 579m · 163km/h
  - (2026-07-30) CNA22 (Spain)
      icao24: 3475cb · position: (27.7969, -15.7968) · alt: 883m · 161km/h
  - (2026-07-30) SAMU59 (France)
      icao24: 39b5d1 · position: (50.4745, 3.3266) · alt: 297m · 238km/h

### U.S. Federal Action — 26 new of 26 total
  - (2026-07-30) Airworthiness Directives; Pilatus Aircraft Ltd. Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Pilatus Aircraft Ltd. (Pilatus) Model PC-12/47E airplanes. This AD was prompted by a report that, during an engine start on the ground, the airplane batt…
  - (2026-07-30) Airworthiness Directives; Stemme GmbH Gliders
      The FAA is adopting a new airworthiness directive (AD) for all Stemme GmbH (Stemme) Model Stemme S 12 gliders. This AD was prompted by reports of fuel leaking around certain copper sealing rings within the fuel system. T…
  - (2026-07-30) Civil Money Penalty for Actions in Contempt of an Immigration Judge's Proper Exercise of Authority
      This notice of proposed rulemaking ("NPRM") would implement a provision of the Immigration and Nationality Act ("INA" or "the Act") that authorizes Immigration Judges, under regulations prescribed by the Attorney General…
  - (2026-07-30) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A330-200 and A330-300 series airplanes modified by a certain supplemental type certificate (STC). This AD was prompted by a finding that…
  - (2026-07-30) Exchange Visitor Program-Termination of Program Participation, Extension of Program and Reinstatement to Valid Program Status
      The Department of State's (Department's) Bureau of Educational and Cultural Affairs administers the Exchange Visitor Program, as set forth at 22 CFR part 62, wherein exchange visitors on educational and cultural exchange…
  - (2026-07-30) Medicare Program; Updates to the Master List of Items Potentially Subject to Face-to-Face Encounter and Written Order Prior to Delivery and/or Prior Authorization Requirements; Updates to the Required…
      This document announces updates to the Healthcare Common Procedure Coding System (HCPCS) codes on the Master List. It also announces updates to the HCPCS codes on the Required Face-to-Face Encounter and Written Order Pri…

### Paper Trading Scorecard — 12 new of 140 total
  - (2026-07-30) [Polymarket] Will the Fed increase interest rates by 25 bps after the October 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-07-30) [Polymarket] Will Elon Musk post 500+ tweets from July 24 to July 31, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 24 12:00 PM ET to July 31, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-30) [Manifold] Will YonKaGor make a cover of "Isn't She Lovely" by EOY 2028?
  - (2026-07-30) [Manifold] Will a frontier model exfiltrate its own weights by EoY 2028?
  - (2026-07-30) [Manifold] Will Seb Krier's Antichrist Meme tweet still be up on August 1st?
  - (2026-07-30) [Manifold] Will I delete my Manifold account by October? (Again)

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-30) [China] Rising costs weigh on Japan summer outbound travel
      ttgasia.com · English
  - (2026-07-30) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-30) [China] Kina : „ Lista pokrivene opreme američkog FCC - a predstavlja širenje diskriminacije protiv kineskih proizvoda
      serbian.cri.cn · English
  - (2026-07-30) [China] Broj poginulih u zemljotresu u Kumamotu porastao na 30 , saopštila japanska premijerka
      serbian.cri.cn · English
  - (2026-07-30) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-30) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 55 total
  - (2026-07-30) [The Hacker News] Russian Hackers Exploit Microsoft OWA Flaw to Keep Mailbox Access After Credential Rotation
      The Russian threat actors recently linked to the exploitation of a now-patched vulnerability in Zimbra have been observed exploiting another vulnerability, this time in Microsoft Outlook Web Access (OWA), to target U.S.…
  - (2026-07-30) [The Hacker News] FCC Blocks New Foreign-Produced Robots and Power Inverters Over Cyber Risks
      The Federal Communications Commission (FCC) added foreign-produced mobile robots and networked power inverters to its Covered List on July 28. The move generally prevents new models from receiving the equipment authoriza…
  - (2026-07-30) [The Hacker News] Amazon Links Debug and Chalk npm Hijack to North Korea’s Sapphire Sleet
      Amazon has tied the September 2025 hijack of the npm packages debug and chalk to North Korea. For ten months, the incident sat in the public record as crypto theft: a maintainer phished through a lookalike npm domain and…
  - (2026-07-30) [The Hacker News] Cisco FMC Zero-Day Actively Exploited, Static Credentials Could Expose Sensitive Data
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Wednesday added a newly disclosed security flaw impacting Cisco Secure Firewall Management Center (FMC) Software to its Known Exploited Vulnerabilities…
  - (2026-07-30) [The Register] 30 years ago, AT&T gave Internet Explorer the default advantage
      Netscape still ruled the browser market, but Microsoft had Windows 95, WorldNet, and a very valuable foothold
  - (2026-07-30) [The Register] Brighton gig screen goes One Step Beyond with an update pop-up
      Install now or remind me later? Neither belongs in the House of Fun

### USGS earthquakes (M4.5+, past day) — 10 new of 25 total
  - (2026-07-30) M 5.8 - Kermadec Islands region
      M5.8 · Kermadec Islands region · depth 10 km
  - (2026-07-30) M 5.4 - 201 km W of Abepura, Indonesia
      M5.4 · 201 km W of Abepura, Indonesia · depth 35 km
  - (2026-07-30) M 5.3 - 217 km SE of Kokopo, Papua New Guinea
      M5.3 · 217 km SE of Kokopo, Papua New Guinea · depth 10 km
  - (2026-07-30) M 5.0 - 8 km WNW of La Democracia, Guatemala
      M5.0 · 8 km WNW of La Democracia, Guatemala · depth 97.012 km
  - (2026-07-30) M 4.8 - 68 km SW of Mago, Russia
      M4.8 · 68 km SW of Mago, Russia · depth 13.668 km
  - (2026-07-30) M 4.8 - 24 km ESE of Qarnābād, Iran
      M4.8 · 24 km ESE of Qarnābād, Iran · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 38 total
  - (2026-07-30) MOVER ▲ Francoise Bettencourt Meyers & family — $97.01B (+$3.38B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-30) MOVER ▲ Bernard Arnault & family — $144.58B (+$1.86B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-30) MOVER ▼ Tadashi Yanai & family — $65.24B ($-1.37B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-30) MOVER ▲ Amancio Ortega — $143.18B (+$1.22B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-30) MOVER ▲ Zhong Shanshan — $64.42B (+$0.96B since yesterday)
      China · Food & Beverage · source: Beverages, pharmaceuticals
  - (2026-07-30) MOVER ▲ Mukesh Ambani — $88.37B (+$0.90B since yesterday)
      India · Diversified · source: Diversified

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-07-30) LoL: Ninjas in Pyjamas vs Weibo Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $709,192 · resolves 2026-07-30
  - (2026-07-30) LoL: Ninjas in Pyjamas vs Weibo Gaming (BO3) - LPL Group Nirvana
      yes price: 100% · 24h volume: $594,654 · resolves 2026-07-30
  - (2026-07-30) LoL: Ninjas in Pyjamas vs Weibo Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $534,982 · resolves 2026-07-30
  - (2026-07-30) LoL: DN SOOPers vs BNK FEARX - Game 1 Winner
      yes price: 0% · 24h volume: $474,321 · resolves 2026-07-30
  - (2026-07-30) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 28% · 24h volume: $398,528 · resolves 2027-01-01
  - (2026-07-30) Will Boston Celtics win the 2027 NBA Finals?
      yes price: 6% · 24h volume: $334,999 · resolves 2027-07-01

### Court opinions of consequence (federal & state) — 3 new of 60 total
  - (2026-07-29) U.S. Court of Appeals, 5th Cir.: United States v. Hunter
  - (2026-07-27) U.S. Court of Appeals, 8th Cir.: United States v. Sterling Spotted Elk, Jr.
  - (2026-07-24) U.S. Court of Appeals, 1st Cir.: Cruz v. UIA

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-30) [Marginal Revolution] An experiment for our schools
      Schools in at least three states will be equipped with drones this year that can zoom through halls, smash windows and pepper-spray active shooters if teachers report a threat. At least nine schools — three in Florida, f…
  - (2026-07-30) [Marginal Revolution] Forty interesting facts about Australia
      Australia was the richest country on earth, per capita, for decades. After the 1850s gold rush, up until the 1890s depression, Australia had the highest per capita income in the world. In 1850, probably only the United K…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=19, 14d-median=19; carrying terms: provide, certain, safety, standard, action, existing, requires, special, directive, revising, airworthiness, published
- state_bills: today=0, 7d-median=117, 14d-median=117; carrying terms: local, certain, defines, safety, budget, within, wildlife, organization, violation, existing, effective, establishes
- state_news: today=786, 7d-median=711, 14d-median=711; carrying terms: republican, oklahoma, local, provide, reelection, earlier, faces, nation, abortion, carry, gubernatorial, vtdigger
- local_news: today=227, 7d-median=228, 14d-median=228; carrying terms: local, faces, wanted, critical, going, weekend, figure, magazine, causes, weather, games, restaurants
- foreign_news: today=1020, 7d-median=1020, 14d-median=1020; carrying terms: republican, raising, streaming, others, earlier, internacional, faces, phone, tibetan, struck, described, eluniversal
- chinese_internal: today=301, 7d-median=276, 14d-median=276; carrying terms: market, google, giant, caixin, https, people, china, chinese, global, politics, lxtfb, demand
- russian_internal: today=1104, 7d-median=908, 14d-median=908; carrying terms: gazeta, novaya, street, reuters, httperror, error, forbidden, laquo, title, https, bloomberg, russian
- ukrainian_internal: today=119, 7d-median=136, 14d-median=136; carrying terms: strategic, civilians, local, marking, mykhailo, central, point, ordered, others, claimed, white, route
- ukraine_theater: today=552, 7d-median=552, 14d-median=552; carrying terms: against, polygons, active, community, known, unauthorized, cartography, httperror, google, assessment, campaign, liveuamap
- paper_bets: today=140, 7d-median=138, 14d-median=138; carrying terms: primary, republican, polymarket, pirates, sachs, robot, florida, jpmorgan, predictit, drought, chair, lesswrong
- weather: today=159, 7d-median=173, 14d-median=173; carrying terms: issued, central, changed, updated, point, atlantic, twoat, increased, mountains, monitoring, white, small
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: recession, cpiaucsl, funds, nonfarm, headline, jtsjol, money, dexuseu, latest, labor, vixcls, rates
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, large, nasdaq, bitcoin, yield, rates, futures, silver, close, commodities, equities, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=122, 7d-median=119, 14d-median=119; carrying terms: tiananmen, niger, violations, provide, central, prohibiting, certain, stanford, measures, rkiye, unauthorised, destabilisation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, unauthorized, httperror, error, client, quiver, congresstrading, https, quantitative
- billionaires: today=38, 7d-median=35, 14d-median=35; carrying terms: michael, exchange, diversified, arnault, spacex, bezos, adani, zuckerberg, tiktok, microsoft, steve, london
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: school, court, district, blanche, international, trade, appeals, robert, delaware, california, services, supreme
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, daniel, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: michael, senate, disbursements, talarico, filing, angels, ossoff, congress, shawn, cycle, ocasio, colorado
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan, china, world
- gdelt_gkg: today=74, 7d-median=47, 14d-median=47; carrying terms: israel, english, trump, hezbollah, keywords, perimeter, sanctions, chinese, russia, market, israeli
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=18, 14d-median=18; carrying terms: france, belgium, position, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: august, niger, local, americas, severe, hospital, cruise, bulape, central, sometimes, round, point
- cisa_kev: today=12, 7d-median=16, 14d-median=16; carrying terms: control, fortinet, improper, authentication, product, command, vendor, microsoft, remediation, untrusted, deserialization, langflow
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=272, 14d-median=272; carrying terms: venezuela, philippines, panama, liechtenstein, minor, germany, colombia, belarus, ecuador, ukraine, kazakhstan, russia
- usgs_quakes: today=25, 7d-median=23, 14d-median=23; carrying terms: south, islands, atlantic, depth, region, philippines, ridge, indonesia, mexico, guinea, papua, kermadec
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, rates, volume, price, interest, prime, ethiopia, resolves, meeting, abiebie, change, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, benefit, economist, conversable, revolution, class, marginal, marginalrevolution, looking, quality, knowing, coming
- tech_news: today=55, 7d-median=57, 14d-median=57; carrying terms: models, going, cybersecurity, computer, download, weekly, electricity, russia, current, operator, research, companies
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: stevens, taylor, newhouse, vought, babin, kiggans, andrea, reserved, administrator, henry, nicole, hillary
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, placed, today, claude, evidence, decision, paper, placement, sufficient, converges, either, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*