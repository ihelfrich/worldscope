# WORLDSCOPE morning brief — 2026-07-30

## Headline
2464 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (570) · Russian Internal News (state + in-exile) (487) · World leaders & government officials (324) · Chinese Internal News (273) · Ukraine Theater (total-war monitoring) (239) · U.S. Weather + Severe / Climate Outlooks (124) · Local News: St. Louis + Atlanta (103) · State-Level News (77) · Government Action: Sanctions + Procurement + Foreign Agents (50) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (33) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 570 new of 1022 total
  - (2026-07-30) [Global] Shell profits double as oil prices rise due to Iran war
      Disruption to global supplies of oil and liquid natural gas through the Strait of Hormuz has pushed up prices.
  - (2026-07-30) [Global] Virtual job interviews don't let people shine, says Burnham
      Interviews online may not allow young people to show their personality and passion, the prime minister says.
  - (2026-07-29) [Global] Beauty Pie founder on how she dropped out of university and built five beauty businesses
      Marcia Kilgore, founder of Beauty Pie, shares her top tips on how to create a successful business.
  - (2026-07-30) [Global] Burnham says nuclear sub investment will protect UK and boost jobs
      Speaking ahead of a visit to Barrow-in-Furness, the PM seeks to stress the economic benefits of defence spending.
  - (2026-07-30) [Global] Trump considering AI controls after OpenAI hacking incidents
      It marks a change of tone for his administration, which has taken a more hands-off approach to the technology.
  - (2026-07-30) [Global] Wiped out by a hurricane, this US community is now a global energy giant
      A US county flattened by Hurricane Rita is now the world's largest exporter of liquified natural gas.

### Russian Internal News (state + in-exile) — 487 new of 1106 total
  - (2026-07-30) Соучастника теракта в московском ЖК «Алые паруса» приговорили к 22 годам. Тогда во время взрыва погиб создатель батальона «Арбат» | LEDE: Второй Западный окружной военный суд приговорил к 22] (ru: Соу…
      Второй Западный окружной военный суд приговорил к 22 годам колонии Ваража Манукяна — соучастника теракта в московском ЖК «Алые паруса».
  - (2026-07-30) Война. 1618-й день. Россия нанесла массированный удар по Украине: восемь погибших, десятки раненых. Украинские беспилотники за одно утро атаковали три склада Wildberries | LEDE: «Медуза» с 2] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-30) В Ленинградской области из-за атак на склад Wildberries свои товары потеряли около 1500 предпринимателей. Губернатор пообещал им поддержку | LEDE: В Ленинградской области около полутора тыся] (ru: В Л…
      В Ленинградской области около полутора тысяч продавцов Wildberries потеряли свои товары из-за пожара на складе после атак украинских беспилотников, заявил глава региона Александр Дрозденко.
  - (2026-07-30) Украинские дроны атаковали третий склад Wildberries за день. Теперь — в Пермском крае | LEDE: Украинские беспилотники утром 30 июля атаковали склад Wildberries в Пермском крае. Первыми об эт] (ru: Укр…
      Украинские беспилотники утром 30 июля атаковали склад Wildberries в Пермском крае. Первыми об этом сообщили украинские телеграм-каналы, в частности, Exilenova+, который опубликовал фотографии и видео пожара.
  - (2026-07-30) «Это мировоззренческий конфликт». Бывший министр обороны Украины Федоров заявил, что у него не было личного конфликта с бывшим главкомом ВСУ Сырским | LEDE: Бывший министр обороны Украины Ми] (ru: «Эт…
      Бывший министр обороны Украины Михаил Федоров рассказал в большом интервью «Украинской правде», что у него не было личного конфликта с бывшим главнокомандующим ВСУ Александром Сырским.
  - (2026-07-30) «Коммерсант»: из Генпрокуратуры уволили «главного специалиста» по конфискации активов. Он готовил иски об изъятиях Домодедово и «Макфы» | LEDE: Из Генпрокуратуры уволили начальника главного ] (ru: «Ко…
      Из Генпрокуратуры уволили начальника главного гражданско-судебного управления Сергея Бочкарева, пишет «Коммерсант» со ссылкой на несколько источников. Газета называет его «главным специалистом» по изъятию активов бизнеса…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 273 new of 300 total
  - (2026-07-28) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1CVWt2RG1NeUtPSk5ncnpQS1NnOER4SzJGZkxqa3VGMFVwaUpnNktlc3M4d3NQdGVIMUtfMjh6NXFwQkJmR3NTN2dLUnRzM3] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-07-29) 就王虹推荐信，北大数院发声 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE92YTh2Vmw3Q3I4V3JMc29GcVlCdnZsaWExcVdKQW85TXc0MUkyQlhQamx6b3NIaVBUeVlwbl9iTFQ4aUNneUZHc19PQ3NhRTdKTmtfYi1p] (zh:…
      就王虹推荐信，北大数院发声 财新
  - (2026-07-29) 日本熊本地震已致12人死亡 商场为何在震后发生爆炸成焦点 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5PdmRKNXljeVB4UHJkOTBjVjhkWllIVG91bFJLeUc2TmpEQXdNVTRxeWNIbnI2dHVrMzRPVmVUTFRHZ2tGNHJGQVZUd] (zh:…
      日本熊本地震已致12人死亡 商场为何在震后发生爆炸成焦点 财新
  - (2026-07-30) 今日开盘：两市双双低开 沪指跌幅0.43% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE40bFk5Um0wQUdVOEl2TGlweld5TWtxd1NFUm9IUmIzUzFIajhQMFdYWFRqclJPX194YXBsQWlwMEc5YWlsX1NHenp2RjR3UU9J] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.43% 财新
  - (2026-07-29) 今日开盘：沪指报3823.29点 涨幅0.26% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5OMTFkYnhGTWtKRFRoNWZKcGhNMFBOTlZERHVIemZXY3NMd1JwOUFZOV96UUZtaElrUFFJSENOX1B1S0NHR1JlelY5VzhTe] (zh:…
      今日开盘：沪指报3823.29点 涨幅0.26% 财新
  - (2026-07-28) 今日开盘：两市双双低开 沪指跌幅0.91% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5HVzZjczdURmpTMXhIdjAwVWc4azZDbVhIVmROOVJIR0VRSEtwR0RWZHlDS3kwTEFJcnJqTEFqWHgwbTUtMXZVSmlFQlBRMm9K] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.91% 财新

### Ukraine Theater (total-war monitoring) — 239 new of 240 total
  - (2026-07-30) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-29) [Liveuamap] Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting group&039;s headquarters in several provinces Amerli, Saladin Governorat…
      Iraq&039;s Popular Mobilization Forces say 20 members killed, 32 wounded in overnight US-Saudi airstrikes targeting gro
  - (2026-07-28) [Liveuamap] Fire at the warehouse in Koledino of Moscow region after drones strikes - Liveuamap
      Fire at the warehouse in Koledino of Moscow region after drones strikes Liveuamap</font
  - (2026-07-28) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap
  - (2026-07-29) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap
  - (2026-07-29) [Liveuamap] The death toll from the Russian strike on an arms exhibition in the Kyiv region has risen to 11. A 66-year-old man, a diplomat of the Order of Malta, died in hospital from his injuries. On…
      The death toll from the Russian strike on an arms exhibition in the Kyiv region has risen to 11. A 66-year-old man, a diplomat

### U.S. Weather + Severe / Climate Outlooks — 124 new of 157 total
  - (2026-07-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-30) [Moderate] Special Weather Statement: Special Weather Statement issued July 30 at 4:45AM CDT by NWS North Platte NE
      At 445 AM CDT/345 AM MDT/, Doppler radar was tracking a strong thunderstorm 8 miles south of Roscoe, or 11 miles southeast of Ogallala, moving east at 10 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE…
  - (2026-07-30) [Moderate] Special Weather Statement: Special Weather Statement issued July 30 at 5:41AM EDT by NWS Tallahassee FL
      At 541 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Cross City to 13 miles south of Horseshoe Point. Movement was east at 10 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Rad…
  - (2026-07-30) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 30 at 2:26AM PDT until August 3 at 11:00PM PDT by NWS Hanford CA
      * WHAT...Dangerously hot conditions with several days of Major to Extreme heat risk. * WHERE...Indian Wells Valley, Mojave Desert, and Mojave Desert Slopes. * WHEN...From 11 AM this morning to 11 PM PDT Monday. * IMPACTS…
  - (2026-07-30) [Severe] Extreme Heat Watch: Extreme Heat Watch issued July 30 at 3:24AM MDT until August 2 at 9:00PM MDT by NWS Salt Lake City UT
      * WHAT...Dangerously hot conditions with temperatures up to 105 possible and overnight lows in the low to mid-70s. * WHERE...Northern Wasatch Front, Salt Lake Valley, Tooele and Rush Valleys, Utah Valley, and Western Uin…
  - (2026-07-30) [Moderate] Heat Advisory: Heat Advisory issued July 30 at 3:24AM MDT until August 2 at 9:00PM MDT by NWS Salt Lake City UT
      * WHAT...Temperatures up to 106 expected, with warm overnight lows in the upper 60s to low 70s offering little relief. * WHERE...Castle Country, Eastern Juab/Millard Counties, San Rafael Swell, and Great Salt Lake Desert…

### Local News: St. Louis + Atlanta — 103 new of 218 total
  - (2026-07-29) [St. Louis] St. Louis County health officials ask patients for help in cyclospora parasite investigations
  - (2026-07-30) [St. Louis] Chargers icon Billy Ray Smith Jr. dies at 64, family says NFL player had CTE-related dementia
      Smith had been a linebacker for the Chargers for 10 seasons.
  - (2026-07-30) [St. Louis] Body of 26-year-old former NCAA soccer player found floating in ocean near San Diego
      San Diego police said the Medical Examiner's Office is leading the investigation and will continue to do so unless it determines the death was a homicide.
  - (2026-07-30) [St. Louis] An Iranian strike has hit a Chinese firm's building, killing 1 worker in Kuwait
      The strike came hours after Jordan's air defenses shot down five missiles launched from Iran.
  - (2026-07-30) [St. Louis] Rufus the rescued dog finds new home with Ohio fire department
      Rufus was rescued from unsafe living conditions and spent two years in the shelter. Now he has a new home and a new job.
  - (2026-07-30) [St. Louis] US launches strikes on Iranian targets a day after it foiled missile attack on American forces
      U.S. Central Command said the strikes are “a powerful response to yesterday’s attempted Iranian attack” and that they began Wednesday evening.

### State-Level News — 77 new of 787 total
  - (2026-07-30) [California] Governor Newsom deploys elite wildfire team to Washington State as western fires surge
      Source
  - (2026-07-29) [Arizona] Abortion matters to voters — but it may not mobilize them, poll suggests
      A survey of voters in three battleground states, including Arizona, found that abortion remains a deciding issue in choosing which candidates to support. Impact Research, a public opinion research company that frequently…
  - (2026-07-30) [Alaska] Alaska National Guard Day 2026
      WHEREAS, since before World War II, the Alaska National Guard has acted as a first line of defense for the United States of America; and WHEREAS, the Alaska National Guard serves our Nation when called by federal service…
  - (2026-07-30) [Connecticut] Thank you, Hartford, for letting me teach. Now save your public schools
      <img width="1024" height="681" src="https://ctmirror.org/wp-content/uploads/2026/07/teachers-demonstrate-hartford-1024x681.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-07-30) [Connecticut] We all can act for CT’s greater good
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/AMERICA-LIBRARY-0701-JL-020-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" lo…
  - (2026-07-30) [Connecticut] The U.S.-imposed fuel crisis in Cuba is inhumane and immoral
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/07/ap-cuba-blackout.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset=…

### Government Action: Sanctions + Procurement + Foreign Agents — 50 new of 122 total
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-07-27) [OFAC] Sanctions List Removals; Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Sanctions List Removals; Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses - Office of Foreign Assets Cont…
      Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-30) [Ashiya Mona] Form 4 (Reporting)
      filed 2026-07-30 01:36 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001104659-26-088371 Size: 6 KB
  - (2026-07-30) [Yarrow Bioscience, Inc.] Form 4 (Issuer)
      filed 2026-07-30 01:36 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001104659-26-088371 Size: 6 KB
  - (2026-07-30) [Sheena Jonathan] Form 4 (Reporting)
      filed 2026-07-30 01:35 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001646649-26-000025 Size: 8 KB
  - (2026-07-30) [Natera, Inc.] Form 4 (Issuer)
      filed 2026-07-30 01:35 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001646649-26-000025 Size: 8 KB
  - (2026-07-30) [Rabinowitz Matthew] Form 4 (Reporting)
      filed 2026-07-30 01:35 UTC · role: Reporting — Filed: 2026-07-29 AccNo: 0001646382-26-000014 Size: 5 KB
  - (2026-07-30) [Natera, Inc.] Form 4 (Issuer)
      filed 2026-07-30 01:35 UTC · role: Issuer — Filed: 2026-07-29 AccNo: 0001646382-26-000014 Size: 5 KB

### Ukrainian Internal News (national + local Kyiv) — 33 new of 119 total
  - (2026-07-30) Усе свідчить про те, що в Польщі впала російська ракета Х-101 – Туск | LEDE: Премʼєр-міністр Польщі Дональд Туск заявив, що наразі все вказує на те, що уночі в Люблінському воєводстві впала рос] (uk:…
      Премʼєр-міністр Польщі Дональд Туск заявив, що наразі все вказує на те, що уночі в Люблінському воєводстві впала російська крилата ракета Х-101.
  - (2026-07-30) На Одещині затримали посадовця ТЦК, який за 500 л дизпалива обіцяв зняти з розшуку | LEDE: На Одещині правоохоронці затримали начальника одного з відділів територіального центру комплектування ] (uk:…
      На Одещині правоохоронці затримали начальника одного з відділів територіального центру комплектування та соціальної підтримки, якого підозрюють у вимаганні талонів на 500 літрів дизельного пального за зняття військовозоб…
  - (2026-07-30) Уночі в метро Києва укривалися понад 56 тисяч людей – у підземці спростували обмеження доступу | LEDE: Під час повітряної тривоги всі станції метро Києва були відкриті як укриття — КМДА] (uk: Уночі в…
      Під час повітряної тривоги всі станції метро Києва були відкриті як укриття — КМДА
  - (2026-07-30) Рада ЄС внесла зміни у план реформ України, необхідних для виділення 8,3 млрд євро | LEDE: 30 липня Рада ЄС схвалила зміни до механізму підтримки України Ukraine Facility та пов'язаного з ним "] (uk:…
      30 липня Рада ЄС схвалила зміни до механізму підтримки України Ukraine Facility та пов'язаного з ним "Плану України" (Ukraine Plan), що визначає необхідні для отримання фінансування реформи.
  - (2026-07-30) У Польщі показали момент падіння об’єкта, який Україна називає ракетою Х-101 | LEDE: Польський портал оприлюднив запис із камери спостереження, на якому зафіксовано падіння об'єкта, що вночі 30] (uk:…
      Польський портал оприлюднив запис із камери спостереження, на якому зафіксовано падіння об'єкта, що вночі 30 липня порушив повітряний простір країни та впав у Люблінському воєводстві. Українська сторона стверджує, що це…
  - (2026-07-30) У Кривому Розі оголосили день жалоби | LEDE: У Кривому Розі 31 липня день жалоби: загинули шестеро людей, серед них троє дітей, внаслідок російського удару.] (uk: У Кривому Розі оголосили день жалоби)
      У Кривому Розі 31 липня день жалоби: загинули шестеро людей, серед них троє дітей, внаслідок російського удару.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-07-30) GAF111 (Germany)
      icao24: 3f7588 · position: (55.515, -4.7518) · alt: 9753m · 645km/h
  - (2026-07-30) GAF191 (Germany)
      icao24: 3f727c · position: (49.6196, 9.9033) · alt: 3657m · 300km/h
  - (2026-07-30) CNA22 (Spain)
      icao24: 3475cb · position: (27.7663, -15.7694) · alt: 914m · 165km/h
  - (2026-07-30) SAMU86 (France)
      icao24: 39c905 · position: (47.0671, 0.8) · alt: 510m · 241km/h
  - (2026-07-30) JAF3NE (Belgium)
      icao24: 44d1ba · position: (49.7057, 2.2083) · alt: 9913m · 970km/h
  - (2026-07-30) JAF7CB (Belgium)
      icao24: 44d1b3 · position: (47.0905, -1.0464) · alt: 11582m · 914km/h

### U.S. Federal Action — 26 new of 26 total
  - (2026-07-30) Airworthiness Directives; Pilatus Aircraft Ltd. Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Pilatus Aircraft Ltd. (Pilatus) Model PC-12/47E airplanes. This AD was prompted by a report that, during an engine start on the ground, the airplane batt…
  - (2026-07-30) Airworthiness Directives; Stemme GmbH Gliders
      The FAA is adopting a new airworthiness directive (AD) for all Stemme GmbH (Stemme) Model Stemme S 12 gliders. This AD was prompted by reports of fuel leaking around certain copper sealing rings within the fuel system. T…
  - (2026-07-30) Civil Money Penalty for Actions in Contempt of an Immigration Judge's Proper Exercise of Authority
      This notice of proposed rulemaking ("NPRM") would implement a provision of the Immigration and Nationality Act ("INA" or "the Act") that authorizes Immigration Judges, under regulations prescribed by the Attorney General…
  - (2026-07-30) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A330-200 and A330-300 series airplanes modified by a certain supplemental type certificate (STC). This AD was prompted by a finding that…
  - (2026-07-30) Exchange Visitor Program-Termination of Program Participation, Extension of Program and Reinstatement to Valid Program Status
      The Department of State's (Department's) Bureau of Educational and Cultural Affairs administers the Exchange Visitor Program, as set forth at 22 CFR part 62, wherein exchange visitors on educational and cultural exchange…
  - (2026-07-30) Medicare Program; Updates to the Master List of Items Potentially Subject to Face-to-Face Encounter and Written Order Prior to Delivery and/or Prior Authorization Requirements; Updates to the Required…
      This document announces updates to the Healthcare Common Procedure Coding System (HCPCS) codes on the Master List. It also announces updates to the HCPCS codes on the Required Face-to-Face Encounter and Written Order Pri…

### Paper Trading Scorecard — 13 new of 141 total
  - (2026-07-30) [Polymarket] Will Apple be the largest company in the world by market cap on July 31?
      This market will resolve to the largest company in the world by market cap on July 31, 2026, as of market close. The resolution source for this market will be a consensus of credible reporting.
  - (2026-07-30) [Polymarket] Will the Fed increase interest rates by 25 bps after the October 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-07-30) [Polymarket] Will Elon Musk post 500+ tweets from July 24 to July 31, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 24 12:00 PM ET to July 31, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-30) [Manifold] Will YonKaGor make a cover of "Isn't She Lovely" by EOY 2028?
  - (2026-07-30) [Manifold] Will a frontier model exfiltrate its own weights by EoY 2028?
  - (2026-07-30) [Manifold] Will Seb Krier's Antichrist Meme tweet still be up on August 1st?

### USGS earthquakes (M4.5+, past day) — 10 new of 25 total
  - (2026-07-30) M 5.8 - Kermadec Islands region
      M5.8 · Kermadec Islands region · depth 10 km
  - (2026-07-30) M 5.4 - 201 km W of Abepura, Indonesia
      M5.4 · 201 km W of Abepura, Indonesia · depth 35 km
  - (2026-07-30) M 5.3 - 217 km SE of Kokopo, Papua New Guinea
      M5.3 · 217 km SE of Kokopo, Papua New Guinea · depth 10 km
  - (2026-07-30) M 5.0 - 8 km WNW of La Democracia, Guatemala
      M5.0 · 8 km WNW of La Democracia, Guatemala · depth 97.012 km
  - (2026-07-30) M 4.8 - 68 km SW of Mago, Russia
      M4.8 · 68 km SW of Mago, Russia · depth 13.668 km
  - (2026-07-30) M 4.8 - 24 km ESE of Qarnābād, Iran
      M4.8 · 24 km ESE of Qarnābād, Iran · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-30) LoL: DN SOOPers vs BNK FEARX - Game 2 Winner
      yes price: 0% · 24h volume: $797,535 · resolves 2026-07-30
  - (2026-07-30) LoL: Ninjas in Pyjamas vs Weibo Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $712,676 · resolves 2026-07-30
  - (2026-07-30) LoL: Ninjas in Pyjamas vs Weibo Gaming (BO3) - LPL Group Nirvana
      yes price: 100% · 24h volume: $682,520 · resolves 2026-07-30
  - (2026-07-30) LoL: Ninjas in Pyjamas vs Weibo Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $645,520 · resolves 2026-07-30
  - (2026-07-30) LoL: DN SOOPers vs BNK FEARX - Game 1 Winner
      yes price: 0% · 24h volume: $590,937 · resolves 2026-07-30
  - (2026-07-30) LoL: EDward Gaming vs Team WE - Game 1 Winner
      yes price: 0% · 24h volume: $562,526 · resolves 2026-07-30

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 38 total
  - (2026-07-30) MOVER ▲ Francoise Bettencourt Meyers & family — $96.69B (+$3.06B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-30) MOVER ▲ Bernard Arnault & family — $145.02B (+$2.30B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-30) MOVER ▲ Amancio Ortega — $143.39B (+$1.43B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-30) MOVER ▼ Tadashi Yanai & family — $65.24B ($-1.37B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-30) MOVER ▲ Zhong Shanshan — $64.42B (+$0.96B since yesterday)
      China · Food & Beverage · source: Beverages, pharmaceuticals
  - (2026-07-30) MOVER ▲ Mukesh Ambani — $88.30B (+$0.83B since yesterday)
      India · Diversified · source: Diversified

### IT, InfoSys & cybersecurity news (last 7 days) — 7 new of 50 total
  - (2026-07-30) [The Hacker News] Russian Hackers Exploit Microsoft OWA Flaw to Keep Mailbox Access After Credential Rotation
      The Russian threat actors recently linked to the exploitation of a now-patched vulnerability in Zimbra have been observed exploiting another vulnerability, this time in Microsoft Outlook Web Access (OWA), to target U.S.…
  - (2026-07-30) [The Hacker News] FCC Blocks New Foreign-Produced Robots and Power Inverters Over Cyber Risks
      The Federal Communications Commission (FCC) added foreign-produced mobile robots and networked power inverters to its Covered List on July 28. The move generally prevents new models from receiving the equipment authoriza…
  - (2026-07-30) [The Hacker News] Amazon Links Debug and Chalk npm Hijack to North Korea’s Sapphire Sleet
      Amazon has tied the September 2025 hijack of the npm packages debug and chalk to North Korea. For ten months, the incident sat in the public record as crypto theft: a maintainer phished through a lookalike npm domain and…
  - (2026-07-30) [The Hacker News] Cisco FMC Zero-Day Actively Exploited, Static Credentials Could Expose Sensitive Data
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Wednesday added a newly disclosed security flaw impacting Cisco Secure Firewall Management Center (FMC) Software to its Known Exploited Vulnerabilities…
  - (2026-07-30) [Computer Weekly] Subpostmasters anxious over Horizon replacement as it is delayed yet again
      The Post Office has delayed signing the Horizon software replacement contract for the sixth time, with sources claiming the losing bidder is challenging the award. Meanwhile, subpostmasters have accused Fujitsu of “takin…
  - (2026-07-30) [TechCrunch] Microsoft is openly competing with OpenAI, Anthropic more than ever
      Microsoft pitched its own homegrown AI models, harnesses, and even a Mythos competitor on Wednesday, telling Wall Street it plans for continued growth.

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-30) [South Korea] ITZY Yuna To Miss Upcoming Fan Sign Event Due To Health
      soompi.com · English
  - (2026-07-30) [South Korea] Hanwha promotes chairman three sons in leadership reshuffle
      koreaherald.com · English
  - (2026-07-30) [South Korea] Seoul shares again dip over 1 % after 2 - day deep rout amid AI spending concerns
      koreaherald.com · English
  - (2026-07-30) [South Korea] DP to Introduce Bill to Strip Prosecution of Investigative Powers at Plenary Session Thursday
      world.kbs.co.kr · English
  - (2026-07-30) [South Korea] Bourse : les indices de nouveau en baisse
      world.kbs.co.kr · English
  - (2026-07-30) [South Korea] Extreme Heat Wave to Stretch into Next Week
      world.kbs.co.kr · English

### Court opinions of consequence (federal & state) — 2 new of 60 total
  - (2026-07-29) U.S. Court of Appeals, 5th Cir.: United States v. Hunter
  - (2026-07-27) U.S. Court of Appeals, 8th Cir.: United States v. Sterling Spotted Elk, Jr.

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-30) [Marginal Revolution] An experiment for our schools
      Schools in at least three states will be equipped with drones this year that can zoom through halls, smash windows and pepper-spray active shooters if teachers report a threat. At least nine schools — three in Florida, f…
  - (2026-07-30) [Marginal Revolution] Forty interesting facts about Australia
      Australia was the richest country on earth, per capita, for decades. After the 1850s gold rush, up until the 1890s depression, Australia had the highest per capita income in the world. In 1850, probably only the United K…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=19, 14d-median=19; carrying terms: applicable, management, proposing, provide, published, airworthiness, directives, airplanes, existing, requires, certain, review
- state_bills: today=0, 7d-median=117, 14d-median=117; carrying terms: distribution, division, organization, customer, appropriate, circumstances, protection, adult, management, business, abuse, limits
- state_news: today=787, 7d-median=711, 14d-median=711; carrying terms: connecticut, forbidden, warning, helped, leaving, hawai, positive, times, tuesday, haley, often, minute
- local_news: today=218, 7d-median=228, 14d-median=228; carrying terms: afternoon, leaving, times, tuesday, residents, atlanta, restaurants, election, student, google, investigation, woman
- foreign_news: today=1022, 7d-median=1022, 14d-median=1022; carrying terms: effect, package, tougher, forbidden, massacre, warning, leaving, helped, hanoi, german, convulsions, times
- chinese_internal: today=300, 7d-median=276, 14d-median=276; carrying terms: market, google, giant, china, global, people, chinese, caixin, https, lxtfb, cbmibkfvx, stock
- russian_internal: today=1106, 7d-median=908, 14d-median=908; carrying terms: forbidden, russian, group, bloomberg, telegram, laquo, raquo, novaya, times, httperror, istories, title
- ukrainian_internal: today=119, 7d-median=136, 14d-median=136; carrying terms: additional, forbidden, capacity, economic, including, expected, warning, russia, reports, casualties, imports, civilians
- ukraine_theater: today=240, 7d-median=530, 14d-median=530; carrying terms: google, russian, takeaways, community, deepstatemap, assessment, token, extra, polygons, alerts, known, russia
- paper_bets: today=141, 7d-median=138, 14d-median=138; carrying terms: verve, nuclear, posts, determined, midterm, leave, levels, december, winner, resolve, celsius, season
- weather: today=157, 7d-median=173, 14d-median=173; carrying terms: worth, additional, portion, strong, effect, messages, including, afternoon, expected, warning, afdtbw, located
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unrate, latest, spread, growth, cpiaucsl, sheet, rates, indicator, energy, money, commodities, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, credit, agriculture, close, russell, nasdaq, silver, crude, yield, natural, futures, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=122, 7d-median=119, 14d-median=119; carrying terms: space, economic, rkiye, russia, detect, control, mediterranean, qaida, embargo, involvement, guatemala, company
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, client, https, error, httperror, unauthorized, congresstrading, quiverquant, quiver
- billionaires: today=38, 7d-median=35, 14d-median=35; carrying terms: devasini, alice, charles, microsoft, peterffy, walton, semiconductors, ellison, india, madrid, mukesh, exchange
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: trade, robert, international, california, appeals, blanche, services, school, delaware, supreme, court, district
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, daniel, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: colorado, trone, robert, booker, disbursements, house, shawn, elect, senate, platner, ocasio, talarico
- gdelt_regions: today=6, 7d-median=12, 14d-median=12; carrying terms: english, korea, world
- gdelt_gkg: today=0, 7d-median=47, 14d-median=47; carrying terms: israel, english, trump, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=18, 14d-median=18; carrying terms: france, position, canada, belgium, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: algeria, infect, support, additional, increasing, genetically, multi, kozhikode, circulate, numbers, direct, batch
- cisa_kev: today=12, 7d-median=16, 14d-median=16; carrying terms: microsoft, command, fortisandbox, management, remediation, vulnerability, sharepoint, product, untrusted, fortinet, authentication, control
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=272, 14d-median=272; carrying terms: ecuador, impact, sweden, denmark, nicaragua, green, congo, republic, switzerland, serbia, romania, philippines
- usgs_quakes: today=25, 7d-median=23, 14d-median=23; carrying terms: depth, islands, south, region, atlantic, philippines, indonesia, ridge, mexico, papua, guinea, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, meeting, resolves, rates, interest, volume, price, ethiopia, prime, abiebie, adanech, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, conversable, https, economist, benefit, marginalrevolution, revolution, class, quality, looking, certain, requirement
- tech_news: today=50, 7d-median=57, 14d-median=57; carrying terms: computer, known, ransomware, russia, company, working, daily, exploitation, research, state, spectrum, edition
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: pettersen, lofgren, strong, philip, vought, kirsten, gorsuch, bresnahan, stevens, mario, larsen, thune
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, unavailable, decision, today, sufficient, market, either, evidence, paper, placed, markets, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*