# WORLDSCOPE morning brief — 2026-07-30

## Headline
3029 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (644) · Russian Internal News (state + in-exile) (563) · Ukraine Theater (total-war monitoring) (324) · World leaders & government officials (324) · Chinese Internal News (286) · State Legislative Action (183) · Local News: St. Louis + Atlanta (127) · State-Level News (121) · U.S. Weather + Severe / Climate Outlooks (119) · Government Action: Sanctions + Procurement + Foreign Agents (50) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 644 new of 1023 total
  - (2026-07-30) [Global] Hundreds of migrants enter Spain's north African territory Ceuta from Morocco
      The president of Spain's north African exclave Ceuta on Thursday warned of a "total humanitarian and social emergency" after hundreds of migrants entered the territory by swimming across from neighbouring Morocco in rece…
  - (2026-07-30) [Global] #Ukraine pounded in Russian attack, Polish airspace 'violated'
      In #Russia's latest deadly attack on #Ukraine, an unidentified object violated Polish airspace and crashed into a field. Ukrainian President Volodymyr #Zelensky has urged allies for anti-ballistic #missiles against 'Russ…
  - (2026-07-30) [Global] How native livestock is reducing the risk of wildfires in Spain's Galicia region
      In Spain's Galicia region, native goats, sheep, and cows are helping local communities reduce the risk of wildfires by grazing on flammable undergrowth.The initiative has gained momentum in an area hit hard by Spain's wo…
  - (2026-07-30) [Global] Greek firefighters battle deadly wildfires on Crete for a second day
      Greek firefighters were ⁠battling deadly wildfires on ​the island of Crete for a second day on Thursday, as wildfires continue to ​spread across Europe following days of devastating blazes in Spain and France. On Wednesd…
  - (2026-07-30) [Global] Tens of thousands of French wildfire evacuees allowed to return home
      French authorities gave the go-ahead Thursday for 84,000 evacuees forced out by a monster wildfire to go back to their homes in southwest France, the strongest sign yet that firefighters are turning a corner in their bat…
  - (2026-07-30) [Global] Poland says giant crater left by explosion after Russia attacks on Ukraine
      Polish authorities said Thursday that a 10 metre (33 feet) wide crater had been left by an explosion in an eastern region that occurred as Russia staged new missile attacks on neighbouring Ukraine. Polish authorities did…

### Russian Internal News (state + in-exile) — 563 new of 1151 total
  - (2026-07-30) Задержан Валерий Кустов — миллиардер и основной акционер «Эфко» (майонез «Слобода» и масло «Олейна»). Его заподозрили в мошенничестве с беспилотниками | LEDE: В Москве по подозрению в крупно] (ru: Зад…
      В Москве по подозрению в крупном мошенничестве задержали председателя совета директоров и основного акционера группы компаний масложировой промышленности «Эфко» Валерия Кустова, сообщают источники РБК.
  - (2026-07-30) В Армении возбудили уголовное дело против блогера из России Надежды Пирожковой. Она возмущалась тем, что на праздник Вардавар все обливаются водой. Пирожкова не скрывает, что этот скандал помог] (ru:…
      Следственный комитет Армении возбудил уголовное дело против россиянки Надежды Пирожковой, которая возмутилась традициями праздника Вардавар. Эту информацию СК Армении подтвердил изданию «Вот так».
  - (2026-07-30) Павла Дурова внесли в перечень террористов и экстремистов Росфинмониторинга | LEDE: Основателя мессенджера Telegram Павла Дурова внесли в перечень террористов и экстремистов Росфинмониторинг] (ru: Пав…
      Основателя мессенджера Telegram Павла Дурова внесли в перечень террористов и экстремистов Росфинмониторинга. Это следует из обновленного списка.
  - (2026-07-30) Из украинской версии фильма «Человек-паук» вырезали песню Монеточки | LEDE: Из украинской прокатной версии нового «Человека-паука» убрали песню Монеточки «Монополия», которая звучит в саундт] (ru: Из…
      Из украинской прокатной версии нового «Человека-паука» убрали песню Монеточки «Монополия», которая звучит в саундтреке картины, рассказали пользователи соцсети Threads.
  - (2026-07-30) Россияне стали реже покупать одежду и обувь — и чаще ходить на распродажи и в секонд-хенды | LEDE: Количество покупок одежды и обуви в январе — мае 2026 года сократилось на 10% по сравнению ] (ru: Рос…
      Количество покупок одежды и обуви в январе — мае 2026 года сократилось на 10% по сравнению с тем же периодом 2025-го, сообщает «Коммерсант», ссылаясь на подсчеты аналитических компаний Kloto Consulting и TrendVision. В о…
  - (2026-07-30) Под Кривым Рогом российская ракета попала в дом, где жила многодетная семья. Погибли мать, отец и четверо детей. Еще троих ищут под завалами | LEDE: В селе Радушное в Днепропетровской област] (ru: Под…
      В селе Радушное в Днепропетровской области в результате российского ракетного удара погибли члены одной семьи — отец, мать и несколько их детей.

### Ukraine Theater (total-war monitoring) — 324 new of 553 total
  - (2026-07-30) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-30) [FIRMS] thermal anomaly 52.807, 32.224 (FRP 0.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 0.85 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.849, 29.990 (FRP 1.09 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 1.09 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.846, 29.989 (FRP 5.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 5.08 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.304, 32.650 (FRP 0.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 0.28 MW
  - (2026-07-30) [FIRMS] thermal anomaly 51.893, 29.343 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 1.95 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 286 new of 313 total
  - (2026-07-28) Covid-19 Infections Surge Across China as Virus Reclaims Dominance - caixinglobal.com
      Covid-19 Infections Surge Across China as Virus Reclaims Dominance caixinglobal.com
  - (2026-07-30) 因担心二次事故，熊本暂停对永旺的搜救行动。还有JAL123复刻？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE9mODNRZE44YW1DQ21GaXZFS1BpVXFKV2VfWV8wR3VJeUhWczhuUlVhWC1TUzlkX01Gd0pWbDRkcnNvMnljS0J3b] (zh:…
      因担心二次事故，熊本暂停对永旺的搜救行动。还有JAL123复刻？ 风闻
  - (2026-07-30) 为什么酒店牙刷一刷就出血？背后的“投胎”故事太惊人 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBnS0c2cnY2U01UMEdsY01YekpvajRIT1JoY1lKM0h3X1Y3bGZieFVMQ1RHdUt4MjdpRmVseHhkemNJcHlKY0lZbk42dlVT] (zh:…
      为什么酒店牙刷一刷就出血？背后的“投胎”故事太惊人 风闻
  - (2026-07-30) 抱着保值增值的老黄历打不赢金融战，中国金融人必须敢于承担风险！ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE9URVdTekEwenhUQXlvNTh6Z1ZoMVRsbTlBamVpeXczb2hUb25iUC1IOEdFbkZoazhwT2ZRZzZWcHhtckVqVE5BbU] (zh:…
      抱着保值增值的老黄历打不赢金融战，中国金融人必须敢于承担风险！ 风闻
  - (2026-07-30) 日本书道 VS 中国书法：这局你觉得谁赢了？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5Td0gxakhOOGhfYWtDd2xneG80b0ROdmJoczMyZjA0MFJ6dThiNWo4Zkxwc1VnWWc5ZExoYmYyQ3ZvalNSQXhIYi0yZjU4Skw] (zh:…
      日本书道 VS 中国书法：这局你觉得谁赢了？ 风闻
  - (2026-07-30) 惊险实录！韩国女主播直播爆仓，300万韩元资产瞬间清零 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE0yYnB5ejNmZDVraFJsVTVWX1htd2tubEltaHB4VVRtYUJKWmh1NThjc1ZNcndvaVNCLTRndFFjTHdMSWppUG9zbXlMck] (zh:…
      惊险实录！韩国女主播直播爆仓，300万韩元资产瞬间清零 风闻

### State Legislative Action — 183 new of 203 total
  - (2026-07-30) [Alaska SB 24] An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco,…
      An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco, a product containing nicotine, or…
  - (2026-07-30) [California AB 69] FAIR Plan policy notices and renewals.
      The California FAIR Plan Association is a joint reinsurance association in which all insurers licensed to write basic property insurance participate to administer a program for the equitable apportionment of basic proper…
  - (2026-07-30) [California ACR 126] Relative to the Captain Vidar Anderson Memorial Highway.
      This measure would designate a specified portion of State Highway Route 395 in the County of Mono as the Captain Vidar Anderson Memorial Highway. The measure would request that the Department of Transportation determine…
  - (2026-07-30) [California SB 594] Short-Term Rental Facilitator Act of 2026.
      Existing law, the Short-Term Rental Facilitator Act of 2025, authorizes a local agency to enact an ordinance to require a short-term rental facilitator, as defined, to report, in the form and manner prescribed by the loc…
  - (2026-07-30) [California AB 1626] Interscholastic athletics: youth sports: coaches: behavioral and mental health training.
      Existing law requires the governing board of each school district to have general control of, and be responsible for, all aspects of the interscholastic athletic policies, programs, and activities in its school district,…
  - (2026-07-30) [California SB 930] Student Test Taker Privacy Protection Act: end-to-end encryption.
      Existing law, the California Consumer Privacy Act of 2018 (CCPA) , imposes various obligations on businesses with respect to personal information, as defined. The California Privacy Rights Act of 2020, approved by the vo…

### Local News: St. Louis + Atlanta — 127 new of 219 total
  - (2026-07-30) [St. Louis] Shock poll shows Zimmerman on top in county executive race
      A poll taken of St. Louis County voters this month shows County Assessor Jake Zimmerman with a nine point lead over state Senator Brian Williams (D-University City) in the Democratic primary race for county executive—a s…
  - (2026-07-30) [St. Louis] The Cardinals’ Tarps Off section: reviewed!
      One in an occasional series of irreverent reviews designed to help people navigate St. Louis in all its quirky glory. It’s no secret that attendance at Cardinals games is way down, and while the internet has no shortage…
  - (2026-07-30) [St. Louis] Rung for Women boasts major salary gains for St. Louis women
      On a beat like economic mobility, few data points are more eye-catching than a local nonprofit—one seeking to uplift women in St. Louis, specifically—saying that graduates of its programming are making tens of thousands…
  - (2026-07-30) [St. Louis] Better roads will cost money—and St. Louis County executive candidates differ on how to find it
      For a bone-rattling experience, steer your vehicle off Manchester in Maplewood and drive south on Hanley. By the time that road becomes Laclede Station and ends in Shrewsbury, you will have passed over multiple stretches…
  - (2026-07-30) [St. Louis] 'Everybody was panicking': Driver of car pulled over when officers were ambushed describes hectic scene
      During an exclusive interview with 5 On Your Side, the man said he ducked behind his car as three scared children ran inside the meat market for cover.
  - (2026-07-30) [St. Louis] Michigan woman sues Taco Bell, produce companies over parasite outbreak
      The lawsuit alleges contaminated lettuce caused a Cyclospora infection that led to hospitalization after Taco Bell meal. Border Foods and Taylor companies are named.

### State-Level News — 121 new of 823 total
  - (2026-07-30) [California] Governor Newsom deploys elite wildfire team to Washington State as western fires surge
      Source
  - (2026-07-30) [Connecticut] Thank you, Hartford, for letting me teach. Now save your public schools
      <img width="1024" height="681" src="https://ctmirror.org/wp-content/uploads/2026/07/teachers-demonstrate-hartford-1024x681.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-07-30) [Connecticut] We all can act for CT’s greater good
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/AMERICA-LIBRARY-0701-JL-020-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" lo…
  - (2026-07-30) [Connecticut] The U.S.-imposed fuel crisis in Cuba is inhumane and immoral
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/07/ap-cuba-blackout.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset=…
  - (2026-07-30) [Connecticut] 1st Congressional District candidates square off in final debate
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/SRR_9255-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" s…
  - (2026-07-30) [Arkansas] Crisis pregnancy centers fight for ultrasound use in clinics without government oversight
      The auditors trying to learn how a dozen crisis pregnancy centers in Louisiana had spent nearly $1.2 million ultimately could not figure it out. Despite a new law, the state had failed to establish a process for the cent…

### U.S. Weather + Severe / Climate Outlooks — 119 new of 149 total
  - (2026-07-30) [Moderate] Special Weather Statement: Special Weather Statement issued July 30 at 7:22AM CDT by NWS Grand Forks ND
      At 721 AM CDT, Doppler radar was tracking a strong thunderstorm near Newfolden, moving east at 45 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock dow…
  - (2026-07-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-30) [Moderate] Special Weather Statement: Special Weather Statement issued July 30 at 8:09AM EDT by NWS Jacksonville FL
      At 809 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Williston Municipal Airport to 7 miles north of Beverly Hills. Movement was east at 15 mph. HAZARD...Wind gusts around 40 mp…
  - (2026-07-30) [Moderate] Special Weather Statement: Special Weather Statement issued July 30 at 8:05AM EDT by NWS Jacksonville FL
      At 805 AM EDT, Doppler radar was tracking a strong thunderstorm 9 miles northeast of Williston, moving east at 25 mph. HAZARD...Wind gusts 40 to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tre…
  - (2026-07-30) [Moderate] Special Weather Statement: Special Weather Statement issued July 30 at 6:01AM MDT by NWS Glasgow MT
      At 600 AM MDT, Doppler radar was tracking a strong thunderstorm near The Pines Rec Area, or 20 miles south of Glasgow, moving east at 20 mph. HAZARD...Winds in excess of 30 mph and penny size hail. SOURCE...Radar indicat…
  - (2026-07-30) [Moderate] Heat Advisory: Heat Advisory issued July 30 at 6:48AM CDT until July 30 at 7:00PM CDT by NWS Mobile AL
      * WHAT...Heat index values up to 110 expected. * WHERE...Portions of south central and southwest Alabama, northwest Florida, and southeast Mississippi. * WHEN...From 11 AM this morning to 7 PM CDT this evening. * IMPACTS…

### Government Action: Sanctions + Procurement + Foreign Agents — 50 new of 122 total
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-07-27) [OFAC] Sanctions List Removals; Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Sanctions List Removals; Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses - Office of Foreign Assets Cont…
      Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-07-30) [Israel-Iran-Hezbollah axis · themes] Pakistan - administered Kashmir vote marred by deadly clashes
      nbcnews.com · English · tone NA
  - (2026-07-30) [Israel-Iran-Hezbollah axis · themes] Fuegos España | Los vecinos de seis pueblos de Castellón regresan a casa al mejorar el incendio de la Vall dUixó
      diariodeibiza.es · Spanish · tone NA
  - (2026-07-30) [Israel-Iran-Hezbollah axis · themes] На Камчатке ищут новорождённую девочку , которую мать выбросила в мусорный бак
      life.ru · Russian · tone NA
  - (2026-07-30) [Israel-Iran-Hezbollah axis · themes] सुनसरी घटनाको समीक्षा गर्दै सुरक्षा परिषद्‌को बैठक सम्पन्‍न
      gorkhapatraonline.com · Nepali · tone NA
  - (2026-07-30) [Israel-Iran-Hezbollah axis · themes] Падіння російської ракети у Польщі . Сибіга провів переговори з Сікорським
      glavcom.ua · Ukrainian · tone NA
  - (2026-07-30) [Israel-Iran-Hezbollah axis · themes] Raids in Bolton under probe into nuisance car finance marketing texts
      manchestereveningnews.co.uk · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-30) 497K - VanEck ETF Trust (0001137360) (Filer)
      filed 2026-07-30 12:18 UTC — Filed: 2026-07-30 AccNo: 0001137360-26-000719 Size: 342 KB
  - (2026-07-30) 497 - VanEck ETF Trust (0001137360) (Filer)
      filed 2026-07-30 12:17 UTC — Filed: 2026-07-30 AccNo: 0001137360-26-000718 Size: 1 MB
  - (2026-07-30) 424B3 - 1st FRANKLIN FINANCIAL CORP (0000038723) (Filer)
      filed 2026-07-30 12:12 UTC — Filed: 2026-07-30 AccNo: 0001628280-26-050821 Size: 24 KB
  - (2026-07-30) 425 - Matinas BioPharma Holdings, Inc. (0001582554) (Subject)
      filed 2026-07-30 12:05 UTC — Filed: 2026-07-30 AccNo: 0001493152-26-035330 Size: 35 KB
  - (2026-07-30) 424B3 - 1st FRANKLIN FINANCIAL CORP (0000038723) (Filer)
      filed 2026-07-30 12:04 UTC — Filed: 2026-07-30 AccNo: 0001628280-26-050816 Size: 29 KB
  - (2026-07-30) [ROTHBLATT MARTINE A] Form 4 (Reporting)
      filed 2026-07-30 11:58 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001106578-26-000109 Size: 29 KB

### Ukrainian Internal News (national + local Kyiv) — 38 new of 122 total
  - (2026-07-30) Суд відправив під варту на 60 днів двох військових полку "Скеля", яких підозрюють у побитті побратимів | LEDE: Двох військових "Скеля" арештували на 60 днів без застави за підозрою в катуванні ] (uk:…
      Двох військових "Скеля" арештували на 60 днів без застави за підозрою в катуванні та побитті побратимів.
  - (2026-07-30) ЄС профінансував закупівлю Gripen для України на 2,5 млрд євро – джерела | LEDE: 2,5 млрд з 3,47 млрд євро, перерахованих Україні від Євросоюзу 30 липня в рамках "оборонних виплат" за кредитом ] (uk:…
      2,5 млрд з 3,47 млрд євро, перерахованих Україні від Євросоюзу 30 липня в рамках "оборонних виплат" за кредитом на загальну суму 90 млрд євро, буде спрямовано на закупівлю для збройних сил України 16 літаків Gripen Е вир…
  - (2026-07-30) На Київщині оголосили пожежну небезпеку через підвищення температури | LEDE: Укргідрометцентр повідомив про підвищення температури з 31 липня і попередив про пожежну небезпеку на Київщині протя] (uk:…
      Укргідрометцентр повідомив про підвищення температури з 31 липня і попередив про пожежну небезпеку на Київщині протягом 31 липня - 2 серпня.
  - (2026-07-30) Туск не вважає, що Польща була ціллю ракетної атаки росіян | LEDE: Польський прем'єр Дональд Туск, коментуючи інцидент з російською ракетою, що впала у Люблінському воєводстві, зазначив, що нем] (uk:…
      Польський прем'єр Дональд Туск, коментуючи інцидент з російською ракетою, що впала у Люблінському воєводстві, зазначив, що немає підстав, що саме Польща була її ціллю.
  - (2026-07-30) Ракетний удар по Криворіжжю: кількість поранених зросла до дев’яти, шестеро людей загинули | LEDE: Кількість постраждалих унаслідок російського ракетного удару по Новопільській громаді зросла д] (uk:…
      Кількість постраждалих унаслідок російського ракетного удару по Новопільській громаді зросла до дев’яти.
  - (2026-07-30) Безпілотники атакували склади Wildberries у Пермському краї РФ і Удмуртії | LEDE: БпЛА уразили низку об'єктів у Пермському краї РФ та Удмуртській республіці, зокрема склади логістичного комплек] (uk:…
      БпЛА уразили низку об'єктів у Пермському краї РФ та Удмуртській республіці, зокрема склади логістичного комплексу Wildberries.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-30) JAF9XT (Bulgaria)
      icao24: 4520d0 · position: (34.2719, -6.3946) · alt: 9265m · 855km/h
  - (2026-07-30) JAF95J (Bulgaria)
      icao24: 4520aa · position: (37.1241, -8.8526) · alt: 10668m · 786km/h
  - (2026-07-30) PUMAA (France)
      icao24: 39ddf7 · position: (46.3623, 4.9566) · alt: 693m · 305km/h
  - (2026-07-30) PAT675 (United States)
      icao24: adfe49 · position: (39.7212, -77.0043) · alt: 3246m · 341km/h
  - (2026-07-30) PAT713 (United States)
      icao24: adfe8d · position: (39.8283, -82.8458) · alt: 2476m · 323km/h
  - (2026-07-30) SAMU59 (France)
      icao24: 39b5d1 · position: (50.3529, 3.7679) · alt: 434m · 260km/h

### U.S. Federal Action — 26 new of 26 total
  - (2026-07-30) Airworthiness Directives; Pilatus Aircraft Ltd. Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Pilatus Aircraft Ltd. (Pilatus) Model PC-12/47E airplanes. This AD was prompted by a report that, during an engine start on the ground, the airplane batt…
  - (2026-07-30) Airworthiness Directives; Stemme GmbH Gliders
      The FAA is adopting a new airworthiness directive (AD) for all Stemme GmbH (Stemme) Model Stemme S 12 gliders. This AD was prompted by reports of fuel leaking around certain copper sealing rings within the fuel system. T…
  - (2026-07-30) Civil Money Penalty for Actions in Contempt of an Immigration Judge's Proper Exercise of Authority
      This notice of proposed rulemaking ("NPRM") would implement a provision of the Immigration and Nationality Act ("INA" or "the Act") that authorizes Immigration Judges, under regulations prescribed by the Attorney General…
  - (2026-07-30) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A330-200 and A330-300 series airplanes modified by a certain supplemental type certificate (STC). This AD was prompted by a finding that…
  - (2026-07-30) Exchange Visitor Program-Termination of Program Participation, Extension of Program and Reinstatement to Valid Program Status
      The Department of State's (Department's) Bureau of Educational and Cultural Affairs administers the Exchange Visitor Program, as set forth at 22 CFR part 62, wherein exchange visitors on educational and cultural exchange…
  - (2026-07-30) Medicare Program; Updates to the Master List of Items Potentially Subject to Face-to-Face Encounter and Written Order Prior to Delivery and/or Prior Authorization Requirements; Updates to the Required…
      This document announces updates to the Healthcare Common Procedure Coding System (HCPCS) codes on the Master List. It also announces updates to the HCPCS codes on the Required Face-to-Face Encounter and Written Order Pri…

### Paper Trading Scorecard — 14 new of 142 total
  - (2026-07-30) [Polymarket] Will the Fed increase interest rates by 25 bps after the October 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-07-30) [Polymarket] Will Elon Musk post 500+ tweets from July 24 to July 31, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 24 12:00 PM ET to July 31, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-30) [Polymarket] Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-07-30) [Manifold] Will "…but have the weights left the server?" make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-07-30) [Manifold] Will YonKaGor make a cover of "Isn't She Lovely" by EOY 2028?
  - (2026-07-30) [Manifold] Will a frontier model exfiltrate its own weights by EoY 2028?

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-30) [China] Idex Is a Cash Compounder With an Impressive Record of Capital Allocation and Margin Expansion
      morningstar.com · English
  - (2026-07-30) [China] BYD gains safety - management certification ahead of China mandatory L2 standard
      autonews.gasgoo.com · English
  - (2026-07-30) [China] Sustainability leadership in a fractured world : What board directors must know in 2026 | Events | Asia
      eco-business.com · English
  - (2026-07-30) [China] As AI spending soars , can China tech giants deliver long - term profits ?
      scmp.com · English
  - (2026-07-30) [China] As Semiconductor Stocks Slide , These Chip Startup IPOs Go On Hold
      morningstar.com · English
  - (2026-07-30) [China] PQSecure and QuickLogic Demonstrate Reprogrammable Post - Quantum Security for Next - Generation SoCs
      design-reuse.com · English

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 50 total
  - (2026-07-30) [The Hacker News] Microsoft Copilot for Word Can Copy Hidden Prompts Into New Documents
      Hidden instructions in a Word document can make Microsoft 365 Copilot rewrite figures in a report, then copy the same instructions into the finished file. Håkon Måløy disclosed the technique on July 28, 144 days after re…
  - (2026-07-30) [The Hacker News] The Network Has Become the Control Plane for AI Security
      Network firewalls are the workhorses of modern cybersecurity. They are trusted to protect the network, blocking malicious traffic and preventing intrusions and breaches. And for decades, network security teams have built…
  - (2026-07-30) [The Hacker News] Hackers Exploit AnySign4PC via Hacked Korean Sites to Install Backdoors Without Prompts
      South Korean authorities and four security firms have disclosed a state-sponsored campaign that compromised trusted domestic websites. The attackers used those sites to exploit locally installed financial-security softwa…
  - (2026-07-30) [The Hacker News] SilverFox Targets Japanese Manufacturer with 3-Driver BYOVD Chain and ValleyRAT
      The Chinese cybercrime group known as Silver Fox has been observed using new drivers as part of bring your own vulnerable driver (BYOVD) attacks targeting a Japanese organization in the industrial manufacturing sector to…
  - (2026-07-30) [The Hacker News] Russian Hackers Exploit Microsoft OWA Flaw to Keep Mailbox Access After Credential Rotation
      The Russian threat actors recently linked to the exploitation of a now-patched vulnerability in Zimbra have been observed exploiting another vulnerability, this time in Microsoft Outlook Web Access (OWA), to target U.S.…
  - (2026-07-30) [The Record] Cyber extortionists steal data from UK Department for Education
      Cybercriminals are attempting to extort Britain’s Department for Education (DfE) after compromising what the hackers said was more than 600,000 pieces of data allegedly including names, email addresses and phone numbers.

### USGS earthquakes (M4.5+, past day) — 10 new of 24 total
  - (2026-07-30) M 5.8 - Kermadec Islands region
      M5.8 · Kermadec Islands region · depth 10 km
  - (2026-07-30) M 5.4 - 201 km W of Abepura, Indonesia
      M5.4 · 201 km W of Abepura, Indonesia · depth 35 km
  - (2026-07-30) M 5.3 - 217 km SE of Kokopo, Papua New Guinea
      M5.3 · 217 km SE of Kokopo, Papua New Guinea · depth 10 km
  - (2026-07-30) M 5.0 - 8 km WNW of La Democracia, Guatemala
      M5.0 · 8 km WNW of La Democracia, Guatemala · depth 97.012 km
  - (2026-07-30) M 4.8 - 68 km SW of Mago, Russia
      M4.8 · 68 km SW of Mago, Russia · depth 13.668 km
  - (2026-07-30) M 4.8 - 24 km ESE of Qarnābād, Iran
      M4.8 · 24 km ESE of Qarnābād, Iran · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-30) LoL: Hanwha Life Esports vs Dplus KIA - Game 2 Winner
      yes price: 100% · 24h volume: $1,046,411 · resolves 2026-07-30
  - (2026-07-30) LoL: EDward Gaming vs Team WE - Game 1 Winner
      yes price: 0% · 24h volume: $1,030,863 · resolves 2026-07-30
  - (2026-07-30) LoL: DN SOOPers vs BNK FEARX - Game 2 Winner
      yes price: 0% · 24h volume: $1,019,264 · resolves 2026-07-30
  - (2026-07-30) LoL: Hanwha Life Esports vs Dplus KIA - Game 1 Winner
      yes price: 0% · 24h volume: $1,009,139 · resolves 2026-07-30
  - (2026-07-30) LoL: EDward Gaming vs Team WE (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $897,597 · resolves 2026-07-30
  - (2026-07-30) LoL: Hanwha Life Esports vs Dplus KIA (BO3) - LCK Round 3-4 Legend Group
      yes price: 36% · 24h volume: $894,952 · resolves 2026-07-30

### Court opinions of consequence (federal & state) — 6 new of 60 total
  - (2026-07-29) U.S. Court of Appeals, 5th Cir.: United States v. Hunter
  - (2026-07-29) Hawaii Supreme Court: Lupton v. Kardash
  - (2026-07-29) Hawaii Supreme Court: M.E. v. R.S.
  - (2026-07-29) Hawaii Supreme Court: M.E. v. R.S.
  - (2026-07-29) Hawaii Supreme Court: M.E. v. R.S.
  - (2026-07-27) U.S. Court of Appeals, 8th Cir.: United States v. Sterling Spotted Elk, Jr.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 35 total
  - (2026-07-30) MOVER ▼ Francoise Bettencourt Meyers & family — $96.04B ($-0.64B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-30) MOVER ▼ Amancio Ortega — $142.81B ($-0.59B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-30) MOVER ▲ Mukesh Ambani — $88.48B (+$0.18B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-30) MOVER ▲ Bernard Arnault & family — $145.18B (+$0.16B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-30) MOVER ▲ Gautam Adani — $84.09B (+$0.13B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-30) [Marginal Revolution] The Endangered Species Act Reduces Housing
      Max Tabarrok’s paper on the Endangered Species Act and housing (WP) has just been published in the Journal of Public Economics! It’s a clever paper: Max observed that the moment an animal is put on the endangered species…
  - (2026-07-30) [Marginal Revolution] An experiment for our schools
      Schools in at least three states will be equipped with drones this year that can zoom through halls, smash windows and pepper-spray active shooters if teachers report a threat. At least nine schools — three in Florida, f…
  - (2026-07-30) [Marginal Revolution] Forty interesting facts about Australia
      Australia was the richest country on earth, per capita, for decades. After the 1850s gold rush, up until the 1890s depression, Australia had the highest per capita income in the world. In 1850, probably only the United K…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=19, 14d-median=19; carrying terms: requires, security, directive, airworthiness, management, action, applicable, safety, standard, certain, proposing, final
- state_bills: today=203, 7d-median=128, 14d-median=128; carrying terms: requires, utilities, property, requiring, child, activities, action, require, regulatory, california, makes, penalties
- state_news: today=823, 7d-median=711, 14d-median=711; carrying terms: working, virginia, insurance, settlement, politics, residents, university, flood, surrounding, began, times, arizona
- local_news: today=219, 7d-median=228, 14d-median=228; carrying terms: close, officials, residents, vehicle, began, saportareport, times, appeared, media, causes, weather, found
- foreign_news: today=1023, 7d-median=1023, 14d-median=1023; carrying terms: brussels, protests, kingdom, settlement, tariffs, residents, restrictions, impose, flood, began, tipoff, child
- chinese_internal: today=313, 7d-median=276, 14d-median=276; carrying terms: caixin, market, people, china, google, chinese, global, giant, https, cbmiw, politics, cbmizkfvx
- russian_internal: today=1151, 7d-median=908, 14d-median=908; carrying terms: client, centcom, wildberries, research, laquo, times, street, novayagazeta, telegram, error, media, gazeta
- ukrainian_internal: today=122, 7d-median=136, 14d-median=136; carrying terms: operations, independent, energy, protests, intelligence, officials, security, behind, vladimir, restrictions, claimed, production
- ukraine_theater: today=553, 7d-median=553, 14d-median=553; carrying terms: anomaly, coverage, error, alerts, defenses, known, httperror, ukraine, token, campaign, polygons, daily
- paper_bets: today=142, 7d-median=138, 14d-median=138; carrying terms: comes, succeed, mamdani, virginia, performing, security, governance, earthquake, arizona, wisconsin, specified, miles
- weather: today=149, 7d-median=173, 14d-median=173; carrying terms: humidity, continues, messages, above, flood, hazardous, oxnard, changed, strong, santa, lying, disregard
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, latest, vixcls, energy, headline, dexjpus, cpiaucsl, cpilfesl, jtsjol, dexchus, walcl, rates
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, close, credit, range, treasury, bitcoin, equities, crypto, china, corporate, rates, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=122, 7d-median=119, 14d-median=119; carrying terms: operations, protests, energy, security, hamas, middle, university, usaspending, palestinian, schools, activities, actions
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, httperror, quiver, https, congresstrading, quantitative, error, client, quiverquant
- billionaires: today=35, 7d-median=35, 14d-median=35; carrying terms: tiktok, ortega, oracle, euronext, mexico, canada, yiming, source, china, amancio, family, warren
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, trade, delaware, appeals, supreme, california, international, court, robert, services, arizona, johnson
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, therapeutics
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, cortez, filing, johnson, senate, disbursements, committee, warner, jonathan, raised, trone, sherrod
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan, korea, china, world
- gdelt_gkg: today=50, 7d-median=47, 14d-median=47; carrying terms: trump, hezbollah, israel, english, mamdani, keywords, hormuz, israeli, graham, chinese, house, lindsey
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=18, 14d-median=18; carrying terms: france, canada, position, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: borne, globally, geographic, kingdom, affected, inconclusive, samples, continues, returning, mauritania, material, sylvatic
- cisa_kev: today=12, 7d-median=16, 14d-median=16; carrying terms: vendor, improper, product, fortinet, langflow, vulnerability, untrusted, command, management, authentication, sharepoint, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=272, 14d-median=272; carrying terms: bosnia, ethiopia, sweden, mexico, canada, philippines, monaco, orange, nicaragua, panama, thailand, italy
- usgs_quakes: today=24, 7d-median=23, 14d-median=23; carrying terms: islands, atlantic, south, depth, region, ridge, philippines, indonesia, mexico, guinea, papua, kermadec
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ethiopia, volume, minister, rates, meeting, interest, prime, price, resolves, abiebie, increase, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: benefit, conversable, https, economist, class, marginal, marginalrevolution, revolution, looking, quality, rather, underlying
- tech_news: today=50, 7d-median=57, 14d-median=57; carrying terms: bleepingcomputer, working, intelligence, security, models, operator, group, network, ransomware, computer, infrastructure, electricity
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: mariannette, baumgartner, howard, panetta, crawford, hamadeh, energy, risch, virginia, intelligence, insurance, sarah
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, either, market, markets, sufficient, unavailable, module, decision, paper, identify, claude, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*