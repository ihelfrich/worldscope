# WORLDSCOPE morning brief — 2026-07-30

## Headline
3446 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (737) · Russian Internal News (state + in-exile) (706) · Ukraine Theater (total-war monitoring) (396) · State-Level News (391) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (171) · Local News: St. Louis + Atlanta (167) · State Legislative Action (125) · Ukrainian Internal News (national + local Kyiv) (56) · IT, InfoSys & cybersecurity news (last 7 days) (43) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 737 new of 1022 total
  - (2026-07-30) [Global] US government map of Africa mislabels every country at global conference
  - (2026-07-30) [Global] Fifteen elephant deaths at Kenya park may be due to cyanide poisoning
  - (2026-07-30) [Global] Fifty-three days and counting: 93-year-old leader’s record absence fuels health speculation
  - (2026-07-30) [Global] A quarter of young Africans believe USAID cuts could be positive, survey finds
  - (2026-07-30) [Global] Death toll in Japan earthquake rises to 30 as aftershock and heat hamper rescue efforts
  - (2026-07-30) [Global] Australia news live: Australia sends firefighters to France as blazes rage; leaders gather for Garma festival

### Russian Internal News (state + in-exile) — 706 new of 1048 total
  - (2026-07-30) В испанскую Сеуту через границу с Марокко проникли две тысячи нелегальных мигрантов. Власти Испании направили в город армию | LEDE: Власти Испании объявили, что введут войска в город Сеута —] (ru: В и…
      Власти Испании объявили, что введут войска в город Сеута — испанский эксклав на севере Африки, граничащий с Марокко, для усиления безопасности на фоне миграционного кризиса.
  - (2026-07-30) Reuters: из-за атаки украинских дронов «Роснефть» остановила работу Рязанского НПЗ, снабжающего Москву | LEDE: Компания «Роснефть» приостановила работу Рязанского НПЗ, который 29 июля подвер] (ru: Reu…
      Компания «Роснефть» приостановила работу Рязанского НПЗ, который 29 июля подвергся атаке украинских беспилотников, пишет Reuters со ссылкой на источники.
  - (2026-07-30) Зеленский: удар по дому под Кривым Рогом, в результате которого погибла многодетная семья, был нанесен северокорейской ракетой | LEDE: Удар по Радушному, в результате которого погибли члены ] (ru: Зел…
      Удар по Радушному, в результате которого погибли члены многодетной семьи, российские военные нанесли северокорейской баллистической ракетой. Об этом заявил президент Украины Владимир Зеленский.
  - (2026-07-30) Россия объявила Павла Дурова террористом. Окей, а покупать Telegram Premium теперь опасно? . Нет, и даже сами власти это признают | LEDE: Оплата Telegram Premium не считается уголовным прест] (ru: Рос…
      Оплата Telegram Premium не считается уголовным преступлением (во всяком случае, пока), так как Росфинмониторинг внес в свой перечень Павла Дурова лично. В отношении самого мессенджера нет судебного решения о признании ег…
  - (2026-07-30) В Москве арестован миллиардер Валерий Кустов. Принадлежащая ему компания выпускает майонез «Слобода» и масло «Олейна». Но задержали его по делу о мошенничестве при производстве дронов | LEDE: <] (ru:…
      .
  - (2026-07-30) Все европейские сборные пригрозили бойкотировать ЧМ-2030 — из-за планов ФИФА продать часть прав на турнир частным инвесторам | LEDE: Футбольные федерации стран, входящих в УЕФА, анонсировали] (ru: Все…
      Футбольные федерации стран, входящих в УЕФА, анонсировали бойкот чемпионатов мира в знак протеста против планов ФИФА продать часть прав на турнир частным инвесторам.

### Ukraine Theater (total-war monitoring) — 396 new of 627 total
  - (2026-07-30) [FIRMS] thermal anomaly 52.807, 32.224 (FRP 0.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 0.85 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.849, 29.990 (FRP 1.09 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 1.09 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.846, 29.989 (FRP 5.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 5.08 MW
  - (2026-07-30) [FIRMS] thermal anomaly 52.304, 32.650 (FRP 0.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 0.28 MW
  - (2026-07-30) [FIRMS] thermal anomaly 51.893, 29.343 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 1.95 MW
  - (2026-07-30) [FIRMS] thermal anomaly 51.890, 29.336 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-30 0013Z, FRP 1.95 MW

### State-Level News — 391 new of 1045 total
  - (2026-07-30) [California] Governor Newsom deploys elite wildfire team to Washington State as western fires surge
      Source
  - (2026-07-30) [Connecticut] Nearly 18,900 CT children have lost SNAP benefits over past year
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2025/12/AP25336728008267-1024x682.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority…
  - (2026-07-30) [Connecticut] Insurance companies propose higher rates on CT health plans
      <img width="1024" height="671" src="https://ctmirror.org/wp-content/uploads/2026/01/AP133679160837-1024x671.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https:/…
  - (2026-07-30) [Connecticut] DeLauro: CT providers’ federal grants represent “amazing victory”
      <img width="683" height="1024" src="https://ctmirror.org/wp-content/uploads/2025/01/2025_0128_SR_GrantPauseConference560-683x1024.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="…
  - (2026-07-30) [Connecticut] Thank you, Hartford, for letting me teach. Now save your public schools
      <img width="1024" height="681" src="https://ctmirror.org/wp-content/uploads/2026/07/teachers-demonstrate-hartford-1024x681.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-07-30) [Connecticut] We all can act for CT’s greater good
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/AMERICA-LIBRARY-0701-JL-020-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" lo…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 171 new of 173 total
  - (2026-07-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-30) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 30 at 6:36PM CDT until July 30 at 7:30PM CDT by NWS North Platte NE
      SVRLBF The National Weather Service in North Platte has issued a * Severe Thunderstorm Warning for... Northeastern Lincoln County in southwestern Nebraska... Southeastern Logan County in west central Nebraska... Southwes…
  - (2026-07-30) [Moderate] Special Weather Statement: Special Weather Statement issued July 30 at 5:33PM MDT by NWS Pocatello ID
      At 532 PM MDT, Doppler radar was tracking a strong thunderstorm 11 miles north of Chilly Barton Flat, or 22 miles southeast of Challis, moving northeast at 25 mph. HAZARD...Wind gusts of 50 to 55 mph and pea size hail. S…
  - (2026-07-30) [Moderate] Special Weather Statement: Special Weather Statement issued July 30 at 5:29PM MDT by NWS Pueblo CO
      At 529 PM MDT, Doppler radar was tracking a strong thunderstorm 13 miles north of Crowley, or 33 miles east of Pueblo Airport, moving east at 25 mph. HAZARD...Heavy rain, wind gusts up to 50 mph and half inch hail. SOURC…
  - (2026-07-30) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 30 at 6:27PM CDT until July 30 at 7:15PM CDT by NWS Omaha/Valley NE
      SVROAX The National Weather Service in Omaha has issued a * Severe Thunderstorm Warning for... Northwestern Antelope County in northeastern Nebraska... Western Knox County in northeastern Nebraska... * Until 715 PM CDT.…
  - (2026-07-30) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 30 at 7:27PM EDT until July 30 at 7:45PM EDT by NWS Tallahassee FL
      At 727 PM EDT, a severe thunderstorm was located 17 miles west of Perry, moving southeast at 25 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, siding, and trees. Locations imp…

### Local News: St. Louis + Atlanta — 167 new of 182 total
  - (2026-07-30) [St. Louis] Photos: St. Louis Supper Club at Great Heart Brewing Co.
      On July 28, 2026, St. Louis Magazine hosted our fifth St. Louis Supper Club, presented by ReeceNichols. The secret location: Great Heart Brewing Co. SLM dining editors George Mahe and Cheryl Baehr carefully selected this…
  - (2026-07-30) [St. Louis] How Nicky Slices founder Nick Williams turned an Instagram pizza side hustle into one of St. Louis’ hottest pizzerias
      In the dark and uncertain days of mid-2020, Nick Williams created a phenomenon that gave people a little slice of joy when it was in short supply in the form of his Instagram-based take-and-bake pizza business, Nicky Sli…
  - (2026-07-30) [St. Louis] A St. Louisan’s guide to the August 2026 ballot issues
      St. Louisans who head to the polls on or before the August 4 primary election will be treated to a ballot-measure bonanza. The issues below are, to us, the most consequential. AMENDMENT 1 What it would do: Renew for anot…
  - (2026-07-30) [St. Louis] Great Rivers Greenway will unveil plans for more than 60 artworks along the Brickline Greenway at CAM Art Party
      Great Rivers Greenway is currently constructing the Brickline Greenway, which, once completed, will connect 14 neighborhoods and four parks. One of the project’s most significant features is the Northern Connector, a two…
  - (2026-07-30) [St. Louis] Film screenings to catch this month
      As we continue through the true doldrums of Missouri summertime, local theaters have plenty of excellent reasons to stay inside with their repertory programming. The Hi-Pointe Theatre has you covered with masterpieces ac…
  - (2026-07-30) [St. Louis] Shock poll shows Zimmerman on top in county executive race
      A poll taken of St. Louis County voters this month shows County Assessor Jake Zimmerman with a nine point lead over state Senator Brian Williams (D-University City) in the Democratic primary race for county executive—a s…

### State Legislative Action — 125 new of 165 total
  - (2026-07-30) [California AB 69] FAIR Plan policy notices and renewals.
      The California FAIR Plan Association is a joint reinsurance association in which all insurers licensed to write basic property insurance participate to administer a program for the equitable apportionment of basic proper…
  - (2026-07-30) [California ACR 126] Relative to the Captain Vidar Anderson Memorial Highway.
      This measure would designate a specified portion of State Highway Route 395 in the County of Mono as the Captain Vidar Anderson Memorial Highway. The measure would request that the Department of Transportation determine…
  - (2026-07-30) [California SB 594] Short-Term Rental Facilitator Act of 2026.
      Existing law, the Short-Term Rental Facilitator Act of 2025, authorizes a local agency to enact an ordinance to require a short-term rental facilitator, as defined, to report, in the form and manner prescribed by the loc…
  - (2026-07-30) [California AB 1626] Interscholastic athletics: youth sports: coaches: behavioral and mental health training.
      Existing law requires the governing board of each school district to have general control of, and be responsible for, all aspects of the interscholastic athletic policies, programs, and activities in its school district,…
  - (2026-07-30) [California SB 930] Student Test Taker Privacy Protection Act: end-to-end encryption.
      Existing law, the California Consumer Privacy Act of 2018 (CCPA) , imposes various obligations on businesses with respect to personal information, as defined. The California Privacy Rights Act of 2020, approved by the vo…
  - (2026-07-30) [California SB 569] Bikeways: reversions and modifications.
      Existing law grants the legislative body of a city certain powers with respect to city streets and highways, including the power to construct and maintain those streets and highways. Existing law grants the board of supe…

### Ukrainian Internal News (national + local Kyiv) — 56 new of 136 total
  - (2026-07-31) Окупанти перекрили Кримський міст, у Севастополі заявили про роботу ППО | LEDE: Вночі 31 липня в окупованому Севастополі заявили про роботу ППО.] (uk: Окупанти перекрили Кримський міст, у Севастополі…
      Вночі 31 липня в окупованому Севастополі заявили про роботу ППО.
  - (2026-07-31) Трамп заявив про досягнення "історичної угоди" про повне роззброєння ХАМАС у Газі | LEDE: Трамп заявив, що досягнуто угоди про повне роззброєння ХАМАС у Газі.] (uk: Трамп заявив про досягнення "істори…
      Трамп заявив, що досягнуто угоди про повне роззброєння ХАМАС у Газі.
  - (2026-07-31) Під час атаки на Київ російська ракета зруйнувала американський завод з виготовлення дронів – ЗМІ | LEDE: За даними ЗМІ, під час атаки на Київ російська ракета зруйнувала американський завод з ] (uk:…
      За даними ЗМІ, під час атаки на Київ російська ракета зруйнувала американський завод з виготовлення дронів.
  - (2026-07-31) Генштаб: 226 бойових зіткнень за добу, найгарячіше – на Костянтинівському і Покровському напрямках | LEDE: У Генштабі повідомили про кількість боїв і найбільш гарячі напрямки на фронті за четве] (uk:…
      У Генштабі повідомили про кількість боїв і найбільш гарячі напрямки на фронті за четвер, 30 липня.
  - (2026-07-31) Білецький в інтерв'ю блогерці Лумер відповів, чи планує балотуватись у президенти | LEDE: Командир Третього армійського корпусу бригадний генерал Андрій Білецький каже, що до закінчення війни з] (uk:…
      Командир Третього армійського корпусу бригадний генерал Андрій Білецький каже, що до закінчення війни з Росією не думає про балотування в президенти України.
  - (2026-07-30) Президент Туреччини прокоментував спроби відродити переговори щодо Кіпру | LEDE: ] (uk: Президент Туреччини прокоментував спроби відродити переговори щодо Кіпру)

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 57 total
  - (2026-07-30) [Krebs on Security] Read This Before You Buy That TV Streaming Stick
      Security experts have been sounding the alarm for years about the risks of using generic TV boxes that promise unlimited content streaming for a one-time fee, warning that they secretly rent the user's Internet connectio…
  - (2026-07-30) [BleepingComputer] South Korea fines telco giant KT $39 million for customer data breach
      South Korea's Personal Information Protection Commission (PIPC) has fined telecommunications giant KT Corporation KRW 53.979 billion ($39 million) over data protection violations. [...]
  - (2026-07-30) [BleepingComputer] JetBrains warns of critical TeamCity remote code execution flaw
      JetBrains is warning of a critical authentication bypass vulnerability affecting TeamCity On-Premises that could be exploited to achieve remote code execution. [...]
  - (2026-07-30) [BleepingComputer] Amazon links Debug, Chalk NPM supply-chain attacks to North Korean hackers
      Amazon linked multiple high-profile open-source software supply chain attacks targeting the Node Package Manager (npm) ecosystem to North Korean hackers. [...]
  - (2026-07-30) [BleepingComputer] VMware fixes three critical flaws allowing auth bypass, VM escapes
      Broadcom has released security updates to fix five vulnerabilities in VMware vCenter, ESX, Workstation, and Fusion, including three critical flaws that allow attackers to bypass authentication, execute arbitrary code, or…
  - (2026-07-30) [BleepingComputer] Google says AI helped Chrome fix 1,072 security bugs in two releases
      Google says artificial intelligence is dramatically increasing the number of security vulnerabilities it can find and fix in Chrome, with more than 1,000 security bugs patched across the browser's two most recent release…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-30) [Johnson Natalia] Form 4 (Reporting)
      filed 2026-07-30 23:27 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001726283-26-000004 Size: 9 KB
  - (2026-07-30) [Public Storage] Form 4 (Issuer)
      filed 2026-07-30 23:27 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001726283-26-000004 Size: 9 KB
  - (2026-07-30) [GRATZ JAY M] Form 4 (Reporting)
      filed 2026-07-30 23:26 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001069878-26-000054 Size: 4 KB
  - (2026-07-30) [TREX CO INC] Form 4 (Issuer)
      filed 2026-07-30 23:26 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001069878-26-000054 Size: 4 KB
  - (2026-07-30) [Cline James E] Form 4 (Reporting)
      filed 2026-07-30 23:19 UTC · role: Reporting — Filed: 2026-07-30 AccNo: 0001069878-26-000050 Size: 4 KB
  - (2026-07-30) [TREX CO INC] Form 4 (Issuer)
      filed 2026-07-30 23:19 UTC · role: Issuer — Filed: 2026-07-30 AccNo: 0001069878-26-000050 Size: 4 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-30) [United States] Valley Center man dies while in Sedgwick County custody
      domain: kwch.com · language: English · tone:
  - (2026-07-30) [United States] Japan Reports 34 Deaths After Earthquake As Extreme Heat Threatens Survivors
      domain: wbap.com · language: English · tone:
  - (2026-07-30) [United States] Is Dos Reales in Rockford Permanently Closed ?
      domain: 967theeagle.net · language: English · tone:
  - (2026-07-30) [United States] No one lasts forever , but Charli XCX is making a legacy in Music , Fashion , Film - The Independent Florida Alligator
      domain: alligator.org · language: English · tone:
  - (2026-07-30) [United States] NM AG sues for return of teen forced to cross border by foster care
      domain: pilotonline.com · language: English · tone:
  - (2026-07-30) [China] Why an Aging Power Grid Is Fueling a New ETF Bet
      domain: etftrends.com · language: English · tone:

### Court opinions of consequence (federal & state) — 31 new of 60 total
  - (2026-07-30) U.S. Court of Appeals, 1st Cir.: Kim v. Blanche
  - (2026-07-30) U.S. Court of Appeals, 1st Cir.: North End Chamber of Commerce, Inc. v. City of Boston
  - (2026-07-30) U.S. Court of Appeals, 1st Cir.: United States v. Gonzalez
  - (2026-07-30) U.S. Court of Appeals, 3rd Cir.: Anash Inc v. Borough of Kingston
  - (2026-07-30) U.S. Court of Appeals, Federal Cir.: Ildico Inc. v. United States
  - (2026-07-30) U.S. Court of Appeals, Federal Cir.: Qoye v. United States

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 26 new of 26 total
  - (2026-07-30) Airworthiness Directives; Pilatus Aircraft Ltd. Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Pilatus Aircraft Ltd. (Pilatus) Model PC-12/47E airplanes. This AD was prompted by a report that, during an engine start on the ground, the airplane batt…
  - (2026-07-30) Airworthiness Directives; Stemme GmbH Gliders
      The FAA is adopting a new airworthiness directive (AD) for all Stemme GmbH (Stemme) Model Stemme S 12 gliders. This AD was prompted by reports of fuel leaking around certain copper sealing rings within the fuel system. T…
  - (2026-07-30) Civil Money Penalty for Actions in Contempt of an Immigration Judge's Proper Exercise of Authority
      This notice of proposed rulemaking ("NPRM") would implement a provision of the Immigration and Nationality Act ("INA" or "the Act") that authorizes Immigration Judges, under regulations prescribed by the Attorney General…
  - (2026-07-30) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A330-200 and A330-300 series airplanes modified by a certain supplemental type certificate (STC). This AD was prompted by a finding that…
  - (2026-07-30) Exchange Visitor Program-Termination of Program Participation, Extension of Program and Reinstatement to Valid Program Status
      The Department of State's (Department's) Bureau of Educational and Cultural Affairs administers the Exchange Visitor Program, as set forth at 22 CFR part 62, wherein exchange visitors on educational and cultural exchange…
  - (2026-07-30) Medicare Program; Updates to the Master List of Items Potentially Subject to Face-to-Face Encounter and Written Order Prior to Delivery and/or Prior Authorization Requirements; Updates to the Required…
      This document announces updates to the Healthcare Common Procedure Coding System (HCPCS) codes on the Master List. It also announces updates to the HCPCS codes on the Required Face-to-Face Encounter and Written Order Pri…

### Paper Trading Scorecard — 25 new of 145 total
  - (2026-07-30) [Polymarket] Will the United States send warships through the Strait of Hormuz by July 31, 2026?
      This market will resolve to "Yes" if a national government, its military, or a broad consensus of credible reporting confirms that the listed country's warships transited through the Strait of Hormuz between market creat…
  - (2026-07-30) [Polymarket] Will Masoud Pezeshkian be head of state in Iran end of 2026?
      This market will resolve to the individual who de facto holds and exercises the powers of the head of state of the Islamic Republic of Iran on December 31, 2026 at 12:00 PM ET. For the purposes of this market, “de facto…
  - (2026-07-30) [Polymarket] Will Erling Haaland win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-07-30) [Polymarket] Extended FDV above $500M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Extended's token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token must be acti…
  - (2026-07-30) [Polymarket] Will Elon Musk post 500+ tweets from July 24 to July 31, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 24 12:00 PM ET to July 31, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-30) [Manifold] Anthony Fauci deceased before January 1st 2028

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-30) [Russia oil sanctions perimeter · keywords] Russian strikes across Ukraine kill 10 and a missile falls in Poland
      kedm.org · English · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · keywords] Russian strikes across Ukraine kill 10 and a missile falls in Poland
      wcsufm.org · English · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · keywords] Black Sea conflict grain price bounce may only be temporary | North Queensland Register
      northqueenslandregister.com.au · English · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · keywords] Russian strikes across Ukraine kill 10 and a missile falls in Poland
      kawc.org · English · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · keywords] Black Sea conflict grain price bounce may only be temporary | Stock & Land
      stockandland.com.au · English · tone NA
  - (2026-07-30) [Russia oil sanctions perimeter · keywords] Lindsey Graham Russia Sanctions Bill Is Getting Closer to Passage
      foreignpolicy.com · English · tone NA

### World News (by country, top stories) — 24 new of 24 total
  - (2026-07-30) [China] 警方油麻地旺角放蛇行動 兩名白牌車司機遭票控
      singtaousa.com · English
  - (2026-07-30) [China] Why an Aging Power Grid Is Fueling a New ETF Bet
      etftrends.com · English
  - (2026-07-30) [China] Russia used North Korean missile in deadly strike on Ukraine village , Zelensky says
      scmp.com · English
  - (2026-07-30) [China] 希臘雅典驚傳行李箱藏屍案 38歲蘇格蘭女子死因待查
      singtaousa.com · English
  - (2026-07-30) [China] 看看这帮家伙 THIS HAS TO BE THE STORY OF 2026 - chyang98发表于 财富智汇 - 论坛
      bbs.wenxuecity.com · English
  - (2026-07-30) [China] 羅雲熙演唱會 最低票價僅13元 - 星島日報
      singtaousa.com · English

### USGS earthquakes (M4.5+, past day) — 20 new of 20 total
  - (2026-07-30) M 5.9 - 247 km NNE of Colonia, Micronesia
      M5.9 · 247 km NNE of Colonia, Micronesia · depth 34.505 km
  - (2026-07-30) M 5.8 - Kermadec Islands region
      M5.8 · Kermadec Islands region · depth 10 km
  - (2026-07-30) M 5.4 - 201 km W of Abepura, Indonesia
      M5.4 · 201 km W of Abepura, Indonesia · depth 35 km
  - (2026-07-30) M 5.3 - 217 km SE of Kokopo, Papua New Guinea
      M5.3 · 217 km SE of Kokopo, Papua New Guinea · depth 10 km
  - (2026-07-30) M 5.2 - Kermadec Islands region
      M5.2 · Kermadec Islands region · depth 46.02 km
  - (2026-07-30) M 5.1 - 67 km E of Petropavlovsk-Kamchatsky, Russia
      M5.1 · 67 km E of Petropavlovsk-Kamchatsky, Russia · depth 63.921 km

### Chinese Internal News — 16 new of 47 total
  - (2026-07-30) Hong Kong home price rally set to cool after strongest first half in 7 years: analysts
  - (2026-07-30) The GBA is optimised for AI to achieve its full potential
  - (2026-07-30) Hongkong Land acquires Singapore’s Wheelock Place in US$900m deal
  - (2026-07-30) ByteDance’s US$4b projected AI revenue tops China as it restructures office tool Lark
  - (2026-07-30) Ant Group spin-offs pursue independent growth with strategic capital moves
  - (2026-07-30) Chinese motorcycle exports roar to record highs amid tech gains, upmarket push

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 87 total
  - (2026-07-30) [USASpending] $42,571,358,868 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-07-30) [USASpending] $35,040,435,874 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-07-30) [USASpending] $34,404,438,770 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS
  - (2026-07-30) [USASpending] $17,573,487,505 → HONEYWELL FEDERAL MANUFACTURING & TECHNOLOGIES, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SEC
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SECURITY CAMPUS -- CONTRACT NO. DE-NA0002839
  - (2026-07-30) [USASpending] $7,660,799,537 → MISSION SUPPORT & TEST SERVICES LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003624 TO THE MISSION S
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003624 TO THE MISSION SUPPORT AND TEST SERVICES LLC (MSTS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY NATIONAL NUCLEAR SEC…
  - (2026-07-30) [USASpending] $3,544,434,459 → PANTEXAS DETERRENCE, LLC: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION
      Agency: Department of Energy. Description: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION OF THE PANTEX PLANT

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-07-30) Mubadala Citi DC Open: Terence Atmane vs Alejandro Tabilo
      yes price: 0% · 24h volume: $918,616 · resolves 2026-08-05
  - (2026-07-30) Will Donald Trump publicly insult Vladimir Putin by July 31, 2026?
      yes price: 3% · 24h volume: $708,847 · resolves 2026-07-31
  - (2026-07-30) Will NVIDIA be the largest company in the world by market cap on July 31?
      yes price: 71% · 24h volume: $591,682 · resolves 2026-07-31
  - (2026-07-30) San Francisco Giants vs. San Diego Padres
      yes price: 40% · 24h volume: $570,194 · resolves 2026-08-07
  - (2026-07-30) Pittsburgh Pirates vs. Cincinnati Reds: O/U 9.5
      yes price: 36% · 24h volume: $549,485 · resolves 2026-07-30
  - (2026-07-30) Will the Fed decrease interest rates by 25 bps after the September 2026 meeting?
      yes price: 3% · 24h volume: $491,360 · resolves 2026-09-16

### GDACS — global disaster alerts — 9 new of 287 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-07-30) [Green] Earthquake in Kermadec Islands Region
      Earthquake · Green alert · Kermadec Islands Region · Magnitude 5.8M, Depth:10km
  - (2026-07-30) [Green] Earthquake in Kermadec Islands Region
      Earthquake · Green alert · Kermadec Islands Region · Magnitude 5.8M, Depth:10km
  - (2026-07-30) [Green] Earthquake in Micronesia
      Earthquake · Green alert · Micronesia · Magnitude 5.9M, Depth:34.505km

### Government & military aircraft airborne (OpenSky) — 8 new of 9 total
  - (2026-07-30) CFC01 (Canada)
      icao24: c2b373 · position: (45.3001, -75.7004) · alt: 281m · 252km/h
  - (2026-07-30) PAT613 (United States)
      icao24: adfe8f · position: (43.5488, -116.1811) · alt: 1028m · 215km/h
  - (2026-07-30) PAT483 (United States)
      icao24: adfe99 · position: (30.5211, -89.4033) · alt: 7620m · 420km/h
  - (2026-07-30) PAT24 (United States)
      icao24: ae5369 · position: (38.722, -77.1821) · alt: 106m · 69km/h
  - (2026-07-30) JAF7GN (Belgium)
      icao24: 44d1a2 · position: (45.8722, -0.4846) · alt: 12192m · 935km/h
  - (2026-07-30) NCR602 (United States)
      icao24: acfc26 · position: (36.769, 126.6184) · alt: 5311m · 798km/h

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 40 total
  - (2026-07-30) MOVER ▲ Steve Ballmer — $141.09B (+$15.31B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-07-30) MOVER ▼ Rob Walton & family — $130.61B ($-2.86B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-07-30) MOVER ▼ Jim Walton & family — $127.92B ($-2.85B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-07-30) MOVER ▼ Alice Walton — $119.08B ($-2.79B since yesterday)
      United States · Fashion & Retail · source: Walmart

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-30) [Marginal Revolution] The Anatomy of Cyber Risk
      This paper uses computational linguistics to introduce a novel measure of firm-level cyber risk exposure based on the quarterly earnings calls of listed firms. Our measure covers more than 14,000 firms from over 90 count…
  - (2026-07-30) [Marginal Revolution] Thursday assorted links
      1. Joshua Rothman on lookism. 2. Young adults are using AI to manage their social media feeds (WSJ). 3. What predicts an NBA Achilles tear? 4. LLM data set on changing cultural trends over the centuries. 5. Xi’an Famous…
  - (2026-07-30) [Marginal Revolution] The Endangered Species Act Reduces Housing
      Max Tabarrok’s paper on the Endangered Species Act and housing (WP) has just been published in the Journal of Public Economics! It’s a clever paper: Max observed that the moment an animal is put on the endangered species…
  - (2026-07-30) [Conversable Economist] The EU Green Deal: How’s It Going?
      Back in the pre-pandemic year of 2019, the European Union passed the European Green Deal, setting a goal of having the EU be climate-neutral in its emissions by 2050. Here in 2026, 20% of that 30-year time window has now…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=19, 14d-median=19; carrying terms: safety, certain, model, provide, management, special, revising, directive, published, national, standard, proposes
- state_bills: today=165, 7d-median=128, 14d-median=128; carrying terms: rights, address, income, defined, protection, years, budget, abuse, programs, require, legal, another
- state_news: today=1045, 7d-median=711, 14d-median=711; carrying terms: streets, rights, cellphone, arrest, smoke, number, measles, short, companies, provisional, interior, programs
- local_news: today=182, 7d-median=228, 14d-median=228; carrying terms: arrest, driver, content, inside, years, across, comes, another, sheriff, missing, office, station
- foreign_news: today=1022, 7d-median=1022, 14d-median=1022; carrying terms: worldbank, platforms, remember, promise, devoured, streets, rights, address, establishment, metric, arrest, australian
- chinese_internal: today=47, 7d-median=265, 14d-median=265; carrying terms: people, global, chinese, https, google, giant, caixin, market, china, firms, demand, sources
- russian_internal: today=1048, 7d-median=908, 14d-median=908; carrying terms: novayagazeta, novaya, laquo, openai, telegram, found, gazeta, error, wildberries, https, title, axios
- ukrainian_internal: today=136, 7d-median=136, 14d-median=136; carrying terms: military, president, lawmakers, allegations, years, across, intelligence, comes, poland, interests, ukrinform, france
- ukraine_theater: today=627, 7d-median=586, 14d-median=586; carrying terms: active, known, snapshot, acquired, cartography, deepstatemap, httperror, maintained, firms, anomaly, polygon, error
- paper_bets: today=145, 7d-median=138, 14d-median=138; carrying terms: named, russell, launches, leader, refers, netanyahu, president, alphabetically, michigan, lesswrong, fifty, official
- weather: today=173, 7d-median=173, 14d-median=173; carrying terms: currents, return, damage, mountains, afddtx, scattered, waters, lightning, afdhgx, includes, lincoln, corridor
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, indicator, walcl, recession, funds, inflation, payems, latest, effective, jtsjol, cpiaucsl, supply
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, rates, futures, crude, china, yield, crypto, large, russell, treasury, silver, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=87, 7d-median=117, 14d-median=117; carrying terms: support, military, junior, leland, eastern, authorities, illegal, rights, russia, armed, boeing, republic
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, unauthorized, https, quiverquant, quiver, error, congresstrading, httperror, quantitative
- billionaires: today=40, 7d-median=35, 14d-median=35; carrying terms: nasdaq, spacex, trading, bloomberg, cryptocurrency, francoise, walmart, holdings, tesla, steve, discount, carlos
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, robert, appeals, delaware, supreme, california, international, blanche, services, trade, johnson, state
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, therapeutics, daniel
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: elect, house, ocasio, ossoff, pinkston, lindsey, disbursements, krishnamoorthi, trone, robert, cooper, receipts
- gdelt_regions: today=24, 7d-median=12, 14d-median=12; carrying terms: english, japan, china, korea
- gdelt_gkg: today=25, 7d-median=36, 14d-median=36; carrying terms: english, lindsey, russia, keywords, sanctions, perimeter, graham
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: police, english, language, domain, found, across, india
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=9, 7d-median=15, 14d-median=15; carrying terms: canada, position, belgium, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: support, known, identified, negative, eastern, sustained, division, recommendations, authorities, onboard, genetically, bulape
- cisa_kev: today=12, 7d-median=16, 14d-median=16; carrying terms: sharepoint, fortinet, improper, authentication, control, microsoft, injection, management, product, deserialization, langflow, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=287, 7d-median=286, 14d-median=286; carrying terms: maximum, belarus, albania, macedonia, flood, serbia, russia, impact, tropical, colombia, canada, papua
- usgs_quakes: today=20, 7d-median=23, 14d-median=23; carrying terms: depth, region, islands, ridge, indonesia, mexico, papua, guinea, japan, abepura, kermadec, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, price, prime, interest, meeting, minister, volume, ethiopia, resolves, abiebie, adanech, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, marginal, benefit, marginalrevolution, https, conversable, revolution, economist, assorted, looking, quality, links
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: campaign, edition, openai, companies, attackers, intelligence, users, weekday, cybersecurity, model, going, leadership
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: marie, nicholas, pelosi, amodei, letlow, waters, anomaly, sotomayor, mcgovern, salud, charles, nicole
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, consensus, identify, markets, claude, decision, either, evidence, sufficient, today, module, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*