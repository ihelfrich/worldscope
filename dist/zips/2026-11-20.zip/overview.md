# WORLDSCOPE morning brief — 2026-11-20

## Headline
3860 new items across 29 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (879) · Russian Internal News (state + in-exile) (700) · State-Level News (392) · World leaders & government officials (324) · Chinese Internal News (263) · Local News: St. Louis + Atlanta (208) · GDELT GKG — themes / entities / watch areas (138) · State Legislative Action (137) · U.S. Weather + Severe / Climate Outlooks (134) · Ukraine Theater (total-war monitoring) (110) · World News (by country, top stories) (103) · Ukrainian Internal News (national + local Kyiv) (77)

## What changed today
### International News + Multilateral Institutions — 879 new of 1071 total
  - (2026-11-20) [India] Padmaja Venugopal quits BJP, cites inability to align with party's ideology in Keralam
  - (2026-11-20) [India] Manipur militant killed in encounter with security forces in Imphal West
  - (2026-11-20) [India] CJI Surya Kant turns down plea for recall hearing on CEC law before judge’s retirement
  - (2026-11-20) [India] Uttar Pradesh CM Yogi Adityanath’s mother Savitri Devi dies at 91 in Uttarakhand
  - (2026-11-20) [India] Nepal PM Balen Shah to visit India on November 22–23
  - (2026-11-20) [India] CBI brings back man accused of exploiting 14 women on false marriage promises from UAE

### Russian Internal News (state + in-exile) — 700 new of 1092 total
  - (2026-11-20) В зоопарке Цинциннати умерла Фиона — самый известный бегемот в мире. Она проглотила шапку одного из посетителей, случайно упавшую в вольер | LEDE: В зоопарке Цинциннати в штате Огайо умерла ] (ru: В з…
      В зоопарке Цинциннати в штате Огайо умерла Фиона — девятилетняя самка бегемота и звезда социальных сетей, у которой были тысячи фанатов по всему миру.
  - (2026-11-20) Танкеры с российским дизелем, отправленные в США в рамках сделки Трампа и Путина, прибыли в Бразилию | LEDE: Танкеры с российским топливом, отправленные в США в рамках дизельной сделки, приб] (ru: Тан…
      Танкеры с российским топливом, отправленные в США в рамках дизельной сделки, прибыли в Бразилию, пишет The Maritime Executive. В американские порты ни один из них так и не зашел, отмечает издание.
  - (2026-11-20) Умер музыкант Герберт Моралес — основатель группы Jah Division | LEDE: Умер регги-музыкант и основатель российской группы Jah Division Герберт (Гера) Моралес. ] (ru: Умер музыкант Герберт Моралес — ос…
      Умер регги-музыкант и основатель российской группы Jah Division Герберт (Гера) Моралес.
  - (2026-11-20) Украинские дроны атаковали завод по производству удобрений (и компонентов для взрывчатки) в Смоленской области | LEDE: Украинские дроны в ночь на 20 ноября нанесли удар по химическому заводу] (ru: Укр…
      Украинские дроны в ночь на 20 ноября нанесли удар по химическому заводу в городе Дорогобуж Смоленской области.
  - (2026-11-20) Россия нанесла удар по Киеву. Повреждены мосты через Днепр, погибли три человека | LEDE: Российские войска в ночь на 20 ноября атаковали Киев ракетами и дронами. Целями ударов были объекты к] (ru: Рос…
      Российские войска в ночь на 20 ноября атаковали Киев ракетами и дронами. Целями ударов были объекты критической инфраструктуры и мосты через Днепр, сообщил мэр города Виталий Кличко.
  - (2026-11-20) Власти продолжают заманивать россиян на войну — в обмен на контракт с Минобороны им разрешили оставлять за собой дорогое имущество при банкротстве. А кто заплатит за чужие долги? И увеличит ли ] (ru:…
      Правительство РФ внесло в Госдуму законопроект, который позволит новым контрактникам, ушедшим на войну с Украиной, сохранить имущество общей стоимостью до 10 миллионов рублей при банкротстве.

### State-Level News — 392 new of 756 total
  - (2026-11-20) [California] Governor Newsom announced appointments 11.19.2026
      Source
  - (2026-11-20) [California] What they are saying: Leaders from across the country celebrate Governor Newsom’s nation-leading AI framework
      Source
  - (2026-11-19) [California] Claim your cash: Millions in CalKIDS scholarships available for community college students
      Source
  - (2026-11-19) [Alabama] Governor Ivey Announces Alabama’s Mobile River Bridge Financing Named The Bond Buyer’s 2026 Southeast Deal of the Year
      MONTGOMERY – Governor Kay Ivey on Thursday announced that financing for the Mobile River Bridge and Bayway Project has been named Southeast Deal of the Year by The Bond Buyer, one of the municipal finance industry’s lead…
  - (2026-11-19) [Alabama] Federal indictment accuses state Rep. Patrick Sellers of fraud involving more than $240,000
  - (2026-11-19) [Alabama] Tuberville names John Mazyck finance director, CFO

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 263 new of 336 total
  - (2026-11-19) Analysis: Nvidia CEO’s Exit, U.S. Chip Rules Leave China’s Tech Giants Reeling - Caixin Global
      Analysis: Nvidia CEO’s Exit, U.S. Chip Rules Leave China’s Tech Giants Reeling Caixin Global
  - (2026-11-19) China’s Xi Pledges $20 Million for APEC Cooperation - Caixin Global
      China’s Xi Pledges $20 Million for APEC Cooperation Caixin Global
  - (2026-11-20) Chinese Carmakers Tighten Grip on Overseas Sales Channels - Caixin Global
      Chinese Carmakers Tighten Grip on Overseas Sales Channels Caixin Global
  - (2026-11-19) DeepSeek Closes 100 Billion Yuan Funding Round - Caixin Global
      DeepSeek Closes 100 Billion Yuan Funding Round Caixin Global
  - (2026-11-19) Xi, Trump Agree to Draw Up Plan for Stable China-U.S. Ties - Caixin Global
      Xi, Trump Agree to Draw Up Plan for Stable China-U.S. Ties Caixin Global
  - (2026-11-19) China’s Inbound Tourism Has Room to Grow, Trip.com CEO Says - Caixin Global
      China’s Inbound Tourism Has Room to Grow, Trip.com CEO Says Caixin Global

### Local News: St. Louis + Atlanta — 208 new of 250 total
  - (2026-11-19) [St. Louis] Holiday pop-up bars in St. Louis
      The concept began in New York’s East Village, when Greg Boehm took a hiatus from building a permanent bar to open Miracle, a 30-day holiday-themed pop-up featuring festive specialty cocktails. The idea took off from ther…
  - (2026-11-19) [St. Louis] St. Charles faces a decision on space museum’s relocation
      A long-discussed plan to bring a space museum to St. Charles may be getting closer to liftoff. But first, the city has to figure out how to—and if it really wants to—pay for it. St. Charles Mayor Dan Borgmeyer this week…
  - (2026-11-19) [St. Louis] The Upstairs Lounge gets its due in Counterpublic oral history project
      When Los Angeles–based artist and oral historian Alan Nakagawa was first invited to St. Louis to participate in Counterpublic’s triennial arts exhibition, he had a vague notion of pursuing something related to Tina Turne…
  - (2026-11-19) [St. Louis] Modern Brewery to open in former Session Taco space in Kirkwood
      The tacos may be gone, but the brewery hookups are still there. Modern Brewery plans to put them back to work at the former Session Taco (105 E. Jefferson) in downtown Kirkwood, turning the 12,000-square-foot space into…
  - (2026-11-19) [St. Louis] Suit against Stange Law went unnoticed—until the firm sought to quash coverage
      Were it not for the lawsuit against Jim Onder of OnderLaw, it’s possible no one would have noticed a different suit against the Stange Law Firm. But then, because of Onder, someone did notice the Stange lawsuit. And then…
  - (2026-11-19) [St. Louis] Brick x Brick aims to get Black St. Louisans into real estate development
      Carla Reid looks at North City and North County and wants more: more energy, more investment, more “responsible” real-estate development, more of a homegrown ecosystem that will counteract the buying-and-holding of out-o…

### GDELT GKG — themes / entities / watch areas — 138 new of 138 total
  - (2026-11-20) [Russia oil sanctions perimeter · themes] Russia open to Nato-like security guarantees for Ukraine: US envoy
      business-standard.com · English · tone -3.06406685236769 · 4 other outlets
  - (2026-11-20) [Russia oil sanctions perimeter · themes] Trump tells Europe to defund Ukraine hours after hailing his 'friend' Putin at historic summit
      independent.co.uk · English · tone -2.36220472440945
  - (2026-11-20) [Russia oil sanctions perimeter · themes] Ukraine says it hit 2 Russian oil refineries as Zelenskyy hails domestically made weapons
      whec.com · English · tone -6.16197183098592
  - (2026-11-20) [Russia oil sanctions perimeter · near] Kushner says he believes Russia is 'comfortable' with NATO-like security guarantees for Ukraine | International
      santamariatimes.com · English · tone -2.15410107705054 · 38 other outlets
  - (2026-11-20) [Russia oil sanctions perimeter · near] Trump-Xi-Putin meeting delivers peace declaration but no action on Ukraine - 20-Nov-2026
      nzcity.co.nz · English · tone -2.17096336499322 · 30 other outlets
  - (2026-11-20) [Russia oil sanctions perimeter · near] Ukraine-Russia war latest: Putin launches missiles at three Kyiv bridges after vowing revenge for Crimea attack
      independent.co.uk · English · tone -0.697836706210746 · 8 other outlets

### State Legislative Action — 137 new of 164 total
  - (2026-11-20) [Alaska HB 316] An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
      An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
  - (2026-11-20) [Alaska HB 350] An Act establishing an income tax on certain entities in the state; and providing for an effective date.
      An Act establishing an income tax on certain entities in the state; and providing for an effective date.
  - (2026-11-20) [Alaska SB 83] An Act relating to health care insurance; relating to insurance reimbursement for health care services provided through telehealth; relating to telehealth; providing for an effective da…
      An Act relating to health care insurance; relating to insurance reimbursement for health care services provided through telehealth; relating to telehealth; providing for an effective date by repealing the effective date…
  - (2026-11-20) [Alaska HB 266] An Act relating to the transfer of big game hunting permits; and providing for an effective date.
      An Act relating to the transfer of big game hunting permits; and providing for an effective date.
  - (2026-11-20) [Alaska HB 335] An Act relating to veterinarians and veterinarian technicians; establishing a pet and service animal disaster emergency plan; relating to the Alaska State Emergency Response Commission…
      An Act relating to veterinarians and veterinarian technicians; establishing a pet and service animal disaster emergency plan; relating to the Alaska State Emergency Response Commission; and relating to local emergency pl…
  - (2026-11-20) [Alaska HB 302] An Act relating to travel insurance; relating to the business of insurance; relating to exceptions to prohibited rebates; relating to the powers of the director of the division of insu…
      An Act relating to travel insurance; relating to the business of insurance; relating to exceptions to prohibited rebates; relating to the powers of the director of the division of insurance; relating to prohibited practi…

### U.S. Weather + Severe / Climate Outlooks — 134 new of 136 total
  - (2026-11-20) [Moderate] Rip Current Statement: Rip Current Statement issued November 20 at 1:46AM CST until November 20 at 6:00PM CST by NWS Brownsville TX
      * WHAT...For the Coastal Flood Advisory, minor coastal flooding. For the High Rip Current Risk, dangerous rip currents. * WHERE...Kenedy Island, Willacy Island and Cameron Island Counties. * WHEN...For the Coastal Flood…
  - (2026-11-19) [Moderate] Wind Advisory: Wind Advisory issued November 19 at 11:45PM PST until November 20 at 12:00AM PST by NWS Las Vegas NV
      Winds have decreased across the area and the Wind Advisory will be allowed to expire at Midnight PST / 1 AM MST.
  - (2026-11-20) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-20) [Moderate] Wind Advisory: Wind Advisory issued November 20 at 1:44AM CST until November 20 at 5:00PM CST by NWS Sioux Falls SD
      * WHAT...South winds 20 to 30 mph with gusts up to 50 mph expected. * WHERE...Portions of northwest and west central Iowa, southwest Minnesota, northeast Nebraska, and southeast South Dakota. * WHEN...From 10 AM this mor…
  - (2026-11-20) [Moderate] Wind Advisory: Wind Advisory issued November 20 at 1:43AM CST until November 20 at 5:00PM CST by NWS Des Moines IA
      * WHAT...South winds 25 to 35 mph with gusts over 45 mph expected. * WHERE...Humboldt, Kossuth, Emmet, Palo Alto, Pocahontas, Calhoun, Carroll, Crawford, and Sac Counties. * WHEN...From 10 AM this morning to 5 PM CST thi…
  - (2026-11-20) [Moderate] Wind Advisory: Wind Advisory issued November 20 at 1:33AM CST until November 20 at 5:00PM CST by NWS Twin Cities/Chanhassen MN
      * WHAT...South winds 20 to 30 mph with gusts in excess of 45 mph expected. * WHERE...Martin County. * WHEN...From 10 AM this morning to 5 PM CST this afternoon. * IMPACTS...Gusty winds will blow around unsecured objects.…

### Ukraine Theater (total-war monitoring) — 110 new of 302 total
  - (2026-11-20) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-19) [Liveuamap] General Staff of the Armed… – Kerch, Crimea - Liveuamap
      General Staff of the Armed… – Kerch, Crimea Liveuamap
  - (2026-11-19) [Liveuamap] Reports of 5 Tu-160 bombers airborne from the Russian far east – Amur Oblast, Russia - Liveuamap
      Reports of 5 Tu-160 bombers airborne from the Russian far east – Amur Oblast, Russia Liveua
  - (2026-11-18) [Liveuamap] Russian occupational authorities confirmed the rail service at the Kerch bridge was stopped after an attack - Liveuamap
      Russian occupational authorities confirmed the rail service at the Kerch bridge was stopped after an attack <font col
  - (2026-11-18) [Liveuamap] The Israeli military launched… – Bureij, Gaza - Liveuamap
      The Israeli military launched… – Bureij, Gaza Liveuamap
  - (2026-11-18) [Liveuamap] Russian forces… – Odesa Oblast, Ukraine - Liveuamap
      Russian forces… – Odesa Oblast, Ukraine Liveuamap

### World News (by country, top stories) — 103 new of 103 total
  - (2026-11-20) [Brazil] Brazil's Lula moves to protect Chief Raoni's birthplace in the Amazon rainforest | World
      cecildaily.com · English · 2 other outlets ran this story
  - (2026-11-20) [Brazil] Brazil pork exports hit October record on strong monthly rise
      thepigsite.com · English · 1 other outlets ran this story
  - (2026-11-20) [Brazil] Five arrested in Brazil over 660kg cocaine haul after Australian pilot's fatal crash
      perthnow.com.au · English
  - (2026-11-20) [Brazil] JETOUR Global Fan Festival Comes to Brazil, Strengthening Local Presence for Long-Term Growth
      manilatimes.net · English
  - (2026-11-20) [Brazil] Alice Webb Inquest: Sister's tribute after Brazilian butt lift death
      independent.co.uk · English
  - (2026-11-20) [Brazil] Brazil Markets Closed as Dollar Hits 5.93 Reals | Morning Call, Nov 20
      riotimesonline.com · English

### Ukrainian Internal News (national + local Kyiv) — 77 new of 139 total
  - (2026-11-20) Злив таємниці слідства та продаж закритих даних: оголосили підозру співробітнику СБУ | LEDE: Антикорупційні органи повідомляють про викриття екскерівника одного з підрозділів Департаменту захис] (uk:…
      Антикорупційні органи повідомляють про викриття екскерівника одного з підрозділів Департаменту захисту національної державності Служби безпеки України на розголошенні відомостей досудового розслідування та одержанні непр…
  - (2026-11-20) У Польщі під час атаки РФ пролунав вибух: військові перевіряють два ймовірні порушення простору | LEDE: Уранці 20 листопада у селищі Хмелек Люблінського воєводства Польщі зафіксували сильний ви] (uk:…
      Уранці 20 листопада у селищі Хмелек Люблінського воєводства Польщі зафіксували сильний вибух під час масованої російської атаки на західні області України. Польські військові розслідують "два можливі порушення" повітряно…
  - (2026-11-20) Британія проводить наступальні кібероперації проти Росії, Китаю, Ірану та КНДР | LEDE: ] (uk: Британія проводить наступальні кібероперації проти Росії, Китаю, Ірану та КНДР)
  - (2026-11-20) Росіяни атакували залізничну станцію у Львові: 2 загиблих, 7 постраждалих | LEDE: Російський удар по станції "Скнилів" у Львові 20 листопада – двоє загиблих, четверо поранених. Пошкоджено енерг] (uk:…
      Російський удар по станції "Скнилів" у Львові 20 листопада – двоє загиблих, четверо поранених. Пошкоджено енергообʼєкт у Стрийському районі.
  - (2026-11-20) Світ не ділиться на трьох. Чому зустріч у Китаї стала для Путіна перемогою, але не проривом | LEDE: ] (uk: Світ не ділиться на трьох. Чому зустріч у Китаї стала для Путіна перемогою, але )
  - (2026-11-20) Пошкоджено об'єкти "Київводоканалу": у столиці є перебої з водою | LEDE: Внаслідок нічної ворожої атаки РФ зазнали пошкоджень об'єкти Київводоканалу: через атаки на енергосистему виникли перебо] (uk:…
      Внаслідок нічної ворожої атаки РФ зазнали пошкоджень об'єкти Київводоканалу: через атаки на енергосистему виникли перебої у водопостачанні столиці.

### GDACS — global disaster alerts — 50 new of 100 total
  - (2026-11-20) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5M, Depth:6.69999980926514km
  - (2026-11-20) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 4.9M, Depth:97.583km
  - (2026-11-20) [Green] Earthquake in Argentina
      Earthquake · Green alert · Argentina · Magnitude 4.8M, Depth:113.86km
  - (2026-11-20) [Green] Earthquake in Southeast Of Loyalty Islands
      Earthquake · Green alert · Southeast Of Loyalty Islands · Magnitude 5.6M, Depth:10km
  - (2026-11-07) [Green] Forest fires in Brazil
      Wildfire · Green alert · Brazil · Green impact for forestfire in 6272 ha
  - (2026-11-19) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.5M, Depth:124.788km

### IT, InfoSys & cybersecurity news (last 7 days) — 48 new of 62 total
  - (2026-11-20) [BleepingComputer] VMware patches vCenter zero-day exploited in attacks since September
      Broadcom has released security updates to fix a critical VMware vCenter Server authentication bypass vulnerability that Chinese-linked hackers have exploited in zero-day attacks since September 2026. [...]
  - (2026-11-20) [The Hacker News] ROMULUS ClickFix Attacks Deliver RAT That Can Spy on Users and Control PCs
      Threat actors have been observed using the ROMULUS ClickFix malware delivery platform to deliver a previously undocumented remote access trojan (RAT) that shares similarities with CNCMachineRMS. "ROMULUS likely operates…
  - (2026-11-20) [The Hacker News] China-Linked Hackers Exploit Critical VMware vCenter Zero-Day to Gain Admin Access and Steal Data
      The suspected China-nexus cyber espionage group known as Armory Castle (formerly UNC5221) has been attributed to the zero-day exploitation of a critical security flaw in VMware vCenter Server in early September 2026. The…
  - (2026-11-20) [The Hacker News] New Unpatched Windows 0-Day FastUnlock Lets Someone Holding a Locked PC Run Programs on It
      A newly disclosed unpatched zero-day technique called FastUnlock lets someone with physical access to a locked Windows computer start programs without signing in. Whoever uses it gets only a limited account, not administ…
  - (2026-11-20) [The Register] Support tech fixed malware by charging client less for their services
      ‘I gave up at least $6,000 and I’d do it again’
  - (2026-11-20) [The Register] Big Tech's compliance with EU market rules is performative, consumer group says
      BEUC urges Brussels to impose tougher penalties over alleged barriers to switching services and controlling personal data

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-20) [Grove Collaborative Holdings, Inc.] Form 4 (Issuer)
      filed 2026-11-20 02:52 UTC · role: Issuer — Filed: 2026-11-19 AccNo: 0001841761-26-000127 Size: 9 KB
  - (2026-11-20) [Karp Jason H.] Form 4 (Reporting)
      filed 2026-11-20 02:52 UTC · role: Reporting — Filed: 2026-11-19 AccNo: 0001841761-26-000127 Size: 9 KB
  - (2026-11-20) [Lucidi Bruno] Form 4 (Reporting)
      filed 2026-11-20 02:51 UTC · role: Reporting — Filed: 2026-11-19 AccNo: 0001193125-26-469038 Size: 13 KB
  - (2026-11-20) [Atea Pharmaceuticals, Inc.] Form 4 (Issuer)
      filed 2026-11-20 02:51 UTC · role: Issuer — Filed: 2026-11-19 AccNo: 0001193125-26-469038 Size: 13 KB
  - (2026-11-20) [Atea Pharmaceuticals, Inc.] Form 4 (Issuer)
      filed 2026-11-20 02:51 UTC · role: Issuer — Filed: 2026-11-19 AccNo: 0001193125-26-469037 Size: 5 KB
  - (2026-11-20) [Polsky Bruce] Form 4 (Reporting)
      filed 2026-11-20 02:51 UTC · role: Reporting — Filed: 2026-11-19 AccNo: 0001193125-26-469037 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-20) [United States] In a cruel connection, Fiona the hippo dies at the same Zoo where Harambe was killed 10 years ago: Here's how her birth lifted spirits after the gorilla's death
      domain: indiatimes.com · language: English · tone: -2.60521042084168 · 105 other outlets ran this story
  - (2026-11-20) [Ukraine] Trump tells Europe to defund Ukraine hours after hailing his 'friend' Putin at historic summit
      domain: independent.co.uk · language: English · tone: -2.36220472440945 · 101 other outlets ran this story
  - (2026-11-20) Reopened investigation into 2024 police shooting delivered to Spokane County Prosecutor's Office for review
      domain: khq.com · language: English · tone: -4.0650406504065 · 100 other outlets ran this story
  - (2026-11-20) [United States] Accused child sex predator Thomas Markle ruled fit to stand trial
      domain: odt.co.nz · language: English · tone: -5.44412607449857 · 89 other outlets ran this story
  - (2026-11-20) [United Kingdom] King Charles' Balmoral estate dragged into Epstein trafficking scandal as police examine claims involving Andrew Windsor
      domain: femalefirst.co.uk · language: English · tone: -5.01355013550136 · 84 other outlets ran this story
  - (2026-11-20) [Nigeria] Ajiran Killings: Defence Challenges Police Evidence As Trial Begins
      domain: leadership.ng · language: English · tone: -5.67375886524823 · 71 other outlets ran this story

### Court opinions of consequence (federal & state) — 39 new of 60 total
  - (2026-11-24) Connecticut Supreme Court: State v. Sharpley
  - (2026-11-19) U.S. Court of Appeals, 6th Cir.: Denny Obermiller v. Tim Shoop
  - (2026-11-19) U.S. Court of Appeals, 6th Cir.: United States v. Justin Bobo
  - (2026-11-19) U.S. Court of International Trade: Oman Aluminium Rolling Co. SPC v. United States
  - (2026-11-19) D.C. Court of Appeals: In re Price
  - (2026-11-19) D.C. Court of Appeals: In re Williams

### Wikidata leader-roster changes (48h) — 33 new of 59 total
  - (2026-11-20) [Cyprus] Nicos Christodoulides (Q48905549) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73590|batch #73590]]: Import P106 from GND
  - (2026-11-20) [Colombia] Abelardo de la Espriella (Q137204778) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73597|batch #73597]]: Import GND source for unsourced occupation
  - (2026-11-20) [Equatorial Guinea] Teodoro Obiang (Q57385) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73565|batch #73565]]: Import P39 from GND
  - (2026-11-20) [Laos] Thongloun Sisoulith (Q58323) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73597|batch #73597]]: Import GND source for unsourced occupation
  - (2026-11-20) [Republic of the Congo] Denis Sassou-Nguesso (Q57418) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73565|batch #73565]]: Import P39 from GND
  - (2026-11-20) [Poland] Karol Nawrocki (Q17704749) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73565|batch #73565]]: Import P39 from GND

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 25 new of 26 total
  - (2026-11-20) SAMU71 (France)
      icao24: 398c4e · position: (46.7778, 4.8415) · alt: 236m · 18km/h
  - (2026-11-20) SAMU69 (France)
      icao24: 39c994 · position: (45.4484, 4.9035) · alt: 548m · 208km/h
  - (2026-11-20) CFC3628 (Canada)
      icao24: c2b3f5 · position: (44.4199, -77.7867) · alt: 3421m · 671km/h
  - (2026-11-20) FNY55C4 (France)
      icao24: 39a408 · position: (44.8291, -0.7102) · on ground · 50km/h
  - (2026-11-20) GAF923 (Germany)
      icao24: 3ea12c · position: (-30.1874, 18.2221) · alt: 11887m · 837km/h
  - (2026-11-20) JAF6GT (Belgium)
      icao24: 44d1a6 · position: (35.0329, -5.8509) · alt: 11277m · 795km/h

### U.S. Federal Action — 24 new of 24 total
  - (2026-11-20) Updates and Amendments to the Civil Service Rules
      The Office of Personnel Management (OPM) is confirming the effective date of the direct final rule updating and amending obsolete and outdated provisions of the Civil Service Rules. OPM received no significant adverse co…
  - (2026-11-20) Procedures for Settling Claims
      The Office of Personnel Management (OPM) confirms that the direct final rule updating the procedures for submitting certain administrative claims to OPM became effective as scheduled.
  - (2026-11-20) FLSA Claims and Compliance
      The Office of Personnel Management (OPM) confirms that the direct final rule updating provisions concerning Fair Labor Standards Act (FLSA) claims submissions to OPM became effective as scheduled.
  - (2026-11-20) Federal Employees' Retirement System; Present Value Conversion Factors for Spouses of Deceased Separated Employees
      The Office of Personnel Management (OPM) is confirming the effective date of its direct final rule revising the table of reduction factors for early commencing dates of survivor annuities paid to spouses of separated emp…
  - (2026-11-20) Extension of Import Restrictions Imposed on Archaeological and Ethnological Material of Greece
      This document amends U.S. Customs and Border Protection (CBP) regulations to reflect the extension of import restrictions on certain categories of archaeological and ecclesiastical ethnological material from the Hellenic…
  - (2026-11-20) Implementation of HAVANA Act of 2021
      This rule provides implementation by the Department of Homeland Security ("the Department" or "DHS") of the HAVANA Act of 2021. The HAVANA Act provides authority for agency heads to provide payments to certain individual…

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 104 total
  - (2026-11-19) [OFAC] Counter Narcotics Designations; Cyber-related Designations; Issuance of Illicit Drugs General License; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office…
      Counter Narcotics Designations; Cyber-related Designations; Issuance of Illicit Drugs General License; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.…
  - (2026-11-19) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-11-19) [OFAC] Russian Harmful Foreign Activities Sanctions - Office of Foreign Assets Control (.gov)
      Russian Harmful Foreign Activities Sanctions Office of Foreign Assets Control (.gov)
  - (2026-11-19) [OFAC] ‘Ndrangheta Operations in Canada - Office of Foreign Assets Control (.gov)
      ‘Ndrangheta Operations in Canada Office of Foreign Assets Control (.gov)
  - (2026-11-19) [OFAC] Comanchero Outlaw Motorcycle Gang - Office of Foreign Assets Control (.gov)
      Comanchero Outlaw Motorcycle Gang Office of Foreign Assets Control (.gov)
  - (2026-11-19) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Illicit Drug Trade Sanctions Regulations 31 CFR part 599 GENERAL LICENSE NO. 1 Authorizing the - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Illicit Drug Trade Sanctions Regulations 31 CFR part 599 GENERAL LICENSE NO. 1 Authorizing the Office of Foreign Assets Control (.gov)

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-11-20) Will Jensen Huang rejoin NVIDIA by November 30, 2026?
      yes price: 1% · 24h volume: $329,513 · resolves 2026-12-01
  - (2026-11-20) ATP World Tour Finals, Ivan Lendl Group: Carlos Alcaraz vs Flavio Cobolli
      yes price: 80% · 24h volume: $245,851 · resolves 2026-11-24
  - (2026-11-20) Will Scott Colom win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $243,996 · resolves 2028-11-07
  - (2026-11-20) Will Bitcoin reach $1,000,000 by December 31, 2026?
      yes price: 0% · 24h volume: $201,188 · resolves 2027-01-01
  - (2026-11-20) Will Dominique de Villepin win the 2027 French presidential election?
      yes price: 2% · 24h volume: $197,780 · resolves 2027-04-19
  - (2026-11-20) Will Bitcoin dip to $60,000 by December 31, 2026?
      yes price: 82% · 24h volume: $187,330 · resolves 2027-01-01

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-11-20) M 5.6 - southeast of the Loyalty Islands
      M5.6 · southeast of the Loyalty Islands · depth 10 km
  - (2026-11-19) M 5.3 - South Georgia Island region
      M5.3 · South Georgia Island region · depth 10 km
  - (2026-11-19) M 5.1 - 99 km WSW of Illapel, Chile
      M5.1 · 99 km WSW of Illapel, Chile · depth 10 km
  - (2026-11-20) M 5.0 - 10 km NW of Pinnacles, CA
      M5.0 · 10 km NW of Pinnacles, CA · depth 6.69999980926514 km · TSUNAMI
  - (2026-11-19) M 5.0 - central East Pacific Rise
      M5.0 · central East Pacific Rise · depth 10 km
  - (2026-11-19) M 5.0 - 31 km WSW of Rabaul, Papua New Guinea
      M5.0 · 31 km WSW of Rabaul, Papua New Guinea · depth 194.803 km

### Paper Trading Scorecard — 10 new of 67 total
  - (2026-11-20) [Kalshi] Who will be the next Prime Minister of the UK?
      Before Jan 1, 2035
  - (2026-11-20) [Manifold] GTA VI Online released by March 31, 2027?
  - (2026-11-20) [Manifold] Is the 2028 Republican President and VP Nominee on this Turning Point AmericaFest ad?
  - (2026-11-20) [Manifold] Daily Coinflip
  - (2026-11-20) [Manifold] Will GTA VI break the 24H sales record?
  - (2026-11-20) [Manifold] Trump declassifies new UFO files by Nov. 30? [Polymarket]

### Campaign finance (FEC: top fundraisers + recent filings) — 10 new of 27 total
  - (2026-11-18) [F2] MRVAN, FRANK J.
      cycle 2026 · filing #2048403
  - (2026-11-18) [F2] CASANOVA, ASHLEY
      cycle 2026 · filing #2048368
  - (2026-11-18) [F99] (unknown)
      cycle 2026 · filing #2048344
  - (2026-11-18) [F1] CHRISTINA FOR CONGRESS
      cycle 2026 · filing #2048377
  - (2026-11-18) [F2] DEMBO, ZACH
      cycle 2026 · filing #2048441
  - (2026-11-18) [F1] PLANNED PARENTHOOD ACTION FUND OF THE PACIFIC SOUTHWEST PAC
      cycle 2026 · filing #2048464

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 40 total
  - (2026-11-20) MOVER ▼ Mark Zuckerberg — $205.03B ($-6.82B since yesterday)
      United States · Technology · source: Facebook
  - (2026-11-20) MOVER ▼ Steve Ballmer — $155.72B ($-2.53B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-11-20) MOVER ▼ Amancio Ortega — $147.58B ($-2.28B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-11-20) MOVER ▼ Francoise Bettencourt Meyers & family — $100.98B ($-1.67B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Commentary & analysis (last 7 days) — 2 new of 4 total
  - (2026-11-20) [Marginal Revolution] AIs vs. humans in economics papers
      Is agentic research any good? Dr Yanagizawa-Drott and his colleague, Olaf Willner, used an AI verifier to check 1,000 APE papers. None was error-free; 842 contained at least one severe error, including ones invalidating…
  - (2026-11-19) [Marginal Revolution] Thursday assorted links
      1. How to turn AI-written maths into a video. 2. Honeypot markets in everything? 3. Traveling a lot without going on planes (WSJ). 4. American audiovisual exports have plunged in terms of global share (I think that is fi…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=20, 14d-median=24; carrying terms: environmental, directives, implementation, issued, airworthiness, applicable, necessary, final, quality, update, airplanes, safety
- state_bills: today=164, 7d-median=73, 14d-median=84; carrying terms: public, relating, local, including, school, health, state, business, licensing, provided, protection, program
- state_news: today=756, 7d-median=712, 14d-median=712; carrying terms: ballot, originally, order, lawsuit, short, working, source, groups, infrastructure, economic, ctmirror, rejected
- local_news: today=250, 7d-median=250, 14d-median=265; carrying terms: police, illinois, atlanta, office, killed, county, trump, million, students, night, weekend, culture
- foreign_news: today=1071, 7d-median=977, 14d-median=997; carrying terms: accuses, crime, share, protests, union, order, build, source, groups, infrastructure, economic, maverick
- chinese_internal: today=336, 7d-median=319, 14d-median=331; carrying terms: cbmix, growth, cbmiw, lxtfb, cbmic, lxtfa, china, cbmickfvx, global, cbmiakfvx, investors, cbmidefvx
- russian_internal: today=1092, 7d-median=938, 14d-median=947; carrying terms: politico, starlink, forbidden, media, europe, error, russian, found, gazeta, novaya, https, times
- ukrainian_internal: today=139, 7d-median=127, 14d-median=134; carrying terms: infrastructure, ukrinform, rejected, error, hmarochos, https, times, operation, police, against, remains, control
- ukraine_theater: today=302, 7d-median=276, 14d-median=271; carrying terms: pymetmkvpt, enemy, zwexznv, pluvovf, flash, ruegnmrlfzavvuvvjus, betueflwzlvfdhv, cbmikafbvv, cbmibefvx, txrjvniwtwtwmmj, rejected, tddtbezsm
- paper_bets: today=67, 7d-median=75, 14d-median=74; carrying terms: drought, resolved, achieved, rushing, minister, prime, total, secretary, named, goldman, passing, mbappe
- weather: today=136, 7d-median=130, 14d-median=130; carrying terms: large, severe, disregard, continues, norton, aviation, afdlox, short, craft, hazardous, angeles, above
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: payrolls, walcl, personal, cpilfesl, supply, payems, balance, rates, latest, dexjpus, spread, consumption
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, large, equities, treasury, crude, agriculture, silver, credit, russell, rates, proxy, close
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=100, 14d-median=99; carrying terms: government, google, islamic, russia, compare, transportation, protests, union, guatemala, order, sovereignty, daesh
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiverquant, error, httperror, quantitative, quiver, unauthorized, https, congresstrading
- billionaires: today=40, 7d-median=40, 14d-median=34; carrying terms: investments, shanghai, beverages, beverage, thomas, larry, giancarlo, adani, tadashi, google, googl, cryptocurrency
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, supreme, international, delaware, state, court, company, martin, people, blanche, trade, miller
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, holdings, michael, management, partners, andrew, medical, jennifer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: david, ossoff, disbursements, cooper, cortez, ocasio, filing, senate, raised, james, abdul, jonathan
- gdelt_regions: today=103, 7d-median=103, 14d-median=100; carrying terms: english, south, japan, korea, trump, russia, germany, korean, turkey, nvidia, german, minister
- gdelt_gkg: today=138, 7d-median=132, 14d-median=116; carrying terms: english, russian, sanctions, keywords, russia, perimeter, israel, hezbollah, themes, trump, against, strikes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: domain, english, murder, language, police, trump, shooting, killed, australia, story, county, injured
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=22, 14d-median=24; carrying terms: position, belgium, france, germany, canada, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: october, activi, sylvatic, mechanical, point, clusters, severe, transmission, activity, continues, comprising, intense
- cisa_kev: today=18, 7d-median=15, 14d-median=15; carrying terms: critical, google, cisco, improper, product, return, authentication, vulnerability, vendor, check, products, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=59, 7d-median=53, 14d-median=45; carrying terms: congo, batch, wbsetaliases, republic, wbsetclaim, kingdom, toollabs, wbsetdescription, wbeditentity, democratic, quickstatements, wbsetsitelink
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: forest, depth, south, botswana, fires, green, impact, earthquake, australia, magnitude, wildfire, alert
- usgs_quakes: today=12, 7d-median=12, 14d-median=12; carrying terms: depth, indonesia, islands, papua, region, guinea, south, chile, central, china, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, december, november, presidential, interest, rates, meeting, israel, election, continues
- commentary: today=4, 7d-median=6, 14d-median=6; carrying terms: revolution, class, economist, conversable, https, marginal, economic, conversableeconomist, marginalrevolution, power, global, called
- tech_news: today=62, 7d-median=63, 14d-median=62; carrying terms: google, techcrunch, report, working, review, https, blogging, cybersecurity, computerweekly, systems, download, cyber
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jeanne, tuberville, auchincloss, levin, jacobs, trade, clyburn, newhouse, teresa, norton, michael, larsen
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, unavailable, identify, decision, placed, today, markets, placement, consensus, sufficient, market, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] ECB press: Boris Vujčić: Risks and resilience in the euro area financial system
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] ECB press: Frank Elderson: Smart supervision for small banks
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-17] ECB press: Philip R. Lane: The practice and science of monetary policy communication: the ECB experience
- [2026-11-18] ECB press: Boris Vujčić: Financial Stability Review - November 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*