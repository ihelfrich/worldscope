# WORLDSCOPE morning brief — 2026-08-16

## Headline
2982 new items across 23 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (887) · International News + Multilateral Institutions (553) · Russian Internal News (state + in-exile) (363) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (200) · Chinese Internal News (197) · Local News: St. Louis + Atlanta (100) · State-Level News (97) · State Legislative Action (54) · Ukrainian Internal News (national + local Kyiv) (42) · Sanctions & Designations (recent) (30) · GDELT GKG — themes / entities / watch areas (25)

## What changed today
### Ukraine Theater (total-war monitoring) — 887 new of 1338 total
  - (2026-08-16) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-15) [FIRMS] thermal anomaly 46.014, 34.833 (FRP 4.65 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-15 1000Z, FRP 4.65 MW
  - (2026-08-15) [FIRMS] thermal anomaly 45.259, 31.672 (FRP 7.24 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-15 1000Z, FRP 7.24 MW
  - (2026-08-15) [FIRMS] thermal anomaly 46.204, 34.377 (FRP 6.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-15 1000Z, FRP 6.15 MW
  - (2026-08-15) [FIRMS] thermal anomaly 46.410, 34.906 (FRP 7.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-15 1000Z, FRP 7.78 MW
  - (2026-08-15) [FIRMS] thermal anomaly 46.409, 34.900 (FRP 7.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-15 1000Z, FRP 7.78 MW

### International News + Multilateral Institutions — 553 new of 950 total
  - (2026-08-16) [Global] Rescuers search for survivors of powerful Indonesia earthquake
      Officials say a rapid assessment into the impact of the earthquake that destroyed hundreds of buildings and killed 47 is under way.
  - (2026-08-16) [Global] Hawaii battles strong winds and rain as Hurricane Lala threat looms
      If the storm makes landfall, it will be Hawaii's first direct hit by a hurricane in 34 years.
  - (2026-08-16) [Global] Twelve killed as Polish bus veers off Hungarian motorway
      Dozens more are seriously injured after the tourist bus overturned in the early hours of Sunday morning.
  - (2026-08-15) [Global] Morocco detains dozens of migrants trying to cross into Ceuta, reports say
      Security had been stepped up amid suggestions on social media of a second mass crossing on Saturday.
  - (2026-08-15) [Global] Liechtenstein changes succession rule to allow women to ascend the throne
      The declaration was made on the national day of the central European country, which has a population of just 44,000.
  - (2026-08-15) [Global] Qatar denies capturing three Iranian pilots after downing fighter jets
      Iran claims they have been held since Qatar downed two fighter jets at the start of the US-Iran war.

### Russian Internal News (state + in-exile) — 363 new of 710 total
  - (2026-08-16) Россия атаковала Кривой Рог и Киев. Есть погибшие и пострадавшие. Минобороны РФ утверждает, что поражено производство комплектующих для ракет «Фламинго» | LEDE: Россия в ночь на 16 августа а] (ru: Рос…
      Россия в ночь на 16 августа атаковала Киев и Кривой Рог в Днепропетровской области ракетами и беспилотниками.
  - (2026-08-16) Украина атаковала два склада в Подмосковье. В Ростовской области в результате атаки ракет и дронов есть погибшие. На Москву летело 600 беспилотников | LEDE: Украинские беспилотники массово а] (ru: Укр…
      Украинские беспилотники массово атаковали Москву, Подмосковье и Ростовскую область, есть погибшие и пострадавшие.
  - (2026-08-15) В Петербурге наложили арест на квартиру основателя рок-группы «Телевизор» Михаила Борзыкина | LEDE: На петербургскую квартиру основателя рок-группы «Телевизор» Михаила Борзыкина наложили аре] (ru: В П…
      На петербургскую квартиру основателя рок-группы «Телевизор» Михаила Борзыкина наложили арест. Также музыканту заблокировали счет в Сбербанке, рассказал телеграм-каналу Sota продюсер музыканта Михаил Елисеев.
  - (2026-08-15) Автор Wired запросил всю информацию, которую о нем знает «Макдоналдс». Получилось досье на 515 страниц с персональным рейтингом блюд! Шанс, что журналист перестанет быть клиентом сети, компания] (ru:…
      Журналист издания Wired Рис Роджерс решил выяснить, какие данные о нем собрала сеть быстрого питания «Макдоналдс» за все те годы, что он пользовался ее мобильным приложением и участвовал в программе лояльности компании.…
  - (2026-08-15) Открытые ИИ-модели Alibaba Group в 2026 году скачали три миллиарда раз. Это больше, чем в совокупности у всех американских компаний | LEDE: Открытые модели искусственного интеллекта от Aliba] (ru: Отк…
      Открытые модели искусственного интеллекта от Alibaba Group за последние шесть месяцев скачали более трех миллиардов раз, пишет Bloomberg. По этому показателю компания стала мировым лидером, оставив позади американских и…
  - (2026-08-15) Невролога Василия Генералова арестовали по обвинению в мошенничестве. В его клинике «лечат аутизм» диетами и изгнанием паразитов | LEDE: Чертановский районный суд Москвы арестовал основателя] (ru: Нев…
      Чертановский районный суд Москвы арестовал основателя и главного врача клиники «ПланетаМед» (официальное название — ООО «Медлайн») Василия Генералова до 28 сентября.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 200 new of 203 total
  - (2026-08-16) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 16 at 2:24AM CDT until August 16 at 8:00PM CDT by NWS Springfield MO
      * WHAT...Dangerously hot conditions with heat index values up to 110. * WHERE...Portions of southeast Kansas and central, east central, south central, southwest, and west central Missouri. * WHEN...Until 8 PM CDT this ev…
  - (2026-08-16) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued August 16 at 1:18AM MDT until August 16 at 7:00AM MDT by NWS Cheyenne WY
      * WHAT...Visibility as low as a quarter mile in dense fog. * WHERE...South Laramie Range and Foothills including the Interstate 80 Summit between Cheyenne and Laramie. * WHEN...Until 7 AM MDT this morning. * IMPACTS...Lo…
  - (2026-08-16) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 16 at 2:18AM CDT until August 16 at 3:00AM CDT by NWS Hastings NE
      SVRGID The National Weather Service in Hastings has issued a * Severe Thunderstorm Warning for... Northwestern Jewell County in north central Kansas... Northern Smith County in north central Kansas... Franklin County in…
  - (2026-08-16) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-16) [Severe] Flash Flood Watch: Flash Flood Watch issued August 16 at 3:17AM EDT until August 16 at 11:00AM EDT by NWS Northern Indiana
      * WHAT...Flash flooding caused by upstream dam release continues to be possible. * WHERE...A portion of northern Indiana, including the following county, White. * WHEN...Until 11 AM EDT this morning. * IMPACTS...Flooding…
  - (2026-08-16) [Severe] Flood Watch: Flood Watch issued August 16 at 3:17AM EDT until August 16 at 11:00AM EDT by NWS Northern Indiana
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of northwest Ohio, including the following areas, Allen OH and Van Wert. * WHEN...Until 11 AM EDT this morning. * IMPACTS...Exc…

### Chinese Internal News — 197 new of 261 total
  - (2026-08-14) Commentary: The Phantom Menace of Chinese Overcapacity - Caixin Global
      Commentary: The Phantom Menace of Chinese Overcapacity Caixin Global
  - (2026-08-15) 一周天下｜哥伦比亚地震造成265人死亡、强台风“白海豚” 致多地降水突破历史极值 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBZYUFPbFBBOHY4VGlaTXJlQ0hrbTFxR1FHR1JjcnZubVVNUmVvVzgxTkpoMWlTZ1hZc0ZoY3oxdEVzU] (zh:…
      一周天下｜哥伦比亚地震造成265人死亡、强台风“白海豚” 致多地降水突破历史极值 财新
  - (2026-08-15) 黑白的骷髅，彩色的花朵｜观展 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE43a2YzY0tKY0VMbUUtaW9ycEFXZlFFLU80SUhmRTg4bElmN1hOSjhILThWRE9MRU5WRFFUQVFRb05acDNRdXBiRER2TzhtQnR2Ym02bkF] (zh:…
      黑白的骷髅，彩色的花朵｜观展 财新
  - (2026-08-15) 朱镕基捐版税做慈善，“一分钱不留”｜纪念 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1QVGhTTmt1Q0l1SG1JLVNQQ1FDMEhXbGw0U3NwVThaWEtiV1RacjJYMDc4cUkxOG9BdGFvaV9heTFYS0RtZzNQSVZkUjh2MmZlb] (zh:…
      朱镕基捐版税做慈善，“一分钱不留”｜纪念 财新
  - (2026-08-15) 旅行最大的乐趣之一，其实是回家｜生命情感对话⑧ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBrT0tHQWctdWFyZWEzRllINzdjY0NkeHg3dFVxT2pSNlhOeUl3dDg1dmhzbXlDYUNBQVNfOFNNTmZabUJudVBQMFhhLWFvSj] (zh:…
      旅行最大的乐趣之一，其实是回家｜生命情感对话⑧ 财新
  - (2026-08-16) 海航一航班备降俄罗斯 更换飞机后再飞曼彻斯特 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE84TmE4Wk5JUktJX1ZoTzRPeUJSX3IxdjFPRUxfZHJIcXF0dDJ4dTNTSFJtWjE5aE1TNkZwNU01UGtzaFJTbXdTRjBSRHFyLTV] (zh:…
      海航一航班备降俄罗斯 更换飞机后再飞曼彻斯特 财新

### Local News: St. Louis + Atlanta — 100 new of 204 total
  - (2026-08-16) [St. Louis] Family searches for missing 41-year-old man in East St. Louis
      A family is pleading for help finding 41-year-old Perrin Cooper, who has been missing from East St. Louis since Monday.
  - (2026-08-15) [St. Louis] Baby rescued from hot car in north St. Louis; Two parents arrested
      St. Louis police officers rescued a 6-month-old baby who was left unattended in hot car Saturday in north St. Louis. Both of the baby's parents were arrested shortly thereafter, police say.
  - (2026-08-15) [St. Louis] History! Cardinals' rising star Joshua Baez homers in first three MLB at-bats
      A Major League Baseball debut for the history books: St. Louis Cardinals outfielder Joshua Baez hit a home run in each of his first three MLB at-bats. He's now the only player in baseball history to ever do that.
  - (2026-08-16) [St. Louis] Missouri Amendment 3 set for November ballots - What would it do?
      Missouri voters will decide on three statewide constitutional amendments in the November 2026 general election, headlined by Amendment 3, which could reinstate abortion bans across the state in most cases.
  - (2026-08-16) [St. Louis] Freedom 13 memorial ride honors fallen Marine Jared Schmitz
      Hundreds of motorists gathered Saturday to take part in the "Angels of Abbey Gate Memorial Ride," an event held in memory of fallen U.S. Marine and Missouri native Jared Schmitz.
  - (2026-08-16) [St. Louis] Carlinville, Illinois competes in Hallmark's 'Merriest Christmas Town' contest
      For years, many people have said Carlinville, Illinois feels like it's right out of a Hallmark movie. Now, the small town could actually become the setting for one.

### State-Level News — 97 new of 366 total
  - (2026-08-15) [Colorado] No more ‘hypothetical situations’: States move to fortify elections against Trump
      State Democratic officials are preparing for chaos at the polls this November, as President Donald Trump casts doubt on election security and pushes for more federal involvement in local voting. “We’re no longer talking…
  - (2026-08-15) [California] After refinery explosions, California lawmakers move to preserve safety rules
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/10/100225-El-Segundo-Fire-AP-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-08-15) [California] US DOJ finds ‘unbroken pattern’ of sexual abuse by California prison staff
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/063026-CCWFTour_KQED_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-08-15) [Arkansas] Controlling wild pigs can work if it’s a group effort
      The federal government is injecting millions of dollars into efforts to combat feral hogs – and it’s considering spending even more in the coming years. The problem has grown for decades, but our research has found that…
  - (2026-08-15) [Arkansas] Trump visa policy leads to fewer international students at US colleges, report concludes
      A decline in international students at American universities is attributable, in part, to Trump administration immigration policies, according to a new analysis, and that loss could cost the U.S. more than $3 billion, in…
  - (2026-08-15) [Arkansas] Q&A: Thune says Republicans can hold their majority — if they stop fighting each other
      SIOUX FALLS — U.S. Senate Majority Leader John Thune’s Republican Party faces midterm elections amid economic anxiety, high gas prices and a war with Iran. But Thune, of South Dakota, said the biggest threat to the party…

### State Legislative Action — 54 new of 62 total
  - (2026-08-15) [California AB 2329] Surplus residential property: condition-adjusted fair market value: Cities of Pasadena and South Pasadena.
      (1) Existing law establishes priorities and procedures that any state agency disposing of surplus property is required to follow. Existing law sets forth an order of priority for the disposal of specified surplus residen…
  - (2026-08-15) [California AB 2510] CalWORKs.
      (1) Under existing law, if the federal government provides funds for the care of a needy relative with whom a needy child is living, aid to the child for any month includes aid to meet the needs of that relative, except…
  - (2026-08-15) [California SB 977] Chain restaurants: children's meals.
      Existing law, the California Retail Food Code, establishes uniform health and sanitation standards for, and provides for regulation by the State Department of Public Health of, retail food facilities, as defined, and req…
  - (2026-08-15) [California AB 1604] Product safety: proofs of purchase: intentionally added bisphenols.
      Existing law prohibits a person from manufacturing, selling, or distributing in commerce any juvenile's feeding product or juvenile's sucking or teething product, as defined, that contains any form of bisphenol, as defin…
  - (2026-08-15) [California AB 2219] Veterans.
      Existing law authorizes the board of supervisors of each county to appoint a county veterans service officer to perform duties relating to the administration of benefits to veterans. Existing law authorizes the board to…
  - (2026-08-15) [California AB 2163] Energy: Strategic Clean Energy and Critical Mineral Development Zones.
      Existing law, the Warren-Alquist State Energy Resources Conservation and Development Act, establishes the State Energy Resources Conservation and Development Commission and prescribes the authorities, duties, and respons…

### Ukrainian Internal News (national + local Kyiv) — 42 new of 102 total
  - (2026-08-16) Винищувач НАТО збив дрон над Румунією | LEDE: Винищувач F-18 Іспанії збив безпілотник над Румунією. Це вже четвертий інцидент вторгнення дрона в румунський повітряний простір.] (uk: Винищувач НАТО зби…
      Винищувач F-18 Іспанії збив безпілотник над Румунією. Це вже четвертий інцидент вторгнення дрона в румунський повітряний простір.
  - (2026-08-16) Польський автобус зазнав аварії в Угорщині, 12 людей загинули | LEDE: В Угорщині сталася масштабна ДТП з автобусом: 12 людей загинули, щонайменше 10 поранені. Ведеться розслідування причин авар] (uk:…
      В Угорщині сталася масштабна ДТП з автобусом: 12 людей загинули, щонайменше 10 поранені. Ведеться розслідування причин аварії.
  - (2026-08-16) Німеччина готується до евакуації міста через загрозу пожеж | LEDE: ] (uk: Німеччина готується до евакуації міста через загрозу пожеж)
  - (2026-08-16) У трьох областях через російські атаки загинули 2 людини, ще 16 постраждали | LEDE: Внаслідок атак РФ у трьох областях України 2 загиблих, 16 поранених, пошкоджено житло та інфраструктуру.] (uk: У трь…
      Внаслідок атак РФ у трьох областях України 2 загиблих, 16 поранених, пошкоджено житло та інфраструктуру.
  - (2026-08-16) У Франції розслідують кібератаку, яка спричинила витік даних майже 700 тисяч осіб | LEDE: ] (uk: У Франції розслідують кібератаку, яка спричинила витік даних майже 700 тисяч осі)
  - (2026-08-16) Я і ми. Куди зникає відчуття спільної долі під час війни | LEDE: ] (uk: Я і ми. Куди зникає відчуття спільної долі під час війни)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-16) [Russia oil sanctions perimeter · keywords] What Bessent economic isolation of Iran could look like
      moneycontrol.com · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Lavrov : Worse is coming for Ukraine war machine
      sott.net · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Russia Threatens to Board united kingdom and French Ships over Shadow Fleet Seizures
      breitbart.com · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] What Bessent economic isolation of Iran could look like
      economictimes.indiatimes.com · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Russia Threatens to Board united kingdom and French Ships over Shadow Fleet Seizures
      breitbart.com · English · tone NA
  - (2026-08-15) [Russia oil sanctions perimeter · keywords] Caucasian Knot | Russian wheat has been sent to Armenia through the territory of Azerbaijan .
      eng.kavkaz-uzel.eu · English · tone NA

### USGS earthquakes (M4.5+, past day) — 25 new of 26 total
  - (2026-08-15) M 6.9 - 15 km NNW of Pematangsiantar, Indonesia
      M6.9 · 15 km NNW of Pematangsiantar, Indonesia · depth 172.526 km
  - (2026-08-16) M 6.1 - 56 km NNE of Port-Olry, Vanuatu
      M6.1 · 56 km NNE of Port-Olry, Vanuatu · depth 188.148 km
  - (2026-08-15) M 5.7 - 125 km NNE of Palu, Indonesia
      M5.7 · 125 km NNE of Palu, Indonesia · depth 72.495 km
  - (2026-08-16) M 5.5 - 76 km N of Ruteng, Indonesia
      M5.5 · 76 km N of Ruteng, Indonesia · depth 10 km
  - (2026-08-15) M 5.5 - Volcano Islands, Japan region
      M5.5 · Volcano Islands, Japan region · depth 39.954 km
  - (2026-08-15) M 5.4 - 19 km NE of Colonia, Micronesia
      M5.4 · 19 km NE of Colonia, Micronesia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-08-16) Dota 2: Aurora vs BoomBoys - Game 1 Winner
      yes price: 0% · 24h volume: $1,316,836 · resolves 2026-08-16
  - (2026-08-16) Dota 2: Team Spirit vs Team Resilience (BO3) - The International Elimination Round
      yes price: 72% · 24h volume: $1,248,205 · resolves 2026-08-16
  - (2026-08-16) Dota 2: Team Spirit vs Team Resilience - Game 2 Winner
      yes price: 0% · 24h volume: $1,196,189 · resolves 2026-08-16
  - (2026-08-16) Dota 2: Iron Wing vs GamerLegion - Game 1 Winner
      yes price: 100% · 24h volume: $375,630 · resolves 2026-08-16
  - (2026-08-16) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 0% · 24h volume: $322,537 · resolves 2026-09-16
  - (2026-08-16) LoL: T1 Academy vs DN SOOPers Challengers (BO3) - LCK Challengers League Rounds 3-4 Challenge Group
      yes price: 100% · 24h volume: $304,140 · resolves 2026-08-16

### Paper Trading Scorecard — 15 new of 136 total
  - (2026-08-16) [Polymarket] Will Anthropic's valuation hit (HIGH) $5.0T by December 31?
      This market will resolve to "Yes" if Anthropic's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or…
  - (2026-08-16) [Polymarket] Will MicroStrategy be margin called in 2026?
      This market will resolve to "Yes" if MicroStrategy incorporated is margin called on any of its Bitcoin-backed loans by December 31, 2026, 11:59 PM ET, resulting in either a forced liquidation of Bitcoin by a lender or Mi…
  - (2026-08-16) [Polymarket] Will an international court find Israel or its leaders guilty of Genocide by December 31, 2027?
      This market will resolve to "Yes" if he International Criminal Court ("ICC"), the International Court of Justice ("ICJ"), or any ad hoc international tribunal with recognized legal standing, issues a judgment or convicti…
  - (2026-08-16) [Polymarket] Will Josh Stein win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-08-16) [Polymarket] Will less than 5 SpaceX Starship launches successfully reach Space in 2026?
      This market will resolve according to the number of SpaceX Starship launches successfully reaching an altitude of 62 miles above sea level between January 1, 2026, and December 31, 2026, 11:59 PM ET. Otherwise, this mark…
  - (2026-08-16) [Manifold] Will Debbie Wasserman Schultz get 60.00% or more of the vote in the Florida 20 Democratic house primary?

### Government & military aircraft airborne (OpenSky) — 12 new of 12 total
  - (2026-08-16) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (43.9883, -1.7173) · alt: 10972m · 872km/h
  - (2026-08-16) JAF76T (Bulgaria)
      icao24: 4520aa · position: (41.6692, -3.413) · alt: 10980m · 847km/h
  - (2026-08-16) GAF666 (Germany)
      icao24: 3e0f77 · position: (51.3192, 7.6369) · alt: 419m · 183km/h
  - (2026-08-16) SAMU691 (France)
      icao24: 39c994 · position: (45.895, 4.7922) · alt: 434m · 227km/h
  - (2026-08-16) JAF6BX (Belgium)
      icao24: 44d2ab · position: (37.3494, 25.3859) · alt: 640m · 238km/h
  - (2026-08-16) JAF14K (Belgium)
      icao24: 449683 · position: (37.8957, 22.4558) · alt: 11887m · 891km/h

### Court opinions of consequence (federal & state) — 10 new of 60 total
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: Alyse Sanchez v. Markwayne Mullin
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: United States v. Danny Roney
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: United States v. Zerion Franklin
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: Wanrong Lin v. Markwayne Mullin
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: United States v. Earl Griffin, Jr.
  - (2026-08-13) U.S. Court of Appeals, 2nd Cir.: Umb

### IT, InfoSys & cybersecurity news (last 7 days) — 10 new of 58 total
  - (2026-08-15) [BleepingComputer] New Evooo1Bot Linux botnet turns routers into traffic relay nodes
      A new Mirai-based modular Linux botnet malware called Evooo1Bot has been targeting internet-facing gateway devices, turning them into SOCKS5 traffic relay nodes. [...]
  - (2026-08-15) [The Register] ChainDrop worm crawls into npm supply chain, evades standard defenses
      Shai-Hulud variant poisons 444 packages, spreads via tarballs and dev-tool hooks
  - (2026-08-15) [Ars Technica] VisionQuest trailer kicks off Disney's D23 fan event
      Also: Ahsoka S2 teaser, Doomsday trailer, news about MCU's X-Men and Star Wars: Starfighter
  - (2026-08-15) [Ars Technica] Ukraine strikes major Russian rocket factory with cruise missiles
      "Flamingo missiles were used. A good achievement."
  - (2026-08-15) [Ars Technica] So much solar: Digging into the list of every US power plant that went online this year
      Utility-scale solar leads by a mile, followed by batteries. Fossil fuels, not so much.
  - (2026-08-15) [TechCrunch] Woman claims her stepfather used Grok to transform childhood photo into explicit imagery
      The woman claimed that AI tools are "taking everyday life and turning it into child sexual abuse."

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 37 total
  - (2026-08-16) MOVER ▲ Amancio Ortega — $146.83B (+$0.46B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-16) MOVER ▲ Bernard Arnault & family — $142.58B (+$0.44B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-16) MOVER ▲ Francoise Bettencourt Meyers & family — $94.37B (+$0.29B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-16) MOVER ▲ Germán Larrea Mota Velasco & family — $67.56B (+$0.22B since yesterday)
      Mexico · Metals & Mining · source: Mining
  - (2026-08-16) MOVER ▼ Changpeng Zhao — $109.54B ($-0.18B since yesterday)
      Canada · Finance & Investments · source: Cryptocurrency exchange
  - (2026-08-16) MOVER ▲ Carlos Slim Helu & family — $121.63B (+$0.18B since yesterday)
      Mexico · Telecom · source: Telecom

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 93 total
  - (2026-08-16) [USASpending] $35,144,939,584 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-08-16) [USASpending] $10,524,604,426 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration. Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF…
  - (2026-08-16) [USASpending] $2,136,203,664 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.
  - (2026-08-16) [USASpending] $683,605,366 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-08-16) [USASpending] $666,810,964 → LEIDOS, INC.: FUTURE FLIGHT SERVICES PROGRAM
      Agency: Department of Transportation. Description: FUTURE FLIGHT SERVICES PROGRAM

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-16) [Marginal Revolution] Another rationale for sticky prices?
      …what can be predicted, Dabis said, is that a recent policy change by the Washington Metropolitan Area Transit Authority requiring drivers to verbally quote the $2.25 fare to passengers may make their job even riskier. E…
  - (2026-08-15) [Marginal Revolution] Adolfo Bioy Cesares delay
      My Amazon shipment is postponed from this fall until April 11, 2028 (!). Will it ever come? Of course this is the fantastic, and long, Bioy Cesares book Borges, his memoir of their friendship. How can the reoptimization…
  - (2026-08-15) [Marginal Revolution] Saturday assorted links
      1. Speculative Chinese claims about Alzheimer’s. 2. Very interesting Anthropic piece on why multi-agentic systems seem to show more herd behavior and collusion than human systems. And a comment from Rune Kvist. 3. Cross-…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-16) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: program, action, proposing, final, remove, proposed, special, proposes, provide, service, procedures, certain
- state_bills: today=62, 7d-median=129, 14d-median=124; carrying terms: person, transfer, among, corporations, government, development, enforcement, income, registration, family, project, available
- state_news: today=366, 7d-median=585, 14d-median=681; carrying terms: officer, legislature, whether, legal, democrat, indiana, government, supreme, enforcement, farmers, wednesday, large
- local_news: today=204, 7d-median=229, 14d-median=230; carrying terms: officer, family, august, charged, mother, apartment, million, former, south, school, content, national
- foreign_news: today=950, 7d-median=1007, 14d-median=1011; carrying terms: officer, tokyo, publication, brainpower, powder, karnataka, legal, digital, sustainable, guangzhong, teacher, inspire
- chinese_internal: today=261, 7d-median=269, 14d-median=269; carrying terms: cbmibefvx, cbmixkfvx, lxtfa, chinese, cbmidefvx, title, global, cbmibkfvx, google, cbmiyefvx, cbmia, politics
- russian_internal: today=710, 7d-median=1040, 14d-median=1056; carrying terms: novayagazeta, title, times, bloomberg, raquo, russian, patriot, wildberries, media, reuters, client, laquo
- ukrainian_internal: today=102, 7d-median=107, 14d-median=107; carrying terms: injured, drone, strikes, latest, washington, wildberries, warehouse, targeting, damage, found, despite, august
- ukraine_theater: today=1338, 7d-median=1025, 14d-median=840; carrying terms: cmvzunk, eodjka, bmlmqml, zixzrmodrpev, cbmiz, ufdbvgfztwg, estimated, klvfkyvpsslfydwkzbvdmdgltqxf, owrsqtf, havlsbkzqyzzlt, thzhpyy, xoufhtnnuzgfiaw
- paper_bets: today=136, 7d-median=129, 14d-median=137; carrying terms: romania, johnny, majors, erupt, texas, world, career, named, washington, artist, inflation, governor
- weather: today=203, 7d-median=198, 14d-median=198; carrying terms: flooding, afdlox, weather, excessive, lincoln, produce, localized, washington, thunderstorms, river, peachtree, afdmtr
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexchus, jtsjol, dcoilwtico, cpilfesl, money, treasury, payrolls, crude, dexjpus, vixcls, labor, openings
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, futures, corporate, crypto, rates, equities, yield, nasdaq, russell, range, treasury, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=93, 7d-median=99, 14d-median=99; carrying terms: sudan, aeronautics, territorial, taliban, undermining, prohibited, libya, prior, hybrid, occupation, usaspending, areas
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quiverquant, httperror, quantitative, https, client, error, unauthorized, quiver
- billionaires: today=37, 7d-median=34, 14d-median=36; carrying terms: tokyo, julia, microsoft, investments, walton, telecom, mexico, nasdaq, walmart, oracle, gates, bloomberg
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, appeals, blanche, connecticut, supreme, state, company, group, trade, international, health, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, financial, richard, robert, partners, david, patrick, capital, management
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: jonathan, krishnamoorthi, angels, house, senate, receipts, lindsey, james, warner, trone, graham, committee
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea, south, japan, koreaherald
- gdelt_gkg: today=25, 7d-median=25, 14d-median=37; carrying terms: english, russian, russia, german, perimeter, sanctions, keywords, attacks, peace, french, kingdom, ukraine
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=12, 7d-median=30, 14d-median=26; carrying terms: position, belgium, ground, france, kingdom, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: diphtheria, rabies, initially, intensive, outbreaks, second, several, prior, analysis, prevention, initiated, polio
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: cisco, using, langflow, vendor, deserialization, central, channel, alternate, secure, command, sensitive, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=251; carrying terms: romania, fires, speed, marino, democratic, wildfire, mexico, herzegovina, papua, china, typhoon, ukraine
- usgs_quakes: today=26, 7d-median=16, 14d-median=13; carrying terms: depth, indonesia, islands, russia, japan, region, vanuatu, papua, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: september, shakhtar, champions, meeting, strait, traffic, championship, normal, winner, volume, hormuz, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, marginal, conversable, economist, revolution, https, conversableeconomist, current, believe, future, impossible, young
- tech_news: today=58, 7d-median=58, 14d-median=56; carrying terms: vulnerabilities, world, digital, exploited, bleepingcomputer, newsletter, government, weekday, companies, tools, cybersecurity, download
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: mentions, baldwin, sherman, lankford, blake, composite, sanders, nathaniel, ronny, wittman, palmer, darrell
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, identify, sufficient, markets, unavailable, evidence, decision, placed, module, claude, market, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*