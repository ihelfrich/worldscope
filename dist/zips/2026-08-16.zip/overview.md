# WORLDSCOPE morning brief — 2026-08-16

## Headline
3187 new items across 23 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (890) · International News + Multilateral Institutions (564) · Russian Internal News (state + in-exile) (491) · World leaders & government officials (324) · Chinese Internal News (206) · U.S. Weather + Severe / Climate Outlooks (194) · State-Level News (103) · Local News: St. Louis + Atlanta (100) · State Legislative Action (54) · Ukrainian Internal News (national + local Kyiv) (50) · GDELT GKG — themes / entities / watch areas (50) · Sanctions & Designations (recent) (30)

## What changed today
### Ukraine Theater (total-war monitoring) — 890 new of 1338 total
  - (2026-08-16) [Liveuamap] Ukraine - Liveuamap
      Ukraine Liveuamap
  - (2026-08-16) [Liveuamap] 1 person killed, 6 wounded as result of missile strike in Sovetskyi district of Bryansk - Liveuamap
      1 person killed, 6 wounded as result of missile strike in Sovetskyi district of Bryansk Liv
  - (2026-08-14) [Liveuamap] PM Netanyahu : "With or without an agreement, as long as I am Prime Minister, Iran will not have nuclear weapons. The existence of our precious country—the existence of Israel—is not subje…
      PM Netanyahu : "With or without an agreement, as long as I am Prime Minister, Iran will not have nuclear weapons. The exist
  - (2026-08-11) [Liveuamap] Israeli warplanes targeted Mansouri in southern Lebanon South Governorate, Lebanon - Lebanon news on live map - lebanon.liveuamap.com
      Israeli warplanes targeted Mansouri in southern Lebanon South Governorate, Lebanon - Lebanon news on live map</a
  - (2026-08-10) [Liveuamap] Lebanon insists on Israel&039;s commitment to a ceasefire, a halt to bulldozing and bombing in the south, and acceptance of new experimental zones. Lazio, Italy - Lebanon news on live map…
      Lebanon insists on Israel&039;s commitment to a ceasefire, a halt to bulldozing and bombing in the sout
  - (2026-08-07) [Liveuamap] Lebanon news on live map - lebanon.liveuamap.com
      Lebanon news on live map lebanon.liveuamap.com

### International News + Multilateral Institutions — 564 new of 940 total
  - (2026-08-16) [Global] Five killed as Russia launches fresh aerial attacks across Ukraine
      Ukrainian President Volodymyr Zelensky accuses Russia of targeting civilian infrastructure, while Moscow reports that a warehouse was hit.
  - (2026-08-16) [Global] Thousands displaced by deadly Indonesia earthquake as rescue efforts continue
      Hundreds of homes and public buildings have been severely damaged with at least 51 people killed.
  - (2026-08-16) [Global] Hurricane Lala lashes Hawaii with strong winds and torrential rain
      If the storm makes landfall, it will be Hawaii's first direct hit by a hurricane in 34 years.
  - (2026-08-16) [Global] Twelve killed as Polish bus veers off Hungarian motorway
      Dozens more are seriously injured after the tourist bus overturned in the early hours of Sunday morning.
  - (2026-08-15) [Global] Morocco detains dozens of migrants trying to cross into Ceuta, reports say
      Security had been stepped up amid suggestions on social media of a second mass crossing on Saturday.
  - (2026-08-15) [Global] Liechtenstein changes succession rule to allow women to ascend the throne
      The declaration was made on the national day of the central European country, which has a population of just 44,000.

### Russian Internal News (state + in-exile) — 491 new of 832 total
  - (2026-08-16) Олимпиадники в этом году заняли больше половины бюджетных мест в лучших вузах России (а на некоторых направлениях — все места) | LEDE: Призеры и победители олимпиад в этом году заняли больше] (ru: Оли…
      Призеры и победители олимпиад в этом году заняли больше половины бюджетных мест на первых курсах ведущих вузов России, а на некоторых направлениях — все места, пишет РБК (доступ к материалу по платной подписке).
  - (2026-08-16) Страны Персидского залива недовольны Трампом, потому что он не может договориться с Ираном. И думают отказаться от размещения американских баз | LEDE: В странах Персидского залива растет нед] (ru: Стр…
      В странах Персидского залива растет недовольство Вашингтоном — союзники США обеспокоены тем, что Дональд Трамп не способен договориться с Ираном, пишет The Washington Post со ссылкой на арабских и западных чиновников.
  - (2026-08-16) Уехать жить в в другую страну — это одно. Но как там встать на ноги и выстроить связи? Может, поступить на PhD? . Инструкция о том, как стать доктором наук и точно ли оно вам нужно | LEDE: В] (ru: Уех…
      В конце 2025 — начале 2026 года россияне снова стали искать в Google, как уехать из страны. Число запросов приблизилось к тому, что было зафиксировано в начале 2023 года. Однако просто уехать — лишь половина дела. Эмигра…
  - (2026-08-16) Комары — не просто надоедливые, но и опасные насекомые: они убивают сотни тысяч людей каждый год. И бороться с ними все сложнее | LEDE: По данным ВОЗ, комары ответственны примерно за 700 тыс] (ru: Ком…
      По данным ВОЗ, комары ответственны примерно за 700 тысяч человеческих смертей каждый год. Причиной большинства становится переносимая насекомыми малярия. При этом они живут по всему миру, за исключением Антарктиды. И в п…
  - (2026-08-16) В Румынию в ночь удара России по Украине залетел беспилотник. Его сбил испанский истребитель | LEDE: В ночь на 16 августа в воздушное пространство Румынии залетел беспилотник, который обнару] (ru: В Р…
      В ночь на 16 августа в воздушное пространство Румынии залетел беспилотник, который обнаружили системы наблюдения Минобороны страны.
  - (2026-08-16) Россия атаковала Кривой Рог и Киев. Есть погибшие и пострадавшие. Минобороны РФ утверждает, что поражено производство комплектующих для ракет «Фламинго» | LEDE: Россия в ночь на 16 августа а] (ru: Рос…
      Россия в ночь на 16 августа атаковала Киев и Кривой Рог в Днепропетровской области ракетами и беспилотниками.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 206 new of 265 total
  - (2026-08-16) 图片报道-2026夏季达沃斯论坛-手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTFBJQTBjRGdNM3J5N3d5N2ZvNG1NOF9oVWNMRzgwWkxKRUVfUjg4SlcxOGlYQ0JEbzc0bjhDOEs5VFRzQ2dwZVBQTHNJNHRoQVV] (zh:…
      图片报道-2026夏季达沃斯论坛-手机财新网 财新
  - (2026-08-15) 一周天下｜哥伦比亚地震造成265人死亡、强台风“白海豚” 致多地降水突破历史极值 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBZYUFPbFBBOHY4VGlaTXJlQ0hrbTFxR1FHR1JjcnZubVVNUmVvVzgxTkpoMWlTZ1hZc0ZoY3oxdEVzU] (zh:…
      一周天下｜哥伦比亚地震造成265人死亡、强台风“白海豚” 致多地降水突破历史极值 财新
  - (2026-08-15) 黑白的骷髅，彩色的花朵｜观展 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE43a2YzY0tKY0VMbUUtaW9ycEFXZlFFLU80SUhmRTg4bElmN1hOSjhILThWRE9MRU5WRFFUQVFRb05acDNRdXBiRER2TzhtQnR2Ym02bkF] (zh:…
      黑白的骷髅，彩色的花朵｜观展 财新
  - (2026-08-15) 朱镕基捐版税做慈善，“一分钱不留”｜纪念 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1QVGhTTmt1Q0l1SG1JLVNQQ1FDMEhXbGw0U3NwVThaWEtiV1RacjJYMDc4cUkxOG9BdGFvaV9heTFYS0RtZzNQSVZkUjh2MmZlb] (zh:…
      朱镕基捐版税做慈善，“一分钱不留”｜纪念 财新
  - (2026-08-16) 海航一航班备降俄罗斯 更换飞机后再飞曼彻斯特 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE84TmE4Wk5JUktJX1ZoTzRPeUJSX3IxdjFPRUxfZHJIcXF0dDJ4dTNTSFJtWjE5aE1TNkZwNU01UGtzaFJTbXdTRjBSRHFyLTV] (zh:…
      海航一航班备降俄罗斯 更换飞机后再飞曼彻斯特 财新
  - (2026-08-15) 旅行最大的乐趣之一，其实是回家｜生命情感对话⑧ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBrT0tHQWctdWFyZWEzRllINzdjY0NkeHg3dFVxT2pSNlhOeUl3dDg1dmhzbXlDYUNBQVNfOFNNTmZabUJudVBQMFhhLWFvSj] (zh:…
      旅行最大的乐趣之一，其实是回家｜生命情感对话⑧ 财新

### U.S. Weather + Severe / Climate Outlooks — 194 new of 196 total
  - (2026-08-16) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 16 at 4:23AM CDT until August 16 at 5:15AM CDT by NWS Omaha/Valley NE
      SVROAX The National Weather Service in Omaha has issued a * Severe Thunderstorm Warning for... Southwestern Lancaster County in southeastern Nebraska... Jefferson County in southeastern Nebraska... Saline County in south…
  - (2026-08-16) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-16) [Moderate] Heat Advisory: Heat Advisory issued August 16 at 5:13AM EDT until August 16 at 8:00PM EDT by NWS Raleigh NC
      * WHAT...Heat index values up to 107 expected. * WHERE...A portion of central North Carolina. * WHEN...From 11 AM this morning to 8 PM EDT this evening. * IMPACTS...Hot temperatures and high humidity may cause heat illne…
  - (2026-08-16) [Severe] Flood Watch: Flood Watch issued August 16 at 5:12AM EDT until August 16 at 10:00PM EDT by NWS State College PA
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of central Pennsylvania, including the following counties, Bedford, Blair, Cambria, Franklin, Fulton, Huntingdon and Some…
  - (2026-08-16) [Severe] Flash Flood Warning: Flash Flood Warning issued August 16 at 5:10AM EDT until August 16 at 9:00AM EDT by NWS Charleston WV
      FFWRLX The National Weather Service in Charleston has extended the * Flash Flood Warning for... Perry County in southeastern Ohio... * Until 900 AM EDT. * At 510 AM EDT, emergency management reported thunderstorms had pr…
  - (2026-08-15) [Moderate] Tropical Cyclone Local Statement: Tropical Cyclone Local Statement issued August 15 at 11:08PM HST by NWS Honolulu HI
      HLSHFO This product covers the Hawaiian islands **LALA REMAINS A HURRICANE AS IT BEGINS TO PULL AWAY FROM THE BIG ISLAND** NEW INFORMATION --------------- * CHANGES TO WATCHES AND WARNINGS: - None * CURRENT WATCHES AND W…

### State-Level News — 103 new of 369 total
  - (2026-08-15) [California] After refinery explosions, California lawmakers move to preserve safety rules
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/10/100225-El-Segundo-Fire-AP-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-08-15) [California] US DOJ finds ‘unbroken pattern’ of sexual abuse by California prison staff
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/063026-CCWFTour_KQED_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-08-16) [Connecticut] CT’s first state-funded methadone vans expand access to treatment
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/MOBILE-METHADONE-0731-0717-SG-01-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=…
  - (2026-08-16) [Connecticut] The high-speed railroad never built — 120 years ago
      <img width="1024" height="642" src="https://ctmirror.org/wp-content/uploads/2026/08/Chicago-New_York_Electric_Air_Line_Railroad_Car_-La_Porte_IN-1024x642.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-08-16) [feed error] FL Governor (Florida): HTTPError
      404 Client Error: Not Found for url: https://www.flgov.com/feed/
  - (2026-08-16) [Hawaii] NEWS RELEASE – STATE OF HAWAIʻI UPDATE ON HURRICANE LALA
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA DEPARTMENT OF DEFENSE KA ʻOIHANA PILI KAUA HAWAI‘I EMERGENCY MANAGEMENT AGENCY KE‘ENA HO‘OMALU PŌULIA O HAWAI‘I HAWAIʻI JOINT INFORMATION CEN…

### Local News: St. Louis + Atlanta — 100 new of 204 total
  - (2026-08-16) [St. Louis] New aircraft carrier heads to the Middle East amid reports of issues on USS Abraham Lincoln
      The USS George Washington is departing the Pacific and expected to replace the USS Abraham Lincoln in the Middle East.
  - (2026-08-16) [St. Louis] Italian pasta maker closes on St. Charles factory
      Bertagni 1882 is taking over the former General Mills plant and is expected to create 150 jobs.
  - (2026-08-16) [St. Louis] 2 in custody after 6-month-old rescued from hot vehicle near North Kingshighway, police say
      Security personnel rescued the child from the vehicle, and he received immediate medical care.
  - (2026-08-16) [St. Louis] Heat pushes back start time for Day 2 of Blues at the Arch, but doesn't keep the crowds away
      Organizers delayed Saturday's Blues at the Arch by two hours because of the heat, but festivalgoers still turned out with fans, umbrellas and cold drinks.
  - (2026-08-16) [St. Louis] Lala strengthens into a hurricane and bears down on Hawaii’s Big Island with heavy rain, winds
      The National Hurricane Center said Lala’s maximum sustained winds increased to 75 mph, making it a Category 1 hurricane.
  - (2026-08-16) [St. Louis] Bruce Willis makes rare public appearance at daughter's wedding
      Bruce Willis attended his daughter Tallulah's wedding in Idaho on Saturday. Here are some photos of the Willis daughter's big day.

### State Legislative Action — 54 new of 62 total
  - (2026-08-15) [California AB 2329] Surplus residential property: condition-adjusted fair market value: Cities of Pasadena and South Pasadena.
      (1) Existing law establishes priorities and procedures that any state agency disposing of surplus property is required to follow. Existing law sets forth an order of priority for the disposal of specified surplus residen…
  - (2026-08-15) [California AB 2510] CalWORKs.
      (1) Under existing law, if the federal government provides funds for the care of a needy relative with whom a needy child is living, aid to the child for any month includes aid to meet the needs of that relative, except…
  - (2026-08-15) [California SB 977] Chain restaurants: children's meals.
      Existing law, the California Retail Food Code, establishes uniform health and sanitation standards for, and provides for regulation by the State Department of Public Health of, retail food facilities, as defined, and req…
  - (2026-08-15) [California AB 1604] Product safety: proofs of purchase: intentionally added bisphenols.
      Existing law prohibits a person from manufacturing, selling, or distributing in commerce any juvenile's feeding product or juvenile's sucking or teething product, as defined, that contains any form of bisphenol, as defin…
  - (2026-08-15) [California AB 2219] Veterans.
      Existing law authorizes the board of supervisors of each county to appoint a county veterans service officer to perform duties relating to the administration of benefits to veterans. Existing law authorizes the board to…
  - (2026-08-15) [California AB 2163] Energy: Strategic Clean Energy and Critical Mineral Development Zones.
      Existing law, the Warren-Alquist State Energy Resources Conservation and Development Act, establishes the State Energy Resources Conservation and Development Commission and prescribes the authorities, duties, and respons…

### Ukrainian Internal News (national + local Kyiv) — 50 new of 108 total
  - (2026-08-16) Двоє людей загинули внаслідок повені в Іспанії | LEDE: ] (uk: Двоє людей загинули внаслідок повені в Іспанії)
  - (2026-08-16) Росіяни вдарили балістикою по промислових об'єктах Кривого Рогу: 2 загиблих і 14 поранених | LEDE: У ніч на 16 серпня росіяни здійснили комбіновану атаку балістичними ракетами та БпЛА на Кривий] (uk:…
      У ніч на 16 серпня росіяни здійснили комбіновану атаку балістичними ракетами та БпЛА на Кривий Ріг. Унаслідок атаки дві людини загинули, ще 14 поранено.
  - (2026-08-16) Генштаб підтвердив ураження ракетного підрозділу в Криму та мосту на Запоріжжі | LEDE: У ніч на 16 серпня Сили оборони уразили район зосередження російського ракетного підрозділу в окупованому ] (uk:…
      У ніч на 16 серпня Сили оборони уразили район зосередження російського ракетного підрозділу в окупованому Криму, залізничний міст на Запоріжжі та склади противника на Донеччині.
  - (2026-08-16) У Сумах російський дрон влучив в автомобіль: загинув чоловік, дружина поранена | LEDE: У Сумах дрон РФ влучив у цивільний автомобіль: один загиблий, одна поранена, пошкоджено інфраструктуру.] (uk: У С…
      У Сумах дрон РФ влучив у цивільний автомобіль: один загиблий, одна поранена, пошкоджено інфраструктуру.
  - (2026-08-16) Понад сотню мігрантів було заарештовано у спробах прорватися до іспанської Сеути | LEDE: ] (uk: Понад сотню мігрантів було заарештовано у спробах прорватися до іспанської Сеути)
  - (2026-08-16) Винищувач НАТО збив дрон над Румунією | LEDE: Винищувач F-18 Іспанії збив безпілотник над Румунією. Це вже четвертий інцидент вторгнення дрона в румунський повітряний простір.] (uk: Винищувач НАТО зби…
      Винищувач F-18 Іспанії збив безпілотник над Румунією. Це вже четвертий інцидент вторгнення дрона в румунський повітряний простір.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-16) [Russia oil sanctions perimeter · themes] 米イラン 「 不安定な膠着 」／ 覚書期限 、 海峡開放見えず | 全国ニュース
      shikoku-np.co.jp · Japanese · tone NA
  - (2026-08-16) [Russia oil sanctions perimeter · themes] Disneyland offers sneak peek at new Coco boat ride
      sbsun.com · English · tone NA
  - (2026-08-16) [Russia oil sanctions perimeter · themes] В Петербурге врачи спасли подростка с язвой , проведя уникальную операцию
      life.ru · Russian · tone NA
  - (2026-08-16) [Russia oil sanctions perimeter · themes] Giá vàng hôm nay ( chiều 16 - 8 ): Vàng SJC giữ ngưỡng 144 triệu đồng / lượng bán ra
      baomoi.com · Vietnamese · tone NA
  - (2026-08-16) [Russia oil sanctions perimeter · themes] القضاء العراقي يكشف عن كمية الأموال والذهب المضبوطة بقضية فساد عدنان الجميلي
      arabic.cnn.com · Arabic · tone NA
  - (2026-08-16) [Russia oil sanctions perimeter · themes] Người đàn ông cào nghêu kể hành trình sống sót sau hơn 10 giờ trôi dạt giữa biển
      tienphong.vn · Vietnamese · tone NA

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 29 total
  - (2026-08-16) CFC01 (Canada)
      icao24: c2c1f1 · position: (42.697, 10.9382) · alt: 1783m · 477km/h
  - (2026-08-16) SAM365 (United States)
      icao24: adfeb8 · position: (56.2152, -5.7575) · alt: 6301m · 705km/h
  - (2026-08-16) GAF666 (Germany)
      icao24: 3e0f77 · position: (51.5927, 11.1054) · alt: 830m · 238km/h
  - (2026-08-16) RFF02 (Portugal)
      icao24: 496ca4 · position: (37.016, -7.9578) · on ground · 29km/h
  - (2026-08-16) CFC2982 (Canada)
      icao24: c2b585 · position: (41.3108, -0.7567) · alt: 9144m · 606km/h
  - (2026-08-16) JAF99Y (Spain)
      icao24: 346516 · position: (45.0689, -3.2365) · alt: 10972m · 809km/h

### USGS earthquakes (M4.5+, past day) — 25 new of 25 total
  - (2026-08-15) M 6.9 - 15 km NNW of Pematangsiantar, Indonesia
      M6.9 · 15 km NNW of Pematangsiantar, Indonesia · depth 172.526 km
  - (2026-08-16) M 6.1 - 56 km NNE of Port-Olry, Vanuatu
      M6.1 · 56 km NNE of Port-Olry, Vanuatu · depth 188.148 km
  - (2026-08-15) M 5.7 - 125 km NNE of Palu, Indonesia
      M5.7 · 125 km NNE of Palu, Indonesia · depth 72.495 km
  - (2026-08-16) M 5.5 - 76 km N of Ruteng, Indonesia
      M5.5 · 76 km N of Ruteng, Indonesia · depth 10 km
  - (2026-08-15) M 5.5 - Volcano Islands, Japan region
      M5.5 · Volcano Islands, Japan region · depth 39.954 km
  - (2026-08-15) M 5.4 - 19 km NE of Colonia, Micronesia
      M5.4 · 19 km NE of Colonia, Micronesia · depth 10 km

### Paper Trading Scorecard — 22 new of 142 total
  - (2026-08-16) [Polymarket] Valorant: Fire Flux Esports vs Joblife (BO3) - VCT EMEA Play-Ins
      This market refers to the Valorant Lower bracket semifinal 2 match between Fire Flux Esports and Joblife in the VCT EMEA Play-Ins, initially scheduled for August 16, 2026 at 12:00 PM ET. This market will resolve to "Fire…
  - (2026-08-16) [Polymarket] Will Ethereum reach $2,000 August 10-16?
      This market will immediately resolve to "Yes" if any Binance 1-minute candle for ETH/USDT during the date range specified in the title (from 12:00 AM ET on the first date to 11:59 PM ET on the last) has a final "High" pr…
  - (2026-08-16) [Polymarket] Will Anthropic's valuation hit (HIGH) $5.0T by December 31?
      This market will resolve to "Yes" if Anthropic's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or…
  - (2026-08-16) [Polymarket] Will an international court find Israel or its leaders guilty of Genocide by December 31, 2027?
      This market will resolve to "Yes" if he International Criminal Court ("ICC"), the International Court of Justice ("ICJ"), or any ad hoc international tribunal with recognized legal standing, issues a judgment or convicti…
  - (2026-08-16) [Polymarket] Will MicroStrategy be margin called in 2026?
      This market will resolve to "Yes" if MicroStrategy incorporated is margin called on any of its Bitcoin-backed loans by December 31, 2026, 11:59 PM ET, resulting in either a forced liquidation of Bitcoin by a lender or Mi…
  - (2026-08-16) [Polymarket] Will Josh Stein win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-08-16) Dota 2: Team Spirit vs Team Resilience (BO3) - The International Elimination Round
      yes price: 100% · 24h volume: $2,049,232 · resolves 2026-08-16
  - (2026-08-16) Dota 2: Aurora vs BoomBoys - Game 1 Winner
      yes price: 0% · 24h volume: $1,333,075 · resolves 2026-08-16
  - (2026-08-16) LoL: T1 vs Gen.G - Game 1 Winner
      yes price: 0% · 24h volume: $1,182,923 · resolves 2026-08-16
  - (2026-08-16) Dota 2: LGD Gaming vs Team Yandex - Game 1 Winner
      yes price: 100% · 24h volume: $1,117,292 · resolves 2026-08-16
  - (2026-08-16) LoL: LGD Gaming vs JD Gaming (BO3) - LPL Group Ascend
      yes price: 57% · 24h volume: $948,105 · resolves 2026-08-16
  - (2026-08-16) LoL: LGD Gaming vs JD Gaming - Game 1 Winner
      yes price: 0% · 24h volume: $794,660 · resolves 2026-08-16

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: Alyse Sanchez v. Markwayne Mullin
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: United States v. Danny Roney
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: United States v. Zerion Franklin
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: Wanrong Lin v. Markwayne Mullin
  - (2026-08-14) U.S. Court of Appeals, 4th Cir.: United States v. Earl Griffin, Jr.
  - (2026-08-13) U.S. Court of Appeals, 6th Cir.: Derek Antol v. Robert English

### IT, InfoSys & cybersecurity news (last 7 days) — 9 new of 53 total
  - (2026-08-15) [BleepingComputer] New Evooo1Bot Linux botnet turns routers into traffic relay nodes
      A new Mirai-based modular Linux botnet malware called Evooo1Bot has been targeting internet-facing gateway devices, turning them into SOCKS5 traffic relay nodes. [...]
  - (2026-08-15) [Ars Technica] VisionQuest trailer kicks off Disney's D23 fan event
      Also: Ahsoka S2 teaser, Doomsday trailer, news about MCU's X-Men and Star Wars: Starfighter
  - (2026-08-15) [Ars Technica] Ukraine strikes major Russian rocket factory with cruise missiles
      "Flamingo missiles were used. A good achievement."
  - (2026-08-15) [Ars Technica] So much solar: Digging into the list of every US power plant that went online this year
      Utility-scale solar leads by a mile, followed by batteries. Fossil fuels, not so much.
  - (2026-08-15) [TechCrunch] Woman claims her stepfather used Grok to transform childhood photo into explicit imagery
      The woman claimed that AI tools are "taking everyday life and turning it into child sexual abuse."
  - (2026-08-15) [TechCrunch] Anthropic shares more details about how Claude’s new watermarks will work
      How will the watermarking actually work? Can it be hidden with editing? And how does this affect code?

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-16) [China] From breast milk to menstrual blood , how artist Jiabao Li challenges norms
      scmp.com · English
  - (2026-08-16) [China] I gave Tencent WeChat AI agent control for 24 hours : where it excelled – and stumbled
      scmp.com · English
  - (2026-08-16) [China] Taiwan groups warn of Taiwan Strait security risks due to Japan neo - militarism
      taiwansun.com · English
  - (2026-08-16) [China] 13th birthday celebration held for giant panda brothers in Haikou , China Hainan
      en.people.cn · English
  - (2026-08-16) [China] Taiwan groups warn of Taiwan Strait security risks due to Japan neo - militarism
      hongkongherald.com · English
  - (2026-08-16) [China] Remains of late Chinese leader Zhu Rongji to be cremated
      hongkongherald.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 93 total
  - (2026-08-16) [USASpending] $35,144,939,584 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-08-16) [USASpending] $10,524,604,426 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration. Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF…
  - (2026-08-16) [USASpending] $2,136,203,664 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.
  - (2026-08-16) [USASpending] $683,605,366 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-08-16) [USASpending] $666,810,964 → LEIDOS, INC.: FUTURE FLIGHT SERVICES PROGRAM
      Agency: Department of Transportation. Description: FUTURE FLIGHT SERVICES PROGRAM

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-16) [Marginal Revolution] Another rationale for sticky prices?
      …what can be predicted, Dabis said, is that a recent policy change by the Washington Metropolitan Area Transit Authority requiring drivers to verbally quote the $2.25 fare to passengers may make their job even riskier. E…
  - (2026-08-15) [Marginal Revolution] Adolfo Bioy Cesares delay
      My Amazon shipment is postponed from this fall until April 11, 2028 (!). Will it ever come? Of course this is the fantastic, and long, Bioy Cesares book Borges, his memoir of their friendship. How can the reoptimization…
  - (2026-08-15) [Marginal Revolution] Saturday assorted links
      1. Speculative Chinese claims about Alzheimer’s. 2. Very interesting Anthropic piece on why multi-agentic systems seem to show more herd behavior and collusion than human systems. And a comment from Rune Kvist. 3. Cross-…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-16) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: state, special, service, procedures, program, final, remove, action, proposed, coast, proposes, provide
- state_bills: today=62, 7d-median=129, 14d-median=124; carrying terms: government, order, based, family, state, jurisdiction, licensing, agency, known, social, regulatory, related
- state_news: today=369, 7d-median=585, 14d-median=686; carrying terms: majority, court, based, family, virginia, changes, image, least, agency, social, tribune, project
- local_news: today=204, 7d-median=229, 14d-median=234; carrying terms: family, image, apartment, accused, nearly, announced, content, magazine, louis, families, child, uploads
- foreign_news: today=940, 7d-median=1007, 14d-median=1022; carrying terms: unbroken, tibet, daughter, court, chinese, firms, packing, sector, changes, director, corruption, least
- chinese_internal: today=265, 7d-median=269, 14d-median=270; carrying terms: lxtfb, chinese, lxtfa, cbmiyefvx, cbmidefvx, cbmickfvx, cbmib, https, cbmibkfvx, china, target, cbmiw
- russian_internal: today=832, 7d-median=1040, 14d-median=1060; carrying terms: forbidden, guardian, europe, media, politico, novaya, gazeta, patriot, wildberries, telegram, title, russian
- ukrainian_internal: today=108, 7d-median=108, 14d-median=108; carrying terms: court, ukrinform, least, campaign, senior, destroyed, hromadske, nearly, announced, missile, infrastructure, civilian
- ukraine_theater: today=1338, 7d-median=1025, 14d-median=920; carrying terms: zdzzoqkc, cdnlvuvcynziotvyowc, firms, bzzomxpzm, based, cuxqehhlsklvzgh, module, llmkxytkhjv, eulqzlzsmjl, jbwjvqvzdizlctanphvfowtgt, cbmiqafbvv, agency
- paper_bets: today=142, 7d-median=129, 14d-median=138; carrying terms: court, nominee, prime, georgia, leave, virginia, michigan, state, african, successor, midterms, according
- weather: today=196, 7d-median=196, 14d-median=197; carrying terms: afdmeg, tulsa, hurricane, mountains, state, changes, result, depth, related, atlantic, holly, monitoring
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: vixcls, payems, growth, pcepilfe, total, balance, energy, jtsjol, walcl, unrate, rates, dexjpus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: futures, agriculture, large, nasdaq, close, corporate, crude, yield, treasury, equities, credit, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=93, 7d-median=99, 14d-median=99; carrying terms: order, attacks, government, burundi, sanctions, company, niger, destabilising, transition, services, sovereignty, african
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, unauthorized, https, quiver, quiverquant, error, congresstrading, client, httperror
- billionaires: today=30, 7d-median=34, 14d-median=34; carrying terms: canada, mukesh, ellison, peterffy, jensen, spacex, semiconductors, bezos, charles, carlos, arnault, ortega
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, company, blanche, state, group, supreme, connecticut, appeals, trade, international, health, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, accno, reporting, robert, richard, financial, partners, david, capital
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: jonathan, ossoff, robert, house, johnson, sherrod, raised, talarico, cooper, committee, ocasio, brown
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan
- gdelt_gkg: today=50, 7d-median=25, 14d-median=42; carrying terms: english, russian, themes, chinese, spanish, trump, hezbollah, israel, indonesian, arabic, russia, strait
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=29, 7d-median=30, 14d-median=28; carrying terms: position, belgium, ground, france, kingdom, canada, germany, spain
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: government, hygiene, canada, determined, since, dhaka, surges, majority, producing, bulape, geographically, inconclusive
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: cisco, tomcat, alternate, missing, sensitive, central, remediation, firewall, authentication, vendor, deserialization, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=258; carrying terms: australia, canada, herzegovina, tanzania, madagascar, fires, guinea, mexico, bosnia, tropical, salvador, democratic
- usgs_quakes: today=25, 7d-median=16, 14d-median=14; carrying terms: depth, indonesia, russia, islands, japan, region, vanuatu, papua, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, donetsk, winner, meeting, strait, league, champions, august, rates, traffic, september, returns
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, marginal, revolution, economist, https, conversable, conversableeconomist, future, believe, current, young, impossible
- tech_news: today=53, 7d-median=58, 14d-median=56; carrying terms: government, vulnerabilities, tools, according, least, known, krebs, newsletter, companies, intelligence, infrastructure, organizations
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: sonderling, clarke, womack, hawley, fuller, summer, court, nicholas, hegseth, schweikert, underwood, fallon
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, placed, identify, converges, evidence, module, market, claude, paper, sufficient, consensus, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*