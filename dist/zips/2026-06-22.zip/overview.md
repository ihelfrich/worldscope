# WORLDSCOPE morning brief — 2026-06-22

## Headline
4419 new items across 30 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (877) · Russian Internal News (state + in-exile) (854) · Ukraine Theater (total-war monitoring) (553) · State-Level News (372) · World leaders & government officials (324) · Chinese Internal News (236) · Local News: St. Louis + Atlanta (213) · U.S. Weather + Severe / Climate Outlooks (174) · State Legislative Action (145) · GDACS — global disaster alerts (100) · Ukrainian Internal News (national + local Kyiv) (89) · Congressional STOCK Act Trades (House + Senate) (68)

## What changed today
### International News + Multilateral Institutions — 877 new of 1015 total
  - (2026-06-22) [Global] US eases oil sanctions as Iran denies Vance claim on nuclear inspectors
      Iran's foreign ministry says it made "no new commitments" on nuclear inspections after talks in Switzerland.
  - (2026-06-22) [Global] At least 13 killed and dozens injured after Qatar gas explosion
      The city's main liquified natural gas (LNG) processing site suffered a "technical accident" in the Ras Laffan industrial zone.
  - (2026-06-22) [Global] Myanmar army killed over 700 civilians in six months, UN says
      The new UN report says the 702 civilian deaths over six months last year included 153 children.
  - (2026-06-21) [Global] Russian troop build-up threatens city seen as key to seizing Ukraine's Donbas
      If Kostyantynivka falls, Russian forces would be able push towards Ukraine's last remaining strongholds in the east.
  - (2026-06-22) [Global] Clive Davis, music mogul behind Whitney Houston and Bruce Springsteen, dies aged 94
      The record company executive also worked with Billy Joel, Pink Floyd, Alicia Keys and Aerosmith.
  - (2026-06-22) [Global] Red heat alerts issued in France, Italy and Spain as 40C temperatures forecast
      The heatwave conditions are forecast to intensify in the coming days across central and western Europe.

### Russian Internal News (state + in-exile) — 854 new of 857 total
  - (2026-06-22) Месси стал лучшим бомбардиром в истории чемпионатов мира | LEDE: Нападающий и капитан сборной Аргентины по футболу Лионель Месси благодаря голу в матче с Австрией стал лучшим бомбардиром в и] (ru: Мес…
      Нападающий и капитан сборной Аргентины по футболу Лионель Месси благодаря голу в матче с Австрией стал лучшим бомбардиром в истории чемпионатов мира.
  - (2026-06-22) Индекс Мосбиржи упал за день более чем на 4%. Это самое сильное падение с сентября 2022 года | LEDE: Индекс Мосбиржи (IMOEX) по итогам основной сессии 22 июня упал на 4,23% — до 2318,28 пунк] (ru: Инд…
      Индекс Мосбиржи (IMOEX) по итогам основной сессии 22 июня упал на 4,23% — до 2318,28 пункта, что стало самым сильным падением за день с 26 сентября 2022 года. Об этом сообщает РБК.
  - (2026-06-22) Трамп помнит все обиды и считает себя самым могущественным в мире (а еще пачкает суперклеем Овальный кабинет). Что мы узнали о президенте США из новой книги журналистов The New York Times | LED] (ru:…
      Корреспонденты The New York Times Мэгги Хаберман и Джонатан Свон написали книгу «Смена режима» о Дональде Трампе и его окружении. В ее основе — более тысячи интервью (в том числе с самим президентом США), которые журнали…
  - (2026-06-22) В Эстонии в поле нашли беспилотник с пятью килограммами взрывчатки | LEDE: В эстонском поселке Рыуге местный житель, пришедший на покос травы, нашел на поле беспилотник, к которому было прик] (ru: В Э…
      В эстонском поселке Рыуге местный житель, пришедший на покос травы, нашел на поле беспилотник, к которому было прикреплено взрывное устройство весом около пяти килограммов. Об этом сообщил руководитель бюро департамента…
  - (2026-06-22) В Воронеже погибли пять человек в результате ракетной атаки ВСУ | LEDE: В результате ракетной атаки ВСУ по Воронежу погибли пять человек, сообщил губернатор Воронежской области. По его данны] (ru: В В…
      В результате ракетной атаки ВСУ по Воронежу погибли пять человек, сообщил губернатор Воронежской области. По его данным, в медицинские учреждения обратились несколько десятков граждан, большинство из них отпустили домой…
  - (2026-06-22) «Путин сажает в тюрьмы тысячи людей, которые против войны. Я пыталась им помочь, но мои силы кончились». Правозащитница Нина Литвинова покончила с собой. «Гласная» рассказывает историю «самой т] (ru:…
      12 мая в Москве покончила с собой диссидентка и правозащитница Нина Литвинова, которая всю свою жизнь, с конца 1960-х годов, посвятила помощи политзаключенным сначала в СССР, а затем и в России. Двоюродная сестра Литвино…

### Ukraine Theater (total-war monitoring) — 553 new of 656 total
  - (2026-06-23) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-21) [FIRMS] thermal anomaly 52.807, 32.228 (FRP 1.79 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-21 0043Z, FRP 1.79 MW
  - (2026-06-21) [FIRMS] thermal anomaly 52.237, 32.820 (FRP 2.48 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-21 0043Z, FRP 2.48 MW
  - (2026-06-21) [FIRMS] thermal anomaly 52.847, 29.993 (FRP 3.26 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-21 0043Z, FRP 3.26 MW
  - (2026-06-21) [FIRMS] thermal anomaly 52.849, 29.986 (FRP 3.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-21 0043Z, FRP 3.37 MW
  - (2026-06-21) [FIRMS] thermal anomaly 51.669, 34.249 (FRP 0.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-21 0043Z, FRP 0.53 MW

### State-Level News — 372 new of 385 total
  - (2026-06-22) [Alabama] Governor Ivey Announces Alabama STEM Council Executive Committee Appointments
      MONTGOMERY – Governor Kay Ivey, in conjunction with Alabama Department of Workforce (ADOW) Secretary Greg Reed, has announced new appointments to the Alabama STEM Council. The appointees represent key sectors across Alab…
  - (2026-06-22) [California] California leaders announce historic Veterans and Affordable Housing Bond Act of 2026 to expand homeownership and build affordable housing for generations of Californians
      <a href="https://www.gov.ca.gov/2026/06/22/california-leaders-ann
  - (2026-06-22) [California] Governor Newsom announces $1.3 billion in new private investment, creating thousands of new jobs in key industries across California
      Source
  - (2026-06-21) [California] Gobernador Newsom declara Estado de Emergencia en el Condado de Los Ángeles por la respuesta al incendio en Boyle Heights
      Source
  - (2026-06-21) [California] Governor Newsom proclaims State of Emergency in Los Angeles for the Boyle Heights fire response
      Source
  - (2026-06-22) [California] L.A, Unified superintendent resigns amid FBI probe into chatbot contract
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/011422_Alberto-Carvalho_GETTY_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 236 new of 251 total
  - (2026-06-22) 加快世界一流港口建设推动港航贸一体化发展新闻发布会--福建频道--人民网_网上的人民日报 - 人民网-福建频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80T2JZVXQ3LTdkVUZJSFVWeVRlb0JVOWhsa1NySDlBVHEwaHdBR3F3ck1xNjU5alVTZHJ] (zh:…
      加快世界一流港口建设推动港航贸一体化发展新闻发布会--福建频道--人民网_网上的人民日报 人民网-福建频道
  - (2026-06-22) “茶和天下”端午游园会在悉尼举行 - 人民网澳新频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE42ZVRCWWpveXBJckRZWGxsdGNRczQxN2xIR3NWemE0N3pVb3JlMFpFQmwwUzFLWEtyNWk5R19vWlNja0V4SHR1MWY5QjZPb3Jm] (zh:…
      “茶和天下”端午游园会在悉尼举行 人民网澳新频道
  - (2026-06-22) “乔治·莫兰迪：独白”在浦东美术馆开幕 - 灵境·人民艺术馆 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBFalkyb2xqVzNJUEcxTGRiWDFZM2dXWjlwX0RwOWxEOGEzQWdrYXc2S0ZySFRTMlBrdC1Ba3NYS2lNWG45Y2hKb3h0NnYt] (zh:…
      “乔治·莫兰迪：独白”在浦东美术馆开幕 灵境·人民艺术馆
  - (2026-06-22) 时政微周刊丨总书记的一周（6月15日—6月21日） - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTE1nN0RGRnZrZWFRcWU4U1BhNk5iR2xSTWdUUHFsWGNtN25IMk1IT1gyUHdqYkZfdmx3RkxiRHg3] (zh:…
      时政微周刊丨总书记的一周（6月15日—6月21日） politics.people.com.cn
  - (2026-06-22) 海军航空兵某旅开展飞行训练 - 人民网军事 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1Kb3M0YjUzVGJ3X0Q4bkcwa29pM2FaRURPNlBLazNQdzF4eHpsSDlCSUFCbGRoMGZNSjk4RWUzUWQzci1MR2VzVGhTMUhZazZsdWpDb] (zh:…
      海军航空兵某旅开展飞行训练 人民网军事
  - (2026-06-22) 生态“天路” 高原牧歌（走近自然） - 共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5OcTFtZ3V0Q0FjTVRpekE1NmRWZnJXNTg0UDZITTdoT0pEMWU1R1o4TDIwWnh5YVpHSUFpaWd1alBzTWdWT3ROb3JlUjBwTV9n] (zh:…
      生态“天路” 高原牧歌（走近自然） 共产党新闻网

### Local News: St. Louis + Atlanta — 213 new of 214 total
  - (2026-06-22) [St. Louis] As Forest Park turns 150, take a look at a day in the life of St. Louis’ crown jewel
      Forest Park opened a century and a half ago, in the summer of 1876. The timing was perfect: The nation’s fourth-largest city could celebrate its new park and the nation’s centennial. Horse-drawn carriages clopped along t…
  - (2026-06-22) [St. Louis] Pickle & Perk is a pickleball-themed retreat a short drive from St. Louis
      With a pickleball court now found in every corner of both urban and suburban areas, avid picklers are hitting the road for a more specialized spot to dink. Pickleball tourism is gaining popularity, and a new destination…
  - (2026-06-22) [St. Louis] A St. Louisan’s guide to a summer weekend getaway in Chicago
      Events & Exhibits Events & Exhibits “Willem de Kooning Drawing” at the Art Institute Chicago | Through September 20 As one of the world’s most celebrated draftsmen, Willem de Kooning had an expansive drawing practice tha…
  - (2026-06-22) [St. Louis] Review: The Key STL hits all the right notes in Grand Center
      Many years ago, not long after I first began reviewing restaurants, I came up with two rules of thumb that nearly always ring true: First, restaurants named after their numerical addresses (Think “Bistro 1234”) are almos…
  - (2026-06-22) [St. Louis] 5-day fireworks battle in LaSalle Park ends with one person detained—a neighbor who mouthed off to police
      For five nights, Zach Chasnoff says he called the police asking them to do something about the youths terrorizing his LaSalle Park neighborhood, blasting off fireworks, setting a dumpster aflame, and threatening to take…
  - (2026-06-22) [St. Louis] Gravois is still deadly, but other St. Louis streets are getting calmer, Trailnet reports
      For the past five years, Trailnet’s annual Crash Report has documented the dangers that pedestrians and cyclists face on St. Louis streets. Beginning in the city in 2020 and expanding to include St. Louis County in 2021,…

### U.S. Weather + Severe / Climate Outlooks — 174 new of 176 total
  - (2026-06-22) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued June 22 at 8:00PM EDT until June 23 at 8:00PM EDT by NWS Newport/Morehead City NC
      * WHAT...Strong longshore currents in the surf zone. * WHERE...The beaches from Oregon Inlet to Surf City. * WHEN...Through Tuesday evening. * IMPACTS...Strong longshore currents will create dangerous swimming conditions…
  - (2026-06-22) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 22 at 7:59PM EDT until June 22 at 8:30PM EDT by NWS Mount Holly NJ
      At 758 PM EDT, a severe thunderstorm was located over Batsto, or 21 miles northwest of Atlantic City, moving east at 20 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Minor dama…
  - (2026-06-22) [Extreme] Tornado Warning: Tornado Warning issued June 22 at 5:59PM MDT until June 22 at 6:15PM MDT by NWS Pueblo CO
      At 558 PM MDT, a confirmed tornado was located over Fowler, or 25 miles west of La Junta, moving east at 25 mph. No new tornadoes have been observed in the last 10 minutes, but strong rotation is still located in the Fow…
  - (2026-06-22) [Moderate] Special Weather Statement: Special Weather Statement issued June 22 at 7:59PM EDT by NWS Columbia SC
      At 759 PM EDT, Doppler radar was tracking a strong thunderstorm over South Augusta, or over Fort Gordon, moving northeast at 30 mph. HAZARD...Wind gusts 35 to 45 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could…
  - (2026-06-22) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-22) [Moderate] Special Weather Statement: Special Weather Statement issued June 22 at 7:58PM EDT by NWS Charleston WV
      At 758 PM EDT, Doppler radar was tracking a strong thunderstorm over Jackson Mill, or near Weston, moving east at 25 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down…

### State Legislative Action — 145 new of 152 total
  - (2026-06-22) [Alabama SB 146] Appropriations from State General Fund for executive, legislative, and judicial agencies of the State, other functions of government, debt service, and capital outlay for fiscal year…
      Appropriations
  - (2026-06-22) [Alaska HB 39] An Act relating to public school students who are deaf or hard of hearing.
      An Act relating to public school students who are deaf or hard of hearing.
  - (2026-06-22) [Alaska HB 195] An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to th…
      An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to the prescription of opioid overdose dr…
  - (2026-06-22) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-06-22) [Alaska HB 36] An Act relating to treatment foster homes; relating to the placement of foster children in hospitals and residential psychiatric treatment centers for psychiatric care; relating to the…
      An Act relating to treatment foster homes; relating to the placement of foster children in hospitals and residential psychiatric treatment centers for psychiatric care; relating to the duties of the Department of Family…
  - (2026-06-22) [Alaska HB 13] An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobi…
      An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobile intensive care paramedic service…

### GDACS — global disaster alerts — 100 new of 120 total
  - (2026-06-17) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-06-17) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-06-17) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-06-19) [Green] Flood in Ghana
      Flood · Green alert · Ghana · Magnitude 0
  - (2026-06-19) [Green] Flood in Ghana
      Flood · Green alert · Ghana · Magnitude 0
  - (2026-06-19) [Green] Flood in Ghana
      Flood · Green alert · Ghana · Magnitude 0

### Ukrainian Internal News (national + local Kyiv) — 89 new of 97 total
  - (2026-06-23) Росіяни атакували Запоріжжя: двоє поранених, пошкоджено будинки, СТО та АЗС | LEDE: Унаслідок російського удару по Запорізькому району отримали поранення двоє літніх людей, а також пошкоджено ж] (uk:…
      Унаслідок російського удару по Запорізькому району отримали поранення двоє літніх людей, а також пошкоджено житлові будинки, станцію технічного обслуговування та автозаправну станцію.
  - (2026-06-23) ООН: Травень став найсмертоноснішим місяцем для цивільних в Україні з 2022 року | LEDE: Помічник генерального секретаря ООН з питань Близького Сходу, Азії та Тихоокеанського регіону Мохаммед Ха] (uk:…
      Помічник генерального секретаря ООН з питань Близького Сходу, Азії та Тихоокеанського регіону Мохаммед Халед Хіарі заявив, що внаслідок російських повітряних атак кількість загиблих і поранених цивільних осіб в Україні у…
  - (2026-06-23) "Час не на боці Москви": США зажадали від РФ негайно укласти мирну угоду | LEDE: Заступник постійного представника США при ООН Ден Негрі заявив, що Вашингтон підтримує Україну в захисті її своб] (uk:…
      Заступник постійного представника США при ООН Ден Негрі заявив, що Вашингтон підтримує Україну в захисті її свободи і суверенітету, та закликав Росію негайно повернутися до переговорів і укласти мирну угоду, оскільки час…
  - (2026-06-23) Мельник на Радбезі ООН попередив про зміну підходів України: "Наше терпіння не безмежне" | LEDE: Постійний представник України при ООН Андрій Мельник заявив, що терпіння України не є безмежним,] (uk:…
      Постійний представник України при ООН Андрій Мельник заявив, що терпіння України не є безмежним, та натякнув на можливу зміну підходів Києва, якщо Рада Безпеки ООН і надалі зволікатиме з реакцією на російську агресію.
  - (2026-06-23) Росіяни намагаються просочитися на околиці Лиману, складна ситуація в Ямполі та Озерному – DeepState | LEDE: Аналітики моніторингового проєкту DeepState повідомили, що російські окупаційні війс] (uk:…
      Аналітики моніторингового проєкту DeepState повідомили, що російські окупаційні війська намагаються просочитися на східні околиці Лиману Донецької області, а також попередили про складну ситуацію в районах населених пунк…
  - (2026-06-22) ЗМІ дізнались про непублічну промову Стармера після оголошення про відставку | LEDE: ] (uk: ЗМІ дізнались про непублічну промову Стармера після оголошення про відставку)

### Congressional STOCK Act Trades (House + Senate) — 68 new of 68 total
  - (2026-06-01) [House] Thomas H. Kean Jr (R): Purchase EQT ($1,001 - $15,000) (excess -6.2% vs SPY)
      Member: Thomas H. Kean Jr (R, house). BioGuide: K000398. Asset: EQT (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-06-01. Disclosure date: 2026-06-18. Excess return vs SPY since disclosure:…
  - (2026-06-01) [House] Thomas H. Kean Jr (R): Sale CHKP ($1,001 - $15,000) (excess -11.1% vs SPY)
      Member: Thomas H. Kean Jr (R, house). BioGuide: K000398. Asset: CHKP (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-06-01. Disclosure date: 2026-06-18. Excess return vs SPY since disclosure: -11…
  - (2026-06-16) [House] Matthew Robert Van Epps (R): Sale IBM ($1,001 - $15,000) (excess -8.5% vs SPY)
      Member: Matthew Robert Van Epps (R, house). BioGuide: V000139. Asset: IBM (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-06-16. Disclosure date: 2026-06-17. Excess return vs SPY since disclosure…
  - (2026-06-16) [House] Matthew Robert Van Epps (R): Sale GEV ($1,001 - $15,000) (excess +14.5% vs SPY)
      Member: Matthew Robert Van Epps (R, house). BioGuide: V000139. Asset: GEV (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-06-16. Disclosure date: 2026-06-17. Excess return vs SPY since disclosure…
  - (2026-06-16) [House] Matthew Robert Van Epps (R): Sale GE ($1,001 - $15,000) (excess +2.3% vs SPY)
      Member: Matthew Robert Van Epps (R, house). BioGuide: V000139. Asset: GE (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-06-16. Disclosure date: 2026-06-17. Excess return vs SPY since disclosure:…
  - (2026-06-16) [House] Matthew Robert Van Epps (R): Sale AMZN ($1,001 - $15,000) (excess -4.6% vs SPY)
      Member: Matthew Robert Van Epps (R, house). BioGuide: V000139. Asset: AMZN (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-06-16. Disclosure date: 2026-06-17. Excess return vs SPY since disclosur…

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-06-23) Connecticut Supreme Court: State v. Raeon A.
  - (2026-06-22) U.S. Supreme Court: McCarthy v. Hernandez
  - (2026-06-22) U.S. Court of Appeals, 3rd Cir.: Lawanda House Johnson v. Quest Diagnostics Inc
  - (2026-06-22) U.S. Court of Appeals, D.C. Cir.: In re: Donald J. Trump
  - (2026-06-22) U.S. Court of Appeals, 7th Cir.: American Academy of Pediatrics v. James Uthmeier
  - (2026-06-22) U.S. Court of Appeals, 7th Cir.: Raymond Echevarria v. Darrin Jackson

### IT, InfoSys & cybersecurity news (last 7 days) — 51 new of 51 total
  - (2026-06-22) [BleepingComputer] WhatsApp phishing attack uses fake business docs to hack PCs
      An ongoing malware campaign is targeting WhatsApp users in multiple countries with deceptive messages that push VBScript files, leading to remote system access. [...]
  - (2026-06-22) [BleepingComputer] JaredFromSubway MEV bot hacked in $15 million crypto theft
      The JaredFromSubway Ethereum MEV (Maximal Extractable Value) bot suffered a $15 million loss after an attacker manipulated the opportunity-detection logic by creating fake cryptocurrency trading opportunities. [...]
  - (2026-06-22) [BleepingComputer] FFmpeg fixes PixelSmash flaw in widely used video decoder
      A newly disclosed FFmpeg flaw dubbed 'PixelSmash' could be exploited for remote code execution on Jellyfin servers under certain conditions, and can also trigger a denial-of-service condition in applications like Kodi, E…
  - (2026-06-22) [BleepingComputer] FortiBleed campaign used custom FortiGate sniffer to steal credentials
      Security firm SOCRadar says the large-scale FortiBleed campaign targeting Fortinet FortiGate devices used custom sniffers to harvest authentication secrets from compromised firewalls and steal credentials. [...]
  - (2026-06-22) [BleepingComputer] Microsoft says Windows 11 26H2 is coming soon, details upgrade process
      Microsoft has confirmed that Windows 11 version 26H2 will be the next feature update and that devices running Windows 11 24H2 and 25H2 will be able to upgrade using a small enablement package. [...]
  - (2026-06-22) [The Hacker News] ShapedPlugin WordPress Pro Plugins Backdoored in Supply Chain Attack
      Multiple WordPress plugins from ShapedPlugin were compromised in a supply chain attack after unknown threat actors managed to tamper with the official release channels and push backdoor code. "Attackers compromised the v…

### Paper Trading Scorecard — 46 new of 139 total
  - (2026-06-23) [Polymarket] Predict.fun FDV above $300M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Predict.fun's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-06-23) [Polymarket] Will Nikki Haley win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-06-23) [Polymarket] Will the Democratic Republic of Congo win Group K in the 2026 FIFA World Cup?
      This market will resolve according to the team that wins Group K in the 2026 FIFA World Cup group stage, scheduled for June 11-27, 2026. If multiple teams tie as group winners, this market will resolve according to the o…
  - (2026-06-23) [Polymarket] Will Alexandru Nazare be the next Prime Minister of Romania?
      This market will resolve to the next individual who officially assumes the office of Prime Minister of Romania by December 31, 2027, 11:59 PM ET. To count for resolution, the individual must be formally appointed by the…
  - (2026-06-23) [Polymarket] Will the Green Party (MP) win the most seats in the 2026 Swedish parliamentary election?
      Parliamentary elections are scheduled to be held in Sweden on September 13, 2026. This market will resolve according to the political party that wins the greatest number of seats in the Swedish Parliament (Riksdag) in th…
  - (2026-06-23) [Polymarket] Anysphere (Cursor) IPO before 2027?
      This market will resolve to "Yes" if the listed company completes an Initial Public Offering (IPO) by December 31, 2026, 11:59 PM ET, as confirmed by official company announcements or credible news sources. The IPO refer…

### Government Action: Sanctions + Procurement + Foreign Agents — 42 new of 102 total
  - (2026-06-22) [OFAC] Issuance of Iran-related General License - Office of Foreign Assets Control (.gov)
      Issuance of Iran-related General License Office of Foreign Assets Control (.gov)
  - (2026-06-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations, 31 CFR part 560 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations, 31 CFR part 560 Office of Foreign Assets Control (.gov)
  - (2026-06-22) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-06-18) [OFAC] Issuance of Venezuela-related General Licenses and Amended Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Issuance of Venezuela-related General Licenses and Amended Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-06-18) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 59 Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 59 Authorizing the Supply Office of Foreign Assets Control (.gov)
  - (2026-06-18) [OFAC] Lisa M. Palluconi - Office of Foreign Assets Control (.gov)
      Lisa M. Palluconi Office of Foreign Assets Control (.gov)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-23) [Welch Suzy] Form 4 (Reporting)
      filed 2026-06-23 00:01 UTC · role: Reporting — Filed: 2026-06-22 AccNo: 0001705110-26-000068 Size: 7 KB
  - (2026-06-23) [Angi Inc.] Form 4 (Issuer)
      filed 2026-06-23 00:01 UTC · role: Issuer — Filed: 2026-06-22 AccNo: 0001705110-26-000068 Size: 7 KB
  - (2026-06-23) [SenesTech, Inc.] Form 4 (Issuer)
      filed 2026-06-23 00:00 UTC · role: Issuer — Filed: 2026-06-22 AccNo: 0000902664-26-002860 Size: 7 KB
  - (2026-06-23) [GLENBROOK CAPITAL MANAGEMENT] Form 4 (Reporting)
      filed 2026-06-23 00:00 UTC · role: Reporting — Filed: 2026-06-22 AccNo: 0000902664-26-002860 Size: 7 KB
  - (2026-06-23) [Boelke Mark] Form 4 (Reporting)
      filed 2026-06-23 00:00 UTC · role: Reporting — Filed: 2026-06-22 AccNo: 0001193125-26-278012 Size: 13 KB
  - (2026-06-23) [RH] Form 4 (Issuer)
      filed 2026-06-23 00:00 UTC · role: Issuer — Filed: 2026-06-22 AccNo: 0001173871-26-000003 Size: 4 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### EPSS — highest exploit-probability CVEs — 30 new of 40 total
  - (2026-06-22) CVE-2024-3400: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-06-22) CVE-2024-21893: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-06-22) CVE-2024-21887: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-06-22) CVE-2023-4966: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-06-22) CVE-2023-44487: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-06-22) CVE-2023-35082: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-06-22) [Israel-Iran-Hezbollah axis · themes] Tucker Carlson says hell no longer support the Republican Party – Brandon Sun
      brandonsun.com · English · tone NA
  - (2026-06-22) [Israel-Iran-Hezbollah axis · themes] 許楠儁捲緋聞爆戀愛觀 ！ 公司狂虧 「 你成功了 」 揭真相
      ent.ltn.com.tw · Chinese · tone NA
  - (2026-06-22) [Israel-Iran-Hezbollah axis · themes] US and Iran Agree To Establish Deconfliction Cell for Lebanon
      news.antiwar.com · English · tone NA
  - (2026-06-22) [Israel-Iran-Hezbollah axis · themes] Tucker Carlson says hell no longer support the Republican Party
      yahoo.com · English · tone NA
  - (2026-06-22) [Israel-Iran-Hezbollah axis · themes] WA news LIVE : Perth cruise ship quarantiners finally on their way home
      theage.com.au · English · tone NA
  - (2026-06-22) [Israel-Iran-Hezbollah axis · themes] Young Wiky pianist making beautiful sounds | Elliot Lake Standard
      elliotlakestandard.ca · English · tone NA

### U.S. Federal Action — 24 new of 24 total
  - (2026-06-22) Establishment of Class E Airspace; Belmont, MS
      This action proposes to establish Class E airspace extending upward from 700 feet above the surface at Tishomingo Airport, Belmont, MS. Controlled airspace is necessary for the safety and management of instrument flight…
  - (2026-06-22) Deletion of Obsolete Regulations
      In this document, the Federal Communications Commission (Commission) acts to eliminate certain outdated, obsolete, and unnecessary rules to modernize its regulatory framework.
  - (2026-06-22) Establishment of Class E Airspace; Rosenberg, TX
      This action establishes Class E airspace at Lane Airpark, Rosenberg, TX. This action supports new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-06-22) Amendment of Domestic Very High Frequency Omnidirectional Range (VOR) Federal Airways V-16, V-94, V-159, and Revocation of V-535; Eastern United States
      This action proposes to amend domestic Very High Frequency Omnidirectional Range (VOR) Federal Airways V-16, V-94, and V-159, and revoke V-535 in the eastern United States. The FAA is proposing these actions due to the p…
  - (2026-06-22) Safety Zone; Delaware River, Philadelphia, PA
      The Coast Guard is establishing a temporary safety zone for navigable waters of the Delaware River, near Pleasant Hill Park, in Philadelphia, PA for a barge based fireworks display. The safety zone is needed to protect p…
  - (2026-06-22) Safety Zone; Toms River, Beachwood, NJ
      The Coast Guard is establishing a temporary safety zone for waters of the Toms River, near Mayo Park, in Beachwood, NJ, for a land- based fireworks display. The safety zone is needed to protect personnel, vessels, and th…

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-06-22) M 5.2 - 42 km SSW of Jurm, Afghanistan
      M5.2 · 42 km SSW of Jurm, Afghanistan · depth 207.008 km
  - (2026-06-22) M 5.1 - Kermadec Islands region
      M5.1 · Kermadec Islands region · depth 28.23 km
  - (2026-06-22) M 4.9 - Mid-Indian Ridge
      M4.9 · Mid-Indian Ridge · depth 10 km
  - (2026-06-22) M 4.9 - 260 km SSW of ‘Ohonua, Tonga
      M4.9 · 260 km SSW of ‘Ohonua, Tonga · depth 10 km
  - (2026-06-22) M 4.9 - 68 km WNW of Tobelo, Indonesia
      M4.9 · 68 km WNW of Tobelo, Indonesia · depth 124.932 km
  - (2026-06-22) M 4.8 - 276 km SSW of ‘Ohonua, Tonga
      M4.8 · 276 km SSW of ‘Ohonua, Tonga · depth 35 km

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-06-23) Will Cape Verde win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $17,712,771 · resolves 2026-07-20
  - (2026-06-23) Will Norway win on 2026-06-22?
      yes price: 40% · 24h volume: $10,793,800 · resolves 2026-06-23
  - (2026-06-23) Spread: France (-2.5)
      yes price: 42% · 24h volume: $10,357,416 · resolves 2026-06-22
  - (2026-06-23) Will France win on 2026-06-22?
      yes price: 94% · 24h volume: $7,663,113 · resolves 2026-06-22
  - (2026-06-23) Will Norway vs. Senegal end in a draw?
      yes price: 28% · 24h volume: $5,434,210 · resolves 2026-06-23
  - (2026-06-23) Will Ivory Coast win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $5,321,115 · resolves 2026-07-20

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-06-23) MOVER ▲ Elon Musk — $1086.91B (+$285.27B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-06-23) MOVER ▼ Larry Ellison — $221.29B ($-38.82B since yesterday)
      United States · Technology · source: Oracle
  - (2026-06-23) MOVER ▼ Steve Ballmer — $119.92B ($-11.23B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-06-23) MOVER ▼ Jeff Bezos — $243.85B ($-10.97B since yesterday)
      United States · Technology · source: Amazon
  - (2026-06-23) MOVER ▲ Thomas Peterffy — $110.80B (+$10.27B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-06-23) MOVER ▼ Larry Page — $286.51B ($-10.17B since yesterday)
      United States · Technology · source: Google

### CISA Known Exploited Vulnerabilities (last 14d) — 9 new of 9 total
  - (2026-06-18) CVE-2026-20253 · Splunk Enterprise: Splunk Enterprise Missing Authentication for Critical Function Vulnerability
      vendor: Splunk · product: Enterprise · CISA remediation by 2026-06-21
  - (2026-06-16) CVE-2026-48907 · Widget Factory Joomla Content Editor : Widget Factory Joomla Content Editor Improper Access Control Vulnerability
      vendor: Widget Factory · product: Joomla Content Editor · CISA remediation by 2026-06-19
  - (2026-06-15) CVE-2026-54420 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin UNIX Symbolic Link (Symlink) Following Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-06-18
  - (2026-06-15) CVE-2026-20262 · Cisco Catalyst SD-WAN Manager: Cisco Catalyst SD-WAN Manager Directory or Path Traversal Vulnerability
      vendor: Cisco · product: Catalyst SD-WAN Manager · CISA remediation by 2026-06-29
  - (2026-06-12) CVE-2026-35273 · Oracle PeopleSoft Enterprise PeopleTools: Oracle PeopleSoft Enterprise PeopleTools Missing Authentication for Critical Function Vulnerability [RANSOMWARE-LINKED]
      vendor: Oracle · product: PeopleSoft Enterprise PeopleTools · CISA remediation by 2026-06-15
  - (2026-06-11) CVE-2026-10520 · Ivanti Sentry: Ivanti Sentry OS Command Injection Vulnerability
      vendor: Ivanti · product: Sentry · CISA remediation by 2026-06-14

### World News (by country, top stories) — 6 new of 6 total
  - (2026-06-22) [Japan] John Cornyn claims Trump seems to revel in chaos , and he pointing at the recent moves regarding the DNI appointment
      attackofthefanboy.com · English
  - (2026-06-22) [Japan] 10 Best Metroidvanias of the 2020s ( So Far )
      dualshockers.com · English
  - (2026-06-22) [Japan] Daughter finally cut ties after her dad prioritized his stepkids over her , and his final request suggests why she walked away
      attackofthefanboy.com · English
  - (2026-06-22) [Japan] Shattered Memories and a Ghost from the Past : Re : Zero Season 4 Episode 77 Preview Teases Unforeseen Plot Twist !
      english.kyodonews.net · English
  - (2026-06-22) [Japan] A French TikToker says America is great for exactly two reasons , and he thinks the national anthem needs a verse dedicated to at least one of them
      attackofthefanboy.com · English
  - (2026-06-22) [Japan] Our films make more money than their film : Bonnie Arnold takes a jab at animation snobs , and she has her whole career to back up her point
      attackofthefanboy.com · English

### Commentary & analysis (last 7 days) — 5 new of 5 total
  - (2026-06-22) [Marginal Revolution] *The Migrants: A Memoir with Manuscripts*
      Christopher de Hamel’s Meetings with Remarkable Manuscripts is one of the very greatest books of the last twenty years. So I buy whatever else he puts out, and I did not regret my purchase of this one. Imagine an interse…
  - (2026-06-22) [Marginal Revolution] Monday assorted links
      1. John Horton: “The “literature” is going to become a collection of nodes/papers representing temporarily suspended computation with “citations” being contingent edges that describe how they sink uses the source; new da…
  - (2026-06-22) [Marginal Revolution] Alan Greenspan, RIP at 100
      Here is a NYT obituary. Here is a WSJ obituary. The post Alan Greenspan, RIP at 100 appeared first on Marginal REVOLUTION.
  - (2026-06-19) [Conversable Economist] Slow Growth: Mexico Edition
      For the last eight years or so, going back before the pandemic, Mexico’s economy has been growing at 1% per year or less, which is barely faster than the population of Mexico has been growing. It is a fact of arithmetic…
  - (2026-06-17) [Conversable Economist] Dairy: Supply and Demand Stories
      Here’s a modest puzzle: The quantity supplied of milk is way up, but the price is also way up. One usually expects higher supply to drive down the price. What’s happening? Here’s a meandering commentary on supply and dem…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - (2026-06-23) [Top] TRONE, DAVID (DEM, House MD): $26.20M raised
      cycle 2026 receipts $26.20M · disbursements $18.97M · net $+7.23M
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### WHO Disease Outbreak News — 2 new of 40 total
  - (2026-06-19) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with sustained transmission and increasing numbers of reported cases. As of 17 June, a cumulative of 896 co…
  - (2026-06-13) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with increasing case numbers and geographic spread. As of 10 June, a cumulative of 676 confirmed cases, inc…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=0, 7d-median=22, 14d-median=22
- state_bills: today=0, 7d-median=140, 14d-median=140
- state_news: today=0, 7d-median=430, 14d-median=430
- local_news: today=0, 7d-median=216, 14d-median=216
- foreign_news: today=0, 7d-median=923, 14d-median=923
- chinese_internal: today=0, 7d-median=250, 14d-median=250
- russian_internal: today=0, 7d-median=902, 14d-median=902
- ukrainian_internal: today=0, 7d-median=104, 14d-median=104
- ukraine_theater: today=0, 7d-median=508, 14d-median=508
- paper_bets: today=0, 7d-median=136, 14d-median=136
- weather: today=0, 7d-median=182, 14d-median=182
- macro: today=0, 7d-median=21, 14d-median=21
- markets: today=0, 7d-median=21, 14d-median=21
- markets_global: today=0, 7d-median=47, 14d-median=47
- sanctions_procurement: today=0, 7d-median=103, 14d-median=103
- congressional_trades: today=0, 7d-median=34, 14d-median=34
- billionaires: today=0, 7d-median=38, 14d-median=38
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60
- form4: today=0, 7d-median=40, 14d-median=40
- fec: today=0, 7d-median=27, 14d-median=27
- gdelt_regions: today=0, 7d-median=9, 14d-median=9
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=0, 14d-median=0
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=0, 7d-median=40, 14d-median=40
- cisa_kev: today=0, 7d-median=10, 14d-median=10
- epss: today=0, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=140, 14d-median=140
- usgs_quakes: today=0, 7d-median=19, 14d-median=19
- forecasts: today=0, 7d-median=20, 14d-median=20
- commentary: today=0, 7d-median=6, 14d-median=6
- tech_news: today=0, 7d-median=51, 14d-median=51
- political_figures: today=0, 7d-median=613, 14d-median=613
- paper_bet_placement: today=0, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-09] Fed press (events + announcements): Federal Reserve Board announces that results from its annual bank stress test will be released on Wednesday, June 24, at 4 p.m. EDT.
- [2026-06-11] Fed press (events + announcements): Federal Reserve Board announces final rule that establishes data standards for certain information collections
- [2026-06-15] ECB press: Carbon emissions of ECB and Eurosystem portfolios continue to decline
- [2026-06-16] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-06-17] ECB press: New data release: ECB wage tracker points to stable negotiated wage pressures in 2026
- [2026-06-17] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-06-17] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the June 16-17 FOMC meeting
- [2026-06-18] ECB press: Piero Cipollone: Digital euro: the future of money
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board requests comment on proposal to require certain payment stablecoin issuers to maintain an effective customer identification program
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Manufacturers and Traders Trust Company
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-19] ECB press: ECB publishes consolidated banking data for end-December 2025
- [2026-06-19] ECB press: Piero Cipollone: The foundations of national sovereignty: the role of central bank money
- [2026-06-19] ECB press: Frank Elderson: Fireside chat
- [2026-06-22] Fed press (events + announcements): Federal Reserve notes with deep sadness the passing of Alan Greenspan
- [2026-06-22] Fed speeches: Waller, Welcoming Remarks on the International Role of the U.S. Dollar
- [2026-06-22] ECB press: Christine Lagarde: Hearing of the Committee on Economic and Monetary Affairs of the European Parliament

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*