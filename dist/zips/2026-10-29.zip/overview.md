# WORLDSCOPE morning brief — 2026-10-29

## Headline
3572 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (868) · Russian Internal News (state + in-exile) (734) · State-Level News (358) · World leaders & government officials (324) · Chinese Internal News (232) · Ukraine Theater (total-war monitoring) (214) · Local News: St. Louis + Atlanta (209) · U.S. Weather + Severe / Climate Outlooks (132) · State Legislative Action (99) · GDACS — global disaster alerts (78) · Ukrainian Internal News (national + local Kyiv) (70) · IT, InfoSys & cybersecurity news (last 7 days) (42)

## What changed today
### International News + Multilateral Institutions — 868 new of 1037 total
  - (2026-10-29) [India] UP tightens government job verification rules, says political ideology alone cannot disqualify candidates
  - (2026-10-29) [India] HT Evening News Brief October 29: Israel ‘vote theft’ row, SC on digital fraud, Imran Khan’s OCI case, India hockey in action
  - (2026-10-29) [India] 'No choice left but to look to increase fares': IndiGo CEO on 'very significant' rise in fuel bill
  - (2026-10-29) [India] ‘Silence is not an option’: Mamata extends support to INDIA bloc's Nov-1 ‘Chalo Dilli Ramlila March’
  - (2026-10-29) [India] Kerala teacher arrested over alleged false claim of worms in food at state sports meet
  - (2026-10-29) [India] Madhya Pradesh man kills wife in Gwalior on Karwa Chauth

### Russian Internal News (state + in-exile) — 734 new of 1142 total
  - (2026-10-29) Саша Барон Коэн публично извинился перед Казахстаном за фильм «Борат» (в стране считают его оскорбительным). Спустя 20 лет после выхода картины | LEDE: Британский актер Саша Барон Коэн публи] (ru: Саш…
      Британский актер Саша Барон Коэн публично извинился перед жителями Казахстана за образ «Бората» из одноименного фильма 2006 года. По сюжету вымышленный журналист из Казахстана Борат Сагдиев отправляется в США для съемок…
  - (2026-10-29) Война. 1709-й день. «Если все удастся, то это будет первый пример реального перемирия». Режим прекращения огня в Алешках действует уже более двух суток | LEDE: «Медуза» с 24 февраля 2022 год] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-29) Минцифры предложило отключать от связи смартфоны, которые ввезли в Россию и не зарегистрировали на «Госуслугах» | LEDE: Министерство цифрового развития РФ предлагает с апреля 2027 года отклю] (ru: Мин…
      Министерство цифрового развития РФ предлагает с апреля 2027 года отключать от связи привезенный из-за границы смартфон, если в течение двух недель владелец не зарегистрирует его по идентификатору IMEI, сообщает РБК.
  - (2026-10-29) «Все произошло за долю секунды. Стол, за которым мы сидели, просто уничтожило». В Испании — крупнейшая железнодорожная катастрофа. Вот что рассказывают пассажиры столкнувшихся поездов | LEDE: <] (ru:…
      Утром 28 октября в Испании произошла одна из крупнейших по количеству жертв железнодорожная катастрофа. На участке пути между Мадридом и Севильей, в провинции Толедо, пассажирский поезд государственной компании Renfe вре…
  - (2026-10-29) «Возвращение имен» — 2026. Онлайн-трансляция. Присоединяйтесь к ежегодной акции памяти жертв политических репрессий | LEDE: 29 октября, накануне Дня памяти жертв политических репрессий, в Ро] (ru: «Во…
      29 октября, накануне Дня памяти жертв политических репрессий, в России и других странах пройдет акция «Возвращение имен», впервые организованная «Мемориалом» в Москве в 2007 году. Участники акции более чем в 100 городах…
  - (2026-10-29) Выборы в Израиле прошли два дня назад — но победителя пока нет (хотя блок Нетаниягу лидирует). Так кто будет править страной? Отвечаем максимально коротко, что известно после подсчета более 90%] (ru:…
      По состоянию на утро 29 октября в Израиле подсчитано более 91% голосов. Распределение 120 мандатов в кнессете пока выглядит следующим образом: блок Биньямина Нетаниягу получает 53 места, оппозиционный блок — 48, арабские…

### State-Level News — 358 new of 752 total
  - (2026-10-28) [Alabama] Governor Ivey Joins Hyundai to Celebrate Major Investment in Alabama Manufacturing
      MONTGOMERY – Governor Kay Ivey on Wednesday joined company officials and state and local leaders to celebrate Hyundai Motor Manufacturing Alabama’s (HMMA)announcement that it will invest nearly $450 million to expand pro…
  - (2026-10-28) [Alabama] Governor Ivey Proclaims First Responders Day, Honors Alabamians Who Answer the Call
      MONTGOMERY – Governor Kay Ivey on Wednesday proclaimed October 28, 2026, as First Responders Day in Alabama, honoring the men and women who protect lives and property and serve their fellow Alabamians in times of need. T…
  - (2026-10-29) [California] Governor Newsom on a federal judge handing the Trump DOJ another “L” in their quest to subvert democracy and the rule of law in California
      Source
  - (2026-10-29) [California] Governor Newsom announces appointments 10.28.26
      Source
  - (2026-10-28) [California] Governor Newsom highlights California’s out-of-this-world economy at the new Space Shuttle Endeavour installation
      Source
  - (2026-10-28) [California] Governor, First Partner issue statement on the passing of Dolores Huerta; state to lower flags in her honor
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 232 new of 308 total
  - (2026-10-29) 港股IPO市场反转 新股破发不断、多家延期取消 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9WbGdFYW94djJfbjl1SGFwQnBwb1d5V3VxV3lPa2d4NEdvLUhBdGVMVHlSanhBQXlJa01nUUZ3aGFFNTBSOHlJOEMwc2VLVU] (zh:…
      港股IPO市场反转 新股破发不断、多家延期取消 财新
  - (2026-10-28) 引入气候暂停条款，打破极端气候与债务悬置恶性循环 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBjM2piOG90Y0ZKcUh0dllFM2c3bE05MVJOdFU3R2dwb2Itb1JLcTVLZ1h6V0wzS3cyUXlTQWRqbXhiTHZPa1dGWHYxTEk2R] (zh:…
      引入气候暂停条款，打破极端气候与债务悬置恶性循环 财新
  - (2026-10-28) 我们的教育，缺一门态度课：一项追踪18年的研究带来的启示｜热点 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1HX09IclhvcVcwN1pmclI5UGRxUllKRi05am41MTB4YV80V09lNlp4YmtTZ3AtcWlUaUZtWnBGbTQzSEE1TXA1LU] (zh:…
      我们的教育，缺一门态度课：一项追踪18年的研究带来的启示｜热点 财新
  - (2026-10-28) 西甲主席特瓦斯：已会晤中国大使，望与中国继续合作 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5iVkdyMXlTU1BDQmMyNURueWpCRk9Za3NZRW96NHU1cjhhaUNGckZlQXBqWHp2a1V1c3RJMjJJbGlJaFlvdVViejZaV2c2N] (zh:…
      西甲主席特瓦斯：已会晤中国大使，望与中国继续合作 财新
  - (2026-10-27) 证监会“最贪”高官王会民被判死缓 27年受贿4.36亿元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1yRF91a2poYlFja1pRazVGMVYtaHRJckdnV1ZpdGZhdGFycVhSS1F0T2JtMTBuSzg3THd3NWllVENMUmVXaHAwbHQyV] (zh:…
      证监会“最贪”高官王会民被判死缓 27年受贿4.36亿元 财新
  - (2026-10-28) 对话龚克：AI发展必须与安全统一，不发展才是最大的不安全 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9HVnBmMXJfSVVaRmx5NldRUDNyWFpYQmo3c2tyVHNSMjN3Z1BkNmprRm5LTWZKVnVGaGZvNlBCQ2hWY1RkanNfZ1ZLU] (zh:…
      对话龚克：AI发展必须与安全统一，不发展才是最大的不安全 财新

### Ukraine Theater (total-war monitoring) — 214 new of 377 total
  - (2026-10-29) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-28) [FIRMS] thermal anomaly 52.846, 29.989 (FRP 1.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-28 0206Z, FRP 1.01 MW
  - (2026-10-28) [FIRMS] thermal anomaly 52.375, 33.408 (FRP 1.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-28 0028Z, FRP 1.01 MW
  - (2026-10-28) [FIRMS] thermal anomaly 52.847, 29.991 (FRP 3.12 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-28 0028Z, FRP 3.12 MW
  - (2026-10-28) [FIRMS] thermal anomaly 52.236, 32.506 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-28 0028Z, FRP 1.02 MW
  - (2026-10-28) [FIRMS] thermal anomaly 52.196, 32.185 (FRP 0.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-28 0028Z, FRP 0.92 MW

### Local News: St. Louis + Atlanta — 209 new of 253 total
  - (2026-10-29) [St. Louis] St. Louis helped create public bathrooms. There's still room for improvement
  - (2026-10-29) [St. Louis] An Illinois disability nonprofit uses hydroponic farming to teach workforce skills
  - (2026-10-29) [St. Louis] Here’s what you need to know about those St. Louis-area school propositions before election day
  - (2026-10-29) [St. Louis] Zimmerman calls executive run a ‘cleanup mission’ for St. Louis County government
  - (2026-10-29) [St. Louis] St. Louis County Council aims to hold Northern Village to eviction moratorium and improvements
  - (2026-10-29) [St. Louis] Photos: St. Louis City SC raises historic U.S. Open Cup champion banner

### U.S. Weather + Severe / Climate Outlooks — 132 new of 134 total
  - (2026-10-29) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 29 at 7:58AM CDT until October 29 at 12:00PM CDT by NWS Dodge City KS
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Portions of south central, southwest, and west central Kansas. * WHEN...Until noon CDT /11 AM MDT/ today. * IMPACTS...Low visibility could make driving…
  - (2026-10-29) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 29 at 7:58AM CDT until October 29 at 12:00PM CDT by NWS Dodge City KS
      * WHAT...Visibility one quarter to one half mile in dense fog. * WHERE...Barber and Pratt Counties. * WHEN...Until noon CDT today. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-10-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-29) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 29 at 8:54AM EDT until October 29 at 11:00AM EDT by NWS Blacksburg VA
      * WHAT...Visibility down to one quarter of a mile or less due to dense fog. * WHERE...Portions of southwest and west central Virginia and southeast West Virginia. * WHEN...Until 11 AM EDT this morning. * IMPACTS...Low vi…
  - (2026-10-29) [Moderate] Special Weather Statement: Special Weather Statement issued October 29 at 5:46AM PDT by NWS Pendleton OR
      Patchy dense fog has been observed in the Kittitas Valley early this morning. Within fog, visibilities as low as one-quarter mile are expected to persist into morning. Use extra caution while traveling as visibilities ca…
  - (2026-10-29) [Moderate] Special Weather Statement: Special Weather Statement issued October 29 at 5:42AM PDT by NWS Spokane WA
      Patchy dense fog has been observed across the Upper Columbia Basin early this morning, especially near Coulee City and Ritzville. Highways that could be impacted are I-90 and US-2. Within fog, expect visibilities as low…

### State Legislative Action — 99 new of 158 total
  - (2026-10-29) [California SB 331] Health care coverage: hearing aids.
      Existing law, the Knox-Keene Health Care Service Plan Act of 1975, provides for the licensure and regulation of health care service plans by the Department of Managed Health Care and makes a willful violation of the act…
  - (2026-10-29) [California SB 700] Capital Programs and Climate Financing Authority Act: California Investment and Innovation Program.
      The Capital Programs and Climate Financing Authority Act establishes the Capital Programs and Climate Financing Authority, consisting of the Director of Finance, the Treasurer, and the Controller. Among other things, the…
  - (2026-10-29) [California SB 1047] Neurodegenerative disease registry program.
      Existing law, until January 1, 2028, and to the extent funds are made available for these purposes, requires the State Department of Public Health to establish a system for the collection of information determining the i…
  - (2026-10-29) [California SB 758] Public health: nitrous oxide.
      (1) Existing law, the Cigarette and Tobacco Products Licensing Act of 2003, requires a retailer, as defined, to hold a license from the California Department of Tax and Fee Administration to engage in the sale of cigaret…
  - (2026-10-29) [California SB 1273] Alcoholic beverages: tied-house restrictions: instructional events and promotional lectures: advertisements.
      Existing law, the Alcoholic Beverage Control Act, which is administered by the Department of Alcoholic Beverage Control, regulates the application, issuance, and suspension of alcoholic beverage licenses. Existing law, k…
  - (2026-10-29) [California SB 741] Low Carbon Transit Operations Program.
      Existing law creates the Low Carbon Transit Operations Program to provide operating and capital assistance for transit agencies to reduce the emissions of greenhouse gases and improve mobility. Existing law requires the…

### GDACS — global disaster alerts — 78 new of 100 total
  - (2026-10-29) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.6M, Depth:10km
  - (2026-10-29) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.9M, Depth:10km
  - (2026-10-29) [Green] Earthquake in Andaman Islands, India Region
      Earthquake · Green alert · Andaman Islands, India Region · Magnitude 5.1M, Depth:10km
  - (2026-10-29) [Green] Earthquake in Portugal
      Earthquake · Green alert · Portugal · Magnitude 4.6M, Depth:10km
  - (2026-10-29) [Green] Earthquake in Southeast Of Easter Island
      Earthquake · Green alert · Southeast Of Easter Island · Magnitude 6.4M, Depth:10km
  - (2026-10-29) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 5.4M, Depth:10km

### Ukrainian Internal News (national + local Kyiv) — 70 new of 131 total
  - (2026-10-29) РФ завдала ракетного удару по Лозовій, поранено шістьох людей – ОВА | LEDE: Російські окупаційні війська 29 жовтня завдали ракетного удару по місту Лозова на Харківщині, постраждали шестеро чол] (uk:…
      Російські окупаційні війська 29 жовтня завдали ракетного удару по місту Лозова на Харківщині, постраждали шестеро чоловіків.
  - (2026-10-29) Голова Dignitas Fund: Що більше роботів на фронті, то більше людей нам потрібно у війську | LEDE: ] (uk: Голова Dignitas Fund: Що більше роботів на фронті, то більше людей нам потрібно )
  - (2026-10-29) "Москва замінувала ООН": МЗС відреагувало на призначення росіянина заступником генсека | LEDE: Міністерство закордонних справ звертає увагу, що призначення предмтавника держави-агресора РФ на п] (uk:…
      Міністерство закордонних справ звертає увагу, що призначення предмтавника держави-агресора РФ на посаду керівника мінної діяльності ООН підриває довіру до цієї організації.
  - (2026-10-29) Кількість загиблих у залізничній катастрофі в Іспанії зросла до 69 осіб | LEDE: В Іспанії зросла кількість загиблих у катастрофі двох поїздів в іспанській провінції Толедо, яка сталася вранці 2] (uk:…
      В Іспанії зросла кількість загиблих у катастрофі двох поїздів в іспанській провінції Толедо, яка сталася вранці 28 жовтня.
  - (2026-10-29) Спікер сейму Польщі просить Навроцького не запрошувати антиукраїнську партію на засідання Ради нацбезпеки | LEDE: Спікер Сейму Польщі Влодзімеж Чажастий попросив президента Кароля Навроцького н] (uk:…
      Спікер Сейму Польщі Влодзімеж Чажастий попросив президента Кароля Навроцького не запрошувати на засідання Ради національної безпеки ультраправу партію "Конфедерація Польської корони", відому антиукраїнськими і проросійсь…
  - (2026-10-29) У Франція проти висунення Орбана на посаду генсека ООН | LEDE: Міністр закордонних справ Франції Жан-Ноель Барро відкинув можливість висунення кандидатури експрем'єра Угорщини Віктора Орбана на] (uk:…
      Міністр закордонних справ Франції Жан-Ноель Барро відкинув можливість висунення кандидатури експрем'єра Угорщини Віктора Орбана на посаду генерального секретаря ООН.

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 56 total
  - (2026-10-29) [BleepingComputer] Windows 11 KB5127936 update released with 41 changes and fixes
      Microsoft released the KB5127936 preview cumulative update for Windows 11 versions 25H2 and 26H2, with 41 changes, including File Explorer and Cloud rebuild improvements. [...]
  - (2026-10-29) [BleepingComputer] New Cisco firewall zero-day exploited to crash SSL VPN devices
      Cisco released security updates to patch a denial-of-service zero-day in Adaptive Security Appliance (ASA) and Threat Defense (FTD) software that attackers are exploiting to remotely crash vulnerable firewall devices. [.…
  - (2026-10-29) [The Hacker News] Webinar: How to Build AI Threat Readiness Into Your Security Operations
      Security teams have spent years trying to detect threats faster. AI is changing the harder part: how much time defenders have left to act. Advanced AI models can now help attackers discover vulnerabilities, generate expl…
  - (2026-10-29) [The Hacker News] Telegram Android Flaw Lets Attackers Run Code When Users Answer Voice Calls
      A flaw in Telegram for Android allowed an attacker to run code on a victim's phone via a voice call once the victim answered, according to security startup NebuSec. The attacker needed only an ordinary Telegram account.…
  - (2026-10-29) [The Hacker News] The Rise of the Threat Operator: How AI Will Redefine Security Operations and Careers
      AI is beginning to take over much of the work that has traditionally defined the security analyst's job. Investigating alerts, collecting evidence, correlating activity across tools, and executing response actions are be…
  - (2026-10-29) [The Hacker News] 26,400 Valid Cloud and AI Credentials Found Exposed in Public Gitee Repositories
      26,400 credentials that developers left in public code on Gitee, a Chinese code-hosting service, still worked when a researcher tested them. Anyone who copied one from that code could have used it. Independent researcher…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-29) 485BPOS - INVESCO ACTIVELY MANAGED EXCHANGE-TRADED FUND TRUST (0001418144) (Filer)
      filed 2026-10-29 13:03 UTC — Filed: 2026-10-29 AccNo: 0001104659-26-119957 Size: 6 MB
  - (2026-10-29) 485BPOS - INVESCO ACTIVELY MANAGED EXCHANGE-TRADED FUND TRUST (0001418144) (Filer)
      filed 2026-10-29 13:03 UTC — Filed: 2026-10-29 AccNo: 0001104659-26-119957 Size: 6 MB
  - (2026-10-29) 485BXT - J.P. Morgan Exchange-Traded Fund Trust (0001485894) (Filer)
      filed 2026-10-29 13:01 UTC — Filed: 2026-10-29 AccNo: 0001193125-26-437098 Size: 54 KB
  - (2026-10-29) 485BXT - J.P. Morgan Exchange-Traded Fund Trust (0001485894) (Filer)
      filed 2026-10-29 13:01 UTC — Filed: 2026-10-29 AccNo: 0001193125-26-437098 Size: 54 KB
  - (2026-10-29) 424B5 - CMS ENERGY CORP (0000811156) (Filer)
      filed 2026-10-29 13:00 UTC — Filed: 2026-10-29 AccNo: 0001104659-26-119952 Size: 545 KB
  - (2026-10-29) 424B2 - Morgan Stanley Finance LLC (0001666268) (Filer)
      filed 2026-10-29 12:59 UTC — Filed: 2026-10-29 AccNo: 0001839882-26-053047 Size: 1 MB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-29) CFC3018 (Canada)
      icao24: c2b373 · position: (47.0764, -1.1457) · alt: 11887m · 914km/h
  - (2026-10-29) CFC3466 (Canada)
      icao24: c2c36d · position: (53.7707, -0.5289) · alt: 12192m · 776km/h
  - (2026-10-29) CFC01 (Canada)
      icao24: c2c1f1 · position: (45.3039, -75.6912) · alt: 662m · 312km/h
  - (2026-10-29) JEDI29 (United States)
      icao24: ae1eab · position: (30.3004, -87.9061) · alt: 2377m · 400km/h
  - (2026-10-29) JEDI18 (United States)
      icao24: ae1eac · position: (30.5763, -88.1499) · alt: 533m · 376km/h
  - (2026-10-29) SAMU44 (France)
      icao24: 39ca84 · position: (47.2093, -1.5547) · on ground · 0km/h

### USGS earthquakes (M4.5+, past day) — 25 new of 25 total
  - (2026-10-29) M 6.4 - southeast of Easter Island
      M6.4 · southeast of Easter Island · depth 10 km
  - (2026-10-29) M 5.8 - 110 km ENE of Barcelona, Philippines
      M5.8 · 110 km ENE of Barcelona, Philippines · depth 10 km
  - (2026-10-29) M 5.7 - 82 km NE of Kiunga, Papua New Guinea
      M5.7 · 82 km NE of Kiunga, Papua New Guinea · depth 10 km
  - (2026-10-28) M 5.7 - 271 km WSW of Tual, Indonesia
      M5.7 · 271 km WSW of Tual, Indonesia · depth 142 km
  - (2026-10-28) M 5.5 - 5 km ESE of Asahi, Japan
      M5.5 · 5 km ESE of Asahi, Japan · depth 41.356 km
  - (2026-10-29) M 5.4 - 114 km ENE of Barcelona, Philippines
      M5.4 · 114 km ENE of Barcelona, Philippines · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 22 new of 103 total
  - (2026-10-27) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-10-28) [OFAC] North Korea Designations; Democratic Republic of the Congo-related Designations - Office of Foreign Assets Control (.gov)
      North Korea Designations; Democratic Republic of the Congo-related Designations Office of Foreign Assets Control (.gov)
  - (2026-10-22) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-10-29) [USASpending] $22,657,326,734 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-10-29) [USASpending] $17,732,163,524 → HONEYWELL FEDERAL MANUFACTURING & TECHNOLOGIES, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SEC
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SECURITY CAMPUS -- CONTRACT NO. DE-NA0002839
  - (2026-10-29) [USASpending] $17,730,321,031 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy. Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-10-29) Counter-Strike: Vitality vs Natus Vincere (BO3) - PGL Masters Bucharest Playoffs
      yes price: 100% · 24h volume: $2,093,067 · resolves 2026-10-29
  - (2026-10-29) Will the Democratic Party control the House after the 2026 Midterm elections?
      yes price: 92% · 24h volume: $1,447,439 · resolves 2026-11-04
  - (2026-10-29) Will the Republican Party control the House after the 2026 Midterm elections?
      yes price: 6% · 24h volume: $1,210,654 · resolves 2026-11-04
  - (2026-10-29) Will there be no change in Fed interest rates after the December 2026 meeting?
      yes price: 20% · 24h volume: $747,093 · resolves 2026-12-09
  - (2026-10-29) Swiss Indoors Basel: Valentin Vacherot vs Rafael Jodar
      yes price: 34% · 24h volume: $671,159 · resolves 2026-11-05
  - (2026-10-29) 2026 Balance of Power: D Senate, D House
      yes price: 66% · 24h volume: $611,342 · resolves 2026-11-04

### U.S. Federal Action — 15 new of 15 total
  - (2026-10-29) Reducing Bureaucracy and Burden for Block Grants
      ACF proposes to amend its block grant regulations to modernize requirements, reduce administrative burden on States and Tribal grantees, and improve the clarity and efficiency of program administration. The current regul…
  - (2026-10-29) Mandatory Guidelines for Federal Workplace Drug Testing Programs Using Urine (UrMG)
      The Department of Health and Human Services ("HHS" or "Department") is proposing to revise the Mandatory Guidelines for Federal Workplace Drug Testing Programs using Urine (UrMG), published in the Federal Register on Oct…
  - (2026-10-29) Mandatory Guidelines for Federal Workplace Drug Testing Programs Using Oral Fluid (OFMG)
      The Department of Health and Human Services ("HHS" or "Department") is proposing to revise the Mandatory Guidelines for Federal Workplace Drug Testing Programs using Oral Fluid (OFMG) published on October 12, 2023.
  - (2026-10-29) Reducing Bureaucracy and Burden for Child Support Enforcement Programs
      This final rule amends the Child Support regulations that were unnecessary or obsolete in the following sections: State Plan Approval and Grant Procedures, State Plan Requirements, Standards for Program Operations, Feder…
  - (2026-10-29) Personnel Management in Agencies: Strategic Human Capital Management
      The Office of Personnel Management (OPM) is issuing a final rule to modernize the framework governing personnel management and strategic human capital management in Federal agencies. This rule amends the regulatory frame…
  - (2026-10-29) Pleasure Vessels of Malta Entitled To Cruising Licenses
      This document amends U.S. Customs and Border Protection (CBP) regulations by adding the Republic of Malta (Malta) to the list of countries whose pleasure vessels may be issued U.S. cruising licenses. The U.S. Department…

### Court opinions of consequence (federal & state) — 15 new of 60 total
  - (2026-10-28) U.S. Court of Appeals, 8th Cir.: Hall Trucking Inc. v. Secretary of Labor
  - (2026-10-28) U.S. Court of Appeals, 9th Cir.: Center for Biological Diversity v. United States Bureau of Reclamation
  - (2026-10-28) U.S. Court of Appeals, 1st Cir.: Wright v. United Services Automobile Association
  - (2026-10-28) U.S. Court of Appeals, D.C. Cir.: Katie Phang v. Todd Blanche
  - (2026-10-28) Hawaii Supreme Court: Kawatachi v. The Parrish Collection, LLC
  - (2026-10-28) U.S. Court of Appeals, 5th Cir.: Students Engaged in Advancing Texas v. Ken Paxton

### Paper Trading Scorecard — 10 new of 60 total
  - (2026-10-29) [Manifold] Will Mary Peltola withdraw from the Alaska senate race?
  - (2026-10-29) [Manifold] Will Alibaba release any Qwen 4 model on October 29, 2026?
  - (2026-10-29) [Manifold] Will Anthropic release a new Claude Fable model before November 5, 2026?
  - (2026-10-29) [Manifold] Will Rob Sand win 2026 Iowa governor election?
  - (2026-10-29) [Manifold] Will gold (XAU/USD) close higher on Thursday, October 29, 2026 than on Wednesday, October 28, 2026?
  - (2026-10-29) [Manifold] Will the Nasdaq Composite close higher on Thursday, October 29, 2026 than on Wednesday, October 28, 2026?

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-29) [Marginal Revolution] How Tyler Cowen and Alex Tabarrok Have Changed Their Views on AI and Where They Disagree
      From the Archives-written by ChatGPT. Both became dramatically more confident in AI’s capabilities while remaining optimistic about its economic potential. Their differences concern how benefits arrive, how seriously to…
  - (2026-10-29) [Marginal Revolution] AI dominates human peer reviews
      We show that AI-generated article reviews are now better, by every measure we could construct, than reviews written by well-compensated human experts and judged to be of unusually high quality by journal editors and auth…
  - (2026-10-29) [Marginal Revolution] My design Conversation with Roman Mars
      Here is the audio, video, and transcript. Here is part of the episode summary: Roman Mars has built one of podcasting’s great empires out of noticing things everyone else walks past. His show, 99% Invisible, has racked u…
  - (2026-10-28) [Conversable Economist] All About Tariffs
      I have made no secret of me deep skepticism about President Trump’s tariff policies since he announced his “Liberation Day” tariffs in April 2025. My first-blink “Thoughts on the Trump Tariffs” from a few days after the…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 17 total
  - (2026-10-28) CVE-2026-41709 · Broadcom VMware ESX: Broadcom VMWare ESX Insufficient Logging Vulnerability
      vendor: Broadcom · product: VMware ESX · CISA remediation by 2026-11-11
  - (2026-10-28) CVE-2026-46300 · Linux Kernel: Linux Kernel Missing Initialization of a Variable Vulnerability
      vendor: Linux · product: Kernel · CISA remediation by 2026-10-31

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=15, 14d-median=16; carrying terms: action, published, regulatory, final, protection, proposing, procedures, certain, vessels, proposed, public, enforcement
- state_bills: today=158, 7d-median=70, 14d-median=113; carrying terms: school, establishes, including, election, persons, insurance, taxes, legislative, state, emergency, property, relating
- state_news: today=752, 7d-median=678, 14d-median=688; carrying terms: decades, field, attention, begin, published, projects, competitive, electric, conservation, tribune, million, nebraska
- local_news: today=253, 7d-median=248, 14d-median=239; carrying terms: million, stlmag, house, nearly, dispatch, missing, woman, illinois, republican, state, health, college
- foreign_news: today=1037, 7d-median=999, 14d-median=1006; carrying terms: football, field, begin, criticism, foreign, sipri, paris, polish, stories, night, house, development
- chinese_internal: today=308, 7d-median=270, 14d-median=278; carrying terms: cbmidefvx, cbmizkfvx, cbmibefvx, cbmibkfvx, cbmickfvx, china, cbmix, title, cbmizefvx, cbmiy, cbmia, cbmiw
- russian_internal: today=1142, 7d-median=1010, 14d-median=1019; carrying terms: politico, novaya, forbidden, europe, media, error, gazeta, russian, httperror, istories, found, street
- ukrainian_internal: today=131, 7d-median=130, 14d-median=130; carrying terms: operations, confirmed, ukrainian, drone, foreign, agreement, civilians, against, drones, interceptors, power, volodymyr
- ukraine_theater: today=377, 7d-median=390, 14d-median=397; carrying terms: evboq, ngogjnay, foreign, syntlyuevzueu, repair, cbmiv, development, pvtlzlnhfn, weapons, drones, interceptors, bridge
- paper_bets: today=60, 7d-median=63, 14d-median=65; carrying terms: prize, season, office, israel, russell, minister, evans, degrees, president, nominal, decrease, rushing
- weather: today=134, 7d-median=134, 14d-median=136; carrying terms: central, continues, baltimore, winds, afdilx, louis, worth, flood, memphis, lincoln, warning, until
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, spread, effective, inflation, nonfarm, money, rates, indicator, unemployment, consumption, dexjpus, dexuseu
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, nasdaq, russell, agriculture, yield, close, rates, natural, crypto, corporate, equities, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=103, 7d-median=102, 14d-median=104; carrying terms: central, operations, program, detect, labor, issuance, management, research, bombing, foreign, threatening, tunisia
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quiver, httperror, congresstrading, unauthorized, client, quantitative, quiverquant, https
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: delaware, supreme, international, court, blanche, trade, state, appeals, board, alaska, alabama, services
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, reporting, accno, holdings, filer, financial, subject, trust, chase, jpmorgan, finance
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, pinkston, david, krishnamoorthi, warner, shawn, senate, committee, disbursements, ossoff, james, cortez
- gdelt_regions: today=0, 7d-median=12, 14d-median=12
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, israel, sanctions, keywords, themes, spanish, russia, russian, chinese, perimeter, elections, ukrainian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=28; carrying terms: position, ground, belgium, france, germany, kingdom, canada, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: regio, rwampara, public, increased, declared, welfare, driving, undetermined, health, continues, previous, formula
- cisa_kev: today=17, 7d-median=17, 14d-median=17; carrying terms: injection, spoofing, secure, server, product, vendor, vulnerability, control, command, remediation, improper, bypass
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: forest, hurricane, typhoon, earthquake, forestfire, wildfire, speed, guinea, islands, fires, cyclone, mozambique
- usgs_quakes: today=25, 7d-median=23, 14d-median=21; carrying terms: depth, vanuatu, indonesia, philippines, islands, china, guinea, papua, japan, south, region, village
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: october, resolves, rates, increase, interest, price, election, meeting, volume, change, league, champions
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, revolution, https, marginal, class, conversable, world, marginalrevolution, economic, example, money, capital
- tech_news: today=56, 7d-median=57, 14d-median=57; carrying terms: computer, research, schneier, group, against, attacker, researchers, systems, updates, technica, weekly, security
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: welch, treasury, samuel, ayanna, russell, foster, auchincloss, cantwell, hoeven, sykes, moolenaar, kaine
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, market, sufficient, consensus, placement, unavailable, either, evidence, converges, today, claude, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-21] ECB press: Philip R. Lane: Euro liquidity lines and the international monetary system
- [2026-10-21] ECB press: Piero Cipollone: Pontes and Appia: unlocking opportunities for banks
- [2026-10-23] ECB press: ECB Consumer Expectations Survey results – September 2026
- [2026-10-24] ECB press: Piero Cipollone: Interview with Milano Finanza
- [2026-10-26] ECB press: Frank Elderson: Taking action for nature – investing in economic resilience and prosperity
- [2026-10-26] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-10-27] ECB press: October 2026 euro area bank lending survey
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] ECB press: ECB President Lagarde to step down on 7 February 2027

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*