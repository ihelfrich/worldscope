# WORLDSCOPE morning brief — 2026-07-28

## Headline
2315 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (535) · Russian Internal News (state + in-exile) (492) · World leaders & government officials (324) · Chinese Internal News (183) · Ukraine Theater (total-war monitoring) (162) · U.S. Weather + Severe / Climate Outlooks (161) · Local News: St. Louis + Atlanta (91) · State-Level News (53) · GDELT GKG — themes / entities / watch areas (48) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (39) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 535 new of 972 total
  - (2026-07-28) [Global] The cocaine superhighway from Ecuador to Europe - the BBC reports on gangs and the police fightback
      The BBC goes on patrol with Ecuador's police, who are grappling with a huge surge in drug crime.
  - (2026-07-28) [Global] US walks out of UN Security Council meeting during France's remarks
      The row sparked after the US joined North Korea and Russia in voting against extending the term of the UN high commissioner for human rights.
  - (2026-07-28) [Global] Zidane confirmed as France head coach
      Former Real Madrid manager Zinedine Zidane has been confirmed as the head coach of the France national team.
  - (2026-07-28) [Global] Ariana Grande sues hackers who leaked music and videos
      The pop star is suing to discover the identity of hackers who obtained unreleased photos and songs.
  - (2026-07-28) [Global] Johnson & Johnson offers up to $5.5bn to settle baby powder lawsuits
      The proposed settlement aims to close a years-long legal battle over claims its talcs products cause cancer.
  - (2026-07-28) [Global] Hong Kong activist allowed to stay in UK after deportation threat
      Wu was detained for hours at London's Heathrow Airport last week and refused entry, he told the BBC.

### Russian Internal News (state + in-exile) — 492 new of 949 total
  - (2026-07-28) Зинедин Зидан стал главным тренером сборной Франции по футболу | LEDE: Новым главным тренером сборной Франции по футболу назначен Зинедин Зидан. Об этом говорится в сообщении национальной ко] (ru: Зин…
      Новым главным тренером сборной Франции по футболу назначен Зинедин Зидан. Об этом говорится в сообщении национальной команды.
  - (2026-07-28) «Верстка»: в Армении вырос спрос на квартиры со стороны россиян | LEDE: Россияне стали чаще искать квартиры в Армении, а цены на рынке аренды в Ереване выросли, пишет «Верстка», ссылаясь на ] (ru: «Ве…
      Россияне стали чаще искать квартиры в Армении, а цены на рынке аренды в Ереване выросли, пишет «Верстка», ссылаясь на местных риелторов.
  - (2026-07-28) Бастрыкин предложил считать использование ИИ при совершении преступлений отягчающим обстоятельством | LEDE: Глава Следственного комитета России Александр Бастрыкин предложил считать использо] (ru: Бас…
      Глава Следственного комитета России Александр Бастрыкин предложил считать использование искусственного интеллекта при совершении преступлений отягчающим обстоятельством. По его словам, сотрудники ведомства уже подготовил…
  - (2026-07-28) «Если вы сейчас не вмешаетесь, то ситуация станет патовой». Продавец с Wildberries (с 1,3М в инстаграме) обратилась к властям после ударов ВСУ | LEDE: Предпринимательница, основательница бре] (ru: «Ес…
      Предпринимательница, основательница бренда косметики Марина Горшкова (1,3 миллиона подписчиков в инстаграме) записала видео, в котором обратилась к руководству России из-за последствий украинских атак на склады Wildberri…
  - (2026-07-28) Омская область стала первым регионом России, где сняли лимиты на продажу топлива | LEDE: В Омской области с 28 июля отменены лимиты на продажу топлива, объявил губернатор Виталий Хоценко. «7] (ru: Омс…
      В Омской области с 28 июля отменены лимиты на продажу топлива, объявил губернатор Виталий Хоценко. «7×7» отмечает, что это первый регион России, где отменили подобные ограничения.
  - (2026-07-28) В Тюмени ввели режим чрезвычайной ситуации из-за наводнения. Жители города жаловались на запах от воды и гибель рыбы в реке | LEDE: В Тюмени и окрестностях ввели режим чрезвычайной ситуации ] (ru: В Т…
      В Тюмени и окрестностях ввели режим чрезвычайной ситуации из-за паводка на реке Тура, сообщил губернатор Тюменской области Александр Моор.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 183 new of 266 total
  - (2026-07-27) In Profile: Wall Street’s Go-To Regulator in China Swept Up in Anti-Graft Dragnet - Caixin Global
      In Profile: Wall Street’s Go-To Regulator in China Swept Up in Anti-Graft Dragnet Caixin Global
  - (2026-07-28) 今日开盘：两市双双低开 沪指跌幅0.91% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5HVzZjczdURmpTMXhIdjAwVWc4azZDbVhIVmROOVJIR0VRSEtwR0RWZHlDS3kwTEFJcnJqTEFqWHgwbTUtMXZVSmlFQlBRMm9K] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.91% 财新
  - (2026-07-28) 南华大学55岁校长夏昆任上被查 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9YZmpza0pqaFZ4a2dCM0RROUZqQ2xsUkxMRGVFQkFORDJiRllGc0NzZFRFQ0ItY1d2SzhpdTE4dkZid190RnJrc1hH] (zh:…
      南华大学55岁校长夏昆任上被查 china.caixin.com
  - (2026-07-28) 人事观察｜新疆新常委李刚兼任组织部长 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE4tU0ROdXZFUjBGb3REeEdCTE1XeTJIWmtpZVBIWW1OMmIydl84THZRVkZPV3Z0WmduRHd5TEZnSzhadUJiMDVJY] (zh:…
      人事观察｜新疆新常委李刚兼任组织部长 china.caixin.com
  - (2026-07-28) 银行老将贺劲松调任中信AMC党委书记 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBXY25udE5ZakxUZE42cXhGQ3N4MWVfRnF4Tnh1dG9EaVhoczhjcEpLX0s1V1VOX2dxT3NOdWwyUzY3aGUxZmtEU3BJejNYVzJ6eXY] (zh:…
      银行老将贺劲松调任中信AMC党委书记 财新
  - (2026-07-28) 含糖饮料不好卖，抹茶成新宠？｜饮食 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE53T0djUTY0SlVJNE1RZmZLOHRDalFkLVVTQ1ZpOHoycFVvbW1ndEhWYUN1d0NVemlVdEloWVM4d2dqV2xoT0tLY2hoRTd6Z3VBMU94] (zh:…
      含糖饮料不好卖，抹茶成新宠？｜饮食 财新

### Ukraine Theater (total-war monitoring) — 162 new of 530 total
  - (2026-07-28) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-26) [Liveuamap] Israeli forces raid the town of Deir Samet near Hebron in the West Bank and fire tear gas canisters. - Liveuamap
      Israeli forces raid the town of Deir Samet near Hebron in the West Bank and fire tear gas canisters.<
  - (2026-07-27) [Liveuamap] 5 people killed, as result of drone strike in Rostov region, - according to local authorities - Liveuamap
      5 people killed, as result of drone strike in Rostov region, - according to local authorities <font color="#
  - (2026-06-26) [Liveuamap] Two civilians were killed and others injured in a drone attack targeting a gas station in Rabak, White Nile State. Drones continued their raids on El Obeid, North Kordofan. - Liveuamap
      Two civilians were killed and others injured in a drone attack targeting a gas station in Rabak, White Nile State. Dron
  - (2026-07-24) [Liveuamap] Palestinians inspect the damage to a building following an Israeli airstrike last night that targeted Al-Jalaa Street in the center of Gaza City. - Liveuamap
      Palestinians inspect the damage to a building following an Israeli airstrike last night that targeted Al-
  - (2026-07-26) [Liveuamap] The Saudi Ministry of Defense says it was attacked earlier today by drones fired by Iraqi militias, aimed at oil facilities. The Ministry of Defense spokesperson, Major General Turki al-Ma…
      The Saudi Ministry of Defense says it was attacked earlier today by drones fired by Iraqi militias, aimed at oil fac

### U.S. Weather + Severe / Climate Outlooks — 161 new of 172 total
  - (2026-07-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-28) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 28 at 2:18AM MST until July 28 at 3:00AM MST by NWS Tucson AZ
      SVRTWC The National Weather Service in Tucson has issued a * Severe Thunderstorm Warning for... Central Pima County in southeastern Arizona... * Until 300 AM MST. * At 218 AM MST, a severe thunderstorm was located near T…
  - (2026-07-28) [Moderate] Special Weather Statement: Special Weather Statement issued July 28 at 5:13AM EDT by NWS Charleston WV
      At 513 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from 9 miles southwest of Hide-A-Way Hills to 8 miles north of South Webster. Movement was southeast at 45 mph. HAZARD...Wind gusts up…
  - (2026-07-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 28 at 5:06AM EDT until July 28 at 11:00AM EDT by NWS Marquette MI
      * WHAT...Visibility 1/4 mile or less in dense fog. * WHERE...Gogebic and Ontonagon Counties. * WHEN...Until 11 AM EDT /10 AM CDT/ this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-07-28) [Moderate] Gale Warning: Gale Warning issued July 28 at 2:05AM PDT until July 29 at 3:00PM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 15 to 25 kt with gusts up to 35 kt. * WHERE...Coastal Waters from Point Pinos to Point Piedras Blancas California out to 10 NM. * WHEN...Until 3 PM PDT Wednesday. * IMPACTS...Strong winds will ca…
  - (2026-07-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 28 at 3:58AM CDT until July 28 at 10:00AM CDT by NWS Duluth MN
      * WHAT...Visibility one quarter to one half mile in dense fog. * WHERE...In Minnesota, Carlton, St. Louis, North Cook and Lake Counties. In Wisconsin, Ashland, Bayfield, Douglas, and Iron Counties. This includes the Trib…

### Local News: St. Louis + Atlanta — 91 new of 224 total
  - (2026-07-28) [St. Louis] Where Art Thou? – 7/28/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-07-26) [St. Louis] 2 injured in overnight shooting in Pacific - First Alert 4
      2 injured in overnight shooting in Pacific First Alert 4
  - (2026-07-27) [St. Louis] Wrong-way crash on I-64 kills 2, injures 1 near downtown St. Louis - First Alert 4
      Wrong-way crash on I-64 kills 2, injures 1 near downtown
  - (2026-07-27) [St. Louis] Salt + Smoke to close 2 locations - First Alert 4
      Salt + Smoke to close 2 locations First Alert 4
  - (2026-07-27) [St. Louis] Nearly 1,200 police calls logged in two-block area where downtown St. Louis stabbing occurred - First Alert 4
      <a href="https://news.google.com/rss/articles/CBMixwFBVV95cUxQUUNkdGpFejQ2VElkN3NoWU4wTjd0MVdSZGtPbThNMXJGNXdEVjJhQkNNaFFTRHVBMkNwMEx1SVNmY25ERTRMZVJHNk1LMlJvWk5QX0FyTFpmc0x3SjFtXzg5aEZ0NEEzdGIzUEJVeHZ4VXJSOFl6dWxXeE1teG…
  - (2026-07-28) [St. Louis] New shopping center in Glen Carbon bringing 21 businesses to Metro East - First Alert 4
      New shopping center in Glen Carbon bringing

### State-Level News — 53 new of 450 total
  - (2026-07-28) [California] ‘Pretty sure he’s wet:’ Immigration agents used racial slurs during LA sweeps, court records show
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/062025-Bell-Immigration-Raid-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…
  - (2026-07-28) [California] California pension ruling limits how many vacation hours workers can count for retirement
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/07/050824-Supreme-Court-JF-AP-CM-25.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-28) [Connecticut] CT hospitals are redesigning ERs for behavioral health crises
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/YALE-KID-CRISIS-CENTER-0721-0721-SG-11-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" dec…
  - (2026-07-28) [Connecticut] CT’s hypocrisy about election integrity
      <img width="886" height="461" src="https://ctmirror.org/wp-content/uploads/2026/07/Bridgeport-ballot-box-stuffing.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="…
  - (2026-07-27) [Colorado] Fifty for 150: Colorado State Fair incorporated in Pueblo in 1886
      The Southern Colorado Agricultural and Industrial Association, after holding multiple fairs in Pueblo County since the 1870s, incorporated as the State Fair Association on Nov. 17, 1886. That established Pueblo as the ho…
  - (2026-07-28) [Maine] Two cities, two deaths, one resolve | Letter
      On Sept. 30, 1962, my dad was serving as a company commander in the 101st Airborne Division (the Screaming Eagles). Soldiers, wives and children were both nervous and proud that the 101st had been designated as highly mo…

### GDELT GKG — themes / entities / watch areas — 48 new of 48 total
  - (2026-07-28) [Russia oil sanctions perimeter · themes] Европе обещают аномально тёплый август : что стоит за изнуряющей жарой
      ru.euronews.com · Russian · tone NA
  - (2026-07-28) [Russia oil sanctions perimeter · themes] Build resilience : refinery touted but discount to end
      mandurahmail.com.au · English · tone NA
  - (2026-07-28) [Russia oil sanctions perimeter · themes] Fluturon çmimi i naftës në Kosovë - Lajmet e fundit
      zeri.info · Albanian · tone NA
  - (2026-07-28) [Russia oil sanctions perimeter · themes] 网红私自霸占无居民海岛 ， 直播 荒岛改造 被海警查处 ： 搭建建筑物5处 ， 铺设下水管道 、 立旗杆 ， 还圈地养家禽 、 布设太阳能供电设备|乔木
      163.com · Chinese · tone NA
  - (2026-07-28) [Russia oil sanctions perimeter · themes] Una fuga de aceite obliga a desalojar una empresa en Castellbisbal
      elperiodico.com · Spanish · tone NA
  - (2026-07-28) [Russia oil sanctions perimeter · themes] Daha Ucuz Olduğu İçin Gemiye Yerleştiler
      haberaktuel.com · Turkish · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-28) [White Lion Capital LLC] Form 4 (Reporting)
      filed 2026-07-28 01:58 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001193125-26-318582 Size: 9 KB
  - (2026-07-28) [ACTELIS NETWORKS INC] Form 4 (Issuer)
      filed 2026-07-28 01:58 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001193125-26-318582 Size: 9 KB
  - (2026-07-28) [Sharplink, Inc.] Form 4 (Issuer)
      filed 2026-07-28 01:52 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001493152-26-034910 Size: 5 KB
  - (2026-07-28) [MCKENZIE OBIE] Form 4 (Reporting)
      filed 2026-07-28 01:52 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001493152-26-034910 Size: 5 KB
  - (2026-07-28) [Chalom Joseph] Form 4 (Reporting)
      filed 2026-07-28 01:52 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001493152-26-034909 Size: 5 KB
  - (2026-07-28) [Sharplink, Inc.] Form 4 (Issuer)
      filed 2026-07-28 01:52 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001493152-26-034909 Size: 5 KB

### Ukrainian Internal News (national + local Kyiv) — 39 new of 108 total
  - (2026-07-28) Блогерка Лумер: Американцям не слід більше проводити переговори щодо війни в Україні в Москві | LEDE: Американська ультраправа блогерка Лора Лумер заявила, що переговори щодо російсько-українсь] (uk:…
      Американська ультраправа блогерка Лора Лумер заявила, що переговори щодо російсько-української війни за участі представників США не варто надалі проводити в Москві.
  - (2026-07-28) Останні дні липня будуть теплими і майже без опадів | LEDE: В Україні до кінця липня прогнозують теплу погоду і майже без опадів, лише 29 липня можливі короткочасні дощі на сході.] (uk: Останні дні ли…
      В Україні до кінця липня прогнозують теплу погоду і майже без опадів, лише 29 липня можливі короткочасні дощі на сході.
  - (2026-07-28) WSJ розповіло, що Трамп почав захоплюватися Україною, її дронами і стійкістю Зеленського | LEDE: Останніми тижнями президент США Дональд Трамп почав висловлювати новий оптимізм щодо України та ] (uk:…
      Останніми тижнями президент США Дональд Трамп почав висловлювати новий оптимізм щодо України та президента Володимира Зеленського, пише The Wall Street Journal.
  - (2026-07-28) Окупанти обстріляли житлові квартали Херсона: загинув 61-річний чоловік | LEDE: Близько 4:30 російські війська з окупованого лівобережжя обстріляли житлові квартали Херсона. Унаслідок атаки заг] (uk:…
      Близько 4:30 російські війська з окупованого лівобережжя обстріляли житлові квартали Херсона. Унаслідок атаки загинув 61-річний місцевий житель.
  - (2026-07-28) "Покарали" до травм черепа: за підозрою в знущанні з побратимів затримали двох бійців "Скелі" | LEDE: Правоохоронці повідомили про підозру двом військовослужбовцям медичної роти полку "Скеля", ] (uk:…
      Правоохоронці повідомили про підозру двом військовослужбовцям медичної роти полку "Скеля", які, за даними слідства, побили та незаконно утримували двох побратимів на Кіровоградщині.
  - (2026-07-28) На Запоріжжі російський БпЛА вдарив по рятувальниках під час гасіння пожежі | LEDE: У Запорізькій області російський безпілотник атакував рятувальників під час гасіння пожежі в одному з лісницт] (uk:…
      У Запорізькій області російський безпілотник атакував рятувальників під час гасіння пожежі в одному з лісництв, внаслідок чого постраждали четверо вогнеборців.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### World News (by country, top stories) — 30 new of 30 total
  - (2026-07-28) [China] 5 . 7 - magnitude quake jolts Qinghai in northwest China
      shanghaisun.com · English
  - (2026-07-28) [China] Opinion | How a Chinese model stopped a cyberattack when US guard rails failed
      scmp.com · English
  - (2026-07-28) [China] Flight Centre leisure CEO : There always a sharp rebound and a sharp recovery
      centreforaviation.com · English
  - (2026-07-28) [China] QAL chief of aviation : Bilateral rights tend to be drip fed
      centreforaviation.com · English
  - (2026-07-28) [China] Internet personality Mr Ho dies at 79 , just a week after receiving jail term
      scmp.com · English
  - (2026-07-28) [China] China rare earth reserves could be much larger than reported : leading geologist
      scmp.com · English

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-28) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (48.727, 2.3724) · on ground
  - (2026-07-28) JAF94H (Bulgaria)
      icao24: 4520aa · position: (48.698, 1.9928) · alt: 5196m · 741km/h
  - (2026-07-28) SAMU05 (France)
      icao24: 39ca81 · position: (45.1506, 5.7687) · alt: 701m · 190km/h
  - (2026-07-28) GAF117 (Germany)
      icao24: 3ea556 · position: (52.307, 8.7311) · alt: 4259m · 509km/h
  - (2026-07-28) GAF870 (Germany)
      icao24: 3f97fd · position: (52.7444, 4.2395) · alt: 10980m · 735km/h
  - (2026-07-28) CFC2976 (Canada)
      icao24: c2b585 · position: (50.844, 19.0717) · alt: 8237m · 683km/h

### U.S. Federal Action — 21 new of 22 total
  - (2026-07-28) Actions by the United States in the Investigations Under Section 301 of the Trade Act of 1974 of the Acts, Policies, and Practices of 60 Economies Related to the Failure of Each Economy To Impose and…
  - (2026-07-28) Presidential Determination on the Proposed Agreement for Cooperation Between the Government of the United States of America and the Government of the Kingdom of Saudi Arabia Concerning Peaceful Uses o…
  - (2026-07-28) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-19- 14, which applied to certain The Boeing Company Model 777-200, 777- 200LR, 777-300ER, and 777F series airplanes. AD 2024-19-14 required repetitive inspections…
  - (2026-07-28) Federal Motor Vehicle Safety Standards; Modernization of FMVSS No. 135 To Accommodate ADS-Equipped Vehicles; Extension of Comment Period
      In response to a request from Varnum LLP (Varnum), NHTSA is announcing a 30-day extension of the public comment period for the notice of proposed rulemaking (NPRM) published on June 26, 2026 proposing to amend Federal Mo…
  - (2026-07-28) Civil Penalties Adjustment for 2026
      The National Endowment for the Arts (NEA) is notifying the public that its civil monetary penalty amounts will not increase for the 2026 calendar year. The NEA is generally required by statute to amend its regulations an…
  - (2026-07-28) Modification of Class E Airspace, Samaritan North Lincoln Hospital Heliport, Lincoln, OR
      This action proposes to modify Class E airspace extending upward from 700 feet above the surface at Samaritan North Lincoln Hospital Heliport, Lincoln, OR. This action would support the safety and management of instrumen…

### Paper Trading Scorecard — 16 new of 133 total
  - (2026-07-28) [Polymarket] Will Coalition Avenir Québec win the most seats in the 2026 Quebec general election?
      Parliamentary elections to elect all 125 seats of the National Assembly of Quebec are scheduled to take place in Quebec on October 5, 2026. This market will resolve to the political party that wins the greatest number of…
  - (2026-07-28) [Polymarket] Will Z.ai have the best Chinese AI model at the end of July 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank among primarily Chinese companies, based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table und…
  - (2026-07-28) [Kalshi] US real GDP growth in 2036?
      2036
  - (2026-07-28) [Kalshi] US real GDP growth in 2035?
      2035
  - (2026-07-28) [Kalshi] US real GDP growth in 2034?
      2034
  - (2026-07-28) [Kalshi] US real GDP growth in 2033?
      2033

### USGS earthquakes (M4.5+, past day) — 14 new of 24 total
  - (2026-07-28) M 6.8 - 5 km E of Uto, Japan
      M6.8 · 5 km E of Uto, Japan · depth 10 km · PAGER red
  - (2026-07-28) M 5.9 - 50 km WSW of Brisas Barra de Suchiate, Mexico
      M5.9 · 50 km WSW of Brisas Barra de Suchiate, Mexico · depth 35 km
  - (2026-07-28) M 5.8 - 160 km E of Ust’-Kamchatsk Staryy, Russia
      M5.8 · 160 km E of Ust’-Kamchatsk Staryy, Russia · depth 10 km
  - (2026-07-28) M 5.8 - 191 km NW of Oula Xiuma, China
      M5.8 · 191 km NW of Oula Xiuma, China · depth 10 km · PAGER yellow
  - (2026-07-28) M 5.7 - 192 km NW of Oula Xiuma, China
      M5.7 · 192 km NW of Oula Xiuma, China · depth 10 km · PAGER yellow
  - (2026-07-28) M 5.6 - 16 km NE of Tsunagi, Japan
      M5.6 · 16 km NE of Tsunagi, Japan · depth 10 km

### IT, InfoSys & cybersecurity news (last 7 days) — 13 new of 57 total
  - (2026-07-28) [BleepingComputer] Data breach at medical billing firm MCBS affects 1.26 million people
      Healthcare billing company Medical Computer Business Services (MCBS) has disclosed that a 2025 network breach exposed the sensitive information of more than 1.2 million people. [...]
  - (2026-07-28) [The Hacker News] Critical TeamCity Flaw Could Let Attackers Run OS Commands Without Logging In
      JetBrains is urging customers of on-premise versions of TeamCity to update to the latest version following the discovery of a critical security issue that could result in arbitrary code execution. The vulnerability, assi…
  - (2026-07-28) [The Hacker News] Researcher Says AI Helped Develop Linux Traffic-Control Race Into Root Exploit
      STAR Labs has published a Linux kernel exploit that turns an ordinary local user into root on the CentOS Stream 9 build it targeted. The flaw, tracked as CVE-2026-53264 (CVSS score: 7.8), is a use-after-free race in the…
  - (2026-07-28) [The Hacker News] Microsoft Says New Cybersecurity AI Model Helps MDASH Hit 95.95% at Half the Cost
      Microsoft has launched its first cybersecurity-specific model inside MDASH, its multi-model vulnerability identification and remediation harness. The company says MDASH, using MAI-Cyber-1-Flash and GPT-5.4, scored 95.95%…
  - (2026-07-28) [The Hacker News] Attackers Exploit Arista VeloCloud Orchestrator Command Injection Flaw
      A maximum-severity security flaw impacting on-premises versions of Arista VeloCloud Orchestrator (VCO) has come under active exploitation in the wild. The vulnerability, tracked as CVE-2026-16812 (CVSS score: 10.0), is a…
  - (2026-07-28) [The Register] Openreach nudges another 112 exchange areas toward full fiber
      Latest batch takes the copper sales restrictions to 1,572 locations and 15.4 million premises

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-28) Targu Mures: Mia Ristic vs Darja Semenistaja
      yes price: 100% · 24h volume: $360,982 · resolves 2026-08-04
  - (2026-07-28) Strait of Hormuz traffic returns to normal by July 31?
      yes price: 0% · 24h volume: $354,914 · resolves 2026-07-31
  - (2026-07-28) Cleveland Guardians vs. Cincinnati Reds
      yes price: 42% · 24h volume: $303,724 · resolves 2026-08-03
  - (2026-07-28) Will Shakhtar Donetsk win the 2026-27 UEFA Champions League Championship?
      yes price: 0% · 24h volume: $284,375 · resolves 2027-05-30
  - (2026-07-28) LoL: Kiwoom DRX vs KT Rolster (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 57% · 24h volume: $277,880 · resolves 2026-07-28
  - (2026-07-28) Samsun: Takuya Kumasaka vs Florent Bax
      yes price: 26% · 24h volume: $256,490 · resolves 2026-08-03

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-07-23) U.S. Court of Appeals, 4th Cir.: Badar Suri v. Donald Trump
  - (2026-07-23) U.S. Court of Appeals, 5th Cir.: United States v. Debrow
  - (2026-07-23) U.S. Court of Appeals, 5th Cir.: United States v. Murphy
  - (2026-07-23) U.S. Court of Appeals, 7th Cir.: Brad Passwater v. Tricia Pretorius
  - (2026-07-23) U.S. Court of Appeals, 7th Cir.: United States v. Larry Doss
  - (2026-07-23) Delaware Supreme Court: Tang v. State

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 37 total
  - (2026-07-28) MOVER ▲ Tadashi Yanai & family — $66.34B (+$1.86B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-28) MOVER ▼ Bernard Arnault & family — $140.92B ($-1.74B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-28) MOVER ▼ Gautam Adani — $84.01B ($-1.56B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-28) MOVER ▲ Francoise Bettencourt Meyers & family — $92.86B (+$0.96B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-28) MOVER ▼ Mukesh Ambani — $85.93B ($-0.73B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-28) MOVER ▲ Bill Gates — $106.31B (+$0.07B since yesterday)
      United States · Technology · source: Microsoft

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 116 total
  - (2026-07-28) [USASpending] $819,751,946 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-28) [USASpending] $677,433,934 → LEIDOS, INC.: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
      Agency: Department of Transportation. Description: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
  - (2026-07-28) [USASpending] $676,184,419 → HII MISSION TECHNOLOGIES CORP: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE
      Agency: General Services Administration. Description: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE ISR AND NEXTGEN TECHNOLOGY (LOGIX)
  - (2026-07-28) [USASpending] $650,555,645 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-07-28) [USASpending] $526,585,488 → PARSONS GOVERNMENT SERVICES INC.: BOLD VENTURE
      Agency: General Services Administration. Description: BOLD VENTURE

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-28) [Marginal Revolution] The AEA presidential election
      AEA is the American Economics Association, and a new president is needed, here is the candidate and likely winner: PINELOPI (PENNY) KOUJIANOU GOLDBERG, William Nordhaus Professor of Economics and Global Affairs, Yale Uni…
  - (2026-07-28) [Marginal Revolution] The Confucian fertility paradox
      Total fertility rates in East Asia have fallen to levels without historical precedent, even though the region’s Confucian heritage long placed extraordinary emphasis on family continuity and large families. We argue that…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=17, 14d-median=17; carrying terms: standard, management, security, model, control, provide, limited, certain, directive, proposing, special, august
- state_bills: today=0, 7d-median=66, 14d-median=66
- state_news: today=450, 7d-median=472, 14d-median=472; carrying terms: immigration, violated, accountability, march, louisiana, settlement, natural, offer, donald, toward, reports, remain
- local_news: today=224, 7d-median=229, 14d-median=229; carrying terms: resize, events, region, reports, cbmirafbvv, latest, figure, killed, stlmag, cbmiowfbvv, critical, crews
- foreign_news: today=972, 7d-median=1007, 14d-median=1007; carrying terms: march, sunday, turkey, settlement, urged, farewell, natural, offer, remain, lebanon, defence, discusses
- chinese_internal: today=266, 7d-median=266, 14d-median=266; carrying terms: lxtfa, global, cbmib, build, giant, google, blank, market, cbmiakfvx, lxtfb, cbmia, target
- russian_internal: today=949, 7d-median=879, 14d-median=879; carrying terms: times, laquo, forbidden, group, title, centcom, error, istories, novayagazeta, reuters, europe, https
- ukrainian_internal: today=108, 7d-median=137, 14d-median=137; carrying terms: disrupt, analysts, growing, efforts, sunday, missiles, urged, donald, moscow, toward, remain, region
- ukraine_theater: today=530, 7d-median=586, 14d-median=586; carrying terms: nemdjuwlqmxjqukl, mxrudhc, xeqmhhaw, nfhtbw, march, rhaybw, fuwvjqa, phsfzrzlv, reports, tvjiuze, jprddvz, lebanon
- paper_bets: today=133, 7d-median=138, 14d-median=138; carrying terms: benefits, playoff, humans, lifetime, jackson, supreme, declared, office, performing, security, georgia, control
- weather: today=172, 7d-median=175, 14d-median=175; carrying terms: afdmtr, lying, worth, details, capable, sunday, ruskin, mountains, greater, region, onshore, begin
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: nonfarm, labor, implied, jtsjol, dexjpus, payems, pcepilfe, crude, commodities, vixcls, treasury, money
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, futures, credit, close, nasdaq, range, large, silver, yield, bitcoin, rates, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=116, 7d-median=119, 14d-median=119; carrying terms: mufswgh, sectoral, abuses, management, homeland, required, actions, cbmiaefvx, enable, security, usaspending, events
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, error, quiverquant, congresstrading, client, quiver, quantitative, unauthorized, https
- billionaires: today=37, 7d-median=34, 14d-median=34; carrying terms: spacex, amazon, tadashi, carlos, francoise, investments, tesla, zuckerberg, adani, meyers, charles, gcarsoa
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: ahmed, supreme, trade, group, international, delaware, robert, blanche, appeals, district, medical, douglas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, committee, alexandria, texas, shawn, sherrod, house, congress, filing, pinkston, ossoff, senate
- gdelt_regions: today=30, 7d-median=12, 14d-median=12; carrying terms: english, china
- gdelt_gkg: today=48, 7d-median=47, 14d-median=47; carrying terms: english, trump, hezbollah, israel, perimeter, hormuz, sanctions, russia, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=18, 14d-median=18
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: observed, consuming, geographic, director, viruses, arabia, beginning, humans, associated, additi, algeria, march
- cisa_kev: today=17, 7d-median=16, 14d-median=16; carrying terms: directory, sonicwall, request, untrusted, fortisandbox, mechanism, active, server, overly, insufficient, function, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=179, 14d-median=179; carrying terms: cyclone, croatia, flood, thailand, ukraine, macedonia, depth, montenegro, switzerland, france, hungary, agricultural
- usgs_quakes: today=24, 7d-median=24, 14d-median=24; carrying terms: depth, atlantic, region, islands, south, ridge, indonesia, philippines
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, price, meeting, resolves, volume, ethiopia, rates, interest, prime, change, decrease, abiebie
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: benefit, economist, https, revolution, conversable, marginalrevolution, marginal, class, looking, working, quality
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: provides, security, model, surveillance, hackers, technology, suspend, record, request, speed, unprecedented, systems
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: zquez, steven, director, risch, reserved, ellzey, cisneros, frost, laurel, comer, rivet, comptroller
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, market, sufficient, claude, decision, markets, either, identify, placement, unavailable, paper, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*