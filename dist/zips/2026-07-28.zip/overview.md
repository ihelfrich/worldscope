# WORLDSCOPE morning brief — 2026-07-28

## Headline
2559 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (634) · Russian Internal News (state + in-exile) (574) · World leaders & government officials (324) · Chinese Internal News (186) · Ukraine Theater (total-war monitoring) (170) · U.S. Weather + Severe / Climate Outlooks (163) · Local News: St. Louis + Atlanta (125) · State-Level News (110) · Ukrainian Internal News (national + local Kyiv) (48) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (30)

## What changed today
### International News + Multilateral Institutions — 634 new of 980 total
  - (2026-07-28) [Global] Zelensky to press Trump on air defences while in Washington
      Ukraine's leader is hoping to firm up US commitments to bolstering Kyiv's anti-ballistic missile defences, as Russia has escalated deadly attacks.
  - (2026-07-28) [Global] The cocaine superhighway from Ecuador to Europe - the BBC reports on gangs and the police fightback
      The BBC goes on patrol with Ecuador's police, who are grappling with a huge surge in drug crime.
  - (2026-07-28) [Global] US walks out of UN Security Council meeting during France's remarks
      The row sparked after the US joined North Korea and Russia in voting against extending the term of the UN high commissioner for human rights.
  - (2026-07-28) [Global] Seattle pays tribute to food festival shooting victims
      Families grieved on Monday as they remembered the three people killed in a shooting at a food festival.
  - (2026-07-28) [Global] Zidane confirmed as France head coach
      Former Real Madrid manager Zinedine Zidane has been confirmed as the head coach of the France national team.
  - (2026-07-28) [Global] Odyssey translator writes scathing review of Nolan film adaptation
      The film has won rave reviews from film critics but a translator of Homer's work was less than impressed.

### Russian Internal News (state + in-exile) — 574 new of 1001 total
  - (2026-07-28) «Единая Россия» наконец прислала в регионы брендбук. До выборов меньше двух месяцев — но программы партии до сих пор нет. Вместо нее в брошюре повторяется отрывок из «Войны и мира»: «Дядюшка пе] (ru:…
      В распоряжение «Медузы» попал брендбук, в соответствии с которым региональные отделения «Единой России» должны оформлять агитационные материалы для местных кандидатов. Также в брендбуке показан дизайн агитации для кампан…
  - (2026-07-28) Из «Эксмо-АСТ» уволили сотрудников, которые отказались цензурировать книги | LEDE: Из издательской группы «Эксмо-АСТ» уволили часть сотрудников, которые отказались работать по цензурным прав] (ru: Из…
      Из издательской группы «Эксмо-АСТ» уволили часть сотрудников, которые отказались работать по цензурным правилам, которые ввели на фоне новых российских законов. Другие несогласные ушли сами, рассказал президент группы Ол…
  - (2026-07-28) Война. 1616-й день. Зеленский прилетел в США на похороны Грэма. Он встретится с Трампом — и попытается получить поддержку у консерваторов MAGA | LEDE: «Медуза» с 24 февраля 2022 года в прямо] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-28) Reuters: тюменский НПЗ приостановил работу после атаки украинских дронов | LEDE: Тюменский нефтеперерабатывающий завод приостановил переработку нефти после атаки украинских беспилотников, ко] (ru: Reu…
      Тюменский нефтеперерабатывающий завод приостановил переработку нефти после атаки украинских беспилотников, которая произошла 25 июля. Об этом сообщает Reuters со ссылкой на источники в отрасли.
  - (2026-07-28) В Японии произошло землетрясение. Пострадали как минимум 50 человек | LEDE: На юго-западе Японии произошло землетрясение магнитудой 7,1. По данным Японского метеорологического агентства, оча] (ru: В Я…
      На юго-западе Японии произошло землетрясение магнитудой 7,1. По данным Японского метеорологического агентства, очаг землетрясения находился в префектуре Кумамото на глубине около 10 километров, сообщает агентство Kyodo.
  - (2026-07-28) «Ведомости» назвали декабристов «нежелательной» организацией. Скорее всего, алгоритм сайта перепутал их c современной НПО из Германии | LEDE: Газета «Ведомости» в статье, посвященной судам н] (ru: «Ве…
      Газета «Ведомости» в статье, посвященной судам над участниками восстания на Сенатской площади Петербурга в 1825 году, по ошибке пометила декабристов как «нежелательную» в России организацию.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 186 new of 276 total
  - (2026-07-27) In Profile: Wall Street’s Go-To Regulator in China Swept Up in Anti-Graft Dragnet - Caixin Global
      In Profile: Wall Street’s Go-To Regulator in China Swept Up in Anti-Graft Dragnet Caixin Global
  - (2026-07-28) 今日开盘：两市双双低开 沪指跌幅0.91% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5HVzZjczdURmpTMXhIdjAwVWc4azZDbVhIVmROOVJIR0VRSEtwR0RWZHlDS3kwTEFJcnJqTEFqWHgwbTUtMXZVSmlFQlBRMm9K] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.91% 财新
  - (2026-07-28) 南华大学55岁校长夏昆任上被查 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9YZmpza0pqaFZ4a2dCM0RROUZqQ2xsUkxMRGVFQkFORDJiRllGc0NzZFRFQ0ItY1d2SzhpdTE4dkZid190RnJrc1hH] (zh:…
      南华大学55岁校长夏昆任上被查 china.caixin.com
  - (2026-07-28) 人事观察｜新疆新常委李刚兼任组织部长 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE4tU0ROdXZFUjBGb3REeEdCTE1XeTJIWmtpZVBIWW1OMmIydl84THZRVkZPV3Z0WmduRHd5TEZnSzhadUJiMDVJY] (zh:…
      人事观察｜新疆新常委李刚兼任组织部长 china.caixin.com
  - (2026-07-28) 含糖饮料不好卖，抹茶成新宠？｜饮食 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE53T0djUTY0SlVJNE1RZmZLOHRDalFkLVVTQ1ZpOHoycFVvbW1ndEhWYUN1d0NVemlVdEloWVM4d2dqV2xoT0tLY2hoRTd6Z3VBMU94] (zh:…
      含糖饮料不好卖，抹茶成新宠？｜饮食 财新
  - (2026-07-28) 法国西班牙野火肆虐致超32万人撤离 两国已启动欧盟民防机制 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1YN01ZTkU1X2pQcEhpaGU5MndxM2lnZmFBY2Yxdm9TZWZqb0RsMHo2Sl9WbV90cGtPc2tKRFJMcEI1djg4empObUJx] (zh:…
      法国西班牙野火肆虐致超32万人撤离 两国已启动欧盟民防机制 财新

### Ukraine Theater (total-war monitoring) — 170 new of 530 total
  - (2026-07-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-27) [Liveuamap] President Zelensky: Ukrainian long range weapons targeted export terminal in Rostov region, oil infrastructure in Yaroslavl region and Udmurtiya Republic 1300 kms from Ukraine Rostov, Rost…
      President Zelensky: Ukrainian long range weapons targeted export terminal in Rostov region, oil infrastructure in Yaroslavl regio
  - (2026-07-26) [Liveuamap] Israeli forces raid the town of Deir Samet near Hebron in the West Bank and fire tear gas canisters. - Liveuamap
      Israeli forces raid the town of Deir Samet near Hebron in the West Bank and fire tear gas canisters.<
  - (2026-07-26) [Liveuamap] 2 people killed, 3 wounded as result of drone strike at the grocery store in Chernihiv - Liveuamap
      2 people killed, 3 wounded as result of drone strike at the grocery store in Chernihiv <font color="#6f6f6f"
  - (2026-07-28) [Liveuamap] At Lyman direction clashes yesterday near Drobysheve, Ozerne, Stavky, Lyman and near Novoselivka and Novomykhaylivka, - General Staff of Armed Forces of Ukraine reports Lyman, Donetsk obla…
      At Lyman direction clashes yesterday near Drobysheve, Ozerne, Stavky, Lyman and near Novoselivka and Novomykhaylivka, - G
  - (2026-07-26) [Liveuamap] The US is attempting to intercept Iranian missiles over the Muwaffaq Salti airbase in Jordan. Azraq, Jordan - Liveuamap
      The US is attempting to intercept Iranian missiles over the Muwaffaq Salti airbase in Jordan. Azraq, Jordan

### U.S. Weather + Severe / Climate Outlooks — 163 new of 171 total
  - (2026-07-28) [Moderate] Special Weather Statement: Special Weather Statement issued July 28 at 8:22AM EDT by NWS Jackson KY
      At 821 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Hoskinston to near Saylor to Kayjay. Movement was southeast at 35 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. S…
  - (2026-07-28) [Severe] Flood Watch: Flood Watch issued July 28 at 8:22AM EDT until July 29 at 8:00PM EDT by NWS Binghamton NY
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of central New York, including the following areas, Broome, Chenango, Delaware, Otsego and Sullivan and northeast Pennsylv…
  - (2026-07-28) [Severe] Flash Flood Warning: Flash Flood Warning issued July 28 at 8:21AM EDT until July 28 at 11:15AM EDT by NWS Charleston WV
      FFWRLX The National Weather Service in Charleston has issued a * Flash Flood Warning for... Northwestern Boone County in central West Virginia... Lincoln County in central West Virginia... North Central Logan County in s…
  - (2026-07-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-28) [Moderate] Special Weather Statement: Special Weather Statement issued July 28 at 7:12AM CDT by NWS Brownsville TX
      The combination of hot temperatures and humidity will produce heat index values between 105 and 110 degrees for several hours this afternoon and early evening. A few locations may briefly experience heat index values abo…
  - (2026-07-28) [Severe] Flash Flood Warning: Flash Flood Warning issued July 28 at 8:06AM EDT until July 28 at 12:15PM EDT by NWS Buffalo NY
      FFWBUF The National Weather Service in Buffalo has issued a * Flash Flood Warning for... Southwestern Allegany County in western New York... Southeastern Cattaraugus County in western New York... * Until 1215 PM EDT. * A…

### Local News: St. Louis + Atlanta — 125 new of 228 total
  - (2026-07-28) [St. Louis] Rep. Bill Hardwick seeks to bring consensus approach to Rolla-area Senate seat
  - (2026-07-28) [St. Louis] 2 St. Louis high schoolers went to the ‘NBA draft for theater’ — and shone
  - (2026-07-28) [St. Louis] An iconic St. Louis mural is getting a refresh after 40 years
  - (2026-07-28) [St. Louis] Salt + Smoke to close restaurants in St. Louis Hills and Ellisville
      Salt + Smoke, one of St. Louis’ locally-owned barbecue chainlets, is closing two of eight locations, effective August 1, according to a social media announcement posted Monday afternoon. The post read, in part, that “wit…
  - (2026-07-28) [St. Louis] ICE explores leasing ‘surge parking’ in St. Louis for up to 30 vehicles
      With little fanfare, the Department of Homeland Security recently posted a notice seeking “surge parking” spaces in several U.S. cities on behalf of Immigration and Customs Enforcement. Among those cities is St. Louis. T…
  - (2026-07-28) [St. Louis] Bush/Bell rematch is far less expensive than 2024—but turnout is trending up
      St. Louisans have already been going to the polls for almost a week as incumbent Representative Wesley Bell faces Cori Bush in a rematch of the 2024 race. Which candidate wins depends on who turns out and, thanks to vote…

### State-Level News — 110 new of 493 total
  - (2026-07-28) [California] California cannot keep rewarding utilities after catastrophic wildfires
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/062926-Altadena-Fire-Protest-GETTY-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-07-28) [California] They once taught about a hero. Now faculty rethink César Chávez lessons after allegations
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/031926_Cesar-Chavez-LA_TS_CM_18.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-07-28) [California] Brazil gives parents social media controls for their kids. Why doesn’t California?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/08/083024_Santa-Monica-Construction_-ZS-32_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp…
  - (2026-07-28) [California] ‘Pretty sure he’s wet:’ Immigration agents used racial slurs during LA sweeps, court records show
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/062025-Bell-Immigration-Raid-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…
  - (2026-07-28) [California] California pension ruling limits how many vacation hours workers can count for retirement
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/07/050824-Supreme-Court-JF-AP-CM-25.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-28) [Connecticut] CT hospitals are redesigning ERs for behavioral health crises
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/YALE-KID-CRISIS-CENTER-0721-0721-SG-11-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" dec…

### Ukrainian Internal News (national + local Kyiv) — 48 new of 114 total
  - (2026-07-28) МЗС відкинуло звинувачення щодо атак на території Іраку: Збігаються з пропагандою РФ | LEDE: МЗС України відкинуло безпідставні та бездоказові звинувачення радника з питань національної безпеки] (uk:…
      МЗС України відкинуло безпідставні та бездоказові звинувачення радника з питань національної безпеки Іраку Касіма Аль-Абуді в нібито причетності України до атак на території цієї країни.
  - (2026-07-28) Затриманим за побиття української пари у Польщі загрожує до 5 років тюрми | LEDE: Затриманим підозрюваним у резонансному побитті українських громадян у польському Вроцлаві загрожує до 5 років п] (uk:…
      Затриманим підозрюваним у резонансному побитті українських громадян у польському Вроцлаві загрожує до 5 років позбавлення волі.
  - (2026-07-28) Військовослужбовець "Гідеон": Україна може повторити помилки США після війни у В'єтнамі | LEDE: ] (uk: Військовослужбовець "Гідеон": Україна може повторити помилки США після війни у В)
  - (2026-07-28) Напад на українців у Вроцлаві: Туск закликав Навроцького перервати мовчання та засудити насильство | LEDE: Прем'єр Польщі Дональд Туск після нападу на українську пару у Вроцлаві закликав презид] (uk:…
      Прем'єр Польщі Дональд Туск після нападу на українську пару у Вроцлаві закликав президента Кароля Навроцького публічно відреагувати на зростання насильства та діяльність радикальних угруповань.
  - (2026-07-28) Пропонував незаконний виїзд до Молдови: організатора затримали в обміннику Києва | LEDE: Правоохоронці повідомили про підозру 25-річному уродженцю Запоріжжя, який обіцяв військовозобов'язаному ] (uk:…
      Правоохоронці повідомили про підозру 25-річному уродженцю Запоріжжя, який обіцяв військовозобов'язаному допомогти незаконно перетнути державний кордон України.
  - (2026-07-28) У Львові на акції проти відставки Федорова затримали психічно хворого чоловіка з ножем | LEDE: Під час акції у Львові поліція затримала чоловіка з ножем, який має психічні розлади.] (uk: У Львові на а…
      Під час акції у Львові поліція затримала чоловіка з ножем, який має психічні розлади.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-28) 425 - STANDARD BIOTOOLS INC. (0001162194) (Subject)
      filed 2026-07-28 12:22 UTC — Filed: 2026-07-28 AccNo: 0001140361-26-029842 Size: 88 KB
  - (2026-07-28) 485APOS - Tidal Trust V (0002081107) (Filer)
      filed 2026-07-28 12:17 UTC — Filed: 2026-07-28 AccNo: 0001999371-26-016182 Size: 1 MB
  - (2026-07-28) 485APOS - Tidal Trust V (0002081107) (Filer)
      filed 2026-07-28 12:17 UTC — Filed: 2026-07-28 AccNo: 0001999371-26-016182 Size: 1 MB
  - (2026-07-28) 424B5 - DYNEX CAPITAL INC (0000826675) (Filer)
      filed 2026-07-28 12:14 UTC — Filed: 2026-07-28 AccNo: 0000826675-26-000084 Size: 766 KB
  - (2026-07-28) 424B3 - URUGUAY REPUBLIC OF (0000102385) (Filer)
      filed 2026-07-28 12:05 UTC — Filed: 2026-07-28 AccNo: 0001193125-26-318917 Size: 621 KB
  - (2026-07-28) 424B3 - URUGUAY REPUBLIC OF (0000102385) (Filer)
      filed 2026-07-28 12:02 UTC — Filed: 2026-07-28 AccNo: 0001193125-26-318915 Size: 650 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-28) CFC3181 (Canada)
      icao24: c2b373 · position: (46.6794, -76.7642) · alt: 11277m · 836km/h
  - (2026-07-28) CFC3412 (Canada)
      icao24: c2c363 · position: (46.8336, -69.2663) · alt: 12496m · 908km/h
  - (2026-07-28) PAT730 (United States)
      icao24: adfe49 · position: (38.7039, -77.167) · alt: 175m · 274km/h
  - (2026-07-28) FAF7812 (France)
      icao24: 39a842 · position: (55.8233, -2.3735) · alt: 2743m · 278km/h
  - (2026-07-28) GAF191 (Germany)
      icao24: 3f727c · position: (49.7108, 9.7665) · alt: 822m · 412km/h
  - (2026-07-28) SAMU06 (France)
      icao24: 39c901 · position: (43.5772, 6.4978) · alt: 1478m · 230km/h

### U.S. Federal Action — 21 new of 22 total
  - (2026-07-28) Actions by the United States in the Investigations Under Section 301 of the Trade Act of 1974 of the Acts, Policies, and Practices of 60 Economies Related to the Failure of Each Economy To Impose and…
  - (2026-07-28) Presidential Determination on the Proposed Agreement for Cooperation Between the Government of the United States of America and the Government of the Kingdom of Saudi Arabia Concerning Peaceful Uses o…
  - (2026-07-28) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-19- 14, which applied to certain The Boeing Company Model 777-200, 777- 200LR, 777-300ER, and 777F series airplanes. AD 2024-19-14 required repetitive inspections…
  - (2026-07-28) Federal Motor Vehicle Safety Standards; Modernization of FMVSS No. 135 To Accommodate ADS-Equipped Vehicles; Extension of Comment Period
      In response to a request from Varnum LLP (Varnum), NHTSA is announcing a 30-day extension of the public comment period for the notice of proposed rulemaking (NPRM) published on June 26, 2026 proposing to amend Federal Mo…
  - (2026-07-28) Civil Penalties Adjustment for 2026
      The National Endowment for the Arts (NEA) is notifying the public that its civil monetary penalty amounts will not increase for the 2026 calendar year. The NEA is generally required by statute to amend its regulations an…
  - (2026-07-28) Modification of Class E Airspace, Samaritan North Lincoln Hospital Heliport, Lincoln, OR
      This action proposes to modify Class E airspace extending upward from 700 feet above the surface at Samaritan North Lincoln Hospital Heliport, Lincoln, OR. This action would support the safety and management of instrumen…

### Paper Trading Scorecard — 19 new of 134 total
  - (2026-07-28) [Polymarket] Will Coalition Avenir Québec win the most seats in the 2026 Quebec general election?
      Parliamentary elections to elect all 125 seats of the National Assembly of Quebec are scheduled to take place in Quebec on October 5, 2026. This market will resolve to the political party that wins the greatest number of…
  - (2026-07-28) [Polymarket] Will Z.ai have the best Chinese AI model at the end of July 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank among primarily Chinese companies, based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table und…
  - (2026-07-28) [Kalshi] US real GDP growth in 2036?
      2036
  - (2026-07-28) [Kalshi] US real GDP growth in 2035?
      2035
  - (2026-07-28) [Kalshi] US real GDP growth in 2034?
      2034
  - (2026-07-28) [Kalshi] US real GDP growth in 2033?
      2033

### IT, InfoSys & cybersecurity news (last 7 days) — 19 new of 57 total
  - (2026-07-28) [BleepingComputer] Over 24,000 exposed server BMCs leak password hash via decades-old flaw
      More than 24,000 internet-exposed servers are leaking authentication password hashes due to a 20-year-old vulnerability in their Baseboard Management Controller (BMC) interface. [...]
  - (2026-07-28) [BleepingComputer] Data breach at medical billing firm MCBS affects 1.26 million people
      Healthcare billing company Medical Computer Business Services (MCBS) has disclosed that a 2025 network breach exposed the sensitive information of more than 1.2 million people. [...]
  - (2026-07-28) [The Hacker News] Critical TeamCity Flaw Could Let Attackers Run OS Commands Without Logging In
      JetBrains is urging customers of on-premise versions of TeamCity to update to the latest version following the discovery of a critical security issue that could result in arbitrary code execution. The vulnerability, assi…
  - (2026-07-28) [The Hacker News] Researcher Says AI Helped Develop Linux Traffic-Control Race Into Root Exploit
      STAR Labs has published a Linux kernel exploit that turns an ordinary local user into root on the CentOS Stream 9 build it targeted. The flaw, tracked as CVE-2026-53264 (CVSS score: 7.8), is a use-after-free race in the…
  - (2026-07-28) [The Hacker News] Microsoft Says New Cybersecurity AI Model Helps MDASH Score 95.95% at Half the Cost
      Microsoft has launched its first cybersecurity-specific model inside MDASH, its multi-model vulnerability identification and remediation harness. The company says MDASH, using MAI-Cyber-1-Flash and GPT-5.4, scored 95.95%…
  - (2026-07-28) [The Hacker News] Attackers Exploit Arista VeloCloud Orchestrator Command Injection Flaw
      A maximum-severity security flaw impacting on-premises versions of Arista VeloCloud Orchestrator (VCO) has come under active exploitation in the wild. The vulnerability, tracked as CVE-2026-16812 (CVSS score: 10.0), is a…

### USGS earthquakes (M4.5+, past day) — 16 new of 23 total
  - (2026-07-28) M 6.8 - 5 km E of Uto, Japan
      M6.8 · 5 km E of Uto, Japan · depth 10 km · PAGER red
  - (2026-07-28) M 5.9 - 50 km WSW of Brisas Barra de Suchiate, Mexico
      M5.9 · 50 km WSW of Brisas Barra de Suchiate, Mexico · depth 35 km
  - (2026-07-28) M 5.8 - 160 km E of Ust’-Kamchatsk Staryy, Russia
      M5.8 · 160 km E of Ust’-Kamchatsk Staryy, Russia · depth 10 km
  - (2026-07-28) M 5.8 - 191 km NW of Oula Xiuma, China
      M5.8 · 191 km NW of Oula Xiuma, China · depth 10 km · PAGER yellow
  - (2026-07-28) M 5.7 - 192 km NW of Oula Xiuma, China
      M5.7 · 192 km NW of Oula Xiuma, China · depth 10 km · PAGER yellow
  - (2026-07-28) M 5.6 - 16 km NE of Tsunagi, Japan
      M5.6 · 16 km NE of Tsunagi, Japan · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-28) Samsun: Takuya Kumasaka vs Florent Bax
      yes price: 0% · 24h volume: $1,330,511 · resolves 2026-08-03
  - (2026-07-28) Liberec: Martin Krumich vs Philip Henning
      yes price: 100% · 24h volume: $822,965 · resolves 2026-08-03
  - (2026-07-28) LoL: DN SOOPers vs HANJIN BRION - Game 1 Winner
      yes price: 0% · 24h volume: $699,366 · resolves 2026-07-28
  - (2026-07-28) Targu Mures: Mia Ristic vs Darja Semenistaja
      yes price: 100% · 24h volume: $572,318 · resolves 2026-08-04
  - (2026-07-28) Bonn: Olle Wallin vs Lorenzo Giustino
      yes price: 82% · 24h volume: $535,275 · resolves 2026-08-04
  - (2026-07-28) Targu Mures: Yelyzaveta Kotliar vs Dalila Spiteri
      yes price: 100% · 24h volume: $490,393 · resolves 2026-08-04

### GDACS — global disaster alerts — 12 new of 286 total
  - (2026-07-28) [Orange] Earthquake in China
      Earthquake · Orange alert · China · Magnitude 5.7M, Depth:10km
  - (2026-07-28) [Orange] Earthquake in China
      Earthquake · Orange alert · China · Magnitude 5.7M, Depth:10km
  - (2026-07-28) [Orange] Earthquake in China
      Earthquake · Orange alert · China · Magnitude 5.8M, Depth:10km
  - (2026-07-28) [Orange] Earthquake in China
      Earthquake · Orange alert · China · Magnitude 5.8M, Depth:10km
  - (2026-07-28) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.6M, Depth:10km
  - (2026-07-28) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.6M, Depth:10km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-28) [Japan] Pakistan Military Strikes in Afghanistan reach nearly 500 Civilian Deaths – Modern Tokyo Times
      moderntokyotimes.com · English
  - (2026-07-28) [Japan] Demonschool Nintendo Switch physical release on the way , pre - orders open
      nintendoeverything.com · English
  - (2026-07-28) [Japan] Sales Tax Holidays 2026 : Here All What You Need to Know
      cnet.com · English
  - (2026-07-28) [Japan] Chinese chip giant defies US pressure with 466 % debut surge
      japanherald.com · English
  - (2026-07-28) [Japan] Waymo may end Uber robotaxi alliance , FT reports
      japanherald.com · English
  - (2026-07-28) [Japan] USFJ grows in size to deepen U . S .- Japan coordination | The Asahi Shimbun : Breaking News , Japan News and Analysis
      asahi.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 117 total
  - (2026-07-28) [USASpending] $819,751,946 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-28) [USASpending] $677,433,934 → LEIDOS, INC.: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
      Agency: Department of Transportation. Description: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
  - (2026-07-28) [USASpending] $676,184,419 → HII MISSION TECHNOLOGIES CORP: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE
      Agency: General Services Administration. Description: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE ISR AND NEXTGEN TECHNOLOGY (LOGIX)
  - (2026-07-28) [USASpending] $650,555,645 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-07-28) [USASpending] $526,585,488 → PARSONS GOVERNMENT SERVICES INC.: BOLD VENTURE
      Agency: General Services Administration. Description: BOLD VENTURE

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-07-28) Connecticut Supreme Court: State v. Keaton
  - (2026-07-28) Connecticut Supreme Court: State v. Kim
  - (2026-07-24) Florida Supreme Court: James Aren Duckett v. State of Florida
  - (2026-07-23) Delaware Supreme Court: Tang v. State
  - (2026-07-23) U.S. Court of Appeals, 4th Cir.: Badar Suri v. Donald Trump

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 35 total
  - (2026-07-28) MOVER ▼ Bernard Arnault & family — $139.69B ($-1.74B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-28) MOVER ▼ Francoise Bettencourt Meyers & family — $92.58B ($-0.48B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-28) MOVER ▲ Mukesh Ambani — $85.97B (+$0.09B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-28) MOVER ▲ Gautam Adani — $84.20B (+$0.05B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-28) [Marginal Revolution] The Apples and Oranges Tribunal
      Suppose that apples sell for more than oranges and Parliament in it’s wisdom decides that, at last, apples and oranges must be compared. Not by shoppers — shoppers are biased, they merely reveal what they are willing to…
  - (2026-07-28) [Marginal Revolution] The AEA presidential election
      AEA is the American Economics Association, and a new president is needed, here is the candidate and likely winner: PINELOPI (PENNY) KOUJIANOU GOLDBERG, William Nordhaus Professor of Economics and Global Affairs, Yale Uni…
  - (2026-07-28) [Marginal Revolution] The Confucian fertility paradox
      Total fertility rates in East Asia have fallen to levels without historical precedent, even though the region’s Confucian heritage long placed extraordinary emphasis on family continuity and large families. We argue that…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=17, 14d-median=17; carrying terms: national, council, amending, certain, prompted, coast, airspace, proposes, published, august, limited, requires
- state_bills: today=0, 7d-median=66, 14d-median=66
- state_news: today=493, 7d-median=493, 14d-median=493; carrying terms: advance, approach, trail, successful, council, given, brown, senate, check, chief, tennessee, southeast
- local_news: today=228, 7d-median=229, 14d-median=229; carrying terms: jackson, cbmiuafbvv, going, public, async, watch, restaurant, traffic, since, beach, blank, cbmirgfbvv
- foreign_news: today=980, 7d-median=1007, 14d-median=1007; carrying terms: australia, senate, plays, accuses, continued, along, reporting, decision, proposal, index, views, going
- chinese_internal: today=276, 7d-median=276, 14d-median=276; carrying terms: blank, cbmidefvx, cbmiykfvx, market, mainland, people, https, caixin, markets, cbmickfvx, cbmib, articles
- russian_internal: today=1001, 7d-median=879, 14d-median=879; carrying terms: street, istories, novaya, error, europe, fonbet, media, russian, research, raquo, reuters, axios
- ukrainian_internal: today=114, 7d-median=137, 14d-median=137; carrying terms: facility, council, important, british, continued, cargo, public, threatens, marking, giants, leader, international
- ukraine_theater: today=530, 7d-median=586, 14d-median=586; carrying terms: counter, otrtrfjkx, qqvvqdlu, ynldfzvvwqzftu, bwlrru, wnmntdkn, zlewhfcmlua, chief, mxetvzrhbmumxpedm, ouuvjthbeqmlzvjj, rqrvp, ltgdca
- paper_bets: today=134, 7d-median=138, 14d-median=138; carrying terms: election, senate, fuentes, texas, tennessee, jackson, washington, fifty, florida, court, become, hampshire
- weather: today=171, 7d-median=175, 14d-median=175; carrying terms: early, across, details, mainly, texas, louis, southeast, drainage, along, washington, heavy, warned
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: recession, jtsjol, spread, pcepilfe, vixcls, cpilfesl, cpiaucsl, headline, walcl, payems, commodities, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, credit, china, russell, bitcoin, commodities, natural, yield, crypto, agriculture, rates, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=117, 7d-median=119, 14d-median=119; carrying terms: counter, tdjwtmlezvlorq, council, taliban, ujgxrwtvbs, occupation, manufacturers, proliferation, certain, relation, february, sectoral
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, error, unauthorized, client, quiverquant, https, quiver, quantitative, congresstrading
- billionaires: today=35, 7d-median=34, 14d-median=34; carrying terms: telecom, sergey, mukesh, france, paris, devasini, china, ambani, fashion, arnault, bettencourt, cryptocurrency
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: medical, court, douglas, trade, ahmed, international, delaware, robert, appeals, school, holdings, services
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: trone, cycle, angels, elect, booker, colorado, brown, senate, sherrod, cortez, james, alexandria
- gdelt_regions: today=6, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=0, 7d-median=47, 14d-median=47; carrying terms: english, hezbollah, israel, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=18, 14d-median=18
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: national, epidemiological, director, several, polio, rajshahi, bivalent, early, across, given, rabies, ventilation
- cisa_kev: today=17, 7d-median=16, 14d-median=16; carrying terms: function, critical, access, authentication, vulnerability, business, missing, mechanism, vendor, lockout, insufficient, forgery
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=286, 7d-median=257, 14d-median=257; carrying terms: ecuador, australia, france, speed, philippines, croatia, minor, costa, liechtenstein, bulgaria, depth, orange
- usgs_quakes: today=23, 7d-median=23, 14d-median=23; carrying terms: islands, region, depth, atlantic, south, philippines, indonesia, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, price, rates, prime, meeting, volume, resolves, interest, ethiopia, change, increase, adanech
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, revolution, benefit, economist, conversable, marginalrevolution, https, marginal, quality, looking
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: engineers, something, models, usual, going, source, amazing, exposed, technica, stories, network, hackers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: reserve, cantwell, frederica, council, hinson, brown, chief, cammack, richmond, simon, cortez, aaron
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, paper, consensus, either, sufficient, today, placed, module, claude, market, placement, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*