# WORLDSCOPE morning brief — 2026-07-28

## Headline
2300 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (543) · Russian Internal News (state + in-exile) (508) · World leaders & government officials (324) · Chinese Internal News (183) · Ukraine Theater (total-war monitoring) (163) · U.S. Weather + Severe / Climate Outlooks (161) · Local News: St. Louis + Atlanta (74) · State-Level News (57) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (39) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 543 new of 974 total
  - (2026-07-28) [Global] Schools to offer technical subjects to pupils from age 14 in England, Burnham says
      The government wants pupils to take courses like AI and manufacturing which are linked to local jobs.
  - (2026-07-28) [Global] The way you look can help you get a job - here's how
      While you need to answer the questions in an interview, your appearance and mannerisms are also crucial.
  - (2026-07-28) [Global] Is it safe to travel to France and Spain right now?
      For those who have upcoming holidays to the affected regions, here is what you should know about how it might impact your plans.
  - (2026-07-28) [Global] Johnson & Johnson offers up to $5.5bn to settle baby powder lawsuits
      The proposed settlement aims to close a years-long legal battle over claims its talcs products cause cancer.
  - (2026-07-28) [Global] Chip stocks slide in US and Asia as AI jitters rattle investors
      Trading on South Korea's Kospi index was paused temporarily on Tuesday morning after slumping by 8%.
  - (2026-07-28) [Global] Some people's chats with Claude AI found to be publicly available online
      Hundreds of conversations with Anthropic’s chatbot were discovered as being publicly accessible.

### Russian Internal News (state + in-exile) — 508 new of 955 total
  - (2026-07-28) В метро Барселоны произошел пожар. Пострадали около 140 человек | LEDE: 136 человек пострадали в результате пожара на контактной линии первой ветки метро Барселоны (L1), сообщает каталонское] (ru: В м…
      136 человек пострадали в результате пожара на контактной линии первой ветки метро Барселоны (L1), сообщает каталонское издание Ara.
  - (2026-07-28) Зинедин Зидан стал главным тренером сборной Франции по футболу | LEDE: Новым главным тренером сборной Франции по футболу назначен Зинедин Зидан. Об этом говорится в сообщении национальной ко] (ru: Зин…
      Новым главным тренером сборной Франции по футболу назначен Зинедин Зидан. Об этом говорится в сообщении национальной команды.
  - (2026-07-28) «Верстка»: в Армении вырос спрос на квартиры со стороны россиян | LEDE: Россияне стали чаще искать квартиры в Армении, а цены на рынке аренды в Ереване выросли, пишет «Верстка», ссылаясь на ] (ru: «Ве…
      Россияне стали чаще искать квартиры в Армении, а цены на рынке аренды в Ереване выросли, пишет «Верстка», ссылаясь на местных риелторов.
  - (2026-07-28) Бастрыкин предложил считать использование ИИ при совершении преступлений отягчающим обстоятельством | LEDE: Глава Следственного комитета России Александр Бастрыкин предложил считать использо] (ru: Бас…
      Глава Следственного комитета России Александр Бастрыкин предложил считать использование искусственного интеллекта при совершении преступлений отягчающим обстоятельством. По его словам, сотрудники ведомства уже подготовил…
  - (2026-07-28) «Если вы сейчас не вмешаетесь, то ситуация станет патовой». Продавец с Wildberries (с 1,3М в инстаграме) обратилась к властям после ударов ВСУ | LEDE: Предпринимательница, основательница бре] (ru: «Ес…
      Предпринимательница, основательница бренда косметики Марина Горшкова (1,3 миллиона подписчиков в инстаграме) записала видео, в котором обратилась к руководству России из-за последствий украинских атак на склады Wildberri…
  - (2026-07-28) Омская область стала первым регионом России, где сняли лимиты на продажу топлива | LEDE: В Омской области с 28 июля отменены лимиты на продажу топлива, объявил губернатор Виталий Хоценко. «7] (ru: Омс…
      В Омской области с 28 июля отменены лимиты на продажу топлива, объявил губернатор Виталий Хоценко. «7×7» отмечает, что это первый регион России, где отменили подобные ограничения.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 183 new of 266 total
  - (2026-07-27) In Profile: Wall Street’s Go-To Regulator in China Swept Up in Anti-Graft Dragnet - Caixin Global
      In Profile: Wall Street’s Go-To Regulator in China Swept Up in Anti-Graft Dragnet Caixin Global
  - (2026-07-28) 今日开盘：两市双双低开 沪指跌幅0.91% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5HVzZjczdURmpTMXhIdjAwVWc4azZDbVhIVmROOVJIR0VRSEtwR0RWZHlDS3kwTEFJcnJqTEFqWHgwbTUtMXZVSmlFQlBRMm9K] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.91% 财新
  - (2026-07-28) 南华大学55岁校长夏昆任上被查 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9YZmpza0pqaFZ4a2dCM0RROUZqQ2xsUkxMRGVFQkFORDJiRllGc0NzZFRFQ0ItY1d2SzhpdTE4dkZid190RnJrc1hH] (zh:…
      南华大学55岁校长夏昆任上被查 china.caixin.com
  - (2026-07-28) 人事观察｜新疆新常委李刚兼任组织部长 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE4tU0ROdXZFUjBGb3REeEdCTE1XeTJIWmtpZVBIWW1OMmIydl84THZRVkZPV3Z0WmduRHd5TEZnSzhadUJiMDVJY] (zh:…
      人事观察｜新疆新常委李刚兼任组织部长 china.caixin.com
  - (2026-07-28) 银行老将贺劲松调任中信AMC党委书记 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBXY25udE5ZakxUZE42cXhGQ3N4MWVfRnF4Tnh1dG9EaVhoczhjcEpLX0s1V1VOX2dxT3NOdWwyUzY3aGUxZmtEU3BJejNYVzJ6eXY] (zh:…
      银行老将贺劲松调任中信AMC党委书记 财新
  - (2026-07-28) 含糖饮料不好卖，抹茶成新宠？｜饮食 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE53T0djUTY0SlVJNE1RZmZLOHRDalFkLVVTQ1ZpOHoycFVvbW1ndEhWYUN1d0NVemlVdEloWVM4d2dqV2xoT0tLY2hoRTd6Z3VBMU94] (zh:…
      含糖饮料不好卖，抹茶成新宠？｜饮食 财新

### Ukraine Theater (total-war monitoring) — 163 new of 530 total
  - (2026-07-28) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-26) [Liveuamap] Israeli forces raid the town of Deir Samet near Hebron in the West Bank and fire tear gas canisters. - Liveuamap
      Israeli forces raid the town of Deir Samet near Hebron in the West Bank and fire tear gas canisters.<
  - (2026-07-27) [Liveuamap] 5 people killed, as result of drone strike in Rostov region, - according to local authorities - Liveuamap
      5 people killed, as result of drone strike in Rostov region, - according to local authorities <font color="#
  - (2026-06-26) [Liveuamap] Two civilians were killed and others injured in a drone attack targeting a gas station in Rabak, White Nile State. Drones continued their raids on El Obeid, North Kordofan. - Liveuamap
      Two civilians were killed and others injured in a drone attack targeting a gas station in Rabak, White Nile State. Dron
  - (2026-07-24) [Liveuamap] Palestinians inspect the damage to a building following an Israeli airstrike last night that targeted Al-Jalaa Street in the center of Gaza City. - Liveuamap
      Palestinians inspect the damage to a building following an Israeli airstrike last night that targeted Al-
  - (2026-07-26) [Liveuamap] The Saudi Ministry of Defense says it was attacked earlier today by drones fired by Iraqi militias, aimed at oil facilities. The Ministry of Defense spokesperson, Major General Turki al-Ma…
      The Saudi Ministry of Defense says it was attacked earlier today by drones fired by Iraqi militias, aimed at oil fac

### U.S. Weather + Severe / Climate Outlooks — 161 new of 172 total
  - (2026-07-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-28) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 28 at 2:42AM MST until July 28 at 3:00AM MST by NWS Tucson AZ
      At 242 AM MST, a severe thunderstorm was located 11 miles west of Three Points, moving northwest at 25 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hail damage to vehicles is…
  - (2026-07-28) [Severe] Special Marine Warning: Special Marine Warning issued July 28 at 5:37AM EDT until July 28 at 7:00AM EDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Coastal Waters from Mexico Beach to Apalachicola out 20 NM... Coastal waters from Okaloosa-Walton County Line to Mexico Beac…
  - (2026-07-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 28 at 5:06AM EDT until July 28 at 11:00AM EDT by NWS Marquette MI
      * WHAT...Visibility 1/4 mile or less in dense fog. * WHERE...Gogebic and Ontonagon Counties. * WHEN...Until 11 AM EDT /10 AM CDT/ this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-07-28) [Moderate] Gale Warning: Gale Warning issued July 28 at 2:05AM PDT until July 29 at 3:00PM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 15 to 25 kt with gusts up to 35 kt. * WHERE...Coastal Waters from Point Pinos to Point Piedras Blancas California out to 10 NM. * WHEN...Until 3 PM PDT Wednesday. * IMPACTS...Strong winds will ca…
  - (2026-07-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 28 at 3:58AM CDT until July 28 at 10:00AM CDT by NWS Duluth MN
      * WHAT...Visibility one quarter to one half mile in dense fog. * WHERE...In Minnesota, Carlton, St. Louis, North Cook and Lake Counties. In Wisconsin, Ashland, Bayfield, Douglas, and Iron Counties. This includes the Trib…

### Local News: St. Louis + Atlanta — 74 new of 215 total
  - (2026-07-28) [St. Louis] Where Art Thou? – 7/28/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-07-28) [Atlanta] 3 people killed at Seattle Center identified; victims honored in candlelight vigil
      The King County Medical Examiner released the names of the 44-year-old man, the 19-year-old man and the 56-year-old woman who died in Sunday's shooting.
  - (2026-07-28) [Atlanta] 'I hear you need a kidney': Fan saves life of longtime Ohio sports announcer with paired donation
      The longtime Toledo, Ohio, sports announcer will receive a kidney July 29 through a paired donation set in motion by a fan he had never met.
  - (2026-07-28) [Atlanta] Prescription drug recall: Papaverine injection possibly contaminated with glass and other matter
      American Regent recalled a batch of Papaverine Hydrochloride Injection medication after finding glass and other matter in vials.
  - (2026-07-28) [Atlanta] $633M Powerball: Winning numbers for Monday, July 27, 2026
      The Powerball jackpot increased to $633 million Monday with a $277.3 million lump sum cash option.
  - (2026-07-28) [Atlanta] 1 hurt in shooting involving Athens-Clarke County Police; GBI investigating
      The police department said there is an active and ongoing investigation underway. No officers were injured.

### State-Level News — 57 new of 454 total
  - (2026-07-28) [California] ‘Pretty sure he’s wet:’ Immigration agents used racial slurs during LA sweeps, court records show
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/062025-Bell-Immigration-Raid-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…
  - (2026-07-28) [California] California pension ruling limits how many vacation hours workers can count for retirement
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/07/050824-Supreme-Court-JF-AP-CM-25.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-28) [Connecticut] CT hospitals are redesigning ERs for behavioral health crises
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/YALE-KID-CRISIS-CENTER-0721-0721-SG-11-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" dec…
  - (2026-07-28) [Connecticut] CT’s hypocrisy about election integrity
      <img width="886" height="461" src="https://ctmirror.org/wp-content/uploads/2026/07/Bridgeport-ballot-box-stuffing.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="…
  - (2026-07-27) [Colorado] Fifty for 150: Colorado State Fair incorporated in Pueblo in 1886
      The Southern Colorado Agricultural and Industrial Association, after holding multiple fairs in Pueblo County since the 1870s, incorporated as the State Fair Association on Nov. 17, 1886. That established Pueblo as the ho…
  - (2026-07-28) [Georgia] Advocates puzzled after HIV is left off of Georgia’s ‘medically frail’ list for Medicaid work rules
      Low-income Georgians living with HIV would not be counted as “medically frail” under a state proposal still under consideration and would therefore have to satisfy work requirements to qualify for Medicaid coverage. As o…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-28) [White Lion Capital LLC] Form 4 (Reporting)
      filed 2026-07-28 01:58 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001193125-26-318582 Size: 9 KB
  - (2026-07-28) [ACTELIS NETWORKS INC] Form 4 (Issuer)
      filed 2026-07-28 01:58 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001193125-26-318582 Size: 9 KB
  - (2026-07-28) [Sharplink, Inc.] Form 4 (Issuer)
      filed 2026-07-28 01:52 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001493152-26-034910 Size: 5 KB
  - (2026-07-28) [MCKENZIE OBIE] Form 4 (Reporting)
      filed 2026-07-28 01:52 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001493152-26-034910 Size: 5 KB
  - (2026-07-28) [Chalom Joseph] Form 4 (Reporting)
      filed 2026-07-28 01:52 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001493152-26-034909 Size: 5 KB
  - (2026-07-28) [Sharplink, Inc.] Form 4 (Issuer)
      filed 2026-07-28 01:52 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001493152-26-034909 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-28) [India] Welcomed him as if he were a superstar : Priyanka Gandhi slams BJP MPs for felicitating Pradhan
      domain: economictimes.indiatimes.com · language: English · tone:
  - (2026-07-28) [Bermuda] Hamilton looks back on top achievements of 2025
      domain: royalgazette.com · language: English · tone:
  - (2026-07-28) [Australia] Dishonesty claim in second act of Rebel libel saga
      domain: theadvocate.com.au · language: English · tone:
  - (2026-07-28) [United States] Research Reveals Sleep Crisis in Workers Over 50
      domain: miragenews.com · language: English · tone:
  - (2026-07-28) [United Kingdom] 150 , 000 warned over DWP letter as benefits change restarts under Andy Burnham
      domain: plymouthherald.co.uk · language: English · tone:
  - (2026-07-28) [Pakistan] US Confirms Rome Talks as Israel Prepares Lebanon Pullback
      domain: pakobserver.net · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 39 new of 108 total
  - (2026-07-28) Трамп виголосить промову на похороні сенатора Грема | LEDE: Похорон Ліндсі Грема 28 липня у Вашингтоні: Трамп, Зеленський, лідери іноземних держав, промови та церемонії.] (uk: Трамп виголосить промову…
      Похорон Ліндсі Грема 28 липня у Вашингтоні: Трамп, Зеленський, лідери іноземних держав, промови та церемонії.
  - (2026-07-28) Блогерка Лумер: Американцям не слід більше проводити переговори щодо війни в Україні в Москві | LEDE: Американська ультраправа блогерка Лора Лумер заявила, що переговори щодо російсько-українсь] (uk:…
      Американська ультраправа блогерка Лора Лумер заявила, що переговори щодо російсько-української війни за участі представників США не варто надалі проводити в Москві.
  - (2026-07-28) Останні дні липня будуть теплими і майже без опадів | LEDE: В Україні до кінця липня прогнозують теплу погоду і майже без опадів, лише 29 липня можливі короткочасні дощі на сході.] (uk: Останні дні ли…
      В Україні до кінця липня прогнозують теплу погоду і майже без опадів, лише 29 липня можливі короткочасні дощі на сході.
  - (2026-07-28) WSJ розповіло, що Трамп почав захоплюватися Україною, її дронами і стійкістю Зеленського | LEDE: Останніми тижнями президент США Дональд Трамп почав висловлювати новий оптимізм щодо України та ] (uk:…
      Останніми тижнями президент США Дональд Трамп почав висловлювати новий оптимізм щодо України та президента Володимира Зеленського, пише The Wall Street Journal.
  - (2026-07-28) Окупанти обстріляли житлові квартали Херсона: загинув 61-річний чоловік | LEDE: Близько 4:30 російські війська з окупованого лівобережжя обстріляли житлові квартали Херсона. Унаслідок атаки заг] (uk:…
      Близько 4:30 російські війська з окупованого лівобережжя обстріляли житлові квартали Херсона. Унаслідок атаки загинув 61-річний місцевий житель.
  - (2026-07-28) "Покарали" до травм черепа: за підозрою в знущанні з побратимів затримали двох бійців "Скелі" | LEDE: Правоохоронці повідомили про підозру двом військовослужбовцям медичної роти полку "Скеля", ] (uk:…
      Правоохоронці повідомили про підозру двом військовослужбовцям медичної роти полку "Скеля", які, за даними слідства, побили та незаконно утримували двох побратимів на Кіровоградщині.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-28) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (48.2687, 2.0744) · alt: 5463m · 703km/h
  - (2026-07-28) JAF94H (Bulgaria)
      icao24: 4520aa · position: (48.1122, -0.4465) · alt: 10652m · 767km/h
  - (2026-07-28) GAF117 (Germany)
      icao24: 3ea556 · position: (52.118, 6.6737) · alt: 9745m · 648km/h
  - (2026-07-28) GAF870 (Germany)
      icao24: 3f97fd · position: (53.1089, 1.5229) · alt: 10980m · 754km/h
  - (2026-07-28) CFC2976 (Canada)
      icao24: c2b585 · position: (50.3474, 21.4771) · alt: 4739m · 645km/h
  - (2026-07-28) JAF3EM (Belgium)
      icao24: 44d1ba · position: (47.6028, 10.621) · alt: 11582m · 762km/h

### U.S. Federal Action — 21 new of 22 total
  - (2026-07-28) Actions by the United States in the Investigations Under Section 301 of the Trade Act of 1974 of the Acts, Policies, and Practices of 60 Economies Related to the Failure of Each Economy To Impose and…
  - (2026-07-28) Presidential Determination on the Proposed Agreement for Cooperation Between the Government of the United States of America and the Government of the Kingdom of Saudi Arabia Concerning Peaceful Uses o…
  - (2026-07-28) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-19- 14, which applied to certain The Boeing Company Model 777-200, 777- 200LR, 777-300ER, and 777F series airplanes. AD 2024-19-14 required repetitive inspections…
  - (2026-07-28) Federal Motor Vehicle Safety Standards; Modernization of FMVSS No. 135 To Accommodate ADS-Equipped Vehicles; Extension of Comment Period
      In response to a request from Varnum LLP (Varnum), NHTSA is announcing a 30-day extension of the public comment period for the notice of proposed rulemaking (NPRM) published on June 26, 2026 proposing to amend Federal Mo…
  - (2026-07-28) Civil Penalties Adjustment for 2026
      The National Endowment for the Arts (NEA) is notifying the public that its civil monetary penalty amounts will not increase for the 2026 calendar year. The NEA is generally required by statute to amend its regulations an…
  - (2026-07-28) Modification of Class E Airspace, Samaritan North Lincoln Hospital Heliport, Lincoln, OR
      This action proposes to modify Class E airspace extending upward from 700 feet above the surface at Samaritan North Lincoln Hospital Heliport, Lincoln, OR. This action would support the safety and management of instrumen…

### Paper Trading Scorecard — 16 new of 131 total
  - (2026-07-28) [Polymarket] Will Coalition Avenir Québec win the most seats in the 2026 Quebec general election?
      Parliamentary elections to elect all 125 seats of the National Assembly of Quebec are scheduled to take place in Quebec on October 5, 2026. This market will resolve to the political party that wins the greatest number of…
  - (2026-07-28) [Polymarket] Will Z.ai have the best Chinese AI model at the end of July 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank among primarily Chinese companies, based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table und…
  - (2026-07-28) [Kalshi] US real GDP growth in 2036?
      2036
  - (2026-07-28) [Kalshi] US real GDP growth in 2035?
      2035
  - (2026-07-28) [Kalshi] US real GDP growth in 2034?
      2034
  - (2026-07-28) [Kalshi] US real GDP growth in 2033?
      2033

### USGS earthquakes (M4.5+, past day) — 14 new of 24 total
  - (2026-07-28) M 6.8 - 5 km E of Uto, Japan
      M6.8 · 5 km E of Uto, Japan · depth 10 km · PAGER red
  - (2026-07-28) M 5.9 - 50 km WSW of Brisas Barra de Suchiate, Mexico
      M5.9 · 50 km WSW of Brisas Barra de Suchiate, Mexico · depth 35 km
  - (2026-07-28) M 5.8 - 160 km E of Ust’-Kamchatsk Staryy, Russia
      M5.8 · 160 km E of Ust’-Kamchatsk Staryy, Russia · depth 10 km
  - (2026-07-28) M 5.8 - 191 km NW of Oula Xiuma, China
      M5.8 · 191 km NW of Oula Xiuma, China · depth 10 km · PAGER yellow
  - (2026-07-28) M 5.7 - 192 km NW of Oula Xiuma, China
      M5.7 · 192 km NW of Oula Xiuma, China · depth 10 km · PAGER yellow
  - (2026-07-28) M 5.6 - 16 km NE of Tsunagi, Japan
      M5.6 · 16 km NE of Tsunagi, Japan · depth 10 km

### IT, InfoSys & cybersecurity news (last 7 days) — 14 new of 57 total
  - (2026-07-28) [BleepingComputer] Data breach at medical billing firm MCBS affects 1.26 million people
      Healthcare billing company Medical Computer Business Services (MCBS) has disclosed that a 2025 network breach exposed the sensitive information of more than 1.2 million people. [...]
  - (2026-07-28) [The Hacker News] Critical TeamCity Flaw Could Let Attackers Run OS Commands Without Logging In
      JetBrains is urging customers of on-premise versions of TeamCity to update to the latest version following the discovery of a critical security issue that could result in arbitrary code execution. The vulnerability, assi…
  - (2026-07-28) [The Hacker News] Researcher Says AI Helped Develop Linux Traffic-Control Race Into Root Exploit
      STAR Labs has published a Linux kernel exploit that turns an ordinary local user into root on the CentOS Stream 9 build it targeted. The flaw, tracked as CVE-2026-53264 (CVSS score: 7.8), is a use-after-free race in the…
  - (2026-07-28) [The Hacker News] Microsoft Says New Cybersecurity AI Model Helps MDASH Hit 95.95% at Half the Cost
      Microsoft has launched its first cybersecurity-specific model inside MDASH, its multi-model vulnerability identification and remediation harness. The company says MDASH, using MAI-Cyber-1-Flash and GPT-5.4, scored 95.95%…
  - (2026-07-28) [The Hacker News] Attackers Exploit Arista VeloCloud Orchestrator Command Injection Flaw
      A maximum-severity security flaw impacting on-premises versions of Arista VeloCloud Orchestrator (VCO) has come under active exploitation in the wild. The vulnerability, tracked as CVE-2026-16812 (CVSS score: 10.0), is a…
  - (2026-07-28) [The Register] Openreach nudges another 112 exchange areas toward full fiber
      Latest batch takes the copper sales restrictions to 1,572 locations and 15.4 million premises

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-28) [China] शी चिनफिंग ने राष्ट्रीय पुनरोत्थान में प्रवासी चीनियों की शक्ति एकत्र करने पर बल दिया
      hindi.cri.cn · English
  - (2026-07-28) [China] Vietnam New AI Law and Its Strategic Implications – The Diplomat
      thediplomat.com · English
  - (2026-07-28) [China] जापान में चीनी दूतावास ने कोडाई मुराता पर अभियोग के सम्बंध में जवाब दिया
      hindi.cri.cn · English
  - (2026-07-28) [China] चीन की एआई शासन योजना वैश्विक दक्षिण के लिए नए अवसर लेकर आई है : अंतरराष्ट्रीय मीडिया
      hindi.cri.cn · English
  - (2026-07-28) [China] GM Korea reaches wage agreement with union
      just-auto.com · English
  - (2026-07-28) [China] अमेरिका और अफ्रीका में चीन के प्रभाव को लेकर अमेरिका से आ रही चिंताओं के जवाब में चीनी विदेश मंत्रालय की प्रतिक्रिया
      hindi.cri.cn · English

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-28) Samsun: Takuya Kumasaka vs Florent Bax
      yes price: 10% · 24h volume: $635,434 · resolves 2026-08-03
  - (2026-07-28) Targu Mures: Mia Ristic vs Darja Semenistaja
      yes price: 100% · 24h volume: $549,938 · resolves 2026-08-04
  - (2026-07-28) Liberec: Martin Krumich vs Philip Henning
      yes price: 24% · 24h volume: $400,605 · resolves 2026-08-03
  - (2026-07-28) Strait of Hormuz traffic returns to normal by July 31?
      yes price: 0% · 24h volume: $344,171 · resolves 2026-07-31
  - (2026-07-28) LoL: Kiwoom DRX vs KT Rolster (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 88% · 24h volume: $327,005 · resolves 2026-07-28
  - (2026-07-28) Samsun: Ergi Kirkin vs Paul Inchauspe
      yes price: 0% · 24h volume: $323,221 · resolves 2026-08-03

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 38 total
  - (2026-07-28) MOVER ▲ Tadashi Yanai & family — $66.34B (+$1.86B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-28) MOVER ▼ Gautam Adani — $84.15B ($-1.42B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-28) MOVER ▼ Bernard Arnault & family — $141.42B ($-1.23B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-28) MOVER ▲ Francoise Bettencourt Meyers & family — $93.06B (+$1.16B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-28) MOVER ▼ Mukesh Ambani — $85.88B ($-0.78B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-28) MOVER ▲ Bill Gates — $106.31B (+$0.07B since yesterday)
      United States · Technology · source: Microsoft

### Court opinions of consequence (federal & state) — 6 new of 60 total
  - (2026-07-23) U.S. Court of Appeals, 4th Cir.: Badar Suri v. Donald Trump
  - (2026-07-23) U.S. Court of Appeals, 7th Cir.: Brad Passwater v. Tricia Pretorius
  - (2026-07-23) U.S. Court of Appeals, 7th Cir.: United States v. Larry Doss
  - (2026-07-23) U.S. Court of Appeals, 5th Cir.: United States v. Debrow
  - (2026-07-23) U.S. Court of Appeals, 5th Cir.: United States v. Murphy
  - (2026-07-23) Delaware Supreme Court: Tang v. State

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 116 total
  - (2026-07-28) [USASpending] $819,751,946 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-28) [USASpending] $677,433,934 → LEIDOS, INC.: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
      Agency: Department of Transportation. Description: ADVANCED TECHNOLOGIES AND OCEANIC PROCEDURES (ATOP)
  - (2026-07-28) [USASpending] $676,184,419 → HII MISSION TECHNOLOGIES CORP: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE
      Agency: General Services Administration. Description: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE ISR AND NEXTGEN TECHNOLOGY (LOGIX)
  - (2026-07-28) [USASpending] $650,555,645 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-07-28) [USASpending] $526,585,488 → PARSONS GOVERNMENT SERVICES INC.: BOLD VENTURE
      Agency: General Services Administration. Description: BOLD VENTURE

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-28) [Marginal Revolution] The AEA presidential election
      AEA is the American Economics Association, and a new president is needed, here is the candidate and likely winner: PINELOPI (PENNY) KOUJIANOU GOLDBERG, William Nordhaus Professor of Economics and Global Affairs, Yale Uni…
  - (2026-07-28) [Marginal Revolution] The Confucian fertility paradox
      Total fertility rates in East Asia have fallen to levels without historical precedent, even though the region’s Confucian heritage long placed extraordinary emphasis on family continuity and large families. We argue that…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=17, 14d-median=17; carrying terms: airplanes, directive, applicable, certain, published, limited, august, security, amending, national, commission, additional
- state_bills: today=0, 7d-median=66, 14d-median=66
- state_news: today=454, 7d-median=472, 14d-median=472; carrying terms: springs, homeland, fruit, tells, island, statewide, digital, confirmation, month, reporters, mission, appeared
- local_news: today=215, 7d-median=229, 14d-median=229; carrying terms: uploads, custody, heritage, month, appeared, srcset, project, saportareport, effort, fetchpriority, shows, afternoon
- foreign_news: today=974, 7d-median=1007, 14d-median=1007; carrying terms: mamdani, plateau, island, walked, digital, emmanuel, flights, month, broke, ankang, culture, reiterated
- chinese_internal: today=266, 7d-median=266, 14d-median=266; carrying terms: cbmickfvx, deepseek, mainland, google, cbmizefvx, cbmiw, market, shein, cbmidefvx, giant, blank, cbmibefvx
- russian_internal: today=955, 7d-median=879, 14d-median=879; carrying terms: wildberries, gazeta, guardian, europe, istories, laquo, error, axios, centcom, group, novaya, novayagazeta
- ukrainian_internal: today=108, 7d-median=137, 14d-median=137; carrying terms: institute, diplomacy, ballistic, hromadske, noted, incidents, crimea, right, commercial, dismissed, growing, season
- ukraine_theater: today=530, 7d-median=586, 14d-median=586; carrying terms: sfnyz, qtrolu, hyuzbxeuw, cuxnaeuytmzqmelqz, cbmir, rosomak, takeaways, libya, hoaerxuu, mission, cuxnm, bpamvqdutnoeo
- paper_bets: today=131, 7d-median=138, 14d-median=138; carrying terms: mamdani, senate, robot, place, chase, annual, cholowsky, pirates, texas, transferable, earthquake, depleted
- weather: today=172, 7d-median=175, 14d-median=175; carrying terms: possible, please, elevated, especially, located, return, county, afdphi, friday, eastern, portion, little
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, jtsjol, dexchus, cpilfesl, personal, jolts, cpiaucsl, vixcls, unemployment, recession, payrolls, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, commodities, close, rates, equities, silver, range, large, corporate, china, agriculture, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=116, 7d-median=119, 14d-median=119; carrying terms: contractor, homeland, greer, involvement, hamilton, institute, return, burundi, construction, certain, asked, libya
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, unauthorized, https, congresstrading, quiverquant, quiver, httperror, quantitative, error
- billionaires: today=38, 7d-median=34, 14d-median=34; carrying terms: ortega, gautam, berkshire, mukesh, walmart, adani, gcarsoa, china, tesla, tiktok, japan, tadashi
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: school, ahmed, robert, california, delaware, group, medical, supreme, appeals, court, douglas, international
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, colorado, platner, elect, receipts, pinkston, jonathan, cooper, johnson, krishnamoorthi, james, bureau
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, china
- gdelt_gkg: today=0, 7d-median=47, 14d-median=47; carrying terms: israel, english, hezbollah, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: english, language, australia, india, domain
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=18, 14d-median=18
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: inconclusive, recombination, bundibugyo, brands, round, unknown, andes, prevention, coronavirus, hospitalized, circulating, confirmation
- cisa_kev: today=17, 7d-median=16, 14d-median=16; carrying terms: management, lockout, overly, directory, association, protocol, remediation, insufficient, connection, suite, option, restrictive
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=179, 14d-median=179; carrying terms: australia, vietnam, flood, kenya, hungary, speed, philippines, kazakhstan, slovakia, bulgaria, honduras, brazil
- usgs_quakes: today=24, 7d-median=24, 14d-median=24; carrying terms: depth, atlantic, islands, region, south, ridge, philippines, indonesia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, interest, minister, price, meeting, rates, prime, ethiopia, volume, abiebie, decrease, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, class, marginal, benefit, economist, revolution, https, marginalrevolution, quality, working, looking
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: month, published, krebs, engineers, friday, million, policy, being, president, everything, request, government
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: marsha, valadao, rutherford, loudermilk, katherine, homeland, chellie, greer, reserve, alsobrooks, murkowski, peter
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, markets, identify, market, placement, today, sufficient, decision, claude, consensus, converges, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*