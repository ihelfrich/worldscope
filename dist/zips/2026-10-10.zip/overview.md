# WORLDSCOPE morning brief — 2026-10-10

## Headline
3136 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (755) · Russian Internal News (state + in-exile) (584) · World leaders & government officials (324) · State-Level News (240) · Chinese Internal News (220) · Local News: St. Louis + Atlanta (184) · U.S. Weather + Severe / Climate Outlooks (179) · GDACS — global disaster alerts (100) · Ukraine Theater (total-war monitoring) (77) · Ukrainian Internal News (national + local Kyiv) (72) · GDELT GKG — themes / entities / watch areas (68) · USGS earthquakes (M4.5+, past day) (55)

## What changed today
### International News + Multilateral Institutions — 755 new of 1018 total
  - (2026-10-10) [Global] Trump announces deal for Russian diesel as Zelensky calls it a gift to Putin
      Ukraine's president sharply criticised the move, calling it an "investment in war that must be ended, not prolonged".
  - (2026-10-09) [Global] Analysis: Trump's shock Russia deal highlights mounting pressure to curb fuel prices
      The US president hopes to ease his party's pain before next month's midterm elections, writes the BBC's North America correspondent.
  - (2026-10-09) [Global] Boots has a new owner: Three ways it could affect you
      The stalwart of Britain's High Street has been sold to a Canadian billionaire family. What will that mean for you?
  - (2026-10-09) [Global] Ex-Deutsche Bank trader jailed for rigging rates has conviction overturned
      The Court of Appeal quashes the conviction of Christian Bittar, a former Deutsche Bank trader jailed in 2018.
  - (2026-10-10) [Global] Trump announces deal for Russian diesel as Zelensky calls it a gift to Putin
      Ukraine's president sharply criticised the move, calling it an "investment in war that must be ended, not prolonged".
  - (2026-10-10) [Global] Money Box
      What age will you get your state pension?

### Russian Internal News (state + in-exile) — 584 new of 1061 total
  - (2026-10-10) Премьер Финляндии предложил полностью остановить выдачу россиянам туристических виз в Европу | LEDE: Премьер-министр Финляндии Петтери Орпо заявил, что для укрепления безопасности Европы нео] (ru: Пре…
      Премьер-министр Финляндии Петтери Орпо заявил, что для укрепления безопасности Европы необходимо полностью прекратить выдачу туристических виз россиянам. Он планирует выступить с соответствующим предложением на саммите Е…
  - (2026-10-10) В Москве по делу о взятке задержали начальника управления лесного хозяйства Минобороны | LEDE: В Москве задержали начальника управления лесного хозяйства и природопользования Минобороны Серг] (ru: В М…
      В Москве задержали начальника управления лесного хозяйства и природопользования Минобороны Сергея Закаморного, его обвиняют в получении взятки в особо крупном размере (часть 6 статьи 290 УК РФ), сообщили источники РБК.
  - (2026-10-10) «Он предал Украину, наших европейских союзников и американскую национальную безопасность». Демократы и республиканцы критикуют Трампа за сделку с Путиным по дизелю, а эксперты сомневаются, что ] (ru:…
      Дональд Трамп и Владимир Путин договорились о смягчении санкций против России. США теперь будут импортировать российский дизель: 300 тысяч тонн, по словам Трампа, поступит в страну немедленно, еще 500 тысяч — в ноябре. Л…
  - (2026-10-10) «Я жива благодаря собакам». Как специально обученные животные спасают жизни своим хозяевам — при ПТСР, эпилепсии, мигрени и других проблемах со здоровьем | LEDE: Собаки-помощники обучены том] (ru: «Я…
      Собаки-помощники обучены тому, чтобы успокоить человека во время панической атаки, поднять упавший предмет, если хозяин не может наклониться, предупредить его о надвигающемся судорожном приступе или приступе мигрени (а п…
  - (2026-10-10) В Россию запретили ввозить грузинскую колу и минеральную воду «Набеглави» | LEDE: Роспотребнадзор запретил ввоз и продажу в России грузинского алкоголя и напитков нескольких производителей. ] (ru: В Р…
      Роспотребнадзор запретил ввоз и продажу в России грузинского алкоголя и напитков нескольких производителей. Об этом сообщил РБК, в распоряжении которого есть соответствующее распоряжение.
  - (2026-10-10) Ozon прекратит страхование товаров продавцов от атак беспилотников | LEDE: Российский маркетплейс Ozon объявил, что с 13 октября прекратит действие программа страхования «Ингосстраха» для пр] (ru: Ozo…
      Российский маркетплейс Ozon объявил, что с 13 октября прекратит действие программа страхования «Ингосстраха» для продавцов от массовых повреждений товаров и атак беспилотников.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 240 new of 667 total
  - (2026-10-09) [Alabama] Second Supplemental State of Emergency: Hurricane Isaias
      Download
  - (2026-10-10) [California] Gobernador Newsom a los californianos: Cuídense y conozcan sus derechos ante el aumento de actividades federales de inmigración
      Source
  - (2026-10-10) [California] Governor Newsom urges Californians to stay safe and know their rights amid increased federal immigration enforcement
      Source
  - (2026-10-10) [California] Governor Newsom announces appointments 10.9.2026
      Source
  - (2026-10-09) [California] Ahead of El Niño this winter, Governor Newsom prepares California for winter storms and flooding impacts
      Source
  - (2026-10-09) [California] California and France build on a decade of cooperation with new partnership to strengthen clean energy, protect communities, and grow economic opportunity
      Source

### Chinese Internal News — 220 new of 315 total
  - (2026-10-09) 在狂欢中沉没｜带着问题去读书 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9uMVZyNWpSNDByMzZpZXZSV1lPQXBsbTEzR0FkNW9VbWx3RGt4ZVhRRk5pTk9nUXBOeEUyblBQckd3ZlpPNGJJSjhxdElOTzN1WS1hS2R] (zh:…
      在狂欢中沉没｜带着问题去读书 财新
  - (2026-10-09) 财政部下达5500亿元地方债结存限额 支持县区财力和扩大有效投资 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1neHBWakw2ZjhSelVNMnVHT2FVckFocWJYZ0VhLUU3X0cwdE9qZ21vLXJwUU1vNUtjM2lHTmVqaU9pdlNucG0ze] (zh:…
      财政部下达5500亿元地方债结存限额 支持县区财力和扩大有效投资 财新
  - (2026-10-09) 央行酝酿征信数据库管理办法 对六种代理征信投诉行为不予受理 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBwbW9FWTdScXo2UTlBaVVXTVB0LXNVR3JZU3YyUDBUb1o5SDZIbGJwTFZXb2JnX1dxSm5vbVM2ODF4c0k1OFpnakh1] (zh:…
      央行酝酿征信数据库管理办法 对六种代理征信投诉行为不予受理 财新
  - (2026-10-09) 联合国前人权事务高级专员皮莱获诺贝尔和平奖 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9LYTlSTi0xandtZWFyLUZCbzdmOFRXRHpFRzJrYTNmbzFZaTU5T2YyOWg2TFJGb1ZCWWJKNndaWXFLbzIzTmpYY0xOMWFINWQt] (zh:…
      联合国前人权事务高级专员皮莱获诺贝尔和平奖 财新
  - (2026-10-09) WHO总干事谭德塞将卸任 中国提名卫健委妇幼健康司宋莉竞选 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1kbTNBT09FdmNBNl9FSG9pRDluTjVjWXctU1kwcW4waThwSFEtNEtyNFRBUC11bk4wNjBMbXZzVFZmWUhkUExidzRy] (zh:…
      WHO总干事谭德塞将卸任 中国提名卫健委妇幼健康司宋莉竞选 财新
  - (2026-10-09) 【CCI快报】中国大宗商品指数周涨1.86% 燃料油领涨13.71% - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1naWc2WDdUZDhTbEtkSnc2aV9lOC1QUXZyOU1nSW1zcVloZElNSkIwRTN4S2h4S3JYa2hPblkzajBiZkNmV] (zh:…
      【CCI快报】中国大宗商品指数周涨1.86% 燃料油领涨13.71% 财新数据

### Local News: St. Louis + Atlanta — 184 new of 239 total
  - (2026-10-09) [St. Louis] Want to intern at SLM? We’re looking for talented students to join our edit team
      Note: We are currently accepting applications for 2027. The Spring 2027 deadline is November 16, 2026. The Summer 2027 deadline is March 26, 2027. The Fall 2027 deadline is July 16, 2027. College students looking for int…
  - (2026-10-09) [St. Louis] Café Amalia champions local art with Julie Enstall’s ‘What Lies Beneath’
      Café Amalia, known for its authentic Mediterranean fare and detailed interior design, is combining art and hospitality by serving as the gallery space for St. Louis–based artist Julie Enstall’s first solo exhibition, Wha…
  - (2026-10-10) [St. Louis] Trump doles out billions to voters ahead of midterm elections
      Trump is sending $2.35 billion in direct payments to millions of Americans just weeks before the Nov. 3 elections. Here is a list of Trump's recent giveaways.
  - (2026-10-10) [St. Louis] Worthy: Blues off to a maddening start just four games into the season
  - (2026-10-10) [St. Louis] 3 things to watch for when Mizzou hosts Texas A&M
  - (2026-10-10) [St. Louis] 100 years after Cardinals' 1st World Series, quest for a Hornsby bat connects championships

### U.S. Weather + Severe / Climate Outlooks — 179 new of 185 total
  - (2026-10-10) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-10) [Severe] Special Marine Warning: Special Marine Warning issued October 10 at 8:26AM EDT until October 10 at 10:30AM EDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Apalachee Bay or Coastal Waters From Keaton Beach to Ochlockonee River Fl out to 20 Nm... Coastal Waters From Ochlockonee Ri…
  - (2026-10-10) [Severe] Special Marine Warning: Special Marine Warning issued October 10 at 8:23AM EDT until October 10 at 9:30AM EDT by NWS Wilmington NC
      SMWILM The National Weather Service in Wilmington has issued a * Special Marine Warning for... Waters from Little River Inlet SC to South Santee River SC from 20 to 60 NM... * Until 930 AM EDT. * At 823 AM EDT, a severe…
  - (2026-10-10) [Severe] Special Marine Warning: Special Marine Warning issued October 10 at 8:15AM EDT until October 10 at 9:45AM EDT by NWS Wilmington NC
      SMWILM The National Weather Service in Wilmington has issued a * Special Marine Warning for... Coastal waters from Murrells Inlet to South Santee River SC out 20 NM... * Until 945 AM EDT. * At 815 AM EDT, a severe thunde…
  - (2026-10-10) [Severe] Special Marine Warning: Special Marine Warning issued October 10 at 8:14AM EDT until October 10 at 8:45AM EDT by NWS Charleston SC
      For the following areas... Coastal waters from South Santee River to Edisto Beach SC out 20 NM... At 814 AM EDT, a severe thunderstorm capable of producing waterspouts was located 7 NM west of Cape Romain Reef, moving no…
  - (2026-10-10) [Severe] Special Marine Warning: Special Marine Warning issued October 10 at 8:13AM EDT until October 10 at 9:15AM EDT by NWS Charleston SC
      For the following areas... Waters from Savannah GA to Altamaha Sound GA out 60 NM... At 813 AM EDT, a severe thunderstorm capable of producing waterspouts was located 7 NM south of C C A Buoy, moving northeast at 25 knot…

### GDACS — global disaster alerts — 100 new of 100 total
  - (2026-10-07) [Red] Tropical Cyclone SIMON-26
      Tropical Cyclone · Red alert · Mexico · Hurricane/Typhoon > 74 mph (maximum wind speed of 250 km/h)
  - (2026-10-06) [Orange] Tropical Cyclone ISAIAS-26
      Tropical Cyclone · Orange alert · United States · Tropical Depression (maximum wind speed of 194 km/h)
  - (2026-10-10) [Green] Earthquake in Panama
      Earthquake · Green alert · Panama · Magnitude 4.8M, Depth:10km
  - (2026-10-10) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 4.6M, Depth:30.387km
  - (2026-09-27) [Green] Tropical Cyclone RACHEL-26
      Tropical Cyclone · Green alert · Mexico · Tropical Storm (maximum wind speed of 194 km/h)
  - (2026-10-10) [Green] Earthquake in Tonga
      Earthquake · Green alert · Tonga · Magnitude 4.5M, Depth:79.424km

### Ukraine Theater (total-war monitoring) — 77 new of 433 total
  - (2026-10-09) [FIRMS] thermal anomaly 50.807, 26.463 (FRP 2.12 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-09 1110Z, FRP 2.12 MW
  - (2026-10-09) [FIRMS] thermal anomaly 51.908, 34.242 (FRP 3.16 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-09 1110Z, FRP 3.16 MW
  - (2026-10-09) [FIRMS] thermal anomaly 52.065, 34.144 (FRP 3.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-09 1110Z, FRP 3.7 MW
  - (2026-10-09) [FIRMS] thermal anomaly 51.329, 26.963 (FRP 2.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-09 1110Z, FRP 2.04 MW
  - (2026-10-09) [FIRMS] thermal anomaly 51.851, 25.253 (FRP 5.48 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-09 1110Z, FRP 5.48 MW
  - (2026-10-10) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.

### Ukrainian Internal News (national + local Kyiv) — 72 new of 136 total
  - (2026-10-10) ЄС закликав США скасувати санкції проти Міжнародного кримінального суду | LEDE: ] (uk: ЄС закликав США скасувати санкції проти Міжнародного кримінального суду)
  - (2026-10-10) У Запоріжжі вже 17 загиблих. Жінку врятували з-під завалів після понад 8 годин пошуків | LEDE: Унаслідок авіаудару 10 жовтня по Запоріжжю загинули 11 людей, серед них троє дітей. Пошук зниклих ] (uk:…
      Унаслідок авіаудару 10 жовтня по Запоріжжю загинули 11 людей, серед них троє дітей. Пошук зниклих триває, у місті оголошено день жалоби.
  - (2026-10-10) Опитування: Більшість німців вважають візит Шредера до Путіна недоречним | LEDE: ] (uk: Опитування: Більшість німців вважають візит Шредера до Путіна недоречним)
  - (2026-10-10) Прем'єр Фінляндії: Слід припинити видачу туристичних віз росіянам до Європи | LEDE: Петтері Орпо ініціює заборону туристичних віз для громадян РФ, посилаючись на безпеку Європи та протидію загр] (uk:…
      Петтері Орпо ініціює заборону туристичних віз для громадян РФ, посилаючись на безпеку Європи та протидію загрозам з боку Росії.
  - (2026-10-10) У Києві зупинялося метро та виникали проблеми зі світлом і водою | LEDE: У Києві через зникнення напруги від зовнішніх живлячих центрів тимчасово зупинили рух поїздів метро та роботу ескалаторі] (uk:…
      У Києві через зникнення напруги від зовнішніх живлячих центрів тимчасово зупинили рух поїздів метро та роботу ескалаторів. Також у столиці виникли проблеми з електро- і водопостачанням.
  - (2026-10-10) Зеленський: Росія подякувала за зняття санкцій США бомбами по Запоріжжю | LEDE: Президент назвав домовленість про експорт дизпального причиною ударів РФ по Запоріжжю, які призвели до 12 жертв, ] (uk:…
      Президент назвав домовленість про експорт дизпального причиною ударів РФ по Запоріжжю, які призвели до 12 жертв, серед них троє дітей.

### GDELT GKG — themes / entities / watch areas — 68 new of 68 total
  - (2026-10-10) [Russia oil sanctions perimeter · keywords] Trump faces hypocrisy charge over Russian diesel deal after targeting India
      orissapost.com · English · tone NA
  - (2026-10-10) [Israel-Iran-Hezbollah axis · themes] 177 . 7 بالمائة ارتفاعا في صادرات السيارات الكهربائية من مدينة تشينغداو الصينية إلى مصر خلال يناير - أغسطس الماضيين
      arabic.news.cn · Arabic · tone NA
  - (2026-10-10) [Israel-Iran-Hezbollah axis · themes] Nur in einer intakten Umwelt können wir gut leben
      tlz.de · German · tone NA
  - (2026-10-10) [Israel-Iran-Hezbollah axis · themes] Thái Lan chặn bắt hơn 1 , 1 tấn ma túy đá trên đường tới Philippines
      baomoi.com · Vietnamese · tone NA
  - (2026-10-10) [Israel-Iran-Hezbollah axis · themes] Logistics : Keeping the Malacca Strait Safe
      strategypage.com · English · tone NA
  - (2026-10-10) [Israel-Iran-Hezbollah axis · themes] PMO honors NAZA , The True Story filmmakers for challenging allegations against
      jpost.com · English · tone NA

### USGS earthquakes (M4.5+, past day) — 55 new of 55 total
  - (2026-10-09) M 7.7 - 12 km WSW of Pitaloza Arriba, Panama
      M7.7 · 12 km WSW of Pitaloza Arriba, Panama · depth 12.647 km · PAGER red
  - (2026-10-09) M 6.6 - 14 km W of Río Grande, Panama
      M6.6 · 14 km W of Río Grande, Panama · depth 10 km · TSUNAMI · PAGER yellow
  - (2026-10-10) M 6.0 - 7 km N of La Tronosa, Panama
      M6.0 · 7 km N of La Tronosa, Panama · depth 10 km · PAGER yellow
  - (2026-10-09) M 5.9 - west of Macquarie Island
      M5.9 · west of Macquarie Island · depth 10 km
  - (2026-10-09) M 5.8 - 1 km S of El Cacao, Panama
      M5.8 · 1 km S of El Cacao, Panama · depth 10 km · PAGER yellow
  - (2026-10-09) M 5.5 - 3 km SW of Bajo Corral, Panama
      M5.5 · 3 km SW of Bajo Corral, Panama · depth 10 km

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-10) [FRIEDMAN BRIAN P] Form 4 (Reporting)
      filed 2026-10-10 01:56 UTC · role: Reporting — Filed: 2026-10-09 AccNo: 0001214659-26-012761 Size: 8 KB
  - (2026-10-10) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-10-10 01:56 UTC · role: Issuer — Filed: 2026-10-09 AccNo: 0001214659-26-012761 Size: 8 KB
  - (2026-10-10) [WRAP TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-10-10 01:30 UTC · role: Issuer — Filed: 2026-10-09 AccNo: 0001493152-26-046649 Size: 7 KB
  - (2026-10-10) [Cohen Scot] Form 4 (Reporting)
      filed 2026-10-10 01:30 UTC · role: Reporting — Filed: 2026-10-09 AccNo: 0001493152-26-046649 Size: 7 KB
  - (2026-10-10) [WRAP TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-10-10 01:30 UTC · role: Issuer — Filed: 2026-10-09 AccNo: 0001493152-26-046650 Size: 5 KB
  - (2026-10-10) [SHULMAN JOHN D] Form 4 (Reporting)
      filed 2026-10-10 01:30 UTC · role: Reporting — Filed: 2026-10-09 AccNo: 0001493152-26-046650 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-10-10) [United Kingdom] How To Moisturise Your Scalp , According To Experts
      domain: vogue.co.uk · language: English · tone:
  - (2026-10-10) [China] Logistics : Keeping the Malacca Strait Safe
      domain: strategypage.com · language: English · tone:
  - (2026-10-10) [Israel] PMO honors NAZA , The True Story filmmakers for challenging allegations against
      domain: jpost.com · language: English · tone:
  - (2026-10-10) [United States] DIVA DAILY DIRT : Diddy Pays Up , Drake Denies Baby Rumors
      domain: ipowerrichmond.com · language: English · tone:
  - (2026-10-10) [India] Who is Hitler Mussolini Simeón Flores ? Peruvian politician named after two infamous dictators wins election for centre - left Ahora Nación party
      domain: indiatimes.com · language: English · tone:
  - (2026-10-10) [India] Even Indira Gandhi didnt do this during Emergency : Dipke last post before CJP leader detention from Delhi flight
      domain: economictimes.indiatimes.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 61 total
  - (2026-10-10) [Krebs on Security] FBI Arrests Founder of Ransomware Negotiation Firm
      Agents with the Federal Bureau of Investigation (FBI) on Thursday arrested the co-founder of a Canadian cybersecurity firm in connection with an investigation into the ShinyHunters hacking group that recently relieved th…
  - (2026-10-10) [BleepingComputer] Criminal IP Introduces AITEM as the Next Evolution of Attack Surface Management
      Traditional attack surface management helps organizations discover exposed assets, but visibility alone is not enough to address threats. Criminal IP introduces AITEM, an AI-powered approach that connects exposure discov…
  - (2026-10-10) [The Hacker News] The Third-Party Agent Problem: Why Security Built for AI You Chose Misses the Agents You Didn't
      In environments studied for the 2026 State of Agent Security Report, roughly 1,280 third-party products now embed AI. About 282 of them sit behind single sign-on. The other thousand are invisible to identity infrastructu…
  - (2026-10-10) [The Hacker News] Anthropic Cuts Live Internet Access for Internal AI Tests After Claude Exploits Injection Flaws
      Anthropic on Friday said it's cutting off live internet access for all its internal evaluations following the discovery of new incidents in which its artificial intelligence (AI) models exhibited misaligned behavior and…
  - (2026-10-10) [The Register] Two characters open up a world of typosquatting opportunities in Chromium browsers
      Attackers abusing rare Cyrillic and Latin letters to impersonate popular websites
  - (2026-10-10) [The Register] EC users should be afraid of a US kill switch - not some new software
      EU executive branch is building a sovereign backup with Element, not replacing Teams. Not yet anyway

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 26 new of 26 total
  - (2026-10-13) Columbus Day, 2026
  - (2026-10-13) National Energy Dominance Month, 2026
  - (2026-10-13) Safety Zone; Brandon Road Lock and Dam to Lake Michigan Including Des Plaines River, Chicago Sanitary and Ship Canal, Chicago River, and Calumet-Saganashkee Channel, Chicago, IL
      The Coast Guard will enforce a safety zone on the South Branch of the Chicago River, between mile marker 325.4 and 325.5, for the assembly of the Lake Street Bridge for the Chicago Department of Transportation bridge rep…
  - (2026-10-13) Safety Zone; Brandon Road Lock and Dam to Lake Michigan Including Des Plaines River, Chicago Sanitary and Ship Canal, Chicago River, and Calumet-Saganashkee Channel, Chicago, IL
      The Coast Guard will enforce a moving safety zone on the South Branch of the Chicago River between the Lake Street Bridge at mile marker 325.5 and South Damen Avenue at mile marker 321 for the floating down of the bridge…
  - (2026-10-13) Safety Zone; Brandon Road Lock and Dam to Lake Michigan Including Des Plaines River, Chicago Sanitary and Ship Canal, Chicago River, and Calumet-Saganashkee Channel, Chicago, IL
      The Coast Guard will enforce a safety zone on the South Branch of the Chicago River between mile markers 325.5 and 325.4 for the demolition of the Lake Street Bridge for the Chicago Department of Transportation bridge re…
  - (2026-10-13) Petition for Reconsideration of Action in Rulemaking Proceeding
      Petition for Reconsideration (Petition) has been filed in the Commission's proceeding by Thomas Goode on behalf of the Alliance for Telecommunications Industry Solutions.

### Court opinions of consequence (federal & state) — 26 new of 60 total
  - (2026-10-09) Supreme Court of Alabama: OMS Pharmacy, Inc., d/b/a The Pharmacy at Midtown; and Hannah D. Browne v. Nationwide Property and Casualty Insurance Company; Baldo-Downs Insurance, LLC; and Roger Downs, In…
  - (2026-10-09) Supreme Court of Alabama: State of Alabama ex rel. Brook Lynn Dorgan and Justin Jude LeBlanc v. Thomas Hawley Tuberville, individually and in his capacity as the certified nominee of the Alabama Repub…
  - (2026-10-09) U.S. Court of Appeals, D.C. Cir.: United States v. James Trankle
  - (2026-10-09) U.S. Court of Appeals, 2nd Cir.: Wyse v. Metro. Com. Bank
  - (2026-10-09) U.S. Court of International Trade: Baroque Timber Indus. (Zhongshan) Co. v. United States
  - (2026-10-09) Alaska Supreme Court: Dash D. v. State of Alaska, Department of Family & Community Services, Office of Children's Services

### Government & military aircraft airborne (OpenSky) — 22 new of 22 total
  - (2026-10-10) JAF95J (Bulgaria)
      icao24: 4520aa · position: (36.051, -8.2985) · alt: 10668m · 919km/h
  - (2026-10-10) JAF55M (Belgium)
      icao24: 44d1ba · position: (44.734, -4.0286) · alt: 11277m · 907km/h
  - (2026-10-10) JAF38Y (Belgium)
      icao24: 44d1a6 · position: (40.1283, -6.6144) · alt: 10972m · 731km/h
  - (2026-10-10) JAF2VJ (Belgium)
      icao24: 44d1a5 · position: (47.9621, 10.3127) · alt: 11277m · 869km/h
  - (2026-10-10) JAF42N (Belgium)
      icao24: 44d1b4 · position: (46.4183, 13.6786) · alt: 11277m · 830km/h
  - (2026-10-10) JAF35D (Belgium)
      icao24: 44d1c2 · position: (41.6708, -8.6781) · alt: 11277m · 947km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 18 new of 113 total
  - (2026-10-09) [OFAC] Issuance of Russia-related General License - Office of Foreign Assets Control (.gov)
      Issuance of Russia-related General License Office of Foreign Assets Control (.gov)
  - (2026-10-09) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Pegasus Worldwide Logistics; International Criminal Court Designation and General License…
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Pegasus Worldwide Logistics; International Criminal Court Designation and General Licenses; Burma-related Designatio…
  - (2026-10-09) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 Ukraine-/Russia-Relat - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 Ukraine-/Russia-Relat Office of Foreign Assets Control (.gov)
  - (2026-10-09) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. Office of Foreign Assets Control (.gov)
  - (2026-10-09) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. Office of Foreign Assets Control (.gov)
  - (2026-10-09) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. Office of Foreign Assets Control (.gov)

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-10-10) Dota 2: Team Yandex vs Team Spirit - Game 2 Winner
      yes price: 98% · 24h volume: $1,246,836 · resolves 2026-10-10
  - (2026-10-10) Dota 2: Team Yandex vs Team Spirit (BO3) - BLAST Slam Playoffs
      yes price: 99% · 24h volume: $761,312 · resolves 2026-10-10
  - (2026-10-10) Valorant: G2 Esports vs Team Vitality (BO3) - VCT Champions Playoffs
      yes price: 34% · 24h volume: $715,423 · resolves 2026-10-10
  - (2026-10-10) Will Athletic Club win on 2026-10-10?
      yes price: 36% · 24h volume: $654,371 · resolves 2026-10-10
  - (2026-10-10) China Open: Qinwen Zheng vs Elise Mertens
      yes price: 98% · 24h volume: $567,088 · resolves 2026-10-17
  - (2026-10-10) Will Arsenal FC win on 2026-10-10?
      yes price: 55% · 24h volume: $465,531 · resolves 2026-10-10

### Paper Trading Scorecard — 12 new of 62 total
  - (2026-10-10) [Manifold] Chi vincerà il pallone d'oro???
  - (2026-10-10) [Manifold] Will my new YouTube channel (MyCoJo) receive 30,000 views by December 31, 2026? (12/31/26)
  - (2026-10-10) [Manifold] Will @jim's Lightcone Commons project be allocated funding in October 2026?
  - (2026-10-10) [Manifold] Will Russia deliver the promised 4.8 million tons of diesel?
  - (2026-10-10) [Manifold] Will 0x7A68AB21211e1338b1b019FFD65f69a0fcA8c6A4 RECEIVE more than 100.00 USDC Base by October 15th 11:59 pm UTC
  - (2026-10-10) [Manifold] Will Roger Marshall win the Kansas senate election by 11% or more?

### State Legislative Action — 5 new of 74 total
  - (2026-10-10) [Alaska SB 140] An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
      An Act relating to a matching grant program for fire station construction and renovation; and providing for an effective date.
  - (2026-10-10) [Alaska SJR 2] Proposing an amendment to the Constitution of the State of Alaska relating to actions upon veto.
      Proposing an amendment to the Constitution of the State of Alaska relating to actions upon veto.
  - (2026-10-10) [Alaska SB 23] An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
      An Act relating to civics education, civics assessments, and secondary school graduation requirements; and providing for an effective date.
  - (2026-10-09) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-10-09) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-10) [Marginal Revolution] Earth facts of the day
      Global call center headcount is 5.3% below its December 2023 peak, ending more than a decade of growth. It has fallen year over year for eight straight quarters, a decline that started in high-income countries and coinci…
  - (2026-10-10) [Marginal Revolution] California in-migration and out-migration
      Long-run U.S. population movements have been driven more by natural amenities than by jobs, and California, rich in both uniform and complementary climates, should be a persistent net gainer of domestic migrants. It has…
  - (2026-10-09) [Marginal Revolution] The origin of risk
      From the QJE, by Alexandr Kopytov, Mathieu Taschereau-Dumouchel, and Zebang Xu: We propose a tractable model in which risk, at both the micro and macro levels, is endogenous and driven by incentives. In the model, each f…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-10) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=26, 14d-median=24; carrying terms: certain, action, proposed, national, model, regulatory, safety, final, issuing, amending, management, state
- state_bills: today=74, 7d-median=111, 14d-median=94; carrying terms: project, board, licensure, programs, review, water, purposes, affordable, coverage, years, existing, medical
- state_news: today=667, 7d-median=667, 14d-median=682; carrying terms: rally, beach, water, worked, wisconsin, begins, secretary, medical, elections, clean, eight, inside
- local_news: today=239, 7d-median=233, 14d-median=229; carrying terms: leads, atlanta, state, content, report, children, against, residents, blank, decoding, north, investigation
- foreign_news: today=1018, 7d-median=1018, 14d-median=1018; carrying terms: looks, leads, ruled, turkey, universal, leave, longer, begins, secretary, crore, citizens, allegedly
- chinese_internal: today=315, 7d-median=255, 14d-median=266; carrying terms: cbmibkfvx, cbmiaefvx, https, cbmizkfvx, cbmic, cbmiw, color, articles, cbmia, investors, target, blank
- russian_internal: today=1061, 7d-median=1074, 14d-median=1052; carrying terms: times, https, httperror, financial, server, client, politico, russian, istories, gazeta, novaya, openai
- ukrainian_internal: today=136, 7d-median=136, 14d-median=132; carrying terms: facility, continue, campaign, scale, weapons, damaged, state, volodymyr, children, against, security, european
- ukraine_theater: today=433, 7d-median=584, 14d-median=572; carrying terms: chestnuts, cbmiwwfbvv, lnxayos, lymmzid, nddfrhzwtqdjvom, ltzhfuowgtvznrotlky, zylmxbgc, cjbsmhh, xrwfyous, rlnus, mxcwxrttfuuvzhee, lxtfaym
- paper_bets: today=62, 7d-median=128, 14d-median=122; carrying terms: speed, world, human, miles, majors, drought, fusion, anthropic, december, industrial, unemployment, evans
- weather: today=185, 7d-median=141, 14d-median=142; carrying terms: flood, afdlwx, beach, center, louis, changes, water, continue, significant, visibility, worth, highest
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: payrolls, balance, treasury, growth, inflation, total, unrate, rates, unemployment, implied, dcoilwtico, latest
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, silver, corporate, credit, china, large, range, bitcoin, treasury, rates, equities, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=113, 7d-median=113, 14d-median=114; carrying terms: human, federation, review, campaign, african, situation, destabilisation, protests, technology, measures, involvement, events
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quiverquant, quantitative, error, client, congresstrading, https, httperror, quiver
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, supreme, court, corporation, international, state, company, howard, board, county, brown, trade
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, financial, trust, holdings, group, robert, james, estate, natera
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, ossoff, alexandria, robert, elect, lindsey, michael, ocasio, congress, house, angels, cortez
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, china
- gdelt_gkg: today=68, 7d-median=49, 14d-median=37; carrying terms: english, themes, russian, spanish, chinese, russia, romanian, israel, sanctions, french, perimeter, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: israeli, medical, israel, domain, india, language, canada, against, kingdom, english, election, police
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, germany, ground, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: adult, human, pregnant, bengal, hospitalized, confined, country, rates, passengers, viruses, natural, fever
- cisa_kev: today=13, 7d-median=16, 14d-median=17; carrying terms: bounds, cisco, buffer, vulnerability, improper, traversal, multiple, injection, remediation, product, write, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100
- usgs_quakes: today=55, 7d-median=17, 14d-median=16; carrying terms: depth, islands, indonesia, south, russia, papua, guinea, kokopo, tadine, caledonia, tonga, petropavlovsk
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: donetsk, league, price, volume, champions, shakhtar, championship, resolves, october, winner, rates, presidential
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, class, conversableeconomist, marginal, economist, conversable, revolution, taxes, income, property, spending, eight
- tech_news: today=61, 7d-median=57, 14d-median=57; carrying terms: review, campaign, edition, years, technology, using, weekly, state, attacks, users, report, bleepingcomputer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: flood, crawford, ansari, paulina, williams, malliotakis, human, monica, louis, board, jacky, marilyn
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, evidence, module, markets, claude, converges, identify, unavailable, today, decision, consensus, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] ECB press: Philip R. Lane: Diagnostic Challenges for ECB Monetary Policy
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*