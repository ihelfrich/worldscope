# WORLDSCOPE morning brief — 2026-08-12

## Headline
3828 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (752) · Russian Internal News (state + in-exile) (737) · Ukraine Theater (total-war monitoring) (675) · State-Level News (334) · World leaders & government officials (324) · Chinese Internal News (210) · Local News: St. Louis + Atlanta (200) · U.S. Weather + Severe / Climate Outlooks (165) · Ukrainian Internal News (national + local Kyiv) (65) · Court opinions of consequence (federal & state) (41) · IT, InfoSys & cybersecurity news (last 7 days) (41) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 752 new of 1011 total
  - (2026-08-11) [Global] Rescuers scramble for survivors with 180 dead in Colombia earthquake
      Colombia experienced a number of aftershocks on Tuesday, as efforts continued to free survivors trapped in rubble and buildings.
  - (2026-08-12) [Global] Trump confirms he switched planes after Nato summit because of possible threat
      Journalists and White House staff who were on board the jet were unaware the president had left.
  - (2026-08-12) [Global] Trump's dramatic plane swap hints at personal stakes of Iran war
      It marks another striking episode in the turbulent history of his relationship with Iran, writes the BBC's Anthony Zurcher.
  - (2026-08-11) [Global] US says helicopter fired missiles to disable ship breaking Iran blockade
      US Central Command says its helicopter hit the engine room of a Panama-flagged cargo vessel in the Gulf of Oman.
  - (2026-08-12) [Global] Baby Shark boy set to make K-pop debut
      The boy from the most-watched YouTube video of all time is now 17 years old, and wants to be a K-pop star.
  - (2026-08-12) [Global] Cristiano Ronaldo marries long-time partner Georgina Rodríguez
      The couple have tied the knot after the Portuguese captain played his last ever World Cup this summer.

### Russian Internal News (state + in-exile) — 737 new of 1157 total
  - (2026-08-12) МЧС предупредило о дожде, грозе и ветре в Москве в среду | LEDE: ] (ru: МЧС предупредило о дожде, грозе и ветре в Москве в среду)
  - (2026-08-12) Росздравнадзор рассказал об импортозамещении в производстве инсулинов | LEDE: ] (ru: Росздравнадзор рассказал об импортозамещении в производстве инсулинов)
  - (2026-08-12) В Красноярском крае потушили пожар в ангаре с пиломатериалами | LEDE: ] (ru: В Красноярском крае потушили пожар в ангаре с пиломатериалами)
  - (2026-08-12) Симоньян предложила помощь семьям погибших от атак БПЛА на Кубани | LEDE: ] (ru: Симоньян предложила помощь семьям погибших от атак БПЛА на Кубани)
  - (2026-08-12) Москвичей предупредили о ливне с грозой в среду | LEDE: ] (ru: Москвичей предупредили о ливне с грозой в среду)
  - (2026-08-12) Сын пропавших Усольцевых опроверг сообщения об отъезде семьи в Калифорнию | LEDE: ] (ru: Сын пропавших Усольцевых опроверг сообщения об отъезде семьи в Калифорнию)

### Ukraine Theater (total-war monitoring) — 675 new of 780 total
  - (2026-08-11) [FIRMS] thermal anomaly 47.335, 34.971 (FRP 140.68 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-11 0934Z, FRP 140.68 MW
  - (2026-08-11) [FIRMS] thermal anomaly 47.331, 34.960 (FRP 77.43 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-11 0934Z, FRP 77.43 MW
  - (2026-08-11) [FIRMS] thermal anomaly 46.616, 32.746 (FRP 6.14 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-11 0934Z, FRP 6.14 MW
  - (2026-08-11) [FIRMS] thermal anomaly 46.431, 32.085 (FRP 5.23 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-11 0934Z, FRP 5.23 MW
  - (2026-08-11) [FIRMS] thermal anomaly 47.179, 34.277 (FRP 5.47 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-11 0934Z, FRP 5.47 MW
  - (2026-08-11) [FIRMS] thermal anomaly 47.050, 33.856 (FRP 5.6 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-11 0934Z, FRP 5.6 MW

### State-Level News — 334 new of 681 total
  - (2026-08-11) [California] First Partner Siebel Newsom, Governor Newsom, and #HalfTheStory launch California’s first Teen Tech Council
      Source
  - (2026-08-11) [California] Governor Newsom fast-tracks 1,700 new affordable housing units
  - (2026-08-11) [California] As 2026 continues notching heat records, Governor Newsom announces a strategic action plan to address extreme heat in California
      Source
  - (2026-08-11) [California] Governor Newsom’s mental health reform continues to deliver, announcing 15 new projects expanding care across the state
      Source
  - (2026-08-11) [Arkansas] Outside of Little Rock, Arkansas counties and cities move ahead on data center moratoriums
      Little Rock and Pulaski County haven’t paused approvals of data centers — despite months of trying — even as they’ve faced community pushback over two major facilities planned in the area. But across Arkansas, other citi…
  - (2026-08-11) [Arkansas] Arkansas lawmakers, NAACP seek accountability over state trooper punching 18-year-old
      The Arkansas Legislative Black Caucus and NAACP Arkansas State Conference are calling for answers about a traffic stop involving a state trooper punching an 18-year-old that has gained national attention. Rep. Jay Richar…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 210 new of 267 total
  - (2026-08-11) 高盛 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5mbFZ2MUFHMHBjR25WRWdSVU1RSmNZY2o0Wl9mMjdFSlpoMF9Kbm1Rc1V5YzdPc1VhdmFFakV3ZU1INkdNN1FWVXpnMkZZNTNnTW] (zh:…
      高盛 deepview.caixin.com
  - (2026-08-10) 数据图解 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE9QVWNaQnFCcTlNRUdGQUgtQU1iQlQ4dVpBQllkbE8wd2o3WkcxX3RHTHFyOEZMTnpNRFhZempxb3Atc2hjNnY1c1BPOXA5ZTh4] (zh:…
      数据图解 deepview.caixin.com
  - (2026-08-11) 哥伦比亚7.4级强震致至少132死570 伤已进入国家灾难状态 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5hV01RWlRGQUduaWl2aHVqZUdYUEFtcjdIdjlnYXdUWXVfT1lZRW0xT2x6MGd2VFY3aFVramZ6enRQS1praUNJaG] (zh:…
      哥伦比亚7.4级强震致至少132死570 伤已进入国家灾难状态 财新
  - (2026-08-12) 宇树上市，高管、核心员工获配超180万股 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE13ODBKUm9nNHJKYWItQzNsRHJPUUhhUk4zZVFYemhBV1NQSHR0dWhCRzhJMFFTZ0ZjSlhkRWpiaFA2VEJYMTNXVGVIbVZYNVlvc] (zh:…
      宇树上市，高管、核心员工获配超180万股 财新
  - (2026-08-12) 朱梅：一句“美女”带来的2.15亿美元巨额罚单 | 出海·专栏 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE8zR3c2T0ZJdmMybTVSV2Q0MFJBbGh5d05YN3pvZE80RUcxcUNzWUQ3ckNqZFBHLXZVUFR2RmVzZ1hWclRsUTNrbV] (zh:…
      朱梅：一句“美女”带来的2.15亿美元巨额罚单 | 出海·专栏 财新
  - (2026-08-12) 前七月法拍住宅成交增长逾四成 均价同比下降9% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE54M2I5OVFfZi1NZllHMy14NnlQdkczc1ZfU1QyYWgyN0t3MThiZHBMMmoxZDNuenl5R3pfMGw1b3hwb2djQkNpOER1ckdsRF] (zh:…
      前七月法拍住宅成交增长逾四成 均价同比下降9% 财新

### Local News: St. Louis + Atlanta — 200 new of 235 total
  - (2026-08-11) [St. Louis] Photos: St. Louis Family Playdate at Metro Theater Company
      On August 7, St. Louis Magazine hosted a Family Playdate at Metro Theater Company, presented by Royal Banks of Missouri and sponsored by Ryan Lawn & Tree. This Back-to-School Rave was the ultimate dance party for kiddos…
  - (2026-08-11) [St. Louis] Purina Farms turns 100: How St. Louis families can celebrate this season
      For generations of St. Louis families, a trip to Purina Farms has been a childhood rite of passage. It’s where kids have met farm animals for the first time, watched dogs leap through the air, and discovered just how exc…
  - (2026-08-11) [St. Louis] St. Louis Children’s Choirs find music and connection on Portugal tour
      For members of the St. Louis Children’s Choirs, a recent performance tour through Portugal was about much more than singing overseas. Over the course of a week, 37 students performed in a world-renowned concert hall, a n…
  - (2026-08-11) [St. Louis] Why Jefferson City deserves more than a day trip
      The Missouri State Capitol‘s dome has become Jefferson City’s calling card. It draws families, history buffs, school groups, and weekend travelers from across the Show-Me State and beyond. Many tour the Capitol, stop by…
  - (2026-08-11) [St. Louis] Trainwreck Saloon owners retiring, selling historic Rock Hill tavern
      The historic Trainwreck Saloon (9243 Manchester) is pulling into the station for a temporary stop. Longtime owners George and Kris Hansford are retiring after 44 years and selling the landmark tavern, which will temporar…
  - (2026-08-11) [St. Louis] As Marcel Hartel nears an exit, St. Louis CITY SC must adapt on the fly
      Marcel Hartel’s absence hung in the air as St. Louis CITY SC manager Yoann Damet coordinated training on Monday morning. While the transfer has not been officially announced, Hartel has arrived in Hanover, Germany, and,…

### U.S. Weather + Severe / Climate Outlooks — 165 new of 170 total
  - (2026-08-12) [Moderate] Special Weather Statement: Special Weather Statement issued August 12 at 3:13AM CDT by NWS Green Bay WI
      At 313 AM CDT, Doppler radar was tracking a strong thunderstorm 6 miles south of Pulaski, or 14 miles west of Green Bay, moving east at 20 mph. HAZARD...Wind gusts up to 40 mph and penny size hail. SOURCE...Radar indicat…
  - (2026-08-12) [Severe] Flood Watch: Flood Watch issued August 12 at 1:11AM MST until August 13 at 12:00AM MST by NWS Flagstaff AZ
      * WHAT...Elevated potential for Flash Flooding due to excessive rainfall. * WHERE...Yavapai County, Coconino County, Navajo County, Apache County and northern Gila County. * WHEN...From Noon MST Wednesday through Midnigh…
  - (2026-08-12) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-12) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 12 at 3:06AM CDT until August 12 at 3:30AM CDT by NWS Green Bay WI
      At 306 AM CDT, a severe thunderstorm was located over Pound, or 23 miles west of Marinette, moving east at 25 mph. HAZARD...Quarter size hail. SOURCE...Radar indicated. IMPACT...Damage to vehicles is expected. This sever…
  - (2026-08-12) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 12 at 3:05AM CDT until August 12 at 3:30AM CDT by NWS Hastings NE
      At 304 AM CDT, severe thunderstorms were located along a line extending from near Neligh to near Bartlett to near Fort Hartsuff State Park, moving southeast at 45 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated…
  - (2026-08-12) [Severe] Flash Flood Warning: Flash Flood Warning issued August 12 at 4:05AM EDT until August 12 at 7:00AM EDT by NWS Wilmington OH
      FFWILN The National Weather Service in Wilmington has issued a * Flash Flood Warning for... Southwestern Franklin County in southeastern Indiana... Ripley County in southeastern Indiana... * Until 700 AM EDT. * At 405 AM…

### Ukrainian Internal News (national + local Kyiv) — 65 new of 113 total
  - (2026-08-12) Зеленський: Дрони "Паляниця" і ракети "Нептун" відпрацювали по морській базі РФ в Новоросійську | LEDE: Україна завдала ударів дронами "Паляниця" і ракетами "Нептун" по російській військово-мор] (uk:…
      Україна завдала ударів дронами "Паляниця" і ракетами "Нептун" по російській військово-морській базі в Новоросійську.
  - (2026-08-12) Російські дрони атакували склади на Київщині: поранена одна людина | LEDE: У Броварському районі Київщини під час дронової атаки сталася пожежа на складах, поранено чоловіка.] (uk: Російські дрони ата…
      У Броварському районі Київщини під час дронової атаки сталася пожежа на складах, поранено чоловіка.
  - (2026-08-12) Дві третини поляків підтримують депортацію безробітних українських чоловіків | LEDE: В опитуванні IBRiS 67% поляків схвалили депортацію українців призовного віку без легальної роботи.] (uk: Дві третин…
      В опитуванні IBRiS 67% поляків схвалили депортацію українців призовного віку без легальної роботи.
  - (2026-08-12) ЗМІ: Венс просив Зеленського не бити по танкерах, які ходять через Новоросійськ | LEDE: Україна припинила інтенсивну кампанію ударів безпілотників по нафтових танкерах, що використовують важлив] (uk:…
      Україна припинила інтенсивну кампанію ударів безпілотників по нафтових танкерах, що використовують важливий чорноморський порт у Новоросійську, після прохання, висловленого наприкінці минулого місяця віцепрезидентом США…
  - (2026-08-12) Росіяни атакували Україну ракетами і 138 БпЛА: 112 дронів знешкодили, про ракети ПС не пишуть | LEDE: Росія атакувала Україну ракетами та дронами. ППО знешкодила 112 БпЛА, атака триває. Про рак] (uk:…
      Росія атакувала Україну ракетами та дронами. ППО знешкодила 112 БпЛА, атака триває. Про ракети ПС нічого не повідомили
  - (2026-08-12) ЄС виділить 2 млн євро на допомогу Колумбії після руйнівного землетрусу | LEDE: Євросоюз виділить 2 млн євро для надання допомоги Колумбії після руйнівного землетрусу 10 серпня.] (uk: ЄС виділить 2 мл…
      Євросоюз виділить 2 млн євро для надання допомоги Колумбії після руйнівного землетрусу 10 серпня.

### Court opinions of consequence (federal & state) — 41 new of 60 total
  - (2026-08-11) U.S. Court of International Trade: Mirror Metals, Inc. v. United States
  - (2026-08-11) U.S. Court of Appeals, 6th Cir.: Danielle Arthur v. Douglas Krause
  - (2026-08-11) U.S. Court of Appeals, 7th Cir.: United States v. Johntavis Matlock
  - (2026-08-11) U.S. Court of Appeals, Federal Cir.: Range of Motion Products, LLC v. Armaid Company Inc.
  - (2026-08-11) U.S. Court of Appeals, Federal Cir.: Fedmet Resources Corporation v. United States
  - (2026-08-11) U.S. Court of Appeals, Federal Cir.: Fusong Jinlong Wooden Group Co., Ltd. v. United States

### IT, InfoSys & cybersecurity news (last 7 days) — 41 new of 53 total
  - (2026-08-12) [BleepingComputer] Google says Chrome cuts 7 billion unwanted Android notifications a day to fight abuse
      Google says Chrome's anti-abuse systems reduced unwanted notifications on Android by more than 7 billion per day during the first quarter of 2026. [...]
  - (2026-08-12) [The Hacker News] SAP Commerce Cloud Flaw Could Let Unauthenticated Attackers Execute Arbitrary Code
      SAP has released patches to address a maximum-severity security flaw impacting Commerce Cloud (Data Hub Adapter) that could result in arbitrary code execution. The vulnerability, assigned the CVE identifier CVE-2026-5823…
  - (2026-08-12) [The Hacker News] ShieldBreak Zero-Day PoC Claims Microsoft Defender Patch Bypass With SYSTEM Access
      The security researcher going by the name Chaotic Eclipse (aka INFINITE NIGHTMARE, MSNightmare, and Nightmare-Eclipse) has released a proof-of-concept (PoC) for a new Microsoft zero-day called ShieldBreak. The vulnerabil…
  - (2026-08-12) [The Hacker News] Cisco ASA and FTD Flaw Exploited in the Wild Can Trigger Remote DoS
      Cisco has warned that a new vulnerability impacting Secure Firewall Adaptive Security Appliance (ASA) Software and Secure Firewall Threat Defense (FTD) Software has been exploited in the wild. The high-severity flaw, tra…
  - (2026-08-12) [Ars Technica] DEF CON crowd suspected in fake-hotspot attack on Delta flight
      FBI Atlanta confirms it's looking into the incident, no arrests made.
  - (2026-08-12) [Computer Weekly] Dubai ranks second globally in AI adoption as investment in digital infrastructure accelerates
      Dubai has been ranked second globally in the inaugural Intelligent Cities Index published by Boston Consulting Group (BCG), securing the top position worldwide for the adoption of artificial intelligence (AI) technologie…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-12) [Meyer John Tull] Form 4 (Reporting)
      filed 2026-08-12 01:52 UTC · role: Reporting — Filed: 2026-08-11 AccNo: 0001476150-26-000043 Size: 5 KB
  - (2026-08-12) [Terreno Realty Corp] Form 4 (Issuer)
      filed 2026-08-12 01:52 UTC · role: Issuer — Filed: 2026-08-11 AccNo: 0001476150-26-000043 Size: 5 KB
  - (2026-08-12) [Tian Jing] Form 4 (Reporting)
      filed 2026-08-12 01:49 UTC · role: Reporting — Filed: 2026-08-11 AccNo: 0001213900-26-087981 Size: 9 KB
  - (2026-08-12) [TIGO ENERGY, INC.] Form 4 (Issuer)
      filed 2026-08-12 01:49 UTC · role: Issuer — Filed: 2026-08-11 AccNo: 0001213900-26-087981 Size: 9 KB
  - (2026-08-12) [LandBridge Holdings LLC] Form 4 (Reporting)
      filed 2026-08-12 01:48 UTC · role: Reporting — Filed: 2026-08-11 AccNo: 0001193125-26-345454 Size: 26 KB
  - (2026-08-12) [Five Point Energy Fund II AIV-VII LP] Form 4 (Reporting)
      filed 2026-08-12 01:48 UTC · role: Reporting — Filed: 2026-08-11 AccNo: 0001193125-26-345454 Size: 26 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-12) [United Kingdom] Burnham pushing the system to try to stop early release of Pc Harper killers
      domain: cravenherald.co.uk · language: English · tone:
  - (2026-08-12) [Australia] Upper house shake - up looms as old voting system binned
      domain: nynganobserver.com.au · language: English · tone:
  - (2026-08-12) [India] Supreme Court to hear plea raising issue of disruption of essential services during protests
      domain: economictimes.indiatimes.com · language: English · tone:
  - (2026-08-12) [United States] Kosovo begins excavations at newly found mass graves tied to 1998 - 99 war missing
      domain: ksat.com · language: English · tone:
  - (2026-08-12) [United Kingdom] Burnham pushing the system to try to stop early release of Pc Harper killers
      domain: clactonandfrintongazette.co.uk · language: English · tone:
  - (2026-08-12) [United Kingdom] Samsung Galaxy Z Roll Release Date and More
      domain: geeky-gadgets.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-12) [Russia oil sanctions perimeter · themes] Ein chinesisches U - Boot tauchte 2006 unbemerkt 8 Kilometer vor der USS Kitty Hawk auf – 15 Jahre später verkaufte die Navy den Träger für einen Cent
      focus.de · German · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] Трамп предупредил Иран о последствиях новой эскалации
      world.comments.ua · Russian · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] FTSE 100 Live : Stocks to slide as Iran and US clash over Hormuz
      cityam.com · English · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] What we know about the death of Tasia Fortune in Mississippi
      broomfieldenterprise.com · English · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] DBH Muna 2026 Tembus Rp 31 , 99 Miliar , Penyalurannya Lampaui Rata - rata Nasional
      batam.tribunnews.com · Indonesian · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] Fonds européens : le GIPEAM peine à corriger les failles quil devait résoudre
      la1ere.franceinfo.fr · French · tone NA

### Government & military aircraft airborne (OpenSky) — 25 new of 28 total
  - (2026-08-12) GAF527 (Germany)
      icao24: 3dbc00 · position: (53.8597, 10.6294) · alt: 1082m · 273km/h
  - (2026-08-12) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (46.0042, -0.0075) · alt: 10789m · 864km/h
  - (2026-08-12) JAF3LC (Bulgaria)
      icao24: 4520aa · position: (43.6409, 7.7057) · alt: 9753m · 849km/h
  - (2026-08-12) GAF115 (Germany)
      icao24: 3ea653 · position: (53.9592, 12.1494) · alt: 990m · 390km/h
  - (2026-08-12) JEDI27 (France)
      icao24: 39a858 · position: (46.0861, 0.0075) · alt: 1813m · 218km/h
  - (2026-08-12) PUMA20 (Slovenia)
      icao24: 506e1f · position: (45.8663, 15.446) · alt: 1005m · 255km/h

### GDACS — global disaster alerts — 24 new of 315 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-07-06) [Green] Eruption Etna
      Volcano · Green alert · Italy
  - (2026-07-06) [Green] Eruption Etna
      Volcano · Green alert · Italy
  - (2026-07-06) [Green] Eruption Etna
      Volcano · Green alert · Italy

### USGS earthquakes (M4.5+, past day) — 17 new of 18 total
  - (2026-08-12) M 5.2 - 42 km ESE of Naalehu, Hawaii
      M5.2 · 42 km ESE of Naalehu, Hawaii · depth 10.73 km
  - (2026-08-12) M 5.1 - Pacific-Antarctic Ridge
      M5.1 · Pacific-Antarctic Ridge · depth 10 km
  - (2026-08-11) M 5.1 - 51 km E of Tobelo, Indonesia
      M5.1 · 51 km E of Tobelo, Indonesia · depth 10 km
  - (2026-08-12) M 5.0 - 66 km E of Chayek, Kyrgyzstan
      M5.0 · 66 km E of Chayek, Kyrgyzstan · depth 10 km
  - (2026-08-11) M 5.0 - 89 km ESE of Kokopo, Papua New Guinea
      M5.0 · 89 km ESE of Kokopo, Papua New Guinea · depth 68.887 km
  - (2026-08-11) M 5.0 - 107 km WNW of Kerema, Papua New Guinea
      M5.0 · 107 km WNW of Kerema, Papua New Guinea · depth 10 km

### U.S. Federal Action — 16 new of 29 total
  - (2026-08-12) Appellate Jurisdiction Update II
      The Merit Systems Protection Board (MSPB or Board) is amending its regulations to remove references to MSPB's jurisdiction over probationary termination, suitability, and reduction-in-force (RIF) appeals. This revision r…
  - (2026-08-12) Community Reinvestment Act Regulations
      The Office of the Comptroller of the Currency (OCC) and the Federal Deposit Insurance Corporation (FDIC) are proposing to amend their Community Reinvestment Act rules by making certain substantive, technical, and process…
  - (2026-08-12) Imposition of Import Restrictions on Categories of Archaeological and Ethnological Material of Nepal
      This document amends U.S. Customs and Border Protection (CBP) regulations to reflect the imposition of import restrictions on certain archaeological and ethnological material from the Federal Democratic Republic of Nepal…
  - (2026-08-12) Special Local Regulation; Casco Bay, Flotilla To Fight Cancer, Long Island, ME
      The Coast Guard is establishing a temporary special local regulation for the navigable waters of Casco Bay, in the vicinity of Cow Island, in the Town of Long Island, ME, to support an offshore concert with spectator ves…
  - (2026-08-12) Special Local Regulation; Daugherty Creek, Crisfield, MD
      The Coast Guard is establishing a temporary special local regulation (SLR) for certain waters of Daugherty Creek, off Wellington Beach, near Crisfield, MD. This action is necessary to provide for the safety of life on th…
  - (2026-08-12) Rescission of DOE's Procedures for Traffic Control on the Nevada Test Site
      This interim final rule rescinds DOE's regulations outlining the establishment of traffic control regulations on the Nevada National Security Site (NNSS), formerly known as the Nevada Test Site. This action is being take…

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 99 total
  - (2026-08-07) [OFAC] Counter Terrorism and Iran-related Designations; Counter Narcotics Designations Removals; Issuance of Amended Iran-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Counter Terrorism and Iran-related Designations; Counter Narcotics Designations Removals; Issuance of Amended Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-06) [OFAC] Cuba-related Designations; Issuance of Cuba-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Cuba-related Designations; Issuance of Cuba-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-06) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-08-05) [OFAC] Counter Terrorism Designations Removals and Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations Removals and Update Office of Foreign Assets Control (.gov)
  - (2026-08-07) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-08-12) [USASpending] $27,583,176,865 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.

### Paper Trading Scorecard — 14 new of 129 total
  - (2026-08-12) [Polymarket] Will annual inflation be 3.4% in July?
      This is a market about inflation over the 12-month period ending July 2026, before seasonal adjustment, as reported by the Bureau of Labor Statistics. This market will resolve to the percentage change in the Consumer Pri…
  - (2026-08-12) [Manifold] Will a 500 megaton explosion happen tommorrow? (Apocalypse Hedging)
  - (2026-08-12) [Manifold] Will the Dan Sullivan ‘impostor’ advance to the general election in the Alaska senate primary on August 18 2026?
  - (2026-08-12) [Manifold] Will Darline Graham get 60.00% or more in the SC Senate primary Runoff?
  - (2026-08-12) [Manifold] Will my new phone survive the night?
  - (2026-08-12) [Manifold] Will Bashar al-Assad's death sentence be carried out?

### World News (by country, top stories) — 12 new of 12 total
  - (2026-08-12) [Japan] Phantom Blade Zero State of Play Set For August 17
      vgchartz.com · English
  - (2026-08-12) [Japan] Typhoon No . 15 Triggers Level 4 Storm Surge Warning
      newsonjapan.com · English
  - (2026-08-12) [Japan] AI Surge Drives Strong Earnings Across Japan Inc .
      newsonjapan.com · English
  - (2026-08-12) [Japan] American Wine Dinner in Tokyo : 5 Regions , 5 Wines
      metropolisjapan.com · English
  - (2026-08-12) [Japan] THQ Sacred 2 Remaster Is Finally Available For Switch , Includes All Expansions & Updates
      nintendolife.com · English
  - (2026-08-12) [Japan] Bethesda Just Hosted A Live Playthrough Of The Elder Scrolls VI
      nintendolife.com · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 40 total
  - (2026-08-12) MOVER ▼ Elon Musk — $826.17B ($-27.12B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-12) MOVER ▼ Larry Page — $281.95B ($-10.38B since yesterday)
      United States · Technology · source: Google
  - (2026-08-12) MOVER ▼ Sergey Brin — $260.10B ($-9.55B since yesterday)
      United States · Technology · source: Google
  - (2026-08-12) MOVER ▼ Michael Dell — $244.65B ($-6.14B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-12) MOVER ▼ Larry Ellison — $186.28B ($-5.95B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-12) MOVER ▼ Jeff Bezos — $278.68B ($-5.13B since yesterday)
      United States · Technology · source: Amazon

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-08-12) Will Francesca Hong win the 2026 Wisconsin Governor Democratic primary election?
      yes price: 0% · 24h volume: $1,570,329 · resolves 2026-08-11
  - (2026-08-12) Will David Crowley win the 2026 Wisconsin Governor Democratic primary election?
      yes price: 100% · 24h volume: $1,257,137 · resolves 2026-08-11
  - (2026-08-12) Strait of Hormuz traffic returns to normal by September 30?
      yes price: 16% · 24h volume: $403,343 · resolves 2026-09-30
  - (2026-08-12) US announces end of Iranian blockade by August 15, 2026?
      yes price: 10% · 24h volume: $344,563 · resolves 2026-08-15
  - (2026-08-12) LoL: HANJIN BRION Challengers vs Hanwha Life Esports Challengers (BO3) - LCK Challengers League Rounds 3-4 Trial Group
      yes price: 0% · 24h volume: $308,029 · resolves 2026-08-12
  - (2026-08-12) Will the U.S. invade Iran before 2027?
      yes price: 18% · 24h volume: $270,068 · resolves 2026-12-31

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-12) [Marginal Revolution] What makes people happy?
      Measuring politically sensitive attitudes in authoritarian settings is difficult because expressions of political support may reflect repression and social pressure as much as genuine belief. We propose a complementary a…
  - (2026-08-12) [Marginal Revolution] Immigrant Earnings Assimilation, 1981–2021
      In this paper, we characterize trends in the earnings assimilation of immigrant workers from 1981 to 2021. We use administrative longitudinal data that contain the earnings of workers beginning in their first year of res…
  - (2026-08-11) [Marginal Revolution] How much will cybersecurity costs rise?
      Here is one (partial) estimate of the higher cyber costs. I am not sure how many incidents they have in mind, but this seems to me realistic as an estimate but also rather modest relative to the Angst I am seeing? Not qu…
  - (2026-08-11) [Conversable Economist] Rocks in the Harbor: Beveridge and Robinson
      For teachers of economics, one familiar metaphor about tariffs is “rocks in the harbor.” Companies and countries go to considerable trouble and expense to build docks and interconnected transportation structure, and even…

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 10 total
  - (2026-08-11) CVE-2026-20349 · Cisco Secure Firewall Adaptive Security Appliance (ASA) and Secure Firewall Threat Defense (FTD) : Cisco Secure Firewall Adaptive Security Appliance (ASA) and Secure Firewall Threat D…
      vendor: Cisco · product: Secure Firewall Adaptive Security Appliance (ASA) and Secure Firewall Threat Defense (FTD) · CISA remediation by 2026-08-14
  - (2026-08-11) CVE-2026-68820 · Microsoft Windows Ancillary Function Driver for WinSock : Microsoft Windows Ancillary Function Driver for WinSock Use-After-Free Vulnerability
      vendor: Microsoft · product: Windows Ancillary Function Driver for WinSock · CISA remediation by 2026-08-25
  - (2026-08-11) CVE-2026-72898 · Metabase Metabase: Metabase SQL Injection Vulnerability
      vendor: Metabase · product: Metabase · CISA remediation by 2026-08-14

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-12) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=21, 14d-median=20; carrying terms: proposes, provide, program, rulemaking, action, august, regulatory, proposed, remove, certain, airspace, amendment
- state_bills: today=0, 7d-median=108, 14d-median=108; carrying terms: adopt, report, forth, affordable, enacted, available, persons, makes, initiate, training, establishes, effective
- state_news: today=681, 7d-median=681, 14d-median=681; carrying terms: still, robert, enough, srcset, according, serious, immigrant, though, attempts, primary, stylar, candidate
- local_news: today=235, 7d-median=235, 14d-median=235; carrying terms: still, according, srcset, saturday, million, georgia, found, shooting, police, magazine, dekalb, child
- foreign_news: today=1011, 7d-median=1011, 14d-median=1011; carrying terms: still, guard, enough, srcset, according, urged, applied, reveals, cyber, hebei, driven, tensions
- chinese_internal: today=267, 7d-median=261, 14d-median=266; carrying terms: cbmizefvx, cbmiw, lxtfa, caixin, cbmiykfvx, cbmickfvx, china, people, cbmixkfvx, color, cbmizkfvx, cbmiakfvx
- russian_internal: today=1157, 7d-median=1056, 14d-median=943; carrying terms: forbidden, novayagazeta, gazeta, found, istories, bloomberg, times, novaya, title, error, journal, media
- ukrainian_internal: today=113, 7d-median=107, 14d-median=113; carrying terms: districts, international, babel, developments, kyivindependent, energy, compiles, title, error, staff, updates, hmarochos
- ukraine_theater: today=780, 7d-median=780, 14d-median=780; carrying terms: vnbtnzvja, nlrmdepyvju, jouvqag, fedorov, hcdxewbec, sfnyz, yxzsbulet, lebanon, sdnqtci, byuryufr, qtldrg, avrasu
- paper_bets: today=129, 7d-median=137, 14d-median=137; carrying terms: degrees, celsius, seats, carolina, according, predictit, mbappe, virginia, rippling, market, inflation, republican
- weather: today=170, 7d-median=170, 14d-median=170; carrying terms: degrees, strong, illnesses, counties, montgomery, forecast, marine, flooding, higher, further, impacts, continues
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, openings, pcepilfe, total, dexjpus, headline, crude, commodities, cpilfesl, treasury, assets, implied
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, silver, crude, natural, bitcoin, commodities, agriculture, close, equities, crypto, treasury, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=99, 14d-median=101; carrying terms: illegal, hanford, military, yemen, mvbiwgfitgdeugxss, representative, international, specific, serious, council, zimbabwe, groups
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, quiverquant, congresstrading, https, client, quiver, unauthorized, httperror, error
- billionaires: today=40, 7d-median=34, 14d-median=37; carrying terms: technologies, ellison, retail, commodities, india, zhang, adani, yiming, spacex, walton, francoise, devasini
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: johnson, delaware, appeals, court, supreme, blanche, association, california, company, charles, trust, group
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, holdings, energy, david, global, chang
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: robert, filing, david, talarico, booker, disbursements, committee, johnson, warner, jonathan, sherrod, michael
- gdelt_regions: today=12, 7d-median=6, 14d-median=6; carrying terms: english, korea, japan
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, spanish, themes, trump, hormuz, chinese, russian, russia, german, china, perimeter, indonesian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: english, russia, domain, language, iheart, kingdom
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=28, 7d-median=26, 14d-median=19; carrying terms: position, france, belgium, ground, kingdom, germany, bulgaria, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: raise, districts, report, infected, americas, relations, municipalities, rwampara, mosquitoes, regarding, cumulative, kerala
- cisa_kev: today=10, 7d-median=9, 14d-median=9; carrying terms: deserialization, vendor, remediation, coded, langflow, center, injection, command, firewall, cisco, product, authentication
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=315, 7d-median=251, 14d-median=244; carrying terms: kazakhstan, tanzania, earthquake, alert, austria, minor, bosnia, gabon, madagascar, honduras, orange, impact
- usgs_quakes: today=18, 7d-median=13, 14d-median=14; carrying terms: depth, russia, indonesia, japan, kuril, severo, alaska, tonga, papua, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ceasefire, volume, august, effective, september, resolves, price, strait, returns, normal, traffic, prime
- commentary: today=6, 7d-median=6, 14d-median=5; carrying terms: economist, revolution, https, class, conversable, marginal, strong, conversableeconomist, marginalrevolution, economic, current, future
- tech_news: today=53, 7d-median=56, 14d-median=56; carrying terms: download, researchers, edition, cyber, weekday, become, government, million, attacks, experts, complex, hacker
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: robert, fuller, mrvan, analilia, strong, fletcher, garcia, topic, hoyle, moore, booker, allen
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, evidence, module, claude, either, converges, placed, consensus, today, identify, market, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*