# WORLDSCOPE morning brief — 2026-08-12

## Headline
3802 new items across 26 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (765) · International News + Multilateral Institutions (757) · Ukraine Theater (total-war monitoring) (597) · State-Level News (344) · World leaders & government officials (324) · Chinese Internal News (225) · Local News: St. Louis + Atlanta (211) · U.S. Weather + Severe / Climate Outlooks (180) · Ukrainian Internal News (national + local Kyiv) (68) · IT, InfoSys & cybersecurity news (last 7 days) (47) · Court opinions of consequence (federal & state) (42) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 765 new of 1182 total
  - (2026-08-12) Россия начала получать бензин из Индии | LEDE: В Россию прибыла первая партия бензина из Индии, сообщает Bloomberg со ссылкой на данные сервиса Kpler. ] (ru: Россия начала получать бензин из Индии)
      В Россию прибыла первая партия бензина из Индии, сообщает Bloomberg со ссылкой на данные сервиса Kpler.
  - (2026-08-12) Рекламодатели сократили рекламу на Wildberries после атак Украины на склады, пишет «Коммерсант». Маркетплейс утверждает, что «масштабы преувеличены» | LEDE: После атак украинских беспилотник] (ru: Рек…
      После атак украинских беспилотников на склады Wildberries на маркетплейсе «заметно снизилась» рекламная активность, рассказали «Коммерсанту» источники в крупных рекламных агентствах.
  - (2026-08-12) Spotify начнет маркировать ИИ-исполнителей значком AI Persona. Их музыку исключат из рекомендаций | LEDE: Музыкальный стриминговый сервис Spotify объявил, что начнет маркировать «музыкантов»] (ru: Spo…
      Музыкальный стриминговый сервис Spotify объявил, что начнет маркировать «музыкантов», созданных с помощью искусственного интеллекта, как AI Persona (ИИ-персона).
  - (2026-08-12) Под Смоленском нашли краснокнижного орлана с пулевым ранением. Зоозащитники 50 дней ждали разрешения властей, чтобы начать лечение. В итоге птица погибла | LEDE: В Карельском зоопарке умер к] (ru: Под…
      В Карельском зоопарке умер краснокнижный орлан-белохвост, найденный в июне с пулевым ранением под Смоленском. По словам зоозащитников, на получение от властей необходимых для его лечения документов ушло 50 дней. В сообще…
  - (2026-08-12) Пора подаваться на загранпаспорт — а вам есть что утаить о себе от российских властей? Понимаем! Вот о чем можно умолчать и не столкнуться с проблемами | LEDE: 22 июля Госдума приняла два за] (ru: Пор…
      22 июля Госдума приняла два закона, которые ограничили права тех, кто находится за границей и преследуется российскими властями. В частности, таких людей лишат возможности получать загранпаспорта и пользоваться большинст…
  - (2026-08-12) Экспорт кофе из Колумбии приостановили из-за землетрясения | LEDE: Экспорт колумбийского кофе оказался «практически приостановлен» после сильнейшего землетрясения в стране, пишет Bloomberg, ] (ru: Экс…
      Экспорт колумбийского кофе оказался «практически приостановлен» после сильнейшего землетрясения в стране, пишет Bloomberg, ссылаясь на главу Национальной ассоциации экспортеров кофе (Asoexport) Густаво Гомеса.

### International News + Multilateral Institutions — 757 new of 1011 total
  - (2026-08-12) [Global] Zambia’s president rallies for second term ahead of election
      Zambia's president rallies for second term ahead of election
  - (2026-08-12) [Global] A hydrogen-powered vehicle sets new land speed record
      A hydrogen-powered vehicle sets new land speed record
  - (2026-08-12) [Global] Rybakina defeats Osaka, advances to Canadian Open semifinals to play Gauff
      Elena Rybakina stages a huge comeback to beat Naomi Osaka and will now play Coco Gauff for a place in the final.
  - (2026-08-12) [Global] Wisconsin race tight: Key takeaways from US primary election results
      Trump-backed candidates both win and lose: Results from Wisconsin, Minnesota, South Carolina and Alabama.
  - (2026-08-12) [Global] Wildberries under fire: Why is Ukraine targeting a Russian retail giant?
      The company akin to Amazon has come under heavy attacks in Russia as Kyiv tries to bring the sense of war home.
  - (2026-08-12) [Global] Clacton by-election: Farage may win the town, but can he win the country?
      Reform UK leader is set to claim victory over the seaside town that adores him, but the party's popularity is in doubt.

### Ukraine Theater (total-war monitoring) — 597 new of 780 total
  - (2026-08-12) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-10) [Liveuamap] An emergency power outage in Gelendzhik and Novorossiysk - Liveuamap
      An emergency power outage in Gelendzhik and Novorossiysk Liveuamap
  - (2026-08-11) [Liveuamap] Internal Security in Aleppo Governorate: Curfew lifted in the city of Ain al-Arab (Kobani) after security was restored and calm returned to the city. - Liveuamap
      Internal Security in Aleppo Governorate: Curfew lifted in the city of Ain al-Arab (Kobani) after security was restore
  - (2026-08-06) [Liveuamap] Yemeni media: Casualties in shelling by Houthis (Houthis) on two government forces camps in Marib and Hadramawt - Liveuamap
      Yemeni media: Casualties in shelling by Houthis (Houthis) on two government forces camps in Marib and Hadramawt &nbs
  - (2026-08-09) [Liveuamap] Iran stated that the Strait of Hormuz will not return to pre-war operating conditions, asserting that only routes agreed upon with Oman and designated by Iranian armed forces will be recog…
      Iran stated that the Strait of Hormuz will not return to pre-war operating conditions, asserting that only routes agree
  - (2017-08-07) [Liveuamap] Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com - sudan.liveuamap.com
      Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com sudan.liveuamap.com

### State-Level News — 344 new of 691 total
  - (2026-08-11) [California] First Partner Siebel Newsom, Governor Newsom, and #HalfTheStory launch California’s first Teen Tech Council
      Source
  - (2026-08-11) [California] Governor Newsom fast-tracks 1,700 new affordable housing units
  - (2026-08-11) [California] As 2026 continues notching heat records, Governor Newsom announces a strategic action plan to address extreme heat in California
      Source
  - (2026-08-11) [California] Governor Newsom’s mental health reform continues to deliver, announcing 15 new projects expanding care across the state
      Source
  - (2026-08-11) [California] Según el estado, casi en ninguna parte de California se está construyendo lo suficiente. He aquí por qué
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/03/052423_Santa-Monica-Construction-ZS_CM_27.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-…
  - (2026-08-11) [California] ¿Cómo funciona el nuevo programa de reembolso de $3,500 para vehículos eléctricos en California?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/012924_EVFILE-KSM-26_KQED_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 225 new of 269 total
  - (2026-08-11) 高盛 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5mbFZ2MUFHMHBjR25WRWdSVU1RSmNZY2o0Wl9mMjdFSlpoMF9Kbm1Rc1V5YzdPc1VhdmFFakV3ZU1INkdNN1FWVXpnMkZZNTNnTW] (zh:…
      高盛 deepview.caixin.com
  - (2026-08-11) 交易所 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE4zWnh3c3ktNHN6WVB6R2Jjc1MwMjdiR1Z2MVp0VzNsd29VeEJDY2xOTzBwelZjWlYzaXk1MUlESEMwTExibURFZHhMTEFZOWprb] (zh:…
      交易所 deepview.caixin.com
  - (2026-08-10) 数据图解 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE9QVWNaQnFCcTlNRUdGQUgtQU1iQlQ4dVpBQllkbE8wd2o3WkcxX3RHTHFyOEZMTnpNRFhZempxb3Atc2hjNnY1c1BPOXA5ZTh4] (zh:…
      数据图解 deepview.caixin.com
  - (2026-08-11) 哥伦比亚7.4级强震致至少132死570 伤已进入国家灾难状态 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5hV01RWlRGQUduaWl2aHVqZUdYUEFtcjdIdjlnYXdUWXVfT1lZRW0xT2x6MGd2VFY3aFVramZ6enRQS1praUNJaG] (zh:…
      哥伦比亚7.4级强震致至少132死570 伤已进入国家灾难状态 财新
  - (2026-08-12) 宇树上市，高管、核心员工获配超180万股 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE13ODBKUm9nNHJKYWItQzNsRHJPUUhhUk4zZVFYemhBV1NQSHR0dWhCRzhJMFFTZ0ZjSlhkRWpiaFA2VEJYMTNXVGVIbVZYNVlvc] (zh:…
      宇树上市，高管、核心员工获配超180万股 财新
  - (2026-08-12) 朱梅：一句“美女”带来的2.15亿美元巨额罚单 | 出海·专栏 - companies.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE8zR3c2T0ZJdmMybTVSV2Q0MFJBbGh5d05YN3pvZE80RUcxcUNzWUQ3ckNqZFBHLXZVUFR2] (zh:…
      朱梅：一句“美女”带来的2.15亿美元巨额罚单 | 出海·专栏 companies.caixin.com

### Local News: St. Louis + Atlanta — 211 new of 244 total
  - (2026-08-12) [St. Louis] David Crowley defeats Francesca Hong in close Wisconsin Democratic primary for governor
      Incumbent Gov. Tony Evers had backed Crowley's campaign while Hong drew endorsements from national progressives.
  - (2026-08-12) [St. Louis] Key races to watch for the Aug. 11 primaries: Live results maps for elections in 6 states
      Voters in six states will cast their ballots Tuesday, Aug. 11 for their preferred candidates in primaries and special elections ahead of Election Day in November.
  - (2026-08-12) [St. Louis] New details released about Jackie the bald eagle's final days
      Wildlife officials revealed Jackie suffered a blood clot and organ decline before her death at the Ojai Raptor Center.
  - (2026-08-12) [St. Louis] Shake Shack says technical glitch caused kiosk tip pricing confusion seen in viral TikTok
      A man posted a TikTok of him and his wife using a self checkout kiosk at Shake Shack to order milkshakes. They said the price increased after they didn't tip.
  - (2026-08-12) [St. Louis] National wiffleball championship bringing top teams to O'Fallon, Missouri
      The tournament is set to be held at CarShield Field this weekend.
  - (2026-08-12) [St. Louis] St. Louis County budget battle continues after online sales tax rejection
      The failed online sales tax proposal has intensified tensions between county leaders over budget cuts and public safety, with debate swirling around police.

### U.S. Weather + Severe / Climate Outlooks — 180 new of 182 total
  - (2026-08-12) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-12) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 12 at 4:37AM CDT until August 12 at 5:00AM CDT by NWS Omaha/Valley NE
      At 436 AM CDT, a severe thunderstorm was located 3 miles northwest of Allen, or 12 miles southwest of Ponca, moving east at 40 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hai…
  - (2026-08-12) [Severe] Flash Flood Warning: Flash Flood Warning issued August 12 at 5:37AM EDT until August 12 at 8:30AM EDT by NWS Louisville KY
      FFWLMK The National Weather Service in Louisville has issued a * Flash Flood Warning for... Central Henry County in central Kentucky... Southeastern Trimble County in central Kentucky... * Until 830 AM EDT. * At 537 AM E…
  - (2026-08-12) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 12 at 4:37AM CDT until August 12 at 5:30AM CDT by NWS Quad Cities IA IL
      SVRDVN The National Weather Service in the Quad Cities has issued a * Severe Thunderstorm Warning for... Northwestern Johnson County in east central Iowa... Southern Benton County in east central Iowa... Southwestern Lin…
  - (2026-08-12) [Severe] Flood Watch: Flood Watch issued August 12 at 2:34AM PDT until August 13 at 8:00PM PDT by NWS Elko NV
      * WHAT...Flooding caused by excessive rainfall is possible. * WHERE...Portions of eastern, north central, and south central Nevada, including the following areas, in eastern Nevada, White Pine. In north central Nevada, S…
  - (2026-08-12) [Severe] Flash Flood Warning: Flash Flood Warning issued August 12 at 5:34AM EDT until August 12 at 10:00AM EDT by NWS Indianapolis IN
      FFWIND The National Weather Service in Indianapolis has issued a * Flash Flood Warning for... Delaware County in east central Indiana... Northern Henry County in east central Indiana... Randolph County in east central In…

### Ukrainian Internal News (national + local Kyiv) — 68 new of 115 total
  - (2026-08-12) В уряді Польщі кажуть, що їхня економіка зупиниться без українців | LEDE: Заступник міністра внутрішніх справ Польщі Мачей Дущик звернув увагу на внесок українців у функціонування польської еко] (uk:…
      Заступник міністра внутрішніх справ Польщі Мачей Дущик звернув увагу на внесок українців у функціонування польської економіки.
  - (2026-08-12) ЗМІ: Польський експосадовець, якого розшукує Варшава, перебуває у Придністров'ї | LEDE: ] (uk: ЗМІ: Польський експосадовець, якого розшукує Варшава, перебуває у Придністров'ї)
  - (2026-08-12) У Польщі обурені, що Starlink виключив їх країну з європейської зони сервісу | LEDE: ] (uk: У Польщі обурені, що Starlink виключив їх країну з європейської зони сервісу)
  - (2026-08-12) Справа про катування в Одеському РТЦК: ДБР оголосило ще чотири підозри | LEDE: Кількість підозрюваних працівників ТЦК на Одещині зросла до 13. Досудове розслідування дій ДБР триває.] (uk: Справа про к…
      Кількість підозрюваних працівників ТЦК на Одещині зросла до 13. Досудове розслідування дій ДБР триває.
  - (2026-08-12) Путін одягнув форму ВМФ і видав нову порцію погроз Заходу | LEDE: Путін відвідав Сахалін, заявив про загрози з боку НАТО, пригрозив відповіддю на затримання суден РФ.] (uk: Путін одягнув форму ВМФ і в…
      Путін відвідав Сахалін, заявив про загрози з боку НАТО, пригрозив відповіддю на затримання суден РФ.
  - (2026-08-12) Зеленський: Дрони "Паляниця" і ракети "Нептун" відпрацювали по морській базі РФ в Новоросійську | LEDE: Україна завдала ударів дронами "Паляниця" і ракетами "Нептун" по російській військово-мор] (uk:…
      Україна завдала ударів дронами "Паляниця" і ракетами "Нептун" по російській військово-морській базі в Новоросійську.

### IT, InfoSys & cybersecurity news (last 7 days) — 47 new of 58 total
  - (2026-08-12) [BleepingComputer] Google says Chrome cuts 7 billion unwanted Android notifications a day to fight abuse
      Google says Chrome's anti-abuse systems reduced unwanted notifications on Android by more than 7 billion per day during the first quarter of 2026. [...]
  - (2026-08-12) [The Hacker News] Malicious LiteLLM Releases Tied to Trivy Hack May Have Exposed 2,100+ Organizations
      Two malicious LiteLLM releases sat on PyPI for about 40 minutes in March carrying credential-stealing code capable of harvesting cloud keys, SSH keys, Kubernetes tokens, database passwords, and other secrets from systems…
  - (2026-08-12) [The Hacker News] SAP Commerce Cloud Flaw Could Let Unauthenticated Attackers Execute Arbitrary Code
      SAP has released patches to address a maximum-severity security flaw impacting Commerce Cloud (Data Hub Adapter) that could result in arbitrary code execution. The vulnerability, assigned the CVE identifier CVE-2026-5823…
  - (2026-08-12) [The Hacker News] ShieldBreak Zero-Day PoC Claims Microsoft Defender Patch Bypass With SYSTEM Access
      The security researcher going by the name Chaotic Eclipse (aka INFINITE NIGHTMARE, MSNightmare, and Nightmare-Eclipse) has released a proof-of-concept (PoC) for a new Microsoft zero-day called ShieldBreak. The vulnerabil…
  - (2026-08-12) [The Hacker News] Cisco ASA and FTD Flaw Exploited in the Wild Can Trigger Remote DoS
      Cisco has warned that a new vulnerability impacting Secure Firewall Adaptive Security Appliance (ASA) Software and Secure Firewall Threat Defense (FTD) Software has been exploited in the wild. The high-severity flaw, tra…
  - (2026-08-12) [The Register] UK puts £14B cloud framework in place with SMEs promised a bigger slice
      Global players dominate the market. Will public sector buyers give local suppliers a look-in?

### Court opinions of consequence (federal & state) — 42 new of 60 total
  - (2026-08-11) U.S. Court of International Trade: Mirror Metals, Inc. v. United States
  - (2026-08-11) U.S. Court of Appeals, 2nd Cir.: Mehrotra v. U.S. Dep't of Lab.
  - (2026-08-11) U.S. Court of Appeals, 2nd Cir.: Glover v. Connecticut General Life Insurance Company
  - (2026-08-11) U.S. Court of Appeals, 2nd Cir.: Paez v. Syracuse University
  - (2026-08-11) U.S. Court of Appeals, Federal Cir.: Range of Motion Products, LLC v. Armaid Company Inc.
  - (2026-08-11) U.S. Court of Appeals, Federal Cir.: Fedmet Resources Corporation v. United States

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-12) [Meyer John Tull] Form 4 (Reporting)
      filed 2026-08-12 01:52 UTC · role: Reporting — Filed: 2026-08-11 AccNo: 0001476150-26-000043 Size: 5 KB
  - (2026-08-12) [Terreno Realty Corp] Form 4 (Issuer)
      filed 2026-08-12 01:52 UTC · role: Issuer — Filed: 2026-08-11 AccNo: 0001476150-26-000043 Size: 5 KB
  - (2026-08-12) [Tian Jing] Form 4 (Reporting)
      filed 2026-08-12 01:49 UTC · role: Reporting — Filed: 2026-08-11 AccNo: 0001213900-26-087981 Size: 9 KB
  - (2026-08-12) [TIGO ENERGY, INC.] Form 4 (Issuer)
      filed 2026-08-12 01:49 UTC · role: Issuer — Filed: 2026-08-11 AccNo: 0001213900-26-087981 Size: 9 KB
  - (2026-08-12) [LandBridge Holdings LLC] Form 4 (Reporting)
      filed 2026-08-12 01:48 UTC · role: Reporting — Filed: 2026-08-11 AccNo: 0001193125-26-345454 Size: 26 KB
  - (2026-08-12) [Five Point Energy Fund II AIV-VII LP] Form 4 (Reporting)
      filed 2026-08-12 01:48 UTC · role: Reporting — Filed: 2026-08-11 AccNo: 0001193125-26-345454 Size: 26 KB

### GDELT GKG — themes / entities / watch areas — 37 new of 37 total
  - (2026-08-12) [Russia oil sanctions perimeter · themes] US Navy sailors jumping ship as deployment in Iran war drags on
      albawaba.com · English · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] Новият ОПЕК : Как Китай стана нефтена суперсила
      money.bg · Bulgarian · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] Tőzsdenyitás Augusztus 12 .– A Mol új csúcson , OTP is pluszban áll
      tozsdeforum.hu · Hungarian · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] Autobahn nach Absturz von Stahlträger noch Stunden gesperrt
      stimme.de · German · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] Zayıflama iğnelerinin bilinmeyen yüzü ortaya çıktı : Kolayca zayıflayacağım sananlar dikkat !
      haber3.com · Turkish · tone NA
  - (2026-08-12) [Russia oil sanctions perimeter · themes] Realitatea . NET | Tafic blocat spre București după ce un camion a lovit un picior de pod , pe A1 : marfa s - a împrăștiat pe șosea
      realitatea.net · Romanian · tone NA

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-12) GAF527 (Germany)
      icao24: 3dbc00 · position: (53.9253, 12.2397) · alt: 182m · 231km/h
  - (2026-08-12) GAF115 (Germany)
      icao24: 3ea653 · position: (61.4105, 18.0992) · alt: 10050m · 648km/h
  - (2026-08-12) PUMA23 (Slovenia)
      icao24: 506e18 · position: (46.4612, 15.8696) · alt: 1402m · 173km/h
  - (2026-08-12) GAF892 (Germany)
      icao24: 3f97fd · position: (51.4099, 12.2242) · on ground
  - (2026-08-12) CFC2981 (Canada)
      icao24: c2b5b7 · position: (51.0429, 7.8885) · alt: 5501m · 468km/h
  - (2026-08-12) CNA21 (Spain)
      icao24: 3475ca · position: (27.9269, -15.4173) · alt: 365m · 179km/h

### GDACS — global disaster alerts — 24 new of 315 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-07-06) [Green] Eruption Etna
      Volcano · Green alert · Italy
  - (2026-07-06) [Green] Eruption Etna
      Volcano · Green alert · Italy
  - (2026-07-06) [Green] Eruption Etna
      Volcano · Green alert · Italy

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-08-12) M 5.2 - 42 km ESE of Naalehu, Hawaii
      M5.2 · 42 km ESE of Naalehu, Hawaii · depth 10.73 km
  - (2026-08-12) M 5.1 - Pacific-Antarctic Ridge
      M5.1 · Pacific-Antarctic Ridge · depth 10 km
  - (2026-08-11) M 5.1 - 51 km E of Tobelo, Indonesia
      M5.1 · 51 km E of Tobelo, Indonesia · depth 10 km
  - (2026-08-12) M 5.0 - 66 km E of Chayek, Kyrgyzstan
      M5.0 · 66 km E of Chayek, Kyrgyzstan · depth 10 km
  - (2026-08-11) M 5.0 - 89 km ESE of Kokopo, Papua New Guinea
      M5.0 · 89 km ESE of Kokopo, Papua New Guinea · depth 68.887 km
  - (2026-08-11) M 5.0 - 107 km WNW of Kerema, Papua New Guinea
      M5.0 · 107 km WNW of Kerema, Papua New Guinea · depth 10 km

### U.S. Federal Action — 16 new of 29 total
  - (2026-08-12) Appellate Jurisdiction Update II
      The Merit Systems Protection Board (MSPB or Board) is amending its regulations to remove references to MSPB's jurisdiction over probationary termination, suitability, and reduction-in-force (RIF) appeals. This revision r…
  - (2026-08-12) Community Reinvestment Act Regulations
      The Office of the Comptroller of the Currency (OCC) and the Federal Deposit Insurance Corporation (FDIC) are proposing to amend their Community Reinvestment Act rules by making certain substantive, technical, and process…
  - (2026-08-12) Imposition of Import Restrictions on Categories of Archaeological and Ethnological Material of Nepal
      This document amends U.S. Customs and Border Protection (CBP) regulations to reflect the imposition of import restrictions on certain archaeological and ethnological material from the Federal Democratic Republic of Nepal…
  - (2026-08-12) Special Local Regulation; Casco Bay, Flotilla To Fight Cancer, Long Island, ME
      The Coast Guard is establishing a temporary special local regulation for the navigable waters of Casco Bay, in the vicinity of Cow Island, in the Town of Long Island, ME, to support an offshore concert with spectator ves…
  - (2026-08-12) Special Local Regulation; Daugherty Creek, Crisfield, MD
      The Coast Guard is establishing a temporary special local regulation (SLR) for certain waters of Daugherty Creek, off Wellington Beach, near Crisfield, MD. This action is necessary to provide for the safety of life on th…
  - (2026-08-12) Rescission of DOE's Procedures for Traffic Control on the Nevada Test Site
      This interim final rule rescinds DOE's regulations outlining the establishment of traffic control regulations on the Nevada National Security Site (NNSS), formerly known as the Nevada Test Site. This action is being take…

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 99 total
  - (2026-08-07) [OFAC] Counter Terrorism and Iran-related Designations; Counter Narcotics Designations Removals; Issuance of Amended Iran-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Counter Terrorism and Iran-related Designations; Counter Narcotics Designations Removals; Issuance of Amended Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-06) [OFAC] Cuba-related Designations; Issuance of Cuba-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Cuba-related Designations; Issuance of Cuba-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-06) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-08-05) [OFAC] Counter Terrorism Designations Removals and Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations Removals and Update Office of Foreign Assets Control (.gov)
  - (2026-08-07) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-08-12) [USASpending] $27,583,176,865 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.

### Paper Trading Scorecard — 14 new of 128 total
  - (2026-08-12) [Manifold] Will someone that had a merge request merged in the official CPython repository comment on this market?
  - (2026-08-12) [Manifold] Will a 500 megaton explosion happen tommorrow? (Apocalypse Hedging)
  - (2026-08-12) [Manifold] Will the Dan Sullivan ‘impostor’ advance to the general election in the Alaska senate primary on August 18 2026?
  - (2026-08-12) [Manifold] Will Darline Graham get 60.00% or more in the SC Senate primary Runoff?
  - (2026-08-12) [Manifold] Will my new phone survive the night?
  - (2026-08-12) [Manifold] Will Bashar al-Assad's death sentence be carried out?

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-08-12) Will Francesca Hong win the 2026 Wisconsin Governor Democratic primary election?
      yes price: 0% · 24h volume: $1,570,103 · resolves 2026-08-11
  - (2026-08-12) Will David Crowley win the 2026 Wisconsin Governor Democratic primary election?
      yes price: 100% · 24h volume: $1,272,173 · resolves 2026-08-11
  - (2026-08-12) LoL: DN SOOPers vs Nongshim Red Force - Game 2 Winner
      yes price: 100% · 24h volume: $880,801 · resolves 2026-08-12
  - (2026-08-12) LoL: DN SOOPers vs Nongshim Red Force - Game 1 Winner
      yes price: 0% · 24h volume: $802,979 · resolves 2026-08-12
  - (2026-08-12) Strait of Hormuz traffic returns to normal by September 30?
      yes price: 16% · 24h volume: $404,503 · resolves 2026-09-30
  - (2026-08-12) LoL: DN SOOPers vs Nongshim Red Force (BO3) - LCK Round 3-4 Rise Group
      yes price: 44% · 24h volume: $367,662 · resolves 2026-08-12

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-12) [Marginal Revolution] What makes people happy?
      Measuring politically sensitive attitudes in authoritarian settings is difficult because expressions of political support may reflect repression and social pressure as much as genuine belief. We propose a complementary a…
  - (2026-08-12) [Marginal Revolution] Immigrant Earnings Assimilation, 1981–2021
      In this paper, we characterize trends in the earnings assimilation of immigrant workers from 1981 to 2021. We use administrative longitudinal data that contain the earnings of workers beginning in their first year of res…
  - (2026-08-11) [Marginal Revolution] How much will cybersecurity costs rise?
      Here is one (partial) estimate of the higher cyber costs. I am not sure how many incidents they have in mind, but this seems to me realistic as an estimate but also rather modest relative to the Angst I am seeing? Not qu…
  - (2026-08-11) [Conversable Economist] Rocks in the Harbor: Beveridge and Robinson
      For teachers of economics, one familiar metaphor about tariffs is “rocks in the harbor.” Companies and countries go to considerable trouble and expense to build docks and interconnected transportation structure, and even…

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 10 total
  - (2026-08-11) CVE-2026-20349 · Cisco Secure Firewall Adaptive Security Appliance (ASA) and Secure Firewall Threat Defense (FTD) : Cisco Secure Firewall Adaptive Security Appliance (ASA) and Secure Firewall Threat D…
      vendor: Cisco · product: Secure Firewall Adaptive Security Appliance (ASA) and Secure Firewall Threat Defense (FTD) · CISA remediation by 2026-08-14
  - (2026-08-11) CVE-2026-68820 · Microsoft Windows Ancillary Function Driver for WinSock : Microsoft Windows Ancillary Function Driver for WinSock Use-After-Free Vulnerability
      vendor: Microsoft · product: Windows Ancillary Function Driver for WinSock · CISA remediation by 2026-08-25
  - (2026-08-11) CVE-2026-72898 · Metabase Metabase: Metabase SQL Injection Vulnerability
      vendor: Metabase · product: Metabase · CISA remediation by 2026-08-14

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 1 new of 34 total
  - (2026-08-12) MOVER ▼ Bernard Arnault & family — $144.98B ($-0.48B since yesterday)
      France · Fashion & Retail · source: LVMH

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-12) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=21, 14d-median=20; carrying terms: proposed, remove, regulatory, amendment, service, rulemaking, operations, proposing, august, safety, provide, program
- state_bills: today=0, 7d-median=108, 14d-median=107; carrying terms: family, enacted, regulatory, relating, state, professional, emergency, employee, taxation, management, review, applicable
- state_news: today=691, 7d-median=691, 14d-median=590; carrying terms: whitmer, family, summer, dropped, jackson, oklahoma, nominee, might, impacts, image, respond, ballots
- local_news: today=244, 7d-median=241, 14d-median=234; carrying terms: family, image, braves, being, august, target, following, health, vehicle, shooting, appeared, police
- foreign_news: today=1011, 7d-median=1011, 14d-median=1006; carrying terms: attacks, backed, adviser, nairobi, shipping, company, spanish, align, christmas, screenshot, dropped, coercive
- chinese_internal: today=269, 7d-median=261, 14d-median=264; carrying terms: cbmickfvx, cbmiaefvx, cbmiyefvx, google, cbmicefvx, cbmidefvx, target, lxtfb, cbmibkfvx, cbmia, china, cbmizkfvx
- russian_internal: today=1182, 7d-median=1056, 14d-median=976; carrying terms: istories, europe, russian, httperror, journal, title, axios, media, times, found, client, bloomberg
- ukrainian_internal: today=115, 7d-median=107, 14d-median=111; carrying terms: attacks, vechirniy, combat, people, company, kills, state, zelensky, cabinet, russia, energy, today
- ukraine_theater: today=780, 7d-median=780, 14d-median=778; carrying terms: dtvrrnk, mlczuvbwyk, attacks, uedtbvbtm, cbmiyafbvv, itzbvevn, adviser, zdfltdfdfyjjhtknitfnqsmuzngjfyk, vkdxvannm, ruvhtwdos, cfnrswxnd, appointed
- paper_bets: today=128, 7d-median=137, 14d-median=135; carrying terms: funds, kylian, caribbean, openai, party, kansas, state, nebraska, arizona, humanoid, secretary, georgia
- weather: today=182, 7d-median=182, 14d-median=172; carrying terms: increasing, afdphi, conditions, rainfall, notice, events, thunderstorms, santa, afdmeg, mainly, today, pontiac
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, commodities, unemployment, cpiaucsl, unrate, implied, assets, dexjpus, balance, walcl, growth, latest
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, large, rates, crypto, agriculture, yield, equities, nasdaq, natural, china, proxy, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=99, 14d-median=100; carrying terms: involvement, funds, linear, qaida, attacks, bosnia, combat, notice, company, burundi, state, certain
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, client, unauthorized, quiverquant, https, quantitative, congresstrading, quiver, error
- billionaires: today=34, 7d-median=34, 14d-median=34; carrying terms: family, commodities, adani, holdings, mexico, sergey, giancarlo, alice, changpeng, bloomberg, yiming, retail
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, delaware, appeals, johnson, supreme, county, blanche, association, connecticut, company, state, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, filed, issuer, holdings, david, energy, chang, global
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, david, sherrod, filing, platner, receipts, senate, talarico, jonathan, alexandria, warner, trone
- gdelt_regions: today=12, 7d-median=6, 14d-median=6; carrying terms: english, korea, japan
- gdelt_gkg: today=37, 7d-median=37, 14d-median=42; carrying terms: english, spanish, russian, themes, chinese, russia, strait, german, italian, turkish, china, indonesian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=26, 14d-median=22; carrying terms: position, france, belgium, ground, kingdom, canada, germany, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: increasing, noted, identified, reported, comprising, ongoing, ventilation, syndrome, cutaneous, oecusse, analysis, blood
- cisa_kev: today=10, 7d-median=9, 14d-median=9; carrying terms: product, password, management, deserialization, authentication, command, cisco, injection, langflow, coded, center, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=315, 7d-median=251, 14d-median=236; carrying terms: panama, herzegovina, tropical, republic, dolphin, hungary, fires, mexico, nicaragua, medium, marshall, bosnia
- usgs_quakes: today=17, 7d-median=13, 14d-median=14; carrying terms: depth, russia, japan, severo, kuril, indonesia, tonga, papua, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: august, price, winner, ceasefire, effective, september, volume, resolves, traffic, strait, returns, normal
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, revolution, conversable, marginal, class, https, conversableeconomist, strong, economic, current, marginalrevolution, workers
- tech_news: today=58, 7d-median=56, 14d-median=56; carrying terms: attacks, problems, people, risks, spectrum, review, today, computer, cloud, computerweekly, daily, cybersecurity
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: hillary, mcdonald, philadelphia, adviser, warsh, chris, dwight, nellie, wittman, drift, frank, salinas
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, market, identify, consensus, paper, today, decision, converges, claude, markets, sufficient, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*