# WORLDSCOPE morning brief — 2026-08-10

## Headline
2923 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (686) · Russian Internal News (state + in-exile) (632) · Ukraine Theater (total-war monitoring) (510) · World leaders & government officials (324) · Chinese Internal News (185) · Local News: St. Louis + Atlanta (115) · U.S. Weather + Severe / Climate Outlooks (105) · State-Level News (85) · State Legislative Action (52) · Ukrainian Internal News (national + local Kyiv) (50) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (28)

## What changed today
### International News + Multilateral Institutions — 686 new of 919 total
  - (2026-08-10) [India] Bihar man poses as IAS officer, claims links to NSA Ajit Doval; cops seize Tesla car, SUV after arrest
  - (2026-08-10) [India] Hyderabad Police warn against ‘Rent a Boyfriend’ trap targeting young girls, women | What we know about the dating scam
  - (2026-08-10) [India] Right-wing activist Mohandas arrested after alleged ‘girls enjoy rape’ remark over NEET protest
  - (2026-08-10) [India] SC asks panel to verify claims of Manipur violence-hit families yet to get rehabilitation benefits
  - (2026-08-10) [India] Maharashtra CM Fadnavis says FCRA bill aims to curb anti-national activities, not target any religion
  - (2026-08-10) [India] XUV rams three two-wheelers, kills retired army jawan in Hyderabad

### Russian Internal News (state + in-exile) — 632 new of 813 total
  - (2026-08-10) В Польше прошли акции против нападений на украинцев | LEDE: В 22 городах Польши в воскресенье, 9 августа, прошли акции в знак протеста против растущего в стране насилия в отношении украинцев] (ru: В П…
      В 22 городах Польши в воскресенье, 9 августа, прошли акции в знак протеста против растущего в стране насилия в отношении украинцев, сообщает RMF24.
  - (2026-08-10) В Австралии полицейские нашли чемодан с телом женщины в синяках. Экспертиза показала, что это кукла. Кто и зачем это сделал, неясно | LEDE: В Австралии полицейские обнаружили чемодан с содер] (ru: В А…
      В Австралии полицейские обнаружили чемодан с содержимым, которое поначалу приняли за человеческое тело, однако позже оказалось, что это была кукла, пишет The Guardian.
  - (2026-08-10) «„Яблоко“ предложило проголосовать за мир — поэтому его пытаются снять с выборов». Явлинский выступил в поддержку своей партии | LEDE: Председатель федерального политического комитета «Яблок] (ru: «„Я…
      Председатель федерального политического комитета «Яблока» Григорий Явлинский опубликовал пост в поддержку своей партии, пока Верховный суд рассматривает иск о снятии ее с выборов.
  - (2026-08-10) Война. 1629-й день. Больше 450 дронов атаковали регионы России. В Нижнекамске 13 погибших и десятки раненых | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-ук] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-08-10) Россиян стали задерживать за фотографии могил российских военных. Некоторым предъявляют обвинения в госизмене | LEDE: В России участились случаи показательных задержаний людей, которые фотог] (ru: Рос…
      В России участились случаи показательных задержаний людей, которые фотографировали могилы на кладбищах, рассказал редактор «Медиазоны» Дмитрий Трещанин. Впоследствии жителей нескольких регионов силовики заставляли извиня…
  - (2026-08-10) Верховный суд РФ начал рассматривать иск с требованием снять «Яблоко» с выборов в Госдуму. Поддержать партию пришли сотни человек | LEDE: У Верховного суда РФ в Москве собралась очередь из с] (ru: Вер…
      У Верховного суда РФ в Москве собралась очередь из сотен человек, пришедших поддержать партию «Яблоко», которую требуют снять с выборов в Госдуму.

### Ukraine Theater (total-war monitoring) — 510 new of 776 total
  - (2026-08-10) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-09) [FIRMS] thermal anomaly 44.942, 34.074 (FRP 1.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 1.9 MW
  - (2026-08-09) [FIRMS] thermal anomaly 45.564, 34.819 (FRP 5.3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 5.3 MW
  - (2026-08-09) [FIRMS] thermal anomaly 44.394, 28.579 (FRP 5.63 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 5.63 MW
  - (2026-08-09) [FIRMS] thermal anomaly 44.393, 28.574 (FRP 5.63 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 5.63 MW
  - (2026-08-09) [FIRMS] thermal anomaly 45.257, 31.672 (FRP 9.1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 9.1 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 185 new of 211 total
  - (2026-08-10) Cover Story: China’s Drive to Shore Up Social Security Funds Brings a Payroll Shock - Caixin Global
      Cover Story: China’s Drive to Shore Up Social Security Funds Brings a Payroll Shock Caixin Global
  - (2026-08-10) 新加坡举行国庆庆典--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE5EVlFnODVxbTVsQ3FnZjRDUFVUVnFOUm9CVmpiREh6RUpYX2ZBNUJUUEV4NjZuc18xb1ppZ2xDTzBYenIyeTJadmFVSkNFLWtmOHpyOUJ] (zh:…
      新加坡举行国庆庆典--国际 人民网
  - (2026-08-10) 菲律宾吕宋岛山体滑坡致4人死亡--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFBDZVY3ZlduOFFzY3FZVElUVUp3UjdyZXBKMlExa19hLXZaVVotT3dXamI1NlVYeXoyZUstU0lxYTdBakluYm1TRlpMblhsdFpIM] (zh:…
      菲律宾吕宋岛山体滑坡致4人死亡--国际 人民网
  - (2026-08-10) 泰国暖武里府行政组织办公楼发生枪击主席重伤--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE05ZDNGcmtsWVFLcDFTMnJXUmVNYmpEdkVTcHNVelZGbVJhSE9XTmxMSU1ZMWh2RGlVRlBTYmFCZ2d0TzJPVjhadjF3bHB] (zh:…
      泰国暖武里府行政组织办公楼发生枪击主席重伤--国际 人民网
  - (2026-08-10) 福建省税务局任命2名干部 - 人民网-福建频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9xVHdZd2ZmSTdQZ2RocUtBZWNPODdDbXNnQzdsaUs4ZFNSVVQySkFBUWJFOVZZMGZteE5lQUEtSDdkTk5JZmt6VW80T0VEc1hYSGJ] (zh:…
      福建省税务局任命2名干部 人民网-福建频道
  - (2026-08-09) 伊朗最高领袖任命佐勒加德尔为其政治顾问--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE5VRHdxS0NnbnVwa0lNZkJDM29BaVdoclZwYnV4QXlFdGdjenBhZHphQnhpN3lnY1o1SksySFZaSWljenhwQ1dLNWRxMEE2Z] (zh:…
      伊朗最高领袖任命佐勒加德尔为其政治顾问--国际 人民网

### Local News: St. Louis + Atlanta — 115 new of 172 total
  - (2026-08-10) [St. Louis] Lou’s Clues – 8/10/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-08-10) [Atlanta] An arts school where Epstein allegedly preyed on students reveals decades of abuse
  - (2026-08-10) [Atlanta] Mike Lindell touts Trump ties in race for governor of Minnesota, where Trump has lost
  - (2026-08-10) [Atlanta] In a competitive Maine Senate race, women voters could be the deciders
  - (2026-08-10) [Atlanta] Voters are sick of the two-party system. A new poll shows they're open to big changes
  - (2026-08-10) [Atlanta] Who really needs testosterone?

### U.S. Weather + Severe / Climate Outlooks — 105 new of 131 total
  - (2026-08-10) [Moderate] Heat Advisory: Heat Advisory issued August 10 at 4:29AM CDT until August 10 at 8:00PM CDT by NWS Jackson MS
      * WHAT...Heat index values up to 107 expected. * WHERE...Portions of southeast Arkansas, northeast Louisiana, and central, north central, northwest, southwest, and west central Mississippi. * WHEN...From 11 AM this morni…
  - (2026-08-10) [Moderate] Heat Advisory: Heat Advisory issued August 10 at 4:29AM CDT until August 10 at 8:00PM CDT by NWS Jackson MS
      * WHAT...Heat index values up to 107 expected. * WHERE...Copiah, Hinds, Holmes, Madison MS, Yazoo, and Lincoln Counties. * WHEN...From 11 AM this morning to 8 PM CDT this evening. * IMPACTS...Hot temperatures and high hu…
  - (2026-08-10) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 10 at 5:27AM EDT until August 10 at 6:15AM EDT by NWS Detroit/Pontiac MI
      At 526 AM EDT, severe thunderstorms were located along a line extending from near Pinckney to near Tecumseh, moving east at 40 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, s…
  - (2026-08-10) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-10) [Severe] Flood Watch: Flood Watch issued August 10 at 2:24AM MST until August 10 at 10:00PM MST by NWS Tucson AZ
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of Southeast Arizona, including the following areas, Baboquivari Mountains, Catalina and Rincon Mountains, South Central…
  - (2026-08-10) [Moderate] Special Weather Statement: Special Weather Statement issued August 10 at 5:09AM EDT by NWS Detroit/Pontiac MI
      At 509 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Brooklyn to near Onsted to near Clayton. Movement was east at 40 mph. HAZARD...Wind gusts up to 50 mph and penny size hail.…

### State-Level News — 85 new of 199 total
  - (2026-08-09) [Arkansas] Arkansas’ Medicaid expansion is endangered. Again.
      Months before Arkansas lawmakers convened for their 2013 legislative session, the thought that the state would expand Medicaid was almost laughable. Republicans had just won a majority in both chambers of the Legislature…
  - (2026-08-09) [Arkansas] More states ban child marriage, though it’s still legal in most of the US
      After authorities rescued 16 children last month who had been confined to a single room in a home in rural Ohio, attention turned to their mother, who had been 15 and pregnant when she married their father. The child end…
  - (2026-08-09) [Arkansas] As Trump pushes for a massive $1.5T in defense spending, a few states brace for a windfall
      WASHINGTON — Congress is considering a hike of hundreds of billions in dollars in defense spending, which would represent a surge in military funding not seen since World War II. Whatever the exact level of spending ulti…
  - (2026-08-10) [Connecticut] The abandoned — CT’s talented and gifted students
      <img width="913" height="587" src="https://ctmirror.org/wp-content/uploads/2026/08/bored-student-thomas-park-unsplast.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetch…
  - (2026-08-10) [Connecticut] Ned Lamont finds places to speak Sunday; less so for Josh Elliott
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/0809-CT01-EVENTS-LAMONT-0809-SG-06-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decodin…
  - (2026-08-10) [Connecticut] In final days, Dems seeking 1st District seat take message to voters
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/0809-CT01-EVENTS-0809-SG-04-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="asyn…

### State Legislative Action — 52 new of 64 total
  - (2026-08-09) [California AB 2639] Merced County Flood Control District: assessment.
      Existing law, the Merced County Flood Control District Act, establishes the Merced County Flood Control District to control the flood and stormwaters of the district, which consists of all the territory of the County of…
  - (2026-08-09) [California AB 353] Public Utilities Commission: Inspector General.
      Existing law requires the Public Utilities Commission to appoint a chief internal auditor who holds office at the pleasure of the commission. Existing law makes the chief internal auditor responsible for the oversight of…
  - (2026-08-09) [California AB 2195] Child support: license suspensions.
      Existing law delegates to the Department of Child Support Services and local child support agencies the responsibility for collecting and enforcing child support obligations, including child support delinquencies, as def…
  - (2026-08-09) [California AB 1881] California Indian Freedom Act of 2026.
      Existing law establishes various protections for California Native American tribes, including prohibiting a public agency or private party using or occupying public property or operating on public property from interferi…
  - (2026-08-09) [California AB 1732] California Environmental Quality Act: exemption: affordable housing projects: public university or public college housing projects.
      The California Environmental Quality Act (CEQA) requires a lead agency, as defined, to prepare, or cause to be prepared, and certify the completion of, an environmental impact report on a project that it proposes to carr…
  - (2026-08-09) [California AB 2058] California Factory-Built Housing Law: inspection: permitting.
      (1) Existing law, the California Factory-Built Housing Law, requires all factory-built housing manufactured after a specified date that is sold or offered for sale to first users within the state to bear insignia of appr…

### Ukrainian Internal News (national + local Kyiv) — 50 new of 106 total
  - (2026-08-10) Понад 60% українців довіряють Залужному і Федорову, Зеленський на 4 місці – КМІС | LEDE: Залужний і Федоров — лідери довіри серед українців. Опитування КМІС: результати довіри до політиків у ли] (uk:…
      Залужний і Федоров — лідери довіри серед українців. Опитування КМІС: результати довіри до політиків у липні 2026 року.
  - (2026-08-10) У Данії фіксують рекордні перебої з GPS – підозрюють Росію | LEDE: У Данії у 2026 році зафіксували рекордні перебої з сигналом GPS в районі острова Борнхольм, є обгрунтовані підстави підозрюват] (uk:…
      У Данії у 2026 році зафіксували рекордні перебої з сигналом GPS в районі острова Борнхольм, є обгрунтовані підстави підозрювати Росію.
  - (2026-08-10) У Києві на Виноградарі машина провалилася під землю: прорвало водопровід | LEDE: На Білицькій у Києві через прорив труби провалилось авто, обмежено рух та відсутнє водопостачання.] (uk: У Києві на Вин…
      На Білицькій у Києві через прорив труби провалилось авто, обмежено рух та відсутнє водопостачання.
  - (2026-08-10) Абсолютна більшість українців вірять, що Україна переможе у війні | LEDE: Більше 80% українців вважають, що Україна вийде переможницею із війни проти Росії.] (uk: Абсолютна більшість українців вірять,…
      Більше 80% українців вважають, що Україна вийде переможницею із війни проти Росії.
  - (2026-08-10) В уряді Німеччини хочуть оперативно покращити захист аеропортів від дронів | LEDE: ] (uk: В уряді Німеччини хочуть оперативно покращити захист аеропортів від дронів)
  - (2026-08-10) Росіяни вранці обстріляли Бугаївку на Харківщині: загинули 5 людей | LEDE: Внаслідок обстрілу Бугаївки у Харківській області 10 серпня загинуло п'ятеро людей, розпочато розслідування] (uk: Росіяни вра…
      Внаслідок обстрілу Бугаївки у Харківській області 10 серпня загинуло п'ятеро людей, розпочато розслідування

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-08-10) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (47.7717, 1.9495) · alt: 6621m · 797km/h
  - (2026-08-10) PUMAA (France)
      icao24: 39ddf7 · position: (44.5352, 5.5004) · alt: 1356m · 111km/h
  - (2026-08-10) FAF7813 (France)
      icao24: 39a842 · position: (47.8427, 5.1481) · alt: 2743m · 311km/h
  - (2026-08-10) CFC2981 (Canada)
      icao24: c2b5b7 · position: (52.0427, 17.2645) · alt: 7315m · 646km/h
  - (2026-08-10) GAF678 (Germany)
      icao24: 3e0f77 · position: (52.5779, 12.7724) · alt: 441m · 192km/h
  - (2026-08-10) SAMU06 (France)
      icao24: 39c901 · position: (43.6974, 7.2262) · on ground

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-10) [Taiwan Strait + South China Sea · themes] 从10 % 到2 . 3 %： 三年利润率腰斩 ， BBA告别豪车暴利时代 - 商业消费 - ITBear科技资讯
      itbear.com.cn · Chinese · tone NA
  - (2026-08-10) [Taiwan Strait + South China Sea · themes] 50 Jahre Bowie in Berlin : Er kam zum Cleanwerden - Weltspiegel - Reutlinger General - Anzeiger
      gea.de · German · tone NA
  - (2026-08-10) [Taiwan Strait + South China Sea · themes] ¿ Quién vigila en Rodalies ?, por Enric Sierra
      lavanguardia.com · Spanish · tone NA
  - (2026-08-10) [Taiwan Strait + South China Sea · themes] Deadly tropical storms and monsoon batter Philippines
      westernadvocate.com.au · English · tone NA
  - (2026-08-10) [Taiwan Strait + South China Sea · themes] 생선도 못 먹겠네 … 고수온에 물고기 줄폐사 위기 [ 세상 &]
      biz.heraldcorp.com · Korean · tone NA
  - (2026-08-10) [Taiwan Strait + South China Sea · themes] 马斯克的芯片梦 ， 要靠这个清华人来落地
      163.com · Chinese · tone NA

### Paper Trading Scorecard — 19 new of 128 total
  - (2026-08-10) [Polymarket] Will a ≤5% Uranium Enrichment Cap (1+ Year) be in a US-Iran deal in 2026?
      This market resolves to “Yes” if a written diplomatic instrument between the United States and Iran that establishes a percentage cap of 5% or less on the purity level to which Iran may enrich uranium, committed to for a…
  - (2026-08-10) [Polymarket] Will Trump be impeached by end of 2026?
      This market will resolve to “Yes“ if the US House of Representatives by simple majority vote to approve or pass one or more articles of impeachment of President Donald Trump, between July 24, 2025, and December 31, 2026,…
  - (2026-08-10) [Polymarket] Will MicroStrategy be margin called in 2026?
      This market will resolve to "Yes" if MicroStrategy incorporated is margin called on any of its Bitcoin-backed loans by December 31, 2026, 11:59 PM ET, resulting in either a forced liquidation of Bitcoin by a lender or Mi…
  - (2026-08-10) [Polymarket] NYSE marketwide circuit breaker before 2027?
      This market will resolve to "Yes" if a marketwide circuit breaker is triggered on the New York Stock Exchange (NYSE) at any time between November 7, 2025, and December 31, 2026. Otherwise, this market will resolve to “No…
  - (2026-08-10) [Polymarket] Will Parti libéral du Québec win the most seats in the 2026 Quebec general election?
      Parliamentary elections to elect all 125 seats of the National Assembly of Quebec are scheduled to take place in Quebec on October 5, 2026. This market will resolve to the political party that wins the greatest number of…
  - (2026-08-10) [Manifold] Will Elon Musk reach 243 M+ followers on X before 20th August?

### GDACS — global disaster alerts — 18 new of 269 total
  - (2026-08-07) [Orange] Forest fires in Spain
      Wildfire · Orange alert · Spain · Orange impact for forestfire in 13744 ha
  - (2026-08-07) [Orange] Forest fires in Spain
      Wildfire · Orange alert · Spain · Orange impact for forestfire in 13744 ha
  - (2026-08-10) [Green] Earthquake in East Central Pacific Ocean
      Earthquake · Green alert · East Central Pacific Ocean · Magnitude 5.5M, Depth:10km
  - (2026-08-10) [Green] Earthquake in East Central Pacific Ocean
      Earthquake · Green alert · East Central Pacific Ocean · Magnitude 5.5M, Depth:10km
  - (2026-08-10) [Green] Tropical Cyclone FIFTEEN-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 65 km/h)
  - (2026-08-10) [Green] Tropical Cyclone FIFTEEN-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 65 km/h)

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-08-10) M 5.5 - east central Pacific Ocean
      M5.5 · east central Pacific Ocean · depth 10 km
  - (2026-08-09) M 5.3 - 197 km SSW of Pagar Alam, Indonesia
      M5.3 · 197 km SSW of Pagar Alam, Indonesia · depth 35 km
  - (2026-08-09) M 5.2 - Galapagos Triple Junction region
      M5.2 · Galapagos Triple Junction region · depth 10 km
  - (2026-08-09) M 5.0 - 206 km SE of Sarangani, Philippines
      M5.0 · 206 km SE of Sarangani, Philippines · depth 35 km
  - (2026-08-10) M 4.9 - 88 km ENE of Hihifo, Tonga
      M4.9 · 88 km ENE of Hihifo, Tonga · depth 10 km
  - (2026-08-09) M 4.9 - 211 km SE of Sarangani, Philippines
      M4.9 · 211 km SE of Sarangani, Philippines · depth 35 km

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-08-07) U.S. Court of Appeals, 1st Cir.: Guzman v. Blanche
  - (2026-08-07) U.S. Court of Appeals, 1st Cir.: Woonasquatucket River Watershed Council v. USDA
  - (2026-08-06) U.S. Court of Appeals, 1st Cir.: United States v. Cooper
  - (2026-08-06) U.S. Court of Appeals, 4th Cir.: PSEG Renewable Transmission LLC v. Arentz Family, LP
  - (2026-08-06) U.S. Court of Appeals, 4th Cir.: United States v. Robert Boyd
  - (2026-08-06) U.S. Court of Appeals, 5th Cir.: Eqbal v. Blanche

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-10) LoL: Hanwha Life Esports vs Gen.G (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 100% · 24h volume: $1,988,208 · resolves 2026-08-10
  - (2026-08-10) LoL: Hanwha Life Esports vs Gen.G - Game 2 Winner
      yes price: 100% · 24h volume: $894,330 · resolves 2026-08-10
  - (2026-08-10) Will Josh Stein win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $733,895 · resolves 2028-11-07
  - (2026-08-10) LoL: Hanwha Life Esports vs Gen.G - Game 1 Winner
      yes price: 0% · 24h volume: $541,664 · resolves 2026-08-10
  - (2026-08-10) Will there be no change in Fed interest rates after the September 2026 meeting?
      yes price: 64% · 24h volume: $307,764 · resolves 2026-09-16
  - (2026-08-10) Will Kai and Speed beat the Minecraft challenge by August 17?
      yes price: 14% · 24h volume: $295,960 · resolves 2026-08-17

### IT, InfoSys & cybersecurity news (last 7 days) — 10 new of 51 total
  - (2026-08-10) [The Hacker News] Solidity Pro VS Code Extensions Steal Crypto Wallets, API Keys, and Credentials
      Cybersecurity researchers have flagged a malicious Microsoft Visual Studio Code (VS Code) extension named Solidity Pro ("solidity-pro") that has been observed delivering a browser wallet and credential stealer. The names…
  - (2026-08-10) [The Hacker News] OpenAI's Next AI Model Astra Shows Cyber Performance Strong Enough to Trigger Pause
      OpenAI has announced that it's pausing some "internal activities" involving its upcoming artificial intelligence (AI) model Astra after an internal evaluation found it had made significant advancements in agentic coding…
  - (2026-08-10) [MIT Technology Review] AI for science needs reasoning, not just data
      Every few decades, someone announces that science has reached its end. In 1903, the revered physicist Albert Michelson wrote that the “facts of physical science have all been discovered.” In the 1980s, Stephen Hawking pr…
  - (2026-08-10) [MIT Technology Review] These startups are chasing the next big thing in LLMs
      MIT Technology Review’s What’s Next series looks across industries, trends, and technologies to give you a first look at the future. You can read the rest of them here. Way back in the summer of 2017, AI researchers at G…
  - (2026-08-09) [Ars Technica] Mount Toba eruption doesn't seem like it could nearly kill our species
      The massive Toba eruption seems to have had little climate impact.
  - (2026-08-09) [TechCrunch] Embattled hedge fund Situational Awareness invests $400M in chip startup Source Foundry
      The AI-focused hedge fund is still making some big bets.

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-10) [Marginal Revolution] Do Faculty Affect Student Partisanship?
      We study whether Democratic college professors make their students more liberal. We link voter data to salary records from 33 state flagships and show that faculty skew Democratic, especially in the humanities and social…
  - (2026-08-10) [Marginal Revolution] Act like it is science
      I am seeing so many doom prognostications, or least severe worries, due to the OAI/HuggingFace incident and related stories. But virtually all of these I find underargued to say the least. So I have a simple request. If…
  - (2026-08-09) [Marginal Revolution] Sunday assorted links
      1. African use of Chinese AI (NYT). And what happened to Talenti gelato? (NYT) And the NIMBY brutalists who live in the Barbican (NYT). 2. Modernist Gothic in Copenhagen. 3. AI-generated Odyssey in Vietnam. 4. Questions…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 32 total
  - (2026-08-10) MOVER ▲ Amancio Ortega — $148.59B (+$0.34B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-10) MOVER ▲ Bernard Arnault & family — $149.41B (+$0.27B since yesterday)
      France · Fashion & Retail · source: LVMH

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-10) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: service, procedures, program, final, standards, notice, safety, certain, regulatory, production, proposed, amendment
- state_bills: today=64, 7d-median=108, 14d-median=118; carrying terms: operate, adopt, purposes, transfer, except, authority, business, procedures, approval, authorizes, activities, implement
- state_news: today=199, 7d-median=717, 14d-median=738; carrying terms: republican, forbidden, market, three, challenges, beyond, something, rising, permalink, ballot, calls, block
- local_news: today=172, 7d-median=239, 14d-median=234; carrying terms: concerns, three, death, people, grand, google, charges, south, neighborhood, senate, content, month
- foreign_news: today=919, 7d-median=1034, 14d-median=1028; carrying terms: concerns, delhi, market, forbidden, stresses, holiday, locals, three, breaks, economy, rising, hardware
- chinese_internal: today=211, 7d-median=261, 14d-median=264; carrying terms: people, caixin, google, chinese, https, china, price, global, color, cbmiaefvx, cbmix, blank
- russian_internal: today=813, 7d-median=1056, 14d-median=940; carrying terms: forbidden, russian, wildberries, gazeta, httperror, insider, https, client, novayagazeta, novaya, found, times
- ukrainian_internal: today=106, 7d-median=106, 14d-median=124; carrying terms: forbidden, correspondents, three, attack, casualties, wildberries, people, combat, kyivindependent, prime, strike, offering
- ukraine_theater: today=776, 7d-median=701, 14d-median=738; carrying terms: extra, liveuamap, snapshot, viirs, firms, cartography, httperror, active, deepstatemap, token, google, https
- paper_bets: today=128, 7d-median=138, 14d-median=139; carrying terms: zohran, lifetime, rippling, market, republican, washington, majors, succeed, october, supervolcano, wisconsin, romania
- weather: today=131, 7d-median=168, 14d-median=174; carrying terms: below, rapidly, washington, fires, dangerously, houston, cyclones, updated, mount, heavy, sensitive, locations
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, unemployment, pcepilfe, inflation, walcl, payems, vixcls, consumption, balance, unrate, sheet, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: silver, treasury, crypto, corporate, bitcoin, equities, china, close, proxy, credit, russell, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=99, 14d-median=102; carrying terms: qaida, haitian, committees, sanctions, oblasts, space, laboratory, federation, authorities, burma, extra, proliferation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, httperror, unauthorized, client, https, quantitative, error, congresstrading, quiver
- billionaires: today=32, 7d-median=37, 14d-median=37; carrying terms: brokerage, spacex, devasini, zhang, meyers, china, trading, euronext, googl, amazon, gates, yiming
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: delaware, supreme, court, county, johnson, appeals, blanche, energy, company, group, corporation, elizabeth
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, michael, richard, therapeutics, william, brian, daniel, group, jackson
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: johnson, elect, cortez, filing, angels, krishnamoorthi, robert, platner, david, committee, senate, ocasio
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, japan, china
- gdelt_gkg: today=25, 7d-median=50, 14d-median=36; carrying terms: english, spanish, russian, themes, hormuz, chinese, china, strait, baidu, baijiahao, german, portuguese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=26, 14d-median=18; carrying terms: position, canada, belgium, ground, france, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: rapidly, given, rwampara, mechanical, adult, additi, poliovirus, increasing, poultry, cambodia, arachidonic, mongbwalu
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: secure, langflow, fortios, authentication, arista, exposure, velocloud, management, vulnerability, actor, fortinet, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=269, 7d-median=233, 14d-median=236; carrying terms: maximum, sweden, cambodia, ukraine, dolphin, australia, ecuador, china, ethiopia, fires, macedonia, nicaragua
- usgs_quakes: today=16, 7d-median=13, 14d-median=15; carrying terms: depth, islands, region, philippines, indonesia, sarangani, zealand, south, papua, tonga, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: september, effective, august, volume, ceasefire, price, resolves, returns, strait, hormuz, normal, prime
- commentary: today=6, 7d-median=6, 14d-median=5; carrying terms: marginal, economist, class, conversable, revolution, https, conversableeconomist, strong, marginalrevolution, college, published, journal
- tech_news: today=51, 7d-median=56, 14d-median=56; carrying terms: three, attack, pushed, models, hackers, people, systems, report, steal, infrastructure, cyber, paper
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: aumua, kevin, randall, whitesides, malliotakis, zinke, vicente, casar, pramila, marlin, mcdowell, latta
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, paper, market, decision, placed, sufficient, unavailable, module, evidence, either, placement, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*