# WORLDSCOPE morning brief — 2026-08-10

## Headline
2814 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (670) · Russian Internal News (state + in-exile) (612) · Ukraine Theater (total-war monitoring) (504) · World leaders & government officials (324) · Chinese Internal News (186) · Local News: St. Louis + Atlanta (114) · U.S. Weather + Severe / Climate Outlooks (103) · State-Level News (66) · Ukrainian Internal News (national + local Kyiv) (49) · Conflict & unrest (GDELT, last 48h) (40) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (29)

## What changed today
### International News + Multilateral Institutions — 670 new of 919 total
  - (2026-08-09) [Global] Canadian government steps in as ‘out of control’ wildfires force thousands to flee
  - (2026-08-10) [Global] Typhoon Dolphin: more than a million people evacuated in China as record rainfall dumped on Shanghai
  - (2026-08-10) [Global] Hong Kong records hottest day ever as Typhoon Dolphin fuels heatwave
  - (2026-08-09) [Global] Typhoon Dolphin makes landfall in China as its strongest storm this year
  - (2026-08-09) [Global] Chinese EV sales surge to new high in Europe putting tariffs under scrutiny
  - (2026-08-10) [Global] SA premier announces royal commission into AI – as it happened

### Russian Internal News (state + in-exile) — 612 new of 798 total
  - (2026-08-10) Верховный суд РФ начал рассматривать иск с требованием снять «Яблоко» с выборов в Госдуму. Поддержать партию пришли сотни человек | LEDE: У Верховного суда РФ в Москве собралась очередь из с] (ru: Вер…
      У Верховного суда РФ в Москве собралась очередь из сотен человек, пришедших поддержать партию «Яблоко», которую требуют снять с выборов в Госдуму.
  - (2026-08-10) В Нижнекамске погибли 13 человек в результате атаки украинских дронов | LEDE: В результате атаки украинских дронов по Нижнекамску погибли 12 человек, 39 человек получили ранения. Об этом соо] (ru: В Н…
      В результате атаки украинских дронов по Нижнекамску погибли 12 человек, 39 человек получили ранения. Об этом сообщили в пресс-службе главы республики Татарстан 10 августа.
  - (2026-08-10) Более 60 тысяч жителей Приднестровья подали заявление на гражданство России. С мая их рассматривают в упрощенном порядке | LEDE: За последние три месяца жители непризнанного Приднестровья по] (ru: Бол…
      За последние три месяца жители непризнанного Приднестровья подали более 60 тысяч заявлений на получение российского гражданства в упрощенном порядке. Об этом «Известиям» рассказал глава самопровозглашенной республики Вад…
  - (2026-08-10) Издательства останавливают поставки книг на Wildberries на фоне атак украинских беспилотников | LEDE: Российские книжные издательства — как крупные, так и независимые — приостанавливают прод] (ru: Изд…
      Российские книжные издательства — как крупные, так и независимые — приостанавливают продажу своей продукции на Wildberries на фоне атак украинских беспилотников по складам маркетплейса. Об этом пишет «Коммерсант», ссылая…
  - (2026-08-10) На Камчатке из-за ремонта кабеля на четыре дня полностью отключат интернет | LEDE: В Камчатском крае на несколько дней отключат весь интернет — как мобильный, так и домашний. Это связано с р] (ru: На…
      В Камчатском крае на несколько дней отключат весь интернет — как мобильный, так и домашний. Это связано с ремонтом подводной волоконно-оптической линии, сообщается на сайте местного правительства.
  - (2026-08-10) Больше 450 беспилотников атаковали 16 регионов России и Крым. Украинские телеграм-каналы сообщают о пожаре на НПЗ в Нижнекамске | LEDE: Украинские беспилотники утром 10 августа атаковали Ниж] (ru: Бол…
      Украинские беспилотники утром 10 августа атаковали Нижнекамск, пишет Astra со ссылкой на местных жителей. Мэр города Радмир Беляев в 5:30 утра сообщил о беспилотной опасности, но никаких подробностей не привел.

### Ukraine Theater (total-war monitoring) — 504 new of 776 total
  - (2026-08-10) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-09) [FIRMS] thermal anomaly 44.942, 34.074 (FRP 1.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 1.9 MW
  - (2026-08-09) [FIRMS] thermal anomaly 45.564, 34.819 (FRP 5.3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 5.3 MW
  - (2026-08-09) [FIRMS] thermal anomaly 44.394, 28.579 (FRP 5.63 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 5.63 MW
  - (2026-08-09) [FIRMS] thermal anomaly 44.393, 28.574 (FRP 5.63 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 5.63 MW
  - (2026-08-09) [FIRMS] thermal anomaly 45.257, 31.672 (FRP 9.1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-09 1011Z, FRP 9.1 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 186 new of 208 total
  - (2026-08-09) 反腐记｜宋致远被查 张建华领刑 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE11YXBDM0UwcHFKWTh4N1ZCejlhQVNfWEN4S2x3bmY3am81VkVtZ2xvYmd1SHFUMjhhZF9wLVZiTXhmZ0hBWE5sbFBQ] (zh:…
      反腐记｜宋致远被查 张建华领刑 china.caixin.com
  - (2026-08-09) 被爆炒、高溢价 QDII、国投白银LOF明确被退市 - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5kRlJxWmRiUzZDak5CSmtGa2c5eU8yN2hvTVhsVVNHTmdJaV95MERtSWpmMHNSRllySlJoN3Y2aTU2] (zh:…
      被爆炒、高溢价 QDII、国投白银LOF明确被退市 finance.caixin.com
  - (2026-08-09) 财经早知道｜公积金最高可贷340万元，北京楼市新政超预期 - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBYcUc0aWM0TUVTVHVlc1ZlTlVJRUNiVlFXLUQwT1BxcmRxcldUOW5Sb1paQzZsUE40SFJRZURUe] (zh:…
      财经早知道｜公积金最高可贷340万元，北京楼市新政超预期 finance.caixin.com
  - (2026-08-09) 河南西平“7.30”刑案嫌犯落网 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBxRzVoanN3dnJicGpYVFlqd1lGUmt0a1JkbzNYcGU4UDNINmNqalAwX2FrR1c5QWxjLTJFMFpVTExRbkw5Q0ZFYlF] (zh:…
      河南西平“7.30”刑案嫌犯落网 china.caixin.com
  - (2026-08-08) 离岸信托90天补税窗口期疑问 - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5MRWxmeHNydEF1d3JMTS05QWluelI4RjU0M1BldlRWLWFQU0pwZUxmYVlNUWlfMTIzc1Z2bk9YQkpvaEM3UnRiTkR] (zh:…
      离岸信托90天补税窗口期疑问 finance.caixin.com
  - (2026-08-09) 债务 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE00b3psWDJJS3plWU9kby1XRlJ2bjZ1SERKQ2ZVZEFnREhmSDJodk9ldW9JZk1ELWJCMzVvQlZ6TG9pX3dZOEZRSGN0MlFZNGM1X2] (zh:…
      债务 deepview.caixin.com

### Local News: St. Louis + Atlanta — 114 new of 183 total
  - (2026-08-10) [St. Louis] Lou’s Clues – 8/10/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-08-10) [St. Louis] PROJECT ADDS A SPLASH OF COLOR
      Artist Amy Miller paints an aquarium scene on a traffic box on Friday at an island on South Compton and Choutaeau Avenues in the Prospect Yards neighborhood of St. Louis. Miller is one of several artists who have been co…
  - (2026-08-10) [St. Louis] Trump faces uphill legal fight on citizenship rights
      U.S. President Donald Trump, with White House Deputy Chief of Staff Stephen Miller and U.S. Secretary of Commerce Howard Lutnick, speaks Thursday during an event to sign executive orders related to birthright citizenship…
  - (2026-08-10) [St. Louis] LAW AND ORDER
      Accident reconstruction investigators work the scene a fatal crash Sunday at Hall Street and Gimblin Road after a two vehicles collided around 8:40 a.m. that morning.
  - (2026-08-10) [St. Louis] BROWN REMEMBERED ON 12TH ANNIVERSARY OF HIS DEATH
      Frontline Ferguson protestor LaShell Eikerenkoetter remembers Michael Brown Jr. at a memorial service on Sunday, Aug. 9, 2026, the 12th anniversary of his death, in Ferguson. Michael Brown Jr. was 18 years old when he wa…
  - (2026-08-10) [St. Louis] Son Hunter: Biden's cancer has spread beyond bones
      Former President Joe Biden speaks on June 5 in Sioux Falls, S.D.

### U.S. Weather + Severe / Climate Outlooks — 103 new of 132 total
  - (2026-08-10) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-10) [Severe] Red Flag Warning: Red Flag Warning issued August 10 at 2:23AM MDT until August 10 at 9:00PM MDT by NWS Riverton WY
      The National Weather Service in Riverton has issued a Red Flag Warning, which is in effect from noon today to 9 PM MDT this evening. * IMPACTS: Low Humidities...Hot Temperatures...Strong Gusty Winds...and Dry Thunderstor…
  - (2026-08-10) [Severe] Red Flag Warning: Red Flag Warning issued August 10 at 2:23AM MDT until August 10 at 9:00PM MDT by NWS Riverton WY
      The National Weather Service in Riverton has issued a Red Flag Warning, which is in effect from noon today to 9 PM MDT this evening. * IMPACTS: Low Humidities...Hot Temperatures...Strong Gusty Winds...and Dry Thunderstor…
  - (2026-08-10) [Severe] Red Flag Warning: Red Flag Warning issued August 10 at 2:23AM MDT until August 10 at 9:00PM MDT by NWS Riverton WY
      The National Weather Service in Riverton has issued a Red Flag Warning, which is in effect from noon today to 9 PM MDT this evening. * IMPACTS: Low Humidities...Hot Temperatures...Strong Gusty Winds...and Dry Thunderstor…
  - (2026-08-10) [Severe] Red Flag Warning: Red Flag Warning issued August 10 at 2:23AM MDT until August 10 at 9:00PM MDT by NWS Riverton WY
      The National Weather Service in Riverton has issued a Red Flag Warning, which is in effect from noon today to 9 PM MDT this evening. * IMPACTS: Low Humidities...Hot Temperatures...Strong Gusty Winds...and Dry Thunderstor…
  - (2026-08-10) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 10 at 4:16AM EDT until August 10 at 4:30AM EDT by NWS Indianapolis IN
      At 415 AM EDT, severe thunderstorms were located along a line extending from near Delphi to 7 miles southeast of Lafayette to 9 miles east of Williamsport, moving southeast at 30 mph. HAZARD...60 mph wind gusts and quart…

### State-Level News — 66 new of 181 total
  - (2026-08-09) [Arkansas] Arkansas’ Medicaid expansion is endangered. Again.
      Months before Arkansas lawmakers convened for their 2013 legislative session, the thought that the state would expand Medicaid was almost laughable. Republicans had just won a majority in both chambers of the Legislature…
  - (2026-08-09) [Arkansas] More states ban child marriage, though it’s still legal in most of the US
      After authorities rescued 16 children last month who had been confined to a single room in a home in rural Ohio, attention turned to their mother, who had been 15 and pregnant when she married their father. The child end…
  - (2026-08-09) [Arkansas] As Trump pushes for a massive $1.5T in defense spending, a few states brace for a windfall
      WASHINGTON — Congress is considering a hike of hundreds of billions in dollars in defense spending, which would represent a surge in military funding not seen since World War II. Whatever the exact level of spending ulti…
  - (2026-08-10) [Florida] As Trump pushes for a massive $1.5T in defense spending, a few states brace for a windfall
      WASHINGTON — Congress is considering a hike of hundreds of billions in dollars in defense spending, which would represent a surge in military funding not seen since World War II. Whatever the exact level of spending ulti…
  - (2026-08-10) [Connecticut] The abandoned — CT’s talented and gifted students
      <img width="913" height="587" src="https://ctmirror.org/wp-content/uploads/2026/08/bored-student-thomas-park-unsplast.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetch…
  - (2026-08-10) [Connecticut] Ned Lamont finds places to speak Sunday; less so for Josh Elliott
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/0809-CT01-EVENTS-LAMONT-0809-SG-06-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decodin…

### Ukrainian Internal News (national + local Kyiv) — 49 new of 105 total
  - (2026-08-10) Росіяни вранці обстріляли Бугаївку на Харківщині: загинули 5 людей | LEDE: У понеділок 10 серпня обстріляли село Бугаївка Чугуївського району Харківської області, внаслідок чого загинули 5 люде] (uk:…
      У понеділок 10 серпня обстріляли село Бугаївка Чугуївського району Харківської області, внаслідок чого загинули 5 людей.
  - (2026-08-10) Скібіцький назвав дві головні цілі ракетних атак Росії на Київ та інші великі міста | LEDE: Росія атакує Київ, щоб зірвати виробництво балістики і БпЛА в ОПК; атаки впливають на війну РФ.] (uk: Скібіц…
      Росія атакує Київ, щоб зірвати виробництво балістики і БпЛА в ОПК; атаки впливають на війну РФ.
  - (2026-08-10) Прем’єр і президентка Молдови поклали на Росію відповідальність за вибух дрона у країні | LEDE: ] (uk: Прем’єр і президентка Молдови поклали на Росію відповідальність за вибух дрона у)
  - (2026-08-10) З квітня Росія зупинила виробництво "Кинджалів", щоб робити більше інших ракет – ГУР | LEDE: Росіяни з квітня місяця перестали випускати балістичні ракети "Кинджал" для того, щоб збільшити виро] (uk:…
      Росіяни з квітня місяця перестали випускати балістичні ракети "Кинджал" для того, щоб збільшити виробництво інших точніших видів ракет.
  - (2026-08-10) Прем’єр Ізраїлю відкинув запропонований США план роззброєння ХАМАС | LEDE: ] (uk: Прем’єр Ізраїлю відкинув запропонований США план роззброєння ХАМАС)
  - (2026-08-10) Скібіцький: РФ нарощує виробництво ракет, паузу в ударах навряд чи буде робити | LEDE: Росія збільшує випуск ракет для ударів по Україні, пауз у ракетних атаках не прогнозується — генерал ГУР М] (uk:…
      Росія збільшує випуск ракет для ударів по Україні, пауз у ракетних атаках не прогнозується — генерал ГУР МО Скібіцький.

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-10) [United Kingdom] The Dukes Of Hazzard star Ben Jones dies aged 84
      domain: stourbridgenews.co.uk · language: English · tone:
  - (2026-08-10) [India] L & T Finance Shares Rise 2 . 03 % in Today Session
      domain: moneycontrol.com · language: English · tone:
  - (2026-08-10) [Australia] Ayatollah vigils were mourning for a religious leader
      domain: irrigator.com.au · language: English · tone:
  - (2026-08-10) [United States] Wildfires burn across western US and Canada as residents are evacuated
      domain: wboc.com · language: English · tone:
  - (2026-08-10) [Australia] Ayatollah vigils were mourning for a religious leader
      domain: dailyadvertiser.com.au · language: English · tone:
  - (2026-08-10) [United States] Normalization of deviance : The real lesson of this summer Cyclospora outbreak
      domain: foodsafetynews.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-10) GAF627 (Germany)
      icao24: 3f6533 · position: (43.4806, 16.8668) · alt: 10668m · 916km/h
  - (2026-08-10) JAF56C (Bulgaria)
      icao24: 4520aa · position: (49.5972, 2.5357) · alt: 6362m · 735km/h
  - (2026-08-10) FAF7813 (France)
      icao24: 39a842 · position: (46.4032, 1.4735) · alt: 2743m · 311km/h
  - (2026-08-10) GAF124 (Germany)
      icao24: 3ea556 · position: (53.7509, 19.9343) · alt: 9441m · 800km/h
  - (2026-08-10) PUMA42 (Slovenia)
      icao24: 506e1f · position: (45.8778, 15.473) · alt: 731m · 183km/h
  - (2026-08-10) CFC2981 (Canada)
      icao24: c2b5b7 · position: (53.1847, 7.433) · alt: 7322m · 669km/h

### Paper Trading Scorecard — 19 new of 128 total
  - (2026-08-10) [Polymarket] US-Iran Final Nuclear Deal by September 30, 2026?
      On June 14, 2026, the United States and Iran announced a written diplomatic agreement, including a 60-day extendable period in which both countries committed to negotiate toward a “final deal” regarding Iran’s nuclear pr…
  - (2026-08-10) [Polymarket] Will a ≤5% Uranium Enrichment Cap (1+ Year) be in a US-Iran deal in 2026?
      This market resolves to “Yes” if a written diplomatic instrument between the United States and Iran that establishes a percentage cap of 5% or less on the purity level to which Iran may enrich uranium, committed to for a…
  - (2026-08-10) [Polymarket] Will Trump be impeached by end of 2026?
      This market will resolve to “Yes“ if the US House of Representatives by simple majority vote to approve or pass one or more articles of impeachment of President Donald Trump, between July 24, 2025, and December 31, 2026,…
  - (2026-08-10) [Polymarket] Will MicroStrategy be margin called in 2026?
      This market will resolve to "Yes" if MicroStrategy incorporated is margin called on any of its Bitcoin-backed loans by December 31, 2026, 11:59 PM ET, resulting in either a forced liquidation of Bitcoin by a lender or Mi…
  - (2026-08-10) [Polymarket] NYSE marketwide circuit breaker before 2027?
      This market will resolve to "Yes" if a marketwide circuit breaker is triggered on the New York Stock Exchange (NYSE) at any time between November 7, 2025, and December 31, 2026. Otherwise, this market will resolve to “No…
  - (2026-08-10) [Polymarket] Will Parti libéral du Québec win the most seats in the 2026 Quebec general election?
      Parliamentary elections to elect all 125 seats of the National Assembly of Quebec are scheduled to take place in Quebec on October 5, 2026. This market will resolve to the political party that wins the greatest number of…

### USGS earthquakes (M4.5+, past day) — 15 new of 15 total
  - (2026-08-10) M 5.5 - east central Pacific Ocean
      M5.5 · east central Pacific Ocean · depth 10 km
  - (2026-08-09) M 5.3 - 197 km SSW of Pagar Alam, Indonesia
      M5.3 · 197 km SSW of Pagar Alam, Indonesia · depth 35 km
  - (2026-08-09) M 5.2 - Galapagos Triple Junction region
      M5.2 · Galapagos Triple Junction region · depth 10 km
  - (2026-08-09) M 5.0 - 206 km SE of Sarangani, Philippines
      M5.0 · 206 km SE of Sarangani, Philippines · depth 35 km
  - (2026-08-10) M 4.9 - 88 km ENE of Hihifo, Tonga
      M4.9 · 88 km ENE of Hihifo, Tonga · depth 10 km
  - (2026-08-09) M 4.9 - 211 km SE of Sarangani, Philippines
      M4.9 · 211 km SE of Sarangani, Philippines · depth 35 km

### IT, InfoSys & cybersecurity news (last 7 days) — 13 new of 56 total
  - (2026-08-10) [The Hacker News] Solidity Pro VS Code Extensions Steal Crypto Wallets, API Keys, and Credentials
      Cybersecurity researchers have flagged a malicious Microsoft Visual Studio Code (VS Code) extension named Solidity Pro ("solidity-pro") that has been observed delivering a browser wallet and credential stealer. The names…
  - (2026-08-10) [The Hacker News] OpenAI's Next AI Model Astra Shows Cyber Performance Strong Enough to Trigger Pause
      OpenAI has announced that it's pausing some "internal activities" involving its upcoming artificial intelligence (AI) model Astra after an internal evaluation found it had made significant advancements in agentic coding…
  - (2026-08-10) [The Register] Smart glasses are only smart if we train them to be good. Then they'll be fantastic
      Just add smart humans – and a pinch of dog
  - (2026-08-10) [The Register] Demoralized developer's desperate hack came back to haunt him on LinkedIn
      A script that shouldn't have worked, on a project that never ended, for a company that hardly cared
  - (2026-08-10) [The Register] Linus Torvalds says AI has made 'huge' Linux kernel updates the new normal
      He’s not thrilled, but won’t let it delay the release of version 7.2
  - (2026-08-10) [The Register] Advertisers are trying to influence AI bots with secret ads
      PLUS: Hiveminds are emerging to hack the planet, and open-weight models are the new new red scare.

### GDACS — global disaster alerts — 11 new of 262 total
  - (2026-08-10) [Green] Earthquake in East Central Pacific Ocean
      Earthquake · Green alert · East Central Pacific Ocean · Magnitude 5.5M, Depth:10km
  - (2026-08-10) [Green] Earthquake in East Central Pacific Ocean
      Earthquake · Green alert · East Central Pacific Ocean · Magnitude 5.5M, Depth:10km
  - (2026-08-10) [Green] Tropical Cyclone FIFTEEN-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 56 km/h)
  - (2026-08-10) [Green] Tropical Cyclone FIFTEEN-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 56 km/h)
  - (2026-08-10) [Green] Tropical Cyclone FIFTEEN-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 56 km/h)
  - (2026-08-10) [Green] Tropical Cyclone FIFTEEN-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 56 km/h)

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-10) LoL: Hanwha Life Esports vs Gen.G (BO3) - KeSPA Cup Last Chance Qualifier
      yes price: 92% · 24h volume: $1,357,197 · resolves 2026-08-10
  - (2026-08-10) LoL: Hanwha Life Esports vs Gen.G - Game 2 Winner
      yes price: 100% · 24h volume: $805,356 · resolves 2026-08-10
  - (2026-08-10) Will Josh Stein win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $733,895 · resolves 2028-11-07
  - (2026-08-10) LoL: Hanwha Life Esports vs Gen.G - Game 1 Winner
      yes price: 0% · 24h volume: $486,816 · resolves 2026-08-10
  - (2026-08-10) Will there be no change in Fed interest rates after the September 2026 meeting?
      yes price: 64% · 24h volume: $334,365 · resolves 2026-09-16
  - (2026-08-10) Will the Iranian regime fall before 2027?
      yes price: 6% · 24h volume: $293,478 · resolves 2026-12-31

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 35 total
  - (2026-08-10) MOVER ▲ Bernard Arnault & family — $149.15B (+$0.68B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-10) MOVER ▼ Amancio Ortega — $148.24B ($-0.52B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-10) MOVER ▼ Tadashi Yanai & family — $67.84B ($-0.44B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-08-10) MOVER ▼ Mukesh Ambani — $91.18B ($-0.44B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-10) MOVER ▲ Francoise Bettencourt Meyers & family — $95.59B (+$0.06B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-08-07) U.S. Court of Appeals, 1st Cir.: Guzman v. Blanche
  - (2026-08-07) U.S. Court of Appeals, 1st Cir.: Woonasquatucket River Watershed Council v. USDA
  - (2026-08-06) U.S. Court of Appeals, 1st Cir.: United States v. Cooper
  - (2026-08-06) U.S. Court of Appeals, 8th Cir.: Kristine Williams v. MO Department of Corrections
  - (2026-08-06) U.S. Court of Appeals, 8th Cir.: Rustico Lacsina v. Todd Blanche

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-10) [Marginal Revolution] Do Faculty Affect Student Partisanship?
      We study whether Democratic college professors make their students more liberal. We link voter data to salary records from 33 state flagships and show that faculty skew Democratic, especially in the humanities and social…
  - (2026-08-10) [Marginal Revolution] Act like it is science
      I am seeing so many doom prognostications, or least severe worries, due to the OAI/HuggingFace incident and related stories. But virtually all of these I find underargued to say the least. So I have a simple request. If…
  - (2026-08-09) [Marginal Revolution] Sunday assorted links
      1. African use of Chinese AI (NYT). And what happened to Talenti gelato? (NYT) And the NIMBY brutalists who live in the Barbican (NYT). 2. Modernist Gothic in Copenhagen. 3. AI-generated Odyssey in Vietnam. 4. Questions…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-10) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: safety, program, service, certain, proposes, rulemaking, notice, proposing, action, final, amendment, standards
- state_bills: today=0, 7d-median=118, 14d-median=129; carrying terms: appropriations, otherwise, violation, agency, services, until, least, corporation, regulatory, respect, terms, annually
- state_news: today=181, 7d-median=717, 14d-median=758; carrying terms: saturday, though, according, bills, agency, services, tennessee, nearly, least, online, stands, longer
- local_news: today=183, 7d-median=239, 14d-median=230; carrying terms: according, nearly, north, weekend, fatal, atlanta, https, person, charged, restaurant, public, faces
- foreign_news: today=919, 7d-median=1034, 14d-median=1034; carrying terms: saturday, speed, conflict, forms, removal, parliamentary, staff, television, inspected, order, widespread, summer
- chinese_internal: today=208, 7d-median=261, 14d-median=261; carrying terms: https, google, people, chinese, china, global, caixin, price, cbmixkfvx, cbmiykfvx, cbmib, title
- russian_internal: today=798, 7d-median=1056, 14d-median=937; carrying terms: street, telegram, reuters, russian, httperror, client, forbidden, journal, novayagazeta, patriot, error, https
- ukrainian_internal: today=105, 7d-median=106, 14d-median=125; carrying terms: ministers, nearly, least, staff, ballistic, sweeping, patriot, https, court, damaged, region, combat
- ukraine_theater: today=776, 7d-median=701, 14d-median=701; carrying terms: https, daily, frontline, active, viirs, coverage, deepstatemap, token, google, cartography, unauthorized, httperror
- paper_bets: today=128, 7d-median=138, 14d-median=138; carrying terms: virginia, approve, announced, degrees, world, speed, according, otherwise, event, industrial, tennessee, least
- weather: today=132, 7d-median=168, 14d-median=173; carrying terms: angeles, saturday, degrees, details, peachtree, please, normal, afdmeg, until, fires, relief, depth
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: headline, consumption, pcepilfe, cpiaucsl, unemployment, dexchus, nonfarm, effective, growth, latest, dexjpus, payrolls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, china, proxy, natural, rates, credit, russell, crypto, commodities, nasdaq, range, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=99, 14d-median=101; carrying terms: economic, activities, beirut, hybrid, specific, mediterranean, niger, agency, services, technology, transactions, tunisia
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, client, https, quiverquant, error, quantitative, congresstrading, quiver, unauthorized
- billionaires: today=35, 7d-median=37, 14d-median=37; carrying terms: yiming, gcarsoa, gates, adani, spain, france, zhang, sergey, brokerage, holdings, steve, mukesh
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: johnson, county, court, supreme, delaware, appeals, blanche, california, corporation, hernandez, company, commission
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, michael, richard, william, group, daniel, therapeutics, brian, alkermes
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: johnson, cooper, krishnamoorthi, talarico, raised, shawn, warner, congress, angels, receipts, trone, graham
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, japan, china
- gdelt_gkg: today=0, 7d-median=50, 14d-median=36; carrying terms: english, israel, hezbollah, keywords, netanyahu, hormuz, israeli, attacks, strikes, peace, withdrawal, drone
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: domain, english, kingdom, language, india, shows, years
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=26, 14d-median=18; carrying terms: position, belgium, canada, ground, france, kingdom, china, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: caused, children, driving, seven, different, confirmed, confirmation, spain, health, suspected, activities, eight
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: vulnerability, coded, velocloud, password, langflow, remediation, unauthorized, information, management, arista, center, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=262, 7d-median=233, 14d-median=244; carrying terms: austria, honduras, hurricane, serbia, montenegro, bulgaria, forest, spain, flood, france, ecuador, brazil
- usgs_quakes: today=15, 7d-median=13, 14d-median=15; carrying terms: depth, islands, region, indonesia, philippines, sarangani, zealand, south, tonga, papua, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: effective, august, resolves, price, september, ceasefire, volume, prime, hormuz, returns, normal, strait
- commentary: today=6, 7d-median=6, 14d-median=5; carrying terms: https, marginal, class, conversable, revolution, economist, conversableeconomist, marginalrevolution, strong, college, economic, assorted
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: technology, people, breach, technica, target, bleepingcomputer, across, anthropic, https, cyber, right, download
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: carbajal, pocan, tulsi, krishnamoorthi, alford, economic, credit, linda, waters, jayapal, valadao, jennifer
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, converges, placed, module, market, markets, claude, decision, paper, evidence, either, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*