# WORLDSCOPE morning brief — 2026-09-07

## Headline
3080 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (806) · Russian Internal News (state + in-exile) (707) · Ukraine Theater (total-war monitoring) (375) · World leaders & government officials (324) · Chinese Internal News (241) · State-Level News (148) · Local News: St. Louis + Atlanta (122) · U.S. Weather + Severe / Climate Outlooks (90) · Ukrainian Internal News (national + local Kyiv) (59) · Conflict & unrest (GDELT, last 48h) (40) · Forbes Real-Time Billionaires (top 30 + biggest movers) (30) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 806 new of 1049 total
  - (2026-09-07) [Global] Germany's far-right AfD says 'democracy demands' parties work with them after state election win
      The far-right party is trying to form a government in the state after falling three seats short of a majority.
  - (2026-09-07) [Global] Israeli strikes in southern Lebanese village kill nine
      Lebanon says a recent Israeli escalation is jeopardising a US-brokered ceasefire meant to end the conflict between Israel and Hezbollah.
  - (2026-09-07) [Global] New videos of man in 9/11 lawsuit reveal extremist links
      The footage and other evidence the FBI failed to share undermine Omar al-Bayoumi's 25 years of denials.
  - (2026-09-07) [Global] Probe begins into why cargo plane overran Miami runway
      Five people died and five others were injured as the Amazon plane overshot the runway after landing at Miami International Airport.
  - (2026-09-07) [Global] Kyiv air raid alerts at record high as Russia launches round-the-clock strikes
      Schools, businesses and public transport are all struggling with the surge in Russian air attacks.
  - (2026-09-07) [Global] Nepal observes national day of mourning for victims of flash flood disaster
      Flags flew at half mast on the 13th day since the disaster, the last day of the Hindu mourning period.

### Russian Internal News (state + in-exile) — 707 new of 899 total
  - (2026-09-07) Финляндия достроила 200-километровый забор на границе с Россией | LEDE: Финляндия завершила строительство 200-километрового заграждения на границе с Россией, сообщает YLE News. ] (ru: Финляндия достро…
      Финляндия завершила строительство 200-километрового заграждения на границе с Россией, сообщает YLE News.
  - (2026-09-07) Война. 1657-й день. В Киеве начали запасать еду и воду на зиму — на случаи отключений электроэнергии из-за российских атак | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-07) Замначальника главка МВД Подмосковья и топ-менеджеров региональной сети заправок задержали по подозрению в хищении топлива у полиции | LEDE: Председателя совета директоров ПАО «ЕвроТранс» Иг] (ru: Зам…
      Председателя совета директоров ПАО «ЕвроТранс» Игоря Мартышова, трех топ-менеджеров компании и трех сотрудников подмосковной полиции задержали по делу о хищении ведомственного топлива, сообщила официальный представитель…
  - (2026-09-07) Литва исключила Ломоносова и Державина из школьной программы. Тараса Шевченко в нее пока не добавили — несмотря на предложение премьер-министра | LEDE: Министерство образования, науки и спор] (ru: Лит…
      Министерство образования, науки и спорта Литвы исключило из школьной программы произведения Михаила Ломоносова и Гавриила Державина, сообщает LRT. Этих авторов проходили в девятом классе в рамках изучения родного языка и…
  - (2026-09-07) «Украдут все, что не приколочено». Украина потеряла как минимум 1,2 миллиарда долларов из-за коррупции в сфере оборонных закупок. Самое важное, что узнала The New York Times из засекреченных ре] (ru:…
      Газета The New York Times (1 и 2) получила результаты аудитов государственных закупок оружия для украинской армии за 2024-2025 годы. Проверку работы агентства по оборонным закупкам проводили государственная аудиторская с…
  - (2026-09-07) К 2040 году под контролем России может оказаться треть мировой добычи урана | LEDE: Россия в ближайшие 15 лет будет прямо или косвенно контролировать треть мировой добычи урана. К такому выв] (ru: К 2…
      Россия в ближайшие 15 лет будет прямо или косвенно контролировать треть мировой добычи урана. К такому выводу, пишет Financial Times, пришли аналитики британского Centre for Strategic Advantage (CSA).

### Ukraine Theater (total-war monitoring) — 375 new of 570 total
  - (2026-09-07) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-06) [FIRMS] thermal anomaly 45.258, 31.674 (FRP 4.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-06 0947Z, FRP 4.69 MW
  - (2026-09-06) [FIRMS] thermal anomaly 45.258, 31.675 (FRP 4.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-06 0947Z, FRP 4.74 MW
  - (2026-09-06) [FIRMS] thermal anomaly 45.317, 28.414 (FRP 4.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-06 0947Z, FRP 4.18 MW
  - (2026-09-06) [FIRMS] thermal anomaly 45.317, 28.415 (FRP 5.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-06 0947Z, FRP 5.93 MW
  - (2026-09-06) [FIRMS] thermal anomaly 51.196, 34.996 (FRP 10.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-06 0949Z, FRP 10.76 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 241 new of 270 total
  - (2026-09-07) 安徽芜湖： 乡道弯弯稻浪相连 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1FU05WUnRnTThjQlE0UFRVUFdXZFAyUnd1ak5jU25IaXdIU0g4NTFmR1V3N3VHajhZNEhLcGoxYXA0VHQ4UTdPeWZyVV9WRHVQUEhfW] (zh:…
      安徽芜湖： 乡道弯弯稻浪相连 人民图片
  - (2026-09-07) 海南琼海： 白露至鱼满舱 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9RY3JZTE9Pal9rNk5xWmc4YktTUWFMYmlrYTBrdlZWSktGNk05RjBUaFE1cFp1U0hjUDE0OTZYcV9aODYzTlVvcFNCdGlVcFdrOWQzbTB] (zh:…
      海南琼海： 白露至鱼满舱 人民图片
  - (2026-09-06) 四川宜宾： 新能源汽车展人气旺 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE84WVZHdWlmTnNreVNKdEhNT01TM3RCN0ZnVVMtemVrNm84NUdvdDU4djRmN3NHWjNidDI1bjR3MTYyV1FmSUl3LURXNkxxNkF5TVN5] (zh:…
      四川宜宾： 新能源汽车展人气旺 人民图片
  - (2026-09-06) 内蒙古鄂尔多斯： 以工代赈治沙增收 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5GNzdlaTAxakZMSDZGd2U4bVN6T25ua2F4SUZDRFd3dDM5YlNsSTM3ZEhJRWNyM0w3SkFaTXNDeHkxY05YcmE3UFBtVEJIdHBvVm] (zh:…
      内蒙古鄂尔多斯： 以工代赈治沙增收 人民图片
  - (2026-09-07) 广西梧州： 公园舞动彩带龙 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFBRNnQ2SFkxQzZrZ0RMel9vZ1NGUEplVkJNSUQwTnp0azVvZ0FzVHF6dWxjT2hXaTRmZ29yNXVkTTlSd3RCdUxlNGRRdDJLSE83cGxvVX] (zh:…
      广西梧州： 公园舞动彩带龙 人民图片
  - (2026-09-07) 河北邯郸： 用爱心温暖无声世界 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFB3MkpYNElqVWdNeF9rZk1qbHROaEZOVjZobWppejR6Q0V1WkVzQXhVZFVyZ2VWUl9mR2xoX0RVV1FRQnlUMlJJU0F3d1hKWG56cDBP] (zh:…
      河北邯郸： 用爱心温暖无声世界 人民图片

### State-Level News — 148 new of 246 total
  - (2026-09-07) [Alabama] Opinion | From Eden to Alexandria to artificial intelligence
  - (2026-09-07) [Alabama] Mobile Baykeeper relaunches coastal Alabama water testing program
  - (2026-09-07) [Alabama] Sewell bill would require tax withholding from college athletes’ NIL payments
  - (2026-09-07) [Alabama] Figures introduces bipartisan legislation to combat “chameleon carriers”
  - (2026-09-07) [Alabama] Alabama mental health centers receive more than $8 million in rural health grants
  - (2026-09-07) [Alabama] Tuberville, Jones put competing plans before Alabama voters

### Local News: St. Louis + Atlanta — 122 new of 181 total
  - (2026-09-07) [St. Louis] John Burroughs senior combats medical misinformation with digital publication
      St. Louis is a nationally recognized powerhouse for medical research, driven by world-class institutions such as Washington University in St. Louis and Saint Louis University. Yet, for many teens and community members, t…
  - (2026-09-07) [St. Louis] Principia students design 3D-printed devices to help people with disabilities
      Last spring, 16-year-old students at Principia School were hard at work engineering, designing, and 3D-printing devices to help members of the St. Louis community as part of the PrintLab & Autodesk Make Challenge. Studen…
  - (2026-09-06) [St. Louis] These historic Midwest towns make for a perfect fall getaway
      Washington, Missouri | 50 minutes from St. Louis Known as the “Corncob Pipe Capital of the World,” nearby Washington was founded in the early 1800s by German settlers. Today, many its historic downtown brick buildings an…
  - (2026-09-06) [St. Louis] Covered bridges of the Midwest
      Missouri There are four covered bridges in Missouri, all of which are recognized as State Historic Sites. Illinois Of the nine covered bridges in Illinois, four are located in the central or southern parts of the state,…
  - (2026-09-07) [St. Louis] Crash temporarily shuts down all I-70 westbound lanes on Monday morning
      Authorities reopened the roadway about 20 minutes after the crash took place.
  - (2026-09-07) [St. Louis] What's open and closed on Labor Day? It's different from most federal holidays
      For stores that are open, many businesses use the holiday to reel in customers with Labor Day sales.

### U.S. Weather + Severe / Climate Outlooks — 90 new of 92 total
  - (2026-09-07) [Moderate] Special Weather Statement: Special Weather Statement issued September 7 at 7:11AM MDT by NWS Great Falls MT
      At 710 AM MDT, trained weather spotters reported strong thunderstorms along a line extending from 10 miles southeast of Power to near Geyser. Movement was northeast at 30 mph. HAZARD...Wind gusts up to 40 mph and a short…
  - (2026-09-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-07) [Moderate] Special Weather Statement: Special Weather Statement issued September 7 at 7:51AM CDT by NWS North Platte NE
      At 751 AM CDT, Doppler radar was tracking a strong thunderstorm 12 miles southeast of Wakpamni, or 16 miles northeast of Gordon, moving northeast at 25 mph. HAZARD...Penny size hail. SOURCE...Radar indicated. IMPACT...Mi…
  - (2026-09-07) [Severe] Special Marine Warning: Special Marine Warning issued September 7 at 7:41AM CDT until September 7 at 8:45AM CDT by NWS New Orleans LA
      SMWLIX The National Weather Service in New Orleans has issued a * Special Marine Warning for... Coastal Waters from Boothville LA to Southwest Pass of the Mississippi River out 20 nm... Coastal waters from Pascagoula Mis…
  - (2026-09-07) [Severe] Special Marine Warning: Special Marine Warning issued September 7 at 7:33AM CDT until September 7 at 9:00AM CDT by NWS Mobile AL
      SMWMOB The National Weather Service in Mobile has issued a * Special Marine Warning for... Waters from Okaloosa-Walton County Line to Pensacola FL from 20 to 60 NM... Waters from Pensacola FL to Pascagoula MS from 20 to…
  - (2026-09-07) [Severe] Flood Watch: Flood Watch issued September 7 at 6:01AM MDT until September 8 at 12:00PM MDT by NWS Great Falls MT
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of north central Montana, including the following areas, East Glacier Park Region, Eastern Glacier, Western Toole, and Central…

### Ukrainian Internal News (national + local Kyiv) — 59 new of 129 total
  - (2026-09-07) Реактивні дрони стали реальністю: якими БПЛА Росія атакує Київ і чи можна їм протидіяти | LEDE: ] (uk: Реактивні дрони стали реальністю: якими БПЛА Росія атакує Київ і чи можна їм про)
  - (2026-09-07) Корецький і Домбровскіс обговорили три питання щодо фіндопомоги ЄС Україні | LEDE: Після відеоконференції єврокомісара Валдіса Домбровскіса з прем'єр-міністром України Сергієм Корецьким 7 верес] (uk:…
      Після відеоконференції єврокомісара Валдіса Домбровскіса з прем'єр-міністром України Сергієм Корецьким 7 вересня у Єврокомісії заявили, що наразі зарано називати конкретну суму фінансових потреб України у 2026-27 роках,…
  - (2026-09-07) Мерц назвав "найважчою поразкою" провал своєї партії на виборах у Саксонії-Ангальт | LEDE: Канцлер Німеччини Фрідріх Мерц назвав результат виборів у Саксонії-Ангальт 6 вересня найважчою поразко] (uk:…
      Канцлер Німеччини Фрідріх Мерц назвав результат виборів у Саксонії-Ангальт 6 вересня найважчою поразкою для своєї партії за десятиліття та пообіцяв продовжувати курс реформ.
  - (2026-09-07) Потепління і невеликі дощі – прогноз погоди в Україні на 8-10 вересня | LEDE: У більшості регіонів збережеться суха й тепла погода, лише на заході у четвер прогнозують короткочасні дощі. Дані У] (uk:…
      У більшості регіонів збережеться суха й тепла погода, лише на заході у четвер прогнозують короткочасні дощі. Дані Укргідрометцентру.
  - (2026-09-07) Окупанти вдарили по Запоріжжю: 5 постраждалих, пошкоджено багатоповерхівки і дитсадок | LEDE: Унаслідок удару безпілотників РФ по Запоріжжю постраждали 5 людей, дві багатоповерхівки та дитячий ] (uk:…
      Унаслідок удару безпілотників РФ по Запоріжжю постраждали 5 людей, дві багатоповерхівки та дитячий садок. Діти перебували в укритті – Запорізька ОВА.
  - (2026-09-07) У Донецьку ліквідували бойовика, причетного до вбивств офіцерів ГУР і СБУ – джерела | LEDE: В липні 2026 року українські спецслужби ліквідували співробітника так званого "Центру спецоперацій МД] (uk:…
      В липні 2026 року українські спецслужби ліквідували співробітника так званого "Центру спецоперацій МДБ "ДНР" Олега Шутова, який був причетний до резонансних убивств українських офіцерів ГУР Максима Шаповала та СБУ Олекса…

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-07) [United States] Her body temperature was 106 : How heat is killing Americans in their homes
      domain: upr.org · language: English · tone:
  - (2026-09-07) [United States] Far - Right AfD Party Wins In German State Election | NewsTalk WMEQ
      domain: wmeq.iheart.com · language: English · tone:
  - (2026-09-07) [Russia] Russia and North Korea Open First Road Bridge
      domain: themoscowtimes.com · language: English · tone:
  - (2026-09-07) [United States] Should Apostle Islands be a national park ? Some say Tiffany proposal lacks buy - in
      domain: mprnews.org · language: English · tone:
  - (2026-09-07) [United Kingdom] Four rescued after sailing vessel sinks off coast of Clacton | Clacton and Frinton Gazette
      domain: clactonandfrintongazette.co.uk · language: English · tone:
  - (2026-09-07) [Egypt] Egypt Sends Legal Team to Saudi Arabia After Umrah Bus Crash
      domain: cairoscene.com · language: English · tone:

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-09-07) #1 Elon Musk — $908.22B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-09-07) #2 Larry Page — $277.88B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-07) #3 Jeff Bezos — $266.54B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-09-07) #4 Michael Dell — $263.11B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-09-07) #5 Sergey Brin — $255.74B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-07) #6 Mark Zuckerberg — $211.98B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-09-07) GAF129 (Germany)
      icao24: 3ea5bc · position: (49.9169, 10.9878) · alt: 9136m · 688km/h
  - (2026-09-07) GAF133 (Germany)
      icao24: 3f62fc · position: (45.8404, 17.1024) · alt: 4869m · 508km/h
  - (2026-09-07) CFC3441 (Canada)
      icao24: c2c36d · position: (45.9524, -74.2275) · alt: 9273m · 828km/h
  - (2026-09-07) SAMU44 (France)
      icao24: 39ca84 · position: (47.7404, -0.4676) · alt: 289m · 218km/h
  - (2026-09-07) SAMU37 (France)
      icao24: 39ca87 · position: (47.3513, 0.7124) · alt: 30m · 23km/h
  - (2026-09-07) SAMU05 (France)
      icao24: 39ca81 · position: (44.0331, 5.9281) · alt: 1981m · 244km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 28 new of 56 total
  - (2026-09-07) [BleepingComputer] Mathspace discloses data breach affecting over 1 million people
      Online maths learning platform Mathspace disclosed over the weekend that attackers stole data from more than 1 million students, staff, and parents after breaching its Metabase internal reporting system. [...]
  - (2026-09-07) [BleepingComputer] Trezor data breach impact now reaches 81,000 customers
      Cryptocurrency hardware wallet maker Trezor says an August data breach at its shipping and logistics provider, ShipMonk, affects an additional 67,000 U.S. customers. [...]
  - (2026-09-07) [BleepingComputer] ChatGPT can now connect to your personal apps to mimic writing style
      OpenAI appears to be testing a new "Writing Style" feature for ChatGPT that can learn how you write by looking at examples from your connected apps. [...]
  - (2026-09-07) [BleepingComputer] Hackers exploit new MikroTik RouterOS flaws to hijack routers
      Hackers are exploiting a chain of two recently disclosed vulnerabilities in MikroTik routers to take control of devices with SSH services exposed to the internet. [...]
  - (2026-09-07) [BleepingComputer] ConnectWise warns of new ScreenConnect flaw without patch
      ConnectWise has shared temporary mitigation measures for a new ScreenConnect Remote Access vulnerability that it plans to patch later this week. [...]
  - (2026-09-07) [The Hacker News] Your Cloud Security Checklist Doesn't Work the Way You Think It Does
      If managing security across multiple cloud providers wasn't hard enough, each one fails in a different way. For the 2026 Cloud Security Index, Intruder analyzed misconfiguration data from 3,000 organizations across AWS,…

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-09-07) LoL: Anyone's Legend vs Bilibili Gaming - Game 3 Winner
      yes price: 0% · 24h volume: $1,028,709 · resolves 2026-09-07
  - (2026-09-07) LoL: Anyone's Legend vs Bilibili Gaming (BO5) - LPL Playoffs
      yes price: 0% · 24h volume: $868,443 · resolves 2026-09-07
  - (2026-09-07) LoL: Invictus Gaming vs LGD Gaming (BO5) - LPL Playoffs
      yes price: 64% · 24h volume: $521,862 · resolves 2026-09-08
  - (2026-09-07) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 0% · 24h volume: $496,836 · resolves 2026-09-16
  - (2026-09-07) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 50% · 24h volume: $340,074 · resolves 2026-09-16
  - (2026-09-07) Will China invade Taiwan by end of 2026?
      yes price: 4% · 24h volume: $301,732 · resolves 2026-12-31

### Paper Trading Scorecard — 14 new of 114 total
  - (2026-09-07) [Manifold] CDU above 5% in 2026 Mecklenburg-Vorpommern state election?
  - (2026-09-07) [Manifold] Will my Democrats win Texas Senate election? Market have 350 traders before 7pm est election day 2026?
  - (2026-09-07) [Manifold] US Average Gas Price Is $4.000 or more on November 1 2026?
  - (2026-09-07) [Manifold] US Average Gas Price Is $4.000 or more on September 14 2026?
  - (2026-09-07) [Manifold] US Average Gas Price Is $4.000 or more on October 1st 2026?
  - (2026-09-07) [Manifold] Will an official manifold account make markets for every state in every presidential election up to 2040

### USGS earthquakes (M4.5+, past day) — 9 new of 9 total
  - (2026-09-07) M 5.5 - southeast of the Loyalty Islands
      M5.5 · southeast of the Loyalty Islands · depth 10 km
  - (2026-09-07) M 5.3 - off the coast of Oregon
      M5.3 · off the coast of Oregon · depth 10 km · TSUNAMI
  - (2026-09-07) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 585.146 km
  - (2026-09-07) M 4.9 - Kermadec Islands region
      M4.9 · Kermadec Islands region · depth 585.921 km
  - (2026-09-06) M 4.8 - 39 km SW of Copala, Mexico
      M4.8 · 39 km SW of Copala, Mexico · depth 10 km
  - (2026-09-07) M 4.7 - Kermadec Islands region
      M4.7 · Kermadec Islands region · depth 586.221 km

### Court opinions of consequence (federal & state) — 4 new of 60 total
  - (2026-09-04) U.S. Court of Appeals, Federal Cir.: Connecticut Yankee Atomic Power Company v. United States
  - (2026-09-03) Florida Supreme Court: Daniel O. Conahan, Jr. v. State of Florida & Daniel O. Conahan, Jr. v. Secretary, Department of Corrections
  - (2026-09-03) Florida Supreme Court: In Re: Amendments to Florida Rules of Civil Procedure 1.080, 1.090, and 1.490
  - (2026-09-03) U.S. Court of Appeals, Federal Cir.: Loomis v. Collins

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-07) [Marginal Revolution] Capital gains vs. wealth taxes
      Standard optimal capital tax theory abstracts from modeling asset prices, making it unsuitable for thinking about capital gains and wealth taxation. We study optimal redistributive taxation in an environment with asset p…
  - (2026-09-07) [Marginal Revolution] Emergent Ventures winners, 59th cohort
      Tym Syrytczyk, London, autonomous vehicles in the UK. Shane Regan, Long Island, 16, AI agents. Maximilian Kornstein, 15, Atlanta area, agents and general career support. Irene Chen and Jessica Dai, UC Berkeley, data on p…
  - (2026-09-06) [Marginal Revolution] Insurance price sentences to ponder
      NYU Stern researcher @NateWitkin questions why cyber insurance rates keep falling if AI cyber risk is accelerating: “Insurance rates for cyber risk declined by about 4% globally in Q2 of this year, and that’s actually th…

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 104 total
  - (2026-09-03) [USTR] Untitled - United States Trade Representative (.gov)
      Untitled United States Trade Representative (.gov)</fo

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=11, 7d-median=16, 14d-median=19; carrying terms: safety, final, applicable, proposed, national, unless, certain, service, document, action, special, changes
- state_bills: today=60, 7d-median=75, 14d-median=79; carrying terms: vests, funds, applicant, health, among, provided, activities, relating, findings, authorizes, effective, administered
- state_news: today=246, 7d-median=623, 14d-median=636; carrying terms: november, single, collins, among, lincoln, staff, tennessee, behind, recently, ballots, texas, fetchpriority
- local_news: today=181, 7d-median=234, 14d-median=238; carrying terms: missing, officer, magazine, child, court, investigation, according, center, georgia, weekend, president, officers
- foreign_news: today=1049, 7d-median=1096, 14d-median=1048; carrying terms: miracles, author, garrison, material, mission, provided, revealed, banco, pushes, build, behind, adviser
- chinese_internal: today=270, 7d-median=282, 14d-median=286; carrying terms: cbmidefvx, cbmiakfvx, cbmibkfvx, cbmix, color, https, cbmiykfvx, cbmixkfvx, politics, cbmickfvx, title, global
- russian_internal: today=899, 7d-median=1042, 14d-median=1058; carrying terms: group, telegram, bloomberg, times, russian, financial, reuters, title, forbidden, truth, politico, journal
- ukrainian_internal: today=129, 7d-median=129, 14d-median=126; carrying terms: institute, ministers, babel, elections, struck, assets, independent, logistics, overnight, security, general, according
- ukraine_theater: today=570, 7d-median=612, 14d-median=591; carrying terms: dovepmvtnqexl, xsfhntktxmhy, cuxnueqzzffhr, cbmijwfbvv, cjlmahr, hitlbjvm, tnvinuzjb, vtzfrueszzvmxcnhzuutpsth, jcxiyq, ndbxohayttristhstnrdwkdewurjcel, meunxeno, mission
- paper_bets: today=114, 7d-median=132, 14d-median=132; carrying terms: republicans, nominal, funds, supervolcano, hampshire, maine, johnson, successor, september, achieved, official, magnitude
- weather: today=92, 7d-median=145, 14d-median=133; carrying terms: early, depth, weather, excessive, combined, activities, afdffc, lincoln, portions, tropical, messages, storm
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: nonfarm, cpilfesl, inflation, payems, balance, total, recession, crude, sheet, dexchus, personal, growth
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, close, russell, agriculture, equities, treasury, futures, silver, range, large, credit, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=104, 14d-median=107; carrying terms: active, institute, funds, transnistrian, combat, mission, palestinian, protecting, activities, imposed, savannah, enable
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quantitative, quiverquant, https, client, unauthorized, httperror, error, quiver
- billionaires: today=30, 7d-median=30, 14d-median=30; carrying terms: spacex, holdings, bezos, buffett, mukesh, larry, metals, zuckerberg, meyers, julia, bloomberg, huang
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, state, court, connecticut, appeals, blanche, company, energy, county, insurance, group, health
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, holdings, brian, america, therapeutics, technologies, robert, george, elliot
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: elect, senate, pinkston, jonathan, lindsey, ossoff, talarico, cycle, booker, angels, filing, johnson
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=0; carrying terms: against, domain, kingdom, english, trump, india, hospital, language, health, iheart
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, canada, ground, germany, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: event, deaths, early, active, notification, november, august, institute, clusters, numbers, aboard, dignified
- cisa_kev: today=21, 7d-median=21, 14d-median=20; carrying terms: missing, forgery, request, command, server, authentication, weblogic, oracle, improper, microsoft, product, access
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=9, 7d-median=12, 14d-median=14; carrying terms: depth, islands, region, south, kermadec
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: interest, volume, resolves, september, decrease, shakhtar, league, rates, meeting, donetsk, championship, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, revolution, class, economist, conversable, https, economy, recent, current, price, conversableeconomist, wealth
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: review, researchers, intelligence, industry, company, weekly, information, agents, computerweekly, openai, security, hackers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: henry, jeanne, mccormick, garbarino, yassamin, bishop, patty, white, spartz, ralph, bernie, mcbride
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, consensus, claude, decision, placement, market, today, module, placed, paper, evidence, converges

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*