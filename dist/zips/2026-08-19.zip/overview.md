# WORLDSCOPE morning brief — 2026-08-19

## Headline
3365 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (752) · Russian Internal News (state + in-exile) (697) · State-Level News (328) · World leaders & government officials (324) · Chinese Internal News (247) · Local News: St. Louis + Atlanta (217) · Ukraine Theater (total-war monitoring) (177) · State Legislative Action (165) · U.S. Weather + Severe / Climate Outlooks (139) · Ukrainian Internal News (national + local Kyiv) (57) · Court opinions of consequence (federal & state) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 752 new of 991 total
  - (2026-08-18) [Global] 'Banned over a pair of £2 sandals': Why some sellers are complaining about Vinted
      Several thousands of Vinted users say they have been wrongly suspended or permanently banned from the preloved app.
  - (2026-08-19) [Global] Trump pauses new tariffs on Canada for three days, saying deal close
      The US president says the two sides are finalising documents to avert import taxes targeting a range of Canadian goods.
  - (2026-08-18) [Global] Meta hooked children on Facebook and Instagram, US court hears
      Meta argued social media addiction does not exist, as a trial stemming from a major lawsuit brought by US states started.
  - (2026-08-18) [Global] Mobile payments on the rise but cash decline slows
      Nine in 10 mobile wallet users have their debit card loaded as their default payment method, new data shows.
  - (2026-08-18) [Global] The critical tech staying safe by going underground
      The war in Ukraine has spurred people to consider putting vital infrastructure underground.
  - (2026-08-19) [Global] Chinese robotics giant Unitree soars in stock market debut
      Shares in the world's biggest humanoid robot maker started trading on Shanghai's Star market on Wednesday.

### Russian Internal News (state + in-exile) — 697 new of 1084 total
  - (2026-08-19) «Ведомости»: военнослужащим МЧС разрешат применять огнестрельное оружие | LEDE: Правительственная комиссия по законопроектной деятельности одобрила законопроект, согласно которому служащие с] (ru: «Ве…
      Правительственная комиссия по законопроектной деятельности одобрила законопроект, согласно которому служащие спасательных воинских формирований МЧС смогут применять силу и огнестрельное оружие, пишут «Ведомости», ссылаяс…
  - (2026-08-19) Как Советский Союз всего за 30 лет прошел путь от первого человека в космосе до танков у Белого дома? Читайте книгу Михаила Зыгаря «Темная сторона Земли» — теперь она доступна бесплатно в прило] (ru:…
      35 лет назад, 19 августа 1991 года, в СССР начался августовский путч — событие, предрешившее судьбу всей страны: всего через четыре месяца после него Советский Союз перестал существовать. Именно 19 августа в стране ввели…
  - (2026-08-19) Uniqlo впервые выпустил коллекцию хиджабов | LEDE: Японский бренд одежды Uniqlo в августе впервые выпустил в продажу линейку хиджабов. В коллекции, поступившей в продажу 17 августа, представ] (ru: Uni…
      Японский бренд одежды Uniqlo в августе впервые выпустил в продажу линейку хиджабов. В коллекции, поступившей в продажу 17 августа, представлены шарфы и платки, в том числе из фирменного материала AIRism, а также шапочка…
  - (2026-08-19) В Украине проводят обыски у депутатов и чиновников. Среди них — замглавы офиса президента Ирина Мудрая | LEDE: Национальное антикоррупционное бюро Украины (НАБУ) и Специализированная антикор] (ru: В У…
      Национальное антикоррупционное бюро Украины (НАБУ) и Специализированная антикоррупционная прокуратура (САП) объявили 19 августа, что проводят «спецоперацию по разоблачению преступной организации».
  - (2026-08-19) Троих москвичей, приходивших к Верховному суду, чтобы поддержать «Яблоко», арестовали на срок от 10 до 15 суток | LEDE: Как минимум троим москвичам, приходившим поддержать «Яблоко» к Верховн] (ru: Тро…
      Как минимум троим москвичам, приходившим поддержать «Яблоко» к Верховному суду, назначили административные аресты.
  - (2026-08-19) Умер барабанщик ZZ Top Фрэнк Бирд | LEDE: Барабанщик ZZ Top Фрэнк Бирд умер в возрасте 77 лет. Представитель музыканта сообщил, что Бирд умер в окружении членов семьи на своем ранчо в Техасе] (ru: Уме…
      Барабанщик ZZ Top Фрэнк Бирд умер в возрасте 77 лет. Представитель музыканта сообщил, что Бирд умер в окружении членов семьи на своем ранчо в Техасе.

### State-Level News — 328 new of 638 total
  - (2026-08-18) [California] Governor Newsom secures federal disaster assistance for small businesses impacted by Boyle Heights warehouse fire
      <a href="https://www.gov.ca.gov/2026/08/18/governor-newsom-secures-federal-disaster-assistance-for-small-businesses-impacted-by-bo
  - (2026-08-18) [California] California leads in organized retail crime fight, recovers 8,500 stolen items in 9-day nationwide blitz
      Source
  - (2026-08-18) [California] Governor Newsom announces $95 million plan to expand EV charging and hydrogen fueling across California
      Source
  - (2026-08-19) [Connecticut] The science that protects our children doesn’t take a summer vacation
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/08/pfizer-campus-sign-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriori…
  - (2026-08-18) [Connecticut] Lamont, CT officials fear nuclear merger could raise electricity costs
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2025/10/2025_1002_SR_MillstoneTour_237-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-08-18) [Connecticut] CT winter heating benefits tick up but still lag pre-pandemic levels
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2024/09/2024_0916_SR_HeatingAssistance_092-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="as…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 247 new of 302 total
  - (2026-08-17) 郭德纲被举报，谁的压力最大 - opinion.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFB1SkFqMktPQWJnemZqdEVwa2YtVHE1TUw5ZThuZjRoWWFxcDVsRE1ac2gzQjR4dUl4bnVQWklaSkRWQ1Vjdlp4WHVo] (zh:…
      郭德纲被举报，谁的压力最大 opinion.caixin.com
  - (2026-08-17) 宇树“暗盘”出价三倍 触及账户监管红线 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9QS0ROSFNCV2p4VGpaZVhmQTVGRk5hT0JGSmNialZqZXZ4NU5keE1wa0l3aGxwNjlub1J4NUt4VXFoNGg4T3hCeGpQX1Y3OGpXNG] (zh:…
      宇树“暗盘”出价三倍 触及账户监管红线 财新
  - (2026-08-17) 长鑫科技市值破4万亿 算力赛道迎来资金集中布局 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5UekJkNDlhWEkwMmVoM1lHUlZkdVUzNEM2c3l3QjNJOFZQd3lXNkZIQVdmbzB0SDMyUjFvSEEyTjBmSzhWY1p5LW9xNEptTG] (zh:…
      长鑫科技市值破4万亿 算力赛道迎来资金集中布局 财新
  - (2026-08-17) “围猎”IPO手法层出不穷 香港ZD Group爆发兑付危机 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE02N0NBODI0TUFsdlNRaTFuRFgxSlpCbmRtcnBzMDRuLU9wTllleUVsbTh0YUNqWjB1RUo0Z19IY185dlFROV9SbEd] (zh:…
      “围猎”IPO手法层出不穷 香港ZD Group爆发兑付危机 财新
  - (2026-08-19) 今日开盘：两市双双低开 沪指跌幅0.96% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBNS0VISGZHeUpxNmU4NVZxT3pMMV85TnA1ejZWZGZJOWlnSHRld0V3NE9pVnVBRnhkUVNscDdaQlNVVHh1NENQWmZhLXJEbDdW] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.96% 财新
  - (2026-08-18) 今日开盘：小幅低开 沪指跌幅0.08% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1xeTVfSnJBN0E5SkdGUE9PUE8xc0VxTEpORXZyZUo5V3ZXWlI2Qk5IN2g3bnhtTDZyNUx1cXZyM1EtbldrR3NwNi1OX1RSeWtQcD] (zh:…
      今日开盘：小幅低开 沪指跌幅0.08% 财新

### Local News: St. Louis + Atlanta — 217 new of 242 total
  - (2026-08-18) [St. Louis] Purina Incredible Dog Challenge doc ‘A Different Breed’ earns three Daytime Emmy Award nominations
      St. Louis residents Aaron Bowden and Erik Becker didn’t expect to get nominated for a Daytime Emmy (much less three) when they were approached by Purina to create a documentary series based around its nationwide dog spor…
  - (2026-08-18) [St. Louis] Where in Chesterfield 8/19/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-08-18) [St. Louis] A St. Louis runner is taking on the world’s biggest marathons for St. Jude
      Every starting line that Scott MacArthur has crossed this year has meant more than another race. Each has brought him closer to helping children and families facing life’s toughest diagnoses. By the end of 2026, the St.…
  - (2026-08-18) [St. Louis] How Conrad Wallem’s World Cup reset helped spark St. Louis CITY SC’s turnaround
      The first half of this year didn’t go the way that Conrad Wallem envisioned. After spending last season on loan and playing all over the pitch, the 26-year-old Norwegian arrived as a full-time player in St. Louis this sp…
  - (2026-08-18) [St. Louis] ‘The Big Bad Business of Murder’ brings true crime questions to the stage
      The true crime genre, while wildly popular, is also fraught with questions of taste and ethics. Who gets to tell victims’ stories? Should people profit from them? What draws millions of readers, listeners, and viewers to…
  - (2026-08-18) [St. Louis] Missy Kelley bids farewell to a career that spans the corporate world and boosting downtown
      There have been multiple points in Missy Kelley’s career where she knew she needed to make a substantial change. She’s moved between stints in the corporate and civic world. But Kelley is now staring down a much differen…

### Ukraine Theater (total-war monitoring) — 177 new of 234 total
  - (2026-08-19) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-18) [Liveuamap] 2 people killed, 13 wounded as result of Russian missile strikes at the ArcelorMittal metallurgical plant in Kryvyi Rih, crucial equipment damaged Kryvyi Rih, Dnipropetrovsk Oblast - Ukrai…
      2 people killed, 13 wounded as result of Russian missile strikes at the ArcelorMittal metallurgical plant in Kryvyi Rih, crucia
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2016-07-28) [Liveuamap] Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com - iran.liveuamap.com
      Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com iran.liveuamap.com
  - (2026-08-18) [Liveuamap] Trump: Hormuz is a "new US territory" Washington, District of Columbia - iran.liveuamap.com
      Trump: Hormuz is a "new US territory" Washington, District of Columbia iran.liveuamap.com
  - (2026-08-18) [Liveuamap] 5 people wounded as result of airstrike in Izium yesterday evening - Liveuamap
      5 people wounded as result of airstrike in Izium yesterday evening Liveuamap

### State Legislative Action — 165 new of 173 total
  - (2026-08-18) [Alaska HB 110] An Act relating to the rural health transformation program; relating to the interstate medical licensure compact; relating to the PA licensure compact; relating to the psychology inter…
      An Act relating to the rural health transformation program; relating to the interstate medical licensure compact; relating to the PA licensure compact; relating to the psychology interjurisdictional compact; relating to…
  - (2026-08-18) [Alaska HJR 20] Encouraging the United States Congress to establish hiring goals for apprentices and veteran apprentices.
      Encouraging the United States Congress to establish hiring goals for apprentices and veteran apprentices.
  - (2026-08-18) [Alaska HCR 302] Authorizing the Senate and the House of Representatives to recess for a period of more than three days.
      Authorizing the Senate and the House of Representatives to recess for a period of more than three days.
  - (2026-08-18) [Alaska SB 249] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; relating to unfair trade or deceptive acts or practices; and providing for an effective…
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; relating to unfair trade or deceptive acts or practices; and providing for an effective date.
  - (2026-08-18) [Alaska SB 252] An Act relating to the Uniform Commercial Code; relating to secured transactions; relating to controllable accounts, controllable electronic records, and controllable payment intangibl…
      An Act relating to the Uniform Commercial Code; relating to secured transactions; relating to controllable accounts, controllable electronic records, and controllable payment intangibles; relating to sales; relating to n…
  - (2026-08-18) [Alaska SB 35] An Act relating to transportation network companies and delivery network companies; and relating to occupational accident insurance.
      An Act relating to transportation network companies and delivery network companies; and relating to occupational accident insurance.

### U.S. Weather + Severe / Climate Outlooks — 139 new of 145 total
  - (2026-08-19) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-19) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 19 at 2:21AM CDT until August 19 at 2:45AM CDT by NWS Springfield MO
      At 221 AM CDT, severe thunderstorms were located along a line extending from near St. Thomas to 10 miles west of Vienna to near Richland, moving east at 45 mph. HAZARD...60 mph wind gusts and nickel size hail. SOURCE...R…
  - (2026-08-19) [Moderate] Special Weather Statement: Special Weather Statement issued August 19 at 2:19AM CDT by NWS La Crosse WI
      If traveling through river valleys this morning, be prepared for fog that could suddenly reduce visibilities to 1/4 mile or less. Areas of fog will be possible outside of river valleys, but visibilities of 1/4 mile are l…
  - (2026-08-19) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 19 at 1:17AM MDT until August 19 at 1:45AM MDT by NWS Denver CO
      At 117 AM MDT, a severe thunderstorm was located 8 miles north of Boyero, or 27 miles southeast of Limon, moving southeast at 40 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...H…
  - (2026-08-19) [Moderate] Blowing Dust Advisory: Blowing Dust Advisory issued August 19 at 12:14AM MST until August 19 at 10:00PM MST by NWS Phoenix AZ
      * WHAT...For the Extreme Heat Warning, dangerously hot conditions. Afternoon temperatures 106 to 113. Major Heat Risk. For the Blowing Dust Advisory, visibility between one-quarter and one mile in blowing dust expected.…
  - (2026-08-19) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 19 at 12:14AM MST until August 21 at 8:00PM MST by NWS Phoenix AZ
      * WHAT...Dangerously hot and humid conditions. Afternoon temperatures 106 to 114 expected. Major Heat Risk. * WHERE...Portions of southwest Arizona and southeast California. * WHEN...Until 8 PM MST /8 PM PDT/ Friday. * I…

### Ukrainian Internal News (national + local Kyiv) — 57 new of 100 total
  - (2026-08-19) У вівторок нардепи 5 годин говорили з кандидатами в міністри. Зранку комітет схвалив Хмару | LEDE: 18 серпня народні депутати понад п'ять годин розмовляли з кандидатами на посади міністра оборо] (uk:…
      18 серпня народні депутати понад п'ять годин розмовляли з кандидатами на посади міністра оборони та міністра закордонних справ. Зранку 19 серпня зустрічі продовжилися.
  - (2026-08-19) Окупанти атакували дроном маршрутку в Херсоні: 4 людини загинули, ще 5 поранені | LEDE: У Корабельному районі Херсона дрон РФ атакував маршрутку: 4 людини загинули, ще 4 жінки поранені.] (uk: Окупанти…
      У Корабельному районі Херсона дрон РФ атакував маршрутку: 4 людини загинули, ще 4 жінки поранені.
  - (2026-08-19) УП: НАБУ і САП прийшли з обшуками до нардепа Столара та заступниці керівника ОП Мудрої | LEDE: НАБУ і САП у межах спецоперації проводять обшуки у народного депутата Вадима Столара, обраного до ] (uk:…
      НАБУ і САП у межах спецоперації проводять обшуки у народного депутата Вадима Столара, обраного до парламенту від нині забороненої партії "Опозиційна платформа – За життя", та заступниці керівника Офісу президента Ірини М…
  - (2026-08-19) У Києві Volkswagen врізався в маршрутку і вилетів на зупинку: 2 загиблих, 4 поранених | LEDE: Правоохоронці працюють на місці смертельної ДТП у Солом'янському районі Києва. За попередньою інфор] (uk:…
      Правоохоронці працюють на місці смертельної ДТП у Солом'янському районі Києва. За попередньою інформацією, є двоє загиблих і четверо поранених.
  - (2026-08-19) НАБУ і САП анонсували спецоперацію "Форест Гамп" щодо злочинної організації за участі нардепів і посадовців ОП | LEDE: НАБУ і САП проводять спецоперацію "Форест Гамп" з викриття злочинної орган] (uk:…
      НАБУ і САП проводять спецоперацію "Форест Гамп" з викриття злочинної організації, яка, за даними слідства, діяла під керівництвом чинного та колишнього народних депутатів за участі високопосадовців Офісу президента та ін…
  - (2026-08-19) Партизани "АТЕШ" знищили три вежі зв’язку окупантів на Курщині | LEDE: Партизанський рух "АТЕШ" заявив про ліквідацію трьох російських веж зв'язку в Курській області.] (uk: Партизани "АТЕШ" знищили тр…
      Партизанський рух "АТЕШ" заявив про ліквідацію трьох російських веж зв'язку в Курській області.

### Court opinions of consequence (federal & state) — 45 new of 60 total
  - (2026-08-18) Arizona Supreme Court: Williams v. ades/lamont
  - (2026-08-18) Arizona Supreme Court: State of Arizona v. Diondra Sharrelle Howard
  - (2026-08-18) Delaware Supreme Court: In the Matter of a Member of the Bar of the Supreme Court of Delaware
  - (2026-08-18) Delaware Supreme Court: Ennis v. State
  - (2026-08-18) Delaware Supreme Court: Scott v, State
  - (2026-08-18) U.S. Court of Appeals, 5th Cir.: R J Reynolds Tobacco Company v. FDA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-19) [Koss Jennifer G.] Form 4 (Reporting)
      filed 2026-08-19 01:59 UTC · role: Reporting — Filed: 2026-08-18 AccNo: 0001872100-26-000003 Size: 9 KB
  - (2026-08-19) [Reservoir Media, Inc.] Form 4 (Issuer)
      filed 2026-08-19 01:59 UTC · role: Issuer — Filed: 2026-08-18 AccNo: 0001872100-26-000003 Size: 9 KB
  - (2026-08-19) [Schocken Joseph L] Form 4 (Reporting)
      filed 2026-08-19 01:51 UTC · role: Reporting — Filed: 2026-08-18 AccNo: 0001437749-26-028463 Size: 5 KB
  - (2026-08-19) [OMEROS CORP] Form 4 (Issuer)
      filed 2026-08-19 01:51 UTC · role: Issuer — Filed: 2026-08-18 AccNo: 0001437749-26-028463 Size: 5 KB
  - (2026-08-19) [Corrigan Catherine] Form 4 (Reporting)
      filed 2026-08-19 01:43 UTC · role: Reporting — Filed: 2026-08-18 AccNo: 0000851520-26-000096 Size: 8 KB
  - (2026-08-19) [EXPONENT INC] Form 4 (Issuer)
      filed 2026-08-19 01:43 UTC · role: Issuer — Filed: 2026-08-18 AccNo: 0000851520-26-000096 Size: 8 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 56 total
  - (2026-08-19) [The Register] NASA estimates the size of the hole SpaceX made in the moon
      As the latest Starship finds its way to an obscure part of Australia, for observations
  - (2026-08-19) [The Register] Baidu says Chinese buyers want local AI chips due to ‘supply chain’ issues
      It seems like Nvidia’s not getting back into the Middle Kingdom anytime soon
  - (2026-08-19) [The Register] Australian hotel chain leaks guests’ PII after breach at third-party database operator
      Unknown parties know where you stayed last summer, down under, across 120 Quest properties
  - (2026-08-19) [The Register] Cerebras CS-4 rack systems juice chips for every last drop of AI performance
      Next-gen systems double per-chip performance while cramming 3x as many into a rack
  - (2026-08-18) [BleepingComputer] Comcast turns your Xfinity WiFi into a home motion detector
      Comcast is promoting WiFi-based motion detection as a part of its new Xfinity Shield home protection platform, allowing routers and wireless devices to detect people moving through a home without cameras or motion sensor…
  - (2026-08-18) [BleepingComputer] Clop created custom web shell for Windchill data theft attacks
      A custom Java web shell likely linked to the Clop ransomware gang was designed specifically for PTC Windchill and FlexPLM servers, with built-in features to decrypt credentials, enumerate file repositories, and steal fil…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 20 new of 21 total
  - (2026-08-18) M 5.9 - 270 km WSW of Yanglong, China
      M5.9 · 270 km WSW of Yanglong, China · depth 6 km · PAGER yellow
  - (2026-08-18) M 5.3 - 35 km SSW of Jurm, Afghanistan
      M5.3 · 35 km SSW of Jurm, Afghanistan · depth 195.937 km
  - (2026-08-19) M 5.2 - 66 km NNW of Ende, Indonesia
      M5.2 · 66 km NNW of Ende, Indonesia · depth 30.365 km
  - (2026-08-18) M 4.9 - 76 km NW of Ende, Indonesia
      M4.9 · 76 km NW of Ende, Indonesia · depth 10 km
  - (2026-08-18) M 4.9 - 79 km N of Ruteng, Indonesia
      M4.9 · 79 km N of Ruteng, Indonesia · depth 36.253 km
  - (2026-08-19) M 4.8 - 62 km NNE of Namuac, Philippines
      M4.8 · 62 km NNE of Namuac, Philippines · depth 10 km

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-08-19) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (40.9659, -3.6873) · alt: 10980m · 866km/h
  - (2026-08-19) JAF3LC (Bulgaria)
      icao24: 4520aa · position: (40.1721, 4.7223) · alt: 10980m · 880km/h
  - (2026-08-19) PUMA23 (Slovenia)
      icao24: 506e18 · position: (46.0967, 14.4338) · alt: 731m · 195km/h
  - (2026-08-19) PUMA45 (Slovenia)
      icao24: 506e1d · position: (45.9001, 15.5413) · alt: 274m · 142km/h
  - (2026-08-19) SAMU13 (France)
      icao24: 39c902 · position: (43.5925, 5.5586) · alt: 563m · 135km/h
  - (2026-08-19) FAF6526 (France)
      icao24: 3b75f5 · position: (46.7134, 0.4395) · alt: 883m · 222km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 95 total
  - (2026-08-18) [OFAC] International Criminal Court-related Designations; Venezuela-related Designation; Issuance of International Criminal Court-related General License - Office of Foreign Assets Control (.gov)
      International Criminal Court-related Designations; Venezuela-related Designation; Issuance of International Criminal Court-related General License Office of Foreign Assets Control (.gov)
  - (2026-08-18) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. Office of Foreign Assets Control (.gov)
  - (2026-08-12) [FARA] DOJ Privacy Impact Assessments - Department of Justice (.gov)
      DOJ Privacy Impact Assessments Department of Justice (.gov)
  - (2026-08-19) [USASpending] $42,257,183,759 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-08-19) [USASpending] $22,442,309,468 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-08-19) [USASpending] $3,102,091,409 → OAK RIDGE ASSOCIATED UNIVERSITIES, INCORPORATED: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIEN
      Agency: Department of Energy. Description: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIENCE AND EDUCATION

### U.S. Federal Action — 13 new of 14 total
  - (2026-08-19) Adjusting Imports of Unmanned Aircraft Systems and Unmanned Aircraft Systems Components Into the United States
  - (2026-08-19) Gardenia Blue Interest Group; Filing of Color Additive Petition
      The Food and Drug Administration (FDA or we) is announcing that we have filed a petition, submitted by Gardenia Blue Interest Group (GBIG or petitioner), c/o Exponent, Inc., proposing that we amend our color additive reg…
  - (2026-08-19) International Association of Color Manufacturers; Filing of Color Additive Petition
      The Food and Drug Administration (FDA or we) is announcing that we have filed a petition, submitted by the International Association of Color Manufacturers, proposing that we amend our color additive regulations to provi…
  - (2026-08-19) Food Additives Permitted in Feed and Drinking Water of Animals; Chromium DL-methionine Chelate
      The Food and Drug Administration (FDA, we, or the Agency) is amending the regulations for food additives permitted in feed and drinking water of animals to provide for the safe use of chromium DL- methionine chelate as a…
  - (2026-08-19) GNT USA, LLC.; Filing of Color Additive Petition
      The Food and Drug Administration (FDA or we) is announcing that we have filed a petition, submitted by GNT USA, LLC., c/o Exponent, Inc., proposing that we amend our color additive regulations to provide for the safe use…
  - (2026-08-19) Air Plan Approval; South Carolina; Minor Source Permit Program Revisions
      The U.S. Environmental Protection Agency (EPA or Agency) is proposing to approve changes to South Carolina's State Implementation Plan (SIP) to revise regulations prescribing minor source permit program requirements, inc…

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-19) Dota 2: TEAM VISION vs BoomBoys (BO3) - The International Playoffs
      yes price: 72% · 24h volume: $469,772 · resolves 2026-08-20
  - (2026-08-19) Will Russia capture Kostyantynivka by December 31, 2026?
      yes price: 100% · 24h volume: $444,843 · resolves 2026-12-31
  - (2026-08-19) Will Hakeem Jeffries win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $379,339 · resolves 2028-11-07
  - (2026-08-19) Will Alex Padilla win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $377,161 · resolves 2028-11-07
  - (2026-08-19) LoL: KT Rolster Challengers vs T1 Academy (BO3) - LCK Challengers League Rounds 3-4 Challenge Group
      yes price: 0% · 24h volume: $337,718 · resolves 2026-08-19
  - (2026-08-19) Will Alex Padilla win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $328,017 · resolves 2028-11-07

### Paper Trading Scorecard — 9 new of 130 total
  - (2026-08-19) [Polymarket] Game Handicap: WB (-1.5) vs LNG Esports (+1.5)
      This market refers to the LoL match between LNG Esports and Weibo Gaming in the LPL Group Nirvana, initially scheduled for August 19 at 3:00AM ET. This market will resolve to "Weibo Gaming" if Weibo Gaming wins 2 or more…
  - (2026-08-19) [Polymarket] Will the Atlanta Falcons win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-08-19) [Polymarket] Will Philadelphia 76ers win the 2027 NBA Finals?
      This market will resolve to "Yes" if the listed team is determined as the champion of the NBA for the 2026-27 season. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed team to be name…
  - (2026-08-19) [Manifold] Has my ex blocked me?
  - (2026-08-19) [Manifold] Will the winner of the 2026 Vuelta a España be Roglic or Pogacar?
  - (2026-08-19) [Manifold] Democrats win the 2026 Special Election for Senate in Florida?

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-08-19) #30 Tadashi Yanai & family — $64.46B
      Japan · Fashion & Retail · source: Fashion retail · holdings: 9983-JP(TOKYO)
  - (2026-08-19) MOVER ▼ Elon Musk — $879.20B ($-15.75B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-19) MOVER ▼ Mark Zuckerberg — $186.87B ($-8.58B since yesterday)
      United States · Technology · source: Facebook
  - (2026-08-19) MOVER ▼ Masayoshi Son — $63.06B ($-6.77B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-08-19) MOVER ▼ Michael Dell — $246.14B ($-5.58B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-19) MOVER ▼ Jensen Huang — $189.76B ($-4.48B since yesterday)
      United States · Technology · source: Semiconductors

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 10 total
  - (2026-08-18) CVE-2026-33824 · Microsoft Internet Key Exchange (IKE) Service Extensions: Microsoft Internet Key Exchange (IKE) Service Extensions Double Free Vulnerability
      vendor: Microsoft · product: Internet Key Exchange (IKE) Service Extensions · CISA remediation by 2026-08-21
  - (2026-08-18) CVE-2026-59310 · Broadcom VMware vCenter: Broadcom VMware vCenter Path Traversal Vulnerability
      vendor: Broadcom · product: VMware vCenter · CISA remediation by 2026-08-21
  - (2026-08-18) CVE-2026-55040 · Microsoft SharePoint: Microsoft SharePoint Weak Authentication Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-08-21
  - (2026-08-18) CVE-2026-65400 · Apple macOS: Apple macOS Improper Authentication Vulnerability
      vendor: Apple · product: macOS · CISA remediation by 2026-08-21

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-19) [Marginal Revolution] Capitalizing untethered AI agents
      That is my latest piece of writing, co-authored with Sonia Farrell Pearson of Harvard. Here is the opening premise: As early as 2017, the European Parliament floated “electronic personhood” for robots. More recently, a h…
  - (2026-08-18) [Marginal Revolution] Some fertility and AI forecasts
      The 2024 forecast is particularly pessimistic about China’s fertility prospects. Both projections produce very substantial global aging, a major global capital glut producing very low long-run real capital returns. The l…
  - (2026-08-18) [Marginal Revolution] Tuesday assorted links
      1. AI is helping patients to solve their medical mysteries (WSJ). 2. History of economic thought in one paragraph. 3. Becca Rothfeld on Rachel Cusk. 4. “Since ChatGPT, the number of new economics papers posted each year…
  - (2026-08-18) [Conversable Economist] The Generalizability Problem, the Natural Field Experiments Answer
      There’s a standard problem in the social sciences in moving from the results of a smaller-scale study to larger-scale applicability. Consider a program in a certain school district that seems to increase academic perform…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=20, 14d-median=20; carrying terms: provide, action, state, national, certain, proposes, establish, proposing, procedures, proposed, program, final
- state_bills: today=173, 7d-median=129, 14d-median=129; carrying terms: commission, applicable, residential, certain, related, social, california, authority, order, family, training, business
- state_news: today=638, 7d-median=585, 14d-median=585; carrying terms: leading, commonwealthbeacon, passed, asked, missouri, national, president, social, representative, republican, outside, spending
- local_news: today=242, 7d-median=216, 14d-median=229; carrying terms: missouri, national, accused, weekend, three, child, morning, dekalb, mother, charles, august, louis
- foreign_news: today=991, 7d-median=991, 14d-median=991; carrying terms: leading, operations, elephant, foreign, placed, envoy, attack, imperial, hours, drill, president, resolve
- chinese_internal: today=302, 7d-median=271, 14d-median=269; carrying terms: cbmickfvx, chinese, lxtfb, cbmizkfvx, cbmixkfvx, cbmibkfvx, title, lxtfa, blank, people, color, cbmiyefvx
- russian_internal: today=1084, 7d-median=1040, 14d-median=1040; carrying terms: journal, error, telegram, world, patriot, media, forbidden, target, street, russian, gazeta, politico
- ukrainian_internal: today=100, 7d-median=107, 14d-median=107; carrying terms: operations, facilities, campaign, independent, national, foreign, babel, attack, president, former, regions, targets
- ukraine_theater: today=234, 7d-median=1151, 14d-median=887; carrying terms: cbmipafbvv, eghdbfleqxnczflruhbqmvzhr, fhcghyd, zgdxvabdhzwtleu, tbhvha, zixzrmodrpev, wvzjocnzpn, operations, yuvvz, workshop, uvufranrsa, nonjhfwe
- paper_bets: today=130, 7d-median=141, 14d-median=139; carrying terms: pennsylvania, predictit, robot, leader, population, world, leaders, state, court, rippling, control, august
- weather: today=145, 7d-median=196, 14d-median=182; carrying terms: lincoln, seattle, southern, worth, message, missouri, county, unknown, dangerously, gusty, below, excessive
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dcoilwtico, openings, commodities, funds, cpiaucsl, dexchus, inflation, labor, walcl, payems, growth, total
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, agriculture, silver, futures, natural, russell, corporate, proxy, range, treasury, close, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=95, 7d-median=93, 14d-median=97; carrying terms: embargo, entities, provide, territorial, technologies, operations, agreement, islamic, development, campaign, agency, state
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, quiverquant, httperror, quantitative, unauthorized, https, client, quiver
- billionaires: today=40, 7d-median=35, 14d-median=34; carrying terms: technology, ambani, london, walmart, steve, retail, technologies, oracle, fashion, euronext, larrea, holdings
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, court, company, appeals, international, supreme, group, connecticut, village, america, delaware, retail
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, accno, reporting, partners, financial, capital, holdings, robert, david, management, snyderman
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, johnson, senate, house, raised, disbursements, platner, michael, elect, ossoff, robert, cooper
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, japan, surge
- gdelt_gkg: today=0, 7d-median=41, 14d-median=39; carrying terms: english, themes, israel, hezbollah, russian, spanish, trump, china, chinese, german, sanctions, perimeter
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=29, 14d-median=29; carrying terms: position, belgium, ground, france, kingdom, germany, bulgaria, netherlands, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: recent, hospitalization, consuming, declaration, diphtheria, generation, private, canada, young, affecting, geographically, leste
- cisa_kev: today=10, 7d-median=9, 14d-median=9; carrying terms: untrusted, firewall, loadmaster, vendor, product, deserialization, command, authentication, injection, vulnerability, teamcity, progress
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=260, 14d-median=260; carrying terms: congo, green, solomon, depth, marino, islands, kenya, czech, canada, somalia, panama, spain
- usgs_quakes: today=21, 7d-median=21, 14d-median=16; carrying terms: depth, indonesia, islands, philippines, south, ruteng, china
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: donetsk, september, championship, shakhtar, hormuz, resolves, interest, returns, normal, volume, august, league
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, conversableeconomist, revolution, https, marginal, conversable, economist, impossible, young, marginalrevolution, social, seems
- tech_news: today=56, 7d-median=58, 14d-median=56; carrying terms: point, million, attackers, hacker, september, weekday, infrastructure, krebs, newsletter, spectrum, network, edition
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: wagner, wesley, teresa, jacobs, commission, fields, nydia, alsobrooks, diana, mannion, young, joaquin
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, either, decision, market, sufficient, converges, claude, unavailable, markets, identify, placed, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*