# WORLDSCOPE morning brief — 2026-08-19

## Headline
3896 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (749) · Russian Internal News (state + in-exile) (683) · Ukraine Theater (total-war monitoring) (650) · State-Level News (352) · World leaders & government officials (324) · Chinese Internal News (257) · Local News: St. Louis + Atlanta (219) · State Legislative Action (173) · U.S. Weather + Severe / Climate Outlooks (143) · Ukrainian Internal News (national + local Kyiv) (60) · Court opinions of consequence (federal & state) (44) · IT, InfoSys & cybersecurity news (last 7 days) (42)

## What changed today
### International News + Multilateral Institutions — 749 new of 978 total
  - (2026-08-19) [Global] US pilot lands jet without front wheels after landing gear failure
      US pilot lands jet without front wheels after landing gear failure
  - (2026-08-19) [Global] Kelsey Mitchell ties WNBA scoring record in Fever win over Tempo
      The three-time All-Star made history when she registered 20 or more points in a WNBA game for the 20th straight time.
  - (2026-08-19) [Global] Ukraine’s sacked defence minister calls for wartime elections
      Ukraine’s sacked defence minister calls for wartime elections
  - (2026-08-19) [Global] Breastfeeding in Gaza: Mothers seek help to provide for their babies
      Breastfeeding mothers in Gaza struggle to feed their babies amid hunger, displacement, stress and living conditions.
  - (2026-08-19) [Global] Sabalenka cruises through as Medvedev falls to Nakashima at Cincinnati Open
      Top-ranked Aryna Sabalenka lost just four games to breeze into fourth round while Brandon Nakashima recorded a huge win.
  - (2026-08-19) [Global] Musiala collapses for Bayern again as ‘neurological disorder’ diagnosed
      Bayern Munich and Germany's Jamal Musiala collapses on field for second time but 'very optimistic' about condition.

### Russian Internal News (state + in-exile) — 683 new of 1066 total
  - (2026-08-19) Россия и Украина снова обменялись военнопленными — 103 на 103 человека | LEDE: Минобороны России сообщило, что провело обмен военнопленными с властями Украины. Стороны передали друг другу по] (ru: Рос…
      Минобороны России сообщило, что провело обмен военнопленными с властями Украины. Стороны передали друг другу по 103 человека.
  - (2026-08-19) На Луне появился новый кратер после того, как в поверхность врезалась часть ракеты SpaceX. Вот как это выглядит | LEDE: NASA опубликовало серию снимков нового кратера на Луне. Этот кратер об] (ru: На…
      NASA опубликовало серию снимков нового кратера на Луне. Этот кратер образовался 5 августа — когда разгонный блок ракеты SpaceX, который больше года дрейфовал в космосе, врезался в Луну на скорости около 8,7 тысячи киломе…
  - (2026-08-19) В Москве снова ограничили продажу бензина | LEDE: Как минимум в двух сетях АЗС в Москве вновь ввели лимиты на продажу топлива, пишет РБК. ] (ru: В Москве снова ограничили продажу бензина)
      Как минимум в двух сетях АЗС в Москве вновь ввели лимиты на продажу топлива, пишет РБК.
  - (2026-08-19) «Коммерсант»: в России возникли перебои с поставками моторных масел | LEDE: В России возникли перебои с поставками моторных масел. О дефиците, сообщили «Коммерсанту» участники рынка, речи по] (ru: «Ко…
      В России возникли перебои с поставками моторных масел. О дефиците, сообщили «Коммерсанту» участники рынка, речи пока не идет, но сроки поставки увеличились, а цены в некоторых сегментах выросли за последнее время на 40%.
  - (2026-08-19) «Ведомости»: военнослужащим МЧС разрешат применять огнестрельное оружие | LEDE: Правительственная комиссия по законопроектной деятельности одобрила законопроект, согласно которому служащие с] (ru: «Ве…
      Правительственная комиссия по законопроектной деятельности одобрила законопроект, согласно которому служащие спасательных воинских формирований МЧС смогут применять силу и огнестрельное оружие, пишут «Ведомости», ссылаяс…
  - (2026-08-19) Как Советский Союз всего за 30 лет прошел путь от первого человека в космосе до танков у Белого дома? Читайте книгу Михаила Зыгаря «Темная сторона Земли» — теперь она доступна бесплатно в прило] (ru:…
      35 лет назад, 19 августа 1991 года, в СССР начался августовский путч — событие, предрешившее судьбу всей страны: всего через четыре месяца после него Советский Союз перестал существовать. Именно 19 августа в стране ввели…

### Ukraine Theater (total-war monitoring) — 650 new of 792 total
  - (2026-08-19) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2026-08-18) [Liveuamap] 2 people killed, 13 wounded as result of Russian missile strikes at the ArcelorMittal metallurgical plant in Kryvyi Rih, crucial equipment damaged Kryvyi Rih, Dnipropetrovsk Oblast - Ukrai…
      2 people killed, 13 wounded as result of Russian missile strikes at the ArcelorMittal metallurgical plant in Kryvyi Rih, crucia
  - (2016-07-28) [Liveuamap] Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com - iran.liveuamap.com
      Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com iran.liveuamap.com
  - (2026-08-18) [Liveuamap] Trump: Hormuz is a "new US territory" Washington, District of Columbia - iran.liveuamap.com
      Trump: Hormuz is a "new US territory" Washington, District of Columbia iran.liveuamap.com
  - (2026-08-18) [Liveuamap] 5 people wounded as result of airstrike in Izium yesterday evening - Liveuamap
      5 people wounded as result of airstrike in Izium yesterday evening Liveuamap

### State-Level News — 352 new of 658 total
  - (2026-08-18) [California] Governor Newsom secures federal disaster assistance for small businesses impacted by Boyle Heights warehouse fire
      <a href="https://www.gov.ca.gov/2026/08/18/governor-newsom-secures-federal-disaster-assistance-for-small-businesses-impacted-by-bo
  - (2026-08-18) [California] California leads in organized retail crime fight, recovers 8,500 stolen items in 9-day nationwide blitz
      Source
  - (2026-08-18) [California] Governor Newsom announces $95 million plan to expand EV charging and hydrogen fueling across California
      Source
  - (2026-08-18) [California] Forest fires follow roads. The Trump administration wants to build more
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/080425-Gifford-Fire-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-08-18) [California] Informe: ICE da altas notas de salud a centros de detención pese a aumento de muertes
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/052726-Adelanto-Detention-Center-AP-CM-01.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-…
  - (2026-08-18) [California] Supervisores del condado de San Diego quieren expulsar al ICE del campo de tiro del condado
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/032426_Truth-Forum_AH_CM_16.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 257 new of 307 total
  - (2026-08-17) Commentary: The Real Flaw in China’s AI Strategy - caixinglobal.com
      Commentary: The Real Flaw in China’s AI Strategy caixinglobal.com
  - (2026-08-18) China’s Green Energy Exports Jump in July as EV Shipments Surge - caixinglobal.com
      China’s Green Energy Exports Jump in July as EV Shipments Surge caixinglobal.com
  - (2026-08-17) China Proposes Independent Privacy Oversight Committees for Big Tech - caixinglobal.com
      China Proposes Independent Privacy Oversight Committees for Big Tech caixinglobal.com
  - (2026-08-18) China to Let Mainland Insurers Buy Hong Kong ETFs Through Stock Connect - caixinglobal.com
      China to Let Mainland Insurers Buy Hong Kong ETFs Through Stock Connect caixinglobal.com
  - (2026-08-19) 谁在看烂片《牛来》？票房超2400万元 一二线城市、青少年观众占比高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1Zenk0TXhEUkhlYi1jbWlBeXdBWkg3MFRsZXNJRUkxQmE2NHhybU9YX3Y3VUp1YzVSd2N6bkxoZEFDRGt1VmI] (zh:…
      谁在看烂片《牛来》？票房超2400万元 一二线城市、青少年观众占比高 财新
  - (2026-08-17) 宇树“暗盘”出价三倍 触及账户监管红线 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9QS0ROSFNCV2p4VGpaZVhmQTVGRk5hT0JGSmNialZqZXZ4NU5keE1wa0l3aGxwNjlub1J4NUt4VXFoNGg4T3hCeGpQX1Y3OGpXNG] (zh:…
      宇树“暗盘”出价三倍 触及账户监管红线 财新

### Local News: St. Louis + Atlanta — 219 new of 243 total
  - (2026-08-18) [St. Louis] Purina Incredible Dog Challenge doc ‘A Different Breed’ earns three Daytime Emmy Award nominations
      St. Louis residents Aaron Bowden and Erik Becker didn’t expect to get nominated for a Daytime Emmy (much less three) when they were approached by Purina to create a documentary series based around its nationwide dog spor…
  - (2026-08-18) [St. Louis] Where in Chesterfield 8/19/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-08-18) [St. Louis] A St. Louis runner is taking on the world’s biggest marathons for St. Jude
      Every starting line that Scott MacArthur has crossed this year has meant more than another race. Each has brought him closer to helping children and families facing life’s toughest diagnoses. By the end of 2026, the St.…
  - (2026-08-18) [St. Louis] How Conrad Wallem’s World Cup reset helped spark St. Louis CITY SC’s turnaround
      The first half of this year didn’t go the way that Conrad Wallem envisioned. After spending last season on loan and playing all over the pitch, the 26-year-old Norwegian arrived as a full-time player in St. Louis this sp…
  - (2026-08-18) [St. Louis] ‘The Big Bad Business of Murder’ brings true crime questions to the stage
      The true crime genre, while wildly popular, is also fraught with questions of taste and ethics. Who gets to tell victims’ stories? Should people profit from them? What draws millions of readers, listeners, and viewers to…
  - (2026-08-18) [St. Louis] Missy Kelley bids farewell to a career that spans the corporate world and boosting downtown
      There have been multiple points in Missy Kelley’s career where she knew she needed to make a substantial change. She’s moved between stints in the corporate and civic world. But Kelley is now staring down a much differen…

### State Legislative Action — 173 new of 181 total
  - (2026-08-18) [Alaska HB 110] An Act relating to the rural health transformation program; relating to the interstate medical licensure compact; relating to the PA licensure compact; relating to the psychology inter…
      An Act relating to the rural health transformation program; relating to the interstate medical licensure compact; relating to the PA licensure compact; relating to the psychology interjurisdictional compact; relating to…
  - (2026-08-18) [Alaska HJR 20] Encouraging the United States Congress to establish hiring goals for apprentices and veteran apprentices.
      Encouraging the United States Congress to establish hiring goals for apprentices and veteran apprentices.
  - (2026-08-18) [Alaska HCR 302] Authorizing the Senate and the House of Representatives to recess for a period of more than three days.
      Authorizing the Senate and the House of Representatives to recess for a period of more than three days.
  - (2026-08-18) [Alaska SB 249] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; relating to unfair trade or deceptive acts or practices; and providing for an effective…
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; relating to unfair trade or deceptive acts or practices; and providing for an effective date.
  - (2026-08-18) [Alaska SB 252] An Act relating to the Uniform Commercial Code; relating to secured transactions; relating to controllable accounts, controllable electronic records, and controllable payment intangibl…
      An Act relating to the Uniform Commercial Code; relating to secured transactions; relating to controllable accounts, controllable electronic records, and controllable payment intangibles; relating to sales; relating to n…
  - (2026-08-18) [Alaska SB 35] An Act relating to transportation network companies and delivery network companies; and relating to occupational accident insurance.
      An Act relating to transportation network companies and delivery network companies; and relating to occupational accident insurance.

### U.S. Weather + Severe / Climate Outlooks — 143 new of 145 total
  - (2026-08-19) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-19) [Moderate] Special Weather Statement: Special Weather Statement issued August 19 at 4:15AM CDT by NWS Milwaukee/Sullivan WI
      Clouds have cleared and fog will continue to redevelop and impact areas along and west of the Kettle Moraine through daybreak. Expect visibility of 1 mile or less in low-lying areas and even pockets of dense in river val…
  - (2026-08-19) [Moderate] Special Weather Statement: Special Weather Statement issued August 19 at 4:14AM CDT by NWS North Platte NE
      At 414 AM CDT, Doppler radar was tracking a strong thunderstorm 12 miles east of Springview, moving southeast at 30 mph. HAZARD...Wind gusts up to 50 mph and nickel size hail. SOURCE...Radar indicated. IMPACT...Gusty win…
  - (2026-08-19) [Moderate] Heat Advisory: Heat Advisory issued August 19 at 2:03AM PDT until August 20 at 8:00PM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...For the Heat Advisory, High temperatures of 92 to 105 expected, with most areas seeing peak heat on Wednesday and Thursday. Low temperatures are expected to range from the upper 60s to lower 70s at lower elevati…
  - (2026-08-19) [Moderate] Heat Advisory: Heat Advisory issued August 19 at 2:03AM PDT until August 20 at 8:00PM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...High temperatures ranging from 95 to 105 degrees. Low temperatures in the upper 60s to lower 70s, except mid 70s to lower 80s in the foothills and mountains. * WHERE...A portion of southwest California. * WHEN..…
  - (2026-08-19) [Moderate] Special Weather Statement: Special Weather Statement issued August 19 at 3:02AM MDT by NWS Denver CO
      At 302 AM MDT, Doppler radar was tracking a line of strong thunderstorms extending from near Boyero to 11 miles south of Kutch, or extending from 29 miles southeast of Limon to 37 miles south of Limon, moving southeast a…

### Ukrainian Internal News (national + local Kyiv) — 60 new of 103 total
  - (2026-08-19) Trump Scales Back Joint Drills With South Korea
      Trump’s decision to scale back US-South Korea military exercises has raised concerns about the consequences for regional security. Critics argue he overestimates his relationship with Kim Jong-un, potentially strengtheni…
  - (2026-08-19) NABU Starts ‘Forest Gump’ Operation, Uncovers Crisis Plan
      Ukraine’s National Anti-Corruption Bureau and Specialized Anti-Corruption Prosecutor’s Office are conducting a special operation targeting an alleged criminal organization led by a current and former lawmaker. During sea…
  - (2026-08-19) Open the Black Sea for Shipping!
      The Russo-Ukrainian War is heating up in the Black Sea this summer, with tit-for-tat attacks on shipping. The Ukrainian economy is at risk and needs the help of Europeans, particularly the Baltic states.
  - (2026-08-19) NATO Draws Up 3-Step Plan to Fight Russia if Putin Attacks the Baltics
      NATO has reportedly developed a three-part strategy for a potential Russian attack on the Baltic states. According to Bild, the plan includes suppressing Russian missile systems, deploying autonomous drones along NATO’s…
  - (2026-08-19) EXPLAINER: 35 Years Ago Today, the World Held Its Breath
      On this day in 1991, a failed hardline coup in Moscow became the final shock that pushed Ukraine from asserted sovereignty to independence. As Soviet authority faltered, Ukraine’s democratic forces, sovereignty Communist…
  - (2026-08-19) ‘Zero Tolerance’: Polish Woman Charged After Alleged Nationality-Based Attack on Ukrainian Siblings
      A 46-year-old Polish woman has been charged after allegedly verbally and physically attacking two Ukrainian siblings, aged 14 and 12, in Bydgoszcz. Police say the incident involved nationality-based insults and damage to…

### Court opinions of consequence (federal & state) — 44 new of 60 total
  - (2026-08-18) U.S. Court of Appeals, 2nd Cir.: Belya v. Kapral
  - (2026-08-18) U.S. Court of Appeals, 2nd Cir.: United States v. Valder
  - (2026-08-18) U.S. Court of Appeals, 3rd Cir.: United States v. Kenneth Strickland
  - (2026-08-18) Arizona Supreme Court: Williams v. ades/lamont
  - (2026-08-18) Arizona Supreme Court: State of Arizona v. Diondra Sharrelle Howard
  - (2026-08-18) U.S. Court of Appeals, 9th Cir.: Thermolife International, LLC v. Bpi Sports, LLC

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 56 total
  - (2026-08-19) [BleepingComputer] Windows 11 24H2 Home and Pro reach end of support in 2 months
      Microsoft has reminded customers that systems running Home and Pro editions of Windows 11 24H2 will stop receiving updates in two months. [...]
  - (2026-08-19) [BleepingComputer] CISA: Medusa ransomware hit over 500 critical infrastructure orgs
      The FBI said Tuesday that the Medusa ransomware gang has breached more than 500 critical infrastructure organizations in the United States since June 2021. [...]
  - (2026-08-19) [The Register] UK taxman discovers low code doesn't mean low cost with £657M awards
      Those legacy systems won't fix themselves
  - (2026-08-19) [The Register] NASA estimates the size of the hole SpaceX made in the moon
      As the latest Starship finds its way to an obscure part of Australia, for observations
  - (2026-08-19) [The Register] Baidu says Chinese buyers want local AI chips due to ‘supply chain’ issues
      It seems like Nvidia’s not getting back into the Middle Kingdom anytime soon
  - (2026-08-19) [The Register] Australian hotel chain leaks guests’ PII after breach at third-party database operator
      Unknown parties know where you stayed last summer, down under, across 120 Quest properties

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-19) [Koss Jennifer G.] Form 4 (Reporting)
      filed 2026-08-19 01:59 UTC · role: Reporting — Filed: 2026-08-18 AccNo: 0001872100-26-000003 Size: 9 KB
  - (2026-08-19) [Reservoir Media, Inc.] Form 4 (Issuer)
      filed 2026-08-19 01:59 UTC · role: Issuer — Filed: 2026-08-18 AccNo: 0001872100-26-000003 Size: 9 KB
  - (2026-08-19) [Schocken Joseph L] Form 4 (Reporting)
      filed 2026-08-19 01:51 UTC · role: Reporting — Filed: 2026-08-18 AccNo: 0001437749-26-028463 Size: 5 KB
  - (2026-08-19) [OMEROS CORP] Form 4 (Issuer)
      filed 2026-08-19 01:51 UTC · role: Issuer — Filed: 2026-08-18 AccNo: 0001437749-26-028463 Size: 5 KB
  - (2026-08-19) [Corrigan Catherine] Form 4 (Reporting)
      filed 2026-08-19 01:43 UTC · role: Reporting — Filed: 2026-08-18 AccNo: 0000851520-26-000096 Size: 8 KB
  - (2026-08-19) [EXPONENT INC] Form 4 (Issuer)
      filed 2026-08-19 01:43 UTC · role: Issuer — Filed: 2026-08-18 AccNo: 0000851520-26-000096 Size: 8 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-19) [Russia oil sanctions perimeter · keywords] There is no fish : The Russian vessels raising spy fears in Europe
      euronews.com · English · tone NA
  - (2026-08-19) [Russia oil sanctions perimeter · keywords] Oil : Third straight day of gains and three - week high amid US - Iran deadlock ; Brent above $91
      sofokleous10.gr · English · tone NA
  - (2026-08-19) [Russia oil sanctions perimeter · keywords] US stocks retreated with underperformance in tech as yields remained elevated - Newsquawk Daily Asia - Pac Market Open
      zerohedge.com · English · tone NA
  - (2026-08-19) [Russia oil sanctions perimeter · keywords] Greek - Run Oil Tanker Comes Under Attack
      rigzone.com · English · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · keywords] Greek oil tanker attacked in Black Sea Bloomberg
      centralasiatimes.com · English · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · keywords] China Touts Success of Arctic Ice Silk Road to Bypass Strait of Hormuz
      breitbart.com · English · tone NA

### Government & military aircraft airborne (OpenSky) — 24 new of 26 total
  - (2026-08-19) PUMA42 (Slovenia)
      icao24: 506e18 · position: (45.9084, 15.4953) · alt: 365m · 155km/h
  - (2026-08-19) SAMU691 (France)
      icao24: 39c994 · position: (45.7477, 4.9026) · alt: 289m · 46km/h
  - (2026-08-19) JAF9WL (Belgium)
      icao24: 44d1a6 · position: (48.6415, 1.4312) · alt: 10363m · 921km/h
  - (2026-08-19) JAF5KH (Belgium)
      icao24: 44d1a5 · position: (39.7435, 24.0848) · alt: 11582m · 744km/h
  - (2026-08-19) JAF8EC (Belgium)
      icao24: 44d1c2 · position: (40.0079, 20.5428) · alt: 11582m · 785km/h
  - (2026-08-19) JAF3NE (Belgium)
      icao24: 44d1a2 · position: (46.2981, -0.1133) · alt: 10363m · 896km/h

### USGS earthquakes (M4.5+, past day) — 18 new of 18 total
  - (2026-08-18) M 5.9 - 270 km WSW of Yanglong, China
      M5.9 · 270 km WSW of Yanglong, China · depth 6 km · PAGER yellow
  - (2026-08-18) M 5.3 - 35 km SSW of Jurm, Afghanistan
      M5.3 · 35 km SSW of Jurm, Afghanistan · depth 195.937 km
  - (2026-08-19) M 5.2 - 66 km NNW of Ende, Indonesia
      M5.2 · 66 km NNW of Ende, Indonesia · depth 30.365 km
  - (2026-08-18) M 4.9 - 76 km NW of Ende, Indonesia
      M4.9 · 76 km NW of Ende, Indonesia · depth 10 km
  - (2026-08-18) M 4.9 - 79 km N of Ruteng, Indonesia
      M4.9 · 79 km N of Ruteng, Indonesia · depth 36.253 km
  - (2026-08-19) M 4.8 - 62 km NNE of Namuac, Philippines
      M4.8 · 62 km NNE of Namuac, Philippines · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-08-19) LoL: LNG Esports vs Weibo Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $659,469 · resolves 2026-08-19
  - (2026-08-19) LoL: LNG Esports vs Weibo Gaming (BO3) - LPL Group Nirvana
      yes price: 38% · 24h volume: $577,897 · resolves 2026-08-19
  - (2026-08-19) LoL: Gen.G vs KT Rolster - Game 1 Winner
      yes price: 100% · 24h volume: $577,105 · resolves 2026-08-19
  - (2026-08-19) Dota 2: TEAM VISION vs BoomBoys (BO3) - The International Playoffs
      yes price: 70% · 24h volume: $460,483 · resolves 2026-08-20
  - (2026-08-19) Will Russia capture Kostyantynivka by December 31, 2026?
      yes price: 100% · 24h volume: $448,768 · resolves 2026-12-31
  - (2026-08-19) LoL: LNG Esports vs Weibo Gaming - Game 1 Winner
      yes price: 0% · 24h volume: $445,448 · resolves 2026-08-19

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 95 total
  - (2026-08-18) [OFAC] International Criminal Court-related Designations; Venezuela-related Designation; Issuance of International Criminal Court-related General License - Office of Foreign Assets Control (.gov)
      International Criminal Court-related Designations; Venezuela-related Designation; Issuance of International Criminal Court-related General License Office of Foreign Assets Control (.gov)
  - (2026-08-18) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL International Criminal Court-Related Sanctions Regulations 31 CFR part 528 GENERAL LICENSE NO. Office of Foreign Assets Control (.gov)
  - (2026-08-12) [FARA] DOJ Privacy Impact Assessments - Department of Justice (.gov)
      DOJ Privacy Impact Assessments Department of Justice (.gov)
  - (2026-08-19) [USASpending] $42,257,183,759 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-08-19) [USASpending] $22,442,309,468 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-08-19) [USASpending] $3,102,091,409 → OAK RIDGE ASSOCIATED UNIVERSITIES, INCORPORATED: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIEN
      Agency: Department of Energy. Description: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIENCE AND EDUCATION

### U.S. Federal Action — 13 new of 14 total
  - (2026-08-19) Adjusting Imports of Unmanned Aircraft Systems and Unmanned Aircraft Systems Components Into the United States
  - (2026-08-19) Gardenia Blue Interest Group; Filing of Color Additive Petition
      The Food and Drug Administration (FDA or we) is announcing that we have filed a petition, submitted by Gardenia Blue Interest Group (GBIG or petitioner), c/o Exponent, Inc., proposing that we amend our color additive reg…
  - (2026-08-19) International Association of Color Manufacturers; Filing of Color Additive Petition
      The Food and Drug Administration (FDA or we) is announcing that we have filed a petition, submitted by the International Association of Color Manufacturers, proposing that we amend our color additive regulations to provi…
  - (2026-08-19) Food Additives Permitted in Feed and Drinking Water of Animals; Chromium DL-methionine Chelate
      The Food and Drug Administration (FDA, we, or the Agency) is amending the regulations for food additives permitted in feed and drinking water of animals to provide for the safe use of chromium DL- methionine chelate as a…
  - (2026-08-19) GNT USA, LLC.; Filing of Color Additive Petition
      The Food and Drug Administration (FDA or we) is announcing that we have filed a petition, submitted by GNT USA, LLC., c/o Exponent, Inc., proposing that we amend our color additive regulations to provide for the safe use…
  - (2026-08-19) Air Plan Approval; South Carolina; Minor Source Permit Program Revisions
      The U.S. Environmental Protection Agency (EPA or Agency) is proposing to approve changes to South Carolina's State Implementation Plan (SIP) to revise regulations prescribing minor source permit program requirements, inc…

### Paper Trading Scorecard — 8 new of 127 total
  - (2026-08-19) [Polymarket] Will the Atlanta Falcons win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-08-19) [Polymarket] Will Philadelphia 76ers win the 2027 NBA Finals?
      This market will resolve to "Yes" if the listed team is determined as the champion of the NBA for the 2026-27 season. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed team to be name…
  - (2026-08-19) [Manifold] Has my ex blocked me?
  - (2026-08-19) [Manifold] Will the winner of the 2026 Vuelta a España be Roglic or Pogacar?
  - (2026-08-19) [Manifold] Democrats win the 2026 Special Election for Senate in Florida?
  - (2026-08-19) [Manifold] Will I score 1580+ on the SAT?

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 10 total
  - (2026-08-18) CVE-2026-33824 · Microsoft Internet Key Exchange (IKE) Service Extensions: Microsoft Internet Key Exchange (IKE) Service Extensions Double Free Vulnerability
      vendor: Microsoft · product: Internet Key Exchange (IKE) Service Extensions · CISA remediation by 2026-08-21
  - (2026-08-18) CVE-2026-59310 · Broadcom VMware vCenter: Broadcom VMware vCenter Path Traversal Vulnerability
      vendor: Broadcom · product: VMware vCenter · CISA remediation by 2026-08-21
  - (2026-08-18) CVE-2026-55040 · Microsoft SharePoint: Microsoft SharePoint Weak Authentication Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-08-21
  - (2026-08-18) CVE-2026-65400 · Apple macOS: Apple macOS Improper Authentication Vulnerability
      vendor: Apple · product: macOS · CISA remediation by 2026-08-21

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-19) [Marginal Revolution] Capitalizing untethered AI agents
      That is my latest piece of writing, co-authored with Sonia Farrell Pearson of Harvard. Here is the opening premise: As early as 2017, the European Parliament floated “electronic personhood” for robots. More recently, a h…
  - (2026-08-18) [Marginal Revolution] Some fertility and AI forecasts
      The 2024 forecast is particularly pessimistic about China’s fertility prospects. Both projections produce very substantial global aging, a major global capital glut producing very low long-run real capital returns. The l…
  - (2026-08-18) [Marginal Revolution] Tuesday assorted links
      1. AI is helping patients to solve their medical mysteries (WSJ). 2. History of economic thought in one paragraph. 3. Becca Rothfeld on Rachel Cusk. 4. “Since ChatGPT, the number of new economics papers posted each year…
  - (2026-08-18) [Conversable Economist] The Generalizability Problem, the Natural Field Experiments Answer
      There’s a standard problem in the social sciences in moving from the results of a smaller-scale study to larger-scale applicability. Consider a program in a certain school district that seems to increase academic perform…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 34 total
  - (2026-08-19) #30 Tadashi Yanai & family — $64.46B
      Japan · Fashion & Retail · source: Fashion retail · holdings: 9983-JP(TOKYO)
  - (2026-08-19) MOVER ▼ Mukesh Ambani — $89.46B ($-0.39B since yesterday)
      India · Diversified · source: Diversified

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=20, 14d-median=20; carrying terms: procedures, action, proposes, state, provide, establish, program, proposed, certain, proposing, final, national
- state_bills: today=181, 7d-median=129, 14d-median=129; carrying terms: service, general, grants, human, permits, development, things, require, known, impact, practice, management
- state_news: today=658, 7d-median=585, 14d-median=531; carrying terms: funding, central, oregon, early, white, notice, dollars, commonwealthbeacon, almost, wednesday, situation, climate
- local_news: today=243, 7d-median=216, 14d-median=222; carrying terms: dekalb, charles, illinois, metro, national, injured, family, state, crash, across, night, faces
- foreign_news: today=978, 7d-median=978, 14d-median=979; carrying terms: governorship, damages, xichang, allafrica, nansha, central, early, white, stunt, centre, index, notice
- chinese_internal: today=307, 7d-median=271, 14d-median=267; carrying terms: cbmib, cbmiaefvx, cbmizefvx, caixin, people, cbmiw, cbmia, china, color, cbmidefvx, articles, lxtfb
- russian_internal: today=1066, 7d-median=1040, 14d-median=1024; carrying terms: httperror, telegram, street, times, media, found, europe, wildberries, journal, raquo, bloomberg, patriot
- ukrainian_internal: today=103, 7d-median=107, 14d-median=106; carrying terms: strike, campaign, minister, general, sanctions, troops, killed, political, forces, donald, growing, volodymyr
- ukraine_theater: today=792, 7d-median=1151, 14d-median=944; carrying terms: ejfnznm, accreditation, cuxoa, hymzjcu, nemdjuwlqmxjqukl, damascus, deployment, peace, nnzbobjdnzmfxmtntz, zntjyugxzrtzwvznhrzzpnlraddflotncn, liveuamap, syrian
- paper_bets: today=127, 7d-median=141, 14d-median=138; carrying terms: hampshire, party, goldman, african, romania, robot, midterms, republican, minister, headline, general, miami
- weather: today=145, 7d-median=196, 14d-median=175; carrying terms: twoat, service, mount, afdmeg, swimmers, messages, central, center, oregon, level, early, miami
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: personal, jolts, pcepilfe, dexchus, crude, assets, labor, energy, openings, payrolls, cpilfesl, dexuseu
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, close, futures, nasdaq, china, crypto, proxy, corporate, bitcoin, crude, yield, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=95, 7d-median=93, 14d-median=97; carrying terms: bombing, destabilisation, prior, events, member, african, group, campaign, central, transnistrian, general, aeronautics
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quantitative, httperror, unauthorized, https, quiverquant, congresstrading, client, quiver
- billionaires: today=34, 7d-median=34, 14d-median=34; carrying terms: amazon, sergey, spain, meyers, julia, finance, canada, china, gates, jensen, thomas, infrastructure
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: group, company, supreme, court, international, connecticut, state, appeals, trust, village, delaware, america
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, partners, financial, capital, holdings, management, david, robert, magnetar
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: shawn, sherrod, alexandria, elect, committee, ocasio, ossoff, cycle, jonathan, cooper, talarico, david
- gdelt_regions: today=0, 7d-median=6, 14d-median=9; carrying terms: english, japan, surge
- gdelt_gkg: today=25, 7d-median=41, 14d-median=31; carrying terms: english, russian, china, perimeter, hormuz, russia, sanctions, strait, greek, keywords, ukrainian, business
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=29, 14d-median=30; carrying terms: position, belgium, france, kingdom, germany, aabfa, netherlands, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: contamination, prior, canada, ventilation, tristan, member, african, third, syndrome, cruise, affects, analysis
- cisa_kev: today=10, 7d-median=9, 14d-median=9; carrying terms: injection, vendor, firewall, secure, jetbrains, loadmaster, untrusted, teamcity, vulnerability, cisco, progress, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=269, 14d-median=269; carrying terms: magnitude, spain, china, canada, belize, republic, colombia, belgium, depth, medium, ukraine, gabon
- usgs_quakes: today=18, 7d-median=18, 14d-median=16; carrying terms: indonesia, depth, philippines, ruteng
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: traffic, hormuz, shakhtar, interest, strait, volume, august, championship, rates, normal, league, champions
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, marginal, economist, conversable, class, conversableeconomist, https, impossible, young, marginalrevolution, social, seems
- tech_news: today=56, 7d-median=58, 14d-median=57; carrying terms: hacker, edition, usual, weekly, systems, technology, spectrum, bleepingcomputer, problems, known, threat, cybersecurity
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: figures, lucas, espaillat, darin, armstrong, cleaver, associate, sorensen, cantwell, budzinski, guthrie, sonia
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, decision, consensus, unavailable, market, converges, sufficient, placed, markets, module, evidence, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*