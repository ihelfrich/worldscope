# WORLDSCOPE morning brief — 2026-11-02

## Headline
3143 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (822) · Russian Internal News (state + in-exile) (638) · World leaders & government officials (324) · Chinese Internal News (240) · State-Level News (184) · Local News: St. Louis + Atlanta (174) · U.S. Weather + Severe / Climate Outlooks (167) · Ukraine Theater (total-war monitoring) (160) · State Legislative Action (122) · Ukrainian Internal News (national + local Kyiv) (60) · GDACS — global disaster alerts (46) · IT, InfoSys & cybersecurity news (last 7 days) (43)

## What changed today
### International News + Multilateral Institutions — 822 new of 937 total
  - (2026-11-01) [Global] UK was ‘vehement’ slavery reparations should not be on Commonwealth summit agenda
  - (2026-11-02) [Global] Guardian Essential poll: record number of Australians are turning their backs on the Melbourne Cup
  - (2026-11-02) [Global] Reddit and libertarian group challenge Australia’s under-16s social media ban in high court
  - (2026-11-02) [Global] NSW council refuses to show world-renowned Gaza artwork over ‘unacceptable’ safety risk
  - (2026-11-02) [Global] Award‑winning Australian children’s author Craig Silvey jailed over child exploitation material
  - (2026-11-02) [Global] ‘Sharper, longer slowdown’ predicted for Australian economy as fifth interest rate hike looms

### Russian Internal News (state + in-exile) — 638 new of 841 total
  - (2026-11-02) Путин обязал владельцев частных дата-центров резервировать десятую часть своих мощностей для государства | LEDE: Владимир Путин подписал указ о мерах поддержки функционирования информационны] (ru: Пут…
      Владимир Путин подписал указ о мерах поддержки функционирования информационных ресурсов в России. Документ обязывает владельцев частных центров обработки данных резервировать 10% имеющихся площадей и мощностей для нужд г…
  - (2026-11-02) Многие российские эмигранты в Сербии остались без денег после краха банка Alta. Им обещают выплаты с замороженных счетов, но пока выкручиваться приходится самим. Вот что они придумывают — и как] (ru:…
      После того как Национальный банк Сербии отозвал лицензию у Alta — одного из немногих местных банков, открывавшего счета эмигрировавшим россиянам, — многие его клиенты остались без средств. Их деньги на ежемесячные расход…
  - (2026-11-02) Binance возобновила возможность вывода средств после хакерской атаки. Всего за десять часов клиенты вывели с биржи 3,6 миллиарда долларов | LEDE: Криптобиржа Binance, продолжающая восстанавл] (ru: Bin…
      Криптобиржа Binance, продолжающая восстанавливать работу после взлома, вернула клиентам возможность вывода средств.
  - (2026-11-02) За какой срок США выиграли бы войну во Вьетнаме, если бы не «тупые президенты»? Отвечает автор обещания завершить российско-украинскую войну за 24 часа | LEDE: . ] (ru: За какой срок США выиграли бы в…
      .
  - (2026-11-02) «Мир тюрьмы богат на ярких персонажей». В издательстве «Медузы» вышла книга политика Андрея Пивоварова. Она называется «Закрытая Россия» и рассказывает о гражданском сопротивлении и тюремном оп] (ru:…
      В издательстве «Медузы» вышла книга политика и бывшего директора «Открытой России» Андрея Пивоварова. Она называется «Закрытая Россия. Из политики в тюрьму и обратно». Пивоваров пришел в политический активизм в начале 20…
  - (2026-11-02) «Мы не считали их по головам». Лантратова заявила, что из Алешек эвакуировали «намного меньше» 750 человек | LEDE: Уполномоченный по правам человека в России Яна Лантратова заявила, что у не] (ru: «Мы…
      Уполномоченный по правам человека в России Яна Лантратова заявила, что у нее нет данных о том, сколько человек уехало из города Алешки (украинское название — Олешки) Херсонской области. Об этом она сообщила на пресс-конф…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 240 new of 281 total
  - (2026-11-01) 美军基地损失或达150亿美元，鲁比奥：还有能力打伊朗，但特朗普尚未决定 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE9OWkptNXdNeEZyclRnRW5FbEZSZkpiT0s1RHhEeHBEQ1JXSmlqSk93SnhuTVNkRi1idzk1d2pUZHpidXdz] (zh:…
      美军基地损失或达150亿美元，鲁比奥：还有能力打伊朗，但特朗普尚未决定 观察者网
  - (2026-11-01) 对仁爱礁那艘破船“不拖”，也“拖”——“不拖”破船，有效管控“拖垮”对方 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE9wWmNmWjg1QnpLOG02ZlVPZXR1SnJfYk56QXg1MWVNSC1KbFQ2d1dZT2RrUTJReUtKS3VCNURhTDh2d1hmb] (zh:…
      对仁爱礁那艘破船“不拖”，也“拖”——“不拖”破船，有效管控“拖垮”对方 风闻
  - (2026-11-02) 中国与美国，最后可能是制度对决 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE1Wc2Jvbjl4cWY4bEx3eUdYSFc5YkpQUnB5MmxWZ2JGc3RzUnlRR1I2eW1CMGRMNmI4QXFUaVRUa2UtQmlvdDFBUTNudzZEN092SE5PTE] (zh:…
      中国与美国，最后可能是制度对决 风闻
  - (2026-11-01) 印度1.3亿选民“被消失”，莫迪引众怒 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTFBDRENIcUJyMjNZUW56ZzFfM2pscVZzT2dNR1daWmNRYm9fNnB5cDNuU0s1MmwxdUtUUXMycmpwVnVRT2p5aDlydFpTTTcxQTNn] (zh:…
      印度1.3亿选民“被消失”，莫迪引众怒 观察者网
  - (2026-11-02) 出生24小时内接种卡介苗，死亡率降6%？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9tSGE0bHdocTZyVGg5TVZtZF9jMG4xd01EcnNBajJRSzBuV2Y4R3VXaUh1a3NZSER4M21QS1Yxd1JPbU1pOTd6cXVnRk5leGlIN] (zh:…
      出生24小时内接种卡介苗，死亡率降6%？ 风闻
  - (2026-11-02) 广州市委原书记郭永航被“双开” - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1uYVV3NjdHUGYxc2MybHJfVDJVRmppd2gydFB2TkJINGVsa3M2WVlLa2hxeDZfZlJSbG1SUDM3cFBEUFlUQUNVb2p3WGZnU3NTb1hz] (zh:…
      广州市委原书记郭永航被“双开” 观察者网

### State-Level News — 184 new of 312 total
  - (2026-11-02) [Connecticut] UConn’s big problem (and it’s not Matt Ritter)
      <img width="910" height="613" src="https://ctmirror.org/wp-content/uploads/2017/10/uconn-campus-shot-e1793545022566.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpr…
  - (2026-11-02) [Connecticut] New Haven’s past haunts short-term rental ordinance proposal
      <img width="720" height="633" src="https://ctmirror.org/wp-content/uploads/2026/10/William-Lanson-statue.png" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" src…
  - (2026-11-02) [Connecticut] CT just fixed paint waste challenges
      <img width="1024" height="531" src="https://ctmirror.org/wp-content/uploads/2026/10/paint-donated-1024x531.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" s…
  - (2026-11-01) [Connecticut] Fazio, Lamont and others make final push as Election Day nears
      <img width="1024" height="536" src="https://ctmirror.org/wp-content/uploads/2026/09/LamontFazio-1024x536.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" sr…
  - (2026-11-01) [Connecticut] U.S. Sen. Chris Murphy hospitalized after having a stroke
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/In-The-Room-0826-SG-01-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading…
  - (2026-11-02) [Alaska] Federal subpoenas to election officials mark escalating Trump DOJ pressure campaign
      As the Trump administration waged a public legal fight with California over the ballots of suspected noncitizen voters in mid-October, behind the scenes a federal grand jury in Santa Ana issued a series of subpoenas to e…

### Local News: St. Louis + Atlanta — 174 new of 218 total
  - (2026-11-02) [St. Louis] A UMSL researcher on why heirlooms gain meaning with use
      The holiday season is just weeks away. Do you have plans to use your good china? How about your mom’s silverware and grandma’s linens? Will they be making a cameo across your party tablescape? Using sentimental objects,…
  - (2026-11-02) [St. Louis] Northern Village woes prompt St. Louis County’s first official tenant union
      Tenants at the Northern Village complex in north St. Louis County—whose living conditions have drawn the ire of County Executive Sam Page—have elected to unionize. It’s the first tenants’ union in St. Louis County, organ…
  - (2026-11-02) [St. Louis] St. Louis County Council has a new tool for its budget crisis: a $273K AI-based platform
      The St. Louis County Council is turning to AI to help it address its budget woes. In September, the council contracted with Tyler Technologies for its AI-powered Priority Based Budgeting solution. For $273,300, the counc…
  - (2026-11-02) [St. Louis] Panelized home construction could yield new affordable housing in St. Louis quickly
      In July, drivers zipping along West Florissant Avenue in St. Louis’ Mark Twain neighborhood likely caught a glimpse of something unfortunately not more familiar in North City: a new home under construction. In just a mat…
  - (2026-11-02) [St. Louis] A winter wellness retreat at Sand Valley offers a reason to embrace the cold
      In winter, a blanket of snow covers the ancient sand dunes of Sand Valley golf course in Wisconsin. Dark evergreens border the expansive open space with dormant prairie grasses and bare shrubs, adding texture to the quie…
  - (2026-10-31) [St. Louis] Top things to do this month in St. Louis
      NOVEMBER 5–15Catch a flick (or five) at the St. Louis International Film Festival. For its 35th iteration—themed “The Declaration of Independents”—the festival will host dozens of new independent films in theaters across…

### U.S. Weather + Severe / Climate Outlooks — 167 new of 169 total
  - (2026-11-02) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued November 2 at 10:48AM EST until November 2 at 11:15AM EST by NWS Melbourne FL
      SVRMLB The National Weather Service in Melbourne has issued a * Severe Thunderstorm Warning for... Southeastern Indian River County in east central Florida... St. Lucie County in east central Florida... * Until 1115 AM E…
  - (2026-11-02) [Severe] Special Marine Warning: Special Marine Warning issued November 2 at 10:46AM EST until November 2 at 11:15AM EST by NWS Melbourne FL
      SMWMLB The National Weather Service in Melbourne has issued a * Special Marine Warning for... Sebastian Inlet to Jupiter Inlet 0-20 nm... * Until 1115 AM EST. * At 1046 AM EST, a strong thunderstorm was located over Port…
  - (2026-11-02) [Moderate] Special Weather Statement: Special Weather Statement issued November 2 at 10:45AM EST by NWS Melbourne FL
      At 1045 AM EST, Doppler radar was tracking a strong thunderstorm over Port Saint Lucie River Park, or near Port Saint Lucie, moving northwest at 40 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT.…
  - (2026-11-02) [Severe] Flash Flood Warning: Flash Flood Warning issued November 2 at 10:45AM EST until November 2 at 1:45PM EST by NWS Tampa Bay Ruskin FL
      FFWTBW The National Weather Service in Tampa Bay Ruskin has issued a * Flash Flood Warning for... Hardee County in central Florida... Northern DeSoto County in south central Florida... Southwestern Highlands County in so…
  - (2026-11-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-02) [Severe] Flash Flood Warning: Flash Flood Warning issued November 2 at 10:41AM EST until November 2 at 1:45PM EST by NWS Melbourne FL
      FFWMLB The National Weather Service in Melbourne has issued a * Flash Flood Warning for... Southeastern Indian River County in east central Florida... Northeastern Martin County in east central Florida... Central St. Luc…

### Ukraine Theater (total-war monitoring) — 160 new of 369 total
  - (2026-11-01) [FIRMS] thermal anomaly 50.545, 26.259 (FRP 1.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-11-01 0052Z, FRP 1.29 MW
  - (2026-11-01) [FIRMS] thermal anomaly 48.974, 24.712 (FRP 1.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-11-01 0054Z, FRP 1.03 MW
  - (2026-11-01) [FIRMS] thermal anomaly 46.758, 33.351 (FRP 1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-11-01 0054Z, FRP 1 MW
  - (2026-11-01) [FIRMS] thermal anomaly 47.784, 29.015 (FRP 0.6 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-11-01 0054Z, FRP 0.6 MW
  - (2026-11-01) [FIRMS] thermal anomaly 47.790, 28.954 (FRP 1.16 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-11-01 0054Z, FRP 1.16 MW
  - (2026-11-01) [FIRMS] thermal anomaly 45.358, 30.903 (FRP 0.43 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-11-01 0054Z, FRP 0.43 MW

### State Legislative Action — 122 new of 137 total
  - (2026-11-02) [Arkansas HB 1001] TO REDUCE THE INCOME TAX RATES FOR INDIVIDUALS, TRUSTS, ESTATES, AND CORPORATIONS.
      TO REDUCE THE INCOME TAX RATES FOR INDIVIDUALS, TRUSTS, ESTATES, AND CORPORATIONS.
  - (2026-11-02) [Arkansas SB 1] TO REDUCE THE INCOME TAX RATES FOR INDIVIDUALS, TRUSTS, ESTATES, AND CORPORATIONS.
      TO REDUCE THE INCOME TAX RATES FOR INDIVIDUALS, TRUSTS, ESTATES, AND CORPORATIONS.
  - (2026-10-31) [Oregon HB 4124] Relating to the state post-secondary education system; and declaring an emergency.
      ] Directs the Higher Education Coordinating Commission to conduct a study of the condition of Oregon's post-secondary education system and to develop detailed recommendations for the design, implementation and operation…
  - (2026-10-31) [Oregon HB 4075] Relating to hospital finance; and declaring an emergency.
      ] [ Authorizes ] Requires the State Treasurer to [ loan ] use up to [ 20 percent of ] $44 million from the Unclaimed Property and Estates Fund to guarantee a loan made to a rural [ hospitals ] hospital for financial stab…
  - (2026-10-31) [Oregon HB 4134] Relating to funding for natural resource matters; prescribing an effective date; and providing for revenue raising that requires approval by a three-fifths majority.
      Increases the state transient lodging tax. Changes the name of the Oregon Conservation Strategy Subaccount to the Recovering Oregon's Wildlife Fund Subaccount. Specifies how moneys attributable to the increase are to be…
  - (2026-10-31) [Oregon HB 4115] Relating to health care providers; and prescribing an effective date.
      Provides that a criminal records check on certain caregivers shall last for three years, subject to exceptions. Requires certain valid criminal records checks to be portable to other care settings. Requires the authority…

### Ukrainian Internal News (national + local Kyiv) — 60 new of 118 total
  - (2026-11-02) На Київщині біля будинку, де перебувають військові Нацгвардії, сталися заворушення | LEDE: Поліція Київської області повідомила про заворушення біля приватного будинку у селі Петропавлівська Бо] (uk:…
      Поліція Київської області повідомила про заворушення біля приватного будинку у селі Петропавлівська Борщагівка на Київщині, де перебувають військовослужбовці одного з підрозділів Національної гвардії України. На місце пр…
  - (2026-11-02) Співпраця з Трампом і зупинка допомоги Україні: німецька "АдН" презентувала свою програму | LEDE: Ультраправі Німеччини пропонують відновити «Північний потік», припинити підтримку України й пра] (uk:…
      Ультраправі Німеччини пропонують відновити «Північний потік», припинити підтримку України й прагнуть співпраці з адміністрацією Трампа.
  - (2026-11-02) Ковальський: Арахамію "в житті не бачив", з Татаровим не спілкувався, а з Покладом зустрічався 5–6 разів | LEDE: Виконувач обов'язків генерального прокурора Антон Ковальський заявив, що не спіл] (uk:…
      Виконувач обов'язків генерального прокурора Антон Ковальський заявив, що не спілкувався з Олегом Татаровим, ніколи не бачив Давида Арахамію, а з Олександром Покладом зустрічався приблизно п'ять чи шість разів і підтримує…
  - (2026-11-02) "Не через ділові якості": Ковальський розкритикував призначення Кропиви й повідомив про нову справу | LEDE: Виконувач обов'язків генерального прокурора Антон Ковальський повідомив, що зареєстру] (uk:…
      Виконувач обов'язків генерального прокурора Антон Ковальський повідомив, що зареєстрував нове кримінальне провадження щодо фігуранта справи "Карфаген" Сергія Кропиви, який, за результатами службового розслідування, їздив…
  - (2026-11-02) Залишив печатку в кабінеті й зник: в ОГП завершили розслідування втечі Кравченка за кордон | LEDE: Виконувач обов'язків генерального прокурора Антон Ковальський заявив про завершення службового] (uk:…
      Виконувач обов'язків генерального прокурора Антон Ковальський заявив про завершення службового розслідування обставин виїзду за кордон ексгенпрокурора Руслана Кравченка.
  - (2026-11-02) Угорщина підняла винищувачі, щоб супроводити літак після повідомлення про загрозу вибуху | LEDE: Міністр оборони Угорщини повідомив: через погрозу вибуху на рейсі Wizz Air винищувачі супроводил] (uk:…
      Міністр оборони Угорщини повідомив: через погрозу вибуху на рейсі Wizz Air винищувачі супроводили літак до аеропорту Будапешта.

### GDACS — global disaster alerts — 46 new of 100 total
  - (2026-11-02) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.1M, Depth:67.239km
  - (2026-11-02) [Green] Earthquake in South Of Fiji Islands
      Earthquake · Green alert · South Of Fiji Islands · Magnitude 4.7M, Depth:502.364km
  - (2026-11-02) [Green] Earthquake in Greece
      Earthquake · Green alert · Greece · Magnitude 4.7M, Depth:40.168km
  - (2026-11-02) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 4.7M, Depth:35km
  - (2026-11-02) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.1M, Depth:196.646km
  - (2026-11-02) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 4.9M, Depth:87.891km

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 61 total
  - (2026-11-02) [BleepingComputer] BTCPay Server warns of hot wallet thefts targeting outdated instances
      The maintainer of BTCPay Server, an open-source cryptocurrency payment processor, has urged users to install the latest version as hackers have been draining "hot wallets" on instances running older versions. [...]
  - (2026-11-02) [BleepingComputer] Your Mobile Carrier Stores Your Call Logs for Years
      Mobile carriers can retain years of call and text metadata, exposing sensitive details about customers' relationships, locations, and daily routines if breached. Cape examines the privacy risks of long-term telecom data…
  - (2026-11-02) [BleepingComputer] Hackers disrupt refrigeration systems at European supermarkets
      A cyberattack on refrigeration systems has disrupted stores run by multiple supermarket chains across several European countries after hackers remotely changed temperature settings on freezers and cooling systems. [...]
  - (2026-11-02) [BleepingComputer] Microsoft fixes Smart App Control broken by October Windows update
      Microsoft has resolved a known issue that prevented some users from activating the Smart App Control security feature after installing the October 2026 KB5127648 Windows 11 security update. [...]
  - (2026-11-02) [BleepingComputer] Over 1,000 GitLab servers vulnerable to ongoing RCE attacks
      Over 1,000 Internet-exposed GitLab servers are still unpatched against a maximum-severity flaw actively exploited in remote code execution attacks. [...]
  - (2026-11-02) [The Hacker News] DarkBlinders Compromises Israeli Target and Iraqi Kurdish Government Cloud Environment
      Cybersecurity researchers have disclosed details of a cyber espionage campaign targeting Israel and the Kurdistan Region of Iraq by an Iran state-aligned threat actor between August and October 2026. According to a repor…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-02) [Dierker Richard A] Form 4 (Reporting)
      filed 2026-11-02 15:54 UTC · role: Reporting — Filed: 2026-11-02 AccNo: 0000313927-26-000338 Size: 5 KB
  - (2026-11-02) [CHURCH & DWIGHT CO INC /DE/] Form 4 (Issuer)
      filed 2026-11-02 15:54 UTC · role: Issuer — Filed: 2026-11-02 AccNo: 0000313927-26-000338 Size: 5 KB
  - (2026-11-02) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-11-02 15:53 UTC — Filed: 2026-11-02 AccNo: 0001918704-26-033704 Size: 466 KB
  - (2026-11-02) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-11-02 15:53 UTC — Filed: 2026-11-02 AccNo: 0001918704-26-033704 Size: 466 KB
  - (2026-11-02) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-11-02 15:52 UTC — Filed: 2026-11-02 AccNo: 0001839882-26-054013 Size: 852 KB
  - (2026-11-02) 424B2 - Wells Fargo Finance LLC (0001738143) (Filer)
      filed 2026-11-02 15:51 UTC — Filed: 2026-11-02 AccNo: 0001839882-26-054012 Size: 429 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-11-02) PAT700 (United States)
      icao24: adfee0 · position: (33.9608, -91.2781) · alt: 6393m · 368km/h
  - (2026-11-02) JAF3YG (Bulgaria)
      icao24: 4520aa · position: (34.5348, -4.4551) · alt: 10980m · 873km/h
  - (2026-11-02) PAT098 (United States)
      icao24: adfe91 · position: (33.7144, -118.1739) · alt: 3223m · 297km/h
  - (2026-11-02) CFC3121 (Canada)
      icao24: c2c1fb · position: (53.3143, -60.4099) · on ground · 0km/h
  - (2026-11-02) PAT044 (United States)
      icao24: adfe97 · position: (36.5929, -81.5274) · alt: 6096m · 462km/h
  - (2026-11-02) PAT957 (United States)
      icao24: adfe8d · position: (37.0223, -87.0319) · alt: 1341m · 354km/h

### USGS earthquakes (M4.5+, past day) — 22 new of 22 total
  - (2026-11-02) M 5.1 - 50 km WSW of Huarmey, Peru
      M5.1 · 50 km WSW of Huarmey, Peru · depth 67.239 km
  - (2026-11-02) M 5.1 - 19 km WNW of Tomohon, Indonesia
      M5.1 · 19 km WNW of Tomohon, Indonesia · depth 196.646 km
  - (2026-11-02) M 5.1 - Kermadec Islands region
      M5.1 · Kermadec Islands region · depth 10 km
  - (2026-11-02) M 5.1 - Banda Sea
      M5.1 · Banda Sea · depth 93.548 km
  - (2026-11-01) M 5.1 - South Sandwich Islands region
      M5.1 · South Sandwich Islands region · depth 108.234 km
  - (2026-11-01) M 5.0 - Mid-Indian Ridge
      M5.0 · Mid-Indian Ridge · depth 10 km

### Paper Trading Scorecard — 12 new of 63 total
  - (2026-11-02) [Polymarket] Will Avengers: Doomsday have the 2nd best domestic opening weekend in 2026?
      This market will resolve according to the title of the movie which grosses the second-most domestically on its opening weekend among all movies in 2026. The "Weekend Box Office Performance" table on the page for the rele…
  - (2026-11-02) [Polymarket] Will WTI Crude Oil (WTI) hit (HIGH) $130 in November?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of November 2026, any Pyth 1-minute candle for the Active Month of ICE Futures Europe WTI Crude Futures (denoted by Py…
  - (2026-11-02) [Polymarket] Will Trump and Putin meet next in Switzerland?
      This market will resolve according to the location of the next meeting between Donald Trump and Vladimir Putin between market creation and December 31, 2026, 11:59 PM ET. This market will resolve to "No meeting by Decemb…
  - (2026-11-02) [Manifold] Will a new element be discovered before 2030?
  - (2026-11-02) [Manifold] Democrats win 53+ Senate seats and 240+ House seats in 2026 Midterms?
  - (2026-11-02) [Manifold] Will Republican chances to win the house go above 5% again?

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-11-02) Will the Republican Party control the Senate after the 2026 Midterm elections?
      yes price: 28% · 24h volume: $1,638,865 · resolves 2026-11-04
  - (2026-11-02) Will Nikki Haley win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $1,579,731 · resolves 2028-11-08
  - (2026-11-02) 2026 Balance of Power: R Senate, R House
      yes price: 4% · 24h volume: $1,105,660 · resolves 2026-11-04
  - (2026-11-02) Will the Democratic Party control the Senate after the 2026 Midterm elections?
      yes price: 74% · 24h volume: $916,606 · resolves 2026-11-04
  - (2026-11-02) Will Tim Scott win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $667,261 · resolves 2028-11-08
  - (2026-11-02) Will Newcastle United FC win on 2026-11-02?
      yes price: 44% · 24h volume: $666,876 · resolves 2026-11-02

### Campaign finance (FEC: top fundraisers + recent filings) — 10 new of 27 total
  - (2026-11-01) [F6] DUNLAP FOR CONGRESS
      cycle 2026 · filing #2045395
  - (2026-11-01) [F3X] VOLUNTEERS FOR DEMOCRACYS FUTURE PAC
      cycle 2026 · filing #2045264
  - (2026-11-01) [F6] VERONICA ESCOBAR FOR CONGRESS
      cycle 2026 · filing #2045477
  - (2026-11-01) [F6] ABDUL FOR U.S. SENATE
      cycle 2026 · filing #2045359
  - (2026-11-01) [F6] MCGUIRE FOR VIRGINIA
      cycle 2026 · filing #2045538
  - (2026-11-01) [F6] PIA DANDIYA FOR CONGRESS
      cycle 2026 · filing #2045449

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-02) [Marginal Revolution] Expensive Pharmaceuticals for Targeted Diseases
      My latest paper, The Price of a Cure: Luxturna and the Economic Dilemmas of Precision Medicine, is in the Journal of Law, Medicine and Ethics. I discuss the economics of the pharmaceutical industry and the special issues…
  - (2026-11-02) [Marginal Revolution] Should you feel grief for the dead who go to heaven?
      I am not myself religious, but let us consider the possible gulf between behavior and doctrine amongst those who are. It has long struck me as a kind of mini-puzzle why people feel so much grief for the departed, at leas…
  - (2026-11-02) [Conversable Economist] Why the Americans Appear So Restless Amid Their Well-Being: Election Day Thoughts
      Alexis de Tocqueville came from France and traveled across the United States in 1831, and several years later published his reflections about Americans and America in the classic Democracy in America. In volume 2, publis…
  - (2026-11-01) [Marginal Revolution] As predicted, the ACA exchanges seem not to be stable
      The average price of health insurance in the Obamacare marketplaces will rise by 13 percent next year, according to an analysis on Friday by KFF, the health research group. The Trump administration on Friday published ne…

### Government Action: Sanctions + Procurement + Foreign Agents — 3 new of 53 total
  - (2026-10-26) [OFAC] 53 - Office of Foreign Assets Control (.gov)
      53 Office of Foreign Assets Control (.gov)
  - (2026-10-26) [OFAC] 35 - Office of Foreign Assets Control (.gov)
      35 Office of Foreign Assets Control (.gov)
  - (2026-11-02) [USASpending] $44,093,914,875 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-11-02) Shamonda virus in human - France
      On 20 October 2026, the National IHR Focal Point (NFP) of France notified WHO regarding the first documented human infection with Shamonda virus (SHAV). The case was an immunocompromised older man from eastern France wit…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=15, 14d-median=15; carrying terms: procedures, action, regulatory, certain, final, proposed, commission, national, persons, safety, enforcement, proposing
- state_bills: today=137, 7d-median=115, 14d-median=108; carrying terms: person, county, review, election, alaska, duties, taxes, property, local, including, certain, committee
- state_news: today=312, 7d-median=724, 14d-median=678; carrying terms: agency, attack, background, nonprofit, candidates, democrat, loading, latest, request, hampshire, families, toomanyredirects
- local_news: today=218, 7d-median=260, 14d-median=241; carrying terms: weekend, person, county, arrested, house, https, incident, children, college, million, officer, florida
- foreign_news: today=937, 7d-median=1006, 14d-median=1006; carrying terms: agency, bringing, already, cancer, candidates, netanyahu, latest, arrested, punchng, opposition, maverick, explaining
- chinese_internal: today=281, 7d-median=281, 14d-median=278; carrying terms: google, china, cbmib, articles, color, cbmidefvx, cbmizkfvx, cbmizefvx, cbmix, https, cbmibefvx, cbmiy
- russian_internal: today=841, 7d-median=991, 14d-median=991; carrying terms: blank, reuters, forbidden, error, laquo, times, novaya, istories, target, https, httperror, starlink
- ukrainian_internal: today=118, 7d-median=129, 14d-median=131; carrying terms: attack, error, andrii, latest, strikes, assessment, infrastructure, offensive, https, washington, meeting, client
- ukraine_theater: today=369, 7d-median=377, 14d-median=392; carrying terms: pazznz, ppwkwyv, ejzvsnpuqzfvy, zgnns, lwutzwxzk, check, tfpnb, condensate, zlujq, vkjamv, mfmttfdtcq, dgswzpehd
- paper_bets: today=63, 7d-median=64, 14d-median=65; carrying terms: president, nominal, koivun, headline, successor, speed, prize, leave, netanyahu, growth, jinping, leaders
- weather: today=169, 7d-median=134, 14d-median=136; carrying terms: monday, western, sweep, marine, counties, patchy, worth, weekend, lower, waves, houston, isolated
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unemployment, walcl, money, rates, vixcls, implied, jtsjol, sheet, commodities, cpiaucsl, funds, effective
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, large, rates, treasury, range, nasdaq, agriculture, proxy, bitcoin, russell, silver, close
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=53, 7d-median=104, 14d-median=104; carrying terms: blank, development, congo, transactions, solutions, agency, updates, award, checksum, cbmizefvx, activities, color
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, client, unauthorized, quantitative, congresstrading, https, quiver, quiverquant, error
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=4, 7d-median=60, 14d-median=60; carrying terms: state, court, international, supreme, florida, jesse, south
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, holdings, filer, trust, finance, estate, america, citigroup, richard
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, congress, cycle, sayed, james, receipts, sherrod, trone, ossoff, cooper, abdul, krishnamoorthi
- gdelt_regions: today=0, 7d-median=6, 14d-median=12
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: english, keywords, israel, spanish, elections, themes, sanctions
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, kingdom, france, ground, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: inconclusive, congo, kingdom, nigeria, contaminated, ebola, intensifying, accordance, hospitalized, experiencing, resulting, cruise
- cisa_kev: today=18, 7d-median=18, 14d-median=18; carrying terms: vendor, remediation, injection, secure, improper, control, product, server, command, vulnerability, authentication, external
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: forest, cyclone, impact, papua, earthquake, forestfire, nigeria, australia, green, hurricane, typhoon, speed
- usgs_quakes: today=22, 7d-median=17, 14d-median=22; carrying terms: depth, islands, philippines, japan, indonesia, papua, russia, region, guinea, south, kuril, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, volume, election, october, presidential, minister, power, balance, prime, benjamin, netanyahu
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, economist, marginal, class, conversable, revolution, world, marginalrevolution, countries, money, access, government
- tech_news: today=61, 7d-median=56, 14d-median=57; carrying terms: group, friday, spectrum, already, computerweekly, attackers, investigation, record, review, infrastructure, computer, https
- political_figures: today=0, 7d-median=613, 14d-median=613; carrying terms: harold, salazar, mccormick, maria, schiff, hillary, agriculture, kustoff, sonia, powell, vance, rogers
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, market, consensus, markets, evidence, converges, claude, unavailable, paper, identify, sufficient, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] ECB press: ECB President Lagarde to step down on 7 February 2027
- [2026-10-29] ECB press: Monetary policy decisions
- [2026-10-29] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-10-29] ECB press: Piero Cipollone: Next-day securities settlement, tokenisation and the transformation of Europe’s financial infrastructure
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Results of the ECB Survey of Professional Forecasters for the fourth quarter of 2026
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*