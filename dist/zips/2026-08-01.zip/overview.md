# WORLDSCOPE morning brief — 2026-08-01

## Headline
2961 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (628) · Russian Internal News (state + in-exile) (544) · Ukraine Theater (total-war monitoring) (524) · World leaders & government officials (324) · Chinese Internal News (188) · U.S. Weather + Severe / Climate Outlooks (165) · Local News: St. Louis + Atlanta (156) · State-Level News (92) · State Legislative Action (82) · Ukrainian Internal News (national + local Kyiv) (57) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 628 new of 1051 total
  - (2026-08-01) [Global] Homemade bomb goes off outside upscale Moscow restaurant state officials say
      Russian authorities said the blast occurred outside a restaurant on Kudrinskaya Square when a woman allegedly carrying explosives was stopped by a security guard.
  - (2026-08-01) [Global] 13 dead after small tourist plane crashes in Peru
      The plane was taking tourists to see the Nazca Lines, a group of geoglyphs etched into the deserts of southern Peru.
  - (2026-08-01) [Global] How does eastern Europe commemorate the Roma Holocaust?
      In 2015, the EU designated August 2 as the European Roma Holocaust Memorial Day. In Germany, the day is marked with memorial services, educational activites and public addresses. And in eastern Europe?
  - (2026-08-01) [Global] Germany news: Big turnout for Pride after Berlin attack
      Several German cities are holding Pride events a week after a deadly attack on a march in Berlin. A forest fire is burning out of control in Bavaria. DW has more.
  - (2026-08-01) [Global] Germany's long road to equality for same-sex couples
      In 2001, same-sex couples in Germany were able to register a civil partnership for the first time. The Civil Partnership Act was a crucial step toward "marriage for all," which was introduced in 2017.
  - (2026-08-01) [Global] Germany widens deportations to Afghanistan
      Earlier this week, Germany for the first time deported a man with no criminal record to Kabul. Faridoon Tofan, who is currently in deportation detention, fears the same fate.

### Russian Internal News (state + in-exile) — 544 new of 854 total
  - (2026-08-01) Теракт в московском ресторане. Бомбу должны были пронести на празднование дня рождения главкома ВКС Александра Чайко. Погибли три человека, 21 получил ранения | LEDE: На Кудринской площади в] (ru: Тер…
      На Кудринской площади в Москве произошел взрыв. Информацию об этом подтвердило ГУ МВД по Москве. Как уточняет Baza, взрыв произошел в ресторане «Balzi Rossi», находящемся на первом этаже сталинской высотки.
  - (2026-08-01) Житель Хабаровска умер после того, как сотрудники Росгвардии избили его при задержании. СК отрицает, что эти два события связаны | LEDE: Житель Хабаровского края умер при задержании сотрудни] (ru: Жит…
      Житель Хабаровского края умер при задержании сотрудниками Росгвардии. Об этом сообщает прокуратура региона.
  - (2026-08-01) Украина потопила российский контейнеровоз в Черном море | LEDE: Морские дроны ВСУ атаковали контейнеровоз «Янина», принадлежащей компании Fesco, которая входит в структуры «Росатома». Об это] (ru: Укр…
      Морские дроны ВСУ атаковали контейнеровоз «Янина», принадлежащей компании Fesco, которая входит в структуры «Росатома». Об этом сообщил глава госкорпорации Алексей Лихачев.
  - (2026-08-01) Самый известный альпинист в мире Нирмал Пурджа погиб во время восхождения в Пакистане. Вместе с девятью альпинистами он попал под лавину | LEDE: Самый известный из действующих альпинистов ми] (ru: Сам…
      Самый известный из действующих альпинистов мира, которого многие знают благодаря рекорду по покорению 14 высочайших гор в мире, Нирмал Пурджа погиб в результате схода лавины. Это произошло на горе Броуд-Пик высотой 8047…
  - (2026-08-01) «На все мои протесты они отвечали, что все окей, у тебя нет проблем». Активистка Ариадна Литвинова рассказала подробности депортации из Турции | LEDE: Активистка Ариадна Литвинова, в начале ] (ru: «На…
      Активистка Ариадна Литвинова, в начале июля 2026-го высланная из Турции в Россию, где ее обвиняют в повторной «дискредитации» армии, рассказала подробности своей депортации. Письмо Литвиновой из СИЗО опубликовал у себя в…
  - (2026-08-01) «Законная ли это цель? Может, юридически и нет, а вот по здравому смыслу — вполне себе да. Это точно не детский сад». Что думают читатели «Медузы» из Украины об ударах по складам Wildberries | ] (ru:…
      Немногим более недели назад мы спросили вас, наших читателей, что вы думаете об ударах украинской армии по складам Wildberries, а затем выпустили отдельный материал с подборкой ваших писем (в основном, там были письма чи…

### Ukraine Theater (total-war monitoring) — 524 new of 1105 total
  - (2026-08-01) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-31) [FIRMS] thermal anomaly 50.737, 30.654 (FRP 0.26 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-31 2335Z, FRP 0.26 MW
  - (2026-07-31) [FIRMS] thermal anomaly 50.906, 24.961 (FRP 0.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-31 2335Z, FRP 0.38 MW
  - (2026-07-31) [FIRMS] thermal anomaly 50.229, 33.353 (FRP 1.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-31 2335Z, FRP 1.35 MW
  - (2026-07-31) [FIRMS] thermal anomaly 50.461, 30.453 (FRP 9.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-31 2335Z, FRP 9.28 MW
  - (2026-07-31) [FIRMS] thermal anomaly 50.461, 30.460 (FRP 9.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-31 2335Z, FRP 9.28 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 188 new of 299 total
  - (2026-07-30) Robotics Startup Unitree Launches $620 Million STAR Market IPO - Caixin Global
      Robotics Startup Unitree Launches $620 Million STAR Market IPO Caixin Global
  - (2026-07-30) 复旦大学经济学院院长张军：比照印度才明白“大一统”对中国创新有多重要 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5XRXdpWHVIOUZmQ1JsZWd2U2ZJZ1pqd0Y3OTFoOVhIUndlOEgtZFhCMjAxeXVaM1JOQ3VzMHFhbEE4aklaa] (zh:…
      复旦大学经济学院院长张军：比照印度才明白“大一统”对中国创新有多重要 观察者网
  - (2026-07-30) 伊朗将接收中国造肩扛式防空导弹发射装置？外交部回应：不符合事实 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5Vd3hCcTZiTkZWSmwtUUV4Qm1NTm9CZkNhaC1uNkUtXzlsQ3lSSHZ5OWhSSXk3MTZST1FmZjRIRE1CUzNJY1Qz] (zh:…
      伊朗将接收中国造肩扛式防空导弹发射装置？外交部回应：不符合事实 观察者网
  - (2026-07-31) 中央军委主席习近平签署通令，给1名个人记功 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE00bGFDQ0g2OTdYV2RyeUpjZ3dIbDU5T29HMl9kY0RiODBWWC1nSkplWGNPUGQ4N3RveHgwUzJMNUdfazBITmdQQ0Z6cFlaRk] (zh:…
      中央军委主席习近平签署通令，给1名个人记功 观察者网
  - (2026-07-31) 多国签署《关于成立世界人工智能合作组织的协定》 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTFBRT2NJN3NybTFQTVhPQm5uNm9jb3lIRFN2YVZzTnNURTBKMDFxWUE3STVObjZsT3BaNVlLQjl1blQxejY0am5iV2JpUndl] (zh:…
      多国签署《关于成立世界人工智能合作组织的协定》 观察者网
  - (2026-08-01) 现场画面！事关黄岩岛，南部战区、中国海警同日行动 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE9Ia1lqSnBMMEVqbG5UWDdzZXNsc0U5RkJzYU9fM2xmUlctdEZoaWdnUHY2UUo1REVMRVcwc1JzR19tbHhvVnZVejNMLWF] (zh:…
      现场画面！事关黄岩岛，南部战区、中国海警同日行动 观察者网

### U.S. Weather + Severe / Climate Outlooks — 165 new of 167 total
  - (2026-08-01) [Moderate] Special Weather Statement: Special Weather Statement issued August 1 at 6:33PM CDT by NWS Birmingham AL
      At 633 PM CDT, Doppler radar was tracking a strong thunderstorm near Munford, or 7 miles northeast of Talladega, moving east at 25 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds cou…
  - (2026-08-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 1 at 7:33PM EDT until August 1 at 8:00PM EDT by NWS Peachtree City GA
      SVRFFC The National Weather Service in Peachtree City has issued a * Severe Thunderstorm Warning for... Northeastern Floyd County in northwestern Georgia... Southwestern Whitfield County in northwestern Georgia... Southe…
  - (2026-08-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 1 at 7:32PM EDT until August 2 at 8:00PM EDT by NWS Wilmington NC
      * WHAT...Strong south to north longshore current. There is also a Moderate Risk of rip currents expected. * WHERE...In North Carolina, Coastal Pender and Coastal New Hanover Counties. In South Carolina, Coastal Horry and…
  - (2026-08-01) [Moderate] Special Weather Statement: Special Weather Statement issued August 1 at 5:31PM MDT by NWS Albuquerque NM
      At 531 PM MDT, Doppler radar was tracking an area of strong thunderstorms 14 miles southwest of Hayden, or 16 miles southwest of Amistad, moving southwest at 25 mph. HAZARD...Wind gusts up to 50 mph and nickel size hail.…
  - (2026-08-01) [Extreme] Tornado Warning: Tornado Warning issued August 1 at 7:31PM EDT until August 1 at 8:00PM EDT by NWS Wilmington OH
      TORILN The National Weather Service in Wilmington has issued a * Tornado Warning for... East central Wayne County in east central Indiana... Northwestern Preble County in west central Ohio... Southern Darke County in wes…
  - (2026-08-01) [Moderate] Special Weather Statement: Special Weather Statement issued August 1 at 7:30PM EDT by NWS Blacksburg VA
      At 730 PM EDT, Doppler radar was tracking a cluster of strong thunderstorms near Francisco, moving northeast at 20 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tr…

### Local News: St. Louis + Atlanta — 156 new of 255 total
  - (2026-08-01) [St. Louis] 10 art exhibits to catch this month
      Whether you’re interested in contemplating independence, exploring stylistic pioneers, or catching the final days of spring and summer programming, there is plenty to take in this month at the city’s many museums and gal…
  - (2026-08-01) [St. Louis] Fall & Winter Arts Guide 2026
      August STL Fringe Fest AUGUST 4–9 Uncensored, original, and raucous are just a few ways to describe the annual STL Fringe Fest. For its 15th year, the fest will take over a variety of stages in Grand Center and beyond, f…
  - (2026-08-01) [St. Louis] 1 person dead following crash near Campbell Avenue and Broadway
      Police are advising drivers to avoid the area.
  - (2026-08-01) [St. Louis] 3 dead, 2 hurt in shooting near Idaho In-N-Out
      A spokesperson for the Twin Falls Police Department told NBC three people are dead and two more were hurt as a result of the shooting.
  - (2026-08-01) [St. Louis] Dellwood celebrates 75 years with community festival honoring city's history
      City leaders say the milestone is an opportunity to celebrate Dellwood's rich history.
  - (2026-08-01) [St. Louis] 1 hurt in overnight shooting near Halls Ferry Road in North County
      Police responded to the scene just before 11:30 p.m.

### State-Level News — 92 new of 758 total
  - (2026-08-01) [California] Fierce floods or wild waves? How San Diego is preparing for a winter of extreme weather under El Niño.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/020224_Flood-San-Diego_AH_CM_16.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-08-01) [Colorado] Coloradans celebrate 150 years of statehood on a historic Colorado Day
      Coloradans young and old spent a hot, sunny day in downtown Denver celebrating 150 years of Centennial State history with cake, sing-alongs, art projects, Legos, lowriders and even a square dance routine in the halls of…
  - (2026-08-01) [Colorado] Fifty for 150: Local boosters and ‘party trickery’ secured statehood for Colorado in 1876
      Colorado may have always been destined to attain statehood, but it owes its identity as the Centennial State to the partisan political interests of the Reconstruction-era Republican Party. The timing of Colorado’s admiss…
  - (2026-08-01) [Alaska] Shooting Sports Month 2026
      WHEREAS, Alaskans enjoy a variety of outdoor activities throughout the year, and many of those activities, from hiking and hunting to recreational shooting, involve the use of firearms; and WHEREAS, many Alaskans rely on…
  - (2026-08-01) [Alaska] First week of third gasline special session ends with no action by Dunleavy or Alaska Legislature
      The Alaska Legislature ended the first week of its third special session on the proposed trans-Alaska natural gas pipeline with no action. The session is for lawmakers to consider a property tax break to incentivize the…
  - (2026-07-31) [Alaska] After federal report, Alaska pilots grapple with unanswered questions in tragic Nome crash
      The National Transportation Safety Board on Thursday released the final report for the February 6, 2025, accident involving Bering Air flight 445 that killed all 10 people on board. While the NTSB’s report identifies air…

### State Legislative Action — 82 new of 106 total
  - (2026-08-01) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-08-01) [Alaska SB 181] An Act relating to disclosure of information obtained by the Department of Labor and Workforce Development to other state agencies.
      An Act relating to disclosure of information obtained by the Department of Labor and Workforce Development to other state agencies.
  - (2026-08-01) [Alaska SB 205] An Act relating to occupational disability benefits for peace officers and firefighters; and providing for an effective date.
      An Act relating to occupational disability benefits for peace officers and firefighters; and providing for an effective date.
  - (2026-08-01) [Alaska SB 233] An Act relating to the Controlled Substances Advisory Committee.
      An Act relating to the Controlled Substances Advisory Committee.
  - (2026-08-01) [Alaska SB 35] An Act relating to transportation network companies and delivery network companies; and relating to occupational accident insurance.
      An Act relating to transportation network companies and delivery network companies; and relating to occupational accident insurance.
  - (2026-08-01) [Alaska SB 163] An Act relating to inactive state accounts and funds; repealing the public access fund; repealing the Alaska temporary assistance program emergency account; repealing the 2001 Special…
      An Act relating to inactive state accounts and funds; repealing the public access fund; repealing the Alaska temporary assistance program emergency account; repealing the 2001 Special Olympics World Winter Games reserve…

### Ukrainian Internal News (national + local Kyiv) — 57 new of 133 total
  - (2026-08-02) Прем'єр Франції заявив, що лісові пожежі вдалось взяти під контроль | LEDE: Пожежі у Франції під контролем, ситуація у Жироні стабілізована. Вжито додаткові заходи.] (uk: Прем'єр Франції заявив, що лі…
      Пожежі у Франції під контролем, ситуація у Жироні стабілізована. Вжито додаткові заходи.
  - (2026-08-02) Литва викличе представника РФ через пошкодження свого посольства в Києві під час російської атаки | LEDE: МЗС Литви викличе представника Росії після ракетної атаки, що пошкодила посольство у Ки] (uk:…
      МЗС Литви викличе представника Росії після ракетної атаки, що пошкодила посольство у Києві.
  - (2026-08-01) Сотні тисяч людей вийшли на прайди в Гамбурзі і Амстердамі | LEDE: ] (uk: Сотні тисяч людей вийшли на прайди в Гамбурзі і Амстердамі)
  - (2026-08-01) У Росії заявили, що в московському ресторані підірвали вибухівку | LEDE: У центрі Москви підірвали ресторан Balzi Rossi, 3 загиблих, 21 поранений. Жінка намагалася пронести вибуховий пристрій.] (uk: У…
      У центрі Москви підірвали ресторан Balzi Rossi, 3 загиблих, 21 поранений. Жінка намагалася пронести вибуховий пристрій.
  - (2026-08-01) Ветерана KRAKEN відправили під цілодобовий домашній арешт – ЗМІ | LEDE: Ветерану KRAKEN Глібу Новостройному призначено цілодобовий домашній арешт. Суть підозри офіційно не розголошують.] (uk: Ветерана…
      Ветерану KRAKEN Глібу Новостройному призначено цілодобовий домашній арешт. Суть підозри офіційно не розголошують.
  - (2026-08-01) Генштаб: Найбільше атак за день – на Покровському й Південно-Слобожанському напрямках | LEDE: ЗСУ відбили 193 атаки ворога на різних напрямках фронту. Найбільші бої — на Покровському та Південн] (uk:…
      ЗСУ відбили 193 атаки ворога на різних напрямках фронту. Найбільші бої — на Покровському та Південно-Слобожанському.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-01) [Allen Zipporah] Form 4 (Reporting)
      filed 2026-08-01 01:54 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089353 Size: 5 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:54 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089353 Size: 5 KB
  - (2026-08-01) [Moore Joshua] Form 4 (Reporting)
      filed 2026-08-01 01:54 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089352 Size: 11 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:54 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089352 Size: 11 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:53 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089351 Size: 5 KB
  - (2026-08-01) [RAUCH STACEY] Form 4 (Reporting)
      filed 2026-08-01 01:53 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089351 Size: 5 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 20 new of 20 total
  - (2026-08-03) Visas: Visa Bond Program
      This rule finalizes the temporary final rule that went into effect on August 20, 2025, which launched a 12-month long Visa Bond Pilot Program (Pilot Program), and establishes a permanent visa bond program. An alien apply…
  - (2026-08-03) Auction of Flexible-Use Licenses in the Upper C-Band for Next-Generation Wireless Services Scheduled for April 27, 2027; Comment Sought on Competitive Bidding Procedures for Auction 115
      In this document, the Federal Communications Commission (the Commission or FCC) announces an auction of 3,248 new flexible-use licenses in the 3.98-4.14 GHz band. The Office of Economics and Analytics (OEA) and the Wirel…
  - (2026-08-03) High-Speed Train Noise Emission Standards
      This NPRM seeks to amend the noise emission regulations to address the unique noise emission characteristics of trains operating at speeds exceeding 160 miles per hour (mph). Specifically, the proposed regulation would p…
  - (2026-08-03) Rescinding Portions of Department of the Treasury Title VI Regulations To Conform More Closely With the Statutory Text and To Implement an Executive Order
      By this rule, the Department of the Treasury ("Department") amends its regulations implementing Title VI of the Civil Rights Act of 1964 ("Title VI") to eliminate disparate-impact liability. These amendments align the De…
  - (2026-08-03) Ventilation Plan Approval Criteria
      In response to a public request, the Mine Safety and Health Administration (MSHA) is reopening the rulemaking record and is scheduling a virtual public hearing on the Agency's proposed rule published on July 1, 2025, tit…
  - (2026-08-03) Medicare Program; FY 2027 Hospice Wage Index and Payment Rate Update and Hospice Quality Reporting Program Requirements
      This final rule updates the hospice wage index, payment rates, and aggregate cap amount for fiscal year 2027. This final rule also includes an analysis of Medicare non-hospice spending, including details regarding a hosp…

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-08-01) CFC4098 (Canada)
      icao24: c2b3f5 · position: (64.6597, -161.4522) · alt: 10058m · 869km/h
  - (2026-08-01) JAF1KW (Belgium)
      icao24: 44d1a6 · position: (50.9007, 4.4989) · on ground · 24km/h
  - (2026-08-01) JAF59V (Belgium)
      icao24: 44d1a7 · position: (50.613, 4.9191) · alt: 9974m · 796km/h
  - (2026-08-01) JAF7XM (Belgium)
      icao24: 44d1c2 · position: (35.206, -2.4701) · alt: 5539m · 682km/h
  - (2026-08-01) SAMU24 (France)
      icao24: 39ada0 · position: (45.1464, 0.8085) · alt: 601m · 222km/h
  - (2026-08-01) RCH646 (United States)
      icao24: ae07d5 · position: (35.1696, -89.8334) · alt: 2080m · 549km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 17 new of 52 total
  - (2026-08-01) [BleepingComputer] Rails patches critical Active Storage flaw with RCE potential
      A critical vulnerability in the Active Storage framework can allow an unauthenticated attacker to read arbitrary files from a Rails application, and potentially escalate to remote code execution (RCE). [...]
  - (2026-08-01) [The Hacker News] Coldcard Hardware Wallet Flaw Linked to $70 Million Bitcoin Theft in 41 Minutes
      An attacker drained 1,196 Bitcoin addresses in 41 minutes on July 30, taking 1,082.65 BTC worth about $70.2 million at the time. Galaxy Research mapped the sweep and tied it to a firmware flaw in Coldcard, the Bitcoin-on…
  - (2026-08-01) [The Hacker News] Hackers Poison Adform Script to Swap Crypto Wallet Addresses Across Customer Sites
      Attackers modified a JavaScript file served by advertising technology company Adform, turning it into a browser-side tool that rewrites cryptocurrency wallet addresses. Adform detected the incident on July 27, 2026, remo…
  - (2026-08-01) [The Hacker News] Adobe Campaign Classic CVSS 10.0 Flaw Could Run Code Without User Interaction
      Adobe has released security updates to address a maximum-severity security flaw in Campaign Classic (ACC), its enterprise-focused marketing automation platform, that could result in arbitrary code execution. The vulnerab…
  - (2026-08-01) [The Hacker News] Hijacked Hotel Wi-Fi Pushes Fake Updates to Deliver Surveillance Malware
      A fake browser update served over hijacked hotel Wi-Fi has been used to deliver CornFlake, a remote access trojan (RAT) that can capture webcam images, microphone audio, and keystrokes, Microsoft said in its latest repor…
  - (2026-08-01) [Ars Technica] Here's how engineers plan to save the satellite sent to save NASA's Swift mission
      "We believe that a capture of Swift, an attempted capture of Swift, is very much in the cards."

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-08-01) M 5.6 - 200 km SW of Port McNeill, Canada
      M5.6 · 200 km SW of Port McNeill, Canada · depth 10 km
  - (2026-08-01) M 5.5 - 57 km E of Mutsu, Japan
      M5.5 · 57 km E of Mutsu, Japan · depth 82.29 km
  - (2026-08-01) M 5.2 - 160 km SSW of Severo-Kuril’sk, Russia
      M5.2 · 160 km SSW of Severo-Kuril’sk, Russia · depth 49.724 km
  - (2026-08-01) M 5.2 - 48 km ESE of Tsunō, Japan
      M5.2 · 48 km ESE of Tsunō, Japan · depth 26.229 km
  - (2026-08-01) M 5.1 - south of the Fiji Islands
      M5.1 · south of the Fiji Islands · depth 69.752 km
  - (2026-08-01) M 5.1 - Tristan da Cunha region
      M5.1 · Tristan da Cunha region · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-08-01) Israel x Iran ceasefire continues through August 1?
      yes price: 99% · 24h volume: $1,062,068 · resolves 2026-08-01
  - (2026-08-01) LoL: Karmine Corp vs Natus Vincere - Game 2 Winner
      yes price: 100% · 24h volume: $927,605 · resolves 2026-08-02
  - (2026-08-01) LoL: Karmine Corp vs Natus Vincere - Game 1 Winner
      yes price: 100% · 24h volume: $872,295 · resolves 2026-08-02
  - (2026-08-01) Will Donald Trump publicly insult Emmanuel Macron by July 31, 2026?
      yes price: 0% · 24h volume: $567,256 · resolves 2026-07-31
  - (2026-08-01) LoL: Cloud9 vs Dignitas - Game 1 Winner
      yes price: 0% · 24h volume: $513,062 · resolves 2026-08-02
  - (2026-08-01) Milwaukee Brewers vs. Los Angeles Angels
      yes price: 57% · 24h volume: $500,427 · resolves 2026-08-09

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 104 total
  - (2026-08-01) [USASpending] $42,774,168,231 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-08-01) [USASpending] $41,457,264,329 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-01) [USASpending] $35,144,939,584 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-08-01) [USASpending] $30,673,332,390 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-08-01) [USASpending] $27,583,176,865 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.
  - (2026-08-01) [USASpending] $19,868,865,110 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…

### Paper Trading Scorecard — 6 new of 114 total
  - (2026-08-01) [Polymarket] Will Hamas agree to disarm by December 31?
      This market will resolve to "Yes" if Hamas officially announces it will disarm in the Gaza Strip by December 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". Only credible announcements, for example by…
  - (2026-08-01) [Polymarket] Will Holger Rune win the 2026 Men's US Open?
      The 2026 U.S. Open tennis tournament is scheduled for August 23 - September 13, 2026. This market will resolve to the player that wins the 2026 U.S. Open Men’s Singles Tournament. If at any point it becomes impossible fo…
  - (2026-08-01) [Polymarket] Will Trump be impeached by end of 2026?
      This market will resolve to “Yes“ if the US House of Representatives by simple majority vote to approve or pass one or more articles of impeachment of President Donald Trump, between July 24, 2025, and December 31, 2026,…
  - (2026-08-01) [Manifold] Will The Odyssey (2026) be Christopher Nolan's highest grossing film at the domestic box office?
  - (2026-08-01) [Manifold] Will Ukraine accept a peace deal that cedes contested land in Donetsk and/or Luhansk?
  - (2026-08-01) [Manifold] Do we live in a simulation?

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-01) [Japan] Xbox Q4 revenue falls 10 percent
      news.punchjump.com · English
  - (2026-08-01) [Japan] Okayama man arrested for catching butterflies in central Japan
      japantoday.com · English
  - (2026-08-01) [Japan] Surveying the damage - Japan Today
      japantoday.com · English
  - (2026-08-01) [Japan] Japan ruling party lawmakers form group to promote trading card industry
      japantoday.com · English
  - (2026-08-01) [Japan] Japan ends rescue operation at mall that collapsed after strong quake
      japantoday.com · English
  - (2026-08-01) [Japan] 2 injured in apartment explosion in Chiba
      japantoday.com · English

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: Bay Area Unitarian v. Ogg
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: Fields v. CIR
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: MIECO v. Targa Gas Marketing
  - (2026-07-31) U.S. Court of Appeals, 4th Cir.: Colby Crosby v. Colleton County Sheriff's Office
  - (2026-07-31) U.S. Court of Appeals, 4th Cir.: Curtis Whateley v. Gerald Lackey

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 34 total
  - (2026-08-01) MOVER ▲ Thomas Peterffy — $102.03B (+$0.83B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-08-01) MOVER ▼ Changpeng Zhao — $108.73B ($-0.29B since yesterday)
      Canada · Finance & Investments · source: Cryptocurrency exchange
  - (2026-08-01) MOVER ▲ Mukesh Ambani — $89.95B (+$0.25B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-01) MOVER ▲ Gautam Adani — $84.86B (+$0.23B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-08-01) [Marginal Revolution] Rothko show in Florence
      In Museo San Marco there is an ancillary exhibit, placing some smaller, lighter colored Rothkos next to their Fra Angelico frescoes. Those rooms bowled me over, as for one thing they show how much Rothko was a religious…
  - (2026-08-01) [Marginal Revolution] Saturday assorted links
      1. What do consultants get paid for? 2. Ugly architecture creates coalitions against development. 3. London is (modestly) degentrifying. 4. Is the “no forward guidance” approach failing? (FT) 5. Chinese interview with Ch…
  - (2026-08-01) [Marginal Revolution] More math breakthroughs from GPT models
      The cost of generating the proofs for all 10 of these breakthroughs combined was under $2,000 at Sol API prices. We’re excited to see what scientists and researchers are able to create with our upcoming Astra models! Tha…

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-08-01) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo is intensifying, with sustained transmission and continued increases in reported cases and deaths. Initially confined to the Mongbwalu h…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: taking, standard, management, action, final, program, published, amend, proposing, safety, certain, requires
- state_bills: today=106, 7d-median=138, 14d-median=138; carrying terms: whose, investigations, retail, action, conduct, administration, program, specified, issue, requiring, procedures, defines
- state_news: today=758, 7d-median=758, 14d-median=734; carrying terms: lawmakers, whose, cellphone, green, sizes, effort, early, kenneth, parts, parks, millions, attorneys
- local_news: today=255, 7d-median=228, 14d-median=228; carrying terms: charges, shooting, against, million, image, murder, local, nearly, health, event, decoding, injured
- foreign_news: today=1051, 7d-median=1022, 14d-median=1023; carrying terms: summons, httpsconnection, super, others, german, heart, parts, teaching, aviation, investors, charges, hopes
- chinese_internal: today=299, 7d-median=265, 14d-median=270; carrying terms: global, google, china, chinese, people, caixin, https, profit, investment, market, stock, beijing
- russian_internal: today=854, 7d-median=916, 14d-median=898; carrying terms: openai, httperror, gazeta, title, https, forbidden, novayagazeta, found, street, istories, axios, wildberries
- ukrainian_internal: today=133, 7d-median=136, 14d-median=136; carrying terms: pressure, drone, early, forbidden, censor, dnipropetrovsk, military, thousands, error, struck, remains, against
- ukraine_theater: today=1105, 7d-median=627, 14d-median=636; carrying terms: anomaly, cartography, client, active, alerts, frontline, maintained, daily, coverage, thermal, viirs, unauthorized
- paper_bets: today=114, 7d-median=134, 14d-median=136; carrying terms: openai, james, december, whose, credible, industrial, magnitude, total, president, speed, california, governor
- weather: today=167, 7d-median=173, 14d-median=174; carrying terms: cause, green, impacts, expect, changed, early, portions, creek, aviation, sensitive, junction, monday
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, cpilfesl, jtsjol, payems, personal, spread, total, growth, dexchus, recession, jolts, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, close, equities, china, natural, corporate, proxy, crypto, silver, credit, crude, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=111, 14d-median=113; carrying terms: claims, serious, destabilisation, violent, entity, economic, african, production, schools, company, actions, specific
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quiverquant, client, quantitative, quiver, httperror, https, unauthorized, congresstrading
- billionaires: today=34, 7d-median=37, 14d-median=36; carrying terms: france, bloomberg, tokyo, facebook, buffett, changpeng, ballmer, holdings, cryptocurrency, adani, finance, googl
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: california, delaware, court, appeals, blanche, services, supreme, arizona, johnson, county, group, jones
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, holdings, amended
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, robert, shawn, jonathan, disbursements, alexandria, trone, senate, johnson, filing, ocasio, graham
- gdelt_regions: today=6, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=93, 7d-median=25, 14d-median=25; carrying terms: english, hezbollah, israel, trump, lindsey, chinese, graham, keywords, spanish, themes, russia, italian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=16, 14d-median=16; carrying terms: position, belgium, canada, france, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: remained, france, travel, cluster, december, cause, border, hygiene, diphtheria, thailand, total, deteriorate
- cisa_kev: today=9, 7d-median=14, 14d-median=15; carrying terms: authentication, vendor, management, remediation, fortinet, injection, sharepoint, untrusted, deserialization, langflow, command, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=287, 14d-median=287; carrying terms: france, maximum, impact, magnitude, ecuador, kazakhstan, thailand, poland, drought, speed, hungary, croatia
- usgs_quakes: today=16, 7d-median=20, 14d-median=22; carrying terms: depth, region, islands, south, japan, philippines, china, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, resolves, volume, price, ceasefire, august, effective, invade, cartel, september, operation, outside
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: conversable, https, class, marginalrevolution, economist, marginal, revolution, students, certain, links, having, doctor
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: openai, exposed, article, power, access, download, groups, ransomware, against, cybersecurity, companies, bleepingcomputer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: james, mccollum, summer, jason, hillary, deputy, clarence, minneapolis, wesley, randall, hirono, boston
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, today, either, unavailable, converges, placement, module, placed, identify, decision, evidence, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*