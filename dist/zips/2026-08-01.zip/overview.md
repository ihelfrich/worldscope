# WORLDSCOPE morning brief — 2026-08-01

## Headline
1813 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (414) · Russian Internal News (state + in-exile) (331) · World leaders & government officials (324) · Chinese Internal News (183) · U.S. Weather + Severe / Climate Outlooks (143) · Local News: St. Louis + Atlanta (71) · Ukraine Theater (total-war monitoring) (57) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · State-Level News (39) · Ukrainian Internal News (national + local Kyiv) (38) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 414 new of 1027 total
  - (2026-08-01) [Global] Bessent ‘to-do’ list shows proposal for US to buy $5bn-$10bn of Japanese yen
  - (2026-08-01) [Global] First Australian mass mortality event suspected as deadly bird flu virus rapidly escalates among native birds
  - (2026-08-01) [Global] Petrol prices on track to top $2 a litre as Bowen sounds death knell for fuel excise relief
  - (2026-08-01) [Global] Adani to pay no company tax despite $1bn revenue from Queensland coalmine
  - (2026-08-01) [Global] Death toll in Ceuta border crisis rises to 67 as Spanish government announces plans for barrier – Europe live
  - (2026-08-01) [Global] EU relations, climate crisis and Gaza: why Ed Miliband is fired up by Foreign Office challenges

### Russian Internal News (state + in-exile) — 331 new of 994 total
  - (2026-08-01) Почему в Европе нет кондиционеров? И с чем придется столкнуться, если я решу все же поставить себе кондиционер? | LEDE: Июнь 2026 года стал самым жарким за всю историю наблюдений в Западной ] (ru: Поч…
      Июнь 2026 года стал самым жарким за всю историю наблюдений в Западной Европе. Волна экстремальных температур охватила большую часть континента всего через несколько недель после сильной жары в мае. Следующая волна жары п…
  - (2026-08-01) Масштабная атака России по Киеву. Фотографии. В пяти районах города повреждены жилые дома и магазин. Погибли девять человек | LEDE: Первого августа Россия нанесла массированный удар по Киеву] (ru: Мас…
      Первого августа Россия нанесла массированный удар по Киеву. Минобороны РФ заявляет, что цель ударов — предприятия военной промышленности и логистические центры. Под удар попали пять районов города, в том числе жилые дома…
  - (2026-08-01) Украинские дроны атаковали НПЗ «Башнефти» в Уфе | LEDE: Украинские беспилотники атаковали НПЗ «Башнефть-Уфанефтехим» в Уфе. Об этом сообщает Astra. ] (ru: Украинские дроны атаковали НПЗ «Башнефти» в У…
      Украинские беспилотники атаковали НПЗ «Башнефть-Уфанефтехим» в Уфе. Об этом сообщает Astra.
  - (2026-08-01) ФИФА отказалась от планов продать долю в чемпионате мира частным инвесторам | LEDE: ФИФА отказалась от планов продажи доли в чемпионате мира частным инвесторам. Соответствующее сообщение пре] (ru: ФИФ…
      ФИФА отказалась от планов продажи доли в чемпионате мира частным инвесторам. Соответствующее сообщение президента Джанни Инфантино размещено на сайте организации.
  - (2026-08-01) Салуки, один из главных российских рэперов, снова выпустил не рэп-альбом. Это танцевальная электроника о человеке, который застрял на вечеринке Муджуса | LEDE: 24 июля вышел Euphoria — пятый] (ru: Сал…
      24 июля вышел Euphoria — пятый сольный альбом российского музыканта Арсения Несатого, записывающего музыку под псевдонимом Салуки. Начинавший с продюсирования хип-хопа исполнитель в очередной раз ушел от хип-хопа в сторо…
  - (2026-08-01) Российские военные нанесли удар по Киеву. Погибли девять человек, более 30 ранены | LEDE: Российские военные в ночь на 1 августа нанесли удар по Киеву. Мэр города Виталий Кличко сообщил, что] (ru: Рос…
      Российские военные в ночь на 1 августа нанесли удар по Киеву. Мэр города Виталий Кличко сообщил, что атака велась баллистическими ракетами.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 183 new of 304 total
  - (2026-07-30) Robotics Startup Unitree Launches $620 Million STAR Market IPO - Caixin Global
      Robotics Startup Unitree Launches $620 Million STAR Market IPO Caixin Global
  - (2026-08-01) 報道日歷--資料中心--人民網 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMidkFVX3lxTFBpcDFmM0llQUU2ckJwT2NqZkVWaUkxV3JPTERnVDNwM2RqbVBndHFjYmVuX0ZQWXRmUzE4VmVGQWtZNWFSSXBxbVZ1VmEwVFBZ] (zh:…
      報道日歷--資料中心--人民網 中国共产党新闻网
  - (2026-07-31) 有回音丨严管乱象、疏通堵点、整修坑路 天津化解群众出行难题 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE0zN1pWMzdVUDBPNUxVQ1hUQzd5dWVydWtONnVJU3h3YzhHaXNHV3FNZUZCQzMxTlZEZ3FGVmNxdGx1QXZ4TW9rT3o] (zh:…
      有回音丨严管乱象、疏通堵点、整修坑路 天津化解群众出行难题 人民网
  - (2026-08-01) 时习之丨今天，重温习近平的强军嘱托--独家稿件 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTFA3VVVIdUE4eWpfRmwwOXV1XzhYX2t1UHRqRGRIYnE4Y0tDWVRvTHVMS0RzUGR1VFFBT0NqazYwZ1JkZ1ZQcVhycWR4] (zh:…
      时习之丨今天，重温习近平的强军嘱托--独家稿件 中国共产党新闻网
  - (2026-08-01) 国务院任免国家工作人员 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9HYjBmNmJNSGM0ZlZ1V0ZVSEluUHJXUnppSDlwVm1vSGRPc3RyR3JwM1IyOXhPelM0Qmc2RjF5ZHUtcW9DWG9rd1Yxc2pKOUtMUDZGajNYV] (zh:…
      国务院任免国家工作人员 人民网
  - (2026-08-01) 陈新武任重庆市代市长 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE10aWZRSUZMMkxOQ09aNGNzWGJGdkRPbkNjQzZ0TXZsUWhkekE5aWV6alh0X3dtT2RqeWNnay1LYXprQ29vYXZ3WEF6YVJlOHE1QUQwbG5RXz] (zh:…
      陈新武任重庆市代市长 人民网

### U.S. Weather + Severe / Climate Outlooks — 143 new of 177 total
  - (2026-08-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 1 at 5:00AM EDT until August 3 at 8:00AM EDT by NWS Northern Indiana
      * WHAT...Dangerous swimming conditions expected. *Waves: Waves 2 to 3 feet Sunday morning building to 3 to 5 feet by late afternoon. *Longshore Current: Expected. Moving from north to south along the beach. *Structural C…
  - (2026-08-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 1 at 5:00AM EDT until August 3 at 8:00AM EDT by NWS Northern Indiana
      * WHAT...Dangerous swimming conditions expected. *Waves: 1 to 2 feet building to 3 to 5 feet by late this afternoon. Waves 3 to 4 feet Sunday morning building to 4 to 7 feet by late afternoon. The highest waves each day…
  - (2026-08-01) [Moderate] Heat Advisory: Heat Advisory issued August 1 at 2:48AM MDT until August 1 at 8:00PM MDT by NWS Albuquerque NM
      * WHAT...Temperatures up to 100 expected. * WHERE...Northwest Plateau and West Central Plateau. * WHEN...From noon today to 8 PM MDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses. * ADDITIONAL DETAI…
  - (2026-08-01) [Unknown] Hydrologic Outlook: Hydrologic Outlook issued August 1 at 3:45AM EDT by NWS Indianapolis IN
      ESFIND A slow moving low pressure system will impact central Indiana today and Sunday with showers and isolated thunderstorms at times. Heavy rainfall will be possible due to efficient rainfall rates from repeated rounds…
  - (2026-08-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 1 at 3:18AM CDT until August 3 at 9:00AM CDT by NWS Chicago IL
      * WHAT...High wave action and dangerous currents expected at Lake Michigan beaches. Waves 6 to 9 feet expected. * WHERE...Lake IL, Northern Cook and Central Cook Counties. * WHEN...Through Monday morning. * IMPACTS...Swi…
  - (2026-08-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 1 at 3:18AM CDT until August 3 at 9:00AM CDT by NWS Chicago IL
      * WHAT...High wave action and dangerous currents expected at Lake Michigan beaches. Waves 6 to 9 feet expected. * WHERE...Lake IN and Porter Counties. * WHEN...From 9 AM CDT this morning through Monday morning. * IMPACTS…

### Local News: St. Louis + Atlanta — 71 new of 255 total
  - (2026-08-01) [St. Louis] See the Aug. 1, 2026, front page: Williams alleges political plot to beat him
      Headlines from the Aug. 1, 2026, front page include: President Coolidge's laundry sent home.
  - (2026-08-01) [St. Louis] SPACE MUSEUM NEEDS NEW SPACE
      Jack Rathbun, 8, of Lesterville, tries on a glove from a real space suit on Friday, July 31, 2026, at the Space Museum and Grissom Center in Bonne Terre. The museum dedicated to the history of space exploration has outgr…
  - (2026-08-01) [St. Louis] Pet kangaroo lost in southeast Mo. is back home
      ROOfus, the beloved pet kangaroo who escaped his pen on July 24, is back home. Owner Dawn McClard said she is grateful to everyone who looked for him when he was gone.
  - (2026-08-01) [St. Louis] CONGRESSIONAL COUNTDOWN
      Staff members feed test ballots into early voting tabulators July 22 at the Lee County Supervisor of Elections Office in Fort Myers, Fla.
  - (2026-08-01) [St. Louis] CONGRESSIONAL COUNTDOWN
      The U.S. Capitol is seen July 28 in Washington.
  - (2026-08-01) [St. Louis] Page A6 eedition image

### Ukraine Theater (total-war monitoring) — 57 new of 245 total
  - (2026-08-01) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-01) [Liveuamap] Drones raid reported in Zelenodolsk, Tatarstan - Liveuamap
      Drones raid reported in Zelenodolsk, Tatarstan Liveuamap
  - (2026-07-31) [Liveuamap] Yemen&039;s Houthis say they forced eight Saudi oil tankers to reroute around the Cape of Good Hope as a result of their naval blockade Sana&039;a, Capital Municipality - Interactive map o…
      Yemen&039;s Houthis say they forced eight Saudi oil tankers to reroute around the Cape of Good Hope as a result of their
  - (2026-07-27) [Liveuamap] Houses burned in Markaba; army bombings in the eastern sector - Liveuamap
      Houses burned in Markaba; army bombings in the eastern sector Liveuamap
  - (2026-07-30) [Liveuamap] Two civilians were killed and others injured in a drone attack targeting a gas station in Rabak, White Nile State. Drones continued their raids on El Obeid, North Kordofan. - Liveuamap
      Two civilians were killed and others injured in a drone attack targeting a gas station in Rabak, White Nile State. Dron
  - (2026-07-30) [Liveuamap] At Kramatorsk direction clashes yesterday near Tykhonivka, - General Staff of Armed Forces of Ukraine reports - Liveuamap
      At Kramatorsk direction clashes yesterday near Tykhonivka, - General Staff of Armed Forces of Ukraine reports <font c

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-01) [Allen Zipporah] Form 4 (Reporting)
      filed 2026-08-01 01:54 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089353 Size: 5 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:54 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089353 Size: 5 KB
  - (2026-08-01) [Moore Joshua] Form 4 (Reporting)
      filed 2026-08-01 01:54 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089352 Size: 11 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:54 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089352 Size: 11 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:53 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089351 Size: 5 KB
  - (2026-08-01) [RAUCH STACEY] Form 4 (Reporting)
      filed 2026-08-01 01:53 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089351 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-01) [United States] This Day in Country History : August 1
      domain: 995qyk.com · language: English · tone:
  - (2026-08-01) [United States] Linguistic expert explains how investigators may analyze ransom notes in Nancy Guthrie case
      domain: kold.com · language: English · tone:
  - (2026-08-01) [United States] How the marriage - equality movement won over America before it won at the Supreme Court
      domain: slate.com · language: English · tone:
  - (2026-08-01) [United States] AP News Summary at 11 : 49 p . m . EDT
      domain: couriernews.com · language: English · tone:
  - (2026-08-01) [India] Centre RERA extension amid Middle East conflict : What it means for homebuyers
      domain: timesofindia.indiatimes.com · language: English · tone:
  - (2026-08-01) [Syria] Paank raises concern over alleged disappearance of three Baloch individuals in Pakistan
      domain: middleeaststar.com · language: English · tone:

### State-Level News — 39 new of 723 total
  - (2026-08-01) [Alaska] Shooting Sports Month 2026
      WHEREAS, Alaskans enjoy a variety of outdoor activities throughout the year, and many of those activities, from hiking and hunting to recreational shooting, involve the use of firearms; and WHEREAS, many Alaskans rely on…
  - (2026-07-31) [Arkansas] Prosecutors drop vandalism charges for Reflecting Pool damage, blame ‘contractor error’
      WASHINGTON — U.S. Attorney for the District of Columbia Jeanine Pirro moved Friday to dismiss charges against a former Olympian canoeist alleged to have damaged part of the Lincoln Memorial Reflecting Pool. Pirro had cha…
  - (2026-08-01) [Arizona] The Trump administration’s ‘draconian’ water cuts could gut Arizona’s Colorado River supply
      A new federal plan released Friday could mean cuts of up to 77% to Arizona’s share of Colorado River water, in the midst of a 25-year megadrought, something that state leaders say would cause catastrophic harm to the sta…
  - (2026-07-31) [Arizona] Bid to freeze Arizona’s ‘Secure the Border Act’ fails, but fight isn’t over
      An attempt to temporarily block an Arizona law allowing state officials to jail immigrants failed, but there’s still a chance that opponents could pause the law’s implementation — though when that might happen and whethe…
  - (2026-08-01) [Alaska] First week of third gasline special session ends with no action by Dunleavy or Alaska Legislature
      The Alaska Legislature ended the first week of its third special session on the proposed trans-Alaska natural gas pipeline with no action. The session is for lawmakers to consider a property tax break to incentivize the…
  - (2026-07-31) [Alaska] After federal report, Alaska pilots grapple with unanswered questions in tragic Nome crash
      The National Transportation Safety Board on Thursday released the final report for the February 6, 2025, accident involving Bering Air flight 445 that killed all 10 people on board. While the NTSB’s report identifies air…

### Ukrainian Internal News (national + local Kyiv) — 38 new of 118 total
  - (2026-08-01) Дві ракети вдарили по території "Київмедспецтранс", є руйнування – Кличко | LEDE: Унаслідок російської атаки в ніч на 1 серпня два влучання зафіксували на території комунальної організації "Киї] (uk:…
      Унаслідок російської атаки в ніч на 1 серпня два влучання зафіксували на території комунальної організації "Київмедспецтранс".
  - (2026-08-01) Рубіо пообіцяв з’ясувати, чи можна відновити переговори між Україною і РФ | LEDE: США планують дипломатичну активізацію для відновлення мирних переговорів між Україною та Росією найближчими тиж] (uk:…
      США планують дипломатичну активізацію для відновлення мирних переговорів між Україною та Росією найближчими тижнями.
  - (2026-08-01) У США розбився винищувач F-35 | LEDE: ] (uk: У США розбився винищувач F-35)
  - (2026-08-01) Зеленський пояснив збиття лише однієї балістичної ракети під час масованої атаки | LEDE: ] (uk: Зеленський пояснив збиття лише однієї балістичної ракети під час масованої атаки)
  - (2026-08-01) У районі Неаполя стався потужний землетрус: є поранені | LEDE: ] (uk: У районі Неаполя стався потужний землетрус: є поранені)
  - (2026-08-01) Росія атакувала Україну 35 ракетами, дві з яких вдалося збити – ПС | LEDE: У ніч на 1 серпня РФ атакувала Україну 35 ракетами й 185 дронами. 156 цілей знешкоджено, є жертви в Києві.] (uk: Росія атакув…
      У ніч на 1 серпня РФ атакувала Україну 35 ракетами й 185 дронами. 156 цілей знешкоджено, є жертви в Києві.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 28 total
  - (2026-08-01) PUMAD (France)
      icao24: 39de61 · position: (42.9045, 8.0094) · alt: 1676m · 295km/h
  - (2026-08-01) SAMU28 (France)
      icao24: 39ca85 · position: (48.03, 1.8206) · alt: 556m · 246km/h
  - (2026-08-01) RCH5010 (United States)
      icao24: ae63c6 · position: (46.1989, 21.1776) · alt: 11887m · 914km/h
  - (2026-08-01) JAF7CB (Belgium)
      icao24: 44d1ba · position: (39.3498, -3.5074) · alt: 10363m · 858km/h
  - (2026-08-01) JAF3MJ (Belgium)
      icao24: 44d1a6 · position: (45.4017, 1.0522) · alt: 10972m · 816km/h
  - (2026-08-01) JAF74C (Belgium)
      icao24: 44d1a7 · position: (36.7409, 26.4939) · alt: 7955m · 811km/h

### U.S. Federal Action — 20 new of 20 total
  - (2026-08-03) Visas: Visa Bond Program
      This rule finalizes the temporary final rule that went into effect on August 20, 2025, which launched a 12-month long Visa Bond Pilot Program (Pilot Program), and establishes a permanent visa bond program. An alien apply…
  - (2026-08-03) Auction of Flexible-Use Licenses in the Upper C-Band for Next-Generation Wireless Services Scheduled for April 27, 2027; Comment Sought on Competitive Bidding Procedures for Auction 115
      In this document, the Federal Communications Commission (the Commission or FCC) announces an auction of 3,248 new flexible-use licenses in the 3.98-4.14 GHz band. The Office of Economics and Analytics (OEA) and the Wirel…
  - (2026-08-03) High-Speed Train Noise Emission Standards
      This NPRM seeks to amend the noise emission regulations to address the unique noise emission characteristics of trains operating at speeds exceeding 160 miles per hour (mph). Specifically, the proposed regulation would p…
  - (2026-08-03) Rescinding Portions of Department of the Treasury Title VI Regulations To Conform More Closely With the Statutory Text and To Implement an Executive Order
      By this rule, the Department of the Treasury ("Department") amends its regulations implementing Title VI of the Civil Rights Act of 1964 ("Title VI") to eliminate disparate-impact liability. These amendments align the De…
  - (2026-08-03) Ventilation Plan Approval Criteria
      In response to a public request, the Mine Safety and Health Administration (MSHA) is reopening the rulemaking record and is scheduling a virtual public hearing on the Agency's proposed rule published on July 1, 2025, tit…
  - (2026-08-03) Medicare Program; FY 2027 Hospice Wage Index and Payment Rate Update and Hospice Quality Reporting Program Requirements
      This final rule updates the hospice wage index, payment rates, and aggregate cap amount for fiscal year 2027. This final rule also includes an analysis of Medicare non-hospice spending, including details regarding a hosp…

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 106 total
  - (2026-08-01) [USASpending] $42,774,168,231 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-08-01) [USASpending] $41,457,264,329 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-01) [USASpending] $35,144,939,584 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-08-01) [USASpending] $30,673,332,390 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-08-01) [USASpending] $27,583,176,865 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.
  - (2026-08-01) [USASpending] $19,868,865,110 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…

### USGS earthquakes (M4.5+, past day) — 10 new of 20 total
  - (2026-08-01) M 5.6 - 200 km SW of Port McNeill, Canada
      M5.6 · 200 km SW of Port McNeill, Canada · depth 10 km
  - (2026-08-01) M 5.5 - 57 km E of Mutsu, Japan
      M5.5 · 57 km E of Mutsu, Japan · depth 82.29 km
  - (2026-08-01) M 5.1 - south of the Fiji Islands
      M5.1 · south of the Fiji Islands · depth 544.366 km
  - (2026-07-31) M 5.1 - 132 km ENE of Masohi, Indonesia
      M5.1 · 132 km ENE of Masohi, Indonesia · depth 10 km
  - (2026-08-01) M 4.8 - 44 km NW of Te Anau, New Zealand
      M4.8 · 44 km NW of Te Anau, New Zealand · depth 112.486 km
  - (2026-08-01) M 4.7 - 206 km NW of Oula Xiuma, China
      M4.7 · 206 km NW of Oula Xiuma, China · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-08-01) LoL: Anyone's Legend vs ThunderTalk Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $873,116 · resolves 2026-08-01
  - (2026-08-01) LoL: Nongshim Red Force vs BNK FEARX - Game 1 Winner
      yes price: 100% · 24h volume: $779,833 · resolves 2026-08-01
  - (2026-08-01) LoL: Anyone's Legend vs ThunderTalk Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $758,453 · resolves 2026-08-01
  - (2026-08-01) LoL: Anyone's Legend vs ThunderTalk Gaming (BO3) - LPL Group Ascend
      yes price: 100% · 24h volume: $661,812 · resolves 2026-08-01
  - (2026-08-01) Game Handicap: AL (-1.5) vs ThunderTalk Gaming (+1.5)
      yes price: 100% · 24h volume: $357,744 · resolves 2026-08-01
  - (2026-08-01) Will China invade Taiwan by September 30, 2026?
      yes price: 1% · 24h volume: $344,274 · resolves 2026-09-30

### Paper Trading Scorecard — 9 new of 143 total
  - (2026-08-01) [Manifold] Will Trump wear glasses in August?
  - (2026-08-01) [Manifold] Will I be jobless at some point before end of 2027?
  - (2026-08-01) [Manifold] Will the leaked OpenAI "GPT 5.6 Sol" proof that nonsofic groups exist be verified as correct?
  - (2026-08-01) [Manifold] Will OpenAI Astra solve a math problem Claude Opus 5 deems more important than the Jacobian Conjecture?
  - (2026-08-01) [Manifold] Polymarket has some METR time horizon market before EOY 2026?
  - (2026-08-01) [Manifold] Will a multi-agent system have its time horizon evaluated by METR before EOY 2026?

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: Bay Area Unitarian v. Ogg
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: Fields v. CIR
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: MIECO v. Targa Gas Marketing
  - (2026-07-29) U.S. Court of Appeals, 9th Cir.: Serenity Investments, LLC v. Sun Hung Kai Strategic Capital, Ltd.
  - (2026-07-29) U.S. Court of Appeals, 9th Cir.: United States v. Yates

### IT, InfoSys & cybersecurity news (last 7 days) — 4 new of 57 total
  - (2026-08-01) [The Hacker News] Adobe Campaign Classic CVSS 10.0 Flaw Could Run Code Without User Interaction
      Adobe has released security updates to address a maximum-severity security flaw in Campaign Classic (ACC), its enterprise-focused marketing automation platform, that could result in arbitrary code execution. The vulnerab…
  - (2026-08-01) [The Hacker News] Hijacked Hotel Wi-Fi Pushes Fake Updates to Deliver Surveillance Malware
      A fake browser update served over hijacked hotel Wi-Fi has been used to deliver CornFlake, a remote access trojan (RAT) that can capture webcam images, microphone audio, and keystrokes, Microsoft said in its latest repor…
  - (2026-08-01) [The Register] A deep dive into Nvidia's Vera CPU and the Olympus cores that power it
      88 custom cores, 176 funky threads, 1.5 TB of laptop RAM, and 1.8 TB/s of NVLink connectivity — this isn't your typical datacenter chip
  - (2026-08-01) [The Register] Enterprise cloud infrastructure uptake shows no sign of slowing
      Cloud revenue now north of $143 billion a quarter, and growth is accelerating

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-01) [Marginal Revolution] Immigration and Macroeconomic Outcomes in OECD Countries
      OECD countries experienced declining native population growth and rising net immigration over 1990-2024. We compile a new dataset of net immigration rates to OECD countries from all origins and show that most of the incr…
  - (2026-08-01) [Marginal Revolution] Emergent Ventures India, 18th cohort
      Adithyan Madhu, 14, an independent researcher, received his grant to study early writing systems, applying computational linguistics, pattern analysis, and structural methods to the Indus Valley script. Aparajeet Shadang…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: amend, final, published, taking, proposing, provide, issued, management, action, proposes, program, safety
- state_bills: today=0, 7d-median=145, 14d-median=145; carrying terms: reporting, allows, products, enforcement, right, written, rights, conditions, another, district, projects, development
- state_news: today=723, 7d-median=723, 14d-median=717; carrying terms: chance, helps, afternoon, sought, union, enforcement, details, nofollow, intelligence, closures, getting, detention
- local_news: today=255, 7d-median=228, 14d-median=228; carrying terms: afternoon, mother, another, killed, events, atlanta, games, figure, louis, appeared, investigation, search
- foreign_news: today=1027, 7d-median=1022, 14d-median=1023; carrying terms: soldiers, helps, reuters, heart, website, summary, materials, union, movement, adviser, internet, suicidal
- chinese_internal: today=304, 7d-median=265, 14d-median=270; carrying terms: global, https, caixin, china, people, chinese, google, stock, profit, beijing, investment, office
- russian_internal: today=994, 7d-median=937, 14d-median=926; carrying terms: reuters, guardian, title, media, centcom, russian, group, error, bloomberg, street, https, telegram
- ukrainian_internal: today=118, 7d-median=136, 14d-median=136; carrying terms: confirmed, moscow, systems, title, support, intelligence, remains, power, possible, supply, despite, broader
- ukraine_theater: today=245, 7d-median=586, 14d-median=606; carrying terms: maintained, httperror, extra, polygon, alerts, thermal, snapshot, daily, token, liveuamap, active, viirs
- paper_bets: today=143, 7d-median=138, 14d-median=140; carrying terms: colonize, fusion, reporting, population, decrease, governor, majors, humans, party, market, consensus, miami
- weather: today=177, 7d-median=175, 14d-median=176; carrying terms: chance, heavy, afternoon, little, afdokx, rainfall, miami, details, detroit, norton, afddtx, remains
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, sheet, unemployment, balance, effective, cpiaucsl, growth, indicator, rates, supply, vixcls, total
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, large, crypto, close, yield, equities, agriculture, credit, bitcoin, rates, china, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=106, 7d-median=111, 14d-median=113; carrying terms: groups, laboratory, terrorist, union, haiti, haitian, support, congo, guatemala, resolution, rights, funds
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quiverquant, httperror, congresstrading, client, quiver, error, quantitative, unauthorized
- billionaires: today=30, 7d-median=37, 14d-median=36; carrying terms: steve, walton, semiconductors, india, investments, michael, bezos, ballmer, yanai, cryptocurrency, zuckerberg, warren
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, blanche, california, international, services, appeals, trade, supreme, delaware, group, jones, johnson
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, holdings, amended
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: lindsey, senate, michael, cycle, cooper, disbursements, sherrod, pinkston, johnson, david, graham, elect
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan, switch
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: language, english, domain, years, india, russia, strike, kingdom
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=28, 7d-median=16, 14d-median=16; carrying terms: position, belgium, france, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: received, cross, individual, driven, reporting, batches, sustained, barasat, anthrax, distributed, respiratory, confirmed
- cisa_kev: today=9, 7d-median=14, 14d-median=15; carrying terms: microsoft, control, injection, fortinet, product, deserialization, authentication, command, management, untrusted, sharepoint, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=287, 14d-median=287; carrying terms: north, flood, brazil, czech, vietnam, bosnia, papua, macedonia, medium, croatia, ecuador, albania
- usgs_quakes: today=20, 7d-median=20, 14d-median=22; carrying terms: islands, region, depth, indonesia, south, japan, mexico, philippines, chile, sandwich, china, puerto
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, interest, meeting, resolves, price, volume, change, decrease, increase, august, ceasefire, effective
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: revolution, marginal, https, class, economist, conversable, government, control, doctor, golden, looking, conversableeconomist
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: groups, systems, provides, intelligence, called, newsletter, power, schneier, leadership, https, hacker, scope
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: pfluger, tommy, rutherford, suozzi, delbene, celeste, richard, steil, castor, timothy, evans, lutnick
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, today, placement, either, evidence, markets, module, paper, unavailable, decision, converges, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*