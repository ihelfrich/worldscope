# WORLDSCOPE morning brief — 2026-08-01

## Headline
2090 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (421) · Russian Internal News (state + in-exile) (338) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (245) · Chinese Internal News (175) · U.S. Weather + Severe / Climate Outlooks (150) · GDELT GKG — themes / entities / watch areas (93) · Local News: St. Louis + Atlanta (76) · State-Level News (41) · Ukrainian Internal News (national + local Kyiv) (40) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 421 new of 1028 total
  - (2026-08-01) [Global] Fifa scraps controversial World Cup investment plan
      Football's world governing body Fifa abandons plans to sell off stakes in its major competitions after widespread opposition to president Gianni Infantino's proposal.
  - (2026-08-01) [Global] Israeli West Bank settler tells BBC attacks on Palestinians are justified as revenge
      Settler violence against Palestinians is on the rise in the West Bank, as settlements and outposts expand.
  - (2026-08-01) [Global] Russian strikes on Kyiv kill at least nine, Ukraine officials say
      The attack comes as Moscow escalates deadly ballistic missile attacks on the Ukrainian capital.
  - (2026-08-01) [Global] Race to rescue remaining climbers after deadly avalanche in Pakistan
      Poor weather has been hampering the search for seven still missing after Thursday's avalanche on Broad Peak.
  - (2026-08-01) [Global] Peru's ex-president leaves jail after 15-year jail term for corruption overturned
      Ollanta Humala had been convicted of money laundering offences alongside his wife in 2025.
  - (2026-07-31) [Global] India's 'cockroach' protesters have wounds consistent with pellet-gun fire, say experts
      Ballistic experts say the dozens of tiny round punctures are tell-tale signs of pellet gun injuries.

### Russian Internal News (state + in-exile) — 338 new of 998 total
  - (2026-08-01) Почему в Европе нет кондиционеров? И с чем придется столкнуться, если я решу все же поставить себе кондиционер? | LEDE: Июнь 2026 года стал самым жарким за всю историю наблюдений в Западной ] (ru: Поч…
      Июнь 2026 года стал самым жарким за всю историю наблюдений в Западной Европе. Волна экстремальных температур охватила большую часть континента всего через несколько недель после сильной жары в мае. Следующая волна жары п…
  - (2026-08-01) Масштабная атака России по Киеву. Фотографии. В пяти районах города повреждены жилые дома и магазин. Погибли девять человек | LEDE: Первого августа Россия нанесла массированный удар по Киеву] (ru: Мас…
      Первого августа Россия нанесла массированный удар по Киеву. Минобороны РФ заявляет, что цель ударов — предприятия военной промышленности и логистические центры. Под удар попали пять районов города, в том числе жилые дома…
  - (2026-08-01) Украинские дроны атаковали НПЗ «Башнефти» в Уфе | LEDE: Украинские беспилотники атаковали НПЗ «Башнефть-Уфанефтехим» в Уфе. Об этом сообщает Astra. ] (ru: Украинские дроны атаковали НПЗ «Башнефти» в У…
      Украинские беспилотники атаковали НПЗ «Башнефть-Уфанефтехим» в Уфе. Об этом сообщает Astra.
  - (2026-08-01) ФИФА отказалась от планов продать долю в чемпионате мира частным инвесторам | LEDE: ФИФА отказалась от планов продажи доли в чемпионате мира частным инвесторам. Соответствующее сообщение пре] (ru: ФИФ…
      ФИФА отказалась от планов продажи доли в чемпионате мира частным инвесторам. Соответствующее сообщение президента Джанни Инфантино размещено на сайте организации.
  - (2026-08-01) Салуки, один из главных российских рэперов, снова выпустил не рэп-альбом. Это танцевальная электроника о человеке, который застрял на вечеринке Муджуса | LEDE: 24 июля вышел Euphoria — пятый] (ru: Сал…
      24 июля вышел Euphoria — пятый сольный альбом российского музыканта Арсения Несатого, записывающего музыку под псевдонимом Салуки. Начинавший с продюсирования хип-хопа исполнитель в очередной раз ушел от хип-хопа в сторо…
  - (2026-08-01) Российские военные нанесли удар по Киеву. Погибли девять человек, более 30 ранены | LEDE: Российские военные в ночь на 1 августа нанесли удар по Киеву. Мэр города Виталий Кличко сообщил, что] (ru: Рос…
      Российские военные в ночь на 1 августа нанесли удар по Киеву. Мэр города Виталий Кличко сообщил, что атака велась баллистическими ракетами.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 245 new of 842 total
  - (2026-08-01) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-01) [Liveuamap] Drones raid reported in Zelenodolsk, Tatarstan - Liveuamap
      Drones raid reported in Zelenodolsk, Tatarstan Liveuamap
  - (2026-07-31) [Liveuamap] Yemen&039;s Houthis say they forced eight Saudi oil tankers to reroute around the Cape of Good Hope as a result of their naval blockade Sana&039;a, Capital Municipality - Interactive map o…
      Yemen&039;s Houthis say they forced eight Saudi oil tankers to reroute around the Cape of Good Hope as a result of their
  - (2026-07-27) [Liveuamap] Houses burned in Markaba; army bombings in the eastern sector - Liveuamap
      Houses burned in Markaba; army bombings in the eastern sector Liveuamap
  - (2026-07-30) [Liveuamap] Two civilians were killed and others injured in a drone attack targeting a gas station in Rabak, White Nile State. Drones continued their raids on El Obeid, North Kordofan. - Liveuamap
      Two civilians were killed and others injured in a drone attack targeting a gas station in Rabak, White Nile State. Dron
  - (2026-07-30) [Liveuamap] At Kramatorsk direction clashes yesterday near Tykhonivka, - General Staff of Armed Forces of Ukraine reports - Liveuamap
      At Kramatorsk direction clashes yesterday near Tykhonivka, - General Staff of Armed Forces of Ukraine reports <font c

### Chinese Internal News — 175 new of 305 total
  - (2026-08-01) 遭遇强烈反对 国际足联宣布放弃世界杯股权出售项目 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9oM1RIWXNvUHc4MXhnWC1kdmpCeC1ka0ZRZ3hmaWZyVVdwZXBHeTI0MXR2YVRTT0tuWXNBeWtLcUo2LTdxWHRzR2lwQi1UQ] (zh:…
      遭遇强烈反对 国际足联宣布放弃世界杯股权出售项目 财新
  - (2026-07-31) 今日开盘：两市双双高开 沪指涨幅0.76% - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1XUU5XLWpnVUpGRV9jZWZzSmhWQTk0TnBkSjcwVnpBWjliMkRFdmpnRnZ3TmJFSFo3bFVyNGRsNENiUXRU] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.76% finance.caixin.com
  - (2026-07-30) 今日开盘：两市双双低开 沪指跌幅0.43% - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE40bFk5Um0wQUdVOEl2TGlweld5TWtxd1NFUm9IUmIzUzFIajhQMFdYWFRqclJPX194YXBsQWlwMEc5YWls] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.43% finance.caixin.com
  - (2026-08-01) 水库蓄水后马尔康红旗特大桥垮塌 调查指地质勘察弄虚作假 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE04VW9oQjR5cXZ5eGdERll4aDJmWUxuSnF2amQyd29HZkNkZVNrUmlidFRiOTlKOVNrNkl3WTJsVkw4] (zh:…
      水库蓄水后马尔康红旗特大桥垮塌 调查指地质勘察弄虚作假 china.caixin.com
  - (2026-08-01) 人事观察｜国务院部门最年轻副职 49岁蒋成华任商务部副部长 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFA5Nk1JYVRMOVZMZkhreEZvVEt5cmM5LUJBeHlQc09pVGdocTlyVElUdlFhR242OThYRlIyS1c4Mm] (zh:…
      人事观察｜国务院部门最年轻副职 49岁蒋成华任商务部副部长 china.caixin.com
  - (2026-08-01) 人事观察｜天津新任市委常委、“75后”谢元兼任教育工委书记 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE1lT0htdjY0djZTaDRJMldKNWw5aVNaTjFPWFJFNG5wMDRUYzlWODhYekp3VExwMC1Bdlcya2R4bH] (zh:…
      人事观察｜天津新任市委常委、“75后”谢元兼任教育工委书记 china.caixin.com

### U.S. Weather + Severe / Climate Outlooks — 150 new of 173 total
  - (2026-08-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 1 at 2:27AM PDT until August 1 at 5:00PM PDT by NWS San Francisco CA
      * WHAT...Long-period southerly swell will bring an increased risk of sneaker waves and strong rip currents. Breaking waves will reach up to 10 feet along some south and southwest facing beaches and break points. * WHERE.…
  - (2026-08-01) [Moderate] Special Weather Statement: Special Weather Statement issued August 1 at 5:27AM EDT by NWS Albany NY
      Patchy dense fog this morning can be seen on area web cameras and has led to reduced visibility to below 1 mile in spots. If traveling this morning, give yourself extra time to reach your destination and allow additional…
  - (2026-08-01) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 1 at 2:15AM PDT until August 1 at 5:00PM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...For the Beach Hazards Statement, frequent, moderate to strong rip currents and breaking waves due to elevated surf. * WHERE...Ventura County Beaches. * WHEN...Through this afternoon. * IMPACTS... Rip currents ca…
  - (2026-08-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 1 at 2:15AM PDT until August 1 at 5:00PM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Dangerous rip currents and elevated surf. Strong, frequent rip currents are likely along some beaches, especially exposed south to southwest facing beaches along the Central Coast. * WHERE...San Luis Obispo Coun…
  - (2026-08-01) [Severe] Red Flag Warning: Red Flag Warning issued August 1 at 2:14AM PDT until August 1 at 9:00PM PDT by NWS Medford OR
      * IMPACTS...Any fires that develop will likely spread rapidly. * AFFECTED AREA...In Oregon, the southeastern portion of Fire Weather Zone 624 covering the Fremont National Forest and all of Fire Weather Zone 625, coverin…

### GDELT GKG — themes / entities / watch areas — 93 new of 93 total
  - (2026-08-01) [Israel-Iran-Hezbollah axis · themes] Motorists urged off panic buying as excise cuts end
      southcoastregister.com.au · English · tone NA
  - (2026-08-01) [Israel-Iran-Hezbollah axis · themes] Ascienden a nueve los muertos y a 30 los heridos en un ataque con misiles balísticos rusos sobre Kiev
      diariosigloxxi.com · Spanish · tone NA
  - (2026-08-01) [Israel-Iran-Hezbollah axis · themes] Historias de las Cortes ( I ): El plan del Congreso para volar un territorio español antes de que Marruecos pusiera su bandera
      laprovincia.es · Spanish · tone NA
  - (2026-08-01) [Israel-Iran-Hezbollah axis · themes] Zelenskyy warns of low air defence supplies after Russian strike kills nine in Ukraine – Europe live
      theguardian.com · English · tone NA
  - (2026-08-01) [Israel-Iran-Hezbollah axis · themes] UFC prvi put stiže u Srbiju - Medić predvodi MMA spektakl u Beogradu
      naslovi.net · Bosnian · tone NA
  - (2026-08-01) [Israel-Iran-Hezbollah axis · themes] Kulgam terror attack : Second migrant worker dies ; search on for TRF terrorists
      theweek.in · English · tone NA

### Local News: St. Louis + Atlanta — 76 new of 255 total
  - (2026-08-01) [St. Louis] Tornado warnings expire for St. Louis region Friday night
      Tornado warnings issued Friday night have expired.
  - (2026-08-01) [St. Louis] 'She could do almost anything she wanted to do' | American climber killed in Pakistan avalanche remembered for her adventurous spirit
      Mallory Geis, 39, was attempting her first climb of an 8,000-meter peak in Pakistan when an avalanche struck.
  - (2026-08-01) [St. Louis] Downtown St. louis leaders double security and crack down on curfews at site of weekend stabbing
      Following a violent stabbing outside the Schnucks grocery store last week, neighborhood groups and police are shifting from dispersing crowds to making arrests.
  - (2026-08-01) [St. Louis] 1 dead, 1 injured following double shooting at home on Avery Lane in Bridgeton
      One person was killed and another injured in a Bridgeton shooting. Police are investigating and questioned a person after the victims were found with gunshot wounds.
  - (2026-08-01) [St. Louis] Google pulls controversial AI image-generation tool from Google Earth one day after launch
      Google rolled back the new tool after critics pushed back, showing how easy it was to generate fake satellite images of real places.
  - (2026-08-01) [St. Louis] Tornado watch ends for most counties west of St. Louis Friday evening
      The watch initially was extended into late Friday night.

### State-Level News — 41 new of 725 total
  - (2026-08-01) [Alaska] Shooting Sports Month 2026
      WHEREAS, Alaskans enjoy a variety of outdoor activities throughout the year, and many of those activities, from hiking and hunting to recreational shooting, involve the use of firearms; and WHEREAS, many Alaskans rely on…
  - (2026-08-01) [Alaska] First week of third gasline special session ends with no action by Dunleavy or Alaska Legislature
      The Alaska Legislature ended the first week of its third special session on the proposed trans-Alaska natural gas pipeline with no action. The session is for lawmakers to consider a property tax break to incentivize the…
  - (2026-07-31) [Alaska] After federal report, Alaska pilots grapple with unanswered questions in tragic Nome crash
      The National Transportation Safety Board on Thursday released the final report for the February 6, 2025, accident involving Bering Air flight 445 that killed all 10 people on board. While the NTSB’s report identifies air…
  - (2026-08-01) [Arizona] The Trump administration’s ‘draconian’ water cuts could gut Arizona’s Colorado River supply
      A new federal plan released Friday could mean cuts of up to 77% to Arizona’s share of Colorado River water, in the midst of a 25-year megadrought, something that state leaders say would cause catastrophic harm to the sta…
  - (2026-07-31) [Arizona] Bid to freeze Arizona’s ‘Secure the Border Act’ fails, but fight isn’t over
      An attempt to temporarily block an Arizona law allowing state officials to jail immigrants failed, but there’s still a chance that opponents could pause the law’s implementation — though when that might happen and whethe…
  - (2026-08-01) [Florida] What the Freedom Trucks don’t say about American history speaks volumes
      Some red flags had already popped up in my mind when I visited the Freedom Truck on July 11 in Huron during its three-day stop in that typical, small, welcoming South Dakota city. But after I experienced it, despite its…

### Ukrainian Internal News (national + local Kyiv) — 40 new of 119 total
  - (2026-08-01) Russian Attack on Kyiv Damages Lithuanian Embassy, 25 Ambulances
      A massive Russian missile and drone attack on Kyiv damaged the Lithuanian embassy and a medical transport depot, destroying five ambulances and significantly damaging 20 others on Saturday morning. Ukrainian officials co…
  - (2026-08-01) Drone Barrage Hits Ufa Refineries and Crimea Bases
      On Saturday, Aug. 1, a massive Ukrainian drone strike targeted Russian oil refineries in Ufa, Bashkortostan, and military positions in occupied Crimea. The Russian Defense Ministry claimed to have intercepted 274 drones…
  - (2026-08-01) Ukraine Downs Only 1 Ballistic Missile During Massive Attack on Kyiv
      A massive overnight Russian attack involving 35 missiles and 185 drones resulted in at least nine deaths and 30 injuries in Kyiv. Due to a critical shortage of Patriot interceptors, Ukrainian air defenses were only able…
  - (2026-08-01) Explainer: Why Kyiv’s Shelters Fail Civilians Under Russian Attack
      Bureaucratic delays, geography and outdated architecture have left Ukraine without enough adequate shelters. Even where protection is available, the realities of a high-intensity war often discourage civilians from using…
  - (2026-08-01) Russian E-Commerce Prices Surge After Wildberries Strikes
      Prices for goods on major Russian online marketplaces, primarily Wildberries and Ozon, have surged by 10% to 30% in recent days following a series of Ukrainian drone strikes targeting logistics infrastructure. The price…
  - (2026-08-01) Polish F-16s Intercept Russian Il-20 Plane Over Baltic Sea
      Two Polish F-16 fighter jets intercepted a Russian Il-20 reconnaissance aircraft flying over the Baltic Sea approximately 40 kilometers north of Kołobrzeg on July 31. Defense Minister Władysław Kosiniak-Kamysz confirmed…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-01) [Allen Zipporah] Form 4 (Reporting)
      filed 2026-08-01 01:54 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089353 Size: 5 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:54 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089353 Size: 5 KB
  - (2026-08-01) [Moore Joshua] Form 4 (Reporting)
      filed 2026-08-01 01:54 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089352 Size: 11 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:54 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089352 Size: 11 KB
  - (2026-08-01) [Reformation Inc.] Form 4 (Issuer)
      filed 2026-08-01 01:53 UTC · role: Issuer — Filed: 2026-07-31 AccNo: 0001104659-26-089351 Size: 5 KB
  - (2026-08-01) [RAUCH STACEY] Form 4 (Reporting)
      filed 2026-08-01 01:53 UTC · role: Reporting — Filed: 2026-07-31 AccNo: 0001104659-26-089351 Size: 5 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-08-01) PUMAD (France)
      icao24: 39de61 · position: (42.4285, 8.9798) · alt: 1981m · 282km/h
  - (2026-08-01) INDIA1 (India)
      icao24: 8002fb · position: (12.4896, 76.8771) · alt: 2537m · 513km/h
  - (2026-08-01) SAMU44 (France)
      icao24: 39ca84 · position: (47.2093, -1.5547) · on ground · 0km/h
  - (2026-08-01) RCH5010 (United States)
      icao24: ae63c6 · position: (43.7104, 23.744) · alt: 11887m · 854km/h
  - (2026-08-01) JAF7CB (Belgium)
      icao24: 44d1ba · position: (42.065, -2.7971) · alt: 10363m · 792km/h
  - (2026-08-01) JAF3MJ (Belgium)
      icao24: 44d1a6 · position: (48.2373, 1.3327) · alt: 10652m · 852km/h

### U.S. Federal Action — 20 new of 20 total
  - (2026-08-03) Visas: Visa Bond Program
      This rule finalizes the temporary final rule that went into effect on August 20, 2025, which launched a 12-month long Visa Bond Pilot Program (Pilot Program), and establishes a permanent visa bond program. An alien apply…
  - (2026-08-03) Auction of Flexible-Use Licenses in the Upper C-Band for Next-Generation Wireless Services Scheduled for April 27, 2027; Comment Sought on Competitive Bidding Procedures for Auction 115
      In this document, the Federal Communications Commission (the Commission or FCC) announces an auction of 3,248 new flexible-use licenses in the 3.98-4.14 GHz band. The Office of Economics and Analytics (OEA) and the Wirel…
  - (2026-08-03) High-Speed Train Noise Emission Standards
      This NPRM seeks to amend the noise emission regulations to address the unique noise emission characteristics of trains operating at speeds exceeding 160 miles per hour (mph). Specifically, the proposed regulation would p…
  - (2026-08-03) Rescinding Portions of Department of the Treasury Title VI Regulations To Conform More Closely With the Statutory Text and To Implement an Executive Order
      By this rule, the Department of the Treasury ("Department") amends its regulations implementing Title VI of the Civil Rights Act of 1964 ("Title VI") to eliminate disparate-impact liability. These amendments align the De…
  - (2026-08-03) Ventilation Plan Approval Criteria
      In response to a public request, the Mine Safety and Health Administration (MSHA) is reopening the rulemaking record and is scheduling a virtual public hearing on the Agency's proposed rule published on July 1, 2025, tit…
  - (2026-08-03) Medicare Program; FY 2027 Hospice Wage Index and Payment Rate Update and Hospice Quality Reporting Program Requirements
      This final rule updates the hospice wage index, payment rates, and aggregate cap amount for fiscal year 2027. This final rule also includes an analysis of Medicare non-hospice spending, including details regarding a hosp…

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 106 total
  - (2026-08-01) [USASpending] $42,774,168,231 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-08-01) [USASpending] $41,457,264,329 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-01) [USASpending] $35,144,939,584 → TRIAD NATIONAL SECURITY, LLC: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS
      Agency: Department of Energy. Description: IGF::CL::IGF COMPETITION FOR MANAGEMENT AND OPERATION OF LOS ALAMOS NATIONAL LABORATORY
  - (2026-08-01) [USASpending] $30,673,332,390 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-08-01) [USASpending] $27,583,176,865 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.
  - (2026-08-01) [USASpending] $19,868,865,110 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…

### State Legislative Action — 13 new of 96 total
  - (2026-08-01) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-08-01) [Alaska SB 181] An Act relating to disclosure of information obtained by the Department of Labor and Workforce Development to other state agencies.
      An Act relating to disclosure of information obtained by the Department of Labor and Workforce Development to other state agencies.
  - (2026-08-01) [Alaska SB 205] An Act relating to occupational disability benefits for peace officers and firefighters; and providing for an effective date.
      An Act relating to occupational disability benefits for peace officers and firefighters; and providing for an effective date.
  - (2026-08-01) [Alaska SB 233] An Act relating to the Controlled Substances Advisory Committee.
      An Act relating to the Controlled Substances Advisory Committee.
  - (2026-08-01) [Alaska SB 35] An Act relating to transportation network companies and delivery network companies; and relating to occupational accident insurance.
      An Act relating to transportation network companies and delivery network companies; and relating to occupational accident insurance.
  - (2026-08-01) [Alaska SB 163] An Act relating to inactive state accounts and funds; repealing the public access fund; repealing the Alaska temporary assistance program emergency account; repealing the 2001 Special…
      An Act relating to inactive state accounts and funds; repealing the public access fund; repealing the Alaska temporary assistance program emergency account; repealing the 2001 Special Olympics World Winter Games reserve…

### USGS earthquakes (M4.5+, past day) — 10 new of 20 total
  - (2026-08-01) M 5.6 - 200 km SW of Port McNeill, Canada
      M5.6 · 200 km SW of Port McNeill, Canada · depth 10 km
  - (2026-08-01) M 5.5 - 57 km E of Mutsu, Japan
      M5.5 · 57 km E of Mutsu, Japan · depth 82.29 km
  - (2026-08-01) M 5.1 - south of the Fiji Islands
      M5.1 · south of the Fiji Islands · depth 544.366 km
  - (2026-07-31) M 5.1 - 132 km ENE of Masohi, Indonesia
      M5.1 · 132 km ENE of Masohi, Indonesia · depth 10 km
  - (2026-08-01) M 4.8 - 44 km NW of Te Anau, New Zealand
      M4.8 · 44 km NW of Te Anau, New Zealand · depth 112.486 km
  - (2026-08-01) M 4.7 - 206 km NW of Oula Xiuma, China
      M4.7 · 206 km NW of Oula Xiuma, China · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-08-01) LoL: Anyone's Legend vs ThunderTalk Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $873,116 · resolves 2026-08-01
  - (2026-08-01) LoL: Nongshim Red Force vs BNK FEARX - Game 1 Winner
      yes price: 100% · 24h volume: $779,833 · resolves 2026-08-01
  - (2026-08-01) LoL: Anyone's Legend vs ThunderTalk Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $758,453 · resolves 2026-08-01
  - (2026-08-01) LoL: Anyone's Legend vs ThunderTalk Gaming (BO3) - LPL Group Ascend
      yes price: 100% · 24h volume: $661,812 · resolves 2026-08-01
  - (2026-08-01) Game Handicap: AL (-1.5) vs ThunderTalk Gaming (+1.5)
      yes price: 100% · 24h volume: $357,744 · resolves 2026-08-01
  - (2026-08-01) Will China invade Taiwan by September 30, 2026?
      yes price: 1% · 24h volume: $344,274 · resolves 2026-09-30

### Paper Trading Scorecard — 9 new of 143 total
  - (2026-08-01) [Manifold] Will Trump wear glasses in August?
  - (2026-08-01) [Manifold] Will I be jobless at some point before end of 2027?
  - (2026-08-01) [Manifold] Will the leaked OpenAI "GPT 5.6 Sol" proof that nonsofic groups exist be verified as correct?
  - (2026-08-01) [Manifold] Will OpenAI Astra solve a math problem Claude Opus 5 deems more important than the Jacobian Conjecture?
  - (2026-08-01) [Manifold] Polymarket has some METR time horizon market before EOY 2026?
  - (2026-08-01) [Manifold] Will a multi-agent system have its time horizon evaluated by METR before EOY 2026?

### IT, InfoSys & cybersecurity news (last 7 days) — 5 new of 57 total
  - (2026-08-01) [The Hacker News] Hackers Poison Adform Script to Swap Crypto Wallet Addresses Across Customer Sites
      Attackers modified a JavaScript file served by advertising technology company Adform, turning it into a browser-side tool that rewrites cryptocurrency wallet addresses. Adform detected the incident on July 27, 2026, remo…
  - (2026-08-01) [The Hacker News] Adobe Campaign Classic CVSS 10.0 Flaw Could Run Code Without User Interaction
      Adobe has released security updates to address a maximum-severity security flaw in Campaign Classic (ACC), its enterprise-focused marketing automation platform, that could result in arbitrary code execution. The vulnerab…
  - (2026-08-01) [The Hacker News] Hijacked Hotel Wi-Fi Pushes Fake Updates to Deliver Surveillance Malware
      A fake browser update served over hijacked hotel Wi-Fi has been used to deliver CornFlake, a remote access trojan (RAT) that can capture webcam images, microphone audio, and keystrokes, Microsoft said in its latest repor…
  - (2026-08-01) [The Register] A deep dive into Nvidia's Vera CPU and the Olympus cores that power it
      88 custom cores, 176 funky threads, 1.5 TB of laptop RAM, and 1.8 TB/s of NVLink connectivity — this isn't your typical datacenter chip
  - (2026-08-01) [The Register] Enterprise cloud infrastructure uptake shows no sign of slowing
      Cloud revenue now north of $143 billion a quarter, and growth is accelerating

### Court opinions of consequence (federal & state) — 3 new of 60 total
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: Bay Area Unitarian v. Ogg
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: Fields v. CIR
  - (2026-07-31) U.S. Court of Appeals, 5th Cir.: MIECO v. Targa Gas Marketing

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-01) [Marginal Revolution] Immigration and Macroeconomic Outcomes in OECD Countries
      OECD countries experienced declining native population growth and rising net immigration over 1990-2024. We compile a new dataset of net immigration rates to OECD countries from all origins and show that most of the incr…
  - (2026-08-01) [Marginal Revolution] Emergent Ventures India, 18th cohort
      Adithyan Madhu, 14, an independent researcher, received his grant to study early writing systems, applying computational linguistics, pattern analysis, and structural methods to the Indus Valley script. Aparajeet Shadang…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: provide, program, management, proposing, action, published, taking, standard, proposes, safety, certain, amend
- state_bills: today=96, 7d-median=138, 14d-median=138; carrying terms: grants, address, management, provides, services, require, prohibits, establishes, appropriate, existing, policy, operating
- state_news: today=725, 7d-median=725, 14d-median=718; carrying terms: controversial, short, electric, process, students, millions, money, break, young, fallen, grand, clean
- local_news: today=255, 7d-median=228, 14d-median=228; carrying terms: events, dining, being, investigation, articles, found, killed, attempted, since, illinois, evening, authorities
- foreign_news: today=1028, 7d-median=1022, 14d-median=1023; carrying terms: punchng, stopped, recital, address, supply, kindergarten, guilty, seven, terrorism, students, prohibit, nantong
- chinese_internal: today=305, 7d-median=265, 14d-median=270; carrying terms: caixin, google, china, global, https, people, chinese, market, office, build, firms, record
- russian_internal: today=998, 7d-median=937, 14d-median=926; carrying terms: gazeta, media, bloomberg, reuters, times, street, istories, forbidden, wildberries, error, title, laquo
- ukrainian_internal: today=119, 7d-median=136, 14d-median=136; carrying terms: joint, forces, supply, company, putin, moscow, restrictions, officials, prime, refineries, victims, hmarochos
- ukraine_theater: today=842, 7d-median=627, 14d-median=636; carrying terms: liveuamap, polygon, thermal, httperror, acquired, known, deepstatemap, client, daily, maintained, google, snapshot
- paper_bets: today=143, 7d-median=138, 14d-median=140; carrying terms: humanoid, state, drought, russell, carolina, resolution, majors, degrees, resolve, listed, baker, alaska
- weather: today=173, 7d-median=173, 14d-median=174; carrying terms: twoat, severe, hours, short, afdmeg, limbs, francisco, normal, portion, nueces, grand, outlook
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: openings, latest, labor, payrolls, money, funds, spread, cpiaucsl, consumption, recession, crude, growth
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, crypto, futures, rates, russell, equities, crude, close, silver, range, nasdaq, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=106, 7d-median=111, 14d-median=113; carrying terms: events, burundi, terrorism, company, annexation, prohibited, venezuela, technologies, engineering, bosnia, protests, situation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, client, quiver, unauthorized, https, quantitative, httperror, quiverquant, error
- billionaires: today=30, 7d-median=37, 14d-median=36; carrying terms: france, yanai, ambani, japan, changpeng, michael, infrastructure, tiktok, bloomberg, discount, zuckerberg, exchange
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: delaware, california, supreme, services, international, blanche, trade, court, appeals, county, johnson, group
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, amended, holdings
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ocasio, trone, krishnamoorthi, elect, james, michael, david, committee, booker, graham, robert, filing
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan, switch
- gdelt_gkg: today=93, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, trump, graham, themes, italian, chinese, keywords, russia, lindsey, spanish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=16, 14d-median=16; carrying terms: belgium, position, ground, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: algeria, affecting, round, paralytic, ventilation, geographical, cruise, circulating, state, outbreak, january, bulape
- cisa_kev: today=9, 7d-median=14, 14d-median=15; carrying terms: fortinet, control, management, command, vulnerability, authentication, remediation, microsoft, injection, vendor, langflow, deserialization
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=287, 14d-median=287; carrying terms: salvador, somalia, macedonia, france, drought, herzegovina, minor, ethiopia, slovakia, philippines, earthquake, thailand
- usgs_quakes: today=20, 7d-median=20, 14d-median=22; carrying terms: indonesia, region, islands, depth, south, mexico, japan, chile, philippines, sandwich, china, puerto
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, interest, rates, resolves, meeting, price, change, decrease, increase, ceasefire, august, invade
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: economist, class, conversable, marginal, revolution, https, conversableeconomist, government, having, doctor, certain, students
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: company, exposed, hacker, provides, review, bleepingcomputer, being, cybersecurity, intelligence, going, ransomware, attack
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: panetta, degette, bonnie, langworthy, crane, clarence, bentz, score, hirono, composite, baumgartner, yakym
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, evidence, placed, unavailable, market, decision, module, sufficient, paper, identify, claude, converges

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*