# WORLDSCOPE morning brief — 2026-11-06

## Headline
3236 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (806) · Russian Internal News (state + in-exile) (642) · State-Level News (346) · World leaders & government officials (324) · Chinese Internal News (251) · Local News: St. Louis + Atlanta (226) · U.S. Weather + Severe / Climate Outlooks (94) · Ukraine Theater (total-war monitoring) (91) · Ukrainian Internal News (national + local Kyiv) (73) · State Legislative Action (62) · GDACS — global disaster alerts (51) · IT, InfoSys & cybersecurity news (last 7 days) (45)

## What changed today
### International News + Multilateral Institutions — 806 new of 1040 total
  - (2026-11-06) [Global] ANC faces bruising defeat in South African local elections with 80% of ballots counted
  - (2026-11-06) [Global] Flávio Bolsonaro battles to remain relevant as he speaks at rightwing conference at Mar-a-Lago
  - (2026-11-06) [Global] Low pressure in US midwest brings unseasonable heat to New York and Boston
  - (2026-11-06) [Global] Paraguay’s president quits after millions of people’s savings frozen in bank crisis
  - (2026-11-06) [Global] Peru airport officials discover 3,000 tarantulas smuggled inside dirty socks
  - (2026-11-06) [Global] Global stocks plunge amid AI slowdown fears after Democrats’ midterm triumph

### Russian Internal News (state + in-exile) — 642 new of 951 total
  - (2026-11-06) Новые «иноагенты» — партии «Мирная Россия» Ильи Яшина и «Рассвет» Екатерины Дунцовой | LEDE: Министерство юстиции РФ обновило реестр «иностранных агентов», добавив в него незарегистрированны] (ru: Нов…
      Министерство юстиции РФ обновило реестр «иностранных агентов», добавив в него незарегистрированные оппозиционные партии «Мирная Россия» и «Рассвет».
  - (2026-11-06) Основатель «Мужского государства» заявил, что не причастен к отправке сообщений о бомбах на европейских рейсах | LEDE: Основатель движения «Мужское государство» Владислав Поздняков заявил, ч] (ru: Осн…
      Основатель движения «Мужское государство» Владислав Поздняков заявил, что не причастен к сообщениям о бомбах на рейсах в Европе. Об этом говорится в посте его канала «Поздняков 3.0».
  - (2026-11-06) Трамп объявил Овальный кабинет «национальным памятником». Он считает, что отныне следующие президенты США не смогут поменять его интерьер | LEDE: Дональд Трамп подписал прокламацию, которая,] (ru: Тра…
      Дональд Трамп подписал прокламацию, которая, по его словам, должна сохранить Овальный кабинет Белого дома и зал заседаний кабинета министров в качестве национального памятника.
  - (2026-11-06) На биржах по всему миру — мощный обвал. Инвесторы боятся победы демократов в США и ограничений в сфере ИИ | LEDE: Фондовые рынки США пережили крупнейший обвал с апреля 2025 года. По оценке F] (ru: На…
      Фондовые рынки США пережили крупнейший обвал с апреля 2025 года. По оценке Financial Times, капитализация американского фондового рынка сократилась за 5 ноября на 3,2 триллиона долларов. Индекс S&P 500 потерял 4,4%, пром…
  - (2026-11-06) Война. 1717-й день. Мелания Трамп подводит итоги гуманитарной миссии в Алешках, ее муж обещает «большую прекрасную сделку» по Украине | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире р] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-11-06) Король Бельгии не принял отставку премьера Барта де Вевера. Тот хотел уйти из-за провала переговоров о бюджете | LEDE: Король Бельгии Филипп отклонил прошение премьер-министра Барта де Вевер] (ru: Кор…
      Король Бельгии Филипп отклонил прошение премьер-министра Барта де Вевера об отставке, которое тот подал 2 ноября.

### State-Level News — 346 new of 1171 total
  - (2026-11-06) [California] Governor Newsom announces major cleanup progress in communities impacted by shuttered Exide battery recycling facility in South Los Angeles
      Source
  - (2026-11-06) [California] Governor Newsom announces appointments 11.5.26
      Source
  - (2026-11-05) [California] Governor Newsom releases letter to California on the death penalty
      Source
  - (2026-11-05) [California] California expands water storage infrastructure, largest new reservoir in more than 50 years clears final permit
      Source
  - (2026-11-06) [California] Will Newsom’s death penalty commutations stick?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/11/072623_San-Quentin_SN_CM_39.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-11-06) [California] Distant polls, spotty mail obstruct Native American voting 6 years after law meant to help them
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/110524_Riverside-Election_JH_CM_06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 251 new of 344 total
  - (2026-11-05) 分析｜拉丁裔选票大转向何以重挫共和党 特朗普拥趸群体纷纷松动 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1XR1FJTHJKVDQtbkk0S0FUQ1AxczB3Wko2TjMzd09JUVk5Z2NKZ3hOMTNDb3NsMW4ydWJfNV9UQUVk] (zh:…
      分析｜拉丁裔选票大转向何以重挫共和党 特朗普拥趸群体纷纷松动 Caixin Global
  - (2026-11-06) 今日开盘：两市双双低开 沪指跌幅2.11% - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1NS2dnbzFZdDZEcGowcVM3dXRmMHBEV2gxcno0YTlnSXlzSU1VUzFoMk1LU1FwTXlyY0FrTGpGdlhVU1lkdTB3S] (zh:…
      今日开盘：两市双双低开 沪指跌幅2.11% Caixin Global
  - (2026-11-06) AI胡说八道该由谁担责？｜法度 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9ZN3hMbUduNnhnU3ROaWdJV1d6YlZiMUhYUEgxV1M5VDJSUjZOUHl5MTdQUWc3dGZNcXpCSFBzUlFuc0VDTFZNMjgyRzU] (zh:…
      AI胡说八道该由谁担责？｜法度 Caixin Global
  - (2026-11-06) “前腐后继” 64岁女高官余艳红官宣投案 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE12SW5OTE1tSFdlbnhrdFAxZGxrWC10Qlhhd1RTNmdlTjBuRmpKNmtIMXZIaTZTcXgtNjBabEVZTlR1REVGaTFQZm] (zh:…
      “前腐后继” 64岁女高官余艳红官宣投案 Caixin Global
  - (2026-11-06) 山东七旬老者杀人沉尸案第三次一审宣判 双双获刑无期 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5oV2lMMUY5Wk8xejM5YUZydEdzR1BpVU1mMjhUTmlWQ0gtOWJsaHB6UDNGUlhlNmJuX2NkME1MZHZGM0daO] (zh:…
      山东七旬老者杀人沉尸案第三次一审宣判 双双获刑无期 Caixin Global
  - (2026-11-05) 财经早知道｜潘功胜：实施好支持资本市场的货币政策工具 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5OMjlXZ0E2WVItMzVwQ2tCMWRpOHJfM0RyX2NyODJyQ1F3WjROQzNMZWZqaWxleTIxa1p2anhnbS10SkQy] (zh:…
      财经早知道｜潘功胜：实施好支持资本市场的货币政策工具 Caixin Global

### Local News: St. Louis + Atlanta — 226 new of 288 total
  - (2026-11-06) [St. Louis] New hazard for St. Louis snow-plow drivers: Traffic-calming infrastructure
      As the city prepares for snow removal efforts ahead of this winter, snow plow drivers are learning to navigate a new obstacle: all the new traffic-calming infrastructure. “We’re gonna hit a lot of concrete,” Streets Depa…
  - (2026-11-06) [St. Louis] St. Louis Public Library’s new CEO Jason Driver has no desire to shake things up
      When Jason Driver comes on the job as CEO of St. Louis Public Library in January, he isn’t just replacing a well-respected leader, Waller McGuire, who ran the system for 22 years. He’s also taking over what was recently…
  - (2026-11-06) [St. Louis] What’s True in the Lou? – 11/6/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-11-05) [St. Louis] Where in St Charles 11/6/2026
      Let’s see how well you know St. Charles. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess”…
  - (2026-11-05) [St. Louis] The Muny and Jazz St. Louis announce new operational partnership
      The Muny and Jazz St. Louis have announced a new partnership designed to support and revitalize Jazz St. Louis’ operations, which has begun early implementation. The partnership, announced in tandem with Jazz St. Louis’…
  - (2026-11-05) [St. Louis] Photos: St. Louis Supper Club at Sidney Street Cafe
      On November 2, 2026, St. Louis Magazine hosted our latest St. Louis Supper Club, presented by ReeceNichols, at Sidney Street Cafe in Benton Park. “Cheryl and I chose a classic over the latest hot spot,” says George. “For…

### U.S. Weather + Severe / Climate Outlooks — 94 new of 96 total
  - (2026-11-06) [Severe] Flood Warning: Flood Warning issued November 6 at 9:17AM EST by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Cocoa 9w affecting Brevard County. .Heavy rainfall will cause a continued rise through Moderate flood stage through the end of the…
  - (2026-11-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-06) [Severe] Flood Warning: Flood Warning issued November 6 at 9:14AM EST by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Deland affecting Lake and Volusia Counties. .Heavy rainfall has caused the St. Johns River near Deland to rise into Minor flood st…
  - (2026-11-06) [Severe] Flash Flood Warning: Flash Flood Warning issued November 6 at 9:14AM EST until November 6 at 11:00AM EST by NWS Mount Holly NJ
      At 914 AM EST, flooding was still ongoing across portions of Monmouth County, as well as northern Ocean County. The heaviest rains have moved out, but more than 3.00 inches fell earlier this morning. NJ 35 in Belmar, NJ…
  - (2026-11-06) [Severe] Flood Warning: Flood Warning issued November 6 at 9:06AM EST by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Astor affecting Lake and Volusia Counties. .Heavy rainfall that has occurred upstream will maintain river levels within Moderate f…
  - (2026-11-06) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued November 6 at 5:38AM PST until November 7 at 12:00AM PST by NWS Eureka CA
      * WHAT...Increased threat of sneaker waves expected. * WHERE...Coastal Del Norte, Northern Coastal Humboldt, Southwestern Humboldt and Coastal Mendocino Counties. * WHEN...Through Friday evening. * IMPACTS...Large, unexp…

### Ukraine Theater (total-war monitoring) — 91 new of 265 total
  - (2026-11-06) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-03) [Liveuamap] Russia targeted a substation critical to the stable operation of the Khmelnytskyi Nuclear Power Plant with three drones, Energy Minister Shmyhal said. According to him, energy facilities w…
      Russia targeted a substation critical to the stable operation of the Khmelnytskyi Nuclear Power Plant with three drones, Energy M
  - (2026-11-05) [Liveuamap] Yemeni forces: We have gained control of the Sanmat area in Taiz and thwarted infiltration attempts in several sectors. - Liveuamap
      Yemeni forces: We have gained control of the Sanmat area in Taiz and thwarted infiltration attempts in several sectors.</
  - (2026-11-05) [Liveuamap] Al-Shifa Medical Center: Injured Palestinians in Gaza&039;s Jabalia refugee camp hit by Israeli strike – Jabalia, Gaza - Liveuamap
      Al-Shifa Medical Center: Injured Palestinians in Gaza&039;s Jabalia refugee camp hit by Israeli strike
  - (2026-11-06) [Liveuamap] At Pokrovsk direction clashes yesterday near Vilne, Molodetske, Kucheriv Yar, Dobropillya, Svyatohorivka, Serhiyivka, Novopavlivka, - General Staff of Armed Forces of Ukraine reports – Dni…
      At Pokrovsk direction clashes yesterday near Vilne, Molodetske, Kucheriv Yar, Dobropillya, Svyatohorivka, Serhiyivka, Novopavlivk
  - (2026-11-04) [Liveuamap] The last detainee in the Ra&039;am election bribery affair has been released. Judge Tsavari criticized the police: "Despite remarks given in my decision and in the appeal, the investigatin…
      The last detainee in the Ra&039;am election bribery affair has been released. Judge Tsavari criti

### Ukrainian Internal News (national + local Kyiv) — 73 new of 139 total
  - (2026-11-06) UADamage Secures US Funding to Scale AI Tech
      Ukrainian startup UADamage secured investments from US based Pravo Ventures and Ondas Capital to accelerate its AI powered demining technologies. The capital will support the integration of multi-sensor data and the glob…
  - (2026-11-06) Japan Demands Russia Return Control of Four Japan Tobacco Businesses
      Tokyo has formally protested Russia’s decision to put four Japan Tobacco businesses under the control of a Russian company. The order affects the country’s largest tobacco producer and follows similar moves against Nestl…
  - (2026-11-06) Kyiv Warns Heating Utility Raids Threaten Energy Projects
      Investigators searched offices and homes of Kyivteploenergo employees, Kyiv authorities said, warning that the possible seizure of original documents could disrupt energy resilience projects. The utility says the design…
  - (2026-11-06) UK and France to Lead First Major Drill for Post-Ceasefire Ukraine Force
      Exercise Koalicja will test whether troops from 11 countries can move equipment across borders, operate under one command and keep a multinational force supplied. Britain and France have declared their intent to deploy a…
  - (2026-11-06) Russia Proposes Letting Airlines Keep Foreign-Leased Jets Through 2028
      Russia’s Transport Ministry has drafted a two-year extension to wartime rules that allowed airlines to retain aircraft after foreign leasing companies demanded their return. Russian carriers still depend on Western-built…
  - (2026-11-06) Ukraine Seeks New Contract for Starshield Amid Connectivity Challenges
      Despite the still unexplained speed limitations imposed on Ukraine by the Starshield satellite network last month, Kyiv is pushing for renewal of the agreement with the US government due to expire in mid-2027.

### State Legislative Action — 62 new of 90 total
  - (2026-11-06) [Alaska SB 40] An Act establishing the period between September 15 and October 15 of each year as Hispanic Heritage Month.
      An Act establishing the period between September 15 and October 15 of each year as Hispanic Heritage Month.
  - (2026-11-06) [Alaska SB 193] An Act relating to the practice of naturopathy.
      An Act relating to the practice of naturopathy.
  - (2026-11-06) [California SB 344] California Environmental Quality Act: City of San Diego: mixed-use development project.
      The California Environmental Quality Act (CEQA) requires a lead agency, as defined, to prepare, or cause to be prepared, and certify the completion of an environmental impact report on a project that it proposes to carry…
  - (2026-11-06) [California AB 1905] Juveniles: custodial interrogation.
      Existing law prohibits law enforcement officers from employing threats, physical harm, deception, or psychologically manipulative interrogation tactics, as specified, during a custodial interrogation of a person 17 years…
  - (2026-11-06) [California SB 501] Responsible Battery Recycling Act of 2022: covered batteries.
      Existing law, the Responsible Battery Recycling Act of 2022, establishes a stewardship program, administered by the Department of Resources Recycling and Recovery, with the Department of Toxic Substances Control, as prov…
  - (2026-11-06) [California AB 220] Medi-Cal: subacute care services.
      Existing law establishes the Medi-Cal program, which is administered by the State Department of Health Care Services, under which qualified low-income individuals receive health care services. The Medi-Cal program is, in…

### GDACS — global disaster alerts — 51 new of 100 total
  - (2026-11-05) [Green] Flood in France
      Flood · Green alert · France · Magnitude 0
  - (2026-11-06) [Green] Tropical Cyclone THIRTYONE-26
      Tropical Cyclone · Green alert · Japan · Tropical Depression (maximum wind speed of 185 km/h)
  - (2026-11-06) [Green] Earthquake in Off East Coast Of Honshu, Japan
      Earthquake · Green alert · Off East Coast Of Honshu, Japan · Magnitude 6.1M, Depth:29km
  - (2026-11-06) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.5M, Depth:246.521km
  - (2026-11-06) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 4.9M, Depth:35km
  - (2026-11-06) [Green] Earthquake in South Of Alaska
      Earthquake · Green alert · South Of Alaska · Magnitude 4.7M, Depth:27.963km

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 61 total
  - (2026-11-06) [BleepingComputer] Chainalysis says breach exposed credentials for all customers
      Blockchain intelligence firm Chainalysis says a recent attack on its systems and internal tools has exposed credentials and live tokens for all customers. [...]
  - (2026-11-06) [BleepingComputer] D-Link warns of multiple zero-days in DGS-3130 Series switches
      D-Link shared mitigation measures for multiple unpatched security flaws affecting DGS-3130 series managed Gigabit stackable switches. [...]
  - (2026-11-06) [BleepingComputer] MetaMask says recent attack didn't affect wallet infrastructure
      Cryptocurrency wallet provider MetaMask said a recent security incident has not affected MetaMask wallets or its wallet infrastructure. [...]
  - (2026-11-06) [BleepingComputer] FBI, CISA warn of cyberattacks targeting refrigeration systems
      The FBI and CISA warn that hackers are actively targeting industrial refrigeration and cold-chain monitoring systems worldwide, potentially causing food spoilage, equipment damage, and fire hazards. [...]
  - (2026-11-06) [The Hacker News] Microsoft Paint RCE Fix Now Available, but Windows Update Won't Deliver It
      A fix for CVE-2026-83844, a remote code execution flaw in Windows Paint, is now in the Microsoft Store. Paint gets this fix only through a Store update, not through Windows updates. The fixed build, 11.2609.401.0, was th…
  - (2026-11-06) [The Hacker News] Malicious Browser Extensions Could Use Claude Dispatch to Run Code on Users' Computers
      A browser extension that can run scripts on claude.ai could make Claude Desktop run code on a person's computer, researchers at Forever Security, an endpoint security company, showed in a test. The attack needs Dispatch,…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-06) 497 - NYLIM VP FUNDS TRUST (0000887340) (Filer)
      filed 2026-11-06 14:17 UTC — Filed: 2026-11-06 AccNo: 0000887340-26-000120 Size: 12 KB
  - (2026-11-06) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-11-06 14:16 UTC — Filed: 2026-11-06 AccNo: 0001918704-26-034800 Size: 921 KB
  - (2026-11-06) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-11-06 14:16 UTC — Filed: 2026-11-06 AccNo: 0001918704-26-034800 Size: 921 KB
  - (2026-11-06) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-11-06 14:13 UTC — Filed: 2026-11-06 AccNo: 0001918704-26-034799 Size: 1 MB
  - (2026-11-06) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-11-06 14:13 UTC — Filed: 2026-11-06 AccNo: 0001918704-26-034799 Size: 1 MB
  - (2026-11-06) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-11-06 14:12 UTC — Filed: 2026-11-06 AccNo: 0001918704-26-034798 Size: 1 MB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-11-06) SAMU71 (France)
      icao24: 398c4e · position: (46.8253, 4.8178) · alt: 121m · 50km/h
  - (2026-11-06) CFC01 (Canada)
      icao24: c2c1f1 · position: (46.592, -80.3254) · alt: 11582m · 840km/h
  - (2026-11-06) PAT334 (United States)
      icao24: adfec9 · position: (37.4223, -87.6695) · alt: 6096m · 478km/h
  - (2026-11-06) PAT348 (United States)
      icao24: adfec0 · position: (35.2225, -98.4916) · alt: 10363m · 716km/h
  - (2026-11-06) NCR306 (United States)
      icao24: ab4ec6 · position: (30.888, -84.5073) · alt: 4495m · 654km/h
  - (2026-11-06) FNY55C4 (France)
      icao24: 39a408 · position: (46.1875, 2.1946) · alt: 10919m · 726km/h

### GDELT GKG — themes / entities / watch areas — 27 new of 27 total
  - (2026-11-06) [Russia oil sanctions perimeter · keywords] Azerbaijan Azeri Light crude price grows to $106 . 84 per barrel
      trend.az · English · tone NA
  - (2026-11-06) [Taiwan Strait + South China Sea · themes] รวมเลขมหามงคล ขบวนพยุหยาตราทางชลมารค 2569 พระราชพิธีถวายผ้าพระกฐิน
      sanook.com · Thai · tone NA
  - (2026-11-06) [Taiwan Strait + South China Sea · themes] Awantura na rafie na Malediwach . Bójka 15 m pod wodą
      turystyka.wp.pl · Polish · tone NA
  - (2026-11-06) [Taiwan Strait + South China Sea · themes] Singapore growing robot workforce
      neworleanssun.com · English · tone NA
  - (2026-11-06) [Taiwan Strait + South China Sea · themes] Télécran
      telecran.lu · French · tone NA
  - (2026-11-06) [Taiwan Strait + South China Sea · themes] 観測史上最も暑い１０月に 年間平均２４年に次ぐ見通し｜全国のニュース｜北國新聞
      hokkoku.co.jp · Japanese · tone NA

### U.S. Federal Action — 18 new of 26 total
  - (2026-11-06) The American Declaration of Freedom in Space
  - (2026-11-06) Anti-Communism Week, 2026
  - (2026-11-06) Amendments to the “Small Business” and “Small Organization” Definitions for Investment Companies and Investment Advisers for Purposes of the Regulatory Flexibility Act
      The Securities and Exchange Commission (the "Commission" or the "SEC") is amending the definitions of "small business" and "small organization" (collectively, "small entities") that are used in connection with Commission…
  - (2026-11-06) Medicare Program: Hospital Outpatient Prospective Payment and Ambulatory Surgical Center Payment Systems; and Quality Reporting Programs; including the Hospital Outpatient Quality Reporting Program an…
      This final rule with comment period revises the Medicare Hospital Outpatient Prospective Payment System (OPPS) and the Medicare Ambulatory Surgical Center (ASC) payment system for calendar year 2027 based on our continui…
  - (2026-11-06) Heightened Requirements for Foreign Importers of Record
      This document amends the U.S. Customs and Border Protection (CBP) regulations, consistent with Section 2 of Executive Order 14411, "Strengthening Customs Enforcement," by establishing new requirements for foreign importe…
  - (2026-11-06) Drawbridge Operation Regulation; Harlem River, Between the Boroughs of Manhattan and the Bronx, New York City, New York
      The Coast Guard proposes to temporarily modify the operating regulation that governs the Macombs Dam Bridge across the Harlem River, mile 3.2, between the Boroughs of Manhattan and the Bronx, New York City, New York. The…

### Court opinions of consequence (federal & state) — 18 new of 60 total
  - (2026-11-06) Supreme Court of Alabama: LG Electronics Alabama, Inc. v. Velaro, Inc.
  - (2026-11-06) Supreme Court of Alabama: LG Electronics Alabama, Inc. v. Velaro, Inc.
  - (2026-11-06) Supreme Court of Alabama: Maynard Nexsen, PC v. Cadence Bank
  - (2026-11-06) Supreme Court of Alabama: Walmart, Inc. v. Bonnie Estell, as the personal representative of the Estate of James E. Reed
  - (2026-11-05) U.S. Court of Appeals, 2nd Cir.: Diaz v. Blanche
  - (2026-11-05) U.S. Court of Appeals, 8th Cir.: United States v. CJ Carruthers

### Government Action: Sanctions + Procurement + Foreign Agents — 17 new of 96 total
  - (2026-11-05) [OFAC] Cyber-related and Transnational Criminal Organizations Designations; Cuba Designations; Publication of Cuba-related Determination - Office of Foreign Assets Control (.gov)
      Cyber-related and Transnational Criminal Organizations Designations; Cuba Designations; Publication of Cuba-related Determination Office of Foreign Assets Control (.gov)
  - (2026-11-05) [OFAC] DETERMINATION PURSUANT TO SECTION 2(a)(i)(A) OF EXECUTIVE ORDER 14404 Electronics, Manufacturing, Marine, and Technology Sector - Office of Foreign Assets Control (.gov)
      DETERMINATION PURSUANT TO SECTION 2(a)(i)(A) OF EXECUTIVE ORDER 14404 Electronics, Manufacturing, Marine, and Technology Sector Office of Foreign Assets Control (.gov)
  - (2026-11-06) [USASpending] $2,594,040,000 → FISHER SAND & GRAVEL CO: BORDER BARRIER DESIGN BUILD FOR BBT-5
      Agency: Department of Homeland Security. Description: BORDER BARRIER DESIGN BUILD FOR BBT-5
  - (2026-11-06) [USASpending] $2,310,148,568 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.
  - (2026-11-06) [USASpending] $1,632,320,471 → AT&T ENTERPRISES, LLC: ENTERPRISE DATA NETWORK SERVICES CARRIER B
      Agency: Department of Veterans Affairs. Description: ENTERPRISE DATA NETWORK SERVICES CARRIER B
  - (2026-11-06) [USASpending] $1,603,374,527 → CALIFORNIA INSTITUTE OF TECHNOLOGY: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270
      Agency: National Aeronautics and Space Administration. Description: MARS SAMPLE RETURN (MSR) PROGRAM - PHASE A 40-108270

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-05) [FRQ] INDEPENDENT ELECTRICAL CONTRACTORS PAC (IEC PAC)
      cycle 2026 · filing #
  - (2026-11-05) [FRQ] LOSERS AND SUCKERS VOTE
      cycle 2026 · filing #
  - (2026-11-05) [F2] GONZALES-TORRES, ANGELA
      cycle 2026 · filing #2046484
  - (2026-11-05) [F2] CAPITO, SHELLEY MOORE
      cycle 2026 · filing #2046362
  - (2026-11-05) [F3X] UNITED POSTMASTERS AND MANAGERS OF AMERICA POLITICAL FUND
      cycle 2026 · filing #2046494 · receipts $0.01M
  - (2026-11-05) [F2] BOHANNAN, CHRISTINA
      cycle 2026 · filing #2046419

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-11-06) Counter-Strike: FURIA vs BetBoom Team (BO3) - IEM Beijing Playoffs
      yes price: 46% · 24h volume: $2,719,792 · resolves 2026-11-06
  - (2026-11-06) Will Donald Trump publicly insult Ken Paxton by October 31, 2026?
      yes price: 100% · 24h volume: $660,401 · resolves 2026-10-31
  - (2026-11-06) Will there be no change in Fed interest rates after the December 2026 meeting?
      yes price: 22% · 24h volume: $568,058 · resolves 2026-12-09
  - (2026-11-06) Rolex Paris Masters: Ben Shelton vs Tommy Paul
      yes price: 52% · 24h volume: $512,917 · resolves 2026-11-13
  - (2026-11-06) Will the Fed decrease interest rates by 50+ bps after the December 2026 meeting?
      yes price: 0% · 24h volume: $471,797 · resolves 2026-12-09
  - (2026-11-06) Will Abdul El-Sayed win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $456,762 · resolves 2028-11-07

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-11-06) M 6.1 - 144 km SE of Hasaki, Japan
      M6.1 · 144 km SE of Hasaki, Japan · depth 29 km
  - (2026-11-05) M 6.1 - Fiji region
      M6.1 · Fiji region · depth 535 km
  - (2026-11-05) M 5.0 - 130 km NE of Thang, India
      M5.0 · 130 km NE of Thang, India · depth 76.944 km
  - (2026-11-06) M 4.9 - 41 km SW of Balangonan, Philippines
      M4.9 · 41 km SW of Balangonan, Philippines · depth 35 km
  - (2026-11-06) M 4.7 - 139 km SSE of False Pass, Alaska
      M4.7 · 139 km SSE of False Pass, Alaska · depth 27.963 km
  - (2026-11-06) M 4.6 - 58 km WNW of Isangel, Vanuatu
      M4.6 · 58 km WNW of Isangel, Vanuatu · depth 83.271 km

### Paper Trading Scorecard — 4 new of 54 total
  - (2026-11-06) [Manifold] Will this resolve yes?
  - (2026-11-06) [Manifold] Will we get another teaser for The Elder Scrolls VI on November 11?
  - (2026-11-06) [Manifold] Will I write for 2 hours a day for the next month?
  - (2026-11-06) [Manifold] Will the AP call the 2026 Mississippi Senate race (Colom vs. Hyde-Smith) by November 20, 2026?

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-11-06) [Marginal Revolution] What They Took From You
      Until August 1914 a sensible, law-abiding Englishman could pass through life and hardly notice the existence of the state, beyond the post office and the police. He could live where he liked and as he liked. He had no of…
  - (2026-11-06) [Marginal Revolution] The Global Office
      This paper argues that globalisation’s frontier has shifted from manufacturing GVCs to services GVCs: from the Global Factory to the Global Office. While the Factory remains larger in gross trade, the Office is growing m…
  - (2026-11-06) [Marginal Revolution] Natasha Cowen guest posts on Caffrey
      I am on my way back home from Armenia, where I was on a Fulbright teaching U.S. securities regulation to Armenian law students. I’m an active user of AI for multiple areas of my life, including my professional life. When…

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-11-06) Yellow fever - WHO African Region
      Yellow fever transmission continues in the WHO African Region, with recent outbreak activity concentrated in parts of West Africa. Between 1 January and 12 October 2026, 67 confirmed cases, including 18 deaths, were reco…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=15, 14d-median=15; carrying terms: action, regulatory, final, safety, commission, certain, provide, national, procedures, published, necessary, changes
- state_bills: today=90, 7d-median=100, 14d-median=90; carrying terms: providing, vehicle, emergency, relating, insurance, alaska, review, provides, motor, specified, grant, procedures
- state_news: today=1171, 7d-median=757, 14d-median=724; carrying terms: sizes, democrat, republican, initiative, administration, little, building, previous, seeks, provide, medical, colorado
- local_news: today=288, 7d-median=256, 14d-median=253; carrying terms: republican, football, atlantamagazine, midterms, years, three, florida, final, health, against, wednesday, google
- foreign_news: today=1040, 7d-median=1013, 14d-median=1006; carrying terms: fears, republic, seized, september, improve, parliament, march, previous, seeks, equity, threat, organizing
- chinese_internal: today=344, 7d-median=304, 14d-median=281; carrying terms: cbmib, google, articles, cbmiy, title, blank, cbmizefvx, china, growth, lxtfa, cbmixkfvx, cbmidefvx
- russian_internal: today=951, 7d-median=938, 14d-median=952; carrying terms: forbidden, bloomberg, times, laquo, financial, novayagazeta, server, media, telegram, error, reuters, istories
- ukrainian_internal: today=139, 7d-median=134, 14d-median=131; carrying terms: trump, provide, oleshky, power, military, minister, vechirniy, general, energy, second, warned, forbidden
- ukraine_theater: today=265, 7d-median=329, 14d-median=369; carrying terms: vkrwmmy, remtavfl, cwhuenvoy, urengoy, mxdozwxxbm, vucwwwnly, wezxa, cuxpdnrawktyvs, dwjjzejqug, yajbsb, ptcehqmwe, september
- paper_bets: today=54, 7d-median=67, 14d-median=65; carrying terms: derrick, california, president, state, passing, millennium, become, degrees, force, speed, human, regular
- weather: today=96, 7d-median=130, 14d-median=132; carrying terms: afdbox, galveston, forecast, level, afdphi, mount, coast, miami, afdmeg, north, pontiac, today
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, rates, assets, walcl, latest, commodities, consumption, supply, pcepilfe, vixcls, unemployment, effective
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, treasury, futures, corporate, large, china, natural, rates, yield, agriculture, commodities, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=96, 7d-median=97, 14d-median=102; carrying terms: cbmiqkfvx, republic, google, services, sanctions, administration, designations, council, issuance, research, color, technologies
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, httperror, unauthorized, quantitative, https, client, quiver, error, congresstrading
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, supreme, international, court, blanche, company, trade, connecticut, secretary, appeals, solar, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, accno, reporting, holdings, filer, financial, trust, finance, america, jpmorgan, chase
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, raised, warner, james, house, cortez, congress, jonathan, cooper, jackson, disbursements
- gdelt_regions: today=0, 7d-median=3, 14d-median=3
- gdelt_gkg: today=27, 7d-median=38, 14d-median=38; carrying terms: english, sanctions, themes, spanish, chinese, keywords, trump, russia, french, romanian, turkish, perimeter
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: kingdom, belgium, position, france, germany, canada, eagle, samuidf
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: epidemic, representing, brings, republic, outbreak, increases, generation, hospital, mongbwalu, global, identified, september
- cisa_kev: today=14, 7d-median=18, 14d-median=17; carrying terms: server, secure, product, authentication, software, injection, vendor, edition, command, vulnerability, remediation, request
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: impact, nigeria, australia, speed, guinea, maximum, magnitude, earthquake, cyclone, botswana, green, forest
- usgs_quakes: today=11, 7d-median=11, 14d-median=17; carrying terms: depth, japan, islands, vanuatu, philippines, region, south, alaska, papua, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, election, october, presidential, senate, republican, benjamin, minister, masters, netanyahu
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, economist, marginal, https, class, conversable, world, being, activity, marginalrevolution, economists, thoughts
- tech_news: today=61, 7d-median=60, 14d-median=57; carrying terms: weekly, company, investigation, computer, today, provides, computerweekly, software, agents, going, newsletter, state
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: mullin, commerce, philadelphia, keating, schmidt, guest, veasey, summer, blanche, hickenlooper, yakym, williams
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, either, markets, placement, evidence, claude, unavailable, paper, sufficient, consensus, identify, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Results of the ECB Survey of Professional Forecasters for the fourth quarter of 2026
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*