# WORLDSCOPE morning brief — 2026-06-09

## Headline
2904 new items across 24 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (625) · International News + Multilateral Institutions (610) · World leaders & government officials (324) · State-Level News (302) · Chinese Internal News (218) · Local News: St. Louis + Atlanta (203) · U.S. Weather + Severe / Climate Outlooks (177) · State Legislative Action (104) · Ukraine Theater (total-war monitoring) (58) · Ukrainian Internal News (national + local Kyiv) (56) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 625 new of 880 total
  - (2026-06-09) В Афганистане госслужащим запретили пользоваться смартфонами | LEDE: Верховный лидер Афганистана и глава «Талибана» мулла Хайбатулла Ахундзада издали указ, запрещающий членам группировки и г] (ru: В А…
      Верховный лидер Афганистана и глава «Талибана» мулла Хайбатулла Ахундзада издали указ, запрещающий членам группировки и госслужащим пользовался смартфонами. Об этом сообщает издание Afghanistan International, в распоряже…
  - (2026-06-09) Компания OpenAI подала заявку на IPO | LEDE: Компания OpenAI, создатель чат-бота ChatGPT, подала заявку на первичное размещение ценных бумаг (IPO). Заявка была подана конфиденциально, объяви] (ru: Ком…
      Компания OpenAI, создатель чат-бота ChatGPT, подала заявку на первичное размещение ценных бумаг (IPO). Заявка была подана конфиденциально, объявила компания во вторник, 9 июня, не став раскрывать какие-либо подробности.
  - (2026-06-09) Американский суд признал незаконным сбор в 100 тысяч долларов за визы высококвалифицированным специалистам, введенный Трампом | LEDE: Сбор в 100 тысяч долларов за визы категории H-1B для выс] (ru: Аме…
      Сбор в 100 тысяч долларов за визы категории H-1B для высококвалифицированных иностранных специалистов, введенный президентом США Дональдом Трампом, противоречит закону. К такому выводу, сообщает Reuters, пришел федеральн…
  - (2026-06-09) Жители Краснодарского края пожаловались на перебои с бензином. Власти объяснили это «искусственным ажиотажем» | LEDE: Жители Краснодарского края начали сообщать о перебоях с топливом на авто] (ru: Жит…
      Жители Краснодарского края начали сообщать о перебоях с топливом на автозаправках. На публикации в местных телеграм-каналах обратила внимание «Говорит НеМосква».
  - (2026-06-09) Украинские военные вновь нанесли удар по Чонгарскому мосту, ведущему в Крым | LEDE: Украинские дроны в ночь на 9 июня атаковали Чонгарский мост, связывающий аннексированный Крым с Херсонской] (ru: Укр…
      Украинские дроны в ночь на 9 июня атаковали Чонгарский мост, связывающий аннексированный Крым с Херсонской областью. Мост поврежден, движение по нему временно закрыто, сообщил назначенный Россией глава оккупированной час…
  - (2026-06-09) В Балашихе взорвали автомобиль. Погиб водитель | LEDE: В подмосковной Балашихе взорвался автомобиль BMW, его водитель погиб, сообщили в Следственном комитете. ] (ru: В Балашихе взорвали автомобиль. По…
      В подмосковной Балашихе взорвался автомобиль BMW, его водитель погиб, сообщили в Следственном комитете.

### International News + Multilateral Institutions — 610 new of 843 total
  - (2026-06-09) [Global] Netanyahu comes out of Iran flare-up a 'humiliated, failed war leader'
      Iran and Israel said hostilities between the two countries were to be put on hold, after a flare-up which threatened the already fragile ceasefire in the region. In Israel, the country was put on hold following strikes f…
  - (2026-06-09) [Global] French singer Bruel held in police custody on sexual assault allegations
      French singer and actor Patrick Bruel will be held in police custody until Wednesday as investigators questioned him over allegations of sexual assault and rape involving at least a dozen women, prosecutors said, adding…
  - (2026-06-09) [Global] Left-winger beats Republican to advance to LA mayor runoff: media
      Left-wing candidate Nithya Raman will face incumbent Karen Bass in the Los Angeles mayor's runoff in November, knocking the Republican candidate backed by President Donald Trump out of the race, US media projected.
  - (2026-06-09) [Global] OpenAI submits confidential filing for market launch with US authorities
      The maker of ChatGPT, OpenAI, has kicked off the process of selling its shares on public markets by submitting a confidential filing with the US Securities and Exchange Commission on Monday. The AI startup is looking to…
  - (2026-06-09) [Global] Beijing condemns US move to blacklist Chinese companies
      China said Tuesday that it “firmly opposed” the US decision to blacklist major Chinese companies including Alibaba and Baidu, after Washington accused them of aiding the Chinese military. Beijing warned against what it c…
  - (2026-06-09) [Global] 'Entire system is broken': Lyhanna's death reveals 'systemic failures' in France's judicial system
      François Picard is pleased to welcome Solène Podevin-Favre, President of the "Face à l'inceste" advocacy and support group and a former co-director of the Ciivise, an independent commission set up in 2021 to come up with…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 302 new of 443 total
  - (2026-06-08) [California] Why Bay Area tech layoffs aren’t raising recession fears — yet
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/01/032223_Meta-Facebook_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-06-08) [California] California wants to change how it funds senior services. That could mean fewer meals for LA’s elderly
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/101625_Senior-EBT_BANG_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-06-08) [California] California wants to cap business tax credits, alarming life sciences and tech industries
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060426-Biotech-Lab-KCA-Getty-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-06-08) [Alabama] Governor Ivey Invites Alabamians to Cast a Line on Free Fishing Day
      MONTGOMERY – Governor Kay Ivey on Monday announced that on Saturday, June 13, 2026, Alabamians and out-of-state visitors alike will have the opportunity to fish for free in most public waters, including both freshwater a…
  - (2026-06-08) [California] Governor Newsom issues proclamation declaring California’s 2026 general election
      Source
  - (2026-06-08) [California] California leads the nation in job creation
      Source

### Chinese Internal News — 218 new of 246 total
  - (2026-06-08) Cover Story: China Restarts Stalled Property Megaproject in State-Led Takeover - Caixin Global
      Cover Story: China Restarts Stalled Property Megaproject in State-Led Takeover Caixin Global
  - (2026-06-08) 财经早知道｜习近平就发展中朝关系提出4点意见 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9qdVI3aGdWdUJrZ0o1ckZoQWxCQ3VIV0MyZ1NOSW1VQ3M1VGZYRVR5M0wzQ0d3d0JWcHhQa00tZjA3ci1EaXNpd3JuVDBMMkR] (zh:…
      财经早知道｜习近平就发展中朝关系提出4点意见 财新
  - (2026-06-08) 油价上涨侵蚀利润 国际航协下调全球航空业盈利预期 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFA3VkhPR2xINXlBQkE2dUNnRjZUM3dieWM3LVh4bWwzUTRySTZ1QVdoTFpSMHp6VHRmckV6bHY4a0xsSmswVXdXYmcwaENxT] (zh:…
      油价上涨侵蚀利润 国际航协下调全球航空业盈利预期 财新
  - (2026-06-08) 监管提示叠加外盘寒流 A股科技股遭遇“黑色星期一” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1OLW9PV0ExajlHTndXQThtTmtjY3puM1doRDA0aWFYRVFNUFhUZkM3UHQ1Y21uUlBYVHZxWVhPMEdNWTFLVkEzdlR5SlU2] (zh:…
      监管提示叠加外盘寒流 A股科技股遭遇“黑色星期一” 财新
  - (2026-06-08) 亚美尼亚总理赢得连任 或推动该国进一步接近欧盟 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBUX3dXVDJBTnd6ckxVem9ldnlsRnJNR2xqUGdPLW1vY2hDZnRacUlXWk9lSk84ZGgyUXc0M1dzemxXMG9aa3NEbjdmcHlHSU] (zh:…
      亚美尼亚总理赢得连任 或推动该国进一步接近欧盟 财新
  - (2026-06-08) 伊朗袭击以色列引爆新一轮冲突 美伊以停火协议岌岌可危 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBSZnFfU1YzX25IajFCZG04c0c0SGdNaHloTWVGZGV6VTZxai1MZ2FJMGtDbEdlV0NNUFJSdzBXNVA3SWVBYUtmdXE1NXI] (zh:…
      伊朗袭击以色列引爆新一轮冲突 美伊以停火协议岌岌可危 财新

### Local News: St. Louis + Atlanta — 203 new of 216 total
  - (2026-06-09) [St. Louis] Festus City Council blocks recall election amid data center dispute
      Festus leaders rejected recall election measures tied to the data center debate, despite certified petitions, leaving opponents pursuing a "Plan B."
  - (2026-06-09) [St. Louis] Donald Trump booed by the crowd during the anthem prior to Game 3 of the NBA Finals
      Donald Trump's attendance at Game 3 of the NBA Finals sparked boos and heightened security that disrupted fans' plans at Madison Square Garden on Monday.
  - (2026-06-09) [St. Louis] FBI testimony alleges Florida teen tried to destroy evidence after killing stepsister on cruise ship
      A teenager charged with killing his stepsister on a cruise now faces charges in adult court, and a possible life sentence if found guilty.
  - (2026-06-09) [St. Louis] Baby ejected from car after Arkansas police pursuit ends in crash
      Three more children, all under 6 years old, were in the car when it crashed.
  - (2026-06-09) [St. Louis] Community to weigh gun violence solutions at town hall following teen's death
      State Sen. Angela Mosley to co-host town hall aimed at combating gun violence, days after 16 year old was shot and killed in north St. Louis store.
  - (2026-06-09) [St. Louis] Two of the brightest planets in the night sky are about to nearly touch
      Even though they're millions of miles apart in space, Jupiter and Venus will appear stacked side by side in the night sky this week.

### U.S. Weather + Severe / Climate Outlooks — 177 new of 181 total
  - (2026-06-09) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-09) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 9 at 3:15AM MDT until June 9 at 4:00AM MDT by NWS Denver CO
      SVRBOU The National Weather Service in Denver has issued a * Severe Thunderstorm Warning for... Northwestern Logan County in northeastern Colorado... Northeastern Weld County in northeastern Colorado... * Until 400 AM MD…
  - (2026-06-09) [Moderate] Special Weather Statement: Special Weather Statement issued June 9 at 3:14AM MDT by NWS Cheyenne WY
      At 314 AM MDT, Doppler radar was tracking a strong thunderstorm near Brownson, or 11 miles west of Sidney, moving northeast at 40 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated. IMPACT…
  - (2026-06-09) [Moderate] Wind Advisory: Wind Advisory issued June 9 at 2:10AM PDT until June 9 at 11:00PM PDT by NWS Pendleton OR
      * WHAT...West winds 25 to 35 mph with gusts up to 50 mph. * WHERE...Eastern Columbia River Gorge of Oregon and Washington, Lower Columbia Basin of Oregon, Foothills of the Southern Blue Mountains of Oregon, and Simcoe Hi…
  - (2026-06-09) [Moderate] Wind Advisory: Wind Advisory issued June 9 at 2:10AM PDT until June 9 at 5:00PM PDT by NWS Pendleton OR
      * WHAT...West winds 20 to 30 mph with gusts up to 50 mph. * WHERE...North Central Oregon. * WHEN...Until 5 PM PDT this afternoon. * IMPACTS...Gusty winds will blow around unsecured objects. Tree limbs could be blown down…
  - (2026-06-09) [Moderate] Wind Advisory: Wind Advisory issued June 9 at 2:10AM PDT until June 9 at 11:00PM PDT by NWS Pendleton OR
      * WHAT...Southwest winds 20 to 30 mph with gusts up to 50 mph expected. * WHERE...Foothills of the Northern Blue Mountains of Oregon. * WHEN...Until 11 PM PDT this evening. * IMPACTS...Gusty winds will blow around unsecu…

### State Legislative Action — 104 new of 115 total
  - (2026-06-09) [Alaska HB 117] An Act relating to electronic monitoring of fishing vessels using trawl gear in a finfish fishery; relating to administrative areas for regulation of certain commercial set net entry p…
      An Act relating to electronic monitoring of fishing vessels using trawl gear in a finfish fishery; relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effecti…
  - (2026-06-09) [Alaska SB 64] An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating t…
      An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating to write-in candidates for President…
  - (2026-06-09) [Alaska HB 11] An Act relating to contributions and donations from permanent fund dividends.
      An Act relating to contributions and donations from permanent fund dividends.
  - (2026-06-09) [Alaska HB 24] An Act relating to aggravating factors considered at sentencing.
      An Act relating to aggravating factors considered at sentencing.
  - (2026-06-09) [Alaska HB 43] An Act relating to elections; relating to voters; relating to the crime of unlawful interference with voting; and providing for an effective date.
      An Act relating to elections; relating to voters; relating to the crime of unlawful interference with voting; and providing for an effective date.
  - (2026-06-09) [Alaska HB 173] An Act relating to occupational therapist licensure; relating to occupational therapy assistant licensure; relating to an occupational therapist licensure compact; relating to an execu…
      An Act relating to occupational therapist licensure; relating to occupational therapy assistant licensure; relating to an occupational therapist licensure compact; relating to an executive administrator for the State Phy…

### Ukraine Theater (total-war monitoring) — 58 new of 243 total
  - (2026-06-09) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-07) [Liveuamap] At Pokrovsk direction clashes yesterday near Toretske, Sofiyivka, Kucheriv Yar, Bilytske, Matyasheve, Vasylivka, Dorozhne, Vilne, Novyi Donbas, Zapovidne, Novooleksandrivka, Rodynske, Shev…
      At Pokrovsk direction clashes yesterday near Toretske, Sofiyivka, Kucheriv Yar, Bilytske, Matyasheve, Vasylivka, Dorozhne
  - (2026-06-09) [Liveuamap] Israeli radio: The air force continues raids deep inside Iran, and the attacks included Shiraz airport in southern Iran. - iran.liveuamap.com
      Israeli radio: The air force continues raids deep inside Iran, and the attacks included Shiraz airport in southern Iran.<
  - (2026-06-08) [Liveuamap] Russian Ministry of Defense claims full occupation of Khimik town in Donetsk region of Ukraine - Liveuamap
      Russian Ministry of Defense claims full occupation of Khimik town in Donetsk region of Ukraine <font color="#6f6
  - (2026-06-08) [Liveuamap] 3 wounded as result of Russian strikes in Odesa - Liveuamap
      3 wounded as result of Russian strikes in Odesa Liveuamap
  - (2026-06-07) [Liveuamap] Missiles fired at northern Israel from Iran North District, Israel - iran.liveuamap.com
      Missiles fired at northern Israel from Iran North District, Israel iran.liveuamap.com

### Ukrainian Internal News (national + local Kyiv) — 56 new of 110 total
  - (2026-06-09) У центрі Херсона комунальник підірвався на російській міні | LEDE: У центральній частині Херсона 67-річний працівник комунального підприємства підірвався на російській міні. Чоловік дістав тяжк] (uk:…
      У центральній частині Херсона 67-річний працівник комунального підприємства підірвався на російській міні. Чоловік дістав тяжкі поранення, зокрема втратив стопу.
  - (2026-06-09) Ідентифікували десять росіян, які влаштовували дронове "сафарі" на жителів Херсонщини | LEDE: Контррозвідка Служби безпеки України зібрала доказову базу на десятьох росіян, які прицільно викори] (uk:…
      Контррозвідка Служби безпеки України зібрала доказову базу на десятьох росіян, які прицільно використовують ударні дрони проти цивільних мешканців Херсона: прокуратура заочно повідомила їм про підозру в порушенні законів…
  - (2026-06-09) Окупація ЧАЕС: як російським військовим допомагали спеціалісти-атомники | LEDE: ] (uk: Окупація ЧАЕС: як російським військовим допомагали спеціалісти-атомники)
  - (2026-06-09) Зеленський прибув з візитом до Естонії | LEDE: Президент Володимир Зеленський з дружиною прибув з візитом до Естонії і вже зустрівся з прем'єр-міністром Фінляндії Петтері Орпо.] (uk: Зеленський прибув…
      Президент Володимир Зеленський з дружиною прибув з візитом до Естонії і вже зустрівся з прем'єр-міністром Фінляндії Петтері Орпо.
  - (2026-06-09) Прикордонники виявили тіло людини за 3,5 кілометра від Румунії | LEDE: Під час патрулювання українсько-румунської ділянки державного кордону, наряд відділу ДПСУ "Ділове" Мукачівського прикордон] (uk:…
      Під час патрулювання українсько-румунської ділянки державного кордону, наряд відділу ДПСУ "Ділове" Мукачівського прикордонного загону виявив тіло невідомого чоловіка.
  - (2026-06-09) Під Москвою у військовому районі підірвали авто: водій загинув | LEDE: Вранці 9 червня в місті Балашиха, що межує з російською столицею Москвою, вибухнув автомобіль BMW X3, водій загинув на міс] (uk:…
      Вранці 9 червня в місті Балашиха, що межує з російською столицею Москвою, вибухнув автомобіль BMW X3, водій загинув на місці.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-06-09) [Israel-Iran-Hezbollah axis · keywords] Israel tells Lebanese city residents to leave , day after Iran called for attacks to stop
      bbc.com · English · tone NA
  - (2026-06-09) [Israel-Iran-Hezbollah axis · keywords] US helicopter crashes near Strait of Hormuz
      wyff4.com · English · tone NA
  - (2026-06-09) [Israel-Iran-Hezbollah axis · keywords] Trump predicts US will achieve
      heraldglobe.com · English · tone NA
  - (2026-06-09) [Israel-Iran-Hezbollah axis · keywords] Trump says pilots are fine after U . S . chopper goes down in Strait of Hormuz – NBC 5 Dallas - Fort Worth
      nbcdfw.com · English · tone NA
  - (2026-06-09) [Israel-Iran-Hezbollah axis · keywords] Trump Says He In Control Of The Iran War . Gavin Newsom Points To $4 Gas Prices : Clearly That Not T
      benzinga.com · English · tone NA
  - (2026-06-09) [Israel-Iran-Hezbollah axis · keywords] Iran war day 102 : Trump warns Israel against new strikes as ceasefire holds - Dominican Republic Post – Caribbean News , Business , Travel & Culture
      dominicanrepublicpost.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-09) [Absci Corp] Form 4 (Issuer)
      filed 2026-06-09 01:59 UTC · role: Issuer — Filed: 2026-06-08 AccNo: 0001470831-26-000526 Size: 7 KB
  - (2026-06-09) [Szela Mary T] Form 4 (Reporting)
      filed 2026-06-09 01:59 UTC · role: Reporting — Filed: 2026-06-08 AccNo: 0001470831-26-000526 Size: 7 KB
  - (2026-06-09) [Boessen Douglas G.] Form 4 (Reporting)
      filed 2026-06-09 01:55 UTC · role: Reporting — Filed: 2026-06-08 AccNo: 0001193125-26-262730 Size: 11 KB
  - (2026-06-09) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-06-09 01:55 UTC · role: Issuer — Filed: 2026-06-08 AccNo: 0001193125-26-262730 Size: 11 KB
  - (2026-06-09) [FICHTHORN JOHN] Form 4 (Reporting)
      filed 2026-06-09 01:54 UTC · role: Reporting — Filed: 2026-06-08 AccNo: 0001628280-26-041759 Size: 15 KB
  - (2026-06-09) [QUANTUM CORP /DE/] Form 4 (Issuer)
      filed 2026-06-09 01:54 UTC · role: Issuer — Filed: 2026-06-08 AccNo: 0001628280-26-041759 Size: 15 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 23 new of 131 total
  - (2026-06-09) [Polymarket] Will Elon Musk post 500+ tweets from June 9 to June 16, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from June 9 12:00 PM ET to June 16, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and rep…
  - (2026-06-09) [Polymarket] Florentino Perez out as Real Madrid president by December 31, 2026?
      This market will resolve to “Yes” if Florentino Perez ceases to be the President of Real Madrid for any length of time by December 31, 11:59 PM ET. Otherwise, this market will resolve to “No”. An announcement of Florenti…
  - (2026-06-09) [Polymarket] Will Yoaz Hendel be the next Prime Minister of Israel?
      Legislative elections are schedule to be held in Israel on October 27, 2026. This market will resolve to the next individual who is officially appointed and sworn in as Prime Minister of Israel following the 2026 parliam…
  - (2026-06-09) [Polymarket] Will Elon Musk post 160-179 tweets from June 5 to June 12, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from June 5 12:00 PM ET to June 12, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and rep…
  - (2026-06-09) [Polymarket] Will Avigdor Lieberman be the next Prime Minister of Israel?
      Legislative elections are schedule to be held in Israel on October 27, 2026. This market will resolve to the next individual who is officially appointed and sworn in as Prime Minister of Israel following the 2026 parliam…
  - (2026-06-09) [Polymarket] Will Ethereum dip to $1,300 in June?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for ETH/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa…

### USGS earthquakes (M4.5+, past day) — 18 new of 20 total
  - (2026-06-08) M 6.1 - 104 km WNW of Mantua, Cuba
      M6.1 · 104 km WNW of Mantua, Cuba · depth 26 km
  - (2026-06-08) M 5.5 - southern Mid-Atlantic Ridge
      M5.5 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-06-08) M 5.4 - southern Mid-Atlantic Ridge
      M5.4 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-06-08) M 5.4 - 197 km SSE of Isangel, Vanuatu
      M5.4 · 197 km SSE of Isangel, Vanuatu · depth 59.614 km
  - (2026-06-08) M 5.3 - 19 km SSW of Lumatil, Philippines
      M5.3 · 19 km SSW of Lumatil, Philippines · depth 45.995 km
  - (2026-06-09) M 5.2 - 21 km SW of Sarangani, Philippines
      M5.2 · 21 km SW of Sarangani, Philippines · depth 82.366 km

### U.S. Federal Action — 17 new of 20 total
  - (2026-06-09) Airworthiness Directives; Airbus Helicopters
      The FAA is superseding Airworthiness Directive (AD) 2025-06-04 for all Airbus Helicopters Model AS350B, AS350B1, AS350B2, AS350B3, AS350BA, AS350D, AS355E, AS355F, AS355F1, AS355F2, AS355N, AS355NP, EC130B4, and EC130T2…
  - (2026-06-09) Preemption-Federal Credit Union Non-Interest Charges and Fees
      The NCUA Board is adopting an interim final rule to clarify federal credit unions' (FCUs) power to charge non-interest charges and fees includes the power to assess, collect, impose, levy, receive, reserve, take, or othe…
  - (2026-06-09) Exemptions To Permit Circumvention of Access Controls on Copyrighted Works
      The United States Copyright Office is initiating the tenth triennial rulemaking proceeding under the Digital Millennium Copyright Act ("DMCA") to determine whether to recommend temporary exemptions to the DMCA's prohibit…
  - (2026-06-09) Request for Information on Modified Organisms Subject to the Plant Protection Act
      On May 15, 2026, the U.S. Department of Agriculture (USDA) published in the Federal Register (91 FR 27868) a Request for Information (RFI) on "Modified Organisms Subject to the Plant Protection Act," to solicit the publi…
  - (2026-06-09) Reducing Bureaucracy and Burden for Community Services Programs
      This Final Rule amends the Block Grants regulations, the Individual Development Account Reserve Funds Established Pursuant to Grants for Assets for Independence regulations, and the Emergency Community Services Homeless…
  - (2026-06-09) Employment and Training Services for Noncustodial Parents in the Child Support Program; Rescission
      The Office of Child Support Enforcement proposes to rescind the Employment and Training Services for Noncustodial Parents in the Child Support Program final rule, published in the Federal Register on December 13, 2024. T…

### Court opinions of consequence (federal & state) — 15 new of 60 total
  - (2026-06-08) U.S. Court of Appeals, 6th Cir.: Leke Dodaj v. Todd Blanche
  - (2026-06-08) U.S. Court of Appeals, 6th Cir.: Vivy Voutsiotis v. PNC Bank, NA
  - (2026-06-08) Delaware Supreme Court: Clark v. State
  - (2026-06-08) Delaware Supreme Court: Rooten, Allice v. Department of Family Services for Children, Youth, and their Families (DSCYF) TPR
  - (2026-06-08) U.S. Court of Appeals, 10th Cir.: Jefferson v. Moore
  - (2026-06-08) U.S. Court of Appeals, 10th Cir.: New Mexico Trappers Association v. Torrez

### Government Action: Sanctions + Procurement + Foreign Agents — 10 new of 104 total
  - (2026-06-09) [USASpending] $563,847,462 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-06-09) [USASpending] $523,182,823 → HANFORD LABORATORY MANAGEMENT AND INTEGRATION LLC: SERVICES DESCRIBED IN SECTION C.2 TO OPERATE AND MAINTAIN TH
      Agency: Department of Energy. Description: SERVICES DESCRIBED IN SECTION C.2 TO OPERATE AND MAINTAIN THE 222-S LABORATORY COMPLEX.
  - (2026-06-09) [USASpending] $512,902,613 → VERTEX AEROSPACE LLC: WARFIGHTER TRAINING READINESS SOLUTIONS W-TRS
      Agency: General Services Administration. Description: WARFIGHTER TRAINING READINESS SOLUTIONS W-TRS
  - (2026-06-09) [USASpending] $499,952,028 → PERATON ENTERPRISE SOLUTIONS LLC: IGF::OT::IGF: FEDERAL STUDENT AID'S VIRTUAL DATA CENTER, PRO
      Agency: Department of Education. Description: IGF::OT::IGF: FEDERAL STUDENT AID'S VIRTUAL DATA CENTER, PROVIDING CENTRALIZED HOSTING AND MANAGEMENT OF ELECTRONIC DATA AND COMPUTER APPLICATIONS, AND RELATED SERVICES TO SU…
  - (2026-06-09) [USASpending] $482,314,982 → BAE SYSTEMS SPACE & MISSION SYSTEMS INC.: ENGINEERING SERVICES AND DEVELOPMENT LEADING TO THE DELIVERY
      Agency: National Aeronautics and Space Administration. Description: ENGINEERING SERVICES AND DEVELOPMENT LEADING TO THE DELIVERY OF THE OMPS PROTOFLIGHT MODEL AND SUPPORT.
  - (2026-06-09) [USASpending] $454,338,460 → SCIENCE SYSTEMS AND APPLICATIONS, INC.: THE PURPOSE OF THIS CONTRACT IS TO ACQUIRE SCIENTIFIC RESEAR
      Agency: National Aeronautics and Space Administration. Description: THE PURPOSE OF THIS CONTRACT IS TO ACQUIRE SCIENTIFIC RESEARCH SERVICES THAT CONCEIVES, DEVELOPS AND APPLIES SPACE, FIELD-DEPLOYED (I.E. AIRBORNE AND IN…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-06-09) MOVER ▲ Elon Musk — $801.64B (+$12.87B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-06-09) MOVER ▲ Michael Dell — $229.22B (+$3.88B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-06-09) MOVER ▼ Larry Page — $296.68B ($-3.66B since yesterday)
      United States · Technology · source: Google
  - (2026-06-09) MOVER ▼ Sergey Brin — $273.64B ($-3.37B since yesterday)
      United States · Technology · source: Google
  - (2026-06-09) MOVER ▲ Thomas Peterffy — $100.53B (+$3.21B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-06-09) MOVER ▲ Jensen Huang — $180.31B (+$3.01B since yesterday)
      United States · Technology · source: Semiconductors

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-06-09) Will Bosnia-Herzegovina win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,197,615 · resolves 2026-07-20
  - (2026-06-09) US x Iran permanent peace deal by December 31, 2026?
      yes price: 68% · 24h volume: $2,078,097 · resolves 2026-12-31
  - (2026-06-09) Will USA win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,979,628 · resolves 2026-07-20
  - (2026-06-09) Will Carlos Álvarez win the 2026 Peruvian presidential election?
      yes price: 0% · 24h volume: $1,779,075 · resolves 2026-04-12
  - (2026-06-09) Will South Korea win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,669,864 · resolves 2026-07-20
  - (2026-06-09) Will Argentina win the 2026 FIFA World Cup?
      yes price: 8% · 24h volume: $1,642,390 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-06-09) [Marginal Revolution] Séb Krier
      I really loved this article. A one-time increase in per capita growth from 2% to 2.1% for a single year, then dropping back to 2%, would permanently raises the level of GDP per capita – and because that small gain recurs…
  - (2026-06-09) [Marginal Revolution] Sao Paulo notes
      The old saw “Brazil is the country of the future, and always will be” now seems so wrong. The place feels increasingly conservative, and it is aging rapidly. In the domestic airport you see couples with only a single kid…
  - (2026-06-08) [Marginal Revolution] Monday assorted links
      1. It seems Piketty has become a degrowther. And other views. Maybe it is rude to say this, but some of our best-known economists basically have a negative-valued understanding of how the world works. And a bit more. 2.…
  - (2026-06-08) [Conversable Economist] Chair Jerome Powell: An Early Retrospective
      Jerome Powell was Chair of the Federal Reserve from February 2018 to May 2026. Of course, the Fed Chair does not have dictatorial power over setting monetary policy: instead, such policy is set by a vote of the 12-member…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 12 total
  - (2026-06-08) CVE-2026-42271 · BerriAI LiteLLM: BerriAI LiteLLM Command Injection Vulnerability
      vendor: BerriAI · product: LiteLLM · CISA remediation by 2026-06-22
  - (2026-06-08) CVE-2026-50751 · Check Point Security Gateway: Check Point Security Gateway Improper Authentication Vulnerability
      vendor: Check Point · product: Security Gateway · CISA remediation by 2026-06-11

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-06-08) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with increasing case numbers, geographic spread, and cross-border transmission to Uganda. As of 6 June, a t…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-09) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=27; carrying terms: coast, authorized, rulemaking, proposed, certain, safety, persons, captain, action, guard, address, waters
- state_bills: today=115, 7d-median=128, 14d-median=140; carrying terms: programs, employer, calculating, purchase, requiring, unless, health, service, development, evaluation, because, administration
- state_news: today=443, 7d-median=651, 14d-median=673; carrying terms: almost, market, election, legislators, fight, partisan, month, april, coverage, tried, development, toomanyredirects
- local_news: today=216, 7d-median=216, 14d-median=234; carrying terms: region, investigators, missouri, month, health, charged, trump, major, according, dining, google, plans
- foreign_news: today=843, 7d-median=847, 14d-median=854; carrying terms: construction, almost, timed, attend, focus, teacher, targets, canada, trips, kills, market, activity
- chinese_internal: today=246, 7d-median=268, 14d-median=270; carrying terms: lxtfa, politics, cbmiykfvx, google, target, china, cbmiw, title, cbmib, cbmiyefvx, cbmixkfvx, cbmizkfvx
- russian_internal: today=880, 7d-median=1014, 14d-median=989; carrying terms: bloomberg, russian, gazeta, financial, telegram, found, reuters, title, roland, istories, europe, forbidden
- ukrainian_internal: today=110, 7d-median=119, 14d-median=122; carrying terms: hmarochos, economic, babel, kyivindependent, independent, title, found, vechirniy, ukrinform, https, error, httperror
- ukraine_theater: today=243, 7d-median=318, 14d-median=313; carrying terms: uljyynrwyxuzbffblvrb, targets, krtfpnhrqzxfsvthxqli, rujpwthxdthzri, jfmmzjbzhidneyb, hnctzssestx, qrljnse, jbywrvak, authorized, stjmefvjaefednrfrwvrbwzwujn, collection, rzngrkfvtuzlmmyywhljqvhxu
- paper_bets: today=131, 7d-median=140, 14d-median=141; carrying terms: officially, pennsylvania, market, season, polymarket, election, virginia, models, resolve, presidential, march, previousl
- weather: today=181, 7d-median=173, 14d-median=128; carrying terms: miles, details, along, region, magnitude, tonight, hurricane, areas, locations, flooding, result, weekend
- macro: today=21, 7d-median=21, 14d-median=10; carrying terms: unrate, rates, indicator, funds, effective, unemployment, spread, recession, labor, treasury, latest, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, range, agriculture, proxy, corporate, silver, rates, close, yield, nasdaq, natural, crypto
- markets_global: today=47, 7d-median=47, 14d-median=79; carrying terms: price, crypto
- sanctions_procurement: today=104, 7d-median=111, 14d-median=106; carrying terms: undermining, actions, acronym, russian, tunisia, campaign, description, hybrid, african, aggression, region, burma
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, client, error, quiverquant, httperror, https, unauthorized, quantitative, quiver
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: euronext, alice, bloomberg, ortega, japan, walton, tokyo, peterffy, gcarsoa, brokerage, carlos, london
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, collins, appeals, court, company, connecticut, supreme, state, jonathan, schulz, people, society
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, group, trust, michael, william, technology
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, cortez, joseph, ocasio, cooper, disbursements, alexandria, brown, warner, senate, robert, james
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=50, 7d-median=75, 14d-median=25; carrying terms: english, china, chinese, lebanon, yahoo, israel, trump, taiwan, trade, ukraine, against, keywords
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=30, 14d-median=28; carrying terms: ground, position, belgium, bulgaria, germany, france, kingdom, eagle, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: cases, institut, seven, cumulative, infect, outbreak, press, hantavirus, levels, derived, announcing, divisions
- cisa_kev: today=12, 7d-median=11, 14d-median=15; carrying terms: overflow, vendor, authentication, product, bypass, remediation, vulnerability, console, cpanel, plugin, malicious, embedded
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=127, 14d-median=127; carrying terms: madagascar, angola, islamic, orange, serbia, russia, czech, drought, romania, vietnam, estonia, tajikistan
- usgs_quakes: today=20, 7d-median=19, 14d-median=18; carrying terms: depth, philippines, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: world, volume, resolves, price, peace, permanent, south, korea, turkiye, switzerland, presidential, croatia
- commentary: today=6, 7d-median=5, 14d-median=6; carrying terms: conversable, revolution, marginal, class, https, economist, policy, marginalrevolution, assorted, links, economy, economic
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: amata, madeleine, hinds, maggie, press, vance, monica, darren, kaine, salinas, grace, jerry
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, converges, unavailable, placement, identify, markets, claude, paper, either, market, sufficient, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline
- [2026-06-06] Fed speeches: Barr, Deregulating in a Financial Boom: What Could Go Wrong?
- [2026-06-08] ECB press: ECB announces main milestones for roll-out of Integrated Reporting Framework

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*