# WORLDSCOPE morning brief — 2026-06-09

## Headline
3194 new items across 25 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (695) · International News + Multilateral Institutions (609) · State-Level News (341) · World leaders & government officials (324) · Chinese Internal News (222) · Local News: St. Louis + Atlanta (205) · U.S. Weather + Severe / Climate Outlooks (185) · Ukraine Theater (total-war monitoring) (173) · State Legislative Action (122) · Ukrainian Internal News (national + local Kyiv) (60) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### Russian Internal News (state + in-exile) — 695 new of 946 total
  - (2026-06-09) Путин на фоне снижения рейтингов стал чаще появляться на публике. Но в регионы президент по-прежнему не ездит — по соображениям безопасности | LEDE: Владимир Путин в апреле и мае стал заметн] (ru: Пут…
      Владимир Путин в апреле и мае стал заметно чаще появляться на публике, чем в первые три месяца 2026 года. К такому выводу пришло издание Faridaily, изучив сообщения об участии Путина в мероприятиях, которые публикует пре…
  - (2026-06-09) Россия потеряла один из спутников системы «Рассвет» (ее называют аналогом Starlink) | LEDE: Российская аэрокосмическая компания «Бюро 1440» потеряла один из 16 первых серийных спутников, зап] (ru: Рос…
      Российская аэрокосмическая компания «Бюро 1440» потеряла один из 16 первых серийных спутников, запущенных на орбиту в марте 2026 год. Это, как пишет «Коммерсант», следует из данных сайтов для мониторинга космических аппа…
  - (2026-06-09) Трамп обещает, что США вот-вот, скоро-скоро, уже-уже заключат сделку с Ираном. Сколько раз он это говорил? | LEDE: Впервые Дональд Трамп заговорил о сделке с Тегераном 23 марта 2026 года — к] (ru: Тра…
      Впервые Дональд Трамп заговорил о сделке с Тегераном 23 марта 2026 года — к тому моменту прошел почти месяц с начала войны США и Израиля против Ирана. Президент изо дня в день уверял, что Иран буквально умоляет заключить…
  - (2026-06-09) «Готовых браться за политические дела не становится меньше». Российские адвокаты первыми видят ужасающую картину преследования россиян — но продолжают помогать им даже несмотря на то, что риску] (ru:…
      С 8 по 14 июня в рамках ежегодного проекта «Ты не один» российские независимые СМИ и НКО участвуют в неделе поддержки политзаключенных. В условиях, когда давление на правозащитников усиливается, особенно важно помогать т…
  - (2026-06-09) В Афганистане госслужащим запретили пользоваться смартфонами | LEDE: Верховный лидер Афганистана и глава «Талибана» мулла Хайбатулла Ахундзада издал указ, запрещающий членам группировки и го] (ru: В А…
      Верховный лидер Афганистана и глава «Талибана» мулла Хайбатулла Ахундзада издал указ, запрещающий членам группировки и госслужащим пользоваться смартфонами. Об этом сообщает издание Afghanistan International, в распоряже…
  - (2026-06-09) Компания OpenAI подала заявку на IPO | LEDE: Компания OpenAI, создатель чат-бота ChatGPT, подала заявку на первичное размещение ценных бумаг (IPO). Заявка была подана конфиденциально, объяви] (ru: Ком…
      Компания OpenAI, создатель чат-бота ChatGPT, подала заявку на первичное размещение ценных бумаг (IPO). Заявка была подана конфиденциально, объявила компания во вторник, 9 июня, не став раскрывать какие-либо подробности.

### International News + Multilateral Institutions — 609 new of 831 total
  - (2026-06-08) [Global] Trump tells BBC Netanyahu did not defy him
      In a call with the US president, the BBC’s Sarah Smith asked Trump about the war in Iran and his relationship with the Israeli leader.
  - (2026-06-09) [Global] Israel and Iran flare-up could strengthen Tehran's negotiating hand
      Iran appears emboldened by the outcome and its leaders may sense Trump's appetite for risk is low.
  - (2026-06-09) [Global] Hundreds of aftershocks jolt Philippines as officials say death toll could rise
      Dozens of people are dead and hundreds more injured following an earthquake in the country's south.
  - (2026-06-09) [Global] Trump booed in New York as he becomes first US president to attend NBA Finals
      The catcalls came after ticketholders faced airport-style security to enter the venue at Madison Square Garden.
  - (2026-06-09) [Global] ICC suspends top prosecutor after investigating misconduct allegations
      Karim Khan denies all allegations of sexual misconduct and his lawyers say he rejects the decision in the strongest terms.
  - (2026-06-09) [Global] Man accused of killing mother-in-law with poison-laced satay
      Indonesia police allege the man killed the woman as he felt disrespected by her.

### State-Level News — 341 new of 476 total
  - (2026-06-08) [Alabama] Governor Ivey Invites Alabamians to Cast a Line on Free Fishing Day
      MONTGOMERY – Governor Kay Ivey on Monday announced that on Saturday, June 13, 2026, Alabamians and out-of-state visitors alike will have the opportunity to fish for free in most public waters, including both freshwater a…
  - (2026-06-08) [California] Governor Newsom issues proclamation declaring California’s 2026 general election
      Source
  - (2026-06-08) [California] California leads the nation in job creation
      Source
  - (2026-06-08) [California] Why Bay Area tech layoffs aren’t raising recession fears — yet
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/01/032223_Meta-Facebook_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-06-08) [California] California wants to change how it funds senior services. That could mean fewer meals for LA’s elderly
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/101625_Senior-EBT_BANG_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-06-08) [California] California wants to cap business tax credits, alarming life sciences and tech industries
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060426-Biotech-Lab-KCA-Getty-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 222 new of 248 total
  - (2026-06-09) 责编：汪灵犀 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxNckNnczdybHdqM3lJeXFGLVo3aE82ckNJWnN2RmRFdE52NHRPSVNEdGltcm5BSnpDakIwcUc1Z0luc3EyWnlDY] (zh:…
      责编：汪灵犀 柴逸扉 邮箱：gtbhwb@people.cn 人民日报
  - (2026-06-08) 责编：汪灵犀 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxNXzRZaFBoZFRYUHFVd19iMGRWVU91TlhjRUZuV1BxNUVSTmdKZGRkd284cktVaE9jLW9ZQjVWZDZNUGJSbENwU] (zh:…
      责编：汪灵犀 柴逸扉 邮箱：gtbhwb@people.cn 人民日报
  - (2026-06-09) 习近平夫妇出席金正恩夫妇举行的小范围午宴 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9qc05LR3pyeDNXWFpEOVR5QUxwYXZENVRPSDhCbDQ0RHo4aUlCdXRFbmRqWDQzbjlPNlRJdnYxc2FWU2paVi0zMGdUOTg] (zh:…
      习近平夫妇出席金正恩夫妇举行的小范围午宴 人民网-图片频道
  - (2026-06-09) 习近平和彭丽媛参谒中朝友谊塔 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE5Ed1RfV3ZTY1NqSzNBVFViQWdxS1U1VDlrem1Ob09UMXZwWTQwUWpmeHlLcGNKYldGMlVMMmJOWUtsX0lfYUtMRXRQUktxaFJrV] (zh:…
      习近平和彭丽媛参谒中朝友谊塔 人民网-图片频道
  - (2026-06-09) 伊朗首都国际机场恢复航班运营--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9QYUFFa3JGQ0NiR0VBS1dNTE8wSlhDb1hjWXhjeXZNWGw5bWNjQmRoWmc1RFdBZDVfUXlOcUZtdlAyVDJPRmdOSGZEUzVjU25Jem] (zh:…
      伊朗首都国际机场恢复航班运营--国际 人民网
  - (2026-06-09) 美军在阿曼湾袭击一艘油轮--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE9PQzZtYmc3aWZpNGNVWGo3ZklHR2o5dlNIQktkUmpTYjVNMnFJcXp0U2sySzlfUnRHcG90bXlxWnN0eHZ5enRuemlNUV9FaEFtMWtx] (zh:…
      美军在阿曼湾袭击一艘油轮--国际 人民网

### Local News: St. Louis + Atlanta — 205 new of 218 total
  - (2026-06-09) [St. Louis] Abide in Love marks a year of helping immigrants detained in Missouri
  - (2026-06-09) [St. Louis] Festus City Council rejects recall resolutions for mayor, 3 council members
  - (2026-06-08) [St. Louis] Belleville’s Skyview Drive-In for sale after almost 80 years of family ownership
  - (2026-06-08) [St. Louis] St. Louis Public Schools district employee diagnosed with Legionnaires’ disease
  - (2026-06-08) [St. Louis] Missouri Supreme Court declines to hear case about tax issue on August ballot, just before deadline
  - (2026-06-08) [St. Louis] SLU Billikens, Missouri Tigers to play basketball series at Enterprise Center starting in November

### U.S. Weather + Severe / Climate Outlooks — 185 new of 188 total
  - (2026-06-09) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-09) [Moderate] Heat Advisory: Heat Advisory issued June 9 at 5:21AM CDT until June 10 at 7:00AM CDT by NWS Springfield MO
      * WHAT...Heat index values up to 100 to 105 expected. * WHERE...Portions of southeast Kansas and central, east central, south central, southwest, and west central Missouri. * WHEN...From noon today to 7 AM CDT Wednesday.…
  - (2026-06-09) [Moderate] Heat Advisory: Heat Advisory issued June 9 at 5:19AM CDT until June 9 at 8:00PM CDT by NWS Memphis TN
      * WHAT...Heat index values up to 108 expected. * WHERE...Portions of East Arkansas, North Mississippi, Southeast Missouri, and West Tennessee. * WHEN...From 11 AM this morning to 8 PM CDT this evening. * IMPACTS...Hot te…
  - (2026-06-09) [Severe] Flood Watch: Flood Watch issued June 9 at 5:19AM CDT until June 9 at 7:00PM CDT by NWS Memphis TN
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of West Tennessee, including the following areas, Benton TN, Carroll, Decatur, Henderson, Henry and Weakley. * WHEN...Thr…
  - (2026-06-09) [Severe] Flood Warning: Flood Warning issued June 9 at 5:19AM CDT until June 9 at 4:53PM CDT by NWS Topeka KS
      ...The Flood Warning continues for the following rivers in Kansas... Wildcat Creek at Manhattan Scenic Drive affecting Riley County. * WHAT...Minor flooding is occurring. * WHERE...Wildcat Creek at Manhattan Scenic Drive…
  - (2026-06-09) [Moderate] Lake Wind Advisory: Lake Wind Advisory issued June 9 at 4:12AM MDT until June 9 at 9:00PM MDT by NWS Pocatello ID
      * WHAT...Southwest winds 20 to 25 mph with gusts up to 35 mph expected for American Falls Reservoir. * WHERE...Lower Snake River Plain. * WHEN...From 10 AM this morning to 9 PM MDT this evening. * IMPACTS...Strong winds…

### Ukraine Theater (total-war monitoring) — 173 new of 359 total
  - (2026-06-09) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-08) [FIRMS] thermal anomaly 45.260, 31.678 (FRP 4.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-08 0934Z, FRP 4.5 MW
  - (2026-06-08) [FIRMS] thermal anomaly 46.592, 32.690 (FRP 4.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-08 0934Z, FRP 4.73 MW
  - (2026-06-08) [FIRMS] thermal anomaly 46.079, 30.479 (FRP 3.62 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-08 0934Z, FRP 3.62 MW
  - (2026-06-08) [FIRMS] thermal anomaly 51.097, 34.917 (FRP 1.67 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-08 0934Z, FRP 1.67 MW
  - (2026-06-08) [FIRMS] thermal anomaly 51.138, 34.642 (FRP 1.45 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-08 0934Z, FRP 1.45 MW

### State Legislative Action — 122 new of 127 total
  - (2026-06-09) [Alaska HB 117] An Act relating to electronic monitoring of fishing vessels using trawl gear in a finfish fishery; relating to administrative areas for regulation of certain commercial set net entry p…
      An Act relating to electronic monitoring of fishing vessels using trawl gear in a finfish fishery; relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effecti…
  - (2026-06-09) [Alaska SB 64] An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating t…
      An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating to write-in candidates for President…
  - (2026-06-09) [Alaska HB 11] An Act relating to contributions and donations from permanent fund dividends.
      An Act relating to contributions and donations from permanent fund dividends.
  - (2026-06-09) [Alaska HB 24] An Act relating to aggravating factors considered at sentencing.
      An Act relating to aggravating factors considered at sentencing.
  - (2026-06-09) [Alaska HB 43] An Act relating to elections; relating to voters; relating to the crime of unlawful interference with voting; and providing for an effective date.
      An Act relating to elections; relating to voters; relating to the crime of unlawful interference with voting; and providing for an effective date.
  - (2026-06-09) [Alaska HB 173] An Act relating to occupational therapist licensure; relating to occupational therapy assistant licensure; relating to an occupational therapist licensure compact; relating to an execu…
      An Act relating to occupational therapist licensure; relating to occupational therapy assistant licensure; relating to an occupational therapist licensure compact; relating to an executive administrator for the State Phy…

### Ukrainian Internal News (national + local Kyiv) — 60 new of 112 total
  - (2026-06-09) Зеленський: Очікуємо сильні політичні рішення ЄС цього літа | LEDE: ] (uk: Зеленський: Очікуємо сильні політичні рішення ЄС цього літа)
  - (2026-06-09) Сирський затвердив Концепцію розвитку ракетних військ і артилерії | LEDE: Головнокомандувач Збройних сил Олександр Сирський затвердив Концепцію розвитку ракетних військ і артилерії ЗСУ, яка виз] (uk:…
      Головнокомандувач Збройних сил Олександр Сирський затвердив Концепцію розвитку ракетних військ і артилерії ЗСУ, яка визначає основні напрями розвитку спроможностей цього роду військ на середньострокову перспективу — до 2…
  - (2026-06-09) У ЄС презентують 21-й санкційний пакет проти Росії 9 червня | LEDE: Урсула фон дер Ляєн представить новий пакет санкцій ЄС проти Росії 9 червня у Брюсселі.] (uk: У ЄС презентують 21-й санкційний пакет…
      Урсула фон дер Ляєн представить новий пакет санкцій ЄС проти Росії 9 червня у Брюсселі.
  - (2026-06-09) У центрі Херсона комунальник підірвався на російській міні | LEDE: У центральній частині Херсона 67-річний працівник комунального підприємства підірвався на російській міні. Чоловік дістав тяжк] (uk:…
      У центральній частині Херсона 67-річний працівник комунального підприємства підірвався на російській міні. Чоловік дістав тяжкі поранення, зокрема втратив стопу.
  - (2026-06-09) Ідентифікували десять росіян, які влаштовували дронове "сафарі" на жителів Херсонщини | LEDE: Контррозвідка Служби безпеки України зібрала доказову базу на десятьох росіян, які прицільно викори] (uk:…
      Контррозвідка Служби безпеки України зібрала доказову базу на десятьох росіян, які прицільно використовують ударні дрони проти цивільних мешканців Херсона: прокуратура заочно повідомила їм про підозру в порушенні законів…
  - (2026-06-09) Окупація ЧАЕС: як російським військовим допомагали спеціалісти-атомники | LEDE: ] (uk: Окупація ЧАЕС: як російським військовим допомагали спеціалісти-атомники)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-09) [Qiu Wenbin] Form 4 (Reporting)
      filed 2026-06-09 10:20 UTC · role: Reporting — Filed: 2026-06-09 AccNo: 0001104659-26-071566 Size: 8 KB
  - (2026-06-09) [Baozun Inc.] Form 4 (Issuer)
      filed 2026-06-09 10:20 UTC · role: Issuer — Filed: 2026-06-09 AccNo: 0001104659-26-071566 Size: 8 KB
  - (2026-06-09) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-09 10:13 UTC — Filed: 2026-06-09 AccNo: 0001213900-26-066519 Size: 2 MB
  - (2026-06-09) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-09 10:13 UTC — Filed: 2026-06-09 AccNo: 0001213900-26-066519 Size: 2 MB
  - (2026-06-09) [Jiang Jun Jason] Form 4 (Reporting)
      filed 2026-06-09 10:12 UTC · role: Reporting — Filed: 2026-06-09 AccNo: 0001213900-26-066518 Size: 6 KB
  - (2026-06-09) [Jinxin Technology Holding Co] Form 4 (Issuer)
      filed 2026-06-09 10:12 UTC · role: Issuer — Filed: 2026-06-09 AccNo: 0001213900-26-066518 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-09) [United States] Chippewa Valley Health Cooperative turns focus to fully reopening HSHS St . Joseph Hospital
      domain: leadertelegram.com · language: English · tone:
  - (2026-06-09) [United Kingdom] Clydebank man threatened to go Charles Bronson on police
      domain: clydebankpost.co.uk · language: English · tone:
  - (2026-06-09) [United States] Ann Patchett reveals the love story at the heart of her novel Whistler – The Ukiah Daily Journal
      domain: ukiahdailyjournal.com · language: English · tone:
  - (2026-06-09) [India] Tripura : Justice Arindam Lodh Submits Promotion Reform Recommendations to CM Dr Manik Saha
      domain: northeasttoday.in · language: English · tone:
  - (2026-06-09) [India] Pakistan human rights body condemns violence in PoJK , calls for immediate de - escalation
      domain: aninews.in · language: English · tone:
  - (2026-06-09) [New Zealand] Police are asking the public for vehicle sightings - as they investigate a homicide in the Far North - 09 - Jun - 2026
      domain: home.nzcity.co.nz · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDACS — global disaster alerts — 27 new of 160 total
  - (2026-06-06) [Green] Flood in China
      Flood · Green alert · China · Magnitude 0
  - (2026-06-06) [Green] Flood in China
      Flood · Green alert · China · Magnitude 0
  - (2026-06-06) [Green] Flood in China
      Flood · Green alert · China · Magnitude 0
  - (2026-06-08) [Green] Earthquake in Southern Mid-Atlantic Ridge
      Earthquake · Green alert · Southern Mid-Atlantic Ridge · Magnitude 5.5M, Depth:10km
  - (2026-06-08) [Green] Earthquake in Southern Mid-Atlantic Ridge
      Earthquake · Green alert · Southern Mid-Atlantic Ridge · Magnitude 5.5M, Depth:10km
  - (2026-06-08) [Green] Earthquake in Cuba
      Earthquake · Green alert · Cuba · Magnitude 6.1M, Depth:26km

### Paper Trading Scorecard — 25 new of 133 total
  - (2026-06-09) [Polymarket] Will Elon Musk post 500+ tweets from June 9 to June 16, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from June 9 12:00 PM ET to June 16, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and rep…
  - (2026-06-09) [Polymarket] Florentino Perez out as Real Madrid president by December 31, 2026?
      This market will resolve to “Yes” if Florentino Perez ceases to be the President of Real Madrid for any length of time by December 31, 11:59 PM ET. Otherwise, this market will resolve to “No”. An announcement of Florenti…
  - (2026-06-09) [Polymarket] Will Elon Musk post 160-179 tweets from June 5 to June 12, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from June 5 12:00 PM ET to June 12, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and rep…
  - (2026-06-09) [Polymarket] Will Yoaz Hendel be the next Prime Minister of Israel?
      Legislative elections are schedule to be held in Israel on October 27, 2026. This market will resolve to the next individual who is officially appointed and sworn in as Prime Minister of Israel following the 2026 parliam…
  - (2026-06-09) [Polymarket] Libema Open: Katie Volynets vs Zeynep Sonmez
      This market refers to the tennis match between Katie Volynets and Zeynep Sonmez in the Libema Open, originally scheduled for June 9, 2026 at 4:00AM ET. This market will resolve to 'Katie Volynets' if Katie Volynets advan…
  - (2026-06-09) [Polymarket] Will Avigdor Lieberman be the next Prime Minister of Israel?
      Legislative elections are schedule to be held in Israel on October 27, 2026. This market will resolve to the next individual who is officially appointed and sworn in as Prime Minister of Israel following the 2026 parliam…

### USGS earthquakes (M4.5+, past day) — 21 new of 22 total
  - (2026-06-08) M 6.1 - 104 km WNW of Mantua, Cuba
      M6.1 · 104 km WNW of Mantua, Cuba · depth 26 km
  - (2026-06-08) M 5.5 - southern Mid-Atlantic Ridge
      M5.5 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-06-09) M 5.4 - 21 km SSW of Lumatil, Philippines
      M5.4 · 21 km SSW of Lumatil, Philippines · depth 35 km
  - (2026-06-08) M 5.4 - southern Mid-Atlantic Ridge
      M5.4 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-06-08) M 5.4 - 197 km SSE of Isangel, Vanuatu
      M5.4 · 197 km SSE of Isangel, Vanuatu · depth 59.614 km
  - (2026-06-08) M 5.3 - 19 km SSW of Lumatil, Philippines
      M5.3 · 19 km SSW of Lumatil, Philippines · depth 45.995 km

### Court opinions of consequence (federal & state) — 20 new of 60 total
  - (2026-06-08) U.S. Court of Appeals, 11th Cir.: United States v. Justin Case Lebarron
  - (2026-06-08) U.S. Court of Appeals, 11th Cir.: Woff Senatus v. U.S. Attorney General
  - (2026-06-08) U.S. Court of Appeals, 10th Cir.: Jefferson v. Moore
  - (2026-06-08) U.S. Court of Appeals, 10th Cir.: New Mexico Trappers Association v. Torrez
  - (2026-06-08) U.S. Court of Appeals, 7th Cir.: Salvatore Arcidiacono v. Elizabeth Whitehorn
  - (2026-06-08) U.S. Court of Appeals, 7th Cir.: Vairrun Strickland v. City of Markham

### U.S. Federal Action — 17 new of 20 total
  - (2026-06-09) Airworthiness Directives; Airbus Helicopters
      The FAA is superseding Airworthiness Directive (AD) 2025-06-04 for all Airbus Helicopters Model AS350B, AS350B1, AS350B2, AS350B3, AS350BA, AS350D, AS355E, AS355F, AS355F1, AS355F2, AS355N, AS355NP, EC130B4, and EC130T2…
  - (2026-06-09) Preemption-Federal Credit Union Non-Interest Charges and Fees
      The NCUA Board is adopting an interim final rule to clarify federal credit unions' (FCUs) power to charge non-interest charges and fees includes the power to assess, collect, impose, levy, receive, reserve, take, or othe…
  - (2026-06-09) Exemptions To Permit Circumvention of Access Controls on Copyrighted Works
      The United States Copyright Office is initiating the tenth triennial rulemaking proceeding under the Digital Millennium Copyright Act ("DMCA") to determine whether to recommend temporary exemptions to the DMCA's prohibit…
  - (2026-06-09) Request for Information on Modified Organisms Subject to the Plant Protection Act
      On May 15, 2026, the U.S. Department of Agriculture (USDA) published in the Federal Register (91 FR 27868) a Request for Information (RFI) on "Modified Organisms Subject to the Plant Protection Act," to solicit the publi…
  - (2026-06-09) Reducing Bureaucracy and Burden for Community Services Programs
      This Final Rule amends the Block Grants regulations, the Individual Development Account Reserve Funds Established Pursuant to Grants for Assets for Independence regulations, and the Emergency Community Services Homeless…
  - (2026-06-09) Employment and Training Services for Noncustodial Parents in the Child Support Program; Rescission
      The Office of Child Support Enforcement proposes to rescind the Employment and Training Services for Noncustodial Parents in the Child Support Program final rule, published in the Federal Register on December 13, 2024. T…

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-09) [Japan] Surprise ! Final Fantasy X | X - 2 HD Remaster Is Heading To Switch 2
      nintendolife.com · English
  - (2026-06-09) [Japan] Culdcept Begin Switch 1 & 2 eShop Pre - Orders Open , Includes Early Bird Discount
      nintendolife.com · English
  - (2026-06-09) [Japan] Final fantasy X and X2 announced for switch 2 , - Nintendo Switch 2 Forum
      nintendolife.com · English
  - (2026-06-09) [Japan] Honorable Mention to HIBAKUSHA – WANDERING SOUL
      nuclear-news.net · English
  - (2026-06-09) [Japan] Damsels in Distress - Game
      nintendoworldreport.com · English
  - (2026-06-09) [Japan] Binance eyes Asian stock trading as Bitcoin slumps
      asia.nikkei.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 10 new of 104 total
  - (2026-06-09) [USASpending] $563,847,462 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-06-09) [USASpending] $523,182,823 → HANFORD LABORATORY MANAGEMENT AND INTEGRATION LLC: SERVICES DESCRIBED IN SECTION C.2 TO OPERATE AND MAINTAIN TH
      Agency: Department of Energy. Description: SERVICES DESCRIBED IN SECTION C.2 TO OPERATE AND MAINTAIN THE 222-S LABORATORY COMPLEX.
  - (2026-06-09) [USASpending] $512,902,613 → VERTEX AEROSPACE LLC: WARFIGHTER TRAINING READINESS SOLUTIONS W-TRS
      Agency: General Services Administration. Description: WARFIGHTER TRAINING READINESS SOLUTIONS W-TRS
  - (2026-06-09) [USASpending] $499,952,028 → PERATON ENTERPRISE SOLUTIONS LLC: IGF::OT::IGF: FEDERAL STUDENT AID'S VIRTUAL DATA CENTER, PRO
      Agency: Department of Education. Description: IGF::OT::IGF: FEDERAL STUDENT AID'S VIRTUAL DATA CENTER, PROVIDING CENTRALIZED HOSTING AND MANAGEMENT OF ELECTRONIC DATA AND COMPUTER APPLICATIONS, AND RELATED SERVICES TO SU…
  - (2026-06-09) [USASpending] $482,314,982 → BAE SYSTEMS SPACE & MISSION SYSTEMS INC.: ENGINEERING SERVICES AND DEVELOPMENT LEADING TO THE DELIVERY
      Agency: National Aeronautics and Space Administration. Description: ENGINEERING SERVICES AND DEVELOPMENT LEADING TO THE DELIVERY OF THE OMPS PROTOFLIGHT MODEL AND SUPPORT.
  - (2026-06-09) [USASpending] $454,338,460 → SCIENCE SYSTEMS AND APPLICATIONS, INC.: THE PURPOSE OF THIS CONTRACT IS TO ACQUIRE SCIENTIFIC RESEAR
      Agency: National Aeronautics and Space Administration. Description: THE PURPOSE OF THIS CONTRACT IS TO ACQUIRE SCIENTIFIC RESEARCH SERVICES THAT CONCEIVES, DEVELOPS AND APPLIES SPACE, FIELD-DEPLOYED (I.E. AIRBORNE AND IN…

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-06-09) Will Sweden win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,839,917 · resolves 2026-07-20
  - (2026-06-09) Will Austria win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,551,719 · resolves 2026-07-20
  - (2026-06-09) Will Bosnia-Herzegovina win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,271,088 · resolves 2026-07-20
  - (2026-06-09) US x Iran permanent peace deal by December 31, 2026?
      yes price: 68% · 24h volume: $2,076,971 · resolves 2026-12-31
  - (2026-06-09) Will USA win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,048,444 · resolves 2026-07-20
  - (2026-06-09) Will South Korea win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,840,846 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-06-09) [Marginal Revolution] Séb Krier
      I really loved this article. A one-time increase in per capita growth from 2% to 2.1% for a single year, then dropping back to 2%, would permanently raises the level of GDP per capita – and because that small gain recurs…
  - (2026-06-09) [Marginal Revolution] Sao Paulo notes
      The old saw “Brazil is the country of the future, and always will be” now seems so wrong. The place feels increasingly conservative, and it is aging rapidly. In the domestic airport you see couples with only a single kid…
  - (2026-06-08) [Marginal Revolution] Monday assorted links
      1. It seems Piketty has become a degrowther. And other views. Maybe it is rude to say this, but some of our best-known economists basically have a negative-valued understanding of how the world works. And a bit more. 2.…
  - (2026-06-08) [Conversable Economist] Chair Jerome Powell: An Early Retrospective
      Jerome Powell was Chair of the Federal Reserve from February 2018 to May 2026. Of course, the Fed Chair does not have dictatorial power over setting monetary policy: instead, such policy is set by a vote of the 12-member…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 12 total
  - (2026-06-08) CVE-2026-42271 · BerriAI LiteLLM: BerriAI LiteLLM Command Injection Vulnerability
      vendor: BerriAI · product: LiteLLM · CISA remediation by 2026-06-22
  - (2026-06-08) CVE-2026-50751 · Check Point Security Gateway: Check Point Security Gateway Improper Authentication Vulnerability
      vendor: Check Point · product: Security Gateway · CISA remediation by 2026-06-11

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-06-08) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with increasing case numbers, geographic spread, and cross-border transmission to Uganda. As of 6 June, a t…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-09) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=27; carrying terms: rulemaking, action, safety, certain, proposed, captain, public, personnel, guard, waters, coast, vessels
- state_bills: today=127, 7d-median=128, 14d-median=140; carrying terms: payment, arizona, office, otherwise, provider, reporting, against, court, until, others, relative, alternative
- state_news: today=476, 7d-median=651, 14d-median=673; carrying terms: potential, coverage, circuit, proposed, reporting, against, nearly, colorado, deaths, others, midterm, defeat
- local_news: today=218, 7d-median=218, 14d-median=234; carrying terms: office, against, court, appeared, morning, public, atlanta, returns, trump, killing, ahead, month
- foreign_news: today=831, 7d-median=847, 14d-median=854; carrying terms: naughty, beijing, praises, itself, growth, forum, nation, publicized, diplomat, potential, kills, circuit
- chinese_internal: today=248, 7d-median=268, 14d-median=270; carrying terms: cbmizefvx, cbmia, china, blank, cbmickfvx, cbmib, people, politics, cbmiykfvx, cbmix, cbmidefvx, articles
- russian_internal: today=946, 7d-median=1014, 14d-median=989; carrying terms: politico, found, times, bloomberg, forbidden, telegram, media, title, europe, novaya, axios, novayagazeta
- ukrainian_internal: today=112, 7d-median=119, 14d-median=122; carrying terms: vechirniy, hmarochos, httperror, error, forbidden, ukrinform, censor, client, independent, kyivindependent, title, https
- ukraine_theater: today=359, 7d-median=342, 14d-median=330; carrying terms: cuxqae, earthquake, cbmiuafbvv, nfvgfpt, rtdzckxnq, ttxcwzhlkmlbjmjrj, coverage, cbmiswfbvv, snnfdvpmtljhewnyodnblvr, yxzkmkv, assessment, howevpsmk
- paper_bets: today=133, 7d-median=140, 14d-median=141; carrying terms: seats, decrease, mexico, republicans, kansas, safety, arizona, world, country, primary, includes, otherwise
- weather: today=188, 7d-median=173, 14d-median=128; carrying terms: possible, florida, center, oxnard, fires, impacted, marine, occur, expected, norton, scattered, stage
- macro: today=21, 7d-median=21, 14d-median=10; carrying terms: unrate, labor, rates, spread, latest, treasury, effective, indicator, recession, unemployment, funds, money
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: large, treasury, proxy, agriculture, corporate, equities, natural, crypto, close, russell, yield, silver
- markets_global: today=47, 7d-median=47, 14d-median=79; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=111, 14d-median=106; carrying terms: xskfisuh, designations, prohibited, yemen, crimea, threatening, sectoral, office, articles, authorities, stage, funds
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, httperror, quiver, client, https, quantitative, quiverquant, unauthorized
- billionaires: today=35, 7d-median=40, 14d-median=40; carrying terms: larry, meyers, francoise, amazon, julia, family, carlos, canada, yiming, mexico, google, holdings
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, collins, court, appeals, supreme, company, state, robert, alaska, general, attorney, people
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, financial, group, chase, jpmorgan, filer, trust, subject, william
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: michael, senate, warner, angels, krishnamoorthi, robert, alexandria, cortez, joshua, graham, ossoff, disbursements
- gdelt_regions: today=12, 7d-median=6, 14d-median=6; carrying terms: english, japan, switch
- gdelt_gkg: today=50, 7d-median=75, 14d-median=25; carrying terms: china, english, chinese, against, lebanon, trade, talks, yahoo, israel, ukraine, taiwan, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: domain, language, english, canada, india, kingdom, strikes, philippines, cancer, president, pakistan, trump
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=30, 14d-median=28; carrying terms: ground, belgium, position, bulgaria, france, germany, kingdom, canada, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: deteriorate, updated, infecting, center, municipalities, cluster, patient, mortality, dicale, products, producing, infections
- cisa_kev: today=12, 7d-median=11, 14d-median=15; carrying terms: vendor, overflow, remediation, vulnerability, authentication, product, bypass, embedded, privilege, escalation, console, cpanel
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=160, 7d-median=128, 14d-median=128; carrying terms: romania, cyclone, democratic, medium, sweden, gabon, mexico, earthquake, vietnam, hungary, islamic, alert
- usgs_quakes: today=22, 7d-median=19, 14d-median=18; carrying terms: depth, indonesia, philippines, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, world, price, volume, peace, permanent, south, korea, turkiye, mexico, switzerland, presidential
- commentary: today=6, 7d-median=5, 14d-median=6; carrying terms: revolution, marginal, https, economist, conversable, class, policy, assorted, links, marginalrevolution, economy, economic
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: lutnick, deluzio, bryan, kevin, orden, andrea, huizenga, roberts, warner, adrian, agriculture, hinds
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, placement, consensus, today, placed, module, paper, sufficient, markets, claude, unavailable, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline
- [2026-06-06] Fed speeches: Barr, Deregulating in a Financial Boom: What Could Go Wrong?
- [2026-06-08] ECB press: ECB announces main milestones for roll-out of Integrated Reporting Framework

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*