# WORLDSCOPE morning brief — 2026-05-25

## Headline
57 new items across 2 section(s).

## What changed today
### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-05-26) #1 Elon Musk — $827.68B
      United States · Technology · source: Tesla, SpaceX · holdings: TSLA-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-05-26) #2 Larry Page — $311.48B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-05-26) #3 Sergey Brin — $287.25B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-05-26) #4 Jeff Bezos — $273.43B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-05-26) #5 Larry Ellison — $239.61B
      United States · Technology · source: Oracle · holdings: ORCL-US(NYSE), ORCL-US(NYSE), PSKY-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-05-26) #6 Mark Zuckerberg — $209.44B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)
  - (2026-05-26) #7 Michael Dell — $201.39B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-05-26) #8 Jensen Huang — $186.00B
      United States · Technology · source: Semiconductors · holdings: NVDA-US(NASDAQ), NVDA-US(NASDAQ), NVDA-US(NASDAQ), NVDA-US(NASDAQ)

### Campaign finance (FEC: top fundraisers + recent filings) — 27 new of 27 total
  - (2026-05-25) [Top] OSSOFF, T. JONATHAN (DEM, Senate GA): $81.15M raised
      cycle 2026 receipts $81.15M · disbursements $52.97M · net $+28.17M
  - (2026-05-25) [Top] TALARICO, JAMES (DEM, Senate TX): $40.28M raised
      cycle 2026 receipts $40.28M · disbursements $30.43M · net $+9.86M
  - (2026-05-25) [Top] BOOKER, CORY A. (DEM, Senate NJ): $32.26M raised
      cycle 2026 receipts $32.26M · disbursements $15.55M · net $+16.71M
  - (2026-05-25) [Top] KRISHNAMOORTHI, S (DEM, Senate IL): $31.39M raised
      cycle 2026 receipts $31.39M · disbursements $28.24M · net $+3.15M
  - (2026-05-25) [Top] OCASIO-CORTEZ, ALEXANDRIA (DEM, House NY): $27.73M raised
      cycle 2026 receipts $27.73M · disbursements $16.78M · net $+10.95M
  - (2026-05-25) [Top] COOPER, ROY (DEM, Senate NC): $26.82M raised
      cycle 2026 receipts $26.82M · disbursements $8.37M · net $+18.46M
  - (2026-05-25) [Top] BROWN, SHERROD (DEM, Senate OH): $25.98M raised
      cycle 2026 receipts $25.98M · disbursements $8.95M · net $+17.03M
  - (2026-05-25) [Top] WARNER, MARK ROBERT (DEM, Senate VA): $21.99M raised
      cycle 2026 receipts $21.99M · disbursements $7.77M · net $+14.22M

## How it fits the arc (last 14 days)
- billionaires: today=30, 7d-median=30, 14d-median=30
- fec: today=27, 7d-median=27, 14d-median=27

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*