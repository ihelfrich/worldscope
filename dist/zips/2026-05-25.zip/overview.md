# WORLDSCOPE morning brief — 2026-05-25

## Headline
80 new items across 2 section(s).

## What changed today
### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-23) [Xerox Holdings Corp] Form 4 (Issuer)
      filed 2026-05-23 01:59 UTC · role: Issuer — Filed: 2026-05-22 AccNo: 0001193125-26-237487 Size: 4 KB
  - (2026-05-23) [BRUNO JOHN G] Form 4 (Reporting)
      filed 2026-05-23 01:59 UTC · role: Reporting — Filed: 2026-05-22 AccNo: 0001193125-26-237487 Size: 4 KB
  - (2026-05-23) [KAO MIN H] Form 4 (Reporting)
      filed 2026-05-23 01:55 UTC · role: Reporting — Filed: 2026-05-22 AccNo: 0001193125-26-237482 Size: 9 KB
  - (2026-05-23) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-05-23 01:55 UTC · role: Issuer — Filed: 2026-05-22 AccNo: 0001193125-26-237482 Size: 9 KB
  - (2026-05-23) [NORRIS DUSTIN DAVID] Form 4 (Reporting)
      filed 2026-05-23 01:47 UTC · role: Reporting — Filed: 2026-05-22 AccNo: 0001437749-26-018308 Size: 6 KB
  - (2026-05-23) [NEXPOINT DIVERSIFIED REAL ESTATE TRUST] Form 4 (Issuer)
      filed 2026-05-23 01:47 UTC · role: Issuer — Filed: 2026-05-22 AccNo: 0001437749-26-018308 Size: 6 KB
  - (2026-05-23) [Geyer Clay Howard] Form 4 (Reporting)
      filed 2026-05-23 01:42 UTC · role: Reporting — Filed: 2026-05-22 AccNo: 0001628280-26-037910 Size: 6 KB
  - (2026-05-23) [Black Rock Coffee Bar, Inc.] Form 4 (Issuer)
      filed 2026-05-23 01:42 UTC · role: Issuer — Filed: 2026-05-22 AccNo: 0001628280-26-037910 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-26) [Canada] Family 120 - kilometre walk for life - saving gene therapy ends in Victoria
      domain: comoxvalleyrecord.com · language: English · tone: 
  - (2026-05-26) [Thailand] Heartless Hit - and - Run : Suspect Flees After Head - On Crash With Motorcycle
      domain: chiangraitimes.com · language: English · tone: 
  - (2026-05-26) [United States] 3 displaced after Magnolia Street house fire
      domain: newsargus.com · language: English · tone: 
  - (2026-05-26) [United States] Letter to the editor : Mossyrock firefighters provide life - saving training for students
      domain: chronline.com · language: English · tone: 
  - (2026-05-26) [United Kingdom] Armed police shut down Hertfordshire road after horror incident sees two rushed to hospital
      domain: mirror.co.uk · language: English · tone: 
  - (2026-05-26) [United States] Trump to get  routine annual  medical exam 7 months after last visit to Walter Reed
      domain: kansaspublicradio.org · language: English · tone: 
  - (2026-05-26) [] Hundreds gather for 27th annual Wild Bill Ride to Remember
      domain: firstalert7.com · language: English · tone: 
  - (2026-05-26) [Canada] Saanich Police seize $55K worth of fentanyl , cocaine , meth , GHB
      domain: comoxvalleyrecord.com · language: English · tone: 

## How it fits the arc (last 14 days)
- form4: today=40, 7d-median=40, 14d-median=40
- conflict: today=40, 7d-median=40, 14d-median=40

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*