# WORLDSCOPE morning brief — 2026-05-25

## Headline
571 new items across 14 section(s).

## What changed today
### U.S. Federal Action — 25 new of 25 total
  - (2026-05-22) Restoring Integrity to America's Financial System
  - (2026-05-22) Integrating Financial Technology Innovation Into Regulatory Frameworks
  - (2026-05-22) To Implement Certain Provisions in the Consolidated Appropriations Act, 2026, and for Other Purposes
  - (2026-05-22) Airworthiness Directives; Pratt & Whitney RTX Corporation (Type Certificate Previously Held by Pratt & Whitney Division United Technologies Corporation) Engines
      The FAA is adopting a new airworthiness directive (AD) for certain Pratt & Whitney RTX Corporation (PW) Model PW4074, PW4074D, PW4077, PW4077D, PW4084D, PW4090, and PW4090-3 engines. This AD was prompted by an analysis o
  - (2026-05-22) Removal of Environmental Clearance Officer Review and Comment for Assessments for Projects Over 200 Lots/Dwelling Units or Beds
      This interim final rule revises the Department of Housing and Urban Development's (HUD's) environmental review regulations by removing HUD's requirement that Environmental Assessments for projects over 200 dwelling units
  - (2026-05-22) Amendment of United States Area Navigation Route T-306 and Establishment of United States Area Navigation Route T-647
      This action proposes to amend United States Area Navigation Route (RNAV) Route T-306 and the establishment of RNAV Route T-647 in the Southwestern United States. The FAA is proposing to amend T-306 by revoking the portio
  - (2026-05-22) Establishment of Class E Airspace; Monee, IL
      This action proposes to establish Class E airspace at Meadow Creek Airport, Monee, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-05-22) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Angling Category Gulf of America Trophy Fishery for 2026
      NMFS closes the Angling category Gulf of America fishery for large medium and giant ("trophy" (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length or greater)) Atlantic bluefin tuna (BFT). This action app

### Macro indicators — latest values (FRED) — 21 new of 21 total
  - (2026-05-21) [Rates] Fed Funds Effective Rate (DFF)
      latest: 3.62 as of 2026-05-21
  - (2026-05-21) [Rates] 2-Year Treasury (DGS2)
      latest: 4.08 as of 2026-05-21
  - (2026-05-21) [Rates] 10-Year Treasury (DGS10)
      latest: 4.57 as of 2026-05-21
  - (2026-05-21) [Rates] 30-Year Treasury (DGS30)
      latest: 5.1 as of 2026-05-21
  - (2026-05-21) [Rates] SOFR (SOFR)
      latest: 3.51 as of 2026-05-21
  - (2026-05-22) [Rates] 10y–2y Spread (recession indicator) (T10Y2Y)
      latest: 0.43 as of 2026-05-22
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-04-01) [Inflation] CPI Core (ex food & energy, SA) (CPILFESL)
      latest: 335.423 as of 2026-04-01

### Markets snapshot (Finnhub) — 21 new of 21 total
  - (2026-05-22) [US equities] S&P 500 (SPY): 745.64 ▲ +0.39%
      close 745.64 · chg +2.92 (+0.39%) · day range 744.48–748.94
  - (2026-05-22) [US equities] Nasdaq 100 (QQQ): 717.54 ▲ +0.42%
      close 717.54 · chg +3.03 (+0.42%) · day range 715.95–722.12
  - (2026-05-22) [US equities] Russell 2000 (IWM): 285.12 ▲ +0.93%
      close 285.12 · chg +2.63 (+0.93%) · day range 283.67–286.61
  - (2026-05-22) [Intl equities] MSCI EAFE (EFA): 103.98 ▼ -0.20%
      close 103.98 · chg -0.21 (-0.20%) · day range 103.79–104.48
  - (2026-05-22) [EM equities] MSCI EM (EEM): 65.88 ▼ -0.23%
      close 65.88 · chg -0.15 (-0.23%) · day range 65.74–66.39
  - (2026-05-22) [China equities] China large-cap (FXI): 35.52 ▼ -1.03%
      close 35.52 · chg -0.37 (-1.03%) · day range 35.15–35.61
  - (2026-05-22) [FX] DXY proxy (UUP): 27.77 ▲ +0.14%
      close 27.77 · chg +0.04 (+0.14%) · day range 27.75–27.82
  - (2026-05-22) [FX] EUR/USD (FXE): 107.10 ▼ -0.12%
      close 107.10 · chg -0.13 (-0.12%) · day range 106.95–107.23

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 30 new of 30 total
  - (2026-05-21) [SCOTUS] Hamm v. Smith
  - (2026-05-21) [SCOTUS] Havana Docks Corp. v. Royal Caribbean Cruises, Ltd.
  - (2026-05-21) [SCOTUS] M & K Employee Solutions, Inc. v. Trustees of IAM Nat. Pension
  - (2026-05-14) [SCOTUS] Jules v. Andre Balazs Properties
  - (2026-05-14) [SCOTUS] Montgomery v. Caribe Transport II, LLC
  - (2026-05-22) [CIT] Toyo Kohan Co., Ltd. v. United States
  - (2026-05-20) [CIT] Oregon v. United States
  - (2026-05-15) [CIT] Green Garden Produce, LLC v. United States

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-23) [Xerox Holdings Corp] Form 4 (Issuer)
      filed 2026-05-23 01:59 UTC · role: Issuer — Filed: 2026-05-22 AccNo: 0001193125-26-237487 Size: 4 KB
  - (2026-05-23) [BRUNO JOHN G] Form 4 (Reporting)
      filed 2026-05-23 01:59 UTC · role: Reporting — Filed: 2026-05-22 AccNo: 0001193125-26-237487 Size: 4 KB
  - (2026-05-23) [KAO MIN H] Form 4 (Reporting)
      filed 2026-05-23 01:55 UTC · role: Reporting — Filed: 2026-05-22 AccNo: 0001193125-26-237482 Size: 9 KB
  - (2026-05-23) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-05-23 01:55 UTC · role: Issuer — Filed: 2026-05-22 AccNo: 0001193125-26-237482 Size: 9 KB
  - (2026-05-23) [NORRIS DUSTIN DAVID] Form 4 (Reporting)
      filed 2026-05-23 01:47 UTC · role: Reporting — Filed: 2026-05-22 AccNo: 0001437749-26-018308 Size: 6 KB
  - (2026-05-23) [NEXPOINT DIVERSIFIED REAL ESTATE TRUST] Form 4 (Issuer)
      filed 2026-05-23 01:47 UTC · role: Issuer — Filed: 2026-05-22 AccNo: 0001437749-26-018308 Size: 6 KB
  - (2026-05-23) [Geyer Clay Howard] Form 4 (Reporting)
      filed 2026-05-23 01:42 UTC · role: Reporting — Filed: 2026-05-22 AccNo: 0001628280-26-037910 Size: 6 KB
  - (2026-05-23) [Black Rock Coffee Bar, Inc.] Form 4 (Issuer)
      filed 2026-05-23 01:42 UTC · role: Issuer — Filed: 2026-05-22 AccNo: 0001628280-26-037910 Size: 6 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 0 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-26) [United States] Potsdam Memorial Day ceremony honors fallen service members
      domain: wwnytv.com · language: English · tone: 
  - (2026-05-26) [United Kingdom] More temperature records could tumble after scorching bank holiday
      domain: yorkpress.co.uk · language: English · tone: 
  - (2026-05-26) [Nigeria] Ekiti Assures Residents of School , Community Safety
      domain: punchng.com · language: English · tone: 
  - (2026-05-26) [United States] Strong earthquake hits Chile , no injuries reported
      domain: terradaily.com · language: English · tone: 
  - (2026-05-26) [United States] Immunosuppression with systemic glucocorticoids close to initiation of immune checkpoint inhibitor is associated with worse survival outcomes
      domain: 2minutemedicine.com · language: English · tone: 
  - (2026-05-26) [United States] Crews work to put out large Opa - locka junkyard fire
      domain: nbcmiami.com · language: English · tone: 
  - (2026-05-26) [India] VB - G RAM G : why workers in Jharkhand are wary of the new programme
      domain: scroll.in · language: English · tone: 
  - (2026-05-26) [United States] Stephen Colbert is back on TV on community access in Michigan
      domain: boston.com · language: English · tone: 

### Government & military aircraft airborne (OpenSky) — 8 new of 8 total
  - (2026-05-26) RCH184 (United States)
      icao24: ae123c · position: (36.9568, -76.0631) · alt: 441m · 330km/h
  - (2026-05-26) CFCBA (Canada)
      icao24: c00563 · position: (43.7012, -79.5594) · alt: 342m · 200km/h
  - (2026-05-26) CFCAU (Canada)
      icao24: c0055d · position: (49.147, -121.8645) · alt: 784m · 183km/h
  - (2026-05-26) AF21 (China)
      on ground · 53km/h
  - (2026-05-26) AF14 (China)
      on ground · 46km/h
  - (2026-05-26) RCH529 (United States)
      icao24: ae07d5 · position: (39.6676, -79.5475) · alt: 10668m · 988km/h
  - (2026-05-26) PAT141 (United States)
      icao24: ae1191 · position: (59.1076, -155.7534) · alt: 12192m · 635km/h
  - (2026-05-26) RCH466 (United States)
      icao24: ae2fa7 · position: (44.7791, -68.4479) · alt: 1066m · 506km/h

### Prediction Markets — most-traded (Polymarket) — 20 new of 20 total
  - (2026-05-26) Knicks vs. Cavaliers
      yes price: 100% · 24h volume: $8,706,837 · resolves 2026-05-26
  - (2026-04-28) Will Bitcoin hit $150k by June 30, 2026?
      yes price: 1% · 24h volume: $5,821,653 · resolves 2026-07-01
  - (2026-05-26) US x Iran permanent peace deal by May 26, 2026?
      yes price: 8% · 24h volume: $5,492,459 · resolves 2026-05-26
  - (2026-05-26) Will the Iran ceasefire continue through May 24?
      yes price: 99% · 24h volume: $4,504,155
  - (2026-05-26) Will the Iran ceasefire continue through May 25?
      yes price: 0% · 24h volume: $3,612,296 · resolves 2026-05-25
  - (2026-05-26) US x Iran permanent peace deal by May 31, 2026?
      yes price: 32% · 24h volume: $2,933,363 · resolves 2026-05-31
  - (2026-05-26) Iran closes its airspace by May 24?
      yes price: 1% · 24h volume: $2,755,059 · resolves 2026-05-24
  - () Will Ivory Coast win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,750,920 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 12 new of 12 total
  - (2026-05-25) [Adam Tooze] Top Links 1112 Semiconductor decoupling. Powell's politics. Industrializing Ogaden. Free trade and the Magna Carta.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze
  - (2026-05-25) [Noah Smith] Are you tired of the Trump era yet?
      Every few weeks there's a new disaster that would have sunk any other president.
  - (2026-05-25) [Marginal Revolution] *Silent Friend*
      An excellent and profound movie, large screen essential.  I take this movie to be an engagement with the truths of German romanticism (set in Marburg, with Geothe and Rilke as relevant texts), and asking whether that rom
  - (2026-05-25) [Marginal Revolution] New Aesthetics awards
      Patrick Collison tweets: Tyler and I just published a list of the recipients of the New Aesthetics grants: https://newaesthetics.art/grants. Thank you very much to all who applied. There were far more applications than w
  - (2026-05-25) [Marginal Revolution] Monday assorted links
      1. Sampling DNA from animal skin parchments. 2. The making of Indian statistics. 3. What happens if your iPhone is stolen in London? (NYT) 4. Brazil school phone bans: &#8220;We then show that test scores, which were tre
  - (2026-05-24) [Adam Tooze] Top Links 1111 The unlikeliness of an Nvidia default. The end of the beginning in Hormuz. The Economist on Mao & Zoroastrian Zeligs.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze
  - (2026-05-23) [Adam Tooze] Top Links 1010 Bond breakout? Big effects of bad data. Immigration and thermostatic politics & dad-chat is coming for dad-books.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze
  - (2026-05-23) [Noah Smith] America is heading for a debtpocalypse
      But if we act now, we can avert disaster.

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=25, 14d-median=25
- macro: today=0, 7d-median=21, 14d-median=21
- markets: today=0, 7d-median=21, 14d-median=21
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=0, 7d-median=0, 14d-median=0
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- conflict: today=40, 7d-median=40, 14d-median=40
- vip_flights: today=6, 7d-median=8, 14d-median=8
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=12, 14d-median=12

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*