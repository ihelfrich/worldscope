# WORLDSCOPE morning brief — 2026-05-25

## Headline
25 new items across 1 section(s).

## What changed today
### U.S. Federal Action — 25 new of 25 total
  - (2026-05-22) Restoring Integrity to America's Financial System
  - (2026-05-22) Integrating Financial Technology Innovation Into Regulatory Frameworks
  - (2026-05-22) To Implement Certain Provisions in the Consolidated Appropriations Act, 2026, and for Other Purposes
  - (2026-05-22) Airworthiness Directives; Pratt & Whitney RTX Corporation (Type Certificate Previously Held by Pratt & Whitney Division United Technologies Corporation) Engines
      The FAA is adopting a new airworthiness directive (AD) for certain Pratt & Whitney RTX Corporation (PW) Model PW4074, PW4074D, PW4077, PW4077D, PW4084D, PW4090, and PW4090-3 engines. This AD was prompted by an analysis o
  - (2026-05-22) Removal of Environmental Clearance Officer Review and Comment for Assessments for Projects Over 200 Lots/Dwelling Units or Beds
      This interim final rule revises the Department of Housing and Urban Development's (HUD's) environmental review regulations by removing HUD's requirement that Environmental Assessments for projects over 200 dwelling units
  - (2026-05-22) Amendment of United States Area Navigation Route T-306 and Establishment of United States Area Navigation Route T-647
      This action proposes to amend United States Area Navigation Route (RNAV) Route T-306 and the establishment of RNAV Route T-647 in the Southwestern United States. The FAA is proposing to amend T-306 by revoking the portio
  - (2026-05-22) Establishment of Class E Airspace; Monee, IL
      This action proposes to establish Class E airspace at Meadow Creek Airport, Monee, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-05-22) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Angling Category Gulf of America Trophy Fishery for 2026
      NMFS closes the Angling category Gulf of America fishery for large medium and giant ("trophy" (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length or greater)) Atlantic bluefin tuna (BFT). This action app

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=25, 14d-median=25

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*