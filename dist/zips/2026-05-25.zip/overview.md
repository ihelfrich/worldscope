# WORLDSCOPE morning brief — 2026-05-25

## Headline
49 new items across 3 section(s).

## What changed today
### Macro indicators — latest values (FRED) — 21 new of 21 total
  - (2026-05-21) [Rates] Fed Funds Effective Rate (DFF)
      latest: 3.62 as of 2026-05-21
  - (2026-05-21) [Rates] 2-Year Treasury (DGS2)
      latest: 4.08 as of 2026-05-21
  - (2026-05-21) [Rates] 10-Year Treasury (DGS10)
      latest: 4.57 as of 2026-05-21
  - (2026-05-21) [Rates] 30-Year Treasury (DGS30)
      latest: 5.1 as of 2026-05-21
  - (2026-05-21) [Rates] SOFR (SOFR)
      latest: 3.51 as of 2026-05-21
  - (2026-05-22) [Rates] 10y–2y Spread (recession indicator) (T10Y2Y)
      latest: 0.43 as of 2026-05-22
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-04-01) [Inflation] CPI Core (ex food & energy, SA) (CPILFESL)
      latest: 335.423 as of 2026-04-01

### Government & military aircraft airborne (OpenSky) — 8 new of 8 total
  - (2026-05-26) RCH143 (United States)
      icao24: ae1471 · position: (61.1863, -148.9415) · alt: 4107m · 620km/h
  - (2026-05-26) CFC3471 (Canada)
      icao24: c2c36d · position: (45.0034, -75.3354) · alt: 2308m · 468km/h
  - (2026-05-26) CFC2594 (Canada)
      icao24: c2b5cb · position: (61.7559, -142.559) · alt: 8526m · 541km/h
  - (2026-05-26) CFCBA (Canada)
      icao24: c00563 · position: (35.232, -80.8926) · alt: 13716m · 872km/h
  - (2026-05-26) RRR6115 (United Kingdom)
      icao24: 43c1c6 · position: (51.7533, -1.5648) · alt: -38m · 236km/h
  - (2026-05-26) NCR854 (United States)
      icao24: a6caa1 · position: (60.3015, -132.4789) · alt: 10050m · 975km/h
  - (2026-05-26) SAMU42 (France)
      icao24: 39ac4d · position: (45.9531, 4.1182) · alt: 708m · 256km/h
  - (2026-05-26) NCR852 (United States)
      icao24: a9c52e · position: (26.5177, -81.8389) · alt: 7627m · 815km/h

### Prediction Markets — most-traded (Polymarket) — 20 new of 20 total
  - (2026-05-26) Knicks vs. Cavaliers
      yes price: 93% · 24h volume: $7,104,304 · resolves 2026-05-26
  - (2026-04-28) Will Bitcoin hit $150k by June 30, 2026?
      yes price: 1% · 24h volume: $5,821,653 · resolves 2026-07-01
  - (2026-05-26) US x Iran permanent peace deal by May 26, 2026?
      yes price: 8% · 24h volume: $5,489,362 · resolves 2026-05-26
  - () Will the Iran ceasefire continue through May 24?
      yes price: 99% · 24h volume: $4,224,617
  - (2026-05-26) Will the Iran ceasefire continue through May 25?
      yes price: 1% · 24h volume: $2,990,571 · resolves 2026-05-25
  - (2026-05-26) US x Iran permanent peace deal by May 31, 2026?
      yes price: 32% · 24h volume: $2,912,950 · resolves 2026-05-31
  - (2026-05-26) Iran closes its airspace by May 24?
      yes price: 1% · 24h volume: $2,532,973 · resolves 2026-05-24
  - (2026-05-26) Will Mexico win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,140,703 · resolves 2026-07-20

## How it fits the arc (last 14 days)
- macro: today=21, 7d-median=21, 14d-median=21
- vip_flights: today=8, 7d-median=8, 14d-median=8
- forecasts: today=20, 7d-median=20, 14d-median=20

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*