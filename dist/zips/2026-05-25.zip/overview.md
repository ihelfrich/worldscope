# WORLDSCOPE morning brief — 2026-05-25

## Headline
55 new items across 4 section(s).

## What changed today
### U.S. Federal Action — 25 new of 25 total
  - (2026-05-22) Restoring Integrity to America's Financial System
  - (2026-05-22) Integrating Financial Technology Innovation Into Regulatory Frameworks
  - (2026-05-22) To Implement Certain Provisions in the Consolidated Appropriations Act, 2026, and for Other Purposes
  - (2026-05-22) Airworthiness Directives; Pratt & Whitney RTX Corporation (Type Certificate Previously Held by Pratt & Whitney Division United Technologies Corporation) Engines
      The FAA is adopting a new airworthiness directive (AD) for certain Pratt & Whitney RTX Corporation (PW) Model PW4074, PW4074D, PW4077, PW4077D, PW4084D, PW4090, and PW4090-3 engines. This AD was prompted by an analysis o
  - (2026-05-22) Removal of Environmental Clearance Officer Review and Comment for Assessments for Projects Over 200 Lots/Dwelling Units or Beds
      This interim final rule revises the Department of Housing and Urban Development's (HUD's) environmental review regulations by removing HUD's requirement that Environmental Assessments for projects over 200 dwelling units
  - (2026-05-22) Amendment of United States Area Navigation Route T-306 and Establishment of United States Area Navigation Route T-647
      This action proposes to amend United States Area Navigation Route (RNAV) Route T-306 and the establishment of RNAV Route T-647 in the Southwestern United States. The FAA is proposing to amend T-306 by revoking the portio
  - (2026-05-22) Establishment of Class E Airspace; Monee, IL
      This action proposes to establish Class E airspace at Meadow Creek Airport, Monee, IL. The FAA is proposing this action to support new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-05-22) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Angling Category Gulf of America Trophy Fishery for 2026
      NMFS closes the Angling category Gulf of America fishery for large medium and giant ("trophy" (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length or greater)) Atlantic bluefin tuna (BFT). This action app

### Sanctions & Designations (recent) — 0 new of 0 total
  (no new items today)

### World News (by country, top stories) — 24 new of 24 total
  - (2026-05-25) [Israel] Trump clarifies :  Nuclear dust  must be disposed of as part of any agreement
      israelnationalnews.com · English
  - (2026-05-25) [Israel] 5 / 25 / 26 – Ep . 7239 – Are You Ready for the Bridegroom ? – Endtime Ministries
      endtime.com · English
  - (2026-05-25) [Israel] Israel steps up Lebanon strikes as Netanyahu escalates offensive
      al-monitor.com · English
  - (2026-05-25) [Israel] US Hints It Open To Greenlighting Israel To Extend Its Operations In Lebanon
      i24news.tv · English
  - (2026-05-25) [Israel] Army Demolishes Homes , Facilities in Jerusalem , Bethlehem , and Qalqilia
      imemc.org · English
  - (2026-05-25) [Israel] Colonizer Desecrates Armenian Monastery in Occupied Jerusalem
      imemc.org · English
  - (2026-05-25) [Portugal] The best brunch spots in the Algarve
      theportugalnews.com · English
  - (2026-05-25) [Portugal] No law in Portugal forbids placing beach umbrella in front of private sunbeds
      theportugalnews.com · English

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-05-25) [Marginal Revolution] New Aesthetics awards
      Patrick Collison tweets: Tyler and I just published a list of the recipients of the New Aesthetics grants: https://newaesthetics.art/grants. Thank you very much to all who applied. There were far more applications than w
  - (2026-05-25) [Marginal Revolution] Monday assorted links
      1. Sampling DNA from animal skin parchments. 2. The making of Indian statistics. 3. What happens if your iPhone is stolen in London? (NYT) 4. Brazil school phone bans: &#8220;We then show that test scores, which were tre
  - (2026-05-25) [Marginal Revolution] Campo Grande bleg, Brazil
      Soon I will be there, in Mato Grosso do Sul, wishing to observe the foundations of Brazil&#8217;s burgeoning agricultural export economy, among other reasons.  So what should I do, where should I go, and what should I ea
  - (2026-05-22) [Conversable Economist] Agricultural Production Functions Without Prices
      I admit this story is insider stuff for those with experience of academic seminars for economists. But it made me laugh, so I pass it along. It&#8217;s how Jesse Tack, Jisang Yu, and Roderick M. Rejesus introduce their r
  - (2026-05-20) [Conversable Economist] A Foretaste of Warsh as Chair of the Federal Reserve
      Kevin Warsh was nominated by President Trump in January 2026 to replace Jerome Powell as Chair of the Federal Reserve. He was confirmed by the US Senate last week and sworn in as the new Fed chair earlier this week. What
  - (2026-05-19) [Conversable Economist] How is AI Affecting the Quantity and Quality of New Books?
      For those of us who live in the world of editing, writing, and publishing, the ability of the newest generations of AI tools to produce rivers of grammatically correct prose is a deep shock. But is there actual evidence 

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=25, 14d-median=25
- sanctions: today=0, 7d-median=0, 14d-median=0
- gdelt_regions: today=24, 7d-median=24, 14d-median=24
- commentary: today=6, 7d-median=6, 14d-median=6

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*