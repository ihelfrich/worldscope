# WORLDSCOPE morning brief — 2026-08-07

## Headline
2456 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (518) · Russian Internal News (state + in-exile) (477) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (191) · Chinese Internal News (168) · U.S. Weather + Severe / Climate Outlooks (156) · Local News: St. Louis + Atlanta (108) · State Legislative Action (97) · State-Level News (85) · GDELT GKG — themes / entities / watch areas (75) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (36)

## What changed today
### International News + Multilateral Institutions — 518 new of 1026 total
  - (2026-08-07) [Global] Meta fined $567m in largest child safety ruling against social media giant
      The ruling is in addition to $375m in fines Meta was already ordered to pay in the case, for a total of $942m.
  - (2026-08-07) [Global] Trump imposes 15% tariff on key chip material to counter China
      The move aims to protect US firms as they face increasing competition from China's chip industry.
  - (2026-08-07) [Global] What do people want from Argos?
      As Sainsbury agrees to sell Argos for £120m, we ask people if they still shop there, and what the new owners can do to compete with big online retailers like Amazon.
  - (2026-08-07) [Global] Colombia on the brink: ELN guerrilla group prepares for return to war
  - (2026-08-07) [Global] Thailand school shooting: eight killed including suspected attacker, police say
  - (2026-08-07) [Global] Dogs to be euthanised after man dies following suspected animal attack at rural Sydney property

### Russian Internal News (state + in-exile) — 477 new of 1150 total
  - (2026-08-07) В Москве прозвучал громкий взрыв. Его слышали в разных частях города. Что это было — не знает даже МЧС | LEDE: Жители Москвы сообщают о звуке громкого взрыва, который они услышали в районе 1] (ru: В М…
      Жители Москвы сообщают о звуке громкого взрыва, который они услышали в районе 11 утра, пишут Msk1, «Росбалт» и «Осторожно, новости».
  - (2026-08-07) Песню Монеточки убрали из российской дублированной версии «Человека-паука». Неделю назад ее вырезали в украинском прокате | LEDE: Песню Монеточки «Монополия», которая звучит в саундтреке нов] (ru: Пес…
      Песню Монеточки «Монополия», которая звучит в саундтреке нового «Человека-паука», в российской версии фильма заменили треком Рианны, обратила внимание Ксения Собчак.
  - (2026-08-07) «Нам самим нужны». Трамп — о дополнительных ракетах Patriot для Украины | LEDE: Президент США Дональд Трамп прокомментировал публичные призывы президента Украины Владимира Зеленского передат] (ru: «На…
      Президент США Дональд Трамп прокомментировал публичные призывы президента Украины Владимира Зеленского передать Киеву дополнительные ракеты для комплексов Patriot.
  - (2026-08-07) Wildberries ввела страхование от атак беспилотников. Продавцы смогут получить до 50 тысяч рублей за уничтоженный товар | LEDE: С 7 августа 2026 года продавцы маркетплейса Wildberries смогут ] (ru: Wil…
      С 7 августа 2026 года продавцы маркетплейса Wildberries смогут застраховать заказанные товары от нового вида риска — повреждения или утраты из-за терактов, диверсий и атак беспилотников, а также их последствий.
  - (2026-08-07) В Таиланде ученик открыл стрельбу в школе и убил шесть человек. Еще 15 ранены | LEDE: В провинции Нонтхабури в Таиланде ученик открыл стрельбу в школе. Об этом сообщает Khaosod Online. ] (ru: В Таилан…
      В провинции Нонтхабури в Таиланде ученик открыл стрельбу в школе. Об этом сообщает Khaosod Online.
  - (2026-08-07) Партия «Яблоко» объявила, что не связана с оппозиционерами в изгнании, которые решили поддержать ее на выборах в Госдуму | LEDE: Партия «Яблоко» заявила, что не связана с оппозиционерами в э] (ru: Пар…
      Партия «Яблоко» заявила, что не связана с оппозиционерами в эмиграции, которые призвали поддержать ее на осенних выборах в Госдуму.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 191 new of 695 total
  - (2026-08-07) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-06) [FIRMS] thermal anomaly 48.533, 34.642 (FRP 2.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 2.53 MW
  - (2026-08-06) [FIRMS] thermal anomaly 48.533, 34.647 (FRP 2.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 2.53 MW
  - (2026-08-06) [FIRMS] thermal anomaly 48.577, 34.050 (FRP 1.13 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 1.13 MW
  - (2026-08-06) [FIRMS] thermal anomaly 48.474, 34.631 (FRP 1.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 1.28 MW
  - (2026-08-06) [FIRMS] thermal anomaly 48.474, 34.629 (FRP 1.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 1.76 MW

### Chinese Internal News — 168 new of 272 total
  - (2026-08-06) In Depth: Former Shanxi Richest Man Indicted on Mafia, Casino Charges - Caixin Global
      In Depth: Former Shanxi Richest Man Indicted on Mafia, Casino Charges Caixin Global
  - (2026-08-06) In Depth: Dangdai Founder Ai Luming Detained as Probe Into Debt Crisis Widens - Caixin Global
      In Depth: Dangdai Founder Ai Luming Detained as Probe Into Debt Crisis Widens Caixin Global
  - (2026-08-06) 夜读精选｜ 贝恩资本宣布收购贡茶在中国大陆无法注册商标后退出市场 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE96QzBqd3R0eE1HaHhUVHNCTzRha2RFM2tSYWc4c254RWZMWlZhX2lpVU9MaWE1OHpfZ3NGTk5mRTRWbElkZHNCM] (zh:…
      夜读精选｜ 贝恩资本宣布收购贡茶在中国大陆无法注册商标后退出市场 财新
  - (2026-08-06) 湖北宜昌局部短时降雨128毫米 紧急转移近4000 人 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9JbURHMjFyQWhzTk55LTJYSWVJSWVsQW5rS1ZEMHRTRUFzcFJxalA0SllKc2l0UElaX1YzdGxlU2dfcHJfNG4xdVZFcn] (zh:…
      湖北宜昌局部短时降雨128毫米 紧急转移近4000 人 财新
  - (2026-08-06) 黎巴嫩贝鲁特港爆炸事件6 周年仍未等到追责结果 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFB3MWxHU3lLM0I5eGZpQWYtMXplYUFTVUpWYm9sc05JSXMtOVQ2elpLR1Q0dXF0bXRjbk5hMnVQMzV3bkhmVTZPRXVVYnJJWD] (zh:…
      黎巴嫩贝鲁特港爆炸事件6 周年仍未等到追责结果 财新
  - (2026-08-07) 今日开盘：沪指报3896.49点 跌幅0.10% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBoaDdMcHJMWlFzSEtnUmtOcUdXM19vQ0RyZUhoZzJJQjJEaHE2U3Nyc2M3VGJRSkVINWs2RTVEeUZIRDgyanpkWFdVbkV2d] (zh:…
      今日开盘：沪指报3896.49点 跌幅0.10% 财新

### U.S. Weather + Severe / Climate Outlooks — 156 new of 200 total
  - (2026-08-07) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 7 at 4:22AM CDT until August 7 at 4:45AM CDT by NWS Little Rock AR
      SVRLZK The National Weather Service in Little Rock has issued a * Severe Thunderstorm Warning for... Eastern Logan County in western Arkansas... Southwestern Johnson County in western Arkansas... Northwestern Yell County…
  - (2026-08-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-07) [Moderate] Special Weather Statement: Special Weather Statement issued August 7 at 4:15AM CDT by NWS Little Rock AR
      At 414 AM CDT, Doppler radar was tracking a strong thunderstorm near Blue Mountain, or 13 miles south of Paris, moving southeast at 15 mph. HAZARD...Winds in excess of 40 mph and half inch hail. SOURCE...Radar indicated.…
  - (2026-08-07) [Moderate] Special Weather Statement: Special Weather Statement issued August 7 at 4:13AM CDT by NWS Grand Forks ND
      At 413 AM CDT, Doppler radar was tracking a strong thunderstorm over Maple Bay, or 32 miles south of Thief River Falls, moving east at 55 mph. HAZARD...Nickel size hail. SOURCE...Radar indicated. IMPACT...Minor hail dama…
  - (2026-08-07) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued August 7 at 5:06AM EDT until August 7 at 9:00AM EDT by NWS Northern Indiana
      * WHAT...Visibility one quarter mile or less at times in dense fog. * WHERE...Portions of northern Indiana, southwest Michigan, and northwest Ohio. * WHEN...Until 9 AM EDT /8 AM CDT/ this morning. * IMPACTS...Rapidly cha…
  - (2026-08-07) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 7 at 4:03AM CDT until August 7 at 4:30AM CDT by NWS Norman OK
      SVROUN The National Weather Service in Norman has issued a * Severe Thunderstorm Warning for... Northwestern Grant County in northern Oklahoma... * Until 430 AM CDT. * At 403 AM CDT, a severe thunderstorm was located 5 m…

### Local News: St. Louis + Atlanta — 108 new of 249 total
  - (2026-08-07) [St. Louis] See the Aug. 7, 1926, front page: Dr. T.S. Manning to leave prison within 60 days
      Headlines from the Aug. 7, 1926, front page include: Gertrude Ederle's own story of record-breaking English Channel swim
  - (2026-08-07) [St. Louis] Webster Groves officials charged the city for strip clubs, pot store and Airbnb, audit says
      Plus: Governor says he will still work to cut taxes
  - (2026-08-07) [St. Louis] Bensky, Jeffrey
      Bensky, Jeffrey
  - (2026-08-07) [St. Louis] Bensky, Jeffrey
      Jeffrey Michael Bensky passed away peacefully on Wednesday, July 15, 2026 surrounded by family in St. Louis, Missouri. He was 74 years old.
  - (2026-08-07) [St. Louis] Coughlin, Cornelius
      Coughlin, Cornelius Eugene
  - (2026-08-07) [St. Louis] Garavaglia, John
      Garavaglia, John L. III

### State Legislative Action — 97 new of 131 total
  - (2026-08-07) [Alaska SB 133] An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step…
      An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step therapy; and providing for an effec…
  - (2026-08-07) [Alaska SB 180] An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regul…
      An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regulatory Commission of Alaska; and prov…
  - (2026-08-06) [Alaska SB 227] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs; relating to the corporate income t…
  - (2026-08-07) [Arizona HB 2755] state land use; highest; best
      state land use; highest; best
  - (2026-08-07) [Arizona HB 2756] utilities; high load factor customers
      utilities; high load factor customers
  - (2026-08-06) [Arizona HB 2041] child neglect; financial resources; exception
      child neglect; financial resources; exception

### State-Level News — 85 new of 771 total
  - (2026-08-07) [Arizona] ‘Sham’ Green Party candidates win primary races over party-backed write-ins
      The only Green Party candidates who made it onto Arizona’s primary ballot for governor and secretary of state, and who the party disavowed as frauds, won their races against Green Party-backed write-in candidates. In the…
  - (2026-08-06) [Arizona] Donald Trump lost on birthright citizenship at the Supreme Court. He’s trying again.
      WASHINGTON — President Donald Trump on Thursday signed two executive orders in his second attempt to deny citizenship to babies born to noncitizens, following the Supreme Court’s defeat this summer of an earlier order to…
  - (2026-08-07) [California] Governor Newsom proclaims State of Emergency in Calaveras County for the Gann Fire response
      Source
  - (2026-08-07) [California] Governor Newsom announces appointments
      Source
  - (2026-08-07) [Connecticut] Lamont sticks to a fiscal discipline not always applauded by labor
      <img width="1024" height="814" src="https://ctmirror.org/wp-content/uploads/2026/08/IMG_1598-1024x814.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high"…
  - (2026-08-07) [Connecticut] A reality check for CT’s housing market
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/04/CT-Public-housing-construction-1024x683.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async…

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] How the Russia – Ukraine War Is Reshaping Central Asia Geopolitical Balance
      timesca.com · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] Russia Turns to South Korea for Fuel as Refinery Crisis Deepens
      oilprice.com · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] Sweden to hand over seized Russian shadow fleet ship to Ukraine
      thelocal.se · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] Ed Miliband just went to war - and for once he on our side !
      aol.co.uk · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] UK Targets Ships and Banks with New Russia Sanctions
      english.aawsat.com · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] Ukraine - Russia war latest : Putin could attack Nato member to test alliance resolve , report on US intel warns
      independent.co.uk · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-07) [Liftoff Mobile, Inc.] Form 4 (Issuer)
      filed 2026-08-07 01:59 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001628280-26-054546 Size: 5 KB
  - (2026-08-07) [RAFAEL BETSY] Form 4 (Reporting)
      filed 2026-08-07 01:59 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001628280-26-054546 Size: 5 KB
  - (2026-08-07) [Liftoff Mobile, Inc.] Form 4 (Issuer)
      filed 2026-08-07 01:58 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001628280-26-054545 Size: 5 KB
  - (2026-08-07) [Habiger David C] Form 4 (Reporting)
      filed 2026-08-07 01:58 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001628280-26-054545 Size: 5 KB
  - (2026-08-07) [Goldman Simon Robert] Form 4 (Reporting)
      filed 2026-08-07 01:58 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001628280-26-054544 Size: 5 KB
  - (2026-08-07) [Liftoff Mobile, Inc.] Form 4 (Issuer)
      filed 2026-08-07 01:58 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001628280-26-054544 Size: 5 KB

### Ukrainian Internal News (national + local Kyiv) — 36 new of 111 total
  - (2026-08-07) На Запоріжжі російський FPV-дрон убив жінку, чоловік поранений | LEDE: У Кушугумі на Запоріжжі внаслідок удару російського FPV-дрона загинула 55-річна жінка, ще один чоловік постраждав.] (uk: На Запор…
      У Кушугумі на Запоріжжі внаслідок удару російського FPV-дрона загинула 55-річна жінка, ще один чоловік постраждав.
  - (2026-08-07) Сили оборони уразили наземні ретранслятори та місце пусків БпЛА в Криму і на ТОТ | LEDE: Уночі 7 серпня ЗСУ вразили військові об'єкти Росії в Криму, Мелітополі та Запоріжжі.] (uk: Сили оборони уразили…
      Уночі 7 серпня ЗСУ вразили військові об'єкти Росії в Криму, Мелітополі та Запоріжжі.
  - (2026-08-07) ЗМІ: в МВС Німеччини кажуть про відсутність зброї на борту Ан-124 в аеропорту Лейпцига | LEDE: Міністерство внутрішніх справ Німеччини заперечило повідомлення про те, що український вантажний л] (uk:…
      Міністерство внутрішніх справ Німеччини заперечило повідомлення про те, що український вантажний літак Ан-124, біля якого виявили дрон з вибухівкою в аеропорту "Лейпциг/Галле", був завантажений боєприпасами.
  - (2026-08-07) Біля Коблевого в морі здетонував вибухонебезпечний предмет: чоловік загинув, дві жінки поранені | LEDE: На Миколаївщині в акваторії Чорного моря здетонував вибухонебезпечний предмет, унаслідок ] (uk:…
      На Миколаївщині в акваторії Чорного моря здетонував вибухонебезпечний предмет, унаслідок чого загинув 45-річний чоловік і були поранені дві жінки.
  - (2026-08-07) Росіяни атакували "Молнією" цивільну автівку на Херсонщині: загинула жінка | LEDE: На Херсонщині російський дрон атакував авто — загинула жінка, чоловік у лікарні з пораненнями.] (uk: Росіяни атакувал…
      На Херсонщині російський дрон атакував авто — загинула жінка, чоловік у лікарні з пораненнями.
  - (2026-08-07) Турецькі військові літаки і дрони в четвер 17 разів порушили повітряний простір Греції | LEDE: За словами грецьких офіційних осіб, у четвер турецькі військові літаки та безпілотники 17 разів по] (uk:…
      За словами грецьких офіційних осіб, у четвер турецькі військові літаки та безпілотники 17 разів порушили повітряний простір Греції над Егейським морем, а в одному випадку грецький винищувач, який вилетів, щоб їх відігнат…

### GDACS — global disaster alerts — 35 new of 215 total
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 26 total
  - (2026-08-07) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (48.6306, 2.0656) · alt: 1120m · 361km/h
  - (2026-08-07) PUMAA (France)
      icao24: 39ddf7 · position: (44.4436, 5.3806) · alt: 1165m · 246km/h
  - (2026-08-07) JEDI27 (France)
      icao24: 39a858 · position: (44.466, -1.2578) · alt: 358m · 241km/h
  - (2026-08-07) JAF63N (Belgium)
      icao24: 44d1ba · position: (50.9173, 4.6049) · alt: 312m · 284km/h
  - (2026-08-07) JAF3NE (Belgium)
      icao24: 44d1a6 · position: (45.1856, -0.6649) · alt: 10972m · 876km/h
  - (2026-08-07) JAF66L (Belgium)
      icao24: 44d1a5 · position: (46.0677, 0.8315) · alt: 10972m · 824km/h

### U.S. Federal Action — 21 new of 21 total
  - (2026-08-07) Protecting Against National Security Threats to the Communications Supply Chain Through the Equipment Authorization Program
      The Federal Communications Commission (Commission or FCC) issues a Third Further Notice of Proposed Rulemaking seeking comment on a broad set of additional measures to strengthen the security and integrity of its equipme…
  - (2026-08-07) Build America: Eliminating Barriers to Wireline Deployments
      In this document, the Federal Communications Commission (Commission) proposes and seeks comment on rules that would eliminate state and local requirements that constrain the deployment of modern high-speed wireline infra…
  - (2026-08-07) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action; Correction
      NMFS is correcting a temporary rule for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. The action added fishing dates in August and September in the…
  - (2026-08-07) Special Local Regulations; Annual Les Cheneaux Islands Antique Wooden Boat Show, Marquette Bay, Hessel, MI
      The Coast Guard will enforce the Annual Les Cheneaux Islands Antique Wooden Boat Show special local regulation on the U.S. navigable waters of Marquette Bay, Hessel, MI on August 8, 2026. This action is necessary to prov…
  - (2026-08-07) Revocation of Class E Airspace; Lake Geneva, WI
      This action revokes the Class E airspace at Lake Geneva, WI. This action is due to the instrument procedures being cancelled and the closure of the airport.
  - (2026-08-07) Amendment of Class D and Class E Airspace; Chicago/Rockford, IL
      This action amends the Class D and Class E airspace at Chicago/Rockford, IL. This action is due to a biennial airspace review conducted pursuant to FAA Order JO 7400.2R, Procedures for Handling Airspace Matters. This act…

### Court opinions of consequence (federal & state) — 18 new of 60 total
  - (2026-08-06) U.S. Court of Appeals, 5th Cir.: Adler v. Energy Debt Holdings
  - (2026-08-06) U.S. Court of Appeals, 5th Cir.: Eqbal v. Blanche
  - (2026-08-06) U.S. Court of Appeals, 5th Cir.: Knighton v. Benton County, MS
  - (2026-08-06) U.S. Court of Appeals, 5th Cir.: MAPP v. Floor and Decor
  - (2026-08-06) U.S. Court of Appeals, 5th Cir.: Rivera Castelan v. Taylor
  - (2026-08-06) U.S. Court of Appeals, 5th Cir.: United States v. Deluna

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 100 total
  - (2026-08-07) [USASpending] $4,682,329,250 → RUSSIA SPACE AGENCY: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
      Agency: National Aeronautics and Space Administration. Description: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
  - (2026-08-07) [USASpending] $2,089,442,660 → BOLLINGER SHIPYARDS LOCKPORT, L.L.C.: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE U
      Agency: Department of Homeland Security. Description: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE UP TO TWENTY-SIX (26) FAST RESPONSE CUTTERS (FRCS) ON A FIRM FIXED PRICE (FFP) BASIS WITH AN ECONOMIC PRICE…
  - (2026-08-07) [USASpending] $1,186,157,198 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR
      Agency: General Services Administration. Description: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR THE USACE.
  - (2026-08-07) [USASpending] $1,175,671,370 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD
  - (2026-08-07) [USASpending] $942,267,915 → ACCENTURE FEDERAL SERVICES LLC: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOM
      Agency: Department of Education. Description: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE PLATFORMS AND SERVICES SOLUTION (ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE SOLUTION, AKA EWDCCPS, AKA DCC)…
  - (2026-08-07) [USASpending] $931,286,481 → HII MISSION TECHNOLOGIES CORP: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED
      Agency: General Services Administration. Description: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED TO ALION SCIENCE AND TECHNOLOGY CORPORATION TO PROVIDE CONTRACTOR SUPPORT TO THE JOINT CAPABILITY EMBEDDE…

### Paper Trading Scorecard — 11 new of 140 total
  - (2026-08-07) [Polymarket] Will Jude Bellingham win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-08-07) [Polymarket] Will Eduardo Bolsonaro finish in second place in the first round of the 2026 Brazilian presidential election?
      A presidential election is scheduled to take place in Brazil on October 4, 2026. This market will resolve according to the listed candidate who receives the second-most valid votes in the first round of this election. Th…
  - (2026-08-07) [Manifold] Will China's total datacenter power capacity surpass the US before 2031?
  - (2026-08-07) [Manifold] Faster S&P 500 Crash than the Dotcom Bubble before 2030?
  - (2026-08-07) [Manifold] Will SCOTUS strike down Alaska’s “$95,000 plane for 6 beers” forfeiture?
  - (2026-08-07) [Manifold] Will the US Unemployment Rate Exceed Dotcom Bubble Levels before 2030?

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-07) LoL: JD Gaming vs EDward Gaming (BO3) - LPL Group Ascend
      yes price: 100% · 24h volume: $1,217,713 · resolves 2026-08-07
  - (2026-08-07) LoL: JD Gaming vs EDward Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $759,743 · resolves 2026-08-07
  - (2026-08-07) LoL: KT Rolster vs Gen.G - Game 1 Winner
      yes price: 0% · 24h volume: $748,636 · resolves 2026-08-07
  - (2026-08-07) LoL: JD Gaming vs EDward Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $711,664 · resolves 2026-08-07
  - (2026-08-07) LoL: KT Rolster vs Gen.G (BO3) - LCK Round 3-4 Legend Group
      yes price: 0% · 24h volume: $465,647 · resolves 2026-08-07
  - (2026-08-07) LoL: KT Rolster vs Gen.G - Game 2 Winner
      yes price: 0% · 24h volume: $394,331 · resolves 2026-08-07

### IT, InfoSys & cybersecurity news (last 7 days) — 7 new of 56 total
  - (2026-08-07) [The Hacker News] TeamPCP Linked To Redis Attacks Dating Back To 2020 And Later Supply Chain Campaign
      A new analysis has uncovered that the threat actor tracked as TeamPCP has been active on the cybercrime scene as far back as 2020, indicating the group has been compromising internet-facing infrastructure for years befor…
  - (2026-08-07) [The Register] Cop who used police system to snoop for info on crook pals sentenced for Computer Misuse Act offenses
      Former Merseyside police officer sacked after failing to declare he was 'too close' with the wrong crowd
  - (2026-08-07) [The Register] Sysadmin summoned to explain italics – to a user with at least two degrees
      What an idiot
  - (2026-08-07) [The Register] China launches mysterious probe into security of Palo Alto Networks' products
      Beijing’s not saying why, which is just what happened when it investigated Micron
  - (2026-08-07) [The Register] ‘Humans will be a rounding error on the internet’ says Cloudflare exec
      Machine-generated traffic to surge 1000x in five years, while we meatbags keep clicking away slowly
  - (2026-08-06) [The Register] How the famed USENIX Security conf is managing a flood of papers in the AI era
      AI usage is evident but isn't yet a serious problem

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 36 total
  - (2026-08-07) MOVER ▼ Bernard Arnault & family — $148.54B ($-0.86B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-07) MOVER ▼ Francoise Bettencourt Meyers & family — $96.63B ($-0.45B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-07) MOVER ▼ Amancio Ortega — $148.95B ($-0.38B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-07) MOVER ▼ Gautam Adani — $84.69B ($-0.16B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-08-07) MOVER ▲ Carlos Slim Helu & family — $122.22B (+$0.06B since yesterday)
      Mexico · Telecom · source: Telecom

### USGS earthquakes (M4.5+, past day) — 3 new of 12 total
  - (2026-08-07) M 5.0 - 7 km NW of Cabacao, Philippines
      M5.0 · 7 km NW of Cabacao, Philippines · depth 90.196 km
  - (2026-08-07) M 4.6 - 51 km WSW of Sarangani, Philippines
      M4.6 · 51 km WSW of Sarangani, Philippines · depth 43.488 km
  - (2026-08-07) M 4.5 - 29 km S of Mendoza, Argentina
      M4.5 · 29 km S of Mendoza, Argentina · depth 10 km

### Commentary & analysis (last 7 days) — 1 new of 5 total
  - (2026-08-07) [Marginal Revolution] My excellent Conversation with Julia Ioffe
      Here is the audio, video, and transcript. Here is from the episode summary: Julia joined Tyler to discuss why so many of Russia’s great constructivist painters were women, why the tsarist government established women’s m…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=20, 14d-median=20; carrying terms: proposing, notice, proposes, rulemaking, action, safety, proposed, final, program, order, provide, certain
- state_bills: today=131, 7d-median=118, 14d-median=118; carrying terms: policy, alaska, management, including, county, business, written, establishes, limits, office, projects, reporting
- state_news: today=771, 7d-median=758, 14d-median=764; carrying terms: estimates, still, dropping, insurance, launches, announced, month, margin, primary, alaska, calling, wyoming
- local_news: today=249, 7d-median=239, 14d-median=230; carrying terms: month, figure, neighborhood, county, couple, three, atlanta, according, class, residents, content, louis
- foreign_news: today=1026, 7d-median=1026, 14d-median=1024; carrying terms: adult, iranian, topnews, still, controlled, consensus, screenshot, announced, bouteflika, kindergarten, margin, primary
- chinese_internal: today=272, 7d-median=272, 14d-median=269; carrying terms: caixin, stock, global, people, google, chinese, china, https, firms, record, price, market
- russian_internal: today=1150, 7d-median=943, 14d-median=940; carrying terms: found, insider, error, press, bloomberg, russian, https, group, variety, street, istories, forbidden
- ukrainian_internal: today=111, 7d-median=125, 14d-median=130; carrying terms: strikes, correspondents, civilians, updates, today, missiles, international, ukrinform, including, growing, changes, supply
- ukraine_theater: today=695, 7d-median=695, 14d-median=643; carrying terms: polygon, cartography, frontline, maintained, google, httperror, liveuamap, known, unauthorized, community, alerts, extra
- paper_bets: today=140, 7d-median=138, 14d-median=136; carrying terms: decrease, token, season, cancelled, total, majors, drought, presidential, theme, winners, miles, performing
- weather: today=200, 7d-median=176, 14d-median=174; carrying terms: aviation, baltimore, values, tampa, adams, afdsew, heatrisk, grand, rainfall, marine, until, colorado
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, commodities, funds, treasury, payrolls, dexchus, latest, sheet, dexuseu, total, spread, supply
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, agriculture, commodities, close, treasury, credit, proxy, futures, natural, nasdaq, crypto, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=100, 7d-median=102, 14d-median=103; carrying terms: armed, qaida, administration, combat, alliance, latinscript, transition, south, serious, controlled, activities, specific
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiver, unauthorized, error, congresstrading, quantitative, httperror, https, quiverquant
- billionaires: today=36, 7d-median=37, 14d-median=38; carrying terms: ambani, google, meyers, alice, gautam, bezos, huang, changpeng, holdings, brokerage, julia, japan
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: california, court, county, supreme, appeals, services, blanche, thomas, group, corporation, capital, holdings
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, holdings, robert, michael, bancorp, capital, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: trone, congress, ossoff, angels, talarico, booker, johnson, cycle, brown, platner, receipts, filing
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea, south, koreaherald
- gdelt_gkg: today=75, 7d-median=50, 14d-median=25; carrying terms: english, israel, hezbollah, keywords, trump, netanyahu, spanish, russian, hormuz, themes, israeli, crisis
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=19, 14d-median=17; carrying terms: position, belgium, ground, france, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: affecting, sylvatic, paralytic, organs, series, algeria, bundibugyo, adult, travel, total, remains, operator
- cisa_kev: today=8, 7d-median=9, 14d-median=10; carrying terms: product, fortinet, information, exposure, vulnerability, arista, sensitive, unauthorized, untrusted, deserialization, authentication, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=215, 7d-median=233, 14d-median=265; carrying terms: honduras, orange, ecuador, wildfire, republic, colombia, fires, earthquake, democratic, monaco, czech, russia
- usgs_quakes: today=12, 7d-median=14, 14d-median=18; carrying terms: japan, depth, islands, russia, philippines, guinea, papua, zealand, argentina, miyako, sarangani, solomon
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, volume, ceasefire, traffic, hormuz, effective, august, strait, normal, returns, rates
- commentary: today=5, 7d-median=5, 14d-median=5; carrying terms: class, revolution, marginal, economist, https, conversable, government, marginalrevolution, links, assorted, college, economic
- tech_news: today=56, 7d-median=56, 14d-median=57; carrying terms: computer, today, models, hackers, technology, bleepingcomputer, daily, vulnerability, hacked, researchers, companies, targeted
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: knott, jeffries, thompson, administration, perez, hollen, adams, marco, gonzalez, patrick, tracey, tillis
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, converges, sufficient, paper, identify, claude, markets, market, today, decision, evidence, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*