# WORLDSCOPE morning brief — 2026-08-07

## Headline
3338 new items across 29 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (751) · Russian Internal News (state + in-exile) (677) · World leaders & government officials (324) · State-Level News (323) · Local News: St. Louis + Atlanta (213) · Chinese Internal News (196) · U.S. Weather + Severe / Climate Outlooks (196) · State Legislative Action (100) · GDELT GKG — themes / entities / watch areas (88) · Ukraine Theater (total-war monitoring) (70) · Ukrainian Internal News (national + local Kyiv) (51) · Court opinions of consequence (federal & state) (47)

## What changed today
### International News + Multilateral Institutions — 751 new of 1092 total
  - (2026-08-07) [Global] Seven killed after Thai student opens fire at home and school
      Authorities say the 14-year-old killed his grandparents before gunning down five teachers at his school.
  - (2026-08-07) [Global] Spain to impose border controls against Italy as row over Ceuta migrant influx intensifies
      Italy introduced border controls following an influx of about 78,000 migrants from neighbouring Morocco into the Spanish exclave of Ceuta.
  - (2026-08-07) [Global] Saudi Arabia, Turkey and Pakistan sign defence pact
      Pakistan says an attack on any of the three will amount to an attack against all, amid conflict in the Middle East.
  - (2026-08-07) [Global] Meta fined $567m in largest child safety ruling against social media giant
      The ruling is in addition to $375m in fines Meta was already ordered to pay in the case, for a total of $942m.
  - (2026-08-07) [Global] Spanish police arrest 78 people in bust of 'one of largest' smuggling networks
      The group moved synthetic drugs from Spain to Algeria, then used the return journey to smuggle migrants and weapons.
  - (2026-08-07) [Global] Mexico and Peru restore diplomatic relations after asylum row
      Relations broke down after former Peruvian Prime Minister Betssy Chávez sought asylum in the Mexican embassy in November 2025.

### Russian Internal News (state + in-exile) — 677 new of 1286 total
  - (2026-08-07) Более 20 российских фигуристов получили нейтральный статус для участия в международных соревнованиях. Среди них — Камила Валиева и Александра Трусова | LEDE: Больше 20 российских фигуристов ] (ru: Бол…
      Больше 20 российских фигуристов получили нейтральный статус для выступления на международных соревнованиях под эгидой Международного союза конькобежцев (ISU). Об этом сообщает «Спортс».
  - (2026-08-07) The Atlantic: Маск не разрешает Украине использовать Starlink для ударов по России. Он считает, что «пора заключать сделку» | LEDE: Бывший министр обороны Украины Михаил Федоров через неофиц] (ru: The…
      Бывший министр обороны Украины Михаил Федоров через неофициальные каналы пытается убедить владельца SpaceX Илона Маска в том, чтобы тот разрешил ВСУ использовать Starlink для наведения на цели в России, а именно на росси…
  - (2026-08-07) В Германии над базой бундесвера заметили неизвестные беспилотники | LEDE: В Германии в ночь на 7 августа в городе Мехерних к юго-западу от Бонна заметили два подозрительных беспилотника, кот] (ru: В Г…
      В Германии в ночь на 7 августа в городе Мехерних к юго-западу от Бонна заметили два подозрительных беспилотника, которые пролетали над базой вооруженных сил страны (бундесвер). Об этом сообщили издания WDR, NDR и Süddeut…
  - (2026-08-07) Сенат США одобрил законопроект о санкциях против России | LEDE: Сенат США проголосовал за законопроект о санкциях против России, сообщает Reuters. ] (ru: Сенат США одобрил законопроект о санкциях прот…
      Сенат США проголосовал за законопроект о санкциях против России, сообщает Reuters.
  - (2026-08-07) В Швеции задержали пару российских туристов. Их посчитали «угрозой безопасности» из-за того, что они поставили палатку рядом с домом «охраняемого лица» | LEDE: В Швеции арестовали семейную п] (ru: В Ш…
      В Швеции арестовали семейную пару россиян, которые постоянно живут в Испании и приехали на север Европы на отдых, сообщили проект «Ковчег» и представители Антивоенного комитета России.
  - (2026-08-07) На Катерину Гордееву завели дело о распространении «фейков» об армии | LEDE: Следственный комитет по Москве возбудил уголовное дело о распространении «фейков» об армии против журналистки Кат] (ru: На…
      Следственный комитет по Москве возбудил уголовное дело о распространении «фейков» об армии против журналистки Катерины Гордеевой.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 323 new of 961 total
  - (2026-08-07) [California] Los recortes a Medicaid podrían afectar a todos (sí, incluso a ti). He aquí por qué.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/073007_MLK_HARBOR_HOSPITAL_GETTY_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-08-07) [California] Last call: CA liquor delivery law ending after lobbying blitz
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/080426_drinks-by-mail_FG_CM_09.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-08-07) [California] Court blocks CHP from firing officer caught in LA overtime scandal
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/060825-California-Highway-Patrol-GETTY-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-…
  - (2026-08-07) [California] California craft liquor delivery is about to go away thanks to big money lobbying
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/080426_drinks-by-mail_FG_22_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-08-07) [California] How a stronger voter ID law can alleviate doubts in California’s election system
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051926-Rancho-Cucamonga-WL-GETTY-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-08-07) [California] California’s voter ID ballot measure would add unnecessary barriers to a secure system
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/06/110123-Voters-Registration-Tulare-ZS-CM-102.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size w…

### Local News: St. Louis + Atlanta — 213 new of 268 total
  - (2026-08-07) [St. Louis] Human waste found in Missouri’s Big River from failing treatment plant
  - (2026-08-07) [St. Louis] Attorney General Hanaway says Missouri Constitution doesn’t allow redistricting referendum
  - (2026-08-07) [St. Louis] Back-to-school sales tax holiday starts now in Missouri and Illinois. Here’s what’s eligible
  - (2026-08-07) [St. Louis] Childcare in Missouri is expensive and hard to find. Proposed laws could change that
  - (2026-08-05) [St. Louis] ‘He was at peace’: Family remembers 78-year-old East St. Louis stabbing victim as a jokester who ‘loved his family’ - First Alert 4
      <a href="https://news.google.com/rss/articles/CBMi2AFBVV95cUxPY2pzQWlwdVNxZ2lhbjFTY3RFZWg5Ym1rdTNPcEFWVzlKYkdpbXo5YnZvZGFRRGUyeDQ3VXZJMVhaeXUtb1RKbHh2TkNINVlkXzJPcTZvQ2twdlNOTVVkQmx2X0cwMjNRNk1pMldmZFNTdlNnSm8wVmFRNWZDaF…
  - (2026-08-06) [St. Louis] St. Louis Metropolitan Sewer District (MSD) offers grants to homeowners for rainscaping - First Alert 4
      S

### Chinese Internal News — 196 new of 280 total
  - (2026-08-06) In Depth: Former Shanxi Richest Man Indicted on Mafia, Casino Charges - Caixin Global
      In Depth: Former Shanxi Richest Man Indicted on Mafia, Casino Charges Caixin Global
  - (2026-08-06) In Depth: Dangdai Founder Ai Luming Detained as Probe Into Debt Crisis Widens - Caixin Global
      In Depth: Dangdai Founder Ai Luming Detained as Probe Into Debt Crisis Widens Caixin Global
  - (2026-08-06) 影视 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1EOTY2WVNZMUoycjBwYklIR2o1d3ZwRFZFdzhFSTJxd3dkdXF2WlhFUGJHd3NWZTVjZ1F1b0MtZzl2emNIc1JTZGtaaEVvenhxdF] (zh:…
      影视 deepview.caixin.com
  - (2026-08-06) 夜读精选｜ 贝恩资本宣布收购贡茶在中国大陆无法注册商标后退出市场 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE96QzBqd3R0eE1HaHhUVHNCTzRha2RFM2tSYWc4c254RWZMWlZhX2lpVU9MaWE1OHpfZ3NGTk5mRTRWbElkZHNCM] (zh:…
      夜读精选｜ 贝恩资本宣布收购贡茶在中国大陆无法注册商标后退出市场 财新
  - (2026-08-06) 湖北宜昌局部短时降雨128毫米 紧急转移近4000 人 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9JbURHMjFyQWhzTk55LTJYSWVJSWVsQW5rS1ZEMHRTRUFzcFJxalA0SllKc2l0UElaX1YzdGxlU2dfcHJfNG4xdVZFcn] (zh:…
      湖北宜昌局部短时降雨128毫米 紧急转移近4000 人 财新
  - (2026-08-06) 黎巴嫩贝鲁特港爆炸事件6 周年仍未等到追责结果 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFB3MWxHU3lLM0I5eGZpQWYtMXplYUFTVUpWYm9sc05JSXMtOVQ2elpLR1Q0dXF0bXRjbk5hMnVQMzV3bkhmVTZPRXVVYnJJWD] (zh:…
      黎巴嫩贝鲁特港爆炸事件6 周年仍未等到追责结果 财新

### U.S. Weather + Severe / Climate Outlooks — 196 new of 199 total
  - (2026-08-07) [Moderate] Special Weather Statement: Special Weather Statement issued August 7 at 4:19PM EDT by NWS Blacksburg VA
      At 418 PM EDT, Doppler radar was tracking a strong thunderstorm near Lawn, or near Rainelle, moving east at 10 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree l…
  - (2026-08-07) [Severe] Special Marine Warning: Special Marine Warning issued August 7 at 4:19PM EDT until August 7 at 5:00PM EDT by NWS Marquette MI
      SMWMQT The National Weather Service in Marquette has issued a * Special Marine Warning for... Black River To Ontonagon MI... Lake Superior from Saxon Harbor WI to Upper Entrance to Portage Canal MI 5NM off shore to the U…
  - (2026-08-07) [Severe] Flash Flood Warning: Flash Flood Warning issued August 7 at 4:19PM EDT until August 7 at 7:15PM EDT by NWS Wilmington OH
      FFWILN The National Weather Service in Wilmington has issued a * Flash Flood Warning for... Southeastern Butler County in southwestern Ohio... Northwestern Hamilton County in southwestern Ohio... * Until 715 PM EDT. * At…
  - (2026-08-07) [Moderate] Special Weather Statement: Special Weather Statement issued August 7 at 4:19PM EDT by NWS Blacksburg VA
      At 419 PM EDT, Doppler radar was tracking a strong thunderstorm over Peoria, or near Beech Mountain, moving northeast at 5 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock…
  - (2026-08-07) [Moderate] Special Weather Statement: Special Weather Statement issued August 7 at 4:19PM EDT by NWS Greenville-Spartanburg SC
      At 419 PM EDT, Doppler radar was tracking a strong thunderstorm 14 miles west of Brevard, or 8 miles southwest of Black Balsam Area, moving northeast at 10 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated.…
  - (2026-08-07) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 7 at 4:18PM EDT until August 7 at 4:30PM EDT by NWS Mount Holly NJ
      At 418 PM EDT, a severe thunderstorm was located over Tatamy, or near Easton, moving east at 35 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Damage to roofs, siding, trees, and power lines is possi…

### State Legislative Action — 100 new of 129 total
  - (2026-08-07) [Alaska SB 133] An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step…
      An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step therapy; and providing for an effec…
  - (2026-08-07) [Alaska SB 180] An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regul…
      An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regulatory Commission of Alaska; and prov…
  - (2026-08-06) [Alaska SB 227] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs; relating to the corporate income t…
  - (2026-08-07) [Arizona HB 2755] state land use; highest; best
      state land use; highest; best
  - (2026-08-07) [Arizona HB 2756] utilities; high load factor customers
      utilities; high load factor customers
  - (2026-08-06) [Arizona HB 2041] child neglect; financial resources; exception
      child neglect; financial resources; exception

### GDELT GKG — themes / entities / watch areas — 88 new of 88 total
  - (2026-08-07) [Russia oil sanctions perimeter · themes] Damen Delivers CF 3850 CF Anja to Juru Agentura Forsa
      maritime-executive.com · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] Цены на продукты в Украине : хлеб , гречка , яйца , масло , молоко
      kv.com.ua · Russian · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] Colombia new president vows to remake the country and challenge rebel groups
      wboi.org · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] Senatul SUA a aprobat sancțiunile împotriva Rusiei : pentru prima dată , este vizată și flota fantomă a lui Vladimir Putin
      digi24.ro · Romanian · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] Arde dos veces en pocas horas una zona del parque del Rivillas de Badajoz
      lacronicabadajoz.com · Spanish · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] El incómodo y polémico vecino del sur
      mundiario.com · Spanish · tone NA

### Ukraine Theater (total-war monitoring) — 70 new of 238 total
  - (2026-08-07) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-07) [Liveuamap] At Pokrovsk direction clashes yesterday near Shakhove, Udachne and towards Toretske, Kucheriv Yar, Bilytske, Novyy Donbas, Shevchenko, Matyasheve, Novopidhorodnie, - General Staff of Armed…
      At Pokrovsk direction clashes yesterday near Shakhove, Udachne and towards Toretske, Kucheriv Yar, Bilytske, Novyy Donbas, Shevchenko
  - (2026-08-06) [Liveuamap] Overnight Russia launched 2 Kh-31P missiles,2 Onyx missiles and 101 drones of different types, - Ukrainian Air Force - Liveuamap
      Overnight Russia launched 2 Kh-31P missiles,2 Onyx missiles and 101 drones of different types, - Ukrainian Air Force &
  - (2026-08-07) [Liveuamap] Deployment of Iraqi army units in the capital, Baghdad. - iraq.liveuamap.com
      Deployment of Iraqi army units in the capital, Baghdad. iraq.liveuamap.com
  - (2026-08-05) [Liveuamap] Air pollution levels rise in Kyiv after massive attack - Liveuamap
      Air pollution levels rise in Kyiv after massive attack Liveuamap
  - (2026-08-06) [Liveuamap] Trump to Fox News: We are delivering powerful blows to Iran and continuing to achieve victories - Liveuamap
      Trump to Fox News: We are delivering powerful blows to Iran and continuing to achieve victories <font

### Ukrainian Internal News (national + local Kyiv) — 51 new of 122 total
  - (2026-08-07) Cибіга привітав ухвалення Сенатом США "проєкту Грема" про санкції проти РФ | LEDE: ] (uk: Cибіга привітав ухвалення Сенатом США "проєкту Грема" про санкції проти РФ)
  - (2026-08-07) За експосадовця МЗС Банькова, якого підозрюють у розкраданні, внесли заставу | LEDE: За колишнього держсекретаря Міністерства закордонних справ Олександра Банькова 3 серпня внесли заставу у роз] (uk:…
      За колишнього держсекретаря Міністерства закордонних справ Олександра Банькова 3 серпня внесли заставу у розмірі 10 млн грн і він вийшов із СІЗО.
  - (2026-08-07) Є лише 6 хвилин на знищення пускових установок: Як протидіяти російській балістиці | LEDE: ] (uk: Є лише 6 хвилин на знищення пускових установок: Як протидіяти російській балісти)
  - (2026-08-07) Вулиці Жешува підтопило після рясної зливи | LEDE: ] (uk: Вулиці Жешува підтопило після рясної зливи)
  - (2026-08-07) На Покровському та Костянтинівському напрямках зафіксували найбільше бойових дій за добу — Генштаб | LEDE: Від початку доби 7 серпня на фронті відбулось 192 бойових зіткнення, з них 25 на Покр] (uk: Н…
      Від початку доби 7 серпня на фронті відбулось 192 бойових зіткнення, з них 25 на Покровському напрямку і 19 — Костянтинівському.
  - (2026-08-07) Стали відомі деталі першого візиту Зеленського до Белграда | LEDE: ] (uk: Стали відомі деталі першого візиту Зеленського до Белграда)

### Court opinions of consequence (federal & state) — 47 new of 60 total
  - (2026-08-11) Connecticut Supreme Court: LPP Mortgage Ltd. v. Underwood Towers Ltd. Partnership
  - (2026-08-11) Connecticut Supreme Court: LPP Mortgage Ltd. v. Underwood Towers Ltd. Partnership
  - (2026-08-07) U.S. Court of Appeals, 3rd Cir.: S.A.S.B. CORP v. Johnson & Johnson Health Care Systems Inc
  - (2026-08-07) Alaska Supreme Court: Lora Reinbold v. State of Alaska and Alaska Legislature Select Committee on Legislative Ethics
  - (2026-08-07) Alaska Supreme Court: SARAH RACHEL MALLETTE and v. GARFIELD TAU ADAMS And
  - (2026-08-07) Alaska Supreme Court: State of Alaska v. Steven Ridenour

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-07) [Beraud Jill] Form 4 (Reporting)
      filed 2026-08-07 20:20 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001999371-26-017422 Size: 7 KB
  - (2026-08-07) [LEVI STRAUSS & CO] Form 4 (Issuer)
      filed 2026-08-07 20:20 UTC · role: Issuer — Filed: 2026-08-07 AccNo: 0001999371-26-017422 Size: 7 KB
  - (2026-08-07) [Gregoire Kevin P.] Form 4 (Reporting)
      filed 2026-08-07 20:20 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0001601818-26-000010 Size: 6 KB
  - (2026-08-07) [BLACKBAUD INC] Form 4 (Issuer)
      filed 2026-08-07 20:20 UTC · role: Issuer — Filed: 2026-08-07 AccNo: 0001601818-26-000010 Size: 6 KB
  - (2026-08-07) [Leinwand Robert] Form 4 (Reporting)
      filed 2026-08-07 20:20 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0000320187-26-000109 Size: 6 KB
  - (2026-08-07) [NIKE, Inc.] Form 4 (Issuer)
      filed 2026-08-07 20:20 UTC · role: Issuer — Filed: 2026-08-07 AccNo: 0000320187-26-000109 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-07) [Indonesia] Sacred places & living lands : How Indigenous Sámi peoples steward biodiversity ( analysis )
      domain: news.mongabay.com · language: English · tone:
  - (2026-08-07) [United States] Stacey Abrams : GOP Intention Is to Dismantle Democracy for All of Us
      domain: breitbart.com · language: English · tone:
  - (2026-08-07) [United States] Colombia new president vows to remake the country and challenge rebel groups
      domain: wboi.org · language: English · tone:
  - (2026-08-07) [New Zealand] Wild at heart
      domain: odt.co.nz · language: English · tone:
  - (2026-08-07) [United States] White House ballroom construction ordered to stop , appeals court rules
      domain: wapt.com · language: English · tone:
  - (2026-08-07) [United States] GOP Midterm Convention Will Be an Anti - Socialism Hatefest
      domain: pjmedia.com · language: English · tone:

### GDACS — global disaster alerts — 38 new of 220 total
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0

### IT, InfoSys & cybersecurity news (last 7 days) — 37 new of 56 total
  - (2026-08-07) [BleepingComputer] Metabase SQLi zero-day exploited in customer data-theft attacks
      A critical Metabase SQL injection vulnerability was exploited in zero-day attacks to breach customer instances in data theft attacks, known to impact Framework and Tally. [...]
  - (2026-08-07) [BleepingComputer] Unlimited Technology Systems breach impacts 3.8 million people
      Healthcare software company Unlimited Technology Systems reported that more than 3.8 million people were impacted by a data breach incident that occurred in October 2025. [...]
  - (2026-08-07) [BleepingComputer] Levi Strauss & Co. says hackers stole corporate data in cyberattack
      Levi Strauss & Co. (Levi's) says that hackers used social engineering on three of its employees to gain access to and steal corporate data stored on their machines. [...]
  - (2026-08-07) [BleepingComputer] Real emails, hijacked payments: Two H1 2026 attack chains
      Gen's H1 2026 Threat Report examines two separate attack chains. One used compromised business inboxes and browser manipulation in a banking-malware campaign, while the other used clipboard hijacking to redirect cryptocu…
  - (2026-08-07) [BleepingComputer] North Carolina Ports confirms cyberattack disrupting operations
      The North Carolina Ports Authority has confirmed that a cyberattack disrupted IT systems and slowed operations at Port of Wilmington, Port of Morehead City, and Charlotte Inland Port. [...]
  - (2026-08-07) [The Hacker News] Nearly 800 Malicious npm Packages Deliver Cross-Platform RAT and Infostealer
      A cluster of nearly 800 malicious packages has been published to the npm registry as part of a new campaign designed to deliver cross-platform malware targeting Windows, Mac, and Linux systems. "These packages appear to…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 26 total
  - (2026-08-07) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (36.6076, -4.7455) · alt: 10668m · 835km/h
  - (2026-08-07) PAT085 (United States)
      icao24: adfedb · position: (10.4754, -75.4663) · alt: 1607m · 253km/h
  - (2026-08-07) PAT556 (United States)
      icao24: adfecf · position: (40.765, -122.0119) · alt: 3032m · 443km/h
  - (2026-08-07) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (40.1013, 0.3202) · alt: 10668m · 799km/h
  - (2026-08-07) PAT284 (United States)
      icao24: adfe95 · position: (37.9041, -85.9254) · alt: 1173m · 364km/h
  - (2026-08-07) RCH578 (United States)
      icao24: adfe88 · position: (39.3278, 24.5135) · alt: 6096m · 547km/h

### U.S. Federal Action — 21 new of 21 total
  - (2026-08-07) Protecting Against National Security Threats to the Communications Supply Chain Through the Equipment Authorization Program
      The Federal Communications Commission (Commission or FCC) issues a Third Further Notice of Proposed Rulemaking seeking comment on a broad set of additional measures to strengthen the security and integrity of its equipme…
  - (2026-08-07) Build America: Eliminating Barriers to Wireline Deployments
      In this document, the Federal Communications Commission (Commission) proposes and seeks comment on rules that would eliminate state and local requirements that constrain the deployment of modern high-speed wireline infra…
  - (2026-08-07) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action; Correction
      NMFS is correcting a temporary rule for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. The action added fishing dates in August and September in the…
  - (2026-08-07) Special Local Regulations; Annual Les Cheneaux Islands Antique Wooden Boat Show, Marquette Bay, Hessel, MI
      The Coast Guard will enforce the Annual Les Cheneaux Islands Antique Wooden Boat Show special local regulation on the U.S. navigable waters of Marquette Bay, Hessel, MI on August 8, 2026. This action is necessary to prov…
  - (2026-08-07) Revocation of Class E Airspace; Lake Geneva, WI
      This action revokes the Class E airspace at Lake Geneva, WI. This action is due to the instrument procedures being cancelled and the closure of the airport.
  - (2026-08-07) Amendment of Class D and Class E Airspace; Chicago/Rockford, IL
      This action amends the Class D and Class E airspace at Chicago/Rockford, IL. This action is due to a biennial airspace review conducted pursuant to FAA Order JO 7400.2R, Procedures for Handling Airspace Matters. This act…

### Paper Trading Scorecard — 20 new of 140 total
  - (2026-08-07) [Polymarket] Will Jude Bellingham win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-08-07) [Polymarket] Foreign intervention in Gaza by December 31?
      This market will resolve to "Yes" if police officers, security forces, or military personnel belonging to neither Israel nor a Palestinian entity begin an officially acknowledged police, military, peacekeeping, and/or se…
  - (2026-08-07) [Polymarket] Will NVIDIA be the largest company in the world by market cap on December 31?
      This market will resolve to the largest company in the world by market cap on December 31, 2026, as of market close. The resolution source for this market will be a consensus of credible reporting.
  - (2026-08-07) [Polymarket] Will Eduardo Bolsonaro finish in second place in the first round of the 2026 Brazilian presidential election?
      A presidential election is scheduled to take place in Brazil on October 4, 2026. This market will resolve according to the listed candidate who receives the second-most valid votes in the first round of this election. Th…
  - (2026-08-07) [Manifold] 🚢 Will Iran and Oman reach an agreement to reopen shipping through the Strait of Hormuz by August 31, 2026?
  - (2026-08-07) [Manifold] Free money for Opus 4.6

### Government Action: Sanctions + Procurement + Foreign Agents — 13 new of 102 total
  - (2026-08-07) [OFAC] Counter Terrorism and Iran-related Designations; Counter Narcotics Designations Removals; Issuance of Amended Iran-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Counter Terrorism and Iran-related Designations; Counter Narcotics Designations Removals; Issuance of Amended Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-07) [USASpending] $4,682,329,250 → RUSSIA SPACE AGENCY: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
      Agency: National Aeronautics and Space Administration. Description: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
  - (2026-08-07) [USASpending] $2,089,442,660 → BOLLINGER SHIPYARDS LOCKPORT, L.L.C.: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE U
      Agency: Department of Homeland Security. Description: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE UP TO TWENTY-SIX (26) FAST RESPONSE CUTTERS (FRCS) ON A FIRM FIXED PRICE (FFP) BASIS WITH AN ECONOMIC PRICE…
  - (2026-08-07) [USASpending] $1,186,157,198 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR
      Agency: General Services Administration. Description: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR THE USACE.
  - (2026-08-07) [USASpending] $1,175,671,370 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD
  - (2026-08-07) [USASpending] $942,267,915 → ACCENTURE FEDERAL SERVICES LLC: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOM
      Agency: Department of Education. Description: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE PLATFORMS AND SERVICES SOLUTION (ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE SOLUTION, AKA EWDCCPS, AKA DCC)…

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-08-07) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 36% · 24h volume: $545,624 · resolves 2026-09-16
  - (2026-08-07) LoL: Team Heretics vs Fnatic - Game 1 Winner
      yes price: 100% · 24h volume: $535,448 · resolves 2026-08-07
  - (2026-08-07) Fed rate hike in 2026?
      yes price: 55% · 24h volume: $515,197 · resolves 2026-12-09
  - (2026-08-07) LoL: Team Heretics vs Fnatic - Game 2 Winner
      yes price: 0% · 24h volume: $479,066 · resolves 2026-08-07
  - (2026-08-07) LoL: Team Heretics vs Fnatic (BO3) - LEC Regular Season
      yes price: 100% · 24h volume: $401,193 · resolves 2026-08-07
  - (2026-08-07) Iran leadership change by August 31?
      yes price: 4% · 24h volume: $238,066 · resolves 2026-08-31

### USGS earthquakes (M4.5+, past day) — 8 new of 9 total
  - (2026-08-07) M 5.1 - 6 km NNE of Xunchang, China
      M5.1 · 6 km NNE of Xunchang, China · depth 10 km
  - (2026-08-07) M 5.0 - 49 km SE of Severo-Kuril’sk, Russia
      M5.0 · 49 km SE of Severo-Kuril’sk, Russia · depth 83.854 km
  - (2026-08-07) M 5.0 - 7 km NW of Cabacao, Philippines
      M5.0 · 7 km NW of Cabacao, Philippines · depth 90.196 km
  - (2026-08-07) M 4.8 - 108 km NNW of Batang, Indonesia
      M4.8 · 108 km NNW of Batang, Indonesia · depth 534.964 km
  - (2026-08-07) M 4.6 - 51 km WSW of Sarangani, Philippines
      M4.6 · 51 km WSW of Sarangani, Philippines · depth 43.488 km
  - (2026-08-07) M 4.5 - 23 km ESE of Khandūd, Afghanistan
      M4.5 · 23 km ESE of Khandūd, Afghanistan · depth 10 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-07) [South Korea] Silver ARMY reshapes BTS fandom - The Korea Times
      koreatimes.co.kr · English
  - (2026-08-07) [South Korea] K - beauty has moved beyond the skincare aisle
      koreatimes.co.kr · English
  - (2026-08-07) [South Korea] 2026 Hangang River Festival : Summer
      koreabridge.net · English
  - (2026-08-07) [South Korea] Jungkook Sets New YouTube Music Record as Seven Surpasses 1 . 3 Billion Streams
      kpopstarz.com · English
  - (2026-08-07) [South Korea] Trump blasts progressive candidates as lunatic and communist ahead of midterms
      english.hani.co.kr · English
  - (2026-08-07) [South Korea] Samsung Electronics and SK Hynix unveil next - gen memory solutions in US
      english.hani.co.kr · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 40 total
  - (2026-08-07) #28 Germán Larrea Mota Velasco & family — $68.66B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-08-07) MOVER ▲ Jensen Huang — $193.34B (+$4.23B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-08-07) MOVER ▲ Jeff Bezos — $280.63B (+$1.96B since yesterday)
      United States · Technology · source: Amazon
  - (2026-08-07) MOVER ▼ Francoise Bettencourt Meyers & family — $95.38B ($-1.11B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-07) [Marginal Revolution] The Queen song ’39
      I only recently learned what it is really about, namely very rapid travel into space and time dilation mattering for the return voyage. I had never before listened carefully to the lyrics. I heard the “’39” reference at…
  - (2026-08-07) [Marginal Revolution] Friday assorted links
      1. Denmark fact of the day. 2. “Books that Tyler Cowen probably would like.” 3. The tenure dismissal of Sanjay Reddy (NYT). 4. Dell and Rambachan NBER video on the economics of AI. I have yet to view, but “self-recommend…
  - (2026-08-07) [Marginal Revolution] AI and Marginal Revolutions in Wastewater Treatment
      An interesting paper from French economists, including recent Nobelist Philippe Aghion, looks at the savings from a predictive machine-learning model applied to wastewater treatment: This paper studies the environmental…
  - (2026-08-07) [Conversable Economist] Growth Effects of AI: Modest for a Decade or Two, At Least
      It is of course impossible to predict the effects of new AI technologies on total economic growth in a precise way, but there are strong reasons to believe that the effect will be modest for a decade or two, anyway. Char…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 9 total
  - (2026-08-07) CVE-2026-8037 · Progress LoadMaster: Progress LoadMaster Command Injection Vulnerability
      vendor: Progress · product: LoadMaster · CISA remediation by 2026-08-10

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=20, 14d-median=20; carrying terms: proposing, action, rulemaking, program, notice, final, provide, certain, safety, order, proposed, proposes
- state_bills: today=129, 7d-median=118, 14d-median=118; carrying terms: standards, utilities, effective, business, environmental, procedures, operating, activities, alaska, apply, enforcement, provides
- state_news: today=961, 7d-median=758, 14d-median=766; carrying terms: failed, lincoln, justice, declined, americans, created, despite, nursing, organization, leader, capitol, enacted
- local_news: today=268, 7d-median=239, 14d-median=230; carrying terms: resize, decoding, including, emergency, fatal, figure, illinois, health, known, night, dining, uploads
- foreign_news: today=1092, 7d-median=1041, 14d-median=1032; carrying terms: later, today, feels, publicized, despite, platform, leader, mobile, block, bensebaa, structure, research
- chinese_internal: today=280, 7d-median=280, 14d-median=271; carrying terms: china, record, firms, stock, caixin, https, people, chinese, google, global, market, price
- russian_internal: today=1286, 7d-median=943, 14d-median=940; carrying terms: variety, europe, httperror, bloomberg, times, client, found, associated, financial, gazeta, novaya, istories
- ukrainian_internal: today=122, 7d-median=125, 14d-median=130; carrying terms: civilians, billion, today, despite, found, kyivindependent, ukraine, facilities, infrastructure, wildberries, dnipropetrovsk, intelligence
- ukraine_theater: today=238, 7d-median=639, 14d-median=633; carrying terms: polygon, coverage, frontline, known, httperror, active, polygons, deepstatemap, firms, client, https, liveuamap
- paper_bets: today=140, 7d-median=138, 14d-median=136; carrying terms: mayfield, lifetime, florida, kylian, rippling, washington, named, sachs, supervolcano, launch, humans, pirates
- weather: today=199, 7d-median=176, 14d-median=174; carrying terms: values, inches, lincoln, discussion, today, afdlox, texas, afddtx, arizona, basin, environmental, messages
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, dcoilwtico, funds, unrate, rates, assets, cpiaucsl, headline, jolts, energy, nonfarm, jtsjol
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, crypto, credit, proxy, rates, yield, nasdaq, close, natural, large, futures, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=102, 7d-median=102, 14d-median=103; carrying terms: transition, embargo, sevastopol, territorial, proliferation, stability, bosnia, threatening, guinea, islamic, libya, tunisia
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quiver, unauthorized, congresstrading, quiverquant, httperror, client, quantitative, error
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: mexico, ortega, adani, berkshire, jensen, spain, italy, holdings, peterffy, francoise, retail, trading
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: delaware, supreme, court, appeals, county, california, johnson, blanche, international, arizona, association, group
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, robert, michael, energy, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: shawn, talarico, platner, graham, raised, angels, sherrod, disbursements, receipts, congress, senate, cortez
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, korea, south
- gdelt_gkg: today=88, 7d-median=50, 14d-median=25; carrying terms: english, israel, hezbollah, trump, keywords, spanish, russian, themes, crisis, hormuz, italian, talks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: english, language, domain, iheart, india, kingdom, years, attack, against, russia
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=19, 14d-median=17; carrying terms: position, canada, belgium, france, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: mosquitoes, published, cause, across, viruses, diphtheria, known, province, spain, majority, government, marburg
- cisa_kev: today=9, 7d-median=9, 14d-median=10; carrying terms: vulnerability, product, unauthorized, velocloud, orchestrator, langflow, sensitive, fortios, remediation, injection, management, untrusted
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=220, 7d-median=233, 14d-median=265; carrying terms: minor, poland, sweden, mexico, cyclone, hurricane, spain, italy, marino, gabon, switzerland, typhoon
- usgs_quakes: today=9, 7d-median=14, 14d-median=18; carrying terms: depth, russia, philippines, indonesia, china, kuril, severo, zealand, argentina, sarangani
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, resolves, strait, august, normal, prime, effective, hormuz, returns, traffic, ceasefire
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: class, marginal, economist, revolution, https, conversable, conversableeconomist, marginalrevolution, links, assorted, college, future
- tech_news: today=56, 7d-median=56, 14d-median=57; carrying terms: today, despite, cyber, schneier, computer, right, people, provides, infrastructure, intelligence, artificial, edition
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: aguilar, bonamici, sheldon, emmer, tommy, waller, khanna, ruben, justice, maggie, cornyn, conaway
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, placed, evidence, module, placement, decision, consensus, identify, unavailable, paper, markets, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*