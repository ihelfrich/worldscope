# WORLDSCOPE morning brief — 2026-08-07

## Headline
3013 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (653) · Russian Internal News (state + in-exile) (553) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (314) · Chinese Internal News (189) · U.S. Weather + Severe / Climate Outlooks (165) · State Legislative Action (142) · State-Level News (141) · Local News: St. Louis + Atlanta (113) · GDELT GKG — themes / entities / watch areas (98) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 653 new of 1062 total
  - (2026-08-07) [Global] Meta fined $567m in largest child safety ruling against social media giant
      The ruling is in addition to $375m in fines Meta was already ordered to pay in the case, for a total of $942m.
  - (2026-08-07) [Global] US strikes $1.2bn deal to pay German firm to halt offshore wind projects
      The RWE payout is the latest in a string of deals cancelling wind energy projects, a power source long derided by Trump.
  - (2026-08-07) [Global] Trump imposes 15% tariff on key chip material to counter China
      The move aims to protect US firms as they face increasing competition from China's chip industry.
  - (2026-08-07) [Global] What do people want from Argos?
      As Sainsbury agrees to sell Argos for £120m, we ask people if they still shop there, and what the new owners can do to compete with big online retailers like Amazon.
  - (2026-08-07) [Global] Meta fined $567m in largest child safety ruling against social media giant
      The ruling is in addition to $375m in fines Meta was already ordered to pay in the case, for a total of $942m.
  - (2026-08-07) [Global] Saudi Arabia, Turkey and Pakistan sign defence pact
      Pakistan says an attack on any of the three will amount to an attack against all, amid conflict in the Middle East.

### Russian Internal News (state + in-exile) — 553 new of 1193 total
  - (2026-08-07) Турция, Саудовская Аравия и Пакистан подписали соглашение о коллективной обороне | LEDE: Турция, Саудовская Аравия и Пакистан подписали трехстороннее соглашение об обороне, сообщает турецкое] (ru: Тур…
      Турция, Саудовская Аравия и Пакистан подписали трехстороннее соглашение об обороне, сообщает турецкое агентство «Анадолу».
  - (2026-08-07) Бывшему директору Popcorn Books Дмитрию Протопопову назначили четыре года условно по делу о продаже квир-литературы | LEDE: Замоскворецкий суд Москвы назначил четыре года условно бывшему дир] (ru: Быв…
      Замоскворецкий суд Москвы назначил четыре года условно бывшему директору издательств Popcorn Books и Individuum Дмитрию Протопопову по уголовному делу об «ЛГБТ-экстремизме», сообщает «Медиазона».
  - (2026-08-07) ФСБ устроила облаву на криптообменники в «Москва-Сити» — через них якобы выводили деньги россиян в Украину. Задержаны больше 20 человек. Некоторые из них считали, что работают на ФСБ | LEDE: <p] (ru:…
      Сотрудники ФСБ задержали более 20 человек, работавших в криптообменниках в деловом комплексе «Москва-Сити». Спецслужба утверждает, что обменники были нелегальными и использовались мошенническими колл-центрами из Украины…
  - (2026-08-07) Секретное ИИ-устройство OpenAI — это умная колонка в форме пончика. Дизайн разработала компания Джони Айва. Вот что узнал Bloomberg об этом гаджете | LEDE: Источники агентства Bloomberg выяс] (ru: Сек…
      Источники агентства Bloomberg выяснили, как будет выглядеть загадочное ИИ-устройство, которое разрабатывает компания OpenAI. По их словам, оно будет представлять собой умную колонку в форме пончика. У пока что безымянног…
  - (2026-08-07) В Подмосковье выписали первый штраф за борщевик, который нашли с помощью ИИ | LEDE: В Московской области впервые назначили штраф из-за борщевика на участке, который обнаружили с помощью бесп] (ru: В П…
      В Московской области впервые назначили штраф из-за борщевика на участке, который обнаружили с помощью беспилотника и искусственного интеллекта, сообщили в министерстве сельского хозяйства региона.
  - (2026-08-07) Украина атаковала побережье Ялты морскими дронами | LEDE: ВСУ атаковали побережье Ялты морскими дронами, пишет украинский мониторинговый паблик Exilenova+. ] (ru: Украина атаковала побережье Ялты морс…
      ВСУ атаковали побережье Ялты морскими дронами, пишет украинский мониторинговый паблик Exilenova+.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 314 new of 819 total
  - (2026-08-07) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-06) [FIRMS] thermal anomaly 48.533, 34.642 (FRP 2.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 2.53 MW
  - (2026-08-06) [FIRMS] thermal anomaly 48.533, 34.647 (FRP 2.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 2.53 MW
  - (2026-08-06) [FIRMS] thermal anomaly 48.577, 34.050 (FRP 1.13 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 1.13 MW
  - (2026-08-06) [FIRMS] thermal anomaly 48.474, 34.631 (FRP 1.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 1.28 MW
  - (2026-08-06) [FIRMS] thermal anomaly 48.474, 34.629 (FRP 1.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-06 2324Z, FRP 1.76 MW

### Chinese Internal News — 189 new of 278 total
  - (2026-08-06) Exclusive: Chinese Supertankers Take Africa Detour to Avoid Red Sea Attacks - caixinglobal.com
      Exclusive: Chinese Supertankers Take Africa Detour to Avoid Red Sea Attacks caixinglobal.com
  - (2026-08-05) Exclusive: China Widens Tax Net to Offshore Insurance - caixinglobal.com
      Exclusive: China Widens Tax Net to Offshore Insurance caixinglobal.com
  - (2026-08-06) In Depth: Former Shanxi Richest Man Indicted on Mafia, Casino Charges - caixinglobal.com
      In Depth: Former Shanxi Richest Man Indicted on Mafia, Casino Charges caixinglobal.com
  - (2026-08-06) In Depth: Dangdai Founder Ai Luming Detained as Probe Into Debt Crisis Widens - caixinglobal.com
      In Depth: Dangdai Founder Ai Luming Detained as Probe Into Debt Crisis Widens caixinglobal.com
  - (2026-08-06) 影视 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1EOTY2WVNZMUoycjBwYklIR2o1d3ZwRFZFdzhFSTJxd3dkdXF2WlhFUGJHd3NWZTVjZ1F1b0MtZzl2emNIc1JTZGtaaEVvenhxdF] (zh:…
      影视 deepview.caixin.com
  - (2026-08-06) 湖北宜昌局部短时降雨128毫米 紧急转移近4000 人 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9JbURHMjFyQWhzTk55LTJYSWVJSWVsQW5rS1ZEMHRTRUFzcFJxalA0SllKc2l0UElaX1YzdGxlU2dfcHJfNG4xdVZFcn] (zh:…
      湖北宜昌局部短时降雨128毫米 紧急转移近4000 人 财新

### U.S. Weather + Severe / Climate Outlooks — 165 new of 196 total
  - (2026-08-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-07) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 7 at 7:11AM CDT until August 7 at 7:30AM CDT by NWS Grand Forks ND
      At 711 AM CDT, severe thunderstorms were located along a line extending from near Oshawa to near Sebeka, moving east at 20 mph. HAZARD...60 mph wind gusts and half dollar size hail. SOURCE...Radar indicated. IMPACT...Hai…
  - (2026-08-07) [Severe] Red Flag Warning: Red Flag Warning issued August 7 at 5:09AM PDT until August 8 at 11:00PM PDT by NWS Pendleton OR
      ...BREEZY WESTERLY WINDS AND LOW RELATIVE HUMIDITY TODAY AND SATURDAY THROUGH THE CASCADE GAPS AND INTO THE COLUMBIA BASIN... .Breezy westerly winds through the Cascade gaps will likely (80% chance) overlap with low rela…
  - (2026-08-07) [Severe] Red Flag Warning: Red Flag Warning issued August 7 at 5:09AM PDT until August 8 at 11:00PM PDT by NWS Pendleton OR
      ...BREEZY WESTERLY WINDS AND LOW RELATIVE HUMIDITY TODAY AND SATURDAY THROUGH THE CASCADE GAPS AND INTO THE COLUMBIA BASIN... .Breezy westerly winds through the Cascade gaps will likely (80% chance) overlap with low rela…
  - (2026-08-07) [Severe] Red Flag Warning: Red Flag Warning issued August 7 at 5:09AM PDT until August 8 at 11:00PM PDT by NWS Pendleton OR
      ...BREEZY WESTERLY WINDS AND LOW RELATIVE HUMIDITY TODAY AND SATURDAY THROUGH THE CASCADE GAPS AND INTO THE COLUMBIA BASIN... .Breezy westerly winds through the Cascade gaps will likely (80% chance) overlap with low rela…
  - (2026-08-07) [Moderate] Heat Advisory: Heat Advisory issued August 7 at 5:08AM PDT until August 7 at 10:00PM PDT by NWS Seattle WA
      * WHAT...Hot conditions with high temperatures up to 85 to 90 degrees expected. This will pose a moderate risk of heat-related illness. * WHERE...Portions of northwest and west central Washington. * WHEN...Until 10 PM PD…

### State Legislative Action — 142 new of 171 total
  - (2026-08-07) [Alaska SB 133] An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step…
      An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step therapy; and providing for an effec…
  - (2026-08-07) [Alaska SB 180] An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regul…
      An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regulatory Commission of Alaska; and prov…
  - (2026-08-06) [Alaska SB 227] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs; relating to the corporate income t…
  - (2026-08-07) [Arizona HB 2755] state land use; highest; best
      state land use; highest; best
  - (2026-08-07) [Arizona HB 2756] utilities; high load factor customers
      utilities; high load factor customers
  - (2026-08-06) [Arizona HB 2041] child neglect; financial resources; exception
      child neglect; financial resources; exception

### State-Level News — 141 new of 813 total
  - (2026-08-07) [California] Governor Newsom proclaims State of Emergency in Calaveras County for the Gann Fire response
      Source
  - (2026-08-07) [California] Governor Newsom announces appointments
      Source
  - (2026-08-07) [California] How a stronger voter ID law can alleviate doubts in California’s election system
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051926-Rancho-Cucamonga-WL-GETTY-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-08-07) [California] California’s voter ID ballot measure would add unnecessary barriers to a secure system
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/06/110123-Voters-Registration-Tulare-ZS-CM-102.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size w…
  - (2026-08-07) [California] Medicaid cuts stand to hit everyone (yes, even you). Here’s why
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/073007_MLK_HARBOR_HOSPITAL_GETTY_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-08-07) [California] Pension boosts for California police, firefighters could spur increases for other workers
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/080224_ParkFireCommandPost_FM_CM_31.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### Local News: St. Louis + Atlanta — 113 new of 240 total
  - (2026-08-07) [St. Louis] St. Louis man faces charges for using bear spray on visitors to PrideFest
      A St. Louis man faces criminal charges after police observed bear spray being used on a group of people during PrideFest in the Grove this past June. He also has pending felony cases for a different pair of assaults in t…
  - (2026-08-07) [St. Louis] Kirkwood renews contract with tech company despite questions about its role in $15.6M deficit
      The Kirkwood City Council OKed a nearly $332,000 one-year contract Thursday night with Tyler Technologies, despite complaints about the Texas-based firm’s role in the council not receiving regular financial reports for m…
  - (2026-08-07) [St. Louis] What’s True in the Lou? – 8/7/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-08-07) [St. Louis] Attorney General Hanaway says Missouri constitution doesn’t allow redistricting referendum
  - (2026-08-07) [St. Louis] Back-to-school sales tax holiday starts now in Missouri and Illinois. Here’s what’s eligible
  - (2026-08-07) [St. Louis] Childcare in Missouri is expensive and hard to find. Proposed laws could change that

### GDELT GKG — themes / entities / watch areas — 98 new of 98 total
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] Ukraine strikes more oil facilities deep inside Russia , Zelenskyy says
      messenger-inquirer.com · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] How the Russia – Ukraine War Is Reshaping Central Asia Geopolitical Balance
      timesca.com · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] Russia Turns to South Korea for Fuel as Refinery Crisis Deepens
      oilprice.com · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] Sweden to hand over seized Russian shadow fleet ship to Ukraine
      thelocal.se · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] Ed Miliband just went to war - and for once he on our side !
      aol.co.uk · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · keywords] UK Targets Ships and Banks with New Russia Sanctions
      english.aawsat.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-07) 485BXT - J.P. Morgan Exchange-Traded Fund Trust (0001485894) (Filer)
      filed 2026-08-07 12:21 UTC — Filed: 2026-08-07 AccNo: 0001193125-26-339244 Size: 54 KB
  - (2026-08-07) 485BXT - J.P. Morgan Exchange-Traded Fund Trust (0001485894) (Filer)
      filed 2026-08-07 12:21 UTC — Filed: 2026-08-07 AccNo: 0001193125-26-339244 Size: 54 KB
  - (2026-08-07) 497 - Tidal Trust I (0001742912) (Filer)
      filed 2026-08-07 12:19 UTC — Filed: 2026-08-07 AccNo: 0001999371-26-017278 Size: 36 KB
  - (2026-08-07) 425 - NEXTERA ENERGY INC (0000753308) (Filed by)
      filed 2026-08-07 12:16 UTC — Filed: 2026-08-07 AccNo: 0001104659-26-092381 Size: 20 KB
  - (2026-08-07) 425 - DOMINION ENERGY, INC (0000715957) (Subject)
      filed 2026-08-07 12:16 UTC — Filed: 2026-08-07 AccNo: 0001104659-26-092381 Size: 20 KB
  - (2026-08-07) [Schmid Christian Mathias] Form 4 (Reporting)
      filed 2026-08-07 12:03 UTC · role: Reporting — Filed: 2026-08-07 AccNo: 0002125050-26-000006 Size: 8 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-07) [United Kingdom] Ambleside peace campaigners remember Hiroshima bombing
      domain: nwemail.co.uk · language: English · tone:
  - (2026-08-07) [India] Punjab Transfers Amritsar Commissioner Gurpreet Singh Bhullar Amid Row Over Jantar Mantar Remarks
      domain: freepressjournal.in · language: English · tone:
  - (2026-08-07) [United States] Nude man who allegedly beat man to death in Lahaina faces multiple charges
      domain: kitv.com · language: English · tone:
  - (2026-08-07) [United States] Beyond the markets , Santa Fe galleries celebrate Native art
      domain: santafenewmexican.com · language: English · tone:
  - (2026-08-07) [United States] Woman Convicted Of Murdering Her Children Granted Retrial
      domain: veropatriot.iheart.com · language: English · tone:
  - (2026-08-07) [United States] Dear Annie : Missing my built - in best friend
      domain: dailyrepublic.com · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 39 new of 114 total
  - (2026-08-07) Є лише 6 хвилин на знищення пускових установок: Як протидіяти російській балістиці | LEDE: ] (uk: Є лише 6 хвилин на знищення пускових установок: Як протидіяти російській балісти)
  - (2026-08-07) У Литві чоловік намагався прорватися до Росії через закритий пункт пропуску | LEDE: На литовсько-російському кордоні стався інцидент на закритому прикордонному контрольно-пропускному пункті "Ні] (uk:…
      На литовсько-російському кордоні стався інцидент на закритому прикордонному контрольно-пропускному пункті "Ніда": чоловік на автомобілі протаранив шлагбаум, об'їхав "зуби дракона", а потім пішки перетнув державний кордон…
  - (2026-08-07) Зеленський обговорив з Драпатим кадрові питання в ЗСУ і посилення захисту на Донеччині | LEDE: Президент Зеленський і головнокомандувач ЗСУ Драпатий обговорили посилення оборони Донеччини та ка] (uk:…
      Президент Зеленський і головнокомандувач ЗСУ Драпатий обговорили посилення оборони Донеччини та кадрові питання в армії.
  - (2026-08-07) Франція попереджає, що не терпітиме спроб іноземного втручання у вибори | LEDE: Міністр закордонних справ Франції Жан-Ноель Барро попередив у п'ятницю, що Париж "не терпітиме жодних спроб інозе] (uk:…
      Міністр закордонних справ Франції Жан-Ноель Барро попередив у п'ятницю, що Париж "не терпітиме жодних спроб іноземного втручання".
  - (2026-08-07) Допомога для ВПО перетворилася на смугу перешкод, яку створила сама держава | LEDE: ВПО в Україні стикаються з бюрократією, затримками компенсацій і недостатньою державною підтримкою.] (uk: Допомога д…
      ВПО в Україні стикаються з бюрократією, затримками компенсацій і недостатньою державною підтримкою.
  - (2026-08-07) Welt: Дрон, який виявили біля українського літака в Лейпцигу, міг збити водій автобуса | LEDE: За однією з версії щодо інциденту в аеропорту "Лейпциг/Галле" дрон, який помітили над українським ] (uk:…
      За однією з версії щодо інциденту в аеропорту "Лейпциг/Галле" дрон, який помітили над українським літаком, міг збити водій автобуса.

### GDACS — global disaster alerts — 35 new of 215 total
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 27 new of 27 total
  - (2026-08-07) JAF50T (Bulgaria)
      icao24: 4520d0 · position: (41.1877, -2.758) · alt: 10675m · 810km/h
  - (2026-08-07) CFC3421 (Canada)
      icao24: c2c363 · position: (46.9962, -81.0957) · alt: 12192m · 854km/h
  - (2026-08-07) PAT914 (United States)
      icao24: adfe93 · position: (29.4852, -81.4588) · alt: 7010m · 509km/h
  - (2026-08-07) PAT991 (United States)
      icao24: adfec1 · position: (34.487, -78.9812) · alt: 12192m · 730km/h
  - (2026-08-07) SAMU44 (France)
      icao24: 39ca84 · position: (47.1335, -1.5799) · alt: 83m · 232km/h
  - (2026-08-07) JAF7AK (Belgium)
      icao24: 44d2b6 · position: (50.9007, 4.4874) · on ground

### Court opinions of consequence (federal & state) — 23 new of 60 total
  - (2026-08-11) Connecticut Supreme Court: LPP Mortgage Ltd. v. Underwood Towers Ltd. Partnership
  - (2026-08-11) Connecticut Supreme Court: LPP Mortgage Ltd. v. Underwood Towers Ltd. Partnership
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: Farrington v. Poole
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: Reyes v. City of New York
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: SEC V.
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: The Retail Property Trust v. Nassau Cnty. Dep't of Assessment

### U.S. Federal Action — 21 new of 21 total
  - (2026-08-07) Protecting Against National Security Threats to the Communications Supply Chain Through the Equipment Authorization Program
      The Federal Communications Commission (Commission or FCC) issues a Third Further Notice of Proposed Rulemaking seeking comment on a broad set of additional measures to strengthen the security and integrity of its equipme…
  - (2026-08-07) Build America: Eliminating Barriers to Wireline Deployments
      In this document, the Federal Communications Commission (Commission) proposes and seeks comment on rules that would eliminate state and local requirements that constrain the deployment of modern high-speed wireline infra…
  - (2026-08-07) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action; Correction
      NMFS is correcting a temporary rule for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. The action added fishing dates in August and September in the…
  - (2026-08-07) Special Local Regulations; Annual Les Cheneaux Islands Antique Wooden Boat Show, Marquette Bay, Hessel, MI
      The Coast Guard will enforce the Annual Les Cheneaux Islands Antique Wooden Boat Show special local regulation on the U.S. navigable waters of Marquette Bay, Hessel, MI on August 8, 2026. This action is necessary to prov…
  - (2026-08-07) Revocation of Class E Airspace; Lake Geneva, WI
      This action revokes the Class E airspace at Lake Geneva, WI. This action is due to the instrument procedures being cancelled and the closure of the airport.
  - (2026-08-07) Amendment of Class D and Class E Airspace; Chicago/Rockford, IL
      This action amends the Class D and Class E airspace at Chicago/Rockford, IL. This action is due to a biennial airspace review conducted pursuant to FAA Order JO 7400.2R, Procedures for Handling Airspace Matters. This act…

### IT, InfoSys & cybersecurity news (last 7 days) — 16 new of 56 total
  - (2026-08-07) [The Hacker News] Growing Up The Hard Way
      Open Source had a great childhood. For two decades it got to be a kid. It ran around barefoot, gave everything away, trusted strangers, and never once thought about who was watching. It ran the kind of lemonade stand tha…
  - (2026-08-07) [The Hacker News] 18-Year-Old Linux SCTP Flaw Could Let Local Users Gain Root and Escape Containers
      A use-after-free bug in Linux's SCTP networking code can be turned into full root on a host, and Tencent researchers say they used it to escape a container and reach the machine underneath. The flaw has existed since 200…
  - (2026-08-07) [The Hacker News] New NatJack Attacks Hijack TCP Sessions and Spoof DNS by Manipulating NAT Tables
      Security researcher Malcolm Stagg has disclosed a new attack class called NatJack that manipulates network address translation (NAT) connection state to hijack active TCP sessions, spoof DNS responses, expose mapped port…
  - (2026-08-07) [The Hacker News] Microsoft 365 AitM Phishing Hijacks Accounts to Collect Payroll and Finance Emails
      Cybersecurity researchers have called attention to an active "widespread email-driven phishing campaign" that employs adversary-in-the-middle (AitM) techniques to take control of Microsoft 365 accounts with an aim to ide…
  - (2026-08-07) [The Hacker News] AI-Assisted HTTP Terminator Finds Novel HTTP Desync Techniques and Apache Zero-Day
      PortSwigger says HTTP Terminator, an artificial intelligence (AI)-assisted research system built by James Kettle, generated and proved new HTTP desynchronization techniques after exploring 30,000 candidate desync vectors…
  - (2026-08-07) [The Record] French rugby club Stade Français restores systems after cyberattack, probes data leak
      The club said Thursday that it had already restored its IT environment from clean backups, allowing operations to continue normally. It added that its ticketing platform and online store were not affected and remain full…

### Paper Trading Scorecard — 13 new of 139 total
  - (2026-08-07) [Polymarket] Will Jude Bellingham win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-08-07) [Polymarket] Will Eduardo Bolsonaro finish in second place in the first round of the 2026 Brazilian presidential election?
      A presidential election is scheduled to take place in Brazil on October 4, 2026. This market will resolve according to the listed candidate who receives the second-most valid votes in the first round of this election. Th…
  - (2026-08-07) [Manifold] Democrats win 2028 Wisconsin Senate election?
  - (2026-08-07) [Manifold] Democrats win Texas, Michigan, Alaska and Maine for Senate in 2026?
  - (2026-08-07) [Manifold] Will China's total datacenter power capacity surpass the US before 2031?
  - (2026-08-07) [Manifold] Faster S&P 500 Crash than the Dotcom Bubble before 2030?

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 100 total
  - (2026-08-07) [USASpending] $4,682,329,250 → RUSSIA SPACE AGENCY: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
      Agency: National Aeronautics and Space Administration. Description: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
  - (2026-08-07) [USASpending] $2,089,442,660 → BOLLINGER SHIPYARDS LOCKPORT, L.L.C.: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE U
      Agency: Department of Homeland Security. Description: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE UP TO TWENTY-SIX (26) FAST RESPONSE CUTTERS (FRCS) ON A FIRM FIXED PRICE (FFP) BASIS WITH AN ECONOMIC PRICE…
  - (2026-08-07) [USASpending] $1,186,157,198 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR
      Agency: General Services Administration. Description: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR THE USACE.
  - (2026-08-07) [USASpending] $1,175,671,370 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD
  - (2026-08-07) [USASpending] $942,267,915 → ACCENTURE FEDERAL SERVICES LLC: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOM
      Agency: Department of Education. Description: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE PLATFORMS AND SERVICES SOLUTION (ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE SOLUTION, AKA EWDCCPS, AKA DCC)…
  - (2026-08-07) [USASpending] $931,286,481 → HII MISSION TECHNOLOGIES CORP: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED
      Agency: General Services Administration. Description: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED TO ALION SCIENCE AND TECHNOLOGY CORPORATION TO PROVIDE CONTRACTOR SUPPORT TO THE JOINT CAPABILITY EMBEDDE…

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-07) LoL: Team WE vs ThunderTalk Gaming (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $2,209,980 · resolves 2026-08-07
  - (2026-08-07) LoL: BNK FEARX vs HANJIN BRION - Game 1 Winner
      yes price: 0% · 24h volume: $1,177,316 · resolves 2026-08-07
  - (2026-08-07) LoL: Team WE vs ThunderTalk Gaming - Game 1 Winner
      yes price: 0% · 24h volume: $1,070,719 · resolves 2026-08-07
  - (2026-08-07) LoL: BNK FEARX vs HANJIN BRION - Game 2 Winner
      yes price: 0% · 24h volume: $907,373 · resolves 2026-08-07
  - (2026-08-07) LoL: Team WE vs ThunderTalk Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $876,982 · resolves 2026-08-07
  - (2026-08-07) LoL: KT Rolster vs Gen.G - Game 2 Winner
      yes price: 0% · 24h volume: $862,318 · resolves 2026-08-07

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 35 total
  - (2026-08-07) MOVER ▲ Amancio Ortega — $149.39B (+$0.43B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-07) MOVER ▼ Gautam Adani — $84.44B ($-0.25B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-08-07) MOVER ▼ Francoise Bettencourt Meyers & family — $96.48B ($-0.15B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-07) MOVER ▼ Bernard Arnault & family — $148.43B ($-0.11B since yesterday)
      France · Fashion & Retail · source: LVMH

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### USGS earthquakes (M4.5+, past day) — 3 new of 10 total
  - (2026-08-07) M 5.0 - 7 km NW of Cabacao, Philippines
      M5.0 · 7 km NW of Cabacao, Philippines · depth 90.196 km
  - (2026-08-07) M 4.6 - 51 km WSW of Sarangani, Philippines
      M4.6 · 51 km WSW of Sarangani, Philippines · depth 43.488 km
  - (2026-08-07) M 4.5 - 29 km S of Mendoza, Argentina
      M4.5 · 29 km S of Mendoza, Argentina · depth 10 km

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-07) [Marginal Revolution] AI and Marginal Revolutions in Wastewater Treatment
      An interesting paper from French economists, including recent Nobelist Philippe Aghion, looks at the savings from a predictive machine-learning model applied to wastewater treatment: This paper studies the environmental…
  - (2026-08-07) [Marginal Revolution] My excellent Conversation with Julia Ioffe
      Here is the audio, video, and transcript. Here is from the episode summary: Julia joined Tyler to discuss why so many of Russia’s great constructivist painters were women, why the tsarist government established women’s m…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=20, 14d-median=20; carrying terms: final, certain, action, safety, notice, order, proposes, rulemaking, provide, proposed, proposing, program
- state_bills: today=171, 7d-median=118, 14d-median=118; carrying terms: residential, activities, alaska, school, action, among, office, state, utilities, violation, person, specific
- state_news: today=813, 7d-median=758, 14d-median=766; carrying terms: criminal, across, biggest, nursing, nevada, speaking, alaska, consider, filed, report, grant, often
- local_news: today=240, 7d-median=239, 14d-median=230; carrying terms: report, accused, height, resize, person, buckhead, articles, fatal, local, vehicle, image, suspect
- foreign_news: today=1062, 7d-median=1041, 14d-median=1032; carrying terms: invasion, suggests, residential, bribes, banking, wardens, records, protective, plateau, times, money, action
- chinese_internal: today=278, 7d-median=278, 14d-median=271; carrying terms: google, global, people, chinese, record, https, caixin, firms, china, stock, market, price
- russian_internal: today=1193, 7d-median=943, 14d-median=940; carrying terms: title, found, telegram, insider, novaya, error, financial, group, times, europe, wildberries, novayagazeta
- ukrainian_internal: today=114, 7d-median=125, 14d-median=130; carrying terms: across, prime, russia, assault, struck, comes, curated, civilian, vechirniy, crimea, energy, attacks
- ukraine_theater: today=819, 7d-median=819, 14d-median=643; carrying terms: active, community, snapshot, client, extra, viirs, cartography, google, unauthorized, polygons, error, maintained
- paper_bets: today=139, 7d-median=138, 14d-median=136; carrying terms: russell, prime, experience, michigan, republican, source, token, transferable, artist, break, manifold, koivun
- weather: today=196, 7d-median=176, 14d-median=174; carrying terms: memphis, across, mostly, experience, warned, holly, afdilx, source, areas, activities, great, impacts
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: energy, jtsjol, dexchus, implied, treasury, crude, unrate, indicator, recession, cpiaucsl, unemployment, vixcls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: china, russell, bitcoin, treasury, crude, natural, large, range, credit, silver, equities, rates
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=100, 7d-median=102, 14d-median=103; carrying terms: bosnia, guatemala, recognition, russia, moldova, agency, production, enable, destabilisation, transnistrian, extra, prohibiting
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, unauthorized, congresstrading, client, quantitative, httperror, error, https, quiverquant
- billionaires: today=35, 7d-median=37, 14d-median=38; carrying terms: zhang, peterffy, tiktok, alice, adani, brokerage, tokyo, discount, giancarlo, source, huang, sergey
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: delaware, court, supreme, appeals, county, services, california, blanche, thomas, corporation, capital, connecticut
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, robert, group, energy, technologies
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: michael, james, ossoff, cortez, shawn, warner, david, cycle, pinkston, jonathan, angels, elect
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea, south, koreaherald
- gdelt_gkg: today=98, 7d-median=50, 14d-median=25; carrying terms: english, hezbollah, israel, netanyahu, trump, keywords, spanish, crisis, russian, chinese, themes, israeli
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: domain, english, language, iheart, kingdom, india
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=27, 7d-median=19, 14d-median=17; carrying terms: position, canada, belgium, france, ground, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: toxin, probable, public, clade, across, global, influenza, oecusse, cumulative, avian, source, municipality
- cisa_kev: today=8, 7d-median=9, 14d-median=10; carrying terms: unauthorized, deserialization, vendor, sensitive, arista, management, fortinet, actor, vulnerability, exposure, untrusted, authentication
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=215, 7d-median=233, 14d-median=265; carrying terms: bosnia, maximum, kazakhstan, hurricane, marshall, typhoon, poland, russia, czech, romania, agricultural, minor
- usgs_quakes: today=10, 7d-median=14, 14d-median=18; carrying terms: japan, depth, islands, russia, philippines, papua, guinea, zealand, argentina, sarangani, solomon, miyako
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, volume, prime, ceasefire, strait, august, hormuz, effective, traffic, normal, returns
- commentary: today=5, 7d-median=5, 14d-median=5; carrying terms: economist, marginal, revolution, https, class, conversable, government, marginalrevolution, college, market, economic, association
- tech_news: today=56, 7d-median=56, 14d-median=57; carrying terms: across, report, schneier, models, targeted, attacks, technica, third, despite, hacked, secure, health
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: harriet, deluzio, cuellar, cramer, topic, marshall, jimmy, maggie, babin, pettersen, clarence, sheldon
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, consensus, evidence, markets, unavailable, placed, sufficient, module, claude, identify, market, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*