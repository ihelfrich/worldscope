# WORLDSCOPE morning brief — 2026-08-07

## Headline
2320 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (465) · Russian Internal News (state + in-exile) (421) · World leaders & government officials (324) · State Legislative Action (206) · Chinese Internal News (177) · U.S. Weather + Severe / Climate Outlooks (157) · Local News: St. Louis + Atlanta (87) · GDELT GKG — themes / entities / watch areas (85) · Ukraine Theater (total-war monitoring) (81) · State-Level News (68) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (33)

## What changed today
### International News + Multilateral Institutions — 465 new of 1050 total
  - (2026-08-07) [Global] Colombia on the brink: ELN guerrilla group prepares for return to war
  - (2026-08-07) [Global] Thailand school shooting: seven killed including suspected attacker, police say
  - (2026-08-07) [Global] Attorney general warns women and children at risk of ‘harmful conduct’ from smartglasses users – as it happened
  - (2026-08-07) [Global] Alan Jones trial: complainant wants to ‘humiliate’ broadcaster by revealing intimate details of alleged assaults, defence tells court
  - (2026-08-07) [Global] Man dies after suspected dog attack at rural property in outer Sydney
  - (2026-08-07) [Global] Extreme heat breaks temperature records in central and eastern Europe

### Russian Internal News (state + in-exile) — 421 new of 1136 total
  - (2026-08-07) Песню Монеточки убрали из российской дублированной версии «Человека-паука». Неделю назад ее вырезали в украинском прокате | LEDE: Песню Монеточки «Монополия», которая звучит в саундтреке нов] (ru: Пес…
      Песню Монеточки «Монополия», которая звучит в саундтреке нового «Человека-паука», в российской версии фильма заменили треком Рианны, обратила внимание Ксения Собчак.
  - (2026-08-07) «Нам самим нужны». Трамп — о дополнительных ракетах Patriot для Украины | LEDE: Президент США Дональд Трамп прокомментировал публичные призывы президента Украины Владимира Зеленского передат] (ru: «На…
      Президент США Дональд Трамп прокомментировал публичные призывы президента Украины Владимира Зеленского передать Киеву дополнительные ракеты для комплексов Patriot.
  - (2026-08-07) Wildberries ввела страхование от атак беспилотников. Продавцы смогут получить до 50 тысяч рублей за уничтоженный товар | LEDE: С 7 августа 2026 года продавцы маркетплейса Wildberries смогут ] (ru: Wil…
      С 7 августа 2026 года продавцы маркетплейса Wildberries смогут застраховать заказанные товары от нового вида риска — повреждения или утраты из-за терактов, диверсий и атак беспилотников, а также их последствий.
  - (2026-08-07) В Таиланде ученик открыл стрельбу в школе и убил шесть человек. Еще 15 ранены | LEDE: В провинции Нонтхабури в Таиланде ученик открыл стрельбу в школе. Об этом сообщает Khaosod Online. ] (ru: В Таилан…
      В провинции Нонтхабури в Таиланде ученик открыл стрельбу в школе. Об этом сообщает Khaosod Online.
  - (2026-08-07) Партия «Яблоко» объявила, что не связана с оппозиционерами в изгнании, которые решили поддержать ее на выборах в Госдуму | LEDE: Партия «Яблоко» заявила, что не связана с оппозиционерами в э] (ru: Пар…
      Партия «Яблоко» заявила, что не связана с оппозиционерами в эмиграции, которые призвали поддержать ее на осенних выборах в Госдуму.
  - (2026-08-07) Трамп подписал указы, ограничивающие получение гражданства США по праву рождения и «родильный туризм» | LEDE: Дональд Трамп подписал два исполнительных указа, которые ограничивают получение ] (ru: Тра…
      Дональд Трамп подписал два исполнительных указа, которые ограничивают получение гражданства США по праву рождения.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State Legislative Action — 206 new of 240 total
  - (2026-08-07) [Alaska SB 133] An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step…
      An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step therapy; and providing for an effec…
  - (2026-08-07) [Alaska SB 180] An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regul…
      An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regulatory Commission of Alaska; and prov…
  - (2026-08-06) [Alaska SB 227] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs; relating to the corporate income t…
  - (2026-08-07) [Arizona HB 2755] state land use; highest; best
      state land use; highest; best
  - (2026-08-07) [Arizona HB 2756] utilities; high load factor customers
      utilities; high load factor customers
  - (2026-08-06) [Arizona HB 2041] child neglect; financial resources; exception
      child neglect; financial resources; exception

### Chinese Internal News — 177 new of 266 total
  - (2026-08-06) In Depth: Former Shanxi Richest Man Indicted on Mafia, Casino Charges - Caixin Global
      In Depth: Former Shanxi Richest Man Indicted on Mafia, Casino Charges Caixin Global
  - (2026-08-06) In Depth: Dangdai Founder Ai Luming Detained as Probe Into Debt Crisis Widens - Caixin Global
      In Depth: Dangdai Founder Ai Luming Detained as Probe Into Debt Crisis Widens Caixin Global
  - (2026-08-06) 组图：澳大利亚悉尼迎来观鲸季【2】 - 人民网澳新频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMid0FVX3lxTFBDaTVKbzVmdEhndk55cEYxUWhLYXFrc3pSdUc5ZFFxcGhZOUswS1VnZG0zVGp2ang0V2hVbGducU9KSkxDcTA5azF5bHZkV0p] (zh:…
      组图：澳大利亚悉尼迎来观鲸季【2】 人民网澳新频道
  - (2026-08-06) 江苏省“人工智能+金融”生态联盟正式成立 - js.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE8zYmdwaEFqemRnLWI0ZC1qQy1rVU1TTzAxN0hFNkN0b1QzS2pEbmwxMThQVUQwQWxHNEhzRXRYOGZaNHJkNFZ] (zh:…
      江苏省“人工智能+金融”生态联盟正式成立 js.people.com.cn
  - (2026-08-06) 绿意盈目 淮安绘就夏日生态长卷 - js.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5PLXZPbFE0dXJvZ1gzenpEZDNVRmZIZlJBX3otekw2STR2bGxqUEFVWVlwY1IzdUE1LTFBbjlaczBNQnYtYVIyeEpT] (zh:…
      绿意盈目 淮安绘就夏日生态长卷 js.people.com.cn
  - (2026-08-07) 每日一句丨祖辈留下的，不只是技法 - 人民网教育 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE0tRmNhd0E4LXF1akFTNDJuZjY3TmxrT2gxTDB0X2lVNWd4ajlVSTlpTVR4U2lfTHU5T3JvSDFZcVl6dDZRVHpFbzdnNFQyenJnc3] (zh:…
      每日一句丨祖辈留下的，不只是技法 人民网教育

### U.S. Weather + Severe / Climate Outlooks — 157 new of 201 total
  - (2026-08-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-07) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 7 at 2:59AM CDT until August 7 at 3:30AM CDT by NWS Amarillo TX
      At 259 AM CDT, a severe thunderstorm was located 7 miles northeast of Bushland, or 10 miles northwest of Amarillo, moving southeast at 25 mph. HAZARD...60 mph wind gusts and penny size hail. SOURCE...Radar indicated. IMP…
  - (2026-08-07) [Moderate] Special Weather Statement: Special Weather Statement issued August 7 at 2:58AM CDT by NWS Amarillo TX
      At 258 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from 11 miles north of Panhandle to 4 miles northwest of Bushland. Movement was southeast at 15 mph. HAZARD...Wind gusts of 50 to 55 m…
  - (2026-08-07) [Moderate] Special Weather Statement: Special Weather Statement issued August 7 at 3:58AM EDT by NWS Northern Indiana
      Areas of fog, locally dense in some spots, will continue in portions of northeastern Indiana, northwestern Ohio and far southern Lower Michigan with visibilities at times at or below 1/2 mile. If you are out driving toni…
  - (2026-08-07) [Moderate] Rip Current Statement: Rip Current Statement issued August 7 at 3:57AM EDT until August 8 at 8:00AM EDT by NWS Miami FL
      * WHAT...Dangerous rip currents. * WHERE...Coastal Palm Beach County, Coastal Broward County and Coastal Miami Dade County. * WHEN...Through Saturday morning. * IMPACTS...Rip currents can sweep even the best swimmers awa…
  - (2026-08-07) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued August 7 at 2:53AM CDT until August 7 at 9:00AM CDT by NWS Quad Cities IA IL
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Benton, Iowa, Linn, Buchanan, and Delaware Counties. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions haz…

### Local News: St. Louis + Atlanta — 87 new of 250 total
  - (2026-08-07) [St. Louis] What’s True in the Lou? – 8/7/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-08-07) [St. Louis] The Rewind: August 7
  - (2026-08-07) [St. Louis] The Rewind: August 7
      Webster Groves officials charged the city for strip clubs, pot store and Airbnb, audit says
  - (2026-08-07) [St. Louis] Lombard homers in Yankees debut
      Yankees shortstop George Lombard Jr. rounds the bases after his solo home run on Tuesday against the Cardinals.
  - (2026-08-07) [St. Louis] Lombard homers in Yankees debut
      MLB
  - (2026-08-07) [St. Louis] Page B5 eedition image

### GDELT GKG — themes / entities / watch areas — 85 new of 85 total
  - (2026-08-07) [Russia oil sanctions perimeter · themes] After centuries in India , the last Cochin Jews try to keep their history alive
      thepeterboroughexaminer.com · English · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] 岩手日報ONLINE
      iwate-np.co.jp · Japanese · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] DBH Kab . Batu Bara 2026 Tembus Rp43 , 51 Miliar , Penyalurannya Lampaui Rata - rata Nasional
      batam.tribunnews.com · Indonesian · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] لوفيغارو : الفخ الإيراني يشتد حول مضيق هرمز وأسنانه تنغلق على ترامب
      alquds.co.uk · Arabic · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] Για « υβριδικές απειλές » μιλάει η Γερμανία , « φωτογραφίζοντας » τη Ρωσία
      dnews.gr · Greek · tone NA
  - (2026-08-07) [Russia oil sanctions perimeter · themes] Los discursos presidenciales
      vanguardia.com · Spanish · tone NA

### Ukraine Theater (total-war monitoring) — 81 new of 238 total
  - (2026-08-07) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-06) [Liveuamap] Reuters, citing maritime security sources: The crew of the ship hit by a projectile in the Strait of Hormuz has abandoned it, and one sailor is missing. - iran.liveuamap.com
      Reuters, citing maritime security sources: The crew of the ship hit by a projectile in the Strait of Hormuz has abandoned it
  - (2026-08-04) [Liveuamap] Israeli airstrikes targeted Mansouri, Lebanon South Governorate, Lebanon - Lebanon news on live map - lebanon.liveuamap.com
      Israeli airstrikes targeted Mansouri, Lebanon South Governorate, Lebanon - Lebanon news on live map <fon
  - (2026-07-31) [Liveuamap] The Iranian Revolutionary Guard announces it targeted two tankers attempting to cross the Strait of Hormuz with US air support. - iran.liveuamap.com
      The Iranian Revolutionary Guard announces it targeted two tankers attempting to cross the Strait of Hormuz with
  - (2026-08-05) [Liveuamap] Ukraine - Liveuamap
      Ukraine Liveuamap
  - (2026-08-03) [Liveuamap] At South Slobozhansky(Kharkiv) direction clashes yesterday near Hoptivka, Nesterne, Pokalyane, Anyskyne, Lyman, Starytsya, - General Staff of Armed Forces of Ukraine reports - Liveuamap
      At South Slobozhansky(Kharkiv) direction clashes yesterday near Hoptivka, Nesterne, Pokalyane, Anyskyne, Lyman, Starytsya, - Gene

### State-Level News — 68 new of 755 total
  - (2026-08-07) [California] Governor Newsom proclaims State of Emergency in Calaveras County for the Gann Fire response
      Source
  - (2026-08-07) [California] Governor Newsom announces appointments
      Source
  - (2026-08-07) [Connecticut] A reality check for CT’s housing market
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/04/CT-Public-housing-construction-1024x683.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async…
  - (2026-08-07) [Connecticut] As a new school year begins, let’s put children’s mental health first
      <img width="937" height="580" src="https://ctmirror.org/wp-content/uploads/2026/07/back-to-school.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctmirror.…
  - (2026-08-07) [Delaware] Delaware enshrines civil rights voting protections
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/08/Voting-Rights-Act-signing-web.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-08-07) [Delaware] Don’t let fraudsters and scammers ground your summer vacation this year
      <img width="1024" height="568" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/08/Chase_Vacation-Scams_CNP-July-2026-summer-travel3_crop.png?fit=1024%2C568&ssl=1" class="attachment-rss-image-size siz…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-07) [Liftoff Mobile, Inc.] Form 4 (Issuer)
      filed 2026-08-07 01:59 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001628280-26-054546 Size: 5 KB
  - (2026-08-07) [RAFAEL BETSY] Form 4 (Reporting)
      filed 2026-08-07 01:59 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001628280-26-054546 Size: 5 KB
  - (2026-08-07) [Liftoff Mobile, Inc.] Form 4 (Issuer)
      filed 2026-08-07 01:58 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001628280-26-054545 Size: 5 KB
  - (2026-08-07) [Habiger David C] Form 4 (Reporting)
      filed 2026-08-07 01:58 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001628280-26-054545 Size: 5 KB
  - (2026-08-07) [Goldman Simon Robert] Form 4 (Reporting)
      filed 2026-08-07 01:58 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001628280-26-054544 Size: 5 KB
  - (2026-08-07) [Liftoff Mobile, Inc.] Form 4 (Issuer)
      filed 2026-08-07 01:58 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001628280-26-054544 Size: 5 KB

### Ukrainian Internal News (national + local Kyiv) — 33 new of 109 total
  - (2026-08-07) Екскерівників Мукачівського ТЦК затримали у справі про незаконне "списання" військовозобов'язаних | LEDE: Правоохоронці розкрили схему виключення 1577 чоловіків з військового обліку в Мукачеві.] (uk:…
      Правоохоронці розкрили схему виключення 1577 чоловіків з військового обліку в Мукачеві. Затримано двох посадовців.
  - (2026-08-07) До Європи із Prozorro: як Україна входить до єдиного ринку публічних закупівель ЄС | LEDE: ] (uk: До Європи із Prozorro: як Україна входить до єдиного ринку публічних закупівель )
  - (2026-08-07) Поляки невдоволені реакцією влади на інцидент з російською ракетою на Люблінщині | LEDE: Майже 38% поляків негативно оцінюють дії держави після того, як на території країни впала російська раке] (uk:…
      Майже 38% поляків негативно оцінюють дії держави після того, як на території країни впала російська ракета.
  - (2026-08-07) Розвідка США вважає, що Росія може напасти на НАТО ще до закінчення війни в Україні – WSJ | LEDE: Американська розвідка переконана, що глава РФ Володимир Путін може спробувати перевірити рішучі] (uk:…
      Американська розвідка переконана, що глава РФ Володимир Путін може спробувати перевірити рішучість НАТО уже в найближчі роки, завдавши удару по одній із країн-членів Альянсу.
  - (2026-08-07) Українці вважають, що війна триватиме у 2027 році, але понад 60% готові терпіти, скільки потрібно – КМІС | LEDE: 45% українців очікують завершення війни не раніше другої половини 2027 року – оп] (uk:…
      45% українців очікують завершення війни не раніше другої половини 2027 року – опитування КМІС.
  - (2026-08-07) ГУР заявило про знищення в окупованому Криму російського "Панцира-С1" за $15 мільйонів | LEDE: Головне управління розвідки повідомило, що на початку серпня його спецпідрозділ Group 13 знищив у ] (uk:…
      Головне управління розвідки повідомило, що на початку серпня його спецпідрозділ Group 13 знищив у тимчасово окупованому Криму російський зенітний ракетно-гарматний комплекс "Панцир-С1" та військовий кран.

### GDACS — global disaster alerts — 33 new of 213 total
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-07-25) [Red] Flood in China
      Flood · Red alert · China · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 22 new of 22 total
  - (2026-08-07) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (40.8638, -3.7858) · alt: 11582m · 904km/h
  - (2026-08-07) JAF76T (Bulgaria)
      icao24: 4520aa · position: (48.7288, 2.3542) · on ground · 18km/h
  - (2026-08-07) JEDI57 (France)
      icao24: 39a842 · position: (45.5881, -0.4194) · alt: 502m · 182km/h
  - (2026-08-07) PUMA45 (Slovenia)
      icao24: 506e1f · position: (45.8827, 15.5337) · alt: 426m · 185km/h
  - (2026-08-07) RFF02 (Portugal)
      icao24: 496ca4 · position: (37.0181, -7.9752) · on ground · 31km/h
  - (2026-08-07) JAF63N (Belgium)
      icao24: 44d1ba · position: (43.522, 1.4023) · alt: 10972m · 817km/h

### U.S. Federal Action — 21 new of 21 total
  - (2026-08-07) Protecting Against National Security Threats to the Communications Supply Chain Through the Equipment Authorization Program
      The Federal Communications Commission (Commission or FCC) issues a Third Further Notice of Proposed Rulemaking seeking comment on a broad set of additional measures to strengthen the security and integrity of its equipme…
  - (2026-08-07) Build America: Eliminating Barriers to Wireline Deployments
      In this document, the Federal Communications Commission (Commission) proposes and seeks comment on rules that would eliminate state and local requirements that constrain the deployment of modern high-speed wireline infra…
  - (2026-08-07) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action; Correction
      NMFS is correcting a temporary rule for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. The action added fishing dates in August and September in the…
  - (2026-08-07) Special Local Regulations; Annual Les Cheneaux Islands Antique Wooden Boat Show, Marquette Bay, Hessel, MI
      The Coast Guard will enforce the Annual Les Cheneaux Islands Antique Wooden Boat Show special local regulation on the U.S. navigable waters of Marquette Bay, Hessel, MI on August 8, 2026. This action is necessary to prov…
  - (2026-08-07) Revocation of Class E Airspace; Lake Geneva, WI
      This action revokes the Class E airspace at Lake Geneva, WI. This action is due to the instrument procedures being cancelled and the closure of the airport.
  - (2026-08-07) Amendment of Class D and Class E Airspace; Chicago/Rockford, IL
      This action amends the Class D and Class E airspace at Chicago/Rockford, IL. This action is due to a biennial airspace review conducted pursuant to FAA Order JO 7400.2R, Procedures for Handling Airspace Matters. This act…

### Court opinions of consequence (federal & state) — 18 new of 60 total
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: Farrington v. Poole
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: Reyes v. City of New York
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: SEC V.
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: The Retail Property Trust v. Nassau Cnty. Dep't of Assessment
  - (2026-08-06) U.S. Court of Appeals, 2nd Cir.: United States v. Browning
  - (2026-08-06) U.S. Court of Appeals, 5th Cir.: Adler v. Energy Debt Holdings

### Paper Trading Scorecard — 13 new of 142 total
  - (2026-08-07) [Polymarket] US-Iran Final Nuclear Deal by August 13, 2026?
      On June 14, 2026, the United States and Iran announced a written diplomatic agreement, including a 60-day extendable period in which both countries committed to negotiate toward a “final deal” regarding Iran’s nuclear pr…
  - (2026-08-07) [Polymarket] Will Jude Bellingham win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-08-07) [Polymarket] Bitcoin Up or Down on August 7?
      This market will resolve to "Up" if the "Close" price for the Binance 1 minute candle for BTC/USDT Aug 6 '26 12:00 in the ET timezone (noon) is lower than the final "Close" price for the Aug 7 '26 12:00 ET candle. This m…
  - (2026-08-07) [Polymarket] Will Eduardo Bolsonaro finish in second place in the first round of the 2026 Brazilian presidential election?
      A presidential election is scheduled to take place in Brazil on October 4, 2026. This market will resolve according to the listed candidate who receives the second-most valid votes in the first round of this election. Th…
  - (2026-08-07) [Manifold] Will China's total datacenter power capacity surpass the US before 2031?
  - (2026-08-07) [Manifold] Faster S&P 500 Crash than the Dotcom Bubble before 2030?

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 100 total
  - (2026-08-07) [USASpending] $4,682,329,250 → RUSSIA SPACE AGENCY: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
      Agency: National Aeronautics and Space Administration. Description: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
  - (2026-08-07) [USASpending] $2,089,442,660 → BOLLINGER SHIPYARDS LOCKPORT, L.L.C.: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE U
      Agency: Department of Homeland Security. Description: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE UP TO TWENTY-SIX (26) FAST RESPONSE CUTTERS (FRCS) ON A FIRM FIXED PRICE (FFP) BASIS WITH AN ECONOMIC PRICE…
  - (2026-08-07) [USASpending] $1,186,157,198 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR
      Agency: General Services Administration. Description: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR THE USACE.
  - (2026-08-07) [USASpending] $1,175,671,370 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD
  - (2026-08-07) [USASpending] $942,267,915 → ACCENTURE FEDERAL SERVICES LLC: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOM
      Agency: Department of Education. Description: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE PLATFORMS AND SERVICES SOLUTION (ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE SOLUTION, AKA EWDCCPS, AKA DCC)…
  - (2026-08-07) [USASpending] $931,286,481 → HII MISSION TECHNOLOGIES CORP: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED
      Agency: General Services Administration. Description: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED TO ALION SCIENCE AND TECHNOLOGY CORPORATION TO PROVIDE CONTRACTOR SUPPORT TO THE JOINT CAPABILITY EMBEDDE…

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-08-07) LoL: JD Gaming vs EDward Gaming (BO3) - LPL Group Ascend
      yes price: 92% · 24h volume: $805,303 · resolves 2026-08-07
  - (2026-08-07) LoL: JD Gaming vs EDward Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $470,060 · resolves 2026-08-07
  - (2026-08-07) Will the Iranian regime fall before 2027?
      yes price: 6% · 24h volume: $314,266 · resolves 2026-12-31
  - (2026-08-07) LoL: KT Rolster vs Gen.G (BO3) - LCK Round 3-4 Legend Group
      yes price: 21% · 24h volume: $244,762 · resolves 2026-08-07
  - (2026-08-07) Israel x Iran ceasefire continues through August 9?
      yes price: 97% · 24h volume: $206,712 · resolves 2026-08-09
  - (2026-08-07) Will the price of Bitcoin be above $60,000 on August 7?
      yes price: 100% · 24h volume: $200,838 · resolves 2026-08-07

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 38 total
  - (2026-08-07) MOVER ▼ Masayoshi Son — $67.41B ($-1.60B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-08-07) MOVER ▲ Francoise Bettencourt Meyers & family — $97.09B (+$0.60B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-07) MOVER ▲ Bernard Arnault & family — $149.41B (+$0.59B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-07) MOVER ▲ Tadashi Yanai & family — $68.48B (+$0.32B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-08-07) MOVER ▲ Amancio Ortega — $149.34B (+$0.29B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-07) MOVER ▲ Gautam Adani — $84.86B (+$0.10B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### IT, InfoSys & cybersecurity news (last 7 days) — 6 new of 56 total
  - (2026-08-07) [The Hacker News] TeamPCP Linked To Redis Attacks Dating Back To 2020 And Later Supply Chain Campaign
      A new analysis has uncovered that the threat actor tracked as TeamPCP has been active on the cybercrime scene as far back as 2020, indicating the group has been compromising internet-facing infrastructure for years befor…
  - (2026-08-07) [The Register] Sysadmin summoned to explain italics – to a user with at least two degrees
      What an idiot
  - (2026-08-07) [The Register] China launches mysterious probe into security of Palo Alto Networks' products
      Beijing’s not saying why, which is just what happened when it investigated Micron
  - (2026-08-07) [The Register] ‘Humans will be a rounding error on the internet’ says Cloudflare exec
      Machine-generated traffic to surge 1000x in five years, while we meatbags keep clicking away slowly
  - (2026-08-06) [The Register] How the famed USENIX Security conf is managing a flood of papers in the AI era
      AI usage is evident but isn't yet a serious problem
  - (2026-08-06) [Ars Technica] Organ donation group accused of trying to take living man's organs faces shutdown
      The organization, Network for Hope, "strongly disagrees" with Trump admin's decision.

### USGS earthquakes (M4.5+, past day) — 2 new of 11 total
  - (2026-08-07) M 5.0 - 7 km NW of Cabacao, Philippines
      M5.0 · 7 km NW of Cabacao, Philippines · depth 90.196 km
  - (2026-08-07) M 4.5 - 29 km S of Mendoza, Argentina
      M4.5 · 29 km S of Mendoza, Argentina · depth 10 km

### Commentary & analysis (last 7 days) — 1 new of 5 total
  - (2026-08-07) [Marginal Revolution] My excellent Conversation with Julia Ioffe
      Here is the audio, video, and transcript. Here is from the episode summary: Julia joined Tyler to discuss why so many of Russia’s great constructivist painters were women, why the tsarist government established women’s m…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=20, 14d-median=20; carrying terms: final, notice, safety, order, certain, action, proposing, proposed, program, rulemaking, proposes, provide
- state_bills: today=240, 7d-median=118, 14d-median=118; carrying terms: required, legal, operating, income, support, projects, business, based, certain, makes, action, approval
- state_news: today=755, 7d-median=755, 14d-median=755; carrying terms: fight, nevada, population, wisconsin, together, notes, sunday, awards, income, responses, technology, support
- local_news: today=250, 7d-median=239, 14d-median=229; carrying terms: mother, multiple, resize, morning, murder, woman, appeared, according, stlmag, content, accused, figure
- foreign_news: today=1050, 7d-median=1041, 14d-median=1022; carrying terms: fight, southwest, having, hangzhou, windshield, loans, mother, harbin, technologies, pushes, union, problem
- chinese_internal: today=266, 7d-median=266, 14d-median=266; carrying terms: https, china, firms, google, chinese, record, people, caixin, global, price, stock, market
- russian_internal: today=1136, 7d-median=943, 14d-median=937; carrying terms: group, found, novaya, axios, press, associated, patriot, httperror, https, gazeta, title, reuters
- ukrainian_internal: today=109, 7d-median=125, 14d-median=131; carrying terms: battlefield, whether, authorities, injuring, today, struck, support, regional, international, warehouses, washington, second
- ukraine_theater: today=238, 7d-median=639, 14d-median=627; carrying terms: firms, token, cartography, extra, client, viirs, maintained, error, alerts, httperror, deepstatemap, known
- paper_bets: today=142, 7d-median=138, 14d-median=138; carrying terms: predictit, population, wisconsin, general, speed, georgia, scheduled, arizona, verve, token, official, humanoid
- weather: today=201, 7d-median=176, 14d-median=175; carrying terms: southwest, afdmeg, cyclone, values, afdmtr, strong, begin, today, sunday, tropical, warned, severe
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unemployment, latest, openings, growth, assets, indicator, inflation, cpilfesl, sheet, consumption, recession, treasury
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, bitcoin, yield, futures, nasdaq, proxy, close, range, treasury, corporate, russell, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=100, 7d-median=102, 14d-median=104; carrying terms: federation, recognition, authorities, sanctions, operating, prohibited, production, technologies, proliferation, resolutions, unauthorised, jihad
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, client, congresstrading, error, quantitative, https, httperror, unauthorized, quiverquant
- billionaires: today=38, 7d-median=38, 14d-median=38; carrying terms: arnault, ellison, bettencourt, trading, bezos, gcarsoa, bloomberg, amancio, devasini, paris, discount, mukesh
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, county, services, delaware, court, supreme, blanche, thomas, group, holdings, corporation, state
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, holdings, robert, michael, david, bancorp, capital
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cortez, ocasio, james, house, alexandria, booker, warner, raised, sherrod, shawn, trone
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea, south, koreaherald
- gdelt_gkg: today=85, 7d-median=50, 14d-median=36; carrying terms: english, hezbollah, israel, trump, keywords, netanyahu, spanish, chinese, russian, themes, israeli, italian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=19, 14d-median=16; carrying terms: position, belgium, france, ground, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: borne, generation, increases, rwampara, general, avian, elements, saudi, measles, coronavirus, regions, authorities
- cisa_kev: today=8, 7d-median=9, 14d-median=10; carrying terms: product, management, deserialization, command, remediation, fortinet, langflow, untrusted, authentication, vulnerability, vendor, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=213, 7d-median=233, 14d-median=261; carrying terms: russia, ethiopia, bulgaria, kenya, brazil, orange, drought, gabon, cyclone, speed, wildfire, republic
- usgs_quakes: today=11, 7d-median=14, 14d-median=17; carrying terms: depth, japan, islands, russia, philippines, papua, guinea, argentina, zealand, solomon, miyako
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, resolves, hormuz, ceasefire, returns, prime, normal, strait, august, traffic, ethiopia
- commentary: today=5, 7d-median=5, 14d-median=5; carrying terms: revolution, marginal, economist, class, conversable, https, government, marginalrevolution, links, assorted, college, market
- tech_news: today=56, 7d-median=56, 14d-median=57; carrying terms: hackers, today, technology, artificial, daily, targeted, https, spectrum, hacker, download, infrastructure, third
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: deposit, schneider, mccollum, cantwell, stefanik, ocasio, jamie, sylvia, salazar, jeffries, gorsuch, composite
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, placement, claude, module, consensus, identify, either, paper, evidence, decision, market, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*