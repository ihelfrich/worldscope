# WORLDSCOPE morning brief — 2026-11-07

## Headline
2944 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (713) · Russian Internal News (state + in-exile) (530) · World leaders & government officials (324) · State-Level News (261) · Chinese Internal News (220) · Local News: St. Louis + Atlanta (205) · State Legislative Action (149) · U.S. Weather + Severe / Climate Outlooks (101) · Ukraine Theater (total-war monitoring) (86) · Ukrainian Internal News (national + local Kyiv) (63) · GDACS — global disaster alerts (55) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 713 new of 989 total
  - (2026-11-06) [Global] Kenyan doomsday sect leader jailed for 200 years for murder of 190 children
  - (2026-11-07) [Global] Ousted Paraguay president under house arrest after banking crisis leaves 60% of country unable to access accounts
  - (2026-11-06) [Global] Sebastián Lelio, director of A Fantastic Woman and Gloria, dies aged 52
  - (2026-11-07) [Global] New Zealand election 2026 live results: National and Labour neck-and-neck as minor party eyes kingmaker role
  - (2026-11-06) [Global] Global stocks fall amid ‘big worries over AI’ after Democrats’ midterms triumph
  - (2026-11-07) [Global] What’s the point? Ten years after the Paris treaty, are climate talks getting anywhere?

### Russian Internal News (state + in-exile) — 530 new of 946 total
  - (2026-11-07) Окунитесь в школьные реалии военного времени в России: со сборами гуманитарки и денег для фронта и хронически уставшими учителями. Почитайте отрывок из романа «Киру всё заебало» Сергея Лебеденк] (ru:…
      В издательстве «Медузы» вышел роман журналиста, писателя и книжного блогера (телеграм-канал «Книгижарь») Сергея Лебеденко «Киру всё заебало» — об учительнице истории из маленького российского города, которая верит в патр…
  - (2026-11-07) «Лето в Бадене» — роман советского патологоанатома Леонида Цыпкина о Федоре и Анне Достоевских, по которому вышел фильм. Сьюзен Зонтаг говорила, что книги достаточно, чтобы понять русскую литер] (ru:…
      5 ноября в российский прокат вышел фильм журналиста Антона Желнова «Лето в Бадене» (соавтор сценария — Юрий Сапрыкин) — экранизация одноименного романа Леонида Цыпкина, впервые опубликованного в тамиздате в 1982 году. Те…
  - (2026-11-07) Европейские спецслужбы проверят причастность России к сообщениям о минированиях, которые получили авиакомпании в Европе | LEDE: Европейские службы безопасности выясняют причастность России к] (ru: Евр…
      Европейские службы безопасности выясняют причастность России к массовой рассылке предупреждений о минировании, которые на этой неделе получили авиакомпании в Европе, пишет Financial Times.
  - (2026-11-07) Умерла Лидия Федосеева-Шукшина | LEDE: Советская и российская актриса Лидия Федосеева-Шукшина умерла в возрасте 88 лет. О ее смерти 7 ноября сообщила ТАСС дочь артистки. ] (ru: Умерла Лидия Федосеева-…
      Советская и российская актриса Лидия Федосеева-Шукшина умерла в возрасте 88 лет. О ее смерти 7 ноября сообщила ТАСС дочь артистки.
  - (2026-11-07) В Иркутской области шаман собирается принести в жертву 60 верблюдов. Он надеется, что это поможет России выиграть войну. «Люди Байкала» рассказали, как на это реагируют защитники животных и дру] (ru:…
      Шаман Артур Цыбиков из Ангарска Иркутской области, которого недавно объявили верховным шаманом России, собирается устроить массовое жертвоприношение и в течение года, начиная с ноября 2026-го, убить 60 верблюдов. Он уже…
  - (2026-11-07) Сенат Парагвая объявил импичмент президенту, его отправили под домашний арест. Он ушел в отставку после краха банка, обслуживавшего большинство жителей страны | LEDE: Сенат Парагвая 6 ноября] (ru: Сен…
      Сенат Парагвая 6 ноября объявил импичмент президенту Сантьяго Пенье, сообщает Associated Press.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 261 new of 675 total
  - (2026-11-07) [California] Governor Newsom announces appointments 11.6.26
      Source
  - (2026-11-06) [California] Governor Newsom honors fallen Los Angeles Police Department Officer Denton
      Source
  - (2026-11-06) [California] California and tribal leaders celebrate opening of first phase of California Indian Heritage Center
      Source
  - (2026-11-06) [California] Governor Newsom proclaims Native American Heritage Month 2026
      Source
  - (2026-11-06) [Alabama] Governor Ivey Announces Alabama’s Opportunity Zones 2.0 Nominations Approved by U.S. Treasury, IRS
      MONTGOMERY – Governor Kay Ivey on Friday announced that Alabama’s Opportunity Zones 2.0 nominations have been approved by the U.S. Treasury Department and Internal Revenue Service. The Opportunity Zones Program encourage…
  - (2026-11-06) [Alabama] Governor Ivey Introduces a CHOOSE Act Family: Meet the Washington Family
      MONTGOMERY – Governor Kay Ivey on Friday introduced the Washingtons, an Alabama family utilizing the CHOOSE Act, the governor’s education savings account (ESA) program. Shalice Washington is a U.S. veteran, full-time stu…

### Chinese Internal News — 220 new of 334 total
  - (2026-11-06) China’s Overseas Funds Slide as U.S. Stock ETF Premiums Surge - Caixin Global
      China’s Overseas Funds Slide as U.S. Stock ETF Premiums Surge Caixin Global
  - (2026-11-06) China’s 10-Year Government Bond Yield Hits Record Low - Caixin Global
      China’s 10-Year Government Bond Yield Hits Record Low Caixin Global
  - (2026-11-06) Cover Story: The Global Tech Sell-Off Tests the Economics Behind AI Boom - Caixin Global
      Cover Story: The Global Tech Sell-Off Tests the Economics Behind AI Boom Caixin Global
  - (2026-11-06) The Week Ahead (Nov. 9-15): Climate Summit Opens, Ukraine Talks Begin - Caixin Global
      The Week Ahead (Nov. 9-15): Climate Summit Opens, Ukraine Talks Begin Caixin Global
  - (2026-11-06) Coach Owner Tapestry Posts Strong China Growth Amid Luxury Market Weakness - Caixin Global
      Coach Owner Tapestry Posts Strong China Growth Amid Luxury Market Weakness Caixin Global
  - (2026-11-06) Guangzhou Proposes Easing Developers’ Infrastructure Obligations - Caixin Global
      Guangzhou Proposes Easing Developers’ Infrastructure Obligations Caixin Global

### Local News: St. Louis + Atlanta — 205 new of 265 total
  - (2026-11-06) [St. Louis] Lawsuit accuses Jim Onder of sex harassment, violating the law to push Ferguson data center
      A former employee is suing Jim Onder of OnderLaw, accusing him of sexual harassment, racially offensive comments, and breaking the law to push forward the data center he wants to build in Ferguson. The woman, identified…
  - (2026-11-06) [St. Louis] Ask George: Which Halloween candies taste better frozen?
      After recently wrestling with a full-size Snickers bar frozen to 5 degrees Fahrenheit, I put the next one in the refrigerator and discovered that colder isn’t always better. Chilled, the caramel and nougat no longer thre…
  - (2026-11-05) [St. Louis] Photos: St. Louis Supper Club at Sidney Street Cafe
      On November 2, 2026, St. Louis Magazine hosted our latest St. Louis Supper Club, presented by ReeceNichols, at Sidney Street Cafe in Benton Park. “Cheryl and I chose a classic over the latest hot spot,” says George. “For…
  - (2026-11-07) [St. Louis] Man killed in High Ridge double-shooting; Suspect charged, had eggs thrown at his car
      One man died from his injuries after a double-shooting Thursday evening in High Ridge, and a suspect now faces criminal charges, according to the Jefferson County Sheriff's Office.
  - (2026-11-07) [St. Louis] SLU tops Mizzou, 90-84, in Show Me Showdown
      For the first time in 25 years, the Show Me Showdown returned to St. Louis on Friday night. The Saint Louis University Billikens took on the Missouri Tigers in a basketball game that brought two dedicated fan bases toget…
  - (2026-11-06) [St. Louis] Robbie Avila cannot play Friday, College Sports Commission says
      Robbie Avila will not play in Friday night's SLU Billikens matchup against the Mizzou Tigers due to an apparent roster conflict, according to College Sports Commission.

### State Legislative Action — 149 new of 199 total
  - (2026-11-07) [California SB 1299] State Fire Marshal Fire Sprinkler Fitter Certification Act.
      Existing law authorizes the State Fire Marshal to propose, adopt, and administer the regulations that the State Fire Marshal deems necessary in order to ensure fire safety in buildings and structures within this state, i…
  - (2026-11-07) [California SB 1301] Residential property insurance: nonrenewals.
      Existing law creates the Department of Insurance, headed by the Insurance Commissioner, and generally regulates classes of insurance, including residential property insurance. Existing law requires an insurer to deliver…
  - (2026-11-07) [California SB 1283] Electric vehicle charging stations: installation: permits.
      Existing law requires a city, county, or city and county (local government) to administratively approve an application to install an electric vehicle charging station (EV station) through the issuance of a building permi…
  - (2026-11-07) [California SB 1340] Small business liaison: contract information: small business procurement participation.
      Existing law establishes the Office of Small Business Advocate within the Governor's Office of Business and Economic Development, led by the Small Business Advocate, and sets forth its powers and duties relating to advoc…
  - (2026-11-07) [California SB 1359] Natural Gas Ratepayer Protection Act.
      Existing law vests the Public Utilities Commission with regulatory authority over public utilities, including gas corporations. Existing law authorizes the commission to fix the rates and charges for every public utility…
  - (2026-11-07) [California SB 133] Education finance: education omnibus trailer bill.
      (1) Existing law, for 2025–26 fiscal year, appropriates $50,000,000 from the General Fund to the State Department of Education for allocation to the Kern County Superintendent of Schools to augment the Mathematics Profes…

### U.S. Weather + Severe / Climate Outlooks — 101 new of 103 total
  - (2026-11-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-07) [Severe] Heavy Freezing Spray Warning: Heavy Freezing Spray Warning issued November 7 at 3:46AM AKST until November 8 at 5:00AM AKST by NWS Fairbanks AK
      Northwestern Alaska Coastal Waters out 100 NM Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one- third of the combined wind-wave and swell height.…
  - (2026-11-07) [Severe] Heavy Freezing Spray Warning: Heavy Freezing Spray Warning issued November 7 at 4:00AM AKST until November 8 at 5:00PM AKST by NWS Fairbanks AK
      Offshore Waters Forecast for the US Arctic Waters Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. Individual waves may be twice as high. .TODAY...NE winds 30 kt. Se…
  - (2026-11-07) [Severe] Heavy Freezing Spray Warning: Heavy Freezing Spray Warning issued November 7 at 3:45AM AKST until November 8 at 5:00AM AKST by NWS Fairbanks AK
      Arctic Alaska Coastal Waters out 100 NM Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one- third of the combined wind-wave and swell height. .TODA…
  - (2026-11-07) [Moderate] Gale Warning: Gale Warning issued November 7 at 3:45AM AKST until November 8 at 5:00AM AKST by NWS Fairbanks AK
      Arctic Alaska Coastal Waters out 100 NM Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one- third of the combined wind-wave and swell height. .TODA…
  - (2026-11-07) [Severe] Heavy Freezing Spray Warning: Heavy Freezing Spray Warning issued November 7 at 3:45AM AKST until November 8 at 5:00AM AKST by NWS Fairbanks AK
      Arctic Alaska Coastal Waters out 100 NM Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one- third of the combined wind-wave and swell height. .TODA…

### Ukraine Theater (total-war monitoring) — 86 new of 268 total
  - (2026-11-07) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-06) [Liveuamap] Several ballistic missiles were launched towards Kyiv region – Kyiv,Kyiv city - Liveuamap
      Several ballistic missiles were launched towards Kyiv region – Kyiv,Kyiv city Liveuama
  - (2026-11-05) [Liveuamap] At Lyman direction clashes yesterday near Novoserhiyivka, Stavky, Lyman and Zarichne, - General Staff of Armed Forces of Ukraine reports – Luhansk Oblast, Ukraine - Liveuamap
      At Lyman direction clashes yesterday near Novoserhiyivka, Stavky, Lyman and Zarichne, - General Staff of Arm
  - (2026-11-03) [Liveuamap] Members of the Hezbollah militia cell were arrested after intelligence thwarted a plot to target the Homs refinery. The arrests were made during a preemptive security operation, in coopera…
      Members of the Hezbollah militia cell were arrested after intelligence thwarted a plot to target the Homs refinery. The arr
  - (2026-11-03) [Liveuamap] Saudi Coalition: Missile intercepted and destroyed in eastern Saudi Arabia – Eastern Province Saudi Arabia - Liveuamap
      Saudi Coalition: Missile intercepted and destroyed in eastern Saudi Arabia – Eastern Province Saudi Arabia &
  - (2026-11-04) [Liveuamap] Six Palestinians from the Jenin area in the northern West Bank were arrested for attempting to build rockets to launch at Israel, the Shin Bet security agency and Israel Police say. The in…
      Six Palestinians from the Jenin area in the northern West Bank were arrested for attempting to build ro

### Ukrainian Internal News (national + local Kyiv) — 63 new of 139 total
  - (2026-11-07) Співробітників СБУ закликають терміново скинутися на заставу Дуці – джерела | LEDE: Співробітникам СБУ надсилають прохання допомогти внести заставу для Сергія Дуки, підозрюваного у справі «Карф] (uk:…
      Співробітникам СБУ надсилають прохання допомогти внести заставу для Сергія Дуки, підозрюваного у справі «Карфаген». Сума застави – 65 млн грн.
  - (2026-11-07) Два аеростати порушили повітряний простір Молдови | LEDE: ] (uk: Два аеростати порушили повітряний простір Молдови)
  - (2026-11-07) Буданов сплатить штраф за російську мову – омбудсменка | LEDE: Керівник Офісу президента визнав порушення мовного законодавства у Петропавлівській Борщагівці та сплатить штраф. Юридичні процеду] (uk:…
      Керівник Офісу президента визнав порушення мовного законодавства у Петропавлівській Борщагівці та сплатить штраф. Юридичні процедури вже розпочато.
  - (2026-11-07) Увечері 7 листопада частина сервісів "Резерв+" може бути недоступною – МО | LEDE: 7 листопада ввечері у Резерв+ можливі перебої з електронним військовим документом — Міноборони радить завчасно ] (uk:…
      7 листопада ввечері у Резерв+ можливі перебої з електронним військовим документом — Міноборони радить завчасно зберегти PDF
  - (2026-11-07) У Чехії планують посилити захист критичної інфраструктури від дронів | LEDE: ] (uk: У Чехії планують посилити захист критичної інфраструктури від дронів)
  - (2026-11-07) Сім хвилин до паніки: чи готова Україна до загроз, яких ще не переживала? | LEDE: Злам застосунку Повітряна тривога – сигнал про важливість координації держави й суспільства для безпеки України] (uk:…
      Злам застосунку Повітряна тривога – сигнал про важливість координації держави й суспільства для безпеки України. Аналізуємо міжнародний досвід.

### GDACS — global disaster alerts — 55 new of 100 total
  - (2026-11-07) [Green] Tropical Cyclone 02-20262027-27
      Tropical Cyclone · Green alert · Madagascar · Tropical Depression (maximum wind speed of 74 km/h)
  - (2026-11-07) [Green] Earthquake in Southern Mid-Atlantic Ridge
      Earthquake · Green alert · Southern Mid-Atlantic Ridge · Magnitude 4.9M, Depth:10km
  - (2026-11-07) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.5M, Depth:31.748km
  - (2026-11-07) [Green] Earthquake in Chile
      Earthquake · Green alert · Chile · Magnitude 4.5M, Depth:110.716km
  - (2026-11-07) [Green] Earthquake in Northern Molucca Sea
      Earthquake · Green alert · Northern Molucca Sea · Magnitude 4.7M, Depth:38.531km
  - (2026-11-06) [Green] Tropical Cyclone PENA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 120 km/h)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-07) [MAXFIELD JOSHUA H] Form 4 (Reporting)
      filed 2026-11-07 02:55 UTC · role: Reporting — Filed: 2026-11-06 AccNo: 0001193125-26-452288 Size: 5 KB
  - (2026-11-07) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-11-07 02:55 UTC · role: Issuer — Filed: 2026-11-06 AccNo: 0001193125-26-452288 Size: 5 KB
  - (2026-11-07) [Barrocas Mark] Form 4 (Reporting)
      filed 2026-11-07 02:54 UTC · role: Reporting — Filed: 2026-11-06 AccNo: 0000908834-26-000509 Size: 16 KB
  - (2026-11-07) [SharkNinja, Inc.] Form 4 (Issuer)
      filed 2026-11-07 02:54 UTC · role: Issuer — Filed: 2026-11-06 AccNo: 0000908834-26-000509 Size: 16 KB
  - (2026-11-07) [FuboTV Inc.] Form 4 (Issuer)
      filed 2026-11-07 02:43 UTC · role: Issuer — Filed: 2026-11-06 AccNo: 0001493152-26-050582 Size: 10 KB
  - (2026-11-07) [LEFF DANIEL V] Form 4 (Reporting)
      filed 2026-11-07 02:43 UTC · role: Reporting — Filed: 2026-11-06 AccNo: 0001493152-26-050582 Size: 10 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 36 new of 61 total
  - (2026-11-07) [BleepingComputer] SonicWall warns of new SSL-VPN MFA bypass flaw exploited in attacks
      SonicWall has released security updates to fix seven vulnerabilities in SonicOS firewalls, including an SSL-VPN authentication bypass flaw exploited in attacks. [...]
  - (2026-11-07) [The Hacker News] Claude Code's “Don't Ask Again” File Exposes Passwords and Keys in 1,122 Public Copies on GitHub
      Passwords and API keys that developers typed into commands they approved in Claude Code are sitting in public GitHub repositories, where anyone can read them. When a user selects "Yes, and don't ask again," Anthropic's A…
  - (2026-11-07) [The Register] NHS breach helpline left staff carrying a 'significant emotional burden'
      Team given a day's notice faced distressed callers, safeguarding decisions during project that stretched from 2 weeks to 11
  - (2026-11-07) [The Register] Windows takes a break at UK motorway services
      Bad drivers behind the wheel or underneath the operating system – neither is ideal
  - (2026-11-07) [Ars Technica] The migration that transformed Africa's languages, genes, and cultures
      Genes and archaeology are revealing how Bantu speakers spread across much of Africa.
  - (2026-11-07) [Ars Technica] British soldier ignored order to pull his SIM card, then got blackmailed
      Soldier told repeatedly to lock down devices before deploying, got sextorted, court-martialed.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 25 new of 60 total
  - (2026-11-06) U.S. Court of Appeals, 8th Cir.: AB Realty, LLC v. Scott Lane
  - (2026-11-06) U.S. Court of Appeals, 8th Cir.: Jermaine Baptiste v. Evergreen Packaging LLC
  - (2026-11-06) U.S. Court of Appeals, 10th Cir.: EEOC v. A & A Appliance
  - (2026-11-06) U.S. Court of Appeals, 10th Cir.: Wisne v. NCAA
  - (2026-11-06) Delaware Supreme Court: 826 Capital Holdings, LLC v. Zama Capital Master Fund, LP
  - (2026-11-06) Delaware Supreme Court: Massey v. State

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-11-07) [Russia oil sanctions perimeter · themes] Robne zalihe teške 93 milijuna eura : Hrvatska ima žitarica za 60 dana , ali lijekova nema ni za prvu pomoć
      glas-slavonije.hr · Croatian · tone NA
  - (2026-11-07) [Russia oil sanctions perimeter · themes] Polis bülteni … 39 yaşındaki Zahid Rasool aranıyor - Havadis Gazetesi
      havadiskibris.com · Turkish · tone NA
  - (2026-11-07) [Russia oil sanctions perimeter · themes] Rusia sufera pierderi pe front din cauza motorinei nevandute in SUA
      stiripesurse.ro · Romanian · tone NA
  - (2026-11-07) [Russia oil sanctions perimeter · themes] Намащення зі скумбрії та карамелізованої цибулі : проста закуска
      tsn.ua · Ukrainian · tone NA
  - (2026-11-07) [Russia oil sanctions perimeter · themes] Удар балістики по Києву : пошкоджений Північний міст , перебої з водою і світлом
      bbc.com · Ukrainian · tone NA
  - (2026-11-07) [Russia oil sanctions perimeter · themes] CPC to leave domestic , diesel prices unchanged next week
      focustaiwan.tw · English · tone NA

### Government & military aircraft airborne (OpenSky) — 25 new of 26 total
  - (2026-11-07) JAF9NV (Bulgaria)
      icao24: 4520aa · position: (34.7914, -8.6821) · alt: 11285m · 850km/h
  - (2026-11-07) SAMU69 (France)
      icao24: 39c994 · position: (45.3349, 5.5253) · alt: 693m · 223km/h
  - (2026-11-07) FNY5560 (France)
      icao24: 39a408 · position: (41.2941, 2.0613) · on ground · 26km/h
  - (2026-11-07) PAT500 (United States)
      icao24: ae08fa · position: (40.1276, -76.2863) · alt: 3459m · 446km/h
  - (2026-11-07) JAF7AX (Belgium)
      icao24: 44d1a5 · position: (50.6898, 4.0848) · alt: 3131m · 521km/h
  - (2026-11-07) JAF55N (Belgium)
      icao24: 44d1c2 · position: (37.9723, -9.9225) · alt: 10972m · 878km/h

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-11-07) Will Rick Scott win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $767,393 · resolves 2028-11-08
  - (2026-11-07) Israel x Iran ceasefire continues through November 7?
      yes price: 98% · 24h volume: $696,141 · resolves 2026-11-08
  - (2026-11-07) LoL: Invictus Gaming vs Gen.G (BO5) - Worlds Playoffs
      yes price: 20% · 24h volume: $670,546 · resolves 2026-11-08
  - (2026-11-07) US x Iran effective ceasefire continues through November 6, 2026?
      yes price: 97% · 24h volume: $580,120 · resolves 2026-11-07
  - (2026-11-07) Will Tulsi Gabbard win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $497,283 · resolves 2028-11-08
  - (2026-11-07) Will Tottenham Hotspur FC win on 2026-11-07?
      yes price: 36% · 24h volume: $418,166 · resolves 2026-11-07

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 99 total
  - (2026-11-06) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-11-07) [USASpending] $616,833,357 → CLARK CONSTRUCTION GROUP LLC: IRA: PROVIDE LABOR, MATERIALS, SUPERVISION, AND EQUIPMENT TO
      Agency: General Services Administration. Description: IRA: PROVIDE LABOR, MATERIALS, SUPERVISION, AND EQUIPMENT TO CONSTRUCT THE NEW CISA HQ BUILDING. SERVICES INCLUDE, BUT ARE NOT LIMITED: CIVIL AND SITE WORK CONSISTING…
  - (2026-11-07) [USASpending] $586,830,465 → HARRIS CORPORATION: DAFIS UDO RECONSTRUCT W/O ADVANCE
      Agency: Department of Transportation. Description: DAFIS UDO RECONSTRUCT W/O ADVANCE
  - (2026-11-07) [USASpending] $583,194,637 → GENERAL DYNAMICS INFORMATION TECHNOLOGY, INC.: THE CLOUD PRODUCTS AND TOOLS (CPT) CONTRACT IS USED TO PROVI
      Agency: Department of Health and Human Services. Description: THE CLOUD PRODUCTS AND TOOLS (CPT) CONTRACT IS USED TO PROVIDE CLOUD-BASED INFRASTRUCTURE FROM COMMERCIAL CLOUD SERVICE PROVIDERS (CSP) SUCH AS MICROSOFT AZUR…
  - (2026-11-07) [USASpending] $504,266,389 → LEIDOS INNOVATIONS GLOBAL, INC.: WA-10-03770-- INCREMENTAL FUNDING - NEXTGEN HD TRAJECTORY M
      Agency: Department of Transportation. Description: WA-10-03770-- INCREMENTAL FUNDING - NEXTGEN HD TRAJECTORY MGMT-ARRIVAL TACTICAL FLOW_TBFM_ PROGRAM 'NEW CONTRACT'. TO PROVIDE PROGRAM MANAGEMENT, SYSTEMS ENGINEERING, SY…
  - (2026-11-07) [USASpending] $457,768,636 → LEIDOS, INC.: CHECKPOINT MAINTENANCE
      Agency: Department of Homeland Security. Description: CHECKPOINT MAINTENANCE

### Campaign finance (FEC: top fundraisers + recent filings) — 10 new of 27 total
  - (2026-11-06) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046661
  - (2026-11-06) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046575
  - (2026-11-06) [F2] MORRISON, KELLY LOUISE
      cycle 2026 · filing #2046554
  - (2026-11-06) [F2] HARDEN, CHRISTOPHER MATTHEW
      cycle 2026 · filing #2046624
  - (2026-11-06) [F99] SCOTT FITZGERALD FOR CONGRESS
      cycle 2026 · filing #2046612
  - (2026-11-06) [F3X] BAYADA HEARTS FOR HOME CARE, INC. POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #2046613

### USGS earthquakes (M4.5+, past day) — 8 new of 8 total
  - (2026-11-07) M 5.5 - 74 km NE of Hasaki, Japan
      M5.5 · 74 km NE of Hasaki, Japan · depth 31.748 km
  - (2026-11-07) M 4.9 - southern Mid-Atlantic Ridge
      M4.9 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-11-06) M 4.8 - 36 km WNW of Poso, Indonesia
      M4.8 · 36 km WNW of Poso, Indonesia · depth 10 km
  - (2026-11-07) M 4.7 - 156 km ESE of Modisi, Indonesia
      M4.7 · 156 km ESE of Modisi, Indonesia · depth 38.531 km
  - (2026-11-07) M 4.6 - South Sandwich Islands region
      M4.6 · South Sandwich Islands region · depth 103.682 km
  - (2026-11-06) M 4.6 - 11 km ENE of Yigo Village, Guam
      M4.6 · 11 km ENE of Yigo Village, Guam · depth 113.394 km

### Paper Trading Scorecard — 5 new of 59 total
  - (2026-11-07) [Manifold] EPL: Will Manchester City beat Nottingham Forest on November 7, 2026?
  - (2026-11-07) [Manifold] Will California courts *sentence* anyone to death in 2027?
  - (2026-11-07) [Manifold] Will 0xDe89112492A292c194D2501b2721D4Bc6cED2A75 RECEIVE more than 300.00 USDC Base by November 10th 11:59 pm UTC
  - (2026-11-07) [Manifold] Will Jon Ossoff win the 2028 US presidential election?
  - (2026-11-07) [Manifold] Will Jon Ossoff run for US president in 2028?

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-07) [Marginal Revolution] What are the Best MR Posts?
      From the Archives–written by ChatGPT. This ranking judges posts on reasoning, originality of framing, explanatory power, intellectual stimulation, timeliness, and how much they accomplish in their length. Originality inc…
  - (2026-11-07) [Marginal Revolution] The Anthropic succession plan?
      Anthropic’s version is rather more elaborate. Each of its seven co-founders will maintain a confidential, ranked list of up to ten people who may eventually inherit that founder’s membership and voting role inside a spec…
  - (2026-11-07) [Marginal Revolution] Was Mossadegh a liberal, democratizing force?
      One reads and hears so many times that Iran was on the path to democracy until a CIA coup installed the Shah in 1953. It turns out that account is quite wrong, as is detailed by Simon Sebag Montefiore: As his support in…
  - (2026-11-06) [Conversable Economist] Fall 2026 Journal of Economic Perspectives Freely Available Online
      I have been the Managing Editor of the Journal of Economic Perspectives since the first issue in Summer 1987. The JEP is published by the American Economic Association, which decided back in 2011–to my delight–that the j…

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-11-06) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo, Kenya and Nigeria
      Since the publication of the previous Disease Outbreak News on 23 October 2026, the Bundibugyo virus disease (BVD) outbreak has expanded geographically in the Democratic Republic of the Congo. While some areas have seen…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-11-06) CVE-2026-19868 · SonicWall SonicOS SSLVPN: SonicWall SonicOS SSLVPN Use of Single-factor Authentication Vulnerability
      vendor: SonicWall · product: SonicOS SSLVPN · CISA remediation by 2026-11-20

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=16, 14d-median=15; carrying terms: certain, commission, regulatory, action, final, safety, document, necessary, published, procedures, proposed, proposes
- state_bills: today=199, 7d-median=100, 14d-median=90; carrying terms: insurance, relating, providing, vehicle, alaska, emergency, review, establishes, including, employment, existing, duties
- state_news: today=675, 7d-median=675, 14d-median=678; carrying terms: decision, connecticut, issues, schools, newsom, races, ctmirror, spotlightdelaware, opinion, opponent, redistricting, world
- local_news: today=265, 7d-median=256, 14d-median=256; carrying terms: world, https, million, google, senate, investigation, killed, trump, still, against, magazine, crash
- foreign_news: today=989, 7d-median=992, 14d-median=999; carrying terms: financiero, bookmark, defence, issues, beijing, warning, thenationalnews, spanish, stolen, government, million, vnexpress
- chinese_internal: today=334, 7d-median=334, 14d-median=294; carrying terms: https, google, cbmiakfvx, cbmidefvx, growth, market, cbmib, cbmiy, china, chinese, cbmiykfvx, title
- russian_internal: today=946, 7d-median=938, 14d-median=951; carrying terms: financial, forbidden, novaya, street, group, laquo, bloomberg, world, server, europe, https, gazeta
- ukrainian_internal: today=139, 7d-median=139, 14d-median=131; carrying terms: noting, international, including, oleshky, https, government, military, campaign, study, missiles, facilities, provide
- ukraine_theater: today=268, 7d-median=328, 14d-median=369; carrying terms: wytjyzuvv, lgvvfzzc, bjvpcgt, incorrect, nvbhdvulrsdtrga, rtsdkxduhrwmzbdmnzrwtcr, defence, naval, hmsunuqq, xzrodgpnakh, quczuvlnuffxmhfmcg, nxmuzitf
- paper_bets: today=59, 7d-median=67, 14d-median=64; carrying terms: earthquake, goals, mamdani, experience, supervolcano, allen, playoff, achieved, evans, break, koivun, chase
- weather: today=103, 7d-median=103, 14d-median=130; carrying terms: twoat, offshore, result, possible, gusts, county, coast, areas, today, coastal, changed, warning
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dcoilwtico, total, jolts, commodities, crude, personal, recession, supply, consumption, cpilfesl, dexjpus, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, yield, bitcoin, range, nasdaq, proxy, close, commodities, crude, large, china, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=97, 14d-median=102; carrying terms: portal, checksum, paeez, support, detect, technology, including, trade, ujgxrwtvbs, https, target, research
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, https, error, congresstrading, httperror, client, quiver, quiverquant, unauthorized
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, state, court, supreme, blanche, connecticut, appeals, company, alabama, secretary, florida, union
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, holdings, michael, franklin, holding
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, filing, abdul, trone, ossoff, krishnamoorthi, warner, booker, david, raised, talarico, cooper
- gdelt_regions: today=0, 7d-median=3, 14d-median=3
- gdelt_gkg: today=25, 7d-median=27, 14d-median=27; carrying terms: english, chinese, themes, spanish, sanctions, romanian, russia, perimeter, turkish, greek, russian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=30, 14d-median=30; carrying terms: kingdom, position, belgium, france, germany, ground, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: death, generation, ubangi, distributed, passengers, round, affected, given, north, april, travel, notified
- cisa_kev: today=13, 7d-median=14, 14d-median=17; carrying terms: vendor, secure, software, vulnerability, authentication, product, remediation, edition, request, improper, cisco, stale
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: earthquake, islands, maximum, wildfire, nigeria, impact, green, forestfire, australia, tropical, forest, papua
- usgs_quakes: today=8, 7d-median=11, 14d-median=17; carrying terms: depth, islands, japan, region, indonesia, south, ridge, sandwich, greece, village
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, election, seats, senate, presidential, republican, power, house, democratic, israel
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, https, class, economist, conversable, marginal, being, marginalrevolution, economists, economic, version, published
- tech_news: today=61, 7d-median=61, 14d-median=57; carrying terms: blogging, cybersecurity, today, technology, weekday, world, https, government, compromised, service, hacker, hackers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: philadelphia, aumua, takano, blackburn, timothy, welch, jacobs, quigley, nathaniel, chief, minneapolis, drift
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, placed, identify, decision, converges, module, sufficient, placement, paper, markets, consensus, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Results of the ECB Survey of Professional Forecasters for the fourth quarter of 2026
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*