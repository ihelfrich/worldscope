# WORLDSCOPE morning brief — 2026-08-18

## Headline
3852 new items across 27 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (737) · International News + Multilateral Institutions (736) · Russian Internal News (state + in-exile) (731) · World leaders & government officials (324) · State-Level News (320) · Chinese Internal News (238) · Local News: St. Louis + Atlanta (211) · U.S. Weather + Severe / Climate Outlooks (157) · Ukrainian Internal News (national + local Kyiv) (57) · IT, InfoSys & cybersecurity news (last 7 days) (42) · GDELT GKG — themes / entities / watch areas (41) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Ukraine Theater (total-war monitoring) — 737 new of 887 total
  - (2026-08-18) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-17) [FIRMS] thermal anomaly 46.393, 34.022 (FRP 7.67 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-17 0924Z, FRP 7.67 MW
  - (2026-08-17) [FIRMS] thermal anomaly 48.813, 34.391 (FRP 4.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-17 0924Z, FRP 4.41 MW
  - (2026-08-17) [FIRMS] thermal anomaly 49.527, 33.189 (FRP 4.07 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-17 0924Z, FRP 4.07 MW
  - (2026-08-17) [FIRMS] thermal anomaly 51.153, 34.787 (FRP 3.27 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-17 0924Z, FRP 3.27 MW
  - (2026-08-17) [FIRMS] thermal anomaly 51.186, 34.868 (FRP 3.63 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-17 0924Z, FRP 3.63 MW

### International News + Multilateral Institutions — 736 new of 962 total
  - (2026-08-18) [Global] South Korea president calls for military independence in wake of Trump call to cut joint drills
  - (2026-08-18) [Global] South Korea city deluged by almost a metre of rain, triggering deadly landslide
  - (2026-08-17) [Global] Trump’s move to gut South Korea alliance is ‘inane, haphazard decision’, lawmakers say
  - (2026-08-17) [Global] China’s economy showing signs that slowdown may be extending
  - (2026-08-18) [Global] Family of missing 18-year-old hiker ‘absolutely devastated’ as search continues in rugged NSW terrain
  - (2026-08-18) [Global] Severe weather warning for northern Victoria – as it happened

### Russian Internal News (state + in-exile) — 731 new of 990 total
  - (2026-08-18) В Финляндии пересмотрят дело о депортации россиян Ольги и Никиты Беловых. Они помогали украинским беженцам, а затем им отказали в убежище | LEDE: Суд в Финляндии постановил пересмотреть дело] (ru: В Ф…
      Суд в Финляндии постановил пересмотреть дело о депортации россиян Ольги и Никиты Беловых, которые помогали украинским беженцам, сообщает The Guardian, ссылаясь на адвоката семьи.
  - (2026-08-18) В ДТП в центре Москвы погиб зампред правления Генбанка Дмитрий Ларин. Его мотоцикл столкнулся со скорой | LEDE: Заместитель председателя правления Генбанка Дмитрий Ларин погиб в ДТП в центре] (ru: В Д…
      Заместитель председателя правления Генбанка Дмитрий Ларин погиб в ДТП в центре Москвы. Утром 18 августа мотоцикл, которым управлял Ларин, столкнулся с автомобилем скорой помощи на 1-й Тверской-Ямской улице.
  - (2026-08-18) Россия нанесла ракетный удар по поселку Печенеги в Харьковской области. Погибли 10 человек | LEDE: Российские войска утром 18 августа нанесли ракетный удар по поселку Печенеги в Харьковской ] (ru: Рос…
      Российские войска утром 18 августа нанесли ракетный удар по поселку Печенеги в Харьковской области, сообщил глава областной администрации Олег Синегубов.
  - (2026-08-18) Власти Тайваня собрались раздать жителям по 10 тысяч тайваньских долларов (314 долларов США). Экономика страны растет из-за спроса на чипы для ИИ | LEDE: Президент Тайваня Лай Циндэ объявил,] (ru: Вла…
      Президент Тайваня Лай Циндэ объявил, что власти острова собираются раздать жителям по 10 тысяч тайваньских долларов (около 314 долларов США по курсу на 17 августа). Соответствующая инициатива, объявил Лай Циндэ в своем ф…
  - (2026-08-18) ЦИК убрал «Яблоко» из бюллетеня. Теперь за номером 1 («Единая Россия») сразу идет номер 3 (ЛДПР) | LEDE: Центризбирком России удалил информацию о партии «Яблоко» из избирательного бюллетеня ] (ru: ЦИК…
      Центризбирком России удалил информацию о партии «Яблоко» из избирательного бюллетеня для голосования на выборах в Госдуму, сообщает «Интерфакс».
  - (2026-08-18) В Москве умерла пенсионерка, поджегшая квартиру, когда ее пришли выселять приставы. В 2022 году она продала жилье и передала деньги мошенникам | LEDE: 68-летняя жительница Москвы Наталья Ива] (ru: В М…
      68-летняя жительница Москвы Наталья Иванова, которая в начале августа подожгла себя и свою квартиру, умерла от полученных ожогов. Об этом 18 августа сообщили телеграм-каналы Baza, Mash и Shot, связанные с силовыми структ…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 320 new of 422 total
  - (2026-08-18) [California] Governor Newsom signs legislation 8.17.2026
      Source
  - (2026-08-17) [California] ICYMI: Law signed by Governor Newsom helps pave the way for the world’s largest union of rideshare drivers
      Source
  - (2026-08-18) [Arizona] Fontes urges high court to reject Trump-linked firm’s ballot rewrite bid for election reform measure
      A Trump-linked law firm should not get to rewrite a description of a Republican-backed ballot referral that would make sweeping changes to Arizona election laws, the Democratic secretary of state argued to the state’s hi…
  - (2026-08-18) [Arizona] Voucher-reform measure hangs by a thread as Supreme Court weighs signatures
      Whether voters this fall will get a chance to weigh in on a ballot measure to implement sweeping new restrictions on the state’s billion-dollar universal school voucher program hinges entirely on whether the Arizona Supr…
  - (2026-08-17) [Arizona] ‘I don’t trust you’: Tensions boil over on Trump administration’s election security call
      Tensions between state election officials and the Trump administration are rising as we head into the heart of the midterm election season. Frustrations boiled over on Monday during a rare election security call hosted b…
  - (2026-08-17) [Arizona] Legal scandal forces Pinal County off high-profile capital murder case
      A Maricopa County Superior Court judge has disqualified the Pinal County Attorney’s Office and the Pinal County Superior Court from trying a high-profile capital murder case plagued by legal scandal. Judge Patricia Starr…

### Chinese Internal News — 238 new of 280 total
  - (2026-08-17) China Proposes Independent Privacy Oversight Committees for Big Tech - Caixin Global
      China Proposes Independent Privacy Oversight Committees for Big Tech Caixin Global
  - (2026-08-17) Commentary: The Real Flaw in China’s AI Strategy - Caixin Global
      Commentary: The Real Flaw in China’s AI Strategy Caixin Global
  - (2026-08-18) 朱镕基同志遗体在京火化 - 人民网图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE5xemtJejZGQ1ZmRlhqRFVOZ2ExTk9QSVpiUk4wM3dKUWhHdHlxalkzbTN6UENnc3BwQ0xOZEZ4aFYyUFVGNUFkcGFZSmxPckVLcWhHR] (zh:…
      朱镕基同志遗体在京火化 人民网图片频道
  - (2026-08-18) 江苏泗洪： 蒲草栽种忙 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE40R05hX053eUI2M25sSHh6TW1BdU8tSE1RV1JNWmlXQmYwZzRoeU4xak5zT1RMNTNhVVRfT0tWRUVfeXZnYm56UVRPZHBOUGcxeGsybVh1] (zh:…
      江苏泗洪： 蒲草栽种忙 人民图片
  - (2026-08-18) 湖北浠水：“渔光互补” 赋能乡村绿色发展 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5jS3dkUmRnUG1oT1RYdi1BYW1HaHcwUjR3cFQ3aHpWT1NBTnc4ZWxyZHQ4N0wzZDdZV1NfQ0FPRVB6d1o4bEMxazROYXhhdnI] (zh:…
      湖北浠水：“渔光互补” 赋能乡村绿色发展 人民图片
  - (2026-08-18) 山东滨州： 多彩过暑假非遗润童心 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE90aG5VYVYwZHdPQlNSMDB3N29SX19BNWk4OGptdHRLZW5LeEc3Y2JsOG95X2dzZXhtbVNfY1poMWEtTzh4RmllbTRlNXVVNHhoVTl] (zh:…
      山东滨州： 多彩过暑假非遗润童心 人民图片

### Local News: St. Louis + Atlanta — 211 new of 216 total
  - (2026-08-18) [St. Louis] Where Art Thou? – 8/18/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-17) [St. Louis] Tamm Story Slamm encourages community connection through storytelling
      In November 2023, Anthony Howell, a young adult working at a power plant, was inspired by the well-known podcast The Moth, in which individuals are given a platform to share a moving story from their lives either on air…
  - (2026-08-17) [St. Louis] Fall getaways in the Midwest
      Mount Magazine State Park | Arkansas As the highest point in Arkansas, Mount Magazine State Park attracts visitors for its views. If you’re into extreme sports, there are plenty of opportunities for mountain biking, rock…
  - (2026-08-17) [St. Louis] St. Louis judge issues warrant for Jill Stein’s arrest
      Perennial Green Party presidential candidate Jill Stein faces an arrest warrant in Missouri after neither she nor her attorney appeared at a hearing Monday morning related to misdemeanor charges for the alleged assault o…
  - (2026-08-17) [St. Louis] Lou’s Clues – 8/17/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-08-17) [St. Louis] Macis’ Prime BBQ joins kitchen lineup at Wash Ave Food Hall
      An additional food vendor has signed on at Wash Ave Food Hall (1122 Washington), the downtown dining and social destination slated to open in October. Macis’ Prime BBQ will join Little BAO (a concept specializing in bao,…

### U.S. Weather + Severe / Climate Outlooks — 157 new of 159 total
  - (2026-08-18) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 18 at 4:24AM CDT until August 18 at 4:30AM CDT by NWS Omaha/Valley NE
      The storm which prompted the warning has weakened below severe limits, and no longer poses an immediate threat to life or property. Therefore, the warning will be allowed to expire.
  - (2026-08-18) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-18) [Moderate] Rip Current Statement: Rip Current Statement issued August 18 at 5:06AM EDT until August 19 at 4:00AM EDT by NWS Tallahassee FL
      * WHAT...Dangerous rip currents expected. * WHERE...Bay and Gulf County Beaches. * WHEN...From noon EDT /11 AM CDT/ today through late tonight. * IMPACTS...Rip currents can sweep even the best swimmers away from shore in…
  - (2026-08-18) [Moderate] Special Weather Statement: Special Weather Statement issued August 18 at 6:56PM ChST by NWS Tiyan GU
      Invest 92W has steadily organized today and is now subject to the Joint Typhoon Warning Center's Tropical Cyclone Formation Alert. Invest 92W is currently located near 8N155E or 180 miles east of Chuuk. Invest 92W is dri…
  - (2026-08-18) [Moderate] Special Weather Statement: Special Weather Statement issued August 18 at 4:56AM EDT by NWS Buffalo NY
      Patchy dense fog is impacting the Western Southern Tier, especially in and near river and creek valleys. The dense fog will reduce visibility to a quarter mile or less. Motorists should slow down, maintain plenty of stop…
  - (2026-08-18) [Moderate] Special Weather Statement: Special Weather Statement issued August 18 at 6:56PM ChST by NWS Tiyan GU
      Invest 92W has steadily organized today and is now subject to the Joint Typhoon Warning Center's Tropical Cyclone Formation Alert. Invest 92W is currently located near 8N155E or 180 miles east of Chuuk. Invest 92W is dri…

### Ukrainian Internal News (national + local Kyiv) — 57 new of 103 total
  - (2026-08-18) "Дуй, пакуй і комплектуй": співробітникам ТЦК в Одесі оголосили підозри в катуванні | LEDE: В ході операції "Чесний призов" правоохоронці викрили протиправні дії двох груп оповіщення Київського] (uk:…
      В ході операції "Чесний призов" правоохоронці викрили протиправні дії двох груп оповіщення Київського районного ТЦК та СП міста Одеса, підозру оголошено 10 військовослужбовцям.
  - (2026-08-18) Росіяни вдарили дроном по авто на Запоріжжі – убили чоловіка | LEDE: На Запоріжжі 72-річний чоловік загинув через удар російського дрона по цивільному авто.] (uk: Росіяни вдарили дроном по авто на Зап…
      На Запоріжжі 72-річний чоловік загинув через удар російського дрона по цивільному авто.
  - (2026-08-18) Зараз починає формуватися суб’єктність Федорова – засновник SOCIS | LEDE: Суб'єктність Федорова почала формуватися після його відставки з посади міністра – соціолог] (uk: Зараз починає формуватися суб…
      Суб'єктність Федорова почала формуватися після його відставки з посади міністра – соціолог
  - (2026-08-18) Молдовських феремрів обурив пільговий транзит для України: погрожують протестами | LEDE: Аграрії Молдови погрожують протестами через знижку на транзит для України, чекають рішень влади до 21 се] (uk:…
      Аграрії Молдови погрожують протестами через знижку на транзит для України, чекають рішень влади до 21 серпня.
  - (2026-08-18) Лідера ОУН Коновальця перепоховали на меморіальному кладовищі | LEDE: На Національному військовому меморіальному кладовищі 18 серпня відбулася церемонія перепоховання останків полковника Армії ] (uk:…
      На Національному військовому меморіальному кладовищі 18 серпня відбулася церемонія перепоховання останків полковника Армії Української Народної Республіки, першого голови Організації українських націоналістів Євгена Коно…
  - (2026-08-18) Арештували агента РФ, який зареєстрував для ворога 27 терміналів Starlink | LEDE: На Харківщині арештували підозрюваного у держзраді, який верифікував Starlink за завданням росіян.] (uk: Арештували аг…
      На Харківщині арештували підозрюваного у держзраді, який верифікував Starlink за завданням росіян.

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 58 total
  - (2026-08-18) [BleepingComputer] Microsoft confirms outage affecting search in Microsoft 365 apps
      Microsoft says some users are experiencing issues searching in Microsoft 365 apps, including Outlook on the web, Outlook desktop, SharePoint Online, and OneDrive. [...]
  - (2026-08-18) [BleepingComputer] Microsoft starts removing WMIC tool used by cybercriminals
      Microsoft announced that it removed the Windows Management Instrumentation Command-line (WMIC) tool from Windows 11 24H2 and 25H2, as well as from Windows 11 beta builds released this week. [...]
  - (2026-08-18) [The Hacker News] SafePal Hardware Wallet Maker Says Flaw Exposed Data of Nearly 40,000 Customers
      SafePal has disclosed that an authorization flaw in an order-tracking plug-in exposed the names, email addresses, shipping addresses, phone numbers, and purchase details of approximately 39,798 customers. The hardware wa…
  - (2026-08-18) [The Hacker News] CISA Flags Actively Exploited Ray Flaw That Can Trigger Browser-Based RCE
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Monday added a critical flaw impacting Ray to its Known Exploited Vulnerabilities (KEV) catalog, citing evidence of active exploitation. Ray is an open-…
  - (2026-08-18) [The Register] AI models get convenient amnesia about source material as they grow, MIT boffins find
      Attributing diffusion model output to a specific input becomes more difficult with more training data
  - (2026-08-18) [The Register] UK's tech talent pipeline shrinks as overseas worker visa applications fall 7%
      Third consecutive annual decline adds to concerns about shortages of specialist skills

### GDELT GKG — themes / entities / watch areas — 41 new of 41 total
  - (2026-08-18) [Russia oil sanctions perimeter · themes] Tues , Aug 18 - The New Hampshire Gazette
      nhgazette.com · English · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] Рејтингот на Трамп падна на најниско ниво од почетокот на мандатот
      mkd.mk · Macedonian · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] 打破静养误区 上海德达医院个性化心脏康复赋能心脏病患回归常态 _ 中华网
      digi.china.com · Chinese · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] 柜子 / 衣柜翻新收纳选哪家 ？ 科学收纳方案解析 - 热点资讯 - ITBear科技资讯
      itbear.com.cn · Chinese · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] « Кредиты , микродоли и внезапная родня »: частые споры при оформлении наследства и как их решить / Новости экономики Красноярска и Красноярского края / Newsl…
      newslab.ru · Russian · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] Adultos mayores , el rango de peatones que más muere por accidentes de tránsito
      elnuevosiglo.com.co · Spanish · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-18) [MediaAlpha, Inc.] Form 4 (Issuer)
      filed 2026-08-18 01:53 UTC · role: Issuer — Filed: 2026-08-17 AccNo: 0001818383-26-000216 Size: 9 KB
  - (2026-08-18) [COYNE JEFFREY B] Form 4 (Reporting)
      filed 2026-08-18 01:53 UTC · role: Reporting — Filed: 2026-08-17 AccNo: 0001818383-26-000216 Size: 9 KB
  - (2026-08-18) [Thompson Patrick Ryan] Form 4 (Reporting)
      filed 2026-08-18 01:53 UTC · role: Reporting — Filed: 2026-08-17 AccNo: 0001818383-26-000215 Size: 9 KB
  - (2026-08-18) [MediaAlpha, Inc.] Form 4 (Issuer)
      filed 2026-08-18 01:53 UTC · role: Issuer — Filed: 2026-08-17 AccNo: 0001818383-26-000215 Size: 9 KB
  - (2026-08-18) [Mobia Medical, Inc.] Form 4 (Issuer)
      filed 2026-08-18 01:53 UTC · role: Issuer — Filed: 2026-08-17 AccNo: 0001193125-26-354538 Size: 10 KB
  - (2026-08-18) [Tansey Casey M] Form 4 (Reporting)
      filed 2026-08-18 01:53 UTC · role: Reporting — Filed: 2026-08-17 AccNo: 0001193125-26-354538 Size: 10 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-18) [United States] Tues , Aug 18 - The New Hampshire Gazette
      domain: nhgazette.com · language: English · tone:
  - (2026-08-18) [United States] Fear grips children after deadly earthquake in eastern Indonesia leaves thousands displaced
      domain: thesunchronicle.com · language: English · tone:
  - (2026-08-18) [United Kingdom] Vacancies slip again as private sector pay growth falls to near six - year low
      domain: borehamwoodtimes.co.uk · language: English · tone:
  - (2026-08-18) [United Kingdom] BBC series Poldark to be available on ITVX from September
      domain: wandsworthguardian.co.uk · language: English · tone:
  - (2026-08-18) [Pakistan] Security forces kill another nine terrorists in Balochistan
      domain: dunyanews.tv · language: English · tone:
  - (2026-08-18) [United Kingdom] Walpole Highway author John Rudd publishes late uncle memoir to spotlight the haulage industry
      domain: fenlandcitizen.co.uk · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-08-18) JAF94H (Bulgaria)
      icao24: 4520aa · position: (48.7331, 2.3845) · alt: 76m · 190km/h
  - (2026-08-18) RCH915 (United States)
      icao24: adfdb8 · position: (40.0285, 23.8944) · alt: 6096m · 538km/h
  - (2026-08-18) GAF103 (Germany)
      icao24: 3ea653 · position: (37.8792, 6.8555) · alt: 10050m · 772km/h
  - (2026-08-18) GAF062 (Germany)
      icao24: 3f7588 · position: (52.9384, 12.7294) · alt: 4076m · 644km/h
  - (2026-08-18) JAF9CK (Belgium)
      icao24: 44d1a6 · position: (51.2182, 2.9972) · alt: 426m · 240km/h
  - (2026-08-18) JAF7CB (Belgium)
      icao24: 44d1b3 · position: (46.5741, 0.1572) · alt: 10363m · 808km/h

### Court opinions of consequence (federal & state) — 26 new of 60 total
  - (2026-08-17) U.S. Court of Appeals, 2nd Cir.: Reyes v. Paul
  - (2026-08-17) U.S. Court of Appeals, 2nd Cir.: Massimino v. Benoit
  - (2026-08-17) U.S. Court of Appeals, 2nd Cir.: Stinn v. United States
  - (2026-08-17) U.S. Court of Appeals, 9th Cir.: United States v. Salazar Del Real
  - (2026-08-17) U.S. Court of Appeals, 9th Cir.: Center for Biological Diversity v. United States Bureau of Reclamation
  - (2026-08-17) U.S. Court of Appeals, 9th Cir.: Rusoff v. the Happy Group, Inc.

### Paper Trading Scorecard — 23 new of 141 total
  - (2026-08-18) [Polymarket] Will the Democrats win the Ohio Senate race in 2026?
      This market will resolve according to the winner of the 2026 Ohio U.S. Senate special election currently scheduled for November 3, inclusive of any run-offs. A candidate shall be considered to represent a party in the ev…
  - (2026-08-18) [Polymarket] Will FaZe Clan Win the CS2 EWC 2026?
      This market will resolve according to the winner of the Counter-Strike 2 tournament at the 2026 Esports World Cup (EWC 2026), currently scheduled for August 12 – August 23, 2026. If this tournament is postponed after Sep…
  - (2026-08-18) [Polymarket] Will Michelle Bolsonaro win the 2026 Brazilian presidential election?
      A presidential election is scheduled to take place in Brazil on October 4, 2026. This market will resolve according to the listed candidate that wins this election. This market includes any potential second round. If the…
  - (2026-08-18) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-08-18) [Manifold] Apakah aptos akan naik 75% September
  - (2026-08-18) [Manifold] Mary peltola 50.00% or more in first round of Alaska Senate jungle primary?

### USGS earthquakes (M4.5+, past day) — 18 new of 18 total
  - (2026-08-17) M 5.8 - 72 km E of Petropavlovsk-Kamchatsky, Russia
      M5.8 · 72 km E of Petropavlovsk-Kamchatsky, Russia · depth 54.741 km
  - (2026-08-18) M 5.7 - 95 km SW of Puerto Madero, Mexico
      M5.7 · 95 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-08-18) M 5.6 - 154 km SSE of Teluk Dalam, Indonesia
      M5.6 · 154 km SSE of Teluk Dalam, Indonesia · depth 10 km
  - (2026-08-17) M 5.4 - 75 km N of Ruteng, Indonesia
      M5.4 · 75 km N of Ruteng, Indonesia · depth 10 km
  - (2026-08-17) M 5.3 - 24 km ENE of Colonia, Micronesia
      M5.3 · 24 km ENE of Colonia, Micronesia · depth 10 km
  - (2026-08-17) M 5.2 - 81 km N of Ruteng, Indonesia
      M5.2 · 81 km N of Ruteng, Indonesia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-18) Will Belete Molla be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $890,456 · resolves 2026-06-01
  - (2026-08-18) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 28% · 24h volume: $626,553 · resolves 2026-09-16
  - (2026-08-18) Will Wes Moore win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $548,266 · resolves 2028-11-07
  - (2026-08-18) US-Iran 60 day negotiation period extended?
      yes price: 3% · 24h volume: $482,200 · resolves 2026-08-20
  - (2026-08-18) LoL: Nongshim Red Force vs DN SOOPers (BO5) - KeSPA Cup Playoffs
      yes price: 40% · 24h volume: $455,966 · resolves 2026-08-18
  - (2026-08-18) Will there be no change in Fed interest rates after the September 2026 meeting?
      yes price: 72% · 24h volume: $388,148 · resolves 2026-09-16

### U.S. Federal Action — 9 new of 15 total
  - (2026-08-18) Establishing the National Fraud Enforcement Division
      This rule amends Part 0 of the Department of Justice's ("Department") organizational regulations in title 28 of the Code of Federal Regulations to establish the National Fraud Enforcement Division ("Fraud Division") and…
  - (2026-08-18) Anchorages; Bolivar Roads Channel, Galveston, TX
      The Coast Guard is proposing to amend the regulation for the Galveston Harbor, Bolivar Roads Channel, Texas Anchorage grounds (the "Bolivar Anchorage") to institute a 48 hour time limit for anchorage area (A) East. Amend…
  - (2026-08-18) Changes to Delegations
      In this final rule, the Board is revising its regulations to clarify certain existing delegations of authority and create certain new delegations for the Board's Chief Counsel and Chief of Passenger Rail and Investigatio…
  - (2026-08-18) Safety Zone; Lake Michigan, Gary, IN
      The Coast Guard is establishing a temporary safety zone for navigable waters on Lake Michigan in Gary, IN. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards associ…
  - (2026-08-18) Safety Zone; ANCHOR Floating Production Unit (FPU) Outer Continental Shelf Facility, Green Canyon Block 763, Gulf of America
      The Coast Guard is establishing a safety zone around the ANCHOR Floating Production Unit (FPU), located in Green Canyon Block 763 on the Outer Continental Shelf (OCS) in the Gulf of America. Establishing a safety zone ar…
  - (2026-08-18) Safety Zone; Ohio Street Beach Swim Course, Lake Michigan, Chicago Harbor, Chicago, IL
      The Coast Guard will enforce a safety zone for the North Avenue Swim & Triathlon Yo (NASTY) Carb Party event to provide for the safety of life on navigable waterways during a swim race. Our regulation for marine events w…

### State Legislative Action — 9 new of 67 total
  - (2026-08-18) [Alaska HB 195] An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to th…
      An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to the prescription of opioid overdose dr…
  - (2026-08-18) [Alaska SB 41] An Act relating to mental health education.
      An Act relating to mental health education.
  - (2026-08-17) [Alaska HB 314] An Act relating to registered interior designers and interior design; relating to project costs for the construction, enlargement, or improvement of airports; extending the termination…
      An Act relating to registered interior designers and interior design; relating to project costs for the construction, enlargement, or improvement of airports; extending the termination date of the State Board of Registra…
  - (2026-08-17) [Alaska HB 308] An Act relating to release before trial; relating to limitation of driver's licenses; relating to operating a vehicle, aircraft, or watercraft while under the influence of an alcoholic…
      An Act relating to release before trial; relating to limitation of driver's licenses; relating to operating a vehicle, aircraft, or watercraft while under the influence of an alcoholic beverage; and providing for an effe…
  - (2026-08-17) [Alaska HB 136] An Act relating to use of railroad easements.
      An Act relating to use of railroad easements.
  - (2026-08-17) [Alaska HB 324] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 92 total
  - (2026-08-18) [USASpending] $639,625,770 → MISSOURI HIGHER EDUCATION LOAN AUTHORITY: THE PURPOSE OF THIS MODIFICATION IS TO CREATE A NEW TASK ORD
      Agency: Department of Education. Description: THE PURPOSE OF THIS MODIFICATION IS TO CREATE A NEW TASK ORDER FOR CONTRACT ED-FSA-11-D-0012 WITH THE PERIOD OF PERFORMANCE:01/01/2020 - 12/31/2020.
  - (2026-08-18) [USASpending] $601,495,890 → CACI, INC. - FEDERAL: ENTERPRISE LEVEL IT EXPERTISE ELITE
      Agency: General Services Administration. Description: ENTERPRISE LEVEL IT EXPERTISE ELITE
  - (2026-08-18) [USASpending] $581,920,718 → CLARK CONSTRUCTION GROUP LLC: IRA: PROVIDE LABOR, MATERIALS, SUPERVISION, AND EQUIPMENT TO
      Agency: General Services Administration. Description: IRA: PROVIDE LABOR, MATERIALS, SUPERVISION, AND EQUIPMENT TO CONSTRUCT THE NEW CISA HQ BUILDING. SERVICES INCLUDE, BUT ARE NOT LIMITED: CIVIL AND SITE WORK CONSISTING…
  - (2026-08-18) [USASpending] $575,906,799 → HARRIS CORPORATION: DAFIS UDO RECONSTRUCT W/O ADVANCE
      Agency: Department of Transportation. Description: DAFIS UDO RECONSTRUCT W/O ADVANCE
  - (2026-08-18) [USASpending] $574,356,346 → PARSONS GOVERNMENT SERVICES INC.: THE PURPOSE OF THIS AWARD IS FOR THE C5ISR, EXERCISES, OPERA
      Agency: General Services Administration. Description: THE PURPOSE OF THIS AWARD IS FOR THE C5ISR, EXERCISES, OPERATIONS, AND INFORMATION SERVICES (CEOIS) TASK ORDER IS TO PROVIDE NEAR REAL-TIME SITUATIONAL AWARENESS AND…
  - (2026-08-18) [USASpending] $538,508,571 → LOCKHEED MARTIN CORPORATION: THE LOW BOOM FLIGHT DEMONSTRATOR (LBFD) CONTRACT IS FOR THE
      Agency: National Aeronautics and Space Administration. Description: THE LOW BOOM FLIGHT DEMONSTRATOR (LBFD) CONTRACT IS FOR THE DESIGN, CONSTRUCTION, AND FLIGHT VALIDATION OF A RESEARCH AIRCRAFT THAT CREATES A SHAPED SON…

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-18) [Japan] Until Dawn 2 Announced For PS5 , Releasing In 2027
      gamerheadlines.com · English
  - (2026-08-18) [Japan] Japanese bond sell - off ignites as bets surge on BOJ rate hike | The Asahi Shimbun : Breaking News , Japan News and Analysis
      asahi.com · English
  - (2026-08-18) [Japan] Evo Vegas 2026 Registration Crash Signals Prestige Loss
      gamerheadlines.com · English
  - (2026-08-18) [Japan] 007 First Light Is Out Here The Best Merch To Pair With It
      gamerheadlines.com · English
  - (2026-08-18) [Japan] Student shooter kills classmate and himself at Philippine school
      japantoday.com · English
  - (2026-08-18) [Japan] Did an Arizona Warehouse Manager Try to Trap Workers From ICE ?
      attackofthefanboy.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-18) [Marginal Revolution] Morocco facts of the day, Morocco is not hopeless
      For decades, South Africa was the great success story of African industrialization. Last year, Morocco took the lead, emerging as the African Development Bank’s top-ranked industrial economy in Africa. In the Bank’s anal…
  - (2026-08-18) [Marginal Revolution] How economics is changing
      As a proportion of the literature, research about econometric theory, monetary policy and corporate governance has slumped. Meanwhile, papers on development, crime and gender are on the up. This could perhaps be because…
  - (2026-08-17) [Marginal Revolution] Monday assorted links
      1. Where do the great American comedians hail from? 2. General thoughts on biosafety. 3. “Violet Hensley Dies at 109; Ozarks Fiddler Made Opry Debut at 99” (NYT). She also handcrafted 73 fiddles, appeared on The Beverly…
  - (2026-08-17) [Conversable Economist] Welcoming First-Year Students with a Wake-Up Call
      Is it really possible that pretty much every single college and university around the country will, this fall, be welcoming its best-ever, most qualified, most curious, most diverse set of first-year students? Seems unli…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 9 total
  - (2026-08-17) CVE-2025-62593 · Ray-Project Ray: Ray-Project Ray Code Injection Vulnerability
      vendor: Ray-Project · product: Ray · CISA remediation by 2026-08-20

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-18) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=20, 14d-median=20; carrying terms: document, coast, existing, remove, establish, certain, national, procedures, provide, proposes, proposing, state
- state_bills: today=67, 7d-median=87, 14d-median=129; carrying terms: makes, housing, control, authority, health, within, benefits, community, provided, penalty, utilities, support
- state_news: today=422, 7d-median=585, 14d-median=531; carrying terms: temporary, control, health, going, permalink, memorial, question, residents, change, kansas, initiative, collins
- local_news: today=216, 7d-median=216, 14d-median=222; carrying terms: health, house, faces, charles, people, school, night, trump, killed, district, officer, early
- foreign_news: today=962, 7d-median=1007, 14d-median=994; carrying terms: broke, female, inaugural, going, future, result, feeds, memorial, question, interviews, doing, change
- chinese_internal: today=280, 7d-median=270, 14d-median=267; carrying terms: cbmib, people, lxtfa, cbmix, cbmibefvx, lxtfb, cbmizkfvx, cbmia, china, cbmiyefvx, cbmibkfvx, cbmidefvx
- russian_internal: today=990, 7d-median=1040, 14d-median=1024; carrying terms: wildberries, patriot, novayagazeta, laquo, journal, street, target, blank, istories, found, gazeta, httperror
- ukrainian_internal: today=103, 7d-median=108, 14d-median=107; carrying terms: hmarochos, missiles, military, territory, support, prime, weapons, warehouse, people, officials, troops, trump
- ukraine_theater: today=887, 7d-median=1151, 14d-median=944; carrying terms: cbmilgfbvv, vhzhfxdzdmnxzzddnkaelkujdvswewqziwtelcqw, fqdme, nfjzujb, female, cbmir, health, dovelxcxvuakftmtjqohrfde, ewgxak, zywdjqovgxt, delegat, pwmehxr
- paper_bets: today=141, 7d-median=141, 14d-median=140; carrying terms: presidential, degrees, mbappe, control, goals, chase, north, supervolcano, johnny, house, experience, california
- weather: today=159, 7d-median=196, 14d-median=189; carrying terms: afdmeg, monday, strenuous, norman, afdphi, front, within, north, coast, mountains, result, afdokx
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: growth, personal, funds, consumption, dexuseu, latest, jtsjol, rates, cpiaucsl, cpilfesl, dexchus, vixcls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, agriculture, corporate, equities, china, russell, large, treasury, natural, crude, close, rates
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=92, 7d-median=93, 14d-median=98; carrying terms: federation, territorial, corporation, extra, mediterranean, annexation, armed, sectoral, blank, against, nicaragua, destruction
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, unauthorized, quantitative, quiver, quiverquant, client, https, httperror
- billionaires: today=34, 7d-median=34, 14d-median=34; carrying terms: jensen, warren, berkshire, alice, zuckerberg, spacex, charles, nasdaq, walmart, discount, retail, euronext
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: connecticut, health, blanche, state, international, supreme, appeals, company, trade, court, group, trust
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, partners, capital, management, patrick, therapeutics, group, holdings, matthew
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: committee, robert, talarico, booker, trone, receipts, warner, shawn, james, senate, ossoff, raised
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, surge
- gdelt_gkg: today=41, 7d-median=41, 14d-median=39; carrying terms: english, themes, spanish, hezbollah, russian, trump, israel, chinese, china, german, hormuz, perimeter
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: kingdom, israeli, english, nigeria, language, india, domain
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, france, kingdom, canada, germany, bulgaria, aabfa, spain
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: incubation, healthcare, strain, bangladesh, haemorrhage, polio, control, rates, transmission, suspected, verified, awareness
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: cisco, product, langflow, channel, authentication, central, sensitive, teamcity, alternate, tomcat, secure, untrusted
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=260, 14d-median=260; carrying terms: democratic, ecuador, earthquake, maximum, luxembourg, madagascar, cyclone, monaco, somalia, albania, kazakhstan, thailand
- usgs_quakes: today=18, 7d-median=18, 14d-median=15; carrying terms: indonesia, depth, russia, islands, kuril, guinea, south, papua, alaska, ruteng
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, donetsk, hormuz, normal, interest, august, shakhtar, rates, winner, resolves, september, price
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, economist, https, class, marginal, conversable, conversableeconomist, impossible, young, growth, economy, assorted
- tech_news: today=58, 7d-median=58, 14d-median=57; carrying terms: critical, going, provided, operating, newsletter, policy, months, including, hacking, access, online, world
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: warren, owens, housing, kevin, sarah, deposit, klobuchar, biggs, strickland, crenshaw, norman, letlow
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, consensus, placed, module, claude, either, identify, today, paper, decision, market, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*