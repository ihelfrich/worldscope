# WORLDSCOPE morning brief — 2026-08-18

## Headline
3151 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (703) · Russian Internal News (state + in-exile) (702) · World leaders & government officials (324) · State-Level News (295) · Chinese Internal News (225) · Local News: St. Louis + Atlanta (207) · Ukraine Theater (total-war monitoring) (170) · U.S. Weather + Severe / Climate Outlooks (153) · Ukrainian Internal News (national + local Kyiv) (54) · IT, InfoSys & cybersecurity news (last 7 days) (41) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 703 new of 942 total
  - (2026-08-18) [Global] Russia says more than 600 drones targeted Moscow region
      The attacks injured at least three people, including a girl, and damaged a Wildberries warehouse, Russian officials say.
  - (2026-08-18) [Global] Vessel hit by ‘unknown projectile’ in Strait of Hormuz, UKMTO says
      British maritime agency says the incident caused one casualty and damaged the vessel's engine room.
  - (2026-08-18) [Global] Can China’s new Arctic Sea route to Europe replace Middle East chokepoints?
      Beijing's new 'Ice Silk Road' cuts through a melting Arctic, and could prompt fresh tensions with the US, say analysts.
  - (2026-08-18) [Global] Trump says N Korea’s Kim has responded to his request for a conversation
      US president says conversations with Kim Jong Un at a 'positive' stage and slams Seoul for refusing to join war on Iran.
  - (2026-08-18) [Global] Can Trump limit birthright citizenship? Legal experts are doubtful
      Trump’s new order targeting ‘birth tourism’ faces an uphill legal battle after an earlier Supreme Court defeat.
  - (2026-08-18) [Global] A hero’s welcome as Cameroon parades its first Women’s AFCON title
      Cameroon’s women’s football team received a hero’s welcome in Yaounde after winning its first Women’s Africa Cup

### Russian Internal News (state + in-exile) — 702 new of 963 total
  - (2026-08-18) ЦИК убрал «Яблоко» из бюллетеня. Теперь за номером 1 («Единая Россия») сразу идет номер 3 (ЛДПР) | LEDE: Центризбирком России удалил информацию о партии «Яблоко» из избирательного бюллетеня ] (ru: ЦИК…
      Центризбирком России удалил информацию о партии «Яблоко» из избирательного бюллетеня для голосования на выборах в Госдуму, сообщает «Интерфакс».
  - (2026-08-18) В Москве умерла пенсионерка, поджегшая квартиру, когда ее пришли выселять приставы. В 2022 году она продала жилье и передала деньги мошенникам | LEDE: 68-летняя жительница Москвы Наталья Ива] (ru: В М…
      68-летняя жительница Москвы Наталья Иванова, которая в начале августа подожгла себя и свою квартиру, умерла от полученных ожогов. Об этом 18 августа сообщили телеграм-каналы Baza, Mash и Shot, связанные с силовыми структ…
  - (2026-08-18) FT: куратор стройки бального зала в Белом доме во время визита на ПМЭФ провел переговоры с чиновниками Кремля | LEDE: Глава комиссии по изящным искусствам США Родни Мимс Кук во время визита ] (ru: FT:…
      Глава комиссии по изящным искусствам США Родни Мимс Кук во время визита на Петербургский экономический форум (ПМЭФ) в июне 2026 года провел переговоры с чиновниками Кремля в рамках «тихой дипломатической миссии», сообщил…
  - (2026-08-18) Журналистка Катерина Гордеева рассказала историю Анны Архиповой — фигурантки дела молодежного движения «Весна», получившей самый большой срок. Вот главные цитаты | LEDE: В апреле суд в Петер] (ru: Жур…
      В апреле суд в Петербурге вынес приговор фигурантам дела «Весны». Это молодежное оппозиционное движение, которое в 2022 году стало организатором протестов против войны и мобилизации. Шесть фигурантов дела получили от шес…
  - (2026-08-18) «Добровольные пожертвования» бизнеса в российский бюджет с начала 2026 года достигли рекордных 384 миллиардов рублей | LEDE: Безвозмездные поступления от бизнеса в бюджет России за восемь ме] (ru: «До…
      Безвозмездные поступления от бизнеса в бюджет России за восемь месяцев 2026 года составили 383,69 миллиарда рублей — почти в полтора раза больше, чем за весь предыдущий год.
  - (2026-08-18) Жительницу Волгограда оштрафовали из-за участия в коллективном обращении по поводу дефицита бензина | LEDE: Суд в Волгограде назначил местной жительнице Татьяне Сметанко штраф 10 тысяч рубле] (ru: Жит…
      Суд в Волгограде назначил местной жительнице Татьяне Сметанко штраф 10 тысяч рублей по протоколу об участии в массовом мероприятии, обратила внимание «Медиазона».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 295 new of 402 total
  - (2026-08-18) [California] Governor Newsom signs legislation 8.17.2026
      Source
  - (2026-08-17) [California] ICYMI: Law signed by Governor Newsom helps pave the way for the world’s largest union of rideshare drivers
      Source
  - (2026-08-18) [Alaska] Polls open at 7 a.m. on Alaska’s pick-one, top-four statewide primary election day
      Over a month ago, Shelley Cotton cast the first vote in Alaska’s statewide primary election, downloading a blank ballot and sending it quickly by mail from Texas to Alaska. Since then, more than 31,000 other Alaskans hav…
  - (2026-08-17) [Alaska] 5 legislative races to watch in Alaska’s Tuesday primary election
      There are five competitive races for the Alaska House and Senate in this year’s primary election, where candidates are vying for the top four places in order to advance to the ranked choice general election in November.…
  - (2026-08-17) [Alaska] Alaska politicians sport beards and bear-hunting bona fides to claim authenticity
      I was aimlessly scrolling through Instagram when I learned that Jonathan Kreiss-Tomkins, or JKT, had entered the governor’s race. My interest was piqued — not so much by the announcement as the photo attached to it. Fram…
  - (2026-08-17) [Alaska] ‘Hidden homicides’: Families push states for more scrutiny of domestic violence deaths
      Families who believe local officials prematurely ruled their loved ones’ deaths suicides or accidents — rather than investigating whether domestic violence played a role — are pushing lawmakers in a growing number of sta…

### Chinese Internal News — 225 new of 275 total
  - (2026-08-17) China Proposes Independent Privacy Oversight Committees for Big Tech - Caixin Global
      China Proposes Independent Privacy Oversight Committees for Big Tech Caixin Global
  - (2026-08-17) Commentary: The Real Flaw in China’s AI Strategy - Caixin Global
      Commentary: The Real Flaw in China’s AI Strategy Caixin Global
  - (2026-08-17) 郭德纲被举报，谁的压力最大 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBPTzdBYm1uTWFGNWJUVmh2Y1pZbmFqa3EtcE9jRzVKSkZRa00xYnBJajdCTXBrY09rZE91Z3VGSkZpYjdTQ3R6bkY4RFB1SW5mVEtsemlu] (zh:…
      郭德纲被举报，谁的压力最大 财新
  - (2026-08-16) 江苏 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFAzTnRKd0RwbWZVWW1aNHhoR2dFajlMMnZzRXZna2o3UzhYa2hlUEFmU0FzUzIyeGlfa0NveVIzNk5BVHU1cU15TXVMWnRJZTk5UU] (zh:…
      江苏 deepview.caixin.com
  - (2026-08-16) 人物报道-2026夏季达沃斯论坛-手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9CR09Sdi1tMnllOVRQSFk3Ym5xVFJJM2tiMXR0dTgyOV9ZbG0zN0tjYTdvaFJIaVBkeFZpdTZSRTJkOG54REllamlZaEMteHd] (zh:…
      人物报道-2026夏季达沃斯论坛-手机财新网 财新
  - (2026-08-17) 财经早知道｜李强：努力完成全年经济社会发展目标任务 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE13Z2xpSl92b2JJcUl6UXF1V00xR2dGbk1kM0dYYVJLZHJwVnNvSVFTYUU2VTh3WjBFc2NIdlJRcDlNQmlSS1FkMGxaSGw5] (zh:…
      财经早知道｜李强：努力完成全年经济社会发展目标任务 财新

### Local News: St. Louis + Atlanta — 207 new of 214 total
  - (2026-08-18) [St. Louis] Where Art Thou? – 8/18/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-17) [St. Louis] Tamm Story Slamm encourages community connection through storytelling
      In November 2023, Anthony Howell, a young adult working at a power plant, was inspired by the well-known podcast The Moth, in which individuals are given a platform to share a moving story from their lives either on air…
  - (2026-08-17) [St. Louis] Fall getaways in the Midwest
      Mount Magazine State Park | Arkansas As the highest point in Arkansas, Mount Magazine State Park attracts visitors for its views. If you’re into extreme sports, there are plenty of opportunities for mountain biking, rock…
  - (2026-08-17) [St. Louis] St. Louis judge issues warrant for Jill Stein’s arrest
      Perennial Green Party presidential candidate Jill Stein faces an arrest warrant in Missouri after neither she nor her attorney appeared at a hearing Monday morning related to misdemeanor charges for the alleged assault o…
  - (2026-08-17) [St. Louis] Macis’ Prime BBQ joins kitchen lineup at Wash Ave Food Hall
      An additional food vendor has signed on at Wash Ave Food Hall (1122 Washington), the downtown dining and social destination slated to open in October. Macis’ Prime BBQ will join Little BAO (a concept specializing in bao,…
  - (2026-08-17) [St. Louis] The new children’s book encouraging families to rediscover Forest Park
      Local author Amanda Clark and artist Audrey Westcott might’ve created the perfect rainy-day book for kids who love Forest Park. Finding Forest Park keeps little ones connected to the city’s beloved green space both when…

### Ukraine Theater (total-war monitoring) — 170 new of 234 total
  - (2026-08-16) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2016-04-27) [Liveuamap] Israel-Palestine - Liveuamap
      Israel-Palestine Liveuamap
  - (2026-08-11) [Liveuamap] The Damascus Criminal Court: The court imposed the harshest penalty allowed under Syrian law on the defendant Atef Najib. - Liveuamap
      The Damascus Criminal Court: The court imposed the harshest penalty allowed under Syrian law on the defendant Atef Naji
  - (2026-08-13) [Liveuamap] Houthis targeted a commercial ship in Bab al-Mandab Mocha, Yemen - Interactive map of Yemen war - Liveuamap
      Houthis targeted a commercial ship in Bab al-Mandab Mocha, Yemen - Interactive map of Yemen war
  - (2026-08-13) [Liveuamap] A large Israeli explosion in the town of Bani Hayyan, Marjeyoun district, southern Lebanon - Liveuamap
      A large Israeli explosion in the town of Bani Hayyan, Marjeyoun district, southern Lebanon <font colo

### U.S. Weather + Severe / Climate Outlooks — 153 new of 155 total
  - (2026-08-18) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 18 at 2:32AM CDT until August 18 at 3:00AM CDT by NWS Omaha/Valley NE
      At 231 AM CDT, severe thunderstorms were located along a line extending from near Waverly to 2 miles east of Hickman to near Cortland, moving southeast at 50 mph. HAZARD...70 mph wind gusts. SOURCE...Multiple measured wi…
  - (2026-08-18) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 18 at 2:30AM CDT until August 18 at 3:30AM CDT by NWS Omaha/Valley NE
      SVROAX The National Weather Service in Omaha has issued a * Severe Thunderstorm Warning for... Johnson County in southeastern Nebraska... Nemaha County in southeastern Nebraska... Otoe County in southeastern Nebraska...…
  - (2026-08-18) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 18 at 12:28AM MST until August 21 at 8:00PM MST by NWS Phoenix AZ
      * WHAT...Dangerously hot and humid conditions. Afternoon temperatures 106 to 114 expected. Major Heat Risk. * WHERE...Portions of southwest Arizona and southeast California. * WHEN...Until 8 PM MST /8 PM PDT/ Friday. * I…
  - (2026-08-18) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 18 at 12:28AM MST until August 21 at 8:00PM MST by NWS Phoenix AZ
      * WHAT...Dangerously hot conditions. Afternoon temperatures 102 to 109 expected. Major Heat Risk. * WHERE...San Carlos. * WHEN...From 10 AM this morning to 8 PM MST Friday. * IMPACTS...Heat related illnesses increase sig…
  - (2026-08-18) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 18 at 12:28AM MST until August 21 at 8:00PM MST by NWS Phoenix AZ
      * WHAT...Dangerously hot conditions. Afternoon temperatures 105 to 113 expected. Major Heat Risk. * WHERE...Aguila Valley, Apache Junction/Gold Canyon, Cave Creek/New River, Fountain Hills/East Mesa, Gila Bend, Northwest…
  - (2026-08-18) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 18 at 12:28AM MST until August 21 at 8:00PM MST by NWS Phoenix AZ
      * WHAT...Dangerously hot conditions. Afternoon temperatures 108 to 112 expected. Major Heat Risk. * WHERE...The Phoenix metropolitan area. * WHEN...Until 8 PM MST Friday. * IMPACTS...Heat related illnesses increase signi…

### Ukrainian Internal News (national + local Kyiv) — 54 new of 100 total
  - (2026-08-18) Арештували агента РФ, який зареєстрував для ворога 27 терміналів Starlink | LEDE: На Харківщині арештували підозрюваного у держзраді, який верифікував Starlink за завданням росіян.] (uk: Арештували аг…
      На Харківщині арештували підозрюваного у держзраді, який верифікував Starlink за завданням росіян.
  - (2026-08-18) В МЗС Литви розглянуть заклик щодо скорочення часу транзиту росіян | LEDE: У Міністерстві закордониних справ Литви підтвердили, що отримали та розглянуть заклик щодо скорочення часу для транзит] (uk:…
      У Міністерстві закордониних справ Литви підтвердили, що отримали та розглянуть заклик щодо скорочення часу для транзиту громадян РФ територією країни до шести годин.
  - (2026-08-18) Росіяни завдали ракетного удару по Печенігах: загинули 10 людей, є поранені | LEDE: Вранці 18 серпня російські окупаційні війська завдали ракетного удару по Печенігах Харківської області — заги] (uk:…
      Вранці 18 серпня російські окупаційні війська завдали ракетного удару по Печенігах Харківської області — загинули 10 людей.
  - (2026-08-18) До Польщі повернули спецрейсом половину паломників, які потрапили в смертельну ДТП в Угорщині | LEDE: До Польщі повернули державним спецрейсом близько половини польських паломників, автобус яки] (uk:…
      До Польщі повернули державним спецрейсом близько половини польських паломників, автобус яких зазнав смертельної аварії на шляху через Угорщину.
  - (2026-08-18) Росія погрожує Британії через постачання Україні дронів | LEDE: Росія звинуватила Велику Британію в "навмисному прагненні до ескалації" після того, як ЗМІ написали, що під час ударів по цілях н] (uk:…
      Росія звинуватила Велику Британію в "навмисному прагненні до ескалації" після того, як ЗМІ написали, що під час ударів по цілях на території РФ начебто використовували безпілотники британського виробництва.
  - (2026-08-18) ГУР: Росія не планує припиняти вогонь, до кінця року мирної угоди не буде | LEDE: В Головному управлінні розвідки кажуть, що за всіма ознаками Росія не готова припиняти бойові дії на фронті і д] (uk:…
      В Головному управлінні розвідки кажуть, що за всіма ознаками Росія не готова припиняти бойові дії на фронті і до кінця цього року жодних мирних домовленостей не очікується.

### IT, InfoSys & cybersecurity news (last 7 days) — 41 new of 58 total
  - (2026-08-18) [The Hacker News] CISA Flags Actively Exploited Ray Flaw That Can Trigger Browser-Based RCE
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Monday added a critical flaw impacting Ray to its Known Exploited Vulnerabilities (KEV) catalog, citing evidence of active exploitation. Ray is an open-…
  - (2026-08-18) [The Register] Microsoft MVP creates site to remind you of all the brands Redmond replaced
      If you’re still talking about ‘DirSync’ or ‘Active Directory’ instead of ‘Entra’, and need to explain why, this is the site for you
  - (2026-08-18) [The Register] Xen Project gets serious about safety in push to possibly partition robot brains
      Boeing quietly joins FOSS hypervisor crew, as AMD and Renesas lead new effort to comply with formal standards
  - (2026-08-18) [Ars Technica] Theban tomb reveals how Egyptian burial trends evolved in time
      Practices shifted from individuals buried in coffins to reusing sites for later mummy interments.
  - (2026-08-17) [BleepingComputer] Hacker claims 3.6 million Azure account records stolen from major companies
      A threat actor is selling employee databases allegedly stolen from the Microsoft Azure infrastructure of multiple Fortune 500 companies after gaining access using compromised credentials. [...]
  - (2026-08-17) [BleepingComputer] Pokémon Center data breach exposes customer info, cancels some orders
      Pokémon Center is notifying customers in the United Kingdom and Germany that it suffered a third-party data breach after hackers stole customer personal and order information from third-party logistics provider CEVA Logi…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-18) [MediaAlpha, Inc.] Form 4 (Issuer)
      filed 2026-08-18 01:53 UTC · role: Issuer — Filed: 2026-08-17 AccNo: 0001818383-26-000216 Size: 9 KB
  - (2026-08-18) [COYNE JEFFREY B] Form 4 (Reporting)
      filed 2026-08-18 01:53 UTC · role: Reporting — Filed: 2026-08-17 AccNo: 0001818383-26-000216 Size: 9 KB
  - (2026-08-18) [Thompson Patrick Ryan] Form 4 (Reporting)
      filed 2026-08-18 01:53 UTC · role: Reporting — Filed: 2026-08-17 AccNo: 0001818383-26-000215 Size: 9 KB
  - (2026-08-18) [MediaAlpha, Inc.] Form 4 (Issuer)
      filed 2026-08-18 01:53 UTC · role: Issuer — Filed: 2026-08-17 AccNo: 0001818383-26-000215 Size: 9 KB
  - (2026-08-18) [Mobia Medical, Inc.] Form 4 (Issuer)
      filed 2026-08-18 01:53 UTC · role: Issuer — Filed: 2026-08-17 AccNo: 0001193125-26-354538 Size: 10 KB
  - (2026-08-18) [Tansey Casey M] Form 4 (Reporting)
      filed 2026-08-18 01:53 UTC · role: Reporting — Filed: 2026-08-17 AccNo: 0001193125-26-354538 Size: 10 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-18) [Germany] Cash from care , upside from concrete ; Initiate with BUY : BUY , PT € 2 . 80 ( SOTP ). Hamburg holding : united kingdom ...
      domain: finanznachrichten.de · language: English · tone:
  - (2026-08-18) [Australia] Drugs seized at Bellarine property
      domain: krock.com.au · language: English · tone:
  - (2026-08-18) [United States] Russian missiles hit Izmail port in southern Ukraine
      domain: dallassun.com · language: English · tone:
  - (2026-08-18) [United States] St Luke East Texas Hospitals To Adopt New Names in October
      domain: kfox95.com · language: English · tone:
  - (2026-08-18) [United States] 2026 Ram Power Wagon Tradesman Conquers Colorado Brutal Red Cone Trail
      domain: off-road.com · language: English · tone:
  - (2026-08-18) [Malaysia] Indian model Twisha Sharma died by suicide , no significant injuries suggesting physical assault : AIIMS medical board report
      domain: thestar.com.my · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 28 new of 60 total
  - (2026-08-17) U.S. Court of Appeals, 9th Cir.: United States v. Salazar Del Real
  - (2026-08-17) U.S. Court of Appeals, 9th Cir.: Center for Biological Diversity v. United States Bureau of Reclamation
  - (2026-08-17) U.S. Court of Appeals, 9th Cir.: Rusoff v. the Happy Group, Inc.
  - (2026-08-17) U.S. Court of Appeals, 5th Cir.: Meeks v. Ray
  - (2026-08-17) U.S. Court of Appeals, 10th Cir.: United States v. Williams
  - (2026-08-17) U.S. Court of Appeals, 10th Cir.: Andrew v. Tinsley

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-18) [Russia oil sanctions perimeter · themes] Le premier ministre Carney sattend à parler au président Trump dici mercredi
      lerefletdulac.com · French · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] Russian missiles hit Izmail port in southern Ukraine
      dallassun.com · English · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] 河西精装洋房3 . 5万 / ㎡起加推 ！ 南开旁高层特惠126万起 ！
      163.com · Chinese · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] Prohibido bañarse , corte de digestión : las dos horas más largas del verano
      publico.es · Spanish · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] INFORME CLIMA | 2025 registró máximos históricos en emisiones atmosféricas , subida del mar y calor oceánico
      laopiniondezamora.es · Spanish · tone NA
  - (2026-08-18) [Russia oil sanctions perimeter · themes] Անօդաչուների զանգվածային հարձակում Մոսկվայի վրա ․ օդանավակայանների աշխատանքը դադարեցվել է
      azatutyun.am · Armenian · tone NA

### Paper Trading Scorecard — 21 new of 142 total
  - (2026-08-18) [Polymarket] Will the Democrats win the Ohio Senate race in 2026?
      This market will resolve according to the winner of the 2026 Ohio U.S. Senate special election currently scheduled for November 3, inclusive of any run-offs. A candidate shall be considered to represent a party in the ev…
  - (2026-08-18) [Polymarket] Will FaZe Clan Win the CS2 EWC 2026?
      This market will resolve according to the winner of the Counter-Strike 2 tournament at the 2026 Esports World Cup (EWC 2026), currently scheduled for August 12 – August 23, 2026. If this tournament is postponed after Sep…
  - (2026-08-18) [Polymarket] Will Michelle Bolsonaro win the 2026 Brazilian presidential election?
      A presidential election is scheduled to take place in Brazil on October 4, 2026. This market will resolve according to the listed candidate that wins this election. This market includes any potential second round. If the…
  - (2026-08-18) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-08-18) [Manifold] Mary peltola 50.00% or more in first round of Alaska Senate jungle primary?
  - (2026-08-18) [Manifold] Will MAA make a meaningful (definition in description) step to secure AIME?

### USGS earthquakes (M4.5+, past day) — 17 new of 18 total
  - (2026-08-17) M 5.8 - 72 km E of Petropavlovsk-Kamchatsky, Russia
      M5.8 · 72 km E of Petropavlovsk-Kamchatsky, Russia · depth 54.741 km
  - (2026-08-18) M 5.7 - 95 km SW of Puerto Madero, Mexico
      M5.7 · 95 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-08-18) M 5.6 - 154 km SSE of Teluk Dalam, Indonesia
      M5.6 · 154 km SSE of Teluk Dalam, Indonesia · depth 10 km
  - (2026-08-17) M 5.4 - 75 km N of Ruteng, Indonesia
      M5.4 · 75 km N of Ruteng, Indonesia · depth 10 km
  - (2026-08-17) M 5.3 - 24 km ENE of Colonia, Micronesia
      M5.3 · 24 km ENE of Colonia, Micronesia · depth 10 km
  - (2026-08-17) M 5.2 - 81 km N of Ruteng, Indonesia
      M5.2 · 81 km N of Ruteng, Indonesia · depth 10 km

### Government & military aircraft airborne (OpenSky) — 15 new of 16 total
  - (2026-08-18) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (46.0835, 0.0295) · alt: 10675m · 801km/h
  - (2026-08-18) JAF76T (Bulgaria)
      icao24: 4520aa · position: (47.1784, -0.6704) · alt: 9761m · 886km/h
  - (2026-08-18) GAF103 (Germany)
      icao24: 3ea653 · position: (49.8659, 10.2515) · alt: 9448m · 857km/h
  - (2026-08-18) JAF2XD (Belgium)
      icao24: 44d1a7 · position: (41.512, 18.1209) · alt: 11277m · 911km/h
  - (2026-08-18) JAF7HW (Belgium)
      icao24: 44d1a5 · position: (32.1081, -16.1185) · alt: 11277m · 794km/h
  - (2026-08-18) JAF63N (Belgium)
      icao24: 44d1c2 · position: (40.4164, 1.8886) · alt: 8854m · 830km/h

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-18) Will Belete Molla be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $737,561 · resolves 2026-06-01
  - (2026-08-18) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 28% · 24h volume: $619,945 · resolves 2026-09-16
  - (2026-08-18) Will Wes Moore win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $548,314 · resolves 2028-11-07
  - (2026-08-18) US-Iran 60 day negotiation period extended?
      yes price: 4% · 24h volume: $500,465 · resolves 2026-08-20
  - (2026-08-18) Will there be no change in Fed interest rates after the September 2026 meeting?
      yes price: 72% · 24h volume: $363,303 · resolves 2026-09-16
  - (2026-08-18) Will Club Puebla win on 2026-08-17?
      yes price: 100% · 24h volume: $294,315 · resolves 2026-08-18

### U.S. Federal Action — 9 new of 15 total
  - (2026-08-18) Establishing the National Fraud Enforcement Division
      This rule amends Part 0 of the Department of Justice's ("Department") organizational regulations in title 28 of the Code of Federal Regulations to establish the National Fraud Enforcement Division ("Fraud Division") and…
  - (2026-08-18) Anchorages; Bolivar Roads Channel, Galveston, TX
      The Coast Guard is proposing to amend the regulation for the Galveston Harbor, Bolivar Roads Channel, Texas Anchorage grounds (the "Bolivar Anchorage") to institute a 48 hour time limit for anchorage area (A) East. Amend…
  - (2026-08-18) Changes to Delegations
      In this final rule, the Board is revising its regulations to clarify certain existing delegations of authority and create certain new delegations for the Board's Chief Counsel and Chief of Passenger Rail and Investigatio…
  - (2026-08-18) Safety Zone; Lake Michigan, Gary, IN
      The Coast Guard is establishing a temporary safety zone for navigable waters on Lake Michigan in Gary, IN. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards associ…
  - (2026-08-18) Safety Zone; ANCHOR Floating Production Unit (FPU) Outer Continental Shelf Facility, Green Canyon Block 763, Gulf of America
      The Coast Guard is establishing a safety zone around the ANCHOR Floating Production Unit (FPU), located in Green Canyon Block 763 on the Outer Continental Shelf (OCS) in the Gulf of America. Establishing a safety zone ar…
  - (2026-08-18) Safety Zone; Ohio Street Beach Swim Course, Lake Michigan, Chicago Harbor, Chicago, IL
      The Coast Guard will enforce a safety zone for the North Avenue Swim & Triathlon Yo (NASTY) Carb Party event to provide for the safety of life on navigable waterways during a swim race. Our regulation for marine events w…

### State Legislative Action — 9 new of 67 total
  - (2026-08-18) [Alaska HB 195] An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to th…
      An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to the prescription of opioid overdose dr…
  - (2026-08-18) [Alaska SB 41] An Act relating to mental health education.
      An Act relating to mental health education.
  - (2026-08-17) [Alaska HB 314] An Act relating to registered interior designers and interior design; relating to project costs for the construction, enlargement, or improvement of airports; extending the termination…
      An Act relating to registered interior designers and interior design; relating to project costs for the construction, enlargement, or improvement of airports; extending the termination date of the State Board of Registra…
  - (2026-08-17) [Alaska HB 308] An Act relating to release before trial; relating to limitation of driver's licenses; relating to operating a vehicle, aircraft, or watercraft while under the influence of an alcoholic…
      An Act relating to release before trial; relating to limitation of driver's licenses; relating to operating a vehicle, aircraft, or watercraft while under the influence of an alcoholic beverage; and providing for an effe…
  - (2026-08-17) [Alaska HB 136] An Act relating to use of railroad easements.
      An Act relating to use of railroad easements.
  - (2026-08-17) [Alaska HB 324] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-08-18) MOVER ▲ Elon Musk — $894.95B (+$30.70B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-18) MOVER ▼ Mark Zuckerberg — $195.44B ($-7.08B since yesterday)
      United States · Technology · source: Facebook
  - (2026-08-18) MOVER ▼ Larry Ellison — $188.51B ($-4.05B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-18) MOVER ▼ Steve Ballmer — $148.49B ($-3.80B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-08-18) MOVER ▼ Michael Dell — $251.71B ($-3.34B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-18) MOVER ▲ Thomas Peterffy — $108.99B (+$2.46B since yesterday)
      United States · Finance & Investments · source: Discount brokerage

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 92 total
  - (2026-08-18) [USASpending] $639,625,770 → MISSOURI HIGHER EDUCATION LOAN AUTHORITY: THE PURPOSE OF THIS MODIFICATION IS TO CREATE A NEW TASK ORD
      Agency: Department of Education. Description: THE PURPOSE OF THIS MODIFICATION IS TO CREATE A NEW TASK ORDER FOR CONTRACT ED-FSA-11-D-0012 WITH THE PERIOD OF PERFORMANCE:01/01/2020 - 12/31/2020.
  - (2026-08-18) [USASpending] $601,495,890 → CACI, INC. - FEDERAL: ENTERPRISE LEVEL IT EXPERTISE ELITE
      Agency: General Services Administration. Description: ENTERPRISE LEVEL IT EXPERTISE ELITE
  - (2026-08-18) [USASpending] $581,920,718 → CLARK CONSTRUCTION GROUP LLC: IRA: PROVIDE LABOR, MATERIALS, SUPERVISION, AND EQUIPMENT TO
      Agency: General Services Administration. Description: IRA: PROVIDE LABOR, MATERIALS, SUPERVISION, AND EQUIPMENT TO CONSTRUCT THE NEW CISA HQ BUILDING. SERVICES INCLUDE, BUT ARE NOT LIMITED: CIVIL AND SITE WORK CONSISTING…
  - (2026-08-18) [USASpending] $575,906,799 → HARRIS CORPORATION: DAFIS UDO RECONSTRUCT W/O ADVANCE
      Agency: Department of Transportation. Description: DAFIS UDO RECONSTRUCT W/O ADVANCE
  - (2026-08-18) [USASpending] $574,356,346 → PARSONS GOVERNMENT SERVICES INC.: THE PURPOSE OF THIS AWARD IS FOR THE C5ISR, EXERCISES, OPERA
      Agency: General Services Administration. Description: THE PURPOSE OF THIS AWARD IS FOR THE C5ISR, EXERCISES, OPERATIONS, AND INFORMATION SERVICES (CEOIS) TASK ORDER IS TO PROVIDE NEAR REAL-TIME SITUATIONAL AWARENESS AND…
  - (2026-08-18) [USASpending] $538,508,571 → LOCKHEED MARTIN CORPORATION: THE LOW BOOM FLIGHT DEMONSTRATOR (LBFD) CONTRACT IS FOR THE
      Agency: National Aeronautics and Space Administration. Description: THE LOW BOOM FLIGHT DEMONSTRATOR (LBFD) CONTRACT IS FOR THE DESIGN, CONSTRUCTION, AND FLIGHT VALIDATION OF A RESEARCH AIRCRAFT THAT CREATES A SHAPED SON…

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-18) [Japan] Student shooter kills classmate and himself at Philippine school
      japantoday.com · English
  - (2026-08-18) [Japan] Did an Arizona Warehouse Manager Try to Trap Workers From ICE ?
      attackofthefanboy.com · English
  - (2026-08-18) [Japan] Itoshima Records Seismic Intensity 4
      fukuoka-now.com · English
  - (2026-08-18) [Japan] RIVER OF SNAKES - FUKUOKA LIVE
      fukuoka-now.com · English
  - (2026-08-18) [Japan] Fukuoka Assembly Speaker Plans to Resign
      fukuoka-now.com · English
  - (2026-08-18) [Japan] Kitazaki Shared Taxi Service to Launch
      fukuoka-now.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-18) [Marginal Revolution] Morocco facts of the day, Morocco is not hopeless
      For decades, South Africa was the great success story of African industrialization. Last year, Morocco took the lead, emerging as the African Development Bank’s top-ranked industrial economy in Africa. In the Bank’s anal…
  - (2026-08-18) [Marginal Revolution] How economics is changing
      As a proportion of the literature, research about econometric theory, monetary policy and corporate governance has slumped. Meanwhile, papers on development, crime and gender are on the up. This could perhaps be because…
  - (2026-08-17) [Marginal Revolution] Monday assorted links
      1. Where do the great American comedians hail from? 2. General thoughts on biosafety. 3. “Violet Hensley Dies at 109; Ozarks Fiddler Made Opry Debut at 99” (NYT). She also handcrafted 73 fiddles, appeared on The Beverly…
  - (2026-08-17) [Conversable Economist] Welcoming First-Year Students with a Wake-Up Call
      Is it really possible that pretty much every single college and university around the country will, this fall, be welcoming its best-ever, most qualified, most curious, most diverse set of first-year students? Seems unli…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 9 total
  - (2026-08-17) CVE-2025-62593 · Ray-Project Ray: Ray-Project Ray Code Injection Vulnerability
      vendor: Ray-Project · product: Ray · CISA remediation by 2026-08-20

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-18) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=20, 14d-median=20; carrying terms: national, coast, proposes, action, document, program, specifically, certain, remove, establish, state, proposing
- state_bills: today=67, 7d-median=87, 14d-median=124; carrying terms: training, prohibits, utilities, forth, existing, income, health, relating, establishes, control, adopt, required
- state_news: today=402, 7d-median=585, 14d-median=585; carrying terms: utilities, health, because, article, three, asked, featured, access, dcist, judge, editor, study
- local_news: today=214, 7d-median=214, 14d-median=229; carrying terms: https, suspect, health, three, shooting, historic, police, nearly, louis, alert, music, following
- foreign_news: today=942, 7d-median=1007, 14d-median=1007; carrying terms: growth, elephant, significant, integration, japan, shows, reach, coast, continents, sslerror, banque, protest
- chinese_internal: today=275, 7d-median=270, 14d-median=269; carrying terms: cbmizkfvx, china, google, politics, cbmia, global, cbmiyefvx, cbmidefvx, cbmizefvx, cbmibefvx, cbmib, color
- russian_internal: today=963, 7d-median=1040, 14d-median=1040; carrying terms: politico, novaya, media, found, https, reuters, telegram, forbidden, error, journal, europe, novayagazeta
- ukrainian_internal: today=100, 7d-median=108, 14d-median=107; carrying terms: damage, ukrinform, campaign, national, border, https, president, forces, missiles, remain, struck, forbidden
- ukraine_theater: today=234, 7d-median=1151, 14d-median=1001; carrying terms: wllxrtzunmhwoxfobdhyrwdqzefmszuteenqnw, vnjpus, training, lboeuwog, ntbho, cbmingfbvv, wkpcutrtzfnsumnpajvtbvr, cbmiukfvx, ajhxmva, cuxnbi, featuring, health
- paper_bets: today=142, 7d-median=142, 14d-median=139; carrying terms: growth, miles, republican, polymarket, colorado, mexico, president, trading, market, majors, population, headline
- weather: today=155, 7d-median=196, 14d-median=196; carrying terms: damage, extended, national, evening, significant, tonight, central, temperatures, northern, locations, index, below
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: total, unemployment, sheet, balance, dexjpus, dcoilwtico, pcepilfe, payems, growth, dexuseu, crude, commodities
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, natural, corporate, proxy, credit, equities, china, large, crude, futures, crypto, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=92, 7d-median=93, 14d-median=99; carrying terms: drilling, campaign, belarus, resolution, national, illegal, daesh, federation, haitian, https, detect, blank
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, httperror, quiver, https, client, quantitative, quiverquant, error, unauthorized
- billionaires: today=40, 7d-median=35, 14d-median=34; carrying terms: steve, adani, larry, infrastructure, paris, microsoft, charles, commodities, investments, brokerage, semiconductors, meyers
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: connecticut, company, court, blanche, state, appeals, supreme, group, trade, health, international, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, issuer, filed, partners, capital, holdings, patrick, management, therapeutics, group, matthew
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: alexandria, brown, ossoff, lindsey, talarico, disbursements, filing, sherrod, booker, graham, cooper, senate
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan
- gdelt_gkg: today=25, 7d-median=37, 14d-median=37; carrying terms: english, themes, trump, russian, spanish, chinese, german, vietnamese, turkish, online, russia, ukrainian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: nigeria, language, kingdom, trump, price, israeli, india, domain, english, iheart
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=16, 7d-median=29, 14d-median=26; carrying terms: belgium, position, canada, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: ebola, infant, private, hospital, november, confirmation, acute, national, nigeria, director, significant, consecutive
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: firewall, cisco, tomcat, secure, remediation, jetbrains, encryption, channel, central, vendor, alternate, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=251; carrying terms: north, depth, tropical, albania, sweden, belarus, earthquake, hungary, dolphin, nicaragua, ukraine, vietnam
- usgs_quakes: today=18, 7d-median=18, 14d-median=14; carrying terms: depth, indonesia, islands, russia, kuril, papua, guinea, south, alaska, ruteng
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, september, interest, normal, price, returns, league, champions, volume, hormuz, championship, august
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, marginal, class, conversable, economist, revolution, conversableeconomist, impossible, young, growth, economy, links
- tech_news: today=58, 7d-median=58, 14d-median=56; carrying terms: software, https, hacker, going, power, technica, download, access, vulnerabilities, including, companies, according
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: mcmahon, elena, clarke, laura, mcgarvey, craig, castro, danny, sherman, julie, scanlon, lance
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, markets, evidence, consensus, unavailable, converges, either, placed, placement, sufficient, module, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*