# WORLDSCOPE morning brief — 2026-10-06

## Headline
3225 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (816) · Russian Internal News (state + in-exile) (717) · World leaders & government officials (324) · State-Level News (320) · Local News: St. Louis + Atlanta (220) · Chinese Internal News (196) · Ukraine Theater (total-war monitoring) (111) · State Legislative Action (110) · U.S. Weather + Severe / Climate Outlooks (95) · Ukrainian Internal News (national + local Kyiv) (61) · IT, InfoSys & cybersecurity news (last 7 days) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 816 new of 1001 total
  - (2026-10-06) [Global] 'Heavy police presence' as students set to march in Paris
      A major march is set to depart from central Paris this afternoon as French students continue their protests classroom conditions. With previous protests marred by violence, France 24’s Claire Paccalin reports that there…
  - (2026-10-06) [Global] Mexico makes push for fracking despite environmental concerns
      Following months of consultations with energy experts, Mexico is preparing to tap its shale oil and gas reserves using one of the world's most controversial extraction techniques: fracking. The process is already used to…
  - (2026-10-06) [Global] 🔴 UK police arrest 22-year-old Briton in suspected Fairford base plot
  - (2026-10-06) [Global] Tigray students relocated by conflict say fled forced conscription
      Due to the ongoing fighting in Ethiopia's Tigray region, some 5,000 students who asked to be relocated are now starting the academic year far from home. Some say back home they faced forced conscription to fight for a ca…
  - (2026-10-06) [Global] Students protest Cornell's response to gang rape complaint
      Students at Cornell University staged an anti-rape protest on Monday and to voice their solidarity with ‘Jane Doe’ - the former student who was allegedly ganged raped after consuming drugs and alcohol at a frat house two…
  - (2026-10-06) [Global] UK police arrest 22-year-old British man in suspected Fairford base plot
      UK ​police on Tuesday said they had ​arrested ‌a ⁠22-year ‌old British man ⁠in London on suspicion ​of preparing terrorist acts ‌in relation ​to the suspected plot at the ​RAF ​Fairford ​airbase used ​by the US to strike…

### Russian Internal News (state + in-exile) — 717 new of 1074 total
  - (2026-10-06) Германия заявила, что не меняла правила выдачи студенческих виз россиянам. Ранее власти отказали в визе выпускнице ВШЭ из-за «угрозы безопасности» | LEDE: Германия продолжает выдавать студен] (ru: Гер…
      Германия продолжает выдавать студенческие визы гражданам России, но каждое заявление рассматривается индивидуально. Так в посольстве ФРГ в Москве прокомментировали случай студентки ВШЭ, которой отказали в учебной визе из…
  - (2026-10-06) The New York Times: США вывели бомбардировщики с авиабазы в Великобритании, так как опасались диверсии Ирана по типу украинской «Паутины» | LEDE: США эвакуировали бомбардировщики с авиабазы ] (ru: The…
      США эвакуировали бомбардировщики с авиабазы Фэрфорд в Великобритании, так как получили данные о возможной атаке иранских беспилотников, пишет The New York Times.
  - (2026-10-06) Представитель АдГ Тобиас Рауш стал главой парламента Саксонии-Анхальт. Он — первый ультраправый политик Германии, занявший такой пост | LEDE: 35-летний Тобиас Рауш из ультраправой «Альтернат] (ru: Пре…
      35-летний Тобиас Рауш из ультраправой «Альтернативы для Германии» избран председателем парламента федеральной земли Саксония-Анхальт. Он стал первым в Германии политиком от этой партии, который занял пост главы ландтага.
  - (2026-10-06) В США впервые со Второй мировой войны казнят военнослужащего через расстрел. Приговоренный — Нидаль Хасан, убивший 13 сослуживцев на базе Форт-Худ | LEDE: Президент США Дональд Трамп санкцио] (ru: В С…
      Президент США Дональд Трамп санкционировал казнь бывшего военного психиатра армии США Нидаля Хасана, убившего в 2009 году 13 человек на базе Форт-Худ.
  - (2026-10-06) «К востоку от Эдема» — на Netflix вышла идеальная экранизация романа Джона Стейнбека. В ней Флоренс Пью играет свою лучшую роль со времен «Солнцестояния» | LEDE: На Netflix 1 октября вышел с] (ru: «К…
      На Netflix 1 октября вышел сериал «К востоку от Эдема» (East of Eden) — экранизация классического романа Джона Стейнбека, созданная актрисой и сценаристкой Зои Казан. Эту книгу, посвященную нескольким поколениям одной ам…
  - (2026-10-06) На журналиста Андрея Лошака завели дело об «оправдании терроризма» | LEDE: Басманный суд Москвы заочно арестовал журналиста, автора документальных фильмов Андрея Лошака по делу об «оправдани] (ru: На…
      Басманный суд Москвы заочно арестовал журналиста, автора документальных фильмов Андрея Лошака по делу об «оправдании терроризма», сообщили «Осторожно, новости».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 320 new of 486 total
  - (2026-10-06) [California] Fed up with recalls, CA Democrats ask voters to change the rules
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/100503_Gray-Davis-Recall_GETTY_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-10-06) [California] ‘Evaluators’ are supposed to keep AI from killing us all. No pressure
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/091526_Dreamforce-2026_AHK_CM_35.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-10-06) [California] Embattled Northern California charter school files for bankruptcy
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/092126-Highlands-Charter-MG-CM-12.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-10-06) [California] Republican Hilton’s ‘Just try it’ ad courts liberals — and angers his own base
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/100526-Steve-Hilton-Ad-CM-03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-10-06) [California] He’s trying to break generational ties to gangs. Los Angeles police keep targeting him
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/091826_FALLOUT-LAPD_AD_CM_08.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-10-05) [California] Las familias de California se están quedando sin tiempo para usar el beneficio de $120 por niño en alimentos
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/061424_Healthy-Food-Access_JG_CM_10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### Local News: St. Louis + Atlanta — 220 new of 235 total
  - (2026-10-06) [St. Louis] Flock Food Truck Park transitions to Heaterz at the Riverfront in downtown Alton
      Flock Food Truck Park (210 Ridge) will finish its fifth and final season in downtown Alton on December 20, but the gathering place that Laura Windisch helped create will carry on. Next spring, the property is slated to r…
  - (2026-10-06) [St. Louis] Wagner touts funding for MoDOT that she voted against
      Last week, U.S. Rep. Ann Wagner boasted about her work securing funds for the Missouri Department of Transportation. She posted a photo on Facebook of her visit with MoDOT’s St. Louis district engineer and said she’d per…
  - (2026-10-06) [St. Louis] Where Art Thou 10/6/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-10-06) [St. Louis] Ask Cheryl: How can I incorporate persimmons into my cooking?
      Persimmon season in Missouri is roughly September through October, and while these fruits are a delicious treat, they can be hard to find and are often considered a niche culinary item. There are many reasons for this, b…
  - (2026-10-06) [St. Louis] Cinema St. Louis celebrates the spirit of independent film at SLIFF 2026
      The St. Louis International Film Festival is turning 35, and this year’s festival, which runs from November 5-15, is a celebration of the spirit of independent film. This year’s festival theme is “The Declaration of Inde…
  - (2026-10-05) [St. Louis] St. Louis police on the scent of burglar breaking into homes while people sleep
      St. Louis police say they are on the tail of a midnight menace—a bold thief breaking into occupied homes and in one case even stealing items from a bedroom while the homeowner was asleep in bed. St. Louis Metropolitan Po…

### Chinese Internal News — 196 new of 255 total
  - (2026-10-06) 在这种时候，也许只有音乐才能给他莫大的抚慰｜带着问题去读书 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBGa3F6R2llS3JLZkRyZ190UE5ha0J0VVFfSHN6eExVdVdUMEdPREMwWEhMd2N4WUwtT1hSRFJkTDNFWWdQZUZFWWlS] (zh:…
      在这种时候，也许只有音乐才能给他莫大的抚慰｜带着问题去读书 财新
  - (2026-10-06) 知名科普博主洪广玉被刑拘 曾参与大连樱桃种植户维权活动 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBFUDVvaVV4YUV4UkFtblBYODZBWmIzVDE1dTJpYTk2WHNLMWI1aHUyc1c4QWhRVkZJZF9HMlZzX01S] (zh:…
      知名科普博主洪广玉被刑拘 曾参与大连樱桃种植户维权活动 china.caixin.com
  - (2026-10-04) 财新闻｜169金89银83铜收官，中国队创境外参加亚运会最佳战绩 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBqSVo5eFo0YndpSzBMV3U3WXQ4SlFod1ZobVZqOXhyTTVwcFNabmVwODRUajU5THpVaGhURTJ5aEJTNWpkN0Q1T] (zh:…
      财新闻｜169金89银83铜收官，中国队创境外参加亚运会最佳战绩 财新
  - (2026-10-06) 贵州“村超”首个海外赛区签约，“村超”模式正式走出国门 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1lVkJHMHZyMHMtcUluRlhzUU5Vem4zNkJzSDU0U05EWGVpblNmTTBzczJOYmNGSThFRjA2ZHFMalN5MWtnYWs2TE5ZbF] (zh:…
      贵州“村超”首个海外赛区签约，“村超”模式正式走出国门 财新
  - (2026-10-06) 雕与塑的完美结合｜千年麦积山石窟⑤ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE4yeUZoVXdwUl9leTN3MFlvZDNQXzdHeFhPbDJLakZLLWs5UUUxemJPbDUwN1FzUk92MzJlQlRwTkZ3UkVocVZfWDZkM3JmUjVjdGxz] (zh:…
      雕与塑的完美结合｜千年麦积山石窟⑤ 财新
  - (2026-10-06) 清华经管学院顾问委员会扩容 黄仁勋、苏姿丰等成新增委员 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1qd0hsLWFEdmczQTVxNEh1LTh3RVdtR3lMRXU4blc4bEJjZXJ4bG9FZmlSTE5UTUIydlNxWHlrNDV6OVZqc2JHS2paeX] (zh:…
      清华经管学院顾问委员会扩容 黄仁勋、苏姿丰等成新增委员 财新

### Ukraine Theater (total-war monitoring) — 111 new of 337 total
  - (2026-10-06) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-04) [Liveuamap] Houthis forces begin entering the city of Turbeh in Taiz At Turbah, Yemen - Interactive map of Yemen war - yemen.liveuamap.com
      Houthis forces begin entering the city of Turbeh in Taiz At Turbah, Yemen - Interactive map of Yemen war
  - (2026-10-04) [Liveuamap] Ukraine - Liveuamap
      Ukraine Liveuamap
  - (2026-10-05) [Liveuamap] ‎Yemeni Armed Forces: Yemeni forces seize control of Mocha after intense clashes under air cover. - yemen.liveuamap.com
      ‎Yemeni Armed Forces: Yemeni forces seize control of Mocha after intense clashes under air cover. <fo
  - (2026-10-06) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - yemen.liveuamap.com
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com yemen.liveuamap.com
  - (2026-10-05) [Liveuamap] Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com - sudan.liveuamap.com
      Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com sudan.liveuamap.com

### State Legislative Action — 110 new of 118 total
  - (2026-10-06) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…
  - (2026-10-05) [Alaska HB 280] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and tele…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and telecommunications service providers; an…
  - (2026-10-05) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-10-05) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-10-06) [California AB 2015] Department of Transportation: third-party navigation applications: study and report.
      Existing law establishes the Department of Transportation and vests it with full possession and control of the state highway system. This bill would require the department, in consultation with the Transportation Agency…
  - (2026-10-06) [California AB 1848] California Seed Law: annual registration fee: Seed Advisory Board.
      Existing law, the California Seed Law, regulates seed sold in California and requires every labeler of agricultural or vegetable seed offered for sale in this state or any persons who sell seed in this state, as provided…

### U.S. Weather + Severe / Climate Outlooks — 95 new of 97 total
  - (2026-10-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-06) [Severe] Freeze Warning: Freeze Warning issued October 6 at 9:28AM EDT until October 7 at 9:00AM EDT by NWS Boston/Norton MA
      * WHAT...Sub-freezing temperatures of 26 to 31 degrees expected. * WHERE...Franklin County, and Hampshire County. * WHEN...From 11 PM this evening to 9 AM EDT Wednesday. * IMPACTS...Frost and freeze conditions could kill…
  - (2026-10-06) [Severe] Flood Warning: Flood Warning issued October 6 at 8:21AM CDT until October 7 at 7:00AM CDT by NWS Omaha/Valley NE
      ...The Flood Warning continues for the following rivers in Nebraska... Big Blue River At Beatrice affecting Gage County. * WHAT...Minor flooding is occurring and minor flooding is forecast. * WHERE...Big Blue River at Be…
  - (2026-10-06) [Moderate] Rip Current Statement: Rip Current Statement issued October 6 at 9:11AM EDT until October 6 at 8:00PM EDT by NWS Charleston SC
      * WHAT...For the High Rip Current Risk, dangerous rip currents. For the High Surf Advisory, large breaking waves of 4 to 6 feet expected in the surf zone. For the Coastal Flood Advisory, up to one foot of inundation abov…
  - (2026-10-06) [Moderate] Rip Current Statement: Rip Current Statement issued October 6 at 9:11AM EDT until October 6 at 8:00PM EDT by NWS Charleston SC
      * WHAT...For the High Rip Current Risk, dangerous rip currents. For the High Surf Advisory, large breaking waves of 4 to 7 feet expected in the surf zone. * WHERE...Georgia Beaches, Beaufort, and Coastal Jasper. * WHEN..…
  - (2026-10-06) [Severe] Flood Warning: Flood Warning issued October 6 at 7:59AM CDT until October 8 at 5:21PM CDT by NWS Topeka KS
      ...The Flood Warning continues for the following rivers in Kansas... Big Blue River near Blue Rapids affecting Marshall County. * WHAT...Minor flooding is occurring and minor flooding is forecast. * WHERE...Big Blue Rive…

### Ukrainian Internal News (national + local Kyiv) — 61 new of 129 total
  - (2026-10-06) У Франції випробували нову балістичну ракету, яку запустили з атомного підводного човна | LEDE: Президент Франції Емманюель Макрон став свідком тестового запуску нової балістичної ракети з атом] (uk:…
      Президент Франції Емманюель Макрон став свідком тестового запуску нової балістичної ракети з атомного підводного човна.
  - (2026-10-06) Рубіо закликав Росію розкрити більше інформації про смерть лаборантки від чуми | LEDE: Держсекретар США Марко Рубіо закликав Росію надати додаткову інформацію щодо смерті працівниці лабораторії] (uk:…
      Держсекретар США Марко Рубіо закликав Росію надати додаткову інформацію щодо смерті працівниці лабораторії з дослідження чуми в Сибіру.
  - (2026-10-06) Польща виділить $26 млрд на цивільний захист: фінансуватимуть укриття і енергопостачання | LEDE: Кабмін Польщі затвердить програму цивільного захисту на 2027–2031 роки з фінансуванням понад 100] (uk:…
      Кабмін Польщі затвердить програму цивільного захисту на 2027–2031 роки з фінансуванням понад 100 млрд злотих для укриттів, енергозабезпечення та регіональних проєктів.
  - (2026-10-06) У monobank з'явилася знижка 25% на підписку "Української правди" | LEDE: У застосунку monobank з'явилася персональна пропозиція для клієнтів банку. До 31 жовтня користувачі monobank можуть отри] (uk:…
      У застосунку monobank з'явилася персональна пропозиція для клієнтів банку. До 31 жовтня користувачі monobank можуть отримати промокод на знижку 25% та використати його під час оформлення підписки на "Українську правду".…
  - (2026-10-06) РФ може підвищити швидкість реактивних дронів до 800-900 км/год – яку протидію готує Україна | LEDE: У Повітряних силах прогнозують, що держава-агресор РФ підвищить швидкість реактивних дронів,] (uk:…
      У Повітряних силах прогнозують, що держава-агресор РФ підвищить швидкість реактивних дронів, які використовує, до 800-900 км на годину.
  - (2026-10-06) Росіяни обстріляли дорогу на Одещині: пошкоджені вантажівки, 5 людей постраждали | LEDE: Російські війська 6 жовтня обстріляли дорогу в Одеській області – постраждало 5 людей, двоє госпіталізов] (uk:…
      Російські війська 6 жовтня обстріляли дорогу в Одеській області – постраждало 5 людей, двоє госпіталізовані, один у тяжкому стані.

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 57 total
  - (2026-10-06) [BleepingComputer] Wikimedia: Rogue OpenAI agents behind unauthorized Wikipedia edits
      The Wikimedia Foundation says rogue OpenAI agents made unauthorized Wikipedia edits and may have been partially responsible for a May outage. [...]
  - (2026-10-06) [BleepingComputer] Nikkei discloses breaches of employees’ Microsoft, Google email accounts
      Over the weekend, Japanese publishing giant Nikkei disclosed that unknown attackers recently breached two employee email accounts and used one to send thousands of phishing emails. [...]
  - (2026-10-06) [BleepingComputer] Engineer sentenced for locking over 3,000 devices on employer network
      A former core infrastructure engineer at an industrial company headquartered in New Jersey was sentenced to 32 months in prison for locking thousands of devices on his employer's network in a ransomware-style attack. [..…
  - (2026-10-06) [The Hacker News] LibreOffice and OpenOffice Flaws Let Malicious Spreadsheets Run Code Without Macro Warnings
      A malicious spreadsheet can make LibreOffice and Apache OpenOffice run an attacker's code as soon as the file is opened, security researchers have shown. There is no warning first, of the kind either program shows before…
  - (2026-10-06) [The Hacker News] Wikimedia Says OpenAI Agents Tried to Compromise Etherpad and Use Wiki Tools as Proxies
      The Wikimedia Foundation, which hosts Wikipedia, has confirmed that it has discovered activity by rogue OpenAI agents on its platforms, including unsuccessful efforts to compromise Etherpad, a public note-taking tool, an…
  - (2026-10-06) [The Hacker News] Welcome to the Jungle: What We Found Inside 15,465 Public MCP Servers
      In 2024, MCP (Model Context Protocol) set out to become the USB-C of AI: one standard for connecting models, agents, and IDEs to tools and data. The protocol delivered. Thousands of developers built servers, and enterpri…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-06) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-10-06 13:51 UTC — Filed: 2026-10-06 AccNo: 0001918704-26-030631 Size: 318 KB
  - (2026-10-06) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-10-06 13:51 UTC — Filed: 2026-10-06 AccNo: 0001918704-26-030631 Size: 318 KB
  - (2026-10-06) 424B2 - BANK OF NOVA SCOTIA (0000009631) (Filer)
      filed 2026-10-06 13:51 UTC — Filed: 2026-10-06 AccNo: 0001839882-26-049702 Size: 316 KB
  - (2026-10-06) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-10-06 13:47 UTC — Filed: 2026-10-06 AccNo: 0001918704-26-030630 Size: 1 MB
  - (2026-10-06) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-10-06 13:47 UTC — Filed: 2026-10-06 AccNo: 0001918704-26-030630 Size: 1 MB
  - (2026-10-06) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-10-06 13:47 UTC — Filed: 2026-10-06 AccNo: 0001839882-26-049699 Size: 953 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-10-06) [United States] G7 to release diesel , oil reserves as fuel prices surge
      domain: utahindependent.com · language: English · tone:
  - (2026-10-06) [United States] Head - To - Head Contrast : Avantor ( NYSE : AVTR ) vs . Medpace ( NASDAQ : MEDP )
      domain: dailypolitical.com · language: English · tone:
  - (2026-10-06) [Saudi Arabia] Arab News | Israel puts military on alert for Oct 7 anniversary , warns Gazans
      domain: arabnews.com · language: English · tone:
  - (2026-10-06) [United States] Cardinals drop a pair of tight matches at Lakeview Quad
      domain: wtvbam.com · language: English · tone:
  - (2026-10-06) [United States] Editorial : As election nears , Healey suddenly peddling natural gas – Lowell Sun
      domain: lowellsun.com · language: English · tone:
  - (2026-10-06) [United Kingdom] New warning to anyone born since 1976 over seven cancers - full list
      domain: derbytelegraph.co.uk · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-06) JAF9BV (Bulgaria)
      icao24: 4520ce · position: (49.7697, 2.3758) · alt: 6042m · 720km/h
  - (2026-10-06) PAT910 (United States)
      icao24: adfecb · position: (39.5603, -79.8707) · alt: 6728m · 591km/h
  - (2026-10-06) JAF5GA (Bulgaria)
      icao24: 4520aa · position: (34.7816, -6.0264) · alt: 11285m · 718km/h
  - (2026-10-06) GAF244 (Germany)
      icao24: 3e8b41 · position: (31.6961, 32.8708) · alt: 10050m · 733km/h
  - (2026-10-06) PAT872 (United States)
      icao24: adfe47 · position: (39.9531, -82.8484) · alt: 7315m · 440km/h
  - (2026-10-06) CFC0540 (Canada)
      icao24: c02044 · position: (49.1553, -97.8431) · alt: 3406m · 482km/h

### U.S. Federal Action — 21 new of 26 total
  - (2026-10-06) Eliminating Obsolete Regulations Related to the 911 Grant Program
      In this action, NTIA and NHTSA are removing regulations related to the 911 Grant Program because the program is no longer active and there have been no new appropriations to revive or extend it. This removal is intended…
  - (2026-10-06) Safety Zone; Red Bull Flugtag, Intercoastal Waterway, Biscayne Bay, Miami, FL
      The Coast Guard is proposing to establish a temporary safety zone for certain navigable waters on the Intercoastal Waterway portion of Biscayne Bay in Miami, FL. The safety zone is needed to protect spectators, vessels,…
  - (2026-10-06) Basin Regulations; Water Code
      The Commission proposes to amend its Water Code and Comprehensive Plan to require water supply systems serving the public (purveyors) to report water use by their largest customers.
  - (2026-10-06) Establishment of Class E Airspace; Peoria, IL
      This action establishes Class E airspace at OSF St Francis Medical Center Heliport, Peoria, IL. This action supports new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-10-06) Security Zone; Patapsco River, Baltimore, MD
      The Coast Guard is establishing a temporary security zone for certain navigable waters of the Patapsco River. The security zone is needed to protect persons, including those under the protection of the United States Secr…
  - (2026-10-06) Investment Adviser Performance-Based Compensation Modernization
      The Securities and Exchange Commission (the "Commission") is proposing to amend the rule under the Investment Advisers Act of 1940 that provides an exemption from the statutory prohibition on registered investment advise…

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-10-06) Bitcoin Up or Down on October 5?
      yes price: 100% · 24h volume: $1,578,728 · resolves 2026-10-05
  - (2026-10-06) Counter-Strike: G2 vs PARIVISION (BO3) - ESL Pro League Group Stage
      yes price: 56% · 24h volume: $873,173 · resolves 2026-10-06
  - (2026-10-06) Counter-Strike: Spirit vs 1WIN (BO3) - ESL Pro League Group Stage
      yes price: 0% · 24h volume: $847,636 · resolves 2026-10-06
  - (2026-10-06) Counter-Strike: Spirit vs 1WIN - Map 2 Winner
      yes price: 0% · 24h volume: $566,536 · resolves 2026-10-06
  - (2026-10-06) Counter-Strike: Legacy vs M80 (BO3) - ESL Pro League Group Stage
      yes price: 55% · 24h volume: $485,560 · resolves 2026-10-06
  - (2026-10-06) Counter-Strike: G2 vs PARIVISION - Map 2 Winner
      yes price: 86% · 24h volume: $413,846 · resolves 2026-10-06

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-10-05) M 5.0 - south of the Fiji Islands
      M5.0 · south of the Fiji Islands · depth 518.638 km
  - (2026-10-06) M 4.9 - 48 km NNE of Semporna, Malaysia
      M4.9 · 48 km NNE of Semporna, Malaysia · depth 10 km
  - (2026-10-06) M 4.9 - 55 km ESE of Kokopo, Papua New Guinea
      M4.9 · 55 km ESE of Kokopo, Papua New Guinea · depth 20.643 km
  - (2026-10-06) M 4.9 - State of Yap, Federated States of Micronesia
      M4.9 · State of Yap, Federated States of Micronesia · depth 10 km
  - (2026-10-06) M 4.8 - 86 km N of Ruteng, Indonesia
      M4.8 · 86 km N of Ruteng, Indonesia · depth 8.653 km
  - (2026-10-05) M 4.8 - 146 km WNW of Panguna, Papua New Guinea
      M4.8 · 146 km WNW of Panguna, Papua New Guinea · depth 142.487 km

### Paper Trading Scorecard — 9 new of 110 total
  - (2026-10-06) [Polymarket] Will Microsoft be the largest company in the world by market cap on December 31?
      This market will resolve to the largest company in the world by market cap on December 31, 2026, as of market close. The resolution source for this market will be a consensus of credible reporting.
  - (2026-10-06) [Manifold] Will Anthropic release a new Claude Fable model before October 12, 2026?
  - (2026-10-06) [Manifold] Will Wisconsin Question 3 (ban on government preferential treatment) be approved in the November 3, 2026 election?
  - (2026-10-06) [Manifold] Will Wisconsin Question 2 (no emergency closures of places of worship) be approved in the November 3, 2026 election?
  - (2026-10-06) [Manifold] Will Wisconsin Question 1 (limit on partial veto to raise taxes/fees) be approved in the November 3, 2026 election?
  - (2026-10-06) [Manifold] Will Virginia Question 1 (right to reproductive freedom) be approved in the November 3, 2026 election?

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 120 total
  - (2026-10-05) [OFAC] OFAC ALERT - Office of Foreign Assets Control (.gov)
      OFAC ALERT Office of Foreign Assets Control (.gov)
  - (2026-10-05) [OFAC] Designations Updates; Publication of Iran-related OFAC Alert - Office of Foreign Assets Control (.gov)
      Designations Updates; Publication of Iran-related OFAC Alert Office of Foreign Assets Control (.gov)
  - (2026-10-01) [OFAC] Transnational Criminal Organizations Designation; Publication of Iran-related Determination - Office of Foreign Assets Control (.gov)
      Transnational Criminal Organizations Designation; Publication of Iran-related Determination Office of Foreign Assets Control (.gov)
  - (2026-10-06) [USASpending] $2,099,442,660 → BOLLINGER SHIPYARDS LOCKPORT, L.L.C.: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE U
      Agency: Department of Homeland Security. Description: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE UP TO TWENTY-SIX (26) FAST RESPONSE CUTTERS (FRCS) ON A FIRM FIXED PRICE (FFP) BASIS WITH AN ECONOMIC PRICE…
  - (2026-10-06) [USASpending] $1,842,641,185 → GENERAL DYNAMICS INFORMATION TECHNOLOGY, INC.: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
      Agency: Department of State. Description: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
  - (2026-10-06) [USASpending] $1,770,847,986 → BARNARD CONSTRUCTION COMPANY, INCORPORATED: BORDER WALL CONSTRUCTION FOR EL PASO SECTOR - EPT-5
      Agency: Department of Homeland Security. Description: BORDER WALL CONSTRUCTION FOR EL PASO SECTOR - EPT-5

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-06) [Marginal Revolution] Paul Graham Versus the Pope
      Pope Leo XIV recently tweeted that there is “an ontological difference, even before an aesthetic one, between art and what a machine can generate through statistical calculation based on millions of images created by oth…
  - (2026-10-06) [Marginal Revolution] The Great Accretion and the Great Depression
      A very old idea, returning with a vengeance: The Second Industrial Revolution sparked a wave of new products and industrial processes, fueling an optimistic Roaring Twenties. But did excitement about technological progre…
  - (2026-10-06) [Marginal Revolution] Rising concentration for economics awards
      We analyze the academic affiliations of nearly 6,000 award-winning researchers in 18 major fields in the natural sciences, engineering, and social sciences from the 1820s to the 2020s, focusing on the 1960s onward. The a…
  - (2026-10-05) [Conversable Economist] Equity in K-12 School Spending
      A long-time concern in the US K-12 schooling system is that local property taxes within each school district are a primary source of funding. As a result, school districts in high-income areas with higher property values…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=26, 14d-median=24; carrying terms: rulemaking, information, state, action, final, proposed, procedures, certain, regulatory, program, model, proposes
- state_bills: today=118, 7d-median=105, 14d-median=108; carrying terms: including, general, request, within, eligible, information, contracts, legislature, court, related, requires, service
- state_news: today=486, 7d-median=698, 14d-median=604; carrying terms: congressional, general, america, billion, feature, south, losing, standing, debates, incumbent, watched, hands
- local_news: today=235, 7d-median=225, 14d-median=227; carrying terms: accused, uploads, south, decoding, officials, games, saportareport, missouri, louis, years, million, shooting
- foreign_news: today=1001, 7d-median=1012, 14d-median=1012; carrying terms: files, explaining, cities, noticias, university, released, though, recent, uganda, short, markets, place
- chinese_internal: today=255, 7d-median=255, 14d-median=267; carrying terms: cbmizkfvx, cbmizefvx, google, cbmiw, cbmibefvx, cbmigwfbvv, articles, color, lxtfb, title, https, chinese
- russian_internal: today=1074, 7d-median=1049, 14d-median=1029; carrying terms: https, axios, telegram, novayagazeta, server, media, reuters, financial, found, europe, target, httperror
- ukrainian_internal: today=129, 7d-median=131, 14d-median=131; carrying terms: nearly, kyivindependent, washington, black, ukrainian, negotiations, institute, meeting, europe, kremlin, remains, officials
- ukraine_theater: today=337, 7d-median=564, 14d-median=442; carrying terms: classification, dulnztfonjeytlfwttf, general, cbmikajbvv, ftetjvs, yemen, billion, bjhncfbzn, fdmlmc, south, continue, cbmit
- paper_bets: today=110, 7d-median=123, 14d-median=122; carrying terms: alaska, pennsylvania, kalshi, earthquake, michigan, supreme, nominee, schumer, labor, general, humans, december
- weather: today=97, 7d-median=144, 14d-median=144; carrying terms: trend, reduce, including, america, afdtbw, waves, southeast, francisco, unknown, washington, hurricane, damage
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: jolts, jtsjol, sheet, supply, effective, rates, commodities, implied, labor, payems, balance, cpilfesl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, agriculture, corporate, large, russell, rates, commodities, futures, bitcoin, natural, nasdaq, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=120, 7d-median=121, 14d-median=106; carrying terms: https, armed, general, union, guinea, resolution, designations, tunisia, yemen, group, national, south
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, quiver, https, error, client, httperror, quiverquant, unauthorized, congresstrading
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, accno, reporting, filer, financial, holdings, trust, america, jpmorgan, finance, chase
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, krishnamoorthi, disbursements, ocasio, trone, sherrod, alexandria, house, committee, cooper, johnson, shawn
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=49, 14d-median=50; carrying terms: english, trump, sanctions, chinese, ukraine, russia, russian, perimeter, spanish, themes, vietnamese, serbian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: india, kingdom, domain, language, english, election, philippines, israel, finanznachrichten, ahead, court, germany
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, france, kingdom, germany, canada, bulgaria, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: andes, algeria, toxin, increasing, africa, including, batches, batch, recombinant, general, affected, clusters
- cisa_kev: today=17, 7d-median=17, 14d-median=18; carrying terms: check, injection, buffer, vendor, products, product, multiple, authorization, based, overflow, write, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=13, 7d-median=14, 14d-median=14; carrying terms: depth, indonesia, islands, south, region, japan, papua, guinea, ruteng, kokopo, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: champions, resolves, league, championship, shakhtar, volume, donetsk, price, october, group, strike, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, revolution, conversableeconomist, conversable, class, marginal, economist, basic, economic, taxes, economics, industrial
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: https, review, information, critical, engineers, computer, vulnerability, hacker, exploitation, government, years, techcrunch
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: harrigan, william, kagan, keating, labor, mariannette, wasserman, general, union, craig, brooke, debbie
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, decision, today, paper, consensus, claude, unavailable, converges, identify, module, sufficient, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board requests public comment on two proposals related to establishing a regulatory framework for Board-supervised payment stablecoin issuers under the GENIUS Act
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.
- [2026-09-28] Fed speeches: Cook, An Update on AI and the Economy
- [2026-09-29] Fed speeches: Bowman, Opening Remarks
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-29] Fed press (events + announcements): Agencies publish resolution plan feedback letters for 15 banking organizations
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] ECB press: Christine Lagarde: Where AI risks meet
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] ECB press: Boris Vujčić: Resilience, integration and competitiveness: building the future of European banking
- [2026-10-02] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*