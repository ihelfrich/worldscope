# WORLDSCOPE morning brief — 2026-10-03

## Headline
3064 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (721) · Russian Internal News (state + in-exile) (574) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (272) · State-Level News (254) · Chinese Internal News (186) · Local News: St. Louis + Atlanta (178) · U.S. Weather + Severe / Climate Outlooks (157) · Ukrainian Internal News (national + local Kyiv) (70) · GDELT GKG — themes / entities / watch areas (49) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (38)

## What changed today
### International News + Multilateral Institutions — 721 new of 1012 total
  - (2026-10-03) [Global] Libyan unity talks upended as warlord’s son linked to drone attacks on fuel facilities
  - (2026-10-03) [Global] Brazil’s neck-and-neck election offers test for growing pro-Trump Latin American bloc
  - (2026-10-02) [Global] Brazil’s Lula says only he can stop rise of fascism under Bolsonaro’s son
  - (2026-10-02) [Global] US Coast Guard says it intercepted ship carrying fuel to Cuba
  - (2026-10-03) [Global] North Korea launches ballistic missile after Seoul demands apology over wounded soldiers
  - (2026-10-03) [Global] Bangkok at breaking point as floods turn streets into stagnant lakes

### Russian Internal News (state + in-exile) — 574 new of 1054 total
  - (2026-10-03) Кадыров получил высшее в России воинское звание, золотые погоны и краповый берет | LEDE: Директор Росгвардии Виктор Золотов вручил главе Чечни Рамзану Кадырову погоны генерала армии и крапов] (ru: Кад…
      Директор Росгвардии Виктор Золотов вручил главе Чечни Рамзану Кадырову погоны генерала армии и краповый берет, сообщает ТАСС.
  - (2026-10-03) Германия отказала российской студентке в учебной визе из-за «угрозы безопасности». Правозащитники назвали это опасным прецедентом | LEDE: Посольство Германии в Москве отказалось выдать учебн] (ru: Гер…
      Посольство Германии в Москве отказалось выдать учебную визу выпускнице программы «Дизайн» НИУ ВШЭ, которая поступила на аналогичную специальность в немецкий университет искусств. Об этом рассказал правозащитный проект дл…
  - (2026-10-03) Умер Анатолий Кашпировский | LEDE: Телевизионный целитель Анатолий Кашпировский умер в возрасте 87 лет, сообщил журналист Андрей Малахов. Причиной смерти стала остановка сердца, сказал ТАСС ] (ru: Уме…
      Телевизионный целитель Анатолий Кашпировский умер в возрасте 87 лет, сообщил журналист Андрей Малахов. Причиной смерти стала остановка сердца, сказал ТАСС его директор.
  - (2026-10-03) Путина в поездке в Челябинскую область сопровождал вертолет. А еще в регионе на три дня перекрыли все федеральные трассы | LEDE: Во время поездки Владимира Путина в Челябинскую область 2 окт] (ru: Пут…
      Во время поездки Владимира Путина в Челябинскую область 2 октября президентский кортеж сопровождал вертолет, предположительно, военный. Это следует из видео, на котором снят проезд кортежа. Ролик снял один из местных жит…
  - (2026-10-03) Как остановить даже мегачих, если чихать никак нельзя. Рассказывают хирург, актер, певец и другие читатели «Медузы» | LEDE: Недавно мы спросили у вас, умеете ли вы останавливать чих, если об] (ru: Как…
      Недавно мы спросили у вас, умеете ли вы останавливать чих, если обстановка к нему совсем не располагает, и получили 600 ответов! В них вы рассказали, как справляетесь с тем, чтобы не чихнуть, а также — когда пригождается…
  - (2026-10-03) Пассажирка рейса из Турции родила ребенка в туалете аэропорта Шереметьево. Она убила его и сама умерла от потери крови | LEDE: В туалете зоны прилета аэропорта Шереметьево в Москве обнаружил] (ru: Пас…
      В туалете зоны прилета аэропорта Шереметьево в Москве обнаружили тела женщины и новорожденного ребенка. Возбуждено уголовное дело, сообщила пресс-служба управления СК по Московской области.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 272 new of 564 total
  - (2026-10-03) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-02) [FIRMS] thermal anomaly 45.258, 31.675 (FRP 6.42 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-02 1002Z, FRP 6.42 MW
  - (2026-10-02) [FIRMS] thermal anomaly 45.257, 31.670 (FRP 3.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-02 1002Z, FRP 3.95 MW
  - (2026-10-02) [FIRMS] thermal anomaly 44.059, 27.362 (FRP 2.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-02 1002Z, FRP 2.41 MW
  - (2026-10-02) [FIRMS] thermal anomaly 46.370, 33.933 (FRP 3.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-02 1002Z, FRP 3.18 MW
  - (2026-10-02) [FIRMS] thermal anomaly 46.585, 34.752 (FRP 1.81 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-02 1002Z, FRP 1.81 MW

### State-Level News — 254 new of 698 total
  - (2026-10-02) [Alabama] National Principals Month
      Download
  - (2026-10-02) [Alabama] Domestic Violence Awareness Month
      Download
  - (2026-10-02) [Alabama] American Indian Heritage Month
      Download
  - (2026-10-02) [Alabama] American Indian Heritage Day
      Download
  - (2026-10-02) [Colorado] Republican Victor Marx fined $58K for campaign finance violations
      Victor Marx, the Republican nominee for Colorado governor, was assessed a fine of $57,647 on Friday by the Colorado secretary of state’s office for accepting campaign contributions in excess of the legal limit. The fine…
  - (2026-10-02) [Colorado] Anxiety is growing Trump may try to disrupt the midterm elections. States are prepping.
      When Homeland Security Secretary Markwayne Mullin declared in September that Immigration and Customs Enforcement could serve warrants on individuals at polling places this fall, officials in Denver, a liberal city where…

### Chinese Internal News — 186 new of 236 total
  - (2026-10-02) 在新的长征路上继续奋勇前进 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE5xU2VHbU1JalU5RXRDd3piUV95dGxkRHFpRXhnZUVoUG5fdXFRZmEwSXl0NzkzQnM3Tm9ZNW41RnFoUzZGTzBoek1jLS1EN3FWcn] (zh:…
      在新的长征路上继续奋勇前进 人民网-图片频道
  - (2026-10-03) π-HuB计划发布两大平台建设成果 - 人民网科技 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1XWjFOaTJlYXktbmFBTkt0Qy1QUldJRm1qeC1lRmJyX211Yk1yTm5sbmdhalJyVjYxNnRJX2lnNHV0U19Dd3NhNVdWZ2Y4UDFRU] (zh:…
      π-HuB计划发布两大平台建设成果 人民网科技
  - (2026-10-03) 百兆瓦级二氧化碳储能项目并网发电一次成功 - 人民网科技 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9kNnk2T0JXMWJIcV90aVZNdENLVW13Wi1hakh2bGstX2FQc3I2enJpb2lxYW5QR1M0UzZ3TmZYTnBuYnI0djFBTng2SHI2eV] (zh:…
      百兆瓦级二氧化碳储能项目并网发电一次成功 人民网科技
  - (2026-10-03) 西南首座柔性直流背靠背换流站建设跑出“加速度” - 人民网科技 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFAwWWJfY0RZanc4aGtBLW11LVM1dHdpUENUa0diTHN4R2lOQnNSOTZTaHVFVjNfeFFxTEdaZEd2Z2M2Y0RWNnNFNk55U2l] (zh:…
      西南首座柔性直流背靠背换流站建设跑出“加速度” 人民网科技
  - (2026-10-02) 安徽马鞍山： 过江通道建设如火如荼 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFBiWTJRTVd5T252TjVqVC1vT1hyMnpQOFE4c0lZMGp6NlhPV3pDb1ZuV0xzTUxKNW1adVpVY3B1S2tfR2tXRU10eGtNU1NJVHhkNE] (zh:…
      安徽马鞍山： 过江通道建设如火如荼 人民图片
  - (2026-10-02) 湖北黄石： 科技文旅人气旺 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1uRlhDRXVXSHM5LVdZQ2RTbTFodzJndjZjbTVtbURlZnV0VW1lN0ZjRU15VjV3cFQ3anZRTkZkLUc5aGM4WldhVWpwU0o3SlVOSXcwSj] (zh:…
      湖北黄石： 科技文旅人气旺 人民图片

### Local News: St. Louis + Atlanta — 178 new of 225 total
  - (2026-10-02) [St. Louis] You know Powell Hall, but do you know the kids singing there?
      You don’t have to be a professional musician to perform at Powell Hall. You don’t even have to be old enough to drive. Nearly 400 young singers from first through 12th grade participate in The St. Louis Children’s Choirs…
  - (2026-10-02) [St. Louis] A conversation with ‘The Daughters of Rosebud’ author Sonny Buttar
      The Daughters of Rosebud, the beautiful, emotional debut novel from longtime Clayton-based corporate lawyer Sonny Buttar, is a story about family—its love, its toxicity, how it is lost, and how it can be reclaimed. Out n…
  - (2026-10-03) [St. Louis] McClellan: Eric Schmitt was right not to step in the apology trap
      Columnist Bill McClellan writes: A mistaken basketball-game accusation leads to a larger question: Is there still room in American politics for admitting you were wrong?
  - (2026-10-03) [St. Louis] Oklahoma reckons with environmental costs of marijuana industry
      As illegal grow sites shut down, the land, agricultural equipment and dangerous chemicals are abandoned.
  - (2026-10-03) [St. Louis] St. Louis obituaries for October 3
      Read through the obituaries published in the St. Louis Post-Dispatch
  - (2026-10-03) [St. Louis] 9 St. Louis stars from college football's first month
      Flip around through college football games and there's a good chance you'll see some St. Louis natives making a difference for teams across the country.

### U.S. Weather + Severe / Climate Outlooks — 157 new of 159 total
  - (2026-10-03) [Moderate] Gale Warning: Gale Warning issued October 3 at 4:10AM AKDT until October 3 at 5:00PM AKDT by NWS Anchorage AK
      Offshore waters forecast for the Gulf of Alaska West of 144W Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and…
  - (2026-10-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-03) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 3 at 6:01AM MDT until October 3 at 9:00AM MDT by NWS Albuquerque NM
      * WHAT...Visibility under one mile in dense fog. * WHERE...Far Northeast Highlands, Johnson and Bartlett Mesas Including Raton Pass, and Northeast Highlands. * WHEN...Until 9 AM MDT this morning. * IMPACTS...Low visibili…
  - (2026-10-03) [Moderate] Gale Warning: Gale Warning issued October 3 at 3:58AM AKDT until October 4 at 1:00AM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, southeast winds 25 to 35 kt with gusts up to 40 kt and seas 6 to 11 ft expected. For the Gale Warning, southeast winds 30 to 40 kt with gusts up to 45 kt and seas 12 to 17 ft…
  - (2026-10-03) [Moderate] Gale Warning: Gale Warning issued October 3 at 3:58AM AKDT until October 4 at 4:00AM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, southeast winds 25 to 35 kt with gusts up to 40 kt and seas 10 to 15 ft expected. For the Gale Warning, southeast winds 30 to 40 kt with gusts up to 45 kt and seas 14 to 19 ft…
  - (2026-10-03) [Moderate] Gale Warning: Gale Warning issued October 3 at 3:58AM AKDT until October 4 at 4:00AM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, east winds 25 to 35 kt with gusts up to 45 kt and seas 7 to 12 ft expected. For the Gale Warning, east winds 30 to 40 kt with gusts up to 50 kt and seas 13 to 18 ft expected.…

### Ukrainian Internal News (national + local Kyiv) — 70 new of 138 total
  - (2026-10-03) Мінфін не погодився з ЄС, який каже, що Україні не треба додаткових коштів у 2026 році | LEDE: Міноборони України заявило про дефіцит $27 млрд на оборону в 2026 році. Частину покриють внутрішні] (uk:…
      Міноборони України заявило про дефіцит $27 млрд на оборону в 2026 році. Частину покриють внутрішніми ресурсами, решта потребує зовнішнього фінансування.
  - (2026-10-03) Санду засудила атаку РФ по Україні | LEDE: ] (uk: Санду засудила атаку РФ по Україні)
  - (2026-10-03) Двоє людей постраждали через ранковий удар росіян по Північному мосту | LEDE: Внаслідок ранкового обстрілу пошкоджено дорожнє покриття та тролейбусну мережу. Один постраждалий госпіталізований.] (uk:…
      Внаслідок ранкового обстрілу пошкоджено дорожнє покриття та тролейбусну мережу. Один постраждалий госпіталізований.
  - (2026-10-03) П’ять дронів залетіли в повітряний простір Молдови: є уламки та пошкодження | LEDE: ] (uk: П’ять дронів залетіли в повітряний простір Молдови: є уламки та пошкодження)
  - (2026-10-03) Росіяни атакували цивільне судно в порту Одещини, загинув моряк – АМПУ | LEDE: Атака на цивільне вантажне судно в порту Одещини: один загиблий, троє поранених, евакуйовано 13 членів екіпажу.] (uk: Рос…
      Атака на цивільне вантажне судно в порту Одещини: один загиблий, троє поранених, евакуйовано 13 членів екіпажу.
  - (2026-10-03) Трамп відмовився від заборони експорту дизеля після рішення G7 | LEDE: Американський президент Дональд Трамп заявив, що Вашингтон не запроваджуватиме заборону на експорт дизеля, адже Європа, як] (uk:…
      Американський президент Дональд Трамп заявив, що Вашингтон не запроваджуватиме заборону на експорт дизеля, адже Європа, як і США, зробить "великий внесок" у світові поставки пального.

### GDELT GKG — themes / entities / watch areas — 49 new of 49 total
  - (2026-10-02) [Russia oil sanctions perimeter · themes] США запровадили санкції проти фінансової мережі , пов язаної з Росією
      eurointegration.com.ua · Ukrainian · tone NA
  - (2026-10-02) [Russia oil sanctions perimeter · themes] Dont worry about diesel shortages , Government says , as US urges use of reserves
      dunfermlinepress.com · English · tone NA
  - (2026-10-02) [Russia oil sanctions perimeter · themes] 日本擬追加對俄制裁 、 鎖定影子艦隊 普亭 ： 關係惡化責任在日本 | 國際焦點 | 全球
      udn.com · Chinese · tone NA
  - (2026-10-02) [Russia oil sanctions perimeter · themes] 科创亮眼 ！ 2026年前三季度A股大数据全景扫描
      stock.jrj.com.cn · Chinese · tone NA
  - (2026-10-02) [Russia oil sanctions perimeter · themes] Goldman Sachs just added theses 4 companies to its key stock picks
      cnbc.com · English · tone NA
  - (2026-10-02) [Russia oil sanctions perimeter · themes] After Maduro , scrutiny turns to his ally Mireya Blavia de Cisneros over corruption
      samaa.tv · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-03) [Sinclair, Inc.] Form 4 (Issuer)
      filed 2026-10-03 01:48 UTC · role: Issuer — Filed: 2026-10-02 AccNo: 0001254012-26-000004 Size: 14 KB
  - (2026-10-03) [SMITH FREDERICK G] Form 4 (Reporting)
      filed 2026-10-03 01:48 UTC · role: Reporting — Filed: 2026-10-02 AccNo: 0001254012-26-000004 Size: 14 KB
  - (2026-10-03) [HANDLER RICHARD B] Form 4 (Reporting)
      filed 2026-10-03 01:48 UTC · role: Reporting — Filed: 2026-10-02 AccNo: 0001214659-26-012521 Size: 15 KB
  - (2026-10-03) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-10-03 01:48 UTC · role: Issuer — Filed: 2026-10-02 AccNo: 0001214659-26-012521 Size: 15 KB
  - (2026-10-03) [ADAMEK PETER] Form 4 (Reporting)
      filed 2026-10-03 01:42 UTC · role: Reporting — Filed: 2026-10-02 AccNo: 0001214659-26-012520 Size: 5 KB
  - (2026-10-03) [NOVAGOLD RESOURCES INC] Form 4 (Issuer)
      filed 2026-10-03 01:42 UTC · role: Issuer — Filed: 2026-10-02 AccNo: 0001214659-26-012520 Size: 5 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 38 new of 56 total
  - (2026-10-03) [The Hacker News] The State of Cybersecurity in 2026: Key Segments, Insights, and Innovations
      Featuring: Cybersecurity is being reshaped by the expansion of cloud infrastructure, AI, distributed systems, and increasingly complex digital environments. As organizations manage more identities, devices, data, and int…
  - (2026-10-03) [The Register] Clever database, but can it run Doom?
      Reg hack learns the meaning of 'Be careful what you wish for'
  - (2026-10-03) [The Register] Palantir's fondness for French food cooked up tech's latest fad – forward-deployed engineers
      Embedded consultants who get you up to speed on new tech in a hurry aren’t new, but they meet the AI moment
  - (2026-10-03) [TechCrunch] Meta wants your next gadget to be Muse-infused
      Meta wants Muse in your TV and your toaster, so it's giving the code away for free.
  - (2026-10-03) [TechCrunch] Sanders introduces bill to ban the federal government from using Flock
      The proposed legislation would extend to all automotica license plate readers.
  - (2026-10-02) [BleepingComputer] Frontline Education breach exposes school district employee data
      Frontline Education is notifying school districts of a data breach after attackers exploited a vulnerability in third-party software to gain unauthorized access to its systems and steal employee information, including So…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 26 new of 26 total
  - (2026-10-05) Presidential Determination on the Revocation of Presidential Determinations Related to Lebanon
  - (2026-10-05) Airworthiness Directives; Airbus Helicopters
      The FAA proposes to supersede Airworthiness Directive (AD) 2026-12-09, which applies to all Airbus Helicopters Model AS350B, AS350BA, AS350B1, and AS350D helicopters. AD 2026-12-09 requires revising the airworthiness lim…
  - (2026-10-05) Airworthiness Directives; DG Aviation GmbH (Type Certificate Previously Held by DG Flugzeugbau GmbH) Gliders
      The FAA proposes to supersede Airworthiness Directive (AD) 2025-13-08, which applies to all DG Aviation GmbH Model DG-1000T gliders. AD 2025-13-08 requires revising the glider flight manual and installing "Motor INOP" pl…
  - (2026-10-05) Overpressure Blast Effects Analysis Burden Reducing Clarification
      FAA proposes to amend its commercial space launch and reentry licensing regulations to streamline the licensing process and reduce regulatory burden for license applicants. Specifically, FAA proposes to amend the regulat…
  - (2026-10-05) Lightning Hazard Mitigation Burden-Reducing Exception
      FAA proposes to amend its commercial space launch and reentry licensing regulations to streamline the licensing process and reduce regulatory burden for license applicants. Specifically, FAA proposes to add an exception…
  - (2026-10-05) Streamlining Flight Safety Analysis Methodology Means of Compliance
      FAA proposes to amend its commercial space launch and reentry licensing regulations to streamline the licensing process. Specifically, FAA proposes to alleviate regulatory burden for license applicants by consolidating i…

### State Legislative Action — 26 new of 82 total
  - (2026-10-03) [California SB 1340] Small business liaison: contract information: small business procurement participation.
      Existing law establishes the Office of Small Business Advocate within the Governor's Office of Business and Economic Development, led by the Small Business Advocate, and sets forth its powers and duties relating to advoc…
  - (2026-10-03) [California SB 877] Residential property insurance: loss estimate transparency.
      Existing law generally regulates classes of insurance, including residential property insurance. Existing law prohibits a policy of residential property insurance from being issued or renewed by an insurer unless the nam…
  - (2026-10-03) [California SB 1059] Employment Training Panel.
      Existing law establishes the Employment Training Panel within the Employment Development Department and sets forth its powers and duties with respect to certain employment training programs. Existing law declares the int…
  - (2026-10-03) [California SB 1130] Invasion of privacy: wearable recording devices.
      Existing law prohibits the intentional use of an electronic amplifying or recording device to eavesdrop upon or record a confidential communication, as specified, without the consent of all parties to the communication.…
  - (2026-10-03) [California SB 1272] Local ordinances: administrative fines or penalties.
      Existing law authorizes the legislative body of a local agency, as defined, to, by ordinance, make any violation of an ordinance subject to an administrative fine or penalty. Existing law requires a local agency to set f…
  - (2026-10-03) [California SB 1238] Common interest developments: management.
      (1) Existing law, the Davis-Stirling Common Interest Development Act (act) , provides for the creation and regulation of common interest developments. Existing law defines "management services" for purposes of a common i…

### Government & military aircraft airborne (OpenSky) — 22 new of 22 total
  - (2026-10-03) GAF628 (Germany)
      icao24: 3f6533 · position: (50.9993, 7.8142) · alt: 5227m · 771km/h
  - (2026-10-03) JAF95J (Bulgaria)
      icao24: 4520aa · position: (37.7231, -7.7374) · alt: 11277m · 782km/h
  - (2026-10-03) CFC2917 (Canada)
      icao24: c2b5cb · position: (52.2862, 19.369) · alt: 7620m · 593km/h
  - (2026-10-03) CFC2902 (Canada)
      icao24: c2b5b7 · position: (51.2825, -1.0145) · alt: 8237m · 561km/h
  - (2026-10-03) CFC2580 (Canada)
      icao24: c2b57b · position: (45.1767, -75.1579) · alt: 8229m · 707km/h
  - (2026-10-03) EAGLE7 (Kingdom of the Netherlands)
      icao24: 486462 · position: (38.952, 16.8714) · alt: 1409m · 319km/h

### Paper Trading Scorecard — 21 new of 123 total
  - (2026-10-03) [Manifold] Sydney Roosters win 2026 NRL Grand Final?
  - (2026-10-03) [Manifold] By Oct 31, 2026, will openai.com say its agents accessed a U.S. federal government system without authorization?
  - (2026-10-03) [Manifold] Will Democrats win Indiana State Senate District 1 in 2026?
  - (2026-10-03) [Manifold] Will Abdul El Sayed win by 100,000 votes or more?
  - (2026-10-03) [Manifold] GPT Astra 6.1+ Released By EOY 2026?
  - (2026-10-03) [Manifold] Does Trimble Football Win?

### Court opinions of consequence (federal & state) — 17 new of 60 total
  - (2026-10-02) U.S. Court of Appeals, 2nd Cir.: United States v. Acevedo
  - (2026-10-02) U.S. Court of Appeals, D.C. Cir.: Basin Electric Power Cooperative v. FERC
  - (2026-10-02) U.S. Court of Appeals, 9th Cir.: Macdonald v. Oregon Health and Science University
  - (2026-10-02) U.S. Court of Appeals, 9th Cir.: William Castillo v. Jeremy Bean
  - (2026-10-02) U.S. Court of Appeals, 5th Cir.: Frankfort v. Metropolis Technologies
  - (2026-10-02) U.S. Court of Appeals, 5th Cir.: Phillips v. Johnson and Johnson

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-10-02) M 5.8 - 165 km SSE of Vilyuchinsk, Russia
      M5.8 · 165 km SSE of Vilyuchinsk, Russia · depth 29.477 km
  - (2026-10-02) M 5.1 - 199 km SSE of Vilyuchinsk, Russia
      M5.1 · 199 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-10-03) M 5.0 - 163 km SE of Petropavlovsk-Kamchatsky, Russia
      M5.0 · 163 km SE of Petropavlovsk-Kamchatsky, Russia · depth 10 km
  - (2026-10-02) M 5.0 - 171 km SE of Vilyuchinsk, Russia
      M5.0 · 171 km SE of Vilyuchinsk, Russia · depth 30.93 km
  - (2026-10-02) M 5.0 - 179 km SSE of Vilyuchinsk, Russia
      M5.0 · 179 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-10-02) M 5.0 - 26 km SSW of Güiria, Venezuela
      M5.0 · 26 km SSW of Güiria, Venezuela · depth 9.763 km

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-10-03) Counter-Strike: Legacy vs PARIVISION (BO3) - ESL Pro League Group Stage
      yes price: 0% · 24h volume: $2,016,328 · resolves 2026-10-03
  - (2026-10-03) Will Indiana enact a data center moratorium by December 31, 2027?
      yes price: 12% · 24h volume: $1,923,417 · resolves 2028-01-01
  - (2026-10-03) LoL: Team Vitality vs BNK FEARX (BO1) - Demacia Cup Global Invitational Group Stage
      yes price: 0% · 24h volume: $905,261 · resolves 2026-10-03
  - (2026-10-03) Will Anthropic announce bankruptcy by December 31, 2027?
      yes price: 10% · 24h volume: $857,536 · resolves 2028-01-01
  - (2026-10-03) China Open: Xinran Sun vs Cristina Bucsa
      yes price: 100% · 24h volume: $713,898 · resolves 2026-10-10
  - (2026-10-03) LoL: Shopify Rebellion vs KT Rolster (BO1) - Demacia Cup Global Invitational Group Stage
      yes price: 0% · 24h volume: $628,503 · resolves 2026-10-03

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 123 total
  - (2026-10-02) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-10-03) [USASpending] $42,668,569,051 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-10-03) [USASpending] $31,083,345,990 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-10-03) [USASpending] $26,718,408,869 → BATTELLE ENERGY ALLIANCE, LLC: MANAGEMENT AND OPERATIONS OF THE INL
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATIONS OF THE INL
  - (2026-10-03) [USASpending] $17,883,024,035 → BECHTEL NATIONAL, INC.:
      Agency: Department of Energy. Description:
  - (2026-10-03) [USASpending] $11,309,020,852 → ALLIANCE FOR ENERGY INNOVATION, LLC: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWAB
      Agency: Department of Energy. Description: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWABLE ENERGY LABORATORY

### World News (by country, top stories) — 6 new of 6 total
  - (2026-10-02) [China] Nidec impairment loss far exceeds estimates as auditor withholds opinion
      digitimes.com · English
  - (2026-10-02) [China] China longest undersea highway tunnel completes shield tunneling
      globaltimes.cn · English
  - (2026-10-02) [China] Climax Technology stays cautious on 2H26 as memory costs rise
      digitimes.com · English
  - (2026-10-02) [China] China - Indonesia book ties grow as Mandarin books find more readers
      globaltimes.cn · English
  - (2026-10-02) [China] US reportedly to deploy NMESIS to Japan westernmost island for first time ; expert warns greater security risk should Tokyo intervene in Taiwan question
      globaltimes.cn · English
  - (2026-10-02) [China] Why wait a week for volume solids ? Measuring under the coating for a faster digital lab
      european-coatings.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-03) [Marginal Revolution] Words to live by?
      In the past year American markets have digested the largest-ever initial public offering (SpaceX), equity raise by a public company (Google) or a foreign firm (SK Hynix), private-funding round (OpenAI) and private-debt d…
  - (2026-10-03) [Marginal Revolution] New issue of Econ Journal Watch
      Volume 23, Issue 2, September 2026 In this issue: “China shock” fragility: According to David Autor, David Dorn, and Gordon Hanson (2013), the “China shock” hit the United States from 1990 to 2007. When corrections by Ki…
  - (2026-10-02) [Marginal Revolution] Supply is elastic, installment #1637
      For taxes too: Using administrative data from Scandinavian countries, we provide evidence on international migration responses to wealth taxes and evaluate their aggregate economic implications. We find significant migra…
  - (2026-10-02) [Conversable Economist] Financial Literacy: How Many Can Pass the Test?
      Financial literacy is meant to be basic stuff. For an example of how basic, here are eight questions from what is called the GFLEC Personal Finance Index. More on the index and the results in a moment, but take a moment…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 17 total
  - (2026-10-02) CVE-2026-102490 · Zammad GmbH Zammad: Zammad GmbH Zammad Improper Privilege Management Vulnerability
      vendor: Zammad GmbH · product: Zammad · CISA remediation by 2026-10-05
  - (2026-10-02) CVE-2026-102489 · Zammad GmbH Zammad: Zammad GmbH Zammad Session Fixation Vulnerability
      vendor: Zammad GmbH · product: Zammad · CISA remediation by 2026-10-05

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=21, 14d-median=19; carrying terms: state, program, procedures, proposed, certain, action, regulatory, final, changes, provide, provisions, management
- state_bills: today=82, 7d-median=82, 14d-median=106; carrying terms: establish, services, actions, general, provides, members, license, agencies, water, policy, subject, child
- state_news: today=698, 7d-median=698, 14d-median=683; carrying terms: remove, attention, nationwide, issues, politics, figure, error, party, members, legislators, traffic, amendment
- local_news: today=225, 7d-median=225, 14d-median=227; carrying terms: target, magazine, shooting, games, across, google, student, blank, according, arrested, atlanta, investigation
- foreign_news: today=1012, 7d-median=1018, 14d-median=1018; carrying terms: target, continues, poland, entity, issues, nations, explaining, homes, error, council, hours, party
- chinese_internal: today=236, 7d-median=267, 14d-median=270; carrying terms: target, cbmiakfvx, politics, cbmiw, cbmix, cbmib, google, cbmia, cbmibefvx, blank, chinese, https
- russian_internal: today=1054, 7d-median=1022, 14d-median=1029; carrying terms: russian, novayagazeta, novaya, media, title, journal, target, financial, laquo, error, reuters, street
- ukrainian_internal: today=138, 7d-median=131, 14d-median=131; carrying terms: speaking, poland, warehouse, error, minister, offensive, cabinet, president, winter, kremlin, occupied, toward
- ukraine_theater: today=564, 7d-median=564, 14d-median=442; carrying terms: cbmif, suvzbc, target, qxjlqlrft, rdzqejhrtdjfotdztdzfuwvwmtfcrdi, cbmingfbvv, bjhncfbzn, zxrvcxnmmxrzbut, dnhlrqwffsq, syria, liveuamap, fpejviewphy
- paper_bets: today=123, 7d-median=122, 14d-median=124; carrying terms: israel, headline, participation, levels, speed, nebraska, break, fusion, world, goldman, colorado, general
- weather: today=159, 7d-median=144, 14d-median=144; carrying terms: angeles, elevated, forecast, continues, impacts, beaches, warning, continue, central, afdsew, hours, waves
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, unemployment, headline, total, spread, dexchus, effective, inflation, cpiaucsl, growth, money, pcepilfe
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, agriculture, close, credit, rates, silver, equities, large, crypto, nasdaq, proxy, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=123, 7d-median=114, 14d-median=105; carrying terms: aggression, imposed, target, libya, services, actions, general, entity, destabilising, zimbabwe, entities, checksum
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, client, unauthorized, httperror, error, congresstrading, quiver, https, quantitative
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: corporation, appeals, court, supreme, state, connecticut, company, international, security, homeland, union, people
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, holdings, financial, group, therapeutics, michael, richard, scott, natera
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, filing, brown, ocasio, trone, cycle, receipts, james, jonathan, krishnamoorthi, angels, committee
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, china
- gdelt_gkg: today=49, 7d-median=49, 14d-median=50; carrying terms: english, sanctions, trump, russian, spanish, russia, perimeter, ukraine, chinese, themes, german, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=30, 14d-median=30; carrying terms: position, belgium, ground, germany, kingdom, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: person, circulation, seasonal, analyzed, jerusalem, alert, poultry, discontinued, result, operator, nationwide, italy
- cisa_kev: today=17, 7d-median=18, 14d-median=18; carrying terms: based, improper, bounds, injection, multiple, products, vendor, check, buffer, incorrect, overflow, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=16, 7d-median=16, 14d-median=16; carrying terms: depth, japan, russia, philippines, papua, guinea, zealand, kokopo
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, volume, championship, donetsk, shakhtar, league, champions, october, counter, strike, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, revolution, conversable, marginal, economist, conversableeconomist, https, basic, wealth, taxes, markets, economic
- tech_news: today=56, 7d-median=57, 14d-median=57; carrying terms: bleepingcomputer, hacker, provides, multiple, using, surveillance, newsletter, today, review, spectrum, openai, weekly
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jason, hollen, welch, friedman, kirsten, marco, coons, tommy, ratcliffe, foushee, stephanie, crane
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, either, claude, evidence, consensus, module, identify, converges, market, today, decision, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board requests public comment on two proposals related to establishing a regulatory framework for Board-supervised payment stablecoin issuers under the GENIUS Act
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.
- [2026-09-28] Fed speeches: Cook, An Update on AI and the Economy
- [2026-09-29] ECB press: ECB amends monetary policy implementation guidelines as part of regular review
- [2026-09-29] Fed speeches: Bowman, Opening Remarks
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-29] Fed press (events + announcements): Agencies publish resolution plan feedback letters for 15 banking organizations
- [2026-09-30] ECB press: Frank Elderson: Supervisory risk appetite, efficiency and effectiveness
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] ECB press: Isabel Schnabel: Monetary policy in a world of overlapping shocks
- [2026-09-30] ECB press: Christine Lagarde: Interview with La Croix
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] ECB press: Christine Lagarde: Where AI risks meet
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*