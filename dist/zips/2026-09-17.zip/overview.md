# WORLDSCOPE morning brief — 2026-09-17

## Headline
3430 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (849) · Russian Internal News (state + in-exile) (723) · State-Level News (397) · World leaders & government officials (324) · Chinese Internal News (240) · Ukraine Theater (total-war monitoring) (226) · Local News: St. Louis + Atlanta (214) · U.S. Weather + Severe / Climate Outlooks (119) · Ukrainian Internal News (national + local Kyiv) (65) · IT, InfoSys & cybersecurity news (last 7 days) (47) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 849 new of 1081 total
  - (2026-09-17) [Global] LIVE: India vs Afghanistan – T20 international cricket series
      Follow the live build-up and coverage, with toss, team lineups and news, ahead of our text commentary steam updates.
  - (2026-09-17) [Global] What’s the Asian Games accommodation crisis, and where will athletes stay?
      In a cost-cutting move, Japan decided against setting up a dedicated athletes' village but now faces a backlash.
  - (2026-09-17) [Global] Climate change had major role in triggering Nepal floods, scientists say
      The combined toll from the deadly incident now stands at 1,446 people dead and at least 6,669 missing.
  - (2026-09-17) [Global] India to impose controversial fee for UPI instant payments: Who benefits?
      It's the end of an era for India's popular instant digital payments system, which has been free of charge until now.
  - (2026-09-17) [Global] Gaza repairman helps journalists to keep documenting genocide
      As journalists in Gaza continue documenting the war, camera repairman Mohammed Radwan keeps damaged equipment in use.
  - (2026-09-17) [Global] Why is inflation rising again around the world?
      Rising energy prices are pushing inflation higher again, forcing major central banks to raise interest rates.

### Russian Internal News (state + in-exile) — 723 new of 1177 total
  - (2026-09-17) Еврокомиссия предложила принять закон о защите детей в интернете (EU Kids Act). Он запретит доступ к соцсетям детям до 13 лет | LEDE: Европейская комиссия предложила принять на территории вс] (ru: Евр…
      Европейская комиссия предложила принять на территории всего Евросоюза закон о защите детей в интернете (EU Kids Act), который среди прочего запретит доступ к соцсетям для детей до 13 лет.
  - (2026-09-17) Премьер Канады поддержал идею об «ассоциированном членстве» с ЕС: не ради «доминирования», а для защиты своих территорий | LEDE: Премьер-министр Канады Марк Карни выступил перед Европарламен] (ru: Пре…
      Премьер-министр Канады Марк Карни выступил перед Европарламентом в Страсбурге. Он поддержал предложение главы Еврокомиссии Урсулы фон дер Ляйен сделать Канаду первым «ассоциированным членом» Евросоюза и подчеркнул, что н…
  - (2026-09-17) Умер двукратный олимпийский чемпион по биатлону Сергей Чепиков | LEDE: Российский биатлонист Сергей Чепиков умер в возрасте 59 лет, сообщил представитель Союза биатлонистов России Сергей Аве] (ru: Уме…
      Российский биатлонист Сергей Чепиков умер в возрасте 59 лет, сообщил представитель Союза биатлонистов России Сергей Аверьянов.
  - (2026-09-17) В США участника ИГИЛ, связанного с терактом в «Крокусе», приговорили к 20 годам | LEDE: Суд в США приговорил к 20 годам лишения свободы гражданина Афганистана Мохаммада Шарифуллу — участника] (ru: В С…
      Суд в США приговорил к 20 годам лишения свободы гражданина Афганистана Мохаммада Шарифуллу — участника террористической группировка «Вилаят Хорасан» (крыло «﻿Исламского государства» в Афганистане), сообщил Минюст США.
  - (2026-09-17) «Адские санкции» США усложнят мирные переговоры, заявили в Кремле | LEDE: Новые санкции США против российского нефтегазового экспорта осложнят переговоры о завершении войны России с Украиной] (ru: «Ад…
      Новые санкции США против российского нефтегазового экспорта осложнят переговоры о завершении войны России с Украиной, заявил пресс-секретарь президента РФ Дмитрий Песков.
  - (2026-09-17) Чеченский активист Мансур Мовлаев второй раз за неделю пытался совершить самоубийство в Казахстане из-за угрозы экстрадиции в Россию | LEDE: Чеченский активист Мансур Мовлаев вновь попытался] (ru: Чеч…
      Чеченский активист Мансур Мовлаев вновь попытался совершить самоубийство, сообщает Антивоенный комитет России.

### State-Level News — 397 new of 836 total
  - (2026-09-17) [California] Governor Newsom announces appointments 9.16.2026
  - (2026-09-16) [California] Governor Newsom cuts red tape to accelerate new zero-emissions ferry project in San Francisco Bay
      Source
  - (2026-09-16) [California] Governor Newsom signs new law to protect workers, require disclosures on AI-generated advertising
      Source
  - (2026-09-16) [California] Governor Newsom visits Jay Leno’s Garage to sign legislation celebrating and preserving California’s classic car and lowrider heritage
      Source
  - (2026-09-17) [California] California’s tough on crime law promised treatment. Here’s why people are falling through the cracks
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/061826-Prop-36-Gustavo-MO-CM-07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-09-17) [California] Newsom and legislators withhold school funds while state blows money on pork and luxury travel
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/02/111925_School-PowerShutoff_KG_CM_03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 240 new of 298 total
  - (2026-09-17) 华为：昇腾960芯片研发超预期 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9CV1pZQ1lHdFcyVGpSLXMxb0dZYmN1Q0pyTFh1SHE0RTY1c0h1elNEUzBucGxlQVYyRHVJSnp5c3g4NE12eDl2Z0Q3QkViR3gwV0Q2] (zh:…
      华为：昇腾960芯片研发超预期 观察者网
  - (2026-09-15) 崔天凯：一劳永逸解决台湾问题 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE83aTVBRW9SenNsYnFsYWVkMW1wVXBaWkowVlFTX3dFY3RlWExpZFhNbVlsRS1aVlNtYzNMaWJabDhnaFZBSEt4TzNQZEMxOHZvTllkS] (zh:…
      崔天凯：一劳永逸解决台湾问题 观察者网
  - (2026-09-17) 也说AI毁灭人类的风险与其关乎人用武之地、所有制和对人口质、量的影响 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBTWFFYaTJxODFabEkyMm5OMHZwWDRIejJoU19NdUJEN3FkZ1BRd2NacTI4RS1wc2hxX1VHNzEtZ3l3cW1DMnF] (zh:…
      也说AI毁灭人类的风险与其关乎人用武之地、所有制和对人口质、量的影响 风闻
  - (2026-09-16) AI视频丨北京新生鸿雁种群“改道”之谜被揭示 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5LSTF0TlN3amVXbDg3TERXQVRocm1NR1hzczZJT0x6Z2lWLUViMnZtUFpEX09OaXdRYkdRYy1MSnF4aTBZdzMtZDRBVlhSUGp] (zh:…
      AI视频丨北京新生鸿雁种群“改道”之谜被揭示 风闻
  - (2026-09-17) 美国归还58件文物，包括百余年前遭劫掠的菩萨像 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE91VFFLbExkdlM0VTJzMm9zMFFrSXhzRS05cm4ybG50TTZHOVlpY1lldFZTbjIyV21ZMDVzZ0VuNUltbXJKS3JHNFZtQmFG] (zh:…
      美国归还58件文物，包括百余年前遭劫掠的菩萨像 观察者网
  - (2026-09-17) 【晚闻风】英语降权、低保追星、单身税，今天的热帖评论亮了 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE9iemVzd295LUJCdGlpOGhKeG5yeURzUEl1emFNQXJzUG1BSkZjb2lDZ25hcDY5em5YM3hGQVdwTHY1cWNUNjRLYWlLV] (zh:…
      【晚闻风】英语降权、低保追星、单身税，今天的热帖评论亮了 风闻

### Ukraine Theater (total-war monitoring) — 226 new of 450 total
  - (2026-09-17) [DeepStateMap] frontline snapshot, 527 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-16) [FIRMS] thermal anomaly 45.256, 31.673 (FRP 6.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-16 1002Z, FRP 6.56 MW
  - (2026-09-16) [FIRMS] thermal anomaly 45.259, 31.675 (FRP 5.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-16 1002Z, FRP 5.25 MW
  - (2026-09-16) [FIRMS] thermal anomaly 45.258, 31.671 (FRP 3.96 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-16 1002Z, FRP 3.96 MW
  - (2026-09-16) [FIRMS] thermal anomaly 46.397, 34.633 (FRP 3.57 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-16 1002Z, FRP 3.57 MW
  - (2026-09-16) [FIRMS] thermal anomaly 46.397, 34.632 (FRP 7.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-16 1002Z, FRP 7.18 MW

### Local News: St. Louis + Atlanta — 214 new of 231 total
  - (2026-09-17) [St. Louis] Missouri History Museum takes a new name: St. Louis History Museum
      A major institution in town is making a big change: The Missouri History Museum is becoming the St. Louis History Museum. A unanimous vote of the board of the Zoological Park and Museum District yesterday made it officia…
  - (2026-09-17) [St. Louis] Democrats’ dreams in Missouri rest on candidates like Mary Ann Perkins
      Democrats in D.C. dream of flipping the House—and maybe even the Senate. But despite poll numbers showing Republicans’ popularity has taken a substantial hit in Missouri, local Democrats have a more modest goal: They wan…
  - (2026-09-17) [St. Louis] Where in the Lou? – 9/17/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-09-16) [St. Louis] Landmark St. Louis restaurant O’Connell’s Pub is closing
      It’s the end of an era for an iconic St. Louis restaurant. O’Connell’s Pub (4652 Shaw), the landmark Irish watering hole and restaurant that originally opened in Gaslight Square in 1961, is closing. Owner John Parker, so…
  - (2026-09-16) [St. Louis] St. Louis Police Board gives the OK to hire 3 new communications staffers
      Mitch McCoy’s comms shop is staffing up. At a meeting yesterday, the Board of Police Commissioners approved increasing the St. Louis Metropolitan Police Department’s public affairs operation from four people to seven. Mc…
  - (2026-09-16) [St. Louis] PiFi Pizza will bring Neapolitan-inspired pies and a listening lounge to The Hill
      The St. Louis pizza scene—and a beloved gathering place on The Hill—are getting a jolt of fresh energy, thanks to two brothers on a mission to serve up pies, music, and community. PiFi Pizza (4916 Shaw), a new concept fr…

### U.S. Weather + Severe / Climate Outlooks — 119 new of 121 total
  - (2026-09-17) [Moderate] Gale Warning: Gale Warning issued September 17 at 4:14AM AKDT until September 18 at 5:00AM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-17) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-17) [Severe] Flash Flood Warning: Flash Flood Warning issued September 17 at 7:07AM CDT until September 17 at 11:00AM CDT by NWS Chicago IL
      FFWLOT The National Weather Service in Chicago has issued a * Flash Flood Warning for... Southern De Kalb County in north central Illinois... Northern La Salle County in north central Illinois... Southeastern Lee County…
  - (2026-09-17) [Severe] Flood Watch: Flood Watch issued September 17 at 5:56AM MDT until September 18 at 3:00AM MDT by NWS Albuquerque NM
      The Flood Watch will expire for a portion of north central New Mexico, including the following areas, Espanola Valley and Southern Sangre de Cristo Mountains. Another Flash Flood Watch is in effect for Thursday.
  - (2026-09-17) [Severe] Flood Watch: Flood Watch issued September 17 at 5:56AM MDT until September 18 at 3:00AM MDT by NWS Albuquerque NM
      The Flood Watch will expire for a portion of west central New Mexico, including the following area, West Central Highlands. Another Flash Flood Watch is in effect for the area Thursday.
  - (2026-09-17) [Severe] Flood Watch: Flood Watch issued September 17 at 5:56AM MDT until September 18 at 3:00AM MDT by NWS Albuquerque NM
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of central New Mexico, including the Albuquerque Metro Area. * WHEN...From 11 AM MDT this morning through late tonight. *…

### Ukrainian Internal News (national + local Kyiv) — 65 new of 139 total
  - (2026-09-17) У Швеції порахували всі голоси: лівоцентристи перемогли з перевагою у три мандати | LEDE: ] (uk: У Швеції порахували всі голоси: лівоцентристи перемогли з перевагою у три мандат)
  - (2026-09-17) Лікарська комісія "намалювала" 1000 висновків для відстрочки – весь склад медиків отримав підозру | LEDE: На Тернопільщині викрито лікарсько-консультативну комісію, яка продавала фальшиві висно] (uk:…
      На Тернопільщині викрито лікарсько-консультативну комісію, яка продавала фальшиві висновки для відстрочки від мобілізації за 6-12 тисяч доларів – прокуратура.
  - (2026-09-17) Справа про вбивство Фаріон: суд пішов до нарадчої кімнати перед винесенням вироку | LEDE: Шевченківський суд Львова пішов у нарадчу кімнату у справі щодо загибелі Ірини Фаріон. В’ячеслава Зінче] (uk:…
      Шевченківський суд Львова пішов у нарадчу кімнату у справі щодо загибелі Ірини Фаріон. В’ячеслава Зінченка підозрюють в умисному вбивстві.
  - (2026-09-17) Поляків налякав звук вибуху в центрі країни, військовим довелось пояснювати | LEDE: Оперативне командування збройних сил Польщі було змушене виступити з поясненнями після звуків вибуху, які чул] (uk:…
      Оперативне командування збройних сил Польщі було змушене виступити з поясненнями після звуків вибуху, які чули в центральній частині країни.
  - (2026-09-17) Чужі серед своїх. Чому звільнені цивільні полонені змушені виживати без підтримки | LEDE: ] (uk: Чужі серед своїх. Чому звільнені цивільні полонені змушені виживати без підтримк)
  - (2026-09-17) Росіяни атакували село на Запоріжжі: одна людина загинула і одна постраждала | LEDE: Унаслідок атаки росіян керованими авіабомбами по Сторчовому загинула 51-річна жінка, 70-річний чоловік поран] (uk:…
      Унаслідок атаки росіян керованими авіабомбами по Сторчовому загинула 51-річна жінка, 70-річний чоловік поранений і отримує допомогу.

### IT, InfoSys & cybersecurity news (last 7 days) — 47 new of 57 total
  - (2026-09-17) [BleepingComputer] US takes down NightmareStresser DDoS-for-hire platform
      The U.S. Federal Bureau of Investigation (FBI) seized the domains used by NightmareStresser, one of the world's longest-running distributed denial-of-service (DDoS) platforms. [...]
  - (2026-09-17) [BleepingComputer] Chinese hackers use SparroWocky malware in govt espionage attacks
      The China-linked espionage group FamousSparrow has been using a new backdoor named SparroWocky in attacks on government organizations in Latin America. [...]
  - (2026-09-17) [BleepingComputer] Microsoft shares workaround for Windows domain login issues
      Microsoft shared a temporary fix on Wednesday for a known issue that prevents Windows 11 users from logging in with valid domain credentials after installing the September 2026 security updates. [...]
  - (2026-09-17) [BleepingComputer] Cisco warns of max severity ISE zero-day exploited in attacks
      Cisco has released security updates to address a maximum-severity Identity Services Engine vulnerability that attackers are actively exploiting in the wild. [...]
  - (2026-09-17) [BleepingComputer] Anthropic wants Claude to analyze your bank account and financial data
      Anthropic is testing a new personal finance feature called "Claude Money" that will allow you to connect your bank accounts directly to Claude and "understand your money." [...]
  - (2026-09-17) [The Record] Israeli contractor BlackCore trained Angolan officials in online influence operations
      An Israeli influence-for-hire company trained Angolan government officials to run online influence operations, including by creating fake social media personas and media outlets, researchers found.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-17) [Pfeifer John C] Form 4 (Reporting)
      filed 2026-09-17 12:21 UTC · role: Reporting — Filed: 2026-09-17 AccNo: 0001628280-26-062381 Size: 5 KB
  - (2026-09-17) [James Hardie Industries plc] Form 4 (Issuer)
      filed 2026-09-17 12:21 UTC · role: Issuer — Filed: 2026-09-17 AccNo: 0001628280-26-062381 Size: 5 KB
  - (2026-09-17) [Sindel Alan Robert Harold] Form 4 (Reporting)
      filed 2026-09-17 12:20 UTC · role: Reporting — Filed: 2026-09-17 AccNo: 0001628280-26-062378 Size: 5 KB
  - (2026-09-17) [James Hardie Industries plc] Form 4 (Issuer)
      filed 2026-09-17 12:20 UTC · role: Issuer — Filed: 2026-09-17 AccNo: 0001628280-26-062378 Size: 5 KB
  - (2026-09-17) [Chen Lawrence Liren] Form 4 (Reporting)
      filed 2026-09-17 12:09 UTC · role: Reporting — Filed: 2026-09-17 AccNo: 0001628280-26-062376 Size: 11 KB
  - (2026-09-17) [InterDigital, Inc.] Form 4 (Issuer)
      filed 2026-09-17 12:09 UTC · role: Issuer — Filed: 2026-09-17 AccNo: 0001628280-26-062376 Size: 11 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-09-17) PATRUL33 (Brazil)
      icao24: e49edf · position: (-4.1307, -69.6102) · alt: 3208m · 208km/h
  - (2026-09-17) JAF95J (Bulgaria)
      icao24: 4520aa · position: (36.4936, -7.9508) · alt: 11269m · 944km/h
  - (2026-09-17) GAF141 (Germany)
      icao24: 3f62fc · position: (56.4141, 17.2317) · alt: 5478m · 515km/h
  - (2026-09-17) PUMAD (France)
      icao24: 39ddf7 · position: (42.542, 8.8253) · alt: 327m · 121km/h
  - (2026-09-17) PAT784 (United States)
      icao24: adfe4c · position: (33.8584, -83.2871) · alt: 7620m · 509km/h
  - (2026-09-17) PAT935 (United States)
      icao24: adfe8d · position: (36.364, -85.0336) · alt: 7620m · 506km/h

### State Legislative Action — 22 new of 74 total
  - (2026-09-17) [Alaska SB 270] An Act relating to grand juries; amending Rules 5(e), 6, and 6.1, Alaska Rules of Criminal Procedure; repealing Rules 6.1(b)(2) and (3), Alaska Rules of Criminal Procedure; and providi…
      An Act relating to grand juries; amending Rules 5(e), 6, and 6.1, Alaska Rules of Criminal Procedure; repealing Rules 6.1(b)(2) and (3), Alaska Rules of Criminal Procedure; and providing for an effective date.
  - (2026-09-16) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…
  - (2026-09-17) [California SB 1077] CalFresh: federal government shutdowns.
      Existing federal law provides for the Supplemental Nutrition Assistance Program (SNAP) , known in California as CalFresh, under which supplemental nutrition assistance benefits allocated to the state by the federal gover…
  - (2026-09-17) [California SB 1051] Foster care: childcare.
      Existing law establishes the Emergency Child Care Bridge Program for Foster Children, to be implemented at the discretion of each county, for the purpose of stabilizing foster children with families at the time of placem…
  - (2026-09-17) [California AB 1795] Smoke Damage Recovery Act.
      (1) Existing law generally regulates classes of insurance, including fire and residential property insurance. Existing law specifies the measure of indemnity under an open fire insurance policy that requires payment of a…
  - (2026-09-17) [California SB 615] Vehicle traction batteries.
      Existing law requires the Secretary for Environmental Protection to convene the Lithium-Ion Car Battery Recycling Advisory Group to review, and advise the Legislature on, policies pertaining to the recovery and recycling…

### Paper Trading Scorecard — 21 new of 126 total
  - (2026-09-17) [Manifold] Another Fed Rate Hike in 2026?
  - (2026-09-17) [Manifold] Will people use the internet in 2030?
  - (2026-09-17) [Manifold] Will trump say or write "effective altruism"?
  - (2026-09-17) [Manifold] Will Australia loosen copyright laws to allow AI model training by EOY 2027?
  - (2026-09-17) [Manifold] US Average DIESEL Price Is $8 or more on any day in 2026?
  - (2026-09-17) [Manifold] US Average Gas Price Is $4.5500 or more on September 21 2026?

### Court opinions of consequence (federal & state) — 17 new of 60 total
  - (2026-09-22) Connecticut Supreme Court: State v. Khan
  - (2026-09-16) U.S. Court of Appeals, 11th Cir.: T. Mueller v. Walmart Corporation
  - (2026-09-16) U.S. Court of Appeals, 1st Cir.: Savage v. City of Springfield
  - (2026-09-16) U.S. Court of Appeals, 1st Cir.: United States v. Levasseur
  - (2026-09-16) U.S. Court of Appeals, 5th Cir.: NexPoint v. Highland
  - (2026-09-16) U.S. Court of Appeals, 3rd Cir.: Kindra O'Bryant v. DCP&P

### U.S. Federal Action — 16 new of 22 total
  - (2026-09-17) Airworthiness Directives; Pratt & Whitney Engines
      The FAA proposes to adopt a new airworthiness directive (AD) for all Pratt & Whitney (PW) Model PW1519G, PW1521G, PW1521GA, PW1521G- 3, PW1524G, PW1524G-3, PW1525G, PW1525G-3, PW1919G, PW1919G-RC, PW1921G, PW1921G-RC, PW…
  - (2026-09-17) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A300 B4-600, B4-600R, and F4-600R series airplanes; and Model A300 C4-605R Variant F airplanes (collectively called Model A300-600 ser…
  - (2026-09-17) Airworthiness Directives; ATR-GIE Avions de Transport Régional Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all ATR-GIE Avions de Transport R[eacute]gional Model ATR42 and ATR72 airplanes. This proposed AD was prompted by reports of uncommanded nose landing gear…
  - (2026-09-17) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for all Airbus SAS Model A330-243, A330-243F, A330-341, A330-342, and A330-343 airplanes. This AD was prompted by reports of cracked and broken restraint brackets of…
  - (2026-09-17) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain The Boeing Company Model 767-300F series airplanes. This AD was prompted by a report of a supplier notice of escapement documenting that some titanium ca…
  - (2026-09-17) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain The Boeing Company Model 737-8, 737-9, and 737-8200 airplanes. This AD was prompted by reports indicating cracks in the bear strap and stub frame at the…

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-09-17) LoL: Top Esports vs Invictus Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $2,153,091 · resolves 2026-09-17
  - (2026-09-17) LoL: Top Esports vs Invictus Gaming (BO5) - LPL Regional Finals Playoffs
      yes price: 84% · 24h volume: $1,745,858 · resolves 2026-09-17
  - (2026-09-17) LoL: Top Esports vs Invictus Gaming - Game 3 Winner
      yes price: 100% · 24h volume: $1,435,318 · resolves 2026-09-17
  - (2026-09-17) Will there be no change in Fed interest rates after the October 2026 meeting?
      yes price: 54% · 24h volume: $1,132,025 · resolves 2026-10-28
  - (2026-09-17) Will Elon Musk win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $948,403 · resolves 2028-11-07
  - (2026-09-17) LoL: Top Esports vs Invictus Gaming - Game 4 Winner
      yes price: 72% · 24h volume: $829,747 · resolves 2026-09-17

### USGS earthquakes (M4.5+, past day) — 15 new of 15 total
  - (2026-09-17) M 5.3 - 191 km SE of Mata-Utu, Wallis and Futuna
      M5.3 · 191 km SE of Mata-Utu, Wallis and Futuna · depth 10 km
  - (2026-09-17) M 5.3 - 155 km SSE of Hihifo, Tonga
      M5.3 · 155 km SSE of Hihifo, Tonga · depth 10 km
  - (2026-09-17) M 5.2 - 132 km E of Bitung, Indonesia
      M5.2 · 132 km E of Bitung, Indonesia · depth 10 km
  - (2026-09-16) M 5.1 - 77 km SSW of San Jose Village, Northern Mariana Islands
      M5.1 · 77 km SSW of San Jose Village, Northern Mariana Islands · depth 110.79 km
  - (2026-09-17) M 5.0 - South Atlantic Ocean
      M5.0 · South Atlantic Ocean · depth 10 km
  - (2026-09-16) M 5.0 - 29 km WSW of Sipí, Colombia
      M5.0 · 29 km WSW of Sipí, Colombia · depth 59.026 km

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 99 total
  - (2026-09-16) [OFAC] Russia-related Designations Removals; Counter Narcotics Designation Removal; Issuance of Amended Venezuela General License and Frequently Asked Question - Office of Foreign Assets Control (.gov…
      Russia-related Designations Removals; Counter Narcotics Designation Removal; Issuance of Amended Venezuela General License and Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-09-16) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Z Authorizing Certain Tra - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Z Authorizing Certain Tra Office of Foreign Assets Control (.gov)
  - (2026-09-16) [FARA] Office of Public Affairs | Liability for Unregistered Foreign Agents - Department of Justice (.gov)
      Office of Public Affairs | Liability for Unregistered Foreign Agents Department of Justice (.gov)
  - (2026-09-17) [USASpending] $14,950,328,527 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE
      Agency: Department of Energy. Description: OPERATION AND MAINTENANCE LINEAR ACCELLERATOR
  - (2026-09-17) [USASpending] $3,373,486,394 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…
  - (2026-09-17) [USASpending] $2,297,343,789 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 19 total
  - (2026-09-16) CVE-2026-58704 · Google Pixel: Google Pixel Improper Authorization Vulnerability
      vendor: Google · product: Pixel · CISA remediation by 2026-09-19
  - (2026-09-16) CVE-2026-76460 · Cisco Identity Services Engine: Cisco Identity Services Engine Incorrect Use of Privileged APIs Vulnerability
      vendor: Cisco · product: Identity Services Engine · CISA remediation by 2026-09-19
  - (2026-09-16) CVE-2026-87886 · Acronis Backup: Acronis Backup Incorrect Default Permissions Vulnerability
      vendor: Acronis · product: Backup · CISA remediation by 2026-09-19

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-17) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=19, 14d-median=17; carrying terms: unless, safety, proposing, adopt, prohibited, coast, guard, vessels, proposed, authorized, certain, program
- state_bills: today=74, 7d-median=90, 14d-median=85; carrying terms: social, misdemeanor, emergency, application, authorize, acquisition, until, educational, education, costs, office, authorizing
- state_news: today=836, 7d-median=772, 14d-median=586; carrying terms: agents, social, according, thursday, emergency, developers, enacted, montana, civil, lincoln, found, appeals
- local_news: today=231, 7d-median=236, 14d-median=229; carrying terms: according, found, https, fulton, downtown, charged, target, google, including, since, color, missouri
- foreign_news: today=1081, 7d-median=986, 14d-median=1004; carrying terms: according, social, billion, targets, internet, urged, thumbnail, backs, families, country, author, threatens
- chinese_internal: today=298, 7d-median=288, 14d-median=283; carrying terms: cbmizkfvx, target, cbmibkfvx, google, cbmidefvx, cbmiw, cbmia, property, people, cbmibefvx, cbmickfvx, lxtfb
- russian_internal: today=1177, 7d-median=1059, 14d-median=1050; carrying terms: found, https, europe, blank, guardian, error, gazeta, telegram, raquo, client, reuters, openai
- ukrainian_internal: today=139, 7d-median=136, 14d-median=136; carrying terms: according, prime, found, early, billion, ukrinform, https, vladimir, country, peace, zelensky, major
- ukraine_theater: today=450, 7d-median=351, 14d-median=433; carrying terms: vzxhjdxppbzdwegdz, qvpou, nemdjuwlqmxjqukl, civil, total, areas, nlrmdepyvju, kurdistan, bjhkski, ilwttethdewnsmkszoedmz, exchange, ujzbsg
- paper_bets: today=126, 7d-median=128, 14d-median=128; carrying terms: speed, california, predictit, sachs, starts, growth, israel, labor, schumer, colonize, senate, participation
- weather: today=121, 7d-median=114, 14d-median=110; carrying terms: thursday, gusty, twoat, lower, until, lincoln, changed, updated, areas, early, rivers, friday
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: nonfarm, assets, payems, labor, unrate, energy, openings, indicator, growth, jolts, rates, recession
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, russell, large, nasdaq, close, china, range, agriculture, natural, silver, bitcoin, rates
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=108, 14d-median=106; carrying terms: qaida, acronym, beirut, adopted, sudan, russia, energy, application, burundi, tiananmen, eastern, events
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, client, https, quiver, unauthorized, error, congresstrading, quiverquant, httperror
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, appeals, supreme, court, company, international, allen, connecticut, trade, corrections, corporation, energy
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, holdings, filer, trust, subject, tidal, robert, financial
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, lindsey, trone, cycle, committee, graham, brown, disbursements, senate, booker, cortez, krishnamoorthi
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: israel, hezbollah, english, sanctions, turkish, minister, iranian, attack
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, canada, germany, bulgaria, ground, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: transmission, ethiopia, pregnant, social, according, genomic, ituri, disembarked, infant, spain, epidemiological, israel
- cisa_kev: today=19, 7d-median=23, 14d-median=22; carrying terms: command, confusion, chromium, bounds, vulnerability, improper, vendor, critical, google, netscaler, jfrog, write
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=15, 7d-median=13, 14d-median=12; carrying terms: depth, islands, indonesia, vanuatu, japan, south, kermadec, zealand, papua, puerto, guinea, colombia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, rates, price, change, september, league, interest, decrease, shakhtar, meeting, champions, championship
- commentary: today=0, 7d-median=6, 14d-median=6; carrying terms: conversableeconomist, evidence, conversable, marginal, revolution, https, economist, class, recent, story, explain, price
- tech_news: today=57, 7d-median=57, 14d-median=56; carrying terms: agents, according, based, security, cyber, https, rsquo, enough, technology, companies, written, computer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: harder, lindsey, madeleine, darrell, dingell, philadelphia, hageman, cloud, currency, amodei, shomari, harris
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, paper, evidence, placed, identify, module, today, either, placement, converges, unavailable, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-10] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-11] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy
- [2026-09-12] ECB press: Christine Lagarde: Interview with Ouest-France
- [2026-09-14] ECB press: Isabel Schnabel: Macroeconomic, fiscal and financial stability in a shock-prone world
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI
- [2026-09-16] ECB press: ECB wage tracker at 2.7% in H1 2027, pointing to a modest uptick in negotiated wage growth
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*