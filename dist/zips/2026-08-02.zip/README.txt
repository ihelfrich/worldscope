WORLDSCOPE daily package — 2026-08-02

Contents:
  index.html       The rendered briefing page
  overview.md      Analyst's morning brief (cross-section synthesis)
  raw/<id>.json    Normalized items per section
  calendar.json    Forthcoming events (next ~14 days, where dated)
  trends.json      14-day section trends + carrying terms
  manifest.json    Provenance + counts

Provenance: all items link back to their source URL. Synthesis prose is
grounded in the listed items only; numbers in 'trends' come from
snapshots stored in ~/.worldscope/store.sqlite.