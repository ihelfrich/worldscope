# WORLDSCOPE morning brief — 2026-08-02

## Headline
2369 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (497) · Russian Internal News (state + in-exile) (442) · Ukraine Theater (total-war monitoring) (431) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (145) · Chinese Internal News (131) · State-Level News (88) · Local News: St. Louis + Atlanta (84) · Ukrainian Internal News (national + local Kyiv) (50) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (28) · GDELT GKG — themes / entities / watch areas (25)

## What changed today
### International News + Multilateral Institutions — 497 new of 954 total
  - (2026-08-02) [Global] Trump cancels Iran strikes subject to deal being made 'rapidly'
      The US president claims Iran and other Middle Eastern countries asked Washington to hold off on any attack as the "perimeters" of a deal had been agreed.
  - (2026-08-02) [Global] At least eight killed in Israeli strikes on Gaza after Hamas agree disarmament deal
      Israel says it was targeting military operatives in the strikes on Gaza City, Khan Younis and Deir el-Balah.
  - (2026-08-02) [Global] How Spain's migrant crisis created a political storm - whipped up by social media
      The Ceuta crossings have shaken Europe politically, exposing divisions over the sensitive issue of migration, the BBC's Sarah Rainsford writes.
  - (2026-08-02) [Global] Five dead, 41 missing, after Indonesia ferry catches fire
      The vessel with at least 250 people on board caught fire off Madura island.
  - (2026-08-01) [Global] A bruising 24 hours - what next for Fifa and under-pressure Infantino?
      Pressure is building on Gianni Infantino. Can he survive as Fifa president after the implosion of the controversial World Cup investment plan?
  - (2026-08-02) [Global] Body of mountaineer Nirmal Purja recovered after Pakistan avalanche
      The renowned climber was known for scaling the world's 14 highest peaks in just over six months in 2019.

### Russian Internal News (state + in-exile) — 442 new of 908 total
  - (2026-08-02) Марокканская футболистка погибла, пытаясь добраться до Сеуты | LEDE: 20-летняя марокканская футболистка Фатен Бен Омар эль-Азиз, играющая за «Магреб Атлетик» (Maghreb Atlético Tetuán), погиб] (ru: Мар…
      20-летняя марокканская футболистка Фатен Бен Омар эль-Азиз, играющая за «Магреб Атлетик» (Maghreb Atlético Tetuán), погибла при попытке добраться до Сеуты, сообщают Mundo Deportivo и El Mundo со ссылкой на заявление клуб…
  - (2026-08-02) Российское подсанкционное судно доставило в Мали военную технику — для борьбы с повстанцами, которую правительство страны ведет при поддержке Москвы | LEDE: Российское грузовое судно «Михаил] (ru: Рос…
      Российское грузовое судно «Михаил Бритнев» в начале июля доставило в порт Ломе в Того военную технику, которая затем была переправлена в столицу Мали Бамако — для поддержки российских и малийских военных в борьбе с повст…
  - (2026-08-02) Патриарх Кирилл назвал российское ядерное оружие «благодатью божьей» | LEDE: Патриарх Кирилл во время своей речи перед верующими в Свято-Троицком Серафимо-Дивеевском женском монастыре в Ниже] (ru: Пат…
      Патриарх Кирилл во время своей речи перед верующими в Свято-Троицком Серафимо-Дивеевском женском монастыре в Нижегородской области высказался о создании и предназначении российского ядерного оружия.
  - (2026-08-02) Война. 1621-й день. Украина атакует очередной (уже 17-й) склад Wildberries. Командир беспилотных войск ВСУ обещает, что это «точно не последний» удар | LEDE: «Медуза» с 24 февраля 2022 года ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Украина расширяет масштаб атак по РФ. Ц…
  - (2026-08-02) Собянин назвал взрыв в московском ресторане терактом. По данным телеграм-каналов, число погибших выросло до пяти человек | LEDE: Взрыв в ресторане Balzi Rossi на Кудринской площади был терак] (ru: Соб…
      Взрыв в ресторане Balzi Rossi на Кудринской площади был терактом, заявил мэр Москвы Сергей Собянин.
  - (2026-08-02) Украина снова бьет по складам Wildberries. Атакован уже 17-й — теперь в Самарской области. Он загорелся и «полностью сложился». Фотографии и видео | LEDE: Украинские беспилотники вновь атако] (ru: Укр…
      Украинские беспилотники вновь атаковали склад Wildberries — на этот раз в Самарской области. По данным самой компании и властей региона, пострадавших в результате атаки нет, однако логистический комплекс загорелся, и, по…

### Ukraine Theater (total-war monitoring) — 431 new of 973 total
  - (2026-08-02) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-31) [Liveuamap] Number of wounded as result of Russian airstrike in Kherson increased to 4 - Liveuamap
      Number of wounded as result of Russian airstrike in Kherson increased to 4 Liveuamap
  - (2026-08-02) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap
  - (2026-08-02) [Liveuamap] A ship was targeted and explosions occurred 21 nautical miles northeast of Khasab, Oman. Strait of Hormuz - Liveuamap
      A ship was targeted and explosions occurred 21 nautical miles northeast of Khasab, Oman. Strait of Hormuz
  - (2026-08-02) [Liveuamap] Big fire at the oil refinery in Saratov as result of a drone strike - Liveuamap
      Big fire at the oil refinery in Saratov as result of a drone strike Liveuamap
  - (2026-07-31) [Liveuamap] Palestinian Civil Defense: One dead and one wounded in an Israeli raid on Mawasi Khan Yunis, southern Gaza Strip - Liveuamap
      Palestinian Civil Defense: One dead and one wounded in an Israeli raid on Mawasi Khan Yunis, sou

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 145 new of 152 total
  - (2026-08-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-02) [Moderate] Special Weather Statement: Special Weather Statement issued August 2 at 10:13AM CDT by NWS Corpus Christi TX
      At 1012 AM CDT, Doppler radar was tracking a cluster of strong thunderstorms over Portland, moving south at 5 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree li…
  - (2026-08-02) [Unknown] Air Quality Alert: Air Quality Alert issued August 2 at 9:12AM MDT by NWS Great Falls MT
      AQAMT The Montana Department of Environmental Quality has issued an air quality alert for Chouteau, Flathead, Glacier, Hill, Lake, Liberty, Lincoln, Pondera, Sanders, Teton, Toole counties in effect until 9AM on 08/03/20…
  - (2026-08-02) [Unknown] Air Quality Alert: Air Quality Alert issued August 2 at 9:12AM MDT by NWS Great Falls MT
      AQAMT The Air Quality Alert for Beaverhead, Blaine, Broadwater, Cascade, Deer Lodge, Fergus, Granite, Jefferson, Judith Basin, Lewis and Clark, Meagher, Mineral, Missoula, Petroleum, Phillips, Powell, Ravalli and Silver…
  - (2026-08-02) [Severe] Special Marine Warning: Special Marine Warning issued August 2 at 11:09AM EDT until August 2 at 12:15PM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Englewood to Tarpon Springs FL out 20 NM... Coastal waters from Tarpon Springs to Suwannee River FL out 20 NM…
  - (2026-08-02) [Severe] Special Marine Warning: Special Marine Warning issued August 2 at 10:08AM CDT until August 2 at 11:45AM CDT by NWS Mobile AL
      SMWMOB The National Weather Service in Mobile has issued a * Special Marine Warning for... Waters from Okaloosa-Walton County Line to Pensacola FL from 20 to 60 NM... * Until 1145 AM CDT. * At 1008 AM CDT, a strong thund…

### Chinese Internal News — 131 new of 260 total
  - (2026-08-02) AIIB explores digital payments, eyes Hong Kong hub as it raises record funds
  - (2026-08-02) China sees flurry of commercial property deals as investors sniff out bargains
  - (2026-08-02) First impressions count as Chinese buyers open their homes to UBTech’s consumer humanoids
  - (2026-08-02) Cheung Kong Center II tests higher rents amid rebound in Central office market
  - (2026-08-02) 时政新闻眼丨八一建军节前夕这次集体学习，传递了哪些重要信息？ - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTE5QQjlqaVR4UmJNdkIySkc1UDBxQjdPdm5NWGFIaS1GZVJMY2gzbDF1YTZob1hRSUFURUp] (zh:…
      时政新闻眼丨八一建军节前夕这次集体学习，传递了哪些重要信息？ politics.people.com.cn
  - (2026-08-02) 最新研究在脑出血后神经再生领域取得关键进展 - 人民网科技 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9Xa0MyeVQzNktGUUJoOGswTGx3ZUdFUVNmMlBRMmJYaGxJUFNKMmtvMlJjZVJyTXNGaHJNb29CZUU0RTdEM1Y1RlFXS0ZMR] (zh:…
      最新研究在脑出血后神经再生领域取得关键进展 人民网科技

### State-Level News — 88 new of 469 total
  - (2026-08-02) [Alaska] Farmers Market Week 2026
      WHEREAS, the United States Department of Agriculture (USDA) proclaimed the first National Farmers Market Week in 1999 to raise awareness of efforts nationwide for producers to sell directly to customers; and WHEREAS, a f…
  - (2026-08-02) [Alaska] Community Health Center Week 2026
      WHEREAS, for over fifty years, community health centers have delivered accessible and affordable healthcare to underserved and uninsured members of communities across the Nation; and WHEREAS, a community health center’s…
  - (2026-08-02) [Connecticut] Lamont’s fiscal success rests on foundation laid by Malloy, others
      <img width="1024" height="769" src="https://ctmirror.org/wp-content/uploads/2018/11/CTJH107.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high" srcset="ht…
  - (2026-08-02) [Connecticut] CT’s $1.6 billion railroad promise
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/caternary-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcse…
  - (2026-08-02) [Arkansas] String of outbreaks tests US public health system amid funding cuts, vaccine resistance
      WASHINGTON — Health and Human Services Secretary Robert F. Kennedy Jr. pledged during his confirmation hearing to do everything in his “power to put the health of America back on track.” Kennedy testified that when he wo…
  - (2026-08-02) [Arkansas] Immigrants helped shape Arkansas. The state shouldn’t forget that history.
      I’ve never been to Tontitown, nor have I had the pleasure of partaking in its storied annual Grape Festival. But the northwest Arkansas community founded by Italian immigrants feels familiar to me. That’s partly because…

### Local News: St. Louis + Atlanta — 84 new of 225 total
  - (2026-08-02) [St. Louis] Witness to Idaho In-N-Out shooting says gunman fired 'at random' into traffic, drive-thru
      A bystander said another armed man returned fire as the gunman shot into traffic and the drive-thru.
  - (2026-08-02) [St. Louis] Gunman found dead after Idaho shooting that left 3 people dead and injured several others
      "It was a very chaotic scene," Twin Falls Police Chief Matthew Hicks said at a news conference.
  - (2026-08-02) [St. Louis] Did anyone win the Powerball? Winning numbers for Saturday, Aug. 1, 2026
      An estimated $719 million was on the line in Saturday night's Powerball drawing.
  - (2026-08-02) [St. Louis] Flight attendants at Canada's WestJet go on strike in dispute over pay
      The Canadian Union of Public Employees represents the 4,400 cabin crew and announced the strike on Sunday.
  - (2026-08-02) [St. Louis] President Trump says he will order American forces to hold off on new strikes against Iran
      The emerging deal “would include the Immediate, Complete, and Total OPENING OF THE HORMUZ STRAIT, and an end to Iran’s nuclear threat,” Trump wrote Saturday.
  - (2026-08-02) [St. Louis] Triple shooting on Gravois leaves 1 critically injured
      Police said three people were shot Saturday night on Gravois Avenue, leaving one person critically injured.

### Ukrainian Internal News (national + local Kyiv) — 50 new of 130 total
  - (2026-08-02) Lubomyr Medvid: ‘Ukraine Can Become Europe’s Teacher, Not Its Stepchild’
      For more than six decades, Lubomyr Medvid has explored history, exile, faith and human conscience. In this wartime monologue, he argues that a renewed Ukraine can become Europe’s partner – and even its teacher.
  - (2026-08-02) Ukrainian Soldiers’ Homecoming Odyssey
      The new cinematic adaptation of Homer’s epic is poignantly relevant to the lives of Ukraine’s warriors, who will need to transcend their war experience. Peace is not merely the absence of a foreign enemy. It requires the…
  - (2026-08-02) Ukraine’s Success
      Clearly, Trump must learn how to identify enemies and choose allies more wisely. In Ukraine’s case, he finally appears to be heeding the wisdom contained in the 4th-century Sanskrit proverb: “The enemy of my enemies is m…
  - (2026-08-02) Belarus Forms New Airborne Brigade Near Ukraine
      Belarus has begun forming a new airborne assault brigade in the southern Gomel region, approximately 40 kilometers (25 miles) from the Ukrainian border. SOF Commander Alexander Ilyukevich announced that the 37th Separate…
  - (2026-08-02) Russian Elites Grow Impatient as Propagandists Panic
      Vladimir Putin is facing growing internal pressure as Russian elites, including top banker German Gref and oligarch Andrey Melnichenko, express unprecedented impatience over the failing war and economic ruin caused by Uk…
  - (2026-08-02) Russian Arms Shipment Reaches Mali via Togo
      The sanctioned Russian cargo vessel Mikhail Britnev delivered a large shipment of military vehicles to Mali’s ruling junta via the port of Lomé in Togo. The ship, which departed Baltiysk on June 18 and was escorted throu…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 28 total
  - (2026-08-02) JAF8LY (Bulgaria)
      icao24: 4520d0 · position: (46.0899, -1.6322) · alt: 11582m · 921km/h
  - (2026-08-02) JAF49Y (Bulgaria)
      icao24: 4520aa · position: (35.6224, -6.4872) · alt: 11582m · 855km/h
  - (2026-08-02) PAT401 (United States)
      icao24: adfe47 · position: (40.5803, -75.6826) · alt: 1524m · 358km/h
  - (2026-08-02) PAT910 (United States)
      icao24: adfe95 · position: (39.8514, -84.0107) · alt: 434m · 208km/h
  - (2026-08-02) PAT911 (United States)
      icao24: adfe93 · position: (39.8229, -84.0404) · on ground · 25km/h
  - (2026-08-02) EAGLE7 (Kingdom of the Netherlands)
      icao24: 486462 · position: (36.7316, 15.7865) · alt: 1531m · 288km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-02) [Russia oil sanctions perimeter · themes] 不務正業的沈伯洋們 - 天蠍浪子的咖啡杯 - udn部落格
      blog.udn.com · Chinese · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · themes] Five dead , 41 missing , after Indonesia ferry catches fire
      capitalfm.africa · English · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · themes] Tehran Did Not Ask Trump To Halt Attacks , Says Iranian Media
      middleeaststar.com · English · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · themes] Al menos cinco muertos y más de 40 desaparecidos tras el incendio de un ferry en Indonesia
      infobae.com · Spanish · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · themes] Ceuta . Redes sociais incentivaram ida de jovens migrantes – Observador
      observador.pt · Portuguese · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · themes] Capital inflows , RBI support limit rupee decline despite 20 % oil price surge in July : Report
      bangladeshsun.com · English · tone NA

### State Legislative Action — 22 new of 82 total
  - (2026-08-02) [California AB 1924] Statewide homelessness prevention strategy.
      Existing law establishes the California Interagency Council on Homelessness and requires the council to take various actions to prevent and end homelessness in California. Existing law establishes various programs to pre…
  - (2026-08-02) [California AB 1826] Cannabis: recall, embargo, and destruction of cannabis and cannabis products.
      Existing law, the Medicinal and Adult-Use Cannabis Regulation and Safety Act (MAUCRSA) , governs the licensure and regulation of commercial cannabis activities. MAUCRSA prohibits engaging in certain commercial activities…
  - (2026-08-02) [California AB 2516] California Grid Manufacturing Initiative.
      Existing law establishes the Governor's Office of Business and Economic Development (GO-Biz) within the Governor's office and requires GO-Biz to serve the Governor as the lead entity for economic strategy and the marketi…
  - (2026-08-02) [California AB 2101] Human trafficking: notice and training: disaster sites.
      Existing law requires specified businesses and other establishments, including, among others, airports, intercity passenger rail or light rail stations, bus stations, and truck stops, to post a notice, as developed by th…
  - (2026-08-02) [California AB 2493] Electrical corporations: interconnection: transmission: permitting: auditor.
      Existing law vests the Public Utilities Commission with regulatory authority over public utilities, including electrical corporations. Existing law requires the commission, if it determines that the rules, practices, equ…
  - (2026-08-02) [California AB 2483] Wildland firefighters: Formerly Incarcerated Firefighter Certification and Employment Program.
      Existing law establishes in the Natural Resources Agency the Department of Forestry and Fire Protection, and requires the department to be responsible for, among other things, fire protection and prevention, as provided.…

### USGS earthquakes (M4.5+, past day) — 17 new of 22 total
  - (2026-08-02) M 5.6 - 14 km S of Hicks Bay, New Zealand
      M5.6 · 14 km S of Hicks Bay, New Zealand · depth 52.806 km
  - (2026-08-02) M 5.3 - north of Ascension Island
      M5.3 · north of Ascension Island · depth 10 km
  - (2026-08-02) M 5.3 - 265 km S of ‘Ohonua, Tonga
      M5.3 · 265 km S of ‘Ohonua, Tonga · depth 10 km
  - (2026-08-02) M 5.2 - 112 km SW of Severo-Kuril’sk, Russia
      M5.2 · 112 km SW of Severo-Kuril’sk, Russia · depth 80.691 km
  - (2026-08-02) M 5.1 - 60 km W of Bahía de Lobos, Mexico
      M5.1 · 60 km W of Bahía de Lobos, Mexico · depth 10 km
  - (2026-08-02) M 5.0 - north of Ascension Island
      M5.0 · north of Ascension Island · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-08-02) Counter-Strike: Spirit vs MOUZ (BO5) - BLAST Bounty Playoffs
      yes price: 0% · 24h volume: $2,608,382 · resolves 2026-08-02
  - (2026-08-02) LoL: KT Rolster vs Hanwha Life Esports (BO3) - LCK Round 3-4 Legend Group
      yes price: 100% · 24h volume: $2,305,591 · resolves 2026-08-02
  - (2026-08-02) LoL: KT Rolster vs Hanwha Life Esports - Game 1 Winner
      yes price: 100% · 24h volume: $1,368,291 · resolves 2026-08-02
  - (2026-08-02) Counter-Strike: Spirit vs MOUZ - Map 4 Winner
      yes price: 0% · 24h volume: $948,809 · resolves 2026-08-02
  - (2026-08-02) LoL: KT Rolster vs Hanwha Life Esports - Game 2 Winner
      yes price: 0% · 24h volume: $913,637 · resolves 2026-08-02
  - (2026-08-02) Counter-Strike: Spirit vs MOUZ - Map 3 Winner
      yes price: 100% · 24h volume: $904,951 · resolves 2026-08-02

### Paper Trading Scorecard — 13 new of 122 total
  - (2026-08-02) [Polymarket] Will Elon Musk post 220-239 tweets from July 28 to August 4, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 28 12:00 PM ET to August 4, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and r…
  - (2026-08-02) [Polymarket] St Johnstone FC vs. Kilmarnock FC: O/U 2.5
      In the upcoming Scottish Premiership game between St Johnstone FC and Kilmarnock FC, scheduled for August 2 at 9:00 AM ET: This market will resolve to "Over" if St Johnstone FC and Kilmarnock FC combine to score 3 or mor…
  - (2026-08-02) [Polymarket] Mitch McConnell steps down from Senate before his term ends?
      This market will resolve to “Yes” if Mitch McConnell formally announces an intention to step down or otherwise vacates his U.S. Senate seat before his current term is scheduled to end (January 3, 2027, 11:59 PM ET). Othe…
  - (2026-08-02) [Polymarket] Will Paris Saint-Germain win the 2026-27 UEFA Champions League Championship?
      This market will resolve according to the team that wins the 2026-27 UEFA Champions League Championship. If at any point it becomes impossible for a listed team to win the 2026-27 UEFA Champions League Championship per t…
  - (2026-08-02) [Manifold] Will Substack implement an automatic AI-generated-content filter by EoY 2026?
  - (2026-08-02) [Manifold] Will Abdul El Sayed and Francesca Hong both win their primaries?

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 103 total
  - (2026-07-31) [FARA] Criminal Division | Whistleblower Awards Pilot Program - Department of Justice (.gov)
      Criminal Division | Whistleblower Awards Pilot Program Department of Justice (.g
  - (2026-08-02) [USASpending] $42,257,183,759 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-08-02) [USASpending] $41,316,801,718 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-02) [USASpending] $26,286,482,128 → BATTELLE ENERGY ALLIANCE, LLC: MANAGEMENT AND OPERATIONS OF THE INL
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATIONS OF THE INL
  - (2026-08-02) [USASpending] $3,500,000,000 → DAVIE DEFENSE INC.: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF F
      Agency: Department of Homeland Security. Description: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF FIVE (5) EACH MULTI-PURPOSE POLAR SHIP (MPPS-100) VESSELS HEREAFTER REFERRED TO AS ARCTIC SECURITY CUTTERS…
  - (2026-08-02) [USASpending] $3,373,486,394 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-02) [China] Trade - in program drives smart , green cooling upgrade across China
      shanghainews.net · English
  - (2026-08-02) [China] China entrepreneurial ecosystem fuels growth of startups
      shanghainews.net · English
  - (2026-08-02) [China] AI reshapes China steel sector
      shanghainews.net · English
  - (2026-08-02) [China] CHINA - HENAN - LUOYANG - TUNNEL - CONSTRUCTION ( CN )
      shanghainews.net · English
  - (2026-08-02) [China] Posters : The 99th founding anniversary of China PLA
      shanghainews.net · English
  - (2026-08-02) [China] China BeiDou Navigation Satellite System completes in - orbit upgrade
      shanghainews.net · English

### IT, InfoSys & cybersecurity news (last 7 days) — 4 new of 52 total
  - (2026-08-02) [BleepingComputer] Google Chrome may soon block New Tab hijacker extensions by default
      Google is preparing a new Chrome security feature that would block policy-installed extensions from hijacking the New Tab page or changing the default search engine. [...]
  - (2026-08-02) [IEEE Spectrum] This Hi-Fi Tape Recorder Changed Radio Forever
      A German engineer wanted a cheaper cigarette. The popular crooner Bing Crosby wanted a vacation. Satisfying both desires inadvertently led to the invention of the laugh track. Along the way there were Nazis, spoils of wa…
  - (2026-08-02) [TechCrunch] These App Store hidden gems prove there’s still room for great software in the AI era
      Despite predictions that AI agents could make traditional apps obsolete, developers are shipping new software faster than ever. From smarter bookmarking tools and neighborhood marketplaces to digital pen pals and nature…
  - (2026-07-31) [Cybersecurity Dive] US authorities see ‘significant escalation’ in attacks on water system devices
      Hackers have locked operators out of their own OT networks, modified passwords and changed IP addresses.

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-08-02) [Marginal Revolution] On the Acemoglu-Autor et.al. fertility result
      Here is criticism from Revana Sharffuddin. Here is criticism from JFV. The post On the Acemoglu-Autor et.al. fertility result appeared first on Marginal REVOLUTION.
  - (2026-08-02) [Marginal Revolution] Taiwan fact of the day
      [Annualized] 14% GDP growth in the first half of 2026 The post Taiwan fact of the day appeared first on Marginal REVOLUTION.
  - (2026-08-02) [Marginal Revolution] Mexico (Taiwan) fact of the day
      Mexico has quietly become a cornerstone of the AI boom, providing 40 per cent of US imports this year of the computer servers that are widely used in the data centres powering artificial intelligence. Taiwanese manufactu…

### Court opinions of consequence (federal & state) — 2 new of 60 total
  - (2026-07-31) Louisiana Supreme Court: John T. Fuller v. State of Louisiana; Jeff Landry in His Official Capacity as Governor; Elizabeth B. Murrill, in Her Official Capacity as Attorney General; Nancy Landry, in He…
  - (2026-07-29) U.S. Court of Appeals, 2nd Cir.: Civil Rights Corps v. LaSalle

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: rulemaking, provide, final, proposed, proposes, notice, issued, safety, certain, taking, amend, requires
- state_bills: today=82, 7d-median=117, 14d-median=117; carrying terms: right, existing, programs, public, temporary, establishes, employee, support, operating, specific, years, apply
- state_news: today=469, 7d-median=758, 14d-median=626; carrying terms: served, tuesday, wants, facility, incarcerated, exceeded, programs, temporary, contentious, analysis, newsletter, client
- local_news: today=225, 7d-median=228, 14d-median=226; carrying terms: missing, public, search, illinois, custody, saportareport, employee, shows, shooting, officials, attachment, years
- foreign_news: today=954, 7d-median=1022, 14d-median=1014; carrying terms: australia, wants, missing, exceeded, criticism, rises, keeps, shanghai, gironde, governments, share, jilin
- chinese_internal: today=260, 7d-median=262, 14d-median=264; carrying terms: people, chinese, profit, https, google, china, record, caixin, firms, stock, beijing, billion
- russian_internal: today=908, 7d-median=916, 14d-median=912; carrying terms: instagram, telegram, openai, axios, wildberries, guardian, group, times, client, russian, found, istories
- ukrainian_internal: today=130, 7d-median=133, 14d-median=134; carrying terms: censor, breaking, strategic, attacked, client, return, drone, peace, diplomatic, support, victims, media
- ukraine_theater: today=973, 7d-median=647, 14d-median=637; carrying terms: client, frontline, known, https, httperror, google, community, unauthorized, viirs, thermal, active, coverage
- paper_bets: today=122, 7d-median=134, 14d-median=134; carrying terms: alphabetically, market, experience, robot, control, mbappe, rippling, player, approve, jinping, romania, artist
- weather: today=152, 7d-median=173, 14d-median=173; carrying terms: tuesday, winds, changed, southeastern, experience, impacts, water, bring, oxnard, mountains, lightning, visibility
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, dexchus, funds, rates, effective, commodities, growth, personal, walcl, dexuseu, inflation, unemployment
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, close, equities, proxy, rates, commodities, china, range, agriculture, silver, credit, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=103, 7d-median=104, 14d-median=108; carrying terms: funds, rkiye, description, prohibited, snapshot, sudan, daesh, beirut, enable, control, annexation, usaspending
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, error, httperror, quiverquant, client, quantitative, unauthorized, congresstrading, quiver
- billionaires: today=30, 7d-median=37, 14d-median=36; carrying terms: carlos, larry, discount, gcarsoa, adani, spacex, technology, ballmer, london, google, mukesh, gautam
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, arizona, texas, supreme, services, johnson, jones, court, california, delaware, county, blanche
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, holdings, steven, amended, robert
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, ocasio, cycle, platner, johnson, house, krishnamoorthi, congress, elect, jonathan, receipts, ossoff
- gdelt_regions: today=6, 7d-median=6, 14d-median=9; carrying terms: english, china
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, trump, attacks, price, russia, conflict, russian, chinese, themes, italian, spanish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=28, 7d-median=18, 14d-median=17; carrying terms: belgium, canada, position, ground, france, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: driving, multi, transmitted, transmission, additi, person, haemorrhage, oecusse, april, evolve, previously, informed
- cisa_kev: today=9, 7d-median=12, 14d-median=13; carrying terms: inclusion, functionality, remediation, overflow, authentication, vendor, product, vulnerability, management, stack, langflow, wordpress
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=296, 14d-median=296; carrying terms: australia, genevieve, orange, zambia, cyclone, poland, impact, fausto, panama, nicaragua, medium, minor
- usgs_quakes: today=22, 7d-median=22, 14d-median=21; carrying terms: depth, islands, south, indonesia, japan, china, russia, mexico, papua, guinea, abepura, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, returns, traffic, normal, august, ceasefire, strait, hormuz, effective, invade
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: economist, students, revolution, doctor, college, marginal, golden, conversable, government, become, having, conversableeconomist
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: artificial, newsletter, model, support, models, systems, being, information, bleepingcomputer, world, years, record
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: armstrong, kamlager, composite, zquez, reserve, angie, ruben, garamendi, nancy, fischbach, steny, yvette
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, evidence, consensus, placement, decision, claude, converges, market, today, paper, identify, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*