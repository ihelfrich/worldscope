# WORLDSCOPE morning brief — 2026-08-02

## Headline
1914 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (350) · World leaders & government officials (324) · Russian Internal News (state + in-exile) (315) · Ukraine Theater (total-war monitoring) (247) · U.S. Weather + Severe / Climate Outlooks (152) · Chinese Internal News (127) · State Legislative Action (87) · State-Level News (62) · Local News: St. Louis + Atlanta (62) · Ukrainian Internal News (national + local Kyiv) (33) · Sanctions & Designations (recent) (30) · GDELT GKG — themes / entities / watch areas (25)

## What changed today
### International News + Multilateral Institutions — 350 new of 935 total
  - (2026-08-02) [Global] Trump says he is cancelling strikes on Iran subject to deal being made 'rapidly'
      The US president claims Iran and other Middle Eastern countries asked Washington to hold off on any attack as the "perimeters" of a deal had been agreed.
  - (2026-08-02) [Global] How Spain's migrant crisis created a political storm - whipped up by social media
      The Ceuta crossings have shaken Europe politically, exposing divisions over the sensitive issue of migration, the BBC's Sarah Rainsford writes.
  - (2026-08-01) [Global] A bruising 24 hours - what next for Fifa and under-pressure Infantino?
      Pressure is building on Gianni Infantino. Can he survive as Fifa president after the implosion of the controversial World Cup investment plan?
  - (2026-08-01) [Global] How Australia combines modern tech and Indigenous knowledge to fight wildfires
      As Europe faces its worst wildfires in decades, Australia offers lessons in disaster preparedness.
  - (2026-08-01) [Global] Solitude as a new aspirational lifestyle: 'We are not lonely'
      A growing number of what the internet has dubbed "loneliness influencers" are spotlighting solo living without children or friends - and it's spurring debate.
  - (2026-08-02) [Global] Parents save on school uniforms at city swap shop
      Parents take home school uniform for free at a pop-up that organisers hope can become a regular event.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Russian Internal News (state + in-exile) — 315 new of 856 total
  - (2026-08-02) Трамп вновь отложил атаку на Иран. По его словам, Израиль присоединился к этому решению | LEDE: США отложили атаку на Иран по просьбе самой исламской республики и других стран Ближнего Восто] (ru: Тра…
      США отложили атаку на Иран по просьбе самой исламской республики и других стран Ближнего Востока, сообщил Дональд Трамп в соцсети Truth Social.
  - (2026-08-02) Украинские дроны вторую ночь подряд атаковали НПЗ «Башнефти» в Уфе | LEDE: Украинские беспилотники нанесли удар по нефтеперерабатывающему заводу «Башнефть-УНПЗ» в Уфе, пишет телеграм-канал A] (ru: Укр…
      Украинские беспилотники нанесли удар по нефтеперерабатывающему заводу «Башнефть-УНПЗ» в Уфе, пишет телеграм-канал Astra, изучивший фото и видео очевидцев.
  - (2026-08-02) Ресторан Balzi Rossi, где произошел взрыв, пообещал помочь семьям погибших. И извинился за пост, в котором говорилось, что в заведении «все в порядке» | LEDE: Ресторан Balzi Rossi на Кудринс] (ru: Рес…
      Ресторан Balzi Rossi на Кудринской площади, где накануне произошел взрыв, пообещал помочь семьям погибших (по официальным данным, их трое), говорится в посте заведения в инстаграме.
  - (2026-08-02) Российская армия терпит поражение за поражением, а правительство ищет внутренних врагов. Нет, это не 2026 год. Почитайте фрагмент книги Михаила Зыгаря «Империя должна умереть» о том, как Россия] (ru:…
      Первое издание книги «Империя должна умереть» журналиста и писателя Михаила Зыгаря вышло в 2017 году, к столетию двух русских революций — Февральской и Октябрьской. Спустя почти десять лет, в 2026 году, издательство «Мед…
  - (2026-08-02) Правительство Армении во главе с Пашиняном подало в отставку. Это формальная процедура после парламентских выборов (на них выиграла партия самого Пашиняна) | LEDE: Правительство Армении во г] (ru: Пра…
      Правительство Армении во главе с премьер-министром страны Николом Пашиняном подало в отставку. Видео, на котором Пашинян подписывает прошение об отставке, адресованное президенту республики, он сам опубликовал в своем те…
  - (2026-08-02) Еще один склад Wildberries атакован в Самарской области. Под Саратовом в результате удара украинских беспилотников погибли два человека | LEDE: Украинские беспилотники атаковали склад Wildbe] (ru: Еще…
      Украинские беспилотники атаковали склад Wildberries в Самарской области, сообщил глава региона Вячеслав Федорищев.

### Ukraine Theater (total-war monitoring) — 247 new of 793 total
  - (2026-08-02) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-01) [FIRMS] thermal anomaly 47.882, 33.401 (FRP 2.75 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 2.75 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.877, 33.408 (FRP 2.16 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 2.16 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.860, 33.444 (FRP 3.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 3.71 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.860, 33.451 (FRP 1.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 1.93 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.732, 34.859 (FRP 0.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 0.37 MW

### U.S. Weather + Severe / Climate Outlooks — 152 new of 162 total
  - (2026-08-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-02) [Severe] Flood Warning: Flood Warning issued August 2 at 4:04AM CDT until August 2 at 11:00AM CDT by NWS Chicago IL
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Southeastern Cook County in northeastern Illinois... Central Will County in northeastern Illinois... Northwestern Lake IN County in northwestern Indiana…
  - (2026-08-02) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued August 2 at 5:03AM EDT until August 2 at 9:00AM EDT by NWS Caribou ME
      * WHAT...Visibility of a quarter-mile or less in dense fog. * WHERE...Coastal Hancock, Coastal Washington, Central Washington, Interior Hancock, and Southern Penobscot Counties. * WHEN...Until 9 AM EDT this morning. * IM…
  - (2026-08-02) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 2 at 5:00AM EDT until August 2 at 8:00PM EDT by NWS Wilmington NC
      * WHAT...Strong south to north longshore current. There is also a Moderate Risk of rip currents expected. * WHERE...In North Carolina, Coastal Pender and Coastal New Hanover Counties. In South Carolina, Coastal Horry and…
  - (2026-08-02) [Moderate] Heat Advisory: Heat Advisory issued August 2 at 2:55AM MDT until August 3 at 9:00PM MDT by NWS Denver CO
      * WHAT...Temperatures of 98 to 104 on Sunday and 96 to 101 on Monday. * WHERE...Fort Collins, Boulder and the western suburbs of Denver, Denver, Castle Rock, Briggsdale, and Greeley. * WHEN...From noon today to 9 PM MDT…
  - (2026-08-02) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 2 at 1:38AM PDT until August 2 at 8:00PM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Hot daytime conditions with high temperatures between 95 and 105 common, except localized 105 to 110 in the hottest locations. Warm overnight conditions will bring less relief than usual. * WHERE...Most valleys…

### Chinese Internal News — 127 new of 259 total
  - (2026-08-02) 赤潮反复暴发 海南启动第三轮应急响应 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBLWk52b1NBT25iVWVCLXNUYVFLRlVBdXR5NkRGbWlibzNRYWlaYzFmMGRhRnZMQldYUzVBTGVNd3E2Z2Q4MWtHTFh6VExpZHVCd2d] (zh:…
      赤潮反复暴发 海南启动第三轮应急响应 财新
  - (2026-08-01) 视线｜极端高温致多瑙河水位跌破纪录 二战沉船与猛犸象化石接连露出 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1fZVRPYkh1OUVFVWx2R0lScDQ2czhTVjJWandkNk1mZlpCX2txQnE5QURnamxOTE5uMTF5WUhiYVBmZ3FCb19LV] (zh:…
      视线｜极端高温致多瑙河水位跌破纪录 二战沉船与猛犸象化石接连露出 财新
  - (2026-08-02) 江苏徐州一地试点集中供冷 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5rTHAxS2swOGNJTVRlRElIb05IWmJLVFo2UUVLQmZHSnEyc0xiamF3c0F6OHZMU1JTdm1Qb0J1bUc0RjZNYUgtVEN2enRDem1vSGJRRWxjc] (zh:…
      江苏徐州一地试点集中供冷 财新
  - (2026-08-02) 7月财新中国新经济指数微降至33.8 主要受资本投入下降影响 - economy.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFB4dHpXT293V1J0VjBKWkxjcGRkblNZVzlqZGZ5eUdpa3M4Qk9FRUZKdG9sNENPOEE5RDBrMHV] (zh:…
      7月财新中国新经济指数微降至33.8 主要受资本投入下降影响 economy.caixin.com
  - (2026-08-02) 不要轻易介入他人的因果，不要干涉与背负他人的命运｜活着，有那么好吗？③ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE04NzRQWTJKaGxQZ2M5SE9wdVJqNThsLVgxQ1JmbE1ka0hZa1lueHgxLTJHWUtUSlc1LW5ZM3N5QzZHVkZqTE] (zh:…
      不要轻易介入他人的因果，不要干涉与背负他人的命运｜活着，有那么好吗？③ 财新
  - (2026-07-31) 离岸信托全周期征税“定音” 90天内存量信托如何申报补税？ - economy.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1sX2VFcHZOZEtxbnJMbkhRUUtxblhBTXZiRUxRWGFYcVU0bFFfdG8yeDJLdGE2cDZDRnJOb19V] (zh:…
      离岸信托全周期征税“定音” 90天内存量信托如何申报补税？ economy.caixin.com

### State Legislative Action — 87 new of 178 total
  - (2026-07-31) [District of Columbia B 26-0734] Special Education for Young Adults in the Custody of the Department of Corrections Emergency Amendment Act of 2026
      Special Education for Young Adults in the Custody of the Department of Corrections Emergency Amendment Act of 2026
  - (2026-07-31) [District of Columbia B 26-0736] Strengthening Probate Administration Congressional Review Emergency Amendment Act of 2026
      Strengthening Probate Administration Congressional Review Emergency Amendment Act of 2026
  - (2026-07-31) [District of Columbia B 26-0737] Certified Business Enterprise Program Compliance and Enforcement Support Congressional Review Emergency Amendment Act of 2026
      Certified Business Enterprise Program Compliance and Enforcement Support Congressional Review Emergency Amendment Act of 2026
  - (2026-07-31) [District of Columbia B 26-0732] Prearrest Diversion Task Force Recommendations Emergency Amendment Act of 2026
      Prearrest Diversion Task Force Recommendations Emergency Amendment Act of 2026
  - (2026-07-31) [District of Columbia B 26-0759] Medical Cannabis Licensing and Unlicensed Establishment Enforcement Clarification Emergency Amendment Act of 2026
      Medical Cannabis Licensing and Unlicensed Establishment Enforcement Clarification Emergency Amendment Act of 2026
  - (2026-07-31) [District of Columbia B 26-0701] Modification Nos. M0008 and M0009 to Contract No. CW113639 with Safeware, Inc. Approval and Payment Authorization Emergency Act of 2026
      Modification Nos. M0008 and M0009 to Contract No. CW113639 with Safeware, Inc. Approval and Payment Authorization Emergency Act of 2026

### State-Level News — 62 new of 447 total
  - (2026-08-02) [Connecticut] Lamont’s fiscal success rests on foundation laid by Malloy, others
      <img width="1024" height="769" src="https://ctmirror.org/wp-content/uploads/2018/11/CTJH107.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high" srcset="ht…
  - (2026-08-02) [Connecticut] CT’s $1.6 billion railroad promise
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/caternary-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcse…
  - (2026-08-02) [Alaska] Farmers Market Week 2026
      WHEREAS, the United States Department of Agriculture (USDA) proclaimed the first National Farmers Market Week in 1999 to raise awareness of efforts nationwide for producers to sell directly to customers; and WHEREAS, a f…
  - (2026-08-02) [Alaska] Community Health Center Week 2026
      WHEREAS, for over fifty years, community health centers have delivered accessible and affordable healthcare to underserved and uninsured members of communities across the Nation; and WHEREAS, a community health center’s…
  - (2026-08-02) [Idaho] Prosecutors drop vandalism charges for Reflecting Pool damage, blame ‘contractor error’
      WASHINGTON — U.S. Attorney for the District of Columbia Jeanine Pirro moved Friday to dismiss charges against a former Olympian canoeist alleged to have damaged part of the Lincoln Memorial Reflecting Pool. Pirro had cha…
  - (2026-08-02) [Idaho] 3 dead, 2 injured in Twin Falls In-N-Out shooting
      This story was first published by Boise State Public Radio on Aug. 1, 2026. Three people are dead and two are injured after a shooting Saturday afternoon at the Twin Falls In-N-Out, according to a city spokesperson. Josh…

### Local News: St. Louis + Atlanta — 62 new of 212 total
  - (2026-08-02) [St. Louis] East St. Louis community calls for peace after mass shooting
      East St. Louis community members held a prayer vigil Saturday in memory of five family members killed in a mass shooting last month.
  - (2026-08-02) [St. Louis] Ferguson community rebuilds memorial for Michael Brown Jr.
      Community members gathered Saturday evening in Ferguson to rebuild a memorial in memory of Michael Brown Jr.
  - (2026-08-02) [St. Louis] St. Louis CITY SC plays Real Salt Lake to 1-1 draw
      Marcel Hartel scored in the 72nd minute and St. Louis played Real Salt Lake to a 1-1 draw on Saturday night.
  - (2026-08-01) [St. Louis] Person killed in north St. Louis crash Saturday afternoon
      One person was killed in a north St. Louis crash Saturday afternoon, police say.
  - (2026-08-02) [St. Louis] Did anyone win the Powerball? Winning numbers for Saturday, August 1, 2026
      An estimated $707 million was on the line in Saturday night's Powerball drawing.
  - (2026-08-02) [St. Louis] NBA's Malachi Smith hosts youth basketball camp, back-to-school drive at Belleville West
      The guard averaged 8.3 points, 3.4 rebounds, and 3.3 assists per game last season.

### Ukrainian Internal News (national + local Kyiv) — 33 new of 115 total
  - (2026-08-02) Зеленський: Росія нарощує виробництво балістики | LEDE: За тиждень РФ атакувала 16 регіонів України, застосувавши 1900 дронів, 1600 авіабомб і 144 ракети.] (uk: Зеленський: Росія нарощує виробництво б…
      За тиждень РФ атакувала 16 регіонів України, застосувавши 1900 дронів, 1600 авіабомб і 144 ракети.
  - (2026-08-02) Генштаб підтвердив ураження Саратовського НПЗ, аеродрому "Енгельс" та нафтобази | LEDE: У ніч на 2 серпня Сили оборони України уразили Саратовський нафтопереробний завод, аеродром "Енгельс", на] (uk:…
      У ніч на 2 серпня Сили оборони України уразили Саратовський нафтопереробний завод, аеродром "Енгельс", нафтобазу в Калузькій області та низку інших російських військових об'єктів.
  - (2026-08-02) Литва придбає технології для виявлення тунелів нелегальних мігрантів | LEDE: ] (uk: Литва придбає технології для виявлення тунелів нелегальних мігрантів)
  - (2026-08-02) Уряд Пашиняна у Вірменії подав у відставку | LEDE: ] (uk: Уряд Пашиняна у Вірменії подав у відставку)
  - (2026-08-02) Алім Алієв: ким є кримські татари і як вони говорять зі світом | LEDE: ] (uk: Алім Алієв: ким є кримські татари і як вони говорять зі світом)
  - (2026-08-02) Наші поміж. Bizimkiler | LEDE: Фестиваль "Кримський інжир" та нова антологія розкривають унікальну історію і голос кримських татар.] (uk: Наші поміж. Bizimkiler)
      Фестиваль "Кримський інжир" та нова антологія розкривають унікальну історію і голос кримських татар.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-02) [Russia oil sanctions perimeter · keywords] Ukraine - Russia war latest : At least three dead after bomb explodes near Moscow restaurant
      independent.co.uk · English · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · keywords] Ukraine and Gulf conflicts increasingly intertwined , says Russia - Iran analyst
      lrt.lt · English · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · keywords] Oil leak spreads from a sanctioned tanker grounded off Oman , images show
      pressdemocrat.com · English · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · keywords] Oil leak spreads from sanctioned tanker grounded off Oman coast
      economictimes.indiatimes.com · English · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · keywords] Oil leak spreads from a sanctioned tanker grounded off Oman , images show
      niagarafallsreview.ca · English · tone NA
  - (2026-08-02) [Russia oil sanctions perimeter · keywords] Oil leak spreads from a sanctioned tanker grounded off Oman , images show
      abcnews.com · English · tone NA

### Government & military aircraft airborne (OpenSky) — 25 new of 25 total
  - (2026-08-02) SAMU05 (France)
      icao24: 39ca81 · position: (44.6076, 6.4031) · alt: 2484m · 234km/h
  - (2026-08-02) JAF99Y (Belgium)
      icao24: 44d1ba · position: (42.3805, -5.1916) · alt: 11582m · 917km/h
  - (2026-08-02) JAF3LV (Belgium)
      icao24: 44d1a6 · position: (36.1875, 9.9965) · alt: 11452m · 874km/h
  - (2026-08-02) JAF3KT (Belgium)
      icao24: 44d1a7 · position: (40.9221, 1.7835) · alt: 10797m · 788km/h
  - (2026-08-02) JAF7CB (Belgium)
      icao24: 44d1b3 · position: (45.0584, -0.9092) · alt: 10363m · 846km/h
  - (2026-08-02) JAF66L (Belgium)
      icao24: 44d1b4 · position: (45.9535, 0.8522) · alt: 10972m · 837km/h

### World News (by country, top stories) — 24 new of 24 total
  - (2026-08-02) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-08-02) [China] Why Chengdu restaurant Co was city first to make the Asia 50 Best list
      scmp.com · English
  - (2026-08-02) [China] CUHK earmarks Pak Shek Kok site for new medical building and 10th college
      scmp.com · English
  - (2026-08-02) [China] Equestrian performance event featuring traditional horse - riding skills held in Sichuan , SW China
      globaltimes.cn · English
  - (2026-08-02) [China] Freelander sets 300 , 000 unit annual ambition ahead of Freelander 8 pre - sales on August 10
      carnewschina.com · English
  - (2026-08-02) [China] China : UN a solid platform for AI cooperation
      global.chinadaily.com.cn · English

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-02) LoL: ThunderTalk Gaming vs Team WE (BO3) - LPL Group Ascend
      yes price: 10% · 24h volume: $1,065,080 · resolves 2026-08-02
  - (2026-08-02) LoL: ThunderTalk Gaming vs Team WE - Game 1 Winner
      yes price: 100% · 24h volume: $1,001,686 · resolves 2026-08-02
  - (2026-08-02) LoL: ThunderTalk Gaming vs Team WE - Game 2 Winner
      yes price: 0% · 24h volume: $898,184 · resolves 2026-08-02
  - (2026-08-02) LoL: DN SOOPers vs HANJIN BRION - Game 1 Winner
      yes price: 100% · 24h volume: $725,344 · resolves 2026-08-02
  - (2026-08-02) Strait of Hormuz traffic returns to normal by August 31?
      yes price: 12% · 24h volume: $700,007 · resolves 2026-08-31
  - (2026-08-02) Strait of Hormuz traffic returns to normal by August 15?
      yes price: 3% · 24h volume: $384,602 · resolves 2026-08-15

### Paper Trading Scorecard — 9 new of 121 total
  - (2026-08-02) [Polymarket] Will the Democrats win the Michigan Senate race in 2026?
      This market will resolve according to the winner of the 2026 midterm Michigan U.S. Senate election, inclusive of any run-offs. A candidate shall be considered to represent a party in the event that he or she is the nomin…
  - (2026-08-02) [Polymarket] Mitch McConnell steps down from Senate before his term ends?
      This market will resolve to “Yes” if Mitch McConnell formally announces an intention to step down or otherwise vacates his U.S. Senate seat before his current term is scheduled to end (January 3, 2027, 11:59 PM ET). Othe…
  - (2026-08-02) [Manifold] Will Abdul El Sayed and Francesca Hong both win their primaries?
  - (2026-08-02) [Manifold] Will my transfer of major get accepted?
  - (2026-08-02) [Manifold] Will Astra solve Elliot Glazer's prototype FrontierMath problem?
  - (2026-08-02) [Manifold] Free Lottery (singularity strength)

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 102 total
  - (2026-08-02) [USASpending] $42,257,183,759 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-08-02) [USASpending] $41,316,801,718 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-02) [USASpending] $26,286,482,128 → BATTELLE ENERGY ALLIANCE, LLC: MANAGEMENT AND OPERATIONS OF THE INL
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATIONS OF THE INL
  - (2026-08-02) [USASpending] $3,500,000,000 → DAVIE DEFENSE INC.: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF F
      Agency: Department of Homeland Security. Description: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF FIVE (5) EACH MULTI-PURPOSE POLAR SHIP (MPPS-100) VESSELS HEREAFTER REFERRED TO AS ARCTIC SECURITY CUTTERS…
  - (2026-08-02) [USASpending] $3,373,486,394 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…
  - (2026-08-02) [USASpending] $2,533,722,927 → UNITED CLEANUP OAK RIDGE LLC: OAK RIDGE RESERVATION CLEANUP CONTRACT TASK ORDERS
      Agency: Department of Energy. Description: OAK RIDGE RESERVATION CLEANUP CONTRACT TASK ORDERS

### USGS earthquakes (M4.5+, past day) — 8 new of 16 total
  - (2026-08-02) M 5.6 - 14 km S of Hicks Bay, New Zealand
      M5.6 · 14 km S of Hicks Bay, New Zealand · depth 52.806 km
  - (2026-08-02) M 5.2 - 112 km SW of Severo-Kuril’sk, Russia
      M5.2 · 112 km SW of Severo-Kuril’sk, Russia · depth 80.691 km
  - (2026-08-02) M 4.9 - 149 km S of Severo-Kuril’sk, Russia
      M4.9 · 149 km S of Severo-Kuril’sk, Russia · depth 33.834 km
  - (2026-08-02) M 4.9 - 36 km SSW of Mendi, Papua New Guinea
      M4.9 · 36 km SSW of Mendi, Papua New Guinea · depth 10 km
  - (2026-08-02) M 4.8 - 77 km SE of Atka, Alaska
      M4.8 · 77 km SE of Atka, Alaska · depth 44.288 km
  - (2026-08-02) M 4.8 - 64 km ENE of Noda, Japan
      M4.8 · 64 km ENE of Noda, Japan · depth 56.352 km

### Court opinions of consequence (federal & state) — 7 new of 60 total
  - (2026-07-29) U.S. Court of International Trade: Ningxia Guanghua Cherishmet Activated Carbon Co. v. United States
  - (2026-07-29) U.S. Court of International Trade: Tube Forgings of Am., Inc. v. United States
  - (2026-07-29) U.S. Court of Appeals, 9th Cir.: Serenity Investments, LLC v. Sun Hung Kai Strategic Capital, Ltd.
  - (2026-07-29) U.S. Court of Appeals, 9th Cir.: United States v. Yates
  - (2026-07-29) U.S. Court of Appeals, 2nd Cir.: Civil Rights Corps v. LaSalle
  - (2026-07-29) U.S. Court of Appeals, 2nd Cir.: Ohindo v. Ball

### IT, InfoSys & cybersecurity news (last 7 days) — 5 new of 57 total
  - (2026-08-02) [The Register] Meet the 'internet radical' who helped Microsoft get email and AT&T get online
      Tom Evslin on Bill Gates, the birth of Exchange, and dragging Ma Bell onto the web
  - (2026-08-01) [The Register] Unexpected item in the bagging area as Windows Activation error pops up at check-in
      Bags weighed down by a Microsoft license key
  - (2026-08-01) [The Register] A deep dive into Nvidia's Vera CPU and the Olympus cores that power it
      88 custom cores, 176 funky threads, 1.5 TB of laptop RAM, and 1.8 TB/s of NVLink connectivity — this isn't your typical datacenter chip
  - (2026-08-01) [The Register] Enterprise cloud infrastructure uptake shows no sign of slowing
      Cloud revenue now north of $143 billion a quarter, and growth is accelerating
  - (2026-07-31) [The Register] Dev who gave HashiCorp its name returns with a faster terminal multiplexer
      Persistent sessions could be just the beginning

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-02) [Marginal Revolution] Taiwan fact of the day
      [Annualized] 14% GDP growth in the first half of 2026 The post Taiwan fact of the day appeared first on Marginal REVOLUTION.
  - (2026-08-02) [Marginal Revolution] Mexico (Taiwan) fact of the day
      Mexico has quietly become a cornerstone of the AI boom, providing 40 per cent of US imports this year of the computer servers that are widely used in the data centres powering artificial intelligence. Taiwanese manufactu…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: requires, order, certain, proposing, program, issued, final, amend, standard, proposes, action, taking
- state_bills: today=178, 7d-median=152, 14d-median=152; carrying terms: commission, office, requires, required, violation, rights, administration, certain, defines, right, increase, digital
- state_news: today=447, 7d-median=758, 14d-median=626; carrying terms: leaving, closer, weigh, sought, incarcerated, night, evening, evidence, cities, young, commission, requires
- local_news: today=212, 7d-median=228, 14d-median=222; carrying terms: evening, night, scaled, office, stlmag, close, metro, being, murder, children, several, attachment
- foreign_news: today=935, 7d-median=1022, 14d-median=1014; carrying terms: looks, closer, pledged, evidence, cities, philippines, marked, southeast, commission, discourage, steps, engines
- chinese_internal: today=259, 7d-median=262, 14d-median=264; carrying terms: record, firms, people, china, https, google, profit, chinese, caixin, office, investment, stock
- russian_internal: today=856, 7d-median=916, 14d-median=898; carrying terms: found, instagram, times, bloomberg, title, axios, russian, wildberries, reuters, centcom, gazeta, press
- ukrainian_internal: today=115, 7d-median=133, 14d-median=134; carrying terms: civilians, threat, censor, office, entered, launchers, saying, washington, update, snapshot, shortages, peace
- ukraine_theater: today=793, 7d-median=647, 14d-median=637; carrying terms: unauthorized, firms, known, cartography, acquired, daily, liveuamap, token, deepstatemap, client, httperror, snapshot
- paper_bets: today=121, 7d-median=134, 14d-median=134; carrying terms: kalshi, successor, change, johnny, california, office, mayfield, midterm, levels, qualify, netanyahu, determined
- weather: today=162, 7d-median=173, 14d-median=173; carrying terms: threat, below, evening, night, norton, portions, southeast, warning, further, watch, southwest, inland
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: labor, sheet, total, recession, dexjpus, headline, inflation, unemployment, walcl, implied, energy, crude
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, natural, silver, futures, russell, equities, bitcoin, commodities, crude, agriculture, range, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=102, 7d-median=104, 14d-median=108; carrying terms: hamas, islamic, innovation, violations, entities, support, daesh, congo, battelle, jihad, campaign, burundi
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quantitative, https, httperror, quiverquant, client, congresstrading, error, quiver
- billionaires: today=30, 7d-median=37, 14d-median=36; carrying terms: gautam, adani, ortega, spain, family, buffett, discount, ballmer, bloomberg, holdings, cryptocurrency, tesla
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, texas, supreme, johnson, arizona, court, services, jones, delaware, appeals, trade, technologies
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, holdings, robert, amended, steven
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, elect, pinkston, platner, house, robert, booker, raised, cycle, ossoff, sherrod, lindsey
- gdelt_regions: today=24, 7d-median=12, 14d-median=12; carrying terms: english, japan, strikes, china, world, korea
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, keywords, strikes, russian, attacks, russia, nuclear, black, drone
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=25, 7d-median=18, 14d-median=17; carrying terms: belgium, position, ground, france, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: contamination, series, declaration, symptoms, recent, support, circulation, outbreak, fifth, cluster, separated, congo
- cisa_kev: today=9, 7d-median=12, 14d-median=13; carrying terms: authentication, remediation, deserialization, overflow, control, point, untrusted, management, injection, product, smartconsole, based
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=296, 14d-median=296; carrying terms: spain, denmark, thailand, typhoon, depth, forestfire, madagascar, austria, brazil, ethiopia, marino, congo
- usgs_quakes: today=16, 7d-median=20, 14d-median=18; carrying terms: depth, region, islands, japan, south, indonesia, papua, russia, guinea, abepura
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, prime, resolves, price, august, strait, hormuz, traffic, normal, returns, ceasefire, effective
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: become, economist, conversable, having, college, golden, revolution, certain, conversableeconomist, students, marginal, doctor
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: threat, networks, scope, research, vulnerability, being, techcrunch, government, record, linux, appeared, schneier
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: landsman, susie, dwight, trent, tonko, lankford, howard, hamadeh, ciscomani, young, martin, bradley
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, market, markets, placement, claude, evidence, paper, converges, consensus, placed, sufficient, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*