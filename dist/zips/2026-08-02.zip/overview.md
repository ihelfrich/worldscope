# WORLDSCOPE morning brief — 2026-08-02

## Headline
1839 new items across 19 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (383) · Russian Internal News (state + in-exile) (331) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (294) · U.S. Weather + Severe / Climate Outlooks (149) · Chinese Internal News (93) · State-Level News (63) · Local News: St. Louis + Atlanta (56) · Ukrainian Internal News (national + local Kyiv) (34) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (29) · Prediction Markets — most-traded (Polymarket) (12)

## What changed today
### International News + Multilateral Institutions — 383 new of 962 total
  - (2026-08-02) [Global] Trump cancels Iran strikes subject to deal being made 'rapidly'
      The US president claims Iran and other Middle Eastern countries asked Washington to hold off on any attack as the "perimeters" of a deal had been agreed.
  - (2026-08-02) [Global] How Spain's migrant crisis created a political storm - whipped up by social media
      The Ceuta crossings have shaken Europe politically, exposing divisions over the sensitive issue of migration, the BBC's Sarah Rainsford writes.
  - (2026-08-01) [Global] A bruising 24 hours - what next for Fifa and under-pressure Infantino?
      Pressure is building on Gianni Infantino. Can he survive as Fifa president after the implosion of the controversial World Cup investment plan?
  - (2026-08-01) [Global] How Australia combines modern tech and Indigenous knowledge to fight wildfires
      As Europe faces its worst wildfires in decades, Australia offers lessons in disaster preparedness.
  - (2026-08-01) [Global] Solitude as a new aspirational lifestyle: 'We are not lonely'
      A growing number of what the internet has dubbed "loneliness influencers" are spotlighting solo living without children or friends - and it's spurring debate.
  - (2026-08-02) [Global] Parents save on school uniforms at city swap shop
      Parents take home school uniform for free at a pop-up that organisers hope can become a regular event.

### Russian Internal News (state + in-exile) — 331 new of 859 total
  - (2026-08-02) Трамп вновь отложил атаку на Иран. По его словам, Израиль присоединился к этому решению | LEDE: США отложили атаку на Иран по просьбе самой исламской республики и других стран Ближнего Восто] (ru: Тра…
      США отложили атаку на Иран по просьбе самой исламской республики и других стран Ближнего Востока, сообщил Дональд Трамп в соцсети Truth Social.
  - (2026-08-02) Украинские дроны вторую ночь подряд атаковали НПЗ «Башнефти» в Уфе | LEDE: Украинские беспилотники нанесли удар по нефтеперерабатывающему заводу «Башнефть-УНПЗ» в Уфе, пишет телеграм-канал A] (ru: Укр…
      Украинские беспилотники нанесли удар по нефтеперерабатывающему заводу «Башнефть-УНПЗ» в Уфе, пишет телеграм-канал Astra, изучивший фото и видео очевидцев.
  - (2026-08-02) Ресторан Balzi Rossi, где произошел взрыв, пообещал помочь семьям погибших. И извинился за пост, в котором говорилось, что в заведении «все в порядке» | LEDE: Ресторан Balzi Rossi на Кудринс] (ru: Рес…
      Ресторан Balzi Rossi на Кудринской площади, где накануне произошел взрыв, пообещал помочь семьям погибших (по официальным данным, их трое), говорится в посте заведения в инстаграме.
  - (2026-08-02) Российская армия терпит поражение за поражением, а правительство ищет внутренних врагов. Нет, это не 2026 год. Почитайте фрагмент книги Михаила Зыгаря «Империя должна умереть» о том, как Россия] (ru:…
      Первое издание книги «Империя должна умереть» журналиста и писателя Михаила Зыгаря вышло в 2017 году, к столетию двух русских революций — Февральской и Октябрьской. Спустя почти десять лет, в 2026 году, издательство «Мед…
  - (2026-08-02) Правительство Армении во главе с Пашиняном подало в отставку. Это формальная процедура после парламентских выборов (на них выиграла партия самого Пашиняна) | LEDE: Правительство Армении во г] (ru: Пра…
      Правительство Армении во главе с премьер-министром страны Николом Пашиняном подало в отставку. Видео, на котором Пашинян подписывает прошение об отставке, адресованное президенту республики, он сам опубликовал в своем те…
  - (2026-08-02) Еще один склад Wildberries атакован в Самарской области. Под Саратовом в результате удара украинских беспилотников погибли два человека | LEDE: Украинские беспилотники атаковали склад Wildbe] (ru: Еще…
      Украинские беспилотники атаковали склад Wildberries в Самарской области, сообщил глава региона Вячеслав Федорищев.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 294 new of 793 total
  - (2026-08-02) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-31) [Liveuamap] Number of wounded as result of Russian airstrike in Kherson increased to 4 - liveuamap.com
      Number of wounded as result of Russian airstrike in Kherson increased to 4 liveuamap.com</f
  - (2026-08-01) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap
  - (2026-08-02) [Liveuamap] A ship was targeted and explosions occurred 21 nautical miles northeast of Khasab, Oman. Strait of Hormuz - Liveuamap
      A ship was targeted and explosions occurred 21 nautical miles northeast of Khasab, Oman. Strait of Hormuz
  - (2026-08-02) [Liveuamap] Drones have attacked oil refinery in Ufa Ufa, Bashkiriya - Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com
      Drones have attacked oil refinery in Ufa Ufa, Bashkiriya - Ukraine Interactive map - Ukraine Latest news on live map <font co
  - (2026-08-01) [Liveuamap] Smoke is rising after explosions in Zaporizhzhia - liveuamap.com
      Smoke is rising after explosions in Zaporizhzhia liveuamap.com

### U.S. Weather + Severe / Climate Outlooks — 149 new of 159 total
  - (2026-08-02) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 2 at 2:41AM MST until August 3 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with temperatures 101 to 106 in Santa Cruz and Cochise counties and 107 to 112 elsewhere. Major to Extreme HeatRisk is expected. * WHERE...Eastern Cochise County below 5000 feet, South…
  - (2026-08-02) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 2 at 5:38AM EDT until August 3 at 8:00AM EDT by NWS Northern Indiana
      * WHAT...Dangerous swimming conditions expected. *Waves: 2 to 5 feet this morning building to 4 to 7 feet this afternoon and evening. Highest waves, especially this morning are expected from Michigan City, IN to New Buff…
  - (2026-08-02) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 2 at 5:38AM EDT until August 3 at 8:00AM EDT by NWS Northern Indiana
      * WHAT...Dangerous swimming conditions expected. *Waves: Waves 2 to 3 feet building to 3 to 5 feet by late this afternoon and evening. *Longshore Current: Expected. Moving from north to south along the beach. *Structural…
  - (2026-08-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-02) [Moderate] Gale Warning: Gale Warning issued August 2 at 2:35AM PDT until August 3 at 3:00AM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 20 to 30 kt with gusts up to 40 kt and seas 10 to 14 ft. * WHERE...Waters from Point Reyes to Pigeon Point 10-60 NM. * WHEN...Until 3 AM PDT Monday. * IMPACTS...Strong winds will cause hazardous…
  - (2026-08-02) [Moderate] Gale Warning: Gale Warning issued August 2 at 2:35AM PDT until August 2 at 9:00PM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 20 to 30 kt with gusts up to 35 kt and seas 8 to 11 ft. * WHERE...Coastal Waters from Point Arena to Point Reyes California out to 10 NM. * WHEN...Until 9 PM PDT this evening. * IMPACTS...Strong…

### Chinese Internal News — 93 new of 259 total
  - (2026-08-02) 赤潮反复暴发 海南启动第三轮应急响应 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBLWk52b1NBT25iVWVCLXNUYVFLRlVBdXR5NkRGbWlibzNRYWlaYzFmMGRhRnZMQldYUzVBTGVNd3E2Z2Q4MWtHTFh6VExpZHVCd2d] (zh:…
      赤潮反复暴发 海南启动第三轮应急响应 财新
  - (2026-08-01) 视线｜极端高温致多瑙河水位跌破纪录 二战沉船与猛犸象化石接连露出 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1fZVRPYkh1OUVFVWx2R0lScDQ2czhTVjJWandkNk1mZlpCX2txQnE5QURnamxOTE5uMTF5WUhiYVBmZ3FCb19LV] (zh:…
      视线｜极端高温致多瑙河水位跌破纪录 二战沉船与猛犸象化石接连露出 财新
  - (2026-08-02) 江苏徐州一地试点集中供冷 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5rTHAxS2swOGNJTVRlRElIb05IWmJLVFo2UUVLQmZHSnEyc0xiamF3c0F6OHZMU1JTdm1Qb0J1bUc0RjZNYUgtVEN2enRDem1vSGJRRWxjc] (zh:…
      江苏徐州一地试点集中供冷 财新
  - (2026-08-02) 7月财新中国新经济指数微降至33.8 主要受资本投入下降影响 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFB4dHpXT293V1J0VjBKWkxjcGRkblNZVzlqZGZ5eUdpa3M4Qk9FRUZKdG9sNENPOEE5RDBrMHVVRE5ISHJ6YjFRVWR] (zh:…
      7月财新中国新经济指数微降至33.8 主要受资本投入下降影响 财新
  - (2026-08-02) 不要轻易介入他人的因果，不要干涉与背负他人的命运｜活着，有那么好吗？③ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE04NzRQWTJKaGxQZ2M5SE9wdVJqNThsLVgxQ1JmbE1ka0hZa1lueHgxLTJHWUtUSlc1LW5ZM3N5QzZHVkZqTE] (zh:…
      不要轻易介入他人的因果，不要干涉与背负他人的命运｜活着，有那么好吗？③ 财新
  - (2026-07-31) 为保障稀土供应多元化 日本将在非洲投资首个稀土项目 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZ0FVX3lxTFBXWHFlQTY1NGVPUE9MLURMc0xYUGNSaXowQnlFMk4tVXA1dmNqNlp3VTZpUGZ3S0N0T0tVWTR1bFk5X3dIa3g1Nm56SHRD] (zh:…
      为保障稀土供应多元化 日本将在非洲投资首个稀土项目 财新

### State-Level News — 63 new of 449 total
  - (2026-08-02) [Alaska] Farmers Market Week 2026
      WHEREAS, the United States Department of Agriculture (USDA) proclaimed the first National Farmers Market Week in 1999 to raise awareness of efforts nationwide for producers to sell directly to customers; and WHEREAS, a f…
  - (2026-08-02) [Alaska] Community Health Center Week 2026
      WHEREAS, for over fifty years, community health centers have delivered accessible and affordable healthcare to underserved and uninsured members of communities across the Nation; and WHEREAS, a community health center’s…
  - (2026-08-02) [Connecticut] Lamont’s fiscal success rests on foundation laid by Malloy, others
      <img width="1024" height="769" src="https://ctmirror.org/wp-content/uploads/2018/11/CTJH107.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high" srcset="ht…
  - (2026-08-02) [Connecticut] CT’s $1.6 billion railroad promise
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/caternary-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcse…
  - (2026-08-02) [Maine] Troy Jackson strikes a winning pose | Letter
      <img width="1024" height="794" src="https://www.pressherald.com/wp-content/uploads/sites/4/2026/07/43712554_20260725_17dems_.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding…
  - (2026-08-02) [Maine] ICE must not be shielded from accountability | Letter
      A letter to the editor by Duane Dumont of Leeds raises some real concerns (“I blame the Democrats and the media for ICE killing,” July 24) , but pointing fingers at the media or local officials skips over something prett…

### Local News: St. Louis + Atlanta — 56 new of 223 total
  - (2026-08-02) [St. Louis] Did anyone win the Powerball? Winning numbers for Saturday, August 1, 2026
      An estimated $707 million was on the line in Saturday night's Powerball drawing.
  - (2026-08-02) [St. Louis] 1 person dead following crash in north St. Louis
      Police are advising drivers to avoid the area.
  - (2026-08-02) [St. Louis] NBA's Malachi Smith hosts youth basketball camp, back-to-school drive at Belleville West
      The guard averaged 8.3 points, 3.4 rebounds, and 3.3 assists per game last season.
  - (2026-08-02) [St. Louis] Man charged in connection with shooting that killed teen near McDonald's in Cahokia Heights
      Cleveland Ware, 20, was booked into the St. Clair County Jail Friday evening.
  - (2026-08-02) [St. Louis] Trump says he will order halt to Iran strikes after parameters reached for deal to end war
      U.S. President Donald Trump has threatened more strikes on Iran as the U.S. pushes to reopen the Strait of Hormuz.
  - (2026-08-02) [St. Louis] 12 years later, Michael Brown Jr.’s family turns pain into purpose with annual Legacy Week
      More than a decade after Michael Brown Jr.’s death, his family launched Legacy Week to remember his legacy and unify a grieving community.

### Ukrainian Internal News (national + local Kyiv) — 34 new of 116 total
  - (2026-08-02) General Staff Confirms Strikes on Engels Airbase and Saratov Refinery
      The General Staff of the Armed Forces of Ukraine confirmed that defense forces struck the Engels strategic airfield and the Saratov oil refinery in Russia early Sunday, Aug. 2. The military noted that the Engels base hou…
  - (2026-08-02) Ukrainian Drones Destroy 8 Russian Radar and Air Defense Sites
      The 1st Separate Center of the Unmanned Systems Forces (USF) of Ukraine reported executing pinpoint strikes more than 270 kilometers deep into the Russian Krasnodar Krai, destroying eight critical aerial surveillance and…
  - (2026-08-02) Air Defenses Downed 445,000 Russian Targets Since 2022
      Acting Defense Minister Evgeniy Khmara stated on Ukraine’s Air Force Day that air defense units have intercepted over 445,000 Russian aerial targets since February 2022, including cruise and ballistic missiles, and drone…
  - (2026-08-02) US Pauses Planned Strikes on Iran Amid Deal Talks
      US President Donald Trump announced the suspension of a planned 10-to-14-day military campaign against Iran following requests from Tehran and regional states to rapidly negotiate a deal. Trump stated that the agreement…
  - (2026-08-02) Ukraine Deploys Firefighters to France Amid EU Wildfires
      Ukraine has dispatched firefighters to France for the first time under the EU Civil Protection Mechanism to help combat large-scale wildfires raging near Bordeaux. European Commission President Ursula von der Leyen highl…
  - (2026-08-02) Drones Strike Saratov Refinery and Samara Wildberries Hub
      Ukrainian drones struck a major oil refinery in Saratov and a Wildberries logistics center in the Samara region early Sunday, Aug. 2. The Saratov strike sparked a large fire, marking the 15th attack on the facility, whic…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-02) RFF07 (Portugal)
      icao24: 496ca7 · position: (37.013, -7.966) · on ground · 25km/h
  - (2026-08-02) JAF99Y (Belgium)
      icao24: 44d1ba · position: (46.4432, -1.7275) · alt: 11582m · 906km/h
  - (2026-08-02) JAF3LV (Belgium)
      icao24: 44d1a6 · position: (40.6739, 9.2787) · alt: 12192m · 887km/h
  - (2026-08-02) JAF3KT (Belgium)
      icao24: 44d1a7 · position: (45.176, 1.1338) · alt: 10972m · 840km/h
  - (2026-08-02) JAF7CB (Belgium)
      icao24: 44d1b3 · position: (49.1052, 1.9825) · alt: 10363m · 885km/h
  - (2026-08-02) JAF66L (Belgium)
      icao24: 44d1b4 · position: (50.0238, 2.7989) · alt: 7178m · 797km/h

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-02) LoL: ThunderTalk Gaming vs Team WE (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $2,247,155 · resolves 2026-08-02
  - (2026-08-02) LoL: ThunderTalk Gaming vs Team WE - Game 2 Winner
      yes price: 0% · 24h volume: $1,013,151 · resolves 2026-08-02
  - (2026-08-02) LoL: ThunderTalk Gaming vs Team WE - Game 1 Winner
      yes price: 100% · 24h volume: $1,008,890 · resolves 2026-08-02
  - (2026-08-02) LoL: DN SOOPers vs HANJIN BRION - Game 2 Winner
      yes price: 0% · 24h volume: $836,835 · resolves 2026-08-02
  - (2026-08-02) LoL: DN SOOPers vs HANJIN BRION - Game 1 Winner
      yes price: 100% · 24h volume: $775,705 · resolves 2026-08-02
  - (2026-08-02) Strait of Hormuz traffic returns to normal by August 31?
      yes price: 12% · 24h volume: $700,608 · resolves 2026-08-31

### Paper Trading Scorecard — 10 new of 122 total
  - (2026-08-02) [Polymarket] Will the Democrats win the Michigan Senate race in 2026?
      This market will resolve according to the winner of the 2026 midterm Michigan U.S. Senate election, inclusive of any run-offs. A candidate shall be considered to represent a party in the event that he or she is the nomin…
  - (2026-08-02) [Polymarket] Mitch McConnell steps down from Senate before his term ends?
      This market will resolve to “Yes” if Mitch McConnell formally announces an intention to step down or otherwise vacates his U.S. Senate seat before his current term is scheduled to end (January 3, 2027, 11:59 PM ET). Othe…
  - (2026-08-02) [Manifold] Will Substack implement an automatic AI-generated-content filter by EoY 2026?
  - (2026-08-02) [Manifold] Will Abdul El Sayed and Francesca Hong both win their primaries?
  - (2026-08-02) [Manifold] Will my transfer of major get accepted?
  - (2026-08-02) [Manifold] Will Astra solve Elliot Glazer's prototype FrontierMath problem?

### USGS earthquakes (M4.5+, past day) — 10 new of 18 total
  - (2026-08-02) M 5.6 - 14 km S of Hicks Bay, New Zealand
      M5.6 · 14 km S of Hicks Bay, New Zealand · depth 52.806 km
  - (2026-08-02) M 5.2 - 112 km SW of Severo-Kuril’sk, Russia
      M5.2 · 112 km SW of Severo-Kuril’sk, Russia · depth 80.691 km
  - (2026-08-02) M 5.0 - north of Ascension Island
      M5.0 · north of Ascension Island · depth 10 km
  - (2026-08-02) M 4.9 - 149 km S of Severo-Kuril’sk, Russia
      M4.9 · 149 km S of Severo-Kuril’sk, Russia · depth 33.834 km
  - (2026-08-02) M 4.9 - 36 km SSW of Mendi, Papua New Guinea
      M4.9 · 36 km SSW of Mendi, Papua New Guinea · depth 10 km
  - (2026-08-02) M 4.8 - 77 km SE of Atka, Alaska
      M4.8 · 77 km SE of Atka, Alaska · depth 44.288 km

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 103 total
  - (2026-08-02) [USASpending] $42,257,183,759 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-08-02) [USASpending] $41,316,801,718 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-02) [USASpending] $26,286,482,128 → BATTELLE ENERGY ALLIANCE, LLC: MANAGEMENT AND OPERATIONS OF THE INL
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATIONS OF THE INL
  - (2026-08-02) [USASpending] $3,500,000,000 → DAVIE DEFENSE INC.: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF F
      Agency: Department of Homeland Security. Description: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF FIVE (5) EACH MULTI-PURPOSE POLAR SHIP (MPPS-100) VESSELS HEREAFTER REFERRED TO AS ARCTIC SECURITY CUTTERS…
  - (2026-08-02) [USASpending] $3,373,486,394 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…
  - (2026-08-02) [USASpending] $2,533,722,927 → UNITED CLEANUP OAK RIDGE LLC: OAK RIDGE RESERVATION CLEANUP CONTRACT TASK ORDERS
      Agency: Department of Energy. Description: OAK RIDGE RESERVATION CLEANUP CONTRACT TASK ORDERS

### IT, InfoSys & cybersecurity news (last 7 days) — 6 new of 57 total
  - (2026-08-02) [The Register] Meet the 'internet radical' who helped Microsoft get email and AT&T get online
      Tom Evslin on Bill Gates, the birth of Exchange, and dragging Ma Bell onto the web
  - (2026-08-01) [The Register] Unexpected item in the bagging area as Windows Activation error pops up at check-in
      Bags weighed down by a Microsoft license key
  - (2026-08-01) [The Register] A deep dive into Nvidia's Vera CPU and the Olympus cores that power it
      88 custom cores, 176 funky threads, 1.5 TB of laptop RAM, and 1.8 TB/s of NVLink connectivity — this isn't your typical datacenter chip
  - (2026-08-01) [The Register] Enterprise cloud infrastructure uptake shows no sign of slowing
      Cloud revenue now north of $143 billion a quarter, and growth is accelerating
  - (2026-07-31) [Cybersecurity Dive] US authorities see ‘significant escalation’ in attacks on water system devices
      Hackers have locked operators out of their own OT networks, modified passwords and changed IP addresses.
  - (2026-07-31) [The Register] Dev who gave HashiCorp its name returns with a faster terminal multiplexer
      Persistent sessions could be just the beginning

### Court opinions of consequence (federal & state) — 4 new of 60 total
  - (2026-07-29) U.S. Court of International Trade: Ningxia Guanghua Cherishmet Activated Carbon Co. v. United States
  - (2026-07-29) U.S. Court of International Trade: Tube Forgings of Am., Inc. v. United States
  - (2026-07-29) U.S. Court of Appeals, 9th Cir.: Serenity Investments, LLC v. Sun Hung Kai Strategic Capital, Ltd.
  - (2026-07-29) U.S. Court of Appeals, 9th Cir.: United States v. Yates

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-08-02) [Marginal Revolution] Taiwan fact of the day
      [Annualized] 14% GDP growth in the first half of 2026 The post Taiwan fact of the day appeared first on Marginal REVOLUTION.
  - (2026-08-02) [Marginal Revolution] Mexico (Taiwan) fact of the day
      Mexico has quietly become a cornerstone of the AI boom, providing 40 per cent of US imports this year of the computer servers that are widely used in the data centres powering artificial intelligence. Taiwanese manufactu…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: standard, order, issued, management, amend, certain, action, safety, published, rulemaking, proposed, taking
- state_bills: today=178, 7d-median=152, 14d-median=152; carrying terms: subject, agency, whose, makes, assistance, families, colorado, relating, creates, pursuant, grants, alaska
- state_news: today=449, 7d-median=758, 14d-median=626; carrying terms: arkansas, agency, announcement, application, maryland, statistics, media, illinois, afternoon, senator, country, tariffs
- local_news: today=223, 7d-median=228, 14d-median=226; carrying terms: killed, games, south, missing, attachment, illinois, afternoon, google, saportareport, resize, three, court
- foreign_news: today=962, 7d-median=1022, 14d-median=1014; carrying terms: institutions, announcement, missing, finding, media, female, mimetype, shangri, country, makes, packing, starting
- chinese_internal: today=259, 7d-median=262, 14d-median=264; carrying terms: chinese, google, record, firms, people, https, caixin, china, profit, stock, investment, office
- russian_internal: today=859, 7d-median=916, 14d-median=898; carrying terms: https, novaya, novayagazeta, axios, press, patriot, wildberries, media, reuters, instagram, group, street
- ukrainian_internal: today=116, 7d-median=133, 14d-median=134; carrying terms: warfare, coincides, killed, media, ukrinform, informed, curated, change, ukraine, entered, mykhailo, damaged
- ukraine_theater: today=793, 7d-median=647, 14d-median=637; carrying terms: known, frontline, unauthorized, coverage, liveuamap, viirs, extra, polygon, google, token, cartography, anomaly
- paper_bets: today=122, 7d-median=134, 14d-median=134; carrying terms: russell, approve, total, wisconsin, accepts, achieved, whose, metamask, decrease, mbappe, israel, prime
- weather: today=159, 7d-median=173, 14d-median=173; carrying terms: https, above, moving, gusts, northwestern, dangerous, arapahoe, thunderstorm, south, houston, issued, currents
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpilfesl, pcepilfe, supply, dcoilwtico, total, vixcls, treasury, dexuseu, cpiaucsl, effective, assets, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, china, bitcoin, treasury, crypto, crude, yield, silver, range, futures, commodities, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=103, 7d-median=104, 14d-median=108; carrying terms: somalia, agency, misappropriation, order, prohibited, jihad, application, concerning, innovation, south, environmental, integrity
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, https, quiverquant, httperror, quantitative, client, unauthorized, congresstrading, quiver
- billionaires: today=30, 7d-median=37, 14d-median=36; carrying terms: yanai, london, euronext, cryptocurrency, adani, devasini, retail, telecom, michael, finance, mukesh, infrastructure
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, appeals, california, arizona, blanche, services, court, delaware, jones, texas, county, johnson
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, holdings, amended, robert, steven
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: krishnamoorthi, cooper, brown, pinkston, committee, trone, raised, cycle, senate, booker, michael, congress
- gdelt_regions: today=24, 7d-median=12, 14d-median=12; carrying terms: english, japan, world, korea, china, strikes
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, keywords, black, drone, attacks, russian, strikes, nuclear, russia
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=18, 14d-median=17; carrying terms: belgium, position, france, ground, kingdom, china
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: including, above, ranging, total, geographical, november, genetically, britain, remains, increases, round, children
- cisa_kev: today=9, 7d-median=12, 14d-median=13; carrying terms: inclusion, improper, functionality, microsoft, conflict, fortinet, check, sphere, wordpress, command, authentication, langflow
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=296, 14d-median=296; carrying terms: somalia, papua, indonesia, magnitude, bulgaria, nicaragua, monaco, forest, austria, macedonia, fausto, croatia
- usgs_quakes: today=18, 7d-median=20, 14d-median=19; carrying terms: region, depth, islands, indonesia, japan, south, papua, russia, guinea, abepura
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, prime, hormuz, august, normal, strait, ceasefire, returns, traffic, effective
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: https, government, doctor, conversableeconomist, become, class, economist, students, golden, college, marginalrevolution, certain
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: https, researchers, group, vulnerability, computer, model, according, review, technica, targeted, cybersecurity, power
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: cornyn, russell, tuberville, walkinshaw, timothy, edwards, treasury, schumer, warsh, moody, olszewski, kristen
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, markets, consensus, paper, today, module, converges, sufficient, market, unavailable, evidence, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*