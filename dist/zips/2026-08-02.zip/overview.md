# WORLDSCOPE morning brief — 2026-08-02

## Headline
2791 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (583) · Russian Internal News (state + in-exile) (570) · Ukraine Theater (total-war monitoring) (560) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (174) · Chinese Internal News (171) · Local News: St. Louis + Atlanta (114) · State-Level News (93) · Ukrainian Internal News (national + local Kyiv) (51) · Sanctions & Designations (recent) (30) · GDELT GKG — themes / entities / watch areas (25) · USGS earthquakes (M4.5+, past day) (22)

## What changed today
### International News + Multilateral Institutions — 583 new of 976 total
  - (2026-08-03) [India] India approves just 1 Chinese FDI proposal worth ₹1 crore in FY26; 13 from Hong Kong
  - (2026-08-03) [India] BMC to monitor illegal waste dumping through CCTV surveillance
  - (2026-08-03) [India] Students continue protests in Ranchi over alleged JPSC, JSSC exam irregularities, demand CBI probe
  - (2026-08-03) [India] 1.35 lakh affected still affected by floods in Assam; 3 more deaths take toll to 85
  - (2026-08-03) [India] M.K. Sanoo never saw continuous LDF rule as dangerous, says Pinarayi Vijayan
  - (2026-08-03) [India] Slipper hurled at MP Pappu Yadav; Opposition slams police

### Russian Internal News (state + in-exile) — 570 new of 786 total
  - (2026-08-02) Итальянский военный корабль досмотрел танкер российского «теневого флота» в Средиземном море | LEDE: Итальянский военный корабль Thaon di Revel высадил досмотровую группу на борт танкера рос] (ru: Ита…
      Итальянский военный корабль Thaon di Revel высадил досмотровую группу на борт танкера российского «теневого флота», сообщили в Минобороны Италии.
  - (2026-08-02) В Венгрии из-за обмеления Дуная остановили предпоследний энергоблок АЭС «Пакш». Станция может полностью прекратить работу | LEDE: Предпоследний работающий энергоблок АЭС «Пакш» в Венгрии в н] (ru: В В…
      Предпоследний работающий энергоблок АЭС «Пакш» в Венгрии в ночь на 2 августа был остановлен в связи со снижением уровня воды в Дунае.
  - (2026-08-02) Летом хорошо! Но еще — выше риск утонуть, заболеть из-за укуса клеща, перегреться, обгореть и спровоцировать пожар, готовя шашлык. Как выжить? Инструкции «Медузы», которые помогут справиться со] (ru:…
      Начался август. Для многих это последний в этом году шанс «хорошо провести лето». Но на отдыхе можно столкнуться с большим количеством опасностей. Минимизировать риски помогают простые правила. Только их нужно знать и со…
  - (2026-08-02) Целью теракта в московском ресторане, вероятно, был генерал Александр Чайко — хотя сам он в итоге не пострадал. Что о нем известно? | LEDE: 1 августа в Москве в высотке на Баррикадной произо] (ru: Цел…
      1 августа в Москве в высотке на Баррикадной произошел взрыв. В этот момент в ресторане Balzi Rossi, расположенном на первом этаже здания, проходило частное мероприятие. По данным Национального антитеррористического комит…
  - (2026-08-02) Марокканская футболистка погибла, пытаясь добраться до Сеуты | LEDE: 20-летняя марокканская футболистка Фатен Бен Омар эль-Азиз, играющая за «Магреб Атлетик» (Maghreb Atlético Tetuán), погиб] (ru: Мар…
      20-летняя марокканская футболистка Фатен Бен Омар эль-Азиз, играющая за «Магреб Атлетик» (Maghreb Atlético Tetuán), погибла при попытке добраться до Сеуты, сообщают Mundo Deportivo и El Mundo со ссылкой на заявление клуб…
  - (2026-08-02) Российское подсанкционное судно доставило в Мали военную технику — для борьбы с повстанцами, которую правительство страны ведет при поддержке Москвы | LEDE: Российское грузовое судно «Михаил] (ru: Рос…
      Российское грузовое судно «Михаил Бритнев» в начале июля доставило в порт Ломе в Того военную технику, которая затем была переправлена в столицу Мали Бамако — для поддержки российских и малийских военных в борьбе с повст…

### Ukraine Theater (total-war monitoring) — 560 new of 1073 total
  - (2026-08-01) [FIRMS] thermal anomaly 47.882, 33.401 (FRP 2.75 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 2.75 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.877, 33.408 (FRP 2.16 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 2.16 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.860, 33.444 (FRP 3.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 3.71 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.860, 33.451 (FRP 1.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 1.93 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.732, 34.859 (FRP 0.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 0.37 MW
  - (2026-08-01) [FIRMS] thermal anomaly 47.728, 34.799 (FRP 0.47 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-01 2318Z, FRP 0.47 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 174 new of 176 total
  - (2026-08-02) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 2 at 5:37PM MDT until August 2 at 5:45PM MDT by NWS Albuquerque NM
      The severe storms have weakened. However, small hail, gusty winds, and heavy rain are still possible with this thunderstorm.
  - (2026-08-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-02) [Moderate] Special Weather Statement: Special Weather Statement issued August 2 at 5:36PM MDT by NWS El Paso Tx/Santa Teresa NM
      At 535 PM MDT, Doppler radar was tracking a cluster of strong thunderstorms 7 miles north of Buckhorn, moving southwest at 30 mph. HAZARD...Wind gusts of 50 to 55 mph and pea size hail. SOURCE...Radar indicated. IMPACT..…
  - (2026-08-02) [Moderate] Dense Smoke Advisory: Dense Smoke Advisory issued August 2 at 5:36PM MDT until August 2 at 6:00PM MDT by NWS Glasgow MT
      The threat has ended. For the Dense Smoke Advisory, areas of reduced visibility and low air quality will remain through the evening, but no longer pose a significant threat. For the Lake Wind Advisory, breezy conditions…
  - (2026-08-02) [Moderate] Lake Wind Advisory: Lake Wind Advisory issued August 2 at 5:36PM MDT until August 2 at 6:00PM MDT by NWS Glasgow MT
      The threat has ended. Breezy conditions will remain through the evening, but no longer pose a significant threat.
  - (2026-08-02) [Moderate] Lake Wind Advisory: Lake Wind Advisory issued August 2 at 5:36PM MDT until August 2 at 6:00PM MDT by NWS Glasgow MT
      The threat has ended. For the Dense Smoke Advisory, areas of reduced visibility and low air quality will remain through the evening, but no longer pose a significant threat. For the Lake Wind Advisory, breezy conditions…

### Chinese Internal News — 171 new of 266 total
  - (2026-08-01) 财新闻｜连云港消防回应火灾母女坠楼：救援人员一直控制水枪射流，尽量避免直接冲击被困人员；现场不具备铺设救生垫和使用举高车、云梯车条件 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9oM1RIWXNvUHc4MXhnWC1kdmpCeC1ka0ZRZ3hmaWZyVVdwZXBHeTI] (zh:…
      财新闻｜连云港消防回应火灾母女坠楼：救援人员一直控制水枪射流，尽量避免直接冲击被困人员；现场不具备铺设救生垫和使用举高车、云梯车条件 财新
  - (2026-07-31) 今日开盘：两市双双高开 沪指涨幅0.76% - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1XUU5XLWpnVUpGRV9jZWZzSmhWQTk0TnBkSjcwVnpBWjliMkRFdmpnRnZ3TmJFSFo3bFVyNGRsNENiUXRU] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.76% finance.caixin.com
  - (2026-08-02) 反腐记｜七月末一日 双“虎”频入网 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBwU1lNV1RvQkhDdHFXNEdhNFVGdkYwdFFMdXlkRU1wcE1pczhCOU5ld3NCYmdLT0o4MkIyRHdjZEhQV1ZWRnlZSF] (zh:…
      反腐记｜七月末一日 双“虎”频入网 china.caixin.com
  - (2026-08-02) 外汇贷款“专户”管理进一步简化 有出口贸易背景不必另开户 - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1PNkVZWWdVak5XSlJ0MHkwbHg3aEtOcG40ZmROYnhHYzNELTR0S3psclZrUFV1WjNrMTVPZmdNN] (zh:…
      外汇贷款“专户”管理进一步简化 有出口贸易背景不必另开户 finance.caixin.com
  - (2026-08-02) 江苏徐州一地试点集中供冷 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5rTHAxS2swOGNJTVRlRElIb05IWmJLVFo2UUVLQmZHSnEyc0xiamF3c0F6OHZMU1JTdm1Qb0J1bUc0RjZNYUgtVEN2enRDem1vSGJRRWxjc] (zh:…
      江苏徐州一地试点集中供冷 财新
  - (2026-08-01) 视线｜极端高温致多瑙河水位跌破纪录 二战沉船与猛犸象化石接连露出 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1fZVRPYkh1OUVFVWx2R0lScDQ2czhTVjJWandkNk1mZlpCX2txQnE5QURnamxOTE5uMTF5WUhiYVBmZ3FCb19LV] (zh:…
      视线｜极端高温致多瑙河水位跌破纪录 二战沉船与猛犸象化石接连露出 财新

### Local News: St. Louis + Atlanta — 114 new of 224 total
  - (2026-08-02) [St. Louis] Trump says Gulf leaders' input weighed heavily in decision to hold off on ordering new Iran strikes
      The emerging deal “would include the Immediate, Complete, and Total OPENING OF THE HORMUZ STRAIT, and an end to Iran’s nuclear threat,” Trump wrote Saturday.
  - (2026-08-02) [St. Louis] Stunt riders gather to pay tribute to man who drowned in Missouri River
      Stunt riders gathered in Portage Des Sioux to honor A. J. Soehlke, while friends urged water safety after the 22-year-old drowned in the Missouri River.
  - (2026-08-02) [St. Louis] Senate leaders reach funding deal to avoid shutdown during campaign season
      Senate leaders push for a short-term spending bill to fund the government through early December and avoid a government shutdown.
  - (2026-08-02) [St. Louis] What we know about the victims in the Idaho In-N-Out shooting
      The owner of the Twin Falls, Idaho In-N-Out, where the shooting took place, confirmed one of their employees was killed during the incident.
  - (2026-08-02) [St. Louis] Gunman found dead after Idaho shooting that left 3 people dead and injured several others
      The suspected gunman, identified by police as 24-year-old Chad Williams in a Sunday afternoon press conference, was found dead from a self-inflected gunshot.
  - (2026-08-02) [St. Louis] ICE detains woman at St. Charles Sam's Club after police chase; driver sought
      A driver is wanted after police say a Kia fled a traffic stop and two passengers jumped out at the St. Charles Sam’s Club. ICE arrived at the scene soon after.

### State-Level News — 93 new of 473 total
  - (2026-08-02) [Alaska] Farmers Market Week 2026
      WHEREAS, the United States Department of Agriculture (USDA) proclaimed the first National Farmers Market Week in 1999 to raise awareness of efforts nationwide for producers to sell directly to customers; and WHEREAS, a f…
  - (2026-08-02) [Alaska] Community Health Center Week 2026
      WHEREAS, for over fifty years, community health centers have delivered accessible and affordable healthcare to underserved and uninsured members of communities across the Nation; and WHEREAS, a community health center’s…
  - (2026-08-02) [Arkansas] String of outbreaks tests US public health system amid funding cuts, vaccine resistance
      WASHINGTON — Health and Human Services Secretary Robert F. Kennedy Jr. pledged during his confirmation hearing to do everything in his “power to put the health of America back on track.” Kennedy testified that when he wo…
  - (2026-08-02) [Arkansas] Immigrants helped shape Arkansas. The state shouldn’t forget that history.
      I’ve never been to Tontitown, nor have I had the pleasure of partaking in its storied annual Grape Festival. But the northwest Arkansas community founded by Italian immigrants feels familiar to me. That’s partly because…
  - (2026-08-02) [Connecticut] Lamont’s fiscal success rests on foundation laid by Malloy, others
      <img width="1024" height="769" src="https://ctmirror.org/wp-content/uploads/2018/11/CTJH107.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high" srcset="ht…
  - (2026-08-02) [Connecticut] CT’s $1.6 billion railroad promise
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/caternary-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcse…

### Ukrainian Internal News (national + local Kyiv) — 51 new of 131 total
  - (2026-08-03) Росіяни влучили в АЗС у Харкові: спалахнула пожежа | LEDE: У Київському районі Харкова російський БПЛА влучив в автозаправку, спалахнула пожежа.] (uk: Росіяни влучили в АЗС у Харкові: спалахнула пожеж…
      У Київському районі Харкова російський БПЛА влучив в автозаправку, спалахнула пожежа.
  - (2026-08-03) Трамп заявив, що США можуть будь-коли вдарити по Ірану у разі необхідності | LEDE: Дональд Трамп заявив, що США готові завдати ударів по Ірану у разі необхідності.] (uk: Трамп заявив, що США можуть бу…
      Дональд Трамп заявив, що США готові завдати ударів по Ірану у разі необхідності.
  - (2026-08-03) ВМС США перехопили 35 торгових суден після відновлення блокади Ірану | LEDE: CENTCOM повідомило про перехоплення 35 суден, пов’язаних з Іраном, та огляди 2 з них після відновлення морської блок] (uk:…
      CENTCOM повідомило про перехоплення 35 суден, пов’язаних з Іраном, та огляди 2 з них після відновлення морської блокади.
  - (2026-08-02) Внаслідок зіткнення пожежних гелікоптерів у Греції загинули двоє людей | LEDE: ] (uk: Внаслідок зіткнення пожежних гелікоптерів у Греції загинули двоє людей)
  - (2026-08-02) Прем'єр Британії висловив підтримку ідеї прийняття писемної конституції | LEDE: ] (uk: Прем'єр Британії висловив підтримку ідеї прийняття писемної конституції)
  - (2026-08-02) В Одесі чоловік відкрив вогонь по військових ТЦК: 4 поранених, стрільця затримали | LEDE: В Одесі чоловік відкрив стрілянину по військових ТЦК, четверо поранено. Нападника шукають, поліція пров] (uk:…
      В Одесі чоловік відкрив стрілянину по військових ТЦК, четверо поранено. Нападника шукають, поліція проводить слідчі дії.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-02) [Israel-Iran-Hezbollah axis · themes] Россиянам назвали факторы , влияющие на продолжительность жизни
      vesti.ru · Russian · tone NA
  - (2026-08-02) [Israel-Iran-Hezbollah axis · themes] เช็กดวงประจำวันที่ 3 ส . ค . 69 ราศีที่ดาวศรีสถิต มีน ราศีที่ดาวกาลีสถิต กรกฎ
      dailynews.co.th · Thai · tone NA
  - (2026-08-02) [Israel-Iran-Hezbollah axis · themes] Celebration of life held for Will Roberts , Alabama teen who battled bone cancer
      waff.com · English · tone NA
  - (2026-08-02) [Israel-Iran-Hezbollah axis · themes] El abismo emocional tras el terremoto - Últimas Noticias
      ultimasnoticias.com.ve · Spanish · tone NA
  - (2026-08-02) [Israel-Iran-Hezbollah axis · themes] Scottish anti - racists : we dont trust the state to beat the far right
      socialistworker.co.uk · English · tone NA
  - (2026-08-02) [Israel-Iran-Hezbollah axis · themes] Microrrelatos SUR VI Premio Pablo Aranda : textos del 3 de agosto
      diariosur.es · Spanish · tone NA

### USGS earthquakes (M4.5+, past day) — 22 new of 22 total
  - (2026-08-02) M 5.6 - 14 km S of Hicks Bay, New Zealand
      M5.6 · 14 km S of Hicks Bay, New Zealand · depth 52.806 km
  - (2026-08-02) M 5.3 - north of Ascension Island
      M5.3 · north of Ascension Island · depth 10 km
  - (2026-08-02) M 5.3 - 265 km S of ‘Ohonua, Tonga
      M5.3 · 265 km S of ‘Ohonua, Tonga · depth 10 km
  - (2026-08-02) M 5.2 - 112 km SW of Severo-Kuril’sk, Russia
      M5.2 · 112 km SW of Severo-Kuril’sk, Russia · depth 80.691 km
  - (2026-08-02) M 5.1 - 60 km W of Bahía de Lobos, Mexico
      M5.1 · 60 km W of Bahía de Lobos, Mexico · depth 10 km
  - (2026-08-02) M 5.0 - 16 km NW of Changning, China
      M5.0 · 16 km NW of Changning, China · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-08-02) Mubadala Citi DC Open: Jessica Pegula vs Alexandra Eala
      yes price: 82% · 24h volume: $1,628,790 · resolves 2026-08-09
  - (2026-08-02) Boston Red Sox vs. Los Angeles Dodgers
      yes price: 60% · 24h volume: $1,494,502 · resolves 2026-08-09
  - (2026-08-02) Strait of Hormuz traffic returns to normal by August 31?
      yes price: 12% · 24h volume: $1,165,703 · resolves 2026-08-31
  - (2026-08-02) LoL: Fnatic vs Movistar KOI (BO3) - LEC Regular Season
      yes price: 0% · 24h volume: $1,062,758 · resolves 2026-08-02
  - (2026-08-02) LoL: LYON vs Shopify Rebellion - Game 1 Winner
      yes price: 100% · 24h volume: $842,473 · resolves 2026-08-03
  - (2026-08-02) Will Tucker Carlson win the 2028 Republican presidential nomination?
      yes price: 1% · 24h volume: $691,161 · resolves 2028-11-07

### IT, InfoSys & cybersecurity news (last 7 days) — 14 new of 57 total
  - (2026-08-02) [BleepingComputer] OpenAI teases Astra, its next major AI model, after it solves 10 long-standing math problems
      OpenAI has revealed Astra, an unreleased model designed to tackle complex, long-running tasks, after an internal version produced ten significant advances in mathematics and theoretical computer science. [...]
  - (2026-08-02) [BleepingComputer] COLDCARD wallet RNG flaw likely linked to $88 million Bitcoin theft
      A vulnerability in COLDCARD hardware wallet firmware allowed attackers to steal an estimated $88.6 million in Bitcoin from thousands of wallets whose seeds were generated using a flawed random number generator. [...]
  - (2026-08-02) [BleepingComputer] Google Chrome may soon block New Tab hijacker extensions by default
      Google is preparing a new Chrome security feature that would block policy-installed extensions from hijacking the New Tab page or changing the default search engine. [...]
  - (2026-08-02) [The Register] Meet the 'internet radical' who helped Microsoft get email and AT&T get online
      Tom Evslin on Bill Gates, the birth of Exchange, and dragging Ma Bell onto the web
  - (2026-08-02) [IEEE Spectrum] This Hi-Fi Tape Recorder Changed Radio Forever
      A German engineer wanted a cheaper cigarette. The popular crooner Bing Crosby wanted a vacation. Satisfying both desires inadvertently led to the invention of the laugh track. Along the way there were Nazis, spoils of wa…
  - (2026-08-02) [TechCrunch] The global memory shortage hits the MacBook Air
      The global memory chip shortage appears to be affecting the availability of Apple’s most popular Mac.

### Paper Trading Scorecard — 13 new of 119 total
  - (2026-08-02) [Polymarket] Will Amazon be the largest company in the world by market cap on August 31?
      This market will resolve to the largest company in the world by market cap on August 31, 2026, as of market close. The resolution source for this market will be a consensus of credible reporting.
  - (2026-08-02) [Polymarket] Will Elon Musk post 240-259 tweets from July 28 to August 4, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 28 12:00 PM ET to August 4, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and r…
  - (2026-08-02) [Polymarket] Mitch McConnell steps down from Senate before his term ends?
      This market will resolve to “Yes” if Mitch McConnell formally announces an intention to step down or otherwise vacates his U.S. Senate seat before his current term is scheduled to end (January 3, 2027, 11:59 PM ET). Othe…
  - (2026-08-02) [Manifold] Will something happen this week in AI (by 5pm EST August 7)?
  - (2026-08-02) [Manifold] Gianni Infantino announces he is out as FIFA President before end of 2026?
  - (2026-08-02) [Manifold] Will Anthropic or Google have a stronger model by the end of 2026?

### GDACS — global disaster alerts — 11 new of 233 total
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-08-01) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.5M, Depth:82.29km
  - (2026-08-01) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.5M, Depth:82.29km
  - (2026-08-01) [Green] Earthquake in Canada
      Earthquake · Green alert · Canada · Magnitude 5.6M, Depth:10km

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 104 total
  - (2026-07-31) [FARA] Criminal Division | Whistleblower Awards Pilot Program - Department of Justice (.gov)
      Criminal Division | Whistleblower Awards Pilot Program Department of Justice (.g
  - (2026-08-02) [USASpending] $42,257,183,759 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-08-02) [USASpending] $41,316,801,718 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-02) [USASpending] $26,286,482,128 → BATTELLE ENERGY ALLIANCE, LLC: MANAGEMENT AND OPERATIONS OF THE INL
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATIONS OF THE INL
  - (2026-08-02) [USASpending] $3,500,000,000 → DAVIE DEFENSE INC.: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF F
      Agency: Department of Homeland Security. Description: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF FIVE (5) EACH MULTI-PURPOSE POLAR SHIP (MPPS-100) VESSELS HEREAFTER REFERRED TO AS ARCTIC SECURITY CUTTERS…
  - (2026-08-02) [USASpending] $3,373,486,394 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…

### Court opinions of consequence (federal & state) — 3 new of 60 total
  - (2026-07-29) U.S. Court of Appeals, 6th Cir.: Bonfiglioli USA, Inc. v. Midwest Engineered Components, Inc.
  - (2026-07-29) U.S. Court of Appeals, 6th Cir.: United States v. Saruba Asante Smith
  - (2026-07-29) U.S. Court of Appeals, 2nd Cir.: Civil Rights Corps v. LaSalle

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-08-02) [Marginal Revolution] Sunday assorted links
      1. The inverseminar, someone else presents your paper. 2. The rise of million-dollar companies with just one employee (WSJ). 3. The political party itself is a big driver of polarization. 4. Gita Gopinath is making sense…
  - (2026-08-02) [Marginal Revolution] On the Acemoglu-Autor et.al. fertility result
      Here is criticism from Revana Sharfuddin. Here is criticism from JFV. The post On the Acemoglu-Autor et.al. fertility result appeared first on Marginal REVOLUTION.
  - (2026-08-02) [Marginal Revolution] Taiwan fact of the day
      [Annualized] 14% GDP growth in the first half of 2026 The post Taiwan fact of the day appeared first on Marginal REVOLUTION.

### Government & military aircraft airborne (OpenSky) — 1 new of 4 total
  - (2026-08-02) RCH5001 (United States)
      icao24: ae051a · position: (21.9411, -156.064) · alt: 9867m · 886km/h

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: safety, action, management, taking, standard, provide, published, notice, requires, rulemaking, issued, certain
- state_bills: today=82, 7d-median=117, 14d-median=117; carrying terms: project, appropriate, penalties, human, state, financial, orders, digital, support, licenses, create, right
- state_news: today=473, 7d-median=758, 14d-median=626; carrying terms: instead, western, announcing, august, everyone, lines, asked, season, latest, effort, redirects, contest
- local_news: today=224, 7d-median=228, 14d-median=226; carrying terms: august, games, family, sheriff, arrested, neighborhood, arrest, https, following, board, search, against
- foreign_news: today=976, 7d-median=1022, 14d-median=1014; carrying terms: instead, western, august, season, tensions, float, conclude, latest, verify, burnham, french, scheme
- chinese_internal: today=266, 7d-median=266, 14d-median=266; carrying terms: https, people, chinese, global, google, caixin, profit, china, record, firms, stock, market
- russian_internal: today=786, 7d-median=916, 14d-median=898; carrying terms: istories, novaya, street, client, axios, media, novayagazeta, found, associated, bloomberg, openai, https
- ukrainian_internal: today=131, 7d-median=133, 14d-median=134; carrying terms: change, latest, vechirniy, assessment, drones, fires, sources, moscow, intelligence, roughly, state, designed
- ukraine_theater: today=1073, 7d-median=647, 14d-median=637; carrying terms: https, known, snapshot, community, anomaly, polygon, liveuamap, acquired, httperror, deepstatemap, maintained, token
- paper_bets: today=119, 7d-median=134, 14d-median=134; carrying terms: wisconsin, lifetime, total, season, humans, magnitude, netanyahu, zohran, miami, according, mbappe, polymarket
- weather: today=176, 7d-median=173, 14d-median=174; carrying terms: western, portions, tomorrow, nueces, depth, increase, diego, state, mcmullen, unsecured, memphis, seattle
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: implied, cpiaucsl, dexuseu, vixcls, treasury, payems, total, jolts, balance, unemployment, inflation, sheet
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, nasdaq, range, equities, treasury, close, agriculture, russell, credit, proxy, corporate, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=104, 7d-median=104, 14d-median=108; carrying terms: actions, snapshot, extra, occupation, renewab, libya, enable, transactions, sevastopol, situation, moldova, production
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiver, https, error, quantitative, unauthorized, quiverquant, httperror, congresstrading
- billionaires: today=30, 7d-median=37, 14d-median=36; carrying terms: cryptocurrency, steve, arnault, canada, francoise, holdings, thomas, technologies, finance, family, walmart, huang
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: california, services, blanche, johnson, texas, arizona, supreme, jones, court, delaware, county, appeals
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, holdings, steven, robert, amended
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, graham, congress, elect, booker, raised, shawn, robert, filing, committee, cortez, alexandria
- gdelt_regions: today=6, 7d-median=6, 14d-median=9; carrying terms: english, china
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, hezbollah, israel, trump, spanish, netanyahu, crisis, themes, chinese, russian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=4, 7d-median=16, 14d-median=16; carrying terms: canada, position, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: coronavirus, circulation, cumulative, sometimes, poliovirus, unrelated, safety, announcing, august, total, ebola, ministry
- cisa_kev: today=9, 7d-median=12, 14d-median=13; carrying terms: check, overflow, based, fortinet, control, command, conflict, point, vulnerability, improper, microsoft, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=233, 7d-median=287, 14d-median=287; carrying terms: orange, madagascar, denmark, canada, green, ecuador, croatia, north, indonesia, herzegovina, magnitude, alert
- usgs_quakes: today=22, 7d-median=22, 14d-median=21; carrying terms: depth, south, indonesia, japan, papua, philippines, china, mexico, russia, guinea, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, returns, strait, august, ceasefire, normal, hormuz, traffic, invade, effective
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: economist, certain, conversable, conversableeconomist, college, revolution, students, doctor, having, marginal, https, marginalrevolution
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: attacks, intelligence, technica, information, financial, despite, cybersecurity, support, techcrunch, artificial, target, computer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: development, robin, scott, morgan, harriet, meuser, vasquez, adriano, august, massie, arrington, grassley
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, claude, markets, sufficient, decision, converges, placed, paper, identify, consensus, placement, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*