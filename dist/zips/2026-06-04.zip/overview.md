# WORLDSCOPE morning brief — 2026-06-04

## Headline
2720 new items across 25 active section(s) (of 41 tracked).

## Top movers today
International News + Multilateral Institutions (534) · Russian Internal News (state + in-exile) (511) · World leaders & government officials (324) · State Legislative Action (209) · Chinese Internal News (207) · State-Level News (199) · GDELT GKG — themes / entities / watch areas (146) · Local News: St. Louis + Atlanta (123) · Ukrainian Internal News (national + local Kyiv) (110) · Ukraine Theater (total-war monitoring) (100) · U.S. Weather + Severe / Climate Outlooks (65) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 534 new of 861 total
  - (2026-06-04) [India] CM Adityanath inaugurates eastern U.P.’s first flatted factory complex in GIDA
  - (2026-06-04) [India] Monsoon 2026 LIVE: Southwest monsoon arrives in Kerala, says IMD
      The India Meteorological Department issues orange alert for six districts as heavy rains hit parts of Kerala
  - (2026-06-04) [India] Heavy rainfall alert in six Telangana districts on June 5
  - (2026-06-04) [India] Congress raises questions on 'substantial' LIC stake in firm under SEBI scanner
  - (2026-06-04) [India] TDP launches State-wide bicycle campaign for World Environment Day; Naidu to ride in Vizag
  - (2026-06-04) [India] TMC councillor of Kolkata Municipal Corporation arrested for ‘molesting’ woman

### Russian Internal News (state + in-exile) — 511 new of 1050 total
  - (2026-06-04) Boards of Canada выпустили первый альбом за 13 лет — это важнейшее событие для мира электронной музыки. В нем множество пасхалок и загадок, которые можно решить, зная предысторию группы. Что мы] (ru:…
      29 мая вышел «Inferno» — первый за тринадцать лет альбом шотландского дуэта Boards of Canada. Это невероятно значимое событие для мира электроники (настолько заметное, что один из их новых треков даже использовал в своем…
  - (2026-06-04) 11 европейских стран потребовали ужесточить выдачу виз россиянам | LEDE: 11 европейских стран призывают Еврокомиссию ввести дополнительные ограничения на выдачу шенгенских виз гражданам Росс] (ru: 11…
      11 европейских стран призывают Еврокомиссию ввести дополнительные ограничения на выдачу шенгенских виз гражданам России. Об этом сообщают Politico, Deutsche Welle и польское издание RMF24. Они ссылаются на письмо, которо…
  - (2026-06-04) К 50-летию Навального вышла аудиоверсия его книги «Патриот». Ее можно послушать бесплатно | LEDE: К 50-летнему юбилею Алексея Навального его мемуары «Патриот» вышли в формате аудиокниги. Ее ] (ru: К 5…
      К 50-летнему юбилею Алексея Навального его мемуары «Патриот» вышли в формате аудиокниги. Ее можно послушать бесплатно на сайте издательства One Book Publishing, рассказала вдова политика Юлия Навальная.
  - (2026-06-04) Германия впервые не смогла получить место временного члена Совбеза ООН. Глава МИД ФРГ обвинил в этом Россию | LEDE: Германия не была избрана непостоянным членом Совета безопасности ООН на 20] (ru: Гер…
      Германия не была избрана непостоянным членом Совета безопасности ООН на 2027-2028 годы, сообщает Deutsche Welle.
  - (2026-06-04) Орешкин призвал россиян не ждать отмены санкций: «Мир как раньше не вернется» | LEDE: России не стоит ждать отмены санкций, заявил на Петербургском экономическом форуме помощник президента М] (ru: Оре…
      России не стоит ждать отмены санкций, заявил на Петербургском экономическом форуме помощник президента Максим Орешкин.
  - (2026-06-04) «Макс» перестал отправлять уведомления на устройства Apple. Накануне мессенджер удалили из App Store | LEDE: На устройства Apple перестали приходить пуш-уведомления о звонках и сообщениях в ] (ru: «Ма…
      На устройства Apple перестали приходить пуш-уведомления о звонках и сообщениях в мессенджере «Макс», сообщила пресс-служба «Макса».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State Legislative Action — 209 new of 209 total
  - (2026-06-04) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…
  - (2026-06-03) [Alaska HB 16] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits for state and local office; direct…
  - (2026-06-03) [Alaska HB 110] HEALTH CARE/LICENSURE COMPACTS/SOCIAL WRK
      HEALTH CARE/LICENSURE COMPACTS/SOCIAL WRK
  - (2026-06-03) [Alaska HB 25] An Act relating to disposable food service ware and containers provided by customers; and providing for an effective date.
      An Act relating to disposable food service ware and containers provided by customers; and providing for an effective date.
  - (2026-06-03) [Alaska HB 48] An Act relating to appropriations to the civil legal services fund.
      An Act relating to appropriations to the civil legal services fund.
  - (2026-06-03) [Alaska HB 39] An Act relating to public school students who are deaf or hard of hearing.
      An Act relating to public school students who are deaf or hard of hearing.

### Chinese Internal News — 207 new of 271 total
  - (2026-06-04) 中央精神 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFAyRDh0X3Q0bnJONElVcVNkQzdHZ3JvS2ZUMlFWZF9xOHcwQXZkTmtrenBBMVlaTXlnTUZqUGVIdG9RdkxzNGc5b2RZLURPNWNsb0Rzek9oOUh] (zh:…
      中央精神 中国共产党新闻网
  - (2026-06-04) 韩国举行第九届地方选举 - 人民网韩国频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1kV0hxU0FDbXc1T0p5SmIydDVfUi12aXV0WnNQQWlWOTRtYkhKV0dxVS1FUkpWYnFoMVdoOW9zVkxsVXB4UnI2Ym1UZGdob0Izd0I2U] (zh:…
      韩国举行第九届地方选举 人民网韩国频道
  - (2026-06-03) 山西芮城： 沿黄岸畔绘盛景 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFAtWGdzVmdSeHhEcVRIdTBtZFVhLVlLbWh6aXFOUV8waEJwVGIwb1NIeUpJbXVUT3dacDRsVTJTOEFIdUJvd0MwYU1EY0lMMTYzNWsxSW] (zh:…
      山西芮城： 沿黄岸畔绘盛景 人民图片
  - (2026-06-03) 福建：泉金航线开通二十年运送旅客突破160 万人次 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5wNXk3OFlNN3ozSXNlV3J4a0UzcldndFVoNW8wUS1jVkg4MlAyU3FoZ1BEa1hyMWhEWmVpTnVhMjFMbjFSRXRFVHBJcU] (zh:…
      福建：泉金航线开通二十年运送旅客突破160 万人次 人民图片
  - (2026-06-03) 浙江长兴： 智慧农业助力乡村振兴 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE82UFM3S2FmdWQ5Wmc1aXQyV1ROMVhmdTM4M0JKeEdVa0J4eFpHMk1EWC1IcEh2Nk1qUnZBYnhXbE1BOFB4LTBwR09GMW1CUHlzM0p] (zh:…
      浙江长兴： 智慧农业助力乡村振兴 人民图片
  - (2026-06-04) 图片报道 - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxOVkRsSzBhblVUbU5kR29KclFaSjB1YWZUOUFNUWpPNnFNdGsxd3ZYN0VpQjdJYTVXeEc1WVpBMk1RRU9jZ0xnSHJadEthdW84N3lzcG9NMC01M3p] (zh:…
      图片报道 人民日报

### State-Level News — 199 new of 766 total
  - (2026-06-03) [California] Federal judge orders immigrant detention center to allow San Diego County health inspection
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/03/022026_Padilla-Otay-Mesa_AH_02_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-06-03) [California] Election denier likely loses job in Shasta County. But voters back hand-counting ballots
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Shasta-County-Election_MH_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-06-03) [California] In a first, California Supreme Court reverses a death sentence under new racial justice law
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/07/050824-Supreme-Court-JF-AP-CM-25.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-06-03) [Arizona] House passes War Powers Resolution to force Trump to end the war he launched against Iran
      WASHINGTON — The U.S. House passed a resolution Wednesday to force President Donald Trump to withdraw from the war with Iran and require congressional approval for further military action in the country. The 215-208 vote…
  - (2026-06-03) [Arizona] Treasury secretary dodges questions on whether Trump still has lifetime IRS audit immunity
      WASHINGTON — The day after acting Attorney General Todd Blanche said the Trump administration’s “anti-weaponization” fund was dead, Treasury Secretary Scott Bessent evaded questions on Capitol Hill Wednesday about whethe…
  - (2026-06-04) [Colorado] Fifty for 150: Obama accepts the Democratic nomination in Denver in 2008
      In August 2008, Americans were feeling uneasy. Eight years of the George W. Bush administration had mired the country in two protracted wars in the Middle East. The attacks of 9/11 still cast a dark shadow over much gove…

### GDELT GKG — themes / entities / watch areas — 146 new of 146 total
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] Shipping amid geopolitical turmoil : Marinakis ( Capital Group ) on the prospect of Strait of Hormuz tolls
      naftemporiki.gr · English · tone NA
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] Azerbaijani oil moves up in price
      trend.az · English · tone NA
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] Overnight News Digest : June 3 , 2026
      dailykos.com · English · tone NA
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] Chinese firms that help Russia are next for EU sanctions
      politico.eu · English · tone NA
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] The Iran War Is Pushing the Global Gas Trade Into the Shadows
      finance.yahoo.com · English · tone NA
  - (2026-06-04) [Israel-Iran-Hezbollah axis · keywords] Trump acknowledges calling Netanyahu crazy and says Israel is complicating peace talks with Iran | News , Sports , Jobs
      salemnews.net · English · tone NA

### Local News: St. Louis + Atlanta — 123 new of 227 total
  - (2026-06-04) [St. Louis] Queer Writes returns to Missouri History Museum with tribute to Kathleen Finneran
      The Missouri Historical Society and That Uppity Theater Company will host its fourth annual Queer Writes event to kick off Pride Month on June 11. Featuring five local artists performing original work, the event will als…
  - (2026-06-04) [St. Louis] Where in the Lou 6/4/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-06-04) [St. Louis] World Cup warmup game sparks excitement for St. Louis Bosnians
  - (2026-06-04) [St. Louis] Svjetsko prvenstvo: Prijateljska utakmica budi uzbuđenje među Bosancima u St. Louisu
  - (2026-06-04) [St. Louis] Most education bills failed in the Missouri legislature this year — here's why
  - (2026-06-04) [St. Louis] Overdose ‘deaths of despair’ decrease significantly in Missouri and Illinois

### Ukrainian Internal News (national + local Kyiv) — 110 new of 121 total
  - (2026-06-04) В Україні дощитиме до кінця тижня | LEDE: В Україні 5-7 червня очікуються дощі, грози і тумани. Температура до +29°. Подробиці прогнозу] (uk: В Україні дощитиме до кінця тижня)
      В Україні 5-7 червня очікуються дощі, грози і тумани. Температура до +29°. Подробиці прогнозу
  - (2026-06-04) СБС уразили російський прикордонний корабель "Світляк" та комплекс "Панцир" у Криму | LEDE: У ніч на 4 червня підрозділи Сил безпілотних систем ЗСУ уразили російський прикордонний сторожовий ко] (uk:…
      У ніч на 4 червня підрозділи Сил безпілотних систем ЗСУ уразили російський прикордонний сторожовий корабель класу "Світляк" у тимчасово окупованому Криму.
  - (2026-06-04) ГУР: Росія може випускати по Україні до 100 балістичних ракет на місяць | LEDE: За оцінками воєнної розвідки України, Росія здатна застосовувати до 100 балістичних ракет зберігаючи сталий рівен] (uk:…
      За оцінками воєнної розвідки України, Росія здатна застосовувати до 100 балістичних ракет зберігаючи сталий рівень їхніх запасів.
  - (2026-06-04) Справу проти детектива НАБУ Гусарова, якого називали "кротом", закрили | LEDE: Шевченківський суд Києва звільнив співробітника Національного антикорупційного бюро Віктора Гусарова від криміналь] (uk:…
      Шевченківський суд Києва звільнив співробітника Національного антикорупційного бюро Віктора Гусарова від кримінальної відповідальності.
  - (2026-06-04) Удар по корвету "Бойкий" у Кронштадті: супутник зафіксував, як росіяни гасять пожежу на кораблі | LEDE: На супутникових знімках, які опублікували "Схеми", видно, як російські пожежники намагают] (uk:…
      На супутникових знімках, які опублікували "Схеми", видно, як російські пожежники намагаються загасити пожежу на корветі "Бойкий" у порту Кронштадта після української атаки.
  - (2026-06-04) У Польщі розбився вертоліт, пілот загинув | LEDE: 4 червня у Польщі знайшли уламки вертольота Robinson R44 Raven II, який вночі зник з радарів, його пілот загинув.] (uk: У Польщі розбився вертоліт, пі…
      4 червня у Польщі знайшли уламки вертольота Robinson R44 Raven II, який вночі зник з радарів, його пілот загинув.

### Ukraine Theater (total-war monitoring) — 100 new of 271 total
  - (2026-06-04) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-03) [FIRMS] thermal anomaly 45.951, 25.280 (FRP 1.31 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 1.31 MW
  - (2026-06-03) [FIRMS] thermal anomaly 45.950, 25.281 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 1.02 MW
  - (2026-06-03) [FIRMS] thermal anomaly 45.294, 25.111 (FRP 0.79 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 0.79 MW
  - (2026-06-03) [FIRMS] thermal anomaly 44.774, 33.863 (FRP 0.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 0.37 MW
  - (2026-06-03) [FIRMS] thermal anomaly 44.348, 28.659 (FRP 0.57 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 0.57 MW

### U.S. Weather + Severe / Climate Outlooks — 65 new of 81 total
  - (2026-06-04) [Severe] Flood Watch: Flood Watch issued June 4 at 5:35AM CDT until June 4 at 10:00PM CDT by NWS Hastings NE
      * WHAT...Flash flooding caused by excessive rainfall is possible. * WHERE...Portions of north central Kansas, including the following counties, Jewell, Mitchell, Osborne and Smith and south central Nebraska, including th…
  - (2026-06-04) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-04) [Severe] Flood Warning: Flood Warning issued June 4 at 4:45AM CDT until June 5 at 6:00PM CDT by NWS Hastings NE
      ...Forecast flooding changed to Minor severity and increased in duration for the following rivers in Kansas... South Fork Solomon Near Osborne affecting Osborne County. * WHAT...Minor flooding is forecast. * WHERE...Sout…
  - (2026-06-04) [Moderate] Gale Warning: Gale Warning issued June 4 at 2:37AM PDT until June 5 at 9:00AM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 20 to 30 kt with gusts up to 40 kt and seas 7 to 12 ft. * WHERE...Coastal Waters from Point Arena to Point Reyes California out to 10 NM. * WHEN...Until 9 AM PDT Friday. * IMPACTS...Strong winds…
  - (2026-06-04) [Moderate] Gale Warning: Gale Warning issued June 4 at 2:37AM PDT until June 5 at 9:00AM PDT by NWS San Francisco CA
      * WHAT...For the Small Craft Advisory, northwest winds 20 to 25 kt with gusts up to 30 kt and seas 8 to 12 ft. For the Gale Warning, northwest winds 20 to 30 kt with gusts up to 45 kt and seas 10 to 14 ft expected. * WHE…
  - (2026-06-04) [Moderate] Gale Warning: Gale Warning issued June 4 at 2:37AM PDT until June 5 at 3:00AM PDT by NWS San Francisco CA
      * WHAT...For the Small Craft Advisory, northwest winds 20 to 25 kt with gusts up to 30 kt and seas 7 to 11 ft. For the Gale Warning, northwest winds 20 to 30 kt with gusts up to 40 kt and seas 11 to 13 ft expected. * WHE…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-04) 425 - LEGGETT & PLATT INC (0000058492) (Subject)
      filed 2026-06-04 10:35 UTC — Filed: 2026-06-04 AccNo: 0001193125-26-256423 Size: 32 KB
  - (2026-06-04) 424B3 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-04 10:35 UTC — Filed: 2026-06-04 AccNo: 0001918704-26-015601 Size: 1 MB
  - (2026-06-04) 424B3 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-04 10:35 UTC — Filed: 2026-06-04 AccNo: 0001918704-26-015601 Size: 1 MB
  - (2026-06-04) 424B5 - Lucas GC Ltd (0001954694) (Filer)
      filed 2026-06-04 10:25 UTC — Filed: 2026-06-04 AccNo: 0001493152-26-027184 Size: 1 MB
  - (2026-06-04) [Jiang Jun Jason] Form 4 (Reporting)
      filed 2026-06-04 10:23 UTC · role: Reporting — Filed: 2026-06-04 AccNo: 0001213900-26-064996 Size: 6 KB
  - (2026-06-04) [Jinxin Technology Holding Co] Form 4 (Issuer)
      filed 2026-06-04 10:23 UTC · role: Issuer — Filed: 2026-06-04 AccNo: 0001213900-26-064996 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 25 new of 26 total
  - (2026-06-04) JAF9XT (Bulgaria)
      icao24: 4520ce · position: (42.8068, 4.2786) · alt: 10668m · 794km/h
  - (2026-06-04) JAF95J (Bulgaria)
      icao24: 4520aa · position: (48.6312, 0.8394) · alt: 9921m · 660km/h
  - (2026-06-04) CFC2948 (Canada)
      icao24: c2b55d · position: (49.1541, 19.6517) · alt: 7620m · 620km/h
  - (2026-06-04) JAF29J (Belgium)
      icao24: 44d1a5 · position: (43.7512, 15.6794) · alt: 12192m · 724km/h
  - (2026-06-04) JAF5KH (Belgium)
      icao24: 44d1b3 · position: (47.1538, 16.7134) · alt: 12192m · 708km/h
  - (2026-06-04) JAF66H (Belgium)
      icao24: 44d1a2 · position: (31.0931, -13.2838) · alt: 11582m · 754km/h

### U.S. Federal Action — 24 new of 24 total
  - (2026-06-04) Further Adjusting the Tariff Regimes for Imports of Aluminum, Steel, and Copper Into the United States
  - (2026-06-04) Special Local Regulation; Ohio River Mile Marker 90-91, Wheeling, WV
      The Coast Guard is establishing a temporary special local regulation on the waters of the Ohio River from mile marker 90 to mile marker 91 in Wheeling, WV. This action is necessary to provide for the safety of life on th…
  - (2026-06-04) Emergency Relief Program
      FTA is amending its emergency relief regulation to reduce the regulatory burden on grant recipients by extending the baseline period to establish a waiver of certain administrative requirements related to FTA's Public Tr…
  - (2026-06-04) Private Investment Project Procedures
      The Federal Transit Administration (FTA) amends its Private Investment Project Procedures regulation to reduce the regulatory burden on recipients subject to FTA's private investment procedures by removing an unnecessary…
  - (2026-06-04) Project Management Oversight
      This final rule modifies the applicability of project management oversight by raising the total cost and Federal investment thresholds to align with the statutory thresholds for Small Starts projects under FTA's Capital…
  - (2026-06-04) Public Transportation Safety Certification Training Program
      The Federal Transit Administration (FTA) is publishing a final rule amending the reporting requirements for the Public Transportation Safety Certification Training Program (PTSCTP). This final rule reduces reporting burd…

### Paper Trading Scorecard — 22 new of 147 total
  - (2026-06-04) [Polymarket] Will Curaçao win on 2026-06-14?
      In the upcoming game, scheduled for June 14, 2026 If Curaçao wins, this market will resolve to "Yes". Otherwise, this market will resolve to "No". If the game is postponed, this market will remain open until the game has…
  - (2026-06-04) [Polymarket] Will Pamela Evette win the 2026 South Carolina Governor Republican primary election?
      This market will resolve according to the winner of the Republican Primary for Governor of South Carolina, scheduled to take place on June 9, 2026. Resolution will be based on the overall winner of the primary, including…
  - (2026-06-04) [Polymarket] Will the Miami Dolphins win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-06-04) [Polymarket] Will Anthropic or OpenAI IPO first?
      This market will resolve to "Anthropic" if Anthropic completes an Initial Public Offering (IPO) before OpenAI completes an IPO by December 31, 2027, 11:59 PM ET, as confirmed by official company announcements and credibl…
  - (2026-06-04) [Polymarket] Will Bitcoin reach $130,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "High" price equal to or gr…
  - (2026-06-04) [Kalshi] Canadian Team to Win the Stanley Cup® Before the 2031 Season
      Before 2031 season starts

### Macro indicators — latest values (FRED) — 11 new of 21 total
  - (2026-04-01) [Labor] Nonfarm payrolls (PAYEMS)
      latest: 158736 as of 2026-04-01
  - (2026-04-01) [Labor] Job openings (JOLTS) (JTSJOL)
      latest: 7618 as of 2026-04-01
  - (2026-01-01) [Growth] Real GDP (GDPC1)
      latest: 24152.656 as of 2026-01-01
  - (2026-04-01) [Growth] Personal consumption (PCE)
      latest: 21979.4 as of 2026-04-01
  - (2026-05-27) [Money] Fed balance sheet (total assets) (WALCL)
      latest: 6704383 as of 2026-05-27
  - (2026-04-01) [Money] M2 money supply (M2SL)
      latest: 22804.5 as of 2026-04-01

### Court opinions of consequence (federal & state) — 9 new of 60 total
  - (2026-06-03) U.S. Court of Appeals, 1st Cir.: Muchiri v. Blanche
  - (2026-06-03) U.S. Court of Appeals, 7th Cir.: United States v. Maurice Whitesides
  - (2026-06-03) U.S. Court of Appeals, 5th Cir.: Wertenbroch v. Hardeman
  - (2026-06-02) U.S. Court of Appeals, 11th Cir.: Lil' Joe Records, Inc. v. Christopher Won, Jr.
  - (2026-06-02) U.S. Court of Appeals, 11th Cir.: United States v. Terrence Smith
  - (2026-06-01) U.S. Court of Appeals, 11th Cir.: Donald Smith v. Sonya Slott

### USGS earthquakes (M4.5+, past day) — 9 new of 19 total
  - (2026-06-04) M 4.9 - 48 km SW of Santiago de Cao, Peru
      M4.9 · 48 km SW of Santiago de Cao, Peru · depth 78.782 km
  - (2026-06-03) M 4.9 - 72 km SE of Pangai, Tonga
      M4.9 · 72 km SE of Pangai, Tonga · depth 10 km
  - (2026-06-04) M 4.7 - 59 km SSW of Puerto Cortés, Costa Rica
      M4.7 · 59 km SSW of Puerto Cortés, Costa Rica · depth 10 km
  - (2026-06-03) M 4.7 - 12 km NW of Draa Klalouche, Algeria
      M4.7 · 12 km NW of Draa Klalouche, Algeria · depth 10 km
  - (2026-06-04) M 4.6 - Kuril Islands
      M4.6 · Kuril Islands · depth 46.104 km
  - (2026-06-03) M 4.6 - south of the Fiji Islands
      M4.6 · south of the Fiji Islands · depth 588.158 km

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 116 total
  - (2026-06-04) [BIS Entity List] page checksum 7a4d417d8244
      Page content hash: 7a4d417d8244. Compare with prior day's hash to detect updates.
  - (2026-06-04) [USASpending] $2,594,040,000 → FISHER SAND & GRAVEL CO: BORDER BARRIER DESIGN BUILD FOR BBT-5
      Agency: Department of Homeland Security. Description: BORDER BARRIER DESIGN BUILD FOR BBT-5
  - (2026-06-04) [USASpending] $1,554,869,544 → IDAHO ENVIRONMENTAL COALITION LLC: THE PURPOSE OF THIS ACTION IS TO AWARD THE ICP TEN YEAR PLAN
      Agency: Department of Energy. Description: THE PURPOSE OF THIS ACTION IS TO AWARD THE ICP TEN YEAR PLAN HYBRID TASK ORDER UNDER SINGLE AWARD MASTER IDIQ CONTRACT 89303321DEM000061. CLIN 05 S1W D&D IS INCLUDED WITH AUTHOR…
  - (2026-06-04) [USASpending] $1,145,001,057 → SPENCER CONSTRUCTION LLC: BORDER BARRIER CONSTRUCTION
      Agency: Department of Homeland Security. Description: BORDER BARRIER CONSTRUCTION
  - (2026-06-04) [USASpending] $1,030,547,968 → DELL FEDERAL SYSTEMS L.P: MICROSOFT ENTERPRISE AGREEMENT
      Agency: Department of Veterans Affairs. Description: MICROSOFT ENTERPRISE AGREEMENT
  - (2026-06-04) [USASpending] $1,011,653,374 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-06-04) Will Congo DR win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $6,488,237 · resolves 2026-07-20
  - (2026-06-04) Will Algeria win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,614,342 · resolves 2026-07-20
  - (2026-06-04) Will the New York Knicks win the 2026 NBA Finals?
      yes price: 53% · 24h volume: $1,487,760 · resolves 2026-07-01
  - (2026-06-04) Israel announces Lebanon ceasefire extension by June 7?
      yes price: 100% · 24h volume: $1,423,707 · resolves 2026-06-07
  - (2026-06-04) Will Japan win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,038,955 · resolves 2026-07-20
  - (2026-06-04) Will the price of Bitcoin be above $62,000 on June 4?
      yes price: 54% · 24h volume: $1,034,733 · resolves 2026-06-04

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 34 total
  - (2026-06-04) MOVER ▼ Amancio Ortega — $140.52B ($-0.65B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-06-04) MOVER ▲ Bernard Arnault & family — $147.65B (+$0.30B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-06-04) MOVER ▼ Gautam Adani — $87.15B ($-0.15B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-06-04) MOVER ▲ Francoise Bettencourt Meyers & family — $93.91B (+$0.14B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-06-04) [Marginal Revolution] Should we recriminalize marijuana?
      That is the topic of my latest Free Press column. Here is one excerpt: The present and also future of mankind is a world where reasonably high levels of self-discipline are needed to do well. The journalist Daniel Akst p…
  - (2026-06-04) [Marginal Revolution] Law professors prefer AI over peer answers
      Large language models (LLMs) are increasingly promoted as educational tutors, yet most evaluations focus on domains with a single ground truth. Many disciplines, however, hinge on judgment: reasoning, weighing ambiguity,…

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-06-04) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=30, 14d-median=30; carrying terms: proposed, enforcement, public, certain, program, safety, action, captain, coast, provide, authorized, address
- state_bills: today=209, 7d-median=155, 14d-median=155; carrying terms: compliance, felony, within, appropriated, vests, schools, arizona, based, institutions, authorizes, procedures, original
- state_news: today=766, 7d-median=722, 14d-median=722; carrying terms: nonprofit, voters, utilities, appears, prison, livestock, schools, arizona, based, republished, minnesota, proclaims
- local_news: today=227, 7d-median=248, 14d-median=248; carrying terms: google, state, night, region, weather, along, media, sharing, found, south, cbmiqwfbvv, officers
- foreign_news: today=861, 7d-median=861, 14d-median=861; carrying terms: httpsconnection, orbit, christmas, discourage, warned, google, foreign, highlighting, started, prison, nostalgia, schools
- chinese_internal: today=271, 7d-median=271, 14d-median=271; carrying terms: google, lxtfa, cbmizkfvx, cbmibkfvx, cbmixkfvx, title, cbmiykfvx, property, cbmix, cbmiakfvx, cbmickfvx, cbmidefvx
- russian_internal: today=1050, 7d-median=964, 14d-median=1021; carrying terms: gazeta, telegram, group, client, reuters, financial, press, international, politico, axios, centcom, https
- ukrainian_internal: today=121, 7d-median=121, 14d-median=122; carrying terms: found, economic, hromadske, title, independent, vechirniy, president, censor, ukrinform, error, httperror, client
- ukraine_theater: today=271, 7d-median=279, 14d-median=290; carrying terms: cbmiygfbvv, latam, google, mwnenwyld, rghsy, tuzhwudcrjhzmfixt, qkxtyusxx, adfwemd, pmovcwbnjkoeldnvb, vunyqs, schools, cbmimgfbvv
- paper_bets: today=147, 7d-median=144, 14d-median=143; carrying terms: otherwise, approve, carolina, official, leaders, release, polymarket, verve, meets, supervolcano, named, become
- weather: today=81, 7d-median=100, 14d-median=107; carrying terms: messages, lincoln, afdhgx, county, houston, thursday, southwest, synopsis, early, tonight, minor, indicated
- macro: today=21, 7d-median=0, 14d-median=0; carrying terms: spread, unemployment, unrate, funds, treasury, effective, latest, rates, labor, recession, indicator
- markets: today=21, 7d-median=0, 14d-median=0; carrying terms: futures, close, treasury, crude, natural, russell, large, credit, range, commodities, rates, china
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: france, coffee, price, close, italy, mexico, equity, kospi, crude, natural, cotton, nikkei
- sanctions_procurement: today=116, 7d-median=103, 14d-median=101; carrying terms: venezuela, description, google, foreign, hamas, sanctions, claims, schools, combat, measures, management, union
- congressional_trades: today=1, 7d-median=40, 14d-median=1; carrying terms: error, unauthorized, https, quantitative, quiver, congresstrading, client, httperror, quiverquant
- billionaires: today=34, 7d-median=37, 14d-median=37; carrying terms: france, facebook, london, alice, infrastructure, steve, technology, india, google, source, berkshire, peterffy
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=60, 14d-median=30; carrying terms: america, blanche, smith, group, castillo, ortiz, veterans, patria, laureano, general, attorney, collins
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, financial, chase, filer, jpmorgan, subject
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, robert, house, sherrod, ossoff, filing, raised, ocasio, receipts, cycle, talarico, committee
- gdelt_regions: today=0, 7d-median=12, 14d-median=12
- gdelt_gkg: today=146, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=26, 14d-median=15; carrying terms: ground, position, belgium, canada, germany, kingdom, bulgaria, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=12, 7d-median=15, 14d-median=16; carrying terms: premise, trend, vendor, overflow, product, vulnerability, validation, traversal, origin, bypass, drupal, micro
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=127, 7d-median=124, 14d-median=124
- usgs_quakes: today=19, 7d-median=17, 14d-median=17
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, peace, permanent, volume, world, bitcoin, ceasefire, coast, ivory, extension, announces
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: revolution, marginal, class, conversable, economist, https, links, assorted, marginalrevolution, people, paying, effect
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jeffries, balderson, kaptur, higgins, zquez, philip, newhouse, mullin, sarah, rouzer, homeland, yvette
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, either, decision, market, sufficient, converges, module, placed, identify, evidence, paper, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*