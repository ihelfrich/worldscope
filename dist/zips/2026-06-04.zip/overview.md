# WORLDSCOPE morning brief — 2026-06-04

## Headline
2464 new items across 22 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (486) · International News + Multilateral Institutions (445) · World leaders & government officials (324) · State Legislative Action (252) · Chinese Internal News (208) · State-Level News (167) · Local News: St. Louis + Atlanta (119) · Ukrainian Internal News (national + local Kyiv) (107) · Ukraine Theater (total-war monitoring) (94) · U.S. Weather + Severe / Climate Outlooks (67) · GDELT GKG — themes / entities / watch areas (49) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 486 new of 1030 total
  - (2026-06-04) 11 европейских стран потребовали ужесточить выдачу виз россиянам | LEDE: 11 европейских стран призывают Еврокомиссию ввести дополнительные ограничения на выдачу шенгенских виз гражданам Росс] (ru: 11…
      11 европейских стран призывают Еврокомиссию ввести дополнительные ограничения на выдачу шенгенских виз гражданам России. Об этом сообщают Politico, Deutsche Welle и польское издание RMF24. Они ссылаются на письмо, которо…
  - (2026-06-04) К 50-летию Навального вышла аудиоверсия его книги «Патриот». Ее можно послушать бесплатно | LEDE: К 50-летнему юбилею Алексея Навального его мемуары «Патриот» вышли в формате аудиокниги. Ее ] (ru: К 5…
      К 50-летнему юбилею Алексея Навального его мемуары «Патриот» вышли в формате аудиокниги. Ее можно послушать бесплатно на сайте издательства One Book Publishing, рассказала вдова политика Юлия Навальная.
  - (2026-06-04) Германия впервые не смогла получить место временного члена Совбеза ООН. Глава МИД ФРГ обвинил в этом Россию | LEDE: Германия не была избрана непостоянным членом Совета безопасности ООН на 20] (ru: Гер…
      Германия не была избрана непостоянным членом Совета безопасности ООН на 2027-2028 годы, сообщает Deutsche Welle.
  - (2026-06-04) Орешкин призвал россиян не ждать отмены санкций: «Мир как раньше не вернется» | LEDE: России не стоит ждать отмены санкций, заявил на Петербургском экономическом форуме помощник президента М] (ru: Оре…
      России не стоит ждать отмены санкций, заявил на Петербургском экономическом форуме помощник президента Максим Орешкин.
  - (2026-06-04) «Макс» перестал отправлять уведомления на устройства Apple. Накануне мессенджер удалили из App Store | LEDE: На устройства Apple перестали приходить пуш-уведомления о звонках и сообщениях в ] (ru: «Ма…
      На устройства Apple перестали приходить пуш-уведомления о звонках и сообщениях в мессенджере «Макс», сообщила пресс-служба «Макса».
  - (2026-06-04) Немцы уезжают из Германии рекордными темпами. А приток мигрантов сократился вдвое. В стране стало меньше выходцев с Ближнего Востока и из Украины | LEDE: Германия — крупнейшая по населению с] (ru: Нем…
      Германия — крупнейшая по населению страна Евросоюза, которую давно считают одним из главных направлений миграции в ЕС. Она остается на первом месте по количеству жителей, родившихся за границей, но сталкивается с сокраще…

### International News + Multilateral Institutions — 445 new of 789 total
  - (2026-06-04) [Global] Rebel attacks in eastern DRC kill 30 people and hamper Ebola response
  - (2026-06-04) [Global] Japan sees shortage of plastic bags, trays and gloves, as Iran war-induced naphtha shortage worsens
  - (2026-06-04) [Global] Australian woman linked to Islamic State lived with teenage slave who was repeatedly raped, court told
  - (2026-06-04) [Global] Labor’s NDIS overhaul faces delay as Coalition and Greens consider teaming up to slow bill’s passage
  - (2026-06-04) [Global] Husic says Labor pile-on after Aukus criticism ‘not healthy’ – as it happened
  - (2026-06-04) [Global] Dozens of vulnerable children were deemed not at risk by Victoria’s child protection system. They are now dead

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State Legislative Action — 252 new of 252 total
  - (2026-06-04) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…
  - (2026-06-03) [Alaska HB 16] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits for state and local office; direct…
  - (2026-06-03) [Alaska HB 110] HEALTH CARE/LICENSURE COMPACTS/SOCIAL WRK
      HEALTH CARE/LICENSURE COMPACTS/SOCIAL WRK
  - (2026-06-03) [Alaska HB 25] An Act relating to disposable food service ware and containers provided by customers; and providing for an effective date.
      An Act relating to disposable food service ware and containers provided by customers; and providing for an effective date.
  - (2026-06-03) [Alaska HB 48] An Act relating to appropriations to the civil legal services fund.
      An Act relating to appropriations to the civil legal services fund.
  - (2026-06-03) [Alaska HB 39] An Act relating to public school students who are deaf or hard of hearing.
      An Act relating to public school students who are deaf or hard of hearing.

### Chinese Internal News — 208 new of 273 total
  - (2026-06-03) 【商圈】阿贝尔：伯克希尔新掌门与他的调仓术 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1YdGF3MGFRMWV1cDJKQUtyQWZWbWpwWDlpb1Z4ZVNzSEVmeHcyQnc5c1MwYm51Ry0zNzNSOXd0Y1YxU2h] (zh:…
      【商圈】阿贝尔：伯克希尔新掌门与他的调仓术 database.caixin.com
  - (2026-06-03) 鸣谢-2026财新夏季峰会-蓄力创新共谋发展-CAIXIN.COM - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE1qVkVPWlBzVWpDTENuZ19kQTZ3NV9YUnNrQjFlZkVOWWlFU3pRNUVsYk1VRjFHQzlaS3F1aWRiSGhrN013Uzhn] (zh:…
      鸣谢-2026财新夏季峰会-蓄力创新共谋发展-CAIXIN.COM 财新
  - (2026-06-03) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5QdDdoTkIxMjBXYjYzU28yRU5LTXU4YVdXUGZZMmRUMUxFRGFaVV9adXlpNTA3MUtzT2NqZUllTTBCOHJHdm0weXYxUWE2Sl] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-06-04) 教育部：推动录取通知书回归一页纸 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9IZ1hXQ0Zlam5pdU1xbE9waGI4UDZNcGxKanRSUjBIQU81TmtDenZ2cm9EamlKSVh4ZUV5UDh6VFM2UEFOWnNKN1RrRkRsVmIyMTZSV] (zh:…
      教育部：推动录取通知书回归一页纸 财新
  - (2026-06-04) 【商圈】比尔·普尔特：出身房地产、充满争议的美国情报部门新掌门人 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9JeGMzdXNFOHgwYVlMdVkyd0FsT0NGN1A1SGVnNnQ5b2hZUmt3N0xRdDc5bkhfUXIzcmpX] (zh:…
      【商圈】比尔·普尔特：出身房地产、充满争议的美国情报部门新掌门人 database.caixin.com
  - (2026-06-04) 火线评论｜女大学生被家人骗入戒网瘾学校，非法管教何时休？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9RcnRtUUFCOHpLZDljZnhTRERxamt6RV9YTjRPQ1VYOEp6SlVXTzJmRHVfUW5adEJmTHVfbmxqdGJBeGM5UzNZZlVPW] (zh:…
      火线评论｜女大学生被家人骗入戒网瘾学校，非法管教何时休？ 财新

### State-Level News — 167 new of 737 total
  - (2026-06-03) [California] Federal judge orders immigrant detention center to allow San Diego County health inspection
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/03/022026_Padilla-Otay-Mesa_AH_02_CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-06-03) [California] Election denier likely loses job in Shasta County. But voters back hand-counting ballots
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Shasta-County-Election_MH_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-06-03) [California] In a first, California Supreme Court reverses a death sentence under new racial justice law
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/07/050824-Supreme-Court-JF-AP-CM-25.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-06-04) [feed error] AK Governor (Alaska): HTTPError
      403 Client Error: Forbidden for url: https://gov.alaska.gov/feed/
  - (2026-06-04) [Connecticut] Can CT make big debt payments while boosting towns, services?
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/05/DEM-CONVENTION_JH_019-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpri…
  - (2026-06-04) [Connecticut] How CT’s cannabis industry dodged transparency again
      <img width="864" height="576" src="https://ctmirror.org/wp-content/uploads/2026/06/Radura-2.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctmirror.org/wp…

### Local News: St. Louis + Atlanta — 119 new of 227 total
  - (2026-06-04) [St. Louis] Where in the Lou 6/4/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-06-04) [feed error] St. Louis Public Radio (St. Louis): HTTPError
      403 Client Error: Forbidden for url: https://www.stlpr.org/news.rss
  - (2026-06-04) [St. Louis] See the June 4, 1926, front page: No censure of Judge Mix; Grand Jury reports today
      Headlines from the June 4, 1926, front page include: Glider, carrying two, stays in air 9 hours.
  - (2026-06-04) [St. Louis] Webster Groves has money problems, again. Officials say they can reverse trend
      Money, money, money, ain't it funny? It's never too early for a little ABBA, and it's pretty on theme with what we've got in today's newsletter for you. Whether it's money problems, donations or what a trip to the new-ol…
  - (2026-06-04) [St. Louis] SERRA'S 'TWAIN' TO BE RESTORED
      JB Fence & Fabrication Inc. employees gate off Richard Serra's sculpture, "Twain," for renovation on Tuesday, June 2, 2026, in Serra Sculpture Park in downtown St. Louis.
  - (2026-06-04) [St. Louis] '86 47' culture war has come to Kirkwood
      JOE HOLLEMAN

### Ukrainian Internal News (national + local Kyiv) — 107 new of 120 total
  - (2026-06-04) Удар по корвету "Бойкий" у Кронштадті: супутник зафіксував, як росіяни гасять пожежу на кораблі | LEDE: На супутникових знімках, які опублікували "Схеми", видно, як російські пожежники намагают] (uk:…
      На супутникових знімках, які опублікували "Схеми", видно, як російські пожежники намагаються загасити пожежу на корветі "Бойкий" у порту Кронштадта після української атаки.
  - (2026-06-04) У Польщі розбився вертоліт, пілот загинув | LEDE: 4 червня у Польщі знайшли уламки вертольота Robinson R44 Raven II, який вночі зник з радарів, його пілот загинув.] (uk: У Польщі розбився вертоліт, пі…
      4 червня у Польщі знайшли уламки вертольота Robinson R44 Raven II, який вночі зник з радарів, його пілот загинув.
  - (2026-06-04) Чотири роки ховався від правосуддя: затримали експрацівника УЗ, який допомагав окупантам | LEDE: Колишнього працівника воєнізованої охорони "Укрзалізниці", який під час тимчасової окупації Херс] (uk:…
      Колишнього працівника воєнізованої охорони "Укрзалізниці", який під час тимчасової окупації Херсона перейшов на службу до ворога та охороняв вантажі окупаційної влади, затримали в Одесі.
  - (2026-06-04) Сибіга: Відкриваємо нову сторінку в українсько-угорських відносинах | LEDE: Глава МЗС України Андрій Сибіга заявив про відкриття нової сторінки у відносинах з Угорщиною.] (uk: Сибіга: Відкриваємо нову…
      Глава МЗС України Андрій Сибіга заявив про відкриття нової сторінки у відносинах з Угорщиною.
  - (2026-06-04) Захист не для всіх. Як ЄС хоче змінити правила прихистку українців та що чекає на чоловіків | LEDE: ] (uk: Захист не для всіх. Як ЄС хоче змінити правила прихистку українців та що чекає н)
  - (2026-06-04) Через російські обстріли на Донеччині загинули 5 людей | LEDE: Через російські обстріли на Донеччині загинули п'ять людей, ще 11 – зазнали поранень.] (uk: Через російські обстріли на Донеччині загинул…
      Через російські обстріли на Донеччині загинули п'ять людей, ще 11 – зазнали поранень.

### Ukraine Theater (total-war monitoring) — 94 new of 271 total
  - (2026-06-04) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-03) [FIRMS] thermal anomaly 45.951, 25.280 (FRP 1.31 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 1.31 MW
  - (2026-06-03) [FIRMS] thermal anomaly 45.950, 25.281 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 1.02 MW
  - (2026-06-03) [FIRMS] thermal anomaly 45.294, 25.111 (FRP 0.79 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 0.79 MW
  - (2026-06-03) [FIRMS] thermal anomaly 44.774, 33.863 (FRP 0.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 0.37 MW
  - (2026-06-03) [FIRMS] thermal anomaly 44.348, 28.659 (FRP 0.57 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-03 2324Z, FRP 0.57 MW

### U.S. Weather + Severe / Climate Outlooks — 67 new of 84 total
  - (2026-06-04) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-04) [Moderate] Special Weather Statement: Special Weather Statement issued June 4 at 4:25AM CDT by NWS Chicago IL
      Warm conditions, southwest winds gusting as high as 25 mph, and relative humidity falling as low as 25 percent will result in an increased grass and brush fire threat this afternoon. Use extra care with any outdoor activ…
  - (2026-06-04) [Moderate] Rip Current Statement: Rip Current Statement issued June 4 at 5:23AM EDT until June 5 at 4:00AM EDT by NWS Tallahassee FL
      * WHAT...Dangerous rip currents. * WHERE...Walton, Bay, and Franklin County Beaches. * WHEN...Through late tonight. * IMPACTS...Rip currents can sweep even the best swimmers away from shore into deeper water.
  - (2026-06-04) [Moderate] Special Weather Statement: Special Weather Statement issued June 4 at 5:02AM EDT by NWS Grand Rapids MI
      The combination of drying fuels, low relative humidity, and gusty winds will result in elevated fire danger conditions along and north of US-10 today. Southwest winds between 5-15 mph will gust to 20-25 mph this afternoo…
  - (2026-06-04) [Severe] Flood Watch: Flood Watch issued June 4 at 3:54AM CDT until June 5 at 7:00AM CDT by NWS Des Moines IA
      * WHAT...Flash flooding caused by excessive rainfall is possible. * WHERE...Southwest into portions of central Iowa. * WHEN...From this afternoon through Friday morning. * IMPACTS...Excessive runoff may result in floodin…
  - (2026-06-04) [Moderate] Special Weather Statement: Special Weather Statement issued June 4 at 4:46AM EDT by NWS Gaylord MI
      The combination of drying fuels, very low relative humidity values, and increasing southwest winds, will result in elevated fire danger conditions across northern lower Michigan today. Southwest winds will gust to 15 to…

### GDELT GKG — themes / entities / watch areas — 49 new of 49 total
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] Shipping amid geopolitical turmoil : Marinakis ( Capital Group ) on the prospect of Strait of Hormuz tolls
      naftemporiki.gr · English · tone NA
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] Azerbaijani oil moves up in price
      trend.az · English · tone NA
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] Overnight News Digest : June 3 , 2026
      dailykos.com · English · tone NA
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] Chinese firms that help Russia are next for EU sanctions
      politico.eu · English · tone NA
  - (2026-06-04) [Russia oil sanctions perimeter · keywords] The Iran War Is Pushing the Global Gas Trade Into the Shadows
      finance.yahoo.com · English · tone NA
  - (2026-06-04) [Israel-Iran-Hezbollah axis · keywords] Israel and Lebanon Reach Conditional Ceasefire Agreement to Implement Truce
      jowhar.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-04) [ASP Isotopes Inc.] Form 4 (Issuer)
      filed 2026-06-04 01:45 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001477932-26-003633 Size: 11 KB
  - (2026-06-04) [Mann Paul Elliot] Form 4 (Reporting)
      filed 2026-06-04 01:45 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001477932-26-003633 Size: 11 KB
  - (2026-06-04) [WhiteHorse Finance, Inc.] Form 4 (Issuer)
      filed 2026-06-04 01:45 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001104659-26-070273 Size: 12 KB
  - (2026-06-04) [BOLDUC JOHN] Form 4 (Reporting)
      filed 2026-06-04 01:45 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001104659-26-070273 Size: 12 KB
  - (2026-06-04) [Ainscow Robert] Form 4 (Reporting)
      filed 2026-06-04 01:45 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001477932-26-003632 Size: 4 KB
  - (2026-06-04) [ASP Isotopes Inc.] Form 4 (Issuer)
      filed 2026-06-04 01:45 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001477932-26-003632 Size: 4 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 21 new of 97 total
  - (2026-06-04) [Polymarket] Will Pamela Evette win the 2026 South Carolina Governor Republican primary election?
      This market will resolve according to the winner of the Republican Primary for Governor of South Carolina, scheduled to take place on June 9, 2026. Resolution will be based on the overall winner of the primary, including…
  - (2026-06-04) [Polymarket] Will Curaçao win on 2026-06-14?
      In the upcoming game, scheduled for June 14, 2026 If Curaçao wins, this market will resolve to "Yes". Otherwise, this market will resolve to "No". If the game is postponed, this market will remain open until the game has…
  - (2026-06-04) [Polymarket] Will the Miami Dolphins win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-06-04) [Polymarket] Will Anthropic or OpenAI IPO first?
      This market will resolve to "Anthropic" if Anthropic completes an Initial Public Offering (IPO) before OpenAI completes an IPO by December 31, 2027, 11:59 PM ET, as confirmed by official company announcements and credibl…
  - (2026-06-04) [Polymarket] Will Bitcoin reach $130,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "High" price equal to or gr…
  - (2026-06-04) [Kalshi error] HTTPError
      403 Client Error: Forbidden for url: https://api.elections.kalshi.com/trade-api/v2/events?status=open&limit=50

### Macro indicators — latest values (FRED) — 11 new of 21 total
  - (2026-04-01) [Labor] Nonfarm payrolls (PAYEMS)
      latest: 158736 as of 2026-04-01
  - (2026-04-01) [Labor] Job openings (JOLTS) (JTSJOL)
      latest: 7618 as of 2026-04-01
  - (2026-01-01) [Growth] Real GDP (GDPC1)
      latest: 24152.656 as of 2026-01-01
  - (2026-04-01) [Growth] Personal consumption (PCE)
      latest: 21979.4 as of 2026-04-01
  - (2026-05-27) [Money] Fed balance sheet (total assets) (WALCL)
      latest: 6704383 as of 2026-05-27
  - (2026-04-01) [Money] M2 money supply (M2SL)
      latest: 22804.5 as of 2026-04-01

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-06-03) U.S. Court of Appeals, 1st Cir.: Muchiri v. Blanche
  - (2026-06-03) U.S. Court of Appeals, 5th Cir.: Wertenbroch v. Hardeman
  - (2026-06-03) Delaware Supreme Court: Camden Foley v. Session Corp.
  - (2026-06-03) U.S. Court of Appeals, 7th Cir.: United States v. Maurice Whitesides
  - (2026-06-02) U.S. Court of Appeals, 4th Cir.: James Mebane v. GKN Driveline North America, Inc.
  - (2026-06-02) U.S. Court of Appeals, 4th Cir.: United States v. Tyrone Davis

### USGS earthquakes (M4.5+, past day) — 9 new of 20 total
  - (2026-06-04) M 4.9 - 48 km SW of Santiago de Cao, Peru
      M4.9 · 48 km SW of Santiago de Cao, Peru · depth 78.782 km
  - (2026-06-03) M 4.9 - 72 km SE of Pangai, Tonga
      M4.9 · 72 km SE of Pangai, Tonga · depth 10 km
  - (2026-06-04) M 4.7 - 59 km SSW of Puerto Cortés, Costa Rica
      M4.7 · 59 km SSW of Puerto Cortés, Costa Rica · depth 10 km
  - (2026-06-03) M 4.7 - 12 km NW of Draa Klalouche, Algeria
      M4.7 · 12 km NW of Draa Klalouche, Algeria · depth 10 km
  - (2026-06-04) M 4.6 - Kuril Islands
      M4.6 · Kuril Islands · depth 46.104 km
  - (2026-06-03) M 4.6 - south of the Fiji Islands
      M4.6 · south of the Fiji Islands · depth 588.158 km

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 114 total
  - (2026-06-04) [BIS Entity List] page checksum 7a4d417d8244
      Page content hash: 7a4d417d8244. Compare with prior day's hash to detect updates.
  - (2026-06-04) [USASpending] $2,594,040,000 → FISHER SAND & GRAVEL CO: BORDER BARRIER DESIGN BUILD FOR BBT-5
      Agency: Department of Homeland Security. Description: BORDER BARRIER DESIGN BUILD FOR BBT-5
  - (2026-06-04) [USASpending] $1,554,869,544 → IDAHO ENVIRONMENTAL COALITION LLC: THE PURPOSE OF THIS ACTION IS TO AWARD THE ICP TEN YEAR PLAN
      Agency: Department of Energy. Description: THE PURPOSE OF THIS ACTION IS TO AWARD THE ICP TEN YEAR PLAN HYBRID TASK ORDER UNDER SINGLE AWARD MASTER IDIQ CONTRACT 89303321DEM000061. CLIN 05 S1W D&D IS INCLUDED WITH AUTHOR…
  - (2026-06-04) [USASpending] $1,145,001,057 → SPENCER CONSTRUCTION LLC: BORDER BARRIER CONSTRUCTION
      Agency: Department of Homeland Security. Description: BORDER BARRIER CONSTRUCTION
  - (2026-06-04) [USASpending] $1,030,547,968 → DELL FEDERAL SYSTEMS L.P: MICROSOFT ENTERPRISE AGREEMENT
      Agency: Department of Veterans Affairs. Description: MICROSOFT ENTERPRISE AGREEMENT
  - (2026-06-04) [USASpending] $1,011,653,374 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 40 total
  - (2026-06-04) MOVER ▼ Masayoshi Son — $86.49B ($-10.32B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-06-04) MOVER ▲ Bernard Arnault & family — $147.36B (+$3.30B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-06-04) MOVER ▲ Amancio Ortega — $141.16B (+$2.50B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-06-04) MOVER ▲ Francoise Bettencourt Meyers & family — $93.77B (+$0.83B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-06-04) MOVER ▼ Mukesh Ambani — $89.31B ($-0.47B since yesterday)
      India · Diversified · source: Diversified
  - (2026-06-04) MOVER ▲ Gautam Adani — $87.30B (+$0.46B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-06-04) Will Congo DR win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $6,488,237 · resolves 2026-07-20
  - (2026-06-04) Will Algeria win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,618,697 · resolves 2026-07-20
  - (2026-06-04) Will the New York Knicks win the 2026 NBA Finals?
      yes price: 53% · 24h volume: $1,484,959 · resolves 2026-07-01
  - (2026-06-04) Israel announces Lebanon ceasefire extension by June 7?
      yes price: 100% · 24h volume: $1,412,159 · resolves 2026-06-07
  - (2026-06-04) Will Switzerland win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,052,913 · resolves 2026-07-20
  - (2026-06-04) Will Japan win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,036,871 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 2 new of 5 total
  - (2026-06-04) [Marginal Revolution] Should we recriminalize marijuana?
      That is the topic of my latest Free Press column. Here is one excerpt: The present and also future of mankind is a world where reasonably high levels of self-discipline are needed to do well. The journalist Daniel Akst p…
  - (2026-06-04) [Marginal Revolution] Law professors prefer AI over peer answers
      Large language models (LLMs) are increasingly promoted as educational tutors, yet most evaluations focus on domains with a single ground truth. Many disciplines, however, hinge on judgment: reasoning, weighing ambiguity,…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=0, 7d-median=30, 14d-median=30; carrying terms: needed, enforcement, events, public, certain, provide, program, safety, vessels, marine, regulatory, coast
- state_bills: today=252, 7d-median=155, 14d-median=155; carrying terms: legislative, driving, systems, definition, advisory, individual, renaming, beginning, applied, families, agencies, mental
- state_news: today=737, 7d-median=722, 14d-median=722; carrying terms: legislative, power, systems, wants, green, south, vermont, beginning, thursday, families, loading, httperror
- local_news: today=227, 7d-median=248, 14d-median=248; carrying terms: south, families, opening, station, missouri, atlantamagazine, investigators, victim, project, state, stars, magazine
- foreign_news: today=789, 7d-median=844, 14d-median=860; carrying terms: power, match, improper, unbroken, pushes, systems, wants, australian, seeks, advisory, article, green
- chinese_internal: today=273, 7d-median=273, 14d-median=273; carrying terms: lxtfa, cbmizkfvx, rally, target, blank, cbmix, cbmiakfvx, china, articles, title, cbmiykfvx, politics
- russian_internal: today=1030, 7d-median=964, 14d-median=1021; carrying terms: novayagazeta, garros, reuters, client, title, httperror, axios, euroclear, centcom, financial, error, europe
- ukrainian_internal: today=120, 7d-median=120, 14d-median=122; carrying terms: httperror, vechirniy, https, partners, hmarochos, independent, censor, client, error, ukrinform, president, ukraine
- ukraine_theater: today=271, 7d-median=279, 14d-median=290; carrying terms: cwuxgyuk, ntrhym, systems, eywxnhyjfivflkzddkm, tjrxv, wounds, south, kvtnxuwhst, cuxnbk, jkmktzmtdyy, hzsffhova, httperror
- paper_bets: today=97, 7d-median=143, 14d-median=141; carrying terms: models, includes, systems, previousl, december, washington, miami, hampshire, trained, restricting, minnesota, michigan
- weather: today=84, 7d-median=100, 14d-median=107; carrying terms: mendocino, holly, damage, urban, shore, advisory, south, create, miami, thursday, prone, northeast
- macro: today=21, 7d-median=0, 14d-median=0; carrying terms: treasury, labor, effective, unemployment, funds, latest, recession, spread, rates, indicator, unrate
- markets: today=21, 7d-median=0, 14d-median=0; carrying terms: credit, futures, equities, proxy, close, commodities, treasury, corporate, china, yield, large, russell
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: lumber, brazil, commodity, mexico, merval, france, copper, cotton, close, sugar, price, kospi
- sanctions_procurement: today=114, 7d-median=103, 14d-median=101; carrying terms: acronym, comment, aggression, recognition, mission, systems, compare, savannah, south, venezuela, bombing, republic
- congressional_trades: today=49, 7d-median=41, 14d-median=40; carrying terms: asset, excess, purchase, description, taylor, david, package, since, auchincloss, brian, tcnnf, stanton
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: ballmer, meyers, brokerage, infrastructure, ellison, retail, amancio, gcarsoa, china, canada, investments, devasini
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=60, 14d-median=30; carrying terms: america, blanche, smith, group, veterans, castillo, ortiz, collins, gregory, buckley, garcia, coast
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, david, scott, finance, robert, resources, james
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cortez, brown, receipts, michael, raised, lindsey, angels, graham, alexandria, joshua, disbursements, ossoff
- gdelt_regions: today=0, 7d-median=12, 14d-median=12
- gdelt_gkg: today=49, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=15, 14d-median=12; carrying terms: position, ground, belgium, kingdom, germany, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=12, 7d-median=15, 14d-median=16; carrying terms: traversal, vulnerability, origin, vendor, error, premise, authentication, trend, remediation, injection, directory, overflow
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=127, 7d-median=124, 14d-median=124
- usgs_quakes: today=20, 7d-median=17, 14d-median=17
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, permanent, peace, resolves, world, volume, bitcoin, ceasefire, coast, ivory, turkiye, announces
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: class, https, economist, revolution, marginal, conversable, links, marginalrevolution, assorted, paying, people, screen
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: veterans, coons, carol, ilhan, ritchie, tillis, sheri, suozzi, urban, sullivan, newhouse, donald
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, markets, evidence, today, paper, identify, either, module, consensus, unavailable, placed, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*