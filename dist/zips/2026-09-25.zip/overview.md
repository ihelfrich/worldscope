# WORLDSCOPE morning brief — 2026-09-25

## Headline
3313 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (841) · Russian Internal News (state + in-exile) (718) · State-Level News (357) · World leaders & government officials (324) · Chinese Internal News (218) · Local News: St. Louis + Atlanta (201) · U.S. Weather + Severe / Climate Outlooks (155) · State Legislative Action (78) · Ukrainian Internal News (national + local Kyiv) (67) · Ukraine Theater (total-war monitoring) (61) · IT, InfoSys & cybersecurity news (last 7 days) (42) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 841 new of 1091 total
  - (2026-09-24) [Global] Rebel offensive against Ethiopian army stokes fears of return to civil war
  - (2026-09-25) [Global] Hurricane Polo barrels towards Baja California region of Mexico
  - (2026-09-25) [Global] Lula says Trump wants to ‘colonise’ and capture Brazil’s resources by meddling in election
  - (2026-09-24) [Global] Democratic lawmakers accuse Trump administration of interference in Brazilian elections
  - (2026-09-24) [Global] At Trump meeting, Xi Jinping lays out terms to avoid US-China military conflict
  - (2026-09-24) [Global] Trump swoons over strongman soulmate Xi – are you feeling jealous, Vladimir?

### Russian Internal News (state + in-exile) — 718 new of 1123 total
  - (2026-09-25) Политолога Александра Кынева арестовали по делу о наркотиках | LEDE: Перовский суд Москвы 25 сентября арестовал политолога Александра Кынева по делу о наркотиках, сообщает «Медиазона», ссыла] (ru: Пол…
      Перовский суд Москвы 25 сентября арестовал политолога Александра Кынева по делу о наркотиках, сообщает «Медиазона», ссылаясь на данные суда и адвоката Михаила Бирюкова.
  - (2026-09-25) Всегда нездешняя. Умерла Марина Влади. Для европейцев актриса была непостижимой русской, а для советских зрителей — загадочной звездой из Франции, покорившей Высоцкого | LEDE: 24 сентября в ] (ru: Все…
      24 сентября в возрасте 88 лет умерла французская актриса Марина Влади. Она родилась под Парижем в семье русского эмигранта — возможно, именно поэтому в Европе она часто играла героинь с «загадочной русской душой». В Сове…
  - (2026-09-25) «Мамины сказки» — первая книга издательства «Медузы» для детей. Ее написала правозащитница Наталья Эстемирова для своей дочери Ланы. Теперь эти добрые и светлые истории можно прочитать бесплатн] (ru:…
      «Мамины сказки» — это истории, которые когда-то сочиняла для своей маленькой дочери Ланы правозащитница и журналистка Наталья Эстемирова. Эти добрые и светлые сказки мало похожи на то, чем приходилось заниматься Наталье…
  - (2026-09-25) The New York Times выбрала 100 лучших сериалов XXI века. На первом месте — «Во все тяжкие». В двадцатку лучших вошли «Чернобыль» и сразу две версии «Офиса» | LEDE: Газета The New York Times ] (ru: The…
      Газета The New York Times опубликовала рейтинг лучших сериалов XXI века. В его составлении приняли участие более 500 актеров, сценаристов, шоураннеров, продюсеров, других специалистов телеиндустрии — каждый из них назвал…
  - (2026-09-25) С Усманова и Фридмана сняли санкции ЕС. А что, так можно было? И как вообще устроены санкционные правила в Европе? | LEDE: 22 сентября страны Евросоюза договорились исключить из санкционного] (ru: С У…
      22 сентября страны Евросоюза договорились исключить из санкционного списка двух российских миллиардеров — основателя USM Holdings Алишера Усманова и сооснователя «Альфа-групп» Михаила Фридмана.
  - (2026-09-25) Александр Стубб попросил Маска расширить покрытие Starlink для Украины, чтобы она могла бить по пусковым установкам на территории России | LEDE: Президент Финляндии Александр Стубб призвал И] (ru: Але…
      Президент Финляндии Александр Стубб призвал Илона Маска расширить зону покрытия спутникового интернета Starlink, чтобы Украина могла наносить удары по ракетным пусковым установкам на территории России, пишет Reuters.

### State-Level News — 357 new of 778 total
  - (2026-09-24) [Alabama] Governor Ivey Directs Alabama Law Enforcement Agency to Halt Enforcement on Dyed Diesel Fuel to Relieve Agricultural & Timber Communities
      MONTGOMERY – Governor Kay Ivey on Thursday directed the Alabama Law Enforcement Agency (ALEA) to halt its enforcement on dyed diesel fuel for the next 120 days to relieve the state’s agricultural and timber communities.…
  - (2026-09-24) [Alabama] Governor Ivey Calls on Alabamians to Get Out and Enjoy God’s Country, Celebrate National Hunting and Fishing Day and Public Lands Day
      MONTGOMERY – Governor Kay Ivey on Thursday encouraged all Alabamians to celebrate National Hunting and Fishing Day and National Public Lands Day on Saturday, September 26, by participating in outdoor recreation on public…
  - (2026-09-24) [California] Governor Newsom applauds federal film and TV tax credit bill, answering his call to keep production in America
      Source
  - (2026-09-24) [California] NEW: Report shows major progress in California on preparing for wildfire, avoiding millions of tons of carbon pollution and toxic smoke
      Source
  - (2026-09-24) [California] Governor Newsom on the California Supreme Court ruling Sheriff Bianco illegally seized ballots
      Source
  - (2026-09-24) [California] California’s largest new water storage project takes a major step forward
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 218 new of 274 total
  - (2026-09-24) China Weighs Dedicated Law for Regulatory Review System - Caixin Global
      China Weighs Dedicated Law for Regulatory Review System Caixin Global
  - (2026-09-24) 人民币国际化 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTFBob2JSLWIxdG9GczJkbGpGZEdDZEhwaXZDSjdUaU9neThoTGp1c2R2Y3UzcWtFRkx4R2dpaWpMYzdoWEVfcHlSdjlOUDVxel] (zh:…
      人民币国际化 deepview.caixin.com
  - (2026-09-24) 化债 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE0tSzkxdHFxdUgwQkRPZnZYMGpObU82QmtNOHBpSDVWak83TzcwMUdlTXowN0cyR3VTWS1YT0F5a2xtQXB5dndObmJZUTJhU2VnQj] (zh:…
      化债 deepview.caixin.com
  - (2026-09-23) 无人出租车 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE94Yi1qb1Bwcl91SVhJUzROand6NWNrVFhOWUsyRExRWUNyNnVkWS15VzM1RC1Zby0xVnZVQVNxSHdPa2dMc1ROX1BvMENsV3B] (zh:…
      无人出租车 deepview.caixin.com
  - (2026-09-24) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE52TVlGYXBMS01LVGo1RE9fbzNqWmV4SllWTWcxU1A2QmtGMmV1TTJRTlhjWUhlNjBhWm5vNzFyQjd1YlNLM1BsQ3N4ek1ia2] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-09-23) 习近平抵达华盛顿开始对美国事访问 特朗普到场迎接 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1MYUVmREt6eWprOFhWRlNpckg2LVpac1FIMklmMVBueUIyenByek5rcUs1Y0x2T1FGcE5vZzdIMEpvZDNSXzl3X1k3UENnV] (zh:…
      习近平抵达华盛顿开始对美国事访问 特朗普到场迎接 财新

### Local News: St. Louis + Atlanta — 201 new of 227 total
  - (2026-09-25) [St. Louis] Coffeestamp opens location in downtown St. Louis
      When Patrick Clapp thinks about all of the other places that he and his brother, Spencer, could have opened Coffeestamp‘s second brick-and-mortar location, he couldn’t be more thrilled that they chose downtown St. Louis.…
  - (2026-09-25) [St. Louis] St. Charles has Germany to thank for its new sister city in France
      The city of St. Charles has been looking for a sister in France for nearly as long as it has had one in Germany: 30 years. Now, as St. Charles officially signs its sister city agreement with Montbéliard, France, on Frida…
  - (2026-09-25) [St. Louis] What’s True in the Lou? – 9/25/26
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-09-25) [St. Louis] Where in St Charles 9/25/2026
      Let’s see how well you know St. Charles. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess”…
  - (2026-09-24) [St. Louis] Snoopy, Charlie Brown, and friends take over The Magic House beginning this weekend
      Good grief. There’s a new reason to visit The Magic House (516 S. Kirkwood) this fall. Beginning September 26, St. Louis families can step inside the world of Charlie Brown, Snoopy, and the rest of the gang with Take Car…
  - (2026-09-24) [St. Louis] UMSL revamps campus dining with local flavors and made-to-order options
      The University of Missouri–St. Louis has partnered with Quest Food Management Services to revamp the school’s dining services. The partnership seeks to address past student concerns while introducing made-to-order concep…

### U.S. Weather + Severe / Climate Outlooks — 155 new of 156 total
  - (2026-09-25) [Severe] Flood Warning: Flood Warning issued September 25 at 6:28AM MDT until September 25 at 6:30AM MDT by NWS El Paso Tx/Santa Teresa NM
      The Flood Warning will expire at 630 AM MDT this morning for a portion of western Texas, including the following areas, El Paso and Hudspeth. Flood waters have receded. Flooding is no longer expected to pose a threat. Pl…
  - (2026-09-25) [Severe] Coastal Flood Warning: Coastal Flood Warning issued September 25 at 4:26AM AKDT until September 26 at 4:00AM AKDT by NWS Anchorage AK
      * WHAT...Water levels on average of 1.5 to 2.5 feet above the normal highest tide line. Southeast winds becoming south winds 30 to 40 mph with gusts to 50 mph. * WHERE...Kuskokwim Delta Coast including Kwigillingok and K…
  - (2026-09-25) [Moderate] Gale Warning: Gale Warning issued September 25 at 8:25AM EDT until September 27 at 8:00PM EDT by NWS Caribou ME
      * WHAT...Northeast winds 25 to 35 kt with gusts up to 45 kt and seas 10 to 15 ft expected. * WHERE...Waters from Eastport ME to Schoodic Point ME from 25 to 60 NM or the Hague Line and Waters from Schoodic Point ME to St…
  - (2026-09-25) [Moderate] Gale Warning: Gale Warning issued September 25 at 8:25AM EDT until September 27 at 8:00PM EDT by NWS Caribou ME
      * WHAT...Northeast winds 20 to 30 kt with gusts up to 40 kt and seas 7 to 10 ft expected. * WHERE...Coastal Waters from Eastport, ME to Schoodic Point, ME out 25 NM and Coastal Waters from Schoodic Point, ME to Stoningto…
  - (2026-09-25) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-25) [Severe] Storm Warning: Storm Warning issued September 25 at 8:13AM EDT until September 26 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...North winds 35 to 40 kt with gusts up to 50 kt and seas 10 to 15 ft. * WHERE...Coastal waters from Fenwick Island DE to Chincoteague VA out 20 NM and Coastal waters from Chincoteague to Parramore Island VA out 2…

### State Legislative Action — 78 new of 120 total
  - (2026-09-25) [Alaska HB 250] An Act establishing the crime of wearing a mask in public while acting as a peace officer; and providing for an effective date.
      An Act establishing the crime of wearing a mask in public while acting as a peace officer; and providing for an effective date.
  - (2026-09-25) [Alaska HJR 23] Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
      Proposing an amendment to the Constitution of the State of Alaska requiring the governor to submit a balanced budget to the legislature.
  - (2026-09-25) [Alaska HB 130] An Act relating to flexible time credit for classified employees in the executive branch who are not eligible for overtime compensation.
      An Act relating to flexible time credit for classified employees in the executive branch who are not eligible for overtime compensation.
  - (2026-09-25) [Alaska SB 282] An Act relating to the Joint Armed Services Committee; and providing for an effective date.
      An Act relating to the Joint Armed Services Committee; and providing for an effective date.
  - (2026-09-25) [Alaska HCR 10] Proposing an amendment to the Uniform Rules of the Alaska State Legislature relating to resolutions.
      Proposing an amendment to the Uniform Rules of the Alaska State Legislature relating to resolutions.
  - (2026-09-25) [Alaska HB 301] An Act relating to and prohibiting discrimination based on sexual orientation or gender identity or expression.
      An Act relating to and prohibiting discrimination based on sexual orientation or gender identity or expression.

### Ukrainian Internal News (national + local Kyiv) — 67 new of 139 total
  - (2026-09-25) Російський дрон упав у Києві: загинули 3 людини, зайнялась офісна будівля | LEDE: В результаті денної атаки російських дронів по Києву пошкоджень зазнала офісна будівля в Соломʼянському районі,] (uk:…
      В результаті денної атаки російських дронів по Києву пошкоджень зазнала офісна будівля в Соломʼянському районі, є потерпілі.
  - (2026-09-25) У Зеленського заперечили, що домовлялись з Сеулом не розкривати передачу полонених з КНДР | LEDE: Радник Зеленського Дмитро Литвин заявив, що Україна не порушувала угоди про нерозголошення щодо] (uk:…
      Радник Зеленського Дмитро Литвин заявив, що Україна не порушувала угоди про нерозголошення щодо передачі військовополонених КНДР Південній Кореї.
  - (2026-09-25) Напад на монастир у Польщі: українцю підготували обвинувачення, він ще в лікарні | LEDE: Польська прокуратура сформулювала обвинувачення щодо 31-річного українця Ігоря М. у вбивстві, замаху на ] (uk:…
      Польська прокуратура сформулювала обвинувачення щодо 31-річного українця Ігоря М. у вбивстві, замаху на вбивство та заподіянні тяжких тілесних ушкоджень після нападу в абатстві сестер-бенедиктинок у Ярославі.
  - (2026-09-25) Глава МВА: В Олешки продукти не завозились з кінця травня, люди почали їсти собак | LEDE: Голова Олешківської міської військової адміністрації Тетяна Гасаненко розповіла, що у місто Олешки офіц] (uk:…
      Голова Олешківської міської військової адміністрації Тетяна Гасаненко розповіла, що у місто Олешки офіційно востаннє завозили продукти 26 травня. Наразі є випадки, коли в окремих сім'ях їдять собак.
  - (2026-09-25) Переважно без опадів, тумани і до +22° – прогноз погоди на вихідні | LEDE: Найближчими днями в Україні без істотних опадів, 27 вересня дощі на сході, а 28 вересня – на півдні та південному сход] (uk:…
      Найближчими днями в Україні без істотних опадів, 27 вересня дощі на сході, а 28 вересня – на півдні та південному сході, вдень до 22° тепла.
  - (2026-09-25) В ЄС обговорять, хто поступиться своєю чергою Україні на ракети до Patriot – джерело | LEDE: Країни ЄС можуть обміняти свої замовлення на перехоплювачі Patriot на користь України. Рішення розгл] (uk:…
      Країни ЄС можуть обміняти свої замовлення на перехоплювачі Patriot на користь України. Рішення розглядається 28 вересня у Брюсселі.

### Ukraine Theater (total-war monitoring) — 61 new of 352 total
  - (2026-09-25) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-24) [FIRMS] thermal anomaly 44.316, 23.370 (FRP 5.33 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-24 1051Z, FRP 5.33 MW
  - (2026-09-24) [FIRMS] thermal anomaly 44.244, 22.822 (FRP 9.44 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-24 1051Z, FRP 9.44 MW
  - (2026-09-24) [FIRMS] thermal anomaly 44.243, 22.816 (FRP 7.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-24 1051Z, FRP 7.74 MW
  - (2026-09-24) [FIRMS] thermal anomaly 44.242, 22.822 (FRP 5.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-24 1051Z, FRP 5.53 MW
  - (2026-09-24) [FIRMS] thermal anomaly 44.241, 22.815 (FRP 5.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-24 1051Z, FRP 5.53 MW

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 56 total
  - (2026-09-25) [BleepingComputer] Rydox marketplace admin pleads guilty, faces 22 years in prison
      A Kosovar national has pleaded guilty to operating Rydox, a large illegal online marketplace that sold stolen personal information, login credentials, credit card details, and cybercrime tools. [...]
  - (2026-09-25) [BleepingComputer] Microsoft: Recent Windows updates cause desktop loading issues
      Microsoft has confirmed that some users may experience desktop loading issues, including black screens, after installing the August 2026 preview updates and subsequent updates. [...]
  - (2026-09-25) [BleepingComputer] Hackers steal $351.6 million in Bitget crypto exchange hack
      ​Cryptocurrency exchange Bitget disclosed today that suspected North Korean hackers have stolen $351.6 million from its hot and warm wallets. [...]
  - (2026-09-25) [The Hacker News] Bitget Says Suspected North Korean Hackers Stole $351.6M After Backend Compromise
      Cryptocurrency exchange Bitget said suspected North Korean threat actors have stolen $351.6 million from its hot and warm wallets. "At 18:31 UTC on September 24, 2026, Bitget's security systems identified unauthorized tr…
  - (2026-09-25) [The Hacker News] Roundcube Pre-Auth SQL Injection Flaw Actively Exploited in the Wild
      The Canadian Centre for Cyber Security has warned that a now-patched Roundcube Webmail vulnerability is being actively exploited in the wild. The vulnerability in question is CVE-2026-48842 (CVSS score: 8.1), a pre-authe…
  - (2026-09-25) [The Hacker News] Cloudflare Fixes Flaw That Let One Container Read Another Customer's Leftover Disk Data
      A flaw in Cloudflare Containers let a paying customer read data that other customers' containers had left behind on the same server, Cloudflare and the researchers who found it said on Thursday. The data came from disk s…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-25) 497 - VIRTUS ASSET TRUST (0001018593) (Filer)
      filed 2026-09-25 12:27 UTC — Filed: 2026-09-25 AccNo: 0000930413-26-002987 Size: 644 KB
  - (2026-09-25) 497 - NYLIM FUNDS (0000787441) (Filer)
      filed 2026-09-25 12:26 UTC — Filed: 2026-09-25 AccNo: 0000787441-26-000076 Size: 312 KB
  - (2026-09-25) 497 - NYLIM FUNDS (0000787441) (Filer)
      filed 2026-09-25 12:26 UTC — Filed: 2026-09-25 AccNo: 0000787441-26-000075 Size: 313 KB
  - (2026-09-25) [Meldgaard Jacob Balslev] Form 4 (Reporting)
      filed 2026-09-25 12:26 UTC · role: Reporting — Filed: 2026-09-25 AccNo: 0000919574-26-006476 Size: 7 KB
  - (2026-09-25) [TORM plc] Form 4 (Issuer)
      filed 2026-09-25 12:26 UTC · role: Issuer — Filed: 2026-09-25 AccNo: 0000919574-26-006476 Size: 7 KB
  - (2026-09-25) 497 - NYLIM FUNDS TRUST (0001469192) (Filer)
      filed 2026-09-25 12:26 UTC — Filed: 2026-09-25 AccNo: 0001469192-26-000204 Size: 319 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-25) [United States] CVS Group H2 Earnings Call Highlights
      domain: themarketsdaily.com · language: English · tone:
  - (2026-09-25) [United Kingdom] National Highways criticised for chao of Cornwall A30 work
      domain: falmouthpacket.co.uk · language: English · tone:
  - (2026-09-25) [United Kingdom] Explosion causes building to collapse near Acropolis
      domain: theargus.co.uk · language: English · tone:
  - (2026-09-25) [United States] Elisam CombiGrader : One Smart Grading Solution for Potatoes and Onions
      domain: potatopro.com · language: English · tone:
  - (2026-09-25) [Ireland] Attention children of Mayo : Last chance to apply for Late Late Toy Show
      domain: con-telegraph.ie · language: English · tone:
  - (2026-09-25) [India] Iran proposes seven - day roadmap to reopen Strait of Hormuz
      domain: siasat.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-25) JAF50T (Bulgaria)
      icao24: 4520ce · position: (39.8835, -2.9807) · alt: 11277m · 821km/h
  - (2026-09-25) PAT590 (United States)
      icao24: adfeda · position: (39.6608, -79.896) · alt: 7901m · 517km/h
  - (2026-09-25) CFC3102 (Canada)
      icao24: c2b373 · position: (45.1513, -75.6512) · alt: 3893m · 633km/h
  - (2026-09-25) PAT040 (United States)
      icao24: adfe4c · position: (38.2159, -86.3235) · alt: 5029m · 358km/h
  - (2026-09-25) SAMU44 (France)
      icao24: 39ca84 · position: (47.4925, -0.9779) · alt: 457m · 220km/h
  - (2026-09-25) JEDI07 (United States)
      icao24: adff0b · position: (30.4169, -87.862) · alt: 3947m · 431km/h

### U.S. Federal Action — 24 new of 24 total
  - (2026-09-25) National Wildlife Refuge System; 2026-2027 Station-Specific Hunting and Sport Fishing Regulations; Correction
      We, the U.S. Fish and Wildlife Service (FWS or Service), are correcting a final rule that appeared in the Federal Register on September 1, 2026. The rule opened or expanded hunting opportunities on 111 field stations, in…
  - (2026-09-25) IFR Altitudes; Miscellaneous Amendments
      This amendment adopts miscellaneous amendments to the required IFR (instrument flight rules) altitudes and changeover points for certain Federal airways, jet routes, or direct routes for which a minimum or maximum en-rou…
  - (2026-09-25) National Environmental Policy Act Implementing Procedures
      The United States Postal Service (USPS) is publishing this interim final rule with request for comments to partially rescind and update its remaining National Environmental Policy Act (NEPA) implementing procedures, whic…
  - (2026-09-25) Modernization of Regulations Under 9 CFR Parts 101-118 and 123-124; Extension of Comment Period
      The U.S. Department of Agriculture (USDA) is extending the public comment period by 20 days on its Request for Information (RFI) to solicit the public's input on regulatory considerations related to 9 CFR parts 101-118,…
  - (2026-09-25) Amendment of Class E Airspace; Del Rio, TX
      This action proposes to amend the Class E airspace at Del Rio, TX. The FAA is proposing this action as the result of a biennial review of the airspace associated with Laughlin Air Force Base (AFB), Del Rio, TX. This prop…
  - (2026-09-25) Driving Efficiency in Farm Loan Delivery; Correction
      The Farm Service Agency (FSA) is issuing a correction to a final rule published in the Federal Register on September 4, 2026, which will be effective October 1, 2026. The final rule amended FSA's Farm Loan Program (FLP)…

### Court opinions of consequence (federal & state) — 21 new of 60 total
  - (2026-09-29) Connecticut Supreme Court: State v. Jose T.
  - (2026-09-24) D.C. Court of Appeals: Faltz v. United States
  - (2026-09-24) D.C. Court of Appeals: In re Toliver
  - (2026-09-24) D.C. Court of Appeals: Rezene v. United States
  - (2026-09-24) Supreme Court of California: Bonta v. Bianco
  - (2026-09-24) Supreme Court of California: Cervantes v. Bianco

### Government Action: Sanctions + Procurement + Foreign Agents — 20 new of 104 total
  - (2026-09-24) [OFAC] Publication of Regulatory Amendments; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) - Office of Foreign Asse…
      Publication of Regulatory Amendments; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) Office of Foreign Assets Control (.gov)
  - (2026-09-24) [OFAC] BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 505 Sanctions Penalties Regulations - Office of Foreign Assets Control (.gov)
      BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 505 Sanctions Penalties Regulations Office of Foreign Assets Control (.gov)
  - (2026-09-23) [OFAC] Democratic Republic of the Congo-related Designations Removals - Office of Foreign Assets Control (.gov)
      Democratic Republic of the Congo-related Designations Removals Office of Foreign Assets Control (.gov)
  - (2026-09-18) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-09-18) [OFAC] Russian Harmful Foreign Activities Sanctions - Office of Foreign Assets Control (.gov)
      Russian Harmful Foreign Activities Sanctions Office of Foreign Assets Control (.gov)
  - (2026-09-19) [OFAC] Sanctions Programs Atlas - Office of Foreign Assets Control (.gov)
      Sanctions Programs Atlas Office of Foreign Assets Control (.gov)

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-09-25) Korea Open: Katie Volynets vs Kimberly Birrell
      yes price: 32% · 24h volume: $616,024 · resolves 2026-10-02
  - (2026-09-25) Singapore Open: Mirra Andreeva vs Leylah Fernandez
      yes price: 0% · 24h volume: $567,310 · resolves 2026-10-02
  - (2026-09-25) Will Mitch Landrieu win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $567,076 · resolves 2028-11-07
  - (2026-09-25) Will Brazil win on 2026-09-25?
      yes price: 0% · 24h volume: $542,796 · resolves 2026-09-25
  - (2026-09-25) Dota 2: GamerLegion vs 1win - Game 2 Winner
      yes price: 76% · 24h volume: $428,494 · resolves 2026-09-25
  - (2026-09-25) Strait of Hormuz traffic returns to normal by September 30?
      yes price: 0% · 24h volume: $411,534 · resolves 2026-10-01

### Paper Trading Scorecard — 11 new of 124 total
  - (2026-09-25) [Manifold] Before 2040 will most of the historical anthropic slack be made public
  - (2026-09-25) [Manifold] Will the US ban diesel exports before Election Day?
  - (2026-09-25) [Manifold] Will Phil Scott win the 2026 Vermont Gubernatorial Election?
  - (2026-09-25) [Manifold] Will Kimi Antonelli win the 2026 F1 Championship?
  - (2026-09-25) [Manifold] Will Lego release a record breaking Largest Set (by number of pieces) before EOY 2027?
  - (2026-09-25) [Manifold] Will India have a Michelin Star restaurant by the end of 2028?

### USGS earthquakes (M4.5+, past day) — 10 new of 10 total
  - (2026-09-25) M 5.3 - Vanuatu region
      M5.3 · Vanuatu region · depth 23.966 km
  - (2026-09-24) M 5.3 - 72 km NW of Finschhafen, Papua New Guinea
      M5.3 · 72 km NW of Finschhafen, Papua New Guinea · depth 53.586 km
  - (2026-09-24) M 5.1 - 32 km S of Kokopo, Papua New Guinea
      M5.1 · 32 km S of Kokopo, Papua New Guinea · depth 93.994 km
  - (2026-09-25) M 5.0 - 124 km N of Metinaro, Timor Leste
      M5.0 · 124 km N of Metinaro, Timor Leste · depth 10 km
  - (2026-09-24) M 4.9 - Kermadec Islands, New Zealand
      M4.9 · Kermadec Islands, New Zealand · depth 48.811 km
  - (2026-09-24) M 4.6 - 155 km NW of Ternate, Indonesia
      M4.6 · 155 km NW of Ternate, Indonesia · depth 48.469 km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-25) [Marginal Revolution] *My Dreadful Body*
      By Egana Djabbarova of Azerbaijan. A wonderful short novel, and as described by Olga Grjasnowa “An extraordinary novel that translates corporality and estrangement into language.” Here is the Amazon link. This has been a…
  - (2026-09-25) [Marginal Revolution] Armenia notes
      I strongly recommend a trip to Armenia, now is a great time to go. Here are a few things I noticed: 1. The country remains intellectual. The book fair is well attended. The classical music season is excellent, with good…
  - (2026-09-24) [Marginal Revolution] Peter Thiel on AI and tech stagnation and democracy
      Lots of fresh material, one of the very best Peter Thiel outputs. The post Peter Thiel on AI and tech stagnation and democracy appeared first on Marginal REVOLUTION.
  - (2026-09-24) [Conversable Economist] A US Federal Budget Chartbook
      For some people, their pulse beats faster when their favorite sports team wins, or their favorite musician drops a new album. For others, pulse and respiration accelerate when confronted with “Spending, Taxes, and Defici…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-09-24) CVE-2026-5430 · WSO2 Multiple Products: WSO2 Multiple Products Path Traversal Vulnerability
      vendor: WSO2 · product: Multiple Products · CISA remediation by 2026-09-27
  - (2026-09-24) CVE-2026-71362 · Adobe Commerce and Magento : Adobe Commerce and Magento Incorrect Authorization Vulnerability
      vendor: Adobe · product: Commerce and Magento · CISA remediation by 2026-09-27

### EPSS — highest exploit-probability CVEs — 2 new of 40 total
  - (2026-09-24) CVE-2024-7593: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-09-24) CVE-2022-22954: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=19, 14d-median=19; carrying terms: certain, establishing, state, program, final, public, proposed, proposes, proposing, regulatory, specifically, navigable
- state_bills: today=120, 7d-median=120, 14d-median=105; carrying terms: commission, legislative, establishes, peace, projects, training, required, activities, resources, instead, including, development
- state_news: today=778, 7d-median=683, 14d-median=754; carrying terms: scaled, issued, commission, projects, elections, seeking, staff, asked, market, summer, inside, concern
- local_news: today=227, 7d-median=227, 14d-median=236; carrying terms: https, shooting, death, police, arrested, state, falcons, fulton, according, community, atlantamagazine, years
- foreign_news: today=1091, 7d-median=1045, 14d-median=994; carrying terms: kingdom, wants, killing, issued, quarterly, elections, seeking, staff, european, market, delhi, facing
- chinese_internal: today=274, 7d-median=271, 14d-median=280; carrying terms: lxtfa, cbmiaefvx, target, cbmix, cbmic, cbmiykfvx, cbmickfvx, cbmiakfvx, cbmibefvx, china, cbmigwfbvv, people
- russian_internal: today=1123, 7d-median=1067, 14d-median=1067; carrying terms: server, europe, politico, httperror, novaya, error, media, https, client, openai, forbidden, ukraina
- ukrainian_internal: today=139, 7d-median=135, 14d-median=136; carrying terms: killing, cabinet, national, reportedly, https, peace, elections, european, infrastructure, latest, august, prime
- ukraine_theater: today=352, 7d-median=426, 14d-median=426; carrying terms: swvnrvaxtdz, wjhsr, oumhmdghidgdva, wzoeqwumh, cbmirefvx, staff, volunteers, lahrolxnjv, latest, defence, dtqujwrkrhluhfqljnq, ilwttethdewnsmkszoedmz
- paper_bets: today=124, 7d-median=125, 14d-median=128; carrying terms: industrial, israel, miles, zohran, prize, maine, mamdani, problem, human, humans, earthquake, mbappe
- weather: today=156, 7d-median=127, 14d-median=117; carrying terms: ruskin, moderate, creeks, national, afdmtr, issued, temperatures, gusty, afternoon, seattle, boston, continues
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: openings, energy, rates, recession, dexuseu, payrolls, money, funds, effective, cpiaucsl, dcoilwtico, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, china, russell, nasdaq, range, large, close, silver, rates, agriculture, bitcoin, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=105, 14d-median=107; carrying terms: moldova, cbmizefvx, african, https, adopted, groups, zimbabwe, legislation, support, asked, transnistrian, undermining
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, congresstrading, client, quantitative, error, unauthorized, httperror, quiverquant, quiver
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: arizona, court, appeals, state, supreme, delaware, company, trade, international, texas, association, jeremy
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, holdings, filer, trust, tidal, therapeutics, technologies, scott, offer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: krishnamoorthi, cycle, ossoff, jonathan, warner, johnson, david, cooper, booker, sherrod, receipts, cortez
- gdelt_regions: today=0, 7d-median=0, 14d-median=6; carrying terms: english
- gdelt_gkg: today=0, 7d-median=60, 14d-median=60; carrying terms: chinese, sanctions, english, themes, spanish, vietnamese, french, german, radio, world, polish, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: kingdom, english, australia, trump, domain, found, state, language, india
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, germany, kingdom, ground, france, bulgaria, canada, kuwait, samuidf
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: netherlands, clade, senegal, kingdom, faster, centers, influenza, fatality, posting, kasai, ethiopian, african
- cisa_kev: today=18, 7d-median=21, 14d-median=21; carrying terms: management, jfrog, product, authentication, engine, secure, cisco, vulnerability, missing, bounds, products, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=10, 7d-median=14, 14d-median=13; carrying terms: depth, indonesia, islands, colombia, vanuatu, region, papua, puerto, guinea, zealand, kermadec, mexico
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, rates, league, champions, donetsk, interest, shakhtar, championship, meeting, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, class, https, revolution, conversable, conversableeconomist, economist, report, marginalrevolution, global, world, review
- tech_news: today=56, 7d-median=56, 14d-median=57; carrying terms: companies, weekday, artificial, https, company, openai, infrastructure, spectrum, schneier, including, techcrunch, security
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: ilhan, quigley, wyden, duffy, perez, griffith, kaptur, cornyn, david, jamie, loudermilk, national
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, sufficient, claude, consensus, either, placed, placement, unavailable, market, module, identify, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-21] ECB press: ECB to invest part of own funds in tokenised securities, with settlement via Pontes
- [2026-09-21] ECB press: Eurosystem brings central bank money to tokenised finance
- [2026-09-22] ECB press: Philip R. Lane: Interview with Le Temps
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-23] ECB press: Almost ten million people took part in ECB survey on new euro banknotes
- [2026-09-23] Fed speeches: Barr, A Long-Term View on the Costs of Shelter
- [2026-09-23] ECB press: The digitalisation of money, payments and finance
- [2026-09-23] ECB press: Philip R. Lane: The Outlook for the Euro Area Economy
- [2026-09-24] ECB press: Philip R. Lane: The outlook for the euro area economy
- [2026-09-24] ECB press: ECB Executive Board member Isabel Schnabel to resign to take senior role at IMF

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*