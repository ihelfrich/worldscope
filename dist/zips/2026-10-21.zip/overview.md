# WORLDSCOPE morning brief — 2026-10-21

## Headline
3364 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (822) · Russian Internal News (state + in-exile) (514) · State-Level News (401) · World leaders & government officials (324) · Chinese Internal News (234) · Local News: St. Louis + Atlanta (207) · Ukraine Theater (total-war monitoring) (169) · U.S. Weather + Severe / Climate Outlooks (113) · State Legislative Action (90) · GDACS — global disaster alerts (85) · Ukrainian Internal News (national + local Kyiv) (71) · GDELT GKG — themes / entities / watch areas (50)

## What changed today
### International News + Multilateral Institutions — 822 new of 1027 total
  - (2026-10-21) [Global] Nigeria confirms Ebola case as outbreak spreads into western Africa
  - (2026-10-20) [Global] RFK Jr’s ‘deities of vaccine research’ raided by police in Guinea-Bissau
  - (2026-10-20) [Global] Alberta voters overwhelmingly reject plan to leave Canada in referendum
  - (2026-10-20) [Global] ‘Bad decisions’: Man convicted for taking Peachy the flamingo from Las Vegas hotel
  - (2026-10-20) [Global] Flavio Bolsonaro’s ‘corrupto’ stunt sparks viral meme before Brazil election runoff
  - (2026-10-20) [Global] Giving £2 a day to people in the Amazon helps protect rainforest, pilot project finds

### Russian Internal News (state + in-exile) — 514 new of 598 total
  - (2026-10-21) Верховный суд разрешил россиянину не возвращать ребенка матери во Францию. Среди аргументов судей — это «недружественная» страна | LEDE: Верховный суд России разрешил россиянину не возвращат] (ru: Вер…
      Верховный суд России разрешил россиянину не возвращать свою дочь ее матери, которая живет во Франции, несмотря на то, что он вывез ребенка в РФ без разрешения. Об этом пишет «Коммерсант».
  - (2026-10-21) Издательству «Медузы» — три года! Дарим вам скидки, наклейки и книгу. Теперь «Когда мы поём, поднимается ветер», исследование Александра Горбачева о музыке XXI века, можно бесплатно прочесть в ] (ru:…
      Это очень важные для нас цифры. Расшифровываем: ровно 3 года назад мы запустили издательство «Медузы», 33 бумажных, 26 электронных и 4 аудиокниги успели выпустить за это время. И наконец, 29 — столько книг можно бесплатн…
  - (2026-10-21) Один день Александра Исаевича: с набережной во Владивостоке сперва убрали памятник Солженицыну, а потом тут же вернули обратно. Цепочка фотографий | LEDE: . ] (ru: Один день Александра Исаевича: с наб…
      .
  - (2026-10-21) Война. 1701-й день. Переговоры Путина и Уиткоффа в Петербурге. Спецпосланник США привез новый план завершения войны | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о росс] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-21) Вице-премьер Новак анонсировал отправку первой партии российского дизеля в США | LEDE: Отправка первой партии дизельного топлива из России в США планируется в четверг, 22 октября, объявил ви] (ru: Виц…
      Отправка первой партии дизельного топлива из России в США планируется в четверг, 22 октября, объявил вице-премьер РФ Александр Новак.
  - (2026-10-21) Путин освободил гражданина США Стивена Хаббарда, воевавшего на стороне ВСУ | LEDE: Гражданин США Стивен Хаббард, воевавший на стороне ВСУ и осужденный российским судом за наемничество, освоб] (ru: Пут…
      Гражданин США Стивен Хаббард, воевавший на стороне ВСУ и осужденный российским судом за наемничество, освобожден, заявил президент РФ Владимир Путин в начале встречи со спецпосланником президента США Стивом Уиткоффом.

### State-Level News — 401 new of 734 total
  - (2026-10-20) [California] Trump DOJ makes shocking admissions; taken to task for latest allegations of voter fraud
      Source
  - (2026-10-20) [California] NEW: California revenues come in $2.9 billion above forecast as state’s innovation economy continues to grow
      Source
  - (2026-10-21) [California] ‘Borders on the absurd.’ California fights Trump lawsuit to set aside 20,000 ballots
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/020425-Rob-Bonta-Presser-FG-CM-12.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-10-20) [California] ¿Es esta la contienda congresional más normal de EEUU? Los candidatos de San Diego se presentan con plataformas clásicas
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/101526-von-Wilpert-and-Desmond-CM-01-1.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-10-20) [California] Los trabajadores estatales de California están a punto de ir a la huelga. ¿Qué significa esto para el DMV, el EDD, los parques y más?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/100226_Fresno-DMV_LV_CM_10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-10-20) [California] Te explicamos la Prop 37: ¿Puede un bono de 25 mil millones de dólares hacer posible la compra de viviendas en California?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2022/06/052622-MOUNTAIN-HOUSE-MHN-15-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 234 new of 294 total
  - (2026-10-20) China Clarifies Offshore Trust Tax Rules Ahead of Oct. 22 Deadline - Caixin Global
      China Clarifies Offshore Trust Tax Rules Ahead of Oct. 22 Deadline Caixin Global
  - (2026-10-20) China Steps Up AI Investment With $9 Billion Fund Backing Model Developers - Caixin Global
      China Steps Up AI Investment With $9 Billion Fund Backing Model Developers Caixin Global
  - (2026-10-19) China Sets Out Financing Support for Three Innovation Hubs - Caixin Global
      China Sets Out Financing Support for Three Innovation Hubs Caixin Global
  - (2026-10-20) Sany Renewable Plans Egypt Wind Turbine Plant as Overseas Revenue Surges - Caixin Global
      Sany Renewable Plans Egypt Wind Turbine Plant as Overseas Revenue Surges Caixin Global
  - (2026-10-20) China’s Consumers Keep Tight Grip on Their Wallets - Caixin Global
      China’s Consumers Keep Tight Grip on Their Wallets Caixin Global
  - (2026-10-19) 最新财新周刊｜暂别“陪聊”智能体 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBVb3VEa2dHSE1nUzVHSXE0WjdWQVZsMXBKZ0hJcXBWMGYtaFBQWGtjT0tOWFN6bXdBRjFGQVpPVnVEelNhUDlNaTZ1NFQ4S0t0dVF] (zh:…
      最新财新周刊｜暂别“陪聊”智能体 财新周刊

### Local News: St. Louis + Atlanta — 207 new of 238 total
  - (2026-10-21) [St. Louis] Rock Hill home becomes St. Louis’ first certified Passive House
      A house in Rock Hill is something new for the region: It’s the first to be certified as a Passive House. Architect Jessica Deem of Virescent Architecture + Design says the certification from the nonprofit Phius is the fi…
  - (2026-10-21) [St. Louis] City’s attempt to foreclose on Bevo Mill lot shows how new tools can address nuisances
      After an incident involving a can of spray paint and a propane heater caused Kenneth Sandrell’s Bevo Mill home to burn down in 2025, he considered turning the vacant lot into tiny homes or a park for the local children.…
  - (2026-10-20) [St. Louis] Photos: St. Louis Family Playdate at Grant’s Farm
      On October 17, St. Louis Magazine hosted a Family Playdate at Grant’s Farm, presented by Royal Banks of Missouri and sponsored by Lutheran Elementary School Association. Families enjoyed seasonal fun at Grant’s Farm Fall…
  - (2026-10-20) [St. Louis] Discover the quieter side of New Buffalo, Michigan, during fall
      New Buffalo settles into a slower rhythm as summer fades into fall. During the warmer months, this popular lakeside town bustles with energy: the beaches are packed with families and sunbathers, the restaurants spill ont…
  - (2026-10-20) [St. Louis] St. Louis chefs share their favorite Halloween candy
      Every year, I buy a bag of fun-size Twix in mid-October with the intention of getting ahead of the Halloween candy shopping game, only to find it completely empty well in advance of the holiday. They’ve been my favorite…
  - (2026-10-20) [St. Louis] 5 things to know ahead of St. Louis CITY SC’s U.S. Open Cup final against Columbus
      The stakes are high for Wednesday’s U.S. Open Cup final, featuring St. Louis CITY SC and the Columbus Crew in Columbus, Ohio. It marks CITY’s first final, the club’s first real opportunity at silverware, and a chance to…

### Ukraine Theater (total-war monitoring) — 169 new of 474 total
  - (2026-10-21) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-20) [FIRMS] thermal anomaly 52.195, 34.040 (FRP 5.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-20 0926Z, FRP 5.72 MW
  - (2026-10-20) [FIRMS] thermal anomaly 52.195, 34.037 (FRP 4.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-20 0926Z, FRP 4.5 MW
  - (2026-10-20) [FIRMS] thermal anomaly 52.386, 34.245 (FRP 2.58 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-20 0926Z, FRP 2.58 MW
  - (2026-10-20) [FIRMS] thermal anomaly 52.550, 34.417 (FRP 2.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-20 0926Z, FRP 2.84 MW
  - (2026-10-20) [FIRMS] thermal anomaly 52.627, 34.491 (FRP 7.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-20 0926Z, FRP 7.04 MW

### U.S. Weather + Severe / Climate Outlooks — 113 new of 115 total
  - (2026-10-21) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued October 21 at 4:48AM MST until October 21 at 5:00AM MST by NWS Flagstaff AZ
      At 448 AM MST, a severe thunderstorm was located 8 miles north of Perkinsville, or 22 miles northeast of Chino Valley, moving northeast at 40 mph. HAZARD...Two inch hail and 60 mph wind gusts. SOURCE...Radar indicated. I…
  - (2026-10-21) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-21) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued October 21 at 3:45AM AKDT until October 21 at 4:00AM AKDT by NWS Anchorage AK
      Periods of light snow will continue through this morning. However, the threat for any additional significant snow accumulation has ended.
  - (2026-10-21) [Severe] High Wind Watch: High Wind Watch issued October 21 at 3:42AM AKDT until October 25 at 1:00AM AKDT by NWS Fairbanks AK
      * WHAT...Southeast winds 25 to 35 mph with gusts up to 70 mph possible. * WHERE...Eastern Alaska Range North of Trims Camp and Northern Denali Borough. * WHEN...From Friday evening through late Saturday night. * IMPACTS.…
  - (2026-10-21) [Severe] Coastal Flood Warning: Coastal Flood Warning issued October 21 at 7:37AM EDT until October 22 at 8:00PM EDT by NWS Newport/Morehead City NC
      * WHAT...For the Coastal Flood Warning, up to 2 to 4 feet of inundation above ground level in low-lying areas near shorelines and tidal waterways. For the High Surf Advisory, large breaking waves of 9 to 12 feet in the s…
  - (2026-10-21) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued October 21 at 7:37AM EDT until October 21 at 8:00PM EDT by NWS Newport/Morehead City NC
      * WHAT...For the Coastal Flood Advisory, up to 1 to 3 feet of inundation above ground level in low-lying areas near shorelines and tidal waterways. For the High Surf Advisory, large breaking waves of 8 to 12 feet in the…

### State Legislative Action — 90 new of 113 total
  - (2026-10-20) [Alabama SB 341] Alabama Work Zone Safety Act; pilot program to establish photographic speed enforcement system in a work zone on interstate highway, provided; civil penalties for violations, provided
      Motor Vehicles & Traffic
  - (2026-10-21) [Alaska HB 226] An Act increasing the loan amount that is eligible for lower interest rates on certain Alaska Housing Finance Corporation loans.
      An Act increasing the loan amount that is eligible for lower interest rates on certain Alaska Housing Finance Corporation loans.
  - (2026-10-21) [Alaska HB 78] An Act relating to the public employees' retirement system and the teachers' retirement system; and providing certain employees an opportunity to choose between the defined benefit and…
      An Act relating to the public employees' retirement system and the teachers' retirement system; and providing certain employees an opportunity to choose between the defined benefit and defined contribution plans of the p…
  - (2026-10-21) [Alaska HB 16] An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits…
      An Act requiring a group supporting or opposing a candidate or ballot proposition in a state or local election to maintain an address in the state; amending campaign contribution limits for state and local office; direct…
  - (2026-10-21) [Alaska HB 188] An Act establishing the welcoming Alaska office; establishing the welcoming Alaska center; establishing the Welcoming Alaska Advisory Committee; repealing the office of citizenship ass…
      An Act establishing the welcoming Alaska office; establishing the welcoming Alaska center; establishing the Welcoming Alaska Advisory Committee; repealing the office of citizenship assistance; and providing for an effect…
  - (2026-10-21) [Alaska HB 262] An Act increasing the number of superior court judges in the third judicial district; and providing for an effective date.
      An Act increasing the number of superior court judges in the third judicial district; and providing for an effective date.

### GDACS — global disaster alerts — 85 new of 100 total
  - (2026-10-19) [Green] Flood in France
      Flood · Green alert · France · Magnitude 0
  - (2026-10-21) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 5.2M, Depth:10km
  - (2026-10-21) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.1M, Depth:122.687km
  - (2026-10-21) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.7M, Depth:10km
  - (2026-10-21) [Green] Earthquake in South Of Panama
      Earthquake · Green alert · South Of Panama · Magnitude 5M, Depth:10km
  - (2026-10-21) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 4.5M, Depth:90.274km

### Ukrainian Internal News (national + local Kyiv) — 71 new of 137 total
  - (2026-10-21) У ЄС очікують на звіт Віткоффа про зустріч з Путіним в РФ: головне питання – переговори з Україною | LEDE: У Європейській комісії очікують, що після зустрічі спецпредставника президента США Сті] (uk:…
      У Європейській комісії очікують, що після зустрічі спецпредставника президента США Стіва Віткоффа з Володимиром Путіним у Санкт-Петербурзі американська делегація поінформує про результати, причому одне з головних питань…
  - (2026-10-21) Україна створює нові правила розслідування сексуального насильства: що змінюється для постраждалих | LEDE: ] (uk: Україна створює нові правила розслідування сексуального насильства: що змінюєтьс)
  - (2026-10-21) Мерц: Капітуляція України означала б капітуляцію всіх союзників | LEDE: Канцлер Німеччини Фрідріх Мерц заявив, що капітуляція України у війні з Росією не розглядається, оскільки це означало б к] (uk:…
      Канцлер Німеччини Фрідріх Мерц заявив, що капітуляція України у війні з Росією не розглядається, оскільки це означало б капітуляцію усіх союзників.
  - (2026-10-21) Території, безпека й повоєнне майбутнє: Єврокомісія назвала головні питання переговорів щодо України в Осло | LEDE: В Осло 20 жовтня Зеленський, Віткофф і європейські лідери обговорили безпеку,] (uk:…
      В Осло 20 жовтня Зеленський, Віткофф і європейські лідери обговорили безпеку, території й повоєнне відновлення України.
  - (2026-10-21) На кордоні завернули вінничанина, який одружився з майбутньою тещею, аби виїхати до Молдови | LEDE: На Вінниччині прикордонники завернули чоловіка, якого запідозрили у фіктивному шлюбі.] (uk: На кордо…
      На Вінниччині прикордонники завернули чоловіка, якого запідозрили у фіктивному шлюбі.
  - (2026-10-21) "Ці люди мене дратують": Макрон розкритикував заяви іноземних лідерів про протести у Франції | LEDE: Президент Франції Емманюель Макрон назвав коментарі іноземних лідерів щодо протестів у країн] (uk:…
      Президент Франції Емманюель Макрон назвав коментарі іноземних лідерів щодо протестів у країні неприйнятними та безглуздими й заявив про маніпуляції інформацією, зокрема поширення згенерованих ШІ зображень подій, яких не…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-10-21) [Russia oil sanctions perimeter · themes] La familia argentina que vive en un velero desde hace 8 años y cruzó el Pacífico en 28 días sin escalas hasta la Polinesia
      clarin.com · Spanish · tone NA
  - (2026-10-21) [Russia oil sanctions perimeter · themes] Ρωσία : Στέλνει 40 . 000 τόνους ντίζελ στις ΗΠΑ – Η συμφωνία Πούτιν και Τραμπ παίρνει σάρκα και οστά
      inewsgr.com · Greek · tone NA
  - (2026-10-21) [Russia oil sanctions perimeter · themes] NATO boosts Black Sea surveillance amid attacks on shipping
      splash247.com · English · tone NA
  - (2026-10-21) [Russia oil sanctions perimeter · themes] Lượng tiền lớn trở lại , chứng khoán tăng mạnh nhất hơn nửa năm
      tienphong.vn · Vietnamese · tone NA
  - (2026-10-21) [Russia oil sanctions perimeter · themes] 70조라던 알래스카 사업비 검토단계 수준 … 최대 2배 될수도
      fnnews.com · Korean · tone NA
  - (2026-10-21) [Russia oil sanctions perimeter · themes] Theater review : Hartford Stage Dracula a psychological thriller
      courant.com · English · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 57 total
  - (2026-10-21) [BleepingComputer] Microsoft says October updates didn’t actually fix VPN issues
      Microsoft says it mistakenly flagged a bug causing Always On VPN connection issues as fixed in the October 2026 Windows 11 cumulative updates. [...]
  - (2026-10-21) [BleepingComputer] CISA: SafePay ransomware hit over 600 critical infrastructure orgs
      The Cybersecurity and Infrastructure Security Agency (CISA) says the SafePay ransomware gang has breached over 600 critical infrastructure organizations worldwide since 2024. [...]
  - (2026-10-21) [BleepingComputer] Stolen UpdraftCentral keys used to backdoor WordPress sites
      A threat actor breached TeamUpdraft's website, a developer of popular WordPress backup and security plugins, potentially compromising UpdraftCentral connection keys that can send commands to connected websites. [...]
  - (2026-10-21) [BleepingComputer] Mozilla, Google, Apple block compromised eMudhra CA certificates
      Certificate authority eMudhra revoked eight compromised intermediate certificates after researchers found their private keys were so weak that anyone could recover them almost instantly and use them to forge trusted cert…
  - (2026-10-21) [The Hacker News] PHP2Shell: What Actually Protects You Before the 14:00 UTC PHP RCE Patch, and What Doesn't
      You cannot fully block the two critical PHP flaws called PHP2Shell before today's fix, and the one setting being passed around as a workaround is not enough on its own, the security firm that suggested it now says. PHP w…
  - (2026-10-21) [The Hacker News] The Harness Is the Hard Part of Agentic Pentesting
      An AppSec team can point an AI agent running on a general-purpose model at its own web apps with little setup. Sure, the model writes the attacks. But everything that makes those attacks safe to run against production an…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-21) [Rozenberg Haine Yael] Form 4 (Reporting)
      filed 2026-10-21 11:34 UTC · role: Reporting — Filed: 2026-10-21 AccNo: 0001976408-26-000898 Size: 5 KB
  - (2026-10-21) [Valens Semiconductor Ltd.] Form 4 (Issuer)
      filed 2026-10-21 11:34 UTC · role: Issuer — Filed: 2026-10-21 AccNo: 0001976408-26-000898 Size: 5 KB
  - (2026-10-21) [WANG CHUN KAI] Form 4 (Reporting)
      filed 2026-10-21 11:31 UTC · role: Reporting — Filed: 2026-10-21 AccNo: 0002109337-26-000012 Size: 5 KB
  - (2026-10-21) [OBOOK HOLDINGS INC.] Form 4 (Issuer)
      filed 2026-10-21 11:31 UTC · role: Issuer — Filed: 2026-10-21 AccNo: 0002109337-26-000012 Size: 5 KB
  - (2026-10-21) 424B2 - TOYOTA MOTOR CREDIT CORP (0000834071) (Filer)
      filed 2026-10-21 11:11 UTC — Filed: 2026-10-21 AccNo: 0000950103-26-015937 Size: 157 KB
  - (2026-10-21) 425 - APEX Tech Acquisition Inc. (0002085485) (Subject)
      filed 2026-10-21 10:47 UTC — Filed: 2026-10-21 AccNo: 0001493152-26-047838 Size: 1 MB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-10-21) [India] Delhi HC not Gen Z remark : How old are key CJP leaders ?
      domain: moneycontrol.com · language: English · tone:
  - (2026-10-21) [United States] Expecting a baby ? 5 tips to help you prepare for pregnancy costs
      domain: kunm.org · language: English · tone:
  - (2026-10-21) [United States] U . S . Envoy Witkoff To Hold Peace Talks With Putin
      domain: whoradio.iheart.com · language: English · tone:
  - (2026-10-21) [United States] World Insights : Cost - of - living protests highlight mounting economic , social pressures across Europe
      domain: mainemirror.com · language: English · tone:
  - (2026-10-21) [South Korea] Align Partners reveals 1 . 5 % stake in SK Inc ., sees 75 % valuation discount
      domain: koreatimes.co.kr · language: English · tone:
  - (2026-10-21) [United States] Europe Dominoes Are Falling . Which Country Might Be Next ?
      domain: newsweek.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 23 new of 23 total
  - (2026-10-21) GAF527 (Germany)
      icao24: 3dbc00 · position: (53.5973, 13.0755) · alt: 868m · 255km/h
  - (2026-10-21) JAF50T (Bulgaria)
      icao24: 4520ce · position: (40.7771, -2.6214) · alt: 10668m · 813km/h
  - (2026-10-21) GAF110 (Germany)
      icao24: 3f717c · position: (53.8225, 11.073) · alt: 9753m · 642km/h
  - (2026-10-21) CFC4266 (Canada)
      icao24: c2b585 · position: (43.6616, 7.2132) · on ground
  - (2026-10-21) CFC4015 (Canada)
      icao24: c2b3eb · position: (55.3178, -4.2919) · alt: 2468m · 504km/h
  - (2026-10-21) JAF86A (Belgium)
      icao24: 44d1ba · position: (50.9019, 4.4886) · on ground

### Court opinions of consequence (federal & state) — 20 new of 60 total
  - (2026-10-20) U.S. Court of Appeals, 9th Cir.: United States v. Mumma
  - (2026-10-20) U.S. Court of Appeals, 2nd Cir.: Seabrook v. City of New York
  - (2026-10-20) U.S. Court of Appeals, D.C. Cir.: Mennonite Church USA v. DHS
  - (2026-10-20) U.S. Court of Appeals, 5th Cir.: Zahid v. Blanche
  - (2026-10-20) U.S. Court of International Trade: Baroque Timber Indus. (Zhongshan) Co. v. United States
  - (2026-10-20) U.S. Court of International Trade: KG Dongbu Steel Co. v. United States

### World News (by country, top stories) — 18 new of 18 total
  - (2026-10-21) [China] NATO boosts Black Sea surveillance amid attacks on shipping
      splash247.com · English
  - (2026-10-21) [China] BOMESC advances $23m Tianjin port expansion
      splash247.com · English
  - (2026-10-21) [China] GrowthCap Ventures Backs LogiXair to Build India Autonomous Aerial Cargo Network
      asiabulletin.com · English
  - (2026-10-21) [China] IFM Investors buys Associated British Ports
      splash247.com · English
  - (2026-10-21) [China] Update : China CERES - 1 rocket launches new satellite from sea
      shanghaisun.com · English
  - (2026-10-21) [China] China biodiversity conservation offers valuable lessons for world , says UN biodiversity chief
      shanghaisun.com · English

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-10-20) M 5.4 - 192 km S of Burica, Panama
      M5.4 · 192 km S of Burica, Panama · depth 10 km
  - (2026-10-21) M 5.2 - 68 km NE of Cabatuan, Philippines
      M5.2 · 68 km NE of Cabatuan, Philippines · depth 10 km
  - (2026-10-21) M 5.1 - 164 km NE of Lospalos, Timor Leste
      M5.1 · 164 km NE of Lospalos, Timor Leste · depth 122.687 km
  - (2026-10-20) M 5.1 - 39 km W of Mosteiros, Portugal
      M5.1 · 39 km W of Mosteiros, Portugal · depth 10 km
  - (2026-10-21) M 5.0 - south of Panama
      M5.0 · south of Panama · depth 10 km
  - (2026-10-20) M 5.0 - 21 km SW of Meulaboh, Indonesia
      M5.0 · 21 km SW of Meulaboh, Indonesia · depth 75.876 km

### Paper Trading Scorecard — 11 new of 63 total
  - (2026-10-21) [Polymarket] Will an AI lab announce another Millennium Prize solution by December 31, 2027?
      This market will resolve to "Yes" if an eligible AI lab, or an official representative of an eligible AI lab, announces that the lab has solved any of the qualifying Millennium Prize Problems by 11:59 PM ET of the date s…
  - (2026-10-21) [Kalshi] Who will be the next Prime Minister of the UK?
      Before Jan 1, 2035
  - (2026-10-21) [Manifold] Will Ukraine strike Russia sovereign land before December?
  - (2026-10-21) [Manifold] In three months, will I think setting up this Manifold news reader was worth it?
  - (2026-10-21) [Manifold] malfoid tv show announced by EOY?
  - (2026-10-21) [Manifold] "You Can See Everything" nominated for Best Picture and NOT Best Documentary

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-10-21) Will FC Bayern München win on 2026-10-21?
      yes price: 44% · 24h volume: $923,838 · resolves 2026-10-21
  - (2026-10-21) 2026 Balance of Power: R Senate, R House
      yes price: 8% · 24h volume: $805,775 · resolves 2026-11-04
  - (2026-10-21) Will Arsenal FC win on 2026-10-21?
      yes price: 32% · 24h volume: $563,759 · resolves 2026-10-21
  - (2026-10-21) 2026 Balance of Power: D Senate, D House
      yes price: 64% · 24h volume: $458,822 · resolves 2026-11-04
  - (2026-10-21) Will Como 1907 win on 2026-10-21?
      yes price: 40% · 24h volume: $457,539 · resolves 2026-10-21
  - (2026-10-21) Will the Republicans win the Texas Senate race in 2026?
      yes price: 36% · 24h volume: $398,701 · resolves 2026-11-04

### U.S. Federal Action — 10 new of 14 total
  - (2026-10-21) Implementing the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026
  - (2026-10-21) Guidance Under Section 355 Concerning Device and Active Trade or Business; Partial Withdrawal
      This document partially withdraws a notice of proposed rulemaking containing proposed regulations regarding the application of the device prohibition and the active trade or business requirement for distributions of cont…
  - (2026-10-21) Fisheries of the Exclusive Economic Zone Off Alaska; Reallocation of Pacific Cod in the Western Regulatory Area of the Gulf of Alaska
      NMFS is reallocating the projected unused amounts of Pacific cod from catcher vessels using trawl gear to catcher vessels using pot gear in the Western Regulatory Area of the Gulf of Alaska (GOA). This action is necessar…
  - (2026-10-21) Notification to Members/Shareholders
      The NCUA Board (Board) solicits public comment on a proposal to streamline the methods a federally insured credit union (FICU) may use to provide its members with notice of share insurance coverage. The current regulatio…
  - (2026-10-21) Petition for Rulemaking of Jason Plotzker
      Please take notice that the Federal Trade Commission ("Commission") received a petition for rulemaking from Jason Plotzker and has published that petition online at https://www.regulations.gov. The Commission invites wri…
  - (2026-10-21) Nonconforming Investment Special Reserve
      The NCUA Board (Board) is proposing to amend its regulations governing the requirements for federal share insurance. This action would remove the requirement for federally insured, state-chartered credit unions to establ…

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 105 total
  - (2026-10-19) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Protecting American Intellectual Property Act of 2022 50 U.S.C. 1709 GENERAL LICENSE NO. 2 Aut - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Protecting American Intellectual Property Act of 2022 50 U.S.C. 1709 GENERAL LICENSE NO. 2 Aut Office of Foreign Assets Control (.gov)
  - (2026-10-21) [BIS Entity List] page checksum 68875abbba3a
      Page content hash: 68875abbba3a. Compare with prior day's hash to detect updates.
  - (2026-10-21) [USASpending] $1,580,872,193 → CALIFORNIA INSTITUTE OF TECHNOLOGY: DEEP SPACE NETWORK (DSN) THE CONTRACT IS THE SPONSORING AGR
      Agency: National Aeronautics and Space Administration. Description: DEEP SPACE NETWORK (DSN) THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION (NASA) AND THE CALIFORNIA IN…
  - (2026-10-21) [USASpending] $1,115,135,672 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…
  - (2026-10-21) [USASpending] $826,465,672 → CALIFORNIA INSTITUTE OF TECHNOLOGY: PSYCHE: JOURNEY TO A METAL WORLD THE CONTRACT IS THE SPONSO
      Agency: National Aeronautics and Space Administration. Description: PSYCHE: JOURNEY TO A METAL WORLD THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION (NASA) AND THE CALIF…
  - (2026-10-21) [USASpending] $681,573,350 → KBR WYLE SERVICES, LLC: GROUND SYSTEMS AND MISSION OPERATIONS (GSMO-3)
      Agency: National Aeronautics and Space Administration. Description: GROUND SYSTEMS AND MISSION OPERATIONS (GSMO-3)

### CISA Known Exploited Vulnerabilities (last 14d) — 6 new of 20 total
  - (2026-10-20) CVE-2026-106931 · EG Secure Solutions SiteGuard Server Edition: EG Secure Solutions SiteGuard Server Edition OS Command Injection Vulnerability
      vendor: EG Secure Solutions · product: SiteGuard Server Edition · CISA remediation by 2026-10-23
  - (2026-10-20) CVE-2026-96656 · Plex Media Server: Plex Media Server External Control of File Name or Path Vulnerability
      vendor: Plex · product: Media Server · CISA remediation by 2026-10-23
  - (2026-10-20) CVE-2026-96655 · Plex Media Server: Plex Media Server Server-Side Request Forgery (SSRF) Vulnerability
      vendor: Plex · product: Media Server · CISA remediation by 2026-11-03
  - (2026-10-20) CVE-2026-96654 · Plex Media Server: Plex Media Server Improper Neutralization of Encoded URI Schemes in a Web Page Vulnerability
      vendor: Plex · product: Media Server · CISA remediation by 2026-10-23
  - (2026-10-20) CVE-2026-96652 · Plex Media Server: Plex Media Server Server-Side Request Forgery (SSRF) Vulnerability
      vendor: Plex · product: Media Server · CISA remediation by 2026-11-03
  - (2026-10-20) CVE-2026-110936 · Siemens Software Center: Siemens Software Center Uncontrolled Search Path Element Vulnerability
      vendor: Siemens · product: Software Center · CISA remediation by 2026-11-03

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-21) [Marginal Revolution] One reason I do not love AI writing, or even AI-assisted writing
      Of course I read to absorb the content, but I also am in a position to meet many authors, have contact with them, and spend time with them. So reading anything also is a potential option on those future connections. But…
  - (2026-10-21) [Marginal Revolution] The Causal Effect of Foreign Ideas on U.S. Innovation
      Globalization is once again better than many people realize: We study the role of foreign ideas in U.S. innovation by constructing a directed “genealogy” of technologies from the full text of 13 million patents filed bet…
  - (2026-10-20) [Marginal Revolution] Saving for the machines
      From Jesús Fernández-Villaverde: When machines can perform a growing share of tasks, growth depends on two margins: how the task structure affects the returns to accumulating machines, and how strongly capital accumulati…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-21) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=33, 14d-median=26; carrying terms: proposes, enforcement, protection, period, proposed, agency, regulatory, action, proposing, national, certain, final
- state_bills: today=113, 7d-median=118, 14d-median=92; carrying terms: school, providing, powers, administration, district, relating, education, state, alaska, health, managed, within
- state_news: today=734, 7d-median=688, 14d-median=678; carrying terms: health, voter, community, utility, airport, commentary, change, criminal, special, majority, toomanyredirects, affordability
- local_news: today=238, 7d-median=235, 14d-median=228; carrying terms: health, deadly, charged, constitution, color, county, october, ahead, officer, jackson, taking, record
- foreign_news: today=1027, 7d-median=1011, 14d-median=1018; carrying terms: australian, david, health, voter, speed, higher, airport, change, universal, families, schools, midterm
- chinese_internal: today=294, 7d-median=282, 14d-median=293; carrying terms: chinese, color, cbmixkfvx, cbmia, cbmigwfbvv, cbmiakfvx, lxtfb, china, cbmiy, investors, cbmiyefvx, cbmizefvx
- russian_internal: today=598, 7d-median=1019, 14d-median=1026; carrying terms: novayagazeta, politico, laquo, https, europe, httperror, istories, raquo, journal, found, media, server
- ukrainian_internal: today=137, 7d-median=130, 14d-median=135; carrying terms: facility, least, sanctions, ballistic, drones, growing, million, europe, infrastructure, volodymyr, urges, zelensky
- ukraine_theater: today=474, 7d-median=409, 14d-median=419; carrying terms: dxaxbtwfztmgnyt, lxtfbosjhpq, nvcwd, processing, hyatt, cuxougfdeddostfsmlvkvlzyr, rsnjrtzdisthjqzvcse, dhfowmnpr, airport, dlwwtdzu, commentary, change
- paper_bets: today=63, 7d-median=69, 14d-median=68; carrying terms: unemployment, labor, total, humans, least, human, succeed, career, speed, president, koivun, patrick
- weather: today=115, 7d-median=138, 14d-median=140; carrying terms: winds, discussion, miami, northeast, afternoon, widespread, continues, afdfwd, waves, following, remains, atlantic
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unemployment, labor, total, commodities, payems, effective, latest, dexuseu, supply, indicator, walcl, cpiaucsl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, nasdaq, proxy, commodities, crude, china, large, range, credit, corporate, yield, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=105, 7d-median=105, 14d-median=108; carrying terms: lebanon, zimbabwe, management, sanctions, restrictive, drilling, cyber, imposed, abuses, february, occupation, schools
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, https, quantitative, error, quiver, congresstrading, httperror, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, board, corporation, supreme, state, court, alabama, international, company, mullin, trade, county
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, holdings, financial, filer, robert, chase, jpmorgan, natera, jonathan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, david, alexandria, booker, ossoff, ocasio, cortez, warner, krishnamoorthi, cooper, filing, johnson
- gdelt_regions: today=18, 7d-median=6, 14d-median=6; carrying terms: english, china, japan
- gdelt_gkg: today=50, 7d-median=25, 14d-median=25; carrying terms: english, italian, themes, spanish, russia, perimeter, sanctions, french, vietnamese, russian, german, ukrainian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: english, killed, australia, india, kingdom, language, domain, story, against, energy, years, canada
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=23, 7d-median=23, 14d-median=28; carrying terms: belgium, position, kingdom, ground, france, bulgaria, germany, canada, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: total, expanded, ventilatory, nipah, symptoms, declaration, member, humans, monkeypox, chikv, alerted, spain
- cisa_kev: today=20, 7d-median=15, 14d-median=14; carrying terms: traversal, injection, cisco, remediation, product, vulnerability, vendor, improper, struts, information, server, errors
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: typhoon, fires, maximum, impact, magnitude, guinea, speed, green, tropical, forest, wildfire, earthquake
- usgs_quakes: today=16, 7d-median=16, 14d-median=18; carrying terms: depth, indonesia, philippines, panama, vanuatu, islands, south, guinea, papua, kokopo, japan, kuril
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, volume, price, champions, championship, shakhtar, october, donetsk, resolves, presidential, election, brazilian
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, class, conversable, https, economist, marginal, track, marginalrevolution, spending, conversableeconomist, years, government
- tech_news: today=57, 7d-median=58, 14d-median=58; carrying terms: people, company, infrastructure, ransomware, systems, technology, according, group, research, technica, hacker, researchers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: fallon, hayes, relations, david, clyde, labor, sykes, carol, warner, ricketts, webster, tuberville
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, sufficient, market, claude, evidence, unavailable, markets, paper, placement, today, consensus, converges

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-07] Fed press (events + announcements): Minutes of the Federal Open Market Committee, September 15-16, 2026
- [2026-10-08] Fed speeches: Waller, The Signaling Value of the Summary of Economic Projections
- [2026-10-08] ECB press: Meeting of 9-10 September 2026
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-13] ECB press: Philip R. Lane: The AI opportunity for Europe
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-17] ECB press: Christine Lagarde: IMFC Statement
- [2026-10-19] ECB press: Frank Elderson: From climate and nature risks to economic resilience and competitiveness
- [2026-10-20] ECB press: Frank Elderson: Interview with Die Presse
- [2026-10-21] ECB press: Philip R. Lane: Euro liquidity lines and the international monetary system
- [2026-10-21] ECB press: Piero Cipollone: Pontes and Appia: unlocking opportunities for banks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*