# WORLDSCOPE morning brief — 2026-07-23

## Headline
3173 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (708) · Russian Internal News (state + in-exile) (634) · State-Level News (385) · World leaders & government officials (324) · Chinese Internal News (222) · Local News: St. Louis + Atlanta (194) · Ukraine Theater (total-war monitoring) (173) · U.S. Weather + Severe / Climate Outlooks (141) · Ukrainian Internal News (national + local Kyiv) (59) · GDELT GKG — themes / entities / watch areas (50) · U.S. Federal Action (41) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 708 new of 1004 total
  - (2026-07-23) [Global] US signs landmark nuclear deal with Saudi Arabia
      The US Department of Energy says the "peaceful" co-operation agreement will give US firms "great access" to the Saudi nuclear energy programme.
  - (2026-07-23) [Global] Houthis claim attack on oil tankers as US launches more strikes on Iran
      The Houthi attacks would be the first in the Red Sea since the Iran-backed group announced a "maritime embargo" against Saudi Arabia.
  - (2026-07-23) [Global] Around 12,000 people evacuated in France fires
      A third firefighter has died in Europe while tackling ongoing wildfires across the continent.
  - (2026-07-23) [Global] 'I am still alive': Indian activist on hunger strike for 26 days loses 11kg
      Sonam Wangchuk has been the main draw at the Cockroach Janta Party (CJP) protest in Delhi.
  - (2026-07-22) [Global] Tankers make sharp U-turns after Houthi shipping threat
      All of the ships were travelling to or from Saudi ports before changing course, ship-tracking data shows.
  - (2026-07-23) [Global] Canada's 'powerful' dairy sector is in Trump's trade crosshairs
      Canada's dairy supply management system is in the spotlight after the US president singled it out as one of three main irritants used to justify new tariffs.

### Russian Internal News (state + in-exile) — 634 new of 1074 total
  - (2026-07-23) Минобороны раскрыло подробности освобождения Белицкого в ДНР | LEDE: ] (ru: Минобороны раскрыло подробности освобождения Белицкого в ДНР)
  - (2026-07-23) Соглашение США и Саудовской Аравии вызывает опасения в Израиле, пишут СМИ | LEDE: ] (ru: Соглашение США и Саудовской Аравии вызывает опасения в Израиле, пишут СМИ)
  - (2026-07-23) В Госдуме объяснили важность особого статуса для учителя | LEDE: ] (ru: В Госдуме объяснили важность особого статуса для учителя)
  - (2026-07-23) Под Волгоградом задержали подозреваемого в убийстве 29-летней давности | LEDE: ] (ru: Под Волгоградом задержали подозреваемого в убийстве 29-летней давности)
  - (2026-07-23) В Петербурге задержали россиянина с незадекларированными украшениями из ОАЭ | LEDE: ] (ru: В Петербурге задержали россиянина с незадекларированными украшениями из ОАЭ)
  - (2026-07-23) Жителя Коми приговорили к тюрьме за попытку вступить в ВСУ | LEDE: ] (ru: Жителя Коми приговорили к тюрьме за попытку вступить в ВСУ)

### State-Level News — 385 new of 816 total
  - (2026-07-22) [California] Acting Governor Rivas proclaims Disability Pride Month
      Source
  - (2026-07-22) [California] California delivers major blow to organized retail theft, recovering $76.2 million in stolen goods since 2019
      Source
  - (2026-07-22) [California] Governor Newsom announces appointments 7.22.2026
      Source
  - (2026-07-22) [Alabama] Governor Ivey Signs Executive Order Establishing Commission on Screen-Based Instruction
      MONTGOMERY – Governor Kay Ivey on Wednesday signed Executive Order No. 745 establishing the Governor’s Commission on Screen-Based Instruction to study the use, risks and benefits of screen-based instruction in Alabama’s…
  - (2026-07-22) [Alabama] Executive Order 745
      Download
  - (2026-07-22) [Alabama] Executive Order 744
      Download

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 222 new of 293 total
  - (2026-07-22) OpenAI模型“越狱”攻击，救场的竟是中国AI工具 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBIaXdHSWVfV28zQWJyWFRnakNRTWpsRC1PUkF3MTdmQkZ5dWJPNGIxcmhFNkpKem4zbzJCdmhiamwybVlFR1owVDZERG] (zh:…
      OpenAI模型“越狱”攻击，救场的竟是中国AI工具 观察者
  - (2026-07-22) 百度智能云张玮：芯片设计正被AI重写，我们要做那个“全栈底座” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE00VVpHaWRweEY1WFduRmdmQ2toVDFUeTE5VVRCMVh5Mmc1TVZuSXU3UlBEenVjZE5qeGNYQ1E0eDdJWnN6M0p0W] (zh:…
      百度智能云张玮：芯片设计正被AI重写，我们要做那个“全栈底座” 观察者
  - (2026-07-21) 英媒爆料：中美9月将举行AI会谈 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5PMjVFZzl6aG5Rc0RwUzN1TW1NVG1wcTZLblg5XzY4bUJiejhXZXNOdEdCZnhzSFFhZjVFX29Rc21nVlpMQUZhUVlrdjdiSTZWUHNC] (zh:…
      英媒爆料：中美9月将举行AI会谈 观察者
  - (2026-07-22) 诺格“太空机器人”发射升空，外界关注其进攻作战潜力 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTFBwRUt5X09NTUpjRkJ5d0t5cDM1QWxTdlRFUW00MGFPMFhnc3R6NjZWaDVNMkZ3UmtlakFFNWRZSHBTQnlDalQwdGVIUVd] (zh:…
      诺格“太空机器人”发射升空，外界关注其进攻作战潜力 观察者
  - (2026-07-23) 久居英国伦敦女子回国，因饭桌上的二手烟和亲戚当场翻脸 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE9xZlBoaXNkUkhDNURZemU3WFhjY0VHWkZHZFZidldTWVhDa2xua2c2WGFYVk1Yd3ZpNTFtS1RkNXlNRXFGemVobDlxTHl] (zh:…
      久居英国伦敦女子回国，因饭桌上的二手烟和亲戚当场翻脸 风闻
  - (2026-07-22) 广州一纺织厂6年暑期给员工带娃管饭，“花不了多少钱”，大家对此怎么看？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE81dGNpbGl1VFpKU1dwZXdTRjdnd1ZBcjZ5YnBQdFItMHFhMFlfaTdiSzFsejNNcUJ3ZGU2NGdGRXpyT3dQNU] (zh:…
      广州一纺织厂6年暑期给员工带娃管饭，“花不了多少钱”，大家对此怎么看？ 风闻

### Local News: St. Louis + Atlanta — 194 new of 236 total
  - (2026-07-22) [St. Louis] Trial begins for man accused of severely injuring Ferguson officer during police brutality protest
  - (2026-07-22) [St. Louis] U.S. Dept. of Education investigating SLU School of Medicine for racial discrimination in admissions
  - (2026-07-22) [St. Louis] State approves new $231 million hospital to replace Touchette in Cahokia Heights
  - (2026-07-23) [St. Louis] Where in the Lou? – 7/23/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-07-22) [St. Louis] First these highway signs didn’t fit. Then came the graffiti
      Three large signs near the Interstates 44 and 55 interchange south of downtown St. Louis aren’t directing much traffic, though they are turning heads. The highway signs, meant to guide highway drivers to Memphis (via sou…
  - (2026-07-22) [St. Louis] Why innovation takes more than a great idea
      Most people have heard the word “ecosystem” in conversations about startups, innovation, or economic development. Outside those industries, it can sound like another business buzzword. Justin Raymundo wants people to thi…

### Ukraine Theater (total-war monitoring) — 173 new of 370 total
  - (2026-07-23) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-22) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - iraq.liveuamap.com
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com iraq.liveuamap.com
  - (2026-07-23) [Liveuamap] Oil depot was attacked near Novospasskoye of Ulyanovsk region - Liveuamap
      Oil depot was attacked near Novospasskoye of Ulyanovsk region Liveuamap
  - (2026-07-18) [Liveuamap] Zelensky: In response to Russian attacks on our civilian infrastructure, our cities and communities, two significant logistics facilities were hit - in the Moscow and Tambov regions, at a…
      Zelensky: In response to Russian attacks on our civilian infrastructure, our cities and communities, two significant logistics facil
  - (2026-07-22) [Liveuamap] Ukrainian drones have targeted 13 Russian vessels in Azov and Black seas during past 48 hours - Liveuamap
      Ukrainian drones have targeted 13 Russian vessels in Azov and Black seas during past 48 hours <font color="#6f6f
  - (2026-07-21) [Liveuamap] Drone targets Ali Al Salem Air Base in Kuwait Al Jahra Governorate, Kuwait - Liveuamap
      Drone targets Ali Al Salem Air Base in Kuwait Al Jahra Governorate, Kuwait Liveuamap</f

### U.S. Weather + Severe / Climate Outlooks — 141 new of 150 total
  - (2026-07-23) [Severe] Flood Watch: Flood Watch issued July 23 at 3:22AM MDT until July 23 at 8:00PM MDT by NWS Riverton WY
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of central and northwest Wyoming, including the following areas, in central Wyoming, Owl Creek and Bridger Mountains, and East W…
  - (2026-07-23) [Severe] Flood Watch: Flood Watch issued July 23 at 3:22AM MDT until July 23 at 6:00AM MDT by NWS Riverton WY
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of central, north central, northwest, south central, southwest, and west central Wyoming, including the following areas, in cent…
  - (2026-07-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-23) [Moderate] Gale Warning: Gale Warning issued July 23 at 2:13AM PDT until July 23 at 3:00AM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Northwest winds 20 to 25 kt with gusts up to 30 kt and combined seas 7 to 10 ft when conditions are worst. * WHERE...Waters from Pt. Sal to Santa Cruz Island CA and westward 60 nm including San Miguel and Santa…
  - (2026-07-23) [Moderate] Tropical Cyclone Local Statement: Tropical Cyclone Local Statement issued July 23 at 4:00AM CDT by NWS Lake Charles LA
      HLSLCH This product covers Southwest Louisiana and Southeast Texas **BERTHA MOVING WESTWARD SOUTH OF THE LOUISIANA COAST** NEW INFORMATION --------------- * CHANGES TO WATCHES AND WARNINGS: - None * CURRENT WATCHES AND W…
  - (2026-07-23) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued July 23 at 3:56AM CDT until July 24 at 6:00AM CDT by NWS Houston/Galveston TX
      * WHAT...Strong rip currents are expected. * WHERE...Gulf-facing beaches, including the Matagorda Peninsula, Brazoria County beaches, Galveston Island and the Bolivar Peninsula. * WHEN...From 7 AM CDT this morning throug…

### Ukrainian Internal News (national + local Kyiv) — 59 new of 114 total
  - (2026-07-23) Троє загиблих і 10 постраждалих внаслідок російської атаки на Павлоград | LEDE: Російські війська 23 липня вдарили по Павлограду: пошкоджене підприємство харчової промисловості, де виникла поже] (uk:…
      Російські війська 23 липня вдарили по Павлограду: пошкоджене підприємство харчової промисловості, де виникла пожежа.
  - (2026-07-23) Держесекретар США каже, що для завершення війни в Україні потрібні "нові ідеї" | LEDE: Державний секретар Сполучений Штатів Марко Рубіо заявив, що для досягнення миру в російсько-українській ві] (uk:…
      Державний секретар Сполучений Штатів Марко Рубіо заявив, що для досягнення миру в російсько-українській війні потрібні "нові ідеї", аби вийти з глухого кута в переговорах.
  - (2026-07-23) Очільник САП Клименко: Експертам у справах про високопосадову корупцію погрожують | LEDE: ] (uk: Очільник САП Клименко: Експертам у справах про високопосадову корупцію погрожуют)
  - (2026-07-23) Атомний ударний підводний човен США прибув до Шотландії | LEDE: Американський атомний ударний підводний човен USS Oregon класу Virginia прибув на військово-морську базу у Фаслейні в Шотландії.] (uk: А…
      Американський атомний ударний підводний човен USS Oregon класу Virginia прибув на військово-морську базу у Фаслейні в Шотландії.
  - (2026-07-23) Експертам у справах про високопосадову корупцію погрожують. Україні потрібна незалежна експертна установа | LEDE: Ризики тиску, затягування та залежності експертів можуть унеможливити боротьбу ] (uk:…
      Ризики тиску, затягування та залежності експертів можуть унеможливити боротьбу з корупцією.
  - (2026-07-23) Карати за нетерпимість, як в Європі: як Україна має змінити норми щодо нападів на "інакших" | LEDE: Злочин на ґрунті нетерпимості – це ситуація, коли людину атакують через її належність до певн] (uk:…
      Злочин на ґрунті нетерпимості – це ситуація, коли людину атакують через її належність до певної групи.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-07-23) [Russia oil sanctions perimeter · themes] Ulisse o Odisseo ? ( e Odissèo o Odìsseo ?)
      ilpost.it · Italian · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] Einigung in Brüssel : EU verhängt neue Russland - Sanktionen
      lr-online.de · German · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] Carburanții se scumpesc din 1 august
      news.yam.md · Romanian · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] UK withdraws diplomatic staff from Iran as US airstrikes continue
      lbc.co.uk · English · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] Houthis claim attack on Saudi tankers while US keeps hitting Iran
      dailysabah.com · English · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] Ucraina , colpita raffineria russa . Lavrov : Mosca vuole fine guerra per via diplomatica
      spotandweb.it · Italian · tone NA

### U.S. Federal Action — 41 new of 41 total
  - (2026-07-23) Continuation of the National Emergency With Respect to Mali
  - (2026-07-23) Securing America's Defense Supply Chains and Ensuring Domestic Acquisition of Critical Materials
  - (2026-07-23) Made in America Week, 2026
  - (2026-07-23) Captive Nations Week, 2026
  - (2026-07-23) Imposing Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Motor Vehicles
  - (2026-07-23) Imposing Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Dairy

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-23) [TKO Group Holdings, Inc.] Form 4 (Issuer)
      filed 2026-07-23 01:40 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001193125-26-312814 Size: 14 KB
  - (2026-07-23) [Khan Nick] Form 4 (Reporting)
      filed 2026-07-23 01:40 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001193125-26-312814 Size: 14 KB
  - (2026-07-23) [Lustgarten Shai Shalom] Form 4 (Reporting)
      filed 2026-07-23 01:27 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001493152-26-034286 Size: 5 KB
  - (2026-07-23) [OMNIQ Corp.] Form 4 (Issuer)
      filed 2026-07-23 01:27 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001493152-26-034286 Size: 5 KB
  - (2026-07-23) [Columbia Financial, Inc./MD/] Form 4 (Issuer)
      filed 2026-07-23 01:24 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001731363-26-000007 Size: 327 KB
  - (2026-07-23) [Van Dyk Robert] Form 4 (Reporting)
      filed 2026-07-23 01:24 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001731363-26-000007 Size: 327 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 33 new of 52 total
  - (2026-07-23) [BleepingComputer] Microsoft working to fix Exchange Online mailbox quarantine issue
      Microsoft is working to resolve an ongoing Exchange Online issue that has been mistakenly quarantining customers' mailboxes since Sunday. [...]
  - (2026-07-23) [BleepingComputer] Check Point warns of SmartConsole zero-day exploited in attacks
      Israeli cybersecurity firm Check Point Software has addressed an actively exploited zero-day flaw in the company's SmartConsole graphical user interface (GUI) admin panel. [...]
  - (2026-07-23) [The Hacker News] Check Point Patches Exploited SmartConsole Flaw Allowing Full Admin Access
      Check Point has released security updates to address multiple vulnerabilities impacting Security Management and Multi-Domain Management (MDSM) products, including a critical flaw that has come under active exploitation i…
  - (2026-07-23) [Ars Technica] Orcas team up to ram sunfish until they explode
      “We think this may help younger orcas feed more easily, or it could also just be for fun.”
  - (2026-07-23) [TechCrunch] ServiceNow bets $40 million on Indian banking software specialist to expand its financial services push
      ServiceNow's investment gives BusinessNext a strategic partner to expand its AI-powered banking software globally.
  - (2026-07-22) [BleepingComputer] Upbound says hack caused $13 million in fraudulent Acima leases
      The Upbound Group fintech company disclosed that threat actors who stole data from its systems leveraged it to create $13 million in Acima leases. [...]

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-07-23) BAF77 (Belgium)
      icao24: 44b2ad · position: (51.6499, -0.275) · alt: 830m · 355km/h
  - (2026-07-23) INDIA1 (India)
      icao24: 800585 · position: (42.2145, 23.2142) · alt: 9144m · 923km/h
  - (2026-07-23) NCR819 (United States)
      icao24: aa3086 · position: (37.9334, 23.936) · on ground · 18km/h
  - (2026-07-23) SAMU37 (France)
      icao24: 39ca87 · position: (47.2582, 1.3159) · alt: 266m · 224km/h
  - (2026-07-23) RCH461 (United States)
      icao24: ae4d66 · position: (55.6912, -11.6681) · alt: 10668m · 856km/h
  - (2026-07-23) PUMA44 (Slovenia)
      icao24: 506e18 · position: (45.9001, 15.5404) · alt: 243m · 142km/h

### GDACS — global disaster alerts — 26 new of 228 total
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 108 total
  - (2026-07-23) [BIS Entity List] page checksum b562eee9df45
      Page content hash: b562eee9df45. Compare with prior day's hash to detect updates.
  - (2026-07-23) [USASpending] $42,096,094,267 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-07-23) [USASpending] $34,256,470,773 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS
  - (2026-07-23) [USASpending] $30,543,975,956 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-07-23) [USASpending] $19,743,215,928 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…
  - (2026-07-23) [USASpending] $3,083,020,287 → OAK RIDGE ASSOCIATED UNIVERSITIES, INCORPORATED: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIEN
      Agency: Department of Energy. Description: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIENCE AND EDUCATION

### USGS earthquakes (M4.5+, past day) — 16 new of 20 total
  - (2026-07-23) M 5.1 - central Mid-Atlantic Ridge
      M5.1 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-07-22) M 5.1 - 61 km SSW of San Pedro de Atacama, Chile
      M5.1 · 61 km SSW of San Pedro de Atacama, Chile · depth 108.731 km
  - (2026-07-22) M 5.0 - Kermadec Islands, New Zealand
      M5.0 · Kermadec Islands, New Zealand · depth 46.903 km
  - (2026-07-22) M 4.9 - 17 km NW of Hihifo, Tonga
      M4.9 · 17 km NW of Hihifo, Tonga · depth 71.248 km
  - (2026-07-22) M 4.9 - 104 km ENE of Port-Olry, Vanuatu
      M4.9 · 104 km ENE of Port-Olry, Vanuatu · depth 10 km
  - (2026-07-22) M 4.9 - Kermadec Islands, New Zealand
      M4.9 · Kermadec Islands, New Zealand · depth 35 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-23) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $2,083,112 · resolves 2026-06-01
  - (2026-07-23) LoL: JD Gaming vs Anyone's Legend (BO3) - LPL Group Ascend
      yes price: 37% · 24h volume: $782,782 · resolves 2026-07-23
  - (2026-07-23) Will the Fed decrease interest rates by 50+ bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $638,975 · resolves 2026-07-29
  - (2026-07-23) LoL: JD Gaming vs Anyone's Legend - Game 1 Winner
      yes price: 26% · 24h volume: $486,189 · resolves 2026-07-23
  - (2026-07-23) Israel x Iran ceasefire continues through July 22?
      yes price: 100% · 24h volume: $417,957 · resolves 2026-07-22
  - (2026-07-23) Trump out as President by July 31?
      yes price: 0% · 24h volume: $305,330 · resolves 2026-07-31

### Paper Trading Scorecard — 12 new of 137 total
  - (2026-07-23) [Polymarket] Will OpenAI's valuation hit (HIGH) $2.0T by December 31?
      This market will resolve to "Yes" if OpenAI's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or exc…
  - (2026-07-23) [Manifold] Will Isaac King set his curtain on fire?
  - (2026-07-23) [Manifold] Will "Announcing the Corrigibility Research Fund" make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-07-23) [Manifold] Will Intel Stock (INTC) reach $150 in 2026?
  - (2026-07-23) [Manifold] Will an AI generate $1M in profit by the end of 2029?
  - (2026-07-23) [Manifold] Will Bitcoin be higher 7 days from now?

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-07-22) U.S. Court of International Trade: Bridgestone Americas Tire Operations, LLC v. United States
  - (2026-07-22) U.S. Court of Appeals, 11th Cir.: United States v. Gray Rivera
  - (2026-07-22) U.S. Court of Appeals, 6th Cir.: United States v. Martin Murff
  - (2026-07-22) U.S. Court of Appeals, 9th Cir.: Torres-Casas v. Blanche
  - (2026-07-22) Delaware Supreme Court: Joanne Mondragon, as parent and guardian of J.W., a minor v. The Board of Education of The Colonial School District
  - (2026-07-22) Delaware Supreme Court: Summit Healthcare Operating Partnership, L.P. v. Best Years, LLC

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-23) [China] Beyond beer -- China brews new experiences to drive consumption
      shanghainews.net · English
  - (2026-07-23) [China] iQOO 15 Ultra Is Finally Heading Global
      gizchina.com · English
  - (2026-07-23) [China] China Vanke wins Shenzhen Metro loan to complete bond extension
      chinaeconomicreview.com · English
  - (2026-07-23) [China] A united front
      chinaeconomicreview.com · English
  - (2026-07-23) [China] Chinese AI model used to stop rogue OpenAI agent
      chinaeconomicreview.com · English
  - (2026-07-23) [China] Beijing pushes back against EU fines to Chinese e - commerce giants
      chinaeconomicreview.com · English

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-23) [Marginal Revolution] What should I ask Gita Gopinath?
      Yes I will be doing a Conversation with her. From Wikipedia: Gita Gopinath…is an Indian-American economist who is currently serving as the Gregory and Ania Coffey professor of Economics at Harvard University and previous…
  - (2026-07-23) [Marginal Revolution] My excellent Conversation with Andrew Graham-Dixon
      Here is the audio, video, and transcript. From the episode summary: Tyler and Andrew discuss whether it was inevitable we’d rediscover Vermeer, how that vanishingly rare sect left its fingerprints all over his life, why…
  - (2026-07-22) [Marginal Revolution] Solve for the equilibrium
      Something that the Ukraine and Iran wars have taught me is that for a lot of countries, including very big countries, there are a small number of buildings and infrastructure components that are required for their econom…
  - (2026-07-22) [Conversable Economist] Chokepoints for Ocean Trade: Strait of Hormuz, and What Else?
      For those who can be fuzzy on global geography, like me, it’s perhaps useful to say that the Persian Gulf is a body of water bordered by eight countries: Bahrain, Iran, Iraq, Kuwait, Qatar, Saudi Arabia, the United Arab…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 38 total
  - (2026-07-23) #30 Germán Larrea Mota Velasco & family — $65.27B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-23) MOVER ▲ Masayoshi Son — $69.08B (+$2.32B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-23) MOVER ▼ Tadashi Yanai & family — $64.56B ($-1.08B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-07-22) CVE-2026-16232 · Check Point SmartConsole: Check Point SmartConsole Improper Authentication Vulnerability
      vendor: Check Point · product: SmartConsole · CISA remediation by 2026-07-25
  - (2026-07-22) CVE-2026-50522 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-25

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=41, 7d-median=20, 14d-median=20; carrying terms: based, coast, establishing, regulated, allow, commission, environment, guard, regulatory, action, unless, final
- state_bills: today=0, 7d-median=120, 14d-median=120; carrying terms: funding, codes, january, grant, investments, entities, services, including, receive, legal, government, ending
- state_news: today=816, 7d-median=747, 14d-median=747; carrying terms: funding, campaign, maintaining, march, victories, commentaries, equity, congress, opportunities, string, services, receive
- local_news: today=236, 7d-median=227, 14d-median=227; carrying terms: another, interstate, decoding, center, months, dispatch, festival, games, school, loading, power, national
- foreign_news: today=1004, 7d-median=1019, 14d-median=1019; carrying terms: march, inspection, investments, reiterated, services, lingering, groups, japanese, technology, almost, another, passengers
- chinese_internal: today=293, 7d-median=299, 14d-median=299; carrying terms: cbmizkfvx, blank, cbmia, global, color, cbmidefvx, title, capital, cbmiw, cbmicefvx, cbmiykfvx, cbmickfvx
- russian_internal: today=1074, 7d-median=908, 14d-median=908; carrying terms: httperror, title, bloomberg, financial, novayagazeta, telegram, found, forbidden, journal, istories, guardian, europe
- ukrainian_internal: today=114, 7d-median=125, 14d-median=125; carrying terms: funding, coastal, campaign, httperror, cargo, strike, trump, whether, foreign, scale, since, services
- ukraine_theater: today=370, 7d-median=443, 14d-median=443; carrying terms: procedure, advanced, campaign, mjzan, sfddbhdiu, tddtbezsm, yvvqrxnnnktzdjj, march, nufqeva, mbjfoynjrbgswd, vfbmz, mnrdv
- paper_bets: today=137, 7d-median=144, 14d-median=144; carrying terms: koivun, african, brazil, valuation, trump, successor, decision, trust, cousins, president, arizona, celsius
- weather: today=150, 7d-median=167, 14d-median=167; carrying terms: drainage, coastal, onshore, lightning, mountains, oxnard, early, including, lewis, gusty, warning, especially
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: indicator, total, implied, headline, labor, dexchus, recession, energy, dexuseu, funds, personal, rates
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, futures, nasdaq, bitcoin, credit, range, corporate, natural, close, rates, agriculture, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=117, 14d-median=117; carrying terms: campaign, transnistria, square, cfzomzh, trump, inezudwdeug, guinea, uztejqm, response, foreign, democratic, protecting
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quiverquant, congresstrading, httperror, https, quantitative, client, unauthorized, quiver
- billionaires: today=38, 7d-median=36, 14d-median=36; carrying terms: family, spacex, ballmer, adani, nasdaq, diversified, charles, zhang, buffett, ambani, sergey, retail
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, investments, insurance, blanche, international, bernardo, charles, appeals, trade, district, supreme, corona
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, thomas, michael, holdings, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, warner, brown, ocasio, receipts, lindsey, action, angels, ossoff, trone, pinkston, house
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=50, 7d-median=46, 14d-median=46; carrying terms: english, chinese, perimeter, russian, sanctions, themes, russia, against, calls, vietnamese, military, german
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=20, 14d-median=20; carrying terms: belgium, kingdom, position, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: associated, diphtheria, african, guinea, additi, march, complete, natural, index, response, arachidonic, january
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: appliances, request, unrestricted, improper, command, management, restrictive, directory, balbooa, langflow, product, protocol
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=228, 7d-median=165, 14d-median=165; carrying terms: salvador, bulgaria, brazil, guinea, impact, panama, germany, agricultural, denmark, switzerland, earthquake, monaco
- usgs_quakes: today=20, 7d-median=20, 14d-median=20; carrying terms: puerto, depth, mexico, islands, madero, kermadec, indonesia, philippines, atlantic, ridge, region, vanuatu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, interest, rates, resolves, minister, ethiopia, meeting, volume, price, mekonnen, demeke, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: sustainable, conve, referring, effects, refer, positive, things, useful, toward, overall, lecture, vibes
- tech_news: today=52, 7d-median=56, 14d-median=56; carrying terms: actors, advanced, trump, computer, plates, computerweekly, including, government, innovation, cryptographic, technology, almost
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: cisneros, taylor, mccollum, wright, bynum, trump, emily, fletcher, curtis, zachary, landsman, boebert
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, unavailable, either, claude, converges, sufficient, markets, decision, placed, identify, paper, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-07-21] ECB press: July 2026 euro area bank lending survey

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*