# WORLDSCOPE morning brief — 2026-07-23

## Headline
3257 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (694) · Russian Internal News (state + in-exile) (686) · State-Level News (389) · World leaders & government officials (324) · Chinese Internal News (223) · Local News: St. Louis + Atlanta (194) · Ukraine Theater (total-war monitoring) (173) · U.S. Weather + Severe / Climate Outlooks (142) · GDELT GKG — themes / entities / watch areas (75) · Ukrainian Internal News (national + local Kyiv) (59) · U.S. Federal Action (41) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 694 new of 989 total
  - (2026-07-23) [Global] UK millionaires ask Andy Burnham to tax them more
      Former footballer Gary Lineker and producer Brian Eno write to the new PM telling him "we can afford it".
  - (2026-07-23) [Global] Airport drop-off fees up by a third - here are the priciest
      The cost of parking closest to the terminal has hit £10 at two of the UK's airports.
  - (2026-07-23) [Global] Big bosses reveal the secret to getting hired
      Business leaders share their best career advice and the qualities they look for when recruiting new staff.
  - (2026-07-23) [Global] Firm hacked by rogue OpenAI models says it is 'a wake-up call'
      A co-founder of start-up Hugging Face told the BBC that most firms are not aware that the "game has changed".
  - (2026-07-23) [Global] Google burning through cash with spiralling AI costs
      The company said earlier this year it expected to spend as much as $190bn on AI investments.
  - (2026-07-22) [Global] Why the UK is dithering over what to do about e-scooters
      Why is it taking so long for the government to regulate them, and what are the consequences of delay?

### Russian Internal News (state + in-exile) — 686 new of 1125 total
  - (2026-07-23) Евросоюз согласовал 21-й пакет санкций против России | LEDE: Послы стран Евросоюза согласовали 21-й пакет санкций против России, сообщила глава Еврокомиссии Урсула фон дер Ляйен. ] (ru: Евросоюз согла…
      Послы стран Евросоюза согласовали 21-й пакет санкций против России, сообщила глава Еврокомиссии Урсула фон дер Ляйен.
  - (2026-07-23) Удары украинских дронов затронули около 10% складских площадей Wildberries | LEDE: Украинские военные за неделю нанесли удары дронами по складам Wildberries общей площадью 552 тысячи квадрат] (ru: Уда…
      Украинские военные за неделю нанесли удары дронами по складам Wildberries общей площадью 552 тысячи квадратным метров, что составляет примерно 10% логистических мощностей маркетплейса, подсчитал «Коммерсант» на основе от…
  - (2026-07-23) The Washington Post: в администрации Трампа обсуждают военную операцию в Мали (там находятся российские наемники) | LEDE: Администрация Дональда Трампа рассматривает возможность проведения в] (ru: The…
      Администрация Дональда Трампа рассматривает возможность проведения военной операции в Мали против связанной с «Аль-Каедой» джихадистской группировки JNIM. Об этом сообщила The Washington Post со ссылкой на источники.
  - (2026-07-23) В доме, где родился Адольф Гитлер, открыли полицейский участок | LEDE: В австрийском городе Браунау-на-Инн, в доме, где родился Адольф Гитлер, открылся полицейский участок. Официальная церем] (ru: В д…
      В австрийском городе Браунау-на-Инн, в доме, где родился Адольф Гитлер, открылся полицейский участок. Официальная церемония открытия участка, на которой присутствовал, в числе прочих, глава МВД Австрии Герхард Карнер, пр…
  - (2026-07-23) Йеменские хуситы нанесли удар по саудовским танкерам. Трамп пообещал уничтожать мосты и электростанции в Иране в ответ на нападения на гражданские суда | LEDE: Йеменские хуситы, которых подд] (ru: Йем…
      Йеменские хуситы, которых поддерживает Иран, объявили об ударе по танкерам в Красном море, принадлежащим Саудовской Аравии. На спутниковом снимке NASA, сообщает CNN, видно, что на борту одного из танкеров, ходящих под фл…
  - (2026-07-23) FT: ЕС разрешит греческой компании перевозить российский газ ради одобрения нового пакета санкций | LEDE: Греческой судоходной компании Dynagas разрешат продолжить перевозку российского сжиж] (ru: FT:…
      Греческой судоходной компании Dynagas разрешат продолжить перевозку российского сжиженного природного газа (СПГ), несмотря на санкции Евросоюза. Об этом сообщает Financial Times со ссылкой на европейских дипломатов.

### State-Level News — 389 new of 820 total
  - (2026-07-22) [Alabama] Governor Ivey Signs Executive Order Establishing Commission on Screen-Based Instruction
      MONTGOMERY – Governor Kay Ivey on Wednesday signed Executive Order No. 745 establishing the Governor’s Commission on Screen-Based Instruction to study the use, risks and benefits of screen-based instruction in Alabama’s…
  - (2026-07-22) [Alabama] Executive Order 745
      Download
  - (2026-07-22) [Alabama] Executive Order 744
      Download
  - (2026-07-22) [California] Lo que revela la venta de dos centros de detención del ICE sobre la nueva estrategia migratoria de Trump.
      <img width="1024" height="671" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092225-CalCity-Detention-MV-CM-09.jpg?fit=1024%2C671&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-22) [California] Universidad Estatal de California otorga un puesto de $340,000 a expresidente que dimitió tras una demanda por discriminación
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072126-Tomas-Morales-CM-02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-07-22) [California] Cal State gives $340K job to ex-president who stepped down after discrimination lawsuit
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072126-Tomas-Morales-CM-02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 223 new of 294 total
  - (2026-07-22) Vanke Wins New Funding as It Completes Extensions on 2026 Public Bonds - Caixin Global
      Vanke Wins New Funding as It Completes Extensions on 2026 Public Bonds Caixin Global
  - (2026-07-23) 江苏苏州：“黄金——中西方交流中的贵金属”展览开幕 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE5DbzBTTnhZRS1TMmxyOTAwOHUyc0ZtU1dDdVh5M0ZNZXNEQWo0RGZuT1ZKckZEN19sY2M1RVNURXpfZ0xYdFIzSG] (zh:…
      江苏苏州：“黄金——中西方交流中的贵金属”展览开幕 人民网-图片频道
  - (2026-07-22) 原创报道 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5NVEJ0c2gtcUhPWXdGWGNaN2xHaWVTaDF0MUtuQzlqbHFxcDhxaWUwSGxGMG1YTGp2TUZSOXg5QnBhX2U2ZXZnQlRXSUdmNjlKa0Mwd2E2QUt] (zh:…
      原创报道 中国共产党新闻网
  - (2026-07-23) 人民建议·献策｜未来5年，我国能源国际合作应转向“四链”协同 - 人民网“领导留言板” | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTFBvT2YtTklYMzcyQU5LVFhZWkh5QzhFU2J1dnNNWHRzMEViVjhTemxfT3ZIOUstODl6UUl2RHloUV9nRTB] (zh:…
      人民建议·献策｜未来5年，我国能源国际合作应转向“四链”协同 人民网“领导留言板”
  - (2026-07-23) 一路走好！全国最后一位长征女红军王全英逝世 - 人民网－四川频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1qcTJMQWFIM05sMDFpN01NUGpHRXN5QlAyLUZtQVR3UFZRUGxTSkhpQkRZZURtOTJnaWFvb2tOVFdyU2FZTU4yenVIaU] (zh:…
      一路走好！全国最后一位长征女红军王全英逝世 人民网－四川频道
  - (2026-07-23) 伊媒：美军袭击伊朗同伊拉克口岸已致2人死亡--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9pelJHLThIdHJ2TVFRV1BodWxLcWVuTVN1ZUNTeXEzbzFHZDIycm5zZ19NQTJHdGtRY3Y3UGRiY1o5NkEtLS1ra0RPWWp] (zh:…
      伊媒：美军袭击伊朗同伊拉克口岸已致2人死亡--国际 人民网

### Local News: St. Louis + Atlanta — 194 new of 235 total
  - (2026-07-23) [St. Louis] Where in the Lou? – 7/23/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-07-22) [St. Louis] First these highway signs didn’t fit. Then came the graffiti
      Three large signs near the Interstates 44 and 55 interchange south of downtown St. Louis aren’t directing much traffic, though they are turning heads. The highway signs, meant to guide highway drivers to Memphis (via sou…
  - (2026-07-22) [St. Louis] Why innovation takes more than a great idea
      Most people have heard the word “ecosystem” in conversations about startups, innovation, or economic development. Outside those industries, it can sound like another business buzzword. Justin Raymundo wants people to thi…
  - (2026-07-22) [St. Louis] Best ice cream sandwiches in St. Louis
      A Spoonful of Sugar A Spoonful of Sugar makes its own ice cream. It also bakes its own cookies. While it does not have a composed ice cream sandwich on its menu, it’s become a thing for patrons of the parlor to combine t…
  - (2026-07-22) [St. Louis] Duane Reed Gallery’s ‘Small Works Invitational’ returns to highlight regional artists
      From renowned artists like Jane Sauer, whose work has been shown at the Smithsonian and the Saint Louis Art Museum, to up-and-coming local artists, the Small Works Invitational at Duane Reed Gallery (4729 McPherson) will…
  - (2026-07-22) [St. Louis] Where in Clayton 7/23/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…

### Ukraine Theater (total-war monitoring) — 173 new of 370 total
  - (2026-07-23) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-22) [FIRMS] thermal anomaly 47.333, 34.665 (FRP 11.68 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-22 0909Z, FRP 11.68 MW
  - (2026-07-22) [FIRMS] thermal anomaly 47.330, 34.656 (FRP 9.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-22 0909Z, FRP 9.01 MW
  - (2026-07-22) [FIRMS] thermal anomaly 47.325, 34.660 (FRP 16.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-22 0909Z, FRP 16.86 MW
  - (2026-07-22) [FIRMS] thermal anomaly 50.379, 33.874 (FRP 5.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-22 0911Z, FRP 5.52 MW
  - (2026-07-22) [FIRMS] thermal anomaly 44.773, 33.862 (FRP 1.67 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-22 1049Z, FRP 1.67 MW

### U.S. Weather + Severe / Climate Outlooks — 142 new of 150 total
  - (2026-07-23) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 23 at 2:36AM PDT until July 27 at 9:00PM PDT by NWS Hanford CA
      * WHAT...Dangerously hot conditions with high temperatures between 108 to 112 degrees. * WHERE...Indian Wells Valley and Mojave Desert. * WHEN...From 8 AM this morning to 9 PM PDT Monday. * IMPACTS...Heat related illness…
  - (2026-07-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-23) [Severe] Fire Weather Watch: Fire Weather Watch issued July 23 at 2:31AM PDT until July 24 at 8:00PM PDT by NWS Medford OR
      The National Weather Service in Medford has issued a Fire Weather Watch, which is in effect from Friday afternoon through Friday evening. * IMPACTS...Any fires that develop will likely spread rapidly. * AFFECTED AREA...M…
  - (2026-07-23) [Severe] Fire Weather Watch: Fire Weather Watch issued July 23 at 2:31AM PDT until July 25 at 9:00PM PDT by NWS Medford OR
      * IMPACTS...Any fires that develop will likely spread rapidly. * AFFECTED AREA...In northern California in Fire Weather Zones 284 and 285, including the Klamath, Shasta and Modoc National Forests. In Oregon, nearly all a…
  - (2026-07-23) [Moderate] Gale Warning: Gale Warning issued July 23 at 1:31AM AKDT until July 24 at 5:00AM AKDT by NWS Anchorage AK
      Offshore waters forecast for the Gulf of Alaska West of 144W Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and…
  - (2026-07-23) [Severe] Flood Watch: Flood Watch issued July 23 at 3:22AM MDT until July 23 at 8:00PM MDT by NWS Riverton WY
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of central and northwest Wyoming, including the following areas, in central Wyoming, Owl Creek and Bridger Mountains, and East W…

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-07-23) [Russia oil sanctions perimeter · themes] ЦБ Турции сохранит ключевую ставку без изменений , заявил аналитик
      1prime.ru · Russian · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] TotalEnergies double son bénéfice net au 2e trimestre à 5 , 4 milliards de dollars
      lessentiel.lu · French · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] ЦБ купил юаней на внутреннем рынке на 4 , 8 миллиарда рублей
      1prime.ru · Russian · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] Félelmetes atommeghajtású csatacirkálóval rukkolt elő Moszkva , de az egész koncepció egy nagy zsákutca lehet
      portfolio.hu · Hungarian · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] Neues Paket mit Strafmaßnahmen : Einigung in Brüssel : EU verhängt neue Russland - Sanktionen - Politik
      rhein-zeitung.de · German · tone NA
  - (2026-07-23) [Russia oil sanctions perimeter · themes] 中聯油案501項產品可重新上架 食藥署 ： 由地方監督 、 業者自主決定 - 生活
      news.ltn.com.tw · Chinese · tone NA

### Ukrainian Internal News (national + local Kyiv) — 59 new of 114 total
  - (2026-07-23) EU Reportedly Agrees on 21st Russia Sanctions Package
      EU ambassadors have agreed on the bloc’s 21st sanctions package against Russia after weeks of disputes over measures targeting Moscow. The deal follows objections from several member states that forced Brussels to scale…
  - (2026-07-23) Russia Says Warned Rubio Against Arms Deliveries to Ukraine
      Russia told the US to stop supplying weapons to Ukraine during Lavrov’s first meeting with Rubio in nearly a year. Moscow also accused Europe of prolonging the war while reiterating its readiness for a diplomatic settlem…
  - (2026-07-23) Russia Restricts Nighttime Shipping at its Largest Cargo Port After Ukrainian Drone Attacks
      Russia has reportedly imposed nighttime restrictions at Novorossiysk, its largest cargo port, as Ukrainian attacks disrupt Black Sea shipping. The measures, alongside disruptions on Ukraine’s coast, have tightened grain…
  - (2026-07-23) Kremlin Prepares for Mobilization as Putin Downplays Deepening Fuel Crisis
      ISW says Russia is preparing legal and security measures for possible mobilization while bracing for domestic unrest. Despite worsening fuel shortages and mounting economic pressure, Putin insists the economy remains sta…
  - (2026-07-23) 223-Drone Raid Hits Russian Regions, Sparking Fires at Oil and Energy Facilities
      Ukraine reportedly struck a Wildberries logistics hub, an oil refinery, and a major oil pipeline station during overnight drone attacks. Russia said it intercepted 223 drones while acknowledging casualties and damage acr…
  - (2026-07-23) ISW Russian Offensive Campaign Assessment, July 22, 2026
      Latest from the Institute for the Study of War.

### U.S. Federal Action — 41 new of 41 total
  - (2026-07-23) Continuation of the National Emergency With Respect to Mali
  - (2026-07-23) Securing America's Defense Supply Chains and Ensuring Domestic Acquisition of Critical Materials
  - (2026-07-23) Made in America Week, 2026
  - (2026-07-23) Captive Nations Week, 2026
  - (2026-07-23) Imposing Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Motor Vehicles
  - (2026-07-23) Imposing Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Dairy

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-23) [TKO Group Holdings, Inc.] Form 4 (Issuer)
      filed 2026-07-23 01:40 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001193125-26-312814 Size: 14 KB
  - (2026-07-23) [Khan Nick] Form 4 (Reporting)
      filed 2026-07-23 01:40 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001193125-26-312814 Size: 14 KB
  - (2026-07-23) [Lustgarten Shai Shalom] Form 4 (Reporting)
      filed 2026-07-23 01:27 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001493152-26-034286 Size: 5 KB
  - (2026-07-23) [OMNIQ Corp.] Form 4 (Issuer)
      filed 2026-07-23 01:27 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001493152-26-034286 Size: 5 KB
  - (2026-07-23) [Columbia Financial, Inc./MD/] Form 4 (Issuer)
      filed 2026-07-23 01:24 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001731363-26-000007 Size: 327 KB
  - (2026-07-23) [Van Dyk Robert] Form 4 (Reporting)
      filed 2026-07-23 01:24 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001731363-26-000007 Size: 327 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 38 new of 57 total
  - (2026-07-23) [BleepingComputer] Microsoft working to fix Exchange Online mailbox quarantine issue
      Microsoft is working to resolve an ongoing Exchange Online issue that has been mistakenly quarantining customers' mailboxes since Sunday. [...]
  - (2026-07-23) [BleepingComputer] Check Point warns of SmartConsole zero-day exploited in attacks
      Israeli cybersecurity firm Check Point Software has addressed an actively exploited zero-day flaw in the company's SmartConsole graphical user interface (GUI) admin panel. [...]
  - (2026-07-23) [The Hacker News] Check Point Patches Exploited SmartConsole Flaw Allowing Full Admin Access
      Check Point has released security updates to address multiple vulnerabilities impacting Security Management and Multi-Domain Management (MDSM) products, including a critical flaw that has come under active exploitation i…
  - (2026-07-23) [The Register] UK pumps £708 million into its future fighter jet
      Tempest cash lands alongside hypersonic target contract and BAE's 'loyal wingman' drone reveal
  - (2026-07-23) [The Register] Britain isn't considering datacenters' thirst for water in its 'AI superpower' ambitions
      Grand compute push could end up as dry as England's reservoirs unless ministers act fast
  - (2026-07-23) [The Register] Talking smack about a doctor got him access to private medical files
      Who needs a working security badge when you know how to talk your way into the records room?

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-07-23) BAF77 (Belgium)
      icao24: 44b2ad · position: (51.5497, -0.4145) · on ground
  - (2026-07-23) INDIA1 (India)
      icao24: 800585 · position: (43.6191, 24.7648) · alt: 7795m · 723km/h
  - (2026-07-23) RCH461 (United States)
      icao24: ae4d66 · position: (55.7227, -8.2918) · alt: 10668m · 859km/h
  - (2026-07-23) GAF893 (Germany)
      icao24: 3f97fd · position: (60.9759, 1.568) · alt: 10355m · 775km/h
  - (2026-07-23) JAF29J (Belgium)
      icao24: 44d2b6 · position: (39.3095, 17.7766) · alt: 11582m · 756km/h
  - (2026-07-23) JAF3NE (Belgium)
      icao24: 44d2ab · position: (47.7363, 0.7471) · alt: 10972m · 757km/h

### GDACS — global disaster alerts — 26 new of 228 total
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)

### USGS earthquakes (M4.5+, past day) — 18 new of 21 total
  - (2026-07-23) M 5.1 - 107 km SE of Atka, Alaska
      M5.1 · 107 km SE of Atka, Alaska · depth 5 km
  - (2026-07-23) M 5.1 - 85 km SE of Tatsugō, Japan
      M5.1 · 85 km SE of Tatsugō, Japan · depth 10 km
  - (2026-07-23) M 5.1 - central Mid-Atlantic Ridge
      M5.1 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-07-22) M 5.1 - 61 km SSW of San Pedro de Atacama, Chile
      M5.1 · 61 km SSW of San Pedro de Atacama, Chile · depth 108.731 km
  - (2026-07-22) M 5.0 - Kermadec Islands, New Zealand
      M5.0 · Kermadec Islands, New Zealand · depth 46.903 km
  - (2026-07-22) M 4.9 - 17 km NW of Hihifo, Tonga
      M4.9 · 17 km NW of Hihifo, Tonga · depth 71.248 km

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 108 total
  - (2026-07-23) [BIS Entity List] page checksum b562eee9df45
      Page content hash: b562eee9df45. Compare with prior day's hash to detect updates.
  - (2026-07-23) [USASpending] $42,096,094,267 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-07-23) [USASpending] $34,256,470,773 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS
  - (2026-07-23) [USASpending] $30,543,975,956 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-07-23) [USASpending] $19,743,215,928 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…
  - (2026-07-23) [USASpending] $3,083,020,287 → OAK RIDGE ASSOCIATED UNIVERSITIES, INCORPORATED: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIEN
      Agency: Department of Energy. Description: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIENCE AND EDUCATION

### Paper Trading Scorecard — 13 new of 140 total
  - (2026-07-23) [Polymarket] Will OpenAI's valuation hit (HIGH) $2.0T by December 31?
      This market will resolve to "Yes" if OpenAI's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or exc…
  - (2026-07-23) [Polymarket] Will the Texas Rangers win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-07-23) [Manifold] Will Isaac King set his curtain on fire?
  - (2026-07-23) [Manifold] Will "Announcing the Corrigibility Research Fund" make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-07-23) [Manifold] Will Intel Stock (INTC) reach $150 in 2026?
  - (2026-07-23) [Manifold] Will an AI generate $1M in profit by the end of 2029?

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-23) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $2,083,112 · resolves 2026-06-01
  - (2026-07-23) LoL: JD Gaming vs Anyone's Legend (BO3) - LPL Group Ascend
      yes price: 56% · 24h volume: $797,372 · resolves 2026-07-23
  - (2026-07-23) LoL: JD Gaming vs Anyone's Legend - Game 1 Winner
      yes price: 60% · 24h volume: $690,316 · resolves 2026-07-23
  - (2026-07-23) Will the Fed decrease interest rates by 50+ bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $642,105 · resolves 2026-07-29
  - (2026-07-23) Israel x Iran ceasefire continues through July 22?
      yes price: 100% · 24h volume: $417,985 · resolves 2026-07-22
  - (2026-07-23) Trump out as President by July 31?
      yes price: 0% · 24h volume: $305,330 · resolves 2026-07-31

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-07-22) U.S. Court of International Trade: Bridgestone Americas Tire Operations, LLC v. United States
  - (2026-07-22) U.S. Court of Appeals, 11th Cir.: United States v. Gray Rivera
  - (2026-07-22) U.S. Court of Appeals, 7th Cir.: BBLI Edison, LLC v. City of Chicago
  - (2026-07-22) U.S. Court of Appeals, 8th Cir.: BSI Group LLC v. Solid Financial Technologies
  - (2026-07-22) Delaware Supreme Court: Joanne Mondragon, as parent and guardian of J.W., a minor v. The Board of Education of The Colonial School District
  - (2026-07-22) Delaware Supreme Court: Summit Healthcare Operating Partnership, L.P. v. Best Years, LLC

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-23) [South Korea] 7 Must - Watch So Ji Sub K - Dramas
      soompi.com · English
  - (2026-07-23) [South Korea] [ Column ] Korea brave new world : Tanking employment and soaring home prices
      hani.co.kr · English
  - (2026-07-23) [South Korea] UNESCO Panel Calls on Japan to Fully Disclose Korean Forced Labor at Sado Mines
      world.kbs.co.kr · English
  - (2026-07-23) [South Korea] The Wind reveal Park Kyung - produced tracklist
      allkpop.com · English
  - (2026-07-23) [South Korea] KOSPI Spikes More than 4 % on Tech Rally
      world.kbs.co.kr · English
  - (2026-07-23) [South Korea] Galaxy Z Flip 8 is thinner , lighter , and stronger than the Galaxy Z Flip 7
      sammobile.com · English

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-23) [Marginal Revolution] What should I ask Gita Gopinath?
      Yes I will be doing a Conversation with her. From Wikipedia: Gita Gopinath…is an Indian-American economist who is currently serving as the Gregory and Ania Coffey professor of Economics at Harvard University and previous…
  - (2026-07-23) [Marginal Revolution] My excellent Conversation with Andrew Graham-Dixon
      Here is the audio, video, and transcript. From the episode summary: Tyler and Andrew discuss whether it was inevitable we’d rediscover Vermeer, how that vanishingly rare sect left its fingerprints all over his life, why…
  - (2026-07-22) [Marginal Revolution] Solve for the equilibrium
      Something that the Ukraine and Iran wars have taught me is that for a lot of countries, including very big countries, there are a small number of buildings and infrastructure components that are required for their econom…
  - (2026-07-22) [Conversable Economist] Chokepoints for Ocean Trade: Strait of Hormuz, and What Else?
      For those who can be fuzzy on global geography, like me, it’s perhaps useful to say that the Persian Gulf is a body of water bordered by eight countries: Bahrain, Iran, Iraq, Kuwait, Qatar, Saudi Arabia, the United Arab…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 38 total
  - (2026-07-23) #30 Germán Larrea Mota Velasco & family — $65.27B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-23) MOVER ▲ Masayoshi Son — $69.08B (+$2.32B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-23) MOVER ▼ Tadashi Yanai & family — $64.56B ($-1.08B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-07-22) CVE-2026-16232 · Check Point SmartConsole: Check Point SmartConsole Improper Authentication Vulnerability
      vendor: Check Point · product: SmartConsole · CISA remediation by 2026-07-25
  - (2026-07-22) CVE-2026-50522 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-25

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=41, 7d-median=20, 14d-median=20; carrying terms: environment, amendment, authorized, proposing, commission, final, vessels, establishing, protect, regulatory, action, marine
- state_bills: today=0, 7d-median=120, 14d-median=120; carrying terms: schools, place, specifying, amendment, supplemental, critical, includes, proceeds, employees, services, human, application
- state_news: today=820, 7d-median=747, 14d-median=747; carrying terms: seats, leading, teachers, ordered, place, march, ballots, recent, amendment, supplemental, merger, prices
- local_news: today=235, 7d-median=227, 14d-median=227; carrying terms: image, killed, lettuce, world, atlanta, water, deadly, staying, again, blank, metro, announced
- foreign_news: today=989, 7d-median=1019, 14d-median=1019; carrying terms: leading, teachers, ordered, march, sonam, environment, halts, chairman, image, inflation, uttarakhand, debate
- chinese_internal: today=294, 7d-median=299, 14d-median=299; carrying terms: cbmix, blank, cbmizkfvx, cbmidefvx, articles, chinese, cbmibkfvx, cbmibefvx, cbmiy, cbmiakfvx, cbmixkfvx, lxtfb
- russian_internal: today=1125, 7d-median=908, 14d-median=908; carrying terms: raquo, client, journal, europe, financial, https, novaya, variety, wildberries, street, reuters, bloomberg
- ukrainian_internal: today=114, 7d-median=125, 14d-median=125; carrying terms: cooperation, major, place, recent, meeting, officials, includes, offensive, https, economic, services, target
- ukraine_theater: today=370, 7d-median=443, 14d-median=443; carrying terms: fksjzbtejsslfjee, jcxiyq, yamplq, yxzsbulet, march, zocum, owtkvlmxyxzgpound, snnfdvpmtljhewnyodnblvr, bmfqcml, dvnht, authorized, dzbwc
- paper_bets: today=140, 7d-median=144, 14d-median=144; carrying terms: seats, valid, levels, cooperation, publicly, place, scheduled, leave, maine, roberto, august, visit
- weather: today=150, 7d-median=167, 14d-median=167; carrying terms: thursday, threat, tropical, remains, afdfwd, louis, worth, radar, statement, capable, beach, includes
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpilfesl, unemployment, dexuseu, sheet, pcepilfe, effective, payrolls, total, supply, personal, growth, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: large, crypto, agriculture, corporate, proxy, futures, china, equities, bitcoin, natural, close, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=117, 14d-median=117; carrying terms: question, syria, schools, nicaragua, acronym, uywvtbm, etdgwzzxq, dfnhytmghfegjqzw, tunisia, contractor, rsale, manufacturers
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quiver, httperror, client, https, congresstrading, unauthorized, error, quantitative
- billionaires: today=38, 7d-median=36, 14d-median=36; carrying terms: buffett, julia, ballmer, gates, yanai, euronext, oracle, google, peterffy, facebook, france, googl
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: bernardo, district, supreme, charles, children, trade, state, romero, steel, appeals, investments, limited
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, accno, reporting, thomas, holdings, michael, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: political, receipts, krishnamoorthi, brown, cooper, elect, james, colorado, lindsey, platner, robert, michael
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=75, 7d-median=46, 14d-median=46; carrying terms: english, israel, hezbollah, chinese, trump, sanctions, perimeter, themes, russia, russian, arabic, vietnamese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=20, 14d-median=20; carrying terms: canada, belgium, kingdom, position
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: surges, sentinel, levels, formula, appropriate, epizootics, infecting, remains, substantial, contamination, ratio, distributed
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: forgery, vendor, association, federation, mechanism, protocol, dangerous, control, option, request, management, lockout
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=228, 7d-median=165, 14d-median=165; carrying terms: belarus, tropical, somalia, sweden, france, nicaragua, congo, bosnia, canada, green, venezuela, russia
- usgs_quakes: today=21, 7d-median=20, 14d-median=20; carrying terms: puerto, depth, indonesia, madero, kermadec, mexico, islands, atlantic, philippines, ridge, vanuatu, region
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, rates, volume, meeting, price, ethiopia, minister, interest, prime, mekonnen, demeke, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, useful, perhaps, interview, particular, movement, longer, progress, https, lecture, economist, refer
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: threat, question, major, request, recent, careers, sheets, beach, bayley, papers, better, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: boebert, mfume, lamonica, carter, zachary, simon, lindsey, blake, louis, murphy, august, speech
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, module, decision, consensus, paper, converges, either, market, placement, markets, evidence, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-07-21] ECB press: July 2026 euro area bank lending survey

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*