# WORLDSCOPE morning brief — 2026-07-23

## Headline
2468 new items across 23 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (541) · International News + Multilateral Institutions (529) · State-Level News (330) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (164) · Chinese Internal News (123) · U.S. Weather + Severe / Climate Outlooks (122) · Ukraine Theater (total-war monitoring) (70) · GDELT GKG — themes / entities / watch areas (47) · Ukrainian Internal News (national + local Kyiv) (46) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### Russian Internal News (state + in-exile) — 541 new of 1003 total
  - (2026-07-23) США хотят закупить для Украины 150 пулеметов для борьбы с дронами | LEDE: ] (ru: США хотят закупить для Украины 150 пулеметов для борьбы с дронами)
  - (2026-07-23) В МЧС назвали опасную для купания температуру воды | LEDE: ] (ru: В МЧС назвали опасную для купания температуру воды)
  - (2026-07-23) Карлсон заявил, что Трамп разделяет его оценку об Израиле | LEDE: ] (ru: Карлсон заявил, что Трамп разделяет его оценку об Израиле)
  - (2026-07-23) В аэропорту Пензы ввели ограничения на полеты | LEDE: ] (ru: В аэропорту Пензы ввели ограничения на полеты)
  - (2026-07-23) Покушавшиеся на Ермолаева могли получить индульгенцию от ЕС, заявил Азаров | LEDE: ] (ru: Покушавшиеся на Ермолаева могли получить индульгенцию от ЕС, заявил Азаров)
  - (2026-07-23) Эксперт рассказал, что ожидается от встречи Лаврова и Рубио | LEDE: ] (ru: Эксперт рассказал, что ожидается от встречи Лаврова и Рубио)

### International News + Multilateral Institutions — 529 new of 990 total
  - (2026-07-22) [Global] Airport drop-off fees up by a third - here are the priciest
      The cost of parking closest to the terminal just for a few minutes has hit £10 at two of the UK's busiest airports.
  - (2026-07-22) [Global] Former Lloyd's of London boss's relationship breached rules, firm says
      The insurance market's chairman said the CEO's conduct "fell significantly below the standards expected of him".
  - (2026-07-22) [Global] I travel four hours on a bus per day - the bus fare cap will save me £500 a year
      The BBC speaks to people around the country about their view on the newly-announced bus fare cap.
  - (2026-07-22) [Global] Aston Martin secures £550m loan deal
      The luxury car maker says the loans will be used to fund current and future product plans.
  - (2026-07-22) [Global] OpenAI says its AI went rogue and launched 'unprecedented' cyber-attack
      It is one of the first publicly disclosed cyber-attacks carried out by AI without direct human involvement.
  - (2026-07-22) [Global] The borough where families are slowly disappearing
      Islington is a snapshot of a trend playing out across inner London, Britain and much of the world.

### State-Level News — 330 new of 772 total
  - (2026-07-22) [California] Lo que revela la venta de dos centros de detención del ICE sobre la nueva estrategia migratoria de Trump.
      <img width="1024" height="671" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092225-CalCity-Detention-MV-CM-09.jpg?fit=1024%2C671&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-22) [California] Universidad Estatal de California otorga un puesto de $340,000 a expresidente que dimitió tras una demanda por discriminación
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072126-Tomas-Morales-CM-02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-07-22) [California] Cal State gives $340K job to ex-president who stepped down after discrimination lawsuit
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072126-Tomas-Morales-CM-02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-07-22) [California] Gavin Newsom’s balancing act on taxing the rich
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/020226-Newsom-Housing-MO-CM-35.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-07-22) [California] What the sale of 2 ICE detention centers reveals about Trump’s new immigration strategy
      <img width="1024" height="671" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092225-CalCity-Detention-MV-CM-09.jpg?fit=1024%2C671&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-22) [Alabama] Governor Ivey Signs Executive Order Establishing Commission on Screen-Based Instruction
      MONTGOMERY – Governor Kay Ivey on Wednesday signed Executive Order No. 745 establishing the Governor’s Commission on Screen-Based Instruction to study the use, risks and benefits of screen-based instruction in Alabama’s…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 164 new of 222 total
  - (2026-07-22) [St. Louis] First these highway signs didn’t fit. Then came the graffiti
      Three large signs near the Interstates 44 and 55 interchange south of downtown St. Louis aren’t directing much traffic, though they are turning heads. The highway signs, meant to guide highway drivers to Memphis (via sou…
  - (2026-07-22) [St. Louis] Why innovation takes more than a great idea
      Most people have heard the word “ecosystem” in conversations about startups, innovation, or economic development. Outside those industries, it can sound like another business buzzword. Justin Raymundo wants people to thi…
  - (2026-07-22) [St. Louis] Best ice cream sandwiches in St. Louis
      A Spoonful of Sugar A Spoonful of Sugar makes its own ice cream. It also bakes its own cookies. While it does not have a composed ice cream sandwich on its menu, it’s become a thing for patrons of the parlor to combine t…
  - (2026-07-22) [St. Louis] Duane Reed Gallery’s ‘Small Works Invitational’ returns to highlight regional artists
      From renowned artists like Jane Sauer, whose work has been shown at the Smithsonian and the Saint Louis Art Museum, to up-and-coming local artists, the Small Works Invitational at Duane Reed Gallery (4729 McPherson) will…
  - (2026-07-22) [St. Louis] Where in Clayton 7/23/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-07-22) [St. Louis] Flyover Comedy Festival announces David Cross, Dropout Improv, Roy Wood Jr., and more for 2026 fest
      Back for its ninth year, the Flyover Comedy Festival will take over the Delmar Loop from November 11-15 with headliners Dropout Improv, David Cross, Roy Wood Jr., the Sklar Brothers, Dulcé Sloan, and Yakov Smirnoff, amon…

### Chinese Internal News — 123 new of 272 total
  - (2026-07-22) 特稿｜韩国股市版“鱿鱼游戏” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9JenRVVWlXdVBxVDUtRWo5YkJHczFvMUptU19mRkZWaEJiM25RZjdHYS0xWEdlWDk4SHlWclRZaG1YSnQ1Ry04ZDhnNmtrcVdxVTBmYjh] (zh:…
      特稿｜韩国股市版“鱿鱼游戏” 财新
  - (2026-07-22) 高市政权出台首份财经发展方针 重押AI投资转向积极财政 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9SNDdhSk1CTFp1YkVjTDFDQXVueGgxR1lneGZrWGRNb1hEUjNCQ3U2dWFMS3FyTnFHQVVIckhWLURBc1JNVVowMmpOcX] (zh:…
      高市政权出台首份财经发展方针 重押AI投资转向积极财政 财新
  - (2026-07-22) 公募基金二季度净利1.94万亿元 主动权益基金抱团TMT - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5TbkRFZmtBdHZHdUJUZGpRLTFvb3d5VkpMQU02YTlNcE15VmRjNi1wcWhxMjU0QXpGeVRqdUEtV2FNX3ZseUV3UDZVW] (zh:…
      公募基金二季度净利1.94万亿元 主动权益基金抱团TMT 财新
  - (2026-07-22) 大众汽车集团与中国企业合作开发自动驾驶系统 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE44UUpFOWVZVGVuS0lDaGxzTmRGTTFwMVNibktOV1pWWVJibHZlUk5ad3lQV3dXOUYxeEhiRTQ0WW1iUHU3YXF1YmJqWS1kQXlt] (zh:…
      大众汽车集团与中国企业合作开发自动驾驶系统 财新
  - (2026-07-22) 深圳地铁年初至今新增借款45亿元 供万科展期 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9ncHJ6c2lqdU5sNE1FSDNER3NVa3hBU21LaEc1dXMtQ1QtdWNrbnp2Vks4OW1NVVluUU8tYUFBZS1CNmN5c3pKdDRGUGZTMFZ] (zh:…
      深圳地铁年初至今新增借款45亿元 供万科展期 财新
  - (2026-07-22) 商务部回应法国出台“反超快时尚”法、欧委会对速卖通罚款 强调反对歧视性措施 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9HODhWeThxdmc2NENLTXBrQVl2aGNzSlZGX2Fva0NnUDZ4Q0hXRWpCUDZJTTRIM2tSMmtGcFhSa28ycC1p] (zh:…
      商务部回应法国出台“反超快时尚”法、欧委会对速卖通罚款 强调反对歧视性措施 财新

### U.S. Weather + Severe / Climate Outlooks — 122 new of 135 total
  - (2026-07-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-22) [Moderate] Special Weather Statement: Special Weather Statement issued July 22 at 8:00PM EDT by NWS Tampa Bay Ruskin FL
      At 800 PM EDT, Doppler radar was tracking a cluster of strong thunderstorms 9 miles west of Arcadia, moving northwest at 25 mph. HAZARD...Wind gusts of 50 to 55 mph and pea size hail. SOURCE...Radar indicated. IMPACT...G…
  - (2026-07-22) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 22 at 6:00PM MDT until July 22 at 6:30PM MDT by NWS Goodland KS
      SVRGLD The National Weather Service in Goodland has issued a * Severe Thunderstorm Warning for... West central Kit Carson County in east central Colorado... * Until 630 PM MDT. * At 600 PM MDT, a severe thunderstorm was…
  - (2026-07-22) [Severe] Special Marine Warning: Special Marine Warning issued July 22 at 7:57PM EDT until July 22 at 9:00PM EDT by NWS Mount Holly NJ
      SMWPHI The National Weather Service in Mount Holly NJ has issued a * Special Marine Warning for... Outer waters from Great Egg Inlet NJ to Fenwick Island DE from 20 to 60 nm... * Until 900 PM EDT. * At 757 PM EDT, a stro…
  - (2026-07-22) [Moderate] Gale Warning: Gale Warning issued July 22 at 3:56PM AKDT until July 23 at 5:00AM AKDT by NWS Anchorage AK
      Offshore Waters Forecast for the Bering Sea Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. .TO…
  - (2026-07-22) [Severe] Flood Watch: Flood Watch issued July 22 at 5:56PM MDT until July 22 at 10:00PM MDT by NWS Albuquerque NM
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Northwest and West Central NM as well as the Southwest Mountains. * WHEN...Until 10 PM MDT this evening. * IMPACTS...Excessive runo…

### Ukraine Theater (total-war monitoring) — 70 new of 244 total
  - (2026-07-23) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-22) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - iraq.liveuamap.com
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com iraq.liveuamap.com
  - (2026-07-21) [Liveuamap] Explosions were reported at the occupied part of Luhansk region, possible missile strike - Liveuamap
      Explosions were reported at the occupied part of Luhansk region, possible missile strike Liveuam
  - (2026-07-21) [Liveuamap] Drone targets Ali Al Salem Air Base in Kuwait Al Jahra Governorate, Kuwait - Liveuamap
      Drone targets Ali Al Salem Air Base in Kuwait Al Jahra Governorate, Kuwait Liveuamap</f
  - (2026-07-20) [Liveuamap] Ambulance and Emergency Services: A woman was shot by Israeli forces outside their areas of control in the Nuseirat camp in the central Gaza Strip. - Liveuamap
      Ambulance and Emergency Services: A woman was shot by Israeli forces outside their areas of contr
  - (2026-07-20) [Liveuamap] A US airstrike targeted an area of Shiraz in southern Iran on Monday, but caused no casualties, a provincial official said. Ahmadizadeh, Fars province&039;s deputy governor for political,…
      A US airstrike targeted an area of Shiraz in southern Iran on Monday, but caused no casualties, a provincial of

### GDELT GKG — themes / entities / watch areas — 47 new of 47 total
  - (2026-07-22) [Russia oil sanctions perimeter · themes] Profit - taking hits Wall Street , indices close with modest losses
      zimbabwestar.com · English · tone NA
  - (2026-07-22) [Russia oil sanctions perimeter · themes] В Британии раскрыли детали нового пакета антироссийских санкций
      news.mail.ru · Russian · tone NA
  - (2026-07-22) [Russia oil sanctions perimeter · themes] El Festival Internacional de Cine de Mar del Plata anuncia una nueva edición con homenajes , entrega de premios a la trayectoria y una gran presentación
      puntonoticias.com · Spanish · tone NA
  - (2026-07-22) [Russia oil sanctions perimeter · themes] Iranian missiles show deadly precision amid US - Iran war escalation - Dominican Republic Post – Caribbean News , Business , Travel & Culture
      dominicanrepublicpost.com · English · tone NA
  - (2026-07-22) [Russia oil sanctions perimeter · themes] بعد زيارته الى واشنطن : الزيدي بين حقيبة الاستثمار و فوهة البندقية – كتابات
      kitabat.com · Arabic · tone NA
  - (2026-07-22) [Russia oil sanctions perimeter · themes] Badenoch to urge Burnham to rule out tax rises to pay for spending spree | Harwich and Manningtree Standard
      harwichandmanningtreestandard.co.uk · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 46 new of 103 total
  - (2026-07-23) Трамп схвалив ядерну угоду з Саудівською Аравією | LEDE: США підписали угоду з Саудівською Аравією, яка може дозволити королівству збагачувати ядерне паливо.] (uk: Трамп схвалив ядерну угоду з Саудівс…
      США підписали угоду з Саудівською Аравією, яка може дозволити королівству збагачувати ядерне паливо.
  - (2026-07-23) США продовжили завдавати ударів по об’єктах Ірану – CENTCOM | LEDE: У ніч на четвер, 23 липня, військові США заявили про нові удари по Ірану.] (uk: США продовжили завдавати ударів по об’єктах Ірану –…
      У ніч на четвер, 23 липня, військові США заявили про нові удари по Ірану.
  - (2026-07-23) У центрі Києва обмежать рух транспорту | LEDE: У четвер, 23 липня, в центральній частині Києва діятимуть обмеження руху транспорту.] (uk: У центрі Києва обмежать рух транспорту)
      У четвер, 23 липня, в центральній частині Києва діятимуть обмеження руху транспорту.
  - (2026-07-23) У двох районах Сум росіяни вдарили по АЗС | LEDE: Російські окупанти завдали ударів по АЗС у Сумах.] (uk: У двох районах Сум росіяни вдарили по АЗС)
      Російські окупанти завдали ударів по АЗС у Сумах.
  - (2026-07-22) На фронті від початку доби відбулося 211 бойових зіткнень – Генштаб | LEDE: Від початку доби 22 липня на фронті відбулось 211 бойових зіткнень.] (uk: На фронті від початку доби відбулося 211 бойових з…
      Від початку доби 22 липня на фронті відбулось 211 бойових зіткнень.
  - (2026-07-22) Зеленський офіційно звільнив Ченцова з посади постпреда при ЄС | LEDE: ] (uk: Зеленський офіційно звільнив Ченцова з посади постпреда при ЄС)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-23) [ANGIODYNAMICS INC] Form 4 (Issuer)
      filed 2026-07-23 00:06 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001140361-26-029341 Size: 4 KB
  - (2026-07-23) [REED JAN STERN] Form 4 (Reporting)
      filed 2026-07-23 00:06 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001140361-26-029341 Size: 4 KB
  - (2026-07-23) [Licitra Karen A] Form 4 (Reporting)
      filed 2026-07-23 00:06 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001140361-26-029340 Size: 4 KB
  - (2026-07-23) [ANGIODYNAMICS INC] Form 4 (Issuer)
      filed 2026-07-23 00:06 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001140361-26-029340 Size: 4 KB
  - (2026-07-23) [ANGIODYNAMICS INC] Form 4 (Issuer)
      filed 2026-07-23 00:06 UTC · role: Issuer — Filed: 2026-07-22 AccNo: 0001140361-26-029339 Size: 4 KB
  - (2026-07-23) [JOHNSON WESLEY] Form 4 (Reporting)
      filed 2026-07-23 00:06 UTC · role: Reporting — Filed: 2026-07-22 AccNo: 0001140361-26-029339 Size: 4 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### IT, InfoSys & cybersecurity news (last 7 days) — 28 new of 47 total
  - (2026-07-22) [BleepingComputer] Upbound says hack caused $13 million in fraudulent Acima leases
      The Upbound Group fintech company disclosed that threat actors who stole data from its systems leveraged it to create $13 million in Acima leases. [...]
  - (2026-07-22) [BleepingComputer] South Korea discloses data breach impacting diplomats worldwide
      South Korea disclosed that hackers breached the National Diplomatic Academy's online education system for ten months and stole personal information belonging to current and former employees of the Ministry of Foreign Aff…
  - (2026-07-22) [BleepingComputer] Swiss rail giant Stadler rejects $12.3M ransom demand after cyberattack
      Swiss rail vehicle manufacturer Stadler Rail says the Everest ransomware gang demanded about $12.3 million after breaching a data exchange platform shared with one of its suppliers. [...]
  - (2026-07-22) [BleepingComputer] How enterprise GenAI can amplify ransomware risk — and how to contain it
      Enterprise AI can accelerate ransomware attacks when AI assistants and agents inherit excessive permissions or compromised identities. Acronis explains how identity controls, governance, and least-privilege access help r…
  - (2026-07-22) [BleepingComputer] New InfraTrust report reveals infrastructure flaws admins should patch first
      Eclypsium has launched InfraTrust, a new infrastructure cybersecurity knowledge base and monthly InfraTrust Pulse report designed to help organizations prioritize vulnerabilities affecting infrastructure, firmware, netwo…
  - (2026-07-22) [The Hacker News] GitHub Cuts Public Bug Bounty Payouts, Moves Top Rewards to VIP Tier
      Beginning July 27, 2026, GitHub will cut public bug bounty payouts by at least half at every severity level. Critical findings will drop from $20,000-$30,000+ to a fixed $10,000, while its permanent invite-only VIP tier…

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-23) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $2,205,273 · resolves 2026-06-01
  - (2026-07-23) The Hundred: Southern Brave vs Welsh Fire
      yes price: 0% · 24h volume: $642,240 · resolves 2026-07-29
  - (2026-07-23) Los Angeles Dodgers vs. Philadelphia Phillies
      yes price: 48% · 24h volume: $611,044 · resolves 2026-07-29
  - (2026-07-23) San Diego Padres vs. Atlanta Braves
      yes price: 36% · 24h volume: $588,277 · resolves 2026-07-29
  - (2026-07-23) Pittsburgh Pirates vs. New York Yankees
      yes price: 42% · 24h volume: $542,453 · resolves 2026-07-22
  - (2026-07-23) Chicago Sky vs. New York Liberty
      yes price: 24% · 24h volume: $514,420 · resolves 2026-07-22

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-07-22) U.S. Court of International Trade: Bridgestone Americas Tire Operations, LLC v. United States
  - (2026-07-22) U.S. Court of Appeals, 11th Cir.: United States v. Gray Rivera
  - (2026-07-22) U.S. Court of Appeals, 9th Cir.: Torres-Casas v. Blanche
  - (2026-07-22) U.S. Court of Appeals, 6th Cir.: United States v. Martin Murff
  - (2026-07-22) U.S. Court of Appeals, 7th Cir.: BBLI Edison, LLC v. City of Chicago
  - (2026-07-22) Delaware Supreme Court: Joanne Mondragon, as parent and guardian of J.W., a minor v. The Board of Education of The Colonial School District

### Paper Trading Scorecard — 11 new of 145 total
  - (2026-07-23) [Polymarket] Will OpenAI's valuation hit (HIGH) $2.0T by December 31?
      This market will resolve to "Yes" if OpenAI's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or exc…
  - (2026-07-23) [Polymarket] Will the Texas Rangers win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-07-23) [Polymarket] Will Dune: Messiah have the best domestic opening weekend in 2026?
      This market will resolve according to the title of the movie which grosses more domestically on its opening weekend than any other movie in 2026. The “Weekend Box Office Performance” table on the page for the relevant mo…
  - (2026-07-23) [Manifold] Will an AI generate $1M in profit by the end of 2029?
  - (2026-07-23) [Manifold] Will Bitcoin be higher 7 days from now?
  - (2026-07-23) [Manifold] Will Hasan wear his Mao / Chinese suit at another public event by the end of 2026?

### USGS earthquakes (M4.5+, past day) — 11 new of 19 total
  - (2026-07-22) M 5.1 - 61 km SSW of San Pedro de Atacama, Chile
      M5.1 · 61 km SSW of San Pedro de Atacama, Chile · depth 108.731 km
  - (2026-07-22) M 5.0 - Kermadec Islands, New Zealand
      M5.0 · Kermadec Islands, New Zealand · depth 46.903 km
  - (2026-07-22) M 4.9 - 17 km NW of Hihifo, Tonga
      M4.9 · 17 km NW of Hihifo, Tonga · depth 71.248 km
  - (2026-07-22) M 4.9 - 104 km ENE of Port-Olry, Vanuatu
      M4.9 · 104 km ENE of Port-Olry, Vanuatu · depth 10 km
  - (2026-07-22) M 4.9 - Kermadec Islands, New Zealand
      M4.9 · Kermadec Islands, New Zealand · depth 35 km
  - (2026-07-22) M 4.9 - 96 km SSE of Akhiok, Alaska
      M4.9 · 96 km SSE of Akhiok, Alaska · depth 16.2 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-07-23) MOVER ▼ Elon Musk — $750.22B ($-44.31B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-07-23) MOVER ▲ Michael Dell — $241.34B (+$12.98B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-07-23) MOVER ▼ Mark Zuckerberg — $215.18B ($-5.64B since yesterday)
      United States · Technology · source: Facebook
  - (2026-07-23) MOVER ▲ Jensen Huang — $183.22B (+$4.06B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-07-23) MOVER ▼ Larry Page — $280.85B ($-3.65B since yesterday)
      United States · Technology · source: Google
  - (2026-07-23) MOVER ▼ Sergey Brin — $259.09B ($-3.36B since yesterday)
      United States · Technology · source: Google

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 110 total
  - (2026-07-23) [BIS Entity List] page checksum b562eee9df45
      Page content hash: b562eee9df45. Compare with prior day's hash to detect updates.
  - (2026-07-23) [USASpending] $575,251,038 → NORTHROP GRUMMAN SYSTEMS CORPORATION: JOINT POLAR SATELLITE SYSTEM-2 SPACECRAFT. GD-300HP CORE SP
      Agency: National Aeronautics and Space Administration. Description: JOINT POLAR SATELLITE SYSTEM-2 SPACECRAFT. GD-300HP CORE SPACECRAFT INCLUDING ALL ASSOCIATED HARDWARE, SOFTWARE, SOURCE CODE, MAINTENANCE SYSTEM AND DOC…
  - (2026-07-23) [USASpending] $560,138,026 → CORECIVIC, INC.: DETENTION SERVICES - LAS VERGAS, NV
      Agency: Department of Justice. Description: DETENTION SERVICES - LAS VERGAS, NV
  - (2026-07-23) [USASpending] $544,992,327 → NOVITAS SOLUTIONS, INC.: A/B MAC JURISDICTION L
      Agency: Department of Health and Human Services. Description: A/B MAC JURISDICTION L
  - (2026-07-23) [USASpending] $521,824,443 → FOUR POINTS TECHNOLOGY, L.L.C.: ENTERPRISE CLOUD CAPACITY - AMAZON WEB SERVICES
      Agency: Department of Veterans Affairs. Description: ENTERPRISE CLOUD CAPACITY - AMAZON WEB SERVICES
  - (2026-07-23) [USASpending] $466,112,965 → SCIENCE SYSTEMS AND APPLICATIONS, INC.: THE PURPOSE OF THIS CONTRACT IS TO ACQUIRE SCIENTIFIC RESEAR
      Agency: National Aeronautics and Space Administration. Description: THE PURPOSE OF THIS CONTRACT IS TO ACQUIRE SCIENTIFIC RESEARCH SERVICES THAT CONCEIVES, DEVELOPS AND APPLIES SPACE, FIELD-DEPLOYED (I.E. AIRBORNE AND IN…

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-22) [Marginal Revolution] Solve for the equilibrium
      Something that the Ukraine and Iran wars have taught me is that for a lot of countries, including very big countries, there are a small number of buildings and infrastructure components that are required for their econom…
  - (2026-07-22) [Marginal Revolution] Brazil fact of the day
      Last year, the US exported $171bn of agricultural goods according to the Department of Agriculture, just $2bn more than the export total claimed by Brazil, which many analysts say has benefited from trade disruption set…
  - (2026-07-22) [Marginal Revolution] Wednesday assorted links
      1. Balaji and Network State moving to Kazakhstan. 2. Why evolvable AI is not yet a Darwinian threat. 3. “This paper argues that societies with greater historical exposure to natural disasters are more likely to develop l…
  - (2026-07-22) [Conversable Economist] Chokepoints for Ocean Trade: Strait of Hormuz, and What Else?
      For those who can be fuzzy on global geography, like me, it’s perhaps useful to say that the Persian Gulf is a body of water bordered by eight countries: Bahrain, Iran, Iraq, Kuwait, Qatar, Saudi Arabia, the United Arab…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-07-22) CVE-2026-16232 · Check Point SmartConsole: Check Point SmartConsole Improper Authentication Vulnerability
      vendor: Check Point · product: SmartConsole · CISA remediation by 2026-07-25
  - (2026-07-22) CVE-2026-50522 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-25

### GDACS — global disaster alerts — 2 new of 209 total
  - (2026-07-18) [Green] Forest fires in Algeria
      Wildfire · Green alert · Algeria · Green impact for forestfire in 13608 ha
  - (2026-07-18) [Green] Forest fires in Algeria
      Wildfire · Green alert · Algeria · Green impact for forestfire in 13608 ha

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: establishing, commission, service, fisheries, navigable, final, unless, based, remove, safety, allow, special
- state_bills: today=0, 7d-median=120, 14d-median=120; carrying terms: acknowledging, notice, process, commission, service, funds, organize, individuals, status, purposes, receive, rural
- state_news: today=772, 7d-median=747, 14d-median=747; carrying terms: detention, azgovernor, something, commission, calls, funds, third, offices, brazenness, wildlife, questions, create
- local_news: today=222, 7d-median=227, 14d-median=227; carrying terms: father, cbmirafbvv, appeared, mayor, region, three, pitch, blank, found, resize, cbmiqafbvv, concerns
- foreign_news: today=990, 7d-median=1019, 14d-median=1019; carrying terms: openai, commission, xichang, calls, tokyo, third, offices, seized, vision, wildlife, rubio, frown
- chinese_internal: today=272, 7d-median=299, 14d-median=299; carrying terms: cbmizkfvx, blank, global, people, politics, cbmia, cbmiaefvx, articles, cbmiyefvx, cbmidefvx, cbmixkfvx, title
- russian_internal: today=1003, 7d-median=908, 14d-median=908; carrying terms: reuters, novayagazeta, telegram, laquo, httperror, gazeta, financial, times, forbidden, variety, guardian, found
- ukrainian_internal: today=103, 7d-median=125, 14d-median=125; carrying terms: missiles, foreign, members, vechirniy, acting, calls, injured, sparked, reported, appointed, former, british
- ukraine_theater: today=244, 7d-median=443, 14d-median=443; carrying terms: netymnjfrwphatu, cuxnbfjewdbdt, tavlzflupendkxekxxdernatvqbxf, hnefr, wfpstwjick, krtfpnhrqzxfsvthxqli, rkxprmx, zfrdqwria, third, jfzex, cbmitkfvx, vision
- paper_bets: today=145, 7d-median=144, 14d-median=144; carrying terms: forces, formally, multiple, achieved, openai, senate, emirates, roberto, sachs, massa, prime, president
- weather: today=135, 7d-median=167, 14d-median=167; carrying terms: please, northwestern, afdphi, tracking, changed, ruskin, service, afdmtr, afdsew, shortly, afdlox, reported
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, total, sheet, money, nonfarm, supply, cpiaucsl, pcepilfe, unrate, recession, indicator, crude
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, china, silver, close, credit, agriculture, crypto, nasdaq, proxy, futures, crude, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=110, 7d-median=117, 14d-median=117; carrying terms: compare, yzeezmdnzhvc, justice, zsmzd, foreign, notice, haitian, vavlppnkzsdln, xwmlmr, funds, related, health
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quantitative, congresstrading, quiverquant, error, https, quiver, client, httperror
- billionaires: today=40, 7d-median=36, 14d-median=36; carrying terms: meyers, sergey, hathaway, ambani, semiconductors, spain, trading, technology, ellison, france, gcarsoa, cryptocurrency
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, insurance, pistol, corona, company, investments, appeals, trade, children, association, jersey, attorney
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, thomas, holdings, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: sherrod, trone, disbursements, platner, action, pinkston, jonathan, senate, ocasio, booker, ossoff, johnson
- gdelt_regions: today=0, 7d-median=9, 14d-median=9; carrying terms: english, japan
- gdelt_gkg: today=47, 7d-median=46, 14d-median=46; carrying terms: hezbollah, israel, english, trump, chinese, arabic, sanctions, themes, russia, perimeter, russian, spanish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=9, 14d-median=9
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: initiated, rates, focal, accordance, multiple, periods, spain, fatal, detected, multi, analyzed, years
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: unrestricted, fortinet, icagenda, granularity, vendor, vulnerability, restrictive, improper, federation, balbooa, services, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=209, 7d-median=165, 14d-median=165; carrying terms: albania, russia, earthquake, montenegro, switzerland, congo, spain, romania, france, brazil, impact, honduras
- usgs_quakes: today=19, 7d-median=19, 14d-median=19; carrying terms: puerto, depth, madero, kermadec, islands, mexico, indonesia, philippines, russia, vanuatu, region, abepura
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, price, prime, resolves, ethiopia, interest, volume, meeting, minister, change, boston, mekonnen
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: generates, economist, sustainable, mokyr, healthier, refer, pushback, perhaps, often, class, economy, progress
- tech_news: today=47, 7d-median=56, 14d-median=56; carrying terms: vulnerability, flaws, company, ransomware, microsoft, former, intelligence, contains, identified, policy, server, exploitation
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: aderholt, steven, justice, currency, hoeven, jerry, webster, emanuel, powell, atlanta, rochester, acting
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, placement, either, consensus, market, unavailable, today, module, converges, evidence, identify, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-07-21] ECB press: July 2026 euro area bank lending survey

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*