# WORLDSCOPE morning brief — 2026-07-23

## Headline
4123 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (877) · Russian Internal News (state + in-exile) (854) · State-Level News (668) · World leaders & government officials (324) · Chinese Internal News (244) · Local News: St. Louis + Atlanta (233) · Ukraine Theater (total-war monitoring) (199) · U.S. Weather + Severe / Climate Outlooks (139) · State Legislative Action (103) · Ukrainian Internal News (national + local Kyiv) (82) · IT, InfoSys & cybersecurity news (last 7 days) (47) · U.S. Federal Action (41)

## What changed today
### International News + Multilateral Institutions — 877 new of 1106 total
  - (2026-07-23) [Global] US imposes tariffs on dozens of trade partners over 'forced labour' imports
      The tariffs target around 60 trading partners over claims they failed to properly stop forced labour.
  - (2026-07-23) [Global] UK complacent about war threat, warns defence boss
      The threat of attack has never been higher, the boss of Europe's biggest defence contractor has warned. Dr Charles Woodburn
  - (2026-07-23) [Global] We split bills equally even when one of us earned a lot more
      Hannah and Max continued to pool finances after Max was made redundant but took "drastic measures" to cut spending.
  - (2026-07-23) [Global] UK mortgage rates rise to highest level for a month
      Renewed tensions in the Middle East feed through to the costs faced by lenders, pushing up borrowing costs.
  - (2026-07-23) [Global] Oil prices hit $100 for the first time since May
      The price of Brent crude rose more than 6% on Thursday as the war in the Middle East continues to escalate.
  - (2026-07-23) [Global] Lawmakers push for AI 'kill switch' after OpenAI goes rogue
      A new bill would let the US government order the shutdown of AI models that pose a public threat.

### Russian Internal News (state + in-exile) — 854 new of 1060 total
  - (2026-07-23) Под санкции ЕС попали Владимир Мединский и Михаил Дегтярев, а также Мосбиржа, банки маркетплейсов и НПЗ | LEDE: Евросоюз опубликовал в официальном журнале списки 21-го пакета санкций, в кото] (ru: Под…
      Евросоюз опубликовал в официальном журнале списки 21-го пакета санкций, в который вошли 48 физических лиц.
  - (2026-07-23) ВСУ стали чаще бить по заправкам в Белгороде и области. За пять дней атаковано около 20 АЗС | LEDE: В течение пяти дней с 19 по 23 июля украинские беспилотники атаковали не менее 19 АЗС в Бе] (ru: ВСУ…
      В течение пяти дней с 19 по 23 июля украинские беспилотники атаковали не менее 19 АЗС в Белгороде и Белгородской агломерации, подсчитало издание «Пепел».
  - (2026-07-23) Российский бюджет в июле получит на 60% больше нефтегазовых доходов, чем в прошлом году — благодаря росту мировых цен на нефть | LEDE: Доходы России от нефти и газа в июле вырастут на 60% по] (ru: Рос…
      Доходы России от нефти и газа в июле вырастут на 60% по сравнению с июлем прошлого года, пишет Reuters со ссылкой на собственные расчеты.
  - (2026-07-23) Сбербанк закрывает валютные карты Visa и Mastercard | LEDE: Сбербанк с 1 сентября 2026 года прекратит обслуживание валютных и мультивалютных карт Visa и Mastercard, сообщают ТАСС и РБК. ] (ru: Сбербан…
      Сбербанк с 1 сентября 2026 года прекратит обслуживание валютных и мультивалютных карт Visa и Mastercard, сообщают ТАСС и РБК.
  - (2026-07-23) «Мы можем себе это позволить». Гари Линекер, Брайан Ино и еще более 100 британских миллионеров попросили правительство поднять им налоги | LEDE: Более 120 богатых британцев подписали обращен] (ru: «Мы…
      Более 120 богатых британцев подписали обращение, адресованное новому премьеру страны Энди Бернему, в котором предлагают ввести 2-процентный налог на состояние, превышающее 10 миллионов фунтов стерлингов.
  - (2026-07-23) У «военкора» Евгения Поддубного (он возглавляет список ЕР) нашлись иностранные акции. Пять лет назад из-за этого с выборов сняли Павла Грудинина | LEDE: Российский «военкор» Евгений Поддубны] (ru: У «…
      Российский «военкор» Евгений Поддубный, вошедший в пятерку лидеров «Единой России» на выборах в Госдуму, задекларировал акции иностранных компаний — в частности, Apple Inc., Intel Corporation, The Procter & Gamble и Nebi…

### State-Level News — 668 new of 1069 total
  - (2026-07-23) [California] California sues to stop Trump from using public safety funding to pressure states on elections
      <a href="https:/
  - (2026-07-23) [California] Governor Newsom delivers $109.6 million in voter-approved Prop 1 funding for 278 supportive homes, including housing for veterans
      <a href="https://www.gov
  - (2026-07-22) [California] Acting Governor Rivas proclaims Disability Pride Month
      Source
  - (2026-07-22) [California] California delivers major blow to organized retail theft, recovering $76.2 million in stolen goods since 2019
      Source
  - (2026-07-22) [California] Governor Newsom announces appointments 7.22.2026
      Source
  - (2026-07-22) [Alabama] Governor Ivey Signs Executive Order Establishing Commission on Screen-Based Instruction
      MONTGOMERY – Governor Kay Ivey on Wednesday signed Executive Order No. 745 establishing the Governor’s Commission on Screen-Based Instruction to study the use, risks and benefits of screen-based instruction in Alabama’s…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 244 new of 311 total
  - (2026-07-22) 城投发债门槛新增“三道红线” 融资收紧可能带来什么局面？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1HckZtZWNXQjRwc0FUR0YxcVdWMDl6S3o1Y1ZJX29GZUtMbVNmNzUyYjhYNGl4aEVsQTdsVmY0dWtQX3M1dzFYMFJyZ] (zh:…
      城投发债门槛新增“三道红线” 融资收紧可能带来什么局面？ 财新
  - (2026-07-22) 特稿｜韩国股市版“鱿鱼游戏” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9JenRVVWlXdVBxVDUtRWo5YkJHczFvMUptU19mRkZWaEJiM25RZjdHYS0xWEdlWDk4SHlWclRZaG1YSnQ1Ry04ZDhnNmtrcVdxVTBmYjh] (zh:…
      特稿｜韩国股市版“鱿鱼游戏” 财新
  - (2026-07-22) 英籍女子在港诬告男银行家强奸并勒索 被判入狱6年 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5RcFhNOWFoSGlBcVZsQUNoYW1WSEtaM25DLWI0ajRrV1c0aWRsWXIxR25CSEhOajE3ZDNHQ1JOX0F6UjR] (zh:…
      英籍女子在港诬告男银行家强奸并勒索 被判入狱6年 china.caixin.com
  - (2026-07-22) 6月财政收入同比增长8.7% 支出增速由负转正 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0zNURnZUZwM3YxdDExMVlTV1gxOW5FY0ZxU01OdEtQZ0FDWjFlRFFUb3ZCV2JLTlpGRXdkRTlONXF2NWc4RU9yekxLS3BILU] (zh:…
      6月财政收入同比增长8.7% 支出增速由负转正 财新
  - (2026-07-22) 王毅会见鲁比奥 要求美方切实管控矛盾分歧 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5pNUNDMDhnUEFzT01RRk96bjEtQlpLbGFKeVBCeEdCN1M4a184ZTdISlFjS01WdEJGaWlIWWc5dXFPeVlPRjZ2RnBVbF9xMW9Ue] (zh:…
      王毅会见鲁比奥 要求美方切实管控矛盾分歧 财新
  - (2026-07-22) 公募基金二季度净利1.94万亿元 主动权益基金抱团TMT - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5TbkRFZmtBdHZHdUJUZGpRLTFvb3d5VkpMQU02YTlNcE15VmRjNi1wcWhxMjU0QXpGeVRqdUEtV2FNX3ZseUV3UDZVW] (zh:…
      公募基金二季度净利1.94万亿元 主动权益基金抱团TMT 财新

### Local News: St. Louis + Atlanta — 233 new of 262 total
  - (2026-07-23) [St. Louis] What’s True in the Lou 7/24/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-07-23) [St. Louis] New Music Circle reveals its 68th Season with Horse Lords, Wadada Leo Smith, Vinny Golia, and more
      Since its inception in 1959, New Music Circle (NMC) has broadened the sonic palette of St. Louis with cutting-edge concert curation and an academic approach that includes workshops, school visits, and artist residencies.…
  - (2026-07-23) [St. Louis] Shark Week tears into the St. Louis Aquarium at Union Station
      Shark-loving St. Louisans can flock to the St. Louis Aquarium at Union Station July 24—August 2 for Shark Week, the aquarium’s celebration of the magnificent and ferocious creatures of the sea. The aquarium will feature…
  - (2026-07-23) [St. Louis] Prohibition adds elevated shareable food to its cocktail experience
      Since opening last fall, Prohibition (2017 Chouteau) has drawn guests into its intimate, dimly lit setting with expertly crafted cocktails, and immersive speakeasy experience, one built on a deep appreciation for the his…
  - (2026-07-23) [St. Louis] Peter Hoffman is fighting vacancy, one derelict house at a time
      Attorney Peter Hoffman is doing as much as anyone in St. Louis to combat the problem of vacant properties in the city—and there is no doubt that vacancies are indeed a problem. Hoffman calls it “existential.” ”The popula…
  - (2026-07-23) [St. Louis] Millennium Hotel’s revolving axle comes down to earth
      More than 10 years after last powering the revolving restaurant atop the Millennium Hotel, the north tower’s 1,500-pound axle came down this week. But the hulking piece of machinery isn’t headed for the scrapyard: City M…

### Ukraine Theater (total-war monitoring) — 199 new of 377 total
  - (2026-07-23) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-23) [Liveuamap] Drones have attacked Subkhanulovo oil pumping station in Bashkiriya - Liveuamap
      Drones have attacked Subkhanulovo oil pumping station in Bashkiriya Liveuamap
  - (2026-07-23) [Liveuamap] Drones have attacked power substation in Yalta Yalta, - Ukraine Interactive map - Ukraine Latest news on live map - Liveuamap
      Drones have attacked power substation in Yalta Yalta, - Ukraine Interactive map - Ukraine Latest news on live map <fo
  - (2026-07-23) [Liveuamap] Fresh satellite imagery confirms new strike damage at Ali Al Salem Air Base in Kuwait after today&039;s Iranian attacks. Multiple structures, likely troop billets, were destroyed, with smo…
      Fresh satellite imagery confirms new strike damage at Ali Al Salem Air Base in Kuwait after today&039;s Iranian atta
  - (2026-07-23) [Liveuamap] Saudi Arabia confirms targeting of its ship in the Red Sea. The official Saudi Press Agency (SPA) announced that a Saudi-owned ship was targeted while sailing in the Red Sea. Without namin…
      Saudi Arabia confirms targeting of its ship in the Red Sea. The official Saudi Press Agency (SPA) announced that a Saudi-
  - (2026-07-20) [Liveuamap] Ambulance and Emergency Services: A woman was shot by Israeli forces outside their areas of control in the Nuseirat camp in the central Gaza Strip. - Liveuamap
      Ambulance and Emergency Services: A woman was shot by Israeli forces outside their areas of contr

### U.S. Weather + Severe / Climate Outlooks — 139 new of 142 total
  - (2026-07-23) [Moderate] Special Weather Statement: Special Weather Statement issued July 23 at 5:42PM MDT by NWS Cheyenne WY
      At 542 PM MDT, Doppler radar was tracking a strong thunderstorm over Sibley Peak, or 27 miles southeast of Douglas, moving southeast at 35 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicate…
  - (2026-07-23) [Severe] Flash Flood Warning: Flash Flood Warning issued July 23 at 5:42PM MDT until July 23 at 8:45PM MDT by NWS Salt Lake City UT
      FFWSLC The National Weather Service in Salt Lake City has issued a * Flash Flood Warning for... South Central Wayne County in southern Utah... * Until 845 PM MDT. * At 542 PM MDT, Doppler radar indicated thunderstorms pr…
  - (2026-07-23) [Moderate] Special Weather Statement: Special Weather Statement issued July 23 at 4:41PM PDT by NWS Pendleton OR
      At 441 PM PDT, Doppler radar was tracking a strong thunderstorm over Paradise, or 33 miles south of Lewiston, moving northeast at 30 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar indicated. IMPA…
  - (2026-07-23) [Moderate] Special Weather Statement: Special Weather Statement issued July 23 at 5:39PM MDT by NWS Pueblo CO
      At 538 PM MDT, Doppler radar was tracking a strong thunderstorm near Peyton, or 25 miles northeast of Colorado Springs, moving east at 20 mph. HAZARD...Wind gusts of 50 to 55 mph and brief pea size hail. SOURCE...Radar i…
  - (2026-07-23) [Moderate] Special Weather Statement: Special Weather Statement issued July 23 at 4:39PM PDT by NWS Boise ID
      At 439 PM PDT, Doppler radar was tracking a strong thunderstorm near Shell Rock Butte, or 23 miles west of Parma, moving northeast at 25 mph. HAZARD...Torrential rain wind gusts up to 40 mph and half inch hail. SOURCE...…
  - (2026-07-23) [Severe] Flash Flood Warning: Flash Flood Warning issued July 23 at 5:38PM MDT until July 23 at 5:45PM MDT by NWS Albuquerque NM
      The heavy rain has ended, and flood waters are receding. Flash flooding is no longer expected to pose a threat. Please continue to heed any remaining road closures. If you observed any flooding, contact the Albuquerque N…

### State Legislative Action — 103 new of 121 total
  - (2026-07-22) [Alabama SB 136] Sunset law; Alabama Massage Therapy Licensing Board continued with modification until October 1, 2027, when renamed Alabama Massage Advisory Council under the regulatory authority of…
      Occupational Licensing Boards
  - (2026-07-22) [Alabama SB 183] Alabama Board of Cosmetology and Barbering; natural hair styling exempt from regulation
      Authorities, Boards, & Commissions
  - (2026-07-22) [Alabama SB 41] Abuse and exploitation of an elder, effect of conviction on intestate succession, wills, joint assets, and other contractual obligations provided
      Crimes & Offenses
  - (2026-07-22) [Alabama SB 113] Alabama Behavior Analyst Licensing Board, continued under Sunset Law as Behavior Analyst Advisory Board under Department of Mental Health
      Occupational Licensing Boards
  - (2026-07-23) [Alaska HB 91] An Act relating to the lawful operation of retail marijuana stores; relating to marijuana cultivation; relating to the registration of marijuana establishments; relating to marijuana ta…
      An Act relating to the lawful operation of retail marijuana stores; relating to marijuana cultivation; relating to the registration of marijuana establishments; relating to marijuana taxes; relating to the duties of the…
  - (2026-07-23) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…

### Ukrainian Internal News (national + local Kyiv) — 82 new of 137 total
  - (2026-07-24) В окупованому Сімферополі безпілотники атакували склад Wildberries | LEDE: Склад Wildberries в окупованому Сімферополі евакуювали після атаки дронів.] (uk: В окупованому Сімферополі безпілотники атаку…
      Склад Wildberries в окупованому Сімферополі евакуювали після атаки дронів.
  - (2026-07-24) Трамп анонсував візит лідера Китаю до США у вересні | LEDE: За словами Трампа, лідер Китаю прибуде до США у вересні.] (uk: Трамп анонсував візит лідера Китаю до США у вересні)
      За словами Трампа, лідер Китаю прибуде до США у вересні.
  - (2026-07-24) Через атаку росіян на Чернігівщині – понад 70 тисяч споживачів без світла | LEDE: Росіяни атакували Чернігівщину, 70 тисяч користувачів лишилися безсівтла.] (uk: Через атаку росіян на Чернігівщині – п…
      Росіяни атакували Чернігівщину, 70 тисяч користувачів лишилися безсівтла.
  - (2026-07-23) У Грузії стався блекаут | LEDE: Енергосистема Грузії зазнала аварії, в країні стався блекаут.] (uk: У Грузії стався блекаут)
      Енергосистема Грузії зазнала аварії, в країні стався блекаут.
  - (2026-07-23) Німеччина відкликає військові кораблі з Червоного моря через поновлення конфлікту США та Ірану | LEDE: ] (uk: Німеччина відкликає військові кораблі з Червоного моря через поновлення конфлікт)
  - (2026-07-23) Від початку доби на фронті відбулося 178 бойових зіткнень – Генштаб | LEDE: Від початку доби 23 липня на фронті відбулось 178 бойових зіткнень.] (uk: Від початку доби на фронті відбулося 178 бойових з…
      Від початку доби 23 липня на фронті відбулось 178 бойових зіткнень.

### IT, InfoSys & cybersecurity news (last 7 days) — 47 new of 57 total
  - (2026-07-23) [BleepingComputer] New Dolphin X malware uses AI to rank high-value targets
      A new Dolphin X remote access trojan claims to use an AI-powered profiling feature to score and rank infected users, helping cybercriminals identify which victims should be targeted first. [...]
  - (2026-07-23) [BleepingComputer] Australian energy provider Origin says data breach exposes client data
      Origin Energy has confirmed that an unauthorized party accessed and subsequently leaked customer data online, exposing sensitive personally identifiable information (PII), among others. [...]
  - (2026-07-23) [BleepingComputer] Fake Claude app promoted by Bing ads pushes SectopRAT malware
      A malvertising campaign on the Bing search service is pushing a fake Claude desktop app installer hosted on a legitimate Claude.ai domain to deliver the SectopRAT malware. [...]
  - (2026-07-23) [BleepingComputer] Russian hackers exploit Zimbra zero-click flaw for email theft
      CISA is warning that the Russian state-sponsored hacking group Laundry Bear, also known as Void Blizzard, is targeting organizations using Zimbra Collaboration email servers by combining phishing attacks with the exploit…
  - (2026-07-23) [BleepingComputer] Hackers abuse Notepad++ plugins to stealthily install malware
      Ukraine's CERT has uncovered attacks distributing an archive containing the legitimate Notepad++ application and a malicious utility called LunchPoke disguised as a plugin to establish persistence. [...]
  - (2026-07-23) [The Hacker News] Russian Espionage Group Exploited Zimbra Zero-Day to Steal Mail and 2FA Codes
      A Russian state-supported espionage group spent months reading Western mailboxes through a then-unknown flaw in Zimbra's webmail client. The payload goes after the last 90 days of email, the organization's entire email d…

### U.S. Federal Action — 41 new of 41 total
  - (2026-07-23) Continuation of the National Emergency With Respect to Mali
  - (2026-07-23) Securing America's Defense Supply Chains and Ensuring Domestic Acquisition of Critical Materials
  - (2026-07-23) Made in America Week, 2026
  - (2026-07-23) Captive Nations Week, 2026
  - (2026-07-23) Imposing Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Motor Vehicles
  - (2026-07-23) Imposing Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Dairy

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-23) [8 Rivers Capital, LLC] Form 4 (Reporting)
      filed 2026-07-23 23:40 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001104659-26-086400 Size: 12 KB
  - (2026-07-23) [BEAUCHAMP DAMIAN R.] Form 4 (Reporting)
      filed 2026-07-23 23:40 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001104659-26-086400 Size: 12 KB
  - (2026-07-23) [NET Power Inc.] Form 4 (Issuer)
      filed 2026-07-23 23:40 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001104659-26-086400 Size: 12 KB
  - (2026-07-23) [Murtagh Nigel J] Form 4 (Reporting)
      filed 2026-07-23 23:39 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001649599-26-000009 Size: 9 KB
  - (2026-07-23) [SCHWAB CHARLES CORP] Form 4 (Issuer)
      filed 2026-07-23 23:39 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001649599-26-000009 Size: 9 KB
  - (2026-07-23) [NPEH, LLC] Form 4 (Reporting)
      filed 2026-07-23 23:37 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001104659-26-086399 Size: 9 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-23) [United States] Trump : Foreign countries are trying to slow down new U . S . data centers in global AI race ; Propaganda , PR
      domain: belgrade-news.com · language: English · tone:
  - (2026-07-23) [United States] WH Announces New Tariffs | News Radio 690 KTSM
      domain: ktsmradio.iheart.com · language: English · tone:
  - (2026-07-23) [United Kingdom] Winner of Theakston Old Peculier Crime Novel of the Year revealed
      domain: enfieldindependent.co.uk · language: English · tone:
  - (2026-07-23) [United States] Arkansas cop tragically dies saving fiancée life just hours after proposing
      domain: ktvu.com · language: English · tone:
  - (2026-07-23) [Nepal] U . S . stocks tumble on dramatic escalation of Iran war
      domain: nepalnational.com · language: English · tone:
  - (2026-07-23) [Australia] Worker dead , another injured as truck rolls over vehicle at Queensland mine
      domain: abc.net.au · language: English · tone:

### GDACS — global disaster alerts — 33 new of 240 total
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · Philippines, China · Tropical Storm (maximum wind speed of 148 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · Philippines, China · Tropical Storm (maximum wind speed of 148 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · Philippines, China · Tropical Storm (maximum wind speed of 148 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · Philippines, China · Tropical Storm (maximum wind speed of 148 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · Philippines, China · Tropical Storm (maximum wind speed of 148 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · Philippines, China · Tropical Storm (maximum wind speed of 148 km/h)

### Paper Trading Scorecard — 32 new of 141 total
  - (2026-07-23) [Polymarket] Will the Bank of Russia make no change to the key rate after the July Meeting?
      This market will resolve according to the change in the key rate resulting from the Bank of Russia’s July meeting, relative to the level it was prior to this meeting. The resolution source for this market is information…
  - (2026-07-23) [Polymarket] Will OpenAI's valuation hit (HIGH) $2.0T by December 31?
      This market will resolve to "Yes" if OpenAI's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or exc…
  - (2026-07-23) [Polymarket] Will the Texas Rangers win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-07-23) [Manifold] Подаст ли КИТИК заявку на контракт на пост разработчика проекта Орион ?
  - (2026-07-23) [Manifold] Will a criminal investigation into OpenAI over the Hugging Face breach be publicly confirmed before 2028?
  - (2026-07-23) [Manifold] Will more than 8 bots trade on this market in the next week

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 29 new of 60 total
  - (2026-07-23) D.C. Court of Appeals: In re Alpert
  - (2026-07-23) U.S. Court of Appeals, 7th Cir.: Brad Passwater v. Tricia Pretorius
  - (2026-07-23) U.S. Court of Appeals, 7th Cir.: United States v. Larry Doss
  - (2026-07-23) U.S. Court of Appeals, 7th Cir.: Debra Pratt v. Wisconsin Aluminum Foundry
  - (2026-07-23) U.S. Court of Appeals, 7th Cir.: Debra Pratt v. Wisconsin Aluminum Foundry
  - (2026-07-23) U.S. Court of Appeals, 10th Cir.: Dressen v. AstraZeneca AB

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-23) [Israel-Iran-Hezbollah axis · themes] Trump : Foreign countries are trying to slow down new U . S . data centers in global AI race ; Propaganda , PR
      belgrade-news.com · English · tone NA
  - (2026-07-23) [Israel-Iran-Hezbollah axis · themes] WH Announces New Tariffs | News Radio 690 KTSM
      ktsmradio.iheart.com · English · tone NA
  - (2026-07-23) [Israel-Iran-Hezbollah axis · themes] Winner of Theakston Old Peculier Crime Novel of the Year revealed
      enfieldindependent.co.uk · English · tone NA
  - (2026-07-23) [Israel-Iran-Hezbollah axis · themes] Arkansas cop tragically dies saving fiancée life just hours after proposing
      ktvu.com · English · tone NA
  - (2026-07-23) [Israel-Iran-Hezbollah axis · themes] U . S . stocks tumble on dramatic escalation of Iran war
      nepalnational.com · English · tone NA
  - (2026-07-23) [Israel-Iran-Hezbollah axis · themes] Worker dead , another injured as truck rolls over vehicle at Queensland mine
      abc.net.au · English · tone NA

### Government Action: Sanctions + Procurement + Foreign Agents — 22 new of 123 total
  - (2026-07-23) [OFAC] Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses - Office of Foreign Assets Cont…
      Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] CJNG Leadership - Office of Foreign Assets Control (.gov)
      CJNG Leadership Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] CJNG-Linked Networks - Office of Foreign Assets Control (.gov)
      CJNG-Linked Networks Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in Office of Foreign Assets Control (.gov)

### USGS earthquakes (M4.5+, past day) — 18 new of 18 total
  - (2026-07-23) M 5.8 - 130 km W of Ternate, Indonesia
      M5.8 · 130 km W of Ternate, Indonesia · depth 49.188 km
  - (2026-07-23) M 5.1 - 92 km SE of Atka, Alaska
      M5.1 · 92 km SE of Atka, Alaska · depth 35 km
  - (2026-07-23) M 5.1 - 85 km SE of Tatsugō, Japan
      M5.1 · 85 km SE of Tatsugō, Japan · depth 10 km
  - (2026-07-23) M 5.1 - central Mid-Atlantic Ridge
      M5.1 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-07-23) M 5.0 - 38 km SSE of Spearman, Texas
      M5.0 · 38 km SSE of Spearman, Texas · depth 5.6885 km
  - (2026-07-23) M 4.9 - 57 km SW of Champerico, Guatemala
      M4.9 · 57 km SW of Champerico, Guatemala · depth 35 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-23) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,775,755 · resolves 2026-06-01
  - (2026-07-23) Arizona Diamondbacks vs. St. Louis Cardinals
      yes price: 100% · 24h volume: $1,056,937 · resolves 2026-07-02
  - (2026-07-23) Arizona Diamondbacks vs. St. Louis Cardinals: O/U 8.5
      yes price: 100% · 24h volume: $826,111 · resolves 2026-06-25
  - (2026-07-23) Kansas City Royals vs. Detroit Tigers: O/U 8.5
      yes price: 12% · 24h volume: $497,874 · resolves 2026-07-23
  - (2026-07-23) Will Hammarby Fotboll win on 2026-07-23?
      yes price: 0% · 24h volume: $385,224 · resolves 2026-07-23
  - (2026-07-23) Will the Fed decrease interest rates by 50+ bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $374,607 · resolves 2026-07-29

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-07-23) MOVER ▼ Larry Page — $262.10B ($-18.75B since yesterday)
      United States · Technology · source: Google
  - (2026-07-23) MOVER ▼ Sergey Brin — $241.85B ($-17.24B since yesterday)
      United States · Technology · source: Google
  - (2026-07-23) MOVER ▼ Jeff Bezos — $244.61B ($-9.87B since yesterday)
      United States · Technology · source: Amazon
  - (2026-07-23) MOVER ▼ Larry Ellison — $157.76B ($-8.27B since yesterday)
      United States · Technology · source: Oracle
  - (2026-07-23) MOVER ▼ Mark Zuckerberg — $208.03B ($-7.14B since yesterday)
      United States · Technology · source: Facebook
  - (2026-07-23) MOVER ▼ Elon Musk — $743.98B ($-6.24B since yesterday)
      United States · Technology · source: Tesla, SpaceX

### Government & military aircraft airborne (OpenSky) — 8 new of 8 total
  - (2026-07-23) SAMU13 (France)
      icao24: 39c902 · position: (43.7454, 5.0569) · alt: 769m · 175km/h
  - (2026-07-23) RCH212 (United States)
      icao24: ae07df · position: (25.9654, -79.9058) · alt: 10088m · 773km/h
  - (2026-07-23) NCR806 (United States)
      icao24: a7488c · position: (31.4907, 30.1118) · alt: 12039m · 911km/h
  - (2026-07-23) NCR405 (United States)
      icao24: acb84d · position: (50.0256, -124.2516) · alt: 11879m · 926km/h
  - (2026-07-23) NCR829 (United States)
      icao24: a95c2f · position: (60.7509, -149.0083) · alt: 4693m · 834km/h
  - (2026-07-23) PAT19 (United States)
      icao24: ae5649 · position: (39.4762, -76.0358) · alt: 541m · 213km/h

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-07-23) [Marginal Revolution] Thursday assorted links
      1. Puffin spotted on the Dorset coast. 2. Anthropic chief economist on AI and unemployment. 3. Whales use different vowels when ships are around. 4. Oliver Kim on McNamara. 5. Large language models can predict the result…
  - (2026-07-23) [Marginal Revolution] Alex Tabarrok on the Economic Analysis of Crime
      I tell my Gary Becker story, why I like police more than prisons, how criminals are like children and more. The post Alex Tabarrok on the Economic Analysis of Crime appeared first on Marginal REVOLUTION.
  - (2026-07-23) [Marginal Revolution] What should I ask Gita Gopinath?
      Yes I will be doing a Conversation with her. From Wikipedia: Gita Gopinath…is an Indian-American economist who is currently serving as the Gregory and Ania Coffey professor of Economics at Harvard University and previous…
  - (2026-07-23) [Conversable Economist] The Job Market for Recent College Graduates
      When I talk with college students, and even high school students, a number of them have a profound sense that it is tremendously hard to find a job coming out of college. The level fear seems to me exaggerated, but some…
  - (2026-07-22) [Conversable Economist] Chokepoints for Ocean Trade: Strait of Hormuz, and What Else?
      For those who can be fuzzy on global geography, like me, it’s perhaps useful to say that the Persian Gulf is a body of water bordered by eight countries: Bahrain, Iran, Iraq, Kuwait, Qatar, Saudi Arabia, the United Arab…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-07-22) CVE-2026-16232 · Check Point SmartConsole: Check Point SmartConsole Improper Authentication Vulnerability
      vendor: Check Point · product: SmartConsole · CISA remediation by 2026-07-25
  - (2026-07-22) CVE-2026-50522 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-25

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=41, 7d-median=20, 14d-median=20; carrying terms: guard, regulatory, final, safety, environment, temporary, amendments, commission, waters, public, establishing, review
- state_bills: today=121, 7d-median=121, 14d-median=121; carrying terms: california, selling, establishment, board, regulatory, individuals, commencing, districts, nonprofit, circumstances, status, centers
- state_news: today=1069, 7d-median=747, 14d-median=747; carrying terms: businessman, killing, equity, power, remained, legislators, acting, along, served, continue, tribes, haven
- local_news: today=262, 7d-median=227, 14d-median=227; carrying terms: power, voting, cbmirwfbvv, including, world, night, width, wants, schools, summer, river, sheriff
- foreign_news: today=1106, 7d-median=1024, 14d-median=1024; carrying terms: killing, worldbank, selling, using, power, bengaluru, board, aircraft, xichang, southern, nanjing, singapore
- chinese_internal: today=311, 7d-median=303, 14d-median=303; carrying terms: cbmiyefvx, cbmiykfvx, lxtfb, color, cbmickfvx, cbmizkfvx, politics, blank, cbmibkfvx, title, global, market
- russian_internal: today=1060, 7d-median=908, 14d-median=908; carrying terms: gazeta, title, telegram, raquo, netflix, google, https, russian, media, istories, forbidden, street
- ukrainian_internal: today=137, 7d-median=128, 14d-median=128; carrying terms: drones, killing, khmara, power, acting, commercial, continue, board, zelensky, authorities, wounds, including
- ukraine_theater: today=377, 7d-median=443, 14d-median=443; carrying terms: cwhuenvoy, zlsdq, drones, cgdtzwdbqkfadwhvt, jvzkn, qtldrg, pbztj, zquywdnvjdzvcbknfqllhaul, ughlntvywffsr, bpamvqdutnoeo, qquromezjr, acting
- paper_bets: today=141, 7d-median=144, 14d-median=144; carrying terms: california, finish, transferable, impossible, event, state, cholowsky, andrew, officially, third, using, benefits
- weather: today=142, 7d-median=167, 14d-median=167; carrying terms: objects, region, chance, state, tropical, flood, beach, winds, scattered, lewis, information, along
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, spread, consumption, effective, headline, indicator, walcl, pcepilfe, rates, unemployment, implied, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, natural, nasdaq, yield, range, crude, equities, rates, corporate, bitcoin, china, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=123, 7d-median=117, 14d-median=117; carrying terms: dnvjblmwtha, california, measures, region, lpzee, jauftzezeqkfix, state, cbmiqefvx, abuses, cbmihgjbvv, jjmudpzw, unauthorised
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiver, quiverquant, unauthorized, httperror, congresstrading, error, quantitative, https
- billionaires: today=40, 7d-median=36, 14d-median=36; carrying terms: meyers, gautam, facebook, fashion, walmart, changpeng, larry, zuckerberg, zhang, madrid, telecom, paris
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, children, blanche, court, insurance, trade, international, appeals, charles, supreme, district, alliance
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, amended, therapeutics, holdings
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: sherrod, jonathan, senate, trone, krishnamoorthi, brown, action, cortez, ossoff, committee, congress, cooper
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, google
- gdelt_gkg: today=25, 7d-median=45, 14d-median=45; carrying terms: hezbollah, israel, english, trump, themes, spanish, russia, global, against, latest, iheart, action
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: australia, military, domain, language, kingdom, killed, police, trump, english
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=8, 7d-median=9, 14d-median=9; carrying terms: position, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: increased, summarizes, region, prevention, algeria, event, continues, state, clade, ebola, alert, contact
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: request, forms, unrestricted, privilege, account, control, icagenda, balbooa, suite, business, vendor, management
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=240, 7d-median=165, 14d-median=165; carrying terms: albania, minor, montenegro, gabon, bosnia, ethiopia, mexico, czech, orange, cambodia, tropical, alert
- usgs_quakes: today=18, 7d-median=18, 14d-median=18; carrying terms: depth, puerto, islands, mexico, indonesia, atlantic, ridge, abepura, region
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, ethiopia, meeting, rates, price, interest, prime, minister, mekonnen, demeke, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, effects, https, economist, marginal, revolution, useful, interview, economic, interlocutor, perhaps, conversable
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: software, malware, techcrunch, beach, using, stories, available, information, haven, hacker, update, vulnerability
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: rounds, chuck, padilla, glenn, amata, onder, state, garamendi, andrew, addison, flood, weber
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, today, converges, paper, market, consensus, markets, placement, claude, unavailable, module, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-07-21] ECB press: July 2026 euro area bank lending survey
- [2026-07-21] ECB press: ECB appoints Boris Kisselevsky as Director General Secretariat
- [2026-07-23] ECB press: Monetary policy decisions
- [2026-07-23] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*