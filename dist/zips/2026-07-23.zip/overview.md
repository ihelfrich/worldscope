# WORLDSCOPE morning brief — 2026-07-23

## Headline
3307 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (756) · Russian Internal News (state + in-exile) (691) · State-Level News (452) · World leaders & government officials (324) · Chinese Internal News (235) · Local News: St. Louis + Atlanta (217) · Ukraine Theater (total-war monitoring) (172) · U.S. Weather + Severe / Climate Outlooks (119) · Ukrainian Internal News (national + local Kyiv) (62) · IT, InfoSys & cybersecurity news (last 7 days) (44) · U.S. Federal Action (41) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 756 new of 1021 total
  - (2026-07-23) [Global] Two Russian men jailed in Angola for terrorism and spying
  - (2026-07-22) [Global] Nicaragua’s congress announces ‘work plan’ to suspend elections
  - (2026-07-22) [Global] Sperm whales change ‘vowel’ sounds when boats are nearby, scientists discover
  - (2026-07-21) [Global] Trump defends 50% tariffs on Canada, saying ‘they need us to survive’
  - (2026-07-23) [Global] Total solar eclipse books out hotels two years in advance in New Zealand city
  - (2026-07-22) [Global] British woman jailed in Hong Kong for blackmail after accusing banker of rape

### Russian Internal News (state + in-exile) — 691 new of 1123 total
  - (2026-07-23) Минцифры порекомендовало устанавливать российские сертификаты безопасности | LEDE: ] (ru: Минцифры порекомендовало устанавливать российские сертификаты безопасности)
  - (2026-07-23) На морском терминале КТК приостановили погрузочные операции | LEDE: ] (ru: На морском терминале КТК приостановили погрузочные операции)
  - (2026-07-23) BMW отзывает более 318 тысяч машин в США | LEDE: ] (ru: BMW отзывает более 318 тысяч машин в США)
  - (2026-07-23) "Заключим сделку". В США сделали заявление о конце конфликта на Украине | LEDE: ] (ru: "Заключим сделку". В США сделали заявление о конце конфликта на Украине)
  - (2026-07-23) Аномальная жара в июне причинила серьезный ущерб экономике Великобритании | LEDE: ] (ru: Аномальная жара в июне причинила серьезный ущерб экономике Великобритании)
  - (2026-07-23) Суд не стал снижать компенсацию Безрукову за продажу масок с его лицом | LEDE: ] (ru: Суд не стал снижать компенсацию Безрукову за продажу масок с его лицом)

### State-Level News — 452 new of 861 total
  - (2026-07-22) [California] Acting Governor Rivas proclaims Disability Pride Month
      Source
  - (2026-07-22) [California] California delivers major blow to organized retail theft, recovering $76.2 million in stolen goods since 2019
      Source
  - (2026-07-22) [California] Governor Newsom announces appointments 7.22.2026
      Source
  - (2026-07-22) [Alabama] Governor Ivey Signs Executive Order Establishing Commission on Screen-Based Instruction
      MONTGOMERY – Governor Kay Ivey on Wednesday signed Executive Order No. 745 establishing the Governor’s Commission on Screen-Based Instruction to study the use, risks and benefits of screen-based instruction in Alabama’s…
  - (2026-07-22) [Alabama] Executive Order 745
      Download
  - (2026-07-22) [Alabama] Executive Order 744
      Download

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 235 new of 304 total
  - (2026-07-22) Vanke Wins New Funding as It Completes Extensions on 2026 Public Bonds - Caixin Global
      Vanke Wins New Funding as It Completes Extensions on 2026 Public Bonds Caixin Global
  - (2026-07-22) 城投发债门槛新增“三道红线” 融资收紧可能带来什么局面？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1HckZtZWNXQjRwc0FUR0YxcVdWMDl6S3o1Y1ZJX29GZUtMbVNmNzUyYjhYNGl4aEVsQTdsVmY0dWtQX3M1dzFYMFJyZ] (zh:…
      城投发债门槛新增“三道红线” 融资收紧可能带来什么局面？ 财新
  - (2026-07-22) 特稿｜韩国股市版“鱿鱼游戏” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9JenRVVWlXdVBxVDUtRWo5YkJHczFvMUptU19mRkZWaEJiM25RZjdHYS0xWEdlWDk4SHlWclRZaG1YSnQ1Ry04ZDhnNmtrcVdxVTBmYjh] (zh:…
      特稿｜韩国股市版“鱿鱼游戏” 财新
  - (2026-07-22) 英籍女子在港诬告男银行家强奸并勒索 被判入狱6年 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5RcFhNOWFoSGlBcVZsQUNoYW1WSEtaM25DLWI0ajRrV1c0aWRsWXIxR25CSEhOajE3ZDNHQ1JOX0F6UjR] (zh:…
      英籍女子在港诬告男银行家强奸并勒索 被判入狱6年 china.caixin.com
  - (2026-07-22) 6月财政收入同比增长8.7% 支出增速由负转正 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0zNURnZUZwM3YxdDExMVlTV1gxOW5FY0ZxU01OdEtQZ0FDWjFlRFFUb3ZCV2JLTlpGRXdkRTlONXF2NWc4RU9yekxLS3BILU] (zh:…
      6月财政收入同比增长8.7% 支出增速由负转正 财新
  - (2026-07-22) 公募基金二季度净利1.94万亿元 主动权益基金抱团TMT - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5TbkRFZmtBdHZHdUJUZGpRLTFvb3d5VkpMQU02YTlNcE15VmRjNi1wcWhxMjU0QXpGeVRqdUEtV2FNX3ZseUV3UDZVW] (zh:…
      公募基金二季度净利1.94万亿元 主动权益基金抱团TMT 财新

### Local News: St. Louis + Atlanta — 217 new of 250 total
  - (2026-07-23) [St. Louis] Nearly 1.6 million dozen eggs recalled over salmonella risk
      The recall affects eggs sold under several brands at Kroger and Brookshire's grocery stores across multiple Southern states.
  - (2026-07-23) [St. Louis] Missouri early voting period opens with a rush that points to high primary turnout
      Four times as many voters cast ballots in St. Charles County on Tuesday than on the first day of early voting before the 2024 primary, the elections director said.
  - (2026-07-23) [St. Louis] Tropical Storm Bertha makes landfall in Louisiana and moves toward Texas with punishing wind and storm surge
      The storm is unlikely to leave behind widespread damage as the heaviest rains are staying offshore.
  - (2026-07-23) [St. Louis] US carries out 12th night of strikes against Iran as Houthis claim attacks on oil tankers
      A Houthi attack in the Red Sea threatened to open a new front in a war that has roiled the global economy.
  - (2026-07-23) [St. Louis] Winning Powerball numbers for Wednesday, July 22, 2026, and the $567M jackpot
      The Powerball jackpot surged to $567 million with a $251.8 million cash value.
  - (2026-07-23) [St. Louis] 82-year-old North St. Louis County woman finally gets A/C repaired after waiting more than a week
      It's been nearly a week since KSDK 5's initial report, and the North St. Louis County great-grandmother was fuming because her central air system had not been fixed.

### Ukraine Theater (total-war monitoring) — 172 new of 370 total
  - (2026-07-23) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-18) [Liveuamap] Zelensky: In response to Russian attacks on our civilian infrastructure, our cities and communities, two significant logistics facilities were hit - in the Moscow and Tambov regions, at a…
      Zelensky: In response to Russian attacks on our civilian infrastructure, our cities and communities, two significant logistics facil
  - (2026-07-22) [Liveuamap] A White House official told Reuters that Wittkof and Kushner spoke by phone with Zelensky to discuss the diplomatic path. Washington, District of Columbia - Ukraine Interactive map - Ukrai…
      A White House official told Reuters that Wittkof and Kushner spoke by phone with Zelensky to discuss the diplomatic path. Washin
  - (2026-07-21) [Liveuamap] Drone targets Ali Al Salem Air Base in Kuwait Al Jahra Governorate, Kuwait - Liveuamap
      Drone targets Ali Al Salem Air Base in Kuwait Al Jahra Governorate, Kuwait Liveuamap</f
  - (2026-07-20) [Liveuamap] Ambulance and Emergency Services: A woman was shot by Israeli forces outside their areas of control in the Nuseirat camp in the central Gaza Strip. - Liveuamap
      Ambulance and Emergency Services: A woman was shot by Israeli forces outside their areas of contr
  - (2026-07-21) [Liveuamap] At Oleksandrivka direction clashes yesterday near Vorone, Oleksandrohrad and Ternove, - General Staff of Armed Forces of Ukraine reports Dnipropetrovsk Oblast, Ukraine - Ukraine Interactiv…
      At Oleksandrivka direction clashes yesterday near Vorone, Oleksandrohrad and Ternove, - General Staff of Armed Forces of Ukrain

### U.S. Weather + Severe / Climate Outlooks — 119 new of 123 total
  - (2026-07-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-23) [Severe] Flash Flood Warning: Flash Flood Warning issued July 23 at 8:21AM EDT until July 23 at 11:15AM EDT by NWS Greenville-Spartanburg SC
      FFWGSP The National Weather Service in Greenville-Spartanburg has issued a * Flash Flood Warning for... Northern Graham County in western North Carolina... West Central Swain County in western North Carolina... * Until 1…
  - (2026-07-23) [Moderate] Wind Advisory: Wind Advisory issued July 23 at 4:12AM AKDT until July 23 at 4:00PM AKDT by NWS Anchorage AK
      * WHAT...South to southwest winds 15 to 30 mph with gusts of 35 to 50 mph expected. * WHERE...Western Kenai Peninsula along and near Cook Inlet. * WHEN...Until 4 PM AKDT this afternoon. * IMPACTS...Gusty winds will blow…
  - (2026-07-23) [Moderate] Wind Advisory: Wind Advisory issued July 23 at 4:12AM AKDT until July 23 at 12:00PM AKDT by NWS Anchorage AK
      * WHAT...Southeast winds 25 to 40 mph with gusts of 50 to 65 mph expected. * WHERE...Anchorage and Eagle River Hillsides. * WHEN...Until noon AKDT today. * IMPACTS...Gusty winds will blow around unsecured objects and a f…
  - (2026-07-23) [Moderate] Wind Advisory: Wind Advisory issued July 23 at 4:12AM AKDT until July 23 at 12:00PM AKDT by NWS Anchorage AK
      * WHAT...Southeast winds 15 to 30 mph with gusts of 35 to 50 mph expected. Strongest winds in south to west Anchorage (along Turnagain Arm). * WHERE...Lower elevations of Anchorage and Eagle River. * WHEN...Until noon AK…
  - (2026-07-23) [Severe] Coastal Flood Warning: Coastal Flood Warning issued July 23 at 7:03AM CDT until July 23 at 7:00PM CDT by NWS Lake Charles LA
      * WHAT...Significant coastal flooding. * WHERE...Lower St. Mary Parish. * WHEN...Until 7 PM CDT this evening. * IMPACTS...Numerous roads may be closed. Low lying property including homes, businesses, and some critical in…

### Ukrainian Internal News (national + local Kyiv) — 62 new of 117 total
  - (2026-07-23) Глава МЗС Франції: дипломати, які зазнали нападу в Ірані, повернулися до Парижа | LEDE: Двоє французьких дипломатів, які зазнали нападу в Ірані, у середу, 22 липня, повернулися до Парижа.] (uk: Глава…
      Двоє французьких дипломатів, які зазнали нападу в Ірані, у середу, 22 липня, повернулися до Парижа.
  - (2026-07-23) Зеленський заявив, що США мають кілька ідей щодо завершення війни і анонсував візит в Штати | LEDE: Зеленський заявив, що США підготували кілька планів щодо завершення війни з РФ та анонсував в] (uk:…
      Зеленський заявив, що США підготували кілька планів щодо завершення війни з РФ та анонсував візит до Штатів.
  - (2026-07-23) Зеленський: Я пропонував Федорову кілька посад, остання – віцепрем'єр з військових новацій | LEDE: Президент Володимир Зеленський запропонував ексміністрові оборони Михайлові Федорову посаду ві] (uk:…
      Президент Володимир Зеленський запропонував ексміністрові оборони Михайлові Федорову посаду віцепрем'єр-міністра з військових новацій.
  - (2026-07-23) Для румунських селищ над Дунаєм оголосили повітряну тривогу | LEDE: У Румунії в північній частині району, що межує з Україною по руслу Дунаю, вдень 23 липня оголосили повітряну тривогу.] (uk: Для руму…
      У Румунії в північній частині району, що межує з Україною по руслу Дунаю, вдень 23 липня оголосили повітряну тривогу.
  - (2026-07-23) Пєсков заявив, що немає зрушень у діалозі щодо завершення війни в Україні | LEDE: Прессекретар лідера РФ Дмитро Пєсков після зустрічі на Філіппінах представників Росії та США заявив про відсутн] (uk:…
      Прессекретар лідера РФ Дмитро Пєсков після зустрічі на Філіппінах представників Росії та США заявив про відсутність нових зрушень у діалозі щодо закінчення війни в України.
  - (2026-07-23) На Харківщині росіяни намагаються прорвати кордон на нових ділянках | LEDE: Російсько-окупаційні війська намагаються розширити зону активних бойових дій на півночі Харківщини.] (uk: На Харківщині росі…
      Російсько-окупаційні війська намагаються розширити зону активних бойових дій на півночі Харківщини.

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 57 total
  - (2026-07-23) [BleepingComputer] New RefluXFS Linux flaw lets attackers gain root privileges
      A nine-year-old race condition vulnerability in the Linux kernel's XFS filesystem, tracked as CVE-2026-64600, allows local attackers to overwrite protected files and gain root privileges. [...]
  - (2026-07-23) [BleepingComputer] New msaRAT malware uses Chrome, Edge browsers to route C2 traffic
      The Chaos ransomware gang is using a new backdoor dubbed msaRAT that hides command-and-control (C2) communication by routing it through the Chrome or Edge browsers. [...]
  - (2026-07-23) [BleepingComputer] Microsoft working to fix Exchange Online mailbox quarantine issue
      Microsoft is working to resolve an ongoing Exchange Online issue that has been mistakenly quarantining customers' mailboxes since Sunday. [...]
  - (2026-07-23) [BleepingComputer] Check Point warns of SmartConsole zero-day exploited in attacks
      Israeli cybersecurity firm Check Point Software has addressed an actively exploited zero-day flaw in the company's SmartConsole graphical user interface (GUI) admin panel. [...]
  - (2026-07-23) [The Hacker News] How Synthetic Identity Fraud is Coming for Machine Identities
      Most people understand identity theft as an attacker stealing a real person's sensitive information and impersonating them. Synthetic identity fraud is much harder to catch. Instead of stealing a real identity, the attac…
  - (2026-07-23) [The Hacker News] Attackers Weaponize GitHub Actions Runners to Target cPanel and WHM Servers
      Cybersecurity researchers have shed light on a large-scale campaign that has turned compromised GitHub repositories into distributed attack infrastructure designed to target cPanel and WebHost Manager (WHM) instances. Th…

### U.S. Federal Action — 41 new of 41 total
  - (2026-07-23) Continuation of the National Emergency With Respect to Mali
  - (2026-07-23) Securing America's Defense Supply Chains and Ensuring Domestic Acquisition of Critical Materials
  - (2026-07-23) Made in America Week, 2026
  - (2026-07-23) Captive Nations Week, 2026
  - (2026-07-23) Imposing Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Motor Vehicles
  - (2026-07-23) Imposing Additional Duties To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Dairy

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-23) 424B3 - FreeCast, Inc. (0001633369) (Filer)
      filed 2026-07-23 12:22 UTC — Filed: 2026-07-23 AccNo: 0001213900-26-080643 Size: 1 MB
  - (2026-07-23) [O'Reilly Timothy M] Form 4 (Reporting)
      filed 2026-07-23 12:08 UTC · role: Reporting — Filed: 2026-07-23 AccNo: 0001676421-26-000002 Size: 5 KB
  - (2026-07-23) [Invesco Quality Municipal Income Trust] Form 4 (Issuer)
      filed 2026-07-23 12:08 UTC · role: Issuer — Filed: 2026-07-23 AccNo: 0001676421-26-000002 Size: 5 KB
  - (2026-07-23) 425 - LIVEPERSON INC (0001102993) (Subject)
      filed 2026-07-23 12:04 UTC — Filed: 2026-07-23 AccNo: 0001193125-26-313372 Size: 757 KB
  - (2026-07-23) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-07-23 12:04 UTC — Filed: 2026-07-23 AccNo: 0001918704-26-020984 Size: 470 KB
  - (2026-07-23) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-07-23 12:04 UTC — Filed: 2026-07-23 AccNo: 0001918704-26-020984 Size: 470 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDACS — global disaster alerts — 29 new of 234 total
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone ELEVEN-26
      Tropical Cyclone · Orange alert · China · Tropical Depression (maximum wind speed of 139 km/h)

### USGS earthquakes (M4.5+, past day) — 18 new of 18 total
  - (2026-07-23) M 5.1 - 92 km SE of Atka, Alaska
      M5.1 · 92 km SE of Atka, Alaska · depth 35 km
  - (2026-07-23) M 5.1 - 85 km SE of Tatsugō, Japan
      M5.1 · 85 km SE of Tatsugō, Japan · depth 10 km
  - (2026-07-23) M 5.1 - central Mid-Atlantic Ridge
      M5.1 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-07-22) M 5.1 - 61 km SSW of San Pedro de Atacama, Chile
      M5.1 · 61 km SSW of San Pedro de Atacama, Chile · depth 108.731 km
  - (2026-07-23) M 5.0 - 38 km SSE of Spearman, Texas
      M5.0 · 38 km SSE of Spearman, Texas · depth 5.6885 km
  - (2026-07-22) M 5.0 - Kermadec Islands, New Zealand
      M5.0 · Kermadec Islands, New Zealand · depth 46.903 km

### Paper Trading Scorecard — 16 new of 141 total
  - (2026-07-23) [Polymarket] Will OpenAI's valuation hit (HIGH) $2.0T by December 31?
      This market will resolve to "Yes" if OpenAI's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or exc…
  - (2026-07-23) [Polymarket] Will Gold (XAUUSD) hit (LOW) $3,900 in July?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of July 2026, any 1-minute candle for Gold (XAUUSD) has a final "High" or "Low" price equal to or beyond (above for ↑…
  - (2026-07-23) [Manifold] Will I get a higher grade than קרני at חדוא 2
  - (2026-07-23) [Manifold] Will "Are we existentially threatened by the type o..." make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-07-23) [Manifold] Andy Burnham to announce wealth tax before December 2026
  - (2026-07-23) [Manifold] Will Isaac King set his curtain on fire?

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 108 total
  - (2026-07-23) [BIS Entity List] page checksum b562eee9df45
      Page content hash: b562eee9df45. Compare with prior day's hash to detect updates.
  - (2026-07-23) [USASpending] $42,096,094,267 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-07-23) [USASpending] $34,256,470,773 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS
  - (2026-07-23) [USASpending] $30,543,975,956 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-07-23) [USASpending] $19,743,215,928 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…
  - (2026-07-23) [USASpending] $3,083,020,287 → OAK RIDGE ASSOCIATED UNIVERSITIES, INCORPORATED: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIEN
      Agency: Department of Energy. Description: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIENCE AND EDUCATION

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-07-22) U.S. Court of Appeals, 11th Cir.: United States v. Gray Rivera
  - (2026-07-22) U.S. Court of International Trade: Bridgestone Americas Tire Operations, LLC v. United States
  - (2026-07-22) U.S. Court of Appeals, 9th Cir.: Torres-Casas v. Blanche
  - (2026-07-22) U.S. Court of Appeals, 6th Cir.: United States v. Martin Murff
  - (2026-07-22) U.S. Court of Appeals, 7th Cir.: BBLI Edison, LLC v. City of Chicago
  - (2026-07-22) Delaware Supreme Court: Joanne Mondragon, as parent and guardian of J.W., a minor v. The Board of Education of The Colonial School District

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-23) LoL: JD Gaming vs Anyone's Legend (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $2,535,578 · resolves 2026-07-23
  - (2026-07-23) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $2,418,561 · resolves 2026-06-01
  - (2026-07-23) Livesport Prague Open: Nikola Bartunkova vs Lanlana Tararudee
      yes price: 0% · 24h volume: $1,429,234 · resolves 2026-07-29
  - (2026-07-23) LoL: JD Gaming vs Anyone's Legend - Game 2 Winner
      yes price: 0% · 24h volume: $1,420,968 · resolves 2026-07-23
  - (2026-07-23) Counter-Strike: Aurora Gaming vs FOKUS (BO3) - BLAST Bounty Qualifier
      yes price: 18% · 24h volume: $1,064,412 · resolves 2026-07-23
  - (2026-07-23) Will the Fed decrease interest rates by 50+ bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $671,846 · resolves 2026-07-29

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-23) [Japan] Europe Hits Google With $1 Billion Fine For Boxing - Out Rivals
      engadget.com · English
  - (2026-07-23) [Japan] Why Beast of Reincarnation Deserves Your Attention
      gamingbolt.com · English
  - (2026-07-23) [Japan] Sony FX5 Cinema Camera Finally Offers Open Gate And RAW 5K Recording
      engadget.com · English
  - (2026-07-23) [Japan] Avatar Legends : The Fighting Game Xbox Series X / S Release Delayed to September 3rd
      gamingbolt.com · English
  - (2026-07-23) [Japan] Bruno Mars – The Romantic Tour ( Tokyo Dome )
      metropolisjapan.com · English
  - (2026-07-23) [Japan] A SpaceX Falcon 9 Rocket Is Expected To Crash Into The Moon This August
      engadget.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-23) [Marginal Revolution] Alex Tabarrok on the Economic Analysis of Crime
      I tell my Gary Becker story, why I like police more than prisons, how criminals are like children and more. The post Alex Tabarrok on the Economic Analysis of Crime appeared first on Marginal REVOLUTION.
  - (2026-07-23) [Marginal Revolution] What should I ask Gita Gopinath?
      Yes I will be doing a Conversation with her. From Wikipedia: Gita Gopinath…is an Indian-American economist who is currently serving as the Gregory and Ania Coffey professor of Economics at Harvard University and previous…
  - (2026-07-23) [Marginal Revolution] My excellent Conversation with Andrew Graham-Dixon
      Here is the audio, video, and transcript. From the episode summary: Tyler and Andrew discuss whether it was inevitable we’d rediscover Vermeer, how that vanishingly rare sect left its fingerprints all over his life, why…
  - (2026-07-22) [Conversable Economist] Chokepoints for Ocean Trade: Strait of Hormuz, and What Else?
      For those who can be fuzzy on global geography, like me, it’s perhaps useful to say that the Persian Gulf is a body of water bordered by eight countries: Bahrain, Iran, Iraq, Kuwait, Qatar, Saudi Arabia, the United Arab…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-07-22) CVE-2026-16232 · Check Point SmartConsole: Check Point SmartConsole Improper Authentication Vulnerability
      vendor: Check Point · product: SmartConsole · CISA remediation by 2026-07-25
  - (2026-07-22) CVE-2026-50522 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-25

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 1 new of 35 total
  - (2026-07-23) #30 Germán Larrea Mota Velasco & family — $65.27B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=41, 7d-median=20, 14d-median=20; carrying terms: remove, authorized, review, public, persons, vessels, specifically, special, environment, amendment, final, allow
- state_bills: today=0, 7d-median=120, 14d-median=120; carrying terms: amended, codes, ombudsman, amount, consumer, agreement, population, contact, later, distribution, nonprofit, procedures
- state_news: today=861, 7d-median=747, 14d-median=747; carrying terms: dozen, receives, endangered, results, merger, media, minnesota, maintaining, charges, honor, remove, decade
- local_news: today=250, 7d-median=227, 14d-median=227; carrying terms: media, charges, downtown, things, including, events, articles, several, national, death, group, following
- foreign_news: today=1021, 7d-median=1021, 14d-median=1021; carrying terms: suspension, media, photos, naval, attack, decade, locals, kicked, leading, pursue, container, democratic
- chinese_internal: today=304, 7d-median=303, 14d-median=303; carrying terms: lxtfb, cbmiykfvx, articles, title, china, cbmicefvx, cbmib, global, capital, cbmix, https, cbmizkfvx
- russian_internal: today=1123, 7d-median=908, 14d-median=908; carrying terms: journal, media, istories, apple, forbidden, street, truth, financial, httperror, laquo, https, google
- ukrainian_internal: today=117, 7d-median=125, 14d-median=125; carrying terms: growing, communication, international, naval, continue, attack, defense, latest, systems, mission, broke, month
- ukraine_theater: today=370, 7d-median=443, 14d-median=443; carrying terms: nqzfjwjlmmemztwjottd, cuxos, tyzjkcznjzm, vgxwsl, ntbho, zzchniouvksldbmhuxqthkaevmtk, lwytlarmfwz, zkywukptvuvnm, jetfcx, cbmikwfbvv, media, zkrnbvhjm
- paper_bets: today=141, 7d-median=144, 14d-median=144; carrying terms: receives, current, koivun, leaders, creation, minnesota, communication, population, court, chase, statement, midterm
- weather: today=123, 7d-median=167, 14d-median=167; carrying terms: afdlwx, northern, movement, beaches, pontiac, continue, counties, hazardous, lightning, highest, afdffc, expect
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: headline, personal, energy, consumption, dexchus, effective, cpilfesl, unrate, unemployment, sheet, treasury, funds
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, agriculture, large, yield, natural, range, proxy, russell, futures, china, crude, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=117, 14d-median=117; carrying terms: amended, libya, tzuvgzfrgsq, acronym, deduohntrfnednhyytjwovi, outlines, rebuil, qjrqy, eddpt, uuxpwhc, agreement, international
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, unauthorized, error, congresstrading, quantitative, https, httperror, quiverquant, client
- billionaires: today=35, 7d-median=35, 14d-median=35; carrying terms: technology, diversified, amazon, jensen, investments, microsoft, mukesh, amancio, ambani, francoise, walton, changpeng
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, investments, limited, court, international, children, bernardo, charles, corona, appeals, trade, insurance
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, thomas, holdings, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ocasio, sherrod, house, receipts, jonathan, action, cortez, krishnamoorthi, chartered, political, committee, groom
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, google
- gdelt_gkg: today=75, 7d-median=46, 14d-median=46; carrying terms: english, hezbollah, israel, chinese, trump, sanctions, themes, russia, perimeter, arabic, russian, latest
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=20, 14d-median=20; carrying terms: belgium, canada, position, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: senegal, viruses, infect, unrelated, transmitted, nipah, strain, circulate, regio, mainly, current, monthly
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: balbooa, appliances, upload, overly, langflow, authorization, mechanism, deserialization, untrusted, business, services, directory
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=234, 7d-median=165, 14d-median=165; carrying terms: brazil, romania, guinea, colombia, ecuador, kazakhstan, marino, congo, north, maximum, philippines, alert
- usgs_quakes: today=18, 7d-median=18, 14d-median=18; carrying terms: puerto, depth, kermadec, islands, indonesia, atlantic, ridge, abepura, vanuatu, region
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, ethiopia, minister, price, resolves, prime, rates, meeting, interest, mekonnen, demeke, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: lecture, movement, conve, overall, interlocutor, mokyr, vibes, effects, caught, refer, useful, pushback
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: vulnerabilities, attack, speed, digital, london, better, moderation, systems, advanced, unknown, review, public
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: agriculture, bennet, moore, shreve, clarence, cohen, baldwin, fitzgerald, nikki, ciscomani, carter, langworthy
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, placed, sufficient, identify, decision, consensus, claude, today, market, unavailable, evidence, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-07-21] ECB press: July 2026 euro area bank lending survey
- [2026-07-21] ECB press: ECB appoints Boris Kisselevsky as Director General Secretariat

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*