# WORLDSCOPE morning brief — 2026-11-23

## Headline
2983 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (763) · Russian Internal News (state + in-exile) (563) · World leaders & government officials (324) · Chinese Internal News (215) · Local News: St. Louis + Atlanta (136) · GDELT GKG — themes / entities / watch areas (125) · U.S. Weather + Severe / Climate Outlooks (121) · State Legislative Action (109) · World News (by country, top stories) (101) · State-Level News (90) · Ukraine Theater (total-war monitoring) (84) · Ukrainian Internal News (national + local Kyiv) (54)

## What changed today
### International News + Multilateral Institutions — 763 new of 938 total
  - (2026-11-23) [Global] Ligue 1: Marseille lose to Le Mans after being up 2 goals at home
      Olympique de Marseille suffered a home defeat against Le Mans (3–2). Having led 2-0 after 40 minutes thanks to goals from Gouiri (33’) and Paixão (40’), OM collapsed.
  - (2026-11-23) [Global] Live: Zelensky confirms Ukraine’s military struck Russian ships in Libyan waters
      Ukraine’s military was responsible for drone attacks on two Russian vessels at the Libyan port of Benghazi Sunday, President Volodymyr Zelensky confirmed Monday. The president alleged that the Russian corvette Merkury ha…
  - (2026-11-23) [Global] Thousands rally in Istanbul against Turkey’s crackdown on opposition and media
      Thousands marched in Istanbul on Sunday against a widening crackdown on Turkey’s opposition and independent media, days after police raided Sozcu TV and arrested senior staff. The main opposition Yeni Parti organised the…
  - (2026-11-23) [Global] Christmas market returns to Paris' Champs Elysées
      France 24's Jamie Smith-Maillet reports from the opening of the Paris Christmas market on the Champs Elysées.
  - (2026-11-23) [Global] France's far-right leader Le Pen denies receiving secrets from civil servant
      French far-right leader Marine Le Pen Sunday denied receiving confidential information from a civil servant suspected of leaking details of investigations to her National Rally (RN) party, while acknowledging she could n…
  - (2026-11-23) [Global] COP31 climate talks in Turkey collapse
      EU member states on Sunday objected to adopting an 11th-hour deal that omitted explicit references to fossil fuels, the bloc's presidency said. The issue remains a major point of contention at the summit, which is taking…

### Russian Internal News (state + in-exile) — 563 new of 707 total
  - (2026-11-23) Пашинян опубликовал проект новой конституции Армении. По требованию Азербайджана из нее исключили отсылку к «воссоединению» с Нагорным Карабахом | LEDE: Премьер-министр Армении Никол Пашинян] (ru: Паш…
      Премьер-министр Армении Никол Пашинян опубликовал проект новой Конституции страны.
  - (2026-11-23) «Образцовая украинская операция в ответ на российскую войну». Зеленский подтвердил, что Украина атаковала российский корабль в Ливии | LEDE: Президент Украины Владимир Зеленский подтвердил, ] (ru: «Об…
      Президент Украины Владимир Зеленский подтвердил, что украинские военные атаковали корвет ВМФ России «Меркурий» у берегов Ливии.
  - (2026-11-23) «Он не друг Америки в Украине. Совсем нет». Директор разведки США — о словах Трампа, назвавшего Путина «другом» | LEDE: Директор Национальной разведки США Джей Клейтон прокомментировал телек] (ru: «Он…
      Директор Национальной разведки США Джей Клейтон прокомментировал телеканалу ABC News слова президента Дональда Трампа, который дважды назвал Владимира Путина своим другом.
  - (2026-11-23) В поселке Дымер Киевской области в результате российского удара погибли 11 человек | LEDE: Спасатели продолжают разбор завалов в поселке Дымер Киевской области, где в ночь на 22 ноября росси] (ru: В п…
      Спасатели продолжают разбор завалов в поселке Дымер Киевской области, где в ночь на 22 ноября российский дрон ударил по пятиэтажному жилому дому.
  - (2026-11-23) В России вновь предложили ввести прокатные удостоверения для видеоигр | LEDE: Правительство России считает, что в стране нужно ввести прокатные удостоверения для видеоигр по аналогии с фильм] (ru: В Р…
      Правительство России считает, что в стране нужно ввести прокатные удостоверения для видеоигр по аналогии с фильмами, сообщила газета «Коммерсант», ссылаясь на источники.
  - (2026-11-23) «Медуза» и другие независимые издания изучили утечку данных Росстата о смертности. Новая оценка потерь ВС РФ — до осени 2026 года — будет опубликована 23 ноября | LEDE: «Медуза», «Медиазона»] (ru: «Ме…
      «Медуза», «Медиазона» и еще более десятка журналистских коллективов сегодня вечером (после 17 CET) подведут итоги независимого анализа данных смертности в России, которые были получены от хакерских группировок «Киберпарт…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 215 new of 250 total
  - (2026-11-22) 财经早知道｜纳指暴跌5%，亚洲密集释放政策迎开盘 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0wLWtIZFFmcUNibUtsbFp1YlNJbHZFV0JEcTg5T2tNQTVwa0FkVmlySEtxZ3otOXlEUFNBaVBzcVY5ZjdvQ1VuZks4eUxBZ] (zh:…
      财经早知道｜纳指暴跌5%，亚洲密集释放政策迎开盘 财新
  - (2026-11-23) 今日开盘：两市双双低开 沪指跌幅0.86% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1WTDdTNVpqQmp5djZTZDhKYjJtM2pXMWdBbXJBdF9wNEpnS0V2SkVCNk84VmhDWXNjelZKWjVpRUZWekw5OVJabGhJVS1UV0xU] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.86% 财新
  - (2026-11-22) 财新闻｜金价跌势凌厉，多家银行发布紧急提示 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5mRUswMlhOVlkzRW5mZTd5R3l3dGpuQjBTRkRiZkpvblFrWkxGSnRVSWI3c0JEMS1OSnJZYnRweERPV010cVVuSUJCUlJiR3ZY] (zh:…
      财新闻｜金价跌势凌厉，多家银行发布紧急提示 财新
  - (2026-11-22) 时隔6年，新版国际高血压指南发布：血压在这一区间的人，要尽早干预｜健保 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5XakJzN09pYUV4ZVJHZWQwdzhBdmd4cGNLeDVzYmFaeUpiT2pTS0Y5ZTZKQ1IzXzkzYW5vMGkxcTdoakc4LV] (zh:…
      时隔6年，新版国际高血压指南发布：血压在这一区间的人，要尽早干预｜健保 财新
  - (2026-11-23) 财新闻｜稳市场，三项新政来了 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1waXN2QUxuSXUxME5jNlpzT19PYlFTd3FjNjN4VlFFTjVfNUR4bGEtQm1FRjVpczRsVEs1azJxbVNqRDYwS0tmNWstOWZqTGhwMWxzS0s] (zh:…
      财新闻｜稳市场，三项新政来了 财新
  - (2026-11-23) 人事观察｜江西省委换届 63岁尹弘当选省委书记 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBOVDVEc3Z2NXhUQWtVcUdoWFRfdlprTC1CMm1lenNwaEU5V1UzQlYtZmVtRlJJdURMclRLRE51Zmp1Ukl4WnVNTnR3T1djY3] (zh:…
      人事观察｜江西省委换届 63岁尹弘当选省委书记 财新

### Local News: St. Louis + Atlanta — 136 new of 212 total
  - (2026-11-22) [St. Louis] The Jujube Inn in the Central West End closing, Mainlander expanding
      The Jujube Inn (392 N. Euclid), which sits adjacent to The Mainlander Supper Club and connects to it inside, will serve its last round on Saturday, November 28. Owners Blake Askew and Gordon Chen plan to turn the “no res…
  - (2026-11-23) [St. Louis] Miley Cyrus marries drummer Maxx Morando in Palm Springs
      Miley Cyrus married rock drummer Maxx Morando in an intimate weekend wedding in Palm Springs, California
  - (2026-11-23) [St. Louis] Delta flight delays disrupt Thanksgiving travel for passengers heading to St. Louis
      A Delta technical issue delayed thousands of flights Sunday, disrupting Thanksgiving travel plans for passengers heading to St. Louis.
  - (2026-11-23) [St. Louis] Court approves $7.25 billion settlement with Bayer over claims Roundup weed killer caused cancer
      Agrochemical maker Bayer will pay up to $7.25 billion over two decades to resolve claims that its popular weed killer Roundup could cause lymphoma.
  - (2026-11-23) [St. Louis] US Army plans to detonate nearly 5 tons of lead azide in Iowa on Wednesday
      The U.S. Army said it intends to move forward with its planned controlled detonation of nearly 5 tons of lead azide in Iowa by Wednesday.
  - (2026-11-23) [St. Louis] Mistaken text leads to decade-long Thanksgiving tradition and now Lifetime movie
      A mistaken text in 2016 sparked a viral Thanksgiving tradition between Wanda Dench and Jamal Hinton, which is now being turned into a Lifetime movie.

### GDELT GKG — themes / entities / watch areas — 125 new of 125 total
  - (2026-11-23) [Russia oil sanctions perimeter · themes] Trump's Director of National Intelligence squirms as he is pressed over whether Putin is 'a friend' to the USA
      dailymail.com · English · tone -1.12554112554113
  - (2026-11-23) [Russia oil sanctions perimeter · near] 15 killed in Russian strikes on Kyiv region, Ukraine says
      rte.ie · English · tone -6.89655172413793 · 13 other outlets
  - (2026-11-23) [Russia oil sanctions perimeter · near] Russian warship sinks after drone attack in Libya
      samaa.tv · English · tone -5.27522935779817 · 6 other outlets
  - (2026-11-23) [Russia oil sanctions perimeter · near] How far can Ukraine go in its counter attacks against Russia?
      abc.net.au · English · tone -12.0 · 2 other outlets
  - (2026-11-23) [Russia oil sanctions perimeter · near] Russia Hits Energy Facilities and Port Infrastructure Used by Ukrainian Army
      sputnikglobe.com · English · tone 0.0 · 2 other outlets
  - (2026-11-23) [Russia oil sanctions perimeter · near] Kushner: Trump urges Europe to invest in its own economies rather than fund Ukraine
      en.apa.az · English · tone 5.37634408602151 · 1 other outlets

### U.S. Weather + Severe / Climate Outlooks — 121 new of 123 total
  - (2026-11-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-23) [Moderate] Special Weather Statement: Special Weather Statement issued November 23 at 1:00AM MST by NWS Great Falls MT
      A mix of patchy dense fog and very low clouds has developed early this morning. If you encounter fog while driving, slow down and use low-beam headlights. The patchy dense fog will continue through the remainder of the m…
  - (2026-11-22) [Moderate] Wind Advisory: Wind Advisory issued November 22 at 11:52PM PST until November 24 at 4:00PM PST by NWS Seattle WA
      * WHAT...Southeast winds 15 to 25 mph with gusts up to 50 mph expected. * WHERE...Foothills of the Western and Southern Olympic Peninsula, Grays Harbor County Coast, and Northern Washington Coast. * WHEN...From 4 PM Mond…
  - (2026-11-23) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 23 at 1:46AM CST until November 23 at 10:00AM CST by NWS Green Bay WI
      * WHAT...Snow. Total snow accumulations of 2 to 5 inches across the northern portion of the county, with 1 to 2 inches over the south. * WHERE...Vilas County. * WHEN...Until 10 AM CST this morning. * IMPACTS...Plan on sl…
  - (2026-11-23) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 23 at 12:43AM MST until November 23 at 10:00AM MST by NWS Billings MT
      * WHAT...Areas of dense fog producing visibility of a quarter mile or less. * WHERE...Portions of central and south central Montana, especially on the east side of the mountains. * WHEN...Until 10 AM MST this morning. *…
  - (2026-11-23) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 23 at 12:40AM MST until November 23 at 11:00AM MST by NWS Great Falls MT
      * WHAT...Visibility one-quarter mile or less in dense fog. * WHERE...Big Belt, Bridger and Castle Mountains, Beaverhead and Western Madison below 6000ft, Gallatin Valley, and Missouri Headwaters. * WHEN...Until 11 AM MST…

### State Legislative Action — 109 new of 136 total
  - (2026-11-21) [Nevada SB 92] Establishes a civil cause of action for the intentional damage or destruction of public property. (BDR 3-557)
      Establishes a civil cause of action for the intentional damage or destruction of public property. (BDR 3-557)
  - (2026-11-21) [Nevada AB 89] Makes an appropriation to the Nevada State Infrastructure Bank Fund for certain projects relating to affordable housing. (BDR S-560)
      Makes an appropriation to the Nevada State Infrastructure Bank Fund for certain projects relating to affordable housing. (BDR S-560)
  - (2026-11-21) [Nevada SB 82] Makes revisions relating to public health. (BDR 40-120)
      Makes revisions relating to public health. (BDR 40-120)
  - (2026-11-21) [Nevada AB 91] Revises provisions relating to nonemergency secure behavioral health transport services. (BDR 38-526)
      Revises provisions relating to nonemergency secure behavioral health transport services. (BDR 38-526)
  - (2026-11-21) [Nevada SB 84] Revises provisions relating to state business licenses. (BDR 7-592)
      Revises provisions relating to state business licenses. (BDR 7-592)
  - (2026-11-21) [Nevada AB 90] Revises various provisions relating to business. (BDR 7-591)
      Revises various provisions relating to business. (BDR 7-591)

### World News (by country, top stories) — 101 new of 101 total
  - (2026-11-23) [Brazil] From pest to prized coffee picker, a Brazilian bird tells the story of a forest
      globaltimes.cn · English · 1 other outlets ran this story
  - (2026-11-23) [Brazil] Self-sustaining mosquito intervention protects Brazilian children during record dengue outbreak
      cedarnews.net · English
  - (2026-11-23) [Brazil] Newcastle disease has not hurt Brazil chicken exports
      thepoultrysite.com · English
  - (2026-11-23) [Brazil] Lula's Digital General Wants to Defeat the Far Right Worldwide – Sri Lanka Guardian
      slguardian.org · English
  - (2026-11-23) [Canada] What is Canada's Parliamentary Press Gallery Dinner? Inside the annual political roast where Mark Carney, Pierre Poilievre and journalists trade jokes
      indiatimes.com · English · 11 other outlets ran this story
  - (2026-11-23) [Canada] 1 person seriously injured, 2 homes destroyed in Vancouver Island blaze | Tofino/Ucluelet Westerly News
      westerlynews.ca · English · 4 other outlets ran this story

### State-Level News — 90 new of 170 total
  - (2026-11-22) [Colorado] Commentary: Coloradans would be left to live with the wreckage of permitting bill
      In the wake of an election in which Americans voted overwhelmingly to rein in President Donald Trump’s agenda, Congress is considering a bill that would remove legal guardrails on a president that has repeatedly shown hi…
  - (2026-11-22) [Arkansas] Christian nationalists see Republicans’ midterm losses as an opportunity to supplant Trump’s MAGA
      IRVING, Texas (AP) — Christian nationalists once celebrated President Donald Trump’s return to the White House as a victory for their movement. Now they see the Republican Party’s recent election losses as an opportunity…
  - (2026-11-22) [Arkansas] Commentary: Believe it or not, there are things to be thankful for in Arkansas politics
      Political journalists are the worst people to ask for hopeful news. It’s hard to find optimism among a group of people whose job is covering the latest political fight or crisis. That’s especially the case over the past…
  - (2026-11-22) [Arkansas] National outages, emergency alerts become fodder for doomsday conspiracy theories
      Stock up on food and medicine. Fill containers with water. Prepare to live off the grid for at least 90 days. Those were among the warnings circulating on social media in recent weeks, as online posts predicted a looming…
  - (2026-11-23) [Connecticut] CT families deserve to see every home for sale
      <img width="1019" height="664" src="https://ctmirror.org/wp-content/uploads/2026/11/for-sale.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high" srcset="h…
  - (2026-11-23) [Connecticut] CT must now confront the costs of past PURA decisions
      <img width="583" height="431" src="https://ctmirror.org/wp-content/uploads/2026/11/gas-line-workers.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="…

### Ukraine Theater (total-war monitoring) — 84 new of 269 total
  - (2026-11-23) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-22) [Liveuamap] A suspected Ukrainian speedboat targeted the… - Liveuamap
      A suspected Ukrainian speedboat targeted the… Liveuamap
  - (2026-11-22) [Liveuamap] Sky News Arabic reports: Libyan and regional sources say the naval base in Misrata hosts Ukrainian military personnel - Liveuamap
      Sky News Arabic reports: Libyan and regional sources say the naval base in Misrata hosts Ukrainian military personnel</
  - (2026-11-17) [Liveuamap] Video of destroyed Kerch bridge – Kerch, Crimea - Liveuamap
      Video of destroyed Kerch bridge – Kerch, Crimea Liveuamap
  - (2026-11-20) [Liveuamap] Kyiv Mayor Klitschko: A… – Kyiv, Kyiv city - Liveuamap
      Kyiv Mayor Klitschko: A… – Kyiv, Kyiv city Liveuamap
  - (2026-11-20) [Liveuamap] Ukraine&039;s nuclear power plants were forced to…… - Liveuamap
      Ukraine&039;s nuclear power plants were forced to…… Liveuamap

### Ukrainian Internal News (national + local Kyiv) — 54 new of 103 total
  - (2026-11-23) Пашинян представив проєкт нової конституції Вірменії та пов’язав його з миром з Азербайджаном | LEDE: Вірменський прем'єр-міністр Нікол Пашинян представив проєкт нової конституції країни: докум] (uk:…
      Вірменський прем'єр-міністр Нікол Пашинян представив проєкт нової конституції країни: документ опублікували на сайті, де громадяни можуть ознайомитися з його змістом і залишити власні пропозиції.
  - (2026-11-23) Західна розвідка попереджає: Росія готується розмістити ядерну зброю у космосі – ЗМІ | LEDE: Західні розвідувальні служби попереджають про нову ядерну загрозу з боку Москви: Росія може вивести ] (uk:…
      Західні розвідувальні служби попереджають про нову ядерну загрозу з боку Москви: Росія може вивести на орбіту супутник з ядерною боєголовкою вже найближчими тижнями.
  - (2026-11-23) Фінські депутати підтримують ідею укріплення кордону з РФ за досвідом України | LEDE: ] (uk: Фінські депутати підтримують ідею укріплення кордону з РФ за досвідом України)
  - (2026-11-23) Зеленський підтвердив, що біля Лівії українські дрони затопили "Меркурій" і уразили російський суховантаж | LEDE: Президент Володимир Зеленський підтвердив, що біля лівійського порту Бенгазі ук] (uk:…
      Президент Володимир Зеленський підтвердив, що біля лівійського порту Бенгазі українські морські дрони затопили російський корвет "Меркурій" із вертольотом Ка-27 на борту та уразили суховантаж MV ANGARA, яким Росія перево…
  - (2026-11-23) Сили оборони уразили місце дислокації "Рубікону С" на Курщині і спростовують фейк РФ | LEDE: Сили оборони України спростували фейк про нібито дистанційне замінування ними міста Рильськ Курської] (uk:…
      Сили оборони України спростували фейк про нібито дистанційне замінування ними міста Рильськ Курської області РФ.
  - (2026-11-23) У Словаччині коаліція опозиційних партій істотно випереджає партію Фіцо – опитування | LEDE: Опозиційна коаліція випередила Smer на 7 пунктів, за неї проголосували б 24,1% виборців за даними Ip] (uk:…
      Опозиційна коаліція випередила Smer на 7 пунктів, за неї проголосували б 24,1% виборців за даними Ipsos для Denník N.

### Wikidata leader-roster changes (48h) — 50 new of 65 total
  - (2026-11-23) [Dominican Republic] Luis Arruinader (Q16594097) edited
      /* wbsetlabeldescriptionaliases:3|en */ Luis Arruinader, President of the Dominican Republic since 2020, Luis Arruinader Corona, Luis Rodolfo Abinader Corona, luis préstamo
  - (2026-11-23) [Democratic Republic of the Congo] Félix Tshisekedi (Q29032770) edited — position held
      /* wbsetclaim-update:2||1|1 */ [[Property:P39]]: [[Q3409199]]
  - (2026-11-23) [Ghana] John Mahama (Q50678) edited — position held
      /* wbsetclaim-update:2||1|1 */ [[Property:P39]]: [[Q2672728]]
  - (2026-11-23) [Eritrea] Isaias Afwerki (Q57348) edited — position held
      /* wbsetclaim-update:2||1|1 */ [[Property:P39]]: [[Q19108193]]
  - (2026-11-23) [Ivory Coast] Alassane Ouattara (Q57413) edited — position held
      /* wbsetclaim-update:2||1|1 */ [[Property:P39]]: [[Q3409195]]
  - (2026-11-23) [Kenya] William Ruto (Q195725) edited — position held
      /* wbsetclaim-update:2||1|1 */ [[Property:P39]]: [[Q14784066]]

### GDACS — global disaster alerts — 47 new of 100 total
  - (2026-11-23) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.4M, Depth:119.267km
  - (2026-11-23) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 5M, Depth:98.944km
  - (2026-11-23) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 4.9M, Depth:595.973km
  - (2026-11-23) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 6.5M, Depth:598km
  - (2026-11-23) [Green] Earthquake in China
      Earthquake · Green alert · China · Magnitude 4.9M, Depth:10km
  - (2026-11-23) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.7M, Depth:50.25km

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-23) 2 drivers taken to hospital after crash involving police vehicle near Durango and Russell
      domain: news3lv.com · language: English · tone: -7.57575757575758 · 102 other outlets ran this story
  - (2026-11-23) [United States] Manchester Co-Op Live: Thousands evacuated as 'unknown substance' fills UK arena during US rapper's show
      domain: cyprusnews.eu · language: English · tone: -5.88235294117647 · 95 other outlets ran this story
  - (2026-11-23) [Indonesia] Indonesia candy factory fire death toll reaches 24
      domain: standard.net.au · language: English · tone: -3.23275862068965 · 69 other outlets ran this story
  - (2026-11-23) Disability benefits should be tailored to claimants' actual costs, review to say | East London and West Essex Guardian Series
      domain: guardian-series.co.uk · language: English · tone: -1.38121546961326 · 65 other outlets ran this story
  - (2026-11-23) [Turkey] 9 people injured in alleged gang related shooting at an unsanctioned concert, deputies say
      domain: cnycentral.com · language: English · tone: -5.55555555555556 · 53 other outlets ran this story
  - (2026-11-23) [United States] Democrats secure biggest House majority in decades with affordability agenda ahead
      domain: ksla.com · language: English · tone: -2.12089077412513 · 47 other outlets ran this story

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 30 new of 60 total
  - (2026-11-20) U.S. Court of Appeals, D.C. Cir.: Mercuria Energy Group Limited v. Republic of Poland
  - (2026-11-20) U.S. Court of Appeals, D.C. Cir.: Nicholas Voegeli v. Hung Cao
  - (2026-11-20) U.S. Court of Appeals, 10th Cir.: United States v. Clark
  - (2026-11-19) U.S. Court of Appeals, 11th Cir.: United States v. Michael Angelo Tollen
  - (2026-11-19) Delaware Supreme Court: Kostyshyn v. State
  - (2026-11-19) Delaware Supreme Court: Kostyshyn, Patricia v. New Castle County, a political subdivision of the State of Delaware

### Paper Trading Scorecard — 23 new of 81 total
  - (2026-11-23) [Polymarket] Will 1 Fed rate hike happen in 2026?
      This market will resolve according to the exact amount of hikes of 25 basis points in 2026 by the Fed (including any hikes made during the December meeting). Emergency rate hikes outside of scheduled FOMC meetings will a…
  - (2026-11-23) [Polymarket] Will Abigail Spanberger win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-11-23) [Polymarket] Will Kamala Harris win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-11-23) [Polymarket] Will Jensen Huang be arrested by December 31, 2026?
      This market will resolve to “Yes” if Jensen Huang, co-founder of NVIDIA, is arrested between market creation and the specified date, 11:59 PM ET. Otherwise, this market will resolve to “No”. A qualifying arrest occurs wh…
  - (2026-11-23) [Polymarket] Probable FDV above $50M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Probable's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token m…
  - (2026-11-23) [Manifold] will @aaa on hack club slack post a meta post about Nest by tomorrow

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-11-23) M 6.5 - Vanuatu region
      M6.5 · Vanuatu region · depth 598 km · TSUNAMI
  - (2026-11-23) M 5.4 - 181 km NE of Lospalos, Timor Leste
      M5.4 · 181 km NE of Lospalos, Timor Leste · depth 119.267 km
  - (2026-11-22) M 5.4 - 9 km N of Carhuamayo, Peru
      M5.4 · 9 km N of Carhuamayo, Peru · depth 117.396 km
  - (2026-11-22) M 5.1 - 45 km SE of Ürümqi, China
      M5.1 · 45 km SE of Ürümqi, China · depth 10 km
  - (2026-11-23) M 5.0 - 159 km ESE of Kokopo, Papua New Guinea
      M5.0 · 159 km ESE of Kokopo, Papua New Guinea · depth 98.944 km
  - (2026-11-23) M 4.9 - Vanuatu region
      M4.9 · Vanuatu region · depth 595.973 km

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-21) [F3] MARK NAIR FOR CD13
      cycle 2026 · filing #2048864
  - (2026-11-21) [F99] (unknown)
      cycle 2026 · filing #2048848
  - (2026-11-21) [F99] (unknown)
      cycle 2026 · filing #2048846
  - (2026-11-21) [F99] (unknown)
      cycle 2026 · filing #2048833
  - (2026-11-21) [F99] (unknown)
      cycle 2026 · filing #2048834
  - (2026-11-21) [F99] (unknown)
      cycle 2026 · filing #2048826

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 63 total
  - (2026-11-23) [BleepingComputer] CISA flags critical Cisco RCE flaw as actively exploited in attacks
      The US Cybersecurity and Infrastructure Security Agency (CISA) warned federal agencies that attackers are now exploiting a recently patched critical Cisco Expressway vulnerability in the wild. [...]
  - (2026-11-23) [The Register] Techie turned his too-easy job interview into a trap
      With the flick of a switch, he smoked out competent PC maintenance skills
  - (2026-11-23) [The Register] Google claims last week’s critical VMware bug was under attack in September
      China-linked ARMORY CASTLE knew about it weeks before it unleashed five custom malware tools targeting vCenter
  - (2026-11-23) [The Register] $1 of GPT-5.1 tokens finds new ways around China’s Great Firewall
      PLUS: Lenovo's infra group finally makes big profit; Indonesia’s glaciers are gone; Australian bank releases its AI bug-finder; and more!
  - (2026-11-23) [TechCrunch] How Notable Capital, GIC, and Baillie Gifford bet big on Anthropic before its IPO
      Three significant backers share what gave them conviction to bet billions on Anthropic.
  - (2026-11-22) [BleepingComputer] Hackers exploit GL.iNet cloud flaw to infect routers, KVM devices
      GL.iNet has confirmed that hackers exploited a vulnerability in its cloud remote management services to install custom malware on customers' routers and KVM devices, with some affected users reporting backdoors and rever…

### Government & military aircraft airborne (OpenSky) — 13 new of 13 total
  - (2026-11-23) GAF014 (Germany)
      icao24: 3f717c · position: (53.337, 16.4578) · alt: 7002m · 610km/h
  - (2026-11-23) CFC2929 (Canada)
      icao24: c2b585 · position: (57.2213, -0.666) · alt: 8839m · 535km/h
  - (2026-11-23) FNY55C4 (France)
      icao24: 39a407 · position: (48.5505, -4.1862) · alt: 1127m · 370km/h
  - (2026-11-23) JAF8AV (Belgium)
      icao24: 44d1a7 · position: (35.4246, 26.0046) · alt: 11277m · 888km/h
  - (2026-11-23) GAF621 (Germany)
      icao24: 3f7b3c · position: (50.8708, 7.137) · on ground · 38km/h
  - (2026-11-23) FAF4095 (France)
      icao24: 3b7564 · position: (45.2307, 14.4001) · alt: 11277m · 894km/h

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-11-23) Yokohama: Ryo Ono vs Lennon Roark Jones
      yes price: 22% · 24h volume: $1,035,576 · resolves 2026-11-30
  - (2026-11-23) Will there be no new be CEO of NVIDIA by December 31, 2028?
      yes price: 18% · 24h volume: $413,552 · resolves 2029-01-01
  - (2026-11-23) Will Jensen Huang rejoin NVIDIA by November 30, 2026?
      yes price: 3% · 24h volume: $381,805 · resolves 2026-12-01
  - (2026-11-23) Will Jensen Huang rejoin NVIDIA by December 31, 2026?
      yes price: 10% · 24h volume: $335,887 · resolves 2027-01-01
  - (2026-11-23) Will Nikki Haley win the 2028 Republican presidential nomination?
      yes price: 1% · 24h volume: $334,612 · resolves 2028-11-08
  - (2026-11-23) Spread: Bengals (-6.5)
      yes price: 48% · 24h volume: $194,796 · resolves 2026-11-24

### Commentary & analysis (last 7 days) — 3 new of 3 total
  - (2026-11-23) [Marginal Revolution] Best non-fiction books of 2026
      These are in the order I read them, and behind the link is either my post on the book or simply the Amazon page: Alan Allport, Advance Britannia: The Epic Story of the Second World War, 1942-1945. Anna Arno, Paul Celan:…
  - (2026-11-22) [Marginal Revolution] Increasing pay for lower wage workers
      From 2014 to 2024, the share of U.S. hourly workers paid below $15 in real terms fell by two-thirds, from 38 percent to 13 percent. Why? We first distinguish the entry and exit of employers—wherein high-paying employers…
  - (2026-11-22) [Marginal Revolution] Sunday assorted links
      1. Jonathan Yardley, RIP (NYT). One of the great book reviewers. 2. Summary of the RH proof. 3. A site collecting my talks and links. 4. Humans were never in control. 5. The Buddhist AI cult? (New Yorker) 6. Teortaxes on…

### Government Action: Sanctions + Procurement + Foreign Agents — 2 new of 104 total
  - (2026-11-21) [OFAC] 1278 - Office of Foreign Assets Control (.gov)
      1278 Office of Foreign Assets Control (.gov)
  - (2026-11-20) [OFAC] 1277 - Office of Foreign Assets Control (.gov)
      1277 Office of Foreign Assets Control (.gov)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 1 new of 33 total
  - (2026-11-23) MOVER ▲ Zhong Shanshan — $65.30B (+$0.10B since yesterday)
      China · Food & Beverage · source: Beverages, pharmaceuticals

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=17, 14d-median=20; carrying terms: provide, amend, action, certain, directives, airplanes, standards, safety, final, published, update, proposed
- state_bills: today=136, 7d-median=73, 14d-median=88; carrying terms: state, business, public, local, including, health, relating, emergency, practice, development, county, transfer
- state_news: today=170, 7d-median=711, 14d-median=711; carrying terms: police, recent, economic, nofollow, media, whether, already, major, conference, colorado, family, letters
- local_news: today=212, 7d-median=250, 14d-median=252; carrying terms: police, family, death, million, missouri, google, officials, thanksgiving, opens, county, found, accused
- foreign_news: today=938, 7d-median=1012, 14d-median=997; carrying terms: police, recent, economic, follow, already, major, conference, attack, deputy, heavy, scheduled, philippines
- chinese_internal: today=250, 7d-median=315, 14d-median=319; carrying terms: cbmiykfvx, chinese, cbmidefvx, cbmizkfvx, lxtfb, google, lxtfa, china, cbmixkfvx, cbmiw, title, cbmizefvx
- russian_internal: today=707, 7d-median=947, 14d-median=947; carrying terms: forbidden, times, politico, gazeta, client, title, media, novaya, novayagazeta, bloomberg, found, server
- ukrainian_internal: today=103, 7d-median=127, 14d-median=132; carrying terms: minister, plant, police, targeting, emergency, european, injuring, major, attack, discussions, censor, missiles
- ukraine_theater: today=269, 7d-median=277, 14d-median=272; carrying terms: tmhtaef, rjhvaxdvn, cexpdxpfytlmt, qtrolu, duvzflrgdevtvidvhnn, terms, wgvqtdljtf, zexcxnxjkmwpuug, upstreamautherror, attack, ngpyqk, cbmiwefvx
- paper_bets: today=81, 7d-median=77, 14d-median=77; carrying terms: resolve, minister, season, solved, israel, allen, israeli, lifetime, former, koivun, marke, speed
- weather: today=123, 7d-median=125, 14d-median=127; carrying terms: dense, norton, gusting, cause, upper, region, average, southwest, monitoring, heavy, center, oxnard
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, vixcls, rates, indicator, headline, dexchus, jtsjol, labor, consumption, inflation, cpiaucsl, unemployment
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, credit, yield, agriculture, rates, treasury, equities, close, nasdaq, proxy, commodities, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=104, 7d-median=101, 14d-median=100; carrying terms: transnistria, unauthorised, blank, economic, transnistrian, hamas, systems, region, space, taliban, sanctions, proliferation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quiver, httperror, https, quantitative, error, unauthorized, congresstrading, client
- billionaires: today=33, 7d-median=40, 14d-median=34; carrying terms: sergey, buffett, steve, devasini, gcarsoa, ballmer, ellison, larry, facebook, telecom, carlos, technology
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: people, appeals, state, blanche, martin, company, court, supreme, miller, charles, delaware, international
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, holdings, william, management, capital, brian, technologies, james, robert
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: krishnamoorthi, talarico, booker, cortez, senate, robert, filing, peltola, cycle, warner, disbursements, sayed
- gdelt_regions: today=101, 7d-median=103, 14d-median=101; carrying terms: english, japan, turkey, china, south, trump, korea, minister, portugal, security, turkish, colombia
- gdelt_gkg: today=125, 7d-median=132, 14d-median=118; carrying terms: english, israel, russian, keywords, hezbollah, sanctions, netanyahu, trump, attack, election, security, report
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: police, shooting, language, killed, domain, australia, english, trump, putin, outlets, injured, story
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=13, 7d-median=17, 14d-median=19; carrying terms: position, belgium, france, germany, kingdom, ground, canada, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: recent, undetermined, incubation, inconclusive, concentrated, expanding, seasonal, ingredient, caused, batch, division, fourth
- cisa_kev: today=21, 7d-median=18, 14d-median=15; carrying terms: cisco, vulnerability, value, return, check, multiple, missing, vendor, remediation, products, google, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=65, 7d-median=46, 14d-median=53; carrying terms: batch, republic, wbsetsitelink, wbsetdescription, congo, wbsetclaim, toollabs, property, quickstatements, update, wbeditentity, edited
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: burkina, magnitude, flood, forestfire, islands, wildfire, fires, impact, african, australia, south, earthquake
- usgs_quakes: today=16, 7d-median=14, 14d-median=14; carrying terms: depth, indonesia, islands, guinea, papua, region, south, vanuatu, china, chile, tsunami
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, december, volume, rates, championship, shakhtar, presidential, interest, meeting, change, league
- commentary: today=3, 7d-median=4, 14d-median=6; carrying terms: revolution, https, marginal, marginalrevolution, world, links, years, story, assorted, books, proof, dollar
- tech_news: today=63, 7d-median=63, 14d-median=63; carrying terms: systems, access, added, attackers, world, technica, employees, cyber, security, three, stories, hacker
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: huizenga, jason, gooden, nanette, booker, mrvan, elena, norton, minneapolis, fuller, leger, robert
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, identify, today, market, evidence, module, unavailable, either, placed, placement, consensus, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] ECB press: Boris Vujčić: Risks and resilience in the euro area financial system
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] ECB press: Frank Elderson: Smart supervision for small banks
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-17] ECB press: Philip R. Lane: The practice and science of monetary policy communication: the ECB experience
- [2026-11-18] ECB press: Boris Vujčić: Financial Stability Review - November 2026
- [2026-11-18] ECB press: Risks from AI valuations, fiscal imbalances and geoeconomic tensions weigh on financial stability outlook
- [2026-11-18] Fed speeches: Barr, Investing in America’s Underserved Communities
- [2026-11-18] Fed press (events + announcements): Minutes of the Federal Open Market Committee, October 27-28, 2026
- [2026-11-19] Fed speeches: Jefferson, Monetary Policy amid Frequent and Complex Shocks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*