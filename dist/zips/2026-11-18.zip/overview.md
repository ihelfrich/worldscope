# WORLDSCOPE morning brief — 2026-11-18

## Headline
3492 new items across 31 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (857) · Russian Internal News (state + in-exile) (463) · State-Level News (386) · World leaders & government officials (324) · Chinese Internal News (266) · Local News: St. Louis + Atlanta (231) · U.S. Weather + Severe / Climate Outlooks (146) · GDELT GKG — themes / entities / watch areas (132) · World News (by country, top stories) (108) · Ukraine Theater (total-war monitoring) (97) · Ukrainian Internal News (national + local Kyiv) (71) · GDACS — global disaster alerts (63)

## What changed today
### International News + Multilateral Institutions — 857 new of 1035 total
  - (2026-11-17) [Global] As Trump and Xi meet, China's AI dreams face an unexpected hurdle: the Nvidia spy scandal
      China worries the scandal could ramp up pressure on the US to further restrict the sale of advanced chips.
  - (2026-11-18) [Global] Nvidia says it won't reinstate Huang as it reports soaring sales
      The AI chip giant reported strong quarterly earnings on Tuesday after the dramatic exit of Jensen Huang.
  - (2026-11-18) [Global] Rubio says US not 'under systemic attack' after series of tech outages
      Secretary of State Marco Rubio said there was "zero evidence" supporting theories online that recent disruptions affecting Microsoft, banks and flights are connected.
  - (2026-11-18) [Global] Democrats win Alaska Senate race two weeks after midterms counting began
      Confirmation of Mary Peltola's victory caps of the party's rout of the Republicans in the midterms Senate election.
  - (2026-11-17) [Global] Putin's Crimean Bridge partly collapses as Zelensky hails 'unprecedented' attack by Ukraine
      Ukraine says the missile and drone attack on the strategic bridge in the Russian-annexed Crimea took weeks to plan.
  - (2026-11-18) [Global] Philippines police ask prosecutors to charge Thomas Markle over child sex abuse material
      Markle is being held in custody in the US after one charge and has previously denied all of the allegations.

### Russian Internal News (state + in-exile) — 463 new of 821 total
  - (2026-11-18) Украинские военные заявили, что атаковали Крымский мост без использования Starlink | LEDE: Украинская атака по Крымскому мосту 17 ноября проводилась без использования спутниковой связи Starl] (ru: Укр…
      Украинская атака по Крымскому мосту 17 ноября проводилась без использования спутниковой связи Starlink и ее военной версии Starshield. Об этом британской The Times рассказал украинский офицер, участвовавший в операции.
  - (2026-11-18) Кембриджский словарь выбрал слово года — «человеческий» | LEDE: Словом 2026 года по версии Кембриджского словаря английского языка (Cambridge Dictionary) стало прилагательное «человеческий» ] (ru: Кем…
      Словом 2026 года по версии Кембриджского словаря английского языка (Cambridge Dictionary) стало прилагательное «человеческий» (human) — то есть «относящийся к людям, в отличие от животных, машин или богов».
  - (2026-11-18) Стубб заявил, что Финляндия не выйдет из НАТО. По его словам, он никогда не слышал о таком требовании России | LEDE: Финляндия не намерена выходить из НАТО и останется членом альянса, заявил] (ru: Сту…
      Финляндия не намерена выходить из НАТО и останется членом альянса, заявил президент страны Александр Стубб в интервью газете Ilta-Sanomat.
  - (2026-11-18) Украина атаковала два НПЗ в Краснодарском крае | LEDE: Украинские беспилотники утром 18 ноября атаковали Краснодарский край. В Северском районе пострадали четыре человека, сообщили в региона] (ru: Укр…
      Украинские беспилотники утром 18 ноября атаковали Краснодарский край. В Северском районе пострадали четыре человека, сообщили в региональном оперштабе.
  - (2026-11-18) Дженсен Хуанг заявил, что готов вернуться на пост гендиректора Nvidia. Совет директоров ответил отказом | LEDE: Совет директоров Nvidia «не намерен» восстанавливать ушедшего в отставку Дженс] (ru: Дже…
      Совет директоров Nvidia «не намерен» восстанавливать ушедшего в отставку Дженсена Хуанга в должности генерального директора, заявил новый председатель совета Харви Джонс во время телефонной конференции.
  - (2026-11-18) Путин прилетел на саммит АТЭС и встретился с Си Цзиньпином перед трехсторонним саммитом России, США и Китая | LEDE: Владимир Путин прилетел в китайский Шэньчжэнь на саммит Азиатско-Тихоокеан] (ru: Пут…
      Владимир Путин прилетел в китайский Шэньчжэнь на саммит Азиатско-Тихоокеанского экономического сотрудничества (АТЭС) и встретился с председателем КНР Си Цзиньпином.

### State-Level News — 386 new of 712 total
  - (2026-11-17) [Alabama] Governor Ivey Announces Longtime Chief of Staff Liz Filmore to Depart
      MONTGOMERY – Governor Kay Ivey on Tuesday announced her longtime chief of staff, Liz Filmore, will depart the Governor’s Office Tuesday, December 1. Filmore is Governor Ivey’s longest serving chief of staff, as well as h…
  - (2026-11-18) [California] In Washington D.C., Governor Newsom takes urgent call for LA wildfire recovery aid directly to Congress
      Source
  - (2026-11-17) [California] RECORD LOW CRIME RATES: Crime drops again in major cities across California
      Source
  - (2026-11-17) [California] Governor Newsom announces completion of major Sacramento Valley flood project ahead of El Niño
      Source
  - (2026-11-17) [Alabama] Tuberville names Amanda Senn chief legal advisor
  - (2026-11-17) [Alabama] Ivey announces longtime Chief of Staff Liz Filmore to depart

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 266 new of 334 total
  - (2026-11-17) In Depth: An Australian Mine Deal Raises Questions About Huang Qifan’s Son - Caixin Global
      In Depth: An Australian Mine Deal Raises Questions About Huang Qifan’s Son Caixin Global
  - (2026-11-17) Battery Recycling Could Help Ease Raw Material Price Swings, Sunwoda Executive Says - Caixin Global
      Battery Recycling Could Help Ease Raw Material Price Swings, Sunwoda Executive Says Caixin Global
  - (2026-11-17) Economists Call for More Stimulus to Bolster Domestic Demand - Caixin Global
      Economists Call for More Stimulus to Bolster Domestic Demand Caixin Global
  - (2026-11-17) Alibaba Cloud Plans Global Data Center Expansion as AI Demand Grows - Caixin Global
      Alibaba Cloud Plans Global Data Center Expansion as AI Demand Grows Caixin Global
  - (2026-11-18) CX Daily: China’s Automakers Scale Back Humanoid Robot Ambitions as Reality Bites - Caixin Global
      CX Daily: China’s Automakers Scale Back Humanoid Robot Ambitions as Reality Bites Caixin Global
  - (2026-11-17) JD Returns to Revenue Growth as New Business Losses Narrow - Caixin Global
      JD Returns to Revenue Growth as New Business Losses Narrow Caixin Global

### Local News: St. Louis + Atlanta — 231 new of 272 total
  - (2026-11-17) [St. Louis] Despite concerns, VA official says it’s full steam ahead on new records system during St. Louis trip
  - (2026-11-17) [St. Louis] Midwest grid operator justifies data center policy amid concerns about rising utility costs
  - (2026-11-17) [St. Louis] St. Louis man sentenced to 45 years in prison for 2016 shooting that paralyzed Ballwin officer
  - (2026-11-17) [St. Louis] Federal grants fund more than policing in St. Louis region, U.S. attorney says
  - (2026-11-17) [St. Louis] Illinois health chief slams Trump administration after U.S. loses measles elimination status
  - (2026-11-17) [St. Louis] Longtime St. Louis Port Authority director dies after retiring earlier this month

### U.S. Weather + Severe / Climate Outlooks — 146 new of 148 total
  - (2026-11-18) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-17) [Moderate] Wind Advisory: Wind Advisory issued November 17 at 11:47PM PST until November 18 at 10:00PM PST by NWS Sacramento CA
      * WHAT...South to southeast winds 20 to 30 mph with gusts up to 55 mph expected. * WHERE...For the Delta, Foothills, Sacramento Valley, and northern San Joaquin Valley. * WHEN...Until 10 PM PST Wednesday. * IMPACTS...Gus…
  - (2026-11-17) [Moderate] Special Weather Statement: Special Weather Statement issued November 17 at 11:42PM PST by NWS Eureka CA
      At 1142 PM PST, Doppler radar was tracking a line of showers extending from 11 miles west of Orick to 15 miles northwest of Petrolia, or extending from 11 miles west of Orick to 25 miles northwest of Honeydew, moving eas…
  - (2026-11-18) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 18 at 12:41AM MST until November 18 at 5:00AM MST by NWS Riverton WY
      * WHAT...Additional snow accumulations up to 4 inches. Additional accumulations of 1 to 3 inches expected along South Pass. Winds gusting as high as 55 mph. * WHERE...Wind River Mountains West. * WHEN...Until 5 AM MST ea…
  - (2026-11-18) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 18 at 12:41AM MST until November 18 at 11:00AM MST by NWS Riverton WY
      * WHAT...Snow expected. Total snow accumulations of 5 to 10 inches along and north of Highway 16. Winds gusting as high as 45 mph. * WHERE...Bighorn Mountains West. * WHEN...Until 11 AM MST this morning. * IMPACTS...Trav…
  - (2026-11-18) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 18 at 12:41AM MST until November 18 at 5:00AM MST by NWS Riverton WY
      * WHAT...Additional snow accumulations of 2 to 4 inches. Winds gusting as high as 45 mph. * WHERE...Teton and Gros Ventre Mountains, including Teton Pass and Togwotee Pass. * WHEN...Until 5 AM MST early this morning. * I…

### GDELT GKG — themes / entities / watch areas — 132 new of 132 total
  - (2026-11-18) [Russia oil sanctions perimeter · themes] Ukraine Invasion Day 1,728: Tomorrow, will Trump kid Putin about the destroyed Kerch Bridge?
      dailykos.com · English · tone -4.28571428571429 · 29 other outlets
  - (2026-11-18) [Russia oil sanctions perimeter · keywords] Russia's Novatek Names Yevgeny Nagorny to Lead Exploration Unit
      econotimes.com · English · tone 0.526315789473684
  - (2026-11-18) [Russia oil sanctions perimeter · near] Ukraine hits Russia's Kerch Bridge, as Russia strikes back at Kyiv's bridges
      newschannel5.com · English · tone -4.93421052631579 · 42 other outlets
  - (2026-11-18) [Russia oil sanctions perimeter · near] Crimean Bridge Partly Collapses into Sea After Second Ukrainian Attack - Novinite.com
      novinite.com · English · tone -4.70588235294118 · 13 other outlets
  - (2026-11-18) [Russia oil sanctions perimeter · near] Ukraine: Civilian casualties in 2026 already far exceed previous years' tolls — Global Issues
      globalissues.org · English · tone -9.45674044265594 · 2 other outlets
  - (2026-11-18) [Russia oil sanctions perimeter · near] Russian crude exports reach four-month high as Ukrainian drones slam refineries
      seekingalpha.com · English · tone -6.75675675675676 · 2 other outlets

### World News (by country, top stories) — 108 new of 108 total
  - (2026-11-18) [Brazil] Rare encounter with isolated Indigenous people in Brazil raises concerns over their safety
      greeleytribune.com · English · 14 other outlets ran this story
  - (2026-11-18) [Brazil] How Lula turned Bolsonaro's social media campaign on its head
      thenationonlineng.net · English
  - (2026-11-18) [Brazil] São Paulo Daily Brief: Wednesday 18 November 2026
      riotimesonline.com · English
  - (2026-11-18) [Brazil] Brazil turns heat on Big Tech and Bolsonaro camp over foreign interference in elections
      thehindu.com · English
  - (2026-11-18) [Brazil] Pitch invader dodges 7 security officers to snap selfie with player at Singapore-Brazil match
      asiaone.com · English
  - (2026-11-18) [Brazil] EU Postpones Vote on Brazilian Poultry and Honey Export Access
      econotimes.com · English

### Ukraine Theater (total-war monitoring) — 97 new of 276 total
  - (2026-11-18) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-17) [Liveuamap] The arch and main span of the road section of the Kerch Bridge have reportedly been destroyed – Kerch, Crimea - Liveuamap
      The arch and main span of the road section of the Kerch Bridge have reportedly been destroyed – Kerch, Crimea <font c
  - (2026-11-16) [Liveuamap] Russian occupation authorities in Crimea have confirmed new strikes on the Kerch Bridge overnight. - Liveuamap
      Russian occupation authorities in Crimea have confirmed new strikes on the Kerch Bridge overnight. <font c
  - (2026-11-16) [Liveuamap] Vehicle traffic on the Crimean Bridge… – Kerch - Liveuamap
      Vehicle traffic on the Crimean Bridge… – Kerch Liveuamap
  - (2026-11-16) [Liveuamap] Six airstrikes by… – Ma&039;rib Governorate, Yemen… - Liveuamap
      Six airstrikes by… – Ma&039;rib Governorate, Yemen… Liveuamap
  - (2014-11-14) [Liveuamap] Ukraine war live map: front line and news today | Liveuamap - Liveuamap
      Ukraine war live map: front line and news today | Liveuamap Liveuamap

### Ukrainian Internal News (national + local Kyiv) — 71 new of 127 total
  - (2026-11-18) Португалія спрямує ще 50 млн євро на озброєння для України через PURL | LEDE: Нуно Мело на засіданні "Рамштайну" повідомив про додатковий внесок Португалії в програму PURL для підтримки України] (uk:…
      Нуно Мело на засіданні "Рамштайну" повідомив про додатковий внесок Португалії в програму PURL для підтримки України.
  - (2026-11-18) РФ скинула 40 авіабомб за 10 днів: із Балабиного евакуюватимуть родини з дітьми | LEDE: Через погіршення безпекової ситуації місцева влада ухвалила рішення про обов'язкову евакуацію родин із ді] (uk:…
      Через погіршення безпекової ситуації місцева влада ухвалила рішення про обов'язкову евакуацію родин із дітьми з Балабиного Запорізької області.
  - (2026-11-18) У Словаччині в річницю початку Оксамитової революції пройшли мітинги проти уряду Фіцо | LEDE: ] (uk: У Словаччині в річницю початку Оксамитової революції пройшли мітинги проти уряду)
  - (2026-11-18) Окупанти вдарили по ринку на Харківщині: 12 постраждалих, серед них дитина | LEDE: 18 листопада росіяни обстріляли ринок у Златополі Харківської області – постраждали 11 людей, зокрема 11-річни] (uk:…
      18 листопада росіяни обстріляли ринок у Златополі Харківської області – постраждали 11 людей, зокрема 11-річний хлопчик. Триває ліквідація наслідків.
  - (2026-11-18) Десять F-16 і два Mirage до кінця року: партнери оголосили плани допомоги Україні на "Рамштайні" | LEDE: Бельгія планує передати Україні десять винищувачів F-16 до кінця 2026 року, а Франція дв] (uk:…
      Бельгія планує передати Україні десять винищувачів F-16 до кінця 2026 року, а Франція два Mirage 2000-5F, водночас інші партнери оголосили підтримку ППО та закупівель українських дронів.
  - (2026-11-18) В окупації показали Кримський міст зблизька: автомобільна частина знищена, а залізниця – працює | LEDE: Український моніторинговий OSINT-проєкт опублікував кадри знищеної автомобільної частини ] (uk:…
      Український моніторинговий OSINT-проєкт опублікував кадри знищеної автомобільної частини Кримського мосту зблизька, залізнична частина функціонує.

### GDACS — global disaster alerts — 63 new of 100 total
  - (2026-11-18) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5.9M, Depth:21.895km
  - (2026-11-18) [Green] Earthquake in Galapagos Triple Jungtion Region
      Earthquake · Green alert · Galapagos Triple Jungtion Region · Magnitude 5.2M, Depth:10km
  - (2026-11-18) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.8M, Depth:10km
  - (2026-11-18) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.8M, Depth:10km
  - (2026-11-18) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.2M, Depth:10km
  - (2026-11-18) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 5.8M, Depth:52.291km

### IT, InfoSys & cybersecurity news (last 7 days) — 50 new of 62 total
  - (2026-11-18) [Krebs on Security] Attackers Used Optimizely to A/B Test Malware on Top Websites
      At least 178 top web destinations unwittingly served a variety of malware exploits against visitors over the past 24 hours thanks to a security vulnerability involving Optimizely, a company that helps websites customize…
  - (2026-11-18) [The Hacker News] Attackers Compromise Microsoft's Agent Framework PyPI Package to Steal Cloud Credentials
      Threat actors have compromised Microsoft's agent-framework package to push a credential stealer, according to reports from Aikido, Chainguard, Endor Labs, OX Security, SafeDep, Socket, StepSecurity, and Google-owned Wiz.…
  - (2026-11-18) [The Hacker News] Russian COLD RELIC Hackers Use Stolen Google Workspace Data to Breach Second U.S. Organization
      The Russia-linked cyber espionage group known as Cold Relic (formerly COLDRIVER and UNC4057) has been observed weaponizing a single cloud compromise into a launchpad for a series of linked intrusions resulting in third-p…
  - (2026-11-18) [The Hacker News] Java4Shell Flaw (CVE-2026-114938) Enables Pre-Auth RCE in Jira, Jenkins, Keycloak and More
      A Java flaw called Java4Shell can let attackers without an account run their own code on Jira, Jenkins, Keycloak, and three other widely used applications, says Calif, the security research firm that disclosed it this we…
  - (2026-11-18) [The Register] A Chinese bottle-cap manufacturer brilliantly deflated AI hype
      Pre-digital tech can't be transformed and automated
  - (2026-11-18) [The Register] Temu's compliance regime is low-quality, fits badly, and full of holes, says Europe
      Prepares to unleash full wrath of Digital Services Act over Chinese e-tailer's alleged sales of illegal products

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-18) [HIGHLAND OPPORTUNITIES & INCOME FUND] Form 4 (Issuer)
      filed 2026-11-18 02:59 UTC · role: Issuer — Filed: 2026-11-17 AccNo: 0001510281-26-000448 Size: 5 KB
  - (2026-11-18) [Saba Capital Management, L.P.] Form 4 (Reporting)
      filed 2026-11-18 02:59 UTC · role: Reporting — Filed: 2026-11-17 AccNo: 0001510281-26-000448 Size: 5 KB
  - (2026-11-18) [First Finance Ltd.] Form 4 (Reporting)
      filed 2026-11-18 02:51 UTC · role: Reporting — Filed: 2026-11-17 AccNo: 0001493152-26-052957 Size: 9 KB
  - (2026-11-18) [HROMYK ANDREW] Form 4 (Reporting)
      filed 2026-11-18 02:51 UTC · role: Reporting — Filed: 2026-11-17 AccNo: 0001493152-26-052957 Size: 9 KB
  - (2026-11-18) [CLEARONE INC] Form 4 (Issuer)
      filed 2026-11-18 02:51 UTC · role: Issuer — Filed: 2026-11-17 AccNo: 0001493152-26-052957 Size: 9 KB
  - (2026-11-18) [Saba Capital Management, L.P.] Form 4 (Reporting)
      filed 2026-11-18 02:48 UTC · role: Reporting — Filed: 2026-11-17 AccNo: 0001510281-26-000447 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-18) [United States] Final humiliation for Trump as Mary Peltola defeats the real Dan Sullivan in Alaska to hand Democrats 56th Senate seat
      domain: dailymail.com · language: English · tone: -1.93236714975845 · 100 other outlets ran this story
  - (2026-11-18) [Iran] U.S. Strikes Iranian Missile Site After Drone Attack in Bahrain
      domain: sanangelolive.com · language: English · tone: -7.80780780780781 · 66 other outlets ran this story
  - (2026-11-18) [Iran] World News: Trump taking Iran dirty bomb plot 'seriously'
      domain: gdnonline.com · language: English · tone: -6.45161290322581 · 62 other outlets ran this story
  - (2026-11-18) [United States] US loses its measles-free status. Here's how the Trump administration has responded to outbreaks | Health
      domain: timesargus.com · language: English · tone: -2.95608108108108 · 62 other outlets ran this story
  - (2026-11-18) [Russia] Ukraine cripples Crimean road bridge in blow to Putin before meeting with Xi and Trump
      domain: bworldonline.com · language: English · tone: -6.15866388308977 · 58 other outlets ran this story
  - (2026-11-18) [Malaysia] Police van tragedy highlights need for stricter vehicle safety measures, says Lam Thye
      domain: thestar.com.my · language: English · tone: -1.32275132275132 · 57 other outlets ran this story

### State Legislative Action — 33 new of 35 total
  - (2026-11-18) [Alaska SB 207] An Act relating to the removal of unlawful occupants from residential real property; relating to the crimes of trespass, forgery, and deceptive business practices; and amending Rules 8…
      An Act relating to the removal of unlawful occupants from residential real property; relating to the crimes of trespass, forgery, and deceptive business practices; and amending Rules 82 and 85(a), Alaska Rules of Civil P…
  - (2026-11-18) [Alaska HB 126] An Act relating to the reinstatement of Native village corporations; relating to proxy solicitations to shareholders of corporations organized under state law under the Alaska Native C…
      An Act relating to the reinstatement of Native village corporations; relating to proxy solicitations to shareholders of corporations organized under state law under the Alaska Native Claims Settlement Act; and providing…
  - (2026-11-18) [Alaska SB 283] An Act relating to staffing standards for registered nurses; and providing for an effective date.
      An Act relating to staffing standards for registered nurses; and providing for an effective date.
  - (2026-11-18) [Alaska HJR 20] Encouraging the United States Congress to establish hiring goals for apprentices and veteran apprentices.
      Encouraging the United States Congress to establish hiring goals for apprentices and veteran apprentices.
  - (2026-11-18) [Alaska HB 244] An Act relating to certified nurse aide training; and providing for an effective date.
      An Act relating to certified nurse aide training; and providing for an effective date.
  - (2026-11-18) [Alaska SB 250] An Act relating to data centers; and relating to utility service for data centers.
      An Act relating to data centers; and relating to utility service for data centers.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 21 new of 77 total
  - (2026-11-18) [Polymarket] Will Gold (GC) dip to (LOW) $3,000 by end of December?
      This market will resolve to "Yes" if, on any trading day, the official CME settlement price for the Active Month (front month) of Gold (GC) futures is equal to or below the listed price between market creation and the fi…
  - (2026-11-18) [Polymarket] Will Lighter reach $6 before 2027?
      This market will immediately resolve to “Yes” if any Lighter 1-minute candle for Lighter (LIT/USDC) between December 30, 2025, 14:25 and December 31, 2026, 23:59 ET has a final “High” price equal to or greater than the p…
  - (2026-11-18) [Polymarket] Will Javokhir Sindarov win the 2026 World Chess Championship?
      This market will resolve to the player that wins the 2026 World Chess Championship. If at any point it becomes impossible for a listed player to win the 2026 World Chess Championship per the rules of FIDE, the correspond…
  - (2026-11-18) [Manifold] Will the Democratic Party hold a filibuster-proof majority (60+ seats) in the Senate after the 2028 election?
  - (2026-11-18) [Manifold] Will a proof of Cramér's conjecture be published before 2031?
  - (2026-11-18) [Manifold] Avengers: Doomsday Highest Worldwide Grossing Movie of All Time?

### USGS earthquakes (M4.5+, past day) — 20 new of 20 total
  - (2026-11-18) M 5.9 - 85 km WNW of San Juan, Peru
      M5.9 · 85 km WNW of San Juan, Peru · depth 21.895 km
  - (2026-11-18) M 5.8 - 40 km N of Ruteng, Indonesia
      M5.8 · 40 km N of Ruteng, Indonesia · depth 10 km
  - (2026-11-18) M 5.8 - 99 km ESE of Madang, Papua New Guinea
      M5.8 · 99 km ESE of Madang, Papua New Guinea · depth 52.291 km
  - (2026-11-18) M 5.8 - 150 km SW of Merizo Village, Guam
      M5.8 · 150 km SW of Merizo Village, Guam · depth 10 km
  - (2026-11-18) M 5.3 - 16 km ESE of Comandău, Romania
      M5.3 · 16 km ESE of Comandău, Romania · depth 130.266 km
  - (2026-11-18) M 5.3 - 7 km SE of Karakenja, Tajikistan
      M5.3 · 7 km SE of Karakenja, Tajikistan · depth 10 km

### Wikidata leader-roster changes (48h) — 19 new of 35 total
  - (2026-11-18) [Democratic Republic of the Congo] Félix Tshisekedi (Q29032770) edited
      /* wbsetclaim-create:2||1 */ [[Property:P2949]]: Tshisekedi-1
  - (2026-11-18) [Jordan] Abdullah II of Jordan (Q57464) edited
      /* wbeditentity-update-languages-short:0||bn, hi */ Removed erroneous machine-translated label(s) from automated batch (Sept 2024)
  - (2026-11-18) [Malawi] Peter Mutharika (Q7176020) edited
      /* wbsetclaim-create:1||1 */ [[Property:P19]]: [[Q2144010]], Add place of birth Thyolo (Q2144010) from Store norske leksikon, preferred rank (best referenced value; the other value has no source); the item says Zomba (Q2…
  - (2026-11-18) [Libya] Mohamed al-Menfi (Q105319610) edited
      /* wbsetclaim-update:2||1 */ [[Property:P18]]: Mohamed al-Menfi Moscow 2026.jpg
  - (2026-11-18) [South Africa] Cyril Ramaphosa (Q1148669) edited
      /* wbsetclaim-create:1||1 */ [[Property:P19]]: [[Q34647]], Add place of birth Johannesburg (Q34647) from Store norske leksikon, beside the other value (sources disagree); the item says Soweto (Q217426). Case checked in […
  - (2026-11-17) [Cape Verde] José Maria Neves (Q57649) edited
      /* wbsetclaim-create:2||1 */ [[Property:P345]]: nm16383778

### U.S. Federal Action — 17 new of 17 total
  - (2026-11-18) Airworthiness Directives; BRP-Rotax GmbH & Co KG (Formerly BRP-POWERTRAIN GMBH & CO KG and Bombardier-Rotax GmbH) Engines
  - (2026-11-18) Racial Nondiscrimination in Private Schools; Hearing
      This document provides a notice of an additional date for the public hearing on the notice of proposed rulemaking (REG-119986-25) published in the Federal Register on Friday, September 4, 2026. The proposed regulations w…
  - (2026-11-18) Automatic Enrollment Requirements Under Section 414A
      This document sets forth final regulations that provide guidance with respect to the automatic enrollment requirements that apply to certain retirement plans. The regulations reflect statutory changes made by the SECURE…
  - (2026-11-18) Accepted Means of Compliance; Airworthiness Standards: Normal Category Airplanes
      This document announces the availability of ASTM International (ASTM) consensus standards for use as an FAA-accepted means of compliance (MOC) to the applicable airworthiness standards for normal category airplanes. The…
  - (2026-11-18) Protecting Consumers From SIM-Swap and Port-Out Fraud
      In this document, the Wireline Competition Bureau (Bureau) announces that the Office of Management and Budget (OMB) has approved, for a period of three years, the information collection associated with Telephone Number P…
  - (2026-11-18) Air Plan Approval; Texas; Revisions to Concrete Batch Plant Standard Permit
      Pursuant to the Federal Clean Air Act (CAA or the Act), the Environmental Protection Agency (EPA) is proposing to approve revisions to the Texas State Implementation Plan (SIP) submitted by the Texas Commission on Enviro…

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-11-17) U.S. Court of Appeals, 3rd Cir.: United States v. Jason Cain
  - (2026-11-17) U.S. Court of Appeals, 1st Cir.: Brown v. Saint-Gobain Performance Plastics Corp.
  - (2026-11-17) U.S. Court of Appeals, Federal Cir.: Cocona, Inc. v. Vf Outdoor, LLC
  - (2026-11-17) U.S. Court of Appeals, 9th Cir.: Elizondo Urzua v. Blanche
  - (2026-11-17) U.S. Court of Appeals, D.C. Cir.: Sean Nealy v. John Phelan
  - (2026-11-17) U.S. Court of Appeals, 2nd Cir.: Miller v. McDonald

### Government & military aircraft airborne (OpenSky) — 16 new of 16 total
  - (2026-11-18) PAT104 (United States)
      icao24: ae012e · position: (38.7188, -77.1868) · on ground · 10km/h
  - (2026-11-18) SAMU06 (France)
      icao24: 39ca81 · position: (43.8553, 7.4029) · alt: 1379m · 235km/h
  - (2026-11-18) JAF1VB (Belgium)
      icao24: 449681 · position: (43.3363, 0.7736) · alt: 11277m · 781km/h
  - (2026-11-18) SAMU69 (France)
      icao24: 39c994 · position: (45.8352, 4.6068) · alt: 647m · 199km/h
  - (2026-11-18) FAF9175 (France)
      icao24: 3b77ec · position: (47.4929, 3.7589) · alt: 5486m · 523km/h
  - (2026-11-18) JAF78M (Belgium)
      icao24: 44d1ba · position: (34.9444, -8.3493) · alt: 11887m · 833km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 91 total
  - (2026-11-12) [FARA] Foreign Agents Registration Act | FARA Reports to Congress - Department of Justice (.gov)
      Foreign Agents Registration Act | FARA Reports to Congress Department of Justice (.gov)
  - (2026-11-18) [USASpending] $3,438,289,825 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…
  - (2026-11-18) [USASpending] $1,511,043,583 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
  - (2026-11-18) [USASpending] $1,306,189,377 → LEIDOS, INC.: ITSSC TASK ORDER FOR SYSTEMS
      Agency: Social Security Administration. Description: ITSSC TASK ORDER FOR SYSTEMS
  - (2026-11-18) [USASpending] $890,000,663 → PERATON INC.: OPERATIONAL PLANNING IMPLEMENTATION AND ASSESSMENT SERVICES
      Agency: General Services Administration. Description: OPERATIONAL PLANNING IMPLEMENTATION AND ASSESSMENT SERVICES (OPIAS) BASE AWARD.
  - (2026-11-18) [USASpending] $817,865,357 → THE MITRE CORPORATION: CAASD MUST PROVIDE ESSENTIAL ENGINEERING, RESEARCH, AND ANAL
      Agency: Department of Transportation. Description: CAASD MUST PROVIDE ESSENTIAL ENGINEERING, RESEARCH, AND ANALYSIS CAPABILITIES TO SUPPORT THE FAA IN THE PERFORMANCE OF ITS MISSION THROUGH A SYSTEMS APPROACH THAT ADDRES…

### Campaign finance (FEC: top fundraisers + recent filings) — 12 new of 27 total
  - (2026-11-16) [F2] MCGOWAN, CHRIS
      cycle 2026 · filing #2048148
  - (2026-11-16) [F99] (unknown)
      cycle 2026 · filing #2047995
  - (2026-11-16) [F99] PALLONE FOR CONGRESS
      cycle 2026 · filing #2048029
  - (2026-11-16) [F2] LARSEN, RICK
      cycle 2026 · filing #2048051
  - (2026-11-16) [F99] (unknown)
      cycle 2026 · filing #2048053
  - (2026-11-16) [F99] COMMON GOOD PAC
      cycle 2026 · filing #2048103

### Commentary & analysis (last 7 days) — 9 new of 11 total
  - (2026-11-18) [Marginal Revolution] Me on the cyberattacks
      Tyler Cowen: Don’t Be Fooled By Randomness The problems are serious, but the sky is not falling in. When it comes to the recent service outages, keep a few points in mind. First, cyber risk is considerably higher than it…
  - (2026-11-17) [Adam Tooze] Top Links 1288 Is the profit dollar for real? China’s renewable energy exports to ASEAN. Disciplining the CCP & the hermeneutics of Macanese pork stew.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze
  - (2026-11-17) [Marginal Revolution] The Kalshi market on U.S. productivity growth
      It is coming in at 2.2%, people. That is for over the next five years. tys…though even I think it will be a bit higher than that. Yes the liquidity is tiny, but that is endogenous to the reality that huge profits are not…
  - (2026-11-17) [Marginal Revolution] What should I ask Alexander Mikaberidze?
      He is the author and the new and excellent The Louisiana Purchase: The Grand Bargain and the Making of America. He also wrote The Napoleonic Wars: A Global History, one of my favorite history books. He has extensive othe…
  - (2026-11-16) [Adam Tooze] Top Links 1287 Oil markets in glut. Strategic maple syrup reserve runs dry. Win Over Replacement & Carlsen on computers.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze
  - (2026-11-16) [Noah Smith] Bumbition
      An alternative route to success in life.

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-11-18) Will South Shields vs. Harborough Town FC end in a draw?
      yes price: 98% · 24h volume: $729,719 · resolves 2026-11-17
  - (2026-11-18) Will Anthropic's market cap be between $2.0T and $2.25T at market close on IPO day?
      yes price: 3% · 24h volume: $207,288 · resolves 2028-01-01
  - (2026-11-18) England Tour of Australia ODIs: Australia vs England
      yes price: 19% · 24h volume: $203,472 · resolves 2026-11-25
  - (2026-11-18) Will South Shields win on 2026-11-17?
      yes price: 4% · 24h volume: $202,586 · resolves 2026-11-17
  - (2026-11-18) Will Anthropic's market cap be between $1.5T and $1.75T at market close on IPO day?
      yes price: 15% · 24h volume: $200,814 · resolves 2028-01-01
  - (2026-11-18) Israel x Iran ceasefire continues through November 22?
      yes price: 94% · 24h volume: $193,988 · resolves 2026-11-23

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 40 total
  - (2026-11-18) MOVER ▼ Bernard Arnault & family — $117.34B ($-3.58B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-11-18) MOVER ▼ Steve Ballmer — $157.73B ($-2.97B since yesterday)
      United States · Technology · source: Microsoft

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-11-17) Chikungunya virus disease - Switzerland
      On 4 November 2026, health authorities in the canton of Ticino, Switzerland, in coordination with federal authorities, reported four locally acquired cases of chikungunya virus disease. These are the first reported local…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 15 total
  - (2026-11-17) CVE-2026-115731 · Perforce Puppet Enterprise: Perforce Puppet Enterprise Deserialization of Untrusted Data Vulnerability
      vendor: Perforce · product: Puppet Enterprise · CISA remediation by 2026-12-01

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-18) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=21, 14d-median=25; carrying terms: standards, airplanes, applicable, safety, directives, action, certain, proposed, published, agency, proposes, provide
- state_bills: today=35, 7d-median=73, 14d-median=78; carrying terms: including, relating, health, state, business, school, public, local, program, income, emergency, practice
- state_news: today=712, 7d-median=712, 14d-median=712; carrying terms: island, speaker, hawaii, srcset, lower, caucus, health, beyond, losses, attorney, prepare, preliminary
- local_news: today=272, 7d-median=266, 14d-median=265; carrying terms: https, state, arrested, black, winning, google, football, three, being, cbmitafbvv, authorities, officials
- foreign_news: today=1035, 7d-median=977, 14d-median=997; carrying terms: visit, ministers, pressure, province, foundation, health, stations, expected, korea, worth, economy, loses
- chinese_internal: today=334, 7d-median=319, 14d-median=331; carrying terms: cbmia, https, lxtfa, cbmiy, caixin, china, google, cbmixkfvx, cbmizkfvx, cbmiw, cbmizefvx, articles
- russian_internal: today=821, 7d-median=938, 14d-median=946; carrying terms: title, axios, journal, error, financial, istories, found, telegram, server, bloomberg, group, novayagazeta
- ukrainian_internal: today=127, 7d-median=127, 14d-median=134; carrying terms: vechirniy, million, ministers, found, ukrinform, expected, missile, agreement, hromadske, world, warning, https
- ukraine_theater: today=276, 7d-median=271, 14d-median=271; carrying terms: ddctb, npakluvxfjbe, dgxvwkrza, benfcnbfawndznpkvevcngdeyklvtmvboecxrmvsnznvdvdkz, personnel, skpysefln, appoints, zvzfrvphmei, hvymd, xujlrdmv, cbmijwfbvv, cbmilafbvv
- paper_bets: today=77, 7d-median=77, 14d-median=73; carrying terms: celsius, headline, prime, allen, mamdani, supervolcano, visit, break, jackson, problems, sachs, minister
- weather: today=148, 7d-median=127, 14d-median=130; carrying terms: francisco, island, afddtx, afdfwd, including, dangerous, pressure, night, heavy, expected, changed, outages
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, dexuseu, headline, recession, payems, growth, funds, unrate, inflation, consumption, unemployment, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, china, corporate, agriculture, bitcoin, large, russell, futures, natural, nasdaq, credit, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=91, 7d-median=99, 14d-median=99; carrying terms: updates, services, crimea, republic, haiti, haitian, situation, maintenance, blank, application, congo, facilitate
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, httperror, quiverquant, client, unauthorized, quiver, congresstrading, quantitative, https
- billionaires: today=40, 7d-median=36, 14d-median=0; carrying terms: zuckerberg, finance, ballmer, oracle, technologies, holdings, yiming, facebook, carlos, alice, tiktok, warren
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, supreme, blanche, delaware, international, company, state, court, miller, trade, arkansas, martin
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, holdings, finance, joseph, centuri, icahn, capital, group, partners
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: abdul, raised, cortez, alexandria, brown, david, cooper, sherrod, disbursements, robert, filing, house
- gdelt_regions: today=108, 7d-median=101, 14d-median=98; carrying terms: english, korea, south, trump, japan, million, nvidia, china, korean, turkey, german, minister
- gdelt_gkg: today=132, 7d-median=123, 14d-median=48; carrying terms: english, russian, sanctions, themes, keywords, trump, perimeter, russia, hezbollah, israel, china, strikes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: police, suspect, killed, language, murder, domain, shooting, english, australia, trump, story, china
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=16, 7d-median=16, 14d-median=24; carrying terms: position, france, belgium, germany, kingdom, ground, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: identification, regarding, fever, republic, ministry, point, diagnosed, mongbwalu, operator, situation, including, mosquitoes
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: missing, return, vendor, cisco, vulnerability, value, critical, google, check, product, authentication, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=35, 7d-median=54, 14d-median=0; carrying terms: wbsetsitelink, republic, kingdom, congo, update, languages, wbeditentity, toollabs, edited, cleanup, wbsetdescription, property
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: alert, impact, sudan, fires, depth, botswana, south, australia, forest, magnitude, green, forestfire
- usgs_quakes: today=20, 7d-median=11, 14d-median=11; carrying terms: depth, islands, japan, indonesia, region, south, papua, guinea, russia, kavieng, vanuatu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, donetsk, championship, champions, league, shakhtar, november, december, meeting, ceasefire
- commentary: today=11, 7d-median=6, 14d-median=6; carrying terms: revolution, class, marginal, conversable, https, economist, challenges, economic, conversableeconomist, world, marginalrevolution, number
- tech_news: today=62, 7d-median=63, 14d-median=62; carrying terms: hacker, million, squid, brought, several, steal, krebs, multiple, world, active, https, organizations
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: davidson, crenshaw, services, tulsi, mcbride, francisco, miller, chellie, moylan, tenney, score, buchanan
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, converges, placed, sufficient, evidence, unavailable, claude, placement, paper, identify, either, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] ECB press: Boris Vujčić: Risks and resilience in the euro area financial system
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] ECB press: Frank Elderson: Smart supervision for small banks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*