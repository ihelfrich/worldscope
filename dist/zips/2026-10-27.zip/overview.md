# WORLDSCOPE morning brief — 2026-10-27

## Headline
3314 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (811) · Russian Internal News (state + in-exile) (684) · World leaders & government officials (324) · State-Level News (318) · Local News: St. Louis + Atlanta (238) · Chinese Internal News (232) · Ukraine Theater (total-war monitoring) (117) · U.S. Weather + Severe / Climate Outlooks (104) · Ukrainian Internal News (national + local Kyiv) (66) · State Legislative Action (63) · GDACS — global disaster alerts (55) · GDELT GKG — themes / entities / watch areas (50)

## What changed today
### International News + Multilateral Institutions — 811 new of 957 total
  - (2026-10-27) [India] ‘There’s bound to be some tamasha’: Sonia Gandhi on her upcoming memoir ‘Belonging’
  - (2026-10-27) [India] Women safety: NHRC recommends sensitisation of police personnel to avoid victim-shaming of survivors
  - (2026-10-27) [India] Jan Suraaj Party functionary, missing from train, found dead near tracks in Ranchi
  - (2026-10-27) [India] 3 arrested for parading teen, father naked in Kolkata; cops take accused bare-chested through locality
  - (2026-10-27) [India] 'Permission stands even now, with conditions': Delhi Police clarifies after Congress alleges bid to stall Nov 1 protest
  - (2026-10-27) [India] ‘Were officers sleeping?’ SC raps Centre, drug regulator over expired Covid-era approvals

### Russian Internal News (state + in-exile) — 684 new of 991 total
  - (2026-10-27) Айтишник из Челябинска подписал контракт с Минобороны, чтобы «приносить пользу обществу». Ему обещали службу в войсках БПЛА, но отправили в «мясной полк». Он пропал без вести, а его деньги, счи] (ru:…
      IT-специалист из Челябинска подписал контракт с Минобороны России, в котором ему обещали службу в беспилотных войсках. В итоге он попал в «мясной полк». Его отправили на штурм, где он пропал без вести, рассказала «Важным…
  - (2026-10-27) В Украине заявили, что режим прекращения огня в Алешках продлится до 1 ноября | LEDE: Режим прекращения огня в районе города Алешки (украинское название — Олешки) продлится до 22:59 1 ноября] (ru: В У…
      Режим прекращения огня в районе города Алешки (украинское название — Олешки) продлится до 22:59 1 ноября, заявил глава фракции «Слуга народа» и член украинской переговорной группы Давид Арахамия.
  - (2026-10-27) Демократы потребовали расследовать связи Трампа с Эпштейном. Они опубликовали доклад, в котором говорится о новом обвинении в изнасиловании в адрес президента | LEDE: Демократы из юридическо] (ru: Дем…
      Демократы из юридического комитета Палаты представителей Конгресса США в понедельник опубликовали 53-страничный доклад, согласно которому пять женщин обвинили президента Дональда Трампа в изнасиловании или сексуализирова…
  - (2026-10-27) Как студенты смогли победить Вучича? И почему сами студенты на самом деле не пойдут во власть? Анализ Александра Баунова | LEDE: 25 октября Сербская прогрессивная партия Александра Вучича, н] (ru: Как…
      25 октября Сербская прогрессивная партия Александра Вучича, находящаяся во власти больше 14 лет, проиграла парламентские выборы «Студенческому списку» — движению, которое появилось чуть больше месяца назад и выросло из п…
  - (2026-10-27) Килиан Мбаппе рассказал, что любит мем, где его изображают «китайским диктатором». Теперь китайские компании разрывают с ним сотрудничество, а местный вещатель прекращает трансляции чемпионата ] (ru:…
      Два крупных китайских бренда в Китае отказались от сотрудничества с нападающим «Реала» и капитаном сборной Франции Килианом Мбаппе после того, как в интернете распространилось видео, на котором футболист пошутил о Мао Цз…
  - (2026-10-27) Дональд Трамп-младший провел два дня в Монголии с Умаром Кремлевым. Они вместе охотились на горных баранов. А до этого глава Международной ассоциации бокса частично оплатил свадьбу сына президе] (ru:…
      Сын президента США Дональда Трампа, 48-летний Дональд Трамп-младший, в августе 2026 года ездил в Монголию на охоту — и провел там два дня с Умаром Кремлевым, главой Международной ассоциации бокса и предпринимателем, близ…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 318 new of 474 total
  - (2026-10-27) [California] Despite lame duck status, Newsom could take a final shot at utilities’ liability for wildfires
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/010825_Eaton-Power-Lines_JH_CM_19.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-10-27) [California] Will Republicans block Democrats from Congress if they win the midterms? We asked them
      <img width="1024" height="669" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2020/11/Young-Kim.jpg?fit=1024%2C669&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="asy…
  - (2026-10-27) [California] Californians revolt against police drones after rapid adoption across state
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/102226_Skydio-Drone_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-10-27) [California] The final stretch: Catch up on what’s happened in the California governor’s race so far
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/102326-Becerra-V-Hilton-Split-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-10-27) [California] California is about to overhaul the way it runs K-12 schools. Will it fix a fragmented system?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/04/080923_School-Attendance_SN_CM_22.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-10-27) [California] AI and social media bans won’t make California kids safer online. It may even be harmful
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072226-Children-on-phones-GL-GETTY-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…

### Local News: St. Louis + Atlanta — 238 new of 260 total
  - (2026-10-27) [St. Louis] The Darkness haunted house: reviewed!
      One in an occasional series of irreverent reviews designed to help people navigate St. Louis in all its quirky glory. The last time I went into a haunted house, I was 13 years old. I don’t remember much, except that I wa…
  - (2026-10-27) [St. Louis] GOP congressional candidate added to defamation suit over phone call to Idaho sheriff
      The Republican waging a long-shot bid to represent St. Louis in Congress is the latest local to get sucked into an Idaho defamation lawsuit filed by the executive chairman of a critical minerals company that not long go…
  - (2026-10-27) [St. Louis] Early voting totals are way up in St. Louis County
      One week into early voting in St Louis County, more people have already cast a ballot than in all of early voting four years ago, during the last midterm election. “Turnout has been strong,” says Eric Fey, the Democratic…
  - (2026-10-27) [St. Louis] Senate Square auction gets cancelled, again
      Two properties whose auctions were rescheduled to take place yesterday will go unsold, at least for now: the embattled Senate Square apartments in Benton Park, and the tornado-stricken Delmar Savoy apartment building at…
  - (2026-10-27) [St. Louis] This tour reframes Downtown St. Louis’ narrative, one group walk at a time
      Denis Beganovic doesn’t shy away from sharing what he thinks about St. Louis and what will drive it forward. A military planner by day, Beganovic is known by locals as the chronically-online guy posting across social med…
  - (2026-10-27) [St. Louis] Where Art Thou 10/27/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…

### Chinese Internal News — 232 new of 294 total
  - (2026-10-27) 最新财新周刊｜求解A股并购对赌后遗症 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFB0TUQ5cnFXdVFlb1lqejBuV0Y2TXpMY2FETXRwa2ZINDdCOEcxNEVZNjc5RHg1dFdpd2syRDNhYjVMNUk2bXhNT2VIdWVvdFBmR] (zh:…
      最新财新周刊｜求解A股并购对赌后遗症 财新周刊
  - (2026-10-27) 【华尔街原声】Anthropic公开提交IPO招股文件，拟在纳斯达克上市 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1WcGE5OUg4SG12V2tEMVRFRFRuazUzZm9paHN6Zmk5djhaMG5kZzVXZUttVmp3NVdZYW5OMzIwb1RVVy1] (zh:…
      【华尔街原声】Anthropic公开提交IPO招股文件，拟在纳斯达克上市 财新数据
  - (2026-10-27) 【市场动态】特朗普关联企业严阵以待民主党调查攻势 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTFBwald0cXFtZ0FGNUlQQWtTRWJ0cC1OZXIxUU1UaTllRF9SSndYdm0waDlFZVVmYk4xbU5XUmFMSnlGazlXUk5zMEZRMjd] (zh:…
      【市场动态】特朗普关联企业严阵以待民主党调查攻势 财新数据
  - (2026-10-27) 任鸿斌寄语APEC工商峰会：汇聚工商界力量 共建亚太共同体 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1uSmhwQmJKX2YwbTl1V2wtSmlsSGNVNy1vWVE2TjBVSUIwODRQNUd2RVpFWEV1NFBGZUV0c1hNOTIyUHVWc0dGX284] (zh:…
      任鸿斌寄语APEC工商峰会：汇聚工商界力量 共建亚太共同体 财新
  - (2026-10-27) 算法铁笼与社会奇点 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1TX1c4U19oX1h4LXphSEZ0eWpmZkpCRl82N19YQkI4UVlrSnFMY19yd2ppUjFGUi1wVjE3YVlSaWJ5bEo2cENCUXJaV1dxY1UyYmx1aGpldGhs] (zh:…
      算法铁笼与社会奇点 财新
  - (2026-10-27) 【华尔街原声】《经济学人》总编辑：法国动荡源于福利困境 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE12SXNVcnZwYzZXbTBoeU82QnNjVmhBajRLYjVJZlZWUGhvOENEUXVSU1NRd3FFaUZ0czV0cUROdXNXQ09YazdlQXMz] (zh:…
      【华尔街原声】《经济学人》总编辑：法国动荡源于福利困境 财新数据

### Ukraine Theater (total-war monitoring) — 117 new of 282 total
  - (2026-10-27) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-26) [FIRMS] thermal anomaly 45.257, 31.673 (FRP 3.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-26 1051Z, FRP 3.39 MW
  - (2026-10-26) [FIRMS] thermal anomaly 49.253, 34.334 (FRP 8.44 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-26 1051Z, FRP 8.44 MW
  - (2026-10-26) [FIRMS] thermal anomaly 49.348, 34.696 (FRP 2.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-26 1051Z, FRP 2.53 MW
  - (2026-10-27) [FIRMS] thermal anomaly 48.533, 34.652 (FRP 9.06 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-27 0045Z, FRP 9.06 MW
  - (2026-10-27) [FIRMS] thermal anomaly 48.529, 34.649 (FRP 3.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-27 0045Z, FRP 3.02 MW

### U.S. Weather + Severe / Climate Outlooks — 104 new of 106 total
  - (2026-10-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-27) [Severe] Winter Storm Warning: Winter Storm Warning issued October 27 at 4:00AM AKDT until October 29 at 4:00PM AKDT by NWS Fairbanks AK
      * WHAT...Heavy snow expected. Total snow accumulations between 6 and 18 inches. Winds gusting as high as 35 mph. * WHERE...Red Dog Mine and the South Slopes of the Western Brooks Range. * WHEN...From 10 AM this morning t…
  - (2026-10-27) [Unknown] Hydrologic Outlook: Hydrologic Outlook issued October 27 at 3:39AM AKDT by NWS Fairbanks AK
      ESFAFG Areas of concern are between Nome and Council, particularity streams and rivers draining the south aspects of the high elevation terrain of the Seward Peninsula. Rivers and streams in the Nome and Council area are…
  - (2026-10-27) [Moderate] Wind Advisory: Wind Advisory issued October 27 at 3:36AM AKDT until October 29 at 7:00AM AKDT by NWS Fairbanks AK
      * WHAT...South winds 30 to 45 mph with gusts up to 65 mph expected. * WHERE...Eastern Alaska Range North of Trims Camp and Windy Pass. * WHEN...From 7 AM Wednesday to 7 AM AKDT Thursday. * IMPACTS...Gusty winds will blow…
  - (2026-10-27) [Severe] High Wind Warning: High Wind Warning issued October 27 at 3:35AM AKDT until October 27 at 4:00PM AKDT by NWS Fairbanks AK
      * WHAT...South winds 30 to 40 mph with gusts up to 60 mph expected. * WHERE...Bering Strait Coast, Diomede, and St Lawrence Island. * WHEN...Until 4 PM AKDT this afternoon. * IMPACTS...High winds may move loose debris, d…
  - (2026-10-27) [Moderate] Gale Warning: Gale Warning issued October 27 at 3:22AM AKDT until October 27 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…

### Ukrainian Internal News (national + local Kyiv) — 66 new of 126 total
  - (2026-10-27) Арахамія: Режим тиші в Олешках триватиме до 1 листопада | LEDE: На фронті у районі Олешків діє режим тиші з 27 жовтня до 22:59 1 листопада для гуманітарної операції. Підтвердили Україна та РФ.] (uk: А…
      На фронті у районі Олешків діє режим тиші з 27 жовтня до 22:59 1 листопада для гуманітарної операції. Підтвердили Україна та РФ.
  - (2026-10-27) Швеція готується до можливої війни: які уроки вона бере від України | LEDE: ] (uk: Швеція готується до можливої війни: які уроки вона бере від України)
  - (2026-10-27) Суд у Німеччині відмовився припинити процес у справі вибухів на "Північних потоках" | LEDE: ] (uk: Суд у Німеччині відмовився припинити процес у справі вибухів на "Північних поток)
  - (2026-10-27) У Британії закликали бути готовими до війни між НАТО та РФ після "заспокійливих" слів Путіна | LEDE: Міністр оборони Великої Британії Вес Стрітінг у Варшаві підкреслив готовність НАТО обороняти] (uk:…
      Міністр оборони Великої Британії Вес Стрітінг у Варшаві підкреслив готовність НАТО обороняти власну територію у разі конфлікту з Росією.
  - (2026-10-27) Південна Корея відкликала 8 своїх дипломатів з України | LEDE: Південна Корея відкликала вісім дипломатів з України на тлі суперечки щодо оприлюднення Києвом інформації про передачу двох північ] (uk:…
      Південна Корея відкликала вісім дипломатів з України на тлі суперечки щодо оприлюднення Києвом інформації про передачу двох північнокорейських військовополонених.
  - (2026-10-27) Швеція на порозі загрози: як країна готується до можливої війни та чого вчиться в України | LEDE: Швеція посилює оборону через кіберзагрози і шпигунство РФ, підтримує Україну на 128 млрд крон. ] (uk:…
      Швеція посилює оборону через кіберзагрози і шпигунство РФ, підтримує Україну на 128 млрд крон. Медійники навчаються стійкості у кризових умовах.

### State Legislative Action — 63 new of 66 total
  - (2026-10-27) [Alaska SB 162] An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
      An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
  - (2026-10-27) [Alaska HB 244] An Act relating to certified nurse aide training; and providing for an effective date.
      An Act relating to certified nurse aide training; and providing for an effective date.
  - (2026-10-27) [Alaska HB 203] An Act relating to the use of certain trawl or dredge fishing gear in state water; and providing for an effective date.
      An Act relating to the use of certain trawl or dredge fishing gear in state water; and providing for an effective date.
  - (2026-10-27) [Alaska HB 47] An Act relating to distribution of a forged digital likeness; relating to crime and criminal procedure; relating to distribution of a generated sexual depiction; relating to generated o…
      An Act relating to distribution of a forged digital likeness; relating to crime and criminal procedure; relating to distribution of a generated sexual depiction; relating to generated obscene child sexual abuse material;…
  - (2026-10-27) [Alaska SB 271] An Act relating to abortion; relating to civil enforcement of abortion laws; relating to abortion after the detection of a fetal heartbeat; and amending Rules 3 and 82, Alaska Rules of…
      An Act relating to abortion; relating to civil enforcement of abortion laws; relating to abortion after the detection of a fetal heartbeat; and amending Rules 3 and 82, Alaska Rules of Civil Procedure, and Rule 508, Alas…
  - (2026-10-27) [Alaska SB 229] An Act relating to certain reports required by the Alaska Public Offices Commission; and relating to the use of campaign contributions held by a candidate or group.
      An Act relating to certain reports required by the Alaska Public Offices Commission; and relating to the use of campaign contributions held by a candidate or group.

### GDACS — global disaster alerts — 55 new of 100 total
  - (2026-10-27) [Green] Earthquake in Argentina
      Earthquake · Green alert · Argentina · Magnitude 4.6M, Depth:206.259km
  - (2026-10-27) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 5.2M, Depth:10km
  - (2026-10-27) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 5M, Depth:10km
  - (2026-10-27) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 5M, Depth:10km
  - (2026-10-27) [Green] Earthquake in Tonga
      Earthquake · Green alert · Tonga · Magnitude 5M, Depth:10km
  - (2026-10-27) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 5.8M, Depth:10km

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-10-27) [Russia oil sanctions perimeter · themes] 奥迪中国官宣 ： 四环标归一汽 ， 字母标 （ AUDI ） 归上汽
      gzstv.com · Chinese · tone NA
  - (2026-10-27) [Russia oil sanctions perimeter · themes] 동해 송정동 주민들 , LS전선 규탄 … 사원아파트 송정동에 건립하라
      newspim.com · Korean · tone NA
  - (2026-10-27) [Russia oil sanctions perimeter · themes] Asian Markets Trade Mixed
      rttnews.com · English · tone NA
  - (2026-10-27) [Russia oil sanctions perimeter · themes] السعودية تعترض صواريخ ومسيرات وسط تصاعد المواجهة مع الحوثيين
      akhbarlibya24.net · Arabic · tone NA
  - (2026-10-27) [Russia oil sanctions perimeter · themes] 전쟁 · 관세 청구서 받아든 유권자 ... 트럼프 외교 심판대 올라 [ 11 · 3 중간선거 … 미국의 선택은 ]( 3 )
      fnnews.com · Korean · tone NA
  - (2026-10-27) [Russia oil sanctions perimeter · themes] Inside the Hazmat Response to the Newport Pacific Seafood Fire
      kezi.com · English · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 56 total
  - (2026-10-27) [BleepingComputer] Apple backports CoreGraphics zero-day patches to older iPhones
      ​Apple has backported security patches released last month to older iPhones and iPads, addressing a zero-day bug exploited in "extremely sophisticated" targeted attacks on iOS devices. [...]
  - (2026-10-27) [BleepingComputer] Energy giant ENGIE discloses data breach affecting customers
      French energy giant ENGIE, one of the world's largest power and natural gas providers, confirmed that attackers stole customer data after breaching a marketing platform used by business partners. [...]
  - (2026-10-27) [BleepingComputer] CISA confirms PHP2Shell vulnerabilities now exploited in attacks
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) has added the PHP2Shell vulnerabilities to its catalog of actively exploited security flaws and ordered federal agencies to patch their systems by Thursday…
  - (2026-10-27) [The Hacker News] Microsoft Authenticator Flaw Let Permissionless Android Apps Steal Work Account Tokens
      Microsoft has fixed a flaw in its Authenticator app for Android that let a malicious app with no permissions pose as a trusted Microsoft app, such as Teams, and collect sign-in tokens for a victim's work account. Microso…
  - (2026-10-27) [The Hacker News] Keystone to Destroy 18,835 Hardware Wallets After Hackers Steal Device Verification Key
      An attacker who gained access to Keystone's website obtained the key that its hardware wallets use to prove they are genuine, the company said in a statement on October 26. Someone with that key could build counterfeit d…
  - (2026-10-27) [The Hacker News] AI-Generated Fake Login Pages Are Making Account Takeovers Easier
      Fake login pages are nothing new, but generative AI is making them easier to build and more convincing. Attackers can recreate familiar login screens, impersonate trusted brands and tailor phishing attempts to specific e…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-27) 424B5 - General Motors Financial Company, Inc. (0000804269) (Filer)
      filed 2026-10-27 12:15 UTC — Filed: 2026-10-27 AccNo: 0001193125-26-432751 Size: 586 KB
  - (2026-10-27) [WANG CHUN KAI] Form 4 (Reporting)
      filed 2026-10-27 12:02 UTC · role: Reporting — Filed: 2026-10-27 AccNo: 0002109337-26-000013 Size: 5 KB
  - (2026-10-27) [OBOOK HOLDINGS INC.] Form 4 (Issuer)
      filed 2026-10-27 12:02 UTC · role: Issuer — Filed: 2026-10-27 AccNo: 0002109337-26-000013 Size: 5 KB
  - (2026-10-27) [Dai Kun] Form 4 (Reporting)
      filed 2026-10-27 12:00 UTC · role: Reporting — Filed: 2026-10-27 AccNo: 0001493152-26-048634 Size: 5 KB
  - (2026-10-27) [Uxin Ltd] Form 4 (Issuer)
      filed 2026-10-27 12:00 UTC · role: Issuer — Filed: 2026-10-27 AccNo: 0001493152-26-048634 Size: 5 KB
  - (2026-10-27) 485BPOS - Tidal Trust II (0001924868) (Filer)
      filed 2026-10-27 11:52 UTC — Filed: 2026-10-27 AccNo: 0001999371-26-023599 Size: 2 MB

### EPSS — highest exploit-probability CVEs — 40 new of 40 total
  - (2026-10-26) CVE-2026-99999: 1% exploit probability (p55.9)
      EPSS 0.008 · percentile 0.559
  - (2026-10-26) CVE-2026-9999: 0% exploit probability (p16.1)
      EPSS 0.002 · percentile 0.161
  - (2026-10-26) CVE-2026-9998: 0% exploit probability (p7.8)
      EPSS 0.002 · percentile 0.078
  - (2026-10-26) CVE-2026-9997: 0% exploit probability (p7.3)
      EPSS 0.002 · percentile 0.073
  - (2026-10-26) CVE-2026-9996: 0% exploit probability (p8.6)
      EPSS 0.002 · percentile 0.086
  - (2026-10-26) CVE-2026-9995: 0% exploit probability (p22.0)
      EPSS 0.003 · percentile 0.220

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 27 new of 27 total
  - (2026-10-27) JAF9FN (Bulgaria)
      icao24: 4520aa · position: (37.0759, -7.953) · alt: 11277m · 812km/h
  - (2026-10-27) CFC3018 (Canada)
      icao24: c2b373 · position: (46.1243, -73.1674) · alt: 11407m · 864km/h
  - (2026-10-27) PAT322 (United States)
      icao24: adfe51 · position: (38.5536, -77.6243) · alt: 2339m · 454km/h
  - (2026-10-27) PAT577 (United States)
      icao24: adfe53 · position: (47.7533, -97.4504) · alt: 937m · 378km/h
  - (2026-10-27) PAT640 (United States)
      icao24: adfe8d · position: (37.8734, -85.8895) · alt: 1996m · 310km/h
  - (2026-10-27) SAMU44 (France)
      icao24: 39ca84 · position: (47.2093, -1.5545) · on ground · 1km/h

### U.S. Federal Action — 18 new of 25 total
  - (2026-10-27) Implementation of HAVANA Act of 2021
      On April 19, 2024, the Department of Justice published an interim final rule to implement the HAVANA Act of 2021. No comments were received on the interim final rule. The HAVANA Act authorizes agency heads to provide pay…
  - (2026-10-27) Hazardous Materials: Harmonization With International Standards
      PHMSA proposes to update the Hazardous Materials Regulations to adopt certain international regulations and standards related to proper shipping names, hazard classes, packing groups, special provisions, packaging author…
  - (2026-10-27) Bipartisan Safer Communities Act of 2022-Criteria for National Instant Criminal Background Check System (“NICS”) Background Checks of Firearm Handlers
      The United States Department of Justice ("Department") is amending several of its regulations pertaining to the National Instant Criminal Background Check System ("NICS" or "system") of the Federal Bureau of Investigatio…
  - (2026-10-27) Safety Zone; Southern California Annual Firework Events for the Los Angeles-Long Beach Captain of the Port Zone
      The Coast Guard is proposing to amend the Southern California Firework Events for Los Angeles-Long Beach Captain of the Port Zone Annual Safety Zones. The Coast Guard proposes eight new events to be added, thirteen event…
  - (2026-10-27) Special Conditions: Embraer S.A. Model ERJ 190-400 Airplane; Embraer Enhanced Takeoff System
      This action proposes special conditions for the Embraer S.A. (Embraer) Model ERJ 190-400 series airplane. This airplane will have a novel or unusual design feature when compared to the state of technology envisioned in t…
  - (2026-10-27) Airworthiness Directives; Ontic Engineering and Manufacturing, Inc. (Type Certificate Previously Held by Swearingen, Fairchild Aircraft, and M7 Aerospace) Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Ontic Engineering and Manufacturing, Inc. Model SA226-T, SA226- AT, SA226-T(B), SA226-TC, SA227-AC (C-26A), SA227-AT, SA227-BC (C-26A), SA227-PC, SA227-C…

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-10-27) M 5.8 - 196 km NW of Port-Olry, Vanuatu
      M5.8 · 196 km NW of Port-Olry, Vanuatu · depth 11 km
  - (2026-10-27) M 5.2 - 191 km NW of Port-Olry, Vanuatu
      M5.2 · 191 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-27) M 5.0 - 184 km NW of Port-Olry, Vanuatu
      M5.0 · 184 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-27) M 5.0 - 206 km NW of Port-Olry, Vanuatu
      M5.0 · 206 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-27) M 5.0 - 95 km NNE of Hihifo, Tonga
      M5.0 · 95 km NNE of Hihifo, Tonga · depth 10 km
  - (2026-10-27) M 4.9 - 69 km WSW of Kirakira, Solomon Islands
      M4.9 · 69 km WSW of Kirakira, Solomon Islands · depth 35 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-10-27) France declares state of emergency by December 31, 2026?
      yes price: 8% · 24h volume: $886,597 · resolves 2027-01-01
  - (2026-10-27) 2026 Balance of Power: Other
      yes price: 0% · 24h volume: $856,592 · resolves 2026-11-04
  - (2026-10-27) Counter-Strike: Liquid vs Aurora Gaming (BO3) - PGL Masters Bucharest Group Stage
      yes price: 16% · 24h volume: $658,040 · resolves 2026-10-27
  - (2026-10-27) Counter-Strike: Nemiga vs DENDELE CS (BO3) - PGL Masters Bucharest Group Stage
      yes price: 98% · 24h volume: $604,818 · resolves 2026-10-27
  - (2026-10-27) Will Together win the most seats in the 2026 Israeli legislative election?
      yes price: 0% · 24h volume: $476,847 · resolves 2026-10-28
  - (2026-10-27) Will Elon Musk win the 2028 Republican presidential nomination?
      yes price: 1% · 24h volume: $418,307 · resolves 2028-11-08

### Paper Trading Scorecard — 10 new of 61 total
  - (2026-10-27) [Manifold] Will CoreWeave be bankrupt by EOY 2027?
  - (2026-10-27) [Manifold] Will BTC reach $85,000 by end of October 31, 2026?
  - (2026-10-27) [Manifold] OpenAI disproof of Exponential Time Hypothesis is substantively correct?
  - (2026-10-27) [Manifold] Will Nicki Minaj be the next White House Press Secretary?
  - (2026-10-27) [Manifold] Will Abdul El-Sayed win by a larger margin than James Talarico does?
  - (2026-10-27) [Manifold] Will Yamal carry the ballon d'or tonight ?

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 102 total
  - (2026-10-26) [OFAC] Issuance of Amended Frequently Asked Questions Regarding Blocking and Rejecting Transactions and Filing Reports with OFAC - Office of Foreign Assets Control (.gov)
      Issuance of Amended Frequently Asked Questions Regarding Blocking and Rejecting Transactions and Filing Reports with OFAC Office of Foreign Assets Control (.gov)
  - (2026-10-26) [OFAC] Updated on - Office of Foreign Assets Control (.gov)
      Updated on Office of Foreign Assets Control (.gov)
  - (2026-10-27) [USASpending] $1,581,222,193 → CALIFORNIA INSTITUTE OF TECHNOLOGY: DEEP SPACE NETWORK (DSN) THE CONTRACT IS THE SPONSORING AGR
      Agency: National Aeronautics and Space Administration. Description: DEEP SPACE NETWORK (DSN) THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION (NASA) AND THE CALIFORNIA IN…
  - (2026-10-27) [USASpending] $540,310,876 → LEIDOS, INC.: IGF::OT::IGF SENS3 AWARD
      Agency: General Services Administration. Description: IGF::OT::IGF SENS3 AWARD
  - (2026-10-27) [USASpending] $539,458,571 → LOCKHEED MARTIN CORPORATION: THE LOW BOOM FLIGHT DEMONSTRATOR (LBFD) CONTRACT IS FOR THE
      Agency: National Aeronautics and Space Administration. Description: THE LOW BOOM FLIGHT DEMONSTRATOR (LBFD) CONTRACT IS FOR THE DESIGN, CONSTRUCTION, AND FLIGHT VALIDATION OF A RESEARCH AIRCRAFT THAT CREATES A SHAPED SON…
  - (2026-10-27) [UN Sanctions] page checksum 25ab49e1ab17
      Active UN Security Council sanctions committees page snapshot

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-27) [Marginal Revolution] Eleven outstanding film and television reviews by Tyler Cowen and Alex Tabarrok
      From the Archive–these posts are written by ChatGPT These selections emphasize the quality of the criticism: original interpretations, close attention to the work, and arguments worth considering even when you disagree.…
  - (2026-10-27) [Marginal Revolution] NYT debate on the rules for AI companies
      Emily Bazelon was the moderator, there were five of us in the symposium. Excerpt from me: Bores: Do you think the federal government pre-empting the states is consistent with democracy? Cowen: Absolutely. We have federal…
  - (2026-10-27) [Marginal Revolution] Is “Who’s on First?” funny?
      Well, no, it is not funny, it would be too easy to relieve the dramatic tension by having Abbott explain the actual situation to Costello. One is not wrong to call the whole thing stupid. Yet there is another reading of…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 19 total
  - (2026-10-26) CVE-2026-109618 · PHP Group PHP: PHP Memory Corruption Vulnerability
      vendor: PHP Group · product: PHP · CISA remediation by 2026-10-29
  - (2026-10-26) CVE-2026-109619 · PHP Group PHP: PHP Stale Internal Request-State Vulnerability
      vendor: PHP Group · product: PHP · CISA remediation by 2026-10-29

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=14, 14d-median=17; carrying terms: proposed, enforcement, certain, action, final, proposing, regulatory, protection, national, program, public, vessels
- state_bills: today=66, 7d-median=70, 14d-median=108; carrying terms: including, existing, specified, state, alaska, school, insurance, california, certain, providing, provides, relating
- state_news: today=474, 7d-median=678, 14d-median=678; carrying terms: michigan, opponent, congressional, newsom, grant, political, close, place, protect, rallies, connecticut, finance
- local_news: today=260, 7d-median=241, 14d-median=238; carrying terms: crash, atlanta, state, north, dispatch, murder, dream, apartments, early, charged, october, deadly
- foreign_news: today=957, 7d-median=999, 14d-median=1011; carrying terms: israeli, europe, eastern, remembrance, lending, armed, giving, auckland, welcome, infrastructure, ongoing, display
- chinese_internal: today=294, 7d-median=270, 14d-median=278; carrying terms: cbmibefvx, chinese, cbmib, title, https, market, cbmiakfvx, lxtfa, color, cbmia, google, china
- russian_internal: today=991, 7d-median=991, 14d-median=1019; carrying terms: journal, title, europe, novayagazeta, gazeta, raquo, street, client, httperror, forbidden, politico, russian
- ukrainian_internal: today=126, 7d-median=136, 14d-median=130; carrying terms: europe, infrastructure, httperror, political, since, defense, injured, president, kremlin, decision, partners, including
- ukraine_theater: today=282, 7d-median=392, 14d-median=393; carrying terms: israeli, cuxpcwngqnhsouzjq, cbmiwafbvv, nwhhdnfzun, ejzvsnpuqzfvy, vjbkl, curyvkvlsfhnujhsmm, armed, mdmwbml, envir, cjbsmhh, hcnulqzghccmrtwufou
- paper_bets: today=61, 7d-median=63, 14d-median=68; carrying terms: december, supervolcano, starts, headline, inflation, colonize, erupt, state, chair, problems, israel, experience
- weather: today=106, 7d-median=136, 14d-median=138; carrying terms: moving, eastern, twoat, county, norton, aviation, weather, waves, southeast, following, ridge, severe
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: implied, headline, inflation, dexuseu, cpilfesl, personal, payrolls, energy, openings, rates, funds, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: china, yield, natural, agriculture, range, equities, nasdaq, silver, crypto, commodities, crude, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=102, 7d-median=102, 14d-median=105; carrying terms: transition, haiti, eastern, armed, prohibited, misappropriation, nicaragua, guinea, aggression, islamic, political, threatening
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, httperror, error, quantitative, quiver, congresstrading, quiverquant, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed, filer, holdings, financial, trust, subject, holding, finance, investment
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, filing, talarico, ossoff, congress, disbursements, cortez, warner, sherrod, jonathan, krishnamoorthi, angels
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan, japanherald, china
- gdelt_gkg: today=50, 7d-median=25, 14d-median=25; carrying terms: english, israel, sanctions, themes, keywords, perimeter, russian, spanish, chinese, russia, attack, elections
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=27, 7d-median=27, 14d-median=28; carrying terms: belgium, position, ground, bulgaria, france, germany, kingdom, canada, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: december, india, genomic, increasingly, notified, reporting, uganda, africa, kayna, determined, yellow, national
- cisa_kev: today=19, 7d-median=17, 14d-median=15; carrying terms: product, control, vulnerability, vendor, server, traversal, improper, remediation, injection, cisco, command, secure
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: maximum, australia, earthquake, indonesia, speed, typhoon, islands, guinea, depth, hurricane, papua, forest
- usgs_quakes: today=17, 7d-median=21, 14d-median=20; carrying terms: depth, vanuatu, philippines, indonesia, islands, tonga, japan, hihifo, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: interest, rates, meeting, october, resolves, price, volume, election, league, donetsk, championship, champions
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, economist, https, conversable, revolution, marginal, marginalrevolution, world, government, economic, example, money
- tech_news: today=56, 7d-median=57, 14d-median=57; carrying terms: technica, infrastructure, computer, computerweekly, software, hacker, record, attacks, cybersecurity, investigation, researchers, report
- political_figures: today=0, 7d-median=613, 14d-median=613; carrying terms: james, suzanne, wicker, valerie, edward, gallego, sullivan, julie, shomari, susan, ramirez, bacon
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, unavailable, placement, today, converges, consensus, market, decision, paper, sufficient, markets, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-20] ECB press: Frank Elderson: Interview with Die Presse
- [2026-10-21] ECB press: Philip R. Lane: Euro liquidity lines and the international monetary system
- [2026-10-21] ECB press: Piero Cipollone: Pontes and Appia: unlocking opportunities for banks
- [2026-10-23] ECB press: ECB Consumer Expectations Survey results – September 2026
- [2026-10-24] ECB press: Piero Cipollone: Interview with Milano Finanza
- [2026-10-26] ECB press: Frank Elderson: Taking action for nature – investing in economic resilience and prosperity
- [2026-10-26] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened
- [2026-10-27] ECB press: October 2026 euro area bank lending survey

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*