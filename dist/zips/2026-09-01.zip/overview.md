# WORLDSCOPE morning brief — 2026-09-01

## Headline
3352 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (806) · Russian Internal News (state + in-exile) (624) · State-Level News (345) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (274) · Chinese Internal News (260) · Local News: St. Louis + Atlanta (201) · U.S. Weather + Severe / Climate Outlooks (144) · State Legislative Action (57) · Ukrainian Internal News (national + local Kyiv) (53) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 806 new of 1096 total
  - (2026-08-31) [Global] South African airline defends dramatic low-level flyby before rugby union clash
  - (2026-09-01) [Global] Canada’s ruling Liberals sweep special elections in boost to Mark Carney
  - (2026-09-01) [Global] Thai resort prepares to host USS Abraham Lincoln sailors after more than 270 days at sea
  - (2026-09-01) [Global] Shein shares slide on fast-fashion retailer’s stock market debut
  - (2026-09-01) [Global] Kākāpō rising: 90 chicks swell population of the world’s heaviest parrot
  - (2026-09-01) [Global] Sydney records warmest winter on record as Melbourne equals previous hottest temperatures

### Russian Internal News (state + in-exile) — 624 new of 982 total
  - (2026-09-01) Следующая выставка Института костюма в Метрополитен-музее должна была чествовать Джона Гальяно. Но все отменили — из-за его высказываний 2011 года. Модный мир обескуражен | LEDE: Музей Метро] (ru: Сле…
      Музей Метрополитен, который ежегодно проводит выставку Института костюма и бал Met Gala, решил не посвящать будущее мероприятие дизайнеру Джону Гальяно. Решение, как сообщает CNN, принято на фоне «растущего общественного…
  - (2026-09-01) В Москве прохожий застрелил прихожанина храма, который кидался камнями и ударил фельдшера лопатой | LEDE: Житель Москвы напал на прихожан храма святых Жен-Мироносиц в московском районе Марьи] (ru: В М…
      Житель Москвы напал на прихожан храма святых Жен-Мироносиц в московском районе Марьино, сообщили российские медиа.
  - (2026-09-01) В Черногории россиянина заподозрили в убийстве троих человек. При задержании он открыл огонь по полиции — и покончил с собой | LEDE: В Черногории 30-летнего россиянина Михаила Шабунина запод] (ru: В Ч…
      В Черногории 30-летнего россиянина Михаила Шабунина заподозрили в тройном убийстве. При попытке задержания он открыл стрельбу по окружившим его полицейским, а затем покончил с собой, сообщает национальная телерадиокомпан…
  - (2026-09-01) Украинский омбудсмен рассказал о коррупции в ТЦК. По его словам, за 50-70 тысяч долларов человека прямо из автобуса могут переправить за пределы страны | LEDE: Уполномоченный Верховной рады ] (ru: Укр…
      Уполномоченный Верховной рады Украины по правам человека Дмитрий Лубинец в интервью «Украинской правде» рассказал о новых случаях коррупции в ТЦК. По его словам, сотрудники центров начали предлагать новую услугу «под клю…
  - (2026-09-01) «Родители отреагировали вроде нормально». Во Владивостоке учеников школы обязали носить на форме шевроны с дронами | LEDE: Во Владивостоке в школе № 61 учеников обязали носить на школьной фо] (ru: «Ро…
      Во Владивостоке в школе № 61 учеников обязали носить на школьной форме шевроны с изображением беспилотников, сообщают «Осторожно, новости» и «7×7».
  - (2026-09-01) Что поменялось в России с 1 сентября. Особенно у тех, кто учится в школе, много играет в азартные игры и держит кур или верблюдов. Максимально коротко | LEDE: Старшеклассники начинают изучат] (ru: Что…
      Старшеклассники начинают изучать обществознание по учебнику под редакцией Медведева, пятиклассники — «Духовно-нравственную культуру России». В некоторых школах теперь можно будет взять арабский в качестве второго иностра…

### State-Level News — 345 new of 519 total
  - (2026-09-01) [California] Governor Newsom signs legislation 8.31.2026
      Source
  - (2026-09-01) [California] Governor Newsom announces appointments 8.31.2026
      Source
  - (2026-08-31) [California] Governor Newsom signs legislation cracking down on cannabis ads and labels that appeal to kids
      Source
  - (2026-08-31) [California] California’s crime rates are at record lows – even if Fox News won’t tell you
      Source
  - (2026-08-31) [Alabama] Family Meals Month
      Download
  - (2026-09-01) [California] As Gavin Newsom’s reign nears end, his ability to sway legislators has also waned
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/071326_Newsom-Housing_MO_CM_40.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 274 new of 735 total
  - (2026-08-31) [FIRMS] thermal anomaly 47.589, 34.664 (FRP 3.42 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 3.42 MW
  - (2026-08-31) [FIRMS] thermal anomaly 47.589, 34.651 (FRP 6.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 6.71 MW
  - (2026-08-31) [FIRMS] thermal anomaly 47.436, 29.867 (FRP 7.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 7.38 MW
  - (2026-08-31) [FIRMS] thermal anomaly 47.551, 30.602 (FRP 6.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 6.19 MW
  - (2026-08-31) [FIRMS] thermal anomaly 46.935, 23.393 (FRP 2.82 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 2.82 MW
  - (2026-08-31) [FIRMS] thermal anomaly 46.938, 23.392 (FRP 4.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 4.86 MW

### Chinese Internal News — 260 new of 291 total
  - (2026-08-31) Cover Story: How U.S. Tech Blockade Sparked China’s AI Chip Boom - Caixin Global
      Cover Story: How U.S. Tech Blockade Sparked China’s AI Chip Boom Caixin Global
  - (2026-08-31) Xi and Putin Pledge Deeper Coordination at SCO Summit in Bishkek - Caixin Global
      Xi and Putin Pledge Deeper Coordination at SCO Summit in Bishkek Caixin Global
  - (2026-08-30) 支付宝董事长韩歆毅：当Agent替人买单，如何做到“可信支付”？ - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9rQjJpVjNlcDRBdFV1MU9VUjNFb1cxV1M3akdYWEhVdzRsV2g0X1M3bXhablR1aHRjeUNnQ0ZGYW] (zh:…
      支付宝董事长韩歆毅：当Agent替人买单，如何做到“可信支付”？ Caixin Global
  - (2026-08-30) 美联储政策范式转换与中国货币金融的战略应对 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBqN1lpZnc0WTVPdER1bzdHbXNkVElqZDBURFpUQ2U5SlZreWx6SUtKU3FOd3RFNTh6UlBMa3BrbHFsdTdzU3JFT] (zh:…
      美联储政策范式转换与中国货币金融的战略应对 Caixin Global
  - (2026-08-30) 房地产信托新规再规范非标投资 设置展业准入门槛 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5RTC1ialA0NkFmUlJUT1JUQnpBR2NYSmEta3NxLWt6MXBsQXU0LU4wclNKYmFpYml6Xzl5dTlpdmRmQXVDeHY] (zh:…
      房地产信托新规再规范非标投资 设置展业准入门槛 Caixin Global
  - (2026-08-30) 中国交建成立铁道集团 铁路基建市场向“三巨头”演变 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9yMTBLQ0I2TENZMXZWLWFlcjZCcWRfQXAxUlpjYVA2VXNBSG1sZ0FLTkZ2TkZwNEFTV3JrQ3hKWHI0eDFla] (zh:…
      中国交建成立铁道集团 铁路基建市场向“三巨头”演变 Caixin Global

### Local News: St. Louis + Atlanta — 201 new of 220 total
  - (2026-09-01) [St. Louis] September gardening tips for St. Louisans
      In this latest edition of This Month in Your Garden, Ian Graves of Quiet Village Landscaping, shares his to-do list 1. Prepare for fall As one hot summer comes to a close, temperatures will (hopefully) start to cool down…
  - (2026-09-01) [St. Louis] Grace Meat + Three closing September 13 in the Grove
      Grace Meat + Three (4270 Manchester), the nine-year-old restaurant inspired by the Southern tradition of pairing a choice of meat with three side dishes, will close after service on September 13, owners Rick and Elisa Le…
  - (2026-09-01) [St. Louis] Restaurant manager sues after being fired over Facebook post about Charlie Kirk
      The former general manager of Lombardo’s Restaurant alleges he was wrongfully terminated from his job after expressing his opinions about the assassinaiton of Charlie Kirk last September. On the same day as the conservat…
  - (2026-09-01) [St. Louis] As a South City scrap recycler hums, neighbors fear the Patch is being scavenged for parts
      On any given day, if you should happen to find yourself near the intersection of Broadway and East Nagel in the Patch neighborhood, you’re likely to see a steady stream of down-on-their-luck types hauling scrap metal tow…
  - (2026-09-01) [St. Louis] Innovation Week looks to fill the gap of entrepreneurial focused events in St. Louis this fall
      Mike Seper wasn’t intending to organize a series of innovation-focused events this October, but the director of innovation and intellectual property at the University of Missouri-St. Louis jumped in when he saw an autumn…
  - (2026-09-01) [St. Louis] Where Art Thou 9/1/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…

### U.S. Weather + Severe / Climate Outlooks — 144 new of 145 total
  - (2026-09-01) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-01) [Moderate] Special Weather Statement: Special Weather Statement issued September 1 at 8:09AM EDT by NWS Binghamton NY
      At 808 AM EDT, Doppler radar was tracking a cluster of strong thunderstorms over Union Center, or near Endicott, moving east at 45 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds cou…
  - (2026-09-01) [Moderate] Tropical Cyclone Local Statement: Tropical Cyclone Local Statement issued September 1 at 7:01AM CDT by NWS Lake Charles LA
      HLSLCH This product covers Southwest Louisiana and Southeast Texas **Tropical Storm Edouard Expected To Strengthen Before Landfall This Afternoon** NEW INFORMATION --------------- * CHANGES TO WATCHES AND WARNINGS: - A T…
  - (2026-09-01) [Moderate] Heat Advisory: Heat Advisory issued September 1 at 7:00AM CDT until September 1 at 7:00PM CDT by NWS Jackson MS
      * WHAT...Heat index values up to 110 expected. * WHERE...Portions of southeast Arkansas, northeast Louisiana, and central, north central, northwest, south central, southwest, and west central Mississippi. * WHEN...From 1…
  - (2026-09-01) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 1 at 6:56AM CDT until September 1 at 9:00AM CDT by NWS Green Bay WI
      * WHAT...Visibility one quarter mile or less in dense fog through 8 am, then visibilities should improve gradually. * WHERE...Portions of central, north central, and northeast Wisconsin. * WHEN...Until 9 AM CDT this morn…
  - (2026-09-01) [Moderate] Gale Warning: Gale Warning issued September 1 at 3:54AM AKDT until September 2 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…

### State Legislative Action — 57 new of 62 total
  - (2026-08-31) [Alaska SB 158] An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
      An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
  - (2026-09-01) [California SB 942] Civil detainees.
      Existing law, the Lanterman-Petris-Short (LPS) Act, authorizes the involuntary commitment and treatment of a person, when the person, as a result of a mental health disorder, is a danger to themselves or others, or is gr…
  - (2026-09-01) [California SB 327] Public utilities: review of accounts: electrical and gas corporations: rates: political influence activities.
      Existing law authorizes the Public Utilities Commission to fix the rates and charges for public utilities, including electrical corporations and gas corporations, and requires those rates and charges to be just and reaso…
  - (2026-09-01) [California AB 1728] Community colleges: common course numbering system: career technical education public safety courses.
      Existing law requires the California Community Colleges, on or before July 1, 2027, to adopt a common course numbering system for all general education requirement courses and transfer pathway courses, and requires each…
  - (2026-09-01) [California AB 194] Transportation.
      Existing law, until September 1, 2031, requires the State Air Resources Board, with funds provided in the Budget Act of 2026, to establish a new zero-emission electric vehicle incentive program for first-time zero-emissi…
  - (2026-09-01) [California AB 2167] Property tax: documentary transfer tax: exemptions: nonprofit corporations chartered under tribal or federal law.
      (1) The California Constitution authorizes the Legislature to exempt from taxation, in whole or in part, property that is used exclusively for religious, hospital, or charitable purposes, and is owned or held in trust by…

### Ukrainian Internal News (national + local Kyiv) — 53 new of 111 total
  - (2026-09-01) У Румунії на кордоні з Молдовою знайшли дрон з вибухівкою | LEDE: Дрон із вибуховою частиною виявили у полі поблизу Війшоари. Периметр ізольовано, працюють піротехніки Румунської розвідувальної] (uk:…
      Дрон із вибуховою частиною виявили у полі поблизу Війшоари. Периметр ізольовано, працюють піротехніки Румунської розвідувальної служби.
  - (2026-09-01) У Херсоні російські дрони вбили комунальника та поранили двох дітей | LEDE: У Корабельному районі Херсона російський безпілотник атакував працівника комунального підприємства – чоловік помер у ] (uk:…
      У Корабельному районі Херсона російський безпілотник атакував працівника комунального підприємства – чоловік помер у лікарні від поранень.
  - (2026-09-01) У ЄС нагадали, що кредит 90 млрд євро покриє лише дві третини потреб України | LEDE: Європейський Союз виплачує позику Україні на 90 млрд євро для покриття бюджетних і оборонних потреб у 2026-2] (uk:…
      Європейський Союз виплачує позику Україні на 90 млрд євро для покриття бюджетних і оборонних потреб у 2026-2027 роках – головна речниця Єврокомісії.
  - (2026-09-01) Лубінець розповів про нову "послугу" вивезення військовозобов’язаних за 50-70 тисяч доларів | LEDE: Уповноважений ВР Дмитро Лубінець розповів про схеми переправлення за кордон за 50–70 тисяч до] (uk:…
      Уповноважений ВР Дмитро Лубінець розповів про схеми переправлення за кордон за 50–70 тисяч доларів і корупцію у ТЦК, особливо на Закарпатті.
  - (2026-09-01) "Уся країна живе в постійному стресі": Посол ЄС розповіла, що спить у ванній через атаки РФ на Київ | LEDE: Катаріна Матернова розповіла, як ховається від обстрілів у Києві, і наголосила на вис] (uk:…
      Катаріна Матернова розповіла, як ховається від обстрілів у Києві, і наголосила на виснаженні мешканців через постійні атаки.
  - (2026-09-01) Рютте та фон дер Ляєн зустрінуться 2 вересня в Брюсселі | LEDE: У середу, 2 вересня, президентка Єврокомісії Урсула фон дер Ляєн та генеральний секретар НАТО Марк Рютте проведуть зустріч у прим] (uk:…
      У середу, 2 вересня, президентка Єврокомісії Урсула фон дер Ляєн та генеральний секретар НАТО Марк Рютте проведуть зустріч у приміщенні Європейської комісії і зроблять заяву для преси.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-01) [Sakellaris George P] Form 4 (Reporting)
      filed 2026-09-01 12:09 UTC · role: Reporting — Filed: 2026-09-01 AccNo: 0001628280-26-059708 Size: 7 KB
  - (2026-09-01) [Ameresco, Inc.] Form 4 (Issuer)
      filed 2026-09-01 12:09 UTC · role: Issuer — Filed: 2026-09-01 AccNo: 0001628280-26-059708 Size: 7 KB
  - (2026-09-01) 424B4 - Advance JV Group Ltd (0002089447) (Filer)
      filed 2026-09-01 12:04 UTC — Filed: 2026-09-01 AccNo: 0001493152-26-040933 Size: 4 MB
  - (2026-09-01) [FTC Solar, Inc.] Form 4 (Issuer)
      filed 2026-09-01 12:00 UTC · role: Issuer — Filed: 2026-09-01 AccNo: 0001193125-26-377575 Size: 6 KB
  - (2026-09-01) [SADASIVAM SHAKER] Form 4 (Reporting)
      filed 2026-09-01 12:00 UTC · role: Reporting — Filed: 2026-09-01 AccNo: 0001193125-26-377575 Size: 6 KB
  - (2026-09-01) 425 - Iron Horse Acquisition II Corp. (0002051985) (Subject)
      filed 2026-09-01 11:55 UTC — Filed: 2026-09-01 AccNo: 0001213900-26-095972 Size: 57 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-01) [India] Telugu director Anand Sai son Sandeep arrested after fatal hit - and - run accident in Hyderabad
      domain: moneycontrol.com · language: English · tone:
  - (2026-09-01) [United States] Sweden Signs Deal to Buy 4 Frigates From France , Deepen Defense Cooperation
      domain: theepochtimes.com · language: English · tone:
  - (2026-09-01) [United States] Data Center Opposition Based More In Fear Of AI Revolution Than Logistics | News Radio 1200 WOAI
      domain: woai.iheart.com · language: English · tone:
  - (2026-09-01) [Thailand] Thailand Pursues UN Action Against Cambodia Over Landmines
      domain: chiangraitimes.com · language: English · tone:
  - (2026-09-01) [United States] General Hospital Mystery Recast Revealed – Primetime Actor Joins GH as Familiar Character
      domain: celebdirtylaundry.com · language: English · tone:
  - (2026-09-01) [Canada] Im a good listener but no one ever asks anything about me . What up ?
      domain: prrecordgazette.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 51 total
  - (2026-09-01) [BleepingComputer] Five Venezuelans plead guilty to ATM jackpotting attacks in US
      Five Venezuelan nationals pleaded guilty to attempting to empty automated teller machines (ATMs) using malware in a series of ATM jackpotting attacks. [...]
  - (2026-09-01) [BleepingComputer] Recently patched PaperCut zero-days used in data theft attacks
      Two security vulnerabilities in the PaperCut NG and MF print management software, patched last week after being exploited as zero-days, are now being abused in data theft attacks. [...]
  - (2026-09-01) [The Hacker News] Threat Actors Don’t Want Better Attacks. They Want Repeatable Ones
      The most common way into a company last year was to ask. A web page tells the visitor to prove they are not a robot. While they read the instructions, it quietly places a command on their clipboard. Then it talks them th…
  - (2026-09-01) [The Hacker News] Attackers Steal METR API Key and Consume AI Credits Worth About $600,000
      METR (short for Model Evaluation and Threat Research and pronounced "Meter"), a research non-profit that evaluates frontier artificial intelligence (AI) models for their ability to carry out long-horizon, agentic tasks,…
  - (2026-09-01) [The Hacker News] Russia-Aligned UAC-0099 Plants Nuclear Weapon Prompt in Malware to Disrupt AI Analysis
      Cybersecurity researchers have disclosed a new technique dubbed GuardBreaker that's been put to use by a Russia-aligned threat actor known as UAC-0099 against a target in Ukraine with an aim to interfere with artificial…
  - (2026-09-01) [The Hacker News] Attackers Exploit Critical Langflow and Rails Flaws in Credential-Probing and C2 Activity
      Threat actors are exploiting two critical flaws impacting Langflow and Ruby on Rails, according to new findings from VulnCheck. The vulnerabilities in question are listed below - CVE-2026-0768 (CVSS score: 9.8) - A lack…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-01) GAF400 (Germany)
      icao24: 3e8b41 · position: (52.4592, 9.4479) · alt: 91m · 219km/h
  - (2026-09-01) GAF131 (Germany)
      icao24: 3ea653 · position: (53.2808, -0.0931) · alt: 4061m · 545km/h
  - (2026-09-01) PAT532 (United States)
      icao24: adfec1 · position: (37.9506, -75.8708) · alt: 9090m · 668km/h
  - (2026-09-01) GAF218 (Germany)
      icao24: 3f6219 · position: (51.9956, 9.7901) · alt: 342m · 466km/h
  - (2026-09-01) CFC2987 (Canada)
      icao24: c2b5b7 · position: (58.3361, 12.1084) · alt: 8229m · 638km/h
  - (2026-09-01) CFC2546 (Canada)
      icao24: c2b58f · position: (44.1899, -77.2363) · alt: 2506m · 407km/h

### Paper Trading Scorecard — 24 new of 136 total
  - (2026-09-01) [Polymarket] Will Spirit Win the BLAST Open Porto 2026?
      This market will resolve according to the winner of BLAST Open Porto 2026, currently scheduled for August 26, 2026 to September 6, 2026. If this tournament is postponed after September 20, 2026, 11:59 PM ET, canceled, or…
  - (2026-09-01) [Polymarket] Will Crystal Palace win the 2026-27 English Premier League (EPL) Championship?
      This market will resolve according to the team that wins the 2026-27 English Premier League (EPL) Championship. If at any point it becomes impossible for a listed team to win the 2026-27 English Premier League (EPL) Cham…
  - (2026-09-01) [Manifold] Will 0x53a125F03c90B8E07BA50356B312F4b7b9bA47A7 REACH more than 291.1471 USDC on Base by September 7th 11:59 pm UTC
  - (2026-09-01) [Manifold] At the end of August 2028, will California be in a widespread drought?
  - (2026-09-01) [Manifold] Will California be in a drought at end of August 2027?
  - (2026-09-01) [Manifold] Will Adam Riess win a second Nobel prize?

### U.S. Federal Action — 19 new of 19 total
  - (2026-09-01) National Environmental Policy Act Regulations
      FHWA, FRA, and FTA (collectively referred to as the "Agencies") are finalizing the interim final rule (IFR) published on July 3, 2025, which revised the Agencies' National Environmental Policy Act (NEPA) of 1969 implemen…
  - (2026-09-01) Conformance of Cost Accounting Standards to Generally Accepted Accounting Principles for CAS 407 Use of Standard Costs for Direct Material and Direct Labor
      The Office of Management and Budget (OMB), Cost Accounting Standards Board (the Board), is publishing a final rule rescinding Cost Accounting Standard (CAS) 407 to conform it with Generally Accepted Accounting Principles…
  - (2026-09-01) Bicycle Use in Park Areas
      The National Park Service (NPS) proposes to modify the procedural requirements in existing NPS regulations for the designation of roads and trails for bicycle use within park areas. The changes would align NPS regulation…
  - (2026-09-01) Increase of Monetary Thresholds and Other Matters Related to Cost Accounting Standards Program Requirements
      The Office of Management and Budget (OMB), Cost Accounting Standards Board (Board), is publishing a final rule to increase the Cost Accounting Standards (CAS) thresholds and agency waiver authority, and issue clarificati…
  - (2026-09-01) National Wildlife Refuge System; 2026-2027 Station-Specific Hunting and Sport Fishing Regulations
      We, the U.S. Fish and Wildlife Service (FWS or Service), open or expand hunting opportunities on 111 field stations, including 107 units of the National Wildlife Refuges System (Refuge System or NWRS) and 4 units of the…
  - (2026-09-01) Fees for the Unified Carrier Registration Plan and Agreement
      FMCSA amends the regulations governing the annual Unified Carrier Registration (UCR) Plan and Agreement registration fees that participating States collect from motor carriers, motor private carriers of property, brokers…

### Court opinions of consequence (federal & state) — 17 new of 60 total
  - (2026-09-01) Connecticut Supreme Court: Bryan v. Commissioner of Correction
  - (2026-08-31) U.S. Court of Appeals, 8th Cir.: Jim Daws Trucking, LLC v. Daws, Inc.
  - (2026-08-31) U.S. Court of Appeals, 8th Cir.: Tosun Fitil v. Justyn Riley
  - (2026-08-31) U.S. Court of Appeals, 8th Cir.: Union Pacific Railroad Company v. STB
  - (2026-08-31) U.S. Court of Appeals, 8th Cir.: United States v. Cameron Smith
  - (2026-08-31) U.S. Supreme Court: National Park Service v. National Trust for Historic Preservation in the United States

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-09-01) Will Crystal Palace win the 2026-27 English Premier League (EPL) Championship?
      yes price: 0% · 24h volume: $679,552 · resolves 2027-05-30
  - (2026-09-01) Will Sunderland win the 2026-27 English Premier League (EPL) Championship?
      yes price: 0% · 24h volume: $295,269 · resolves 2027-05-30
  - (2026-09-01) Will Coventry City win the 2026-27 English Premier League (EPL) Championship?
      yes price: 0% · 24h volume: $273,043 · resolves 2027-05-30
  - (2026-09-01) Will Renan Santos win the 2026 Brazilian presidential election?
      yes price: 2% · 24h volume: $272,626 · resolves 2026-10-04
  - (2026-09-01) Will Nottingham Forest win the 2026-27 English Premier League (EPL) Championship?
      yes price: 0% · 24h volume: $271,268 · resolves 2027-05-30
  - (2026-09-01) Will Ipswich Town win the 2026-27 English Premier League (EPL) Championship?
      yes price: 0% · 24h volume: $270,343 · resolves 2027-05-30

### USGS earthquakes (M4.5+, past day) — 10 new of 10 total
  - (2026-09-01) M 5.6 - 82 km SE of Maba, Indonesia
      M5.6 · 82 km SE of Maba, Indonesia · depth 10 km
  - (2026-09-01) M 5.3 - 89 km SSW of Nikolski, Alaska
      M5.3 · 89 km SSW of Nikolski, Alaska · depth 26.001 km
  - (2026-09-01) M 4.9 - 117 km WNW of Pangai, Tonga
      M4.9 · 117 km WNW of Pangai, Tonga · depth 198.068 km
  - (2026-09-01) M 4.8 - 292 km WNW of Houma, Tonga
      M4.8 · 292 km WNW of Houma, Tonga · depth 533.035 km
  - (2026-08-31) M 4.8 - 176 km SE of Gizo, Solomon Islands
      M4.8 · 176 km SE of Gizo, Solomon Islands · depth 10 km
  - (2026-09-01) M 4.6 - 201 km SW of Fakfak, Indonesia
      M4.6 · 201 km SW of Fakfak, Indonesia · depth 35 km

### Government Action: Sanctions + Procurement + Foreign Agents — 3 new of 106 total
  - (2026-09-01) [USASpending] $1,018,396,052 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…
  - (2026-09-01) [USASpending] $942,267,915 → ACCENTURE FEDERAL SERVICES LLC: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOM
      Agency: Department of Education. Description: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE PLATFORMS AND SERVICES SOLUTION (ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE SOLUTION, AKA EWDCCPS, AKA DCC)…
  - (2026-09-01) [USASpending] $892,757,974 → MAXIMUS FEDERAL SERVICES, INC.: DEBT MANAGEMENT AND COLLECTIONS SYSTEM (DMCS) IGF::CT::IGF
      Agency: Department of Education. Description: DEBT MANAGEMENT AND COLLECTIONS SYSTEM (DMCS) IGF::CT::IGF

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-01) [Marginal Revolution] More optimistic results on AI and job markets
      Here is a good Jon Hartley thread. Here is the paper, with Jolevski, Melo, and Moore. From Jon’s thread: “Generative AI adoption is widespread, but substantial aggregate labor-market disruption is not yet visible. Worker…
  - (2026-09-01) [Marginal Revolution] The Hugging Face hack
      That is the topic of my latest Free Press column. Some people are taking this in very dramatic fashion: One commentator is worried about a “full-blown AI takeover within months,” and another wrote that he was “feeling a…
  - (2026-08-31) [Marginal Revolution] Yerevan bleg
      Any advice on this front is most welcome, thank you! The post Yerevan bleg appeared first on Marginal REVOLUTION.

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=27, 14d-median=24; carrying terms: safety, action, certain, proposed, public, specifically, national, regulatory, service, management, unless, temporary
- state_bills: today=62, 7d-median=80, 14d-median=92; carrying terms: local, financial, funds, safety, known, entities, including, court, control, certain, persons, makes
- state_news: today=519, 7d-median=648, 14d-median=597; carrying terms: voting, organizations, seeking, wednesday, makes, health, attendees, efforts, privacy, president, using, dakota
- local_news: today=220, 7d-median=249, 14d-median=238; carrying terms: local, charged, investigation, crash, shows, president, murder, louis, being, killed, found, injured
- foreign_news: today=1096, 7d-median=1041, 14d-median=1027; carrying terms: practical, global, globe, submitted, wednesday, chinadaily, health, attendees, patrolling, spain, regularly, systems
- chinese_internal: today=291, 7d-median=291, 14d-median=289; carrying terms: global, politics, articles, google, lxtfb, caixin, cbmix, cbmia, color, cbmibkfvx, cbmibefvx, cbmiaefvx
- russian_internal: today=982, 7d-median=1074, 14d-median=1030; carrying terms: title, street, gazeta, financial, times, httperror, wildberries, client, politico, truth, europe, novaya
- ukrainian_internal: today=111, 7d-median=122, 14d-median=119; carrying terms: local, confirmed, sources, systems, forces, hromadske, president, reportedly, kremlin, being, censor, continue
- ukraine_theater: today=735, 7d-median=236, 14d-median=834; carrying terms: members, boyev, gmzlaaddimm, appoints, ltvyrzfda, hymzjcu, nvmjseg, zqujn, buvnpc, cbminwfbvv, tofdjukjkewwzqvjnb, functions
- paper_bets: today=136, 7d-median=133, 14d-median=133; carrying terms: verve, chair, starts, issues, lifetime, andrew, kansas, mbappe, genocide, funds, speed, hampshire
- weather: today=145, 7d-median=133, 14d-median=143; carrying terms: upper, today, afdilx, reach, center, message, ozone, depth, indicated, oregon, peachtree, including
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: spread, growth, openings, energy, total, recession, sheet, treasury, payrolls, jolts, headline, dexchus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: silver, treasury, range, china, proxy, credit, futures, close, large, commodities, yield, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=106, 7d-median=108, 14d-median=105; carrying terms: somalia, space, political, btdyc, enable, respect, venezuela, transactions, sectoral, funds, research, proliferation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quiver, client, unauthorized, congresstrading, quantitative, https, httperror, quiverquant
- billionaires: today=0, 7d-median=0, 14d-median=30
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, supreme, delaware, appeals, smith, cisneros, america, connecticut, company, county, community
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, issuer, accno, holdings, group, trust, financial, filer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: pinkston, receipts, graham, committee, booker, ocasio, house, angels, shawn, raised, talarico, cooper
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: english, trump, keywords, russia, perimeter, ukrainian, jpost, russian, indiatimes, strikes, against, sanctions
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, ground, germany, canada, kuwait, adfec
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: declaration, alert, point, previous, mongbwalu, fever, global, yellow, following, influenza, symptoms, infected
- cisa_kev: today=21, 7d-median=20, 14d-median=13; carrying terms: double, exchange, vcenter, remediation, service, vulnerability, broadcom, sharepoint, macos, server, vmware, mlflow
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=10, 7d-median=13, 14d-median=14; carrying terms: depth, indonesia, islands, tonga, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: championship, donetsk, volume, champions, august, rates, decrease, price, shakhtar, interest, september, meeting
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, marginal, class, economist, https, conversable, demand, number, together, shows, future, might
- tech_news: today=51, 7d-median=56, 14d-median=55; carrying terms: today, cybersecurity, review, systems, incident, devices, company, using, schneier, breach, rogue, researchers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: balint, mitch, wyden, composite, scholten, joseph, samuel, harold, zeldin, marlin, kennedy, duffy
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, markets, today, evidence, consensus, module, identify, claude, paper, placement, sufficient, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*