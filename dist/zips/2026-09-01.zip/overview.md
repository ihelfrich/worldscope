# WORLDSCOPE morning brief — 2026-09-01

## Headline
3200 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (750) · Russian Internal News (state + in-exile) (578) · World leaders & government officials (324) · State-Level News (286) · Ukraine Theater (total-war monitoring) (262) · Chinese Internal News (256) · Local News: St. Louis + Atlanta (193) · U.S. Weather + Severe / Climate Outlooks (135) · State Legislative Action (82) · Ukrainian Internal News (national + local Kyiv) (44) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 750 new of 1078 total
  - (2026-08-31) [Global] South African airline defends dramatic low-level flyby before rugby union clash
  - (2026-09-01) [Global] Canada’s ruling Liberals sweep special elections in boost to Mark Carney
  - (2026-09-01) [Global] Thai resort prepares to host USS Abraham Lincoln sailors after more than 270 days at sea
  - (2026-09-01) [Global] Kākāpō rising: 90 chicks swell population of the world’s heaviest parrot
  - (2026-09-01) [Global] Sydney records warmest winter on record as Melbourne equals previous hottest temperatures
  - (2026-09-01) [Global] Albanese has everything to lose engaging in a fight with Hanson, but he may be drawn in anyway | Analysis

### Russian Internal News (state + in-exile) — 578 new of 948 total
  - (2026-09-01) В Ленинградской области массовые сообщения о минировании школ, детских садов и больниц. В Москве закрыли «по техническим причинам» два музея | LEDE: Губернатор Ленинградской области Александ] (ru: В Л…
      Губернатор Ленинградской области Александр Дрозденко сообщил об «информационной террористической атаке» на регион.
  - (2026-09-01) Онлайн-ретейлер Shein несколько лет пытался выйти на биржу. В первые минуты торгов цена акций упала на 4% | LEDE: Китайский онлайн-магазин Shein, специализирующийся на продаже недорогой одеж] (ru: Онл…
      Китайский онлайн-магазин Shein, специализирующийся на продаже недорогой одежды и аксессуаров, провел первичное размещение акций на бирже в Гонконге.
  - (2026-09-01) Казахстан введет обязательные платные электронные разрешения на въезд в страну для иностранцев с 1 ноября. Это коснется и россиян | LEDE: Казахстан начал поэтапно вводить платные электронные] (ru: Каз…
      Казахстан начал поэтапно вводить платные электронные разрешения на въезд для иностранцев, которым не требуется виза. Такие разрешения потребуются в том числе россиянам. Подробности о новых правилах въезда в страну опубли…
  - (2026-09-01) Присяжные признали бывшего лидера уличной банды виновным по делу об убийстве Тупака Шакура | LEDE: Присяжные в суде Лас-Вегаса признали 63-летнего Дуэйна Дэвиса, известного в криминальных кр] (ru: При…
      Присяжные в суде Лас-Вегаса признали 63-летнего Дуэйна Дэвиса, известного в криминальных кругах как Киф Ди, виновным по делу об убийстве рэпера Тупака Шакура в 1996 году. Об этом сообщает BBC News.
  - (2026-09-01) Латвия запретила ввоз книг, одежды и игрушек, произведенных в России и Беларуси | LEDE: В Латвии 1 сентября вступил в силу запрет на импорт ряда товаров, произведенных в России и Беларуси. З] (ru: Лат…
      В Латвии 1 сентября вступил в силу запрет на импорт ряда товаров, произведенных в России и Беларуси. Запрет распространяется не только на прямой импорт, но и на поставку товаров из третьих стран.
  - (2026-09-01) «Агентство»: директор ЦРУ приезжал в Москву с призывом начать мирные переговоры. Путин собирался встретиться с ним, но передумал | LEDE: Владимир Путин изначально собирался встретиться с дир] (ru: «Аг…
      Владимир Путин изначально собирался встретиться с директором ЦРУ Джоном Рэтклиффом во время его визита в Москву 25 августа, но передумал, узнав цель поездки, рассказал «Агентству» источник, близкий к Кремлю.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 286 new of 472 total
  - (2026-08-31) [Alabama] Family Meals Month
      Download
  - (2026-09-01) [California] Governor Newsom signs legislation 8.31.2026
      Source
  - (2026-09-01) [California] Governor Newsom announces appointments 8.31.2026
      Source
  - (2026-08-31) [California] Governor Newsom signs legislation cracking down on cannabis ads and labels that appeal to kids
      Source
  - (2026-08-31) [California] California’s crime rates are at record lows – even if Fox News won’t tell you
      Source
  - (2026-08-31) [California] Data from 911 calls at ICE detention centers must be released under bill going to Gov. Newsom
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082317-Otay-Mesa-Detention-Center-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp…

### Ukraine Theater (total-war monitoring) — 262 new of 725 total
  - (2026-09-01) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-31) [FIRMS] thermal anomaly 47.589, 34.664 (FRP 3.42 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 3.42 MW
  - (2026-08-31) [FIRMS] thermal anomaly 47.589, 34.651 (FRP 6.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 6.71 MW
  - (2026-08-31) [FIRMS] thermal anomaly 47.436, 29.867 (FRP 7.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 7.38 MW
  - (2026-08-31) [FIRMS] thermal anomaly 47.551, 30.602 (FRP 6.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 6.19 MW
  - (2026-08-31) [FIRMS] thermal anomaly 46.935, 23.393 (FRP 2.82 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-31 1142Z, FRP 2.82 MW

### Chinese Internal News — 256 new of 289 total
  - (2026-08-31) Cover Story: How U.S. Tech Blockade Sparked China’s AI Chip Boom - caixinglobal.com
      Cover Story: How U.S. Tech Blockade Sparked China’s AI Chip Boom caixinglobal.com
  - (2026-08-31) 责编：王 平 金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxQUWhCM2diUENaRldUQXV0ellELUVLTVpVaU5ld29KYlVaaWFtcHdDcl9Nb29uWGt4MkFQSS1FZnZLSDhLd2dYZ] (zh:…
      责编：王 平 金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-09-01) 习近平出席上海合作组织成员国元首理事会第二十六次会议并发表重要讲话 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1xMGh3b05WUjdrNGVSbWs0eDBnNDVkTm5pZUZTS3ptTUc4YXlmV2tNZWRteUhpMEY4X0dkUmZya0tMZk] (zh:…
      习近平出席上海合作组织成员国元首理事会第二十六次会议并发表重要讲话 人民网-图片频道
  - (2026-08-31) 浙江义乌： 晾晒南枣 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9wRS1VaHVRdzdCQlM2OHZRT1BJeWRFWG10bU56bjN5SlFuS3JmVnRyVzRUamNrckJDSnpEMEdUdUpkR2xuWS1JMThoUnJqTTFFN1RmMy1PR] (zh:…
      浙江义乌： 晾晒南枣 人民图片
  - (2026-08-31) 上海： 小米澎程联动宜家 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE8zYVVoZ0dvT3M1SFNudUdOdTZSOUxNRUQ0cjFXOU9MSHBtQkJhcDNkdlBuNGotNTBjcWxXMEh2djBLWHo5MmFDMFQxM3I2UUpxZHN5TDM] (zh:…
      上海： 小米澎程联动宜家 人民图片
  - (2026-09-01) 安徽庐江：护航开学季 平安“警” 相伴 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5RTkY0VFVCV1lZSFpwS3Q5MzNuZ0lIQTB3NjJjaGNRTkVvSi1pQ2hELV9SVWlRQjdxX1ZCcEFjeV9fSXNMeUdKNy03UGFPZ0JP] (zh:…
      安徽庐江：护航开学季 平安“警” 相伴 人民图片

### Local News: St. Louis + Atlanta — 193 new of 214 total
  - (2026-09-01) [St. Louis] Where Art Thou 9/1/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-31) [St. Louis] Ms. Karly Dances makes movement accessible for kids of all ages and abilities
      At Ms. Karly Dances, success might mean learning to gallop, balance on one foot, or bounce in a caregiver’s arms. As owner Karly Pierce Lystad tells her students, it all counts. Pierce Lystad teaches movement classes tha…
  - (2026-08-31) [St. Louis] Lou’s Clues – 9/01/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-08-31) [St. Louis] SWADE’s Best Buds cannabis dinner series returns September 14
      Tim Wiggins was surprised by the scene at his first Best Buds dinner collaboration with SWADE Cannabis. It was 2024, recreational cannabis had just been legalized in Missouri about a year prior, and he knew there was a g…
  - (2026-08-31) [St. Louis] Film screenings to catch this month
      With summer winding down and fall soon upon us, there are still plenty of opportunities to see excellent curated repertory screenings around St. Louis. The Hi-Pointe Theatre is ringing in the end of summer with their “We…
  - (2026-08-31) [St. Louis] 10 art exhibits to catch this month
      Whether you’re interested in taking a journey to the past or exploring contemporary voices, there is plenty to take in this month at the city’s many museums and galleries. Here are a few must-see shows to catch this mont…

### U.S. Weather + Severe / Climate Outlooks — 135 new of 137 total
  - (2026-09-01) [Moderate] Tropical Cyclone Local Statement: Tropical Cyclone Local Statement issued September 1 at 4:34AM CDT by NWS Houston/Galveston TX
      HLSHGX This product covers Southeast Texas EDOUARD BECOMING BETTER ORGANIZED AS IT APPROACHES THE COAST NEAR THE TEXAS AND LOUISIANA BORDER. NEW INFORMATION --------------- * CHANGES TO WATCHES AND WARNINGS: - A Tropical…
  - (2026-09-01) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-01) [Severe] Tropical Storm Warning: Tropical Storm Warning issued September 1 at 4:20AM CDT by NWS Lake Charles LA
      * WHAT...Southeast winds 30 to 35 kt with gusts up to 50 kt near the center and seas 4 to 8 ft. * WHERE...Portions of and the coastal lakes and bays of the Gulf of America. * WHEN... This evening into tomorrow. * IMPACTS…
  - (2026-09-01) [Severe] Flood Watch: Flood Watch issued September 1 at 4:14AM CDT until September 2 at 7:00AM CDT by NWS Houston/Galveston TX
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of southeast Texas, including the following areas, Bolivar Peninsula, Brazoria Islands, Chambers, Coastal Brazoria, Coastal Gal…
  - (2026-09-01) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 1 at 4:11AM CDT until September 1 at 9:00AM CDT by NWS Twin Cities/Chanhassen MN
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Barron and Rusk Counties. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-09-01) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 1 at 4:10AM CDT until September 1 at 9:00AM CDT by NWS Duluth MN
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Price, Ashland, Bayfield, Douglas, Iron, Sawyer, and Washburn Counties. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility could make dri…

### State Legislative Action — 82 new of 89 total
  - (2026-08-31) [Alaska SB 158] An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
      An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
  - (2026-08-31) [California AB 114] Budget Acts of 2022, 2023, 2024, and 2025.
      The Budget Acts of 2022, 2023, 2024, and 2025 made appropriations for the support of state government for the 2022–23, 2023–24, 2024–25, and 2025–26 fiscal years, respectively. This bill would amend those budget acts by…
  - (2026-08-31) [California SB 1369] Recall petitions.
      (1) Existing law requires a state or local initiative, referendum, or recall petition that is required to be signed by voters to contain specified notices, including a notice that the petition may be circulated by a paid…
  - (2026-08-31) [California AB 2163] Energy: Strategic Clean Energy and Critical Mineral Development Zones.
      Existing law, the Warren-Alquist State Energy Resources Conservation and Development Act, establishes the State Energy Resources Conservation and Development Commission and prescribes the authorities, duties, and respons…
  - (2026-08-31) [California AB 1609] Customer service chatbots.
      Existing law prohibits a person from using a bot, as defined, to mislead another person about the bot's artificial identity to incentivize the purchase or sale of goods or services, among other things. Existing law requi…
  - (2026-08-31) [California AB 2469] Data centers: water use disclosures.
      The Planning and Zoning Law authorizes the legislative body of any county or city to adopt ordinances that, among other things, regulate the use of buildings, structures, and land as between industry, businesses, residen…

### Ukrainian Internal News (national + local Kyiv) — 44 new of 105 total
  - (2026-09-01) Під час тривоги засідання Ради планують продовжувати в укритті. Як це виглядатиме | LEDE: Під час повітряних тривог депутати працюватимуть у підземній залі Ради на Грушевського, 5. Голосування ] (uk:…
      Під час повітряних тривог депутати працюватимуть у підземній залі Ради на Грушевського, 5. Голосування – через QR-коди на персональних картках у закритій мережі.
  - (2026-09-01) ЗМІ: Берлін вже готовий заявити про причетність РФ до появи дрона з вибухівкою у Лейпцигу | LEDE: Німецькі слідчі нібито вже мають достатню впевненість у тому, що до появи дрона з вибухівкою в ] (uk:…
      Німецькі слідчі нібито вже мають достатню впевненість у тому, що до появи дрона з вибухівкою в аеропорту Лейпцига причетні російські спецслужби; про це невдовзі планують заявити публічно.
  - (2026-09-01) Українські дрони порушили повітряний простір Естонії – естонський міністр | LEDE: Ханно Певкур повідомив про ймовірний проліт українських дронів над Естонією 1 вересня. Жертв та пошкоджень не з] (uk:…
      Ханно Певкур повідомив про ймовірний проліт українських дронів над Естонією 1 вересня. Жертв та пошкоджень не зафіксовано, за ситуацією слідкували літаки НАТО.
  - (2026-09-01) Естонія відправила нову команду для допомоги з охороною кордону Латвії | LEDE: На латвійсько-білоруському кордоні розпочала роботу нова ротація ESTPOL11, яка замінила естонську команду, що прот] (uk:…
      На латвійсько-білоруському кордоні розпочала роботу нова ротація ESTPOL11, яка замінила естонську команду, що протягом останніх двох тижнів допомагала забезпечувати безпеку кордону в Латвії.
  - (2026-09-01) Більшість країн ЄС віддадуть Україні кошти з Європейського фонду миру, якщо його розблокують – Каллас | LEDE: Кая Каллас повідомила: у разі розблокування Європейського фонду миру більшість краї] (uk:…
      Кая Каллас повідомила: у разі розблокування Європейського фонду миру більшість країн ЄС готові спрямувати кошти на протиповітряну оборону України.
  - (2026-09-01) Повені в Непалі й Тибеті забрали життя понад тисячі людей, тисячі зникли безвісти | LEDE: Руйнівні повені в Непалі та Тибеті забрали понад 1000 життів, 600 людей заблоковані на гідроелектростан] (uk:…
      Руйнівні повені в Непалі та Тибеті забрали понад 1000 життів, 600 людей заблоковані на гідроелектростанціях, сотні українців зниклі безвісти.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-01) [KENNEY CHRISTOPHER JOHN] Form 4 (Reporting)
      filed 2026-09-01 01:59 UTC · role: Reporting — Filed: 2026-08-31 AccNo: 0001193125-26-377309 Size: 7 KB
  - (2026-09-01) [Xenon Pharmaceuticals Inc.] Form 4 (Issuer)
      filed 2026-09-01 01:59 UTC · role: Issuer — Filed: 2026-08-31 AccNo: 0001193125-26-377309 Size: 7 KB
  - (2026-09-01) [Drucker Mann Lindsay] Form 4 (Reporting)
      filed 2026-09-01 01:50 UTC · role: Reporting — Filed: 2026-08-31 AccNo: 0001104659-26-104012 Size: 21 KB
  - (2026-09-01) [Oddity Tech Ltd] Form 4 (Issuer)
      filed 2026-09-01 01:50 UTC · role: Issuer — Filed: 2026-08-31 AccNo: 0001104659-26-104012 Size: 21 KB
  - (2026-09-01) [Edwards Simon Stephen] Form 4 (Reporting)
      filed 2026-09-01 01:43 UTC · role: Reporting — Filed: 2026-08-31 AccNo: 0001193125-26-377301 Size: 4 KB
  - (2026-09-01) [Bloom Energy Corp] Form 4 (Issuer)
      filed 2026-09-01 01:43 UTC · role: Issuer — Filed: 2026-08-31 AccNo: 0001193125-26-377301 Size: 4 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-01) [Canada] R . R . Moore lauded on his birthday in 1916 : IN OTHER YEARS
      domain: northernnews.ca · language: English · tone:
  - (2026-09-01) [United States] This Day in Hip - Hop and R & B History : September 1
      domain: power98fm.com · language: English · tone:
  - (2026-09-01) [China] China service exports expand globally - People Daily Online
      domain: en.people.cn · language: English · tone:
  - (2026-09-01) [India] H1N1 or regular flu ? Doctor explains main differences and 7 warning signs that need medical attention
      domain: hindustantimes.com · language: English · tone:
  - (2026-09-01) [United Kingdom] Russian barrage of drones and missiles on Ukraine capital kills at least 11
      domain: readingchronicle.co.uk · language: English · tone:
  - (2026-09-01) [India] Disaster expert links Nepal floods to climate change , says these events increasing every year
      domain: news.webindia123.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 36 new of 56 total
  - (2026-09-01) [BleepingComputer] Five Venezuelans plead guilty to ATM jackpotting attacks in US
      Five Venezuelan nationals pleaded guilty to attempting to empty automated teller machines (ATMs) using malware in a series of ATM jackpotting attacks. [...]
  - (2026-09-01) [BleepingComputer] Recently patched PaperCut zero-days used in data theft attacks
      Two security vulnerabilities in the PaperCut NG and MF print management software, patched last week after being exploited as zero-days, are now being abused in data theft attacks. [...]
  - (2026-09-01) [The Hacker News] Russia-Aligned UAC-0099 Plants Nuclear Weapon Prompt in Malware to Disrupt AI Analysis
      Cybersecurity researchers have disclosed a new technique dubbed GuardBreaker that's been put to use by a Russia-aligned threat actor known as UAC-0099 against a target in Ukraine with an aim to interfere with artificial…
  - (2026-09-01) [The Hacker News] Attackers Exploit Critical Langflow and Rails Flaws in Credential-Probing and C2 Activity
      Threat actors are exploiting two critical flaws impacting Langflow and Ruby on Rails, according to new findings from VulnCheck. The vulnerabilities in question are listed below - CVE-2026-0768 (CVSS score: 9.8) - A lack…
  - (2026-09-01) [The Register] Next bus to Altrincham delayed by Windows Defender
      Or possibly "AI", it's hard to tell behind the firewall warning
  - (2026-09-01) [The Register] The teen Bill Gates has answers to the AI-pocalypse the 70-year-old Gates has forgotten
      Hacking education to thrive in the AI world is the first and best step in keeping control

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-09-01) #1 Elon Musk — $891.91B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-09-01) #2 Larry Page — $277.24B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-01) #3 Jeff Bezos — $267.65B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-09-01) #4 Sergey Brin — $255.77B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-01) #5 Michael Dell — $240.64B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-09-01) #6 Mark Zuckerberg — $196.59B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-01) PUMAD (France)
      icao24: 39de61 · position: (43.6507, 5.5469) · alt: 967m · 272km/h
  - (2026-09-01) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (47.4224, 1.8651) · alt: 9006m · 836km/h
  - (2026-09-01) JAF5GA (Bulgaria)
      icao24: 4520aa · position: (46.0972, 0.986) · alt: 11879m · 762km/h
  - (2026-09-01) GAF131 (Germany)
      icao24: 3ea653 · position: (51.0939, 4.9888) · alt: 9745m · 695km/h
  - (2026-09-01) GAF680 (Germany)
      icao24: 3eb82d · position: (51.7642, 13.259) · alt: 320m · 165km/h
  - (2026-09-01) PUMA45 (Slovenia)
      icao24: 506e1c · position: (45.8423, 15.4254) · alt: 1158m · 179km/h

### Paper Trading Scorecard — 23 new of 136 total
  - (2026-09-01) [Polymarket] Will Mirra Andreeva win the 2026 Women’s US Open?
      The 2026 U.S. Open tennis tournament is scheduled for August 23 - September 13, 2026. This market will resolve to the player that wins the 2026 U.S. Open Women’s Singles Tournament. If at any point it becomes impossible…
  - (2026-09-01) [Polymarket] Will Elon Musk post 220-239 tweets from August 25 to September 1, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from August 25 12:00 PM ET to September 1, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts…
  - (2026-09-01) [Manifold] Will 0x53a125F03c90B8E07BA50356B312F4b7b9bA47A7 REACH more than 291.1471 USDC on Base by September 7th 11:59 UTC
  - (2026-09-01) [Manifold] At the end of August 2028, will California be in a widespread drought?
  - (2026-09-01) [Manifold] Will California be in a drought at end of August 2027?
  - (2026-09-01) [Manifold] Will there be a Fire/Fairy Pokemon released by the end of 2029?

### U.S. Federal Action — 19 new of 19 total
  - (2026-09-01) National Environmental Policy Act Regulations
      FHWA, FRA, and FTA (collectively referred to as the "Agencies") are finalizing the interim final rule (IFR) published on July 3, 2025, which revised the Agencies' National Environmental Policy Act (NEPA) of 1969 implemen…
  - (2026-09-01) Conformance of Cost Accounting Standards to Generally Accepted Accounting Principles for CAS 407 Use of Standard Costs for Direct Material and Direct Labor
      The Office of Management and Budget (OMB), Cost Accounting Standards Board (the Board), is publishing a final rule rescinding Cost Accounting Standard (CAS) 407 to conform it with Generally Accepted Accounting Principles…
  - (2026-09-01) Bicycle Use in Park Areas
      The National Park Service (NPS) proposes to modify the procedural requirements in existing NPS regulations for the designation of roads and trails for bicycle use within park areas. The changes would align NPS regulation…
  - (2026-09-01) Increase of Monetary Thresholds and Other Matters Related to Cost Accounting Standards Program Requirements
      The Office of Management and Budget (OMB), Cost Accounting Standards Board (Board), is publishing a final rule to increase the Cost Accounting Standards (CAS) thresholds and agency waiver authority, and issue clarificati…
  - (2026-09-01) National Wildlife Refuge System; 2026-2027 Station-Specific Hunting and Sport Fishing Regulations
      We, the U.S. Fish and Wildlife Service (FWS or Service), open or expand hunting opportunities on 111 field stations, including 107 units of the National Wildlife Refuges System (Refuge System or NWRS) and 4 units of the…
  - (2026-09-01) Fees for the Unified Carrier Registration Plan and Agreement
      FMCSA amends the regulations governing the annual Unified Carrier Registration (UCR) Plan and Agreement registration fees that participating States collect from motor carriers, motor private carriers of property, brokers…

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-08-31) U.S. Court of Appeals, 8th Cir.: Jim Daws Trucking, LLC v. Daws, Inc.
  - (2026-08-31) U.S. Court of Appeals, 8th Cir.: Tosun Fitil v. Justyn Riley
  - (2026-08-31) U.S. Court of Appeals, 8th Cir.: Union Pacific Railroad Company v. STB
  - (2026-08-31) U.S. Court of Appeals, 8th Cir.: United States v. Cameron Smith
  - (2026-08-31) U.S. Court of Appeals, 10th Cir.: Pomeroy v. Utah State Bar
  - (2026-08-31) U.S. Court of Appeals, 10th Cir.: In re: Church of Jesus Christ of Latter-Day Saints

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-09-01) LoL: Gen.G vs KT Rolster - Game 1 Winner
      yes price: 100% · 24h volume: $2,067,228 · resolves 2026-09-01
  - (2026-09-01) LoL: Gen.G vs KT Rolster - Game 2 Winner
      yes price: 78% · 24h volume: $926,342 · resolves 2026-09-01
  - (2026-09-01) LoL: Gen.G vs KT Rolster (BO5) - LCK Playoffs
      yes price: 92% · 24h volume: $811,256 · resolves 2026-09-01
  - (2026-09-01) Will Crystal Palace win the 2026-27 English Premier League (EPL) Championship?
      yes price: 0% · 24h volume: $676,722 · resolves 2027-05-30
  - (2026-09-01) Will Sunderland win the 2026-27 English Premier League (EPL) Championship?
      yes price: 0% · 24h volume: $292,469 · resolves 2027-05-30
  - (2026-09-01) Zhangjiagang: Ilya Ivashka vs Yi Zhou
      yes price: 100% · 24h volume: $271,712 · resolves 2026-09-07

### USGS earthquakes (M4.5+, past day) — 9 new of 10 total
  - (2026-09-01) M 5.6 - 82 km SE of Maba, Indonesia
      M5.6 · 82 km SE of Maba, Indonesia · depth 10 km
  - (2026-09-01) M 5.3 - 89 km SSW of Nikolski, Alaska
      M5.3 · 89 km SSW of Nikolski, Alaska · depth 26.001 km
  - (2026-09-01) M 4.8 - 292 km WNW of Houma, Tonga
      M4.8 · 292 km WNW of Houma, Tonga · depth 533.035 km
  - (2026-08-31) M 4.8 - 176 km SE of Gizo, Solomon Islands
      M4.8 · 176 km SE of Gizo, Solomon Islands · depth 10 km
  - (2026-09-01) M 4.6 - 201 km SW of Fakfak, Indonesia
      M4.6 · 201 km SW of Fakfak, Indonesia · depth 35 km
  - (2026-08-31) M 4.6 - 112 km SSW of Chirilagua, El Salvador
      M4.6 · 112 km SSW of Chirilagua, El Salvador · depth 35 km

### Government Action: Sanctions + Procurement + Foreign Agents — 3 new of 106 total
  - (2026-09-01) [USASpending] $1,018,396,052 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…
  - (2026-09-01) [USASpending] $942,267,915 → ACCENTURE FEDERAL SERVICES LLC: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOM
      Agency: Department of Education. Description: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE PLATFORMS AND SERVICES SOLUTION (ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE SOLUTION, AKA EWDCCPS, AKA DCC)…
  - (2026-09-01) [USASpending] $892,757,974 → MAXIMUS FEDERAL SERVICES, INC.: DEBT MANAGEMENT AND COLLECTIONS SYSTEM (DMCS) IGF::CT::IGF
      Agency: Department of Education. Description: DEBT MANAGEMENT AND COLLECTIONS SYSTEM (DMCS) IGF::CT::IGF

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-01) [Marginal Revolution] More optimistic results on AI and job markets
      Here is a good Jon Hartley thread. Here is the paper, with Jolevski, Melo, and Moore. From Jon’s thread: “Generative AI adoption is widespread, but substantial aggregate labor-market disruption is not yet visible. Worker…
  - (2026-09-01) [Marginal Revolution] The Hugging Face hack
      That is the topic of my latest Free Press column. Some people are taking this in very dramatic fashion: One commentator is worried about a “full-blown AI takeover within months,” and another wrote that he was “feeling a…
  - (2026-08-31) [Marginal Revolution] Yerevan bleg
      Any advice on this front is most welcome, thank you! The post Yerevan bleg appeared first on Marginal REVOLUTION.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=27, 14d-median=23; carrying terms: certain, proposed, public, management, action, national, service, regulatory, safety, amends, specifically, temporary
- state_bills: today=89, 7d-median=89, 14d-median=105; carrying terms: entities, permits, report, relating, effective, provisions, certain, governing, board, others, development, within
- state_news: today=472, 7d-median=648, 14d-median=614; carrying terms: advocates, plans, spent, return, issues, lawsuit, async, voters, large, toward, likely, prison
- local_news: today=214, 7d-median=249, 14d-median=240; carrying terms: async, atlanta, atlantamagazine, people, shooting, woman, trump, image, another, color, killed, dining
- foreign_news: today=1078, 7d-median=1041, 14d-median=1025; carrying terms: plans, thailand, homes, metric, issues, market, async, russian, pledged, course, large, tourist
- chinese_internal: today=289, 7d-median=289, 14d-median=289; carrying terms: global, people, color, cbmiakfvx, cbmia, cbmix, cbmidefvx, cbmibefvx, https, cbmiaefvx, china, articles
- russian_internal: today=948, 7d-median=1074, 14d-median=1048; carrying terms: istories, title, russian, media, financial, client, httperror, novaya, gazeta, novayagazeta, wildberries, social
- ukrainian_internal: today=105, 7d-median=122, 14d-median=117; carrying terms: mykhailo, plans, missiles, crimea, russian, independence, kremlin, aerial, moscow, warned, vladimir, confirmed
- ukraine_theater: today=725, 7d-median=236, 14d-median=813; carrying terms: ruvhtwdos, zrwhwnfm, batches, ywnmna, tjrhmtrfv, nevepptkn, cudwdf, vwnwjouzzwlxn, jtdfjkbejyshqznlz, ptugfudtbdbdfictjytgdtsgldwvhtyufpcdvwbhozltlhn, bcwvnqc, qmpobldvz
- paper_bets: today=136, 7d-median=133, 14d-median=132; carrying terms: zohran, succeed, schumer, former, kylian, justice, mexico, rippling, russell, pennsylvania, current, successor
- weather: today=137, 7d-median=133, 14d-median=140; carrying terms: humid, tonight, oxnard, front, winds, advisory, updated, short, current, rainfall, humidity, galveston
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unrate, cpiaucsl, personal, vixcls, dexjpus, cpilfesl, consumption, dcoilwtico, commodities, headline, recession, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, large, equities, close, proxy, corporate, china, commodities, bitcoin, agriculture, treasury, range
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=106, 7d-median=108, 14d-median=104; carrying terms: amended, respect, designations, cbmixkfvx, measures, entities, crimea, blank, operation, drilling, beirut, prohibiting
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, congresstrading, client, unauthorized, error, quiverquant, quiver, httperror, https
- billionaires: today=30, 7d-median=0, 14d-median=30; carrying terms: gates, discount, bettencourt, technology, oracle, china, michael, mexico, meyers, technologies, facebook, spacex
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, appeals, delaware, company, county, connecticut, america, smith, cisneros, office
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, holdings, financial, david, robert, kaspi, vyacheslav, stock, joint
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cortez, krishnamoorthi, alexandria, robert, michael, james, committee, ossoff, elect, talarico, cooper, receipts
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, keywords, russian, ukrainian, trump, russia, sanctions, perimeter, indiatimes, themes, drone, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, germany, ground, canada, bulgaria, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: natural, german, above, municipalities, hondius, batches, raise, sequencing, representing, poliovirus, developed, ongoing
- cisa_kev: today=21, 7d-median=20, 14d-median=13; carrying terms: apple, function, vulnerability, vendor, microsoft, authentication, product, sharepoint, exchange, macos, improper, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=10, 7d-median=13, 14d-median=14; carrying terms: depth, indonesia, islands, tonga, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, interest, championship, donetsk, champions, shakhtar, volume, league, august, meeting, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, revolution, class, https, marginal, economist, number, demand, together, shows, future, rates
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: weekly, computerweekly, computer, agents, people, hacker, https, attackers, openai, companies, technology, artificial
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: fitzgerald, speech, cortez, bessent, titus, scalise, hollen, lawler, urban, castro, lauren, veterans
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, consensus, claude, market, today, sufficient, placed, evidence, markets, module, unavailable, converges

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*