# WORLDSCOPE morning brief — 2026-05-30

## Headline
1972 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 30 new of 30 total
  - (2026-06-01) List of Approved Spent Fuel Storage Casks: Holtec International HI-STORM UMAX Canister Storage System, Certificate of Compliance No. 1040, Amendment No. 5
      The U.S. Nuclear Regulatory Commission (NRC) is confirming the effective date of June 16, 2026, for the direct final rule that was published in the Federal Register on April 2, 2026. This direct final rule amended Holtec
  - (2026-06-01) Assistance for Specialty Crop Farmers (ASCF) Program
      The Commodity Credit Corporation (CCC) is issuing this rule to provide assistance to producers of eligible specialty crops through the Assistance for Specialty Crop Farmers (ASCF) Program. These one-time bridge payments 
  - (2026-06-01) Holding Foreign Insiders Accountable Act Disclosure; Correction
      This document makes technical corrections to certain amendments to the Commission's disclosure rules and forms adopted in Release No. 34-104903 (February 27, 2026), which was published in the Federal Register on March 3,
  - (2026-06-01) Medical Devices; General Hospital and Personal Use Devices; Classification of the Rigid Sterilization Container With Electronic Monitoring
      The Food and Drug Administration (FDA) is classifying the rigid sterilization container with electronic monitoring into class II (special controls). The special controls that apply to the device type are identified in th
  - (2026-06-01) Medical Devices; Anesthesiology Devices; Classification of the Real-Time Ultrasound Anatomy Visualization and Labeling Device for Ultrasound Guided Regional Anesthesia
      The Food and Drug Administration (FDA) is classifying the real-time ultrasound anatomy visualization and labeling device for ultrasound guided regional anesthesia into class II (special controls). The special controls th
  - (2026-06-01) Medical Devices; Anesthesiology Devices; Classification of the Adjunctive Pain Measurement Device for Anesthesiology
      The Food and Drug Administration (FDA) is classifying the adjunctive pain measurement device for anesthesiology into class II (special controls). The special controls that apply to the device type are identified in this 
  - (2026-06-01) Medical Devices; Gastroenterology-Urology Devices; Classification of the Orally Ingested Transient Device for Constipation
      The Food and Drug Administration (FDA) is classifying the orally ingested transient device for constipation into class II (special controls). The special controls that apply to the device type are identified in this orde
  - (2026-06-01) Airworthiness Directives; Rolls-Royce Deutschland Ltd & Co KG Engines
      The FAA proposes to adopt a new airworthiness directive (AD) for all Rolls-Royce Deutschland Ltd & Co KG (RRD) Model RB211 Trent 768-60, 772-60, and 772B-60 engines. This proposed AD was prompted by a report that a batch

### State Legislative Action — 182 new of 302 total
  - (2026-05-30) [Alaska SB 63] An Act relating to the Local Boundary Commission; and providing for an effective date.
      An Act relating to the Local Boundary Commission; and providing for an effective date.
  - (2026-05-30) [Alaska SB 269] An Act restructuring the Board of Fisheries; and providing for an effective date.
      An Act restructuring the Board of Fisheries; and providing for an effective date.
  - (2026-05-30) [Alaska SB 174] An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
      An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
  - (2026-05-30) [Alaska HB 356] An Act relating to health and sanitary requirements and certain permits for commercial fishing vessels; and providing for an effective date.
      An Act relating to health and sanitary requirements and certain permits for commercial fishing vessels; and providing for an effective date.
  - (2026-05-30) [Alaska SB 280] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of revenue from the alternative volumetric tax; and providing for an 
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re
  - (2026-05-30) [Alaska SB 29] An Act establishing an executive administrator position for the Board of Dental Examiners; and relating to an executive administrator for the Big Game Commercial Services Board.
      An Act establishing an executive administrator position for the Board of Dental Examiners; and relating to an executive administrator for the Big Game Commercial Services Board.
  - (2026-05-30) [Alaska HB 152] An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on individuals under the Alaska Net Income Tax Act; and providing for an effective date.
      An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on individuals under the Alaska Net Income T
  - (2026-05-30) [Alaska SJR 20] Supporting federal, state, and local efforts to clean up and remove marine debris from the state; urging the National Oceanic and Atmospheric Administration and the Environmental Protection Agency to provide additional funding for those efforts and to remove barriers faced by tribes 
      Supporting federal, state, and local efforts to clean up and remove marine debris from the state; urging the National Oceanic and Atmospheric Administration and the Environmental Protection Agency to provide additional f

### State-Level News — 135 new of 722 total
  - (2026-05-29) [Alabama] Governor Ivey Proclaims June as Strong Families Month in Alabama
      MONTGOMERY – Governor Kay Ivey on Friday signed a proclamation officially declaring June 2026 as Strong Families Month in the state of Alabama. This proclamation highlights the importance of strong families led by a fath
  - (2026-05-30) [California] First Partner Siebel Newsom celebrates the annual Move Your Body, Calm Your Mind Day in Sacramento
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/First-Partner-Siebel-Newsom-celebrates-the-annual-Move-Your-Body-Calm-Your-Mind-Day-in-Sacramento-SEO-GFX-150x150.png" class="attachmen
  - (2026-05-30) [California] Governor Newsom applauds updates to California’s Cap-and-Invest Program
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Governor-Newsom-applauds-updates-to-Californias-Cap-and-Invest-Program-SEO-GFX-v2-150x150.png" class="attachment-thumbnail size-thumbna
  - (2026-05-30) [California] Governor Newsom announces appointments 5.29.2026
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2024/05/6C94C750-0DF8-46C6-A8E3-00EA4F1B1ADD-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async" />
  - (2026-05-29) [California] Governor Newsom celebrates graduation of emergency response leaders, highlights investments since 2019
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Governor-Newsom-celebrates-graduation-of-emergency-response-leaders-highlights-investments-since-2019-SEO-GFX-150x150.png" class="attac
  - (2026-05-30) [California] California overhauls carbon market — critics say it’s a giveaway to oil
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/02/050924-Marathon-Refinery-AP-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size
  - (2026-05-29) [Connecticut] The electric grid, homeschool and a food business incubator: CT politics news
      <figure><img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/05/Lamont_CitySeed_LauraTillman-1024x768.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=
  - (2026-05-29) [Connecticut] Fairfield speed cameras debut to mixed reaction
      <figure><img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/01/2026_0115_SR_SpeedCamera_114-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="

### Local News: St. Louis + Atlanta — 112 new of 248 total
  - (2026-05-30) [St. Louis] 3 climbers who fell near treacherous pass on Alaska’s Mount McKinley are dead, 1 rescued
      The four climbers were members of a Latvian mountaineering expedition.
  - (2026-05-30) [St. Louis] Huge crowd turns out to remember St. Louis man fatally shot outside biker bar
      "I want police to come and talk to me, tell me what happened to my son and I want justice," said Angela Pernell.
  - (2026-05-30) [St. Louis] Blue Origin investigates rocket explosion as public is warned about possible wreckage washing ashore
      Aerial views on Friday revealed heaps of crumpled structures on the ground, with just one tower and the water tank still standing.
  - (2026-05-30) [St. Louis] St. Louis Internship Program to steer teens toward professional careers this summer
      More than 200 local high schoolers are preparing to enter corporate boardrooms and earn college credentials as leaders look to combat youth crime with jobs.
  - (2026-05-30) [St. Louis] 'If I can just save one person': Man who lost two cousins in triple fatal Highway 367 crash pushes for barrier
      Donnell Ellis has collected hundreds of signatures calling for a taller concrete barrier on Highway 367. MoDOT now says it's considering speeding up the project.
  - (2026-05-30) [St. Louis] Google seeks approval to release millions of specially treated mosquitoes to combat disease
      Google's lesser-known "Debug" initiative seeks to release up to 32 million specially treated mosquitoes in Florida and California over the next two years.
  - (2026-05-30) [St. Louis] Bus hits cars in Virginia, killing 5 people and injuring 34
      Police say the bus failed to slow down and crashed into six vehicles. Four of the five fatalities were in one vehicle.
  - (2026-05-29) [St. Louis] 'Angels': St. Louis health networks unify to give tornado survivors life-saving medical aid and care
      One year post-tornado, St. Louis health workers go door-to-door delivering medicine, utility aid, and emotional support to survivors trapped in damaged homes.

### International News + Multilateral Institutions — 392 new of 868 total
  - (2026-05-30) [Global] No deal announced after Trump meeting to make 'final determination' on Iran
      The US president met his advisers, after officials confirmed the US and Iran had agreed a framework of a deal.
  - (2026-05-30) [Global] US not 'turning back' on Asia allies, but expects them to boost defence - Hegseth
      The US defense secretary is questioned about US commitment, including further arms deals, at an Asian security summit in Singapore.
  - (2026-05-29) [Global] First of five men found alive in flooded Laos cave rescued
      The bedraggled man was led to safety by rescuers after nine days stranded in the cavern
  - (2026-05-30) [Global] Ghana parliament passes anti-LGBTQ+ bill
      Same-sex acts are punishable by jail terms under Ghana's new bill targeting those identifying as gay, lesbian or transgender.
  - (2026-05-30) [Global] Spain's Sánchez digs in after eight years as PM as wave of scandals threatens survival
      Corruption probes of colleagues and relatives have put Spain's premier into a fight for survival.
  - (2026-05-29) [Global] Israel put on UN sexual violence in warzones blacklist for first time
      Israel says it rejects allegations in a new report by the office of the UN secretary general.
  - (2026-05-30) [Global] Ukraine using AI drones to strike vital convoys supplying Russian troops
      BBC Verify has analysed videos of attacks in occupied Ukraine on Russian trucks carrying ammunition, fuel and food.
  - (2026-05-30) [Global] 'Gifts' from a lover and 'botched' cocaine raids: Police inquiry grips South Africa
      South Africa's Madlanga Commission hears about Brazilian butt lift bribe denials and alleged drug heists.

### Chinese Internal News — 197 new of 277 total
  - (2026-05-30) Writing’s on the wall for the bond market – for those who can read it
  - (2026-05-30) Unicorn born in record time amid ‘arms race’ among China’s robotic hand developers
  - (2026-05-30) Chip boom powers Hong Kong stock exchange at 40. Innovation, resilience set next stage
  - (2026-05-29) [TITLE: 责编：汪灵犀 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxPNFM0TTE1RzVWa3BPWl9NX251Y2pKRXdhUlBzaG0wSFdob2o4eFBsOXZYeElYNUtkdmFocmxQNUVNMjNrQlQ1SEpGY] (zh: 责编：汪灵犀 邮箱：gtbhwb@people.cn - 人民日报)
      <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxPNFM0TTE1RzVWa3BPWl9NX251Y2pKRXdhUlBzaG0wSFdob2o4eFBsOXZYeElYNUtkdmFocmxQNUVNMjNrQlQ1SEpGY1pPWnRKbS04NlM4eVgtbS13UjFiaFFORjN1UlhJdk9tM2VKVkNaTjhhTHFkeWw2MnY5UW
  - (2026-05-29) [TITLE: “技”耀龙江--黑龙江频道--人民网_网上的人民日报 - 人民网黑龙江频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9sMFhfVWVONHhfSHc2TTZPYkliX05JN2g5cFdLSThSVUIzMGxpS3NrdlNndnJ3RDh4d3AweFNFdzhUbEpmVzltZ] (zh: “技”耀龙江--黑龙江频道--人民网_网上的人民日报 - 人民网黑龙江频道)
      <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9sMFhfVWVONHhfSHc2TTZPYkliX05JN2g5cFdLSThSVUIzMGxpS3NrdlNndnJ3RDh4d3AweFNFdzhUbEpmVzltZFdWQ0NFWWFsOHVXSkpWSml4N0hobmlCT0U4aGszY0ZxN2dB?oc=5" target="_blank">“技”
  - (2026-05-29) [TITLE: “创”响龙江--黑龙江频道--人民网_网上的人民日报 - 人民网黑龙江频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9oeGc2VXpMRTk0VHdIcmtMT2J1Y3dPbElQTzNYck5YLUdjZkxPQks0SmxULWdiUWM0THVFZEMzY3A4MzVlcmpyZ] (zh: “创”响龙江--黑龙江频道--人民网_网上的人民日报 - 人民网黑龙江频道)
      <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9oeGc2VXpMRTk0VHdIcmtMT2J1Y3dPbElQTzNYck5YLUdjZkxPQks0SmxULWdiUWM0THVFZEMzY3A4MzVlcmpyZHBFVG9Tc2RHUkhCcmNCVDhZTUxyaFptYlhTck1TQ19OMzZn?oc=5" target="_blank">“创”
  - (2026-05-30) [TITLE: 幼儿园食品安全新规6月1日施行 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFBXVkV4WWFfWUE4V2I0cWkza1NLUGtZX2RUR3daTHN0YzVEYXVEaWdkdjdpOGxpOWt4LXp0RTVfYk95ZF9INWd4aWRNejEwS0lQQ3V] (zh: 幼儿园食品安全新规6月1日施行 - 人民网健康)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFBXVkV4WWFfWUE4V2I0cWkza1NLUGtZX2RUR3daTHN0YzVEYXVEaWdkdjdpOGxpOWt4LXp0RTVfYk95ZF9INWd4aWRNejEwS0lQQ3VUQm14aEpnc090TmUtWGk1TGRLN3pQamlIbHpn?oc=5" target="_blank"
  - (2026-05-30) [TITLE: 高温“烤”验广州 医生：消暑别伤了耳鼻喉 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1ZcDE1ZExQMXlWeVpFZEpXNklhNlFteG5rV3lJV2tIdHdFaEpiYjNTQ1Q2Wl9ITVdqTW5rS2VBcHQxQXlOZFhncUdYUjJsZ2] (zh: 高温“烤”验广州 医生：消暑别伤了耳鼻喉 - 人民网健康)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1ZcDE1ZExQMXlWeVpFZEpXNklhNlFteG5rV3lJV2tIdHdFaEpiYjNTQ1Q2Wl9ITVdqTW5rS2VBcHQxQXlOZFhncUdYUjJsZ2dfUzBXSmxtNkQzbjJad2dXWlhiS1ZGN2Vib0pHVER3?oc=5" target="_blank"

### Russian Internal News (state + in-exile) — 290 new of 916 total
  - (2026-05-30) [TITLE: Бывший шеф-повар из Канады признал вину в продаже химикатов для самоубийства. Его подозревают в причастности к смерти более 100 человек по всему миру | LEDE: <p>Канадец Кеннет Лоу признал вину ] (ru: Бывший шеф-повар из Канады признал вину в продаже химикатов для самоубийства. Ег)
      <p>Канадец Кеннет Лоу признал вину в продаже через интернет химических веществ, используемых для самоубийства. Признание Лоу сделал на процессе в суде Ньюмаркета, провинция Онтарио, сообщает CBS News.<p>
  - (2026-05-30) [TITLE: Помните Эль-Ниньо? Из-за него 2023 год стал самым жарким в истории. Так вот, этим летом нас ждет супер Эль-Ниньо. Аномальная жара в России, засуха в Европе и новые климатические рекорды | LEDE:] (ru: Помните Эль-Ниньо? Из-за него 2023 год стал самым жарким в истории. Так вот, эти)
      <p>Последние несколько лет последствия климатического кризиса видны максимально наглядно: в 2023-м все говорили об Эль-Ниньо — климатическом явлении, которое привело к аномальной жаре. Тот год в принципе стал самым жарки
  - (2026-05-30) [TITLE: Россия отозвала посла из Армении для консультаций | LEDE: <p>Посол России в Армении Сергей Копыркин вызван в Москву для консультаций «в связи с шагами армянского руководства по сближению с Евро] (ru: Россия отозвала посла из Армении для консультаций)
      <p>Посол России в Армении Сергей Копыркин вызван в Москву для консультаций «в связи с шагами армянского руководства по сближению с Евросоюзом, наносящими ущерб взаимодействию в рамках ЕАЭС».<p>
  - (2026-05-30) [TITLE: Украинские дроны атаковали Ростовскую область. В порту Таганрога загорелись танкер и резервуары с топливом | LEDE: <p>В порту Таганрога в результате удара украинских дронов загорелись танкер и ] (ru: Украинские дроны атаковали Ростовскую область. В порту Таганрога загорелись танк)
      <p>В порту Таганрога в результате удара украинских дронов загорелись танкер и резервуары с топливом, а также административное здание, сообщил глава Ростовской области Юрий Слюсарь. По его данным, люди не пострадали.<p>
  - (2026-05-30) [TITLE: Снова берете телефон, без цели листаете соцсети и не можете остановиться? Вам точно нужен этот чек-лист, чтобы избавиться от такой привычки. И поделитесь опытом, если вы уже смогли перестать за] (ru: Снова берете телефон, без цели листаете соцсети и не можете остановиться? Вам то)
      <p>В марте суд в США признал, что соцсети вызывают зависимость. Впрочем, включить это состояние в Международную классификацию болезней и другие подобные перечни могут только врачи. И пока они этого не сделали, такая зави
  - (2026-05-30) [TITLE: США готовятся вернуться на Луну: в NASA показали роверы, на которых астронавты будут ездить по спутнику. А сверху за ними присмотрят прыгающие дроны. Как все это будет выглядеть? | LEDE: <p>Сов] (ru: США готовятся вернуться на Луну: в NASA показали роверы, на которых астронавты б)
      <p>Совсем недавно на Землю вернулись астронавты миссии «Артемида-2», впервые за полвека добравшиеся до Луны и облетевшие ее. А уже на этой неделе американское аэрокосмическое агентство NASA впервые представило планы разв
  - (2026-05-29) [TITLE: Суд запретил добавлять к названию Кеннеди-центра имя Трампа | LEDE: <p>Судья окружного суда США Кристофер Купер постановил, что переименование Кеннеди-центра в Центр Трампа-Кеннеди незаконно, п] (ru: Суд запретил добавлять к названию Кеннеди-центра имя Трампа)
      <p>Судья окружного суда США Кристофер Купер постановил, что переименование Кеннеди-центра в Центр Трампа-Кеннеди незаконно, поскольку учреждение должно быть посвящено «президенту Кеннеди и только президенту Кеннеди», соо
  - (2026-05-30) [TITLE: Появились новые подробности о пропавшей в Омске паре сапбордистов | LEDE: ] (ru: Появились новые подробности о пропавшей в Омске паре сапбордистов)

### Ukrainian Internal News (national + local Kyiv) — 42 new of 123 total
  - (2026-05-30) [TITLE: У Мюнхені тимчасово закривали аеропорт через ймовірний проліт дрона | LEDE: Вранці 30 травня аеропорт Мюнхена призупинив роботу на годину через підозру на дрон.] (uk: У Мюнхені тимчасово закривали аеропорт через ймовірний проліт дрона)
      Вранці 30 травня аеропорт Мюнхена призупинив роботу на годину через підозру на дрон.
  - (2026-05-30) [TITLE: "Птахи" СБС уразили танкер та нафтобазу у Таганрозі і "запалили" нафтовий термінал у Феодосії | LEDE: У ніч на 30 травня українські дрони вразили танкер, нафтобазу Таганрога та термінал у Феодо] (uk: "Птахи" СБС уразили танкер та нафтобазу у Таганрозі і "запалили" нафтовий термін)
      У ніч на 30 травня українські дрони вразили танкер, нафтобазу Таганрога та термінал у Феодосії, знищили "Іскандер" і два Ту-142.
  - (2026-05-30) [TITLE: У Словаччині в гірській ущелині загинула польська туристка | LEDE: ] (uk: У Словаччині в гірській ущелині загинула польська туристка)
  - (2026-05-30) [TITLE: У Трампа не виключають, що можуть пом'якшити санкції проти Ірану | LEDE: Адміністрація Трампа розглядає поступове скасування санкцій щодо Ірану залежно від розвитку подій.] (uk: У Трампа не виключають, що можуть пом'якшити санкції проти Ірану)
      Адміністрація Трампа розглядає поступове скасування санкцій щодо Ірану залежно від розвитку подій.
  - (2026-05-30) [TITLE: Глава Пентагону розкритикував Європу та похвалив азійських союзників США | LEDE: ] (uk: Глава Пентагону розкритикував Європу та похвалив азійських союзників США)
  - (2026-05-30) [TITLE: СБС вночі у Таганрозі знищили 2 літаки Ту-142 та "Іскандер"– Мадяр | LEDE: У ніч на 30 травня українські дрони знищили "Іскандер" та 2 літака Ту-142 на аеродромі у російському Таганрозі.] (uk: СБС вночі у Таганрозі знищили 2 літаки Ту-142 та "Іскандер"– Мадяр)
      У ніч на 30 травня українські дрони знищили "Іскандер" та 2 літака Ту-142 на аеродромі у російському Таганрозі.
  - (2026-05-30) [TITLE: Ворог атакував промислову інфраструктуру Запоріжжя: один загиблий, двоє поранених | LEDE: 30 травня у Запоріжжі окупанти обстріляли промислову інфраструктуру, поранено чоловіка, його стан важки] (uk: Ворог атакував промислову інфраструктуру Запоріжжя: один загиблий, двоє поранени)
      30 травня у Запоріжжі окупанти обстріляли промислову інфраструктуру, поранено чоловіка, його стан важкий.
  - (2026-05-30) [TITLE: Гегсет: Ситуація з війною в Ірані така, що будь-яка угода буде вигідною | LEDE: Піт Гегсет заявив, що США готові до угоди з Іраном, яка гарантує ненабуття ядерної зброї цією країною.] (uk: Гегсет: Ситуація з війною в Ірані така, що будь-яка угода буде вигідною)
      Піт Гегсет заявив, що США готові до угоди з Іраном, яка гарантує ненабуття ядерної зброї цією країною.

### Ukraine Theater (total-war monitoring) — 61 new of 308 total
  - (2026-05-30) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-29) [FIRMS] thermal anomaly 51.878, 33.522 (FRP 1.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-29 2314Z, FRP 1.28 MW
  - (2026-05-29) [FIRMS] thermal anomaly 51.613, 34.254 (FRP 1.33 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-29 2314Z, FRP 1.33 MW
  - (2026-05-29) [FIRMS] thermal anomaly 48.533, 34.649 (FRP 1.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-29 2316Z, FRP 1.9 MW
  - (2026-05-29) [FIRMS] thermal anomaly 47.866, 33.433 (FRP 21.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-29 2316Z, FRP 21.25 MW
  - (2026-05-29) [FIRMS] thermal anomaly 47.869, 33.388 (FRP 1.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-29 2316Z, FRP 1.74 MW
  - (2026-05-29) [FIRMS] thermal anomaly 46.842, 33.437 (FRP 6.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-29 2316Z, FRP 6.87 MW
  - (2026-05-29) [FIRMS] thermal anomaly 46.841, 33.437 (FRP 8.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-29 2316Z, FRP 8.8 MW

### Paper Trading Scorecard — 14 new of 141 total
  - (2026-05-30) [Polymarket] Will Xavier Becerra win the California Governor Election in 2026?
      This market will resolve to according to the candidate who wins the 2026 California gubernatorial election currently scheduled for November 3, 2026.

If the results of the election are not confirmed by July 31, 2027, thi
  - (2026-05-30) [Polymarket] Will Google have the best Math AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab for "Math"
  - (2026-05-30) [Polymarket] GRVT FDV above $200M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of GRVT's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No."

The token must
  - (2026-05-30) [Polymarket] Will Daniel Mercuri win the California Governor Election in 2026?
      This market will resolve to according to the candidate who wins the 2026 California gubernatorial election currently scheduled for November 3, 2026.

If the results of the election are not confirmed by July 31, 2027, thi
  - (2026-05-30) [Polymarket] Will the ECB announce a 50+ bps decrease at the June 2026 meeting?
      This market will resolve to the amount of basis points the upper bound of the deposit facility rate is changed by versus the level it was prior to the European Central Bank's (ECB) June 2026 meeting.

If the deposit faci
  - (2026-05-30) [Polymarket] Will Elon Musk post 880-919 tweets in May 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X during the month of May 2026.

For the purposes of this market, only main feed posts, quote posts and reposts will count.

Repli
  - (2026-05-30) [Manifold] Resolves to the side with the most holders at market close
  - (2026-05-30) [Manifold] Resolves to Square root of a random number between 1-10,000

### U.S. Weather + Severe / Climate Outlooks — 91 new of 107 total
  - (2026-05-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-30) [Severe] Flash Flood Warning: Flash Flood Warning issued May 30 at 5:08AM EDT until May 30 at 9:15AM EDT by NWS Morristown TN
      FFWMRX

The National Weather Service in Morristown has issued a

* Flash Flood Warning for...
Northwestern Anderson County in east Tennessee...
Southwestern Campbell County in east Tennessee...
East Central Morgan County
  - (2026-05-30) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 30 at 4:01AM CDT until May 30 at 9:00PM CDT by NWS Milwaukee/Sullivan WI
      * WHAT...Life threatening waves of 2 to 4 feet and dangerous
currents are expected.

* WHERE...Ozaukee, Milwaukee, Racine and Kenosha Counties.

* WHEN...From 7 AM CDT this morning through this evening.

* IMPACTS...Dang
  - (2026-05-30) [Moderate] Gale Watch: Gale Watch issued May 30 at 1:52AM PDT until June 1 at 2:00AM PDT by NWS Medford OR
      * WHAT...For the Small Craft Advisory, north winds 20 to 30 kt
with gusts up to 35 kt and seas 7 to 11 ft. For the Gale
Watch, north winds 25 to 35 kt with gusts up to 45 kt and seas
10 to 13 ft possible.

* WHERE...All 
  - (2026-05-30) [Moderate] Special Weather Statement: Special Weather Statement issued May 30 at 3:44AM CDT by NWS Topeka KS
      At 344 AM CDT, Doppler radar was tracking a strong thunderstorm 7
miles southwest of Miltonvale, moving east at 30 mph.

HAZARD...Wind gusts up to 50 mph and penny size hail.

SOURCE...Radar indicated.

IMPACT...Gusty wi
  - (2026-05-30) [Moderate] Rip Current Statement: Rip Current Statement issued May 30 at 4:42AM EDT until June 2 at 2:00AM EDT by NWS Tallahassee FL
      * WHAT...Dangerous rip currents.

* WHERE...Walton, Bay, Gulf, and Franklin County Beaches.

* WHEN...Through late Monday night.

* IMPACTS...Rip currents can sweep even the best swimmers away
from shore into deeper wate
  - (2026-05-30) [Severe] Flash Flood Warning: Flash Flood Warning issued May 30 at 4:25AM EDT until May 30 at 8:30AM EDT by NWS Morristown TN
      FFWMRX

The National Weather Service in Morristown has issued a

* Flash Flood Warning for...
Central Anderson County in east Tennessee...
East Central Morgan County in east Tennessee...

* Until 830 AM EDT.

* At 425 AM
  - (2026-05-30) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 30 at 3:18AM CDT until May 30 at 9:00PM CDT by NWS Chicago IL
      * WHAT...High waves of 3 to 6 ft and dangerous currents expected
at Illinois Lake Michigan beaches.

* WHERE...Lake IL, Northern Cook and Central Cook Counties.

* WHEN...From 7 AM CDT this morning through this evening.


### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 78 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 100 total
  - (2026-05-29) [OFAC] Counter Terrorism Designations; Issuance of Amended Iran-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBZT2x6ZWpsX3daM2U4SWE3bngxSGgwT3lxRmI1X1hpdHRIS19aU3p6S1d0SE1TT1V2dlM5cENaOXRfcFN4YUlsXzk3Mkk3cG9MTGR4M3lBWnpDcHZUTlE?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-30) [BIS Entity List] page checksum 3c02210a260b
      Page content hash: 3c02210a260b. Compare with prior day's hash to detect updates.
  - (2026-05-30) [USASpending] $42,370,311,401 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL 
      Agency: Department of Energy.  Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY
  - (2026-05-30) [USASpending] $41,553,920,412 → UT-BATTELLE LLC: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATOR
      Agency: Department of Energy.  Description: MANAGEMENT AND OPERATION OF THE OAK RIDGE NATIONAL LABORATORY
  - (2026-05-30) [USASpending] $34,070,138,514 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy.  Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS
  - (2026-05-30) [USASpending] $27,139,821,087 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy.  Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.
  - (2026-05-30) [USASpending] $22,428,178,818 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-30) [USASpending] $19,714,118,737 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy.  Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL).  THE CONTRACTOR SHALL,

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-05-30) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 4 new of 30 total
  - (2026-05-29) [CA1] Buckley v. Blanche
  - (2026-05-29) [CA1] United States v. Garcia-Toro
  - (2026-05-28) [CA4] United States v. Gregory Gentner
  - (2026-05-28) [CA4] United States v. Richard Brasser

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-30) [Coastlands Capital LP] Form 4 (Reporting)
      filed 2026-05-30 01:55 UTC · role: Reporting — Filed: 2026-05-29 AccNo: 0001104659-26-068440 Size: 10 KB
  - (2026-05-30) [Eloxx Pharmaceuticals, Inc.] Form 4 (Issuer)
      filed 2026-05-30 01:55 UTC · role: Issuer — Filed: 2026-05-29 AccNo: 0001104659-26-068440 Size: 10 KB
  - (2026-05-30) [Perisich John M.] Form 4 (Reporting)
      filed 2026-05-30 01:45 UTC · role: Reporting — Filed: 2026-05-29 AccNo: 0001441444-26-000004 Size: 15 KB
  - (2026-05-30) [Primoris Services Corp] Form 4 (Issuer)
      filed 2026-05-30 01:45 UTC · role: Issuer — Filed: 2026-05-29 AccNo: 0001441444-26-000004 Size: 15 KB
  - (2026-05-30) [Ullman Sharon] Form 4 (Reporting)
      filed 2026-05-30 01:39 UTC · role: Reporting — Filed: 2026-05-29 AccNo: 0001213900-26-063075 Size: 5 KB
  - (2026-05-30) [American Clean Resources Group, Inc.] Form 4 (Issuer)
      filed 2026-05-30 01:39 UTC · role: Issuer — Filed: 2026-05-29 AccNo: 0001213900-26-063075 Size: 5 KB
  - (2026-05-30) [Infleqtion, Inc.] Form 4/A (Issuer)
      filed 2026-05-30 01:37 UTC · amended · role: Issuer — Filed: 2026-05-29 AccNo: 0001012975-26-000508 Size: 19 KB
  - (2026-05-30) [SINGER DAVID B] Form 4/A (Reporting)
      filed 2026-05-30 01:37 UTC · amended · role: Reporting — Filed: 2026-05-29 AccNo: 0001012975-26-000508 Size: 19 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 27 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 15 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-05-30) Will WTI Crude Oil (WTI) hit (LOW) $85 in May?
      yes price: 0% · 24h volume: $3,286,977 · resolves 2026-06-01
  - (2026-05-30) Will Paris Saint-Germain FC win on 2026-05-30?
      yes price: 40% · 24h volume: $1,882,410 · resolves 2026-05-30
  - (2026-05-30) Roland Garros ATP: Francisco Cerundolo vs Zachary Svajda
      yes price: 92% · 24h volume: $1,313,967 · resolves 2026-06-06
  - (2026-05-30) US x Iran permanent peace deal by June 7, 2026?
      yes price: 16% · 24h volume: $897,273 · resolves 2026-06-07
  - (2026-05-30) MicroStrategy sells any Bitcoin by May 31, 2026?
      yes price: 17% · 24h volume: $867,021 · resolves 2026-07-01
  - (2026-05-30) Strait of Hormuz traffic returns to normal by end of May?
      yes price: 0% · 24h volume: $726,753 · resolves 2026-05-31
  - (2026-05-30) Will Switzerland win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $719,808 · resolves 2026-07-20
  - (2026-05-30) Will Croatia win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $687,764 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-05-30) [Marginal Revolution] How to improve British procurement
      Until two years ago, West London&#8217;s Greenford Tube station used to flood whenever it rained heavily. The train tracks are aboveground, but the ticket office would often get inundated. Sandbags still line the corrido
  - (2026-05-30) [Marginal Revolution] Supply is elastic, installment #1637
      With deadly precision, the Trump administration has launched dozens of attacks on small boats in the waters off South America, killing nearly 200 people in a campaign U.S. officials say is meant to curb the flow of illic

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=30, 14d-median=30; carrying terms: affected, airplanes, waters, regulatory, adopting, order, event, personnel, prompted, model, potential, vessels
- state_bills: today=302, 7d-median=155, 14d-median=155
- state_news: today=722, 7d-median=722, 14d-median=722; carrying terms: formally, expands, state, denver, better, supporters, evidence, oversight, wednesday, gubernatorial, weeks, vicinity
- local_news: today=248, 7d-median=252, 14d-median=252; carrying terms: drones, state, better, probe, weeks, street, found, began, governor, decoding, community, hopes
- foreign_news: today=868, 7d-median=905, 14d-median=905; carrying terms: drones, state, organisation, better, algorithm, probe, evidence, violation, diplomacy, wednesday, rejuvenation, weeks
- chinese_internal: today=277, 7d-median=284, 14d-median=284; carrying terms: huawei, challenge, brokerage, cbmiaefvx, banks, cbmib, crackdown, stock, lxtfb, cbmixkfvx, gtbhwb, cbmiykfvx
- russian_internal: today=916, 7d-median=1067, 14d-median=1067; carrying terms: collect, games, politico, centcom, reuters, youtube, china, media, street, title, found, financial
- ukrainian_internal: today=123, 7d-median=138, 14d-median=138; carrying terms: drones, state, condemned, central, wednesday, later, elections, peace, order, rubles, statement, rhetoric
- ukraine_theater: today=308, 7d-median=367, 14d-median=367; carrying terms: drones, state, nwhnv, governorate, rvvbukx, corpus, snnmbl, investigate, dvdhczjnoxh, ntmpivmfiajfzwelud, peace, xtbuvjeglhnkduzwtochnxshiydffnru
- paper_bets: today=141, 7d-median=141, 14d-median=141; carrying terms: formally, drones, state, including, consumption, humans, later, jared, lifetime, sachs, resolution, consensus
- weather: today=107, 7d-median=126, 14d-median=126; carrying terms: state, including, central, wednesday, escambia, impacts, hurricane, baltimore, norton, corpus, south, scattered
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=78, 7d-median=79, 14d-median=79; carrying terms: china, germany, coffee, index, brazil, lumber, italy, natural, cotton, mexico, commodity, equity
- sanctions_procurement: today=100, 7d-median=97, 14d-median=97; carrying terms: state, ofdruvlyzw, including, central, relation, resolution, islamic, council, south, beleu, herzegovina, order
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: evans, employee, blanche, chavez, transport, caribbean, salud, trustees, docks, webuild, khalil, kohan
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, david, financial, holdings
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, ocasio, johnson, filing, cooper, alexandria, graham, receipts, disbursements, talarico, redpath, joshua
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=0, 14d-median=0
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=15, 7d-median=16, 14d-median=16; carrying terms: denial, microsoft, following, adobe, trend, explorer, langflow, buffer, overflow, error, overwrite, defender
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, ceasefire, permanent, continue, hormuz, strait, agreement, peace, resolves, world, extension, price
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, marginal, revolution, story, class, policy, https, economist, recipients, assorted, links, conve
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: crane, craig, reserved, chrissy, keith, welch, stefanik, state, markwayne, michelle, shreve, meeks
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, placed, evidence, claude, market, sufficient, either, consensus, markets, identify, converges, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] ECB press: Financial stability vulnerabilities remain elevated as geoeconomic shock unfolds
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*