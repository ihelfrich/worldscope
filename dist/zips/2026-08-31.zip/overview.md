# WORLDSCOPE morning brief — 2026-08-31

## Headline
2834 new items across 19 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (683) · Russian Internal News (state + in-exile) (621) · Ukraine Theater (total-war monitoring) (496) · World leaders & government officials (324) · Chinese Internal News (212) · Local News: St. Louis + Atlanta (102) · U.S. Weather + Severe / Climate Outlooks (87) · State-Level News (84) · State Legislative Action (54) · Ukrainian Internal News (national + local Kyiv) (43) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (30)

## What changed today
### International News + Multilateral Institutions — 683 new of 987 total
  - (2026-08-30) [Global] 'My parents won't lend me £10k but helped my brother': When families play financial favourites
      So-called financial favouritism can cause jealousy and resentment long into adulthood. Here is how experts say you can avoid it
  - (2026-08-31) [Global] How the US-Canada trade war is being felt on both sides of the border
      The US-Canada trade war is being felt on both sides of the border.
  - (2026-08-31) [Global] Business groups urge Swinney to scrap 'ineffective' food price cap plan
      More than 20 organisations have written a joint letter to John Swinney urging him to scrap his plan for a legal cap on some food and drink prices.
  - (2026-08-30) [Global] 'My parents won't lend me £10k but helped my brother': When families play financial favourites
      So-called financial favouritism can cause jealousy and resentment long into adulthood. Here is how experts say you can avoid it
  - (2026-08-30) [Global] School uniform swap shop 'saves money and tackles second hand clothes stigma'
      A free initiative which started with one school four years ago now has more than 200 involved.
  - (2026-08-31) [Global] US and Iran trade strikes for first time in weeks
      The attack on Larak Island in the Strait of Hormuz - the first known US strike since late July - has killed two people and injured two others.

### Russian Internal News (state + in-exile) — 621 new of 831 total
  - (2026-08-31) В Бурятии коммунист, баллотирующийся в Госдуму, запустил на телевидении агитацию с лозунгом «Миру — мир» | LEDE: Кандидат в Госдуму от КПРФ по Бурятскому одномандатному округу, депутат Народ] (ru: В Б…
      Кандидат в Госдуму от КПРФ по Бурятскому одномандатному округу, депутат Народного хурала Бурятии Баир Цыренов запустил на местном телевидении агитационные ролики с лозунгом «Власть — народу, миру — мир», обратило внимани…
  - (2026-08-31) РБК: Минцифры пытается бороться с маскировкой VPN и запрещенных сайтов в «белых списках» | LEDE: Минцифры начало борьбу с сайтами в «белом списке», содержащими «запрещенный в России контент»] (ru: РБК…
      Минцифры начало борьбу с сайтами в «белом списке», содержащими «запрещенный в России контент», включая «рекламу VPN-сервисов», пишет РБК.
  - (2026-08-31) Украинские беспилотники атаковали Екатеринбург. Поврежден многоэтажный дом | LEDE: Украинские беспилотники атаковали Свердловскую область, сообщил глава региона Денис Паслер. В результате ат] (ru: Укр…
      Украинские беспилотники атаковали Свердловскую область, сообщил глава региона Денис Паслер. В результате атаки повреждены несколько квартир многоэтажного жилого дома в Екатеринбурге, заявил полномочный представитель през…
  - (2026-08-31) «Меня повесят». Это якобы сказал своему окружению Путин, утверждает The Economist. Глава Кремля не знает, как закончить войну — и поэтому готов пойти на эскалацию | LEDE: Президент РФ Владим] (ru: «Ме…
      Президент РФ Владимир Путин опасается за свою личную безопасность в случае прекращения войны без достижения хотя бы минимальной цели — захвата всего Донбасса, пишет The Economist.
  - (2026-08-31) В Гранд-Каньоне наводнение. Есть погибший и пропавшие без вести. Десятки туристов эвакуированы | LEDE: Один человек погиб, еще около 15 пропали без вести после внезапного наводнения в национ] (ru: В Г…
      Один человек погиб, еще около 15 пропали без вести после внезапного наводнения в национальном парке Гранд-Каньон в США.
  - (2026-08-31) Пропавшими без вести после наводнения в Непале числятся 4200 человек | LEDE: Власти Непала сообщили новые данные о пропавших без вести после наводнения. По состоянию на утро 31 августа, нет ] (ru: Про…
      Власти Непала сообщили новые данные о пропавших без вести после наводнения. По состоянию на утро 31 августа, нет сведений о судьбе около 4200 человек, находившихся в районе бедствия. В списке пропавших без вести, по данн…

### Ukraine Theater (total-war monitoring) — 496 new of 682 total
  - (2026-08-30) [FIRMS] thermal anomaly 52.177, 34.422 (FRP 2.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 2.5 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.179, 34.425 (FRP 1.11 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 1.11 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.175, 34.423 (FRP 1.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 1.56 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.109, 34.475 (FRP 1.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 1.03 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.287, 33.505 (FRP 2.57 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 2.57 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.213, 33.845 (FRP 1.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 1.01 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 212 new of 255 total
  - (2026-08-31) 习近平同吉尔吉斯斯坦总统扎帕罗夫会谈 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE5CeTJBWE04aks5eUgtVWplWFVvcWRGeGZITUFMb1dkMnBHMXFCd1BKSVYwLW9DaXpUaEhTY040N182amkxR0ZnbVFveTN5R] (zh:…
      习近平同吉尔吉斯斯坦总统扎帕罗夫会谈 人民网-图片频道
  - (2026-08-31) 读者点题·共同关注 | 情绪消费，“新”在哪里 - 人民网“领导留言板” | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1HeTM5azF3RmxRZjR4SzJJaVBaT0JvT3M2bWRwNnBoX0g2dHVFQkc3QkkzQ01YYzR4SlpqR1JvTUc0SEJjdzZ4TV] (zh:…
      读者点题·共同关注 | 情绪消费，“新”在哪里 人民网“领导留言板”
  - (2026-08-31) 浙江三门： 养殖塘景如画 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5DUldrZGJhRE1USG5RUDZ3aWlTb1ZScGs0OWVXNlE0bzU5SzdRaGxPNHdvV2FZYUhpQ0NsR1RjV3pwdVZqYnVkZ0tPWjd0ZTdnN3lxYUR] (zh:…
      浙江三门： 养殖塘景如画 人民图片
  - (2026-08-30) 山西永济： 农民画家描绘丰收图景 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9zZTZBU0pUMjB1ZlE5NkVqcHZmRkRpU1pQQzJmMnJDTG83WUZUaVVyZUdPQUdoM1duRnpFaWc0TWtJNEFjRTVWTFFTSWpoRlFIMEh] (zh:…
      山西永济： 农民画家描绘丰收图景 人民图片
  - (2026-08-31) 内蒙古呼和浩特： 开学第一课点燃科技梦 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1KRWw4SzhaRlNRMlVEenQ0VzUxOGVzanJpMVpOYnJnR181clg5RFJHa2xjdmdsMkw5eGxwNVM4aENoRmxLcENMRl9kVVFKb0tB] (zh:…
      内蒙古呼和浩特： 开学第一课点燃科技梦 人民图片
  - (2026-08-30) 山西晋中： 交通立体路网赋能城市发展 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9SYmdXMkE1cDVPTk9lM3VhbDlLM3kwZWo1NjJGZW1QaHZVTHZYeV90N05QMTFIRGVLcEpsTEVJaXhOMmxiNjBNdnFGR2pKRXg4N] (zh:…
      山西晋中： 交通立体路网赋能城市发展 人民图片

### Local News: St. Louis + Atlanta — 102 new of 183 total
  - (2026-08-31) [St. Louis] See the Aug. 31, 1926, front page: Bell hits home run and Cardinals lead Pittsburgh
      Headlines from the Aug. 31, 1926, front page include: Siren scares off men holding up Kirkwood bank
  - (2026-08-31) [St. Louis] St. Louis hospital CEOs got raises in COVID era despite pay cut pledge
      Plus: St. Louis-area school districts ban e-bikes, citing safety concerns
  - (2026-08-31) [St. Louis] The Short List: August 31
      Welcome to The Short List newsletter, a look at what's ahead in the St. Louis area — key news happenings, big sports matchups, can't-miss events and maybe even food recommendations.
  - (2026-08-31) [St. Louis] TRUMP'S TARIFFS HIT HOCKEY STICKS
      Members of the St. Louis AAA Blues under-14 team gather to hear instructions for a drill during practice Thursday, Aug. 27, 2026, at Centene Community Ice Center in Maryland Heights. Between sticks, skates, pads and othe…
  - (2026-08-31) [St. Louis] ABC moves to new channel on Tuesday in St. Louis
      Tuesday will see a major change in the alignment of St. Louis television stations.
  - (2026-08-31) [St. Louis] Richie's timeless lyricism captures Muny audience
      Lionel Richie performs onstage Saturday, Aug. 29, 2026, at the Muny in St. Louis.

### U.S. Weather + Severe / Climate Outlooks — 87 new of 90 total
  - (2026-08-31) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-31) [Moderate] Special Weather Statement: Special Weather Statement issued August 31 at 4:11AM CDT by NWS Brownsville TX
      The combination of hot temperatures and humidity levels will produce heat index values between 105 and 110 degrees for several hours this afternoon into this evening. A few locations may briefly experience heat index val…
  - (2026-08-31) [Moderate] Special Weather Statement: Special Weather Statement issued August 31 at 2:04AM MST by NWS Phoenix AZ
      At 203 AM MST, Doppler radar was tracking strong thunderstorms along a line extending from Punkin Center to near Four Peaks to 7 miles south of Apache Lake. Movement was northeast at 15 mph. HAZARD...Wind gusts up to 50…
  - (2026-08-31) [Unknown] Air Quality Alert: Air Quality Alert issued August 31 at 4:00AM CDT by NWS Memphis TN
      AQAMEG The Shelby County Health Department has issued a Code Orange Ozone Forecast effective for Shelby County Tennessee, Crittenden County Arkansas, and DeSoto County Mississippi, including the city of Memphis for today…
  - (2026-08-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 31 at 1:46AM MST until August 31 at 2:45AM MST by NWS Tucson AZ
      SVRTWC The National Weather Service in Tucson has issued a * Severe Thunderstorm Warning for... North Central Cochise County in southeastern Arizona... South Central Graham County in southeastern Arizona... * Until 245 A…
  - (2026-08-31) [Moderate] Gale Watch: Gale Watch issued August 31 at 1:35AM PDT until September 2 at 11:00PM PDT by NWS Seattle WA
      * WHAT...Southeast winds 25 to 35 kt possible. * WHERE...East Entrance U. S. Waters Strait Of Juan De Fuca and Northern Inland Waters Including The San Juan Islands. * WHEN...From Tuesday evening through Wednesday evenin…

### State-Level News — 84 new of 199 total
  - (2026-08-30) [Colorado] Colorado Newsline wins 7 awards in Colorado Press Association contest
      Colorado Newsline earned seven awards in the 2025 Colorado Press Association Better News Media Contest, the results of which were announced during a ceremony Saturday at the association’s annual convention. The contest i…
  - (2026-08-31) [California] Lawmakers vote to let first responders retire earlier and with more money. Will Newsom sign on?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/051826_Sandy_Fire_ZC_CM_09.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-08-31) [California] School sex abuse bill going to Newsom. Will he sign the ‘hard-won’ compromise?
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/020623-School-Abstract-CM-01.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-08-31) [Connecticut] Congress can finally make progress on this chronic disease
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/08/PXL_20210601_180600238-scaled-1-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async…
  - (2026-08-31) [Connecticut] Generational health is generational wealth
      <img width="724" height="483" src="https://ctmirror.org/wp-content/uploads/2020/04/Disparity-photo-from-c-hit.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy…
  - (2026-08-31) [Connecticut] As network news turn itself into a ‘Tic Toc platform’ will local television news rise to the challenge?
      <img width="1024" height="615" src="https://ctmirror.org/wp-content/uploads/2026/08/tv-news-logos-1024x615.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" s…

### State Legislative Action — 54 new of 118 total
  - (2026-08-29) [Louisiana HB 784] SEX OFFENSE/REGISTRY: Provides relative to sex offender registration and notification requirements
      SEX OFFENSE/REGISTRY: Provides relative to sex offender registration and notification requirements
  - (2026-08-29) [Massachusetts H 1338] An Act allowing fair compensation of Massachusetts credit union directors
      By Representative Vargas of Haverhill, a petition (accompanied by bill, House, No. 1338) of Andres X. Vargas relative to credit union compensation to members of boards of directors. Financial Services.
  - (2026-08-29) [Michigan HB 6309] Highways: memorial; portion of M-86; designate as the "Casey Rice Memorial Highway". Amends 2001 PA 142 (MCL 250.1001 - 250.2092) by adding sec. 116.
      Highways: memorial; portion of M-86; designate as the "Casey Rice Memorial Highway". Amends 2001 PA 142 (MCL 250.1001 - 250.2092) by adding sec. 116.
  - (2026-08-29) [Michigan HB 6311] Employment security: administration; notice requirements for determination of benefits; modify. Amends sec. 32 of 1936 (Ex Sess) PA 1 (MCL 421.32).
      Employment security: administration; notice requirements for determination of benefits; modify. Amends sec. 32 of 1936 (Ex Sess) PA 1 (MCL 421.32).
  - (2026-08-29) [Michigan SB 702] Civil procedure: foreclosure; foreclosure or garnishment of wages for medical debt; prohibit. Creates new act. TIE BAR WITH: SB 0701'25
      Civil procedure: foreclosure; foreclosure or garnishment of wages for medical debt; prohibit. Creates new act. TIE BAR WITH: SB 0701'25
  - (2026-08-29) [Michigan HB 6290] Health: other; office of primary care transformation; establish. Creates new act. TIE BAR WITH: HB 6289'26
      Health: other; office of primary care transformation; establish. Creates new act. TIE BAR WITH: HB 6289'26

### Ukrainian Internal News (national + local Kyiv) — 43 new of 112 total
  - (2026-08-31) Росіяни атакували центр Херсона: загинули двоє людей | LEDE: У центрі Херсона від атак російського безпілотника і обстрілів загинули чоловік та літня жінка. Особу загиблих встановлюють.] (uk: Росіяни…
      У центрі Херсона від атак російського безпілотника і обстрілів загинули чоловік та літня жінка. Особу загиблих встановлюють.
  - (2026-08-31) Через Рош га-Шана в Умані запровадили обмеження на пересування | LEDE: В Умані з 4 по 17 вересня запроваджено особливий режим руху через Рош га-Шана. На деяких дорогах в'їзд дозволено лише пало] (uk:…
      В Умані з 4 по 17 вересня запроваджено особливий режим руху через Рош га-Шана. На деяких дорогах в'їзд дозволено лише паломникам–хасидам або діють посилені обмеження.
  - (2026-08-31) Ексомандиру "Русича" у Фінляндії пом’якшили вирок за воєнні злочини проти України | LEDE: Апеляційний суд скоротив вирок Яну Петровському за три воєнні злочини в Україні до 12 років і 6 місяців] (uk:…
      Апеляційний суд скоротив вирок Яну Петровському за три воєнні злочини в Україні до 12 років і 6 місяців ув'язнення, замість довічного.
  - (2026-08-31) Угорські Gripen змусили сісти крадений літак, що летів до АЕС, пілот спробував вкрасти ще й авто | LEDE: ] (uk: Угорські Gripen змусили сісти крадений літак, що летів до АЕС, пілот спробував в)
  - (2026-08-31) Вимагали $20 тис. за службу в тилу і погрожували перевести в штурмовики: затримали 4 військових | LEDE: ДБР та СБУ викрили групу, серед яких полковник ЗСУ, що вимагали $20 тис. за переведення в] (uk:…
      ДБР та СБУ викрили групу, серед яких полковник ЗСУ, що вимагали $20 тис. за переведення військового до тилу. Затриманим повідомлено про підозру.
  - (2026-08-31) Санчес вказав на причетність РФ до міграційної кризи в Іспанії | LEDE: Прем'єр-міністр Іспанії Педро Санчес заявив, що Росія та Ізраїль причетні до хвилі дезінформації, яка призвела до масового] (uk:…
      Прем'єр-міністр Іспанії Педро Санчес заявив, що Росія та Ізраїль причетні до хвилі дезінформації, яка призвела до масового напливу мігрантів до іспанського анклаву Сеута наприкінці липня.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-08-31) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (48.7152, 2.3757) · alt: 342m · 247km/h
  - (2026-08-31) PUMA44 (Slovenia)
      icao24: 506e1d · position: (45.8703, 15.4532) · alt: 1188m · 257km/h
  - (2026-08-31) CFC2987 (Canada)
      icao24: c2b5b7 · position: (51.8042, 18.4615) · alt: 8831m · 630km/h
  - (2026-08-31) GAF152 (Germany)
      icao24: 3f46db · position: (46.7906, 11.757) · alt: 10058m · 731km/h
  - (2026-08-31) JAF66L (Belgium)
      icao24: 44d1ba · position: (50.3668, 3.0662) · alt: 5692m · 804km/h
  - (2026-08-31) JAF7CB (Belgium)
      icao24: 44d1a6 · position: (47.0466, 0.7115) · alt: 10972m · 882km/h

### Paper Trading Scorecard — 18 new of 128 total
  - (2026-08-31) [Polymarket] US-Iran Hormuz Agreement by September 30?
      This market will resolve to “Yes” if a diplomatic agreement between the United States and Iran over traffic in the strait of Hormuz is announced by the specified date, 11:59 PM ET. A diplomatic agreement refers to an off…
  - (2026-08-31) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-08-31) [Polymarket] Will Max Miller drop out of the OH-07 race by August 30?
      This market will resolve to "Yes" if Max Miller withdraws from or officially announces his withdrawal from the 2026 OH-07 Congressional election, or announces the suspension of his 2026 OH-07 Congressional campaign, by t…
  - (2026-08-31) [Manifold] Rogue AIs before 2028?
  - (2026-08-31) [Manifold] By the start of september will i be over 110 pounds
  - (2026-08-31) [Manifold] Will Waymo expand it's LA service area by the end of 2026?

### IT, InfoSys & cybersecurity news (last 7 days) — 18 new of 56 total
  - (2026-08-31) [BleepingComputer] Nigerians extradited to US for sextortion, deaths of two teens
      Two Nigerian men extradited to the U.S. on Thursday have been charged with involvement in sextortion schemes that resulted in the deaths of two minor victims in Mississippi and North Carolina. [...]
  - (2026-08-31) [BleepingComputer] Microsoft asks users to ignore 'Antivirus is turned off' errors
      Microsoft asked customers this week to ignore incorrect alerts that Defender Antivirus has been turned off after installing the latest Defender updates. [...]
  - (2026-08-31) [The Hacker News] DoJ Corrects China Hacking Claim, Says U.S. Agencies Were Targets, Not Victims
      The U.S. Department of Justice (DoJ) on Friday corrected a previously issued press statement that several of its agencies were victims of attacks carried out by Chinese threat actors, instead now pointing out that they w…
  - (2026-08-31) [The Register] Energy biz SSE smacked around in court by a guy and AI
      Company's three year pursuit of debt from non-existent address ended by Oxford judge
  - (2026-08-31) [The Register] The balkanization of virtualization will de-throne VMware, which doesn't mind a bit
      The real fight is who wins the most AI and K8s workloads
  - (2026-08-31) [The Register] Who, me? Techie with three months' experience was sent in as the Cisco expert and proceeded to blow everything up
      The real mistake here was probably sending someone so young to do the job

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-08-31) US Open ATP: Thiago Agustin Tirante vs Adrian Mannarino
      yes price: 9% · 24h volume: $805,686 · resolves 2026-09-06
  - (2026-08-31) US Open ATP: Martin Landaluce vs Jacob Fearnley
      yes price: 70% · 24h volume: $646,385 · resolves 2026-09-06
  - (2026-08-31) Will the U.S. invade Iran before 2027?
      yes price: 16% · 24h volume: $644,328 · resolves 2027-01-01
  - (2026-08-31) Will Arsenal FC win on 2026-08-31?
      yes price: 64% · 24h volume: $600,688 · resolves 2026-08-31
  - (2026-08-31) US Open WTA: Emma Navarro vs Lois Boisson
      yes price: 95% · 24h volume: $469,103 · resolves 2026-09-06
  - (2026-08-31) Counter-Strike: Spirit vs FURIA (BO3) - BLAST Open Porto Group A
      yes price: 50% · 24h volume: $440,380 · resolves 2026-08-31

### USGS earthquakes (M4.5+, past day) — 9 new of 10 total
  - (2026-08-31) M 5.5 - 44 km NNE of Ruteng, Indonesia
      M5.5 · 44 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-31) M 4.9 - 13 km SSE of Union, Philippines
      M4.9 · 13 km SSE of Union, Philippines · depth 83.891 km
  - (2026-08-30) M 4.7 - 62 km SSE of Palca, Peru
      M4.7 · 62 km SSE of Palca, Peru · depth 102.036 km
  - (2026-08-30) M 4.6 - 128 km N of Aksu, China
      M4.6 · 128 km N of Aksu, China · depth 10 km
  - (2026-08-31) M 4.5 - south of the Fiji Islands
      M4.5 · south of the Fiji Islands · depth 508.306 km
  - (2026-08-31) M 4.5 - 71 km WSW of Puerto Casma, Peru
      M4.5 · 71 km WSW of Puerto Casma, Peru · depth 59.386 km

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-08-28) Alaska Supreme Court: Donkel v. State
  - (2026-08-28) Alaska Supreme Court: Tanuk S. v. Department of Family & Community Services, Office of Children's Services
  - (2026-08-28) Alaska Supreme Court: Victoria W. v. State
  - (2026-08-27) U.S. Court of Appeals, 8th Cir.: United States v. William Parrott
  - (2026-08-26) U.S. Court of Appeals, 6th Cir.: Dennis O'Connor v. Rachael Eubanks

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-31) [Marginal Revolution] Spain fact of the day
      CoverManager, an online platform that manages reservations for thousands of Spanish restaurants, reports that half the dinner bookings now are for before 9 p.m., compared with 27 percent a decade ago. TheFork, a similar…
  - (2026-08-31) [Marginal Revolution] Anthropomorphizing AI?
      I am very much opposed to the view that the AIs are sentient, or might be sentient. I view that as a category error, and the chances of it being true are vanishingly small. Nonetheless I largely side with Roon when he wr…
  - (2026-08-30) [Marginal Revolution] Russia markets in everything
      While Western export bans have severed Russia from much of the auto market, they have not tempered the demand for brand-name SUVs and trucks. That has given rise to a sophisticated network of criminals that steals cars,…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-31) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=29, 14d-median=23; carrying terms: public, establish, proposed, management, national, action, certain, temporary, regulatory, specifically, amends, service
- state_bills: today=118, 7d-median=92, 14d-median=118; carrying terms: requiring, defined, regulatory, including, local, issue, provided, require, provider, grant, alaska, order
- state_news: today=199, 7d-median=648, 14d-median=614; carrying terms: attorney, political, biggest, redirects, tennessee, jersey, https, freedom, width, forbidden, campaign, efforts
- local_news: today=183, 7d-median=249, 14d-median=240; carrying terms: driver, https, atlanta, width, dining, async, local, center, shooting, following, attachment, injured
- foreign_news: today=987, 7d-median=1027, 14d-median=1012; carrying terms: italia, political, production, sector, climbed, brings, garden, southern, trade, algerian, problems, newsroom
- chinese_internal: today=255, 7d-median=289, 14d-median=288; carrying terms: https, cbmia, lxtfb, target, color, people, cbmixkfvx, cbmiykfvx, cbmiakfvx, articles, cbmidefvx, cbmizkfvx
- russian_internal: today=831, 7d-median=1074, 14d-median=1048; carrying terms: telegram, novayagazeta, error, https, telegraph, social, found, forbidden, truth, street, financial, wildberries
- ukrainian_internal: today=112, 7d-median=122, 14d-median=114; carrying terms: barrage, https, strike, forbidden, campaign, crimea, attacks, forces, including, local, center, intelligence
- ukraine_theater: today=682, 7d-median=236, 14d-median=813; carrying terms: production, equipment, hnctzssestx, pwsznqcmndrwixvdboutrgwnvibnrca, lfuhfougp, exbyce, ewtywtlyehbqc, delive, rghsy, egnrnuhnlwc, nvhzyky, rvhuwjrcd
- paper_bets: today=128, 7d-median=132, 14d-median=132; carrying terms: general, artist, schumer, degrees, romania, verve, caribbean, source, goals, pirates, november, koivun
- weather: today=90, 7d-median=133, 14d-median=144; carrying terms: storm, afddtx, inland, possible, especially, afdilx, widespread, degrees, louis, caribbean, houston, conditions
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: labor, funds, rates, balance, indicator, jtsjol, sheet, unemployment, cpiaucsl, payems, recession, supply
- markets: today=5, 7d-median=21, 14d-median=21; carrying terms: treasury, credit, rates, equities, nasdaq, yield, commodities, range, close, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=111, 7d-median=108, 14d-median=102; carrying terms: articles, claims, political, herzegovina, general, bissau, comments, against, aggression, destruction, transnistria, annexation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, congresstrading, https, quiver, httperror, quantitative, unauthorized, quiverquant, client
- billionaires: today=0, 7d-median=0, 14d-median=32
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, appeals, california, delaware, connecticut, county, america, company, thomas, cisneros
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, issuer, filed, group, scott, joseph, brian, michael, robert, david, financial
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: booker, ossoff, disbursements, robert, angels, cycle, brown, lindsey, platner, cortez, friends, michael
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=33; carrying terms: english, trump, perimeter, keywords, russia, russian, sanctions, attack, ukrainian, themes, against, strikes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, kingdom, france, ground, germany, canada, bulgaria, netherlands, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: unaffected, investigations, march, reporting, batches, spain, disembarked, general, detected, declaration, consuming, contamination
- cisa_kev: today=20, 7d-median=20, 14d-median=12; carrying terms: authentication, product, function, injection, microsoft, command, remediation, vendor, project, vulnerability, sharepoint, service
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=10, 7d-median=14, 14d-median=16; carrying terms: indonesia, depth, ruteng, islands, south, philippines, guinea, china, papua
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, interest, august, september, meeting, price, championship, resolves, donetsk, volume, shakhtar, league
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, marginal, class, conversable, revolution, economist, demand, number, together, shows, marginalrevolution, often
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: agents, against, breach, https, cybersecurity, vulnerability, techcrunch, record, attacks, today, intelligence, using
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: cassidy, attorney, tlaib, commodity, terri, gregory, courtney, kimberlyn, jeffries, clyburn, general, harris
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, module, consensus, converges, today, market, evidence, either, placed, decision, placement, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*