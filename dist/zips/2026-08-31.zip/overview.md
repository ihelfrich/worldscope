# WORLDSCOPE morning brief — 2026-08-31

## Headline
3593 new items across 22 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (793) · International News + Multilateral Institutions (756) · Russian Internal News (state + in-exile) (727) · World leaders & government officials (324) · Chinese Internal News (235) · State-Level News (173) · Local News: St. Louis + Atlanta (156) · U.S. Weather + Severe / Climate Outlooks (101) · State Legislative Action (70) · Ukrainian Internal News (national + local Kyiv) (55) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (31)

## What changed today
### Ukraine Theater (total-war monitoring) — 793 new of 911 total
  - (2026-08-31) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-30) [FIRMS] thermal anomaly 52.177, 34.422 (FRP 2.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 2.5 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.179, 34.425 (FRP 1.11 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 1.11 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.175, 34.423 (FRP 1.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 1.56 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.109, 34.475 (FRP 1.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 1.03 MW
  - (2026-08-30) [FIRMS] thermal anomaly 52.287, 33.505 (FRP 2.57 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-30 0033Z, FRP 2.57 MW

### International News + Multilateral Institutions — 756 new of 1005 total
  - (2026-08-31) [Global] Countries legally obliged to consider slavery reparations, says UN committee
  - (2026-08-31) [Global] Morocco not to blame for Ceuta border breach, says Spanish PM
  - (2026-08-30) [Global] People fleeing Sudan civil war face ‘dire and deteriorating’ conditions in refuge city
  - (2026-08-30) [Global] Canada erects giant ‘Lake Ontario’ sign as spat with Trump over name escalates
  - (2026-08-30) [Global] Venezuela’s Delcy Rodríguez defends ‘endless’ benefits of her oil deal with Trump
  - (2026-08-31) [Global] Nepal rescuers race to reach hundreds feared trapped in hydropower tunnels

### Russian Internal News (state + in-exile) — 727 new of 924 total
  - (2026-08-31) Премьер Индии — Путину: «мы должны работать над прекращением военных действий» | LEDE: Премьер-министр Индии Нарендра Моди на встрече с президентом России Владимиром Путиным заявил о необход] (ru: Пре…
      Премьер-министр Индии Нарендра Моди на встрече с президентом России Владимиром Путиным заявил о необходимости прекращения войны в Украине.
  - (2026-08-31) В результате удара ВСУ по Белгороду погиб 16-летний глухой подросток. Он ходил на подработку на склад Ozon | LEDE: В Белгороде в результате ракетного удара ВСУ по складу Ozon, который был на] (ru: В р…
      В Белгороде в результате ракетного удара ВСУ по складу Ozon, который был нанесен 30 августа, погиб 16-летний глухой подросток Давид З. Об этом «Осторожно, новости» рассказали его родственники.
  - (2026-08-31) Глава европейской дипломатии Кая Каллас заявила, что в Средиземном море задержан танкер «теневого флота» | LEDE: В Средиземном море задержан танкер, который, предположительно, входит в «тене] (ru: Гла…
      В Средиземном море задержан танкер, который, предположительно, входит в «теневой флот», перевозящий российскую нефть в обход санкций.
  - (2026-08-31) Премьер Испании возложил ответственность за распространение фейков о миграционном кризисе в Сеуте на сети, связанные с Россией и Израилем | LEDE: Расследование причин миграционного кризиса в] (ru: Пре…
      Расследование причин миграционного кризиса в Сеуте продолжается, однако в соцсетях появилось множество фейков и дезинформации, заявил премьер-министр Испании Педро Санчес в эфире радио Cadena Ser.
  - (2026-08-31) России не нужна военная экономика, это «полный слом системы», заявил бывший министр финансов Михаил Задорнов | LEDE: Российскую экономику «не нужно» превращать в военную, это «невозможно» сд] (ru: Рос…
      Российскую экономику «не нужно» превращать в военную, это «невозможно» сделать. Об этом в интервью РБК заявил бывший министр финансов РФ (1997 — 1999 годы) и бывший глава банка «Открытие» Михаил Задорнов.
  - (2026-08-31) Визит главы ЦРУ еще раз показал, как сильно Кремль любит закулисную дипломатию. Но она уже давно не работает. Александр Баунов — о том, почему России нечего сказать Западу даже за закрытыми две] (ru:…
      История и здравый смысл говорят, что закулисная дипломатия может быть более результативной, чем публичное обсуждение позиций. Эти надежды подкрепляются тем, что Россия не первое десятилетие настаивает на преимуществах от…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 235 new of 276 total
  - (2026-08-30) 美国迪士尼将取消部分员工配偶的医疗保险，“这种做法并不常见” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE84Z1FaSHY3MFVLQVJVanJFMi1iUkxVWHI0VHE5RXJIOTdqQTE2eFVRcWpqOEh6VDh2dVlkVUZIaTFVX3JWajlMeX] (zh:…
      美国迪士尼将取消部分员工配偶的医疗保险，“这种做法并不常见” 观察者
  - (2026-08-31) 发展靠创新系列：人民币升值节奏由中国掌握 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBlVDVoRlM5QmdidEF0dnhhbEhqT2pNLU4yd2xTWUNqWE1sMGZYZW95dmhpaFpkdWRacERSZFpCNFAzdmVKSy1DdjVvVXFyUk5YO] (zh:…
      发展靠创新系列：人民币升值节奏由中国掌握 风闻
  - (2026-08-30) 马杜罗社媒发布狱中照片：爱与希望的小礼物 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9Zc01FeVl1dEVLMGk1Uy0yc1JTWUs0dzdMVGVwOEFVa0REYUtHWHpaSklBYWlicHlDN0xPUS1VRzB6WTVNYk8ybmExd0J0YlVn] (zh:…
      马杜罗社媒发布狱中照片：爱与希望的小礼物 观察者
  - (2026-08-31) 特朗普发布AI合成视频，威胁“炸毁”伊朗石油出口枢纽 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBkZG9oSWhnQmU5U2RzSk14NTZ0T204alRyaElXSTZiajVJV2h3MXUzYXhkQ3E1RGFxZGZvZHdhaEVvSzgtQ3dTUEt4aU] (zh:…
      特朗普发布AI合成视频，威胁“炸毁”伊朗石油出口枢纽 观察者
  - (2026-08-31) 乐山电力发布中报 归母净利润同比降12.71% - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9VSmNNM2M1bVp0TldNTHVQYUxmTE1SWjc0Mld5VFJ1X0FPcXVNd19jWHpFY1YtUVp5dnVXMFRDa283YmlyTjlPUWxlNElrX] (zh:…
      乐山电力发布中报 归母净利润同比降12.71% 观察者
  - (2026-08-31) 担心遭到袭击，通过霍尔木兹海峡的商船数量降至每日5艘 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5hQ1dlMnRweDZtWDFhNnBwcGpQSmx3VzNaSHFDeERVRlBqUzRVd0MwZHNUZXZtQ2lJX1l0bHh6bjF5QnctNHYxWkdJZE] (zh:…
      担心遭到袭击，通过霍尔木兹海峡的商船数量降至每日5艘 观察者

### State-Level News — 173 new of 278 total
  - (2026-08-31) [California] Deadline today for the final bills Newsom will see as governor
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/052826_Assembly-Session_MG_CM_29.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-08-31) [California] California lawmakers greenlight a new San Diego sports arena, bypassing environmental hurdles
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082126-Pechanga-Arena-San-Diego-VOSD-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp…
  - (2026-08-31) [California] California to get more power to sue big businesses under anti-monopoly bill going to Newsom
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/010625_First-Day-Session_FG_CM_15.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-08-31) [California] A year after their promise, lawmakers again reform environmental planning. Now Newsom will weigh in
      <img width="1024" height="673" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082526-GKN-JG-GETTY-CM-01.jpg?fit=1024%2C673&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-08-31) [California] California may restrict undercover police operations targeting youth
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/070126-Riverside-Jail-JAH-CM-15.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-08-31) [California] Saving Hollywood? California to restore access to tax break for independent films
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/080426-Indie-Film-Crew-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### Local News: St. Louis + Atlanta — 156 new of 196 total
  - (2026-08-31) [St. Louis] Top family-friendly events this week in St. Louis
      UniverSoul Circus | September 2–13The big top returns to St. Louis with UniverSoul Circus’ new WE ALL BELONG production. Expect flying motorcycles, fire-breathing stilt walkers, aerialists, acrobats, roller skaters, danc…
  - (2026-08-31) [St. Louis] Elephant Baby postpartum retreat for moms could be coming to St. Louis
      When Kilah Lawson became a mother, she discovered something she hadn’t expected: Everyone was focused on the baby, but very few people were focused on her. After having her third baby, she remembers lying in bed wishing…
  - (2026-08-31) [St. Louis] Missouri Athletic Club tightens its belt to plug operating deficit
      It’s not just the Saint Louis Club experiencing financial woes: Another private club in St. Louis says it’s facing a “significant operating deficit”—but its president says members have no reason to fear. Mark Milton, pre…
  - (2026-08-31) [St. Louis] Top things to do this month in St. Louis
      SEPTEMBER 5–7 This Labor Day weekend, see sumo wrestling, hear taiko drums, explore the Japanese Garden, and even see world-renowned artist Masayo Ishigure perform traditional Japanese music at the Missouri Botanical Gar…
  - (2026-08-30) [St. Louis] New book explores how St. Louis became a craft beer city in the shadow of Anheuser-Busch
      When Joel Bittle began writing a book about St. Louis craft beer, he thought he knew when the story started. “I thought the book would hinge on the sale of Anheuser-Busch to InBev,” Bittle says. “It felt like collective…
  - (2026-08-30) [St. Louis] New craft brew options across St. Louis
      Learn more about the craft beer scene on the Arch Eats podcast featuring guest Jordan Palmer. SEPTEMBER Millpond Brewing (Millstadt, IL) – Maurice | 0.5% ABV | ReturningMillpond’s nonalcoholic golden ale is back on draft…

### U.S. Weather + Severe / Climate Outlooks — 101 new of 103 total
  - (2026-08-31) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-31) [Severe] Flash Flood Warning: Flash Flood Warning issued August 31 at 8:34AM MDT until August 31 at 10:30AM MDT by NWS Salt Lake City UT
      FFWSLC The National Weather Service in Salt Lake City has extended the * Flash Flood Warning for... Southern Kane County in southern Utah... * Until 1030 AM MDT. * At 834 AM MDT, gauge reports indicated thunderstorms pro…
  - (2026-08-31) [Moderate] Rip Current Statement: Rip Current Statement issued August 31 at 10:30AM AST until August 31 at 6:00PM AST by NWS San Juan PR
      * WHAT..Life-threatening rip currents. * WHERE...Beaches of northern, eastern and southeastern Puerto Rico, Vieques, Culebra, and the U.S. Virgin Islands. * WHEN...Through Monday afternoon. * IMPACTS...Rip currents can s…
  - (2026-08-31) [Moderate] Wind Advisory: Wind Advisory issued August 31 at 9:01AM CDT until August 31 at 7:00PM CDT by NWS Bismarck ND
      * WHAT...West winds to 35 mph with gusts up to 55 mph expected. * WHERE...Northwest and north central North Dakota. * WHEN...Until 7 PM CDT /6 PM MDT/ this evening. * IMPACTS...Things left unsecured outside will be blown…
  - (2026-08-31) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued August 31 at 5:52AM AKDT until September 1 at 4:00AM AKDT by NWS Fairbanks AK
      * WHAT...Snow and breezy winds. Total snow accumulations of 3 to 7 inches above 2500 feet along the Richardson Highway near Isabel Pass, with heavier amounts above pass level. Northerly winds gusting as high as 40 mph. *…
  - (2026-08-31) [Severe] Flash Flood Warning: Flash Flood Warning issued August 31 at 6:38AM MST until August 31 at 8:30AM MST by NWS Tucson AZ
      FFWTWC The National Weather Service in Tucson has extended the * Flash Flood Warning for... Central Pima County in southeastern Arizona... * Until 830 AM MST. * At 638 AM MST, Doppler radar and automated rain gauges indi…

### State Legislative Action — 70 new of 78 total
  - (2026-08-31) [California AB 1665] School athletics: coaches: youth athletics behavioral and mental health training.
      Existing law requires the governing board of a school district to have general control of, and be responsible for, all aspects of the interscholastic athletic policies, programs, and activities in its school district, as…
  - (2026-08-31) [California AB 282] Elections: seizure of election materials.
      Under existing law, a county elections official is required to prepare a certified statement of the results of an election and submit it to the county board of supervisors within 30 days of the election. This bill would…
  - (2026-08-31) [California AB 739] Common interest developments: managing agent fees.
      Existing law, the Davis-Stirling Common Interest Development Act, governs the formation and operation of common interest developments, and requires a common interest development to be managed by an association, as specif…
  - (2026-08-31) [California AB 2484] San Diego Metropolitan Transit System: transactions and use tax: voter initiatives.
      The Mills-Deddeh Transit Development Act establishes the San Diego Metropolitan Transit Development Board, also known as the San Diego Metropolitan Transit System (MTS) , governed by a 15-member board with specified powe…
  - (2026-08-31) [California SB 615] Vehicle traction batteries.
      Existing law requires the Secretary for Environmental Protection to convene the Lithium-Ion Car Battery Recycling Advisory Group to review, and advise the Legislature on, policies pertaining to the recovery and recycling…
  - (2026-08-31) [California AB 1946] Reporting mechanism: child sexual abuse material.
      Existing law requires a social media platform to take certain actions with respect to child sexual abuse material on the social media platform, including requiring the platform to provide, in a mechanism that is reasonab…

### Ukrainian Internal News (national + local Kyiv) — 55 new of 119 total
  - (2026-08-31) Атаки Росії восени: реактивні дрони, балістика та нова тактика терору | LEDE: ] (uk: Атаки Росії восени: реактивні дрони, балістика та нова тактика терору)
  - (2026-08-31) Трамп пообіцяв Ірану відповідь після удару по базах США в Йорданії | LEDE: ] (uk: Трамп пообіцяв Ірану відповідь після удару по базах США в Йорданії)
  - (2026-08-31) У Бучанському районі вирує пожежа: киян попередили про можливе задимлення | LEDE: У Києві можливе задимлення через пожежу в Бучанському районі Київської області. За попередньою інформацією, зай] (uk:…
      У Києві можливе задимлення через пожежу в Бучанському районі Київської області. За попередньою інформацією, займання виникло внаслідок влучання у складські приміщення в Стоянці.
  - (2026-08-31) Ісландія визначилася з подальшими кроками після провалу референдуму щодо ЄС | LEDE: ] (uk: Ісландія визначилася з подальшими кроками після провалу референдуму щодо ЄС)
  - (2026-08-31) "Говорили рефреном" – Пєсков намагався переконати, що Путін і Сі майже не обговорювали війну проти України | LEDE: Пєсков хотів переконати, що Путін і Сі Цзіньпін майже не говорили про російськ] (uk:…
      Пєсков хотів переконати, що Путін і Сі Цзіньпін майже не говорили про російську війну проти України, але чомусь сказав, що "говорили рефреном"
  - (2026-08-31) Гроші, пільги та пропаганда: Як Кремль стимулює народжуваність росіян | LEDE: ] (uk: Гроші, пільги та пропаганда: Як Кремль стимулює народжуваність росіян)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-31) 424B2 - Morgan Stanley Finance LLC (0001666268) (Filer)
      filed 2026-08-31 14:40 UTC — Filed: 2026-08-31 AccNo: 0001839882-26-042554 Size: 499 KB
  - (2026-08-31) 424B2 - MORGAN STANLEY (0000895421) (Filer)
      filed 2026-08-31 14:40 UTC — Filed: 2026-08-31 AccNo: 0001839882-26-042554 Size: 499 KB
  - (2026-08-31) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-08-31 14:39 UTC — Filed: 2026-08-31 AccNo: 0001918704-26-025621 Size: 659 KB
  - (2026-08-31) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-08-31 14:39 UTC — Filed: 2026-08-31 AccNo: 0001918704-26-025621 Size: 659 KB
  - (2026-08-31) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-08-31 14:38 UTC — Filed: 2026-08-31 AccNo: 0000950103-26-013217 Size: 609 KB
  - (2026-08-31) [Tompkins Bonnie M] Form 4 (Reporting)
      filed 2026-08-31 14:37 UTC · role: Reporting — Filed: 2026-08-31 AccNo: 0001174947-26-000821 Size: 5 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 31 new of 56 total
  - (2026-08-31) [BleepingComputer] File servers are here to stay. Here’s how to manage them securely
      File servers remain a critical part of many IT environments, but managing access securely can become complex as permissions accumulate. tenfold Software outlines five best practices for simplifying file server administra…
  - (2026-08-31) [BleepingComputer] Berlin confirms data theft after Rhysida ransomware attack claims
      Berlin's city administration has confirmed that cybercriminals are attempting to extort the city after the Rhysida ransomware gang listed it on their data leak site. [...]
  - (2026-08-31) [BleepingComputer] Microsoft says Windows 11 KB5120998 update resets mouse settings
      Microsoft has confirmed that mouse settings are being reverted on Windows 11 systems after installing the KB5120998 August 2026 non-security preview update. [...]
  - (2026-08-31) [BleepingComputer] Nigerians extradited to US for sextortion, deaths of two teens
      Two Nigerian men extradited to the U.S. on Thursday have been charged with involvement in sextortion schemes that resulted in the deaths of two minor victims in Mississippi and North Carolina. [...]
  - (2026-08-31) [BleepingComputer] Microsoft asks users to ignore 'Antivirus is turned off' errors
      Microsoft asked customers this week to ignore alerts that Defender Antivirus has been turned off after installing the latest Defender updates. [...]
  - (2026-08-31) [The Hacker News] ⚡ Weekly Recap: Chinese Spy Proxy, AI Agents Go Off-Task, Router Backdoors and More
      The boring parts caused most of the trouble. A router shipped ready to listen. A fake check turned the user into the installer. Trusted systems collected traffic and passwords, then cleaned the logs. Old bugs formed new…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-31) JAF1TA (Bulgaria)
      icao24: 4520d0 · position: (39.7894, -4.4332) · alt: 10965m · 908km/h
  - (2026-08-31) PAT312 (United States)
      icao24: adfeda · position: (36.5338, -81.0596) · alt: 7917m · 486km/h
  - (2026-08-31) PAT372 (United States)
      icao24: adfe47 · position: (38.2942, -83.3318) · alt: 7924m · 463km/h
  - (2026-08-31) PAT458 (United States)
      icao24: adfe4a · position: (34.772, -82.47) · alt: 1173m · 375km/h
  - (2026-08-31) PAT574 (United States)
      icao24: adfec1 · position: (38.1674, -80.0907) · alt: 11277m · 723km/h
  - (2026-08-31) SAMU44 (France)
      icao24: 39ca84 · position: (47.1931, -1.5539) · alt: 220m · 135km/h

### Paper Trading Scorecard — 20 new of 128 total
  - (2026-08-31) [Polymarket] US-Iran Hormuz Agreement by September 30?
      This market will resolve to “Yes” if a diplomatic agreement between the United States and Iran over traffic in the strait of Hormuz is announced by the specified date, 11:59 PM ET. A diplomatic agreement refers to an off…
  - (2026-08-31) [Polymarket] Counter-Strike: 1WIN vs ex-RUBY (BO3) - Moscow Cyber Games European Qualifier Playoffs
      This market refers to the Counter-Strike Quarterfinal 4 match between 1WIN and ex-RUBY in the Moscow Cyber Games European Qualifier Playoffs, initially scheduled for August 31, 2026 at 11:00 AM ET. This market will resol…
  - (2026-08-31) [Manifold] Pangram say average feed <50% human by 1 March 2027?
  - (2026-08-31) [Manifold] Daily Coinflip
  - (2026-08-31) [Manifold] (FREE MANA???) Will I get demoted to Silver?
  - (2026-08-31) [Manifold] Rogue AIs before 2028?

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-08-31) Delaware Supreme Court: Great American Insurance Company v. Big V Capital LLC
  - (2026-08-31) U.S. Court of Appeals, Federal Cir.: Christensen v. United States
  - (2026-08-31) U.S. Court of Appeals, Federal Cir.: Estate of Paul Bruyea v. United States
  - (2026-08-31) U.S. Court of Appeals, Federal Cir.: Exelixis, Inc. v. Msn Laboratories Private Ltd.
  - (2026-08-31) U.S. Court of Appeals, Federal Cir.: Jadue v. Dhs
  - (2026-08-31) U.S. Court of Appeals, 2nd Cir.: Dolce v. Connetquot Cent. Sch. Dist.

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-08-31) Counter-Strike: G2 vs Aurora Gaming (BO3) - BLAST Open Porto Group A
      yes price: 92% · 24h volume: $1,617,457 · resolves 2026-08-31
  - (2026-08-31) US Open ATP: Thiago Agustin Tirante vs Adrian Mannarino
      yes price: 8% · 24h volume: $825,130 · resolves 2026-09-06
  - (2026-08-31) Will the U.S. invade Iran before 2027?
      yes price: 16% · 24h volume: $741,126 · resolves 2027-01-01
  - (2026-08-31) Will Arsenal FC win on 2026-08-31?
      yes price: 64% · 24h volume: $708,135 · resolves 2026-08-31
  - (2026-08-31) US Open ATP: Martin Landaluce vs Jacob Fearnley
      yes price: 70% · 24h volume: $646,206 · resolves 2026-09-06
  - (2026-08-31) Will FC Barcelona win on 2026-08-31?
      yes price: 88% · 24h volume: $589,460 · resolves 2026-08-31

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-08-31) M 5.5 - 44 km NNE of Ruteng, Indonesia
      M5.5 · 44 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-31) M 4.9 - 13 km SSE of Union, Philippines
      M4.9 · 13 km SSE of Union, Philippines · depth 83.891 km
  - (2026-08-31) M 4.7 - 3 km NW of Yanacancha, Peru
      M4.7 · 3 km NW of Yanacancha, Peru · depth 10 km
  - (2026-08-30) M 4.7 - 62 km SSE of Palca, Peru
      M4.7 · 62 km SSE of Palca, Peru · depth 102.036 km
  - (2026-08-31) M 4.6 - 28 km ESE of Kuril’sk, Russia
      M4.6 · 28 km ESE of Kuril’sk, Russia · depth 147.811 km
  - (2026-08-30) M 4.6 - 128 km N of Aksu, China
      M4.6 · 128 km N of Aksu, China · depth 10 km

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-31) [Marginal Revolution] AI and Employment: So Far, So Good
      In September 2023, the Census Bureau added questions about AI to its Business Trends and Outlook Survey. Census asked hundreds of thousands of businesses whether they had used AI in the previous two weeks to produce good…
  - (2026-08-31) [Marginal Revolution] Spain fact of the day
      CoverManager, an online platform that manages reservations for thousands of Spanish restaurants, reports that half the dinner bookings now are for before 9 p.m., compared with 27 percent a decade ago. TheFork, a similar…
  - (2026-08-31) [Marginal Revolution] Anthropomorphizing AI?
      I am very much opposed to the view that the AIs are sentient, or might be sentient. I view that as a category error, and the chances of it being true are vanishingly small. Nonetheless I largely side with Roon when he wr…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 22 total
  - (2026-08-28) CVE-2026-82078 · PaperCut NG/MF: PaperCut NG/MF Unsafe Reflection Vulnerability
      vendor: PaperCut · product: NG/MF · CISA remediation by 2026-09-11
  - (2026-08-28) CVE-2026-81578 · PaperCut NG/MF: PaperCut NG/MF Missing Authentication for Critical Function Vulnerability
      vendor: PaperCut · product: NG/MF · CISA remediation by 2026-09-11

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-31) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=27, 7d-median=27, 14d-median=24; carrying terms: management, service, action, proposed, certain, national, establish, public, regulatory, amends, safety, commercial
- state_bills: today=78, 7d-median=80, 14d-median=118; carrying terms: provisions, natural, relating, known, service, court, program, agencies, support, conditions, state, among
- state_news: today=278, 7d-median=648, 14d-median=632; carrying terms: round, social, allowed, voted, mexico, records, campus, kansas, across, season, changes, important
- local_news: today=196, 7d-median=249, 14d-median=243; carrying terms: season, court, injured, owner, shows, attachment, uploads, state, trial, following, county, stlmag
- foreign_news: today=1005, 7d-median=1027, 14d-median=1023; carrying terms: russia, plateau, suburban, suffered, coercive, seldom, debate, unocha, worker, offices, comprehensive, visited
- chinese_internal: today=276, 7d-median=289, 14d-median=289; carrying terms: cbmiakfvx, articles, cbmibkfvx, color, cbmibefvx, caixin, global, cbmizefvx, blank, https, cbmidefvx, cbmiykfvx
- russian_internal: today=924, 7d-median=1074, 14d-median=1066; carrying terms: novaya, social, truth, telegram, reuters, client, politico, journal, istories, gazeta, telegraph, forbidden
- ukrainian_internal: today=119, 7d-median=122, 14d-median=119; carrying terms: russia, regions, across, changes, drone, remains, service, injured, title, latest, independence, strikes
- ukraine_theater: today=911, 7d-median=236, 14d-median=834; carrying terms: russia, lrrgm, mskrwnwdxu, tofdjukjkewwzqvjnb, zawtku, jctexhsu, mlczuvbwyk, mglwau, armed, nfhtbw, polygons, appoints
- paper_bets: today=128, 7d-median=132, 14d-median=132; carrying terms: total, source, minnesota, resolution, general, virginia, democratic, midterms, pennsylvania, alaska, prime, andrew
- weather: today=103, 7d-median=133, 14d-median=143; carrying terms: southeast, gusts, tropical, health, precipitation, flood, aviation, inland, afddtx, temperatures, streams, children
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: openings, total, dexuseu, dexchus, jolts, vixcls, unrate, cpiaucsl, spread, recession, crude, supply
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: silver, agriculture, yield, bitcoin, nasdaq, large, crude, futures, rates, crypto, natural, equities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=108, 14d-median=102; carrying terms: venezuela, russia, contract, resolution, comments, space, bombing, zimbabwe, daesh, oblasts, engineering, enable
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, quantitative, unauthorized, quiverquant, client, httperror, error, congresstrading, https
- billionaires: today=0, 7d-median=0, 14d-median=30
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, california, appeals, delaware, america, county, connecticut, company, cisneros, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, holdings, group, financial, david, trust, finance, goldman, filer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, raised, lindsey, johnson, filing, disbursements, michael, shawn, ossoff, warner, jonathan, sherrod
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, keywords, russia, perimeter, sanctions, russian, ukrainian, trump, drone, indiatimes, strikes, attack
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: source, alerted, round, occur, kinshasa, noted, conflict, social, country, operator, unaffected, october
- cisa_kev: today=22, 7d-median=20, 14d-median=13; carrying terms: internet, broadcom, extensions, double, vcenter, project, macos, remediation, injection, microsoft, service, sharepoint
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=11, 7d-median=14, 14d-median=14; carrying terms: indonesia, depth, ruteng, islands, russia, south, philippines, china, kuril, guinea, papua
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, league, september, interest, rates, champions, price, donetsk, championship, resolves, august, meeting
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, economist, revolution, class, conversable, https, number, together, demand, shows, marginalrevolution, future
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: schneier, devices, across, computerweekly, companies, world, around, systems, technology, weekly, technica, hackers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: tillis, mccormick, liccardo, whitesides, suozzi, tuberville, schrier, kamlager, grace, blumenthal, gomez, health
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, markets, decision, market, claude, module, sufficient, paper, placement, consensus, converges, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*