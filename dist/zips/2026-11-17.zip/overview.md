# WORLDSCOPE morning brief — 2026-11-17

## Headline
3663 new items across 29 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (838) · Russian Internal News (state + in-exile) (731) · State-Level News (350) · World leaders & government officials (324) · Chinese Internal News (273) · Local News: St. Louis + Atlanta (228) · GDELT GKG — themes / entities / watch areas (133) · U.S. Weather + Severe / Climate Outlooks (125) · Ukraine Theater (total-war monitoring) (107) · World News (by country, top stories) (98) · Ukrainian Internal News (national + local Kyiv) (74) · GDACS — global disaster alerts (53)

## What changed today
### International News + Multilateral Institutions — 838 new of 974 total
  - (2026-11-17) [Global] Trump kicks off Asia tour ahead of major talks with Putin, Xi in China
      US President Donald Trump is flying into Manila for a Quad meeting before he takes off to China for a much anticipated meet with Russian and Chinese counterparts. Follow live.
  - (2026-11-17) [Global] Canada, China agree to ease tariffs amid trade rows with US
      The Canadian and Chinese leaders have vowed closer cooperation as both nations seek to reduce reliance on the US. Canada's government said it had agreed to further reduce tariffs on a range of products.
  - (2026-11-17) [Global] India news: Modi to attend ASEAN, Quad meet in Manila
      This is the first time Modi and US President Donald Trump are meeting since the US midterm elections, which changed the political scene in the US.
  - (2026-11-17) [Global] Mongolian President Khurelsukh to resign amid corruption allegations
      Khurelsukh has said he will step down over accusations that he profited from a government railway project, but said he had been "falsely accused."
  - (2026-11-17) [Global] Japan scrambles jets to counter suspected Russian aircraft
      Japan said it lodged a "very stern protest" with Moscow after two suspected Russian aircraft violated Japanese airspace.
  - (2026-11-17) [Global] Ukraine updates: Key bridges in Kyiv, Crimea hit in strikes
      Kyiv's mayor said Russian forces have hit bridges on the Dnipro River. Ukraine launched a massive attack on Russia earlier on Monday, hitting the Crimean Bridge. DW has the latest.

### Russian Internal News (state + in-exile) — 731 new of 947 total
  - (2026-11-17) Россия ударила по мостам в Киеве | LEDE: Вооруженные силы России в ночь на 17 ноября нанесли удары по мостам через Днепр в Киеве, движение по ним перекрыто, сообщили украинские власти. ] (ru: Россия у…
      Вооруженные силы России в ночь на 17 ноября нанесли удары по мостам через Днепр в Киеве, движение по ним перекрыто, сообщили украинские власти.
  - (2026-11-17) Война. 1728-й день. Украина нанесла новый удар по Крымскому мосту. Обрушилась одна из арок, движение по мосту остановлено | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-11-17) Каллас заявила, что разведка «очень легко» получит данные российских военных — чтобы запретить им въезд в ЕС. Володин пригрозил ей 20 годами тюрьмы | LEDE: В Евросоюзе продолжается обсуждени] (ru: Кал…
      В Евросоюзе продолжается обсуждение запрета на въезд для российских участников войны, и получить их данные было бы «очень легко», заявила глава евродипломатии Кая Каллас.
  - (2026-11-17) В Курске установили памятник северокорейским военным, участвовавшим в войне с Украиной на стороне России | LEDE: В Курске на улице Интернациональной поставили памятник северокорейским военны] (ru: В К…
      В Курске на улице Интернациональной поставили памятник северокорейским военным. Фото монумента, закрытого пленкой, опубликовало местное издание «Друг для друга». Памятник изготовлен Студией военных художников имени Греко…
  - (2026-11-17) Более 1400 украинских беспилотников атаковали Россию и Крым. В Башкортостане пожар на заводе «Газпрома» | LEDE: Украинские беспилотники атаковали промзоны Уфы и Салавата, сообщили в Госкомит] (ru: Бол…
      Украинские беспилотники атаковали промзоны Уфы и Салавата, сообщили в Госкомитете Башкортостана по чрезвычайным ситуациям.
  - (2026-11-17) Украина вновь атаковала Крымский мост. Обрушилась одна из арок | LEDE: В ночь на 17 ноября ВСУ вновь атаковали Крымский мост, сообщил назначенный Россией глава Крыма Сергей Аксенов. ] (ru: Украина вно…
      В ночь на 17 ноября ВСУ вновь атаковали Крымский мост, сообщил назначенный Россией глава Крыма Сергей Аксенов.

### State-Level News — 350 new of 412 total
  - (2026-11-16) [California] Governor Newsom cuts the cost of becoming a teacher with a new earn-and-learn pathway
      Source
  - (2026-11-16) [California] Exploring new frontiers: Governor Newsom welcomes the public to the opening of the Samuel Oschin Air and Space Center
      Source
  - (2026-11-16) [California] Standing on Ukrainian soil, Governor Newsom announces new lifesaving aid for the defenders of freedom
      Source
  - (2026-11-17) [Colorado] Trump volleys back to Congress in blame game over aviation ground stop
      President Donald Trump on Monday accused Congress of underfunding the nation’s aviation infrastructure, which he blamed for the weekend ground stop that caused thousands of canceled and delayed flights. But Democrats say…
  - (2026-11-16) [Colorado] States, cities move to ban cryptocurrency kiosks as scams mount
      States and cities across the country are cracking down on cryptocurrency kiosks as financial scams involving the ATM-like machines continue to mount, costing Americans nearly $389 million last year alone. Four states — I…
  - (2026-11-16) [Colorado] Defeated GOP Rep. Gabe Evans ditches Colorado battleground seat for safer 4th District in 2028
      For the second time in three years, a Colorado Republican member of Congress on the outs in their district is fleeing for the safety of the state’s most GOP-leaning seat. U.S. Rep. Gabe Evans, a Fort Lupton Republican, a…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 273 new of 315 total
  - (2026-11-16) ANVF Innovation 2026 - From Connectivity to Growth: ASEAN’s Next Chapter - Caixin Global
      ANVF Innovation 2026 - From Connectivity to Growth: ASEAN’s Next Chapter Caixin Global
  - (2026-11-16) Commentary: AI Is Speeding Up Workers, but Not Boosting the Bottom Line - Caixin Global
      Commentary: AI Is Speeding Up Workers, but Not Boosting the Bottom Line Caixin Global
  - (2026-11-16) Carmaker Seres Regains Aito Sales Control in Revised Huawei Partnership - Caixin Global
      Carmaker Seres Regains Aito Sales Control in Revised Huawei Partnership Caixin Global
  - (2026-11-17) CX Daily: The Promise and Risks of China’s AI Infrastructure Rush - Caixin Global
      CX Daily: The Promise and Risks of China’s AI Infrastructure Rush Caixin Global
  - (2026-11-16) Wingtech to Appeal Dutch Court Order in Nexperia Control Dispute - Caixin Global
      Wingtech to Appeal Dutch Court Order in Nexperia Control Dispute Caixin Global
  - (2026-11-17) Nearing AI Robotics Breakthrough Would Strain Production, Unitree Founder Says - Caixin Global
      Nearing AI Robotics Breakthrough Would Strain Production, Unitree Founder Says Caixin Global

### Local News: St. Louis + Atlanta — 228 new of 248 total
  - (2026-11-16) [St. Louis] Your ultimate guide to family-friendly holiday activities in St. Louis
      ‘Tis the season to be merry and bright with family and friends, and St. Louis has an activity for every person on your list. So get holiday hopping by adding a few of the below traditions to your calendar this year! Perf…
  - (2026-11-16) [St. Louis] Must-see holiday light displays in St. Louis
      There’s just something about seeing St. Louis dressed up in its twinkly best. Each year, we make a list of the prettiest holiday light displays, check it twice, pile into the car, and ooh and ahh at the megawatt marvels.…
  - (2026-11-16) [St. Louis] School board member Robert Harvey testifies that he just remembered where he lived in 2024
      Robert Harvey, a member of the Board of Education for the St. Louis Public Schools testified in court this morning about his residency in the city—and tried to explain the lack of documentation to support it. School boar…
  - (2026-11-16) [St. Louis] Hoffmann aims to buy Townsquare Media in bid to become nation’s biggest newspaper/radio station owner
      Missouri-born billionaire David Hoffmann already owns the St. Louis Post-Dispatch, radio station KMOX, and scores of other media entities, as well as a dairy, a ferry company and a yacht club. Today, the Hoffmann Family…
  - (2026-11-16) [St. Louis] Lou’s Clues – 11/16/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-11-16) [St. Louis] St. Louis Symphony Orchestra welcomes John Goodman, U.S. Naval Academy ensembles for Boyer’s ‘American Mosaic’
      There’s something Whitmanic in the way composer Peter Boyer describes the catalog of imagery, voices, and musical gestures that together make up American Mosaic—his 11-movement, multimedia work for symphony commemorating…

### GDELT GKG — themes / entities / watch areas — 133 new of 133 total
  - (2026-11-17) [Russia oil sanctions perimeter · themes] Ukraine updates: Key bridges in Kyiv, Crimea hit in strikes
      dw.com · English · tone -4.32203389830508 · 2 other outlets
  - (2026-11-17) [Russia oil sanctions perimeter · themes] Ukraine Invasion Day 1,727: denting the Kerch bridge, again.
      dailykos.com · English · tone -6.21621621621622
  - (2026-11-17) [Russia oil sanctions perimeter · themes] Russia says it intercepted over 1,300 Ukrainian drones Monday
      ckom.com · English · tone -5.77223088923557
  - (2026-11-17) [Russia oil sanctions perimeter · near] Russia, Ukraine exchange strikes on bridges ahead of Xi-Trump-Putin summit
      japantoday.com · English · tone -3.57634112792297 · 14 other outlets
  - (2026-11-17) [Russia oil sanctions perimeter · near] Live: Russian attacks target bridges in Kyiv, knocking out heating and water – Ya Libnan
      yalibnan.com · English · tone -5.1063829787234 · 7 other outlets
  - (2026-11-17) [Russia oil sanctions perimeter · near] Putin's Crimean bridge is 'seriously damaged' in second attack by Ukraine drones as section 'collapses into river'
      dailymail.com · English · tone -5.16304347826087 · 6 other outlets

### U.S. Weather + Severe / Climate Outlooks — 125 new of 127 total
  - (2026-11-17) [Moderate] Wind Advisory: Wind Advisory issued November 17 at 12:28AM PST until November 17 at 1:00PM PST by NWS Phoenix AZ
      * WHAT...West winds 20 to 30 mph with gusts up to 45 mph. * WHERE...Western Imperial County. * WHEN...Until 1 PM PST this afternoon. * IMPACTS...Difficult driving conditions, especially for larger vehicles traveling alon…
  - (2026-11-17) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-17) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 17 at 1:19AM MST until November 18 at 11:00AM MST by NWS Billings MT
      * WHAT...Snow and blowing snow expected. Total snow accumulations of 1 to 3 inches. Winds gusting as high as 45 mph. * WHERE...Judith Gap. * WHEN...From 2 PM this afternoon to 11 AM MST Wednesday. * IMPACTS...Plan on pot…
  - (2026-11-17) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 17 at 1:19AM MST until November 18 at 11:00AM MST by NWS Billings MT
      * WHAT...Snow expected. Total snow accumulations between 1 and 3 inches. * WHERE...Livingston Area, Northern Park, and Paradise Valley. * WHEN...From 2 PM this afternoon to 11 AM MST Wednesday. * IMPACTS...Plan on potent…
  - (2026-11-17) [Moderate] Special Weather Statement: Special Weather Statement issued November 17 at 3:00AM EST by NWS Jackson KY
      At 300 AM EST, Satellite imagery is starting to indicate a potential for patchy dense freezing fog near the larger rivers and lakes. This could lead to slick spots on area roads, particularly bridges and overpasses along…
  - (2026-11-17) [Moderate] Special Weather Statement: Special Weather Statement issued November 17 at 2:59AM EST by NWS Charleston WV
      Areas of dense fog has formed in many of the river and mountain valleys this morning. Visibility will be restricted with any fog and could be as low as half a mile or less in spots. Temperatures are forecast to plummet i…

### Ukraine Theater (total-war monitoring) — 107 new of 279 total
  - (2026-11-17) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-16) [Liveuamap] Klitschko: Preliminary reports indicate that the North and South bridges in Kyiv have been hit – Kyiv, Kyiv city - Liveuamap
      Klitschko: Preliminary reports indicate that the North and South bridges in Kyiv have been hit – Kyiv, Kyiv city <
  - (2026-11-15) [Liveuamap] Power blackout in Kamianske as result of Russian attacks - Liveuamap
      Power blackout in Kamianske as result of Russian attacks Liveuamap
  - (2026-11-16) [Liveuamap] Defense Ministry: Colonel &039;Onad al-Darwish… - Liveuamap
      Defense Ministry: Colonel &039;Onad al-Darwish… Liveuamap
  - (2016-04-29) [Liveuamap] Epidemics live map: outbreaks today | Liveuamap - Liveuamap
      Epidemics live map: outbreaks today | Liveuamap Liveuamap
  - (2026-11-17) [Liveuamap] Three UAE convoys deliver winter clothing to Gaza under Operation Chivalrous Knight 3 – Rafah, Gaza - Liveuamap
      Three UAE convoys deliver winter clothing to Gaza under Operation Chivalrous Knight 3 – Rafah, Gaza &n

### World News (by country, top stories) — 98 new of 98 total
  - (2026-11-17) [Brazil] 'Brazil No Longer Lives In A Full Democracy': Self-Exiled Flávio Bolsonaro Plans To Stay In US
      zerohedge.com · English
  - (2026-11-17) [Brazil] US tightens AI chip exports to data centres in SEA and Brazil
      developingtelecoms.com · English
  - (2026-11-17) [Brazil] Mercy For Animals, Inc.: As COP31 turns to implementation, international assessment finds Brazil shows progress on food and climate
      finanznachrichten.de · English
  - (2026-11-17) [Brazil] European-made pesticides named in 1,605 poisoning reports in Brazil last year
      theguardian.com · English
  - (2026-11-17) [Brazil] Brazil's Lula And Spain's Sánchez Call For Unity Against Rise Of Far Right
      eurasiareview.com · English
  - (2026-11-17) [Brazil] Brazil Federal Police Find Hidden Cash During Bahia Raids as Pix Amendment Scandal Reaches a Lawmaker's Family
      latintimes.com · English

### Ukrainian Internal News (national + local Kyiv) — 74 new of 116 total
  - (2026-11-17) У Києві внаслідок російської атаки загинули 2 людини | LEDE: Дві людини загинули та ще одна постраждала внаслідок російського дару по Києву 17 листопада.] (uk: У Києві внаслідок російської атаки загин…
      Дві людини загинули та ще одна постраждала внаслідок російського дару по Києву 17 листопада.
  - (2026-11-17) Німеччина оголосила про спільний з Норвегією пакет на закупівлю ракет до Patriot для України | LEDE: Німеччина і Норвегія профінансують пакет військової допомоги для України в межах PURL, зокре] (uk:…
      Німеччина і Норвегія профінансують пакет військової допомоги для України в межах PURL, зокрема закупівлю ракет PAC-2, PAC-3 та нових РЛС.
  - (2026-11-17) Росіяни атакували промоб’єкти у Запоріжжі: 2 загиблих, 18 поранених | LEDE: Дві людини загинули та ще 18 постраждали внаслідок російських ударів по промислових об'єктах у Запоріжжі вранці 17 ли] (uk:…
      Дві людини загинули та ще 18 постраждали внаслідок російських ударів по промислових об'єктах у Запоріжжі вранці 17 листопада.
  - (2026-11-17) Президент Фінляндії не знає, чи стане Україна членом НАТО | LEDE: ] (uk: Президент Фінляндії не знає, чи стане Україна членом НАТО)
  - (2026-11-17) Кількість жертв атаки на Чернігів зросла до трьох осіб – ОВА | LEDE: Кількість загиблих через російську атаку безпілотниками 16 листопада у вівторок зросла до трьох осіб: у лікарні помер чолові] (uk:…
      Кількість загиблих через російську атаку безпілотниками 16 листопада у вівторок зросла до трьох осіб: у лікарні помер чоловік, що дістав поранень.
  - (2026-11-17) Росіяни атакували Одещину – пошкодили об’єкт енергетики, склади і гуртожиток, постраждала людина | LEDE: Внаслідок атаки по Одеській області постраждала одна людина, є руйнування енергооб'єкта ] (uk:…
      Внаслідок атаки по Одеській області постраждала одна людина, є руйнування енергооб'єкта ДТЕК та інших споруд. Частина жителів 2 міст залишилась без світла.

### GDACS — global disaster alerts — 53 new of 100 total
  - (2026-11-16) [Orange] Tropical Cyclone AKVAN-26
      Tropical Cyclone · Orange alert · India · Tropical Storm (maximum wind speed of 102 km/h)
  - (2026-11-17) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.9M, Depth:126.959km
  - (2026-11-17) [Green] Earthquake in Solomon Islands
      Earthquake · Green alert · Solomon Islands · Magnitude 5M, Depth:10km
  - (2026-11-15) [Green] Flood in South Africa
      Flood · Green alert · South Africa · Magnitude 0
  - (2026-11-15) [Green] Flood in Spain
      Flood · Green alert · Spain · Magnitude 0
  - (2026-10-24) [Green] Flood in Indonesia
      Flood · Green alert · Indonesia · Magnitude 0

### IT, InfoSys & cybersecurity news (last 7 days) — 48 new of 63 total
  - (2026-11-18) [The Record] Uber says nearly 150,000 impacted by third-party breach
      In breach notification letters, the rideshare company said it was notified by a third party service provider on October 9 that internal credentials were stolen and used to access Uber’s account.
  - (2026-11-17) [BleepingComputer] Ransomware affiliate suspect extradited to US, faces 27 years in prison
      A Kazakh national has been extradited from Italy to face charges alleging he targeted US schools, hospitals, and healthcare entities in ransomware attacks. [...]
  - (2026-11-17) [BleepingComputer] Optimizely hack infected CNN, Fox News, BBC, Salesforce sites with malware
      A suspected supply chain attack targeting Optimizely has led to malicious JavaScript being loaded on numerous popular websites, including Zoom, CNN, Fox News, BBC, Salesforce, and GitLab, exposing visitors to scripts des…
  - (2026-11-17) [The Hacker News] Hijacked Optimizely Scripts Served Card Skimmer and iOS Exploit Kits to CNN, BBC and Zoom Visitors
      An attacker exploited a flaw in Optimizely Web Experimentation to plant malicious code in some of the scripts that customers' websites load from the service, Optimizely said early today. Visitors to sites run by at least…
  - (2026-11-17) [The Hacker News] ConnectWise Warns ScreenConnect Attacks Continue as SCKit Targets Unpatched Systems
      ConnectWise on Monday said it completed its investigation into unauthorized access targeting partner ScreenConnect environments, and recommended customers to ensure that the technician client is running version 26.6.5 or…
  - (2026-11-17) [The Hacker News] N-able Patches 17 N-central Flaws as Attackers Exploit Earlier Bugs to Deploy Crypto Miners
      N-able has released a new security update to address additional critical security flaws impacting N-central. Describing N-central 2026.4 Hotfix 3 as a critical security update, the company said it includes a number of se…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-17) [LEE CHAE] Form 4 (Reporting)
      filed 2026-11-17 02:54 UTC · role: Reporting — Filed: 2026-11-16 AccNo: 0001193125-26-464325 Size: 11 KB
  - (2026-11-17) [MAGNACHIP SEMICONDUCTOR Corp] Form 4 (Issuer)
      filed 2026-11-17 02:54 UTC · role: Issuer — Filed: 2026-11-16 AccNo: 0001193125-26-464325 Size: 11 KB
  - (2026-11-17) [Ong Chin Yin] Form 4 (Reporting)
      filed 2026-11-17 02:52 UTC · role: Reporting — Filed: 2026-11-16 AccNo: 0001990865-26-000018 Size: 4 KB
  - (2026-11-17) [Grab Holdings Ltd] Form 4 (Issuer)
      filed 2026-11-17 02:52 UTC · role: Issuer — Filed: 2026-11-16 AccNo: 0001990865-26-000018 Size: 4 KB
  - (2026-11-17) [Grab Holdings Ltd] Form 4 (Issuer)
      filed 2026-11-17 02:52 UTC · role: Issuer — Filed: 2026-11-16 AccNo: 0001855612-26-000157 Size: 7 KB
  - (2026-11-17) [Kandal Philipp Wolfgang Josef] Form 4 (Reporting)
      filed 2026-11-17 02:52 UTC · role: Reporting — Filed: 2026-11-16 AccNo: 0001855612-26-000157 Size: 7 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-17) [Iran] Third US aircraft carrier arrives in the Middle East as Trump keeps options open in the Iran war
      domain: asiaone.com · language: English · tone: -3.81773399014778 · 81 other outlets ran this story
  - (2026-11-17) [United States] The Latest: Trump says he plans to talk about war in Ukraine during meeting with Xi and Putin
      domain: wfmj.com · language: English · tone: -2.15252152521525 · 75 other outlets ran this story
  - (2026-11-17) [United States] One dead, one seriously injured in three-vehicle fatal crash on Highway 101 near Warrenton
      domain: katu.com · language: English · tone: -4.37158469945355 · 61 other outlets ran this story
  - (2026-11-17) [United States] US warns citizens travelling in Europe of terror risks at Christmas markets, crowded public places
      domain: moneycontrol.com · language: English · tone: -1.30890052356021 · 57 other outlets ran this story
  - (2026-11-17) [Iran] Anon Intel Officials: Iran Could Detonate Dirty Bomb Or Chemical Weapon In D.C.
      domain: zerohedge.com · language: English · tone: -3.6986301369863 · 55 other outlets ran this story
  - (2026-11-17) [Ireland] Robert Pattinson Is Officially The New James Bond, And People Can't Stop Making Memes About It
      domain: boredpanda.com · language: English · tone: 1.88679245283019 · 54 other outlets ran this story

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 22 new of 78 total
  - (2026-11-17) [Polymarket] Will Bitcoin dip to $30,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "Low" price equal to or low…
  - (2026-11-17) [Manifold] Daily Coinflip
  - (2026-11-17) [Manifold] Will a G20 country hold a referendum on ASI by the end of January 2027?
  - (2026-11-17) [Manifold] Will eng 1 aac have a reading check before thanksgiving break
  - (2026-11-17) [Manifold] will i reach Master before 2027?
  - (2026-11-17) [Manifold] Will a new prize drawing be opened before EOY 2026?

### Government & military aircraft airborne (OpenSky) — 22 new of 22 total
  - (2026-11-17) GAF289 (Germany)
      icao24: 3e8b41 · position: (44.704, 12.6456) · alt: 9441m · 835km/h
  - (2026-11-17) PAT322 (United States)
      icao24: adfe51 · position: (38.7129, -77.1804) · on ground
  - (2026-11-17) CNA11 (Spain)
      icao24: 3475ca · position: (28.4794, -16.3542) · alt: 640m · 140km/h
  - (2026-11-17) SAMU13 (France)
      icao24: 39c90b · position: (43.3807, 5.3615) · alt: 320m · 25km/h
  - (2026-11-17) FNY55C4 (France)
      icao24: 39a408 · position: (48.5297, -4.1444) · on ground · 35km/h
  - (2026-11-17) JAF4GM (Belgium)
      icao24: 44d1a6 · position: (36.6581, 25.09) · alt: 11277m · 896km/h

### Wikidata leader-roster changes (48h) — 19 new of 46 total
  - (2026-11-17) [Brazil] Luiz Inácio Lula da Silva (Q37181) edited
      /* wbmergeitems-from:0||Q142182739 */ same entity
  - (2026-11-17) [Lithuania] Gitanas Nausėda (Q9268379) edited
      /* wbsetclaim-update:2||1|1 */ [[Property:P166]]: [[Q23058339]]
  - (2026-11-17) [Saudi Arabia] Salman bin Abdulaziz Al Saud (Q367825) edited
      /* wbsetdescription-add:1|te */ 2015 నుండి సౌదీ అరేబియా రాజు, ([[w:en:Wikipedia:Shortdesc helper|Shortdesc helper]])
  - (2026-11-17) [Senegal] Bassirou Diomaye Faye (Q124382437) edited
      /* wbsetclaim-update:2||1|1 */ [[Property:P462]]: [[Q39338]]
  - (2026-11-17) [Tanzania] Samia Suluhu Hassan (Q16193885) edited
      /* wbsetsitelink-add:1|idwikiquote */ Samia Suluhu Hassan
  - (2026-11-17) [Kingdom of Denmark] Mette Frederiksen (Q5015) edited
      /* wbsetsitelink-add:1|idwikiquote */ Mette Frederiksen

### U.S. Federal Action — 17 new of 17 total
  - (2026-11-17) Safety Zone; Monongahela River, Pittsburgh, PA
      The Coast Guard is establishing a temporary safety zone for navigable waters on the Monongahela River from Mile Marker 15 to Mile Marker 16. This safety zone is necessary to protect personnel and vessels from potential h…
  - (2026-11-17) Protecting Consumers From SIM-Swap and Port-Out Fraud
      In this document, the Wireline Competition Bureau (Bureau) announces that the Office of Management and Budget (OMB) has approved, for a period of three years, the information collection associated with the Commission's r…
  - (2026-11-17) Modernizing to Electronic Payments
      FAA proposes to modernize its payment systems to require electronic payments and eliminate the option to pay by paper payment methods such as cash, money orders, and paper checks. This proposal complies with Executive Or…
  - (2026-11-17) Chartering and Field of Membership for Federal Credit Unions; Associational Common Bonds and Client-Customer Relationships
      The NCUA Board (Board) is issuing a final rule to amend its criteria for determining associational common bonds. The amendments clarify that requiring members to buy a good, product, or service from a group as a conditio…
  - (2026-11-17) Respirable Crystalline Silica and Respiratory Protection
      The Mine Safety and Health Administration (MSHA) is correcting an error in the "Respirable Crystalline Silica and Respiratory Protection" proposed rule that was published in the Federal Register on November 12, 2026. The…
  - (2026-11-17) Modernizing the Commission's National Environmental Policy Act Rules
      In this document (Order), the Federal Communications Commission ("Commission" or "FCC") takes action to cut through outdated and unnecessary burdens that have slowed deployment of critical communications networks. These…

### Court opinions of consequence (federal & state) — 17 new of 60 total
  - (2026-11-16) U.S. Court of Appeals, 6th Cir.: Ford Motor Co. v. InterMotive, Inc.
  - (2026-11-16) U.S. Court of Appeals, 3rd Cir.: Holy Trinity Ukrainian Catholic Church v. Township of Collier
  - (2026-11-16) U.S. Court of International Trade: Kaptan Demir Çelik Endüstrisi ve Ticaret A.S. v. United States
  - (2026-11-16) U.S. Court of Appeals, Federal Cir.: Traxcell Technologies, LLC v. Cellco Partnership
  - (2026-11-16) U.S. Court of Appeals, 2nd Cir.: Prophete v. Acevedo-Smith
  - (2026-11-16) U.S. Court of Appeals, 2nd Cir.: Warrick v. Bedard

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-15) [FRQ] MCGUIRE VICTORY FUND
      cycle 2026 · filing #
  - (2026-11-15) [F99] (unknown)
      cycle 2026 · filing #2047879
  - (2026-11-15) [F99] (unknown)
      cycle 2026 · filing #2047871
  - (2026-11-15) [F3] DYLAN FOR ILLINOIS
      cycle 2026 · filing #2047803 · receipts $0.00M
  - (2026-11-15) [F3] DYLAN FOR ILLINOIS
      cycle 2026 · filing #2047802 · receipts $0.04M
  - (2026-11-15) [F99] (unknown)
      cycle 2026 · filing #2047773

### State Legislative Action — 14 new of 14 total
  - (2026-11-17) [Delaware HB 242] AN ACT RELATING TO LOCAL SCHOOL TAXES IN THE 2025-2026 TAX YEAR.
      This Act allows any school district located in New Castle County to reset its tax rates for the 2025-2026 tax year and to reissue a tax warrant using different residential and non-residential tax rates. The non-residenti…
  - (2026-11-16) [Delaware SB 355] AN ACT TO AMEND TITLE 29 OF THE DELAWARE CODE RELATING TO THE FREEDOM OF INFORMATION ACT.
      With a commitment to transparency and engagement with interested Delawareans, including journalists whose work is essential to the realization of America's promise, the sponsors file this Act at the end of the 153rd Gene…
  - (2026-11-17) [District of Columbia B 26-0624] Elizabeth M. Goodman Health School Redesignation Act of 2026
      Elizabeth M. Goodman Health School Redesignation Act of 2026
  - (2026-11-17) [District of Columbia B 26-0835] Supporting Survivors of Domestic Violence and Abuse Amendment Act of 2026
      Supporting Survivors of Domestic Violence and Abuse Amendment Act of 2026
  - (2026-11-17) [District of Columbia B 26-0603] Body-Worn Camera Transparency for Use of Force Amendment Act of 2026
      Body-Worn Camera Transparency for Use of Force Amendment Act of 2026
  - (2026-11-17) [District of Columbia B 26-0689] Closing of a Portion of a Public Alley in Square 785, S.O. 21-03369, Act of 2026
      Closing of a Portion of a Public Alley in Square 785, S.O. 21-03369, Act of 2026

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-11-17) Will Anthropic's market cap be less than $1.25T at market close on IPO day?
      yes price: 37% · 24h volume: $363,903 · resolves 2028-01-01
  - (2026-11-17) Will there be no change in Fed interest rates after the December 2026 meeting?
      yes price: 3% · 24h volume: $322,895 · resolves 2026-12-09
  - (2026-11-17) Will Scott Colom win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $306,422 · resolves 2028-11-07
  - (2026-11-17) Will the Fed increase interest rates by 50+ bps after the December 2026 meeting?
      yes price: 5% · 24h volume: $296,296 · resolves 2026-12-09
  - (2026-11-17) Counter-Strike: magic vs Heroic (BO3) - PGL Cluj-Napoca: Closed Qualifier Playoffs
      yes price: 42% · 24h volume: $281,837 · resolves 2026-11-17
  - (2026-11-17) Will the Fed decrease interest rates by 50+ bps after the December 2026 meeting?
      yes price: 0% · 24h volume: $244,181 · resolves 2026-12-09

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-11-16) M 6.6 - 148 km WSW of Tual, Indonesia
      M6.6 · 148 km WSW of Tual, Indonesia · depth 68 km
  - (2026-11-16) M 5.4 - 95 km WSW of Changuillo, Peru
      M5.4 · 95 km WSW of Changuillo, Peru · depth 10 km
  - (2026-11-17) M 5.0 - 137 km SSE of Kirakira, Solomon Islands
      M5.0 · 137 km SSE of Kirakira, Solomon Islands · depth 10 km
  - (2026-11-17) M 4.9 - 26 km E of Port-Olry, Vanuatu
      M4.9 · 26 km E of Port-Olry, Vanuatu · depth 126.959 km
  - (2026-11-16) M 4.8 - 28 km SW of Changuillo, Peru
      M4.8 · 28 km SW of Changuillo, Peru · depth 39.085 km
  - (2026-11-16) M 4.8 - 166 km N of Caluula, Somalia
      M4.8 · 166 km N of Caluula, Somalia · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-11-17) MOVER ▼ Elon Musk — $874.06B ($-13.10B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-11-17) MOVER ▼ Michael Dell — $199.14B ($-9.31B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-11-17) MOVER ▼ Larry Page — $235.44B ($-9.09B since yesterday)
      United States · Technology · source: Google
  - (2026-11-17) MOVER ▼ Sergey Brin — $216.75B ($-8.35B since yesterday)
      United States · Technology · source: Google
  - (2026-11-17) MOVER ▼ Jeff Bezos — $376.70B ($-7.88B since yesterday)
      United States · Technology · source: Amazon
  - (2026-11-17) MOVER ▼ Larry Ellison — $158.28B ($-7.23B since yesterday)
      United States · Technology · source: Oracle

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 96 total
  - (2026-11-17) [BIS Entity List] page checksum fed7ca88291a
      Page content hash: fed7ca88291a. Compare with prior day's hash to detect updates.
  - (2026-11-17) [USASpending] $210,650,842 → NELNET SERVICING LLC: OPERATIONS AND MAINTENANCE (O&M) TASK ORDER FOR STUDENT LOAN
      Agency: Department of Education. Description: OPERATIONS AND MAINTENANCE (O&M) TASK ORDER FOR STUDENT LOAN SERVICING IN ACCORDANCE WITH THE REQUIREMENTS OF THE USDS CONTRACT. ALL WORK AND DELIVERABLES PROVIDED BY THE USD…
  - (2026-11-17) [USASpending] $208,572,279 → A SQUARE GROUP LLC: NITAAC CIO-SP3 SMALL BUSINESS TASK ORDER OF RE-COMPETED WMS
      Agency: Department of Health and Human Services. Description: NITAAC CIO-SP3 SMALL BUSINESS TASK ORDER OF RE-COMPETED WMS REQUIREMENT
  - (2026-11-17) [USASpending] $198,221,173 → DLH, LLC: IGF::CT::IGF OFFICE OF HEAD START (OHS) MONITORING SYSTEM
      Agency: Department of Health and Human Services. Description: IGF::CT::IGF OFFICE OF HEAD START (OHS) MONITORING SYSTEM
  - (2026-11-17) [USASpending] $194,514,277 → LOCKHEED MARTIN CORPORATION: INTERFACE REGION IMAGING SPECTROGRAPH (IRIS). THE CONTRACTOR
      Agency: National Aeronautics and Space Administration. Description: INTERFACE REGION IMAGING SPECTROGRAPH (IRIS). THE CONTRACTOR SHALL REFINE AND EVOLVE THE CONTRACTOR'S COST ESTIMATE FOR PHASES B-F FOR THE INTERFACE REG…
  - (2026-11-17) [USASpending] $174,180,619 → BOOZ ALLEN HAMILTON INC: BENEFITS ENTERPRISE SERVICES
      Agency: Department of Veterans Affairs. Description: BENEFITS ENTERPRISE SERVICES

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-11-17) [Marginal Revolution] Adlerlicht, reporting on crime in Germany
      In both German and English. Built with AI agents, we are going to see much more of this kind of effort. English-language explainer is here. The post Adlerlicht, reporting on crime in Germany appeared first on Marginal RE…
  - (2026-11-17) [Marginal Revolution] The economics of Jensen Huang
      Most of my assessment is very positive, but I will excerpt this bit from my latest Free Press piece: Finally, the company was not built to withstand Huang’s departure. Too much authority and knowledge were concentrated i…
  - (2026-11-16) [Marginal Revolution] Monday assorted links
      1. Some Henry Oliver book reviews. 2. Washington Monthly’s The Reader, book reviews. And High Line, a new publishing house for disfavored books. 3. Inflation-indexed bonds around the world. 4. Garett Jones on Richard Pos…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-17) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=21, 14d-median=25; carrying terms: standards, published, safety, directive, protection, regulatory, service, certain, proposes, applicable, agency, issued
- state_bills: today=14, 7d-median=78, 14d-median=78; carrying terms: health, authority, reporting, relating, commission, including, public, school, rates, state, local, business
- state_news: today=412, 7d-median=717, 14d-median=675; carrying terms: published, calmatters, island, letter, shows, military, reform, being, commonwealthbeacon, attorney, hawaii, serve
- local_news: today=248, 7d-median=266, 14d-median=256; carrying terms: accused, killed, being, downtown, county, night, trump, football, november, cbmigafbvv, early, democrats
- foreign_news: today=974, 7d-median=977, 14d-median=992; carrying terms: accused, defence, loses, killed, bound, premiumtimesng, threatens, reform, towards, province, being, domestic
- chinese_internal: today=315, 7d-median=319, 14d-median=321; carrying terms: investors, cbmiw, cbmib, cbmidefvx, cbmix, lxtfb, global, cbmizkfvx, market, china, google, cbmizefvx
- russian_internal: today=947, 7d-median=947, 14d-median=946; carrying terms: europe, https, axios, raquo, laquo, istories, street, telegram, media, gazeta, times, found
- ukrainian_internal: today=116, 7d-median=129, 14d-median=134; carrying terms: damaged, white, killed, military, forbidden, facilities, critical, dhabi, ballistic, ministry, president, international
- ukraine_theater: today=279, 7d-median=271, 14d-median=271; carrying terms: zexcxnxjkmwpuug, defence, rdmhbrxdhdf, ukfwvkpaugfjavrnevhfdffrvvvdvwt, killed, zrmwjrz, riswdlos, zosjnyatnxduxmd, ngpyqk, wllxrtzunmhwoxfobdhyrwdqzefmszuteenqnw, military, xwfvusuj
- paper_bets: today=78, 7d-median=75, 14d-median=71; carrying terms: leaders, riemann, become, fusion, hypothesis, problem, playoff, goldman, november, rushing, mamdani, miles
- weather: today=127, 7d-median=127, 14d-median=127; carrying terms: southeast, conditions, island, afdilx, until, discussion, atlantic, oxnard, below, visibility, morning, forecast
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: growth, implied, openings, crude, latest, personal, payrolls, energy, treasury, payems, dcoilwtico, walcl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, corporate, russell, credit, bitcoin, yield, china, commodities, crude, agriculture, close, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=96, 7d-median=100, 14d-median=99; carrying terms: designations, transactions, square, cbmixkfvx, maintenance, usaspending, claims, resolutions, sanctions, sovereignty, protests, support
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, client, quiver, unauthorized, quantitative, https, congresstrading, quiverquant, error
- billionaires: today=40, 7d-median=34, 14d-median=0; carrying terms: adani, finance, giancarlo, jensen, family, telecom, gates, berkshire, shanghai, ortega, shanshan, cryptocurrency
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, appeals, court, delaware, company, international, blanche, state, trade, thomas, corporation, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, holdings, william, joseph, capital, management, technologies
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: jackson, ossoff, david, cycle, filing, booker, talarico, jonathan, raised, senate, james, peltola
- gdelt_regions: today=98, 7d-median=98, 14d-median=97; carrying terms: english, trump, japan, korea, south, russia, nvidia, million, turkey, china, germany, korean
- gdelt_gkg: today=133, 7d-median=118, 14d-median=27; carrying terms: english, sanctions, russian, perimeter, russia, trump, themes, keywords, israel, hezbollah, netanyahu, strikes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=0; carrying terms: killed, language, english, australia, trump, domain, suspect, police, shooting, murder, israel, collapse
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=22, 14d-median=25; carrying terms: position, belgium, france, germany, kingdom, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: broader, prevention, imported, batches, hondius, followed, uganda, interconnected, internationally, published, according, generation
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: value, missing, return, remediation, authentication, google, product, critical, vendor, cisco, vulnerability, toctou
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=46, 7d-median=54, 14d-median=0; carrying terms: wbsetdescription, kingdom, short, edited, property, republic, democratic, wbsetaliases, people, languages, import, remove
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: forest, wildfire, sudan, depth, botswana, earthquake, impact, magnitude, alert, fires, forestfire, south
- usgs_quakes: today=11, 7d-median=11, 14d-median=11; carrying terms: depth, islands, japan, indonesia, papua, russia, guinea, vanuatu, solomon, kavieng
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, presidential, resolves, volume, donetsk, november, championship, shakhtar, champions, league, nomination, december
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: class, https, conversable, revolution, economist, marginal, world, challenges, conversableeconomist, around, economic, marginalrevolution
- tech_news: today=63, 7d-median=63, 14d-median=62; carrying terms: remote, information, agents, devices, intelligence, critical, review, newsletter, computerweekly, company, targeting, cloud
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: stephanie, reserve, clyde, bentz, rulli, ernst, mentions, harder, courtney, commission, neguse, finstad
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, claude, either, unavailable, market, placed, paper, placement, sufficient, evidence, module, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] ECB press: Boris Vujčić: Risks and resilience in the euro area financial system
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*