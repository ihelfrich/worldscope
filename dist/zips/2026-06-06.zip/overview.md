# WORLDSCOPE morning brief — 2026-06-06

## Headline
2304 new items across 25 active section(s) (of 41 tracked).

## Top movers today
International News + Multilateral Institutions (417) · Russian Internal News (state + in-exile) (405) · World leaders & government officials (324) · Chinese Internal News (193) · U.S. Weather + Severe / Climate Outlooks (162) · GDELT GKG — themes / entities / watch areas (127) · Local News: St. Louis + Atlanta (120) · Ukraine Theater (total-war monitoring) (110) · State-Level News (79) · State Legislative Action (76) · Congressional STOCK Act Trades (House + Senate) (50) · Ukrainian Internal News (national + local Kyiv) (45)

## What changed today
### International News + Multilateral Institutions — 417 new of 902 total
  - (2026-06-06) [Global] Ebola spread in central Africa could match 2014 record outbreak, US health officials say
  - (2026-06-06) [Global] Aviation industry looks skywards as leaders fly in for Rio summit
  - (2026-06-06) [Global] Man dies after shark attack off Western Australia coast near Albany
  - (2026-06-06) [Global] Australian snow season begins amid El Niño fears
  - (2026-06-06) [Global] Doctor’s ‘grossly irresponsible prescribing’ played direct role in two deaths, Tasmanian coroner finds
  - (2026-06-06) [Global] Regrettable references and claims of ‘rigged’ election laws: why this week has reignited Jacinta Allan spill rumours

### Russian Internal News (state + in-exile) — 405 new of 1061 total
  - (2026-06-06) Минцифры России начало переговоры с Apple о возврате «Макса» в App Store | LEDE: Власти РФ начали переговоры с компанией Apple о возврате мессенджера «Макс» в магазин приложений App Store, с] (ru: Мин…
      Власти РФ начали переговоры с компанией Apple о возврате мессенджера «Макс» в магазин приложений App Store, сообщил глава Минцифры Максут Шадаев на Международном экономическом форуме в Петербурге.
  - (2026-06-06) Петербург пережил ПМЭФ, а вместе с ним — атаки украинских дронов. Журналистов попросили не писать о вечеринках и работницах эскорта, чтобы «не злить народ». Иностранным гостям закупили подписки] (ru:…
      Когда-то Петербургский экономический форум был статусным мероприятием, куда приезжали иностранные инвесторы и высокопоставленные спикеры со всего мира. Но в 2026-м все внимание приковано к одиозным блогерам, а презентаци…
  - (2026-06-06) The Art Newspaper Russia и «Би-би-си» выяснили подробности о поддельных скульптурах Эрнста Неизвестного. Вопросов стало еще больше: одни источники говорят, что в Третьяковке выставили явные фал] (ru:…
      29 мая в Следственном комитете России рассказали о группе фальсификаторов, которая подделывает работы знаменитого советско-американского скульптора Эрнста Неизвестного. Единственным обвиняемым, чье имя было названо, стал…
  - (2026-06-06) В самопровозглашенной ЛНР запретили пассажирские перевозки по трассе «Новороссия» и отменили пригородные поезда | LEDE: В самопровозглашенной ЛНР запретили пассажирские перевозки на трассе «] (ru: В с…
      В самопровозглашенной ЛНР запретили пассажирские перевозки на трассе «Новороссия», идущей через территорию региона из Ростова-на-Дону в Симферополь. Соответствующий указ подписал глава региона Леонид Пасечник.
  - (2026-06-06) Еврокомиссия пообещала ужесточить правила выдачи виз россиянам. Этого добивались 11 стран Шенгенской зоны | LEDE: Еврокомиссия пообещала ужесточить выдачу виз российским гражданам — после то] (ru: Евр…
      Еврокомиссия пообещала ужесточить выдачу виз российским гражданам — после того, как это потребовали сделать 11 стран Шенгенской зоны, сообщает Euronews.
  - (2026-06-06) Такого Человека-паука у нас еще не было. Вышел сериал, в котором супергероя играет Николас Кейдж. Это нуар о разочарованном следователе, а если брать шире — о травмах Первой мировой | LEDE: ] (ru: Так…
      На стриминге Prime вышел сериал «Человек-паук Нуар» (Spider Noir). Это предельно далекое от марвеловской киновселенной произведение: следователя в Нью-Йорке 1930-х роднит с привычным Питером Паркером разве что паутина (и…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 193 new of 263 total
  - (2026-06-05) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5MaTAycGlDMjVZcFFnVUZxbXJYT05kc1hXWk1fR2x6Q01HaVZ5UmdIRWFreDduN1hpaWkydG4wN0txaEtWQno1cTgwZzBZbj] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-06-06) 时隔24年，上海队夺得队史第二座CBA总冠军 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1qUEg3TEI3NDhkUWNVSENjSkJ5eGRoUXhhN2pBY2ZwNE5FMzEtT2hiZkY5Qy01ZFlIa2JVWmFRSXJKZzkwUHU4RjA0aTllNW1] (zh:…
      时隔24年，上海队夺得队史第二座CBA总冠军 财新
  - (2026-06-06) 2026第30“虎” 正省级魏小东落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE0ydFlQMHVpUzFsOFZ6cGNlVlB6aVozZ2hOcW84SnV0SmFodlFSR3Jpczk1OU5nTk1EOTVUOWVuSDc0VFpqd2JG] (zh:…
      2026第30“虎” 正省级魏小东落马 china.caixin.com
  - (2026-06-05) 国办发文严管私募基金 明确央地协同备案、处置 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9NWW5WaE1QaXRhY2VWQnZueTA4UUozXzI1ekd6cGFzUE9heldDc0ZtenRsanc3UkRaTnVhdlFlYjVtS2hrWUMwLW1YdXQ4ZEx] (zh:…
      国办发文严管私募基金 明确央地协同备案、处置 财新
  - (2026-06-05) 中方回应美国制裁古巴领导人及亲属：搞乱古巴最终也将反噬自身 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE12TTBHVS1NakpzV3E3Z0dqNGpSMGZRY0hqd2tmcE9xaTRfRXlHM0NQbVppSXV1dlZUd1k5bHhtbnBRLXpIUjJzR2dQ] (zh:…
      中方回应美国制裁古巴领导人及亲属：搞乱古巴最终也将反噬自身 财新
  - (2026-06-06) 芯片股暴跌致纳指重挫4.18% 美国AI投资热潮面临加息威胁 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9qMW5hZkNpenpGR09MbFFaVlozSjR5bWYyNm9KcTJ3OFYwOWN6U004RndTZEZlWllHNmtkMk41OTJLY1pLdUpsVmV] (zh:…
      芯片股暴跌致纳指重挫4.18% 美国AI投资热潮面临加息威胁 财新

### U.S. Weather + Severe / Climate Outlooks — 162 new of 172 total
  - (2026-06-06) [Severe] Red Flag Warning: Red Flag Warning issued June 6 at 2:21AM PDT until June 6 at 11:00PM PDT by NWS Elko NV
      * AFFECTED AREA...Fire weather zones 424, 425, 426, 427, 437, 438, 469, and 470. * WIND...Sustained southwest winds near 20 mph, with gusts near 35 mph. * HUMIDITY...Minimum relative humidity values as low as 9 percent.…
  - (2026-06-06) [Severe] Flash Flood Warning: Flash Flood Warning issued June 6 at 4:19AM CDT until June 6 at 6:30AM CDT by NWS Fort Worth TX
      FFWFWD The National Weather Service in Fort Worth has extended the * Flash Flood Warning for... North Central Bell County in central Texas... * Until 630 AM CDT. * At 419 AM CDT, Doppler radar indicated thunderstorms pro…
  - (2026-06-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-06) [Moderate] Gale Warning: Gale Warning issued June 6 at 2:17AM PDT until June 7 at 3:00AM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Northwest winds 20 to 30 kt with gusts up to 35 kt and combined seas 10 to 14 ft expected when conditions are worst. * WHERE...Waters from Pt. Sal to Santa Cruz Island CA and westward 60 nm including San Miguel…
  - (2026-06-06) [Moderate] Gale Warning: Gale Warning issued June 6 at 2:17AM PDT until June 7 at 3:00AM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Northwest winds 20 to 30 kt with gusts up to 35 kt and combined seas 11 to 15 ft expected when conditions are worst. * WHERE...Point Piedras Blancas to Point Sal from 10 to 60 NM. * WHEN...For the Small Craft Ad…
  - (2026-06-06) [Moderate] Special Weather Statement: Special Weather Statement issued June 6 at 5:15AM EDT by NWS Northern Indiana
      At 515 AM EDT/415 AM CDT/, Doppler radar was tracking a strong thunderstorm near Knox, moving east at 45 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knoc…

### GDELT GKG — themes / entities / watch areas — 127 new of 127 total
  - (2026-06-06) [Russia oil sanctions perimeter · themes] Ukraine targets St . Petersburg again after Putin rejects Zelenskyy offer for direct talks
      stcatharinesstandard.ca · English · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · themes] U . S . military says it shot down Iranian drones launched toward Gulf allies
      kvnf.org · English · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · themes] Vesak : den , kdy se rodí světlo . Mostecká Pagoda oslavila svátek buddhistů
      mostecky.denik.cz · Czech · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · themes] Глава « Роснефти » сравнил развитие мировой экономики с древнегреческим мифом о ларце Пандоры
      ng.ru · Russian · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · themes] Argentina to expand hantavirus search to a second province
      straitstimes.com · English · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · themes] 開拍首日就開戰 ！ 北影新人鄧筠熹中正橋上狠吵香港男星 崩潰 ： 簡直要把我逼瘋 | ETtoday星光雲
      star.ettoday.net · Chinese · tone NA

### Local News: St. Louis + Atlanta — 120 new of 234 total
  - (2026-06-06) [St. Louis] See the June 6, 1926, front page: Judge Frey gave a $6,500 fee job to father-in-law
      Headlines from the June 6, 1926, front page include: $6,000 robbery story a fake to fool his bride.
  - (2026-06-06) [St. Louis] Meyer, Francis
      Meyer, Francis "Frank"
  - (2026-06-06) [St. Louis] CATCHING A GLIMPSE
      The Canadian Snowbirds practice near the Spirit of St. Louis Airport for the annual St. Louis Air Show & STEM Expo in Chesterfield on Friday, June 5, 2026. The air show begins on Saturday and continues on Sunday. The sho…
  - (2026-06-06) [St. Louis] CATCHING A GLIMPSE
  - (2026-06-06) [St. Louis] SLPS discovers Legionella bacteria
      Employees sit outside with cleaning supplies and masks at the St. Louis Public Schools Central Office in St. Louis on Friday, June 5, 2026. The Central Office shut down after finding Legionella bacteria in the building's…
  - (2026-06-06) [St. Louis] SLPS discovers Legionella bacteria
      The St. Louis Public Schools has shut off water to its central office and told staff to stay away after testing found the presence of Legionella bacteria in the building's cooling and water systems.

### Ukraine Theater (total-war monitoring) — 110 new of 360 total
  - (2026-06-05) [FIRMS] thermal anomaly 48.473, 34.627 (FRP 1.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2244Z, FRP 1.01 MW
  - (2026-06-05) [FIRMS] thermal anomaly 47.872, 33.438 (FRP 1.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2244Z, FRP 1.69 MW
  - (2026-06-05) [FIRMS] thermal anomaly 47.865, 33.438 (FRP 1.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2244Z, FRP 1.69 MW
  - (2026-06-05) [FIRMS] thermal anomaly 47.859, 33.447 (FRP 0.58 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2244Z, FRP 0.58 MW
  - (2026-06-05) [FIRMS] thermal anomaly 45.262, 31.666 (FRP 1.62 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2246Z, FRP 1.62 MW
  - (2026-06-05) [FIRMS] thermal anomaly 45.262, 31.676 (FRP 1.62 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2246Z, FRP 1.62 MW

### State-Level News — 79 new of 659 total
  - (2026-06-05) [California] Governor Newsom visits Space Beach and highlights California’s aerospace dominance
      Source
  - (2026-06-05) [Arizona] Federal judge: Trump freeze on asylum applications from 39 countries violates federal law
      WASHINGTON — A federal judge in Rhode Island Friday struck down several Trump administration policies that halted processing for asylum seekers following a shooting in Washington, D.C., that left one West Virginia Nation…
  - (2026-06-05) [Alaska] Controversial oil lease sale in Alaska wildlife refuge draws limited interest
      A controversial oil and gas lease sale in the Arctic National Wildlife Refuge drew one big bid Friday from an independent Anchorage-based natural gas producer, along with a smattering of other bids from a state economic…
  - (2026-06-05) [Alaska] Trump administration processing freeze on asylum seekers violated law, judge rules
      WASHINGTON — A federal judge in Rhode Island Friday struck down several Trump administration policies that halted processing for asylum seekers following a shooting in Washington, D.C., that left one West Virginia Nation…
  - (2026-06-06) [California] Democrat Xavier Becerra advances to November race for California governor
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226-Becerra-Watch-Party-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-06-05) [Colorado] US Senate blocks Trump’s SAVE America Act, thwarting restrictions on voting
      The U.S. Senate rejected the SAVE America Act on Thursday, dealing a blow to President Donald Trump’s efforts to impose voting restrictions ahead of the November midterm elections. Senators voted 48-50 against advancing…

### State Legislative Action — 76 new of 141 total
  - (2026-06-06) [Arizona HB 2032] statewide assessment; testing window; revisions
      statewide assessment; testing window; revisions
  - (2026-06-06) [Arizona HB 2342] homeowners' associations; shade structures
      homeowners' associations; shade structures
  - (2026-06-06) [Arizona HB 2109] distracted driving; penalties; motorcycles
      distracted driving; penalties; motorcycles
  - (2026-06-06) [Arizona SB 1254] real property conveyances; formal requirements
      real property conveyances; formal requirements
  - (2026-06-06) [Arizona HB 2078] reclamation plans; aggregate mining; notice
      reclamation plans; aggregate mining; notice
  - (2026-06-06) [Arizona HB 2195] nursing facilities; records; surveys; timelines
      nursing facilities; records; surveys; timelines

### Congressional STOCK Act Trades (House + Senate) — 50 new of 50 total
  - (2026-05-15) [House] Lloyd Doggett (D): Purchase PG ($1,001 - $15,000) (excess +3.7% vs SPY)
      Member: Lloyd Doggett (D, house). BioGuide: D000399. Asset: PG (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-06-04. Excess return vs SPY since disclosure: +3.72…
  - (2026-06-01) [House] Tim Walberg (R): Sale FSSL ($15,001 - $50,000) (excess -1.3% vs SPY)
      Member: Tim Walberg (R, house). BioGuide: W000798. Asset: FSSL (ST). Type: Sale. Amount range: $15,001 - $50,000. Transaction date: 2026-06-01. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: -1.29%.
  - (2026-05-27) [House] Josh Gottheimer (D): Sale ABT ($1,001 - $15,000) (excess +8.0% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: ABT (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-05-27. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: +8.02%…
  - (2026-05-22) [House] Josh Gottheimer (D): Purchase LITE ($1,001 - $15,000) (excess -7.7% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: LITE (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-22. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: -…
  - (2026-05-22) [House] Josh Gottheimer (D): Sale INTU ($1,001 - $15,000) (excess -6.1% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: INTU (ST). Type: Sale. Amount range: $1,001 - $15,000. Transaction date: 2026-05-22. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: -6.14…
  - (2026-05-21) [House] Josh Gottheimer (D): Purchase MU ($1,001 - $15,000) (excess +14.1% vs SPY)
      Member: Josh Gottheimer (D, house). BioGuide: G000583. Asset: MU (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-21. Disclosure date: 2026-06-03. Excess return vs SPY since disclosure: +14…

### Ukrainian Internal News (national + local Kyiv) — 45 new of 128 total
  - (2026-06-06) Трагедії на дорогах: де шукати крайнього? | LEDE: Висока смертність у ДТП — друга після війни проблема України. Чому влада та поліція не діють для безпеки на дорогах?] (uk: Трагедії на дорогах: де шук…
      Висока смертність у ДТП — друга після війни проблема України. Чому влада та поліція не діють для безпеки на дорогах?
  - (2026-06-06) Зеленський нагородив 37 українських та іноземних працівників медіа | LEDE: З нагоди Дня журналіста президент Володимир Зеленський підписав указ про нагородження 37 журналістів, працівників і пр] (uk:…
      З нагоди Дня журналіста президент Володимир Зеленський підписав указ про нагородження 37 журналістів, працівників і працівниць українських та іноземних медіа за їхній внесок у розвиток журналістики та висвітлення правди…
  - (2026-06-06) У Швейцарії винесуть на референдум зміни до військової та цивільної служби | LEDE: ] (uk: У Швейцарії винесуть на референдум зміни до військової та цивільної служби)
  - (2026-06-06) Зеленський: Уночі українські дрони атакували арсенали ВМФ Росії та базу в Кронштадті | LEDE: Українські дрони завдали ударів по арсеналах та базах РФ у Ленінградській області і Кронштадті, пові] (uk:…
      Українські дрони завдали ударів по арсеналах та базах РФ у Ленінградській області і Кронштадті, повідомив Зеленський.
  - (2026-06-06) Сирський доручив збільшити забезпечення військ на Півдні | LEDE: Олександр Сирський ухвалив рішення про додаткове забезпечення підрозділів Південної зони технічними засобами й боєприпасами.] (uk: Сирс…
      Олександр Сирський ухвалив рішення про додаткове забезпечення підрозділів Південної зони технічними засобами й боєприпасами.
  - (2026-06-06) Польща-Україна: пробачаємо і просимо пробачення? | LEDE: Як історична пам’ять і політика впливають на сучасні відносини між Україною та Польщею] (uk: Польща-Україна: пробачаємо і просимо пробачення?)
      Як історична пам’ять і політика впливають на сучасні відносини між Україною та Польщею

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-06) [WhiteHorse Finance, Inc.] Form 4 (Issuer)
      filed 2026-06-06 01:45 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001104659-26-071091 Size: 12 KB
  - (2026-06-06) [BOLDUC JOHN] Form 4 (Reporting)
      filed 2026-06-06 01:45 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001104659-26-071091 Size: 12 KB
  - (2026-06-06) [LENSAR, Inc.] Form 4 (Issuer)
      filed 2026-06-06 01:34 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001193125-26-260337 Size: 6 KB
  - (2026-06-06) [HAMMER TODD B] Form 4 (Reporting)
      filed 2026-06-06 01:34 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001193125-26-260337 Size: 6 KB
  - (2026-06-06) [Delek US Holdings, Inc.] Form 4 (Issuer)
      filed 2026-06-06 01:34 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001508550-26-000006 Size: 4 KB
  - (2026-06-06) [Sutil Vicky] Form 4 (Reporting)
      filed 2026-06-06 01:34 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001508550-26-000006 Size: 4 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-06) [] Technical issue detected on united kingdom largest warship while docked in Norway
      domain: glasgowtimes.co.uk · language: English · tone:
  - (2026-06-06) [Canada] Ukraine targets St . Petersburg again after Putin rejects Zelenskyy offer for direct talks
      domain: stcatharinesstandard.ca · language: English · tone:
  - (2026-06-06) [Israel] Terms & Conditions - Jerusalem Online
      domain: jerusalemonline.com · language: English · tone:
  - (2026-06-06) [United States] U . S . military says it shot down Iranian drones launched toward Gulf allies
      domain: kvnf.org · language: English · tone:
  - (2026-06-06) [India] Moderate earthquake jolts Palampur ; residents recall 1905 deadly Kangra quake
      domain: tribuneindia.com · language: English · tone:
  - (2026-06-06) [Nepal] Government forms panel to probe 779 seized EVs
      domain: peoplesreview.com.np · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 18 new of 149 total
  - (2026-06-06) [Polymarket] Will the Bank of Brazil decrease the Selic rate after June 2026 meeting?
      This market will resolve according to the change in the target for the Selic rate as a result of the monetary policy decision of the Bank of Brazil's June 2026 meeting versus the level it was prior to this meeting. The r…
  - (2026-06-06) [Polymarket] US x Iran diplomatic meeting by June 15, 2026?
      This market will resolve to "Yes" if there is a diplomatic meeting between representatives of the United States and Iran by the listed date, 11:59 PM ET. Otherwise, this market will resolve to “No”. A diplomatic meeting…
  - (2026-06-06) [Polymarket] Will SpaceX's market cap be between $1.2T and $1.4T at market close on IPO day?
      This market will resolve based on SpaceX's market capitalization at the closing price on its first day of trading. If no SpaceX IPO occurs by December 31, 2027, 11:59 PM ET, the market will resolve to "No IPO before 2028…
  - (2026-06-06) [Polymarket] Will China invade Taiwan by June 30, 2026?
      This market will resolve to "Yes" if China commences a military offensive intended to establish control over any portion of the Republic of China (Taiwan) by June 30, 2026, 11:59 PM ET. Otherwise, this market will resolv…
  - (2026-06-06) [Polymarket] OpenAI IPO closing market cap above $800B?
      This market will resolve to “Yes” if the official closing price for OpenAI's market capitalization on its first trading day is above the listed value. Otherwise, it will resolve to “No”. If no IPO occurs by December 31,…
  - (2026-06-06) [Polymarket] Will Gabriel Bortoleto be the 2026 F1 Drivers' Champion?
      This market will resolve according to the listed driver that finishes 1st in the driver standings for the 2026 F1 season. This market will resolve as soon as the official results of the final scheduled race of the 2026 F…

### Court opinions of consequence (federal & state) — 15 new of 60 total
  - (2026-06-05) U.S. Court of Appeals, 7th Cir.: Unite Here Local 1 v. Magnificent Mile Hotel Management, LLC
  - (2026-06-05) U.S. Court of Appeals, 1st Cir.: Jordan v. Lizotte
  - (2026-06-05) U.S. Court of Appeals, 1st Cir.: Premca Extra Income Fund LP v. Angle
  - (2026-06-05) Hawaii Supreme Court: Bellamy v. City and County of Honolulu
  - (2026-06-05) Hawaii Supreme Court: State v. Ellway
  - (2026-06-05) Massachusetts Supreme Judicial Court: Crown Communities, LLC v. Austin

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-06) [Japan] VV : ULTIMATUM codes ( June 2026 )
      destructoid.com · English
  - (2026-06-06) [Japan] FC 26 Champions Tokens explained : Best rewards to pick
      destructoid.com · English
  - (2026-06-06) [Japan] Which faction should you join in Gothic 1 Remake
      destructoid.com · English
  - (2026-06-06) [Japan] Monster Hunter Wilds coming to Switch 2
      nichegamer.com · English
  - (2026-06-06) [Japan] Star Wars Zero Company launches in August
      nichegamer.com · English
  - (2026-06-06) [Japan] iRacing Reveals Upgraded BMW GTP for Upcoming Season
      explosion.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 111 total
  - (2026-06-06) [USASpending] $22,428,178,818 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-06-06) [USASpending] $4,465,823,660 → FLUOR-BWXT PORTSMOUTH LLC: PORTSMOUTH GASEOUS DIFFUSION PLANT DECONTAMINATION AND DECOM
      Agency: Department of Energy. Description: PORTSMOUTH GASEOUS DIFFUSION PLANT DECONTAMINATION AND DECOMMISSIONING PROJECT
  - (2026-06-06) [USASpending] $3,272,481,574 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…
  - (2026-06-06) [USASpending] $2,409,248,908 → UNITED CLEANUP OAK RIDGE LLC: OAK RIDGE RESERVATION CLEANUP CONTRACT TASK ORDERS
      Agency: Department of Energy. Description: OAK RIDGE RESERVATION CLEANUP CONTRACT TASK ORDERS
  - (2026-06-06) [USASpending] $1,415,863,745 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
  - (2026-06-06) [USASpending] $786,064,460 → SERCO INC: ELIGIBILITY SUPPORT
      Agency: Department of Health and Human Services. Description: ELIGIBILITY SUPPORT

### USGS earthquakes (M4.5+, past day) — 11 new of 20 total
  - (2026-06-05) M 5.6 - Balleny Islands region
      M5.6 · Balleny Islands region · depth 10 km
  - (2026-06-05) M 5.1 - 0 km SSW of Quetzalapa, Mexico
      M5.1 · 0 km SSW of Quetzalapa, Mexico · depth 47.928 km
  - (2026-06-05) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 10 km
  - (2026-06-06) M 4.9 - 47 km WSW of Magdalena, Philippines
      M4.9 · 47 km WSW of Magdalena, Philippines · depth 10 km
  - (2026-06-06) M 4.8 - 82 km W of Ambunti, Papua New Guinea
      M4.8 · 82 km W of Ambunti, Papua New Guinea · depth 93.01 km
  - (2026-06-05) M 4.7 - Izu Islands, Japan region
      M4.7 · Izu Islands, Japan region · depth 10 km

### U.S. Federal Action — 8 new of 8 total
  - (2026-06-08) Establishment of Class E Airspace; Dover, OH
      This action establishes Class E airspace at Cleveland Clinic, Union Hospital Heliport, Dover, OH. This action supports new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-06-08) Airworthiness Directives; The Boeing Company Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for certain The Boeing Company Model 747-8 series airplanes. This proposed AD was prompted by a report of cracks in the fuselage skin lap splice at the upper f…
  - (2026-06-08) Rescission of Policy Relating to the Acceptance of Settlements in Administrative and Civil Proceedings
      The Commodity Futures Trading Commission ("CFTC" or "Commission") is rescinding a policy contained in an appendix to its regulations concerning acceptance of settlements in administrative and civil proceedings. This poli…
  - (2026-06-08) Approval and Promulgation of Air Quality Implementation Plans; Wyoming; Regional Haze Federal Implementation Plan
      The U.S. Environmental Protection Agency (EPA) is proposing revisions to the Federal Implementation Plan (FIP) addressing regional haze in the State of Wyoming. The EPA is proposing revisions to the FIP's nitrogen oxides…
  - (2026-06-08) Anchorages; Port of New York
      The Coast Guard is proposing to amend regulations to conform to requirements in the National Defense Authorization Act for Fiscal Year 2026, which required the Commandant to prohibit any vessel anchoring on the reach of…
  - (2026-06-08) Air Plan Approval; Minnesota; Revision to Taconite Federal Implementation Plan
      The U.S. Environmental Protection Agency (EPA) is revising the Original 2013 Federal Implementation Plan (FIP) by finalizing nitrogen oxide (NO X ) emission limits for the indurating furnace at United States Steel's (U.S…

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-06-06) Roland Garros WTA: Maja Chwalinska vs Mirra Andreeva
      yes price: 18% · 24h volume: $2,930,649 · resolves 2026-06-13
  - (2026-06-06) Will the Fed decrease interest rates by 50+ bps after the June 2026 meeting?
      yes price: 0% · 24h volume: $1,377,986 · resolves 2026-06-17
  - (2026-06-06) Will the San Antonio Spurs win the 2026 NBA Finals?
      yes price: 21% · 24h volume: $1,150,901 · resolves 2026-07-01
  - (2026-06-06) Will the New York Knicks win the 2026 NBA Finals?
      yes price: 79% · 24h volume: $1,119,554 · resolves 2026-07-01
  - (2026-06-06) Spurs vs. Knicks
      yes price: 46% · 24h volume: $1,111,868 · resolves 2026-06-09
  - (2026-06-06) Will Portugal win the 2026 FIFA World Cup?
      yes price: 10% · 24h volume: $941,525 · resolves 2026-07-20

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 40 total
  - (2026-06-06) MOVER ▼ Rob Walton & family — $137.74B ($-0.33B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-06-06) MOVER ▼ Jim Walton & family — $135.03B ($-0.32B since yesterday)
      United States · Fashion & Retail · source: Walmart

### Commentary & analysis (last 7 days) — 1 new of 5 total
  - (2026-06-06) [Marginal Revolution] Should you move to Argentina? (from my email)
      My name is Josh Neuman, and I’m writing from Buenos Aires, Argentina where Peter Thiel’s move is all over the news here. He lives in [redacted], only a xx minute drive from my own apartment in Recoleta. I want to pitch a…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=8, 7d-median=30, 14d-median=30; carrying terms: certain, persons, safety, waters, public, provide, guard, address, vessels, captain, authorized, action
- state_bills: today=141, 7d-median=141, 14d-median=141; carrying terms: allow, insurance, engage, electronic, violation, commercial, allocation, development, public, license, california, order
- state_news: today=659, 7d-median=659, 14d-median=722; carrying terms: pressherald, helped, again, might, offices, michigan, toomanyredirects, released, wants, sizes, businesses, recent
- local_news: today=234, 7d-median=234, 14d-median=246; carrying terms: weekend, development, public, shooting, articles, missouri, cbminafbvv, final, summer, returns, suspect, region
- foreign_news: today=902, 7d-median=861, 14d-median=868; carrying terms: elpais, helped, explosion, wowed, again, packing, tibet, confirms, offices, survivor, released, anniversary
- chinese_internal: today=263, 7d-median=270, 14d-median=271; carrying terms: caixin, articles, cbmickfvx, target, politics, cbmibkfvx, lxtfa, cbmidefvx, google, cbmiykfvx, cbmizefvx, cbmixkfvx
- russian_internal: today=1061, 7d-median=1050, 14d-median=1050; carrying terms: politico, reuters, europe, found, media, client, telegram, centcom, group, httperror, times, financial
- ukrainian_internal: today=128, 7d-median=121, 14d-median=122; carrying terms: independent, ukraine, error, forbidden, censor, found, vechirniy, kyivindependent, president, httperror, hromadske, https
- ukraine_theater: today=360, 7d-median=279, 14d-median=308; carrying terms: rnhsqxl, losses, cbmicefvx, latam, trzgd, confirms, fcnlhaqzzkovm, nominal, positive, ztntrefor, development, cbminwfbvv
- paper_bets: today=149, 7d-median=148, 14d-median=144; carrying terms: population, forbids, virginia, predictit, state, results, december, primary, become, control, goldman, senate
- weather: today=172, 7d-median=100, 14d-median=112; carrying terms: morning, locations, portion, deeper, twoat, warning, cyclone, weekend, along, current, recent, sweep
- macro: today=21, 7d-median=10, 14d-median=0; carrying terms: recession, indicator, rates, labor, funds, latest, spread, effective, treasury, unemployment, unrate, balance
- markets: today=21, 7d-median=21, 14d-median=0; carrying terms: silver, corporate, bitcoin, crypto, close, yield, commodities, rates, equities, treasury, range, nasdaq
- markets_global: today=47, 7d-median=79, 14d-median=79; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=111, 14d-median=103; carrying terms: protecting, herzegovina, operation, integrity, control, campaign, award, response, myanmar, resolutions, sevastopol, national
- congressional_trades: today=50, 7d-median=40, 14d-median=1; carrying terms: smith, david, googl, since, house, jacobs, transaction, compensation, stock, excess, senate, taylor
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: hathaway, gates, india, facebook, charles, technology, commodities, investments, jensen, diversified, discount, china
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=60, 14d-median=30; carrying terms: blanche, collins, robert, state, company, connecticut, alaska, supreme, appeals, services, court, insurance
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, issuer, accno, david, holdings, michael, american, finance, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: alexandria, booker, angels, disbursements, robert, receipts, house, raised, committee, johnson, lindsey, warner
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=127, 7d-median=83, 14d-median=0; carrying terms: china, strike, military, petersburg, linked, english, trump, ukraine, taiwan, ukrainian, russia, themes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: language, english, india, canada, domain, israel, killed, trump, woman, kingdom, ireland
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=30, 14d-median=20; carrying terms: ground, position, belgium, bulgaria, france, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: yellow, alerted, strain, infecting, ethiopia, haemorrhage, travel, associated, locations, state, prevention, critically
- cisa_kev: today=10, 7d-median=15, 14d-median=15; carrying terms: product, bypass, vulnerability, authentication, remediation, vendor, overflow, cpanel, daemon, privilege, plugin, litespeed
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=126, 14d-median=126; carrying terms: flood, afghanistan, speed, madagascar, pakistan, alert, agricultural, czech, latvia, finland, medium, poland
- usgs_quakes: today=20, 7d-median=17, 14d-median=17; carrying terms: indonesia, depth, islands, russia, labuan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, world, permanent, resolves, peace, price, ceasefire, announces, extension, garros, south, roland
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: https, revolution, economist, conversable, class, marginal, assorted, links, marginalrevolution, policy, economy, economic
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: philip, casten, kustoff, cisneros, meeks, shomari, virginia, sykes, counsel, lindsey, insurance, angie
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, claude, market, converges, placed, module, placement, unavailable, paper, markets, either, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*