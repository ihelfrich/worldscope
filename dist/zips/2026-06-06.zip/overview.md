# WORLDSCOPE morning brief — 2026-06-06

## Headline
2026 new items across 23 active section(s) (of 41 tracked).

## Top movers today
International News + Multilateral Institutions (385) · Russian Internal News (state + in-exile) (363) · World leaders & government officials (324) · Chinese Internal News (196) · U.S. Weather + Severe / Climate Outlooks (163) · Local News: St. Louis + Atlanta (111) · Ukraine Theater (total-war monitoring) (111) · State-Level News (80) · GDELT GKG — themes / entities / watch areas (74) · Ukrainian Internal News (national + local Kyiv) (46) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 385 new of 832 total
  - (2026-06-06) [Global] Bernadette Chirac, widow of former French president, dies at 93
  - (2026-06-06) [Global] Bernadette Chirac, widow of former French president, dies at 93
      Bernadette Chirac, the widow of former French president Jacques Chirac, died at the age of 93, her daughter told AFP on Saturday.
  - (2026-06-06) [Global] Supporters of India's Gen Z 'cockroach' party stage first protest in New Delhi
      Hundreds of mostly young Indians gathered in New Dehli on Saturday for the first street protest organised by the Cockroach Janata Party – a movement which began as an online joke but has quickly gained momentum among Ind…
  - (2026-06-06) [Global] Armenia prepares for vote amid shifting relations with Russia and the West
      Armenia's parliamentary elections Sunday will be a vote on its geopolitical future as incumbent Prime Minister Nikol Pashinyan seeks closer relations with the European Union and the United States despite longstanding tie…
  - (2026-06-06) [Global] Several soldiers killed in Israeli strike on Lebanon
      Several soldiers have been killed in an Israeli strike on a vehicle in south Lebanon, Beirut's military said Saturday, days after the two countries announced a conditional truce following talks in the United States. FRAN…
  - (2026-06-06) [Global] Alexander Zverev closes in on first major title after reaching French Open final
      Alexander Zverev fended off first-time semi-finalist Jakub Menšík in four sets (7-5, 6-2, 3-6, 6-3) to reach the French Open final. A long-awaited first Grand Slam title is now in sight for the German.

### Russian Internal News (state + in-exile) — 363 new of 1014 total
  - (2026-06-06) Минцифры России начало переговоры с Apple о возврате «Макса» в App Store | LEDE: Власти РФ начали переговоры с компанией Apple о возврате мессенджера «Макс» в магазин приложений App Store, с] (ru: Мин…
      Власти РФ начали переговоры с компанией Apple о возврате мессенджера «Макс» в магазин приложений App Store, сообщил глава Минцифры Максут Шадаев на Международном экономическом форуме в Петербурге.
  - (2026-06-06) Петербург пережил ПМЭФ, а вместе с ним — атаки украинских дронов. Журналистов попросили не писать о вечеринках и работницах эскорта, чтобы «не злить народ». Иностранным гостям закупили подписки] (ru:…
      Когда-то Петербургский экономический форум был статусным мероприятием, куда приезжали иностранные инвесторы и высокопоставленные спикеры со всего мира. Но в 2026-м все внимание приковано к одиозным блогерам, а презентаци…
  - (2026-06-06) The Art Newspaper Russia и «Би-би-си» выяснили подробности о поддельных скульптурах Эрнста Неизвестного. Вопросов стало еще больше: одни источники говорят, что в Третьяковке выставили явные фал] (ru:…
      29 мая в Следственном комитете России рассказали о группе фальсификаторов, которая подделывает работы знаменитого советско-американского скульптора Эрнста Неизвестного. Единственным обвиняемым, чье имя было названо, стал…
  - (2026-06-06) В самопровозглашенной ЛНР запретили пассажирские перевозки по трассе «Новороссия» и отменили пригородные поезда | LEDE: В самопровозглашенной ЛНР запретили пассажирские перевозки на трассе «] (ru: В с…
      В самопровозглашенной ЛНР запретили пассажирские перевозки на трассе «Новороссия», идущей через территорию региона из Ростова-на-Дону в Симферополь. Соответствующий указ подписал глава региона Леонид Пасечник.
  - (2026-06-06) Еврокомиссия пообещала ужесточить правила выдачи виз россиянам. Этого добивались 11 стран Шенгенской зоны | LEDE: Еврокомиссия пообещала ужесточить выдачу виз российским гражданам — после то] (ru: Евр…
      Еврокомиссия пообещала ужесточить выдачу виз российским гражданам — после того, как это потребовали сделать 11 стран Шенгенской зоны, сообщает Euronews.
  - (2026-06-06) Такого Человека-паука у нас еще не было. Вышел сериал, в котором супергероя играет Николас Кейдж. Это нуар о разочарованном следователе, а если брать шире — о травмах Первой мировой | LEDE: ] (ru: Так…
      На стриминге Prime вышел сериал «Человек-паук Нуар» (Spider Noir). Это предельно далекое от марвеловской киновселенной произведение: следователя в Нью-Йорке 1930-х роднит с привычным Питером Паркером разве что паутина (и…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 196 new of 268 total
  - (2026-06-06) 时隔24年，上海队夺得队史第二座CBA总冠军 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1qUEg3TEI3NDhkUWNVSENjSkJ5eGRoUXhhN2pBY2ZwNE5FMzEtT2hiZkY5Qy01ZFlIa2JVWmFRSXJKZzkwUHU4RjA0aTllNW1] (zh:…
      时隔24年，上海队夺得队史第二座CBA总冠军 财新
  - (2026-06-06) 2026第30“虎” 正省级魏小东落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE0ydFlQMHVpUzFsOFZ6cGNlVlB6aVozZ2hOcW84SnV0SmFodlFSR3Jpczk1OU5nTk1EOTVUOWVuSDc0VFpqd2JG] (zh:…
      2026第30“虎” 正省级魏小东落马 china.caixin.com
  - (2026-06-05) 国办发文严管私募基金 明确央地协同备案、处置 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9NWW5WaE1QaXRhY2VWQnZueTA4UUozXzI1ekd6cGFzUE9heldDc0ZtenRsanc3UkRaTnVhdlFlYjVtS2hrWUMwLW1YdXQ4ZEx] (zh:…
      国办发文严管私募基金 明确央地协同备案、处置 财新
  - (2026-06-05) 中方回应美国制裁古巴领导人及亲属：搞乱古巴最终也将反噬自身 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE12TTBHVS1NakpzV3E3Z0dqNGpSMGZRY0hqd2tmcE9xaTRfRXlHM0NQbVppSXV1dlZUd1k5bHhtbnBRLXpIUjJzR2dQ] (zh:…
      中方回应美国制裁古巴领导人及亲属：搞乱古巴最终也将反噬自身 财新
  - (2026-06-06) 芯片股暴跌致纳指重挫4.18% 美国AI投资热潮面临加息威胁 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9qMW5hZkNpenpGR09MbFFaVlozSjR5bWYyNm9KcTJ3OFYwOWN6U004RndTZEZlWllHNmtkMk41OTJLY1pLdUpsVmV] (zh:…
      芯片股暴跌致纳指重挫4.18% 美国AI投资热潮面临加息威胁 财新
  - (2026-06-05) 普京称俄罗斯准备“妥协” 泽连斯基提议乌俄元首直接会晤 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE03bHRYZ3UtRUtnWmZVSGFQa3RLLWNFVUs5UmFNSTNVVXI4Y05GdkcwU2dna1UtMnZMVHBSUzN1U0hpVmZ1a2ZSWE5VSn] (zh:…
      普京称俄罗斯准备“妥协” 泽连斯基提议乌俄元首直接会晤 财新

### U.S. Weather + Severe / Climate Outlooks — 163 new of 173 total
  - (2026-06-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-06) [Moderate] Special Weather Statement: Special Weather Statement issued June 6 at 5:28AM EDT by NWS Northern Indiana
      At 528 AM EDT, Doppler radar was tracking a strong thunderstorm near Markle, or 7 miles east of Huntington, moving east at 30 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated. IMPACT...G…
  - (2026-06-06) [Severe] Red Flag Warning: Red Flag Warning issued June 6 at 3:25AM MDT until June 6 at 7:00PM MDT by NWS Denver CO
      * AFFECTED AREA...Fire Weather Zones 242, 243, 244, 245 and 248. * TIMING...From noon today to 7 PM MDT this evening. * WINDS...Southeast 15 to 25 mph with gusts up to 30 mph. * RELATIVE HUMIDITY...As low as 14 percent.…
  - (2026-06-06) [Severe] Red Flag Warning: Red Flag Warning issued June 6 at 2:21AM PDT until June 6 at 11:00PM PDT by NWS Elko NV
      * AFFECTED AREA...Fire weather zones 424, 425, 426, 427, 437, 438, 469, and 470. * WIND...Sustained southwest winds near 20 mph, with gusts near 35 mph. * HUMIDITY...Minimum relative humidity values as low as 9 percent.…
  - (2026-06-06) [Severe] Flash Flood Warning: Flash Flood Warning issued June 6 at 4:19AM CDT until June 6 at 6:30AM CDT by NWS Fort Worth TX
      FFWFWD The National Weather Service in Fort Worth has extended the * Flash Flood Warning for... North Central Bell County in central Texas... * Until 630 AM CDT. * At 419 AM CDT, Doppler radar indicated thunderstorms pro…
  - (2026-06-06) [Moderate] Gale Warning: Gale Warning issued June 6 at 2:17AM PDT until June 7 at 3:00AM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Northwest winds 20 to 30 kt with gusts up to 35 kt and combined seas 11 to 15 ft expected when conditions are worst. * WHERE...Point Piedras Blancas to Point Sal from 10 to 60 NM. * WHEN...For the Small Craft Ad…

### Local News: St. Louis + Atlanta — 111 new of 216 total
  - (2026-06-06) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-06-05) [St. Louis] Man dies in UTV crash in Franklin County
      A man died from injuries suffered in a UTV crash Friday morning in Franklin County, according to the Missouri State Highway Patrol.
  - (2026-06-05) [St. Louis] What can the Cardinals do with Nolan Gorman, Victor Scott stuck in slumps?
      Two players who the St. Louis Cardinals prepared to take on larger everyday roles this season, Nolan Gorman and Victor Scott, both find themselves working through prolonged offensive slumps, putting the Cardinals in a to…
  - (2026-06-06) [St. Louis] St. Louis billboards honor Black people as 'America's MVP'
      Civil rights activist and Skate King CEO Matthew Foggy Jr. has launched a billboard campaign across St. Louis and East St. Louis, featuring the message "Black People America's MVP." The campaign aims to highlight the ind…
  - (2026-06-06) [St. Louis] Jam-packed sports weekend hits St. Louis
      Baseball fan Demario Pleasant traveled to St. Louis from Ohio for Friday night’s baseball game at Busch Stadium. He stopped by Top Notch Axe Throwing before the game.
  - (2026-06-05) [St. Louis] Festus mayor, councilmen sue in effort to stop recall election
      Festus Mayor Sam Richards and three city councilmen filed a lawsuit Friday in an effort to block a recall election tied to the city's controversial data center plans.

### Ukraine Theater (total-war monitoring) — 111 new of 360 total
  - (2026-06-06) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-05) [FIRMS] thermal anomaly 48.473, 34.627 (FRP 1.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2244Z, FRP 1.01 MW
  - (2026-06-05) [FIRMS] thermal anomaly 47.872, 33.438 (FRP 1.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2244Z, FRP 1.69 MW
  - (2026-06-05) [FIRMS] thermal anomaly 47.865, 33.438 (FRP 1.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2244Z, FRP 1.69 MW
  - (2026-06-05) [FIRMS] thermal anomaly 47.859, 33.447 (FRP 0.58 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2244Z, FRP 0.58 MW
  - (2026-06-05) [FIRMS] thermal anomaly 45.262, 31.666 (FRP 1.62 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-05 2246Z, FRP 1.62 MW

### State-Level News — 80 new of 651 total
  - (2026-06-05) [California] Governor Newsom visits Space Beach and highlights California’s aerospace dominance
      Source
  - (2026-06-05) [Colorado] US Senate blocks Trump’s SAVE America Act, thwarting restrictions on voting
      The U.S. Senate rejected the SAVE America Act on Thursday, dealing a blow to President Donald Trump’s efforts to impose voting restrictions ahead of the November midterm elections. Senators voted 48-50 against advancing…
  - (2026-06-06) [feed error] AK Governor (Alaska): HTTPError
      403 Client Error: Forbidden for url: https://gov.alaska.gov/feed/
  - (2026-06-05) [Alaska] Controversial oil lease sale in Alaska wildlife refuge draws limited interest
      A controversial oil and gas lease sale in the Arctic National Wildlife Refuge drew one big bid Friday from an independent Anchorage-based natural gas producer, along with a smattering of other bids from a state economic…
  - (2026-06-05) [Alaska] Trump administration processing freeze on asylum seekers violated law, judge rules
      WASHINGTON — A federal judge in Rhode Island Friday struck down several Trump administration policies that halted processing for asylum seekers following a shooting in Washington, D.C., that left one West Virginia Nation…
  - (2026-06-06) [California] Democrat Xavier Becerra advances to November race for California governor
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226-Becerra-Watch-Party-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### GDELT GKG — themes / entities / watch areas — 74 new of 74 total
  - (2026-06-06) [Russia oil sanctions perimeter · keywords] Ukraine launches massive attack on Russia hours after Putin snubs rude Zelensky
      mirror.co.uk · English · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · keywords] US Issues New Iran - Linked Sanctions
      english.aawsat.com · English · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · keywords] US targets Iranian LPG smuggling network and shadow banking system
      middleeaststar.com · English · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · keywords] US Sanctions Iranian LPG Smuggling Network
      newkerala.com · English · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · keywords] US targets Iranian LPG smuggling network and shadow banking system
      iraqsun.com · English · tone NA
  - (2026-06-06) [Russia oil sanctions perimeter · keywords] US targets Iranian LPG smuggling network and shadow banking system
      aninews.in · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 46 new of 129 total
  - (2026-06-06) ГО "Пасажири Києва": Трагічне ДТП в Києві – це пряма ціна бездіяльності влади | LEDE: ] (uk: ГО "Пасажири Києва": Трагічне ДТП в Києві – це пряма ціна бездіяльності влади)
  - (2026-06-06) Трагедії на дорогах: де шукати крайнього? | LEDE: Висока смертність у ДТП — друга після війни проблема України. Чому влада та поліція не діють для безпеки на дорогах?] (uk: Трагедії на дорогах: де шук…
      Висока смертність у ДТП — друга після війни проблема України. Чому влада та поліція не діють для безпеки на дорогах?
  - (2026-06-06) Зеленський нагородив 37 українських та іноземних працівників медіа | LEDE: З нагоди Дня журналіста президент Володимир Зеленський підписав указ про нагородження 37 журналістів, працівників і пр] (uk:…
      З нагоди Дня журналіста президент Володимир Зеленський підписав указ про нагородження 37 журналістів, працівників і працівниць українських та іноземних медіа за їхній внесок у розвиток журналістики та висвітлення правди…
  - (2026-06-06) У Швейцарії винесуть на референдум зміни до військової та цивільної служби | LEDE: ] (uk: У Швейцарії винесуть на референдум зміни до військової та цивільної служби)
  - (2026-06-06) Зеленський: Уночі українські дрони атакували арсенали ВМФ Росії та базу в Кронштадті | LEDE: Українські дрони завдали ударів по арсеналах та базах РФ у Ленінградській області і Кронштадті, пові] (uk:…
      Українські дрони завдали ударів по арсеналах та базах РФ у Ленінградській області і Кронштадті, повідомив Зеленський.
  - (2026-06-06) Сирський доручив збільшити забезпечення військ на Півдні | LEDE: Олександр Сирський ухвалив рішення про додаткове забезпечення підрозділів Південної зони технічними засобами й боєприпасами.] (uk: Сирс…
      Олександр Сирський ухвалив рішення про додаткове забезпечення підрозділів Південної зони технічними засобами й боєприпасами.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-06) [WhiteHorse Finance, Inc.] Form 4 (Issuer)
      filed 2026-06-06 01:45 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001104659-26-071091 Size: 12 KB
  - (2026-06-06) [BOLDUC JOHN] Form 4 (Reporting)
      filed 2026-06-06 01:45 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001104659-26-071091 Size: 12 KB
  - (2026-06-06) [LENSAR, Inc.] Form 4 (Issuer)
      filed 2026-06-06 01:34 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001193125-26-260337 Size: 6 KB
  - (2026-06-06) [HAMMER TODD B] Form 4 (Reporting)
      filed 2026-06-06 01:34 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001193125-26-260337 Size: 6 KB
  - (2026-06-06) [Delek US Holdings, Inc.] Form 4 (Issuer)
      filed 2026-06-06 01:34 UTC · role: Issuer — Filed: 2026-06-05 AccNo: 0001508550-26-000006 Size: 4 KB
  - (2026-06-06) [Sutil Vicky] Form 4 (Reporting)
      filed 2026-06-06 01:34 UTC · role: Reporting — Filed: 2026-06-05 AccNo: 0001508550-26-000006 Size: 4 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### State Legislative Action — 27 new of 141 total
  - (2026-06-06) [Alaska SB 252] An Act relating to the Uniform Commercial Code; relating to secured transactions; relating to controllable accounts, controllable electronic records, and controllable payment intangibl…
      An Act relating to the Uniform Commercial Code; relating to secured transactions; relating to controllable accounts, controllable electronic records, and controllable payment intangibles; relating to sales; relating to n…
  - (2026-06-06) [Alaska SB 86] An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing sy…
      An Act relating to the business of money transmission; relating to licenses for money transmission, licensure requirements, and registration through a nationwide multistate licensing system; relating to the use of virtua…
  - (2026-06-06) [Alaska HB 52] An Act relating to the rights of minors undergoing evaluation or inpatient treatment at psychiatric hospitals; relating to the use of seclusion or restraint of minors at psychiatric hos…
      An Act relating to the rights of minors undergoing evaluation or inpatient treatment at psychiatric hospitals; relating to the use of seclusion or restraint of minors at psychiatric hospitals; relating to a report publis…
  - (2026-06-06) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-06-05) [Alaska HB 208] An Act relating to the regulation of liquefied natural gas import facilities by the Regulatory Commission of Alaska.
      An Act relating to the regulation of liquefied natural gas import facilities by the Regulatory Commission of Alaska.
  - (2026-06-05) [Alaska HJR 32] Expressing commitment to the rural health transformation program; acknowledging the critical health care challenges facing rural areas of the state; and urging action by the Governor a…
      Expressing commitment to the rural health transformation program; acknowledging the critical health care challenges facing rural areas of the state; and urging action by the Governor and the Alaska delegation in Congress…

### Paper Trading Scorecard — 19 new of 100 total
  - (2026-06-06) [Polymarket] Will the Bank of Brazil decrease the Selic rate after June 2026 meeting?
      This market will resolve according to the change in the target for the Selic rate as a result of the monetary policy decision of the Bank of Brazil's June 2026 meeting versus the level it was prior to this meeting. The r…
  - (2026-06-06) [Polymarket] US x Iran diplomatic meeting by June 15, 2026?
      This market will resolve to "Yes" if there is a diplomatic meeting between representatives of the United States and Iran by the listed date, 11:59 PM ET. Otherwise, this market will resolve to “No”. A diplomatic meeting…
  - (2026-06-06) [Polymarket] Will SpaceX's market cap be between $1.2T and $1.4T at market close on IPO day?
      This market will resolve based on SpaceX's market capitalization at the closing price on its first day of trading. If no SpaceX IPO occurs by December 31, 2027, 11:59 PM ET, the market will resolve to "No IPO before 2028…
  - (2026-06-06) [Polymarket] Will China invade Taiwan by June 30, 2026?
      This market will resolve to "Yes" if China commences a military offensive intended to establish control over any portion of the Republic of China (Taiwan) by June 30, 2026, 11:59 PM ET. Otherwise, this market will resolv…
  - (2026-06-06) [Polymarket] OpenAI IPO closing market cap above $800B?
      This market will resolve to “Yes” if the official closing price for OpenAI's market capitalization on its first trading day is above the listed value. Otherwise, it will resolve to “No”. If no IPO occurs by December 31,…
  - (2026-06-06) [Polymarket] Will Gabriel Bortoleto be the 2026 F1 Drivers' Champion?
      This market will resolve according to the listed driver that finishes 1st in the driver standings for the 2026 F1 season. This market will resolve as soon as the official results of the final scheduled race of the 2026 F…

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-06-05) U.S. Court of Appeals, 1st Cir.: Jordan v. Lizotte
  - (2026-06-05) U.S. Court of Appeals, 1st Cir.: Premca Extra Income Fund LP v. Angle
  - (2026-06-04) U.S. Court of Appeals, 4th Cir.: Emmanuel Shaw v. T. Foreman
  - (2026-06-04) U.S. Court of Appeals, 4th Cir.: Jonathan R. v. Patrick Morrisey
  - (2026-06-04) U.S. Court of Appeals, 4th Cir.: Jonathan R. v. Patrick Morrisey
  - (2026-06-04) U.S. Court of Appeals, 4th Cir.: United States ex rel. Liesa Kyer v. Thomas Health System, Inc.

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 110 total
  - (2026-06-06) [USASpending] $22,428,178,818 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-06-06) [USASpending] $4,465,823,660 → FLUOR-BWXT PORTSMOUTH LLC: PORTSMOUTH GASEOUS DIFFUSION PLANT DECONTAMINATION AND DECOM
      Agency: Department of Energy. Description: PORTSMOUTH GASEOUS DIFFUSION PLANT DECONTAMINATION AND DECOMMISSIONING PROJECT
  - (2026-06-06) [USASpending] $3,272,481,574 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…
  - (2026-06-06) [USASpending] $2,409,248,908 → UNITED CLEANUP OAK RIDGE LLC: OAK RIDGE RESERVATION CLEANUP CONTRACT TASK ORDERS
      Agency: Department of Energy. Description: OAK RIDGE RESERVATION CLEANUP CONTRACT TASK ORDERS
  - (2026-06-06) [USASpending] $1,415,863,745 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
  - (2026-06-06) [USASpending] $786,064,460 → SERCO INC: ELIGIBILITY SUPPORT
      Agency: Department of Health and Human Services. Description: ELIGIBILITY SUPPORT

### USGS earthquakes (M4.5+, past day) — 11 new of 20 total
  - (2026-06-05) M 5.6 - Balleny Islands region
      M5.6 · Balleny Islands region · depth 10 km
  - (2026-06-05) M 5.1 - 0 km SSW of Quetzalapa, Mexico
      M5.1 · 0 km SSW of Quetzalapa, Mexico · depth 47.928 km
  - (2026-06-05) M 5.0 - Kermadec Islands region
      M5.0 · Kermadec Islands region · depth 10 km
  - (2026-06-06) M 4.9 - 47 km WSW of Magdalena, Philippines
      M4.9 · 47 km WSW of Magdalena, Philippines · depth 10 km
  - (2026-06-06) M 4.8 - 82 km W of Ambunti, Papua New Guinea
      M4.8 · 82 km W of Ambunti, Papua New Guinea · depth 93.01 km
  - (2026-06-05) M 4.7 - Izu Islands, Japan region
      M4.7 · Izu Islands, Japan region · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-06-06) Roland Garros WTA: Maja Chwalinska vs Mirra Andreeva
      yes price: 18% · 24h volume: $2,933,932 · resolves 2026-06-13
  - (2026-06-06) Will the Fed decrease interest rates by 50+ bps after the June 2026 meeting?
      yes price: 0% · 24h volume: $1,377,977 · resolves 2026-06-17
  - (2026-06-06) Will the San Antonio Spurs win the 2026 NBA Finals?
      yes price: 21% · 24h volume: $1,150,901 · resolves 2026-07-01
  - (2026-06-06) Will the New York Knicks win the 2026 NBA Finals?
      yes price: 79% · 24h volume: $1,119,554 · resolves 2026-07-01
  - (2026-06-06) Spurs vs. Knicks
      yes price: 46% · 24h volume: $1,111,868 · resolves 2026-06-09
  - (2026-06-06) Will Portugal win the 2026 FIFA World Cup?
      yes price: 10% · 24h volume: $941,525 · resolves 2026-07-20

### World News (by country, top stories) — 6 new of 6 total
  - (2026-06-06) [Japan] VV : ULTIMATUM codes ( June 2026 )
      destructoid.com · English
  - (2026-06-06) [Japan] FC 26 Champions Tokens explained : Best rewards to pick
      destructoid.com · English
  - (2026-06-06) [Japan] Which faction should you join in Gothic 1 Remake
      destructoid.com · English
  - (2026-06-06) [Japan] Monster Hunter Wilds coming to Switch 2
      nichegamer.com · English
  - (2026-06-06) [Japan] Star Wars Zero Company launches in August
      nichegamer.com · English
  - (2026-06-06) [Japan] iRacing Reveals Upgraded BMW GTP for Upcoming Season
      explosion.com · English

### GDACS — global disaster alerts — 5 new of 154 total
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-06-05) [Green] Earthquake in Balleny Islands Region
      Earthquake · Green alert · Balleny Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-05) [Green] Earthquake in Balleny Islands Region
      Earthquake · Green alert · Balleny Islands Region · Magnitude 5.6M, Depth:10km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 40 total
  - (2026-06-06) MOVER ▼ Rob Walton & family — $137.74B ($-0.33B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-06-06) MOVER ▼ Jim Walton & family — $135.03B ($-0.32B since yesterday)
      United States · Fashion & Retail · source: Walmart

### Commentary & analysis (last 7 days) — 1 new of 5 total
  - (2026-06-06) [Marginal Revolution] Should you move to Argentina? (from my email)
      My name is Josh Neuman, and I’m writing from Buenos Aires, Argentina where Peter Thiel’s move is all over the news here. He lives in [redacted], only a xx minute drive from my own apartment in Recoleta. I want to pitch a…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=0, 7d-median=30, 14d-median=30; carrying terms: proposed, persons, event, enforcement, guard, certain, public, events, waters, address, provide, vessels
- state_bills: today=141, 7d-median=141, 14d-median=141; carrying terms: protection, native, establishes, construction, purposes, engage, housing, funds, providers, license, effect, permits
- state_news: today=651, 7d-median=651, 14d-median=722; carrying terms: native, amendment, decide, congress, multiple, housing, source, republicans, johnson, tennessee, november, farmer
- local_news: today=216, 7d-median=231, 14d-median=246; carrying terms: multiple, dining, restaurant, victim, accused, south, illinois, house, final, block, public, atlanta
- foreign_news: today=832, 7d-median=844, 14d-median=861; carrying terms: forest, speaks, japan, bureau, stations, greener, arrest, worldwide, victims, delhi, tokyo, inaugural
- chinese_internal: today=268, 7d-median=270, 14d-median=271; carrying terms: china, lxtfa, cbmizefvx, https, cbmiykfvx, cbmiakfvx, cbmia, cbmib, politics, cbmickfvx, cbmibkfvx, color
- russian_internal: today=1014, 7d-median=1014, 14d-median=1021; carrying terms: financial, novayagazeta, title, httperror, axios, garros, reuters, centcom, found, politico, russian, roland
- ukrainian_internal: today=129, 7d-median=121, 14d-median=122; carrying terms: error, vechirniy, economic, babel, https, found, censor, client, kyivindependent, forbidden, forum, title
- ukraine_theater: today=360, 7d-median=279, 14d-median=308; carrying terms: acquisition, bxbxaydmjddjblwlpkakpses, japan, vugzlvh, rjmed, cuxnshn, haberleri, extra, zoruhmdnrualhmwg, bndzbzfutezod, cuxpawe, bntdrsou
- paper_bets: today=100, 7d-median=147, 14d-median=143; carrying terms: texas, special, california, hampshire, senate, world, according, release, limits, december, purposes, maine
- weather: today=173, 7d-median=100, 14d-median=112; carrying terms: urban, showers, southwest, lightning, afdmeg, lincoln, return, state, northeast, alert, afddtx, cyclones
- macro: today=21, 7d-median=10, 14d-median=0; carrying terms: spread, unrate, indicator, recession, unemployment, labor, latest, funds, treasury, rates, effective, nonfarm
- markets: today=21, 7d-median=21, 14d-median=0; carrying terms: equities, yield, china, proxy, crude, nasdaq, commodities, futures, treasury, russell, credit, range
- markets_global: today=47, 7d-median=79, 14d-median=79; carrying terms: price, crypto
- sanctions_procurement: today=110, 7d-median=110, 14d-median=103; carrying terms: administration, territorial, updates, weapons, violations, extra, latinscript, detect, launch, sovereignty, terrorist, funds
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, unauthorized, quantitative, https, quiver, httperror, quiverquant, client
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: tiktok, adani, oracle, japan, china, bloomberg, alice, madrid, peterffy, larry, holdings, india
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=60, 14d-median=30; carrying terms: america, blanche, smith, ortiz, collins, robert, society, company, state, court, schulz, wilmington
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, holdings, david, michael, finance, american, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, johnson, cortez, committee, receipts, raised, alexandria, senate, talarico, ocasio, sherrod, warner
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan
- gdelt_gkg: today=74, 7d-median=74, 14d-median=0; carrying terms: kyivpost, special, peakoil, countries, drone, russia, taiwan, russian, against, operations, message, talks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=30, 14d-median=20; carrying terms: ground, position, belgium, bulgaria, france, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: deteriorate, conflict, workers, remains, protection, director, yellow, additional, traceability, detected, recommendations, mechanical
- cisa_kev: today=10, 7d-median=15, 14d-median=15; carrying terms: remediation, vendor, product, overflow, bypass, vulnerability, authentication, cpanel, privilege, tanstack, daemon, malicious
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=154, 7d-median=127, 14d-median=127; carrying terms: estonia, depth, impact, tajikistan, japan, china, speed, flood, islamic, czech, vietnam, denmark
- usgs_quakes: today=20, 7d-median=17, 14d-median=17; carrying terms: depth, indonesia, labuan, islands, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, permanent, peace, world, price, resolves, ceasefire, announces, extension, south, roland, garros
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: conversable, revolution, class, marginal, economist, https, links, assorted, policy, marginalrevolution, economy, economic
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: teresa, knott, clark, hoyer, urban, aderholt, director, adviser, minneapolis, laura, emanuel, jared
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, module, sufficient, unavailable, identify, either, claude, converges, markets, consensus, paper, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*