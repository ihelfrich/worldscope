# WORLDSCOPE morning brief — 2026-10-15

## Headline
3514 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (831) · Russian Internal News (state + in-exile) (670) · State-Level News (410) · World leaders & government officials (324) · Chinese Internal News (245) · Local News: St. Louis + Atlanta (198) · State Legislative Action (163) · U.S. Weather + Severe / Climate Outlooks (155) · Ukraine Theater (total-war monitoring) (122) · Ukrainian Internal News (national + local Kyiv) (69) · GDACS — global disaster alerts (49) · IT, InfoSys & cybersecurity news (last 7 days) (49)

## What changed today
### International News + Multilateral Institutions — 831 new of 1034 total
  - (2026-10-15) [Global] Ukraine to restart strikes on Russian oil refineries, Zelensky says
      Russia reports a Ukrainian strike on an oil refinery on Thursday, after Ukraine's president says a pause is over following fresh Russian attacks.
  - (2026-10-15) [Global] Two dead in Istanbul after heaviest rainfall in 84 years, governor says
      Residents have been told to avoid leaving their homes unless absolutely necessary.
  - (2026-10-15) [Global] Eight crew missing after drone attack leaves tanker ablaze off Romania's coast
      A search and rescue operation is under way in the Black Sea after the latest attack in the area.
  - (2026-10-15) [Global] White House defends new press secretary amid questions about her legal credentials
      Katie Zacharia does not appear to be registered to the legal bar in any state where she has lived.
  - (2026-10-15) [Global] Brazil's Congress approves shorter working week in win for Lula
      Lula's supporters hope the measure will boost his popularity ahead of a presidential run-off in 10 days.
  - (2026-10-15) [Global] Obama says drift towards extremism 'not inevitable'
      More than 12,000 people filled a major venue in the city to hear the former US president's take on the challenges the world is facing. .

### Russian Internal News (state + in-exile) — 670 new of 1081 total
  - (2026-10-15) Украинские военные на сутки лишились Starlink. До сих пор непонятно, кто несет за это ответственность. И Илон Маск, и Белый дом говорят, что они ни при чем. В конгрессе начнут расследование | L] (ru:…
      Утром 14 октября украинские военные начали сообщать об ограничении работы Starshield — военной версии спутниковой связи Starlink, которая необходима для поддержания связи с беспилотниками, движущимися на большой скорости…
  - (2026-10-15) В России — сезон Стругацких: не успел закончиться «Трудно быть богом», как начался новый сериал «Полдень». Ни одной говорящей собаки в кадре! И вообще-то это серьезный недостаток | LEDE: В о] (ru: В Р…
      В онлайн-кинотеатрах «Кион» и «Окко» показывают сериал Клима Козинского «Полдень» по повести Аркадия и Бориса Стругацких «Жук в муравейнике». Первоисточник входит в цикл «Мир полудня» о благополучном будущем, где человеч…
  - (2026-10-15) FT: европейские лидеры попросят Зеленского поменьше критиковать Трампа | LEDE: Лидеры стран Евросоюза намерены призвать президента Украины Владимира Зеленского смягчить публичную критику в а] (ru: FT:…
      Лидеры стран Евросоюза намерены призвать президента Украины Владимира Зеленского смягчить публичную критику в адрес Дональда Трампа, сообщает Financial Times со ссылкой на источники.
  - (2026-10-15) К главреду «Новой газеты» Сергею Соколову пришли с обыском | LEDE: У главного редактора «Новой газеты» Сергея Соколова проводят обыск, сообщили близкий к силовикам телеграм-канал «База» и РБ] (ru: К г…
      У главного редактора «Новой газеты» Сергея Соколова проводят обыск, сообщили близкий к силовикам телеграм-канал «База» и РБК со ссылкой на источники в правоохранительных органах.
  - (2026-10-15) Генералы в отставке попросили отменить трансляцию казни военного, который убил 13 сослуживцев на базе Форт-Худ. Его планируют расстрелять в прямом эфире | LEDE: Группа из 72 американских ген] (ru: Ген…
      Группа из 72 американских генералов, адмиралов и других высокопоставленных военных в отставке опубликовала открытое письмо к властям США, в котором призвала отказаться от трансляции казни военнослужащего Нидала Хасана, к…
  - (2026-10-15) Правда ли, что в Евросоюзе хотят запретить россиянам обычные шенгенские визы — и разрешить поездки только в конкретную страну? | LEDE: 14 октября в Евросоюзе обсудили новые визовые ограничен] (ru: Пра…
      14 октября в Евросоюзе обсудили новые визовые ограничения для россиян. На заседании рабочей группы по визовой политике Совета ЕС в Брюсселе речь шла о выдаче гражданам РФ определенного типа виз под «необязательные» — то…

### State-Level News — 410 new of 772 total
  - (2026-10-15) [California] Governor Newsom announces appointments 10.14.26
      Source
  - (2026-10-14) [California] California’s economic dominance under Governor Newsom
  - (2026-10-14) [California] Governor Newsom directs early, proactive steps to protect California communities and strengthen local fire response ahead of dangerous Santa Ana winds and Red Flag Warnings
      Source
  - (2026-10-14) [California] Look for the Label: Governor Newsom visits Central Valley, highlights state’s manufacturing might with new Made in California program
      Source
  - (2026-10-14) [Alabama] Fourth Supplemental State of Emergency: Hurricane Isaias
      Download
  - (2026-10-15) [California] MyChart and a major hospital said I could opt out of sharing my health data. But they didn’t make it easy
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/101326-OPT-OUT-GH-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="Illu…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 245 new of 300 total
  - (2026-10-13) IMF Cuts China Growth Forecasts for 2026 and 2027 - Caixin Global
      IMF Cuts China Growth Forecasts for 2026 and 2027 Caixin Global
  - (2026-10-13) BYD Expects European Workforce to Top 40,000 by 2030 - Caixin Global
      BYD Expects European Workforce to Top 40,000 by 2030 Caixin Global
  - (2026-10-14) Chinese AI Startup StepFun Launches Smartphone to Challenge Tech Giants - Caixin Global
      Chinese AI Startup StepFun Launches Smartphone to Challenge Tech Giants Caixin Global
  - (2026-10-15) 湖北巴东： 迁改工程施工忙 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5FLVpIbHltTnVZel9YR2dyd3J6Nno3a1dxMGoxd3hHbTItTFNUOGFmXzFTc3l5NUZCNWY0R3Q0N3RlTHFPbElvc2pKY2g4YjBnX0ZkcG] (zh:…
      湖北巴东： 迁改工程施工忙 人民图片
  - (2026-10-15) 安徽马鞍山：具身机器人“上课” 忙 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFBsX2U5c3hCUm5RR2VZZDJJV0ROcmV4QlBUa1MxaVhCejVHWEo0QkVrdWgxeG9lR3JhcnVteXRkNUo3WTBXOGN5WV9zVmljdlpQS2] (zh:…
      安徽马鞍山：具身机器人“上课” 忙 人民图片
  - (2026-10-14) 山东高密： 自主游戏欢乐多 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1paXI3UFFUQ253VGZteWZoRVZpT2hKN2lUM0lwTEYtaEdOVUlYSWVnZnJWTlBvTFV0MW9qeEtZX0t6bFBKdzB3MEpQTEx5T3BWWVFiZm] (zh:…
      山东高密： 自主游戏欢乐多 人民图片

### Local News: St. Louis + Atlanta — 198 new of 235 total
  - (2026-10-15) [St. Louis] McKee’s Northside Regeneration is the target of 130 foreclosure suits filed by the city Tuesday
      On Tuesday, the City of St. Louis filed lawsuits seeking foreclosure on 173 properties with significant taxes. Three-quarters of those properties are owned by the same entity, a name that should come as no surprise: Paul…
  - (2026-10-15) [St. Louis] The Lemp Mansion ghost tour, reviewed
      One in an occasional series of irreverent reviews designed to help people navigate St. Louis in all its quirky glory. I don’t believe in ghosts, but also, I definitely saw a ghost on multiple occasions in an apartment th…
  - (2026-10-15) [St. Louis] Cinema St. Louis weathered the storm—literally—thanks to a big anonymous gift
      Not everyone thought it was a good idea when Cinema St. Louis bought the historic Hi-Pointe Theatre. It was 2023, and the world was just stumbling out of a global pandemic. Some pundits weren’t sure people would ever ret…
  - (2026-10-15) [St. Louis] Where in Clayton 10/15/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-10-14) [St. Louis] Photos: St. Louis Kids Book Club at Prairie Commons Branch
      On October 8, 2026, families gathered at the St. Louis County Library’s Prairie Commons Branch for St. Louis Magazine’s Kids Book Club, presented by PNC and The Clark Family and hosted by St. Louis County Library. The mo…
  - (2026-10-14) [St. Louis] New Kids Who Travel Club connects St. Louis families who love to explore
      Traveling with kids is a whole different adventure. There are strollers to pack, naps to plan around, enough snacks to feed a small army, and the occasional airport meltdown. But St. Louis mom Amanda Reyna believes havin…

### State Legislative Action — 163 new of 171 total
  - (2026-10-15) [Alaska SB 24] An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco,…
      An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco, a product containing nicotine, or…
  - (2026-10-15) [Alaska HB 261] An Act relating to education funding; providing for an effective date by amending the effective date of secs. 10, 11, 13, and 15, ch. 5, SLA 2025; and providing for an effective date.
      An Act relating to education funding; providing for an effective date by amending the effective date of secs. 10, 11, 13, and 15, ch. 5, SLA 2025; and providing for an effective date.
  - (2026-10-15) [Alaska HB 280] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and tele…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and telecommunications service providers; an…
  - (2026-10-15) [Alaska SB 167] An Act relating to eligibility of criminal offenders for certain benefits, including the permanent fund dividend; relating to a permanent fund dividend for an individual whose convicti…
      An Act relating to eligibility of criminal offenders for certain benefits, including the permanent fund dividend; relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or di…
  - (2026-10-15) [Alaska SB 26] An Act petitioning the United States Department of Transportation to change the time zones of Alaska; exempting the state from daylight saving time; and providing for an effective date.
      An Act petitioning the United States Department of Transportation to change the time zones of Alaska; exempting the state from daylight saving time; and providing for an effective date.
  - (2026-10-15) [Alaska HB 104] An Act creating and relating to the address confidentiality program; and providing for an effective date.
      An Act creating and relating to the address confidentiality program; and providing for an effective date.

### U.S. Weather + Severe / Climate Outlooks — 155 new of 157 total
  - (2026-10-15) [Severe] Flash Flood Warning: Flash Flood Warning issued October 15 at 6:31AM CDT until October 15 at 8:00AM CDT by NWS Midland/Odessa TX
      At 631 AM CDT, Doppler radar indicated thunderstorms producing heavy rain across the warned area. Between 0.5 and 1.5 inches of rain have fallen. Additional rainfall amounts up to 0.5 inches are possible in the warned ar…
  - (2026-10-15) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-15) [Severe] Flash Flood Warning: Flash Flood Warning issued October 15 at 6:25AM CDT until October 15 at 9:00AM CDT by NWS Norman OK
      FFWOUN The National Weather Service in Norman has extended the * Flash Flood Warning for... Southeastern Comanche County in southwestern Oklahoma... Cotton County in southwestern Oklahoma... * Until 900 AM CDT. * At 625…
  - (2026-10-15) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 15 at 6:19AM CDT until October 15 at 10:00AM CDT by NWS Jackson MS
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...In Louisiana, Catahoula and Concordia Counties. In Mississippi, Lincoln, Adams, Franklin MS, and Jefferson Counties. * WHEN...Until 10 AM CDT this morn…
  - (2026-10-15) [Moderate] Special Weather Statement: Special Weather Statement issued October 15 at 7:14AM EDT by NWS Jackson KY
      Fog will bring localized visibility of a quarter mile or less this morning. Motorists are urged to slow down, use low beam headlights, and leave extra distance between vehicles when encountering dense fog.
  - (2026-10-15) [Moderate] Gale Watch: Gale Watch issued October 15 at 6:13AM CDT until October 17 at 1:00PM CDT by NWS Houston/Galveston TX
      * WHAT...North winds 25 to 35 kt with gusts over 40 kt and seas 7 to 13 ft possible. * WHERE...Galveston Bay, Matagorda Bay, and the adjacent Gulf waters. * WHEN...From Friday afternoon through Saturday afternoon. * IMPA…

### Ukraine Theater (total-war monitoring) — 122 new of 409 total
  - (2026-10-15) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-14) [FIRMS] thermal anomaly 51.140, 23.551 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-14 0130Z, FRP 0.8 MW
  - (2026-10-14) [FIRMS] thermal anomaly 49.035, 28.115 (FRP 0.82 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-14 0130Z, FRP 0.82 MW
  - (2026-10-14) [FIRMS] thermal anomaly 51.320, 29.192 (FRP 4.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-14 0937Z, FRP 4.53 MW
  - (2026-10-14) [FIRMS] thermal anomaly 52.846, 29.988 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-14 0130Z, FRP 1.95 MW
  - (2026-10-14) [FIRMS] thermal anomaly 52.845, 29.993 (FRP 1.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-14 0130Z, FRP 1.77 MW

### Ukrainian Internal News (national + local Kyiv) — 69 new of 130 total
  - (2026-10-15) Британія виділить 17 млн фунтів на ремонт укриття Чорнобильської АЕС | LEDE: ] (uk: Британія виділить 17 млн фунтів на ремонт укриття Чорнобильської АЕС)
  - (2026-10-15) Росіяни вдарили дроном по продуктовому супермаркету на Одещині: є постраждалі | LEDE: Росія завдала удару реактивним БпЛА по “Таврія В” в Одеській області. Поранено трьох людей, магазин частков] (uk:…
      Росія завдала удару реактивним БпЛА по “Таврія В” в Одеській області. Поранено трьох людей, магазин частково зруйнований – подробиці від Зеленського.
  - (2026-10-15) Каллас підтримала поновлення ударів по НПЗ РФ: Тиснути слід на Росію, а не на Україну | LEDE: Очільниця дипломатії ЄС заявила, що удари України по нафтопереробних заводах РФ допоможуть зупинити] (uk:…
      Очільниця дипломатії ЄС заявила, що удари України по нафтопереробних заводах РФ допоможуть зупинити фінансування війни.
  - (2026-10-15) Українські інкасатори судитимуться в ЄСПЛ з Угорщиною | LEDE: ] (uk: Українські інкасатори судитимуться в ЄСПЛ з Угорщиною)
  - (2026-10-15) Рада знову звернулась до Зеленського щодо присвоєння Рощиній звання Героя України посмертно | LEDE: Парламент направив запит президенту про присвоєння журналістці Вікторії Рощиній звання Героя ] (uk:…
      Парламент направив запит президенту про присвоєння журналістці Вікторії Рощиній звання Героя України посмертно.
  - (2026-10-15) Гора Монблан втратила понад метр висоти за рік | LEDE: ] (uk: Гора Монблан втратила понад метр висоти за рік)

### GDACS — global disaster alerts — 49 new of 100 total
  - (2026-10-14) [Orange] Tropical Cyclone CHAMPI-26
      Tropical Cyclone · Orange alert · Guam, Northern Mariana Islands · Tropical Depression (maximum wind speed of 231 km/h)
  - (2026-10-15) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.6M, Depth:1km
  - (2026-10-15) [Green] Earthquake in New Zealand
      Earthquake · Green alert · New Zealand · Magnitude 5.3M, Depth:286.008km
  - (2026-10-15) [Green] Earthquake in Samoa
      Earthquake · Green alert · Samoa · Magnitude 4.8M, Depth:13.468km
  - (2026-10-07) [Green] Forest fires in Bolivia
      Wildfire · Green alert · Bolivia · Green impact for forestfire in 10166 ha
  - (2026-10-07) [Green] Forest fires in Brazil
      Wildfire · Green alert · Brazil · Green impact for forestfire in 10053 ha

### IT, InfoSys & cybersecurity news (last 7 days) — 49 new of 59 total
  - (2026-10-15) [BleepingComputer] Microsoft fixes bug causing Windows black screens, Explorer crashes
      Microsoft has resolved a known issue that was causing black screens, desktop loading issues, and Explorer crashes after installing Windows 11 updates released since August. [...]
  - (2026-10-15) [BleepingComputer] UK Legal Aid Agency: Hackers stole records dating back to 1978
      The Legal Aid Agency (LAA), an executive agency of the UK's Ministry of Justice that manages the country's Public Defender Service, says attackers who breached its IT systems in April 2025 stole records dating back to 19…
  - (2026-10-15) [The Hacker News] India Mandates Registered Caller Name Display on 4G and Newer Networks From November 1
      The Indian government has directed telecom service providers (TSPs) in the country to mandatorily display callers' registered names along with their numbers for incoming calls starting November 1, 2026, in an effort to h…
  - (2026-10-15) [The Hacker News] GhostAction Compromises About 1,900 GitHub Accounts, Targets Over 30,000 Repositories
      The credential-theft campaign known as GhostAction has ramped up, targeting more than 30,000 repositories across 3,000 users and organizations. The spike, according to GitGuardian, was observed on October 8 and 9, 2026.…
  - (2026-10-15) [The Hacker News] Langflow's Critical Authenticated RCE Flaw Targeted in 1,423 Honeypot Exploit Attempts
      Threat actors are exploiting a critical security flaw in Langflow, according to an alert from Previdian. Langflow is an open-source platform that allows developers to build artificial intelligence (AI) applications and a…
  - (2026-10-15) [The Hacker News] AhsayCBS Flaws Exploited to Deploy Web Shells Get New Fixes After Incomplete Patches
      Singapore-based Ahsay Backup has released security updates to address two security flaws in AhsayCBS that have been exploited by bad actors to drop web shells and XMRig cryptocurrency miners. The vulnerabilities in quest…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-15) [Zhao Bin] Form 4 (Reporting)
      filed 2026-10-15 10:56 UTC · role: Reporting — Filed: 2026-10-15 AccNo: 0001193125-26-422252 Size: 11 KB
  - (2026-10-15) [Agora, Inc.] Form 4 (Issuer)
      filed 2026-10-15 10:56 UTC · role: Issuer — Filed: 2026-10-15 AccNo: 0001193125-26-422252 Size: 11 KB
  - (2026-10-15) 424B3 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-10-15 10:51 UTC — Filed: 2026-10-15 AccNo: 0001213900-26-109572 Size: 1 MB
  - (2026-10-15) 424B3 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-10-15 10:51 UTC — Filed: 2026-10-15 AccNo: 0001213900-26-109572 Size: 1 MB
  - (2026-10-15) [EVgo Inc.] Form 4 (Issuer)
      filed 2026-10-15 10:39 UTC · role: Issuer — Filed: 2026-10-15 AccNo: 0001783152-26-000002 Size: 9 KB
  - (2026-10-15) [Seelig Jonathan] Form 4 (Reporting)
      filed 2026-10-15 10:39 UTC · role: Reporting — Filed: 2026-10-15 AccNo: 0001783152-26-000002 Size: 9 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 28 total
  - (2026-10-15) JAF9XT (Bulgaria)
      icao24: 4520ce · position: (37.2262, -4.1429) · alt: 10675m · 838km/h
  - (2026-10-15) JAF95J (Bulgaria)
      icao24: 4520aa · position: (41.7728, -2.1432) · alt: 11277m · 842km/h
  - (2026-10-15) INDIA1 (India)
      icao24: 8002fb · position: (28.5681, 77.1124) · on ground · 21km/h
  - (2026-10-15) SAMU71 (France)
      icao24: 398c4e · position: (46.7915, 4.8038) · alt: 320m · 249km/h
  - (2026-10-15) CFC4283 (Canada)
      icao24: c2b5cb · position: (57.0374, 22.6849) · alt: 6598m · 598km/h
  - (2026-10-15) CFC2537 (Canada)
      icao24: c2b599 · position: (40.0192, -5.4418) · alt: 8221m · 601km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-10-15) [Russia oil sanctions perimeter · themes] No Casualties as 33 , 000 - Litre Ethanol Truck Falls off Lagos Bridge
      quicknews-africa.net · English · tone NA
  - (2026-10-15) [Russia oil sanctions perimeter · themes] Vertice Ue Kallas LEuropa deve fare pressione su Mosca non su Kiev per la pace
      laregione.ch · Italian · tone NA
  - (2026-10-15) [Russia oil sanctions perimeter · themes] AP Business SummaryBrief at 5 : 28 a . m . EDT
      mankatofreepress.com · English · tone NA
  - (2026-10-15) [Russia oil sanctions perimeter · themes] Aboud to pay adviser $25 , 000
      trinidadexpress.com · English · tone NA
  - (2026-10-15) [Russia oil sanctions perimeter · themes] Ουκρανία : Ο Ζελένσκι προαναγγέλλει νέες επιθέσεις στα ρωσικά διυλιστήρια – Ζητά Patriot για νέα παύση
      lifo.gr · Greek · tone NA
  - (2026-10-15) [Russia oil sanctions perimeter · themes] दुई महिनामा सवा तीन खर्ब नाघ्यो व्यापार घाटा , निर्यातमा भने ६२ प्रतिशतको छलाङ | Nepal first 24 - hour updated news portal
      ratopati.com · Nepali · tone NA

### U.S. Federal Action — 23 new of 33 total
  - (2026-10-15) Airworthiness Directives; Airbus Helicopters Deutschland GmbH (AHD) Helicopters
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus Helicopters Deutschland GmbH (AHD) Model MBB-BK 117 D-2 helicopters. This proposed AD was prompted by certification test results of a certain co…
  - (2026-10-15) Fisheries of the Exclusive Economic Zone off Alaska; Pacific Ocean Perch in the Central Regulatory Area of the Gulf of Alaska
      NMFS is prohibiting retention of the incidental catch allowance for Pacific Ocean perch in the Central Regulatory Area of the Gulf of Alaska (GOA) except by vessels checked-in to the Central GOA Rockfish Program who are…
  - (2026-10-15) Family and Medical Leave Act
      The Office of Personnel Management (OPM) is issuing a direct final rule making technical revisions to OPM's Family and Medical Leave Act (FMLA) regulations to incorporate various statutory amendments. The rule reflects s…
  - (2026-10-15) Standard Instrument Approach Procedures, and Takeoff Minimums and Obstacle Departure Procedures; Miscellaneous Amendments
      This rule establishes, amends, suspends, or removes Standard Instrument Approach Procedures (SIAPS) and associated Takeoff Minimums and Obstacle Departure procedures (ODPs) for operations at certain airports. These regul…
  - (2026-10-15) Standard Instrument Approach Procedures, and Takeoff Minimums and Obstacle Departure Procedures; Miscellaneous Amendments
      This rule amends, suspends, or removes Standard Instrument Approach Procedures (SIAPs) and associated Takeoff Minimums and Obstacle Departure Procedures for operations at certain airports. These regulatory actions are ne…
  - (2026-10-15) Central Liquidity Facility
      The NCUA Board (Board) is proposing to adopt as final the revisions to the Central Liquidity Facility (CLF) rule made under two interim final rules (IFRs) published in the Federal Register on April 29, 2020, and March 24…

### Court opinions of consequence (federal & state) — 20 new of 60 total
  - (2026-10-14) U.S. Supreme Court: FCC v. Brown
  - (2026-10-14) U.S. Court of Appeals, 9th Cir.: United States v. State of California
  - (2026-10-14) U.S. Court of International Trade: CS Wind Malaysia Sdn. Bhd. v. United States
  - (2026-10-14) U.S. Court of Appeals, 3rd Cir.: Delaware Riverkeeper Network v. Pennsylvania Environmental Hearing Board
  - (2026-10-14) U.S. Court of Appeals, 3rd Cir.: Lisa Debar v. FirstEnergy Corp
  - (2026-10-14) U.S. Court of Appeals, 3rd Cir.: Sofiqul Islam v. Attorney General United States of America

### Paper Trading Scorecard — 19 new of 84 total
  - (2026-10-15) [Manifold] Will the October surprises destroy Democrats' chances of winning the midterms in 2026?
  - (2026-10-15) [Manifold] Will Katie Hobbs win reelection for Arizona governor in 2026?
  - (2026-10-15) [Manifold] Will OpenAI announce a massively recursive model, a new mechinterp system, and non-token based pricing, before December?
  - (2026-10-15) [Manifold] will my squishies last 1 year?
  - (2026-10-15) [Manifold] Will Zvi write a full capabilities report on Gemini 4 Argon?
  - (2026-10-15) [Manifold] Will Zvi write a full report on Muse Wonder?

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-10-15) Will the Fed increase interest rates by 25 bps after the October 2026 meeting?
      yes price: 28% · 24h volume: $1,564,592 · resolves 2026-10-29
  - (2026-10-15) LoL: Team WE vs HANJIN BRION (BO5) - Demacia Cup Global Invitational Playoffs
      yes price: 76% · 24h volume: $1,273,935 · resolves 2026-10-15
  - (2026-10-15) LoL: Team WE vs HANJIN BRION - Game 1 Winner
      yes price: 100% · 24h volume: $1,158,377 · resolves 2026-10-15
  - (2026-10-15) LoL: Team WE vs HANJIN BRION - Game 2 Winner
      yes price: 100% · 24h volume: $1,049,455 · resolves 2026-10-15
  - (2026-10-15) LoL: Team WE vs HANJIN BRION - Game 3 Winner
      yes price: 0% · 24h volume: $953,383 · resolves 2026-10-15
  - (2026-10-15) Will the Fed increase interest rates by 50+ bps after the October 2026 meeting?
      yes price: 0% · 24h volume: $910,924 · resolves 2026-10-29

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 107 total
  - (2026-10-14) [OFAC] Venezuela-related Designation Removal - Office of Foreign Assets Control (.gov)
      Venezuela-related Designation Removal Office of Foreign Assets Control (.gov)
  - (2026-10-15) [USASpending] $17,732,163,524 → HONEYWELL FEDERAL MANUFACTURING & TECHNOLOGIES, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SEC
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATION OF THE NATIONAL SECURITY CAMPUS -- CONTRACT NO. DE-NA0002839
  - (2026-10-15) [USASpending] $2,985,859,581 → CALIFORNIA INSTITUTE OF TECHNOLOGY: EUROPA CLIPPER PROJECT THE CONTRACT IS THE SPONSORING AGREE
      Agency: National Aeronautics and Space Administration. Description: EUROPA CLIPPER PROJECT THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION NASA AND THE CALIFORNIA INSTIT…
  - (2026-10-15) [USASpending] $561,184,437 → BOOZ ALLEN HAMILTON INC: AWARD OF TASK ORDER 47QFCA23F0058 FOR DATA MODERNIZATION ACC
      Agency: General Services Administration. Description: AWARD OF TASK ORDER 47QFCA23F0058 FOR DATA MODERNIZATION ACCELERATOR FOR CDC (DMAC).
  - (2026-10-15) [USASpending] $539,458,571 → LOCKHEED MARTIN CORPORATION: THE LOW BOOM FLIGHT DEMONSTRATOR (LBFD) CONTRACT IS FOR THE
      Agency: National Aeronautics and Space Administration. Description: THE LOW BOOM FLIGHT DEMONSTRATOR (LBFD) CONTRACT IS FOR THE DESIGN, CONSTRUCTION, AND FLIGHT VALIDATION OF A RESEARCH AIRCRAFT THAT CREATES A SHAPED SON…
  - (2026-10-15) [USASpending] $449,574,000 → GUIDEHOUSE INC.: THE PURPOSE OF THIS REQUIREMENT FOR GRANTS PROGRAM SOLUTIONS
      Agency: Department of the Interior. Description: THE PURPOSE OF THIS REQUIREMENT FOR GRANTS PROGRAM SOLUTIONS AND IT SUPPORT SERVICES IS TO PROVIDE EFFICIENT AND EFFECTIVE GRANT, FINANCIAL, AND CONTRACT MANAGEMENT SERVIC…

### USGS earthquakes (M4.5+, past day) — 5 new of 5 total
  - (2026-10-15) M 5.6 - 43 km NNW of Lake Minchumina, Alaska
      M5.6 · 43 km NNW of Lake Minchumina, Alaska · depth 4.5 km
  - (2026-10-15) M 5.3 - 43 km SSE of Otorohanga, New Zealand
      M5.3 · 43 km SSE of Otorohanga, New Zealand · depth 286.008 km
  - (2026-10-15) M 5.1 - 36 km E of Safotu, Samoa
      M5.1 · 36 km E of Safotu, Samoa · depth 13.211 km
  - (2026-10-15) M 4.8 - 30 km E of Safotu, Samoa
      M4.8 · 30 km E of Safotu, Samoa · depth 13.468 km
  - (2026-10-14) M 4.5 - 82 km SSW of Mil’kovo, Russia
      M4.5 · 82 km SSW of Mil’kovo, Russia · depth 183.497 km

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 15 total
  - (2026-10-14) CVE-2026-105134 · Ahsay AhsayCBS: Ahsay AhsayCBS Command Injection Vulnerability
      vendor: Ahsay · product: AhsayCBS · CISA remediation by 2026-10-17
  - (2026-10-14) CVE-2026-76519 · Cisco Secure Email Gateway: Cisco Secure Email Gateway Relative Path Traversal Vulnerability
      vendor: Cisco · product: Secure Email Gateway · CISA remediation by 2026-10-17
  - (2026-10-14) CVE-2026-105133 · Ahsay AhsayCBS: Ahsay AhsayCBS Improper Authentication Vulnerability
      vendor: Ahsay · product: AhsayCBS · CISA remediation by 2026-10-17
  - (2026-10-14) CVE-2026-0322 · Palo Alto Networks PAN-OS: Palo Alto Networks PAN-OS Code Injection Vulnerability
      vendor: Palo Alto Networks · product: PAN-OS · CISA remediation by 2026-10-17

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-15) [Marginal Revolution] Astra Held Its Ground (Truth)
      TheoPhysEval: We present a suite of 50 unpublished research-level theoretical physics problems with verifiable answers. Without AI assistance, a typical problem in our collection could be solved by a world expert in abou…
  - (2026-10-15) [Marginal Revolution] Why I do not use LLMs more
      They are so very, very good at matching me to the books I wish to read and the music I wish to listen to. In this odd sense they are not very sticky. The LLMs are amazing, but the world is awesome too! Thus the LLMs keep…
  - (2026-10-15) [Marginal Revolution] My excellent Conversation with Liaquat Ahamed
      Here is the audio, video, and transcript. Here is part of the episode summary: They start with that puzzle before moving through Gladstone’s startlingly self-interested bet on Egyptian bonds, Bismarck’s role in destroyin…
  - (2026-10-14) [Conversable Economist] The Nobel Prize to Hall and Woodford: A Macroeconomic Journey
      The Sveriges Riksbank Prize in Economic Sciences in Memory of Alfred Nobel 2026 has been awarded to Robert E. Hall and Michael Woodford “”for microeconomic foundations of macroeconomic stabilisation.” To gain some intuit…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-15) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=33, 7d-median=26, 14d-median=26; carrying terms: safety, final, national, period, regulatory, proposes, proposing, certain, public, action, order, proposed
- state_bills: today=171, 7d-median=73, 14d-median=78; carrying terms: relating, school, providing, education, administration, state, effective, alaska, district, subject, contracts, insurance
- state_news: today=772, 7d-median=667, 14d-median=682; carrying terms: women, supporters, library, apply, calmatters, grants, process, customs, market, special, obituary, width
- local_news: today=235, 7d-median=223, 14d-median=229; carrying terms: woman, residents, student, metro, among, county, school, trump, still, content, killed, making
- foreign_news: today=1034, 7d-median=1018, 14d-median=1018; carrying terms: track, areas, women, jakarta, troops, market, special, league, fired, dialogue, economy, bottom
- chinese_internal: today=300, 7d-median=300, 14d-median=282; carrying terms: cbmizkfvx, cbmiykfvx, cbmickfvx, china, cbmiyefvx, cbmigwfbvv, google, https, articles, color, cbmia, blank
- russian_internal: today=1081, 7d-median=1061, 14d-median=1068; carrying terms: raquo, bloomberg, https, russian, reuters, error, istories, media, politico, forbidden, telegram, title
- ukrainian_internal: today=130, 7d-median=136, 14d-median=136; carrying terms: security, three, civilian, killing, troops, independent, civilians, damaged, europe, washington, authorities, defense
- ukraine_theater: today=409, 7d-median=433, 14d-median=522; carrying terms: ktlvem, ucudwnmrsyxr, nxrgrltzlycgp, mdvkz, czvfcjlcc, cbmirafbvv, yaemttujuahzxadr, szzsoc, ldujwd, ebfjzyjixzfitbelvuddbzerdunm, monastery, cfhguv
- paper_bets: today=84, 7d-median=68, 14d-median=114; carrying terms: season, humans, koivun, henry, yards, drought, participation, playoff, celsius, miles, sachs, goals
- weather: today=157, 7d-median=150, 14d-median=146; carrying terms: counties, friday, details, areas, hazardous, valley, degrees, afdmfl, along, afdlox, tropical, hurricane
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpilfesl, rates, vixcls, sheet, spread, treasury, recession, consumption, dexchus, latest, growth, walcl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, equities, bitcoin, proxy, rates, futures, russell, nasdaq, range, agriculture, treasury, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=107, 7d-median=111, 14d-median=112; carrying terms: bosnia, control, areas, security, cbmizefvx, terrorist, energy, guinea, federation, laboratory, violations, maintenance
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, error, httperror, https, congresstrading, quiver, quiverquant, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: corporation, james, supreme, appeals, state, company, court, board, alabama, division, brown, arkansas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, financial, trust, filer, jpmorgan, chase
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, david, raised, congress, angels, elect, krishnamoorthi, booker, talarico, ocasio, trone, cooper
- gdelt_regions: today=0, 7d-median=1, 14d-median=1
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: themes, english, italian, spanish, vietnamese, chinese, russia, perimeter, russian, sanctions, business, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=28, 7d-median=28, 14d-median=30; carrying terms: belgium, position, kingdom, germany, france, ground, canada, bulgaria, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: animals, brands, rajshahi, burial, humans, toxin, however, consecutive, mainly, hospitalized, increasing, dicale
- cisa_kev: today=15, 7d-median=13, 14d-median=14; carrying terms: bounds, restriction, vulnerability, netscaler, cisco, product, within, remediation, memory, injection, traversal, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: orange, maximum, depth, cyclone, forest, tropical, earthquake, hurricane, australia, speed, mongolia, papua
- usgs_quakes: today=5, 7d-median=21, 14d-median=17; carrying terms: depth, russia, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: shakhtar, league, donetsk, volume, price, october, champions, championship, presidential, resolves, election, brazilian
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, economist, class, revolution, conversable, marginal, spend, spending, money, public, trillion, remember
- tech_news: today=59, 7d-median=60, 14d-median=58; carrying terms: security, bleepingcomputer, report, going, software, computer, vulnerability, cybersecurity, today, spectrum, agents, campaign
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: angus, tuberville, carbajal, ellzey, corporation, garamendi, guest, collins, clarke, salazar, williams, communications
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, module, market, decision, markets, placement, either, today, unavailable, placed, sufficient, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-10-07] Fed press (events + announcements): Minutes of the Federal Open Market Committee, September 15-16, 2026
- [2026-10-08] ECB press: Piero Cipollone: Interview with Corriere della Sera
- [2026-10-08] Fed speeches: Waller, The Signaling Value of the Summary of Economic Projections
- [2026-10-08] ECB press: Meeting of 9-10 September 2026
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*