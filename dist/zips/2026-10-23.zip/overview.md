# WORLDSCOPE morning brief — 2026-10-23

## Headline
3226 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (826) · Russian Internal News (state + in-exile) (681) · State-Level News (361) · World leaders & government officials (324) · Chinese Internal News (221) · Local News: St. Louis + Atlanta (208) · U.S. Weather + Severe / Climate Outlooks (135) · Ukraine Theater (total-war monitoring) (82) · Ukrainian Internal News (national + local Kyiv) (71) · State Legislative Action (65) · IT, InfoSys & cybersecurity news (last 7 days) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 826 new of 1029 total
  - (2026-10-22) [Global] Lewis Hamilton aims to extend career till early 2030s so he can race in African Grand Prix
  - (2026-10-23) [Global] Brazil’s election and the battle for the Amazon – podcast
  - (2026-10-22) [Global] Alberta welcomed migrant workers. Now, it wants to restrict their rights
  - (2026-10-23) [Global] Duchess of Sussex ‘deeply distressed’ over child sexual abuse image claims against father
  - (2026-10-23) [Global] Magnitude-7 earthquake hits Tibet, killing at least 16 and destroying hundreds of homes
  - (2026-10-23) [Global] Jordon Steele-John’s position remains in limbo as Greens prepare for moment in spotlight

### Russian Internal News (state + in-exile) — 681 new of 1135 total
  - (2026-10-23) Война. 1703-й день. США предлагают создать в Донбассе демилитаризованную зону. Киев: Украина не сдает свои территории. Путин: это территория исторической России | LEDE: «Медуза» с 24 февраля] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-23) «Би-би-си» рассказала о россиянине Фоме, который организует слежку за военными и помог подготовить убийство генерала Фанила Сарварова. Человек с таким же псевдонимом участвует в эфирах The Brea] (ru:…
      В декабре 2025 года в Москве при взрыве автомобиля погиб генерал-лейтенант Фанил Сарваров — начальник управления оперативной подготовки Генштаба Вооруженных сил России. Это убийство помог подготовить россиянин, который у…
  - (2026-10-23) Бывший директор канала «Спас» рассказал о «замироточившей» фотографии бойца батальона «Эспаньола», убитого на войне с Украиной | LEDE: Бывший директор телеканала «Спас» Борис Костенко, заним] (ru: Быв…
      Бывший директор телеканала «Спас» Борис Костенко, занимающий пост советника госсекретаря Союзного государства России и Беларуси, заявил, что фотография одного из бойцов батальона «Эспаньола», убитого на войне с Украиной,…
  - (2026-10-23) Украина атаковала Городец в Нижегородской области. Там расположен дата-центр Федеральной налоговой службы | LEDE: В ночь на 23 октября в Городце Нижегородской области был атакован центр обра] (ru: Укр…
      В ночь на 23 октября в Городце Нижегородской области был атакован центр обработки данных Федеральной налоговой службы (ФНС) России, сообщил украинский мониторинговый канал Exilenova+.
  - (2026-10-23) Трамп попросил Google переименовать Атлантический океан в свою честь. Ему отказали | LEDE: Дональд Трамп обратился к руководству компании Google с просьбой переименовать Атлантический океан,] (ru: Тра…
      Дональд Трамп обратился к руководству компании Google с просьбой переименовать Атлантический океан, но получил отказ.
  - (2026-10-23) ФСБ велела отключить сайты критической инфраструктуры России из-за уязвимостей в языке программирования PHP | LEDE: Центр кибербезопасности при ФСБ потребовал от организаций, отвечающих за к] (ru: ФСБ…
      Центр кибербезопасности при ФСБ потребовал от организаций, отвечающих за критическую информационную инфраструктуру России, временно отключить свои сайты, если они не могут быстро обновить программное обеспечение для защи…

### State-Level News — 361 new of 757 total
  - (2026-10-23) [California] Governor Newsom announces clemency actions
      Source
  - (2026-10-23) [California] Governor Newsom announces appointments 10.22.2026
      Source
  - (2026-10-22) [California] Governor Newsom welcomes first Cal State LA bachelor’s cohort at San Quentin as California crime rates reach historic lows
      Source
  - (2026-10-22) [California] Governor Newsom announces interagency effort to coordinate California’s public safety strategy into the future
      Source
  - (2026-10-23) [Alaska] Red Ribbon Week 2026
      WHEREAS, drug and alcohol misuse causes harmful and lasting effects to individuals, families and communities across Alaska and the Nation; and WHEREAS, it is imperative that community members launch visible and unified e…
  - (2026-10-23) [Connecticut] CT’s new money curriculum should start at the check cashing counter
      <img width="1024" height="664" src="https://ctmirror.org/wp-content/uploads/2026/10/check-book-1024x664.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 221 new of 264 total
  - (2026-10-22) 安全是底座、智能是引擎、出海是纵深，世界智能网联汽车大会释放三重信号 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5kdHFUamZwRUJRZlFpdnU2VmtkYjJNRWcyU0ZTSXl5S2dVVjBlTjZPR2lOSDJvWldJdGRqRi1aeTF0Qm1QN] (zh:…
      安全是底座、智能是引擎、出海是纵深，世界智能网联汽车大会释放三重信号 观察者网
  - (2026-10-22) 杭州警方通报：盘石集团涉嫌合同诈骗被立案，田某等被采取刑事强制措施 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBYc3F2cVRmNTQ4MkZjcms1bERzUWRCc2FDUTFneVlPSVVyb3o3bm80MV9wWXAxVHl3ZU5hY1FPWnp5ZjJqYm] (zh:…
      杭州警方通报：盘石集团涉嫌合同诈骗被立案，田某等被采取刑事强制措施 观察者网
  - (2026-10-23) 这两年全世界好像不怎么关心环保了，我们中国为啥还在坚定推动呢？ - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFByYTJydkFSdU1TMWY2WlFsSWkzeHFlb1ZKVHl1aVd4Y0daa25ZREpncGN2RW4wVEZvcTJWdEwwNFV6Q2dxRHJy] (zh:…
      这两年全世界好像不怎么关心环保了，我们中国为啥还在坚定推动呢？ 观察者网
  - (2026-10-23) 核意味？纯属科普？仅供学习？“全电推进”核动力航母 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE9FWkVyaXZEMzVLaGdOX1hJQjhMU2Fsak1fTkVFcjRzaFlscGh1V2tXUkdBdV9GcHphMWpWODR5dDJKTmk0cGFTOFdDUE1m] (zh:…
      核意味？纯属科普？仅供学习？“全电推进”核动力航母 风闻
  - (2026-10-22) 医学博士生在综艺称“诊断靠盲猜”“博士不上临床”，校方回应 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBhbzNYNFd3WWpaMGI4MTZkVmZNM0ZpWTRTWm1HSzE5WnlmdnNYMmpBQzRlckI0X0F0aXo4c2lfT1pveTY1WWpCek] (zh:…
      医学博士生在综艺称“诊断靠盲猜”“博士不上临床”，校方回应 观察者网
  - (2026-10-23) CLDN18.2：胃癌精准治疗新靶标的病理学解析 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBkZmxKRHpyU01qZzBzdXQxMmdiMnpmcHJvbDZWT3Jrd2Y3WmJIaE83c3Iyc0xlajJZX3dkeV9NaUMwZHBsXzc2TFBVR3dmZ] (zh:…
      CLDN18.2：胃癌精准治疗新靶标的病理学解析 风闻

### Local News: St. Louis + Atlanta — 208 new of 248 total
  - (2026-10-23) [St. Louis] How the death of 2 CIA agents in northern Mexico led to a treason case
      A former Mexican official could face trial for treason after an illegal joint operation with the CIA caused two deaths.
  - (2026-10-23) [St. Louis] Pope Leo XIV cancels Assisi trip after lung surgery on doctors' advice
      Pope Leo XIV cancels Assisi trip after doctors advise against a helicopter journey as he recovers from thoracic surgery.
  - (2026-10-23) [St. Louis] A 29-year-old sex offender went to jail trying to enroll in high school. A year later, they tried again, police say.
      Police say Makayla Craig tried to enroll in a Minnesota high school, a year after going to jail in Oregon for the same thing.
  - (2026-10-23) [St. Louis] Election officials debunk viral misinformation about ballot validity in St. Louis area
      Election officials in the St. Louis area are debunking viral misinformation that claims poll worker initials invalidate ballots, clarifying it's required by law.
  - (2026-10-23) [St. Louis] Trump calls LeBron James a 'disgrace' for not standing still during national anthem
      President Donald Trump accused LeBron James of disrespecting the United States after James appeared to continue his warmups while the national anthem was performed.
  - (2026-10-23) [St. Louis] VERIFY: Can tax-exempt churches tell voters how to vote in elections?
      A St. Louis-area church is urging voters to take a position on Amendment 3. VERIFY examines what federal law allows churches to enter the debate.

### U.S. Weather + Severe / Climate Outlooks — 135 new of 136 total
  - (2026-10-23) [Severe] Flood Warning: Flood Warning issued October 23 at 4:39AM MST until October 23 at 7:45AM MST by NWS Flagstaff AZ
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Chinle Creek from Chinle to Rock Point. * WHEN...Until 845 AM MDT. * IMPACTS...Flooding of Chinle Creek is occurring. * ADDITIONAL DETAILS... - At 537 A…
  - (2026-10-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-23) [Severe] Flood Warning: Flood Warning issued October 23 at 5:34AM MDT until October 23 at 7:45AM MDT by NWS Grand Junction CO
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Southwestern San Juan County in southeastern Utah... * WHEN...Until 745 AM MDT. * IMPACTS...Flooding of rivers, creeks, streams, and other low-lying and…
  - (2026-10-23) [Severe] Flood Warning: Flood Warning issued October 23 at 5:33AM MDT until October 23 at 7:45AM MDT by NWS Grand Junction CO
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Southwestern Grand County in east central Utah... Northeastern San Juan County in southeastern Utah... * WHEN...Until 745 AM MDT. * IMPACTS...Flooding o…
  - (2026-10-23) [Severe] Flood Warning: Flood Warning issued October 23 at 4:33AM MST until October 23 at 11:00AM MST by NWS Flagstaff AZ
      * WHAT...Flooding caused by excessive rainfall continues within Oak Creek. * WHERE...Oak Creek in Coconino and Yavapai counties. * WHEN...Until 1100 AM MST Friday. * IMPACTS...Flooding of Oak Creek is occurring. Deadly f…
  - (2026-10-23) [Severe] Flood Warning: Flood Warning issued October 23 at 5:32AM MDT until October 23 at 7:45AM MDT by NWS Grand Junction CO
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Archuleta County in southwestern Colorado... * WHEN...Until 745 AM MDT. * IMPACTS...Flooding of rivers, creeks, streams, and other low-lying and flood-p…

### Ukraine Theater (total-war monitoring) — 82 new of 355 total
  - (2026-10-22) [FIRMS] thermal anomaly 45.258, 31.672 (FRP 4.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-22 1026Z, FRP 4.73 MW
  - (2026-10-22) [FIRMS] thermal anomaly 51.179, 34.804 (FRP 7.13 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-22 1028Z, FRP 7.13 MW
  - (2026-10-22) [FIRMS] thermal anomaly 52.431, 33.663 (FRP 3.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-22 1028Z, FRP 3.39 MW
  - (2026-10-22) [FIRMS] thermal anomaly 44.050, 27.432 (FRP 8.05 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-22 1206Z, FRP 8.05 MW
  - (2026-10-22) [FIRMS] thermal anomaly 44.049, 27.426 (FRP 7.43 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-22 1206Z, FRP 7.43 MW
  - (2026-10-22) [FIRMS] thermal anomaly 44.049, 27.421 (FRP 7.43 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-22 1206Z, FRP 7.43 MW

### Ukrainian Internal News (national + local Kyiv) — 71 new of 138 total
  - (2026-10-23) М'яка, але морози можливі: в метеоцентрі розповіли, якої зими очікують в Україні | LEDE: Температурні показники цієї зими в Україні можуть бути трохи вищими за кліматичну норму, однак виключати] (uk:…
      Температурні показники цієї зими в Україні можуть бути трохи вищими за кліматичну норму, однак виключати морози не варто.
  - (2026-10-23) Німеччина хоче закупити тисячі ракет у виробників з Європи та України – ЗМІ | LEDE: Німеччина веде переговори про закупівлю тисяч одиниць високоточних далекобійних ракет європейського виробницт] (uk:…
      Німеччина веде переговори про закупівлю тисяч одиниць високоточних далекобійних ракет європейського виробництва, щоб поповнити свій арсенал на тлі затримок надходження американських ракет Tomahawk.
  - (2026-10-23) Омбудсман повідомив про повернення з Росії 7 цивільних українців | LEDE: Україна повернула з Росії сімох цивільних українців та натомість передала державі-агресору сімох цивільних.] (uk: Омбудсман пов…
      Україна повернула з Росії сімох цивільних українців та натомість передала державі-агресору сімох цивільних.
  - (2026-10-23) Росіяни поцілили по приватному будинку у Вільнянську: є руйнування, 2 жінки поранені | LEDE: У Вільнянську Запорізької області через удар РФ по приватному будинку травмовано двох жінок. Постраж] (uk:…
      У Вільнянську Запорізької області через удар РФ по приватному будинку травмовано двох жінок. Постраждалим надають допомогу, рятувальники ліквідували пожежу.
  - (2026-10-23) Мирний план Трампа небезпечний для України, Європи та Америки – The Economist | LEDE: The Economist розкритикував план Трампа з 28 пунктів щодо припинення війни в Україні, зазначаючи його небез] (uk:…
      The Economist розкритикував план Трампа з 28 пунктів щодо припинення війни в Україні, зазначаючи його небезпеку для Європи та США. Основні деталі – у матеріалі.
  - (2026-10-23) У Чорному морі затонуло судно, ймовірно, вражене дроном, є загиблий і зниклі безвісти | LEDE: У Чорному морі біля узбережжя Румунії у п'ятницю вранці, 23 жовтня, затонуло комерційне судно, яке,] (uk:…
      У Чорному морі біля узбережжя Румунії у п'ятницю вранці, 23 жовтня, затонуло комерційне судно, яке, схоже, було вражене дроном.

### State Legislative Action — 65 new of 108 total
  - (2026-10-22) [Alabama SB 277] Unincorporated nonprofit associations; decentralized associations provided for
      Businesses & Financial Institutions
  - (2026-10-22) [Alabama SB 231] Security; security provided at new Alabama State House, parking deck, and adjacent park
      Legislature
  - (2026-10-22) [Alabama SB 259] Counties and municipalities; compensation of local officials, revised
      Counties & Municipalities
  - (2026-10-23) [California SB 675] Imperial County Air Pollution Control District: members and duties.
      Existing law provides for the establishment of air pollution control districts and air quality management districts and prescribes the membership of the governing boards of air pollution control districts and air quality…
  - (2026-10-23) [California SB 1114] Data collection: sexual orientation, gender identity, and intersex status: disclosure.
      Existing law, the Lesbian, Gay, Bisexual, Transgender, and Intersex Disparities Reduction Act, requires the State Department of Public Health, among other specified state entities, in the course of collecting demographic…
  - (2026-10-23) [California SB 909] Public works.
      Existing law requires that, except as specified, not less than the general prevailing rate of per diem wages be paid to workers employed on public works and imposes misdemeanor penalties for a willful violation of this r…

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 57 total
  - (2026-10-23) [The Hacker News] URGENT - PHP Warns of Another Unpatched RCE Two Days After Emergency PHP2Shell Patches
      PHP has warned of another way an attacker could run code on a web server, two days after it shipped emergency fixes for the critical PHP2Shell flaws. The new issue, assigned CVE-2026-115560, affects only web applications…
  - (2026-10-23) [The Hacker News] Russian-Linked Hackers Used New Mesh Network Backdoor in Destructive Ukraine Attack
      The Russian state-sponsored hacking group Sandworm teamed up with another threat actor to carry out a destructive wiping attack targeting a Ukrainian logistics company last year. According to ESET, the attack involved UA…
  - (2026-10-23) [The Hacker News] Critical Flaw in Python’s Popular Pillow Image Library Allows Code Execution via a Crafted Image
      Pillow, the most widely used image library for Python, can be made to run operating system commands on a server by specifying the name of a file it is told to open. The flaw, CVE-2026-112900, is in the way Pillow handles…
  - (2026-10-23) [The Hacker News] Researchers Demonstrate Node2Shell RCE Exploit on Node.js Build Using Crafted Brotli Data
      Malicious Brotli data can make an application on an official build of Node.js run attacker-supplied code, security researchers at Imperva have demonstrated. Their "Node2Shell" proof of concept ran code on the official No…
  - (2026-10-23) [The Hacker News] Critical x402 SDK Flaw Could Let Malicious APIs Drain AI Agents’ Token Balances
      AI agents paying for API calls with the x402 SDKs could sign a payment for their full balance of a supported token if a malicious API asked for it, security firm V12 said on October 22. The cause was the SDKs' default cl…
  - (2026-10-23) [Schneier on Security] Compromised TLS Certificates
      The Indian CA eMudhra Limited has eight TLS certificates with laughably weak private keys: The compromised eMudhra keys were defective at a level that’s challenging the imagination of many of the engineers studying the i…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-23) 485BXT - Nushares ETF Trust (0001635073) (Filer)
      filed 2026-10-23 11:00 UTC — Filed: 2026-10-23 AccNo: 0001193125-26-429430 Size: 31 KB
  - (2026-10-23) 485BXT - Nushares ETF Trust (0001635073) (Filer)
      filed 2026-10-23 11:00 UTC — Filed: 2026-10-23 AccNo: 0001193125-26-429430 Size: 31 KB
  - (2026-10-23) [Hastings Gregory S] Form 4 (Reporting)
      filed 2026-10-23 10:55 UTC · role: Reporting — Filed: 2026-10-23 AccNo: 0000711377-26-000034 Size: 8 KB
  - (2026-10-23) [NEOGEN CORP] Form 4 (Issuer)
      filed 2026-10-23 10:55 UTC · role: Issuer — Filed: 2026-10-23 AccNo: 0000711377-26-000034 Size: 8 KB
  - (2026-10-23) [Qiu Wenbin] Form 4 (Reporting)
      filed 2026-10-23 10:35 UTC · role: Reporting — Filed: 2026-10-23 AccNo: 0001104659-26-118281 Size: 7 KB
  - (2026-10-23) [Baozun Inc.] Form 4 (Issuer)
      filed 2026-10-23 10:35 UTC · role: Issuer — Filed: 2026-10-23 AccNo: 0001104659-26-118281 Size: 7 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-23) GAF143 (Germany)
      icao24: 3e8b02 · position: (49.6183, -9.3554) · alt: 9745m · 628km/h
  - (2026-10-23) INDIA1 (India)
      icao24: 8002fb · position: (27.8223, 77.1135) · alt: 5379m · 749km/h
  - (2026-10-23) CFC3123 (Canada)
      icao24: c2c1fb · position: (47.3121, -82.2637) · alt: 11582m · 752km/h
  - (2026-10-23) JAF5GA (Bulgaria)
      icao24: 452179 · position: (41.4234, -2.5658) · alt: 10043m · 804km/h
  - (2026-10-23) CFC2927 (Canada)
      icao24: c2b5b7 · position: (58.8237, 12.4025) · alt: 7018m · 562km/h
  - (2026-10-23) GAF661 (Germany)
      icao24: 3e89d5 · position: (53.7904, 18.4815) · alt: 510m · 257km/h

### Court opinions of consequence (federal & state) — 26 new of 60 total
  - (2026-10-27) Connecticut Supreme Court: Greenstein v. Thomas
  - (2026-10-22) D.C. Court of Appeals: District of Columbia Department of Public Works v. District of Columbia Department of Employment Services
  - (2026-10-22) Delaware Supreme Court: Middleton, Deshaun v. Department of Services for Children Youth and Their Families (DSCYF) TPR
  - (2026-10-22) U.S. Court of Appeals, 1st Cir.: MW Gestion v. 1Globe Capital LLC
  - (2026-10-22) Arkansas Supreme Court: Tarus Melick Walker v. State of Arkansas
  - (2026-10-22) Florida Supreme Court: S.H., in the Interest of A.H. and K.W., the Children v. Department of Children and Families and Guardian Ad Litem

### USGS earthquakes (M4.5+, past day) — 22 new of 22 total
  - (2026-10-22) M 7.0 - 191 km ENE of Nagqu, China
      M7.0 · 191 km ENE of Nagqu, China · depth 18 km · PAGER orange
  - (2026-10-23) M 5.7 - 61 km WNW of Leni, Italy
      M5.7 · 61 km WNW of Leni, Italy · depth 10 km
  - (2026-10-22) M 5.2 - 201 km ENE of Nagqu, China
      M5.2 · 201 km ENE of Nagqu, China · depth 10 km
  - (2026-10-22) M 5.0 - 153 km S of Kokopo, Papua New Guinea
      M5.0 · 153 km S of Kokopo, Papua New Guinea · depth 10 km
  - (2026-10-22) M 5.0 - 207 km ENE of Nagqu, China
      M5.0 · 207 km ENE of Nagqu, China · depth 10 km
  - (2026-10-23) M 4.9 - 53 km WNW of Leni, Italy
      M4.9 · 53 km WNW of Leni, Italy · depth 10 km

### Paper Trading Scorecard — 17 new of 72 total
  - (2026-10-23) [Polymarket] Will Detroit Pistons win the 2027 NBA Finals?
      This market will resolve to "Yes" if the listed team is determined as the champion of the NBA for the 2026-27 season. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed team to be name…
  - (2026-10-23) [Manifold] Will this story end up on "Last Week Tonight"?
  - (2026-10-23) [Manifold] Talarico and El-Sayed combined margin of victory of 10% or more?
  - (2026-10-23) [Manifold] Jon Ossoff and Roy Cooper combined margin of victory of 25% or more?
  - (2026-10-23) [Manifold] Did Ilhan Omar marry her brother?
  - (2026-10-23) [Manifold] Will the federal government bring a criminal or civil case against Ilhan Omar over her immigration history by EOY 2027?

### U.S. Federal Action — 13 new of 17 total
  - (2026-10-23) Part 572; Anthropomorphic Test Devices; Test Device for Human Occupant Restraint 50th Percentile Adult Male Dummy (THOR-50M); Extension of Comment Period
      In response to a request from the Alliance for Automotive Innovation (Auto Innovators), NHTSA is announcing a 30-day extension of the public comment period for the Supplemental Notice of Proposed Rulemaking (SNPRM) publi…
  - (2026-10-23) Implementing the Guiding and Establishing National Innovation for U.S. Stablecoins Act for the Issuance of Stablecoins by Entities Subject to the Jurisdiction of the Office of the Comptroller of the C…
      The Office of the Comptroller of the Currency (OCC) is issuing regulations implementing the Guiding and Establishing National Innovation for U.S. Stablecoins Act regarding the issuance of payment stablecoins and certain…
  - (2026-10-23) Revision of National Environmental Policy Act Implementing Procedures; Extension of Comment Period
      On September 25, 2026, the United States Postal Service (USPS) published an interim final rule with request for comments to partially rescind and update its remaining National Environmental Policy Act (NEPA) implementing…
  - (2026-10-23) Irradiated Fuel Reprocessing Plants
      The U.S. Nuclear Regulatory Commission (NRC) has received a petition for rulemaking (PRM) from Howard L. Hall, Ph.D., dated August 14, 2026, requesting that the NRC remove the exclusion of irradiated fuel reprocessing pl…
  - (2026-10-23) Airworthiness Directives; The Boeing Company Airplanes; Correction
      The FAA is correcting an airworthiness directive (AD) that was published in the Federal Register. That AD applies to certain The Boeing Company Model 787-8, 787-9, and 787-10 airplanes. As published, a paragraph referenc…
  - (2026-10-23) Fisheries of the Exclusive Economic Zone Off Alaska; Pacific Cod by Catcher Vessels Using Trawl Gear in the Central Regulatory Area of the Gulf of Alaska
      NMFS is prohibiting directed fishing for Pacific cod by catcher vessels using trawl gear in the Central Regulatory Area of the Gulf of Alaska (GOA). This action is necessary to prevent exceeding the 2026 total allowable…

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 107 total
  - (2026-10-16) [OFAC] 1263 - Office of Foreign Assets Control (.gov)
      1263 Office of Foreign Assets Control (.gov)
  - (2026-10-23) [BIS Entity List] page checksum d94820520592
      Page content hash: d94820520592. Compare with prior day's hash to detect updates.
  - (2026-10-23) [USASpending] $15,126,647,249 → FLUOR MARINE PROPULSION, LLC: MANAGEMENT AND OPERATION OF THE NAVAL NUCLEAR LABORATORY AND
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF THE NAVAL NUCLEAR LABORATORY AND NAVAL NUCLEAR PROPULSION PROGRAM SUPPORT
  - (2026-10-23) [USASpending] $4,429,530,857 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WI
      Agency: National Aeronautics and Space Administration. Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOLID…
  - (2026-10-23) [USASpending] $3,584,176,461 → PANTEXAS DETERRENCE, LLC: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION
      Agency: Department of Energy. Description: CONTRACT 89233224CNA000004 FOR THE MANAGEMENT AND OPERATION OF THE PANTEX PLANT
  - (2026-10-23) [USASpending] $1,336,720,376 → THE BOEING COMPANY: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS
      Agency: National Aeronautics and Space Administration. Description: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-10-23) Will the price of Ethereum be above $2,400 on October 22?
      yes price: 0% · 24h volume: $775,741 · resolves 2026-10-22
  - (2026-10-23) Ningbo Open: Iva Jovic vs Diana Shnaider
      yes price: 6% · 24h volume: $697,668 · resolves 2026-10-30
  - (2026-10-23) Will the Democratic Party control the Senate after the 2026 Midterm elections?
      yes price: 68% · 24h volume: $681,874 · resolves 2026-11-04
  - (2026-10-23) Will Russia and Ukraine hold any diplomatic meeting by October 31, 2026?
      yes price: 98% · 24h volume: $490,467 · resolves 2026-11-01
  - (2026-10-23) NATO x Russia military clash by October 31, 2026?
      yes price: 16% · 24h volume: $459,597 · resolves 2026-11-01
  - (2026-10-23) Will Kylian Mbappé win the 2026 Ballon d'Or?
      yes price: 6% · 24h volume: $404,343 · resolves 2026-10-27

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - (2026-10-23) [Top] JACKSON, TROY DALE (DEM, Senate ME): $26.87M raised
      cycle 2026 receipts $26.87M · disbursements $25.28M · net $+1.60M
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-23) [Marginal Revolution] Prediction Markets Are Accurate
      No surprise to me but a new paper looks at the forecast accuracy of over one million prediction questions from Polymarket, Kalshi, Manifold and the forecasting platform Metaculus. A virtue of the new analysis is that it…
  - (2026-10-23) [Marginal Revolution] Protecting Americans from Medicine
      Max Doppelt: In January 2025 my mom’s lung cancer spread to her brain. The drug with the best chance of helping her was approved in China but not here. A doctor told me, almost as an aside, that if she were Chinese she c…
  - (2026-10-23) [Marginal Revolution] Podcast with Rabbi David Wolpe
      Here is their episode summary: Economist Tyler Cowen joins David Wolpe for a conversation about AI, religion, and what makes us human. Tyler makes the case that AI’s biggest impact may be on status: who gains it, who los…
  - (2026-10-22) [Conversable Economist] Financing the AI Physical Capital Buildout
      The amounts of money being spent on the hardware and buildings behind the new AI boom may turn out to be enormously large by historical standards. How is it being financed? Stijn Van Nieuwerburgh tells the story in “Fina…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=17, 14d-median=26; carrying terms: protection, regulatory, agency, final, proposed, proposing, action, certain, enforcement, period, national, control
- state_bills: today=108, 7d-median=113, 14d-median=109; carrying terms: providing, alaska, education, school, relating, district, administration, state, california, subject, amending, appropriation
- state_news: today=757, 7d-median=688, 14d-median=688; carrying terms: allow, parents, later, alleges, democrats, attorney, newsletter, montana, tribune, facing, access, second
- local_news: today=248, 7d-median=238, 14d-median=235; carrying terms: second, million, deadly, according, health, october, across, county, following, another, suspect, google
- foreign_news: today=1029, 7d-median=1011, 14d-median=1018; carrying terms: allow, worldbank, experts, russian, anthropic, story, traffic, possible, track, chief, eastern, watch
- chinese_internal: today=264, 7d-median=273, 14d-median=292; carrying terms: cbmib, market, chinese, cbmickfvx, cbmix, lxtfa, cbmixkfvx, cbmizefvx, cbmiakfvx, google, blank, cbmiykfvx
- russian_internal: today=1135, 7d-median=1019, 14d-median=1029; carrying terms: times, journal, raquo, forbidden, laquo, russian, novaya, istories, europe, client, title, found
- ukrainian_internal: today=138, 7d-median=136, 14d-median=136; carrying terms: volodymyr, injured, comes, russian, regions, commercial, remain, capital, critical, found, babel, targets
- ukraine_theater: today=355, 7d-median=413, 14d-median=413; carrying terms: fhmldqy, anllzgziwnoxou, taras, nwlyrzzxew, bkcldpswlpsdkytda, rnwxlqcmztb, cbmifefvx, xqdexwr, lvnwhirlnlsnlsvk, wnrwmhrmlwv, dzbfegzungn, cbmivefvx
- paper_bets: today=72, 7d-median=69, 14d-median=69; carrying terms: unemployment, california, receiving, speed, problems, world, zohran, career, chair, nuclear, kalshi, succeed
- weather: today=136, 7d-median=136, 14d-median=138; carrying terms: message, moderate, severe, miami, tropical, showers, light, gusty, changed, worth, moving, additional
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: balance, unemployment, cpilfesl, growth, money, treasury, rates, dexuseu, assets, commodities, labor, pcepilfe
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, proxy, range, treasury, equities, close, crude, rates, crypto, corporate, agriculture, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=107, 7d-median=105, 14d-median=107; carrying terms: operation, laboratory, satisfying, response, sovereignty, google, target, russian, blank, international, destabilisation, space
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, congresstrading, httperror, https, quiverquant, error, quiver, client, unauthorized
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, board, appeals, state, international, mullin, trade, delaware, blanche, company, hernandez
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, issuer, filed, trust, financial, filer, jpmorgan, chase, subject, technologies, finance
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, filing, robert, brown, david, cycle, angels, committee, jonathan, alexandria, congress, trone
- gdelt_regions: today=0, 7d-median=10, 14d-median=8; carrying terms: english, japan, china, japanherald
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, israel, sanctions, russia, perimeter, keywords, greek, trump, china, diesel, south
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=23, 14d-median=28; carrying terms: belgium, position, france, ground, bulgaria, germany, kingdom, canada, aabbef
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: hantavirus, active, months, chikungunya, mainly, probable, recent, faster, seasonal, imported, cross, respiratory
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: cisco, vulnerability, command, control, vendor, remediation, server, product, injection, traversal, improper, fortinet
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=100, 14d-median=100; carrying terms: typhoon, speed, cyclone, papua, impact, tropical, australia, green, forestfire, hurricane, wildfire, maximum
- usgs_quakes: today=22, 7d-median=21, 14d-median=21; carrying terms: depth, russia, philippines, guinea, papua, vanuatu, tonga, kokopo, kuril, china, severo, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: donetsk, championship, resolves, volume, presidential, price, league, october, champions, shakhtar, election, brazilian
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, economist, https, class, revolution, conversable, marginalrevolution, government, conversableeconomist, spending, trillion, total
- tech_news: today=57, 7d-median=57, 14d-median=58; carrying terms: computerweekly, schneier, review, hacker, software, weekly, company, sensitive, service, engineering, spectrum, download
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: relations, blackburn, rubio, commodity, perez, fleischmann, fletcher, laurel, hudson, jerome, linda, brecheen
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, consensus, claude, paper, today, module, converges, either, unavailable, evidence, sufficient, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-13] ECB press: Philip R. Lane: The AI opportunity for Europe
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-17] ECB press: Christine Lagarde: IMFC Statement
- [2026-10-19] ECB press: Frank Elderson: From climate and nature risks to economic resilience and competitiveness
- [2026-10-20] ECB press: Frank Elderson: Interview with Die Presse
- [2026-10-21] ECB press: Philip R. Lane: Euro liquidity lines and the international monetary system
- [2026-10-21] ECB press: Piero Cipollone: Pontes and Appia: unlocking opportunities for banks
- [2026-10-23] ECB press: ECB Consumer Expectations Survey results – September 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*