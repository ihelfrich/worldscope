# WORLDSCOPE morning brief — 2026-06-24

## Headline
3771 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (770) · Russian Internal News (state + in-exile) (672) · Ukraine Theater (total-war monitoring) (371) · State-Level News (365) · World leaders & government officials (324) · Chinese Internal News (253) · State Legislative Action (231) · Local News: St. Louis + Atlanta (209) · U.S. Weather + Severe / Climate Outlooks (160) · Ukrainian Internal News (national + local Kyiv) (65) · IT, InfoSys & cybersecurity news (last 7 days) (46) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 770 new of 1068 total
  - (2026-06-24) [Global] France braces for another day of sweltering heat as Europe heatwave spreads
      The heatwave is expected to spread to other parts of western Europe on Wednesday, before extending eastwards over the weekend.
  - (2026-06-24) [Global] Congress passes war powers measure for first time, breaking with Trump over Iran
      The resolution passed on Tuesday was largely symbolic, but it adds to pressure on the White House to end the conflict once and for all.
  - (2026-06-23) [Global] UN says it will evacuate sailors stranded in Strait of Hormuz, as Rubio warns against tolls
      US Secretary of State Marco Rubio warned Iran that no country can charge fees for ships to travel through the strait.
  - (2026-06-24) [Global] Clean sweep for Mamdani-backed candidates in New York's Democratic primary
      Brad Lander unseats Dan Goldman in a race that laid bare the city's divisions over the Israel-Gaza war.
  - (2026-06-24) [Global] Ukraine strikes knock out power in key city in Russian-occupied Crimea
      Sevastopol's Moscow-installed governor warns there will be no electricity in some areas until the evening.
  - (2026-06-24) [Global] France confirms first Ebola case
      More than 260 people in the Democratic Republic of Congo are known to have died during the current outbreak.

### Russian Internal News (state + in-exile) — 672 new of 1046 total
  - (2026-06-24) «Важные истории»: семья депутата Госдумы, близкая к Рамзану Кадырову, инвестирует миллионы евро в европейскую недвижимость | LEDE: Брат депутата Госдумы от «Единой России» Бекхана Агаева Бат] (ru: «Ва…
      Брат депутата Госдумы от «Единой России» Бекхана Агаева Батыр имеет гражданство Бельгии и участвует в инвестиционном фонде, который вкладывает миллионы евро в европейскую недвижимость. Об этом говорится в материале «Важн…
  - (2026-06-24) «Что-то может начаться уже в октябре». Российские власти обсуждают возможность новой волны мобилизации — после выборов в Госдуму | LEDE: В России все меньше желающих пойти служить в армию по] (ru: «Чт…
      В России все меньше желающих пойти служить в армию по контракту, что заставляет власти задуматься о новой волне мобилизации. Об этом говорят источники «Медузы», а также пишут «Важные истории» и «Верстка».
  - (2026-06-24) США провели первые испытания системы противоракетной обороны «Золотой купол» | LEDE: В США прошли первые испытания системы противоракетной обороны «Золотой купол». ] (ru: США провели первые испытания…
      В США прошли первые испытания системы противоракетной обороны «Золотой купол».
  - (2026-06-24) Глава «Роснефти» Игорь Сечин предложил меры по борьбе с топливным кризисом | LEDE: Глава «Роснефти» Игорь Сечин предложил Владимиру Путину меры для стабилизации российского топливного рынка ] (ru: Гла…
      Глава «Роснефти» Игорь Сечин предложил Владимиру Путину меры для стабилизации российского топливного рынка «в условиях беспрецедентного количества повреждений» российских НПЗ, пишет «Коммерсант».
  - (2026-06-24) В Кремле заявили, что не обсуждают вопрос о переносе выборов в Госдуму. По информации «Медузы», силовики пытаются убедить Путина отложить голосование | LEDE: Вопрос переноса выборов в Госдум] (ru: В К…
      Вопрос переноса выборов в Госдуму, запланированных на сентябрь 2026 года, не обсуждается, заявил пресс-секретарь президента России Дмитрий Песков.
  - (2026-06-24) Коммунисты захотели узнать у Роскомнадзора и Минцифры, зачем нужна блокировка телеграма. Госдума отказалась направлять запрос | LEDE: Госдума отклонила предложение депутатов от фракции КПРФ,] (ru: Ком…
      Госдума отклонила предложение депутатов от фракции КПРФ, которые призывали запросить в Роскомнадзоре и Минцифры информацию об «эффективности и целесообразности» блокировки телеграма. «Коммерсант» сообщает, что соответств…

### Ukraine Theater (total-war monitoring) — 371 new of 616 total
  - (2026-06-24) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2016-07-28) [Liveuamap] Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com - iran.liveuamap.com
      Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com iran.liveuamap.com
  - (2026-06-24) [Liveuamap] Lebanese Ministry of Health: 83 dead and 141 wounded as a result of the intense Israeli raids on June 19 - Liveuamap
      Lebanese Ministry of Health: 83 dead and 141 wounded as a result of the intense Israeli raids on June 19
  - (2026-06-22) [Liveuamap] Explosion was reported in Pavlohrad - Liveuamap
      Explosion was reported in Pavlohrad Liveuamap
  - (2026-06-18) [Liveuamap] CENTCOM: Today, U.S. forces lifted the blockade on all maritime traffic entering and exiting Iranian ports and coastal areas, in accordance with the President's direction. American forces…
      CENTCOM: Today, U.S. forces lifted the blockade on all maritime traffic entering and exiting Iranian ports and coastal area
  - (2026-06-20) [Liveuamap] The Sudanese army launched fierce raids on Rapid Support Forces positions in the city of Bara, North Kordofan, and inflicted heavy damage on their vehicles. Barah,North Kurdufan - Sudan la…
      The Sudanese army launched fierce raids on Rapid Support Forces positions in the city of Bara, North Kordofan, and in

### State-Level News — 365 new of 708 total
  - (2026-06-23) [Alabama] Flags Lowered Honoring Former State Representative James Thomas Cullins, Jr.
      Download
  - (2026-06-23) [Alabama] Governor Ivey Announces Eli Lilly, Space Command and Other State Economic Growth Help Earn Alabama a Silver Shovel Award
      MONTGOMERY – Governor Kay Ivey on Tuesday announced that growth in Alabama’s defense presence and a major pharmaceutical facility announcement helped the state earn a 2026 Silver Shovel Award from the business publicatio…
  - (2026-06-23) [California] California leaders announce Save for California’s Future Act to strengthen rainy day fund, fiscal responsibility to protect future generations
      Source
  - (2026-06-23) [California] Las redadas de inmigración han convertido el color de la piel en una preocupación primordial para una nueva generación de latinos en California
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/061226-Priscilla-Preciado-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-06-23) [California] What will you vote on in November? Ballot measures take shape at deadline
      <img width="1024" height="705" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/02/020226-Uber-JS-Getty-CM-01.jpg?fit=1024%2C705&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-06-23) [California] Will Democrats win the congressional seats Newsom’s gerrymander made competitive?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/09/082125_Redistricting-Newsom_MG_CM_16.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 253 new of 316 total
  - (2026-06-23) 人民银行法修订草案首次提请审议 完善中央银行基础管理制度 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1jQ0dxOUgycS1qUEZjNWVxMzlNMGVPUHhuWUEza3dmLTJoVmFIcm5nSGwzcUZxb3VVM0xYWWJoX0xRLWF1N1llR190U] (zh:…
      人民银行法修订草案首次提请审议 完善中央银行基础管理制度 财新
  - (2026-06-23) 2026年十大新兴技术报告：强调公众信任是技术发展的先决条件 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9ZcHgxLXJBZVo3QjFaNkJUZDYxd3p1ejM5djNqMjR5TEhXd3g0QWRkbDlOYlFmbThBeTlESDloajdzdEdOYUhhTjc] (zh:…
      2026年十大新兴技术报告：强调公众信任是技术发展的先决条件 财新
  - (2026-06-23) 洲际船务：霍尔木兹海峡危机如何改变国际航运市场 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE0wQVZzZ0RqVkFOY1ZhU04zSURJOHM0RF9CX3JHQnZtNUxBcHdZaklnRkp5Zi02NmFWdW5QRTlrYlNudmlnNzZNY09UbzRpWF] (zh:…
      洲际船务：霍尔木兹海峡危机如何改变国际航运市场 财新
  - (2026-06-23) 专家：美伊停火之后，中东地区如何转危为机 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBvTEVpOG5XYWV6V3Jta050WG43dlJWTkpQVWJBUjZhaGg4MUJfVmFnSTZrMVk5bzlZeFNVdDBVNEJ6UXI3SVpHTFhoNGVwNUlIe] (zh:…
      专家：美伊停火之后，中东地区如何转危为机 财新
  - (2026-06-23) 极右翼富商领跑哥伦比亚总统决选 现总统质疑选举过程不规范 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1wUElUUWRFNTRoRk5XQ2tTbDZ2M3pZUWV2SEZ2S3IyUWRnOG5OTjI1dTYyUEp4UEY4R3RYSFQ0NE1TQmoycVVyc1NMV] (zh:…
      极右翼富商领跑哥伦比亚总统决选 现总统质疑选举过程不规范 财新
  - (2026-06-23) 达沃斯热议：中国贸易顺差扩大背后是怎样的故事 如何再平衡？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBJT1FfSDRzeUZ5czlxby1Kck9QNklURlk0ZU9rcGluOTZlNUVyWW45M0NhYU1LcjM1ZzVuampaeFpCZlhlR0VGSlJy] (zh:…
      达沃斯热议：中国贸易顺差扩大背后是怎样的故事 如何再平衡？ 财新

### State Legislative Action — 231 new of 283 total
  - (2026-06-23) [Alaska SB 174] An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
      An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
  - (2026-06-23) [Alaska SB 208] An Act relating to industrial hemp; relating to the sale and lease of state land for agricultural uses; designating the O-S Cross cabbage, commonly known as 'giant green cabbage,' as t…
      An Act relating to industrial hemp; relating to the sale and lease of state land for agricultural uses; designating the O-S Cross cabbage, commonly known as 'giant green cabbage,' as the official state vegetable; and pro…
  - (2026-06-24) [Arizona SB 1171] AHCCCS; dual enrollment; notice
      AHCCCS; dual enrollment; notice
  - (2026-06-24) [Arizona SB 1011] medical examiners; sudden infant death
      medical examiners; sudden infant death
  - (2026-06-24) [Arizona SB 1421] undocumented aliens; financial services
      undocumented aliens; financial services
  - (2026-06-23) [Arizona HB 4162] human services; 2026-2027
      human services; 2026-2027

### Local News: St. Louis + Atlanta — 209 new of 252 total
  - (2026-06-24) [St. Louis] Data centers have loud opposition, but supporters gathered at Missouri S&T to push them
  - (2026-06-24) [St. Louis] Missouri House to hold committee hearing on possible data center rules in September
  - (2026-06-23) [St. Louis] ‘Safer streets are not created by chance’: Group looks at causes of St. Louis walking, biking deaths
  - (2026-06-23) [St. Louis] Missouri Voter Guide: August 2026 primary election in the St. Louis area and beyond
  - (2026-06-23) [St. Louis] The Grove’s bars fight back as St. Louis mayor pushes early closures during Pride weekend
  - (2026-06-23) [St. Louis] Second Missouri man charged with conspiracy to commit murder at White House UFC event

### U.S. Weather + Severe / Climate Outlooks — 160 new of 163 total
  - (2026-06-24) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-24) [Severe] Flash Flood Warning: Flash Flood Warning issued June 24 at 5:10AM CDT until June 24 at 9:15AM CDT by NWS Shreveport LA
      FFWSHV The National Weather Service in Shreveport has issued a * Flash Flood Warning for... Southwestern Union County in south central Arkansas... Columbia County in southwestern Arkansas... Northwestern Lincoln Parish i…
  - (2026-06-24) [Moderate] Special Weather Statement: Special Weather Statement issued June 24 at 5:04AM CDT by NWS Dodge City KS
      At 504 AM CDT, Doppler radar was tracking a strong thunderstorm 10 miles east of Clark State Lake, moving east at 25 mph. HAZARD...Wind gusts up to 40 mph and penny size hail. SOURCE...Radar indicated. IMPACT...Gusty win…
  - (2026-06-24) [Moderate] Gale Warning: Gale Warning issued June 24 at 2:40AM PDT until June 25 at 6:00AM PDT by NWS Seattle WA
      * WHAT...West winds 25 to 35 kt. * WHERE...Central U. S. Waters Strait Of Juan De Fuca and East Entrance U. S. Waters Strait Of Juan De Fuca. * WHEN...From 6 PM this evening to 6 AM PDT Thursday. * IMPACTS...Strong winds…
  - (2026-06-24) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued June 24 at 2:39AM PDT until June 25 at 10:00PM PDT by NWS San Diego CA
      * WHAT...Surf of 3 to 5 feet with sets to 6 feet on south- southwest facing beaches. Strong rip currents expected. * WHERE...San Diego County Coastal Areas and Orange County Coastal Areas. * WHEN...Now through Thursday e…
  - (2026-06-24) [Severe] Extreme Heat Warning: Extreme Heat Warning issued June 24 at 2:30AM MST until June 25 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with afternoon temperatures of 107 to 111 degrees. Localized Major Heat Risk. * WHERE...Southeast Pinal County, Tucson Metro Area, Upper Gila River Valley, and Upper San Pedro River Va…

### Ukrainian Internal News (national + local Kyiv) — 65 new of 122 total
  - (2026-06-24) У Путіна кажуть, що домовленостей про продовження мирних переговорів щодо України немає | LEDE: У Кремлі заявили, що жодних домовленостей щодо продовження переговорів з Україною поки що немає.] (uk: У…
      У Кремлі заявили, що жодних домовленостей щодо продовження переговорів з Україною поки що немає.
  - (2026-06-24) Окупанти вдарили дронами по центру Конотопа: є поранені | LEDE: 24 червня армія РФ атакувала безпілотниками об'єкти цивільної інфраструктури у центрі Конотопа на Сумщині, внаслідок удару двоє л] (uk:…
      24 червня армія РФ атакувала безпілотниками об'єкти цивільної інфраструктури у центрі Конотопа на Сумщині, внаслідок удару двоє людей дістали поранення.
  - (2026-06-24) Генштаб уточнив наслідки удару по центру космічного зв’язку "Дубна" у Москві | LEDE: Генштаб ЗСУ підтвердив удар по центру зв'язку «Дубна» у Москві: пошкоджено антену та будівлю.] (uk: Генштаб уточнив…
      Генштаб ЗСУ підтвердив удар по центру зв'язку «Дубна» у Москві: пошкоджено антену та будівлю.
  - (2026-06-24) В Україну йде сильна спека: на Закарпатті прогнозують до +37° | LEDE: 25-27 червня в Україні спекотно, до +37°; дощі лише місцями на півночі й сході. У Києві без опадів – до +29°.] (uk: В Україну йде…
      25-27 червня в Україні спекотно, до +37°; дощі лише місцями на півночі й сході. У Києві без опадів – до +29°.
  - (2026-06-24) Сирський після візиту на Олександрівський напрямок "скорегував" плани десантників | LEDE: Головнокомандувач Збройних сил України Олександр Сирський здійснив робочу поїздку на Олександрівський н] (uk:…
      Головнокомандувач Збройних сил України Олександр Сирський здійснив робочу поїздку на Олександрівський напрямок, де заслухав доповіді командирів і скорегував плани подальших дій українських військ.
  - (2026-06-24) Окупанти знову атакували АЗС: у Сумах 3 постраждалих | LEDE: Три людини постраждали внаслідок російського удару по автозаправній станції у Сумах ранці 24 червня.] (uk: Окупанти знову атакували АЗС: у…
      Три людини постраждали внаслідок російського удару по автозаправній станції у Сумах ранці 24 червня.

### IT, InfoSys & cybersecurity news (last 7 days) — 46 new of 57 total
  - (2026-06-24) [The Hacker News] DoJ Seizes Huione Cloud Account Tied to Cyber Scam Money Laundering
      The U.S. Department of Justice (DoJ) on Tuesday announced the seizure of a cloud computing account put to use by subsidiaries of Cambodia-based corporate conglomerate HuiOne Group, as the Treasury unveiled fresh sanction…
  - (2026-06-24) [The Hacker News] Cisco Unified CM Flaw Exploited After PoC Reveals File-Write Path to Root
      Threat actors have begun to exploit a recently disclosed critical security flaw impacting Cisco Unified Communications Manager (Unified CM) and Unified Communications Manager Session Management Edition (Unified CM SME).…
  - (2026-06-24) [The Register] Database vendors pitch themselves as the cure for runaway AI costs
      Pinecone and Tiger Data say smarter data plumbing can cut token use and tame agentic workloads
  - (2026-06-24) [The Register] Alpine Linux 3.24 scales new desktop heights with COSMIC
      Plus interesting news from the Xfce-on-Wayland project
  - (2026-06-24) [The Register] Ordering a trip back to 2009, with a side of nostalgia
      A time when Windows 7 was Microsoft's latest and greatest
  - (2026-06-24) [The Register] Explainer: Why your legacy storage is choking your expensive GPU
      THE REGISTER EXPLAINER: GPUs idle? Blame your outdated storage, not the silicon sprinters.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-24) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-06-24 10:15 UTC — Filed: 2026-06-24 AccNo: 0001918704-26-017482 Size: 478 KB
  - (2026-06-24) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-06-24 10:15 UTC — Filed: 2026-06-24 AccNo: 0001918704-26-017482 Size: 478 KB
  - (2026-06-24) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-24 10:13 UTC — Filed: 2026-06-24 AccNo: 0001918704-26-017481 Size: 869 KB
  - (2026-06-24) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-24 10:13 UTC — Filed: 2026-06-24 AccNo: 0001918704-26-017481 Size: 869 KB
  - (2026-06-24) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-24 10:11 UTC — Filed: 2026-06-24 AccNo: 0001918704-26-017480 Size: 908 KB
  - (2026-06-24) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-24 10:11 UTC — Filed: 2026-06-24 AccNo: 0001918704-26-017480 Size: 908 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-24) [United States] Philippine devotees honor St . John the Baptist with a mud - covered display of faith
      domain: wboc.com · language: English · tone:
  - (2026-06-24) [United States] New Research Shows How Root Canal Treatment Helps Protect Your Whole Body
      domain: thesunchronicle.com · language: English · tone:
  - (2026-06-24) [Canada] The booming U . S . is for builders and entrepreneurs . Canada is the opposite
      domain: theglobeandmail.com · language: English · tone:
  - (2026-06-24) [United States] Two Georges serves up taste , vibes of old Florida
      domain: cbs12.com · language: English · tone:
  - (2026-06-24) [China] Exclusive | Dutch semiconductor giants join delegation to China as US pushes chip export curbs : source
      domain: scmp.com · language: English · tone:
  - (2026-06-24) [United Kingdom] Second ever red heat warning comes into force
      domain: peeblesshirenews.com · language: English · tone:

### Paper Trading Scorecard — 32 new of 143 total
  - (2026-06-24) [Polymarket] Will Bitcoin reach $80,000 in June?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…
  - (2026-06-24) [Polymarket] Will the price of Bitcoin be above $56,000 on June 25?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-06-24) [Polymarket] Will England reach the Round of 16 at the 2026 FIFA World Cup?
      This market will resolve “Yes” if the listed team reaches the 2026 FIFA World Cup Round of 16. If at any point it becomes impossible for the listed team to advance to the 2026 FIFA World Cup Round of 16 (e.g. they are ma…
  - (2026-06-24) [Polymarket] Will Portugal reach the 2026 FIFA World Cup final?
      This market will resolve “Yes” if the listed team reaches the 2026 FIFA World Cup final. If at any point it becomes impossible for the listed nation to advance to the 2026 FIFA World Cup final (e.g. they are mathematical…
  - (2026-06-24) [Polymarket] Will Luiz Inácio Lula da Silva finish in second place in the first round of the 2026 Brazilian presidential election?
      A presidential election is scheduled to take place in Brazil on October 4, 2026. This market will resolve according to the listed candidate who receives the second-most valid votes in the first round of this election. Th…
  - (2026-06-24) [Polymarket] Will China invade Taiwan by September 30, 2026?
      This market will resolve to "Yes" if China commences a military offensive intended to establish control over any portion of the Republic of China (Taiwan) by September 30, 2026, 11:59 PM ET. Otherwise, this market will r…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 27 new of 30 total
  - (2026-06-24) GAF527 (Germany)
      icao24: 3dbc00 · position: (52.9138, 11.3511) · alt: 2438m · 311km/h
  - (2026-06-24) JAF50T (Bulgaria)
      icao24: 4520ce · position: (48.7258, 2.3663) · on ground · 24km/h
  - (2026-06-24) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (44.5447, 10.7673) · alt: 5547m · 641km/h
  - (2026-06-24) SAMU37 (France)
      icao24: 39ca87 · position: (47.5014, -0.0991) · alt: 342m · 244km/h
  - (2026-06-24) FAF7811 (France)
      icao24: 39a842 · position: (45.8416, -0.269) · alt: 1135m · 254km/h
  - (2026-06-24) PAT376 (United States)
      icao24: adfdcf · position: (31.5526, -93.1718) · alt: 8534m · 415km/h

### U.S. Federal Action — 26 new of 26 total
  - (2026-06-24) Continuation of the National Emergency With Respect to the Western Balkans
  - (2026-06-24) Continuation of the National Emergency With Respect to North Korea
  - (2026-06-24) Establishing the Digital Opportunity Data Collection; Modernizing the FCC Form 477 Data Program; Delete, Delete, Delete
      In this document, the Federal Communications Commission (Commission) adopted a Further Notice of Proposed Rulemaking (FNPRM) that seeks comment on eliminating outdated requirements and ways to enhance the efficiency of t…
  - (2026-06-24) Establishing the Digital Opportunity Data Collection; Modernizing the FCC Form 477 Data Program; Delete, Delete, Delete
      In this document, the Federal Communications Commission (Commission) adopted an Order that takes steps to streamline the processes associated with the Broadband Data Collection (BDC) and the National Broadband Map and al…
  - (2026-06-24) Enterprise Duty To Serve Underserved Markets
      The Federal Housing Finance Agency (FHFA or Agency) proposes to rescind its regulation on Duty to Serve Underserved Markets and replace it with a new rule. If adopted as proposed, the new rule would enable the Federal Na…
  - (2026-06-24) Safety Standard for Lithium-Ion Batteries Used in Micromobility Products and Electrical Systems of Micromobility Products Containing Such Batteries
      The U.S. Consumer Product Safety Commission (CPSC) issues this notice of proposed rulemaking (NPR) to address the unreasonable risk of death and injury associated with lithium-ion batteries used in micromobility products…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-06-24) [Russia oil sanctions perimeter · themes] 比亚迪唐L四驱智能解耦与宣传不符 - 新浪汽车
      feedback.auto.sina.com.cn · Chinese · tone NA
  - (2026-06-24) [Russia oil sanctions perimeter · themes] Coos Bay City Council hears presentation from South Coast Development Council
      theworldlink.com · English · tone NA
  - (2026-06-24) [Russia oil sanctions perimeter · themes] Укор към държавата : Институциите не правят или потулват изследванията на некачествени храни
      actualno.com · Bulgarian · tone NA
  - (2026-06-24) [Russia oil sanctions perimeter · themes] Polri Peringatkan Ratusan Pabrik Kelapa Sawit yang Terindikasi Beli TBS dengan Harga Tak Wajar
      tribunnews.com · Indonesian · tone NA
  - (2026-06-24) [Russia oil sanctions perimeter · themes] County to host hazardous waste disposal Saturday in Dunkirk | News , Sports , Jobs
      post-journal.com · English · tone NA
  - (2026-06-24) [Russia oil sanctions perimeter · themes] Polished Concrete Vs . Epoxy : Which Is Considered Better For A Garage Floor ?
      slashgear.com · English · tone NA

### World News (by country, top stories) — 24 new of 24 total
  - (2026-06-24) [China] Forced labor allegations in Xinjiang denied
      usa.chinadaily.com.cn · English
  - (2026-06-24) [China] 외자기업 , 중국 투자 강화할 전망
      korean.cri.cn · English
  - (2026-06-24) [China] 리창 총리 , 김민석 한국 총리 회견
      korean.cri.cn · English
  - (2026-06-24) [China]
      en.acnnewswire.com · English
  - (2026-06-24) [China] 최현호 신형 다목적 구축함 조선인민군 해군에 정식 취역
      korean.cri.cn · English
  - (2026-06-24) [China]
      en.acnnewswire.com · English

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-06-23) M 5.3 - 120 km S of Isangel, Vanuatu
      M5.3 · 120 km S of Isangel, Vanuatu · depth 21.543 km
  - (2026-06-23) M 5.2 - 265 km SSE of Dunhuang, China
      M5.2 · 265 km SSE of Dunhuang, China · depth 8.098 km
  - (2026-06-24) M 5.1 - 61 km SSW of Panguna, Papua New Guinea
      M5.1 · 61 km SSW of Panguna, Papua New Guinea · depth 70.1 km
  - (2026-06-24) M 5.0 - 71 km WNW of Catuday, Philippines
      M5.0 · 71 km WNW of Catuday, Philippines · depth 10 km
  - (2026-06-24) M 4.9 - 28 km SE of Fry, Greece
      M4.9 · 28 km SE of Fry, Greece · depth 10 km
  - (2026-06-24) M 4.9 - 64 km WNW of Catuday, Philippines
      M4.9 · 64 km WNW of Catuday, Philippines · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 104 total
  - (2026-06-23) [OFAC] Transnational Criminal Organizations Designations; Cuba Designations; Russia-related Designations Removals; Issuance of TCO-related General License; Publication of OFAC-OFSI Comparative Overvie…
      Transnational Criminal Organizations Designations; Cuba Designations; Russia-related Designations Removals; Issuance of TCO-related General License; Publication of OFAC-OFSI Comparative Overview Office of Foreign Assets…
  - (2026-06-23) [OFAC] U.S and UK Economic Sanctions Authorities - Office of Foreign Assets Control (.gov)
      U.S and UK Economic Sanctions Authorities Office of Foreign Assets Control (.gov)
  - (2026-06-23) [OFAC] Ripley Quinby IV - Office of Foreign Assets Control (.gov)
      Ripley Quinby IV Office of Foreign Assets Control (.gov)
  - (2026-06-23) [FARA] Assistant Attorney General John A. Eisenberg - Department of Justice (.gov)
      Assistant Attorney General John A. Eisenberg Department of Justice (.gov)
  - (2026-06-24) [USASpending] $3,088,721,030 → LEIDOS, INC.: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STA
      Agency: National Science Foundation. Description: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STATES ANTARCTIC PROGRAM
  - (2026-06-24) [USASpending] $1,385,702,409 → HANFORD TANK WASTE OPERATIONS & CLOSURE, LLC: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITI
      Agency: Department of Energy. Description: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITION CONTRACT VIA THE IMPLEMENTATION TASK ORDER, TO-02.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-06-24) MOVER ▼ Larry Ellison — $209.76B ($-11.53B since yesterday)
      United States · Technology · source: Oracle
  - (2026-06-24) MOVER ▼ Elon Musk — $1078.23B ($-8.68B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-06-24) MOVER ▼ Jensen Huang — $173.00B ($-7.32B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-06-24) MOVER ▼ Larry Page — $284.06B ($-2.44B since yesterday)
      United States · Technology · source: Google
  - (2026-06-24) MOVER ▼ Thomas Peterffy — $108.50B ($-2.30B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-06-24) MOVER ▼ Sergey Brin — $262.04B ($-2.25B since yesterday)
      United States · Technology · source: Google

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-06-24) Will Congo DR win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,943,547 · resolves 2026-07-20
  - (2026-06-24) Will USA win the 2026 FIFA World Cup?
      yes price: 3% · 24h volume: $2,918,647 · resolves 2026-07-20
  - (2026-06-24) Will Brazil win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $2,605,661 · resolves 2026-07-20
  - (2026-06-24) Will Switzerland win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,596,068 · resolves 2026-07-20
  - (2026-06-24) Will Morocco win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $2,251,538 · resolves 2026-07-20
  - (2026-06-24) Will France win the 2026 FIFA World Cup?
      yes price: 19% · 24h volume: $2,186,108 · resolves 2026-07-20

### Court opinions of consequence (federal & state) — 5 new of 8 total
  - (2026-06-23) U.S. Supreme Court: Blanche v. Lau
  - (2026-06-23) U.S. Supreme Court: Cisco Systems, Inc. v. Doe
  - (2026-06-23) U.S. Supreme Court: Exxon Mobil Corp. v. Corporación Cimex, S. A. (Cuba)
  - (2026-06-23) U.S. Supreme Court: Landor v. Louisiana Dept of Corrections and Public Safety
  - (2026-06-23) U.S. Supreme Court: Pung v. Isabella County

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 10 total
  - (2026-06-23) CVE-2025-67038 · Lantronix EDS5000: Lantronix EDS5000 Code Injection Vulnerability
      vendor: Lantronix · product: EDS5000 · CISA remediation by 2026-06-26
  - (2026-06-23) CVE-2026-34910 · Ubiquiti UniFi OS: Ubiquiti UniFi OS Improper Input Validation Vulnerability
      vendor: Ubiquiti · product: UniFi OS · CISA remediation by 2026-06-26
  - (2026-06-23) CVE-2026-34909 · Ubiquiti UniFi OS: Ubiquiti UniFi OS Path Traversal Vulnerability
      vendor: Ubiquiti · product: UniFi OS · CISA remediation by 2026-06-26
  - (2026-06-23) CVE-2026-34908 · Ubiquiti UniFi OS: Ubiquiti UniFi OS Improper Access Control Vulnerability
      vendor: Ubiquiti · product: UniFi OS · CISA remediation by 2026-06-26

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-06-24) [Marginal Revolution] GLP-1 drugs and marriage
      GLP-1 medications generate large weight loss and may also alter social and economic outcomes. Using the Understanding America Study, I compare women starting GLP-1s for weight loss with matched women who would like to st…
  - (2026-06-24) [Marginal Revolution] Emergent Ventures winners, 55th cohort
      Aliaksandra Melnichenka, Belarus/Kentucky, to support science and math writing. Guilherme Pinho, Sao Paulo, real estate titling and transactions in Brazil. Diyar Zhakpelov, Astana, Kazakhstan, 17, exam prep app for Kazak…
  - (2026-06-23) [Marginal Revolution] Tuesday assorted links
      1. This paper was presented 57 different times!? Is that good or bad? 2. Benny Goodman and Lionel Hampton doing “I Got Rhythm.” 3. Claims about advancements in cancer testing. 4. Reconstructing Welles’s Don Quixote? 5. T…
  - (2026-06-23) [Conversable Economist] Some Economics of Paid Sick Leave
      Employers will often choose to provide paid sick leave to some of their employees. About 15 years ago, neither the US federal government nor state governments required paid sick leave, but about 63% of US employees worke…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=24, 14d-median=24
- state_bills: today=283, 7d-median=152, 14d-median=152
- state_news: today=708, 7d-median=452, 14d-median=452
- local_news: today=252, 7d-median=221, 14d-median=221
- foreign_news: today=1068, 7d-median=1034, 14d-median=1034
- chinese_internal: today=316, 7d-median=281, 14d-median=281
- russian_internal: today=1046, 7d-median=915, 14d-median=915
- ukrainian_internal: today=122, 7d-median=111, 14d-median=111
- ukraine_theater: today=616, 7d-median=616, 14d-median=616
- paper_bets: today=143, 7d-median=139, 14d-median=139
- weather: today=163, 7d-median=176, 14d-median=176
- macro: today=21, 7d-median=21, 14d-median=21
- markets: today=21, 7d-median=21, 14d-median=21
- markets_global: today=47, 7d-median=47, 14d-median=47
- sanctions_procurement: today=104, 7d-median=102, 14d-median=102
- congressional_trades: today=68, 7d-median=68, 14d-median=68
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=8, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=24, 7d-median=6, 14d-median=6
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=28, 14d-median=28
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=10, 7d-median=9, 14d-median=9
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=116, 7d-median=118, 14d-median=118
- usgs_quakes: today=17, 7d-median=16, 14d-median=16
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=5, 14d-median=5
- tech_news: today=57, 7d-median=51, 14d-median=51
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-11] Fed press (events + announcements): Federal Reserve Board announces final rule that establishes data standards for certain information collections
- [2026-06-17] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-06-17] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the June 16-17 FOMC meeting
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board requests comment on proposal to require certain payment stablecoin issuers to maintain an effective customer identification program
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Manufacturers and Traders Trust Company
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-19] ECB press: ECB publishes consolidated banking data for end-December 2025
- [2026-06-19] ECB press: Piero Cipollone: The foundations of national sovereignty: the role of central bank money
- [2026-06-19] ECB press: Frank Elderson: Fireside chat
- [2026-06-22] Fed press (events + announcements): Federal Reserve notes with deep sadness the passing of Alan Greenspan
- [2026-06-22] Fed speeches: Waller, Welcoming Remarks on the International Role of the U.S. Dollar
- [2026-06-22] ECB press: Christine Lagarde: Hearing of the Committee on Economic and Monetary Affairs of the European Parliament
- [2026-06-23] ECB press: Philip R. Lane: Introductory remarks
- [2026-06-23] ECB press: Boris Vujčić: Outlook for the euro area economy and monetary policy
- [2026-06-24] ECB press: Iceland joins TIPS for instant payments
- [2026-06-24] ECB press: ECB reports on progress towards euro adoption

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*