# WORLDSCOPE morning brief — 2026-05-26

## Headline
540 new items across 22 section(s).

## What changed today
### U.S. Federal Action — 25 new of 32 total
  - (2026-05-26) Conforming Change for Approving a Making Application
  - (2026-05-26) Continuation of the National Emergency With Respect to Belarus
  - (2026-05-26) Security Zone; Ohio River, Cincinnati, OH
      The Coast Guard is establishing a temporary security zone for all navigable waters of the Ohio River, extending the entire width of the river, between mile marker (MM) 461 to Mile 473. This security zone is needed to pro
  - (2026-05-26) Town Hall Meetings To Provide Input on Cyber Incident Reporting for Critical Infrastructure Act (CIRCIA) Rulemaking
      This notice announces a revised town hall meeting schedule to allow external stakeholders a limited additional opportunity to provide input on refining the scope and burden of the CIRCIA Notice of Proposed Rulemaking (NP
  - (2026-05-26) Foam Fire-Extinguishing Systems
      The Coast Guard must approve marine foam fire-extinguishing systems. Currently, eight guidance documents set out the existing type approval criteria. The Coast Guard proposes to update and codify the type approval criter
  - (2026-05-26) Airworthiness Directives; Pratt & Whitney Division Engines
      The FAA proposes to adopt a new airworthiness directive (AD) for all Pratt & Whitney Division (PW) Model PW4052, PW4056, PW4060, PW4060A, PW4060C, PW4062, PW4062A, PW4152, PW4156, PW4156A, PW4158, PW4460, and PW4462 engi
  - (2026-05-26) Enhancing Know-Your-Customer Requirements
      In this document, the Federal Communications Commission (Commission) proposes actions to provide additional clarity to fill the gap between its current Know Your Customer (KYC) requirement and the types of rigorous KYC s
  - (2026-05-26) Reducing Bureaucracy and Burden for Family Assistance Programs
      The Administration for Children and Families proposes to amend the Grants to States for Public Assistance Programs regulations, the General Administration--State Plans and Grant Appeals regulations, the General Administr

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-26) 424B2 - TORONTO DOMINION BANK (0000947263) (Filer)
      filed 2026-05-26 13:27 UTC — Filed: 2026-05-26 AccNo: 0001140361-26-022728 Size: 431 KB
  - (2026-05-26) 424B5 - Global Mofy AI Ltd (0001913749) (Filer)
      filed 2026-05-26 13:23 UTC — Filed: 2026-05-26 AccNo: 0001213900-26-060808 Size: 2 MB
  - (2026-05-26) [Japan Post Holdings Co., Ltd.] Form 4 (Reporting)
      filed 2026-05-26 13:21 UTC · role: Reporting — Filed: 2026-05-26 AccNo: 0001104659-26-066061 Size: 8 KB
  - (2026-05-26) [AFLAC INC] Form 4 (Issuer)
      filed 2026-05-26 13:21 UTC · role: Issuer — Filed: 2026-05-26 AccNo: 0001104659-26-066061 Size: 8 KB
  - (2026-05-26) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-05-26 13:18 UTC — Filed: 2026-05-26 AccNo: 0001839882-26-025409 Size: 715 KB
  - (2026-05-26) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-26 13:17 UTC — Filed: 2026-05-26 AccNo: 0001918704-26-013968 Size: 748 KB
  - (2026-05-26) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-26 13:17 UTC — Filed: 2026-05-26 AccNo: 0001918704-26-013968 Size: 748 KB
  - (2026-05-26) [McCray Gregory James] Form 4 (Reporting)
      filed 2026-05-26 13:15 UTC · role: Reporting — Filed: 2026-05-26 AccNo: 0001193125-26-238091 Size: 20 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 27 new of 27 total
  - (2026-05-26) [Top] OSSOFF, T. JONATHAN (DEM, Senate GA): $81.15M raised
      cycle 2026 receipts $81.15M · disbursements $52.97M · net $+28.17M
  - (2026-05-26) [Top] TALARICO, JAMES (DEM, Senate TX): $40.28M raised
      cycle 2026 receipts $40.28M · disbursements $30.43M · net $+9.86M
  - (2026-05-26) [Top] BOOKER, CORY A. (DEM, Senate NJ): $32.26M raised
      cycle 2026 receipts $32.26M · disbursements $15.55M · net $+16.71M
  - (2026-05-26) [Top] KRISHNAMOORTHI, S (DEM, Senate IL): $31.39M raised
      cycle 2026 receipts $31.39M · disbursements $28.24M · net $+3.15M
  - (2026-05-26) [Top] OCASIO-CORTEZ, ALEXANDRIA (DEM, House NY): $27.73M raised
      cycle 2026 receipts $27.73M · disbursements $16.78M · net $+10.95M
  - (2026-05-26) [Top] COOPER, ROY (DEM, Senate NC): $26.82M raised
      cycle 2026 receipts $26.82M · disbursements $8.37M · net $+18.46M
  - (2026-05-26) [Top] BROWN, SHERROD (DEM, Senate OH): $25.98M raised
      cycle 2026 receipts $25.98M · disbursements $8.95M · net $+17.03M
  - (2026-05-26) [Top] WARNER, MARK ROBERT (DEM, Senate VA): $21.99M raised
      cycle 2026 receipts $21.99M · disbursements $7.77M · net $+14.22M

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-26) [United States] Two Dead After Forward Township House Fire | WISR 680 AM – Butler , PA
      domain: wisr680.com · language: English · tone: 
  - (2026-05-26) [] Vietnam seeks stronger reproductive healthcare as safe sex awareness remains low
      domain: news.tuoitre.vn · language: English · tone: 
  - (2026-05-26) [United Kingdom] Conservatives choose BHASVIC student for Hove by - election
      domain: theargus.co.uk · language: English · tone: 
  - (2026-05-26) [Philippines] Glucotrack to Highlight Implantable Continuous Blood Glucose Monitoring Technology at the American Diabetes Association 2026 Scientific Sessions
      domain: manilatimes.net · language: English · tone: 
  - (2026-05-26) [United States] In West Texas , an unlikely alliance stands against extending the border wall
      domain: wsiu.org · language: English · tone: 
  - (2026-05-26) [United States] Firefighters respond to house fire on Cleveland East Side
      domain: cleveland19.com · language: English · tone: 
  - (2026-05-26) [Germany] Klondike Gold Corp .: Klondike Gold Announces 2026 Diamond Drilling Program Underway to Update and Expand Gold Mineral Resources
      domain: finanznachrichten.de · language: English · tone: 
  - (2026-05-26) [Canada] Pope Leo is emerging as a critical voice in AI
      domain: stcatharinesstandard.ca · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-05-26) GAF527 (Germany)
      icao24: 3dbc00 · position: (51.4374, 11.1948) · alt: 3048m · 254km/h
  - (2026-05-26) JAF9BV (Bulgaria)
      icao24: 4520ce · position: (45.3862, -0.6) · alt: 10972m · 885km/h
  - (2026-05-26) PAT326 (United States)
      icao24: adfe55 · position: (39.6777, -77.9596) · alt: 1028m · 302km/h
  - (2026-05-26) PAT091 (United States)
      icao24: adfe54 · position: (39.5701, -76.3436) · alt: 2301m · 294km/h
  - (2026-05-26) NCR850 (United States)
      icao24: a95c2f · position: (48.1622, 19.7026) · alt: 10363m · 861km/h
  - (2026-05-26) PAT140 (United States)
      icao24: adfec1 · position: (39.9205, -75.6321) · alt: 3817m · 557km/h
  - (2026-05-26) SAMU45 (France)
      icao24: 39ca86 · position: (47.8391, 1.9178) · alt: 129m · 84km/h
  - (2026-05-26) JEDI77 (France)
      icao24: 39a842 · position: (45.0316, 0.2246) · alt: 129m · 274km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 12 new of 12 total
  - (2026-05-22) CVE-2026-9082 · Drupal Core: Drupal Core SQL Injection Vulnerability
      vendor: Drupal · product: Core · CISA remediation by 2026-05-27
  - (2026-05-21) CVE-2025-34291 · Langflow Langflow: Langflow Origin Validation Error Vulnerability
      vendor: Langflow · product: Langflow · CISA remediation by 2026-06-04
  - (2026-05-21) CVE-2026-34926 · Trend Micro Apex One: Trend Micro Apex One (On-Premise) Directory Traversal Vulnerability
      vendor: Trend Micro · product: Apex One · CISA remediation by 2026-06-04
  - (2026-05-20) CVE-2008-4250 · Microsoft Windows: Microsoft Windows Buffer Overflow Vulnerability
      vendor: Microsoft · product: Windows · CISA remediation by 2026-06-03
  - (2026-05-20) CVE-2009-1537 · Microsoft DirectX: Microsoft DirectX NULL Byte Overwrite Vulnerability
      vendor: Microsoft · product: DirectX · CISA remediation by 2026-06-03
  - (2026-05-20) CVE-2009-3459 · Adobe Acrobat and Reader: Adobe Acrobat and Reader Heap-Based Buffer Overflow Vulnerability
      vendor: Adobe · product: Acrobat and Reader · CISA remediation by 2026-06-03
  - (2026-05-20) CVE-2010-0249 · Microsoft Internet Explorer: Microsoft Internet Explorer Use-After-Free Vulnerability
      vendor: Microsoft · product: Internet Explorer · CISA remediation by 2026-06-03
  - (2026-05-20) CVE-2010-0806 · Microsoft Internet Explorer: Microsoft Internet Explorer Use-After-Free Vulnerability
      vendor: Microsoft · product: Internet Explorer · CISA remediation by 2026-06-03

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-05-26) LoL: Dplus KIA vs Hanwha Life Esports (BO5) - Esports World Cup Korea Qualifier Playoffs
      yes price: 0% · 24h volume: $1,621,835 · resolves 2026-05-26
  - (2026-05-26) Will the Fed increase interest rates by 50+ bps after the June 2026 meeting?
      yes price: 0% · 24h volume: $1,156,118 · resolves 2026-06-17
  - (2026-05-26) Spurs vs. Thunder
      yes price: 38% · 24h volume: $1,069,526 · resolves 2026-05-27
  - (2026-05-26) Will Norway win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $990,327 · resolves 2026-07-20
  - (2026-05-26) Will Oliver Bearman be the 2026 F1 Drivers' Champion?
      yes price: 0% · 24h volume: $789,920 · resolves 2026-12-06
  - (2026-05-26) Will Pierre Gasly be the 2026 F1 Drivers' Champion?
      yes price: 0% · 24h volume: $768,270 · resolves 2026-12-06
  - (2026-05-26) Will Switzerland win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $741,589 · resolves 2026-07-20
  - (2026-05-26) US announces new Iran agreement/ceasefire extension by May 26?
      yes price: 6% · 24h volume: $723,384

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-05-26) [Marginal Revolution] A Beautiful Theory Falls to Ugly Data
      My latest paper, A Test of the Coase Conjecture Using Prices of Electronic Books, with the excellent Tim Groseclose, has just been published. The Coase Conjecture is another one of Coase&#8217;s little ideas — the origin
  - (2026-05-26) [Marginal Revolution] The corporate tax rate really matters
      Three findings emerge. First, improvements in aggregate tax competitiveness are positively and significantly associated with real GDP per capita growth, robust to a wide range of controls. Second, this aggregate effect i
  - (2026-05-26) [Marginal Revolution] What I’ve been reading
      1. Paul Mendes-Flohr, Martin Buber: A Life of Faith and Dissent.  A beautifully written, first-rate intellectual biography of Buber.  It is hard to imagine finding a better book on him. 2. Robert C. Austin and Artan R. H

## How it fits the arc (last 14 days)
- federal_register: today=32, 7d-median=32, 14d-median=32
- macro: today=0, 7d-median=21, 14d-median=21
- markets: today=0, 7d-median=21, 14d-median=21
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=12, 7d-median=12, 14d-median=12
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=12, 14d-median=12

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*