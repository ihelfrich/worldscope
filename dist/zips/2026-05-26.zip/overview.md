# WORLDSCOPE morning brief — 2026-05-26

## Headline
453 new items across 22 section(s).

## What changed today
### U.S. Federal Action — 0 new of 25 total
  (no new items today)

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 0 new of 40 total
  (no new items today)

### Campaign finance (FEC: top fundraisers + recent filings) — 27 new of 27 total
  - (2026-05-26) [Top] OSSOFF, T. JONATHAN (DEM, Senate GA): $81.15M raised
      cycle 2026 receipts $81.15M · disbursements $52.97M · net $+28.17M
  - (2026-05-26) [Top] TALARICO, JAMES (DEM, Senate TX): $40.28M raised
      cycle 2026 receipts $40.28M · disbursements $30.43M · net $+9.86M
  - (2026-05-26) [Top] BOOKER, CORY A. (DEM, Senate NJ): $32.26M raised
      cycle 2026 receipts $32.26M · disbursements $15.55M · net $+16.71M
  - (2026-05-26) [Top] KRISHNAMOORTHI, S (DEM, Senate IL): $31.39M raised
      cycle 2026 receipts $31.39M · disbursements $28.24M · net $+3.15M
  - (2026-05-26) [Top] OCASIO-CORTEZ, ALEXANDRIA (DEM, House NY): $27.73M raised
      cycle 2026 receipts $27.73M · disbursements $16.78M · net $+10.95M
  - (2026-05-26) [Top] COOPER, ROY (DEM, Senate NC): $26.82M raised
      cycle 2026 receipts $26.82M · disbursements $8.37M · net $+18.46M
  - (2026-05-26) [Top] BROWN, SHERROD (DEM, Senate OH): $25.98M raised
      cycle 2026 receipts $25.98M · disbursements $8.95M · net $+17.03M
  - (2026-05-26) [Top] WARNER, MARK ROBERT (DEM, Senate VA): $21.99M raised
      cycle 2026 receipts $21.99M · disbursements $7.77M · net $+14.22M

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-26) [Australia] Bondi terror probe witnesses targeted by online hate
      domain: westernadvocate.com.au · language: English · tone: 
  - (2026-05-26) [Indonesia] Idul Adha and Indonesia protein intake paradox - Academia
      domain: thejakartapost.com · language: English · tone: 
  - (2026-05-26) [United States] Oil Prices Fall 4 . 7 Percent on Hopes of US – Iran Deal
      domain: theepochtimes.com · language: English · tone: 
  - (2026-05-26) [Australia] Australian Federal Police still assessing Pauline Hanson Muslim comments three months after the saga
      domain: skynews.com.au · language: English · tone: 
  - (2026-05-26) [Australia] Lowood death : Mother , child identified as police launch probe into alleged homicide
      domain: theage.com.au · language: English · tone: 
  - (2026-05-26) [United States] Listings | TheFutonCritic . com
      domain: thefutoncritic.com · language: English · tone: 
  - (2026-05-26) [United States] Hour 2 : The Wilderness | 960 WELI | The Jesse Kelly Show
      domain: 960weli.iheart.com · language: English · tone: 
  - (2026-05-26) [Australia] Foul - mouthed bikie denies heading anti - Semitic attack
      domain: westernadvocate.com.au · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 14 new of 15 total
  - (2026-05-26) NCR560 (United States)
      icao24: ad3c48 · position: (21.7408, 91.985) · alt: 9753m · 957km/h
  - (2026-05-26) RCH143 (United States)
      icao24: ae1471 · position: (59.7823, -170.8104) · alt: 10363m · 828km/h
  - (2026-05-26) INDIA1 (India)
      icao24: 8002f6 · position: (26.3288, 86.2608) · alt: 11407m · 875km/h
  - (2026-05-26) RCH049 (United States)
      icao24: ae5e11 · position: (38.1682, -96.1184) · alt: 8458m · 905km/h
  - (2026-05-26) JAF4AB (Belgium)
      icao24: 44d2aa · position: (48.3233, 10.4666) · alt: 11277m · 817km/h
  - (2026-05-26) JAF9NV (Belgium)
      icao24: 449681 · position: (48.953, 9.0743) · alt: 11887m · 794km/h
  - (2026-05-26) JAF68V (Belgium)
      icao24: 44d1ba · position: (46.1998, 2.6399) · alt: 11277m · 774km/h
  - (2026-05-26) JAF62J (Belgium)
      icao24: 44d1a6 · position: (49.8299, 6.7059) · alt: 9936m · 847km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 12 new of 12 total
  - (2026-05-22) CVE-2026-9082 · Drupal Core: Drupal Core SQL Injection Vulnerability
      vendor: Drupal · product: Core · CISA remediation by 2026-05-27
  - (2026-05-21) CVE-2025-34291 · Langflow Langflow: Langflow Origin Validation Error Vulnerability
      vendor: Langflow · product: Langflow · CISA remediation by 2026-06-04
  - (2026-05-21) CVE-2026-34926 · Trend Micro Apex One: Trend Micro Apex One (On-Premise) Directory Traversal Vulnerability
      vendor: Trend Micro · product: Apex One · CISA remediation by 2026-06-04
  - (2026-05-20) CVE-2008-4250 · Microsoft Windows: Microsoft Windows Buffer Overflow Vulnerability
      vendor: Microsoft · product: Windows · CISA remediation by 2026-06-03
  - (2026-05-20) CVE-2009-1537 · Microsoft DirectX: Microsoft DirectX NULL Byte Overwrite Vulnerability
      vendor: Microsoft · product: DirectX · CISA remediation by 2026-06-03
  - (2026-05-20) CVE-2009-3459 · Adobe Acrobat and Reader: Adobe Acrobat and Reader Heap-Based Buffer Overflow Vulnerability
      vendor: Adobe · product: Acrobat and Reader · CISA remediation by 2026-06-03
  - (2026-05-20) CVE-2010-0249 · Microsoft Internet Explorer: Microsoft Internet Explorer Use-After-Free Vulnerability
      vendor: Microsoft · product: Internet Explorer · CISA remediation by 2026-06-03
  - (2026-05-20) CVE-2010-0806 · Microsoft Internet Explorer: Microsoft Internet Explorer Use-After-Free Vulnerability
      vendor: Microsoft · product: Internet Explorer · CISA remediation by 2026-06-03

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 5 new of 20 total
  - (2026-05-26) Will Norway win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $806,559 · resolves 2026-07-20
  - (2026-05-26) Will Oliver Bearman be the 2026 F1 Drivers' Champion?
      yes price: 0% · 24h volume: $787,323 · resolves 2026-12-06
  - (2026-05-26) Will Pierre Gasly be the 2026 F1 Drivers' Champion?
      yes price: 0% · 24h volume: $756,312 · resolves 2026-12-06
  - (2026-05-26) Spurs vs. Thunder
      yes price: 38% · 24h volume: $744,215 · resolves 2026-05-27
  - (2026-05-26) Will Lance Stroll be the 2026 F1 Drivers' Champion?
      yes price: 0% · 24h volume: $724,657 · resolves 2026-12-06

### Commentary & analysis (last 7 days) — 1 new of 6 total
  - (2026-05-26) [Marginal Revolution] What I’ve been reading
      1. Paul Mendes-Flohr, Martin Buber: A Life of Faith and Dissent.  A beautifully written, first-rate intellectual biography of Buber.  It is hard to imagine finding a better book on him. 2. Robert C. Austin and Artan R. H

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=25, 14d-median=25
- macro: today=0, 7d-median=21, 14d-median=21
- markets: today=0, 7d-median=21, 14d-median=21
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=15, 7d-median=15, 14d-median=15
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=12, 7d-median=12, 14d-median=12
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=12, 14d-median=12

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*