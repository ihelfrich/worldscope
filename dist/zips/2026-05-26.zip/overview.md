# WORLDSCOPE morning brief — 2026-05-26

## Headline
172 new items across 10 section(s).

## What changed today
### U.S. Federal Action — 0 new of 25 total
  (no new items today)

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### World leaders & government officials — 0 new of 0 total
  (no new items today)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 30 new of 30 total
  - (2026-05-21) [SCOTUS] Hamm v. Smith
  - (2026-05-21) [SCOTUS] Havana Docks Corp. v. Royal Caribbean Cruises, Ltd.
  - (2026-05-21) [SCOTUS] M & K Employee Solutions, Inc. v. Trustees of IAM Nat. Pension
  - (2026-05-14) [SCOTUS] Jules v. Andre Balazs Properties
  - (2026-05-14) [SCOTUS] Montgomery v. Caribe Transport II, LLC
  - (2026-05-22) [CIT] Toyo Kohan Co., Ltd. v. United States
  - (2026-05-20) [CIT] Oregon v. United States
  - (2026-05-15) [CIT] Green Garden Produce, LLC v. United States

### World News (by country, top stories) — 80 new of 80 total
  - (2026-05-26) [Japan] Outfit 3 DLC revealed for Ingrid , Sagat , Alex and C . Viper in Street Fighter 6
      eventhubs.com · English
  - (2026-05-26) [Japan] Tekken 8 sales have suddenly jumped after the announcement of Yujiro Hanma for Season 3
      eventhubs.com · English
  - (2026-05-26) [Japan] How to turn off aging in Paralives
      destructoid.com · English
  - (2026-05-26) [South Korea] South Korea slow shift for single mothers , through their eyes
      koreaherald.com · English
  - (2026-05-26) [Israel] The six graves in Alaska oldest Jewish cemetery – The Forward
      forward.com · English
  - (2026-05-26) [Israel] Israeli Security Forces Secretly Helped to Smuggle Unsupervised Goods Into Gaza
      haaretz.com · English
  - (2026-05-26) [Israel] Canada demands Israel probe  appalling  treatment of flotilla members
      al-monitor.com · English
  - (2026-05-26) [Israel] Second group of Australian women linked to Islamic State to return home
      al-monitor.com · English

### Government & military aircraft airborne (OpenSky) — 6 new of 6 total
  - (2026-05-26) CFC2594 (Canada)
      icao24: c2b5cb · position: (61.5033, -147.675) · alt: 7856m · 556km/h
  - (2026-05-26) CFCBA (Canada)
      icao24: c00563 · position: (39.1999, -80.1761) · alt: 13716m · 872km/h
  - (2026-05-26) SAMU22 (France)
      icao24: 3988f5 · position: (48.434, -4.4293) · alt: 274m · 212km/h
  - (2026-05-26) RCH529 (United States)
      icao24: ae07d5 · position: (36.9573, -86.3587) · alt: 5486m · 837km/h
  - (2026-05-26) PAT141 (United States)
      on ground · 18km/h
  - (2026-05-26) RCH466 (United States)
      icao24: ae2fa7 · position: (47.5344, -63.6213) · alt: 9144m · 748km/h

### Prediction Markets — most-traded (Polymarket) — 20 new of 20 total
  - (2026-05-26) Knicks vs. Cavaliers
      yes price: 90% · 24h volume: $7,541,306 · resolves 2026-05-26
  - (2026-04-28) Will Bitcoin hit $150k by June 30, 2026?
      yes price: 1% · 24h volume: $5,821,653 · resolves 2026-07-01
  - (2026-05-26) US x Iran permanent peace deal by May 26, 2026?
      yes price: 8% · 24h volume: $5,445,216 · resolves 2026-05-26
  - (2026-05-26) Will the Iran ceasefire continue through May 24?
      yes price: 99% · 24h volume: $4,390,691
  - (2026-05-26) Will the Iran ceasefire continue through May 25?
      yes price: 0% · 24h volume: $3,254,695 · resolves 2026-05-25
  - (2026-05-26) US x Iran permanent peace deal by May 31, 2026?
      yes price: 32% · 24h volume: $2,916,569 · resolves 2026-05-31
  - (2026-05-26) Iran closes its airspace by May 24?
      yes price: 1% · 24h volume: $2,676,874 · resolves 2026-05-24
  - (2026-05-26) Will Mexico win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,120,273 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-05-25) [Marginal Revolution] *Silent Friend*
      An excellent and profound movie, large screen essential.  I take this movie to be an engagement with the truths of German romanticism (set in Marburg, with Geothe and Rilke as relevant texts), and asking whether that rom
  - (2026-05-25) [Marginal Revolution] New Aesthetics awards
      Patrick Collison tweets: Tyler and I just published a list of the recipients of the New Aesthetics grants: https://newaesthetics.art/grants. Thank you very much to all who applied. There were far more applications than w
  - (2026-05-25) [Marginal Revolution] Monday assorted links
      1. Sampling DNA from animal skin parchments. 2. The making of Indian statistics. 3. What happens if your iPhone is stolen in London? (NYT) 4. Brazil school phone bans: &#8220;We then show that test scores, which were tre
  - (2026-05-22) [Conversable Economist] Agricultural Production Functions Without Prices
      I admit this story is insider stuff for those with experience of academic seminars for economists. But it made me laugh, so I pass it along. It&#8217;s how Jesse Tack, Jisang Yu, and Roderick M. Rejesus introduce their r
  - (2026-05-20) [Conversable Economist] A Foretaste of Warsh as Chair of the Federal Reserve
      Kevin Warsh was nominated by President Trump in January 2026 to replace Jerome Powell as Chair of the Federal Reserve. He was confirmed by the US Senate last week and sworn in as the new Fed chair earlier this week. What
  - (2026-05-19) [Conversable Economist] How is AI Affecting the Quantity and Quality of New Books?
      For those of us who live in the world of editing, writing, and publishing, the ability of the newest generations of AI tools to produce rivers of grammatically correct prose is a deep shock. But is there actual evidence 

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=25, 14d-median=25
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- vip_flights: today=6, 7d-median=6, 14d-median=6
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*