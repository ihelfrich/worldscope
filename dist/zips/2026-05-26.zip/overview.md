# WORLDSCOPE morning brief — 2026-05-26

## Headline
424 new items across 14 section(s).

## What changed today
### U.S. Federal Action — 0 new of 25 total
  (no new items today)

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 0 new of 40 total
  (no new items today)

### Campaign finance (FEC: top fundraisers + recent filings) — 27 new of 27 total
  - (2026-05-26) [Top] OSSOFF, T. JONATHAN (DEM, Senate GA): $81.15M raised
      cycle 2026 receipts $81.15M · disbursements $52.97M · net $+28.17M
  - (2026-05-26) [Top] TALARICO, JAMES (DEM, Senate TX): $40.28M raised
      cycle 2026 receipts $40.28M · disbursements $30.43M · net $+9.86M
  - (2026-05-26) [Top] BOOKER, CORY A. (DEM, Senate NJ): $32.26M raised
      cycle 2026 receipts $32.26M · disbursements $15.55M · net $+16.71M
  - (2026-05-26) [Top] KRISHNAMOORTHI, S (DEM, Senate IL): $31.39M raised
      cycle 2026 receipts $31.39M · disbursements $28.24M · net $+3.15M
  - (2026-05-26) [Top] OCASIO-CORTEZ, ALEXANDRIA (DEM, House NY): $27.73M raised
      cycle 2026 receipts $27.73M · disbursements $16.78M · net $+10.95M
  - (2026-05-26) [Top] COOPER, ROY (DEM, Senate NC): $26.82M raised
      cycle 2026 receipts $26.82M · disbursements $8.37M · net $+18.46M
  - (2026-05-26) [Top] BROWN, SHERROD (DEM, Senate OH): $25.98M raised
      cycle 2026 receipts $25.98M · disbursements $8.95M · net $+17.03M
  - (2026-05-26) [Top] WARNER, MARK ROBERT (DEM, Senate VA): $21.99M raised
      cycle 2026 receipts $21.99M · disbursements $7.77M · net $+14.22M

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-26) [United States] Protests escalate at N . J . ICE facility ; detainees claim hunger strike
      domain: breitbart.com · language: English · tone: 
  - (2026-05-26) [United States] Trump : Iran  Nuclear Dust  uranium will be destroyed or surrendered
      domain: upnorthlive.com · language: English · tone: 
  - (2026-05-26) [United States] Texans honor service men , women on Memorial Day
      domain: fox7austin.com · language: English · tone: 
  - (2026-05-26) [Germany] Elektros , Inc .: As More Global Investors Discover ELEKTROS Inc . Vision for Hard Rock Lithium Mining and Advanced EV Patent Technology , the Company Celebrates Growing Worldwide Interest
      domain: finanznachrichten.de · language: English · tone: 
  - (2026-05-26) [United States] Memorial Day parades honor fallen in Wrightstown , De Pere
      domain: wbay.com · language: English · tone: 
  - (2026-05-26) [United States] Spring migration is here : Watch for Western painted turtles crossing MT highways
      domain: kxlf.com · language: English · tone: 
  - (2026-05-26) [United States]   I felt used , dirty , like a prostitute :  After two women claim they were raped on Channel 4 Married At First Sight , another  bride  tells of her own deeply traumatising experience
      domain: dailymail.com · language: English · tone: 
  - (2026-05-26) [United Kingdom] Streeting likens social media to tobacco as pressure grows for under - 16s ban
      domain: cravenherald.co.uk · language: English · tone: 

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 3 new of 20 total
  - (2026-05-26) Colorado Rockies vs. Los Angeles Dodgers
      yes price: 6% · 24h volume: $1,364,378 · resolves 2026-06-02
  - (2026-05-26) Spurs vs. Thunder
      yes price: 38% · 24h volume: $854,354 · resolves 2026-05-27
  - (2026-05-26) Will Norway win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $811,573 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 0 new of 6 total
  (no new items today)

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=25, 14d-median=25
- macro: today=0, 7d-median=21, 14d-median=21
- markets: today=0, 7d-median=21, 14d-median=21
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- conflict: today=40, 7d-median=40, 14d-median=40
- vip_flights: today=0, 7d-median=8, 14d-median=8
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=12, 14d-median=12

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*