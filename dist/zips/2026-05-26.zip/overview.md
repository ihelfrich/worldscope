# WORLDSCOPE morning brief — 2026-05-26

## Headline
98 new items across 4 section(s).

## What changed today
### U.S. Federal Action — 0 new of 25 total
  (no new items today)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### World News (by country, top stories) — 62 new of 62 total
  - (2026-05-26) [China] 代价与现实 ： 川普中东新格局 | www . wenxuecity . com
      wenxuecity.com · English
  - (2026-05-26) [China] 广西十日 南宁 崇左 桂林 | www . wenxuecity . com
      wenxuecity.com · English
  - (2026-05-26) [China]  《 雅典学院 》 壁画中的哲理三角形与对理解当前中国与世界关系的重要意义 | www . wenxuecity . com
      wenxuecity.com · English
  - (2026-05-26) [China] Private equity firm Templewater primed as Hong Kong moves to deepen Central Asia ties
      scmp.com · English
  - (2026-05-26) [China] French Open : Zheng woes continue after losing 1st - round match
      china.org.cn · English
  - (2026-05-26) [China] Modernista Presents Songwriter Series : Heseri Jalantai
      thebeijinger.com · English
  - (2026-05-26) [Japan] Outfit 3 DLC revealed for Ingrid , Sagat , Alex and C . Viper in Street Fighter 6
      eventhubs.com · English
  - (2026-05-26) [Japan] Tekken 8 sales have suddenly jumped after the announcement of Yujiro Hanma for Season 3
      eventhubs.com · English

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-05-25) [Marginal Revolution] *Silent Friend*
      An excellent and profound movie, large screen essential.  I take this movie to be an engagement with the truths of German romanticism (set in Marburg, with Geothe and Rilke as relevant texts), and asking whether that rom
  - (2026-05-25) [Marginal Revolution] New Aesthetics awards
      Patrick Collison tweets: Tyler and I just published a list of the recipients of the New Aesthetics grants: https://newaesthetics.art/grants. Thank you very much to all who applied. There were far more applications than w
  - (2026-05-25) [Marginal Revolution] Monday assorted links
      1. Sampling DNA from animal skin parchments. 2. The making of Indian statistics. 3. What happens if your iPhone is stolen in London? (NYT) 4. Brazil school phone bans: &#8220;We then show that test scores, which were tre
  - (2026-05-22) [Conversable Economist] Agricultural Production Functions Without Prices
      I admit this story is insider stuff for those with experience of academic seminars for economists. But it made me laugh, so I pass it along. It&#8217;s how Jesse Tack, Jisang Yu, and Roderick M. Rejesus introduce their r
  - (2026-05-20) [Conversable Economist] A Foretaste of Warsh as Chair of the Federal Reserve
      Kevin Warsh was nominated by President Trump in January 2026 to replace Jerome Powell as Chair of the Federal Reserve. He was confirmed by the US Senate last week and sworn in as the new Fed chair earlier this week. What
  - (2026-05-19) [Conversable Economist] How is AI Affecting the Quantity and Quality of New Books?
      For those of us who live in the world of editing, writing, and publishing, the ability of the newest generations of AI tools to produce rivers of grammatically correct prose is a deep shock. But is there actual evidence 

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=25, 14d-median=25
- sanctions: today=30, 7d-median=30, 14d-median=30
- gdelt_regions: today=62, 7d-median=62, 14d-median=62
- commentary: today=6, 7d-median=6, 14d-median=6

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-12] ECB press: Frank Elderson: Boosting prosperity through deeper integration
- [2026-05-13] ECB press: Philip R. Lane: Analytical perspectives on energy supply shocks
- [2026-05-13] ECB press: Christine Lagarde: The courage to build a Europe that endures
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces it does not object to the conversion of United Texas Bank, of Dallas, Texas, from a bank supervised by the Federal Reserve to a national bank supervised by the Office of the Comptroller of the Currency
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*