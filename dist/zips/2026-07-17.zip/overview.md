# WORLDSCOPE morning brief — 2026-07-17

## Headline
4822 new items across 28 active section(s) (of 42 tracked).

## Top movers today
State-Level News (961) · International News + Multilateral Institutions (938) · Russian Internal News (state + in-exile) (905) · World leaders & government officials (324) · Chinese Internal News (318) · Ukraine Theater (total-war monitoring) (299) · Local News: St. Louis + Atlanta (248) · U.S. Weather + Severe / Climate Outlooks (163) · Ukrainian Internal News (national + local Kyiv) (130) · GDACS — global disaster alerts (72) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (58)

## What changed today
### State-Level News — 961 new of 974 total
  - (2026-07-17) [Alabama] Governor Ivey Deploys Swiftwater Rescue Teams to Texas to Assist Amid Severe Flooding
      MONTGOMERY – Governor Kay Ivey on Friday announced she has deployed four Type III Swiftwater search-and-rescue teams to assist Texas with ongoing life-threatening flooding. “Alabamians always stand ready to lend a helpin…
  - (2026-07-16) [Alabama] Governor Ivey Continues Rebuilding Alabama with $3.6 Million in Road Grants
      MONTGOMERY – Governor Kay Ivey on Thursday announced more than $3.6 million in state funding is being awarded to cities and counties for 11 road projects across Alabama, highlighting her ongoing commitment to enhancing t…
  - (2026-07-15) [Alabama] Governor Ivey Taps Glenda Allred as New Tourism Director, Announces Lee Sentell’s Retirement
      MONTGOMERY – Governor Kay Ivey on Wednesday announced the retirement of Lee Sentell, Alabama’s longest-serving Tourism Director. Governor Bob Riley originally appointed Sentell in 2003. “Since Lee began serving at the De…
  - (2026-07-17) [California] Governor Newsom announces California nearly triples internet infrastructure ready to connect homes and businesses
      Source
  - (2026-07-17) [California] California Film and Television Tax Credit awardees secure 79 Emmy nominations
      Source
  - (2026-07-17) [California] Governor Newsom announces appointments

### International News + Multilateral Institutions — 938 new of 1080 total
  - (2026-07-18) [India] Babulal Marandi writes to Hemant Soren demanding a judicial probe into the alleged scam in JSDMS
  - (2026-07-18) [India] Jantar Mantar protest updates: Opposition support grows as Wangchuk’s hunger strike continues on day 20
      “The medical team stated that Sonam Wangchuk continues to be under 24-hour medical vigilance, with his health being monitored closely,” the CJP said
  - (2026-07-18) [India] Congress alleges irregularities in gram sabha approvals for Ken-Betwa project
  - (2026-07-18) [India] Congress moves no-confidence motion against Sai government in Chhattisgarh Assembly
  - (2026-07-18) [India] Groping breasts not part of routine gynaecological examination, says Gauhati High Court
  - (2026-07-18) [India] ‘Sharad Pawar should take the final call on allying with NDA’

### Russian Internal News (state + in-exile) — 905 new of 908 total
  - (2026-07-17) Зеленский пообещал открыть архивы по Волынской резне | LEDE: Президент Украины Владимир Зеленский объявил о планах открыть архивы украинских спецслужб, посвященные Волынской резне. Об этом о] (ru: Зел…
      Президент Украины Владимир Зеленский объявил о планах открыть архивы украинских спецслужб, посвященные Волынской резне. Об этом он объявил по итогам совещания, посвященного отношениям с Польшей.
  - (2026-07-17) Россиян, задержанных в Стамбуле за чтение Библии в мечети Айя-София, отправили в Россию | LEDE: Двое граждан России, задержанные в соборе Айя-София в Стамбуле за чтение Библии, вечером 17 ию] (ru: Рос…
      Двое граждан России, задержанные в соборе Айя-София в Стамбуле за чтение Библии, вечером 17 июля вылетели в РФ. Об этом сообщает ТАСС со ссылкой на российское генконсульство.
  - (2026-07-17) В Киеве, Одессе, Львове и других городах Украины снова прошли протесты из-за смены министра обороны. Люди скандируют «Верните Федорова!» и «Долой Сырского!» | LEDE: Жители нескольких городов] (ru: В К…
      Жители нескольких городов Украины снова вышли на улицы на акции протеста против отставки Михаила Федорова с поста министра обороны. Об этом сообщают «Украинская правда» и «Суспiльне».
  - (2026-07-17) Правительство РФ предложило расширить список статей УК, осужденных по которым можно отправлять на войну | LEDE: Правительство России внесло в Госдуме законопроект, предлагающий расширить спи] (ru: Пра…
      Правительство России внесло в Госдуме законопроект, предлагающий расширить список статей Уголовного кодекса, обвиняемые и осужденные по которым могут заключать контракты с Минобороны РФ во время мобилизации, военного пол…
  - (2026-07-17) Провластного блогера Илью Ремесло отправили в СИЗО за посты с критикой Путина | LEDE: Басманный районный суд Москвы арестовал на два месяца провластного блогера и доносчика Илью Ремесло, кот] (ru: Про…
      Басманный районный суд Москвы арестовал на два месяца провластного блогера и доносчика Илью Ремесло, которого обвиняют в «фейках» про российскую армию по мотиву политической ненависти (пункт «д» части 2 статьи 207.3 УК).…
  - (2026-07-17) В реестр «нежелательных» организаций внесли несуществующее международное движение «Голос» | LEDE: Минюст России включил в реестр «нежелательных» организаций международное общественное движен] (ru: В р…
      Минюст России включил в реестр «нежелательных» организаций международное общественное движение «В Защиту прав избирателей „Голос“».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 318 new of 318 total
  - (2026-07-16) Chinese Consumers Tighten Purse Strings Despite Modest Income Gains - Caixin Global
      Chinese Consumers Tighten Purse Strings Despite Modest Income Gains Caixin Global
  - (2026-07-15) China’s Growth Misses, but AI and Oil Prices Snap Its 3-Year Deflation Streak - Caixin Global
      China’s Growth Misses, but AI and Oil Prices Snap Its 3-Year Deflation Streak Caixin Global
  - (2026-07-15) China Clears Mobile AI Models, Paving Way for Apple Intelligence - Caixin Global
      China Clears Mobile AI Models, Paving Way for Apple Intelligence Caixin Global
  - (2026-07-16) 日本一女护士涉嫌在患者输液管中混入粪便，致其死亡后被捕 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE05RVN2SDRMczZ1N0lrVHJJU3RWdjZxcXdUYnJ6YTlwWGRsaU1NOU9semt1aHlneS0ta003cFRLczk4V0M5cEI1b0tp] (zh:…
      日本一女护士涉嫌在患者输液管中混入粪便，致其死亡后被捕 观察者网
  - (2026-07-16) 警惕！“德国对华立场大转向” - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE01VTlvNFdFc2xaOE83Yl91NTlEVzVhcXhLOExDSzE1enZPeVdKYnZ1YjB6ajA5UnF6Z0d5ZGl1ckhlN0JCclB3M0E1YnJtQ212SWRRW] (zh:…
      警惕！“德国对华立场大转向” 观察者网
  - (2026-07-16) 三地四馆、规模创纪录，WAIC 2026今日开幕 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5wSE95eVVKV2IxbHd4amRvSV9zVE4tVjFLTEw2VXV1MWY0eDBucVkyZVVZNkQ5MHJ0OTI2djlpQVQzSzFhWEgxZWFrSFZ] (zh:…
      三地四馆、规模创纪录，WAIC 2026今日开幕 观察者网

### Ukraine Theater (total-war monitoring) — 299 new of 400 total
  - (2026-07-17) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-16) [FIRMS] thermal anomaly 46.618, 32.688 (FRP 2.3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 2.3 MW
  - (2026-07-16) [FIRMS] thermal anomaly 46.616, 32.727 (FRP 0.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 0.85 MW
  - (2026-07-16) [FIRMS] thermal anomaly 46.389, 34.814 (FRP 1.17 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 1.17 MW
  - (2026-07-16) [FIRMS] thermal anomaly 46.465, 32.140 (FRP 0.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 0.73 MW
  - (2026-07-16) [FIRMS] thermal anomaly 46.123, 34.828 (FRP 1.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 1.78 MW

### Local News: St. Louis + Atlanta — 248 new of 248 total
  - (2026-07-17) [St. Louis] Kris Miss Bake Shop opens in Lake Saint Louis
      Kristen Gassel remembers the moment she shed her first tear over her vegan and allergen-friendly baked goods brand, Kris Miss. A few years ago, a little boy and his mother approached her booth at the Lake Saint Louis Far…
  - (2026-07-17) [St. Louis] New Cardinal Glennon center will keep more moms and babies together after high-risk births
      For most families, childbirth is filled with firsts: the first cry, the first cuddle, the first hours spent getting to know a brand-new baby. But for parents facing a high-risk pregnancy or a newborn who needs intensive…
  - (2026-07-17) [St. Louis] Kirkwood City Council OKs upgrades for Public Works building, despite growing budget concerns
      The Kirkwood City Council is counting pennies like never before—the result of $116 million in debt and a $15.6 million Electric Department overspending scandal that sent electric rates soaring. Kirkwood’s newfound auster…
  - (2026-07-17) [St. Louis] Account Executive
      Help St. Louis businesses grow through one of the region’s most trusted media brands. SLM Media Group is looking for a driven, curious, and commercially minded Account Executive to help local businesses reach the St. Lou…
  - (2026-07-17) [St. Louis] What St. Louis restaurants are saying about the cyclospora outbreak
      Ask George: Have St. Louis restaurants made any adjustments following the cyclospora outbreak? It only took two words to briefly knock international politics out of the headlines: “explosive diarrhea.” Reports of a cyclo…
  - (2026-07-17) [St. Louis] The most anticipated restaurants in metro St. Louis
      Learn even more about these restaurants on the Arch Eats podcast. ELEVATION By. K. RENAProjected Opening: Late JulyThis forthcoming Grand Center destination is led by Korri King and backed by luxury beverage partners inc…

### U.S. Weather + Severe / Climate Outlooks — 163 new of 165 total
  - (2026-07-17) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 17 at 6:32PM CDT until July 17 at 7:00PM CDT by NWS Midland/Odessa TX
      At 632 PM CDT, a severe thunderstorm was located 9 miles northwest of Marathon, or 19 miles east of Alpine, and is nearly stationary. HAZARD...60 mph wind gusts and half dollar size hail. SOURCE...Radar indicated. IMPACT…
  - (2026-07-17) [Moderate] Special Weather Statement: Special Weather Statement issued July 17 at 7:32PM EDT by NWS Wilmington OH
      At 732 PM EDT, a strong thunderstorm was located over Johnstown, moving northeast at 15 mph. HAZARD...Wind gusts up to 45 mph and very heavy rain. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limb…
  - (2026-07-17) [Moderate] Special Weather Statement: Special Weather Statement issued July 17 at 5:31PM MDT by NWS Salt Lake City UT
      At 531 PM MDT, Doppler radar was tracking a strong thunderstorm near Bluffdale, or 10 miles southwest of Sandy, moving northeast at 10 mph. HAZARD...Pea size hail. SOURCE...Radar indicated. IMPACT...Minor damage to outdo…
  - (2026-07-17) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 17 at 7:30PM EDT until July 17 at 8:00PM EDT by NWS Louisville KY
      SVRLMK The National Weather Service in Louisville has issued a * Severe Thunderstorm Warning for... Southeastern Oldham County in central Kentucky... Northwestern Shelby County in central Kentucky... Southwestern Henry C…
  - (2026-07-17) [Severe] Flood Warning: Flood Warning issued July 17 at 7:30PM EDT until July 18 at 3:00AM EDT by NWS Wilmington OH
      * WHAT...Flooding caused by excessive rainfall is expected. * WHERE...Southern Warren County, northeast Hamilton County, and northwest Clermont County in Ohio. * WHEN...Until 300 AM EDT Saturday. * IMPACTS...Flooding of…
  - (2026-07-17) [Severe] Flash Flood Warning: Flash Flood Warning issued July 17 at 5:29PM MDT until July 17 at 6:45PM MDT by NWS Salt Lake City UT
      At 529 PM MDT, Piute County Emergency Management reported Flash Flooding and debris flows in upper Bullion Canyon with flood waters moving downstream Bullion Creek towards Marysvale. Between 0.5 and 0.6 inches of rain ha…

### Ukrainian Internal News (national + local Kyiv) — 130 new of 138 total
  - (2026-07-18) У Франції через сильну спеку за тиждень загинуло майже 3 тисячі людей | LEDE: У червні рекордна спека спричинила понад 3 тис. смертей у регіоні Іль-де-Франс, що удвічі вище за норму.] (uk: У Франції ч…
      У червні рекордна спека спричинила понад 3 тис. смертей у регіоні Іль-де-Франс, що удвічі вище за норму.
  - (2026-07-18) У Києві та областях двічі за ніч оголошували тривогу через загрозу балістики | LEDE: У Києві в ніч на 18 липня двічі лунала повітряна тривога через можливу атаку з Таганрогу.] (uk: У Києві та областях…
      У Києві в ніч на 18 липня двічі лунала повітряна тривога через можливу атаку з Таганрогу.
  - (2026-07-18) США оголосили про нові удари по Ірану | LEDE: CENTCOM сьому ніч поспіль атакує цілі в Ірані задля послаблення його військового потенціалу.] (uk: США оголосили про нові удари по Ірану)
      CENTCOM сьому ніч поспіль атакує цілі в Ірані задля послаблення його військового потенціалу.
  - (2026-07-18) "Резерв+" може бути недоступним з 18 до 22 липня — Міноборони | LEDE: Через технічні роботи Резерв+ буде тимчасово недоступним 18-22 липня. Завчасно підготуйте PDF-документ.] (uk: "Резерв+" може бути…
      Через технічні роботи Резерв+ буде тимчасово недоступним 18-22 липня. Завчасно підготуйте PDF-документ.
  - (2026-07-17) Від початку доби на фронті відбулося 229 бойових зіткнень – Генштаб | LEDE: 229 бойових зіткнень відбулось на фронті з початку доби 17 липня і до 22:00.] (uk: Від початку доби на фронті відбулося 229…
      229 бойових зіткнень відбулось на фронті з початку доби 17 липня і до 22:00.
  - (2026-07-17) РФ знову атакувала судно під прапором Маршаллових Островів в порту Одещини: 4 постраждалих | LEDE: Російські війська ввечері 17 липня атакували цивільне судно під прапором Маршаллових Островів ] (uk:…
      Російські війська ввечері 17 липня атакували цивільне судно під прапором Маршаллових Островів на Одещині: четверо членів екіпажу постраждали.

### GDACS — global disaster alerts — 72 new of 101 total
  - (2026-07-16) [Orange] Eruption Mayon
      Volcano · Orange alert · Philippines
  - (2026-07-16) [Orange] Eruption Mayon
      Volcano · Orange alert · Philippines
  - (2026-07-12) [Orange] Forest fires in France
      Wildfire · Orange alert · France · Orange impact for forestfire in 2280 ha
  - (2026-07-12) [Orange] Forest fires in France
      Wildfire · Orange alert · France · Orange impact for forestfire in 2280 ha
  - (2026-07-11) [Green] Flood in Malaysia
      Flood · Green alert · Malaysia · Magnitude 0
  - (2026-07-11) [Green] Flood in Malaysia
      Flood · Green alert · Malaysia · Magnitude 0

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Keathley v. Buddy Ayers
  - (2026-07-17) U.S. Court of Appeals, 3rd Cir.: Association of New Jersey Rifle and Pistol Clubs I v. Attorney General New Jersey
  - (2026-07-17) U.S. Court of Appeals, 3rd Cir.: City of Chester Pennsylvania v.
  - (2026-07-17) U.S. Court of Appeals, 1st Cir.: Rhode Island Truck Ctr., LLC v. Daimler Trucks North America, LLC
  - (2026-07-17) U.S. Court of Appeals, 6th Cir.: Gertrude Crisp v. Scioto Ambulance Dist.
  - (2026-07-17) U.S. Court of Appeals, 6th Cir.: Naya Abbey v. Metro. Gov't of Nashville & Davidson Cnty.

### IT, InfoSys & cybersecurity news (last 7 days) — 58 new of 58 total
  - (2026-07-17) [BleepingComputer] Abbott probes two cyber incidents amid extortion claims
      Abbott Laboratories is investigating two separate cybersecurity incidents after confirming unauthorized access to internal legacy Exact Sciences systems in its Cancer Diagnostics business, while also investigating a sepa…
  - (2026-07-17) [BleepingComputer] HollowByte DDoS flaw bloats OpenSSL server memory with 11-byte payload
      A vulnerability dubbed HollowByte allows unauthenticated attackers to trigger a denial-of-service (DoS) condition on OpenSSL servers with a malicious payload of just 11 bytes. [...]
  - (2026-07-17) [BleepingComputer] Ernst & Young discloses data breach after support system hack
      Ernst & Young is notifying customers of a data breach caused by the compromise of a third-party support ticket system used by its IT personnel. [...]
  - (2026-07-17) [BleepingComputer] Inside the Search for "Clean" Residential Proxies for Carding
      Residential proxies are no longer the silver bullet they once were for carding. Flare explains why cybercriminals increasingly seek "clean" residential proxies and combine them with browser fingerprints, device profiles,…
  - (2026-07-17) [BleepingComputer] New Windows LegacyHive zero-day gives hackers admin privileges
      A security researcher using the "Nightmare Eclipse" handle has released a Windows zero-day exploit dubbed LegacyHive that allows attackers to escalate privileges on up-to-date Windows systems. [...]
  - (2026-07-17) [The Hacker News] New wp2shell WordPress Core Flaw Lets Unauthenticated Attackers Run Code
      An anonymous HTTP request can run code on a WordPress site. The bug is in core, so a bare install with zero plugins is exploitable. Every 6.9 and 7.0 site was in range until Friday, when WordPress shipped 6.9.5 and 7.0.2…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-07-17) [Russia oil sanctions perimeter · keywords] Shadow Fleet : The Vessels Behind the World Biggest Superyachts
      superyachts.com · English · tone NA
  - (2026-07-17) [Russia oil sanctions perimeter · keywords] UK Denies Bail to Chinese Captain of Detained Shadow Fleet Tanker
      maritime-executive.com · English · tone NA
  - (2026-07-17) [Russia oil sanctions perimeter · keywords] Russian troops surviving an average of 20 and 30 minute on Ukraine front line due to AI killing machine , CIA says
      lbc.co.uk · English · tone NA
  - (2026-07-17) [Russia oil sanctions perimeter · keywords] Ireland to prioritise maritime security during EU presidency
      irishsun.com · English · tone NA
  - (2026-07-17) [Russia oil sanctions perimeter · keywords] Sanctioned tanker is leaking oil near Oman , according to satellite images and experts
      al-monitor.com · English · tone NA
  - (2026-07-17) [Russia oil sanctions perimeter · keywords] UK court denies bail to Indian captain of sanctioned Russian oil vessel
      timesofindia.indiatimes.com · English · tone NA

### Paper Trading Scorecard — 45 new of 144 total
  - (2026-07-17) [Polymarket] Will the Atlanta Braves win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-07-17) [Polymarket] Israel withdraws from Lebanon by December 31, 2026?
      This market will resolve to "Yes" if Israel announces it has withdrawn all ground forces from Lebanon by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No". For this market to resolve to "Yes" i…
  - (2026-07-17) [Polymarket] Will Kansas City Chiefs win the 2027 NFL AFC Championship?
      This market will resolve according to the team that wins the 2027 AFC championship game. If at any point it becomes impossible for a listed team to win the 2027 NFL AFC championship per the rules of the NFL (e.g., they a…
  - (2026-07-17) [Polymarket] Will the Indianapolis Colts win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-17) [Polymarket] Will Lautaro Martinez win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-07-17) [Polymarket] Will John Pardon win the 2026 Fields Medal?
      The Fields Medal is a prize regarded as the top award in the field of mathematics worldwide. It is awarded to two, three, or four mathematicians under 40 years of age at the International Congress of the International Ma…

### Government Action: Sanctions + Procurement + Foreign Agents — 45 new of 119 total
  - (2026-07-17) [OFAC] Hong Kong-related Designations Updates and Removals - Office of Foreign Assets Control (.gov)
      Hong Kong-related Designations Updates and Removals Office of Foreign Assets Control (.gov)
  - (2026-07-13) [OFAC] Cyber-related Designations; Cuba Designations; Issuance of Cuba-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Cyber-related Designations; Cuba Designations; Issuance of Cuba-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-07-15) [OFAC] Non-Proliferation Designations; Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Non-Proliferation Designations; Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-07-17) [OFAC] 1263 - Office of Foreign Assets Control (.gov)
      1263 Office of Foreign Assets Control (.gov)
  - (2026-07-14) [OFAC] Iran-related Designations; Iran-related and Counter Terrorism Designation Update; Issuance of Iran-related General License - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Iran-related and Counter Terrorism Designation Update; Issuance of Iran-related General License Office of Foreign Assets Control (.gov)
  - (2026-07-14) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Sec - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Sec Office of Foreign Assets Control (.gov)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-17) [ADAR1 Capital Management, LLC] Form 4 (Reporting)
      filed 2026-07-17 23:29 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001940272-26-000010 Size: 7 KB
  - (2026-07-17) [Schneeberger Daniel] Form 4 (Reporting)
      filed 2026-07-17 23:29 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001940272-26-000010 Size: 7 KB
  - (2026-07-17) [InMed Pharmaceuticals Inc.] Form 4 (Issuer)
      filed 2026-07-17 23:29 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001940272-26-000010 Size: 7 KB
  - (2026-07-17) [Turley Bryan Patrick] Form 4 (Reporting)
      filed 2026-07-17 23:26 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001213900-26-079342 Size: 6 KB
  - (2026-07-17) [Jones Ventures INTL Acquisition1 Corp] Form 4 (Issuer)
      filed 2026-07-17 23:26 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001213900-26-079342 Size: 6 KB
  - (2026-07-17) [Jones Ventures INTL Acquisition1 Sponsor LLC] Form 4 (Reporting)
      filed 2026-07-17 23:25 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001213900-26-079341 Size: 7 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-17) [Philippines] FLUENT Provides Update and Supplemental Disclosure on Circular to Approve All - Stock Transaction With Vireo Growth Inc .
      domain: manilatimes.net · language: English · tone:
  - (2026-07-17) [United States] Plea deal reached in case of baby found alive in rural Adams County ditch
      domain: wowt.com · language: English · tone:
  - (2026-07-17) [United States] Canadian wildfire smoke smothers US : PHOTOS
      domain: washingtonexaminer.com · language: English · tone:
  - (2026-07-17) [United States] Milk prices at an all - time high , but most consumer costs slip in June after months of increases
      domain: citizensvoice.com · language: English · tone:
  - (2026-07-17) [United States] Infectious Disease Doctors Answer the Top 6 Questions About Cyclosporiasis Right Now
      domain: womenshealthmag.com · language: English · tone:
  - (2026-07-17) [Australia] Promoting misogyny as four women and girls killed
      domain: yasstribune.com.au · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 28 new of 28 total
  - (2026-07-17) M 7.3 - 58 km WSW of Puerto Madero, Mexico
      M7.3 · 58 km WSW of Puerto Madero, Mexico · depth 18.584 km · PAGER yellow
  - (2026-07-17) M 6.0 - 90 km SW of Puerto Madero, Mexico
      M6.0 · 90 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-17) M 5.3 - 93 km SW of Puerto Madero, Mexico
      M5.3 · 93 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-17) M 5.3 - 203 km N of Hadibu, Yemen
      M5.3 · 203 km N of Hadibu, Yemen · depth 10 km
  - (2026-07-17) M 5.2 - 67 km SW of Puerto Madero, Mexico
      M5.2 · 67 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-17) M 5.2 - 11 km SE of Kiupo, Philippines
      M5.2 · 11 km SE of Kiupo, Philippines · depth 79.819 km

### U.S. Federal Action — 17 new of 17 total
  - (2026-07-17) Modifying the Grand Staircase-Escalante National Monument
  - (2026-07-17) Modifying the Bears Ears National Monument
  - (2026-07-17) Death of Senator Lindsey Graham
  - (2026-07-17) Fisheries of the Exclusive Economic Zone off Alaska; Amendment 129 to the Fishery Management Plan for Groundfish of the Bering Sea and Aleutian Islands Management Area; Amendment 58 to the Fishery Man…
      The North Pacific Fishery Management Council (Council) submitted amendment 129 to the Fishery Management Plans for Groundfish of the Bering Sea and Aleutian Islands Management Area (BSAI FMP) and amendment 58 to the Fish…
  - (2026-07-17) Airworthiness Directives; Diamond Aircraft Industries GmbH
      The FAA is adopting a new airworthiness directive (AD) for all Diamond Aircraft Industries GmbH (DAI) Model DA 42, DA 42 NG, and DA 42 M-NG airplanes. This AD was prompted by occurrences of uncommanded rudder deflection…
  - (2026-07-17) Margin Requirements for Uncleared Swaps for Swap Dealers and Major Swap Participants
      The Commodity Futures Trading Commission ("Commission") is amending the margin requirements for uncleared swaps applicable to swap dealers and major swap participants that are not subject to the margin rules of a prudent…

### CISA Known Exploited Vulnerabilities (last 14d) — 16 new of 16 total
  - (2026-07-16) CVE-2026-58644 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-19
  - (2026-07-16) CVE-2026-25089 · Fortinet FortiSandbox: Fortinet FortiSandbox OS Command Injection Vulnerability
      vendor: Fortinet · product: FortiSandbox · CISA remediation by 2026-07-19
  - (2026-07-16) CVE-2026-39808 · Fortinet FortiSandbox: Fortinet FortiSandbox OS Command Injection Vulnerability
      vendor: Fortinet · product: FortiSandbox · CISA remediation by 2026-07-19
  - (2026-07-15) CVE-2026-46817 · Oracle E-Business Suite: Oracle E-Business Suite Improper Privilege Management Vulnerability
      vendor: Oracle · product: E-Business Suite · CISA remediation by 2026-07-18
  - (2026-07-15) CVE-2023-4346 · KNX Association KNX Protocol Connection Authorization Option 1: KNX Association KNX Protocol Connection Authorization Option 1 Overly Restrictive Account Lockout Mechanism Vulnerabilit…
      vendor: KNX Association · product: KNX Protocol Connection Authorization Option 1 · CISA remediation by 2026-07-29
  - (2026-07-14) CVE-2026-56155 · Microsoft Active Directory Federation Services: Microsoft Active Directory Federation Services Insufficient Granularity of Access Control Vulnerability
      vendor: Microsoft · product: Active Directory Federation Services · CISA remediation by 2026-07-28

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-07-17) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $5,085,096 · resolves 2026-06-01
  - (2026-07-17) Will Belete Molla be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $4,787,001 · resolves 2026-06-01
  - (2026-07-17) Exact Score: Spain 2 - 3 Argentina?
      yes price: 3% · 24h volume: $1,663,290 · resolves 2026-07-19
  - (2026-07-17) Will France win on 2026-07-18?
      yes price: 52% · 24h volume: $1,187,320 · resolves 2026-07-18
  - (2026-07-17) France vs. England: Team to Win
      yes price: 66% · 24h volume: $1,185,683 · resolves 2026-07-18
  - (2026-07-17) Tampa Bay Rays vs. Boston Red Sox
      yes price: 0% · 24h volume: $932,194 · resolves 2026-05-16

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-17) [China] US LNG exports to add $1 . 4 trillion to GDP by 2040 , study says | Hellenic Shipping News Worldwide
      hellenicshippingnews.com · English
  - (2026-07-17) [China] Huawei Pura 90s Pro Max in for review
      gsmarena.com · English
  - (2026-07-17) [China] China hits out at British Steel nationalization | Hellenic Shipping News Worldwide
      hellenicshippingnews.com · English
  - (2026-07-17) [China] WSC : ETS rightly reinvests more into maritime decarbonisation , but new port rules risk targeting competition rather than emissions
      hellenicshippingnews.com · English
  - (2026-07-17) [China] Fujairah Fuel Oil Inventories Rise Massively This Month | Hellenic Shipping News Worldwide
      hellenicshippingnews.com · English
  - (2026-07-17) [China] New BIMCO survey explores challenges and best practices in operational crewing and rest hour compliance
      hellenicshippingnews.com · English

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-17) [Marginal Revolution] Friday assorted links
      1. David Wallace-Wells on the status of reading (NYT). 2. Very good, very positive Kimi ad. 3. Balaji update. 4. An eighth-century Mayan mathematician. 5. Yet another balloon. 6. Nearby planet with helium-rich atmosphere…
  - (2026-07-17) [Marginal Revolution] Cataloging Growth: A Re-Evaluation of 1900–1990
      From Verónica Bäcker-Peral and Benjamin Wittenbrink of MIT: Measuring real GDP growth requires distinguishing changes in prices from changes in product quality and composition, yet systematic quality adjustment of price…
  - (2026-07-17) [Marginal Revolution] A Phone is a Cow
      Philip Auerswald’s A Phone is a Cow is three books in one, it’s a history of the mobile phone, it’s a business biography of Iqbal Quadir, who brought the cell phone to Bangladesh at at time when that seemed quixotic and…
  - (2026-07-17) [Conversable Economist] Is Progress Sustainable? Mokyr’s Nobel Lecture
      “Progress” is a word that often generates both a lot of positive vibes, and also a lot of pushback? Progress toward what? At what cost? So it’s perhaps useful to specify that when I refer to “progress,” I’m referring to…
  - (2026-07-15) [Conversable Economist] How Much Does Federal R&D Pay Off?
      How much does federally funded R&D benefit the economy? Sheila Campbell, Jaeger Nelson, Eli Schrag, Heidi Williams, and Caleb Wroblewski work through some ways of answering that question in “Estimating the Economic Effec…
  - (2026-07-13) [Conversable Economist] Interview with Joel Mokyr: Big Topics in Long-Run Growth
      Tyler Cowen serves as interlocutor in “Joel Mokyr on Clans, Corporations, and a Culture of Growth” (Conversations with Tyler, July 8, 2026). Mokyr (Nobel, ’25) has a genius for looking at broad trends, and then sorting o…

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### State Legislative Action — 1 new of 1 total
  - (2026-07-17) [ingest error] Alabama: ReadTimeout
      HTTPSConnectionPool(host='v3.openstates.org', port=443): Read timed out. (read timeout=45)

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-07-17) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo remains active, with sustained transmission driving increases in reported cases and deaths. As of 15 July 2026, a cumulative total of 21…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-17) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=24, 14d-median=24
- state_bills: today=1, 7d-median=1, 14d-median=1
- state_news: today=974, 7d-median=445, 14d-median=445
- local_news: today=248, 7d-median=236, 14d-median=236
- foreign_news: today=1080, 7d-median=1038, 14d-median=1038
- chinese_internal: today=318, 7d-median=276, 14d-median=276
- russian_internal: today=908, 7d-median=908, 14d-median=908
- ukrainian_internal: today=138, 7d-median=135, 14d-median=135
- ukraine_theater: today=400, 7d-median=400, 14d-median=400
- paper_bets: today=144, 7d-median=138, 14d-median=138
- weather: today=165, 7d-median=147, 14d-median=147
- macro: today=21, 7d-median=21, 14d-median=21
- markets: today=21, 7d-median=21, 14d-median=21
- markets_global: today=47, 7d-median=47, 14d-median=47
- sanctions_procurement: today=119, 7d-median=114, 14d-median=114
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=32, 14d-median=32
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=6, 7d-median=6, 14d-median=6
- gdelt_gkg: today=50, 7d-median=48, 14d-median=48
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=16, 7d-median=8, 14d-median=8
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=101, 7d-median=151, 14d-median=151
- usgs_quakes: today=28, 7d-median=12, 14d-median=12
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- tech_news: today=58, 7d-median=57, 14d-median=57
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*