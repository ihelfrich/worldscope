# WORLDSCOPE morning brief — 2026-07-17

## Headline
4680 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (938) · State-Level News (920) · Russian Internal News (state + in-exile) (902) · World leaders & government officials (324) · Chinese Internal News (320) · Ukraine Theater (total-war monitoring) (305) · Local News: St. Louis + Atlanta (249) · U.S. Weather + Severe / Climate Outlooks (196) · Ukrainian Internal News (national + local Kyiv) (130) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (58) · Government Action: Sanctions + Procurement + Foreign Agents (43)

## What changed today
### International News + Multilateral Institutions — 938 new of 1080 total
  - (2026-07-17) [Global] Top IRS lawyer to resign post amid disagreements with Trump administration
      Reports indicate a controversial settlement deal and disputes over tax audits may have prompted Ken Kies to step down.
  - (2026-07-17) [Global] Israel, Gaza and the future of US power
      Congressman Ro Khanna joins Sreenivasan Jain.
  - (2026-07-17) [Global] How an Italian sculptor created the iconic World Cup trophy
      In 1970, an Italian sculptor designed the iconic World Cup trophy that’s become familiar to generations of fans.
  - (2026-07-17) [Global] At least two dead as heavy rains, floods strike central Texas
      Officials in the southern state have seen new warning systems tested by the floods, after last year's deadly rainfall.
  - (2026-07-17) [Global] Will the Canadian wildfire smoke affect Spain vs Argentina World Cup final?
      World Cup organisers are monitoring the situation 'closely', with US and FIFA presidents meeting on Friday.
  - (2026-07-17) [Global] At least three killed and hundreds displaced by heavy rain in Chile
      Chilean President Jose Antonio Kast says that he is travelling to the Biobio region to survey flood damage.

### State-Level News — 920 new of 933 total
  - (2026-07-17) [Alabama] Governor Ivey Deploys Swiftwater Rescue Teams to Texas to Assist Amid Severe Flooding
      MONTGOMERY – Governor Kay Ivey on Friday announced she has deployed four Type III Swiftwater search-and-rescue teams to assist Texas with ongoing life-threatening flooding. “Alabamians always stand ready to lend a helpin…
  - (2026-07-16) [Alabama] Governor Ivey Continues Rebuilding Alabama with $3.6 Million in Road Grants
      MONTGOMERY – Governor Kay Ivey on Thursday announced more than $3.6 million in state funding is being awarded to cities and counties for 11 road projects across Alabama, highlighting her ongoing commitment to enhancing t…
  - (2026-07-15) [Alabama] Governor Ivey Taps Glenda Allred as New Tourism Director, Announces Lee Sentell’s Retirement
      MONTGOMERY – Governor Kay Ivey on Wednesday announced the retirement of Lee Sentell, Alabama’s longest-serving Tourism Director. Governor Bob Riley originally appointed Sentell in 2003. “Since Lee began serving at the De…
  - (2026-07-16) [Alaska] Alaska Launches America 250 Commemorative Merchandise Collection
      As the United States celebrates 250 years of independence, Governor Mike Dunleavy invites you to celebrate the milestone in true Alaska fashion. The State of Alaska has partnered to launch a limited-edition collection of…
  - (2026-07-16) [Alaska] Rural Transit Day 2026
      WHEREAS, Rural Transit Day has been celebrated since July 16, 2020, highlighting the ways in which agencies recognize and support the specialized needs of rural passengers and staff; and WHEREAS, as the reliance on rural…
  - (2026-07-17) [California] Governor Newsom announces California nearly triples internet infrastructure ready to connect homes and businesses
      Source

### Russian Internal News (state + in-exile) — 902 new of 905 total
  - (2026-07-17) Зеленский пообещал открыть архивы по Волынской резне | LEDE: Президент Украины Владимир Зеленский объявил о планах открыть архивы украинских спецслужб, посвященные Волынской резне. Об этом о] (ru: Зел…
      Президент Украины Владимир Зеленский объявил о планах открыть архивы украинских спецслужб, посвященные Волынской резне. Об этом он объявил по итогам совещания, посвященного отношениям с Польшей.
  - (2026-07-17) Россиян, задержанных в Стамбуле за чтение Библии в мечети Айя-София, отправили в Россию | LEDE: Двое граждан России, задержанные в соборе Айя-София в Стамбуле за чтение Библии, вечером 17 ию] (ru: Рос…
      Двое граждан России, задержанные в соборе Айя-София в Стамбуле за чтение Библии, вечером 17 июля вылетели в РФ. Об этом сообщает ТАСС со ссылкой на российское генконсульство.
  - (2026-07-17) В Киеве, Одессе, Львове и других городах Украины снова прошли протесты из-за смены министра обороны. Люди скандируют «Верните Федорова!» и «Долой Сырского!» | LEDE: Жители нескольких городов] (ru: В К…
      Жители нескольких городов Украины снова вышли на улицы на акции протеста против отставки Михаила Федорова с поста министра обороны. Об этом сообщают «Украинская правда» и «Суспiльне».
  - (2026-07-17) Правительство РФ предложило расширить список статей УК, осужденных по которым можно отправлять на войну | LEDE: Правительство России внесло в Госдуме законопроект, предлагающий расширить спи] (ru: Пра…
      Правительство России внесло в Госдуме законопроект, предлагающий расширить список статей Уголовного кодекса, обвиняемые и осужденные по которым могут заключать контракты с Минобороны РФ во время мобилизации, военного пол…
  - (2026-07-17) Провластного блогера Илью Ремесло отправили в СИЗО за посты с критикой Путина | LEDE: Басманный районный суд Москвы арестовал на два месяца провластного блогера и доносчика Илью Ремесло, кот] (ru: Про…
      Басманный районный суд Москвы арестовал на два месяца провластного блогера и доносчика Илью Ремесло, которого обвиняют в «фейках» про российскую армию по мотиву политической ненависти (пункт «д» части 2 статьи 207.3 УК).…
  - (2026-07-17) В реестр «нежелательных» организаций внесли несуществующее международное движение «Голос» | LEDE: Минюст России включил в реестр «нежелательных» организаций международное общественное движен] (ru: В р…
      Минюст России включил в реестр «нежелательных» организаций международное общественное движение «В Защиту прав избирателей „Голос“».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 320 new of 320 total
  - (2026-07-16) 日本一女护士涉嫌在患者输液管中混入粪便，致其死亡后被捕 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE05RVN2SDRMczZ1N0lrVHJJU3RWdjZxcXdUYnJ6YTlwWGRsaU1NOU9semt1aHlneS0ta003cFRLczk4V0M5cEI1b0tpY] (zh:…
      日本一女护士涉嫌在患者输液管中混入粪便，致其死亡后被捕 观察者
  - (2026-07-16) 警惕！“德国对华立场大转向” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE01VTlvNFdFc2xaOE83Yl91NTlEVzVhcXhLOExDSzE1enZPeVdKYnZ1YjB6ajA5UnF6Z0d5ZGl1ckhlN0JCclB3M0E1YnJtQ212SWRRWH] (zh:…
      警惕！“德国对华立场大转向” 观察者
  - (2026-07-16) 三地四馆、规模创纪录，WAIC 2026今日开幕 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5wSE95eVVKV2IxbHd4amRvSV9zVE4tVjFLTEw2VXV1MWY0eDBucVkyZVVZNkQ5MHJ0OTI2djlpQVQzSzFhWEgxZWFrSFZ0] (zh:…
      三地四馆、规模创纪录，WAIC 2026今日开幕 观察者
  - (2026-07-17) 懂王：东大希望我输掉20年大选，因为我向他们征收了关税，建立了世界上最强大的军队 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBZbGh5Vm4tV1ZIbDZ5V3dMSHFaWGhFM1d4anNiUHpReFZJMXlWMmZ2d1ZOSXd3NURWN09ScHE1WC1xR] (zh:…
      懂王：东大希望我输掉20年大选，因为我向他们征收了关税，建立了世界上最强大的军队 风闻
  - (2026-07-17) 星舰第13次飞行：在 T0 时刻中断发射！今日发射取消。空X股票随即暴跌6美元 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE56X3c3bk45V1JBX1dfaXM4X21mT0p3N1NTTmtTSXFDYVFzcFJ2YWtBS2VqeEUzSHI0NkxteERYX1BHN1] (zh:…
      星舰第13次飞行：在 T0 时刻中断发射！今日发射取消。空X股票随即暴跌6美元 风闻
  - (2026-07-17) 美国之音死而不僵 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBGVEpDRXYwMU9tdDNwcUZ5M1dVSzFwZkhaYUtWc2dyby0yQXpzRlVHa0JQQ0Q1RDhURWlUX1kwZWFPSDhIc2k0SXFISDVNSnpNbEV2bV8yYVhQ] (zh:…
      美国之音死而不僵 观察者

### Ukraine Theater (total-war monitoring) — 305 new of 400 total
  - (2026-07-17) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-16) [FIRMS] thermal anomaly 46.618, 32.688 (FRP 2.3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 2.3 MW
  - (2026-07-16) [FIRMS] thermal anomaly 46.616, 32.727 (FRP 0.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 0.85 MW
  - (2026-07-16) [FIRMS] thermal anomaly 46.389, 34.814 (FRP 1.17 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 1.17 MW
  - (2026-07-16) [FIRMS] thermal anomaly 46.465, 32.140 (FRP 0.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 0.73 MW
  - (2026-07-16) [FIRMS] thermal anomaly 46.123, 34.828 (FRP 1.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-16 2318Z, FRP 1.78 MW

### Local News: St. Louis + Atlanta — 249 new of 249 total
  - (2026-07-17) [St. Louis] Kris Miss Bake Shop opens in Lake Saint Louis
      Kristen Gassel remembers the moment she shed her first tear over her vegan and allergen-friendly baked goods brand, Kris Miss. A few years ago, a little boy and his mother approached her booth at the Lake Saint Louis Far…
  - (2026-07-17) [St. Louis] New Cardinal Glennon center will keep more moms and babies together after high-risk births
      For most families, childbirth is filled with firsts: the first cry, the first cuddle, the first hours spent getting to know a brand-new baby. But for parents facing a high-risk pregnancy or a newborn who needs intensive…
  - (2026-07-17) [St. Louis] Kirkwood City Council OKs upgrades for Public Works building, despite growing budget concerns
      The Kirkwood City Council is counting pennies like never before—the result of $116 million in debt and a $15.6 million Electric Department overspending scandal that sent electric rates soaring. Kirkwood’s newfound auster…
  - (2026-07-17) [St. Louis] Account Executive
      Help St. Louis businesses grow through one of the region’s most trusted media brands. SLM Media Group is looking for a driven, curious, and commercially minded Account Executive to help local businesses reach the St. Lou…
  - (2026-07-17) [St. Louis] What St. Louis restaurants are saying about the cyclospora outbreak
      Ask George: Have St. Louis restaurants made any adjustments following the cyclospora outbreak? It only took two words to briefly knock international politics out of the headlines: “explosive diarrhea.” Reports of a cyclo…
  - (2026-07-17) [St. Louis] The most anticipated restaurants in metro St. Louis
      Learn even more about these restaurants on the Arch Eats podcast. ELEVATION By. K. RENAProjected Opening: Late JulyThis forthcoming Grand Center destination is led by Korri King and backed by luxury beverage partners inc…

### U.S. Weather + Severe / Climate Outlooks — 196 new of 198 total
  - (2026-07-17) [Moderate] Special Weather Statement: Special Weather Statement issued July 17 at 5:12PM EDT by NWS Peachtree City GA
      At 512 PM EDT, a strong thunderstorm was near Fayetteville, moving southwest at 5 mph. HAZARD...Up to 40 mph wind, frequent cloud to ground lightning and heavy rain. SOURCE...Radar indicated. IMPACT...Expect minor damage…
  - (2026-07-17) [Moderate] Special Weather Statement: Special Weather Statement issued July 17 at 5:12PM EDT by NWS Tallahassee FL
      At 512 PM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Trenton to 7 miles south of Fowlers Bluff. Movement was northwest at 25 mph. HAZARD...Wind gusts up to 50 mph and pea size h…
  - (2026-07-17) [Moderate] Special Weather Statement: Special Weather Statement issued July 17 at 5:12PM EDT by NWS Jacksonville FL
      At 512 PM EDT, Doppler radar was tracking strong thunderstorms along a line extending from Trenton to near Chiefland. Movement was west at 5 mph. HAZARD...Wind gusts around 40 mph. SOURCE...Radar indicated. IMPACT...Gust…
  - (2026-07-17) [Moderate] Special Weather Statement: Special Weather Statement issued July 17 at 3:11PM MDT by NWS Albuquerque NM
      At 311 PM MDT, Doppler radar was tracking a strong thunderstorm near La Bajada, or 20 miles southwest of Santa Fe, moving south at 5 mph. HAZARD...Wind gusts up to 50 mph and half inch size hail. SOURCE...Radar indicated…
  - (2026-07-17) [Moderate] Special Weather Statement: Special Weather Statement issued July 17 at 5:11PM EDT by NWS Wilmington OH
      At 511 PM EDT, a strong thunderstorm was located over West Carrollton, moving northeast at 10 mph. HAZARD...Wind gusts up to 45 mph and very heavy rain. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tre…
  - (2026-07-17) [Moderate] Special Weather Statement: Special Weather Statement issued July 17 at 5:11PM EDT by NWS Northern Indiana
      At 511 PM EDT, Doppler radar was tracking a cluster of strong thunderstorms near Spencerville, or 7 miles west of Fort Shawnee, moving northeast at 35 mph. HAZARD...Winds in excess of 30 mph and torrential rainfall. SOUR…

### Ukrainian Internal News (national + local Kyiv) — 130 new of 138 total
  - (2026-07-17) Від початку доби на фронті відбулося 229 бойових зіткнень – Генштаб | LEDE: 229 бойових зіткнень відбулось на фронті з початку доби 17 липня і до 22:00.] (uk: Від початку доби на фронті відбулося 229…
      229 бойових зіткнень відбулось на фронті з початку доби 17 липня і до 22:00.
  - (2026-07-17) РФ знову атакувала судно під прапором Маршаллових Островів в порту Одещини: 4 постраждалих | LEDE: Російські війська ввечері 17 липня атакували цивільне судно під прапором Маршаллових Островів ] (uk:…
      Російські війська ввечері 17 липня атакували цивільне судно під прапором Маршаллових Островів на Одещині: четверо членів екіпажу постраждали.
  - (2026-07-17) ЗМІ: Адміністрація Трампа направляє до Ізраїлю додаткові літаки-заправники | LEDE: ] (uk: ЗМІ: Адміністрація Трампа направляє до Ізраїлю додаткові літаки-заправники)
  - (2026-07-17) Протестувальників закликають у суботу також виходити на мітинг: вимагають звільнити Сирського | LEDE: Ветеран Дмитро Козятинський, який скликав людей на мітинги проти відставки Михайла Федорова] (uk:…
      Ветеран Дмитро Козятинський, який скликав людей на мітинги проти відставки Михайла Федорова, закликає у суботу, 18 липня, теж вийти на протести з вимогою звільнити головнокомандувача ЗСУ Сирського.
  - (2026-07-17) У Києві завершили очищувальні роботи на озері Кирилівське після російського удару | LEDE: Рятувальники завершили збирати нафтопродукти з поверхні водойми на озері Кирилівське в Києві.] (uk: У Києві за…
      Рятувальники завершили збирати нафтопродукти з поверхні водойми на озері Кирилівське в Києві.
  - (2026-07-17) Росіяни ударним БпЛА атакували Чернігівщину: постраждала сім’я з трьома дітьми | LEDE: Російські війська ввечері 17 липня атакували Новгород-Сіверський на Чернігівщині.] (uk: Росіяни ударним БпЛА атак…
      Російські війська ввечері 17 липня атакували Новгород-Сіверський на Чернігівщині.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-17) U.S. Court of Appeals, D.C. Cir.: Clean Air Council v. EPA
  - (2026-07-17) U.S. Court of Appeals, D.C. Cir.: Rinat Akhmetshin v. William Browder
  - (2026-07-17) U.S. Court of Appeals, D.C. Cir.: United States v. Ahmed Abukhatallah
  - (2026-07-17) U.S. Court of Appeals, D.C. Cir.: United States v. Charles Littlejohn
  - (2026-07-17) U.S. Court of Appeals, D.C. Cir.: United States v. David Zobel
  - (2026-07-17) Arizona Supreme Court: REPUBLICAN NATL COMMITTEE v. FONTES

### IT, InfoSys & cybersecurity news (last 7 days) — 58 new of 58 total
  - (2026-07-17) [BleepingComputer] Abbott Laboratories probes two cyber incidents amid extortion claims
      Abbott Laboratories is investigating two separate cybersecurity incidents after confirming unauthorized access to internal legacy Exact Sciences systems in its Cancer Diagnostics business, while also investigating a sepa…
  - (2026-07-17) [BleepingComputer] HollowByte DDoS flaw bloats OpenSSL server memory with 11-byte payload
      A vulnerability dubbed HollowByte allows unauthenticated attackers to trigger a denial-of-service (DoS) condition on OpenSSL servers with a malicious payload of just 11 bytes. [...]
  - (2026-07-17) [BleepingComputer] Ernst & Young discloses data breach after support system hack
      Ernst & Young is notifying customers of a data breach caused by the compromise of a third-party support ticket system used by its IT personnel. [...]
  - (2026-07-17) [BleepingComputer] Inside the Search for "Clean" Residential Proxies for Carding
      Residential proxies are no longer the silver bullet they once were for carding. Flare explains why cybercriminals increasingly seek "clean" residential proxies and combine them with browser fingerprints, device profiles,…
  - (2026-07-17) [BleepingComputer] New Windows LegacyHive zero-day gives hackers admin privileges
      A security researcher using the "Nightmare Eclipse" handle has released a Windows zero-day exploit dubbed LegacyHive that allows attackers to escalate privileges on up-to-date Windows systems. [...]
  - (2026-07-17) [The Hacker News] OpenSSL HollowByte Flaw Could Freeze Server Memory with 11-Byte TLS Requests
      Eleven bytes will make an unpatched OpenSSL server set aside up to 131 KB of memory for a message that never arrives. On the glibc systems Okta tested, that memory is gone until the process restarts. OpenSSL shipped the…

### Government Action: Sanctions + Procurement + Foreign Agents — 43 new of 117 total
  - (2026-07-17) [OFAC] Hong Kong-related Designations Updates and Removals - Office of Foreign Assets Control (.gov)
      Hong Kong-related Designations Updates and Removals Office of Foreign Assets Control (.gov)
  - (2026-07-13) [OFAC] Cyber-related Designations; Cuba Designations; Issuance of Cuba-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Cyber-related Designations; Cuba Designations; Issuance of Cuba-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-07-15) [OFAC] Non-Proliferation Designations; Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Non-Proliferation Designations; Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-07-14) [OFAC] Iran-related Designations; Iran-related and Counter Terrorism Designation Update; Issuance of Iran-related General License - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Iran-related and Counter Terrorism Designation Update; Issuance of Iran-related General License Office of Foreign Assets Control (.gov)
  - (2026-07-14) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Sec - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Sec Office of Foreign Assets Control (.gov)
  - (2026-07-13) [OFAC] 1262 - Office of Foreign Assets Control (.gov)
      1262 Office of Foreign Assets Control (.gov)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-17) [Reikes Peter N] Form 4 (Reporting)
      filed 2026-07-17 21:13 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0000874015-26-000247 Size: 6 KB
  - (2026-07-17) [IONIS PHARMACEUTICALS INC] Form 4 (Issuer)
      filed 2026-07-17 21:13 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0000874015-26-000247 Size: 6 KB
  - (2026-07-17) [Veralto Corp] Form 4 (Issuer)
      filed 2026-07-17 21:13 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001292810-26-000002 Size: 10 KB
  - (2026-07-17) [FILLER LINDA] Form 4 (Reporting)
      filed 2026-07-17 21:13 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001292810-26-000002 Size: 10 KB
  - (2026-07-17) [HANTSON LUDWIG] Form 4 (Reporting)
      filed 2026-07-17 21:13 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0000874015-26-000246 Size: 5 KB
  - (2026-07-17) [IONIS PHARMACEUTICALS INC] Form 4 (Issuer)
      filed 2026-07-17 21:13 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0000874015-26-000246 Size: 5 KB

### Paper Trading Scorecard — 39 new of 137 total
  - (2026-07-17) [Polymarket] Will the Atlanta Braves win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-07-17) [Polymarket] Will Trump be in the WC Champions Photo?
      This market will resolve to “Yes” if Donald Trump is visibly in the frame for the winning team's official team photo following the 2026 FIFA World Cup Final. Otherwise, this market will resolve to “No”. If Trump does not…
  - (2026-07-17) [Polymarket] Will Kansas City Chiefs win the 2027 NFL AFC Championship?
      This market will resolve according to the team that wins the 2027 AFC championship game. If at any point it becomes impossible for a listed team to win the 2027 NFL AFC championship per the rules of the NFL (e.g., they a…
  - (2026-07-17) [Polymarket] Israel withdraws from Lebanon by December 31, 2026?
      This market will resolve to "Yes" if Israel announces it has withdrawn all ground forces from Lebanon by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No". For this market to resolve to "Yes" i…
  - (2026-07-17) [Polymarket] Will the Indianapolis Colts win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-17) [Polymarket] Will John Pardon win the 2026 Fields Medal?
      The Fields Medal is a prize regarded as the top award in the field of mathematics worldwide. It is awarded to two, three, or four mathematicians under 40 years of age at the International Congress of the International Ma…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDACS — global disaster alerts — 28 new of 57 total
  - (2026-07-16) [Orange] Eruption Mayon
      Volcano · Orange alert · Philippines
  - (2026-07-16) [Orange] Eruption Mayon
      Volcano · Orange alert · Philippines
  - (2026-07-12) [Orange] Forest fires in France
      Wildfire · Orange alert · France · Orange impact for forestfire in 2280 ha
  - (2026-07-12) [Orange] Forest fires in France
      Wildfire · Orange alert · France · Orange impact for forestfire in 2280 ha
  - (2026-07-11) [Green] Flood in Malaysia
      Flood · Green alert · Malaysia · Magnitude 0
  - (2026-07-11) [Green] Flood in Malaysia
      Flood · Green alert · Malaysia · Magnitude 0

### USGS earthquakes (M4.5+, past day) — 28 new of 28 total
  - (2026-07-17) M 7.3 - 58 km WSW of Puerto Madero, Mexico
      M7.3 · 58 km WSW of Puerto Madero, Mexico · depth 18.584 km · PAGER yellow
  - (2026-07-17) M 6.0 - 90 km SW of Puerto Madero, Mexico
      M6.0 · 90 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-17) M 5.3 - 93 km SW of Puerto Madero, Mexico
      M5.3 · 93 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-17) M 5.3 - 203 km N of Hadibu, Yemen
      M5.3 · 203 km N of Hadibu, Yemen · depth 10 km
  - (2026-07-17) M 5.2 - 67 km SW of Puerto Madero, Mexico
      M5.2 · 67 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-17) M 5.2 - 11 km SE of Kiupo, Philippines
      M5.2 · 11 km SE of Kiupo, Philippines · depth 79.819 km

### U.S. Federal Action — 17 new of 17 total
  - (2026-07-17) Modifying the Grand Staircase-Escalante National Monument
  - (2026-07-17) Modifying the Bears Ears National Monument
  - (2026-07-17) Death of Senator Lindsey Graham
  - (2026-07-17) Fisheries of the Exclusive Economic Zone off Alaska; Amendment 129 to the Fishery Management Plan for Groundfish of the Bering Sea and Aleutian Islands Management Area; Amendment 58 to the Fishery Man…
      The North Pacific Fishery Management Council (Council) submitted amendment 129 to the Fishery Management Plans for Groundfish of the Bering Sea and Aleutian Islands Management Area (BSAI FMP) and amendment 58 to the Fish…
  - (2026-07-17) Airworthiness Directives; Diamond Aircraft Industries GmbH
      The FAA is adopting a new airworthiness directive (AD) for all Diamond Aircraft Industries GmbH (DAI) Model DA 42, DA 42 NG, and DA 42 M-NG airplanes. This AD was prompted by occurrences of uncommanded rudder deflection…
  - (2026-07-17) Margin Requirements for Uncleared Swaps for Swap Dealers and Major Swap Participants
      The Commodity Futures Trading Commission ("Commission") is amending the margin requirements for uncleared swaps applicable to swap dealers and major swap participants that are not subject to the margin rules of a prudent…

### CISA Known Exploited Vulnerabilities (last 14d) — 16 new of 16 total
  - (2026-07-16) CVE-2026-58644 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-19
  - (2026-07-16) CVE-2026-25089 · Fortinet FortiSandbox: Fortinet FortiSandbox OS Command Injection Vulnerability
      vendor: Fortinet · product: FortiSandbox · CISA remediation by 2026-07-19
  - (2026-07-16) CVE-2026-39808 · Fortinet FortiSandbox: Fortinet FortiSandbox OS Command Injection Vulnerability
      vendor: Fortinet · product: FortiSandbox · CISA remediation by 2026-07-19
  - (2026-07-15) CVE-2026-46817 · Oracle E-Business Suite: Oracle E-Business Suite Improper Privilege Management Vulnerability
      vendor: Oracle · product: E-Business Suite · CISA remediation by 2026-07-18
  - (2026-07-15) CVE-2023-4346 · KNX Association KNX Protocol Connection Authorization Option 1: KNX Association KNX Protocol Connection Authorization Option 1 Overly Restrictive Account Lockout Mechanism Vulnerabilit…
      vendor: KNX Association · product: KNX Protocol Connection Authorization Option 1 · CISA remediation by 2026-07-29
  - (2026-07-14) CVE-2026-56155 · Microsoft Active Directory Federation Services: Microsoft Active Directory Federation Services Insufficient Granularity of Access Control Vulnerability
      vendor: Microsoft · product: Active Directory Federation Services · CISA remediation by 2026-07-28

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-07-17) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $5,084,896 · resolves 2026-06-01
  - (2026-07-17) Will Belete Molla be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $4,787,001 · resolves 2026-06-01
  - (2026-07-17) Exact Score: Spain 2 - 3 Argentina?
      yes price: 3% · 24h volume: $1,588,126 · resolves 2026-07-19
  - (2026-07-17) France vs. England: Team to Win
      yes price: 66% · 24h volume: $1,347,190 · resolves 2026-07-18
  - (2026-07-17) Will France win on 2026-07-18?
      yes price: 50% · 24h volume: $1,055,574 · resolves 2026-07-18
  - (2026-07-17) Tampa Bay Rays vs. Boston Red Sox
      yes price: 0% · 24h volume: $918,376 · resolves 2026-05-16

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 40 total
  - (2026-07-17) MOVER ▼ Elon Musk — $797.59B ($-201.79B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-07-17) MOVER ▼ Larry Ellison — $167.04B ($-21.45B since yesterday)
      United States · Technology · source: Oracle
  - (2026-07-17) MOVER ▲ Mark Zuckerberg — $221.57B (+$15.50B since yesterday)
      United States · Technology · source: Facebook
  - (2026-07-17) MOVER ▼ Larry Page — $284.33B ($-15.04B since yesterday)
      United States · Technology · source: Google
  - (2026-07-17) MOVER ▼ Sergey Brin — $262.28B ($-13.83B since yesterday)
      United States · Technology · source: Google
  - (2026-07-17) MOVER ▼ Warren Buffett — $139.33B ($-10.03B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-17) [Marginal Revolution] Friday assorted links
      1. David Wallace-Wells on the status of reading (NYT). 2. Very good, very positive Kimi ad. 3. Balaji update. 4. An eighth-century Mayan mathematician. 5. Yet another balloon. 6. Nearby planet with helium-rich atmosphere…
  - (2026-07-17) [Marginal Revolution] Cataloging Growth: A Re-Evaluation of 1900–1990
      From Verónica Bäcker-Peral and Benjamin Wittenbrink of MIT: Measuring real GDP growth requires distinguishing changes in prices from changes in product quality and composition, yet systematic quality adjustment of price…
  - (2026-07-17) [Marginal Revolution] A Phone is a Cow
      Philip Auerswald’s A Phone is a Cow is three books in one, it’s a history of the mobile phone, it’s a business biography of Iqbal Quadir, who brought the cell phone to Bangladesh at at time when that seemed quixotic and…
  - (2026-07-17) [Conversable Economist] Is Progress Sustainable? Mokyr’s Nobel Lecture
      “Progress” is a word that often generates both a lot of positive vibes, and also a lot of pushback? Progress toward what? At what cost? So it’s perhaps useful to specify that when I refer to “progress,” I’m referring to…
  - (2026-07-15) [Conversable Economist] How Much Does Federal R&D Pay Off?
      How much does federally funded R&D benefit the economy? Sheila Campbell, Jaeger Nelson, Eli Schrag, Heidi Williams, and Caleb Wroblewski work through some ways of answering that question in “Estimating the Economic Effec…
  - (2026-07-13) [Conversable Economist] Interview with Joel Mokyr: Big Topics in Long-Run Growth
      Tyler Cowen serves as interlocutor in “Joel Mokyr on Clans, Corporations, and a Culture of Growth” (Conversations with Tyler, July 8, 2026). Mokyr (Nobel, ’25) has a genius for looking at broad trends, and then sorting o…

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-07-17) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo remains active, with sustained transmission driving increases in reported cases and deaths. As of 15 July 2026, a cumulative total of 21…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-17) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=24, 14d-median=24
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=933, 7d-median=445, 14d-median=445
- local_news: today=249, 7d-median=236, 14d-median=236
- foreign_news: today=1080, 7d-median=1038, 14d-median=1038
- chinese_internal: today=320, 7d-median=276, 14d-median=276
- russian_internal: today=905, 7d-median=905, 14d-median=905
- ukrainian_internal: today=138, 7d-median=135, 14d-median=135
- ukraine_theater: today=400, 7d-median=400, 14d-median=400
- paper_bets: today=137, 7d-median=137, 14d-median=137
- weather: today=198, 7d-median=147, 14d-median=147
- macro: today=21, 7d-median=21, 14d-median=21
- markets: today=21, 7d-median=21, 14d-median=21
- markets_global: today=47, 7d-median=47, 14d-median=47
- sanctions_procurement: today=117, 7d-median=114, 14d-median=114
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=0, 7d-median=9, 14d-median=9
- gdelt_gkg: today=0, 7d-median=36, 14d-median=36
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=16, 7d-median=8, 14d-median=8
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=57, 7d-median=151, 14d-median=151
- usgs_quakes: today=28, 7d-median=12, 14d-median=12
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- tech_news: today=58, 7d-median=57, 14d-median=57
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*