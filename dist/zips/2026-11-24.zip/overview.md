# WORLDSCOPE morning brief — 2026-11-24

## Headline
3684 new items across 29 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (863) · Russian Internal News (state + in-exile) (729) · State-Level News (358) · World leaders & government officials (324) · Chinese Internal News (236) · Local News: St. Louis + Atlanta (207) · U.S. Weather + Severe / Climate Outlooks (140) · Ukraine Theater (total-war monitoring) (139) · GDELT GKG — themes / entities / watch areas (139) · World News (by country, top stories) (103) · Ukrainian Internal News (national + local Kyiv) (71) · GDACS — global disaster alerts (47)

## What changed today
### International News + Multilateral Institutions — 863 new of 1024 total
  - (2026-11-23) [Global] Ukraine confirms it used naval drones to strike two Russian ships off Libya
  - (2026-11-23) [Global] Butt of the joke: Trump impersonator mocks president at Canada press dinner
  - (2026-11-23) [Global] Barbados town’s three-year deal with Bristol ‘part of the reparative process’
  - (2026-11-23) [Global] Trump administration deported US citizen to Mexico, DoJ admits in court
  - (2026-11-24) [Global] Malaysia to send thousands of migrants back to Myanmar as PM acknowledges junta’s ‘atrocities’
  - (2026-11-24) [Global] South Korea tells island residents to take shelter after Russian military aircraft approach

### Russian Internal News (state + in-exile) — 729 new of 943 total
  - (2026-11-24) В российских дронах, атаковавших Украину, нашли литовские сим-карты | LEDE: В российских беспилотниках, атаковавших Украину в 2025 году, обнаружили литовские предоплаченные сим-карты. Об это] (ru: В р…
      В российских беспилотниках, атаковавших Украину в 2025 году, обнаружили литовские предоплаченные сим-карты. Об этом сообщило литовское издание 15min со ссылкой на данные украинской военной разведки (материал находится в…
  - (2026-11-24) Сын главы Чечни Али Кадыров получил гражданство Сербии | LEDE: Власти Сербии выдали гражданство страны Али Кадырову — второму сыну главы Чечни Рамзану Кадырову. Решение об этом в «Государств] (ru: Сын…
      Власти Сербии выдали гражданство страны Али Кадырову — второму сыну главы Чечни Рамзану Кадырову. Решение об этом в «Государственном вестнике Сербии» обнаружил Фонд борьбы с коррупцией.
  - (2026-11-24) Вот это да: Дженсен Хуанг — снова глава Nvidia. Как все сразу и подумали, в его возвращении лично поучаствовал Трамп. Биржи и сотрудники в восторге. В конгрессе решение вернуть Хуанга назвали «] (ru:…
      Совет директоров Nvidia 23 ноября восстановил Дженсена Хуанга в должности гендиректора и президента компании. За 11 дней до этого Хуанг был отстранен от руководства компанией после того, как стало известно о его внебрачн…
  - (2026-11-24) В реестре Минюста появилась отметка о прекращении статуса адвоката Калоя Ахильгова. Он защищал «Фонд Ройзмана», Алексея Венедиктова и Артемия Лебедева | LEDE: В Едином государственном реестр] (ru: В р…
      В Едином государственном реестре адвокатов, который ведет министерство юстиции РФ, статус адвоката Калоя Ахильгова отмечен как «прекращен». На это обратило внимание издание Sotavision.
  - (2026-11-24) Жизель Пелико подаст в суд на французское издательство. Оно использовало ее обнаженные фотографии для продвижения книги | LEDE: Жизель Пелико, ставшая символом сопротивления сексуализированн] (ru: Жиз…
      Жизель Пелико, ставшая символом сопротивления сексуализированному насилию, планирует подать в суд на издательство Tinbad, которое использовало для продвижения одной из книг ее обнаженные фотографии, сообщает Le Monde.
  - (2026-11-24) В Госдуме подготовили законопроект о квотах для зарубежного кино. Он предполагает периоды полного запрета иностранных фильмов в кинотеатрах | LEDE: В Госдуме подготовили законопроект о «квот] (ru: В Г…
      В Госдуме подготовили законопроект о «квотировании иностранного кино», сообщает ТАСС, в распоряжении которого есть текст документа. Кто именно разработал документ, не уточняется.

### State-Level News — 358 new of 431 total
  - (2026-11-23) [Alabama] Governor Ivey Encourages Alabamians to Shop and Dine Local on Small Business Saturday
      MONTGOMERY – Governor Kay Ivey on Monday encouraged Alabamians to shop and dine locally on Saturday, November 28, as they make plans for Thanksgiving weekend and the Iron Bowl. Alabama’s more than 465,000 small businesse…
  - (2026-11-23) [California] California sues to block Trump rule denying aid to families with mixed immigration statuses
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/022326_For-Sale-Rent-LV_CM_06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-11-23) [California] Miles de familias californianas con estatus migratorio mixto perderán sus viviendas bajo nueva norma del gobierno de Trump
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/112026-Housing-File-LA-PU-CM-04.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-11-23) [California] California confirmó 60 casos de sarampión este año, más que en los dos años anteriores juntos
      <img width="1024" height="705" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/112026-Measles-Vaccine-JS-GETTY-CM-01.jpg?fit=1024%2C705&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-11-23) [California] El Niño ya está aquí. El programa piloto de seguros contra inundaciones de esta ciudad era un modelo estatal, pero acabó en fracaso
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/04/040125_Isleton-Delta_MG_CM_07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-11-23) [California] Measles is spreading in the U.S. What it means for California
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/02/022626_Measles_AD_CM_32.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="A…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 236 new of 289 total
  - (2026-11-23) China’s Fiscal Revenue Returns to Growth, but Spending Remains Weak - Caixin Global
      China’s Fiscal Revenue Returns to Growth, but Spending Remains Weak Caixin Global
  - (2026-11-24) CX Daily: Jensen Huang’s Exit Tests Nvidia — and the AI Boom - Caixin Global
      CX Daily: Jensen Huang’s Exit Tests Nvidia — and the AI Boom Caixin Global
  - (2026-11-23) In Depth: Shooting Coach’s Appeal Asks if China’s Gun Controls Go Too Far - Caixin Global
      In Depth: Shooting Coach’s Appeal Asks if China’s Gun Controls Go Too Far Caixin Global
  - (2026-11-24) Trump Praises Nvidia Chief’s Return - Caixin Global
      Trump Praises Nvidia Chief’s Return Caixin Global
  - (2026-11-23) Germany, Austria Propose Putting TikTok Under European Ownership - Caixin Global
      Germany, Austria Propose Putting TikTok Under European Ownership Caixin Global
  - (2026-11-23) Dutch Court Rules in Favor of Jaguar Land Rover in Design Dispute With BYD - Caixin Global
      Dutch Court Rules in Favor of Jaguar Land Rover in Design Dispute With BYD Caixin Global

### Local News: St. Louis + Atlanta — 207 new of 221 total
  - (2026-11-24) [St. Louis] Pope Francis' private diary details a profound spiritual crisis and encounters with the devil
      The Vatican is releasing excerpts of Pope Francis' private diary, publishing in several languages around the world.
  - (2026-11-24) [St. Louis] 86-year-old 'Cradle Lady' builds 105 wooden cradles for Colorado Santa Claus Shop
      Lillian Glasgow, known as the "Cradle Lady," has dedicated 54 years to crafting wooden cradles for the Denver Santa Claus Shop.
  - (2026-11-24) [St. Louis] Teen and adult sister killed in Midtown St. Louis shooting; 15-year-old injured
      A 14-year-old boy and his 27-year-old sister died and a 15-year-old was critically injured in a shooting Sunday in Midtown. Police took a 17-year-old into custody.
  - (2026-11-24) [St. Louis] St. Charles County approves grant for new license plate readers; data regulation bill delayed
      St. Charles County Council okays funding for five new license plate readers amid public outcry over privacy issues, delaying a decision on data policy regulations.
  - (2026-11-24) [St. Louis] SEC plans to vote on whether to terminate LSU's membership
      The Southeastern Conference is planning to vote on whether to remove LSU from its membership amid an ongoing federal lawsuit against the school.
  - (2026-11-24) [St. Louis] Lights go out briefly at Northwest Stadium during 3rd quarter of Bengals-Commanders game
      The lights at Northwest Stadium went out during Monday’s game between the Cincinnati Bengals and the Washington Commanders, leading to a delay.

### U.S. Weather + Severe / Climate Outlooks — 140 new of 142 total
  - (2026-11-24) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-24) [Moderate] Special Weather Statement: Special Weather Statement issued November 24 at 4:09AM CST by NWS Amarillo TX
      Bands of moderate snow will impact portions of Gray and Donley counties through around 8 AM. These snow bands will be capable of reducing visibility to around 1 mile and lead to a quick snow accumulation on grass, elevat…
  - (2026-11-24) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 24 at 2:04AM PST until November 24 at 10:00AM PST by NWS Hanford CA
      * WHAT...Widespread High Risk for Transportation as visibility of one half to one quarter mile or less in dense fog will be observed. * WHERE...The San Joaquin Valley. * WHEN...Until 10 AM PST this morning. * IMPACTS...L…
  - (2026-11-24) [Moderate] Coastal Flood Watch: Coastal Flood Watch issued November 24 at 4:49AM EST until November 27 at 3:00AM EST by NWS Mount Holly NJ
      * WHAT...Two to three feet of inundation above ground level possible in low-lying areas near shorelines and tidal waterways. * WHERE...Atlantic, Cape May, Atlantic Coastal Cape May, Coastal Atlantic and Southeastern Burl…
  - (2026-11-24) [Moderate] Coastal Flood Watch: Coastal Flood Watch issued November 24 at 4:49AM EST until November 27 at 3:00PM EST by NWS Mount Holly NJ
      * WHAT...One to two feet of inundation above ground level possible in low-lying areas near shorelines and tidal waterways. * WHERE...Ocean and Coastal Ocean. * WHEN...From Thursday morning through Friday afternoon. * IMP…
  - (2026-11-24) [Moderate] Coastal Flood Watch: Coastal Flood Watch issued November 24 at 4:49AM EST until November 27 at 3:00AM EST by NWS Mount Holly NJ
      * WHAT...One to two feet of inundation above ground level possible in low-lying areas near shorelines and tidal waterways. * WHERE...In Delaware, Kent. In New Jersey, Cumberland. * WHEN...From Thursday morning through la…

### Ukraine Theater (total-war monitoring) — 139 new of 324 total
  - (2026-11-24) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-23) [Liveuamap] Poland&039;s Armed Forces… – Chełm, Polska - Liveuamap
      Poland&039;s Armed Forces… – Chełm, Polska Liveuamap
  - (2026-11-22) [Liveuamap] New satellite imagery… – Benghazi, Libya - Liveuamap
      New satellite imagery… – Benghazi, Libya Liveuamap
  - (2026-11-22) [Liveuamap] Reuters: Ten people, including Russians and Libyans, suffer minor injuries in attack on Russian vessel in Benghazi - Liveuamap
      Reuters: Ten people, including Russians and Libyans, suffer minor injuries in attack on Russian vessel in Benghazi
  - (2026-11-21) [Liveuamap] Number of wounded as result of Russian strikes in Kryvyi Rih had increased to 60 – Kryvyi Rih, Dnipropetrovsk Oblast - Liveuamap
      Number of wounded as result of Russian strikes in Kryvyi Rih had increased to 60 – Kryvyi Rih, Dnipropetrovsk Oblast &nbs
  - (2026-11-23) [Liveuamap] Yemeni Armed Forces say 122 Houthi militia leaders and members have been neutralized. - Liveuamap
      Yemeni Armed Forces say 122 Houthi militia leaders and members have been neutralized. <font color="#6f6f6f

### GDELT GKG — themes / entities / watch areas — 139 new of 139 total
  - (2026-11-24) [Russia oil sanctions perimeter · themes] Inside the Ukrainian attack that sank Russian warship docked in Libya
      livemint.com · English · tone -3.28102710413695
  - (2026-11-24) [Russia oil sanctions perimeter · near] Ukraine says Russian strike on southeast city kills two, wounds dozens
      timesofmalta.com · English · tone -9.80392156862745 · 13 other outlets
  - (2026-11-24) [Russia oil sanctions perimeter · near] Russia warns of 'preventive nuclear attack' as Medvedev claims Ukraine, NATO crossed line
      nypost.com · English · tone -5.80204778156997 · 9 other outlets
  - (2026-11-24) [Russia oil sanctions perimeter · near] Hegseth Stalls Delivery Of 60 Patriot Interceptors Bought By Ukraine's Allies As Russian Strikes Intensify - Report
      i24news.tv · English · tone -1.98675496688742 · 9 other outlets
  - (2026-11-24) [Russia oil sanctions perimeter · near] Russian warship hit by Ukrainian drones in Libya, Zelensky says
      thechronicle.com.gh · English · tone -4.85074626865672 · 6 other outlets
  - (2026-11-24) [Russia oil sanctions perimeter · near] EU demands immediate Ukraine ceasefire at UNSC - News Today
      newstodaynet.com · English · tone -2.97029702970297 · 4 other outlets

### World News (by country, top stories) — 103 new of 103 total
  - (2026-11-24) [Brazil] Serengeti Boys face Brazil in tough WC test
      dailynews.co.tz · English
  - (2026-11-24) [Brazil] Pulp mill in Brazil halted following recovery boiler explosion
      pulpapernews.com · English
  - (2026-11-24) [Brazil] Latin America Mood: Brazil's Fiscal Vote, Chile's Strain
      riotimesonline.com · English
  - (2026-11-24) [Brazil] Brazilian Court orders arrest of Corazul's Buenavista over dispute
      travelextra.ie · English
  - (2026-11-24) [Canada] Pentagon sharply rebukes Canada over defense spending and the F-35 fighter jet review
      clickondetroit.com · English · 24 other outlets ran this story
  - (2026-11-24) [Canada] Canada's Military Readiness Depends on Strong Reserve and Cadet Programs
      theepochtimes.com · English · 6 other outlets ran this story

### Ukrainian Internal News (national + local Kyiv) — 71 new of 115 total
  - (2026-11-24) З Молдови екстрадували офіцера, якого підозрюють у знущаннях над військовими | LEDE: З Молдови в Україну екстрадували старшого лейтенанта ЗСУ Владислава Пастуха, якого підозрюють у систематично] (uk:…
      З Молдови в Україну екстрадували старшого лейтенанта ЗСУ Владислава Пастуха, якого підозрюють у систематичному катуванні підлеглих під час будівництва фортифікаційних споруд.
  - (2026-11-24) Справа про "відкати" у Полтаві: НАБУ і САП оголосили підозру 11-му фігуранту | LEDE: Національне антикорупційне бюро та Спеціалізована антикорупційна прокуратура повідомили про підозру ще одном] (uk:…
      Національне антикорупційне бюро та Спеціалізована антикорупційна прокуратура повідомили про підозру ще одному посадовцю Полтавської міської ради у справі щодо схеми систематичного вимагання "відкатів" від підрядників. За…
  - (2026-11-24) Опитування: блок Туска здатний перемогти коаліцію правих сил | LEDE: Якби на парламентських виборах у Польщі партії виступили у складі двох блоків – лівоцентристського на чолі з "Громадянською ] (uk:…
      Якби на парламентських виборах у Польщі партії виступили у складі двох блоків – лівоцентристського на чолі з "Громадянською коаліцією" та правого, до якого увійшли б "Право і справедливість" і "Конфедерації", – переміг б…
  - (2026-11-24) Росіяни атакували Запоріжжя FPV-дроном: поранено жінку | LEDE: Російські окупаційні війська атакували Запоріжжя безпілотником: поранено жінку, вона у тяжкому стані.] (uk: Росіяни атакували Запоріжжя F…
      Російські окупаційні війська атакували Запоріжжя безпілотником: поранено жінку, вона у тяжкому стані.
  - (2026-11-24) Молдова готується приєднатися до секторальних санкцій ЄС проти Росії та Білорусі | LEDE: В уряді Молдови до кінця січня 2027 року планують розробити дорожню карту щодо приєднання до секторальни] (uk:…
      В уряді Молдови до кінця січня 2027 року планують розробити дорожню карту щодо приєднання до секторальних санкцій Євросоюзу проти РФ і Білорусі.
  - (2026-11-24) Присвоєння Вікторії Рощиній ордена "Золота зірка" — це вимога справедливості та державної гідності | LEDE: Громадськість та Верховна Рада закликають Президента надати Вікторії Рощиній звання Ге] (uk:…
      Громадськість та Верховна Рада закликають Президента надати Вікторії Рощиній звання Героя України за її подвиг і жертовність.

### GDACS — global disaster alerts — 47 new of 100 total
  - (2026-10-24) [Green] Flood in Indonesia
      Flood · Green alert · Indonesia · Magnitude 0
  - (2026-11-24) [Green] Tropical Cyclone 03-20262027-27
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 63 km/h)
  - (2026-11-24) [Green] Earthquake in Panama
      Earthquake · Green alert · Panama · Magnitude 4.5M, Depth:15.655km
  - (2026-11-24) [Green] Earthquake in Nepal
      Earthquake · Green alert · Nepal · Magnitude 5.3M, Depth:10km
  - (2026-11-22) [Green] Flood in Ireland
      Flood · Green alert · Ireland · Magnitude 0
  - (2026-11-22) [Green] Flood in Thailand
      Flood · Green alert · Thailand · Magnitude 0

### IT, InfoSys & cybersecurity news (last 7 days) — 46 new of 63 total
  - (2026-11-24) [The Hacker News] WHMCS SQL Injection Could Expose Customer Data and Admin Password Hashes without Login
      A flaw in WHMCS's shopping cart, the billing and automation platform many web hosting companies use to run their businesses, could allow anyone on the internet to retrieve customer records and administrator password hash…
  - (2026-11-24) [The Hacker News] OpenAI and Cisco Unveil AI-Assisted Linux Security Tool to Block Exploits Before Patching
      OpenAI and Cisco have teamed up to launch Shirudo (meaning "shield" in Japanese), an open-source Linux runtime that allows artificial intelligence (AI) agents to defend systems without downtime. "It lets agents write dyn…
  - (2026-11-24) [The Hacker News] Hackers Exploit N-able MailAssure Flaw While AI Agents Exploit MONAI Label Zero-Day
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Monday added two flaws impacting N-able MailAssure and MONAI Label to its Known Exploited Vulnerabilities (KEV) catalog, citing evidence of active explo…
  - (2026-11-24) [The Record] LaLiga hacked: Spain’s top football league confirms theft of fans’ personal data
      Spain’s professional soccer league LaLiga said Monday hackers stole personal information belonging to fans in a cyberattack affecting its digital services and those of several Spanish clubs.
  - (2026-11-24) [The Record] ‘Grand Theft Auto VI’ hacker sentenced to seven years, released the same day
      A British cybercriminal who hacked Rockstar Games and leaked footage of Grand Theft Auto VI was sentenced Monday to seven years in prison, and then released on license because of time served.
  - (2026-11-24) [The Record] Hackers breach Austrian Foreign Ministry website, access diplomats' contact details
      Austria's Foreign Ministry said late last week that hackers breached one of its websites and accessed the names and official contact information of employees at its Vienna headquarters and at Austria’s diplomatic mission…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-24) [Smith Jada] Form 4 (Reporting)
      filed 2026-11-24 02:52 UTC · role: Reporting — Filed: 2026-11-23 AccNo: 0001493152-26-053869 Size: 5 KB
  - (2026-11-24) [MICROVISION, INC.] Form 4 (Issuer)
      filed 2026-11-24 02:52 UTC · role: Issuer — Filed: 2026-11-23 AccNo: 0001493152-26-053869 Size: 5 KB
  - (2026-11-24) [Klein Frank] Form 4 (Reporting)
      filed 2026-11-24 02:52 UTC · role: Reporting — Filed: 2026-11-23 AccNo: 0001628280-26-075601 Size: 4 KB
  - (2026-11-24) [Proto Labs Inc] Form 4 (Issuer)
      filed 2026-11-24 02:52 UTC · role: Issuer — Filed: 2026-11-23 AccNo: 0001628280-26-075601 Size: 4 KB
  - (2026-11-24) [Wentz George R. Jr.] Form 4 (Reporting)
      filed 2026-11-24 02:51 UTC · role: Reporting — Filed: 2026-11-23 AccNo: 0001213900-26-123347 Size: 12 KB
  - (2026-11-24) [Fermi Inc.] Form 4 (Issuer)
      filed 2026-11-24 02:51 UTC · role: Issuer — Filed: 2026-11-23 AccNo: 0001213900-26-123347 Size: 12 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-24) [United Kingdom] One in eight vapes seized by police at schools contained drugs
      domain: hulldailymail.co.uk · language: English · tone: -3.65535248041775 · 66 other outlets ran this story
  - (2026-11-24) [Bangladesh] Sheikh Hasina requests December 16 return, picks Bangladesh Victory Day for comeback
      domain: indiatimes.com · language: English · tone: -6.22775800711744 · 63 other outlets ran this story
  - (2026-11-24) Review will recommend changes to 'rehumanise' disability benefit, says minister
      domain: romfordrecorder.co.uk · language: English · tone: 1.01237345331833 · 56 other outlets ran this story
  - (2026-11-24) [United Kingdom] Man to run five ultramarathons in five days from Aviemore to Glasgow for charity
      domain: cambstimes.co.uk · language: English · tone: -1.20689655172414 · 54 other outlets ran this story
  - (2026-11-24) [United States] Federal appeals court gives President Donald Trump a path to erasing hush money conviction
      domain: mymotherlode.com · language: English · tone: -4.52322738386308 · 54 other outlets ran this story
  - (2026-11-24) [United States] Jensen Huang's comeback to Nvidia underscores his outsized grip on AI
      domain: bdnews24.com · language: English · tone: -0.452488687782806 · 47 other outlets ran this story

### State Legislative Action — 31 new of 31 total
  - (2026-11-23) [Alaska HB 321] An Act relating to state refuges, sanctuaries, and fish and game critical habitat areas; relating to the hunting of brown bear; and providing for an effective date.
      An Act relating to state refuges, sanctuaries, and fish and game critical habitat areas; relating to the hunting of brown bear; and providing for an effective date.
  - (2026-11-23) [Connecticut SB 83] AN ACT ESTABLISHING THE FEDERAL CUTS RESPONSE FUND.
      AN ACT ESTABLISHING THE FEDERAL CUTS RESPONSE FUND.
  - (2026-11-23) [Connecticut SJ 36] RESOLUTION CONFIRMING THE NOMINATION OF DONALD E. WILLIAMS, JR. OF BROOKLYN TO BE A MEMBER OF THE BOARD OF REGENTS FOR HIGHER EDUCATION.
      RESOLUTION CONFIRMING THE NOMINATION OF DONALD E. WILLIAMS, JR. OF BROOKLYN TO BE A MEMBER OF THE BOARD OF REGENTS FOR HIGHER EDUCATION.
  - (2026-11-24) [District of Columbia B 26-0861] Dupont Underground and Anacostia Boathouse Lease Extension Authority Act of 2026
      Dupont Underground and Anacostia Boathouse Lease Extension Authority Act of 2026
  - (2026-11-24) [District of Columbia B 26-0530] St. Elizabeths East Parcel 6 Surplus Declaration and Disposition Approval Act of 2025
      St. Elizabeths East Parcel 6 Surplus Declaration and Disposition Approval Act of 2025
  - (2026-11-24) [District of Columbia B 26-0829] Shared Housing Agreements and Resolution Effort Pilot Program Amendment Act of 2026
      Shared Housing Agreements and Resolution Effort Pilot Program Amendment Act of 2026

### Wikidata leader-roster changes (48h) — 31 new of 73 total
  - (2026-11-24) [Liechtenstein] Hans-Adam II, Prince of Liechtenstein (Q57454) edited
      /* wbeditentity-statements-multiple-properties-update:0||5 */ source for date of birth, source for father, source for mother, source for sibling, source for spouse from the Historisches Lexikon des Fürstentums Liechtenst…
  - (2026-11-24) [Honduras] Nasry Asfura (Q16146159) edited
      /* wbeditentity-statements-single-property-update:1||2 */ [[Property:P1449]]
  - (2026-11-24) [Mexico] Q5771800 (Q5771800) edited
      /* wbsetsitelink-add:1|ukwikiquote */ Клаудія Шейнбаум
  - (2026-11-24) [Djibouti] Abdoulkader Kamil Mohamed (Q10522744) edited
      /* clientsitelink-update:0|trwiki|trwiki:Abdulkadir Kamil Muhammed|trwiki:Abdülkadir Kamil Muhammed */
  - (2026-11-24) [Czech Republic] Andrej Babiš (Q10819807) edited
      /* wbeditentity-statements-multiple-properties-update:0||2 */ source for date of birth, source for place of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])
  - (2026-11-24) [Croatia] Andrej Plenković (Q11685764) edited
      /* wbsetclaim-update-references:1||1|1 */ [[Property:P569]]: 8 April 1970, source for date of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 24 new of 81 total
  - (2026-11-24) [Polymarket] Will S&P 500 (SPX) hit $6,200 (LOW) in December?
      This market will resolve to "Yes" if, at any point between market creation and market close on the final day of trading for December 2026, any 1-minute candle for S&P 500 (SPX) shows a final "Low" price equal to or below…
  - (2026-11-24) [Polymarket] Will the upper bound of the target federal funds rate be 3.25% at the end of 2026?
      The FED rate is defined in this market by the upper bound of the target federal funds range. The decisions on the target federal fund range are made by the Federal Open Market Committee (FOMC) meetings. This market will…
  - (2026-11-24) [Manifold] Trump anunciará a existência de seres externos ao planeta terra?
  - (2026-11-24) [Manifold] Will the Army detonate the degraded lead azide at the Iowa Army Ammunition Plant by November 30?
  - (2026-11-24) [Manifold] Will an unofficial PC port of GTA VI let a player control a character in the game world by December 15, 2026?
  - (2026-11-24) [Manifold] Did the US govt. use Jensen to feed false intelligence to China via Alice Huang?

### Government & military aircraft airborne (OpenSky) — 20 new of 21 total
  - (2026-11-24) GAF013 (Germany)
      icao24: 3ea5bc · position: (53.1067, 13.2203) · alt: 7002m · 545km/h
  - (2026-11-24) SAMU974 (France)
      icao24: 3a1e46 · position: (-20.9831, 55.358) · alt: 914m · 249km/h
  - (2026-11-24) FAF7812 (France)
      icao24: 39a858 · position: (45.8963, 0.6513) · alt: 1676m · 309km/h
  - (2026-11-24) GAF614 (Germany)
      icao24: 3f6087 · position: (49.5128, 10.9347) · alt: 685m · 224km/h
  - (2026-11-24) GAF512 (Germany)
      icao24: 3f475d · position: (55.931, 16.4965) · alt: 7010m · 267km/h
  - (2026-11-24) GAF280 (Germany)
      icao24: 3f46db · position: (38.181, -5.5199) · alt: 6103m · 570km/h

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-22) [F3X] CFF
      cycle 2026 · filing #2048874 · receipts $0.48M
  - (2026-11-22) [F99] (unknown)
      cycle 2026 · filing #2048893
  - (2026-11-22) [FRQ] AMERICAN DEMOCRACY PROJECT
      cycle 2026 · filing #
  - (2026-11-22) [F3X] COMMITTEE FOR AMERICAN LEADERSHIP
      cycle 2026 · filing #2048873 · receipts $0.12M
  - (2026-11-22) [FRQ] AUSTAL USA LLC FEDERAL POLITICAL ACTION COMMITTIEE
      cycle 2026 · filing #
  - (2026-11-22) [F99] (unknown)
      cycle 2026 · filing #2048875

### Court opinions of consequence (federal & state) — 13 new of 31 total
  - (2026-11-23) U.S. Court of Appeals, 8th Cir.: Iowa Environmental Council v. EPA
  - (2026-11-23) U.S. Court of Appeals, 8th Cir.: United States v. Mark Moss
  - (2026-11-20) U.S. Court of Appeals, 6th Cir.: United States v. Norman Charles Rhodes
  - (2026-11-18) U.S. Court of Appeals, 4th Cir.: Kalshiex LLC v. John Martin
  - (2026-11-18) U.S. Court of Appeals, 4th Cir.: Peter Laurenzano v. Commissioner of Internal Revenue
  - (2026-11-16) U.S. Court of Appeals, 8th Cir.: Don R. Clark, Jr. v. City of St. Louis, Missouri

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-11-24) New NVIDIA CEO named by December 31, 2026?
      yes price: 100% · 24h volume: $3,221,484 · resolves 2027-01-01
  - (2026-11-24) Counter-Strike: 100 Thieves vs Imperial (BO1) - PGL Major Singapore Stage 1
      yes price: 10% · 24h volume: $717,955 · resolves 2026-11-24
  - (2026-11-24) Yokohama: Jie Cui vs Benjamin Hassan
      yes price: 52% · 24h volume: $667,008 · resolves 2026-11-30
  - (2026-11-24) Counter-Strike: 9z vs M80 (BO1) - PGL Major Singapore Stage 1
      yes price: 0% · 24h volume: $528,497 · resolves 2026-11-24
  - (2026-11-24) Will Josh Shapiro win the 2028 Democratic presidential nomination?
      yes price: 6% · 24h volume: $400,796 · resolves 2028-11-08
  - (2026-11-24) Yokohama: Rio Noguchi vs Maximus Jones
      yes price: 93% · 24h volume: $397,308 · resolves 2026-11-30

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-11-24) MOVER ▲ Elon Musk — $855.80B (+$44.13B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-11-24) MOVER ▲ Jensen Huang — $143.77B (+$33.66B since yesterday)
      United States · Technology · source: Nvidia
  - (2026-11-24) MOVER ▲ Michael Dell — $200.07B (+$18.26B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-11-24) MOVER ▲ Larry Ellison — $152.30B (+$14.64B since yesterday)
      United States · Technology · source: Oracle
  - (2026-11-24) MOVER ▲ Larry Page — $234.13B (+$12.62B since yesterday)
      United States · Technology · source: Google
  - (2026-11-24) MOVER ▲ Mark Zuckerberg — $205.50B (+$12.44B since yesterday)
      United States · Technology · source: Facebook

### USGS earthquakes (M4.5+, past day) — 7 new of 7 total
  - (2026-11-24) M 5.3 - 67 km WNW of Mangan, India
      M5.3 · 67 km WNW of Mangan, India · depth 10 km
  - (2026-11-23) M 4.8 - 209 km SSE of Tobi Village, Palau
      M4.8 · 209 km SSE of Tobi Village, Palau · depth 10 km
  - (2026-11-23) M 4.7 - South Sandwich Islands region
      M4.7 · South Sandwich Islands region · depth 103.295 km
  - (2026-11-23) M 4.7 - 52 km SW of Tyrma, Russia
      M4.7 · 52 km SW of Tyrma, Russia · depth 14.86 km
  - (2026-11-23) M 4.6 - 130 km SSW of Merizo Village, Guam
      M4.6 · 130 km SSW of Merizo Village, Guam · depth 35 km
  - (2026-11-23) M 4.6 - 30 km SW of Finschhafen, Papua New Guinea
      M4.6 · 30 km SW of Finschhafen, Papua New Guinea · depth 56.968 km

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 104 total
  - (2026-11-23) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-11-24) [USASpending] $672,702,242 → AMENTUM SPACEPORT LLC: BASE OPERATIONS AND SPACEPORT SERVICES (BOSS) CONTRACT
      Agency: National Aeronautics and Space Administration. Description: BASE OPERATIONS AND SPACEPORT SERVICES (BOSS) CONTRACT
  - (2026-11-24) [USASpending] $631,537,193 → WELLPOINT FEDERAL SOLUTIONS, INC.: J6 A/B MAC SERVICES
      Agency: Department of Health and Human Services. Description: J6 A/B MAC SERVICES
  - (2026-11-24) [USASpending] $626,506,870 → SIGA TECHNOLOGIES, INC.: PROCUREMENT AND LATE-STAGE DEVELOPMENT OF SMALLPOX ANTIVIRAL
      Agency: Department of Health and Human Services. Description: PROCUREMENT AND LATE-STAGE DEVELOPMENT OF SMALLPOX ANTIVIRAL DRUG(S) IGF::OT::IGF

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 19 total
  - (2026-11-23) CVE-2026-133968 · Project MONAI MONAI Label: Project MONAI MONAI Label Path Traversal Vulnerability
      vendor: Project MONAI · product: MONAI Label · CISA remediation by 2026-11-26
  - (2026-11-23) CVE-2026-134624 · N-able MailAssure: N-able MailAssure (SpamExperts) Server-Side Request Forgery (SSRF) Vulnerability
      vendor: N-able · product: MailAssure · CISA remediation by 2026-11-26

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-11-23) Circulating vaccine-derived poliovirus type 1 – Syrian Arab Republic
      In October 2026, a cluster of four cases of acute flaccid paralysis (AFP) was identified in Al-Mayadin District, Deir Ez Zor Governorate, Syrian Arab Republic. As of 13 November 2026, three confirmed cases of circulating…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=17, 14d-median=19; carrying terms: update, management, safety, airworthiness, provide, certain, protection, amend, action, final, standards, airplanes
- state_bills: today=31, 7d-median=68, 14d-median=88; carrying terms: relating, state, health, providing, alaska, board, district, transfer, medical, emergency, service, authority
- state_news: today=431, 7d-median=711, 14d-median=711; carrying terms: chris, infrastructure, crisis, according, social, maine, demand, investigation, election, every, almost, executive
- local_news: today=221, 7d-median=250, 14d-median=252; carrying terms: family, restaurant, killed, million, accused, state, google, search, thanksgiving, across, officials, health
- foreign_news: today=1024, 7d-median=1024, 14d-median=1008; carrying terms: punchng, preview, traffic, opened, senior, antalya, involving, demand, scheme, cricket, election, probe
- chinese_internal: today=289, 7d-median=293, 14d-median=319; carrying terms: cbmigwfbvv, cbmickfvx, cbmib, market, lxtfb, chinese, cbmiakfvx, color, cbmiyefvx, title, cbmibkfvx, https
- russian_internal: today=943, 7d-median=943, 14d-median=947; carrying terms: press, anthropic, times, httperror, russian, error, axios, novaya, claude, gazeta, https, journal
- ukrainian_internal: today=115, 7d-median=127, 14d-median=129; carrying terms: infrastructure, according, censor, russia, attack, killed, babel, million, launched, overnight, state, across
- ukraine_theater: today=324, 7d-median=277, 14d-median=273; carrying terms: ytzla, betueflwzlvfdhv, naval, nddfrhzwtqdjvom, zexcxnxjkmwpuug, novorossiysk, ovjtoxa, shahed, onuhinvdbc, ucfhntmpfsm, cbmikafbvv, trophylab
- paper_bets: today=81, 7d-median=77, 14d-median=77; carrying terms: marke, secretary, either, another, jpmorgan, conviction, committed, otherwise, allen, completes, derrick, playoff
- weather: today=142, 7d-median=125, 14d-median=127; carrying terms: afdbox, gusting, afdokx, washington, visibility, outlook, afddtx, coastal, coast, magnitude, large, power
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: indicator, vixcls, unrate, unemployment, openings, assets, payrolls, walcl, jtsjol, headline, nonfarm, cpiaucsl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, large, rates, natural, bitcoin, china, credit, futures, agriculture, yield, proxy, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=104, 7d-median=102, 14d-median=100; carrying terms: sanctions, engineering, against, russia, articles, acronym, adopted, assets, color, chemical, sevastopol, management
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, client, quiverquant, https, unauthorized, congresstrading, quiver, httperror, quantitative
- billionaires: today=40, 7d-median=40, 14d-median=36; carrying terms: spain, technologies, finance, infrastructure, berkshire, sergey, warren, retail, madrid, tokyo, changpeng, julia
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=31, 7d-median=60, 14d-median=60; carrying terms: appeals, court, state, martin, blanche, company, charles, justin, derailment, palestine, train, commerce
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, holdings, william, brian, partners, michael, james, robert, laura
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: sherrod, jackson, disbursements, peltola, house, david, warner, booker, senate, trone, ossoff, james
- gdelt_regions: today=103, 7d-median=103, 14d-median=101; carrying terms: english, japan, south, trump, korea, china, turkey, portugal, italian, canada, russia, summit
- gdelt_gkg: today=139, 7d-median=132, 14d-median=123; carrying terms: english, sanctions, keywords, israel, russian, hezbollah, themes, against, russia, attack, security, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: australia, story, killed, english, police, language, outlets, shooting, injured, crash, domain, trump
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=17, 14d-median=19; carrying terms: position, belgium, france, germany, ground, kingdom, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: numbers, september, organization, continued, determined, consuming, rwampara, faster, ivoire, sustained, according, inflammation
- cisa_kev: today=19, 7d-median=19, 14d-median=17; carrying terms: improper, vendor, multiple, google, critical, products, vulnerability, check, product, missing, authentication, incorrect
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=73, 7d-median=54, 14d-median=54; carrying terms: wbsetclaim, republic, congo, update, batch, toollabs, edited, wbeditentity, wbsetsitelink, property, wbsetdescription, quickstatements
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: central, fires, indonesia, australia, earthquake, islands, forest, flood, forestfire, green, burkina, wildfire
- usgs_quakes: today=7, 7d-median=14, 14d-median=12; carrying terms: depth, islands, guinea, papua, region, south, russia, merizo, village
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, resolves, december, change, championship, donetsk, rates, interest, meeting, champions, increase
- commentary: today=0, 7d-median=4, 14d-median=6; carrying terms: revolution, https, marginal, marginalrevolution, world, links, years, assorted, story, books, proof
- tech_news: today=63, 7d-median=63, 14d-median=63; carrying terms: according, information, computerweekly, remote, exploited, weekly, daily, google, vulnerability, record, people, vulnerabilities
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: drift, chris, bilirakis, britt, lankford, khanna, meeks, wasserman, derek, cindy, mcclintock, grothman
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, unavailable, either, paper, today, placed, placement, market, converges, markets, decision, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] ECB press: Boris Vujčić: Risks and resilience in the euro area financial system
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] ECB press: Frank Elderson: Smart supervision for small banks
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-17] ECB press: Philip R. Lane: The practice and science of monetary policy communication: the ECB experience
- [2026-11-18] ECB press: Boris Vujčić: Financial Stability Review - November 2026
- [2026-11-18] ECB press: Risks from AI valuations, fiscal imbalances and geoeconomic tensions weigh on financial stability outlook
- [2026-11-18] Fed speeches: Barr, Investing in America’s Underserved Communities
- [2026-11-18] Fed press (events + announcements): Minutes of the Federal Open Market Committee, October 27-28, 2026
- [2026-11-19] Fed speeches: Jefferson, Monetary Policy amid Frequent and Complex Shocks
- [2026-11-19] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of First Security Bancorp
- [2026-11-20] ECB press: Christine Lagarde: Acting in time

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*