# WORLDSCOPE morning brief — 2026-06-01

## Headline
2164 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 30 total
  (no new items today)

### State Legislative Action — 0 new of 140 total
  (no new items today)

### State-Level News — 58 new of 175 total
  - (2026-06-01) [Connecticut] Secure gun storage will save lives
      <figure><img width="1024" height="390" src="https://ctmirror.org/wp-content/uploads/2026/05/gun-storage-check-week-banner-1024x390.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=
  - (2026-06-01) [Connecticut] CT needs a 21st century tool to fight Medicaid fraud
      <figure><img width="800" height="538" src="https://ctmirror.org/wp-content/uploads/2026/05/Medicaid-form.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" src
  - (2026-05-31) [California] Governor Newsom proclaims Jewish Heritage Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-31) [Colorado] More cities are pressing pause on data centers as local backlash grows
      Hearing backlash from residents, cities and counties across the country in recent weeks have blocked planned data centers amid concerns over rising electricity prices and environmental harms. The local actions come as st
  - (2026-05-31) [Arkansas] Flesh-eating screwworms head for American livestock
      Southern states are bracing for a potential invasion of the New World screwworm that could disrupt livestock markets and raise already high meat prices. So far, the parasite has yet to land in the United States, but it h
  - (2026-05-31) [Arkansas] Rental rates and abortion laws: Dems scrutinize states vying to go first in picking a president
      WASHINGTON — Democratic Party leaders from a dozen states traveled to Washington, D.C., at the end of May to press for their voters to cast the first ballots in the next presidential primary.  State representatives argue
  - (2026-05-31) [Arkansas] Utah governor orders ‘higher bar’ for data centers, says public input ‘absolutely matters’
      Facing public outcry from across the state and intense pushback from communities closest to a massive proposed data center in northern Utah, Gov. Spencer Cox on Friday said the health of the Great Salt Lake and safeguard
  - (2026-05-31) [Arkansas] The data center debates are only a preview of Arkansas’ AI challenges
      As central Arkansas debated how to handle the influx of data centers needed to power artificial intelligence, another story played out in Fort Smith. There, local police sent an alert to community members about an AI-gen

### Local News: St. Louis + Atlanta — 104 new of 190 total
  - (2026-05-31) [St. Louis] Illinois POWER Act data center regulation won’t move forward this spring
  - (2026-05-31) [St. Louis] Lou’s Clues – 6/1/2026
      <p>Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it 
  - (2026-05-31) [St. Louis] Busch was 'electric': What Oli Marmol, players said after Cardinals took series from Cubs
      Here's what manager Oliver Marmol as well as Matthew Liberatore, Hunter Dobbins and Masyn Winn had to say after a series-clinching win vs. the Cubs in Sunday night's finale.
  - (2026-05-31) [St. Louis] Cardinals lose 6-1 against the Chicago Cubs second game of series
      St. Louis Cardinals pitcher Graceffo takes the mound as Chicago Cubs runner Pete Crow-Armstrong gestures to fans on Saturday, May 30, 2026, as he rounds third base on a solo home run in the eighth inning of a game at…
  - (2026-05-31) [St. Louis] UCLA Bruins shortstop Roch Cholowsky (1) throws to first base against the Murray State Racers during the ninth inning at Charles Schwab Field.
      UCLA and shortstop Roch Cholowsky lost to Saint Mary's for the second time in three days on Sunday and were bounced from the NCAA Regionals.
  - (2026-05-31) [St. Louis] 'The energy in the stadium was electric,' Masyn Winn says of Cardinals-cubs
      St. Louis Cardinals shortstop Masyn Winn speaks with the media after a series-clinching win vs. the Cubs at Busch Stadium on Sunday, May 31, 2026.
  - (2026-05-31) [St. Louis] 'Great experience' earning first save vs. Cubs, Cardinals' Hunter Dobbins says
      St. Louis Cardinals pitcher Hunter Dobbins speaks with the media after a series-clinching win vs. the Cubs at Busch Stadium on Sunday, May 31, 2026.
  - (2026-05-31) [St. Louis] 'Exactly as planned': Oli Marmol on Hunter Dobbins giving Cardinals bullpen rest vs. Cubs
      St. Louis Cardinals manager Oliver Marmol speaks with the media after a series-clinching win vs. the Cubs at Busch Stadium on Sunday, May 31, 2026.

### International News + Multilateral Institutions — 494 new of 807 total
  - (2026-05-31) [Global] Israel seizes castle in Lebanon as it expands ground offensive
      Prime Minister Benjamin Netanyahu calls the capture of the strategic fortress a "decisive shift" in Israel's campaign against Hezbollah, as European governments criticise the escalation.
  - (2026-06-01) [Global] Colombia presidential runoff pits leftist senator against pro-Trump rival
      Left-wing senator Iván Cepeda will face Trump admirer Abelardo de la Espriella at the final ballot on 21 June.
  - (2026-05-31) [Global] Trump seeking edits to US-Iran deal, US media report
      The requested changes are related to the Strait of Hormuz and the removal of highly enriched uranium, according to US media.
  - (2026-05-31) [Global] Huge blast kills dozens in rebel-held village in Myanmar
      Insurgents say it was caused by explosives being used for mining close to the Chinese border.
  - (2026-06-01) [Global] Poland's controversial 'Highway to Hel' 666 bus revived
      Poland's seaside resort called Hel is getting its 666 bus service back, despite earlier opposition from Christian groups.
  - (2026-05-31) [Global] Hundreds arrested and dozens of police injured after Champions League riots in France
      Nearly 800 people were arrested after clashes with police which saw 219 people injured, including 57 police officers.
  - (2026-05-31) [Global] South Africa made to look like fools over World Cup visa issues, says minister
      After a day of uncertainty, the government confirms the team will depart for Mexico on Monday.
  - (2026-05-31) [Global] Dead whale towed ashore in Denmark ahead of autopsy
      "Timmy" was found dead off the coast of Anholt despite multiple attempts to rescue it.

### Chinese Internal News — 191 new of 225 total
  - (2026-05-30) [TITLE: 美防长在香会对华“降调”，对欧“施压”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9HdWZfQW1meFBGUmZtRVk3WTB0OXlqVnBWZ0tkVWY3cHRfRlk3NVBMWkc3SjA2N0NGaFZyMy16WGdaWng1WFkxX1ZZRkFL] (zh: 美防长在香会对华“降调”，对欧“施压”-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9HdWZfQW1meFBGUmZtRVk3WTB0OXlqVnBWZ0tkVWY3cHRfRlk3NVBMWkc3SjA2N0NGaFZyMy16WGdaWng1WFkxX1ZZRkFLTlZxc2pDTVU1THlHVmlzZW5RWEQ4VGNDUmFDamc?oc=5" target="_blank">美防长在
  - (2026-05-30) [TITLE: 中山大学：涉学术不端，生科院副院长等多人被处理-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1QRUZLUG5LR0Ric01ycWxWNUFlZ25GbE1NN09wVzVyZW12TUxiaVMyNHN5TjlvTE1fcm9uOC1NZXN4Sjk3eUQyZWlX] (zh: 中山大学：涉学术不端，生科院副院长等多人被处理-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1QRUZLUG5LR0Ric01ycWxWNUFlZ25GbE1NN09wVzVyZW12TUxiaVMyNHN5TjlvTE1fcm9uOC1NZXN4Sjk3eUQyZWlXU2RVa09wWWI1bURNM2lRWnhIU2s5QlRMcHRpZw?oc=5" target="_blank">中山大学：涉学术不
  - (2026-05-30) [TITLE: 南开大学：涉学术不端，生科院院长被免职，第一作者被解聘-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBfVFFRaG83UDNFaGRjM19FOHdKckR6SFhNTXNYLXJpNFVjdkVhUDNpSUpxMXNpaWZycy1jRURmeldHekhEVjNL] (zh: 南开大学：涉学术不端，生科院院长被免职，第一作者被解聘-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBfVFFRaG83UDNFaGRjM19FOHdKckR6SFhNTXNYLXJpNFVjdkVhUDNpSUpxMXNpaWZycy1jRURmeldHekhEVjNLZjdNRUo3T2ZTLXRIWUF3aXVveHJiZmRpOVN1NTJQZw?oc=5" target="_blank">南开大学：涉学术不
  - (2026-05-30) [TITLE: 又来，“中国要2027‘武统’，美军悄悄准备了…”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE4yX2lueHctOWx4aUJ5X2ViRWcwcnAzMDRtYXBFQkdhbFk4ZDFFbFUweF8zZFhqMDV4cUNCTG91anR4NlFSbDFvaV] (zh: 又来，“中国要2027‘武统’，美军悄悄准备了…”-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE4yX2lueHctOWx4aUJ5X2ViRWcwcnAzMDRtYXBFQkdhbFk4ZDFFbFUweF8zZFhqMDV4cUNCTG91anR4NlFSbDFvaVJ3QnlhZUlIcHFfZUxKbmlFUVJ0eHdObzE3RWotQVJsUlE?oc=5" target="_blank">又来，“
  - (2026-06-01) [TITLE: 80岁微胖老翁如何担任美国总统两晚发280条推 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5mRjBnVE16T1FGcmtJSjA5eGlJY0dnWGstOHpoaXhzM3pVMDJNU2lKS2FEX2NobDRGZURCMm1xQ3ZlQ0dMODEySVNyWlA5T2] (zh: 80岁微胖老翁如何担任美国总统两晚发280条推 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5mRjBnVE16T1FGcmtJSjA5eGlJY0dnWGstOHpoaXhzM3pVMDJNU2lKS2FEX2NobDRGZURCMm1xQ3ZlQ0dMODEySVNyWlA5T2lsaGhqNXk3eXlDRmc?oc=5" target="_blank">80岁微胖老翁如何担任美国总统两晚发280条推<
  - (2026-05-31) [TITLE: 智利缉毒犬在官方仪式现场，突然扑咬海军中将裤兜…-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1iSUJjUDhSaTZTeHd5QkVvekp1ZHdxdUczVGtPbjlkTmFESFVsV05wQUtzM1RZcFBPN1dZQ24xamU3c1hOeVFjRGN] (zh: 智利缉毒犬在官方仪式现场，突然扑咬海军中将裤兜…-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1iSUJjUDhSaTZTeHd5QkVvekp1ZHdxdUczVGtPbjlkTmFESFVsV05wQUtzM1RZcFBPN1dZQ24xamU3c1hOeVFjRGNyQ1VhbnJtN05hRWxKaGNsWHdKQnVGUWl0VHNNclBXcFE?oc=5" target="_blank">智利缉毒
  - (2026-06-01) [TITLE: 不看历史仇恨，压抑、排外…日本这样的社会到底有何吸引力？怎么那么多人崇日啊 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5HdUFNNGs3SW15cGtGaHhyT1hydGpXUVRBS1FjdV9WdFVzYjBuVDh3dV9UMmNmdkR4Z2FMc2Q2aEh6VHpI] (zh: 不看历史仇恨，压抑、排外…日本这样的社会到底有何吸引力？怎么那么多人崇日啊 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5HdUFNNGs3SW15cGtGaHhyT1hydGpXUVRBS1FjdV9WdFVzYjBuVDh3dV9UMmNmdkR4Z2FMc2Q2aEh6VHpIR3BlVEFNazRkbG1CcHdrMzd4ZEluNjg?oc=5" target="_blank">不看历史仇恨，压抑、排外…日本这样的社会到底有何
  - (2026-06-01) [TITLE: “馆长”的川渝行也挺多看点的，尤其是和张雪对谈的这段 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5yaVRuWHZ4OWFIMlVnbVl6SEoyRjhIZ2h6bWUyUU5ZeXZWMFdKYzREVGlxX1NMLXZJNTJ5R1hKXy16bHVOVURZOWtJVFU] (zh: “馆长”的川渝行也挺多看点的，尤其是和张雪对谈的这段 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5yaVRuWHZ4OWFIMlVnbVl6SEoyRjhIZ2h6bWUyUU5ZeXZWMFdKYzREVGlxX1NMLXZJNTJ5R1hKXy16bHVOVURZOWtJVFUwTmRUZFZEYlVhdWQ0ekU?oc=5" target="_blank">“馆长”的川渝行也挺多看点的，尤其是和张雪对谈的

### Russian Internal News (state + in-exile) — 510 new of 684 total
  - (2026-05-31) [TITLE: В Болгарии завершился чемпионат Европы по художественной гимнастике. На нем звучали гимны России и Беларуси (против чего протестовали украинские спортсменки), а российская сборная почти полност] (ru: В Болгарии завершился чемпионат Европы по художественной гимнастике. На нем звуч)
      <p>С 27 по 31 мая в болгарской Варне прошел чемпионат Европы по художественной гимнастике — это были первые с 2021 года международные соревнования, на которых спортсменки из России и Беларуси выступили с флагом и гимном.
  - (2026-05-31) [TITLE: «Расследование пришло к выводу, что обломки принадлежат российскому дрону». Президент Румынии опубликовал фотографии фрагментов беспилотника, попавшего в жилой дом | LEDE: <p>Беспилотник, попав] (ru: «Расследование пришло к выводу, что обломки принадлежат российскому дрону». През)
      <p>Беспилотник, попавший ночью 29 мая в жилой дом в городе Галац на юго-востоке Румынии, был российского производства, в такому выводу пришли румынские специалисты. Об этом заявил президент Румынии Никушор Дан. <p>
  - (2026-05-31) [TITLE: Лукашенко заявил, что Армении следует быть «аккуратнее», выбирая между Евразийским союзом и ЕС. Вслед за Путиным он сказал, что «в Украине все ровно так начиналось» | LEDE: <p>Александр Лукашен] (ru: Лукашенко заявил, что Армении следует быть «аккуратнее», выбирая между Евразийск)
      <p>Александр Лукашенко призвал народ Армении быть «очень аккуратным» при выборе между Евразийским союзом и Европой, чтобы «не повторить то, что произошло в Украине». Его слова приводит «Белта». <p>
  - (2026-05-31) [TITLE: Некоторые зашифрованные тексты не удается декодировать на протяжении сотен и даже тысяч лет. Вероятно, это получится изменить с помощью ИИ | LEDE: <p>В Ватиканской апостольской библиотеке более] (ru: Некоторые зашифрованные тексты не удается декодировать на протяжении сотен и даж)
      <p>В Ватиканской апостольской библиотеке более четырех веков хранится рукописная книга из 408 страниц, большую часть которой до недавнего времени было невозможно прочитать. В тексте использованы 34 необычных символа впер
  - (2026-05-31) [TITLE: В Москве в жилом доме произошел конфликт между 14-летней школьницей из Бурятии и двумя женщинами. Девочка рассказала, что ее избили и назвали «узкоглазой» | LEDE: <p>Глава Бурятии Алексей Цыден] (ru: В Москве в жилом доме произошел конфликт между 14-летней школьницей из Бурятии и)
      <p>Глава Бурятии Алексей Цыденов поручил правительству республики «разобраться» в нападении в Москве на 14-летнюю школьницу из Бурятии. <p>
  - (2026-05-31) [TITLE: Война. 1558-й день. Украина атаковала нефтяные объекты в трех регионах России | LEDE: <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно п] (ru: Война. 1558-й день. Украина атаковала нефтяные объекты в трех регионах России)
      <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. К
  - (2026-05-31) [TITLE: Россия снова обвинила ВСУ в ударе по Запорожской АЭС | LEDE: <p>Вооруженные силы Украины нанесли удар по транспортному цеху Запорожской АЭС, заявило назначенное Россией руководство станции. <p>] (ru: Россия снова обвинила ВСУ в ударе по Запорожской АЭС)
      <p>Вооруженные силы Украины нанесли удар по транспортному цеху Запорожской АЭС, заявило назначенное Россией руководство станции. <p>
  - (2026-05-31) [TITLE: Bloomberg: Евросоюз рассматривает вариант заморозки потолка цен на российскую нефть из-за войны на Ближнем Востоке | LEDE: <p>Евросоюз рассматривает возможность временной заморозки потолка цен ] (ru: Bloomberg: Евросоюз рассматривает вариант заморозки потолка цен на российскую не)
      <p>Евросоюз рассматривает возможность временной заморозки потолка цен на российскую нефть на фоне роста мировых цен на энергоносители из-за войны на Ближнем Востоке. Об этом сообщает Bloomberg со ссылкой на источники. <p

### Ukrainian Internal News (national + local Kyiv) — 37 new of 96 total
  - (2026-06-01) [TITLE: Росіяни вдарили по Запоріжжю – поранили жінку | LEDE: 1 червня росіяни обстріляли Запоріжжя – поранено жінку і пошкоджено приватний будинок.] (uk: Росіяни вдарили по Запоріжжю – поранили жінку)
      1 червня росіяни обстріляли Запоріжжя – поранено жінку і пошкоджено приватний будинок.
  - (2026-06-01) [TITLE: ЗСУ за добу відмінусували понад 1400 окупантів | LEDE: За добу ЗСУ знешкодили 1 410 окупантів і понад 2 тисячі одиниць озброєння і військової техніки РФ. Дані Генштабу ЗСУ.] (uk: ЗСУ за добу відмінусували понад 1400 окупантів)
      За добу ЗСУ знешкодили 1 410 окупантів і понад 2 тисячі одиниць озброєння і військової техніки РФ. Дані Генштабу ЗСУ.
  - (2026-06-01) [TITLE: Трамп назвав CNN "катастрофою" після статті про угоду з Іраном | LEDE: Дональд Трамп заявив, що CNN поширює фейкові новини про його угоду з Іраном щодо ядерної зброї.] (uk: Трамп назвав CNN "катастрофою" після статті про угоду з Іраном)
      Дональд Трамп заявив, що CNN поширює фейкові новини про його угоду з Іраном щодо ядерної зброї.
  - (2026-06-01) [TITLE: Росіяни вдарили по Сумах: пошкоджений дитячий садок та житлові будинки | LEDE: У ніч на 1 червня російські війська атакували Суми — пошкоджено дитсадок і будинки, постраждалих немає.] (uk: Росіяни вдарили по Сумах: пошкоджений дитячий садок та житлові будинки)
      У ніч на 1 червня російські війська атакували Суми — пошкоджено дитсадок і будинки, постраждалих немає.
  - (2026-06-01) [TITLE: Міністр МЗС Молдови підтримав об'єднання з Румунією | LEDE: Міністр МЗС Молдови Попшой заявив про підтримку об'єднання з Румунією, якщо цього захоче суспільство.] (uk: Міністр МЗС Молдови підтримав об'єднання з Румунією)
      Міністр МЗС Молдови Попшой заявив про підтримку об'єднання з Румунією, якщо цього захоче суспільство.
  - (2026-06-01) [TITLE: Ізраїль просить дозволу у США для нових ударів по Лівану | LEDE: Ізраїль звернувся до США щодо погодження розширення військових дій у Бейруті через відсутність прогресу в переговорах.] (uk: Ізраїль просить дозволу у США для нових ударів по Лівану)
      Ізраїль звернувся до США щодо погодження розширення військових дій у Бейруті через відсутність прогресу в переговорах.
  - (2026-06-01) [TITLE: Щоб доставити Содоля на лівий берег, використали ледь не весь РЕБ корпусу морської піхоти – колишній начрозвідки 501-го батальйону "Оріон" про Кринки | LEDE: У липні 2022 року розвідники 501-го] (uk: Щоб доставити Содоля на лівий берег, використали ледь не весь РЕБ корпусу морськ)
      У липні 2022 року розвідники 501-го окремого батальйону морпіхів розгортали спостережні пости (СП) для піхоти в посадках на Гуляйпільському напрямку. Дорогою до "СПшок" піхотинців засікли росіяни.
  - (2026-06-01) [TITLE: ЗМІ: Ціна на нафту зростає на тлі невизначеності щодо угоди між США та Іраном | LEDE: Нафта подорожчала після падіння через невідомість навколо переговорів між США та Іраном про перемир'я і від] (uk: ЗМІ: Ціна на нафту зростає на тлі невизначеності щодо угоди між США та Іраном)
      Нафта подорожчала після падіння через невідомість навколо переговорів між США та Іраном про перемир'я і відкриття Ормузької протоки.

### Ukraine Theater (total-war monitoring) — 100 new of 266 total
  - (2026-06-01) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-31) [FIRMS] thermal anomaly 50.052, 34.889 (FRP 2.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1024Z, FRP 2.7 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.337, 34.366 (FRP 3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1026Z, FRP 3 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.284, 33.032 (FRP 1.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 1.15 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.193, 34.040 (FRP 2.66 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 2.66 MW
  - (2026-05-31) [FIRMS] thermal anomaly 50.181, 34.759 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2237Z, FRP 1.02 MW
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMiOkFVX3lxTFBsdGdBOUMtUGIzaWpMRVRwa0x4VWY3SlRTTVdTYW83Y01rR0xpSWpXd2xNOWFkV0lWNUE?oc=5" target="_blank">Ukraine Interactive map - Ukraine Latest news on live map - liveuama
  - (2017-06-06) [Liveuamap] Lebanon news on live map - lebanon.liveuamap.com - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMiREFVX3lxTE9ldllvQVZJdkFSY1VwVEdEMTJ0YVI0SHA5QzJDZGNrcnJCNk1wbVYtT0FXRmdZN1d6cGxNbG1CZnIxT1B1?oc=5" target="_blank">Lebanon news on live map - lebanon.liveuamap.com</a>&nb

### Paper Trading Scorecard — 31 new of 144 total
  - (2026-06-01) [Polymarket] Will "Backrooms" Opening Weekend Box Office be between 73m and 79m?
      This market will resolve according to how much "Backrooms" Opening Weekend Box Office will gross domestically on its opening weekend. The "Daily Box Office Performance" figures found on the “Box Office” tab on this movie
  - (2026-06-01) [Polymarket] Tesla and xAI merger officially announced by June 30?
      This market will resolve to "Yes" if it is officially announced that Tesla, Inc. will be, has been, or is being acquired by or merged with xAI, or vice versa, by June 30, 2026, 11:59 PM ET. Otherwise, this market will re
  - (2026-06-01) [Polymarket] Will CD Castellón vs. SD Eibar end in a draw?
      In the upcoming game, scheduled for May 31, 2026
If the game ends in a draw, this market will resolve to "Yes".
Otherwise, this market will resolve to "No".
If the game is postponed, this market will remain open until th
  - (2026-06-01) [Polymarket] Will Robert Kenyon win the 2026 Makerfield by-election?
      A by-election for the United Kingdom parliamentary constituency of Makerfield is expected to be held on June 18, 2026, following the announced resignation of incumbent Josh Simons.

This market will resolve according to 
  - (2026-06-01) [Polymarket] Will Gen.G Esports win the LCK 2026 season playoffs?
      This market will resolve according to the winner of the League of Legends Champions Korea (LCK) 2026 season playoffs.

If the 2026 LCK season is postponed after December 31, 2026 11:59 PM ET, canceled, or a winner has no
  - (2026-06-01) [Polymarket] Israel x Iran permanent peace deal by June 30, 2026?
      This market will resolve to “Yes” if Israel and Iran agree to a permanent peace deal by the specified date, 11:59 PM ET. Otherwise, this market will resolve to “No”.

A permanent peace deal refers to any agreement which 
  - (2026-06-01) [Polymarket] Will Cătălin Predoiu be the next Prime Minister of Romania?
      This market will resolve to the next individual who officially assumes the office of Prime Minister of Romania by December 31, 2027, 11:59 PM ET.

To count for resolution, the individual must be formally appointed by the
  - (2026-06-01) [Polymarket] Will Wes Moore win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028.

This market will resolve to the person who wins the 2028 US Presidential Election.

The resolution source for this market is the Associat

### U.S. Weather + Severe / Climate Outlooks — 131 new of 134 total
  - (2026-05-31) [Extreme] Tornado Warning: Tornado Warning issued May 31 at 11:44PM CDT until June 1 at 12:15AM CDT by NWS Topeka KS
      TORTOP

The National Weather Service in Topeka has issued a

* Tornado Warning for...
Southern Coffey County in east central Kansas...

* Until 1215 AM CDT.

* At 1143 PM CDT, a severe thunderstorm capable of producing a
  - (2026-05-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 31 at 11:44PM CDT until June 1 at 12:30AM CDT by NWS Sioux Falls SD
      SVRFSD

The National Weather Service in Sioux Falls has issued a

* Severe Thunderstorm Warning for...
Southwestern Cherokee County in northwestern Iowa...
Northern Woodbury County in west central Iowa...
Southeastern Pl
  - (2026-05-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 31 at 11:42PM CDT until June 1 at 12:30AM CDT by NWS Norman OK
      SVROUN

The National Weather Service in Norman has issued a

* Severe Thunderstorm Warning for...
Northwestern Blaine County in northwestern Oklahoma...
Northeastern Dewey County in northwestern Oklahoma...
Southwestern 
  - (2026-05-31) [Severe] Flood Warning: Flood Warning issued May 31 at 11:41PM CDT until June 1 at 3:45AM CDT by NWS Wichita KS
      * WHAT...Flooding caused by excessive rainfall is expected.

* WHERE...A portion of southeast Kansas, including the following
county, Greenwood.

* WHEN...Until 345 AM CDT.

* IMPACTS...Flooding of rivers, creeks, stream
  - (2026-05-31) [Severe] Flash Flood Warning: Flash Flood Warning issued May 31 at 11:40PM CDT until June 1 at 2:30AM CDT by NWS Topeka KS
      FFWTOP

The National Weather Service in Topeka has issued a

* Flash Flood Warning for...
Southwestern Coffey County in east central Kansas...

* Until 230 AM CDT.

* At 1139 PM CDT, Doppler radar indicated thunderstorms
  - (2026-05-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 31 at 11:39PM CDT until June 1 at 12:00AM CDT by NWS Wichita KS
      At 1139 PM CDT, a severe thunderstorm was located near Gridley, or 9
miles east of Madison, moving southeast at 15 mph.

HAZARD...Golf ball size hail and 60 mph wind gusts.

SOURCE...Radar indicated.

IMPACT...People and
  - (2026-06-01) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-31) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 31 at 11:36PM CDT until June 1 at 12:15AM CDT by NWS Omaha/Valley NE
      SVROAX

The National Weather Service in Omaha has issued a

* Severe Thunderstorm Warning for...
Northeastern Harrison County in southwestern Iowa...
West central Shelby County in southwestern Iowa...

* Until 1215 AM CD

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 101 total
  - (2026-06-01) [BIS Entity List] page checksum 0220879c7d79
      Page content hash: 0220879c7d79. Compare with prior day's hash to detect updates.

### Congressional STOCK Act Trades (House + Senate) — 39 new of 39 total
  - (2026-05-15) [House] David J. Taylor (R): Purchase PH ($1,001 - $15,000) (excess -4.5% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: PH (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase PH ($1,001 - $15,000) (excess -4.5% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: PH (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase MEDP ($1,001 - $15,000) (excess +5.3% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: MEDP (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclo
  - (2026-05-15) [House] David J. Taylor (R): Purchase MEDP ($1,001 - $15,000) (excess +5.3% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: MEDP (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclo
  - (2026-05-15) [House] David J. Taylor (R): Purchase HD ($1,001 - $15,000) (excess +4.2% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: HD (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase HD ($1,001 - $15,000) (excess +4.2% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: HD (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase T ($1,001 - $15,000) (excess +0.8% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: T (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosur
  - (2026-05-15) [House] David J. Taylor (R): Sale AAPL ($1,001 - $15,000) (excess +1.6% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: AAPL (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosure

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal & state) — 51 new of 60 total
  - (2026-06-02) Connecticut Supreme Court: Wilmington Savings Fund Society, FSB v. Schulz
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: Fahirri Dannah v. City of Grand Rapids
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: Julie Schulz Halbower v. Hiscox Syndicate 33 of Lloyd's of London
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: Odinaka Ethelberth Nwosu v. Todd Blanche
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: United States v. Radu Miclaus
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: William Klopfenstein v. Fifth Third Bank
  - (2026-05-29) U.S. Court of Appeals, D.C. Cir.: Global Voice Group SA v. Republic of Guinea
  - (2026-05-29) U.S. Court of Appeals, D.C. Cir.: ModernWest Longmont, LLC v. FAA

### SEC Form 4 insider transactions (recent) — 0 new of 40 total
  (no new items today)

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-01) [Philippines] SEIMC Launches Precision Gallbladder - Preserving Treatment to Safeguard Biliary Health
      domain: manilatimes.net · language: English · tone: 
  - (2026-06-01) [Malaysia] Tomoe Shokai expands Indian footprint for 2027
      domain: malaysiasun.com · language: English · tone: 
  - (2026-06-01) [Turkey] Israeli army reports rocket fire from Lebanon
      domain: aa.com.tr · language: English · tone: 
  - (2026-06-01) [Iran] British journalist Bushra Shaikh targeted by Western media for exposing US - Israeli war crimes in Iran
      domain: presstv.ir · language: English · tone: 
  - (2026-06-01) [United States] Buffalo  Ladies First  hip - hop event returns for 4th year with new venue
      domain: wkbw.com · language: English · tone: 
  - (2026-06-01) [Egypt] Zendaya Signals Season 3 End , Is This The Last Season Of Euphoria
      domain: el-balad.com · language: English · tone: 
  - (2026-06-01) [Malaysia] ASSOE 2026 Connects Global Buyers with Advanced Safety & Security Solutions Through a Five - Month Online Exhibition
      domain: malaysiasun.com · language: English · tone: 
  - (2026-06-01) [Kenya] Hantavirus sparks pandemic fears despite limited evidence of human transmission
      domain: standardmedia.co.ke · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 15 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 15 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-06-01) Will Cape Verde win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,742,752 · resolves 2026-07-20
  - (2026-06-01) Will Iraq win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,574,215 · resolves 2026-07-20
  - (2026-06-01) Will Qatar win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,120,960 · resolves 2026-07-20
  - (2026-06-01) Will Haiti win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,070,932 · resolves 2026-07-20
  - (2026-06-01) Will New Zealand win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $9,151,925 · resolves 2026-07-20
  - (2026-06-01) Will Saudi Arabia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $8,081,695 · resolves 2026-07-20
  - (2026-06-01) Will Uzbekistan win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $6,555,649 · resolves 2026-07-20
  - (2026-06-01) Roland Garros ATP: Jakub Mensik vs Andrey Rublev
      yes price: 100% · 24h volume: $4,986,861 · resolves 2026-06-07

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-06-01) [Marginal Revolution] The political right continues to gain ground in Latin America
      A leftist senator and a rightwing populist outsider who calls himself “The Tiger” will go to a run-off presidential election in Colombia this month after no candidate won outright in the first round of voting on Sunday. 
  - (2026-05-31) [Marginal Revolution] The returns to good data are rising
      When we want A.I. to solve real problems for real people, we need to make sure the data exists. That means cleaning up government data sets that are currently in a shambles (a project that the province of Alberta’s gover
  - (2026-05-31) [Marginal Revolution] A new American exceptionalism?
      From Paul Krugman: Let me be clear: I am not arguing that European productivity is mismeasured, and never said that. I am, instead, arguing that standard measures of productivity do not have the implications for cross-co

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=30, 14d-median=30; carrying terms: regulatory, event, proposing, temporary, navigable, order, potential, captain, needed, model, adopting, proposes
- state_bills: today=140, 7d-median=148, 14d-median=148; carrying terms: community, willful, postsecondary, committees, responsibility, native, supporting, members, provided, level, toxic, assessor
- state_news: today=175, 7d-median=708, 14d-median=708; carrying terms: community, illinois, broadcasting, native, nationally, shows, members, power, toxic, donald, video, three
- local_news: today=190, 7d-median=247, 14d-median=247; carrying terms: officer, community, illinois, members, event, power, three, apartment, nofollow, years, stars, nation
- foreign_news: today=807, 7d-median=864, 14d-median=864; carrying terms: community, kills, sichuan, politician, supporting, adviser, fulfilling, event, power, level, conservation, forces
- chinese_internal: today=225, 7d-median=273, 14d-median=273; carrying terms: cbmib, cbmibkfvx, caixin, lxtfb, cbmizefvx, cbmia, title, cbmizkfvx, china, cbmidefvx, cbmibefvx, cbmixkfvx
- russian_internal: today=684, 7d-median=968, 14d-median=968; carrying terms: forbidden, error, politico, russian, title, origin, found, novayagazeta, times, spiegel, europe, group
- ukrainian_internal: today=96, 7d-median=122, 14d-median=122; carrying terms: negotiations, urged, european, responsibility, urges, iranian, adviser, power, donald, forces, three, years
- ukraine_theater: today=266, 7d-median=336, 14d-median=336; carrying terms: community, illinois, szdvderoujbvrc, xpdeten, explosions, vzmzlxj, eetgs, nlbudwrfqtbkbejnsdzqbdm, jxamxtzg, pnyunnevpfcg, rqqxnnnvvsef, cbmilafbvv
- paper_bets: today=144, 7d-median=141, 14d-median=141; carrying terms: miami, total, approve, humans, diabetes, world, colonize, earthquake, office, minnesota, official, another
- weather: today=134, 7d-median=119, 14d-median=119; carrying terms: hazard, miles, state, power, level, angeles, sweep, afdsew, islands, hazleton, upper, mobile
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: nasdaq, equity, cotton, silver, crypto, brazil, australia, commodity, natural, kospi, france, price
- sanctions_procurement: today=101, 7d-median=98, 14d-median=98; carrying terms: proliferation, cbmib, xtgxrdudrnejwemltsu, unauthorised, ubhjmx, transnistrian, committees, niger, rounds, hamas, engineering, russian
- congressional_trades: today=39, 7d-median=1, 14d-median=1
- billionaires: today=0, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: bondi, america, vasquez, smith, blanche, transport, employee, fernandez, group, kenneth, robert, pitchford
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, financial, david, holdings, group, brian, scott, michael, american
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, alexandria, ossoff, booker, jonathan, robert, lindsey, cooper, receipts, scott, sherrod, michael
- gdelt_regions: today=0, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=20; carrying terms: india, kingdom, israel, domain, language, canada, english, nigeria
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=0, 14d-median=0
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: authentication, traversal, error, overflow, defender, reader, micro, windows, adobe, bypass, origin, acrobat
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: hormuz, continue, strait, world, volume, resolves, ceasefire, peace, price, permanent, returns, traffic
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, revolution, marginal, economist, policy, story, https, class, marginalrevolution, recipients, scenario, poses
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: stevens, walkinshaw, analilia, brandon, sheldon, laura, peters, ratcliffe, pelosi, components, lindsey, latimer
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, markets, converges, today, unavailable, claude, decision, placement, sufficient, evidence, consensus, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] ECB press: Financial stability vulnerabilities remain elevated as geoeconomic shock unfolds
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*