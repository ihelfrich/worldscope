# WORLDSCOPE morning brief — 2026-06-01

## Headline
2945 new items across 21 active section(s) (of 37 tracked).

## Top movers today
Russian Internal News (state + in-exile) (698) · International News + Multilateral Institutions (668) · World leaders & government officials (324) · State-Level News (275) · Chinese Internal News (228) · Local News: St. Louis + Atlanta (214) · U.S. Weather + Severe / Climate Outlooks (129) · Ukraine Theater (total-war monitoring) (106) · Ukrainian Internal News (national + local Kyiv) (72) · Court opinions of consequence (federal & state) (49) · SEC Form 4 insider transactions (recent) (40) · Paper Trading Scorecard (34)

## What changed today
### Russian Internal News (state + in-exile) — 698 new of 835 total
  - (2026-06-01) "Хезболла" подтвердила властям Ливана прекращение огня с Израилем | LEDE: ] (ru: "Хезболла" подтвердила властям Ливана прекращение огня с Израилем)
  - (2026-06-01) На Украине пересмотрят решения, позволявшие предприятиям давать бронь | LEDE: ] (ru: На Украине пересмотрят решения, позволявшие предприятиям давать бронь)
  - (2026-06-01) В Кировской области создали подразделение БАРС для подавления БПЛА | LEDE: ] (ru: В Кировской области создали подразделение БАРС для подавления БПЛА)
  - (2026-06-01) Врачи оказывают помощь пострадавшему в тяжелом состоянии после удара в ЛНР | LEDE: ] (ru: Врачи оказывают помощь пострадавшему в тяжелом состоянии после удара в ЛНР)
  - (2026-06-01) В ДНР из-за киевской агрессии погибли два человека | LEDE: ] (ru: В ДНР из-за киевской агрессии погибли два человека)
  - (2026-06-01) Энергодар в Запорожской области остался без электроснабжения | LEDE: ] (ru: Энергодар в Запорожской области остался без электроснабжения)

### International News + Multilateral Institutions — 668 new of 859 total
  - (2026-06-01) [Australia] The sliding door moment for 'awestruck' Diamonds bolter
      Despite signing her first full-time Super Netball contract this year there was no guarantee Jessie Grenvold would get a lot of court time. But through injury, the Mavericks defender took on a starting spot and is now a D…
  - (2026-06-01) [Australia] Maroons hit with double injury blow ahead of Origin II
      Queensland's task of levelling the State of Origin series has become more difficult after confirmation two of its stars have been ruled out of Game II at the MCG.
  - (2026-06-01) [Australia] 'One more to go': Aussies on cusp of winning rugby 7s World Championship
      Australia puts itself in pole position to win the women's rugby sevens World Championship, while the men's team also enjoys the spoils of victory in Spain.
  - (2026-06-01) [Australia] Why Naomi Osaka and Taylor Townsend's dinner party 'caused a stir'
      From the Harlem Renaissance of the 20s and 30s to Soul Food Sundays at Wimbledon in the 80s and 90s, Naomi Osaka and Taylor Townsend's dinner party before the French Open continues a long history of black athletes coming…
  - (2026-05-31) [Australia] Fowler wins FA Cup with Man City as fans honour Aussie coach's late father
      The Women's FA Cup has a distinctly Australian flavour with Mary Fowler's Manchester City thumping Charlize Rule's Brighton and Hove Albion, coached by compatriot Dario Vidošić, whose father was honoured by fans at Wembl…
  - (2026-05-31) [Australia] Teen star reaches first major quarterfinal while Świątek out of French Open
      Nineteen-year-old Joao Fonseca beats two-time French Open runner-up Casper Ruud to reach his first grand slam quarterfinal, while four-time champion Iga Świątek suffers her earliest exit since 2019.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 275 new of 361 total
  - (2026-06-01) [Alaska] High-profile child deaths spark push for welfare agency transparency
      After two 5-year-old Indianapolis girls separately died from abuse in the last two years, Indiana Republican state Sen. Julie McGuire said lawmakers could not get basic answers from the state agency responsible for the s…
  - (2026-06-01) [Alaska] In Kachemak Bay, Kotzebue and beyond, Alaskans are on the lookout for harmful algae blooms
      Algae is vital to a healthy marine system, and most of the hundreds of varieties in Alaska’s waters are beneficial or benign. But the handful that are harmful are, like other algae, proliferating in warmer conditions and…
  - (2026-06-01) [California] Un tanque de productos químicos estuvo a punto de explotar. ¿Acaso los reguladores de California no detectaron las señales de alerta?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052226-Garden-Grove-Leak-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-06-01) [California] Suspense in California governor’s race as Democrats hold on to their ballots
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_UCSD-Voting_AD_CM_02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-06-01) [California] Long after protests ended, this interfaith group rallies to remember LA immigrants taken by ICE
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052726-godmothers-of-the-disappeared-SR-GETTY-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-imag…
  - (2026-06-01) [California] Why a yearslong fight over gambling is good news for California politicians
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052126-Cardroom-Protest-MG-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…

### Chinese Internal News — 228 new of 258 total
  - (2026-06-01) Chinese EV makers recover in May but competition remains fierce amid overcapacity woes
  - (2026-06-01) Closure of Hong Kong’s Casa Hotel tied to student-housing trend after failed sale attempts
  - (2026-06-01) Akeso lung cancer drug shines in trials, boosting hopes in US$20b market
  - (2026-06-01) Unitree clears key hurdle to Shanghai IPO as China’s humanoid robot wave gathers pace
  - (2026-06-01) China index reshuffle to entrench tech trades and boost AI rally: brokerages
  - (2026-06-01) China’s property market shows more positive signs with price, sales upticks

### Local News: St. Louis + Atlanta — 214 new of 230 total
  - (2026-06-01) [St. Louis] Ask Goold: When will Cardinals put money where their rebuild is with extensions, additions?
      A strong series of questions in this weeks Ask the Baseball Writer that range from Nolan Gorman's swing to the lots about the Cardinals' investments.
  - (2026-06-01) [St. Louis] Photos: Hundreds in Maplewood Richmond Heights community rally against deportation of school janitors
      Hundreds of students, teachers and staff in the Maplewood Richmond Heights community rallied against deportation of school janitor Boanerges Flores, of Nicaragua, who was detained by ICE last week.
  - (2026-06-01) [St. Louis] U.S. Rep. Mike Bost of Southern Illinois steers two veterans bills to passage
      One bill would stop Veterans Affairs department from stripping veterans of rights to possess firearms solely because they required help in managing their benefits.
  - (2026-06-01) [St. Louis] Worthy: Pete Crow-Armstrong a perfect fit for new era of Cardinals-Cubs rivalry
      A visit from the Chicago Cubs turned up the volume and intensity in Busch Stadium over weekend, and PCA was a huge part of that atmosphere.
  - (2026-06-01) [St. Louis] Man fatally shot in Bridgeton, 'person of interest' in custody
      The incident happened about 10:30 a.m. Monday at a residence on Taylor Oaks Court, police said.
  - (2026-06-01) [St. Louis] See who was at the May 30 Cardinals vs. Cubs game!
      Photos from the STL Photo Party Roamer at the St. Louis Cardinals vs. Chicago Cubs game on May 30, 2026.

### U.S. Weather + Severe / Climate Outlooks — 129 new of 131 total
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 1:26PM MDT until June 1 at 2:15PM MDT by NWS Cheyenne WY
      SVRCYS The National Weather Service in Cheyenne has issued a * Severe Thunderstorm Warning for... Southwestern Goshen County in southeastern Wyoming... Southern Platte County in southeastern Wyoming... * Until 215 PM MDT…
  - (2026-06-01) [Moderate] Special Weather Statement: Special Weather Statement issued June 1 at 2:25PM CDT by NWS Springfield MO
      At 224 PM CDT, Doppler radar was tracking a strong thunderstorm 7 miles south of West Plains, moving southeast at 15 mph. HAZARD...Wind gusts up to 40 mph and penny size hail. SOURCE...Radar indicated. IMPACT...Gusty win…
  - (2026-06-01) [Severe] Severe Thunderstorm Watch: Severe Thunderstorm Watch issued June 1 at 2:24PM CDT until June 1 at 7:00PM CDT by NWS Birmingham AL
      SEVERE THUNDERSTORM WATCH 261 REMAINS VALID UNTIL 7 PM CDT THIS EVENING FOR THE FOLLOWING AREAS IN ALABAMA THIS WATCH INCLUDES 18 COUNTIES IN CENTRAL ALABAMA BLOUNT CALHOUN CHEROKEE CLAY CLEBURNE ETOWAH FAYETTE JEFFERSON…
  - (2026-06-01) [Severe] Severe Thunderstorm Watch: Severe Thunderstorm Watch issued June 1 at 2:24PM CDT until June 1 at 7:00PM CDT by NWS Birmingham AL
      THE NATIONAL WEATHER SERVICE HAS EXTENDED SEVERE THUNDERSTORM WATCH 261 TO INCLUDE THE FOLLOWING AREAS UNTIL 7 PM CDT THIS EVENING IN ALABAMA THIS WATCH INCLUDES 17 COUNTIES IN CENTRAL ALABAMA AUTAUGA BIBB CHAMBERS CHILT…
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 2:23PM CDT until June 1 at 2:30PM CDT by NWS Birmingham AL
      The storms which prompted the warning have moved out of the area. Therefore, the warning will be allowed to expire. A Severe Thunderstorm Watch remains in effect until 700 PM CDT for central, northwestern and west centra…
  - (2026-06-01) [Severe] Flood Warning: Flood Warning issued June 1 at 12:21PM PDT by NWS Spokane WA
      ...The Flood Warning continues for the following rivers in Washington... Stehekin River at Stehekin affecting Chelan County. For the Stehekin River...including Stehekin...Minor flooding is forecast. * WHAT...Minor floodi…

### Ukraine Theater (total-war monitoring) — 106 new of 266 total
  - (2026-05-31) [FIRMS] thermal anomaly 50.052, 34.889 (FRP 2.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1024Z, FRP 2.7 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.337, 34.366 (FRP 3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1026Z, FRP 3 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.284, 33.032 (FRP 1.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 1.15 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.193, 34.040 (FRP 2.66 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 2.66 MW
  - (2026-05-31) [FIRMS] thermal anomaly 50.181, 34.759 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2237Z, FRP 1.02 MW
  - (2026-06-01) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.

### Ukrainian Internal News (national + local Kyiv) — 72 new of 124 total
  - (2026-06-01) Російські війська атакували південь Одещини: є пошкодження | LEDE: Російська армія 1 червня вдарила по півдню Одеської області, пошкодила цивільну інфраструктуру.] (uk: Російські війська атакували пів…
      Російська армія 1 червня вдарила по півдню Одеської області, пошкодила цивільну інфраструктуру.
  - (2026-06-01) Квартири на матері й клініка дружини: Bihus.Info дослідили майно родини очільника київського БЕБ | LEDE: Журналісти Bihus.Info з'ясували, що мати т. в. о. керівника столичного БЕБ Романа Лисако] (uk:…
      Журналісти Bihus.Info з'ясували, що мати т. в. о. керівника столичного БЕБ Романа Лисаковського купувала нерухомість за нижчими від ринкових цінами, а дружина-співвласниця стоматологічної клініки в Тернополі задекларувал…
  - (2026-06-01) Трамп: Переговори між США та Іраном тривають "у швидкому темпі" | LEDE: Американський президент Дональд Трамп висловився щодо переговорів із Іраном на тлі заяв у ЗМІ щодо їхнього "призупинення"] (uk:…
      Американський президент Дональд Трамп висловився щодо переговорів із Іраном на тлі заяв у ЗМІ щодо їхнього "призупинення".
  - (2026-06-01) Зеленський: Попередження розвідок про масований удар росіян залишаються в силі | LEDE: Президент Володимир Зеленський повідомив, що попередження розвідок щодо російських ударів залишаються в си] (uk:…
      Президент Володимир Зеленський повідомив, що попередження розвідок щодо російських ударів залишаються в силі, росіяни готові до нового масованого удару.
  - (2026-06-01) Трамп: Ізраїльські війська, що прямували до Лівану, повертаються назад | LEDE: Американський президент Дональд Трамп заявив, що ізраїльські війська, які вирушили до Лівану – "вже повертаються н] (uk:…
      Американський президент Дональд Трамп заявив, що ізраїльські війська, які вирушили до Лівану – "вже повертаються назад".
  - (2026-06-01) Трамп заявив, що Іран не попереджав США про зупинку переговорів | LEDE: Президент США Дональд Трамп заявив, що Іран не повідомляв Вашингтон про припинення переговорів, попри повідомлення про ні] (uk:…
      Президент США Дональд Трамп заявив, що Іран не повідомляв Вашингтон про припинення переговорів, попри повідомлення про нібито призупинення діалогу між сторонами.

### Court opinions of consequence (federal & state) — 49 new of 60 total
  - (2026-06-02) Connecticut Supreme Court: Wilmington Savings Fund Society, FSB v. Schulz
  - (2026-06-01) U.S. Supreme Court: Whitton v. Dixon
  - (2026-06-01) Arizona Supreme Court: State of Arizona v. Ricky Alonzo Hippensteel
  - (2026-06-01) U.S. Court of Appeals, 11th Cir.: Gregory Light v. LVNV Funding, LLC
  - (2026-06-01) U.S. Court of Appeals, 10th Cir.: Bonilla-Espinoza v. Blanche
  - (2026-06-01) U.S. Court of Appeals, 8th Cir.: Data Axle, Inc. v. Andrew Nolting

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-01) 424B2 - GS Finance Corp. (0001419828) (Filer)
      filed 2026-06-01 19:27 UTC — Filed: 2026-06-01 AccNo: 0001193125-26-251173 Size: 1 MB
  - (2026-06-01) 424B2 - GOLDMAN SACHS GROUP INC (0000886982) (Filer)
      filed 2026-06-01 19:27 UTC — Filed: 2026-06-01 AccNo: 0001193125-26-251173 Size: 1 MB
  - (2026-06-01) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-01 19:26 UTC — Filed: 2026-06-01 AccNo: 0001918704-26-014933 Size: 533 KB
  - (2026-06-01) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-01 19:26 UTC — Filed: 2026-06-01 AccNo: 0001918704-26-014933 Size: 533 KB
  - (2026-06-01) 497 - ARTISAN PARTNERS FUNDS INC (0000935015) (Filer)
      filed 2026-06-01 19:26 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011797 Size: 390 KB
  - (2026-06-01) 497 - BlackRock ETF Trust (0001761055) (Filer)
      filed 2026-06-01 19:25 UTC — Filed: 2026-06-01 AccNo: 0001193125-26-251165 Size: 503 KB

### Paper Trading Scorecard — 34 new of 139 total
  - (2026-06-01) [Polymarket] Will Alberta join the US?
      This market will resolve to "Yes" if it is officially announced that Alberta will come under US sovereignty, or if Alberta officially comes under US sovereignty, by December 31, 2026, 11:59 PM ET. Otherwise this market w…
  - (2026-06-01) [Polymarket] Will Gideon Sa’ar be the next Prime Minister of Israel?
      Legislative elections are schedule to be held in Israel on October 27, 2026. This market will resolve to the next individual who is officially appointed and sworn in as Prime Minister of Israel following the 2026 parliam…
  - (2026-06-01) [Polymarket] Will Montenegro win on 2026-06-01?
      In the upcoming game, scheduled for June 1, 2026 If Montenegro wins, this market will resolve to "Yes". Otherwise, this market will resolve to "No". If the game is postponed, this market will remain open until the game h…
  - (2026-06-01) [Polymarket] Will Israel annex Gaza territory by June 30 2026?
      This market will resolve to "Yes" if Israel officially annexes any territory in the Gaza Strip by June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". Annexation is defined as an official declaration…
  - (2026-06-01) [Polymarket] Will Jordan Bardella win the 2027 French presidential election?
      The next French presidential election is currently expected to be held around April 2027. This market pertains to the outcome of the next French presidential election, regardless of whether it follows the scheduled end o…
  - (2026-06-01) [Polymarket] Israel announces Lebanon ceasefire extension by June 7?
      This market will resolve to “Yes” if Israel officially announces another extension of the ceasefire agreement between Israel and Hezbollah announced on April 16, 2026, defined as a publicly announced commitment to halt d…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-06-01) PAT191 (United States)
      icao24: adfeda · position: (43.3738, -78.6963) · alt: 403m · 282km/h
  - (2026-06-01) PAT303 (United States)
      icao24: adfee0 · position: (33.5125, -93.1967) · alt: 7612m · 491km/h
  - (2026-06-01) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (43.6024, 9.0204) · alt: 10058m · 874km/h
  - (2026-06-01) CFC669 (Canada)
      icao24: c2c31d · position: (31.3245, -93.9934) · alt: 7924m · 525km/h
  - (2026-06-01) PAT480 (United States)
      icao24: adfe49 · position: (40.3139, -78.1097) · alt: 2103m · 348km/h
  - (2026-06-01) CFC01 (Canada)
      icao24: c2c1fb · position: (45.2718, -75.9142) · alt: 2887m · 538km/h

### Markets snapshot — 21 new of 21 total
  - (2026-06-01) [US equities] S&P 500 (SPY): 759.69 ▲ +0.42%
      close 759.69 · chg +3.21 (+0.42%) · day range 754.69–760.28
  - (2026-06-01) [US equities] Nasdaq 100 (QQQ): 744.04 ▲ +0.78%
      close 744.04 · chg +5.73 (+0.78%) · day range 735.99–745.65
  - (2026-06-01) [US equities] Russell 2000 (IWM): 289.64 ▼ -0.27%
      close 289.64 · chg -0.79 (-0.27%) · day range 286.27–290.61
  - (2026-06-01) [Intl equities] MSCI EAFE (EFA): 104.59 ▼ -0.20%
      close 104.59 · chg -0.21 (-0.20%) · day range 103.60–104.92
  - (2026-06-01) [EM equities] MSCI EM (EEM): 70.24 ▲ +2.39%
      close 70.24 · chg +1.64 (+2.39%) · day range 69.13–70.51
  - (2026-06-01) [China equities] China large-cap (FXI): 35.39 ▲ +0.97%
      close 35.39 · chg +0.34 (+0.97%) · day range 35.00–35.45

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-06-01) Roland Garros ATP: Frances Tiafoe vs Matteo Arnaldi
      yes price: 44% · 24h volume: $4,033,422 · resolves 2026-06-08
  - (2026-06-01) Roland Garros ATP: Juan Manuel Cerundolo vs Matteo Berrettini
      yes price: 0% · 24h volume: $2,991,737 · resolves 2026-06-08
  - (2026-06-01) Will Uruguay win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,728,414 · resolves 2026-07-20
  - (2026-06-01) Will Mexico win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,675,517 · resolves 2026-07-20
  - (2026-06-01) Will Germany win the 2026 FIFA World Cup?
      yes price: 6% · 24h volume: $1,751,391 · resolves 2026-07-20
  - (2026-06-01) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,720,454 · resolves 2026-07-20

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 105 total
  - (2026-06-01) [OFAC] Publication of Introduction to OFAC Guide - Office of Foreign Assets Control (.gov)
      Publication of Introduction to OFAC Guide Office of Foreign Assets Control (.gov)
  - (2026-06-01) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control, and FTI Consulting, Inc. - Office of Foreign Assets Control (.gov)
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control, and FTI Consulting, Inc. Office of Foreign Assets Control (.gov)
  - (2026-06-01) [OFAC] Introduction to the Office of Foreign Assets Control - Office of Foreign Assets Control (.gov)
      Introduction to the Office of Foreign Assets Control Office of Foreign Assets Control (.gov)
  - (2026-06-01) [BIS Entity List] page checksum 0220879c7d79
      Page content hash: 0220879c7d79. Compare with prior day's hash to detect updates.

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-06-01) [Marginal Revolution] The chimera of universal coverage in a large, diverse country
      Our findings suggest that policies intended to subsidize health insurance of higher income groups, for example, the enhanced premium subsidies, are far less efficient than policies intended to further expand public insur…
  - (2026-06-01) [Marginal Revolution] Monday assorted links
      1. Progress Ireland. 2. Some new results on tatonnement? 3. The new Paul McCartney album is his best since the 2004 Chaos and Creation in the Backyard. Here is a song by song analysis. For an 83-year-old, it is an astoni…
  - (2026-06-01) [Marginal Revolution] Europe Demands Family Dynasties
      In the US, someone with wealth is free to give it away more or less as they see fit (spousal claims excepted, which partly reflect marital co-ownership). In much of Europe, however, there is forced heirship–a large fract…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 16 total
  - (2026-06-01) CVE-2024-21182 · Oracle WebLogic Server: Oracle WebLogic Server Unspecified Vulnerability
      vendor: Oracle · product: WebLogic Server · CISA remediation by 2026-06-04

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=30, 14d-median=30; carrying terms: provide, navigable, certain, establishing, events, potential, proposing, enforcement, model, actions, proposes, affected
- state_bills: today=0, 7d-median=78, 14d-median=78
- state_news: today=361, 7d-median=708, 14d-median=708; carrying terms: issue, provide, counted, based, addiction, ballots, massive, potential, develop, topeka, hopes, kentucky
- local_news: today=230, 7d-median=247, 14d-median=247; carrying terms: watch, night, illinois, party, everything, injured, power, lxtfbmqu, cbmiwkfvx, senate, leads, water
- foreign_news: today=859, 7d-median=864, 14d-median=864; carrying terms: connolly, improper, triggered, issue, ceremony, provide, guideline, backed, speaks, variables, natural, female
- chinese_internal: today=258, 7d-median=273, 14d-median=273; carrying terms: politics, cbmiw, cbmixkfvx, google, cbmizefvx, rally, people, https, cbmibkfvx, articles, cbmiaefvx, record
- russian_internal: today=835, 7d-median=968, 14d-median=968; carrying terms: international, russian, media, centcom, politico, https, novaya, error, axios, associated, istories, europe
- ukrainian_internal: today=124, 7d-median=124, 14d-median=124; carrying terms: infrastructure, triggered, intelligence, european, total, hitting, systems, based, partners, massive, injured, power
- ukraine_theater: today=266, 7d-median=336, 14d-median=336; carrying terms: hsdxg, eywjf, nwnxo, yswvhcxrwbk, lyjnkwmexqwxg, dkyxbbtjdouuf, jtdfjkbejyshqznlz, bntdrsou, clpttffsshz, hjqxvbogthwepvzei, procured, tfzlmee
- paper_bets: today=139, 7d-median=140, 14d-median=140; carrying terms: climate, restrictions, successor, arizona, price, candidate, specific, total, goals, speed, human, james
- weather: today=131, 7d-median=119, 14d-median=119; carrying terms: details, indianapolis, eureka, areas, especially, perry, watch, occur, night, lowlands, potential, river
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=78, 7d-median=79, 14d-median=79; carrying terms: italy, australia, kospi, canada, sugar, nikkei, crypto, index, lumber, price, france, germany
- sanctions_procurement: today=105, 7d-median=98, 14d-median=98; carrying terms: provide, facilitate, terrorist, areas, systems, member, ddewdvfioetfmu, review, certain, svjynuppvdhkvkrfu, events, ujgxrwtvbs
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiverquant, quantitative, quiver, https, congresstrading, error, unauthorized, httperror
- billionaires: today=0, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: transport, bondi, blanche, employee, vasquez, america, fernandez, group, veterans, robert, kenneth, flowers
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, accno, reporting, financial, trust, group, chase, jpmorgan, filer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, johnson, booker, jonathan, ocasio, talarico, congress, raised, ossoff, james, joseph, cortez
- gdelt_regions: today=0, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=0, 14d-median=4; carrying terms: position, ground
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: windows, premise, vulnerability, injection, drupal, langflow, origin, trend, directx, based, explorer, acrobat
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, world, continue, price, permanent, peace, volume, ceasefire, bitcoin, ivory, garros, roland
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, revolution, policy, conversable, https, story, class, marginal, assorted, marginalrevolution, links, recipients
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: maxwell, baumgartner, kweisi, intelligence, mario, babin, lucas, advisor, byron, gilbert, wasserman, housing
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, either, consensus, placed, module, claude, paper, evidence, sufficient, identify, markets, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*