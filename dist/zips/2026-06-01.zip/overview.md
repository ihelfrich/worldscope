# WORLDSCOPE morning brief — 2026-06-01

## Headline
2577 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 30 total
  (no new items today)

### State Legislative Action — 0 new of 140 total
  (no new items today)

### State-Level News — 172 new of 276 total
  - (2026-06-01) [California] Long after protests ended, this interfaith group rallies to remember LA immigrants taken by ICE
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052726-godmothers-of-the-disappeared-SR-GETTY-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size s
  - (2026-06-01) [California] Why a yearslong fight over gambling is good news for California politicians
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052126-Cardroom-Protest-MG-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-06-01) [California] More candidates are using their personal wealth to campaign than ever before. Should voters care?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/041426_gov-candidate-forum_FG_49-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-06-01) [Arkansas] Migrants detained at ICE facilities launch hunger strikes to protest conditions
      In at least four states, migrants detained in ICE facilities have launched hunger strikes in recent weeks to protest the conditions in which they are being held. An ongoing hunger and labor strike at the 1,000-bed Delane
  - (2026-06-01) [Arkansas] How Trump’s giant ‘slush fund’ sparked lawsuits, roiled Republicans and revived Jan. 6
      WASHINGTON — The Trump administration’s nearly $1.8 billion “anti-weaponization” fund has attracted scrutiny for its corruption potential, even splitting congressional Republicans who rarely confront President Donald Tru
  - (2026-06-01) [Arkansas] Arkansas Advocate staff win multiple state journalism awards
      Arkansas Advocate staff won five first-place awards, including for its series exploring overcrowding in the state prison system, in the 2026 Arkansas Press Women Professional Communications Contest over the weekend. The 
  - (2026-06-01) [Arkansas] The feds have embraced medical marijuana. Now what?
      The U.S. Department of Justice’s recent decision to downgrade the drug classification for medical cannabis will help medical marijuana businesses. Companies will be able to claim some federal tax benefits. New research c
  - (2026-05-31) [Arkansas] Flesh-eating screwworms head for American livestock
      Southern states are bracing for a potential invasion of the New World screwworm that could disrupt livestock markets and raise already high meat prices. So far, the parasite has yet to land in the United States, but it h

### Local News: St. Louis + Atlanta — 135 new of 184 total
  - (2026-06-01) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-06-01) [St. Louis] Dr. Brown’s sues Dr. Brown’s as the bottle company seeks to stop the soda company’s trademark claim
      <p>A maker of classic sodas in cans with old-timey designs is facing off against the maker of gold-standard, anti-colic baby bottles. The issue? That consumers might confuse one Dr. Brown&#8217;s for another.  Since 1869
  - (2026-06-01) [St. Louis] Developer has 9 days to come up with a plan to save Euclid School
      <p>Developer Benjamin Anderson says he’s been given until June 9 to come up with a plan to save Euclid School—three years after he first made an offer to buy it but got “ghosted” by the district and what may be one last 
  - (2026-06-01) [St. Louis] UnCommon Energy wants to solve power challenges for farms and rural America
      <p>Over the past few years, utilities across the country have won the right to steadily increase what they charge for power, and they’re likely to keep raising rates in the coming years too. It’s a pinch for consumers ev
  - (2026-05-31) [St. Louis] Lou’s Clues – 6/1/2026
      <p>Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it 
  - (2026-06-01) [St. Louis] St. Louis librarians share their top summer reads for 2026
  - (2026-06-01) [St. Louis] New Missouri guidebook highlights over 80 scenic sites to explore
  - (2026-06-01) [St. Louis] Here’s what St. Louis restaurants opened and closed in May 2026

### International News + Multilateral Institutions — 605 new of 832 total
  - (2026-06-01) [India] TMC forgery case filed by 2 MLAs, says Suvendu Adhikari; Mamata expels them
  - (2026-06-01) [India] 'All major points settled': First tranche of India-US trade deal soon, says Piyush Goyal
  - (2026-06-01) [India] Twisha ‘dowry death’ case: CBI recreates crime scene with mother-in-law Giribala, husband Samarth in Bhopal
  - (2026-06-01) [India] Monkey's cash heist at UP court:  ₹2 lakh bag snatched, currency notes rain from tree | Video
  - (2026-06-01) [India] Fire rips through fish market in Odisha’s Cuttack, guts over 30 shops, bank
  - (2026-06-01) [India] Manipur: Minors caught in crossfire pick up guns, bombs, lose their innocence
  - (2026-06-01) [India] Govt to retain AI labelling rule, bring schedule for advisories
  - (2026-06-01) [India] ‘Beware of pickpockets’: Rahul Gandhi slams CBSE, Modi govt over re-evaluation process

### Chinese Internal News — 223 new of 250 total
  - (2026-05-30) [TITLE: 美防长在香会对华“降调”，对欧“施压” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9HdWZfQW1meFBGUmZtRVk3WTB0OXlqVnBWZ0tkVWY3cHRfRlk3NVBMWkc3SjA2N0NGaFZyMy16WGdaWng1WFkxX1ZZRkFLTlZxc] (zh: 美防长在香会对华“降调”，对欧“施压” - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9HdWZfQW1meFBGUmZtRVk3WTB0OXlqVnBWZ0tkVWY3cHRfRlk3NVBMWkc3SjA2N0NGaFZyMy16WGdaWng1WFkxX1ZZRkFLTlZxc2pDTVU1THlHVmlzZW5RWEQ4VGNDUmFDamc?oc=5" target="_blank">美防长在
  - (2026-06-01) [TITLE: 多档综艺接连出现后期P安全带 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFA4bnpzRnFPYXRqM0RaSGNadjFKbDVTN19ScjdMTnYyNTBkOGxkbHpuSnhJbkVjN3dEWmJlVzMwT0JneVRheHFkaG5hT3YxZU9xekpxWH] (zh: 多档综艺接连出现后期P安全带 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFA4bnpzRnFPYXRqM0RaSGNadjFKbDVTN19ScjdMTnYyNTBkOGxkbHpuSnhJbkVjN3dEWmJlVzMwT0JneVRheHFkaG5hT3YxZU9xekpxWHEtOG5tbklaU3pzeXNoNlZ3Zw?oc=5" target="_blank">多档综艺接连出现后
  - (2026-06-01) [TITLE: 首部女子反恐特战队电影？战队全员女性？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBBSnZGTlo1U2NQRWZaa3B3dy1aUDBEMFNmYVJEUUV5UG5aNHVRNGQwaFZTZFlRLTF3RUV4RDVRM3JwRVZBYnNaRExBUU9oTVdDel] (zh: 首部女子反恐特战队电影？战队全员女性？ - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBBSnZGTlo1U2NQRWZaa3B3dy1aUDBEMFNmYVJEUUV5UG5aNHVRNGQwaFZTZFlRLTF3RUV4RDVRM3JwRVZBYnNaRExBUU9oTVdDelJFTHNaNVNpV0E?oc=5" target="_blank">首部女子反恐特战队电影？战队全员女性？</a>&
  - (2026-05-31) [TITLE: 智利缉毒犬在官方仪式现场，突然扑咬海军中将裤兜…-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1iSUJjUDhSaTZTeHd5QkVvekp1ZHdxdUczVGtPbjlkTmFESFVsV05wQUtzM1RZcFBPN1dZQ24xamU3c1hOeVFjRGN] (zh: 智利缉毒犬在官方仪式现场，突然扑咬海军中将裤兜…-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1iSUJjUDhSaTZTeHd5QkVvekp1ZHdxdUczVGtPbjlkTmFESFVsV05wQUtzM1RZcFBPN1dZQ24xamU3c1hOeVFjRGNyQ1VhbnJtN05hRWxKaGNsWHdKQnVGUWl0VHNNclBXcFE?oc=5" target="_blank">智利缉毒
  - (2026-06-01) [TITLE: 托举孩子进山姆的女子，她开心的说自己的山姆签证下来了 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1vY0Jfc2pwTk9ubHFyRUZIaXNWUmlMd1Q1cUtyUGRuUUhxVXFnRDJyMjBDSC15QU10YmNMYXVqVUhVZG8zcjNNUDR4Q2I] (zh: 托举孩子进山姆的女子，她开心的说自己的山姆签证下来了 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1vY0Jfc2pwTk9ubHFyRUZIaXNWUmlMd1Q1cUtyUGRuUUhxVXFnRDJyMjBDSC15QU10YmNMYXVqVUhVZG8zcjNNUDR4Q2I0MnA1Q1c3dmNJbGpHZWs?oc=5" target="_blank">托举孩子进山姆的女子，她开心的说自己的山姆签证下
  - (2026-06-01) [TITLE: 带狗去逛瓷器市集，结果一个不小心，把摊主的货品搞碎一地 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE4wU1NXMHlBVi0tWVYwcUpiaVFsVFd3S1N2bGlkSUdrbEFyUy1KMUhWRm80SzkzV21Sd0lqQUUya0VGQ29hLU9TTUFlZF] (zh: 带狗去逛瓷器市集，结果一个不小心，把摊主的货品搞碎一地 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE4wU1NXMHlBVi0tWVYwcUpiaVFsVFd3S1N2bGlkSUdrbEFyUy1KMUhWRm80SzkzV21Sd0lqQUUya0VGQ29hLU9TTUFlZFdRVmxNN21TemxLaWlPU0k?oc=5" target="_blank">带狗去逛瓷器市集，结果一个不小心，把摊主的货品搞
  - (2026-06-01) [TITLE: 不看历史仇恨，压抑、排外…日本这样的社会到底有何吸引力？怎么那么多人崇日啊 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5HdUFNNGs3SW15cGtGaHhyT1hydGpXUVRBS1FjdV9WdFVzYjBuVDh3dV9UMmNmdkR4Z2FMc2Q2aEh6VHpI] (zh: 不看历史仇恨，压抑、排外…日本这样的社会到底有何吸引力？怎么那么多人崇日啊 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5HdUFNNGs3SW15cGtGaHhyT1hydGpXUVRBS1FjdV9WdFVzYjBuVDh3dV9UMmNmdkR4Z2FMc2Q2aEh6VHpIR3BlVEFNazRkbG1CcHdrMzd4ZEluNjg?oc=5" target="_blank">不看历史仇恨，压抑、排外…日本这样的社会到底有何
  - (2026-06-01) [TITLE: “我儿子5岁就能来山姆，我30多岁才能来”，如何看待宝妈玩山姆梗遭网暴？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1RYTFWT3lRUXhneE5CWERrVExEaVR0TWpGdm95NXdaZk5pVlpMMXB1RnRpQ0l6Q1F4bE9RaFNmbnlkRHNwR] (zh: “我儿子5岁就能来山姆，我30多岁才能来”，如何看待宝妈玩山姆梗遭网暴？ - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1RYTFWT3lRUXhneE5CWERrVExEaVR0TWpGdm95NXdaZk5pVlpMMXB1RnRpQ0l6Q1F4bE9RaFNmbnlkRHNwRE9lWk8zRlFhWE9zOG9SOU1HZEdMUkE?oc=5" target="_blank">“我儿子5岁就能来山姆，我30多岁才能来”，如何

### Russian Internal News (state + in-exile) — 636 new of 792 total
  - (2026-06-01) [TITLE: Nvidia выходит на рынок ноутбуков на базе Windows. Компания выпустит для них суперчип RTX Spark | LEDE: <p>Компания Nvidia, известная как производитель графических процессоров, выпустит новый с] (ru: Nvidia выходит на рынок ноутбуков на базе Windows. Компания выпустит для них суп)
      <p>Компания Nvidia, известная как производитель графических процессоров, выпустит новый суперчип RTX Spark, который появится в ноутбуках сторонних производителей осенью 2026 года. Об этом на выставке Computex в Тайбэе со
  - (2026-06-01) [TITLE: «Снял барахло — переделывай». Мединский предложил ввести контроль качества кинофильмов — как при советской цензуре | LEDE: <p>В российском кино не хватает контроля качества со стороны государст] (ru: «Снял барахло — переделывай». Мединский предложил ввести контроль качества киноф)
      <p>В российском кино не хватает контроля качества со стороны государства, заявил в интервью журналу «Эксперт» помощник президента РФ, бывший министр культуры Владимир Мединский. <p>
  - (2026-06-01) [TITLE: Переезд (в новую страну, город или даже квартиру) — большой стресс для ребенка. Как помочь ему с этим справиться? Рассказывает Дима Зицер, педагог и автор книги «Любовь в условиях турбулентност] (ru: Переезд (в новую страну, город или даже квартиру) — большой стресс для ребенка. )
      <p>В 2022 году, когда после начала полномасштабной войны России с Украиной тысячи родителей с детьми были вынуждены покинуть свои дома, «Медуза» выпустила большую инструкцию о том, как помочь ребенку адаптироваться к нов
  - (2026-06-01) [TITLE: «Обсессия» — копеечный хоррор ютьюбера Карри Баркера стал главным прокатным хитом. Главные пугалки в нем — не маньяки или монстры, а любовь и ответственность | LEDE: <p>В мировой прокат вышла «] (ru: «Обсессия» — копеечный хоррор ютьюбера Карри Баркера стал главным прокатным хито)
      <p>В мировой прокат вышла «Обсессия» (Obsession) — хоррор 26-летнего ютьюб-блогера и режиссера Карри Баркера. Это уникальное событие для мира кино: фильм стоил меньше миллиона долларов, но за первые недели проката собрал
  - (2026-06-01) [TITLE: «Мама, меня посадят?». В Сыктывкаре школьники играли на инсталляции из кубиков ко Дню Победы. Теперь, как утверждают родители, власти пытаются забрать детей из семей | LEDE: <p>Полиция Сыктывка] (ru: «Мама, меня посадят?». В Сыктывкаре школьники играли на инсталляции из кубиков к)
      <p>Полиция Сыктывкара потребовала изъять из семей троих школьников из-за того, что они играли на инсталляции ко Дню Победы. Об этом рассказали мамы двоих детей, Анна Савельева и Ирина Калибабчук, в публикациях во «ВКонта
  - (2026-06-01) [TITLE: Пашинян отказался проводить в Армении референдум о выборе между Европейским и Евразийским союзами. Этого требовали Россия, Беларусь, Казахстан и Кыргызстан | LEDE: <p>В настоящее время нет осно] (ru: Пашинян отказался проводить в Армении референдум о выборе между Европейским и Ев)
      <p>В настоящее время нет оснований для проведения в Армении референдума о выборе между Евросоюзом и Евразийским экономическим союзом (ЕАЭС), заявил премьер-министр страны Никол Пашинян.<p>
  - (2026-06-01) [TITLE: Россия вводит новые ограничения на продукцию из Армении. В этот раз запретили импорт рыбы | LEDE: <p>Почти вся живая рыба и рыбная продукция, поставляемая Арменией, попала под запрет в России. ] (ru: Россия вводит новые ограничения на продукцию из Армении. В этот раз запретили им)
      <p>Почти вся живая рыба и рыбная продукция, поставляемая Арменией, попала под запрет в России. О новых ограничениях сообщил Россельхознадзор.<p>
  - (2026-06-01) [TITLE: Александр Запесоцкий снова стал ректором университета профсоюзов в Петербурге. Его обвиняли в обогащении за счет вуза | LEDE: <p>Александр Запесоцкий восстановлен в должности ректора Санкт-Пете] (ru: Александр Запесоцкий снова стал ректором университета профсоюзов в Петербурге. Е)
      <p>Александр Запесоцкий восстановлен в должности ректора Санкт-Петербургского гуманитарного университета профсоюзов (СПбГУП), сообщила «Фонтанка». Это произошло после того, как Арбитражный суд отменил обеспечительные мер

### Ukrainian Internal News (national + local Kyiv) — 60 new of 112 total
  - (2026-06-01) [TITLE: Головний соціолог Путіна забезпечив розкішне життя своїй дружині | LEDE: Нова дружина голови Всеросійського центру вивчення громадської думки Валерія Федорова, який вже 2 десятиліття малює росі] (uk: Головний соціолог Путіна забезпечив розкішне життя своїй дружині)
      Нова дружина голови Всеросійського центру вивчення громадської думки Валерія Федорова, який вже 2 десятиліття малює російському правителю "правильні рейтинги", Дар'я Васильєва носить дорогі сумки та прикраси, подорожує с
  - (2026-06-01) [TITLE: Травень у Києві не обійшовся без температурних рекордів | LEDE: Травень у столиці України встановив три температурні рекорди.] (uk: Травень у Києві не обійшовся без температурних рекордів)
      Травень у столиці України встановив три температурні рекорди.
  - (2026-06-01) [TITLE: У Путіна обурились затриманням танкера "тіньового флоту" РФ та назвали це "піратством" | LEDE: Пєсков заявив, що дії Франції щодо російського танкера Tagor межують з піратством і незаконні.] (uk: У Путіна обурились затриманням танкера "тіньового флоту" РФ та назвали це "пірат)
      Пєсков заявив, що дії Франції щодо російського танкера Tagor межують з піратством і незаконні.
  - (2026-06-01) [TITLE: Пастка "м’якої сили": як РФ вербує іноземців з країн Африки на війну проти України | LEDE: Розслідування про вербування громадян Африки та інших країн до армії РФ, використані схеми та ризики д] (uk: Пастка "м’якої сили": як РФ вербує іноземців з країн Африки на війну проти Украї)
      Розслідування про вербування громадян Африки та інших країн до армії РФ, використані схеми та ризики для іноземців.
  - (2026-06-01) [TITLE: В омбудсмена перевіряють погоню на авто ТЦК за чоловіком на Волині | LEDE: На Волині омбудсмен перевіряє ДТП із ТЦК: авто цивільних злетіло в кювет. Триває розслідування органів влади.] (uk: В омбудсмена перевіряють погоню на авто ТЦК за чоловіком на Волині)
      На Волині омбудсмен перевіряє ДТП із ТЦК: авто цивільних злетіло в кювет. Триває розслідування органів влади.
  - (2026-06-01) [TITLE: Росіяни скинули три авіабомби на багатоповерхівки в Дружківці: 5 потерпілих | LEDE: П'ять мирних мешканців постраждали в результаті удару російських окупаційних військ по Дружківці Донецької об] (uk: Росіяни скинули три авіабомби на багатоповерхівки в Дружківці: 5 потерпілих)
      П'ять мирних мешканців постраждали в результаті удару російських окупаційних військ по Дружківці Донецької області.
  - (2026-06-01) [TITLE: Корупція на закупівлі критичного обладнання: ексзаступник міністра отримав нову підозру | LEDE: За процесуального керівництва прокурора САП детективи Національного антикорупційного бюро повідом] (uk: Корупція на закупівлі критичного обладнання: ексзаступник міністра отримав нову )
      За процесуального керівництва прокурора САП детективи Національного антикорупційного бюро повідомили про нову підозру колишньому заступнику міністра розвитку громад, територій та інфраструктури Василю Лозинському й посад
  - (2026-06-01) [TITLE: Пашинян відмовився проводити у Вірменії референдум щодо вибору між ЄС та ЄАЕС | LEDE: Прем'єр Вірменії заявив, що референдум щодо вибору між ЄС та ЄАЕС поки недоцільний.] (uk: Пашинян відмовився проводити у Вірменії референдум щодо вибору між ЄС та ЄАЕС)
      Прем'єр Вірменії заявив, що референдум щодо вибору між ЄС та ЄАЕС поки недоцільний.

### Ukraine Theater (total-war monitoring) — 94 new of 266 total
  - (2026-05-31) [FIRMS] thermal anomaly 50.052, 34.889 (FRP 2.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1024Z, FRP 2.7 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.337, 34.366 (FRP 3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1026Z, FRP 3 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.284, 33.032 (FRP 1.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 1.15 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.193, 34.040 (FRP 2.66 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 2.66 MW
  - (2026-05-31) [FIRMS] thermal anomaly 50.181, 34.759 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2237Z, FRP 1.02 MW
  - (2026-06-01) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2017-06-06) [Liveuamap] Lebanon news on live map - lebanon.liveuamap.com - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMiREFVX3lxTE9ldllvQVZJdkFSY1VwVEdEMTJ0YVI0SHA5QzJDZGNrcnJCNk1wbVYtT0FXRmdZN1d6cGxNbG1CZnIxT1B1?oc=5" target="_blank">Lebanon news on live map - lebanon.liveuamap.com</a>&nb
  - (2026-05-31) [Liveuamap] Explosions were reported in Zaporizhzhia - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMihwFBVV95cUxQckotbWdFc3l1TTYweG1BV19CemFIQUF5Z0ktNkY3cTV2ZUtlaXJ6eUlQTHV2RGw3T01wcVp1c1hBbEpHUkVGX0FwbFRJM3B5VE80MXBDU2F1MFFJX0lKY1VoeENpamhtWmNHQmdjdmFiVjBrTWlhNDRyMWNwaE

### Paper Trading Scorecard — 28 new of 135 total
  - (2026-06-01) [Polymarket] Will there be between 20 and 40 average daily transits of the Strait of Hormuz on May 31?
      This market will resolve according to the 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for May 31, 2026.

If the reported value falls exactly between two
  - (2026-06-01) [Polymarket] Will Russia enter Orikhiv by June 30?
      This market will resolve to “Yes” if, according to the ISW map, Russia captures any territory of Orikhiv by June 30, 2026, at 11:59 PM ET.

Territory will be considered captured if any part of Orikhiv is shaded under a b
  - (2026-06-01) [Polymarket] Will Gen.G Esports win the LCK 2026 season playoffs?
      This market will resolve according to the winner of the League of Legends Champions Korea (LCK) 2026 season playoffs.

If the 2026 LCK season is postponed after December 31, 2026 11:59 PM ET, canceled, or a winner has no
  - (2026-06-01) [Polymarket] Will Cătălin Predoiu be the next Prime Minister of Romania?
      This market will resolve to the next individual who officially assumes the office of Prime Minister of Romania by December 31, 2027, 11:59 PM ET.

To count for resolution, the individual must be formally appointed by the
  - (2026-06-01) [Manifold] Daily Coinflip
  - (2026-06-01) [Manifold] Next James Bond officially announced before end of June 2026?
  - (2026-06-01) [Manifold] Resolves to floor(sqrt(traders)) mod 2
  - (2026-06-01) [Manifold] Will The Amazing Digital Circus: The Last Act make over $100 million at the worldwide box office?

### U.S. Weather + Severe / Climate Outlooks — 125 new of 127 total
  - (2026-06-01) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued June 1 at 8:31AM EDT until June 1 at 8:00PM EDT by NWS Newport/Morehead City NC
      * WHAT...Dangerous rip currents.

* WHERE...The beaches from Duck to Cape Lookout.

* WHEN...Until 8 PM EDT this evening.

* IMPACTS...Rip currents can sweep even the best swimmers away
from shore into deeper water.

* A
  - (2026-06-01) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-01) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued June 1 at 5:23AM PDT until June 1 at 9:00AM PDT by NWS San Francisco CA
      * WHAT...Visibility down to a quarter to half an mile in dense fog.

* WHERE...Southern Monterey Bay and the Big Sur Coast.

* WHEN...Until 9 AM PDT this morning.

* IMPACTS...Low visibility could make driving conditions
  - (2026-06-01) [Moderate] Special Weather Statement: Special Weather Statement issued June 1 at 4:22AM AKDT by NWS Anchorage AK
      A front approaching the area will bring gusty northeast winds
along the Northern Bristol Bay Coast beginning today. The
strongest winds, up to 45 mph are expected to occur this afternoon
and evening before winds slowly d
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 7:19AM CDT until June 1 at 8:00AM CDT by NWS Paducah KY
      SVRPAH

The National Weather Service in Paducah has issued a

* Severe Thunderstorm Warning for...
Southwestern Jackson County in southern Illinois...
Northeastern Bollinger County in southeastern Missouri...
Perry Count
  - (2026-06-01) [Moderate] Special Weather Statement: Special Weather Statement issued June 1 at 7:16AM CDT by NWS Memphis TN
      At 716 AM CDT, Doppler radar was tracking a strong thunderstorm over
Southeast Memphis, or near Germantown, moving east at 30 mph.

HAZARD...Wind gusts up to 40 mph and nickel size hail.

SOURCE...Radar indicated.

IMPAC
  - (2026-06-01) [Moderate] Special Weather Statement: Special Weather Statement issued June 1 at 7:09AM CDT by NWS Paducah KY
      At 709 AM CDT, Doppler radar was tracking strong thunderstorms along
a line extending from near Du Quoin to Womac. Movement was southeast
at 50 mph.

HAZARD...Wind gusts up to 50 mph.

SOURCE...Radar indicated.

IMPACT..
  - (2026-06-01) [Moderate] Special Weather Statement: Special Weather Statement issued June 1 at 6:08AM MDT by NWS Goodland KS
      At 608 AM MDT, Doppler radar was tracking a strong thunderstorm near
Burlington, moving northeast at 15 mph.

HAZARD...Wind gusts up to 40 mph and penny size hail.

SOURCE...Radar indicated.

IMPACT...Gusty winds could k

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 101 total
  - (2026-06-01) [BIS Entity List] page checksum 0220879c7d79
      Page content hash: 0220879c7d79. Compare with prior day's hash to detect updates.

### Congressional STOCK Act Trades (House + Senate) — 39 new of 39 total
  - (2026-05-15) [House] David J. Taylor (R): Purchase PH ($1,001 - $15,000) (excess -4.5% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: PH (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase PH ($1,001 - $15,000) (excess -4.5% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: PH (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase MEDP ($1,001 - $15,000) (excess +5.3% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: MEDP (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclo
  - (2026-05-15) [House] David J. Taylor (R): Purchase MEDP ($1,001 - $15,000) (excess +5.3% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: MEDP (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclo
  - (2026-05-15) [House] David J. Taylor (R): Purchase HD ($1,001 - $15,000) (excess +4.2% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: HD (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase HD ($1,001 - $15,000) (excess +4.2% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: HD (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase T ($1,001 - $15,000) (excess +0.8% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: T (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosur
  - (2026-05-15) [House] David J. Taylor (R): Sale AAPL ($1,001 - $15,000) (excess +1.6% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: AAPL (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosure

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal & state) — 41 new of 60 total
  - (2026-06-02) Connecticut Supreme Court: Wilmington Savings Fund Society, FSB v. Schulz
  - (2026-05-29) U.S. Court of Appeals, D.C. Cir.: Global Voice Group SA v. Republic of Guinea
  - (2026-05-29) U.S. Court of Appeals, D.C. Cir.: ModernWest Longmont, LLC v. FAA
  - (2026-05-29) U.S. Court of Appeals, D.C. Cir.: United States v. Raul Flores-Hernandez
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: Fahirri Dannah v. City of Grand Rapids
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: Julie Schulz Halbower v. Hiscox Syndicate 33 of Lloyd's of London
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: Odinaka Ethelberth Nwosu v. Todd Blanche
  - (2026-05-29) U.S. Court of Appeals, 6th Cir.: United States v. Radu Miclaus

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-01) 497K - T. Rowe Price Institutional Income Funds, Inc. (0001169187) (Filer)
      filed 2026-06-01 12:31 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011735 Size: 5 KB
  - (2026-06-01) 497K - T. Rowe Price High Yield Fund, Inc. (0000754915) (Filer)
      filed 2026-06-01 12:31 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011734 Size: 5 KB
  - (2026-06-01) 497K - T. Rowe Price Exchange-Traded Funds, Inc. (0001795351) (Filer)
      filed 2026-06-01 12:31 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011733 Size: 4 KB
  - (2026-06-01) 497 - T. Rowe Price Exchange-Traded Funds, Inc. (0001795351) (Filer)
      filed 2026-06-01 12:31 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011732 Size: 6 KB
  - (2026-06-01) 497 - T. Rowe Price High Yield Fund, Inc. (0000754915) (Filer)
      filed 2026-06-01 12:31 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011732 Size: 6 KB
  - (2026-06-01) 497K - T. Rowe Price High Yield Fund, Inc. (0000754915) (Filer)
      filed 2026-06-01 12:31 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011731 Size: 6 KB
  - (2026-06-01) 497 - T. Rowe Price Exchange-Traded Funds, Inc. (0001795351) (Filer)
      filed 2026-06-01 12:31 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011730 Size: 4 KB
  - (2026-06-01) 497 - T. Rowe Price Institutional Income Funds, Inc. (0001169187) (Filer)
      filed 2026-06-01 12:30 UTC — Filed: 2026-06-01 AccNo: 0001999371-26-011729 Size: 7 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 15 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 15 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-06-01) Will Cape Verde win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,808,860 · resolves 2026-07-20
  - (2026-06-01) Will Iraq win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,561,488 · resolves 2026-07-20
  - (2026-06-01) Will Qatar win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,120,875 · resolves 2026-07-20
  - (2026-06-01) Will Haiti win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,070,924 · resolves 2026-07-20
  - (2026-06-01) Will New Zealand win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $9,269,731 · resolves 2026-07-20
  - (2026-06-01) Will Saudi Arabia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $8,186,356 · resolves 2026-07-20
  - (2026-06-01) Will Uzbekistan win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $6,547,248 · resolves 2026-07-20
  - (2026-06-01) Will Turkiye win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $3,883,243 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-06-01) [Marginal Revolution] Europe Demands Family Dynasties
      In the US, someone with wealth is free to give it away more or less as they see fit (spousal claims excepted, which partly reflect marital co-ownership). In much of Europe, however, there is forced heirship&#8211;a large
  - (2026-06-01) [Marginal Revolution] UK facts of the day
      At the peak, the year to March 2023, almost 1.5m immigrants came. The Office for National Statistics thinks that far fewer people left, so net migration amounted to 944,000. &#8230;Net migration to Britain last year amou
  - (2026-06-01) [Marginal Revolution] The political right continues to gain ground in Latin America
      A leftist senator and a rightwing populist outsider who calls himself “The Tiger” will go to a run-off presidential election in Colombia this month after no candidate won outright in the first round of voting on Sunday. 

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=30, 14d-median=30; carrying terms: event, order, public, associated, sector, service, enforcement, adopting, establishing, airplanes, designated, prompted
- state_bills: today=140, 7d-median=148, 14d-median=148; carrying terms: designation, prescribed, special, material, reduce, provisions, court, pavement, structure, remaining, public, office
- state_news: today=276, 7d-median=708, 14d-median=708; carrying terms: special, texas, ethics, featured, largely, reduce, field, spotlightdelaware, nearly, dozen, letter, feature
- local_news: today=184, 7d-median=247, 14d-median=247; carrying terms: likely, crash, court, restaurants, cbmingfbvv, public, office, remains, republicans, along, house, atlantamagazine
- foreign_news: today=832, 7d-median=864, 14d-median=864; carrying terms: likely, special, correspondent, industries, partly, material, pushing, india, rajasthan, venture, replace, great
- chinese_internal: today=250, 7d-median=273, 14d-median=273; carrying terms: record, cbmickfvx, cbmizefvx, cbmia, lxtfa, https, cbmixkfvx, articles, title, cbmib, cbmibkfvx, cbmiyefvx
- russian_internal: today=792, 7d-median=968, 14d-median=968; carrying terms: disney, origin, journal, politico, russian, company, financial, associated, spiegel, client, euroclear, tasnim
- ukrainian_internal: today=112, 7d-median=122, 14d-median=122; carrying terms: destroy, pushing, nearly, oreshnik, kremlin, public, remains, received, warns, crews, adviser, network
- ukraine_theater: today=266, 7d-median=336, 14d-median=336; carrying terms: josknra, governorate, cuxqa, vnlhywxzafrwslz, pizvvmzwvuzvlnauvfykzmuedpekzgulbdoupzntaxzzc, hvdxhuthnzz, rwogh, reduce, india, feature, iennuctrpou, etzldtm
- paper_bets: today=135, 7d-median=138, 14d-median=138; carrying terms: special, texas, formally, minute, humans, pirates, provisions, india, solana, minnesota, midterms, enacts
- weather: today=127, 7d-median=119, 14d-median=119; carrying terms: likely, special, hazards, afdlwx, reduce, especially, statement, augusta, minnesota, showers, short, limbs
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: price, italy, france, nikkei, shanghai, coffee, brazil, mexico, crude, canada, silver, cotton
- sanctions_procurement: today=101, 7d-median=98, 14d-median=98; carrying terms: usmca, designation, homeland, cbmixkfvx, prohibited, ztwgwxqzvywvd, sectoral, court, services, bklyaxzos, announce, government
- congressional_trades: today=39, 7d-median=1, 14d-median=1
- billionaires: today=0, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: smith, blanche, transport, america, girard, argueta, castillo, group, margolin, fernandez, garrison, messer
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, accno, reporting, holdings, financial, trust, filer, jpmorgan, chase, subject
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ocasio, friends, james, disbursements, joshua, ossoff, cooper, cortez, alexandria, brown, booker, krishnamoorthi
- gdelt_regions: today=0, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=0, 14d-median=0
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: reader, vulnerability, adobe, denial, service, traversal, remediation, microsoft, origin, overwrite, product, explorer
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, ceasefire, world, continue, bitcoin, ivory, coast, roland, garros, turkiye
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, story, class, marginal, https, policy, revolution, conversable, marginalrevolution, recipients, analysis, journal
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: dexter, lankford, elijah, ogles, womack, fischer, murphy, huizenga, mullin, alexandria, vicente, crane
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, converges, evidence, today, identify, market, module, consensus, paper, placement, placed, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*