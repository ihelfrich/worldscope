# WORLDSCOPE morning brief — 2026-06-01

## Headline
2102 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 30 total
  (no new items today)

### State Legislative Action — 0 new of 140 total
  (no new items today)

### State-Level News — 59 new of 176 total
  - (2026-05-31) [Colorado] More cities are pressing pause on data centers as local backlash grows
      Hearing backlash from residents, cities and counties across the country in recent weeks have blocked planned data centers amid concerns over rising electricity prices and environmental harms. The local actions come as st
  - (2026-05-31) [Arkansas] Flesh-eating screwworms head for American livestock
      Southern states are bracing for a potential invasion of the New World screwworm that could disrupt livestock markets and raise already high meat prices. So far, the parasite has yet to land in the United States, but it h
  - (2026-05-31) [Arkansas] Rental rates and abortion laws: Dems scrutinize states vying to go first in picking a president
      WASHINGTON — Democratic Party leaders from a dozen states traveled to Washington, D.C., at the end of May to press for their voters to cast the first ballots in the next presidential primary.  State representatives argue
  - (2026-05-31) [Arkansas] Utah governor orders ‘higher bar’ for data centers, says public input ‘absolutely matters’
      Facing public outcry from across the state and intense pushback from communities closest to a massive proposed data center in northern Utah, Gov. Spencer Cox on Friday said the health of the Great Salt Lake and safeguard
  - (2026-05-31) [Arkansas] The data center debates are only a preview of Arkansas’ AI challenges
      As central Arkansas debated how to handle the influx of data centers needed to power artificial intelligence, another story played out in Fort Smith. There, local police sent an alert to community members about an AI-gen
  - (2026-06-01) [Connecticut] Secure gun storage will save lives
      <figure><img width="1024" height="390" src="https://ctmirror.org/wp-content/uploads/2026/05/gun-storage-check-week-banner-1024x390.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=
  - (2026-06-01) [Connecticut] CT needs a 21st century tool to fight Medicaid fraud
      <figure><img width="800" height="538" src="https://ctmirror.org/wp-content/uploads/2026/05/Medicaid-form.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" src
  - (2026-05-31) [California] Governor Newsom proclaims Jewish Heritage Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn

### Local News: St. Louis + Atlanta — 99 new of 175 total
  - (2026-06-01) [St. Louis] After 41 years, neighborhood gives beloved mail carrier a party he'll never forget
      After 41 years on the same route, beloved mail carrier Mike Carranza's retirement was cause for a surprise neighborhood celebration in Frontenac Estates.
  - (2026-06-01) [St. Louis] 'My son is covered in blood': Carnival assault in St. Peters sends 2 teens to hospital, sparks safety concerns
      Two teens were hospitalized after an assault Friday night at a carnival in St. Peters, renewing concerns from parents and business owners over youth violence.
  - (2026-06-01) [St. Louis] Peabo Bryson 'under medical care' after stroke, rep says
      The 75-year-old Grammy-award winning singer, songwriter has had many hits, including "If You're Ever in My Arms Again" and "A Whole New World."
  - (2026-06-01) [St. Louis] 'Mister Rogers' Neighborhood' jazz guitarist Joe Negri dies at 99
      Joe Negri, known for his role as Handyman Negri on "Mister Rogers’ Neighborhood," has died at 99.
  - (2026-05-31) [St. Louis] 'Overwhelmed with emotions': Navy veteran reunites with missing service dog
      Scott Baker and his service dog Mal’i reunited after a dayslong search in Jacksonville, Florida.
  - (2026-05-31) [St. Louis] 'It's a beacon of hope': North St. Louis church reopens one year after tornado damage
      Original Friendship Missionary Baptist Church held its first service since last year's tornado, offering hope to a recovering community.
  - (2026-05-31) [St. Louis] 'I didn’t hesitate': Coworker and friend becomes kidney donor for Texas jail sergeant
      After learning his kidneys were failing, Joseph Vela began searching for a donor. The person who would ultimately change his life was much closer than he expected.
  - (2026-05-31) [St. Louis] Matt Brown, star of 'Alaskan Bush People,' has died
      Matt Brown of "Alaskan Bush People" has died at 43, his brothers announced on social media.

### International News + Multilateral Institutions — 508 new of 812 total
  - (2026-06-01) [Global] France and allies intercept sanctioned Russian oil tanker in Atlantic
      France and its partners intercepted a Russian oil tanker circumventing sanctions in the Atlantic over the weekend, President Emmanuel Macron said in a social media post on Monday. The Tagor was detained Sunday morning in
  - (2026-06-01) [Global] PSG parade champions league trophy as they celebrate back-to-back titles
      Paris Saint-Germain brought the Champions League trophy back to France, taking it from the Champ-de-Mars to the Parc des Princes.
  - (2026-06-01) [Global] Middle East live: US bombs Iranian military sites, Kuwait intercepts drone and missile attacks
      The US conducted strikes on military sites in Iran’s ‌Goruk and Qeshm Island over the weekend in response to “aggressive Iranian actions”, the military said late ‌Sunday. Meanwhile Kuwaiti air defences on Monday intercep
  - (2026-06-01) [Global] Brazil isolates two suspected Ebola cases as Congo outbreak surpasses 1,000 infections
      Brazilian health authorities isolated two patients who recently arrived from African countries after they showed symptoms consistent with Ebola, officials said on Friday, although one later tested negative. The move come
  - (2026-05-31) [Global] PSG celebrate Champions League title with 48,000 fans at Parc des Princes stadium
      The European champions celebrated back-to-back titles with jubilant fans at their Paris home after a day of revelry in the French capital.
  - (2026-05-31) [Global] Colombia's presidential race goes to a runoff: De la Espriella vs. Cepeda
      Colombians voted Sunday in the first round of presidential elections, choosing between a reformist left seeking to retain power and a hard-line right promising security amid escalating violence by armed groups. With 99.9
  - (2026-05-31) [Global] Jubilant PSG fans celebrate Champions League victory by the Eiffel Tower
      A huge crowd of jubilant PSG supporters gathered near the Eiffel Tower on Sunday to celebrate their team's second Champions League title victory.
 
Thousands of people celebrated across France throughout the night but th
  - (2026-05-31) [Global] Colombia's election: Meeting the Presidential contenders
      The Economist’s Kinley Salmon on his encounters with the candidates

### Chinese Internal News — 202 new of 233 total
  - (2026-06-01) [TITLE: 最新封面报道下篇｜颠覆影视：AI渗透全产业链 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5kVWRTRTFNM2Z2ZGJCNmNIOWlhVkJjTW1keGNkRmVad3l6cVpoMG9FUFJoanBldGpaT0tRR21uMmhwNS1GMVZidEZCUFVqa] (zh: 最新封面报道下篇｜颠覆影视：AI渗透全产业链 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5kVWRTRTFNM2Z2ZGJCNmNIOWlhVkJjTW1keGNkRmVad3l6cVpoMG9FUFJoanBldGpaT0tRR21uMmhwNS1GMVZidEZCUFVqaUFRQm1wUlVBT3UwYy1vek81WA?oc=5" target="_blank">最新封面报道下篇｜颠覆影视：AI渗
  - (2026-06-01) [TITLE: 最新封面报道上篇｜短剧变局：AI生意自闭环 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE55VFRKUGV5OEotb08zemcxUHA3ZW1jM2txcnF3RXEzYnhrRmJkTGN6VFUyOEljVjVOMnExb3hERnpudU1mQkZsYXZ0SHFOQX] (zh: 最新封面报道上篇｜短剧变局：AI生意自闭环 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE55VFRKUGV5OEotb08zemcxUHA3ZW1jM2txcnF3RXEzYnhrRmJkTGN6VFUyOEljVjVOMnExb3hERnpudU1mQkZsYXZ0SHFOQXMyMlhPbGpGZ29oUDBDMEU4bA?oc=5" target="_blank">最新封面报道上篇｜短剧变局：AI生
  - (2026-06-01) [TITLE: 今日开盘：沪指报4067.16点 跌幅0.03% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9ralhvOVBqSncybmx1QlRZamhiQWR2T21ua1VLWURPb2Y2VHA4XzZpTk1fUDNTdVBrWGZVV3hKbld5R2hFaklHbjE1NW5Oa] (zh: 今日开盘：沪指报4067.16点 跌幅0.03% - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9ralhvOVBqSncybmx1QlRZamhiQWR2T21ua1VLWURPb2Y2VHA4XzZpTk1fUDNTdVBrWGZVV3hKbld5R2hFaklHbjE1NW5OaW5UZjRad25uYmJHSHNQWFFHdXJn?oc=5" target="_blank">今日开盘：沪指报4067.16
  - (2026-06-01) [TITLE: 事关幼儿园食品安全，新规6月1日起施行 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1QSzRfTGpfRExFamh1bnJBcUl1WmJ1dGZhb1FlcjZkZ0NIY2pXMVM0UkcwcW5hSEtJQ2xRTWgtdENkV1o5Z2lLdnA1UjljSjIwYl] (zh: 事关幼儿园食品安全，新规6月1日起施行 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1QSzRfTGpfRExFamh1bnJBcUl1WmJ1dGZhb1FlcjZkZ0NIY2pXMVM0UkcwcW5hSEtJQ2xRTWgtdENkV1o5Z2lLdnA1UjljSjIwYllFRWZiMGtKZ0szMFE?oc=5" target="_blank">事关幼儿园食品安全，新规6月1日起施行<
  - (2026-05-31) [TITLE: 财经早知道｜习近平《求是》撰文：前瞻布局和发展未来产业 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5jWXNyV2tuRFVEeGQ3OThLZ3FLYlNZSHl3d1VxeTlsdVB5S0w3Y1V2QUxLODR0bUk2YkMzeHRJRUpqbnE5WFFvZDVscV] (zh: 财经早知道｜习近平《求是》撰文：前瞻布局和发展未来产业 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5jWXNyV2tuRFVEeGQ3OThLZ3FLYlNZSHl3d1VxeTlsdVB5S0w3Y1V2QUxLODR0bUk2YkMzeHRJRUpqbnE5WFFvZDVscVlJM0VUU3dCaUQ4dW1VSVZvbzNMakh3?oc=5" target="_blank">财经早知道｜习近平《求是》撰文
  - (2026-05-31) [TITLE: 求学之路：像山丘一样平坦｜故事 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1iMmZZeXRNNVB5czVicjV2Tmd4ejB0elNNREtWTXdoSGxaS1I0bVFxRi1wamdqcDJFUEQ0dW1QMGtac1FnYWpYRkg3T0hmVW5GN0FMSz] (zh: 求学之路：像山丘一样平坦｜故事 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1iMmZZeXRNNVB5czVicjV2Tmd4ejB0elNNREtWTXdoSGxaS1I0bVFxRi1wamdqcDJFUEQ0dW1QMGtac1FnYWpYRkg3T0hmVW5GN0FMSzZQMDJHRWI1NlE?oc=5" target="_blank">求学之路：像山丘一样平坦｜故事</a>&
  - (2026-06-01) [TITLE: 自缚者胜：一家万亿估值AI公司的信任溢价 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1yQWdhUUxVamptOW1BZm44WVFzcW03TUZXQVlrWVp2QVNOckZTTlJmQ3ZmTl9aaS1ubDN0N2d3OXdkNlF2R01XaTR6YXoyMnFTc] (zh: 自缚者胜：一家万亿估值AI公司的信任溢价 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1yQWdhUUxVamptOW1BZm44WVFzcW03TUZXQVlrWVp2QVNOckZTTlJmQ3ZmTl9aaS1ubDN0N2d3OXdkNlF2R01XaTR6YXoyMnFTcU5YR0drR2xwWFFkQjNlQ3pn?oc=5" target="_blank">自缚者胜：一家万亿估值AI公司
  - (2026-06-01) [TITLE: 莎士比亚也是俺的朋友｜猎读 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBfNWZ1OEpNTDZSWTZaWHM0dHJyb3F5bGhrZW82M2hiODc1NWZsenJvYlluN0p6cmQyS3prckd1MThEWHJjU21KN2RGTHdBUzUtZDhjYmpI] (zh: 莎士比亚也是俺的朋友｜猎读 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBfNWZ1OEpNTDZSWTZaWHM0dHJyb3F5bGhrZW82M2hiODc1NWZsenJvYlluN0p6cmQyS3prckd1MThEWHJjU21KN2RGTHdBUzUtZDhjYmpITjFuZlNWaXc?oc=5" target="_blank">莎士比亚也是俺的朋友｜猎读</a>&nb

### Russian Internal News (state + in-exile) — 525 new of 696 total
  - (2026-06-01) [TITLE: Франция задержала в Атлантическом океане танкер российского «теневого флота» | LEDE: <p>ВМС Франции задержали в Атлантическом океане нефтяной танкер «Тагор» (Tagor), находящийся под международн] (ru: Франция задержала в Атлантическом океане танкер российского «теневого флота»)
      <p>ВМС Франции задержали в Атлантическом океане нефтяной танкер «Тагор» (Tagor), находящийся под международными санкциями. Об этом объявил президент Франции Эммануэль Макрон. <p>
  - (2026-06-01) [TITLE: Насколько успешна борьба властей с VPN? И чем она закончится? Объясняет Мария Коломыченко (Carnegie Politika) | LEDE: <p>Чем больше ресурсов блокируют российские власти, тем больше людей исполь] (ru: Насколько успешна борьба властей с VPN? И чем она закончится? Объясняет Мария Ко)
      <p>Чем больше ресурсов блокируют российские власти, тем больше людей использует VPN. По данным Russian Field на апрель 2026 года, таких россиян было 55% (в возрасте от 18 до 45 лет). Только за март 2026-го российские пол
  - (2026-06-01) [TITLE: «Исключит ли эта мера френдли-фаер? Конечно, нет». Минобороны хочет закрыть небо над европейской частью России для малой авиации — чтобы было проще сбивать дроны. Пилоты уверены, что запрет раз] (ru: «Исключит ли эта мера френдли-фаер? Конечно, нет». Минобороны хочет закрыть небо)
      <p>Минобороны в конце мая обратилось к Росавиации с просьбой запретить полеты малой авиации над центральноевропейской частью России. В авиасообществе предполагают, что так военные решили бороться с украинскими беспилотни
  - (2026-05-31) [TITLE: В Болгарии завершился чемпионат Европы по художественной гимнастике. На нем звучали гимны России и Беларуси (против чего протестовали украинские спортсменки), а российская сборная почти полност] (ru: В Болгарии завершился чемпионат Европы по художественной гимнастике. На нем звуч)
      <p>С 27 по 31 мая в болгарской Варне прошел чемпионат Европы по художественной гимнастике — это были первые с 2021 года международные соревнования, на которых спортсменки из России и Беларуси выступили с флагом и гимном.
  - (2026-05-31) [TITLE: «Расследование пришло к выводу, что обломки принадлежат российскому дрону». Президент Румынии опубликовал фотографии фрагментов беспилотника, попавшего в жилой дом | LEDE: <p>Беспилотник, попав] (ru: «Расследование пришло к выводу, что обломки принадлежат российскому дрону». През)
      <p>Беспилотник, попавший ночью 29 мая в жилой дом в городе Галац на юго-востоке Румынии, был российского производства, к такому выводу пришли румынские специалисты. Об этом заявил президент Румынии Никушор Дан. <p>
  - (2026-05-31) [TITLE: Лукашенко заявил, что Армении следует быть «аккуратнее», выбирая между Евразийским союзом и ЕС. Вслед за Путиным он сказал, что «в Украине все ровно так начиналось» | LEDE: <p>Александр Лукашен] (ru: Лукашенко заявил, что Армении следует быть «аккуратнее», выбирая между Евразийск)
      <p>Александр Лукашенко призвал народ Армении быть «очень аккуратным» при выборе между Евразийским союзом и Европой, чтобы «не повторить то, что произошло в Украине». Его слова приводит «Белта». <p>
  - (2026-05-31) [TITLE: Некоторые зашифрованные тексты не удается декодировать на протяжении сотен и даже тысяч лет. Вероятно, это получится изменить с помощью ИИ | LEDE: <p>В Ватиканской апостольской библиотеке более] (ru: Некоторые зашифрованные тексты не удается декодировать на протяжении сотен и даж)
      <p>В Ватиканской апостольской библиотеке более четырех веков хранится рукописная книга из 408 страниц, большую часть которой до недавнего времени было невозможно прочитать. В тексте использованы 34 необычных символа впер
  - (2026-05-31) [TITLE: В Москве в жилом доме произошел конфликт между 14-летней школьницей из Бурятии и двумя женщинами. Девочка рассказала, что ее избили и назвали «узкоглазой» | LEDE: <p>Глава Бурятии Алексей Цыден] (ru: В Москве в жилом доме произошел конфликт между 14-летней школьницей из Бурятии и)
      <p>Глава Бурятии Алексей Цыденов поручил правительству республики «разобраться» в нападении в Москве на 14-летнюю школьницу из Бурятии. <p>

### Ukrainian Internal News (national + local Kyiv) — 44 new of 101 total
  - (2026-06-01) [TITLE: Прем’єр Іспанії обіцяє залишатись на посаді попри корупційні скандали | LEDE: Прем’єр-міністр Іспанії Педро Санчес заявив, що залишатиметься на посаді до парламентських виборів у 2027 році попр] (uk: Прем’єр Іспанії обіцяє залишатись на посаді попри корупційні скандали)
      Прем’єр-міністр Іспанії Педро Санчес заявив, що залишатиметься на посаді до парламентських виборів у 2027 році попри низку корупційних скандалів, що зачепили очолювану ним Соціалістичну партію (PSOE).
  - (2026-06-01) [TITLE: У Києві водій вчинив стрілянину та поранив опонента під час конфлікту: його затримали | LEDE: У Києві на Оболоні під час конфлікту між водіями сталася стрілянина — є поранений, затримано підозр] (uk: У Києві водій вчинив стрілянину та поранив опонента під час конфлікту: його затр)
      У Києві на Оболоні під час конфлікту між водіями сталася стрілянина — є поранений, затримано підозрюваного.
  - (2026-06-01) [TITLE: Удар по Одесі: кількість постраждалих зросла до 5 | LEDE: 5 людей постраждали під час нічної атаки на Одесу, сталося займання будинків. Всі отримали допомогу.] (uk: Удар по Одесі: кількість постраждалих зросла до 5)
      5 людей постраждали під час нічної атаки на Одесу, сталося займання будинків. Всі отримали допомогу.
  - (2026-06-01) [TITLE: ППО знешкодила 228 з 265 безпілотників, які атакували Україну | LEDE: У ніч на 1 червня російські загарбники атакували 265 ударними БпЛА типу Shahed, "Гербера", "Італмас" та дронами-імітаторами] (uk: ППО знешкодила 228 з 265 безпілотників, які атакували Україну)
      У ніч на 1 червня російські загарбники атакували 265 ударними БпЛА типу Shahed, "Гербера", "Італмас" та дронами-імітаторами типу "Пародія".
  - (2026-06-01) [TITLE: Росіяни штурмували Покровський і Гуляйпільський напрямки понад 90 разів – Генштаб | LEDE: За минулу добу на фронті зафіксовано 276 бойових зіткнень, найбільше атак на Покровському та Гуляйпільс] (uk: Росіяни штурмували Покровський і Гуляйпільський напрямки понад 90 разів – Геншта)
      За минулу добу на фронті зафіксовано 276 бойових зіткнень, найбільше атак на Покровському та Гуляйпільському напрямках.
  - (2026-06-01) [TITLE: Одним з регіонів Польщі пронісся торнадо: пошкоджено житлові будинки | LEDE: Унаслідок проходження торнадо в селі Бальцажовіце у Стшелецькому повіті Опольського воєводства Польщі зруйновано 18 ] (uk: Одним з регіонів Польщі пронісся торнадо: пошкоджено житлові будинки)
      Унаслідок проходження торнадо в селі Бальцажовіце у Стшелецькому повіті Опольського воєводства Польщі зруйновано 18 будівель, 11 з яких – це житлові будинки.
  - (2026-06-01) [TITLE: Росіяни поранили 18 цивільних на Херсонщині, Сумщині та Дніпропетровщини | LEDE: Росія обстріляла Херсонську, Дніпропетровську та Сумську області – 15 мирних жителів отримали поранення, пошкодж] (uk: Росіяни поранили 18 цивільних на Херсонщині, Сумщині та Дніпропетровщини)
      Росія обстріляла Херсонську, Дніпропетровську та Сумську області – 15 мирних жителів отримали поранення, пошкоджено інфраструктуру.
  - (2026-06-01) [TITLE: Росіяни вранці вдарили по Запоріжжю – поранили жінку | LEDE: 1 червня росіяни обстріляли Запоріжжя – поранено жінку і пошкоджено приватний будинок.] (uk: Росіяни вранці вдарили по Запоріжжю – поранили жінку)
      1 червня росіяни обстріляли Запоріжжя – поранено жінку і пошкоджено приватний будинок.

### Ukraine Theater (total-war monitoring) — 70 new of 266 total
  - (2026-05-31) [FIRMS] thermal anomaly 50.052, 34.889 (FRP 2.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1024Z, FRP 2.7 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.337, 34.366 (FRP 3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1026Z, FRP 3 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.284, 33.032 (FRP 1.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 1.15 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.193, 34.040 (FRP 2.66 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 2.66 MW
  - (2026-05-31) [FIRMS] thermal anomaly 50.181, 34.759 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2237Z, FRP 1.02 MW
  - (2026-06-01) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMiOkFVX3lxTFBsdGdBOUMtUGIzaWpMRVRwa0x4VWY3SlRTTVdTYW83Y01rR0xpSWpXd2xNOWFkV0lWNUE?oc=5" target="_blank">Ukraine Interactive map - Ukraine Latest news on live map - liveuama
  - (2017-06-06) [Liveuamap] Lebanon news on live map - lebanon.liveuamap.com - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMiREFVX3lxTE9ldllvQVZJdkFSY1VwVEdEMTJ0YVI0SHA5QzJDZGNrcnJCNk1wbVYtT0FXRmdZN1d6cGxNbG1CZnIxT1B1?oc=5" target="_blank">Lebanon news on live map - lebanon.liveuamap.com</a>&nb

### Paper Trading Scorecard — 31 new of 144 total
  - (2026-06-01) [Polymarket] Tesla and xAI merger officially announced by June 30?
      This market will resolve to "Yes" if it is officially announced that Tesla, Inc. will be, has been, or is being acquired by or merged with xAI, or vice versa, by June 30, 2026, 11:59 PM ET. Otherwise, this market will re
  - (2026-06-01) [Polymarket] Will CD Castellón vs. SD Eibar end in a draw?
      In the upcoming game, scheduled for May 31, 2026
If the game ends in a draw, this market will resolve to "Yes".
Otherwise, this market will resolve to "No".
If the game is postponed, this market will remain open until th
  - (2026-06-01) [Polymarket] Will Robert Kenyon win the 2026 Makerfield by-election?
      A by-election for the United Kingdom parliamentary constituency of Makerfield is expected to be held on June 18, 2026, following the announced resignation of incumbent Josh Simons.

This market will resolve according to 
  - (2026-06-01) [Polymarket] Will Elon Musk post 65-89 tweets from May 30 to June 1, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from May 30 12:00 PM ET to June 1, 2026 12:00 PM ET.

For the purposes of this market, only main feed posts, quote posts and rep
  - (2026-06-01) [Polymarket] Will Gen.G Esports win the LCK 2026 season playoffs?
      This market will resolve according to the winner of the League of Legends Champions Korea (LCK) 2026 season playoffs.

If the 2026 LCK season is postponed after December 31, 2026 11:59 PM ET, canceled, or a winner has no
  - (2026-06-01) [Polymarket] Israel x Iran permanent peace deal by June 30, 2026?
      This market will resolve to “Yes” if Israel and Iran agree to a permanent peace deal by the specified date, 11:59 PM ET. Otherwise, this market will resolve to “No”.

A permanent peace deal refers to any agreement which 
  - (2026-06-01) [Polymarket] Will Cătălin Predoiu be the next Prime Minister of Romania?
      This market will resolve to the next individual who officially assumes the office of Prime Minister of Romania by December 31, 2027, 11:59 PM ET.

To count for resolution, the individual must be formally appointed by the
  - (2026-06-01) [Polymarket] Will Wes Moore win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028.

This market will resolve to the person who wins the 2028 US Presidential Election.

The resolution source for this market is the Associat

### U.S. Weather + Severe / Climate Outlooks — 138 new of 140 total
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 12:54AM CDT until June 1 at 1:30AM CDT by NWS Omaha/Valley NE
      At 1254 AM CDT, a severe thunderstorm was located 3 miles south of
Herman, or 7 miles northwest of Blair, moving east at 20 mph.

HAZARD...60 mph wind gusts and quarter size hail.

SOURCE...Radar indicated.

IMPACT...Hai
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 12:53AM CDT until June 1 at 1:00AM CDT by NWS Topeka KS
      The severe thunderstorm which prompted the warning has weakened.
Therefore, the warning will be allowed to expire.  However, small
hail and gusty winds are still possible with this thunderstorm.

A Severe Thunderstorm Wa
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 12:53AM CDT until June 1 at 1:45AM CDT by NWS Kansas City/Pleasant Hill MO
      SVREAX

The National Weather Service in Pleasant Hill has issued a

* Severe Thunderstorm Warning for...
Northeastern Wyandotte County in northeastern Kansas...
Southern Clay County in west central Missouri...
Southeaste
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 12:53AM CDT until June 1 at 1:00AM CDT by NWS Omaha/Valley NE
      The storm which prompted the warning has weakened below severe
limits, and no longer poses an immediate threat to life or property.
Therefore, the warning will be allowed to expire.  However, small
hail is still possible
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 12:52AM CDT until June 1 at 1:45AM CDT by NWS Wichita KS
      At 1252 AM CDT, a severe thunderstorm was located near La Harpe,
moving east at 30 mph.

HAZARD...70 mph wind gusts and ping pong ball size hail.

SOURCE...Radar indicated.

IMPACT...People and animals outdoors will be i
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 12:51AM CDT until June 1 at 1:30AM CDT by NWS Topeka KS
      SVRTOP

The National Weather Service in Topeka has issued a

* Severe Thunderstorm Warning for...
Northern Jefferson County in northeastern Kansas...

* Until 130 AM CDT.

* At 1251 AM CDT, a severe thunderstorm was loca
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 12:51AM CDT until June 1 at 1:15AM CDT by NWS Kansas City/Pleasant Hill MO
      At 1251 AM CDT, a severe thunderstorm was located over Holt, or near
Kearney, moving east at 30 mph.

HAZARD...60 mph wind gusts and quarter size hail.

SOURCE...Public reported quarter size hail in Trimble at 1251 am.


  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 12:51AM CDT until June 1 at 1:00AM CDT by NWS Topeka KS
      The storm which prompted the warning has moved out of the area.
Therefore, the warning will be allowed to expire.

A Severe Thunderstorm Watch remains in effect until 400 AM CDT for
east central Kansas.

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 101 total
  - (2026-06-01) [BIS Entity List] page checksum 0220879c7d79
      Page content hash: 0220879c7d79. Compare with prior day's hash to detect updates.

### Congressional STOCK Act Trades (House + Senate) — 0 new of 1 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal & state) — 48 new of 60 total
  - (2026-06-02) Connecticut Supreme Court: Wilmington Savings Fund Society, FSB v. Schulz
  - (2026-05-29) U.S. Court of Appeals, D.C. Cir.: Global Voice Group SA v. Republic of Guinea
  - (2026-05-29) U.S. Court of Appeals, D.C. Cir.: ModernWest Longmont, LLC v. FAA
  - (2026-05-29) U.S. Court of Appeals, D.C. Cir.: United States v. Raul Flores-Hernandez
  - (2026-05-29) U.S. Court of Appeals, 8th Cir.: Charles Kleinsteuber v. Metropolitan Life Ins. Co.
  - (2026-05-29) U.S. Court of Appeals, 8th Cir.: Elisa Lopez-Vasquez v. Pamela Bondi
  - (2026-05-29) Alaska Supreme Court: Jace B. (Father) v. State of Alaska, DFCS, OCS
  - (2026-05-29) U.S. Court of Appeals, 11th Cir.: Florida East Coast Holdings Corporation v. Lexington Insurance Company

### SEC Form 4 insider transactions (recent) — 0 new of 40 total
  (no new items today)

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 15 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 15 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-06-01) Will Cape Verde win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,744,752 · resolves 2026-07-20
  - (2026-06-01) Will Iraq win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,574,315 · resolves 2026-07-20
  - (2026-06-01) Will Qatar win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,120,960 · resolves 2026-07-20
  - (2026-06-01) Will Haiti win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,070,932 · resolves 2026-07-20
  - (2026-06-01) Will New Zealand win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $9,151,925 · resolves 2026-07-20
  - (2026-06-01) Will Saudi Arabia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $8,101,695 · resolves 2026-07-20
  - (2026-06-01) Will Uzbekistan win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $6,555,649 · resolves 2026-07-20
  - (2026-06-01) Will Turkiye win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $3,998,651 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-06-01) [Marginal Revolution] The political right continues to gain ground in Latin America
      A leftist senator and a rightwing populist outsider who calls himself “The Tiger” will go to a run-off presidential election in Colombia this month after no candidate won outright in the first round of voting on Sunday. 
  - (2026-05-31) [Marginal Revolution] The returns to good data are rising
      When we want A.I. to solve real problems for real people, we need to make sure the data exists. That means cleaning up government data sets that are currently in a shambles (a project that the province of Alberta’s gover
  - (2026-05-31) [Marginal Revolution] A new American exceptionalism?
      From Paul Krugman: Let me be clear: I am not arguing that European productivity is mismeasured, and never said that. I am, instead, arguing that standard measures of productivity do not have the implications for cross-co

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=30, 14d-median=30; carrying terms: applicable, service, safety, amendment, proposes, airworthiness, actions, national, sector, public, requires, order
- state_bills: today=140, 7d-median=148, 14d-median=148; carrying terms: collaborative, requesting, because, hearing, priority, storage, wildfire, entry, fiscal, promote, jurisdiction, measurement
- state_news: today=176, 7d-median=708, 14d-median=708; carrying terms: because, hearing, weaponization, wearing, published, respond, fiscal, hosted, california, financial, https, shift
- local_news: today=175, 7d-median=247, 14d-median=247; carrying terms: because, https, death, began, several, public, board, scene, family, patients, morning, violent
- foreign_news: today=812, 7d-median=864, 14d-median=864; carrying terms: orbit, undesirable, bruce, integration, match, setting, published, promote, queen, oldest, packing, features
- chinese_internal: today=233, 7d-median=273, 14d-median=273; carrying terms: https, cbmiyefvx, cbmiw, cbmibkfvx, blank, lxtfa, cbmixkfvx, cbmizkfvx, cbmizefvx, google, color, stock
- russian_internal: today=696, 7d-median=968, 14d-median=968; carrying terms: group, istories, press, financial, https, found, china, times, garros, gazeta, disney, media
- ukrainian_internal: today=101, 7d-median=122, 14d-median=122; carrying terms: hromadske, condemned, sviatlana, https, logistics, warns, called, destroy, several, public, tsikhanouskaya, daily
- ukraine_theater: today=266, 7d-median=336, 14d-median=336; carrying terms: hcxzwnzdwn, mzzxy, pcgtrrl, nxtvfcng, hidwhzre, cuxortnytvjjofbzt, lpzxfhsuvcovnmmjvzowzqvnb, plmvvrywv, cbmihwfbvv, rwdmdmi, msepslvrcbghhnwzpshcya, qvlyumk
- paper_bets: today=144, 7d-median=141, 14d-median=141; carrying terms: republicans, announcement, immediately, zohran, minute, midterms, population, california, https, party, carolina, safety
- weather: today=140, 7d-median=119, 14d-median=119; carrying terms: afdlsx, currents, values, gusty, service, property, rivers, region, today, george, occur, roads
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: copper, canada, australia, crypto, crude, index, kospi, china, india, nasdaq, nikkei, shanghai
- sanctions_procurement: today=101, 7d-median=98, 14d-median=98; carrying terms: involvement, maintenance, sevastopol, threatening, oblasts, committees, operations, rounds, congo, integrity, negotiating, science
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, unauthorized, https, client, quantitative, quiver, httperror, error, quiverquant
- billionaires: today=0, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: transport, smith, blanche, vasquez, america, bondi, group, castillo, fernandez, argueta, catherine, kenneth
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, financial, holdings, david, group, brian, michael, american, jefferies
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: robert, ossoff, robinson, friends, filing, michael, sherrod, talarico, graham, joshua, booker, warner
- gdelt_regions: today=0, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=0, 14d-median=0
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: windows, acrobat, internet, defender, reader, langflow, traversal, trend, buffer, injection, service, denial
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, ceasefire, world, permanent, continue, volume, peace, hormuz, strait, price, normal, returns
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, https, marginal, conversable, economist, policy, story, class, marginalrevolution, recipients, former, health
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: boozman, cammack, bruce, emily, mccaul, trump, thune, hillary, currency, adrian, latimer, duyne
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, paper, consensus, market, identify, module, placement, claude, markets, unavailable, today, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] ECB press: Financial stability vulnerabilities remain elevated as geoeconomic shock unfolds
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*