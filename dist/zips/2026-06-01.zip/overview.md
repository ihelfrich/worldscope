# WORLDSCOPE morning brief — 2026-06-01

## Headline
2819 new items across 21 active section(s) (of 37 tracked).

## Top movers today
Russian Internal News (state + in-exile) (662) · International News + Multilateral Institutions (632) · World leaders & government officials (324) · Chinese Internal News (230) · State-Level News (223) · Local News: St. Louis + Atlanta (194) · U.S. Weather + Severe / Climate Outlooks (129) · Ukraine Theater (total-war monitoring) (99) · Ukrainian Internal News (national + local Kyiv) (66) · Court opinions of consequence (federal & state) (51) · Paper Trading Scorecard (44) · Congressional STOCK Act Trades (House + Senate) (40)

## What changed today
### Russian Internal News (state + in-exile) — 662 new of 806 total
  - (2026-06-01) Автору телеграм-канала «Свободная Лапландия» назначили 15 лет по делу о госизмене и терроризме. Он трижды пытался покончить с собой | LEDE: 23-летний студент, автор телеграм-канала «Свободна] (ru: Авт…
      23-летний студент, автор телеграм-канала «Свободная Лапландия» Рафаэль Мамедов приговорен к 15 годам заключения по обвинению в государственной измене и участии в террористической организации. Такое решение вынес Северный…
  - (2026-06-01) Центробанк и Минфин предупредили Путина, что военные расходы непосильны для российского бюджета | LEDE: Высокопоставленные чиновники Минфина и Центрального банка России предупредили Владимир] (ru: Цен…
      Высокопоставленные чиновники Минфина и Центрального банка России предупредили Владимира Путина, что нынешний уровень оборонных расходов ведет к опасному увеличению бюджетного дефицита, пишет со ссылкой на источники агент…
  - (2026-06-01) Организаторы забега на Куршской косе в Литве поставили условие для россиян и белорусов — им можно участвовать только под флагом Украины | LEDE: Организаторы трейлового забега Trail Kuršių Ne] (ru: Орг…
      Организаторы трейлового забега Trail Kuršių Nerija по Куршской косе в Литве заявили, что на мероприятии «не приветствуются» участники из двух «недружественных» стран — России и Беларуси. В регламенте регистрации, как соо…
  - (2026-06-01) Tasnim: Иран приостановил переговоры с США | LEDE: Иранские переговорщики приостановят обмен сообщениями с представителями США, сообщило государственное иранское агентство Tasnim без ссылки ] (ru: Tas…
      Иранские переговорщики приостановят обмен сообщениями с представителями США, сообщило государственное иранское агентство Tasnim без ссылки на источник.
  - (2026-06-01) ФБК нашел у семьи главы ВЦИОМ недвижимость, автомобили и предметы роскоши на 500 миллионов рублей. Валерий Федоров больше 20 лет возглавляет государственную службу, которая манипулирует обществ] (ru:…
      Фонд борьбы с коррупцией обнаружил у семьи директора Всероссийского центра изучения общественного мнения (ВЦИОМ) Валерия Федорова недвижимость, автомобили и предметы роскоши на сумму более 500 миллионов рублей. Авторы ра…
  - (2026-06-01) Россия и Армения сползают в новый кризис. Кремль не устраивает прозападный курс Еревана. Путин почти открыто угрожает украинским сценарием | LEDE: Парламентские выборы в Армении пройдут в бл] (ru: Рос…
      Парламентские выборы в Армении пройдут в ближайшее воскресенье, 7 июня. Россия неоднократно критиковала действующего премьера страны Никола Пашиняна за то, что Ереван, как считают в Кремле, выбрал прозападный курс. Армен…

### International News + Multilateral Institutions — 632 new of 830 total
  - (2026-06-01) [Global] As Israel pushes past the Litani, Lebanese question the purpose of UNIFIL
      Israel has pushed past the Litani River, with the UNFIL peacekeeping force helpless to prevent an invasion.
  - (2026-06-01) [Global] Indian PM Modi meets Myanmar military gov’t leader in New Delhi
      Myanmar opposition groups criticise India for hosting Min Aung Hlaing, but India says engagement is best way forward.
  - (2026-06-01) [Global] Lebanon latest: Israel captures more land in the south
      Al Jazeera’s Zeina Khodr brings you the latest from Lebanon as Israel expands its occupation there.
  - (2026-06-01) [Global] Egypt’s new monorail offers a modern ride, but Cairo is still not convinced
      Cairo's East Nile monorail opened to passengers this month as a flagship of Egypt's infrastructure ambitions.
  - (2026-06-01) [Global] Sacked Arsenal staffer doesn’t regret speaking out for Palestine
      Mark Bonnick is suing Arsenal football club for unfair dismissal, saying he was sacked for supporting Palestine.
  - (2026-06-01) [Global] Huge explosion at Malta fireworks factory
      A large explosion has torn through a fireworks factory in northern Malta, damaging buildings several kilometres away.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 230 new of 260 total
  - (2026-05-30) 美防长在香会对华“降调”，对欧“施压” - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9HdWZfQW1meFBGUmZtRVk3WTB0OXlqVnBWZ0tkVWY3cHRfRlk3NVBMWkc3SjA2N0NGaFZyMy16WGdaWng1WFkxX1ZZRk] (zh:…
      美防长在香会对华“降调”，对欧“施压” guancha.cn
  - (2026-06-01) 观网问计：中国金融虚拟资本市场怎样才算发展到店养家的标准？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE11MEVyN2hnWEIzYlZhYXVxWEZzYklOd0p6NkNpaHBneGtiTGZVTkpnRmhCZHF5ZUZ5aUhNS2staVNKbEE4emczRlhT] (zh:…
      观网问计：中国金融虚拟资本市场怎样才算发展到店养家的标准？ 风闻
  - (2026-06-01) “一车安全带全是P上去的”-观察者网 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFA4bnpzRnFPYXRqM0RaSGNadjFKbDVTN19ScjdMTnYyNTBkOGxkbHpuSnhJbkVjN3dEWmJlVzMwT0JneVRheHFkaG5hT3Y] (zh:…
      “一车安全带全是P上去的”-观察者网 guancha.cn
  - (2026-05-31) 智利缉毒犬在官方仪式现场，突然扑咬海军中将裤兜…-观察者网 - guancha.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1iSUJjUDhSaTZTeHd5QkVvekp1ZHdxdUczVGtPbjlkTmFESFVsV05wQUtzM1RZcFBPN1dZQ24xamU3c1hO] (zh:…
      智利缉毒犬在官方仪式现场，突然扑咬海军中将裤兜…-观察者网 guancha.cn
  - (2026-06-01) 托举孩子进山姆的女子，她开心的说自己的山姆签证下来了 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1vY0Jfc2pwTk9ubHFyRUZIaXNWUmlMd1Q1cUtyUGRuUUhxVXFnRDJyMjBDSC15QU10YmNMYXVqVUhVZG8zcjNNUDR4Q2I] (zh:…
      托举孩子进山姆的女子，她开心的说自己的山姆签证下来了 风闻
  - (2026-06-01) 带狗去逛瓷器市集，结果一个不小心，把摊主的货品搞碎一地 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE4wU1NXMHlBVi0tWVYwcUpiaVFsVFd3S1N2bGlkSUdrbEFyUy1KMUhWRm80SzkzV21Sd0lqQUUya0VGQ29hLU9TTUFlZF] (zh:…
      带狗去逛瓷器市集，结果一个不小心，把摊主的货品搞碎一地 风闻

### State-Level News — 223 new of 319 total
  - (2026-06-01) [California] Suspense in California governor’s race as Democrats hold on to their ballots
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_UCSD-Voting_AD_CM_02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-06-01) [California] Long after protests ended, this interfaith group rallies to remember LA immigrants taken by ICE
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052726-godmothers-of-the-disappeared-SR-GETTY-01-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-imag…
  - (2026-06-01) [California] Why a yearslong fight over gambling is good news for California politicians
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052126-Cardroom-Protest-MG-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-06-01) [California] More candidates are using their personal wealth to campaign than ever before. Should voters care?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/041426_gov-candidate-forum_FG_49-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-05-31) [California] Governor Newsom proclaims Jewish Heritage Month
      Source
  - (2026-06-01) [Alaska] In Kachemak Bay, Kotzebue and beyond, Alaskans are on the lookout for harmful algae blooms
      Algae is vital to a healthy marine system, and most of the hundreds of varieties in Alaska’s waters are beneficial or benign. But the handful that are harmful are, like other algae, proliferating in warmer conditions and…

### Local News: St. Louis + Atlanta — 194 new of 217 total
  - (2026-06-01) [St. Louis] Nicolas Cage revels in being 'a Spider-Man for aging adults'
      At 62, Nicolas Cage is finally embracing his inner Spider-Man, swinging around the Big Apple with style while also feeling his age a bit.
  - (2026-06-01) [St. Louis] Heart of St. Charles banquet center demolition underway
      The Heart of St. Charles building is being demolished to make way for a new hotel. The former banquet center hosted many weddings and events through the decades, but the building has been vacant since 2019.
  - (2026-06-01) [St. Louis] St. Louis police identify man killed in Columbus Square neighborhood
      Terrence Tunstall was shot to death May 26 in the 1400 block of North 13th Street. Tunstall, 43, lived in St. Louis.
  - (2026-06-01) [St. Louis] Suntrup plans car repair shop at historic Manchester school. Residents say history at risk
      The Henry Avenue Historic District has become a battleground between city officials who support the plan and residents who say the development would destroy the neighborhood.
  - (2026-06-01) [St. Louis] Serena Williams
      Serena Williams
  - (2026-06-01) [St. Louis] Photos: Suntrup plans car repair shop at historic Manchester school
      Suntrup plans car repair shop at historic Manchester school

### U.S. Weather + Severe / Climate Outlooks — 129 new of 131 total
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 11:32AM CDT until June 1 at 11:45AM CDT by NWS Huntsville AL
      At 1132 AM CDT, severe thunderstorms were located along a line extending from near Lynchburg to Fayetteville, moving southeast at 35 mph. HAZARD...60 mph wind gusts and nickel size hail. SOURCE...Emergency management rep…
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 11:30AM CDT until June 1 at 11:45AM CDT by NWS Huntsville AL
      At 1130 AM CDT, a severe thunderstorm was located over Lynchburg, moving southeast at 35 mph. HAZARD...60 mph wind gusts and nickel size hail. SOURCE...Emergency management reported power outages with this storm back in…
  - (2026-06-01) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 1 at 11:29AM CDT until June 1 at 11:45AM CDT by NWS Nashville TN
      At 1128 AM CDT, a severe thunderstorm was located near Waynesboro, moving southeast at 35 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hail damage to vehicles is expected. Exp…
  - (2026-06-01) [Moderate] Special Weather Statement: Special Weather Statement issued June 1 at 11:29AM CDT by NWS Memphis TN
      At 1129 AM CDT, Doppler radar was tracking a strong thunderstorm 8 miles northwest of Jumpertown, or 9 miles east of Ripley, moving southeast at 20 mph. HAZARD...Wind gusts up to 40 mph and penny size hail. SOURCE...Rada…
  - (2026-06-01) [Severe] Flash Flood Warning: Flash Flood Warning issued June 1 at 11:29AM CDT until June 1 at 2:15PM CDT by NWS Paducah KY
      At 1129 AM CDT, Rainfall has ended but amounts were high enough that flash flooding remains possible through early this afternoon. HAZARD...Flash flooding caused by thunderstorms. SOURCE...Radar. IMPACT...Flash flooding…
  - (2026-06-01) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.

### Ukraine Theater (total-war monitoring) — 99 new of 266 total
  - (2026-05-31) [FIRMS] thermal anomaly 50.052, 34.889 (FRP 2.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1024Z, FRP 2.7 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.337, 34.366 (FRP 3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 1026Z, FRP 3 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.284, 33.032 (FRP 1.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 1.15 MW
  - (2026-05-31) [FIRMS] thermal anomaly 52.193, 34.040 (FRP 2.66 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2235Z, FRP 2.66 MW
  - (2026-05-31) [FIRMS] thermal anomaly 50.181, 34.759 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-31 2237Z, FRP 1.02 MW
  - (2026-06-01) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.

### Ukrainian Internal News (national + local Kyiv) — 66 new of 118 total
  - (2026-06-01) У Чехії розслідують смерть українця після інциденту з дезінфектором у в’язниці | LEDE: У Чехії Генеральна інспекція сил безпеки розслідує смерть 40-річного українця, який помер після того, як р] (uk:…
      У Чехії Генеральна інспекція сил безпеки розслідує смерть 40-річного українця, який помер після того, як разом із двома іншими ув'язненими випив дезінфікуючий засіб у в'язниці міста Плзень.
  - (2026-06-01) Двоє людей поранені через російські атаки на Дніпропетровщині | LEDE: Російські війська понад 40 разів атакували безпілотниками, артилерією та авіабомбою чотири райони Дніпропетровської області] (uk:…
      Російські війська понад 40 разів атакували безпілотниками, артилерією та авіабомбою чотири райони Дніпропетровської області: двоє людей дістали поранень.
  - (2026-06-01) Bloomberg: Мерц хоче зібрати лідерів Європи перед зустріччю з Трампом на саміті НАТО | LEDE: Канцлер Німеччини Фрідріх Мерц планує наприкінці червня провести зустріч із європейськими лідерами, ] (uk:…
      Канцлер Німеччини Фрідріх Мерц планує наприкінці червня провести зустріч із європейськими лідерами, щоб узгодити підхід до переговорів із президентом США Дональдом Трампом на липневому саміті НАТО.
  - (2026-06-01) ЦВК визнала обраним нардепом політолога Давидюка | LEDE: Центральна виборча комісія визнала політолога Миколу Давидюка обраним народним депутатом від партії "Голос" замість Володимира Цабаля, я] (uk:…
      Центральна виборча комісія визнала політолога Миколу Давидюка обраним народним депутатом від партії "Голос" замість Володимира Цабаля, який склав мандат.
  - (2026-06-01) ЗМІ: Іран призупинив переговори зі США через удари Ізраїлю по Лівану | LEDE: Іран нібито призупинив переговори зі США про можливу мирну угоду, вимагаючи припинити бойові дії Ізраїлю проти Ліван] (uk:…
      Іран нібито призупинив переговори зі США про можливу мирну угоду, вимагаючи припинити бойові дії Ізраїлю проти Лівану та вивести ізраїльські сили з ліванської території.
  - (2026-06-01) DeepState: Просування РФ у травні стали найменшими з жовтня 2023 року | LEDE: Армія РФ протягом травня окупувала 14 квадратних кілометрів української території. За даними аналітиків DeepState, ] (uk:…
      Армія РФ протягом травня окупувала 14 квадратних кілометрів української території. За даними аналітиків DeepState, це найнижчий місячний показник просування росіян за останні три роки.

### Court opinions of consequence (federal & state) — 51 new of 60 total
  - (2026-06-02) Connecticut Supreme Court: Wilmington Savings Fund Society, FSB v. Schulz
  - (2026-06-01) U.S. Supreme Court: Whitton v. Dixon
  - (2026-06-01) U.S. Court of Appeals, Federal Cir.: Eregli Demir Ve Celik Fabrikalari T.A.S. v. Itc
  - (2026-06-01) U.S. Court of Appeals, Federal Cir.: Veterans Legal Advocacy Group v. Collins
  - (2026-06-01) U.S. Court of Appeals, 8th Cir.: Data Axle, Inc. v. Andrew Nolting
  - (2026-06-01) U.S. Court of Appeals, 8th Cir.: United States v. Roy Franklin, Jr.

### Paper Trading Scorecard — 44 new of 149 total
  - (2026-06-01) [Polymarket] Will Cătălin Predoiu be the next Prime Minister of Romania?
      This market will resolve to the next individual who officially assumes the office of Prime Minister of Romania by December 31, 2027, 11:59 PM ET. To count for resolution, the individual must be formally appointed by the…
  - (2026-06-01) [Polymarket] Will Israel annex Gaza territory by June 30 2026?
      This market will resolve to "Yes" if Israel officially annexes any territory in the Gaza Strip by June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". Annexation is defined as an official declaration…
  - (2026-06-01) [Polymarket] Will Jordan Bardella win the 2027 French presidential election?
      The next French presidential election is currently expected to be held around April 2027. This market pertains to the outcome of the next French presidential election, regardless of whether it follows the scheduled end o…
  - (2026-06-01) [Polymarket] S&P 500 (SPX) Up or Down on June 1?
      This market will resolve to "Up" if the official S&P 500 Index closing price for S&P 500 (SPX) on Monday, June 1, 2026 is higher than the official S&P 500 Index closing price for SPX on the most recent prior trading day.…
  - (2026-06-01) [Polymarket] Will Gen.G Esports win the LCK 2026 season playoffs?
      This market will resolve according to the winner of the League of Legends Champions Korea (LCK) 2026 season playoffs. If the 2026 LCK season is postponed after December 31, 2026 11:59 PM ET, canceled, or a winner has not…
  - (2026-06-01) [Polymarket] New "Stranger Things" episode released by December 31?
      This market will resolve to "Yes" if Netflix officially releases a new episode of Stranger Things (i.e., an episode that was not previously available to stream on Netflix) between market creation and December 31, 2026, 1…

### Congressional STOCK Act Trades (House + Senate) — 40 new of 40 total
  - (2026-05-14) [House] Ed Case (D): Purchase AAPL ($1,001 - $15,000) (excess +3.5% vs SPY)
      Member: Ed Case (D, house). BioGuide: C001055. Asset: AAPL (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-14. Disclosure date: 2026-05-31. Excess return vs SPY since disclosure: +3.52%. D…
  - (2026-05-15) [House] David J. Taylor (R): Purchase T ($1,001 - $15,000) (excess +0.8% vs SPY)
      Member: David J. Taylor (R, house). BioGuide: T000490. Asset: T (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-05-28. Excess return vs SPY since disclosure: +0.8…
  - (2026-05-15) [House] David J. Taylor (R): Purchase MEDP ($1,001 - $15,000) (excess +5.3% vs SPY)
      Member: David J. Taylor (R, house). BioGuide: T000490. Asset: MEDP (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-05-28. Excess return vs SPY since disclosure: +…
  - (2026-05-15) [House] David J. Taylor (R): Purchase PH ($1,001 - $15,000) (excess -4.5% vs SPY)
      Member: David J. Taylor (R, house). BioGuide: T000490. Asset: PH (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-05-28. Excess return vs SPY since disclosure: -4.…
  - (2026-05-15) [House] David J. Taylor (R): Purchase PH ($1,001 - $15,000) (excess -4.5% vs SPY)
      Member: David J. Taylor (R, house). BioGuide: T000490. Asset: PH (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-05-28. Excess return vs SPY since disclosure: -4.…
  - (2026-05-15) [House] David J. Taylor (R): Purchase MEDP ($1,001 - $15,000) (excess +5.3% vs SPY)
      Member: David J. Taylor (R, house). BioGuide: T000490. Asset: MEDP (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-05-28. Excess return vs SPY since disclosure: +…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-01) [Rankin Thomas Parker] Form 4 (Reporting)
      filed 2026-06-01 16:33 UTC · role: Reporting — Filed: 2026-06-01 AccNo: 0001173514-26-000149 Size: 18 KB
  - (2026-06-01) [HYSTER-YALE, INC.] Form 4 (Issuer)
      filed 2026-06-01 16:33 UTC · role: Issuer — Filed: 2026-06-01 AccNo: 0001173514-26-000149 Size: 18 KB
  - (2026-06-01) 424B2 - Morgan Stanley Finance LLC (0001666268) (Filer)
      filed 2026-06-01 16:33 UTC — Filed: 2026-06-01 AccNo: 0001839882-26-026774 Size: 655 KB
  - (2026-06-01) 424B2 - MORGAN STANLEY (0000895421) (Filer)
      filed 2026-06-01 16:33 UTC — Filed: 2026-06-01 AccNo: 0001839882-26-026774 Size: 655 KB
  - (2026-06-01) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-01 16:33 UTC — Filed: 2026-06-01 AccNo: 0001213900-26-063303 Size: 2 MB
  - (2026-06-01) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-01 16:33 UTC — Filed: 2026-06-01 AccNo: 0001213900-26-063303 Size: 2 MB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-06-01) PAT191 (United States)
      icao24: adfeda · position: (42.0331, -75.0747) · alt: 4831m · 504km/h
  - (2026-06-01) PAT303 (United States)
      icao24: adfee0 · position: (30.5884, -97.498) · alt: 2034m · 451km/h
  - (2026-06-01) JAF3LC (Bulgaria)
      icao24: 4520aa · position: (39.1343, 2.4368) · alt: 10972m · 823km/h
  - (2026-06-01) PAT290 (United States)
      icao24: adfe91 · position: (38.1985, -121.9825) · alt: 967m · 316km/h
  - (2026-06-01) PAT193 (United States)
      icao24: adfdcf · position: (31.2581, -88.97) · alt: 8229m · 507km/h
  - (2026-06-01) JAF9WL (Belgium)
      icao24: 44d1ba · position: (38.3298, -0.3759) · alt: 1005m · 525km/h

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-06-01) Will Uruguay win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,787,466 · resolves 2026-07-20
  - (2026-06-01) Will Mexico win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,600,933 · resolves 2026-07-20
  - (2026-06-01) Roland Garros ATP: Juan Manuel Cerundolo vs Matteo Berrettini
      yes price: 10% · 24h volume: $2,325,146 · resolves 2026-06-08
  - (2026-06-01) Roland Garros ATP: Flavio Cobolli vs Zachary Svajda
      yes price: 100% · 24h volume: $2,025,392 · resolves 2026-06-07
  - (2026-06-01) Will Germany win the 2026 FIFA World Cup?
      yes price: 6% · 24h volume: $1,745,318 · resolves 2026-07-20
  - (2026-06-01) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,732,380 · resolves 2026-07-20

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-06-01) [Marginal Revolution] Monday assorted links
      1. Progress Ireland. 2. Some new results on tatonnement? 3. The new Paul McCartney album is his best since the 2004 Chaos and Creation in the Backyard. Here is a song by song analysis. For an 83-year-old, it is an astoni…
  - (2026-06-01) [Marginal Revolution] Europe Demands Family Dynasties
      In the US, someone with wealth is free to give it away more or less as they see fit (spousal claims excepted, which partly reflect marital co-ownership). In much of Europe, however, there is forced heirship–a large fract…
  - (2026-06-01) [Marginal Revolution] UK facts of the day
      At the peak, the year to March 2023, almost 1.5m immigrants came. The Office for National Statistics thinks that far fewer people left, so net migration amounted to 944,000. …Net migration to Britain last year amounted t…

### Government Action: Sanctions + Procurement + Foreign Agents — 2 new of 103 total
  - (2026-06-01) [OFAC] Publication of Introduction to OFAC Guide - Office of Foreign Assets Control (.gov)
      Publication of Introduction to OFAC Guide Office of Foreign Assets Control (.gov)
  - (2026-06-01) [BIS Entity List] page checksum 0220879c7d79
      Page content hash: 0220879c7d79. Compare with prior day's hash to detect updates.

### State Legislative Action — 1 new of 140 total
  - (2026-06-01) [Colorado HB 1036] Local Taxes on Vacant Residential Property
      The bill authorizes a county or municipality (local government), after approval by the electors of the local government, to impose an excise or a property tax, or both, on vacant residential properties within the boundar…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=30, 14d-median=30; carrying terms: provide, actions, needed, order, model, environmental, action, require, representative, authorized, waters, designated
- state_bills: today=140, 7d-median=148, 14d-median=148; carrying terms: measure, agencies, actions, enrollment, higher, acquired, related, mental, follows, value, throughput, single
- state_news: today=319, 7d-median=708, 14d-median=708; carrying terms: agencies, called, professor, enrollment, ballots, legislation, illinois, fifty, living, minneapolis, value, universities
- local_news: today=217, 7d-median=247, 14d-median=247; carrying terms: illinois, appeared, stealing, restaurants, target, month, center, found, runoff, cbmixkfvx, morning, residents
- foreign_news: today=830, 7d-median=864, 14d-median=864; carrying terms: agencies, terminal, called, rises, professor, trips, procuratorate, urban, legislation, soaring, living, appeared
- chinese_internal: today=260, 7d-median=273, 14d-median=273; carrying terms: target, cbmixkfvx, rally, caixin, cbmibefvx, lxtfa, people, record, google, cbmiyefvx, cbmib, color
- russian_internal: today=806, 7d-median=968, 14d-median=968; carrying terms: group, https, novayagazeta, novaya, spiegel, street, international, origin, found, forbidden, centcom, press
- ukrainian_internal: today=118, 7d-median=122, 14d-median=122; carrying terms: additional, called, poland, follows, production, independent, ending, weapon, strait, found, presidential, cooperation
- ukraine_theater: today=266, 7d-median=336, 14d-median=336; carrying terms: yxvfz, additional, mrvllwuhrrg, fnaeo, oxnjnddtdk, batches, zwhtwnzlbwjiszlry, illinois, pizvvmzwvuzvlnauvfykzmuedpekzgulbdoupzntaxzzc, emirates, twwnntexdmellhz, etzldtm
- paper_bets: today=149, 7d-median=141, 14d-median=141; carrying terms: james, kalshi, theme, jpmorgan, chase, coinflip, solana, miami, whether, equal, country, source
- weather: today=131, 7d-median=119, 14d-median=119; carrying terms: franklin, today, additional, warming, early, urban, affecting, fires, afdfwd, radar, miami, bankfull
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: coffee, canada, crude, france, mexico, close, lumber, india, merval, australia, germany, nikkei
- sanctions_procurement: today=103, 7d-median=98, 14d-median=98; carrying terms: zimbabwe, burma, sectoral, integrity, destruction, actions, mtjwwxz, associates, paeez, legislation, ztwgwxqzvywvd, related
- congressional_trades: today=40, 7d-median=1, 14d-median=1
- billionaires: today=0, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: vasquez, blanche, bondi, america, smith, transport, employee, group, fernandez, veterans, robert, kenneth
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, david, financial, group, jpmorgan, chase, filer, jefferies
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: jonathan, senate, lindsey, alexandria, friends, disbursements, robert, warner, krishnamoorthi, james, brown, graham
- gdelt_regions: today=0, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=0, 14d-median=4; carrying terms: ground, position
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: premise, drupal, micro, directx, microsoft, vendor, vulnerability, langflow, acrobat, directory, adobe, based
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, world, ceasefire, continue, volume, peace, price, resolves, bitcoin, ivory, coast, scotland
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: policy, story, https, marginal, class, revolution, conversable, economist, marginalrevolution, links, assorted, recipients
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: klobuchar, jonathan, barrag, franklin, schultz, alexandria, carter, edward, moreno, urban, lloyd, bonamici
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, sufficient, today, paper, unavailable, identify, module, converges, placement, consensus, market, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*