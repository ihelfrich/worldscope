# WORLDSCOPE morning brief — 2026-09-12

## Headline
2981 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (739) · Russian Internal News (state + in-exile) (631) · World leaders & government officials (324) · State-Level News (287) · Local News: St. Louis + Atlanta (211) · Chinese Internal News (211) · U.S. Weather + Severe / Climate Outlooks (98) · Ukraine Theater (total-war monitoring) (95) · State Legislative Action (71) · Ukrainian Internal News (national + local Kyiv) (67) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (40)

## What changed today
### International News + Multilateral Institutions — 739 new of 986 total
  - (2026-09-12) [Global] Hong Kong jails Tiananmen vigil activists for seven years
      Hong Kong jails Tiananmen vigil activists for seven years
  - (2026-09-12) [Global] Far-right protesters rally against Islam on 9/11 anniversary
      A far-right Islamophobic rally was held outside New York City Hall on the 25th anniversary of the September 11 attacks.
  - (2026-09-12) [Global] Two men receive jail terms for violent burglary of Man City’s Donnarumma
      Two men jailed after Italy international Gianluigi Donnarumma and his now wife attacked in Paris home during PSG stint.
  - (2026-09-12) [Global] Saudi Arabia shuts critical oil pipeline after drone attack: What it means
      Baghdad launches investigation, closes border after confirming strike came from Iraqi territory.
  - (2026-09-12) [Global] Real Madrid’s Mbappe confident of Ballon d’Or despite trophyless season
      Kylian Mbappe went trophyless in his first two Real Madrid seasons, but hopes World Cup goals boost Ballon d'Or bid.
  - (2026-09-12) [Global] What did US intelligence know before the 9/11 attacks?
      The CIA have declassified documents showing US presidents were warned about Osama bin Laden and al-Qaeda before 9/11.

### Russian Internal News (state + in-exile) — 631 new of 1059 total
  - (2026-09-12) Во Франции сошел с рельсов пассажирский поезд, десятки человек ранены. Власти подозревают диверсию | LEDE: Во Франции вечером 11 сентября сошел с рельсов пассажирский поезд. ] (ru: Во Франции сошел с…
      Во Франции вечером 11 сентября сошел с рельсов пассажирский поезд.
  - (2026-09-12) В Татарстане легкомоторный самолет упал в огород жилого дома. Два человека погибли | LEDE: Два человека погибли в результате падения легкомоторного самолета Cessna-172 в Татарстане, сообщает] (ru: В Т…
      Два человека погибли в результате падения легкомоторного самолета Cessna-172 в Татарстане, сообщает региональное управление МЧС.
  - (2026-09-12) «Растения прижились, акклиматизировались, пережили лагерь, заключенных и надзирателей». Фрагмент книги «Dendrarium» — о путешественнике Владимире Дягтереве, заключенном Соловков, который созда] (ru:…
      В издательствах Individuum и shell (f) вышла книга Алисы Кусти «Dendrarium. Пять садов заключенного Дегтярева». Автор описывает, как ищет сведения о Владимире Дягтереве — заключенном Соловецкого лагеря, который создал во…
  - (2026-09-12) «Это из-за этой плесени позавчерашней, которой я отказала?». Россиянка отказалась знакомиться с военным. Через два дня ее похитили, угрожали пытками и требовали сознаться в связях с Украиной | ] (ru:…
      Жительницу одного из крупных приграничных городов России похитили люди в военной форме — они угрожали ей пытками током, получили доступ к ее телефону и требовали признаться в возможных связях с Украиной. За два дня до эт…
  - (2026-09-12) Франция выступила за снятие санкций с Алишера Усманова. Это вызвало «огромное разочарование» у других стран ЕС | LEDE: Франция поддержала Словакию в ее предложении снять санкции с российског] (ru: Фра…
      Франция поддержала Словакию в ее предложении снять санкции с российского бизнесмена Алишера Усманова, сообщили Euronews неназванные европейские дипломаты.
  - (2026-09-12) В Одессе в результате российской атаки повреждена многоэтажка. Пострадали 35 человек | LEDE: Российские военные в ночь на 12 сентября нанесли комбинированный ракетно-дроновый удар по Одессе.] (ru: В О…
      Российские военные в ночь на 12 сентября нанесли комбинированный ракетно-дроновый удар по Одессе.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 287 new of 772 total
  - (2026-09-11) [California] On September 11, Governor Newsom welcomes CAL FIRE’s newest leaders as they answer the call to serve
      Source
  - (2026-09-11) [California] Governor Newsom proclaims Patriot Day
  - (2026-09-11) [Alaska] Patriot Day 2026
      WHEREAS, today marks 25 years since the American people experienced the worst terrorist attack on United States soil on September 11, 2001; and WHEREAS, although the attacks were intended to divide our Great Nation, Amer…
  - (2026-09-11) [California] Tech companies are selling kids’ data. A new California law aims to protect their privacy
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/05/053023_Community-College-Budget_LJ_CM_02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…
  - (2026-09-11) [California] Newsom wants kids to back off the clicks, chats and swipes
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/Teen-Phone_ISTOCK_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="C…
  - (2026-09-11) [California] Newsom signed 13 new laws to protect kids from technology. Will they work?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/091026-Newsom-Kids-Tech-Bills-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### Local News: St. Louis + Atlanta — 211 new of 247 total
  - (2026-09-11) [St. Louis] The reimagined nest: How St. Louis empty nesters are redesigning home
      At some point, all parents face that inevitable day when their last child leaves home. When the “nest” is empty, the dynamics of both the family and the home are forever changed. Whether the kids continue to return for c…
  - (2026-09-11) [St. Louis] 6 reasons to experience the Musial Awards in person
      Take your seat at Stifel Theatre for the Musial Awards, and you may notice something unexpected waiting for you: a package of tissues. There’s a reason they come with the evening. Over the next few hours, some of the big…
  - (2026-09-11) [St. Louis] Choosing a new toilet? Here’s how to find the right one
      A toilet probably isn’t the first selection that homeowners look forward to making when they begin planning a bathroom, especially when tile, lighting, and cabinetry offer so many opportunities to shape the room’s person…
  - (2026-09-11) [St. Louis] Ask George: With prices up and appetites down, is splitting an entrée frowned upon?
      I see three forces at work here: higher menu prices, which arguably encourages couples to share; so-called “portion fatigue,” with diners wanting less food, rather than dealing with (and paying for) leftovers; and, most…
  - (2026-09-11) [St. Louis] Where in St. Charles? – 9/11/2026
      Let’s see how well you know St. Charles. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess”…
  - (2026-09-12) [St. Louis] Latest Missouri poll finds another razor-thin margin ahead of November vote on abortion
      Polling done by SLU/YouGov in February found that 50% of Missourians supported reinstating an abortion ban. That dropped to 43% last month.

### Chinese Internal News — 211 new of 288 total
  - (2026-09-11) 发表大量煽动民族仇恨言论，造成重大恶劣影响，宋剑仁被判刑 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5xNTVfTDZyMWpLcVVWSFo4bE1mQ0lnSnh0ZHJidWlBcC1nQ1RqNE1xTkg2ZkpObFhtTkgxT253MHZNRngwd2lPNk4] (zh:…
      发表大量煽动民族仇恨言论，造成重大恶劣影响，宋剑仁被判刑 观察者网
  - (2026-09-11) 上海美国商会会长：美企离不开中国市场 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE85WGxJcjctb2ljVU1ONVFidzFWTTZMdHltcy1sVUd2d0Z2cDhhbXdoWktqdXdVZFFFb0tzeV8wNGU5VTI1ODBrT3lxdG14NldOe] (zh:…
      上海美国商会会长：美企离不开中国市场 观察者网
  - (2026-09-10) 世界科先声 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE1JbVFXT1VlOWFsd0g5LVZaTFlWTW1JZzlOTnc5bVJLU3ZhQ04zMGpUQU1NVjVQNnc1bG1wNHQ4UUE3TVFENEFhamdoMU5qTkh6Vmh5RVBnYlo3MG] (zh:…
      世界科先声 观察者网
  - (2026-09-10) “特朗普称胜选每人发5000美元，纯属吹牛” - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE81NjdvZE1tSEtLSXcxekZ2Sk1xMjN3OUxfSUZVLTRiVk9ZUFpTRmhBUlFleDFnZVhKMzhKRDFiWmtTbFdabXlzVWtmSkV3N] (zh:…
      “特朗普称胜选每人发5000美元，纯属吹牛” 观察者网
  - (2026-09-10) 乌克兰之殇 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiV0FVX3lxTE5QSGNEMERXa3VwaFE2RUhxX00taEFHMVNuYWhsMmthc3V4SVhGY2k0Yy1CQ1RTLTNqU1hpT0pzVlZ0LTM4Mk00aTF4QmttZzhiSklWOGdxVQ?oc=] (zh:…
      乌克兰之殇 观察者网
  - (2026-09-10) 城事 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5Ya0hFY0JEbWdMNzRaYXFBd3NTOG14cUtETnpQQjdqbkVIVUZVQTh5eUpROFFRMTJReWotLUFrNTQ1Mms3NUMyWnUySUFjeEEzVUZPN01pMDNaNzVCQ] (zh:…
      城事 观察者网

### U.S. Weather + Severe / Climate Outlooks — 98 new of 102 total
  - (2026-09-12) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-12) [Severe] Flash Flood Warning: Flash Flood Warning issued September 12 at 7:21AM EDT until September 12 at 1:15PM EDT by NWS Peachtree City GA
      FFWFFC The National Weather Service in Peachtree City has issued a * Flash Flood Warning for... Southwestern Cobb County in north central Georgia... Northwestern Douglas County in north central Georgia... Central Carroll…
  - (2026-09-12) [Moderate] Special Weather Statement: Special Weather Statement issued September 12 at 7:19AM EDT by NWS Tallahassee FL
      At 719 AM EDT/619 AM CDT/, Doppler radar was tracking strong thunderstorms along a line extending from 14 miles southeast of De Funiak Springs to 8 miles southeast of Santa Rosa Beach. Movement was east at 15 mph. HAZARD…
  - (2026-09-12) [Severe] Special Marine Warning: Special Marine Warning issued September 12 at 5:58AM CDT until September 12 at 9:00AM CDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Coastal Waters from Mexico Beach to Apalachicola out 20 NM... Coastal waters from Okaloosa-Walton County Line to Mexico Beac…
  - (2026-09-12) [Severe] Red Flag Warning: Red Flag Warning issued September 12 at 3:12AM PDT until September 14 at 11:00AM PDT by NWS Sacramento CA
      ...RED FLAG WARNING REMAINS IN EFFECT FROM 11 AM THIS MORNING TO 11 AM PDT MONDAY DUE TO WIND AND LOW RELATIVE HUMIDITY FOR A PORTION OF NORTHERN CALIFORNIA, GLENN/COLUSA COAST RANGE ABOVE 3000 FT, AND W. GLENN/COLUSA FO…
  - (2026-09-12) [Severe] Red Flag Warning: Red Flag Warning issued September 12 at 3:12AM PDT until September 14 at 11:00AM PDT by NWS Sacramento CA
      ...RED FLAG WARNING REMAINS IN EFFECT FROM 11 AM THIS MORNING TO 11 AM PDT MONDAY DUE TO WIND AND LOW RELATIVE HUMIDITY FOR A PORTION OF NORTHERN CALIFORNIA, GLENN/COLUSA COAST RANGE ABOVE 3000 FT, AND W. GLENN/COLUSA FO…

### Ukraine Theater (total-war monitoring) — 95 new of 239 total
  - (2026-09-12) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-11) [Liveuamap] Belarusian President Lukashenka announces conducting a full-scale army combat readiness check, including preparation for the mobilization Minsk Region, Belarus - Ukraine Interactive map -…
      Belarusian President Lukashenka announces conducting a full-scale army combat readiness check, including preparation for the mobiliz
  - (2026-09-10) [Liveuamap] Israeli Chief of Staff: Any attack on northern towns or Israeli military forces will be met with a swift and strong response, and the Blue Line in Lebanon will remain under our complete co…
      Israeli Chief of Staff: Any attack on northern towns or Israeli military forces will be met with a swift and st
  - (2026-09-07) [Liveuamap] Reporter: The army is carrying out a large-scale demolition operation within its controlled areas east of Khan Younis in the southern Gaza Strip. Khan Yunis, Gaza - Liveuamap
      Reporter: The army is carrying out a large-scale demolition operation within its controlled area
  - (2026-09-11) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap
  - (2026-09-11) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - iraq.liveuamap.com
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com iraq.liveuamap.com

### State Legislative Action — 71 new of 111 total
  - (2026-09-11) [Alabama HB 429] Crimes and offenses; unmanned aircraft systems, operation near ticketed entertainment events prohibited
      Crimes & Offenses
  - (2026-09-11) [Alabama HB 499] Constables; county commission, authorized to revise number of constables and geographic area served in county
      State & State Officers
  - (2026-09-11) [Alabama HB 282] Board of Pardons and Paroles; commencement date changed to March 1
      Authorities, Boards, & Commissions
  - (2026-09-11) [Alabama SB 154] State employees, cost-of-living increase for fiscal year beginning October 1, 2026
      Appropriations
  - (2026-09-11) [Alabama HB 220] Multi-member boards; Governor, Lieutenant Governor, Speaker, and President Pro Tempore authorized to replace any board member whom the Governor, Lieutenant Governor, Speaker, and Pres…
      Authorities, Boards, & Commissions
  - (2026-09-11) [Alabama SB 247] Insurance; to allow reorganization of a nonprofit health care service corporation under the control of a nonprofit holding company
      Businesses & Financial Institutions

### Ukrainian Internal News (national + local Kyiv) — 67 new of 136 total
  - (2026-09-12) На Філіппінах після пожежі на поромі загинули щонайменше 35 людей, понад 50 зникли безвісти | LEDE: Внаслідок пожежі на пасажирському поромі MV June Aster загинули 35 осіб, понад 50 зниклих шук] (uk:…
      Внаслідок пожежі на пасажирському поромі MV June Aster загинули 35 осіб, понад 50 зниклих шукають. Слідство встановлює причини трагедії та дії екіпажу.
  - (2026-09-12) У Болгарії палають склади збройової компанії | LEDE: У Болгарії сталася пожежа на складі боєприпасів EMKO біля села Горні Верпища. Пролунало кілька вибухів, постраждалих немає.] (uk: У Болгарії палают…
      У Болгарії сталася пожежа на складі боєприпасів EMKO біля села Горні Верпища. Пролунало кілька вибухів, постраждалих немає.
  - (2026-09-12) На Одещині після масованої атаки вже 35 постраждалих, ще двох шукають | LEDE: Внаслідок обстрілу Одещини пошкоджено житлові будинки, зруйновано реабілітаційний центр, рятувальники шукають зникл] (uk:…
      Внаслідок обстрілу Одещини пошкоджено житлові будинки, зруйновано реабілітаційний центр, рятувальники шукають зниклих.
  - (2026-09-12) Мамедов про реформу прокуратури: наступний Генпрокурор має обмежити власну владу | LEDE: ] (uk: Мамедов про реформу прокуратури: наступний Генпрокурор має обмежити власну владу)
  - (2026-09-12) Змінити систему, а не прізвище: завдання для майбутнього Генпрокурора | LEDE: Обрано ключові принципи змін у прокуратурі: реформаторський мандат, участь міжнародних експертів та нові механізми ] (uk:…
      Обрано ключові принципи змін у прокуратурі: реформаторський мандат, участь міжнародних експертів та нові механізми контролю й автономії.
  - (2026-09-12) "Мадяр": СБС вполювали 285 суден російського тіньового флоту | LEDE: Сили безпілотних систем під керівництвом Бровді ліквідували 285 суден тіньового флоту РФ в Азовському та Чорному морях за 10] (uk:…
      Сили безпілотних систем під керівництвом Бровді ліквідували 285 суден тіньового флоту РФ в Азовському та Чорному морях за 10 тижнів операції.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-12) [Ault & Company, Inc.] Form 4 (Reporting)
      filed 2026-09-12 01:59 UTC · role: Reporting — Filed: 2026-09-11 AccNo: 0001214659-26-011648 Size: 12 KB
  - (2026-09-12) [AULT MILTON C III] Form 4 (Reporting)
      filed 2026-09-12 01:59 UTC · role: Reporting — Filed: 2026-09-11 AccNo: 0001214659-26-011648 Size: 12 KB
  - (2026-09-12) [Hyperscale Data, Inc.] Form 4 (Issuer)
      filed 2026-09-12 01:59 UTC · role: Issuer — Filed: 2026-09-11 AccNo: 0001214659-26-011648 Size: 12 KB
  - (2026-09-12) [Raymond John w] Form 4 (Reporting)
      filed 2026-09-12 01:55 UTC · role: Reporting — Filed: 2026-09-11 AccNo: 0001193125-26-389607 Size: 4 KB
  - (2026-09-12) [IonQ, Inc.] Form 4 (Issuer)
      filed 2026-09-12 01:55 UTC · role: Issuer — Filed: 2026-09-11 AccNo: 0001193125-26-389607 Size: 4 KB
  - (2026-09-12) [Rabinowitz Matthew] Form 4 (Reporting)
      filed 2026-09-12 01:35 UTC · role: Reporting — Filed: 2026-09-11 AccNo: 0001646382-26-000019 Size: 15 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 40 new of 57 total
  - (2026-09-12) [The Hacker News] When the Whole Company Adopts AI: What It Does to Your SOC
      Over the past year, we watched a new class of alert appear in enterprise security operations centers and grow faster than anything else in the stream: alerts that were triggered by AI tools and agents. Not attacks agains…
  - (2026-09-12) [The Hacker News] OpenAI Agents Linked to RubyGems Campaign That Gained RCE on RubyDoc Servers
      The "major malicious attack" that targeted RubyGems in May 2026 was the work of a swarm of OpenAI agents, according to a new report published by researchers Spencer Kitts, Thomas Larsen, and Sydney Von Arx. On May 12, Ma…
  - (2026-09-12) [The Register] Dell's 52-inch enormo-monitor is a tsunami of impractical fun
      You probably don't need it, but as an example of the possible it impresses
  - (2026-09-12) [The Register] The aircraft might not be flying, but the certificate has gone on vacation
      Information is not forthcoming from this screen
  - (2026-09-11) [BleepingComputer] Hackers abused Claude to extract secrets from 1.8M Android apps
      Anthropic says multiple threat groups, including the financially motivated and state-sponsored espionage groups linked to Russia and China, tried to abuse its Claude AI model for malicious purposes. [...]
  - (2026-09-11) [BleepingComputer] Florida confirms DMV database breached via stolen police account
      The Florida Department of Highway Safety and Motor Vehicles (FLHSMV) has confirmed that its DAVID driver database suffered a data breach, saying the attackers gained access using credentials belonging to a police departm…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 29 new of 60 total
  - (2026-09-11) U.S. Court of Appeals, 1st Cir.: Linardon v. Walsh
  - (2026-09-11) U.S. Court of Appeals, 1st Cir.: Roberge v. Travelers Prop. Casualty Co. of America
  - (2026-09-11) U.S. Court of Appeals, 1st Cir.: United States v. Parsons
  - (2026-09-11) U.S. Court of Appeals, 1st Cir.: United States v. Pena de la Cruz
  - (2026-09-11) U.S. Court of Appeals, 6th Cir.: United States v. Steve Croom, Jr.
  - (2026-09-11) U.S. Court of Appeals, 6th Cir.: United States v. Todd Allen Stafford

### Government & military aircraft airborne (OpenSky) — 20 new of 20 total
  - (2026-09-12) JAF4KN (Bulgaria)
      icao24: 4520ce · position: (45, 0.2578) · alt: 11277m · 916km/h
  - (2026-09-12) JAF7212 (Bulgaria)
      icao24: 4520aa · position: (42.7748, -1.6725) · alt: 10668m · 917km/h
  - (2026-09-12) CFC3701 (Canada)
      icao24: c2b373 · position: (48.8625, -62.5843) · alt: 11582m · 789km/h
  - (2026-09-12) SAMU05 (France)
      icao24: 39ca81 · position: (44.485, 6.0259) · alt: 1135m · 215km/h
  - (2026-09-12) CNA22 (Spain)
      icao24: 3475cb · position: (27.7759, -15.7242) · alt: 914m · 148km/h
  - (2026-09-12) SAMU13 (France)
      icao24: 39c902 · position: (43.5346, 5.4424) · alt: 167m · 5km/h

### U.S. Federal Action — 19 new of 19 total
  - (2026-09-14) Modifying the Scope of Products of Canada Subject to the Additional Duties Imposed To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Motor Vehicles
  - (2026-09-14) Modifying the Scope of Products of Canada Subject to the Additional Duties Imposed To Offset Canadian Discrimination Against the Commerce of the United States With Respect to Alcoholic Beverages
  - (2026-09-14) Excluding Certain Canadian Products From Importation Into the United States in Response to Continued Discrimination Against the Commerce of the United States With Respect to Motor Vehicles
  - (2026-09-14) Excluding Certain Canadian Products From Importation Into the United States in Response to Continued Discrimination Against the Commerce of the United States With Respect to Dairy
  - (2026-09-14) Excluding Certain Canadian Products From Importation Into the United States in Response to Continued Discrimination Against the Commerce of the United States With Respect to Alcoholic Beverages
  - (2026-09-14) Use of Certain Restricted Category Aircraft for the Transport of Firefighters for Wildfire Suppression
      FAA is evaluating a future amendment to its regulations to permit firefighters to be transported to and from the site of a wildfire aboard certain restricted category aircraft when the purpose of that transportation is t…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-12) LoL: Anyone's Legend vs Invictus Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $1,869,237 · resolves 2026-09-12
  - (2026-09-12) LoL: Anyone's Legend vs Invictus Gaming (BO5) - LPL Playoffs
      yes price: 72% · 24h volume: $1,583,977 · resolves 2026-09-12
  - (2026-09-12) LoL: Anyone's Legend vs Invictus Gaming - Game 1 Winner
      yes price: 0% · 24h volume: $1,392,546 · resolves 2026-09-12
  - (2026-09-12) Will Kristi Noem win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $1,261,096 · resolves 2028-11-07
  - (2026-09-12) LoL: Anyone's Legend vs Invictus Gaming - Game 3 Winner
      yes price: 92% · 24h volume: $935,334 · resolves 2026-09-12
  - (2026-09-12) Counter-Strike: BetBoom Team vs G2 (BO3) - FISSURE PLAYGROUND Playoffs
      yes price: 50% · 24h volume: $893,225 · resolves 2026-09-12

### Government Action: Sanctions + Procurement + Foreign Agents — 13 new of 107 total
  - (2026-09-08) [OFAC] Iran-related Designations; Counter Terrorism Designations; Updates to Iran-related General Licenses; Issuance of Counter Terrorism General License - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Counter Terrorism Designations; Updates to Iran-related General Licenses; Issuance of Counter Terrorism General License Office of Foreign Assets Control (.gov)
  - (2026-09-09) [OFAC] | Office of Foreign Assets Control - Office of Foreign Assets Control (.gov)
      | Office of Foreign Assets Control Office of Foreign Assets Control (.gov)
  - (2026-09-09) [OFAC] 77. How can I find the status of my pending specific license application? - Office of Foreign Assets Control (.gov)
      77. How can I find the status of my pending specific license application? Office of Foreign Assets Control (.gov)
  - (2026-09-08) [OFAC] Suspended Indefinitely, Effective September 8, 2026 - Office of Foreign Assets Control (.gov)
      Suspended Indefinitely, Effective September 8, 2026 Office of Foreign Assets Control (.gov)
  - (2026-09-12) [USASpending] $2,913,354,965 → MAXIMUS FEDERAL SERVICES, INC.: CONTACT CENTER OPERATIONS
      Agency: Department of Health and Human Services. Description: CONTACT CENTER OPERATIONS
  - (2026-09-12) [USASpending] $1,988,277,191 → BLUE ORIGIN MANUFACTURING, LLC: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING
      Agency: National Aeronautics and Space Administration. Description: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING SYSTEM INTEGRATED LANDER.

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-09-11) M 6.6 - 115 km NNE of Teluknaga, Indonesia
      M6.6 · 115 km NNE of Teluknaga, Indonesia · depth 358.597 km
  - (2026-09-11) M 5.9 - 253 km ENE of Lospalos, Timor Leste
      M5.9 · 253 km ENE of Lospalos, Timor Leste · depth 111.763 km
  - (2026-09-12) M 5.1 - South Sandwich Islands region
      M5.1 · South Sandwich Islands region · depth 10 km
  - (2026-09-12) M 4.9 - South Sandwich Islands region
      M4.9 · South Sandwich Islands region · depth 98.187 km
  - (2026-09-12) M 4.9 - 147 km WNW of Sola, Vanuatu
      M4.9 · 147 km WNW of Sola, Vanuatu · depth 16.926 km
  - (2026-09-11) M 4.9 - 235 km W of Puerto Chacabuco, Chile
      M4.9 · 235 km W of Puerto Chacabuco, Chile · depth 10 km

### Paper Trading Scorecard — 12 new of 128 total
  - (2026-09-12) [Polymarket] Trump x Greenland deal signed by December 31?
      This market will resolve to “Yes” if both Denmark and the United States sign a deal, treaty, or similar international agreement of any kind relating to Greenland by December 31, 2026, 11:59 PM ET. Otherwise, this market…
  - (2026-09-12) [Polymarket] Will Apple release a foldable iPhone by September 30?
      This market will resolve to "Yes" if Apple officially releases a foldable iPhone by September 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". In order to be considered released, the product must be av…
  - (2026-09-12) [Polymarket] Will the next diplomatic US-Iran meeting be in Saudi Arabia by September 30, 2026?
      On June 22, the first round of U.S.-Iran diplomatic talks in Switzerland concluded, with mediators reporting progress toward a roadmap for a final deal and follow-on technical talks expected to continue (see: https://www…
  - (2026-09-12) [Manifold] Will Maduro comeback to Venezuela?
  - (2026-09-12) [Manifold] Daily Coinflip
  - (2026-09-12) [Manifold] Will Quroe's brother join Manifold before October 2026?

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-12) [China] Explainer : How Lao role as Southeast Asia battery is changing | News | Eco - Business
      eco-business.com · English
  - (2026-09-12) [China] Space Telescope Interferometer to Image Exoplanet Continents – NextBigFuture . com
      nextbigfuture.com · English
  - (2026-09-12) [China] ECB hikes rates again as inflation risks fuel tightening bets
      hongkongherald.com · English
  - (2026-09-12) [China] Self - propelled howitzer spits fire on plateau - Photo - 中国军网 （ 英文版 ）
      eng.chinamil.com.cn · English
  - (2026-09-12) [China] Anti - aircraft shooting assessment - Focus - 中国军网 （ 英文版 ）
      eng.chinamil.com.cn · English
  - (2026-09-12) [China] 20 years of BRICS : From Wall Street acronym to global power center
      taiwansun.com · English

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 24 total
  - (2026-09-11) CVE-2026-84869 · ConnectWise ScreenConnect: ConnectWise ScreenConnect Improper Privilege Management and Missing Authorization Vulnerability
      vendor: ConnectWise · product: ScreenConnect · CISA remediation by 2026-09-14
  - (2026-09-11) CVE-2026-42016 · JFrog Artifactory: JFrog Artifactory Incorrect Authorization Vulnerability
      vendor: JFrog · product: Artifactory · CISA remediation by 2026-09-25
  - (2026-09-11) CVE-2026-42018 · JFrog Artifactory: JFrog Artifactory Improper Authentication Vulnerability
      vendor: JFrog · product: Artifactory · CISA remediation by 2026-09-25
  - (2026-09-11) CVE-2026-85706 · GitLab Community Edition and Enterprise Edition: GitLab Community Edition and Enterprise Edition Path Traversal Vulnerability
      vendor: GitLab · product: Community Edition and Enterprise Edition · CISA remediation by 2026-09-14

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-12) [Marginal Revolution] UK fact of the day
      The UK economy grew 0.4 per cent in July as the global AI boom helped deliver an unexpectedly robust start to the third quarter, in a boost to Prime Minister Andy Burnham as he prepares for a tough first Budget next mont…
  - (2026-09-12) [Marginal Revolution] The Prediction Archive
      The Prediction Archive is a public database of tens of thousands of world predictions. Using AI it tracks predictions over many decades and marks to market. I was surprised to discover that I am currently the highest ran…
  - (2026-09-12) [Marginal Revolution] Labor reallocation during the Industrial Revolution
      New technologies swept through Britain during the Second Industrial Revolution, destroying old jobs and creating new ones. We know little about how workers reallocated. Using 170 million full-count British census observa…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-12) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=16, 14d-median=18; carrying terms: changes, program, safety, national, commission, proposed, unless, existing, certain, final, special, applicable
- state_bills: today=111, 7d-median=88, 14d-median=80; carrying terms: common, general, agency, programs, water, makes, business, county, payment, specified, period, approve
- state_news: today=772, 7d-median=549, 14d-median=586; carrying terms: candidates, general, since, analysis, srcset, colorado, error, union, oregon, hawaii, around, appeals
- local_news: today=247, 7d-median=226, 14d-median=226; carrying terms: since, appeared, county, killed, football, missouri, class, residents, charged, years, https, officials
- foreign_news: today=986, 7d-median=1004, 14d-median=1006; carrying terms: internet, candidates, general, given, flood, union, abuse, crackdown, makes, central, measures, traffic
- chinese_internal: today=288, 7d-median=284, 14d-median=284; carrying terms: cbmizefvx, title, https, cbmiw, global, articles, cbmix, blank, caixin, cbmia, cbmibkfvx, target
- russian_internal: today=1059, 7d-median=1059, 14d-median=1050; carrying terms: laquo, politico, novaya, https, raquo, forbidden, httperror, error, street, gazeta, journal, media
- ukrainian_internal: today=136, 7d-median=132, 14d-median=131; carrying terms: remains, general, error, zelensky, economic, killed, transport, political, energy, destroyed, threat, prime
- ukraine_theater: today=239, 7d-median=486, 14d-median=528; carrying terms: cuxqcnhzrmngsnazc, vlbttvfnqk, htjdqow, general, cfnrswxnd, cbmixefvx, cuxnzghps, dhdmnbrxjgoxe, rgcxcwz, error, yxzkmkv, iranian
- paper_bets: today=128, 7d-median=131, 14d-median=131; carrying terms: office, nebraska, texas, speed, chair, goldman, general, fuentes, secretary, romania, district, earthquake
- weather: today=102, 7d-median=102, 14d-median=105; carrying terms: chance, gusty, afdfwd, flood, afdokx, worth, water, locally, hazardous, afdilx, discussion, bring
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, latest, jtsjol, payrolls, jolts, vixcls, pcepilfe, dcoilwtico, payems, assets, dexjpus, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, large, commodities, agriculture, crude, equities, natural, bitcoin, china, russell, futures, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=107, 7d-median=104, 14d-median=106; carrying terms: haitian, general, issuance, agency, programs, portal, sevastopol, crimea, occupation, btdyc, jihad, sanctions
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, error, https, congresstrading, quiver, unauthorized, httperror, client, quiverquant
- billionaires: today=0, 7d-median=0, 14d-median=15
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: company, state, appeals, supreme, blanche, court, national, center, williams, international, university, robert
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, holdings, therapeutics, group, technology, health, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: sherrod, disbursements, brown, elect, shawn, house, cortez, pinkston, congress, ossoff, senate, cooper
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, china
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: killed, english, israel, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=20, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, bulgaria, kingdom, canada, spain
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: viadana, remains, activities, early, reference, diarrhoea, hospitalized, multi, hygiene, clade, international, indicating
- cisa_kev: today=24, 7d-median=21, 14d-median=21; carrying terms: server, improper, missing, function, netscaler, vulnerability, injection, artifactory, microsoft, jfrog, command, forgery
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=13, 7d-median=11, 14d-median=11; carrying terms: depth, islands, indonesia, region, south, chile, vanuatu, ruteng, sandwich, puerto
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: change, championship, price, volume, interest, donetsk, resolves, meeting, september, champions, shakhtar, decrease
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, revolution, economist, marginal, class, conversable, conversableeconomist, government, evidence, economy, economists, price
- tech_news: today=57, 7d-median=57, 14d-median=56; carrying terms: agency, openai, technology, software, agents, newsletter, computerweekly, intelligence, target, infrastructure, spectrum, company
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: arrington, analilia, kathy, thune, sanford, mccollum, pramila, goldman, speech, luttrell, tommy, moore
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, market, either, consensus, module, placed, claude, evidence, markets, today, placement, converges

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-08] ECB press: Frank Elderson: Fireside chat
- [2026-09-09] ECB press: Christine Lagarde: The choice facing Europeans
- [2026-09-10] ECB press: Monetary policy decisions
- [2026-09-10] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-11] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*