# WORLDSCOPE morning brief — 2026-09-05

## Headline
2230 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (551) · Russian Internal News (state + in-exile) (412) · World leaders & government officials (324) · Chinese Internal News (227) · Local News: St. Louis + Atlanta (124) · State-Level News (120) · U.S. Weather + Severe / Climate Outlooks (98) · State Legislative Action (60) · Ukrainian Internal News (national + local Kyiv) (49) · Ukraine Theater (total-war monitoring) (49) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 551 new of 1085 total
  - (2026-09-04) [Global] Mistrial declared in Lindsay Clancy murder case, after jury deadlocks
      The mistrial now puts the murder case - and Clancy's future - in limbo as to whether she will be held criminally liable in the deaths of her three kids.
  - (2026-09-05) [Global] Trump envoys arrive in Moscow ahead of Ukraine talks, reports say
      Steve Witkoff and Jared Kushner are due to hold talks with Russia before travelling to Ukraine on Sunday.
  - (2026-09-04) [Global] Nepal rescuers try to reach dozens trapped in tunnel after two found alive
      More than 1,300 people have died and thousands are missing, but rescuers' hopes have risen after finding survivors in a tunnel.
  - (2026-09-05) [Global] Trump signs order to remove endangered species protection for grey wolves
      The US president says the move will help ranchers, but conservationists say it could derail efforts to recover populations.
  - (2026-09-04) [Global] Germany's far-right AfD bids for first taste of power in eastern vote
      If it wins an outright majority in Saxony-Anhalt, it would be the first time a far-right party has held state-level power in Germany since World War Two.
  - (2026-09-05) [Global] At least two dead in blast at Bolivia military barracks
      Authorities fear the death toll in Viacha will rise and warn people to stay away from the barracks due to a risk of further explosions.

### Russian Internal News (state + in-exile) — 412 new of 1042 total
  - (2026-09-05) Война. 1655-й день. Спецпосланники Трампа приехали в Москву, чтобы возобновить мирные переговоры. На время их визита Зеленский предложил прекратить огонь — Россия ответила ударом по Украине | L] (ru:…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-05) Переговорщики Трампа — Стив Уиткофф и Джаред Кушнер — прилетели в Москву | LEDE: Самолет, на борту которого находятся спецпосланник президента США Стив Уиткофф и зять американского лидера Дж] (ru: Пер…
      Самолет, на борту которого находятся спецпосланник президента США Стив Уиткофф и зять американского лидера Джаред Кушнер, приземлился в московском аэропорту Внуково, сообщают корреспонденты РИА Новости и ТАСС.
  - (2026-09-05) Зеленский: Россия демонстративно ударила по аэропортам в Киеве и Борисполе на фоне сообщений о визите переговорщиков США | LEDE: Войска РФ в ночь на 5 сентября нанесли «демонстративные» и «ц] (ru: Зел…
      Войска РФ в ночь на 5 сентября нанесли «демонстративные» и «целенаправленные» удары по аэропортам в Киеве и Борисполе, заявил президент Украины Владимир Зеленский. По его словам, так Россия отреагировала на возможный виз…
  - (2026-09-05) РИА Новости: у российской фигуристки Камилы Валиевой отозвали нейтральный статус. Без него нельзя участвовать в международных соревнованиях | LEDE: Международный союз конькобежцев (ISU) отоз] (ru: РИА…
      Международный союз конькобежцев (ISU) отозвал у российской фигуристки Камилы Валиевой выданный в августе нейтральный статус, который позволял ей выступать на международных соревнованиях, сообщил РИА Новости неназванный и…
  - (2026-09-05) Когда вы в последний раз употребляли слово «мох»? А «опушка»? Слова, связанные с природой, исчезают из речи, книг и мультфильмов. И это имеет серьезные последствия | LEDE: Люди все реже гово] (ru: Ког…
      Люди все реже говорят о природе. Слова, связанные с ней, исчезают также из книг и мультфильмов. Такое отдаление людей от природы имеет экологические последствия. Издание «Кедр» опубликовало материал, в котором лингвист А…
  - (2026-09-05) Будет ли новая волна эмиграции из России? Для ответа на этот вопрос «Медузе» нужна ваша помощь. Если вы уже готовитесь к отъезду — расскажите нам | LEDE: Чем ближе сентябрьские выборы в Госд] (ru: Буд…
      Чем ближе сентябрьские выборы в Госдуму, тем больше слухов о возможной мобилизации в России. Хотя подтверждений этому нет, в соцсетях практически каждый день появляются новые истории о том, как россияне хотят поскорее уе…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 227 new of 276 total
  - (2026-09-03) 财经早知道｜十部门重磅发布 设立国家中小企业发展基金二期 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9zZFZpblQ3c0MzaFN3M3JRYm80SlRfOWRSRGdOLXJVSEJzMWI2YjVjVXlKbHJ4eUxYRHY4Y0FHMmF2ZHBXNDFXaS1Nb] (zh:…
      财经早知道｜十部门重磅发布 设立国家中小企业发展基金二期 财新
  - (2026-09-04) 今日开盘：两市双双高开 沪指涨幅0.34% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBtRFJhaFFxNU1UaGtsamtJM05STjRQSW5XVXRwZHdGVHd4TWxxY0VrcDRDb28tRmRNaEc2X0lQVFU3cUR1WG1tbjM5Z1A1TUdh] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.34% 财新
  - (2026-09-03) 潘功胜谈应对全球失衡 各国应制定中长期政策、避免“翻烧饼” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBPaGlRTGVDeFJrc3VWYV8zRFl6RWFHQTRnZU9wdHFZUENFN1pEanlUWU00aDFkS2hpLUZmcGFRZ3N5MnVBVU9JakhJ] (zh:…
      潘功胜谈应对全球失衡 各国应制定中长期政策、避免“翻烧饼” 财新
  - (2026-09-04) 台风不只是一场风：风、潮、雨如何合成上海的风险账 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9wRlVjM3pYdDBSelVRXzFubWc2RlJESkhlc0pMUjRJaFVQS3N3NE9BZ2x4S21ONG1IR0R4V3dqMGhBOV9vaVdsdHl0cWFvU] (zh:…
      台风不只是一场风：风、潮、雨如何合成上海的风险账 财新
  - (2026-09-04) K型分化？ i型割裂？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE93Z2ZGVER4MGhheHF3WVQ2Vmx5NGNXQzJ4anNUaWtzWnF6QmN3cHJyUUtMdl9xel9nVFBNc0VJQmhKanIzbzNzeG1YUXhfR3Zobm80MHp2Um] (zh:…
      K型分化？ i型割裂？ 财新
  - (2026-09-04) 冷静认识平台和AI对经济增长的支撑作用 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9HLTNiN3ZtemVwWUdmU1FqNGtIQkpVSjhKalVCcFpTb0ptQ1hhVDk0MzVXd1JxNTNmSzF2UkJqTEdKUzdHaS1maUFERzdQd0hRdE] (zh:…
      冷静认识平台和AI对经济增长的支撑作用 财新

### Local News: St. Louis + Atlanta — 124 new of 234 total
  - (2026-09-03) [St. Louis] Are the stars aligned for a downtown St. Louis renaissance? Spencer and Kehoe say yes
  - (2026-09-05) [St. Louis] Catch up on the latest in St. Louis-area high school football
      See scores, game stories, standout performances, photos and video from the second weekend of high school football in Missouri and third in Illinois.
  - (2026-09-05) [St. Louis] Q&A: How uncommon is this sweltering St. Louis September?
      How long has it been since we've had five straight days of 99-plus, like St. Louis did this week? When was it last this hot in September?
  - (2026-09-05) [St. Louis] Five things to watch when City SC faces Vancouver on Saturday night
      After lots of rearranging of the lineup off the field, the time for City SC coach Yoann Damet to put the talent in order on the field comes Saturday, when City SC faces the first-place Vancouver Whitecaps at BC Place.
  - (2026-09-05) [St. Louis] Simple approach helps make Webster Groves' Clark Montgomery one of state's best swimmers
      Clark Montgomery has made state appearances in each of his first three seasons with the Statesmen and has earned a pair of individual medals the last two.
  - (2026-09-05) [St. Louis] Ump took issue with rookie's cap. Cardinals irked by ump. Ivan Herrera's homer erases it all.
      Cardinals manager Oli Marmol called it a 'power-hungry' move for umpire to tell rookie to adjust his tilted cap, and it nearly cost the Cardinals before a ninth-inning homer erased all the frustrations with a 7-6 victory…

### State-Level News — 120 new of 623 total
  - (2026-09-04) [California] Governor Gavin Newsom on California securing massive victory for democracy
  - (2026-09-05) [Alabama] Governor Kay Ivey Honors Alabama Workers in Labor Day Message
      Governor Ivey released a video message honoring the hardworking men and women whose dedication strengthens Alabama and drives America forward. (Governor’s Office, Alyssa Turner)
  - (2026-09-04) [Connecticut] Puerto Rico water crisis, youth marketing campaign: CT politics news
      <img width="1024" height="684" src="https://ctmirror.org/wp-content/uploads/2026/09/Susan-Bysiewicz-Dolly-Parton-9.3.26-1024x684.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="a…
  - (2026-09-04) [Connecticut] Jahana Hayes, angling for labor chair, suggests Dems failed unions
      <img width="1024" height="861" src="https://ctmirror.org/wp-content/uploads/2026/09/IMG_2064-1024x861.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctmi…
  - (2026-09-04) [Delaware] Delmarva Power sues to overturn interim rate cut
      <img width="1024" height="679" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/01/Delmarva-Power.jpg?fit=1024%2C679&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" d…
  - (2026-09-05) [Hawaii] Office of the Governor – News Release – Gov. Green and Leaders Provide Update on Hurricane Lowell
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA GOVERNOR GREEN AND LEADERS PROVIDE UPDATE ON HURRICANE LOWELL FOR IMMEDIATE RELEASE September 4, […]

### U.S. Weather + Severe / Climate Outlooks — 98 new of 105 total
  - (2026-09-05) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 5 at 7:05AM EDT until September 5 at 7:15AM EDT by NWS Charleston WV
      At 704 AM EDT, severe thunderstorms were located along a line extending from near Athens to 8 miles west of Albany, moving southeast at 45 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage…
  - (2026-09-05) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 5 at 6:02AM CDT until September 5 at 9:00AM CDT by NWS La Crosse WI
      * WHAT...Visibility 1/4 mile or less in dense fog. * WHERE...Dodge, Fillmore, Mower, and Olmsted Counties. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-09-05) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 5 at 6:02AM CDT until September 5 at 9:00AM CDT by NWS La Crosse WI
      * WHAT...Visibility 1/4 mile or less in dense fog. * WHERE...Floyd, Mitchell, Chickasaw, and Howard Counties. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-09-05) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 5 at 6:59AM EDT until September 5 at 7:45AM EDT by NWS Charleston WV
      SVRRLX The National Weather Service in Charleston West Virginia has issued a * Severe Thunderstorm Warning for... Calhoun County in north central West Virginia... Southwestern Ritchie County in northwestern West Virginia…
  - (2026-09-05) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 5 at 5:58AM CDT until September 5 at 9:00AM CDT by NWS Twin Cities/Chanhassen MN
      * WHAT...Visibility as low as one quarter mile in dense fog. * WHERE...Rice, Steele, and Goodhue Counties. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-09-05) [Moderate] Special Weather Statement: Special Weather Statement issued September 5 at 6:54AM EDT by NWS Charleston WV
      At 654 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from 7 miles east of Elizabeth to 9 miles east of Sandyville. Movement was southeast at 40 mph. HAZARD...Wind gusts up to 40 mph and p…

### State Legislative Action — 60 new of 82 total
  - (2026-09-05) [California AB 1707] Electricians: certification application, examination, and renewal.
      Existing law establishes the Division of Labor Standards Enforcement, under the direction of the Labor Commissioner, within the Department of Industrial Relations, for the purpose of enforcing labor laws. Existing law re…
  - (2026-09-05) [California SB 1388] Affordable Housing Risk Reduction Program.
      Existing law establishes the Department of Housing and Community Development and requires it to administer various programs intended to promote the development of housing, including the Multifamily Housing Program, pursu…
  - (2026-09-05) [California AB 2298] Pupil instruction: computer science: content standards.
      Existing law establishes the Instructional Quality Commission and requires the commission to, among other things, advise and recommend to the State Board of Education the policies and activities that are needed to implem…
  - (2026-09-05) [California AB 1976] Streets and highways: pedestrian and bicycle facilities.
      (1) Existing law grants the legislative body of a city certain powers with respect to city streets and highways, including the power to construct and maintain those streets and highways. Existing law grants the board of…
  - (2026-09-05) [California AB 706] Forest Organic Residue, Energy, and Safety Transformation (FOREST) and Wildfire Prevention Fund Act.
      Existing law establishes in the Natural Resources Agency the Department of Forestry and Fire Protection (CAL-FIRE) and makes CAL-FIRE responsible for, among other things, fire protection and prevention, as provided. Exis…
  - (2026-09-05) [California AB 2471] Alfred E. Alquist Seismic Safety Commission.
      Existing law, the California Emergency Services Act, establishes the Office of Emergency Services within the Governor's office under the supervision of the Director of Emergency Services and makes the office responsible…

### Ukrainian Internal News (national + local Kyiv) — 49 new of 138 total
  - (2026-09-05) Віткофф та Кушнер прибули в Москву | LEDE: Стів Віткофф і Джаред Кушнер прилетіли до Москви для перемовин з Путіним. Вони привезли пропозицію щодо завершення війни і готуються до візиту в Київ.] (uk:…
      Стів Віткофф і Джаред Кушнер прилетіли до Москви для перемовин з Путіним. Вони привезли пропозицію щодо завершення війни і готуються до візиту в Київ.
  - (2026-09-05) Хакери злили в мережу конфіденційні дані Сенату Берліна | LEDE: ] (uk: Хакери злили в мережу конфіденційні дані Сенату Берліна)
  - (2026-09-05) Буданов: Пропозицію про припинення вогню донесли Путіну, той не відповів | LEDE: Кирило Буданов повідомив, що Україна передала Росії пропозицію припинити бойові дії, але відповіді не отримала. ] (uk:…
      Кирило Буданов повідомив, що Україна передала Росії пропозицію припинити бойові дії, але відповіді не отримала. Деталі перемир'я – у матеріалі.
  - (2026-09-05) Зеленський: Росія вдарила по аеропортах в Жулянах та Борисполі | LEDE: Президент Володимир Зеленський заявив, що в ніч на 5 вересня Росія цілеспрямовано атакувала аеропорти "Київ" (Жуляни) та "] (uk:…
      Президент Володимир Зеленський заявив, що в ніч на 5 вересня Росія цілеспрямовано атакувала аеропорти "Київ" (Жуляни) та "Бориспіль" – за його словами, вперше за довгий час.
  - (2026-09-05) Більшість поляків вірить у ймовірність російських провокацій проти Польщі | LEDE: ] (uk: Більшість поляків вірить у ймовірність російських провокацій проти Польщі)
  - (2026-09-05) Росіяни атакували СТО на Дніпропетровщині: загинула людина, ще 5 поранені | LEDE: У Дніпровському районі російські війська завдали удару по станції технічного обслуговування, внаслідок чого заг] (uk:…
      У Дніпровському районі російські війська завдали удару по станції технічного обслуговування, внаслідок чого загинула людина, ще п'ятеро дістали поранення.

### Ukraine Theater (total-war monitoring) — 49 new of 239 total
  - (2026-09-05) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-04) [Liveuamap] Units of the Defense Forces were ordered to observe a regime of silence on the front line from 00:00 on September 5 to 23:59 on September 8 — sources of Ukrainy Pravda Kyiv, Kyiv city - Uk…
      Units of the Defense Forces were ordered to observe a regime of silence on the front line from 00:00 on September 5 to 23:59 on S
  - (2026-09-03) [Liveuamap] China Interactive News Map - china.liveuamap.com - Liveuamap
      China Interactive News Map - china.liveuamap.com Liveuamap
  - (2026-09-03) [Liveuamap] Exodus from the towns of Maqbana district and Al-Kadha area in Taiz governorate after Houthis took control of them. - Liveuamap
      Exodus from the towns of Maqbana district and Al-Kadha area in Taiz governorate after Houthis took control of them. &nbs
  - (2026-09-04) [Liveuamap] Drones have attacked chemical plant in Sterlitamak, Bashkiria - Liveuamap
      Drones have attacked chemical plant in Sterlitamak, Bashkiria Liveuamap
  - (2026-09-04) [Liveuamap] Israeli army: Shin Bet forces raided a building in Gaza City and arrested the head of Hamas&039 - Liveuamap
      Israeli army: Shin Bet forces raided a building in Gaza City and arrested the head of Hamas&039<

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-05) [Novick Jared] Form 4 (Reporting)
      filed 2026-09-05 01:56 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001493152-26-041638 Size: 6 KB
  - (2026-09-05) [WRAP TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-09-05 01:56 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0001493152-26-041638 Size: 6 KB
  - (2026-09-05) [WRAP TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-09-05 01:55 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0001493152-26-041637 Size: 6 KB
  - (2026-09-05) [Cohen Scot] Form 4 (Reporting)
      filed 2026-09-05 01:55 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001493152-26-041637 Size: 6 KB
  - (2026-09-05) [Rackspace Technology, Inc.] Form 4 (Issuer)
      filed 2026-09-05 01:55 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0001684713-26-000003 Size: 6 KB
  - (2026-09-05) [Kandiah Gajakarnan Vibushanan] Form 4 (Reporting)
      filed 2026-09-05 01:55 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001684713-26-000003 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-09-05) [Israel-Iran-Hezbollah axis · keywords] Life returned to me : Lebanese father welcomes son home after release from Israeli detention
      aa.com.tr · English · tone NA
  - (2026-09-05) [Israel-Iran-Hezbollah axis · keywords] Months after ceasefire , Israel and Hezbollah battle over a strategic hill in Lebanon
      wellandtribune.ca · English · tone NA
  - (2026-09-05) [Israel-Iran-Hezbollah axis · keywords] Months after ceasefire , Israel and Hezbollah battle over a strategic hill in Lebanon
      durangoherald.com · English · tone NA
  - (2026-09-05) [Israel-Iran-Hezbollah axis · keywords] Months after ceasefire , Israel and Hezbollah battle over a strategic hill in Lebanon
      clickorlando.com · English · tone NA
  - (2026-09-05) [Israel-Iran-Hezbollah axis · keywords] Three killed in Israeli strikes on Lebanon , health ministry says
      euronews.com · English · tone NA
  - (2026-09-05) [Israel-Iran-Hezbollah axis · keywords] Blasts Reported Near Kharg Island Oil Hub
      arabherald.com · English · tone NA

### Court opinions of consequence (federal & state) — 21 new of 60 total
  - (2026-09-04) U.S. Court of Appeals, 6th Cir.: Summit Locations, LLC v. Bd. of Trs., Bath Twp., Ohio
  - (2026-09-04) U.S. Court of Appeals, D.C. Cir.: League of Women Voters v. DHS
  - (2026-09-04) U.S. Court of Appeals, 9th Cir.: Trigueros Quizar v. Blanche
  - (2026-09-04) U.S. Court of International Trade: Jiangsu Nova Intelligent Logistics Equip. Co. v. United States
  - (2026-09-04) U.S. Court of International Trade: Catfish Farmers of Am. v. United States
  - (2026-09-04) U.S. Court of International Trade: Industrial Pesquera Santa Priscila, S.A. v. United States

### Government & military aircraft airborne (OpenSky) — 21 new of 21 total
  - (2026-09-05) JAF4KN (Bulgaria)
      icao24: 4520ce · position: (40.6392, -2.4981) · alt: 11269m · 796km/h
  - (2026-09-05) JAF95J (Bulgaria)
      icao24: 4520aa · position: (46.1094, -3.1821) · alt: 10660m · 825km/h
  - (2026-09-05) SAMU71 (France)
      icao24: 398c4e · position: (46.5775, 5.2646) · alt: 350m · 233km/h
  - (2026-09-05) SAMU13 (France)
      icao24: 39c902 · position: (43.2512, 5.5055) · alt: 632m · 186km/h
  - (2026-09-05) CFC2984 (Canada)
      icao24: c2b585 · position: (50.7886, 7.4998) · alt: 4876m · 495km/h
  - (2026-09-05) KAF3226 (Kuwait)
      icao24: 7061f5 · position: (36.4711, 20.7931) · alt: 6096m · 578km/h

### Paper Trading Scorecard — 16 new of 132 total
  - (2026-09-05) [Polymarket] Will Ciro Gomes win the 2026 Ceará gubernatorial election?
      The Ceará gubernatorial election is scheduled to take place in Brazil on October 4, 2026, with a runoff on October 25, 2026, if no candidate receives a majority of the valid votes in the first round. This market will res…
  - (2026-09-05) [Polymarket] Will Bitcoin dip to $67,500 in September?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa…
  - (2026-09-05) [Manifold] 👽 Will scientists announce a credible potential signal from extraterrestrial intelligence before 2027?
  - (2026-09-05) [Manifold] Will Iran strike US military base at least once in September?
  - (2026-09-05) [Manifold] Will Anthropic have the best public model when they IPO?
  - (2026-09-05) [Manifold] Did Claude just solve navier stokes??

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 56 total
  - (2026-09-05) [BleepingComputer] OpenAI admits it didn't disclose rogue AI wiki hijacking incident
      OpenAI admits it did not disclose an incident where autonomous AI agents hijacked a German wiki, created 18,000 posts, shared answers, and bypassed restrictions, saying it treated the activity as model "misalignment" rat…
  - (2026-09-05) [The Hacker News] Thousands of OpenAI Agents Quietly Turned an Abandoned Wiki Into Their Coordination Channel
      A group of AI safety researchers says a fleet of autonomous agents that identified themselves as OpenAI systems left about 18,000 posts on a dormant 25-year-old German wiki between May and July 2026, using the site as a…
  - (2026-09-05) [The Hacker News] Attackers Exploit PaperCut Flaws to Steal Credentials From Schools and Universities
      Threat actors are exploiting the newly disclosed PaperCut flaws to facilitate credential theft in attacks targeting the education sector in the U.S. and Europe. The Arctic Wolf Adversary Research Team said it observed at…
  - (2026-09-05) [The Register] BepiColombo sheds its ride and starts the final glide to Mercury
      Eight year after launch, Mercury probe and its Mercury Transfer Module consciously uncouple as orbit approaches
  - (2026-09-04) [Schneier on Security] Friday Squid Blogging: Squid on a Stick at the New York State Fair
      Looks tasty. As usual, you can also use this squid post to talk about the security stories in the news that I haven’t covered. Blog moderation policy.
  - (2026-09-04) [The Register] Anthropic lays groundwork for bots that shop for you
      Now comes the harder sell: Convincing customers and merchants to trust AI with purchases

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-05) LoL: Invictus Gaming vs Top Esports (BO5) - LPL Playoffs
      yes price: 100% · 24h volume: $2,334,912 · resolves 2026-09-05
  - (2026-09-05) LoL: Gen.G vs Hanwha Life Esports - Game 2 Winner
      yes price: 100% · 24h volume: $1,718,458 · resolves 2026-09-05
  - (2026-09-05) LoL: Invictus Gaming vs Top Esports - Game 4 Winner
      yes price: 0% · 24h volume: $1,647,161 · resolves 2026-09-05
  - (2026-09-05) LoL: Gen.G vs Hanwha Life Esports - Game 3 Winner
      yes price: 100% · 24h volume: $1,503,053 · resolves 2026-09-05
  - (2026-09-05) LoL: Gen.G vs Hanwha Life Esports - Game 1 Winner
      yes price: 0% · 24h volume: $1,298,795 · resolves 2026-09-05
  - (2026-09-05) LoL: Gen.G vs Hanwha Life Esports (BO5) - LCK Playoffs
      yes price: 78% · 24h volume: $1,191,205 · resolves 2026-09-05

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 103 total
  - (2026-09-02) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 51D Authorizing Certain Ac - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 51D Authorizing Certain Ac Office of Foreign Assets Control (.gov)
  - (2026-09-05) [USASpending] $3,500,000,000 → DAVIE DEFENSE INC.: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF F
      Agency: Department of Homeland Security. Description: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF FIVE (5) EACH MULTI-PURPOSE POLAR SHIP (MPPS-100) VESSELS HEREAFTER REFERRED TO AS ARCTIC SECURITY CUTTERS…
  - (2026-09-05) [USASpending] $1,205,937,998 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR
      Agency: General Services Administration. Description: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR THE USACE.
  - (2026-09-05) [USASpending] $1,122,648,775 → RAUMA MARINE CONSTRUCTIONS OY: PURCHASE OF TWO ARCTIC SECURITY CUTTERS FOR THE USCG
      Agency: Department of Homeland Security. Description: PURCHASE OF TWO ARCTIC SECURITY CUTTERS FOR THE USCG
  - (2026-09-05) [USASpending] $1,074,890,380 → DELL FEDERAL SYSTEMS L.P: MICROSOFT ENTERPRISE AGREEMENT
      Agency: Department of Veterans Affairs. Description: MICROSOFT ENTERPRISE AGREEMENT
  - (2026-09-05) [USASpending] $1,060,163,601 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)

### USGS earthquakes (M4.5+, past day) — 7 new of 11 total
  - (2026-09-04) M 5.5 - 156 km E of Kuril’sk, Russia
      M5.5 · 156 km E of Kuril’sk, Russia · depth 36.429 km
  - (2026-09-04) M 5.1 - central Mid-Atlantic Ridge
      M5.1 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-09-05) M 5.0 - off the coast of Central America
      M5.0 · off the coast of Central America · depth 10 km
  - (2026-09-05) M 4.8 - Kermadec Islands, New Zealand
      M4.8 · Kermadec Islands, New Zealand · depth 33.579 km
  - (2026-09-05) M 4.5 - 76 km S of Gorontalo, Indonesia
      M4.5 · 76 km S of Gorontalo, Indonesia · depth 202.347 km
  - (2026-09-05) M 4.5 - 159 km ENE of Noda, Japan
      M4.5 · 159 km ENE of Noda, Japan · depth 33.857 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-05) [Japan] South Korea exports surpass full - year record , hit $709 . 4bn so far
      asia.nikkei.com · English
  - (2026-09-05) [Japan] Philippine VP Duterte posts bail after arrest order for alleged threats
      asia.nikkei.com · English
  - (2026-09-05) [Japan] China summer travel boom loses heat
      asia.nikkei.com · English
  - (2026-09-05) [Japan] Nintendo Switch eShop charts - September 5 , 2026 - Tomodachi Life : Living the Dream on a crazy run
      nintendoeverything.com · English
  - (2026-09-05) [Japan] Next Nintendo Direct ? - Nintendo Switch 2 Forum - Page 1097 ( Page 1097 )
      nintendolife.com · English
  - (2026-09-05) [Japan] Thais slurp up Japan - style Sanuki udon noodles
      asia.nikkei.com · English

### U.S. Federal Action — 5 new of 11 total
  - (2026-09-08) Unleashing Unlicensed Spectrum for Direct-to-Device
      The Federal Communications Commission (Commission or FCC) issues a Notice of Proposed Rulemaking proposes to expand opportunities for direct-to-device (D2D) communications by permitting certain unlicensed devices to comm…
  - (2026-09-08) Safety Zone; Laguna Madre, South Padre Island, TX
      The Coast Guard is establishing a temporary safety zone for navigable waters on the Laguna Madre. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards associated with…
  - (2026-09-08) National Petroleum Reserve in Alaska Production Site Development
      The Bureau of Land Management (BLM) is proposing to streamline its decision-making process for authorizing the construction and operation of qualifying oil and gas production sites and their associated rights-of-way (ROW…
  - (2026-09-08) Car Loan Interest Deduction
      This document contains final regulations regarding the deduction for certain taxpayers for an amount up to $10,000 of qualified passenger vehicle loan interest. This document also contains final regulations regarding new…
  - (2026-09-08) Clearing Requirement Determination Under Section 2(h) of the Commodity Exchange Act for Interest Rate Swaps To Account for CAD and MXN Interest Rate Benchmark Transitions
      The Commodity Futures Trading Commission (Commission or CFTC) is amending its interest rate swap clearing requirement regulations under applicable provisions of the Commodity Exchange Act (CEA) to address the transition…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-09-05) [Marginal Revolution] Mein Ingeborg Bachmann Studium
      Recently I finished read Malina, by Ingeborg Bachmann, an Austrian novel published in 1971. I was pretty stunned by how good it was (it seems less good in English), and I would say I enjoyed it more, and found it deeper,…
  - (2026-09-05) [Marginal Revolution] Is Lichtenstein an actual monarchy?
      It seems so: Internal documents reviewed by the FT show that three days earlier, behind the walls of Vaduz Castle, Europe’s wealthiest ruling dynasty had quietly approved an overhaul that strengthens the authority of a p…

### Macro indicators — latest values (FRED) — 1 new of 21 total
  - (2026-09-03) [Rates] Fed Funds Effective Rate (DFF)
      latest: 3.63 as of 2026-09-03

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=11, 7d-median=18, 14d-median=19; carrying terms: certain, national, proposed, safety, unless, management, regulatory, final, existing, action, specifically, temporary
- state_bills: today=82, 7d-median=78, 14d-median=80; carrying terms: control, authorizes, support, generally, making, develop, conditions, local, providing, prohibits, permits, district
- state_news: today=623, 7d-median=623, 14d-median=648; carrying terms: error, cases, children, often, control, economic, story, fetchpriority, carolina, redirects, automated, nationwide
- local_news: today=234, 7d-median=234, 14d-median=238; carrying terms: georgia, fetchpriority, color, officers, season, death, following, police, local, alert, charged, fight
- foreign_news: today=1085, 7d-median=1096, 14d-median=1048; carrying terms: error, noticias, severe, solid, seldom, control, acting, economic, widespread, fetchpriority, scratched, investors
- chinese_internal: today=276, 7d-median=286, 14d-median=287; carrying terms: china, title, google, politics, cbmibkfvx, lxtfa, cbmiw, cbmiykfvx, cbmickfvx, cbmibefvx, cbmizkfvx, cbmia
- russian_internal: today=1042, 7d-median=1042, 14d-median=1074; carrying terms: error, journal, novaya, axios, gazeta, europe, istories, wildberries, politico, truth, bloomberg, title
- ukrainian_internal: today=138, 7d-median=122, 14d-median=122; carrying terms: error, children, economic, comes, continue, people, support, military, title, fedorov, months, strikes
- ukraine_theater: today=239, 7d-median=612, 14d-median=612; carrying terms: sknvutv, error, cuxpdxvzsdnyqvn, wjhsr, dvafneutjty, control, nddfrhzwtqdjvom, drzfaexfrmfljodl, deepstatemap, jzzkxmu, flxbbemxiwud, interactive
- paper_bets: today=132, 7d-median=132, 14d-median=132; carrying terms: minister, nuclear, georgia, governor, achieved, fusion, court, control, florida, nomination, population, maine
- weather: today=105, 7d-median=145, 14d-median=143; carrying terms: severe, georgia, along, flooding, widespread, changed, including, areas, please, flood, above, creeks
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: energy, walcl, crude, dexuseu, payems, inflation, supply, payrolls, sheet, pcepilfe, jtsjol, openings
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, yield, large, corporate, crude, commodities, futures, silver, treasury, crypto, proxy, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=103, 7d-median=109, 14d-median=108; carrying terms: energy, member, groups, nuclear, provisions, moldova, weapons, imposed, control, management, economic, committees
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, error, unauthorized, quantitative, quiverquant, congresstrading, client, quiver, https
- billionaires: today=30, 7d-median=30, 14d-median=30; carrying terms: thomas, gautam, google, diversified, mukesh, gates, hathaway, technology, cryptocurrency, berkshire, finance, walmart
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, supreme, connecticut, appeals, county, company, energy, blanche, board, insurance, florida
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, holdings, brian, therapeutics, technologies, america, robert
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: robert, receipts, raised, committee, sherrod, disbursements, johnson, booker, michael, house, trone, angels
- gdelt_regions: today=6, 7d-median=9, 14d-median=9; carrying terms: english, japan
- gdelt_gkg: today=25, 7d-median=38, 14d-median=38; carrying terms: english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, canada, kingdom, bulgaria, ground, germany, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: young, investigations, member, severe, environmental, epidemic, formula, increased, since, cases, children, municipalities
- cisa_kev: today=21, 7d-median=21, 14d-median=20; carrying terms: missing, product, function, vulnerability, microsoft, command, server, vendor, improper, authentication, request, critical
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=11, 7d-median=12, 14d-median=14; carrying terms: depth, indonesia, islands, japan, south, region, ruteng, russia, ridge, zealand, kuril, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: change, shakhtar, resolves, championship, donetsk, league, interest, price, rates, decrease, volume, presidential
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, revolution, economist, class, marginal, https, economy, recent, current, conversableeconomist, price, point
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: computer, cybersecurity, across, hackers, people, industry, cyber, recent, attack, weekly, schneier, company
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: tammy, hawley, young, capito, schmidt, delaney, massie, reserve, castor, plaskett, futures, garamendi
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, identify, sufficient, converges, consensus, placed, today, claude, paper, market, either, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*