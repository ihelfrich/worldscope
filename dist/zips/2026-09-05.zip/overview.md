# WORLDSCOPE morning brief — 2026-09-05

## Headline
2176 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (500) · Russian Internal News (state + in-exile) (378) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (204) · Chinese Internal News (192) · Local News: St. Louis + Atlanta (112) · State-Level News (111) · U.S. Weather + Severe / Climate Outlooks (100) · Ukrainian Internal News (national + local Kyiv) (44) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (26)

## What changed today
### International News + Multilateral Institutions — 500 new of 1081 total
  - (2026-09-04) [Global] Trump’s ‘retribution’ could now include Falklands as favor to Milei – and revenge on the UK
  - (2026-09-05) [Global] Sydney reaches 33C in potentially warmest start to spring since mid-1800s, while snow forecast in southern NSW
  - (2026-09-05) [Global] ‘Every girl now wants to be a boxer’: excitement in Katie Taylor’s home town for her valedictory bout
  - (2026-09-05) [Global] Death on the road to Rafah: the night the IDF targeted World Central Kitchen aid workers
  - (2026-09-05) [Global] ‘Guilt by association’: why seven international aid workers were killed in Israeli airstrike
  - (2026-09-05) [Global] Black-clad protesters in balaclavas block road at port of Dover in Kent

### Russian Internal News (state + in-exile) — 378 new of 1033 total
  - (2026-09-05) Зеленский: Россия демонстративно ударила по аэропортам в Киеве и Борисполе на фоне сообщений о визите переговорщиков США | LEDE: Войска РФ в ночь на 5 сентября нанесли «демонстративные» и «ц] (ru: Зел…
      Войска РФ в ночь на 5 сентября нанесли «демонстративные» и «целенаправленные» удары по аэропортам в Киеве и Борисполе, заявил президент Украины Владимир Зеленский. По его словам, это реакция РФ на обсуждение возможного в…
  - (2026-09-05) РИА Новости: у российской фигуристки Камилы Валиевой отозвали нейтральный статус. Без него нельзя участвовать в международных соревнованиях | LEDE: Международный союз конькобежцев (ISU) отоз] (ru: РИА…
      Международный союз конькобежцев (ISU) отозвал у российской фигуристки Камилы Валиевой выданный в августе нейтральный статус, который позволял ей выступать на международных соревнованиях, сообщил РИА Новости неназванный и…
  - (2026-09-05) Когда вы в последний раз употребляли слово «мох»? А «опушка»? Слова, связанные с природой, исчезают из речи, книг и мультфильмов. И это имеет серьезные последствия | LEDE: Люди все реже гово] (ru: Ког…
      Люди все реже говорят о природе. Слова, связанные с ней, исчезают также из книг и мультфильмов. Такое отдаление людей от природы имеет экологические последствия. Издание «Кедр» опубликовало материал, в котором лингвист А…
  - (2026-09-05) Будет ли новая волна эмиграции из России? Для ответа на этот вопрос «Медузе» нужна ваша помощь. Если вы уже готовитесь к отъезду — расскажите нам | LEDE: Чем ближе сентябрьские выборы в Госд] (ru: Буд…
      Чем ближе сентябрьские выборы в Госдуму, тем больше слухов о возможной мобилизации в России. Хотя подтверждений этому нет, в соцсетях практически каждый день появляются новые истории о том, как россияне хотят поскорее уе…
  - (2026-09-05) Фигурантов дела о подготовке покушения на митрополита Тихона (Шевкунова) обвинили в госизмене и помощи противнику | LEDE: Следователи ФСБ предъявили окончательное обвинение фигурантам дела о] (ru: Фиг…
      Следователи ФСБ предъявили окончательное обвинение фигурантам дела о подготовке покушения на митрополита Симферопольского и Крымского Тихона (Шевкунова) — выпускникам Сретенской семинарии Денису Поповичу и Никите Иванков…
  - (2026-09-05) Латвия и Литва хотят прекратить транзит российского зерна через свои порты | LEDE: Латвия и Литва рассматривают возможность прекратить поставки российского зерна через свои порты, сообщили в] (ru: Лат…
      Латвия и Литва рассматривают возможность прекратить поставки российского зерна через свои порты, сообщили высокопоставленные представители двух стран агентству Reuters.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 204 new of 710 total
  - (2026-09-05) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-04) [FIRMS] thermal anomaly 50.226, 33.398 (FRP 2.09 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-04 2240Z, FRP 2.09 MW
  - (2026-09-04) [FIRMS] thermal anomaly 48.530, 34.619 (FRP 6.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-04 2240Z, FRP 6.91 MW
  - (2026-09-04) [FIRMS] thermal anomaly 48.532, 34.617 (FRP 6.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-04 2240Z, FRP 6.61 MW
  - (2026-09-04) [FIRMS] thermal anomaly 48.518, 34.627 (FRP 1.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-04 2240Z, FRP 1.9 MW
  - (2026-09-04) [FIRMS] thermal anomaly 47.352, 34.966 (FRP 1.43 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-04 2240Z, FRP 1.43 MW

### Chinese Internal News — 192 new of 274 total
  - (2026-09-03) 财经早知道｜十部门重磅发布 设立国家中小企业发展基金二期 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9zZFZpblQ3c0MzaFN3M3JRYm80SlRfOWRSRGdOLXJVSEJzMWI2YjVjVXlKbHJ4eUxYRHY4Y0FHMmF2ZHBXNDFXaS1Nb] (zh:…
      财经早知道｜十部门重磅发布 设立国家中小企业发展基金二期 财新
  - (2026-09-04) 今日开盘：两市双双高开 沪指涨幅0.34% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBtRFJhaFFxNU1UaGtsamtJM05STjRQSW5XVXRwZHdGVHd4TWxxY0VrcDRDb28tRmRNaEc2X0lQVFU3cUR1WG1tbjM5Z1A1TUdh] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.34% 财新
  - (2026-09-03) 潘功胜谈应对全球失衡 各国应制定中长期政策、避免“翻烧饼” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBPaGlRTGVDeFJrc3VWYV8zRFl6RWFHQTRnZU9wdHFZUENFN1pEanlUWU00aDFkS2hpLUZmcGFRZ3N5MnVBVU9JakhJ] (zh:…
      潘功胜谈应对全球失衡 各国应制定中长期政策、避免“翻烧饼” 财新
  - (2026-09-04) 台风不只是一场风：风、潮、雨如何合成上海的风险账 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9wRlVjM3pYdDBSelVRXzFubWc2RlJESkhlc0pMUjRJaFVQS3N3NE9BZ2x4S21ONG1IR0R4V3dqMGhBOV9vaVdsdHl0cWFvU] (zh:…
      台风不只是一场风：风、潮、雨如何合成上海的风险账 财新
  - (2026-09-04) K型分化？ i型割裂？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE93Z2ZGVER4MGhheHF3WVQ2Vmx5NGNXQzJ4anNUaWtzWnF6QmN3cHJyUUtMdl9xel9nVFBNc0VJQmhKanIzbzNzeG1YUXhfR3Zobm80MHp2Um] (zh:…
      K型分化？ i型割裂？ 财新
  - (2026-09-04) 冷静认识平台和AI对经济增长的支撑作用 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9HLTNiN3ZtemVwWUdmU1FqNGtIQkpVSjhKalVCcFpTb0ptQ1hhVDk0MzVXd1JxNTNmSzF2UkJqTEdKUzdHaS1maUFERzdQd0hRdE] (zh:…
      冷静认识平台和AI对经济增长的支撑作用 财新

### Local News: St. Louis + Atlanta — 112 new of 234 total
  - (2026-09-05) [St. Louis] See the Sept. 5, 1926, front page: Minister's son admits killing 2 at roadhouse
      Headlines from the Sept. 5, 1926, front page include: Brilliant spectacle as Greater St. Louis Exposition is opened
  - (2026-09-05) [St. Louis] MacCarthy, John
      MacCarthy, John P.
  - (2026-09-05) [St. Louis] Reinventing Business Internet from the Ground Up and the Sky Down
      Powered by America’s fastest 5G internet and integrated with Starlink, SuperBroadband delivers virtually unbreakable connectivity.
  - (2026-09-05) [St. Louis] Reinventing Business Internet from the Ground Up and the Sky Down
      (NAPSI)—Here’s news many companies may consider out of this world: A revolutionary business internet solution that combines the largest 5G network with Starlink. Called SuperBroadband, this groundbreaking service deliver…
  - (2026-09-05) [St. Louis] When Federal Programs and Workers are Cut, Main Street Bears the Cost
  - (2026-09-05) [St. Louis] When Federal Programs and Workers are Cut, Main Street Bears the Cost
      by Edith Mwangi

### State-Level News — 111 new of 620 total
  - (2026-09-05) [Alabama] Governor Kay Ivey Honors Alabama Workers in Labor Day Message
      Governor Ivey released a video message honoring the hardworking men and women whose dedication strengthens Alabama and drives America forward. (Governor’s Office, Alyssa Turner)
  - (2026-09-04) [California] Governor Gavin Newsom on California securing massive victory for democracy
  - (2026-09-05) [Alaska] Former Bethel judge’s apparent resignation as top public defender remains unconfirmed
      This story was originally published by KYUK. Former Bethel judge Terrence Haas became the state’s top public defender in September 2023. Last week, he announced in a resignation letter sent to Gov. Mike Dunleavy that he…
  - (2026-09-05) [Alaska] Feds seek to ‘streamline’ Arctic oil permitting, ending environment studies of individual projects
      The Trump administration on Friday moved to exempt oil projects in federal territory on the west side of the North Slope from environmental reviews that have been standard for decades. An industry-initiated proposed rule…
  - (2026-09-04) [Alaska] Alaska’s state-owned gasline corporation says it will continue to pursue AKLNG pipeline in 2027
      The Alaska Gasline Development Corp. plans to ask the Alaska State Legislature for additional funding as it renews its pursuit of a proposed trans-Alaska natural gas pipeline in 2027. Frank Richards, AGDC’s president, sa…
  - (2026-09-04) [Alaska] Alaska appeals court dismisses noncitizen voting case against Whittier woman
      A three-judge panel of the Alaska Court of Appeals ruled Friday that state prosecutors misled grand jurors who indicted a Whittier resident for allegedly voting illegally. Had jurors received accurate information, the co…

### U.S. Weather + Severe / Climate Outlooks — 100 new of 108 total
  - (2026-09-05) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 5 at 4:28AM CDT until September 5 at 4:30AM CDT by NWS Sioux Falls SD
      The severe thunderstorm which prompted the warning has weakened. Therefore, the warning will be allowed to expire. However, gusty winds and heavy rain are still possible with this thunderstorm.
  - (2026-09-05) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-05) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued September 5 at 4:27AM CDT until September 5 at 4:30AM CDT by NWS Bismarck ND
      The storm which prompted the warning has weakened below severe limits. Therefore, the warning will be allowed to expire. However, heavy rain is still expected with this thunderstorm.
  - (2026-09-05) [Moderate] Special Weather Statement: Special Weather Statement issued September 5 at 4:27AM CDT by NWS La Crosse WI
      If traveling this morning, be prepared for pockets of dense fog that could suddenly reduce visibilities to 1/4 mile or less. Expect the fog to dissipate by 9AM. Slow down and allow extra time to reach your destination.
  - (2026-09-05) [Moderate] Special Weather Statement: Special Weather Statement issued September 5 at 4:26AM CDT by NWS Bismarck ND
      At 426 AM CDT, a strong thunderstorm was located 7 miles southwest of Antler, or 44 miles west of Bottineau, moving northeast at 25 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE...Radar indicated. IM…
  - (2026-09-05) [Moderate] Special Weather Statement: Special Weather Statement issued September 5 at 5:26AM EDT by NWS Wilmington OH
      At 526 AM EDT, a strong thunderstorm was located near Carrollton, moving east at 25 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limbs and blow around unsecu…

### Ukrainian Internal News (national + local Kyiv) — 44 new of 133 total
  - (2026-09-05) Росіяни атакували СТО на Дніпропетровщині: загинула людина, ще 5 поранені | LEDE: У Дніпровському районі російські війська завдали удару по станції технічного обслуговування, внаслідок чого заг] (uk:…
      У Дніпровському районі російські війська завдали удару по станції технічного обслуговування, внаслідок чого загинула людина, ще п'ятеро дістали поранення.
  - (2026-09-05) ЗМІ: ЄС та Україна наступного тижня проведуть перше засідання Альянсу дронів | LEDE: 11 вересня в Брюсселі відбудеться перше засідання Альянсу ЄС-Україна з питань безпілотників. Планується учас] (uk:…
      11 вересня в Брюсселі відбудеться перше засідання Альянсу ЄС-Україна з питань безпілотників. Планується участь європейських і українських виробників дронів.
  - (2026-09-05) Керівник підрозділу ОГП організував "кришування" шахрайських кол-центрів – НАБУ | LEDE: НАБУ і САП заявили про викриття злочинної організації, яку, за даними слідства, очолював один із керівник] (uk:…
      НАБУ і САП заявили про викриття злочинної організації, яку, за даними слідства, очолював один із керівників структурних підрозділів Офісу генерального прокурора. Її учасників підозрюють у систематичному отриманні хабарів…
  - (2026-09-05) Генштаб: Україна уразила РЛС, РЕБ та ретранслятор на Брянщині | LEDE: Українські військові завдали удару по радіолокаційній станції, комплексу радіоелектронної боротьби і ретранслятору росіян у] (uk:…
      Українські військові завдали удару по радіолокаційній станції, комплексу радіоелектронної боротьби і ретранслятору росіян у Брянській області РФ.
  - (2026-09-05) Кандидати у президенти Франції посварились через допомогу Україні | LEDE: Марін Ле Пен пообіцяла зупинити допомогу Україні, Едуар Філіпп розкритикував ультраправих. Вибори у Франції пройдуть у ] (uk:…
      Марін Ле Пен пообіцяла зупинити допомогу Україні, Едуар Філіпп розкритикував ультраправих. Вибори у Франції пройдуть у 2027 році.
  - (2026-09-05) Литва хоче створити інтегровану систему виявлення повітряних загроз | LEDE: ] (uk: Литва хоче створити інтегровану систему виявлення повітряних загроз)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-05) [Novick Jared] Form 4 (Reporting)
      filed 2026-09-05 01:56 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001493152-26-041638 Size: 6 KB
  - (2026-09-05) [WRAP TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-09-05 01:56 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0001493152-26-041638 Size: 6 KB
  - (2026-09-05) [WRAP TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-09-05 01:55 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0001493152-26-041637 Size: 6 KB
  - (2026-09-05) [Cohen Scot] Form 4 (Reporting)
      filed 2026-09-05 01:55 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001493152-26-041637 Size: 6 KB
  - (2026-09-05) [Rackspace Technology, Inc.] Form 4 (Issuer)
      filed 2026-09-05 01:55 UTC · role: Issuer — Filed: 2026-09-04 AccNo: 0001684713-26-000003 Size: 6 KB
  - (2026-09-05) [Kandiah Gajakarnan Vibushanan] Form 4 (Reporting)
      filed 2026-09-05 01:55 UTC · role: Reporting — Filed: 2026-09-04 AccNo: 0001684713-26-000003 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 29 total
  - (2026-09-05) SAMU37 (France)
      icao24: 39ca87 · position: (47.2636, 0.8702) · alt: 434m · 229km/h
  - (2026-09-05) SAMU05 (France)
      icao24: 39ca81 · position: (44.436, 6.0011) · alt: 937m · 244km/h
  - (2026-09-05) CFC2984 (Canada)
      icao24: c2b585 · position: (50.6072, 18.7577) · alt: 4884m · 493km/h
  - (2026-09-05) KAF3226 (Kuwait)
      icao24: 7061f5 · position: (31.7744, 29.0019) · alt: 6096m · 516km/h
  - (2026-09-05) JAF66L (Belgium)
      icao24: 44d1ba · position: (48.0344, 1.2217) · alt: 10363m · 793km/h
  - (2026-09-05) JAF74C (Belgium)
      icao24: 44d1a6 · position: (37.3635, 22.9049) · alt: 11582m · 799km/h

### Court opinions of consequence (federal & state) — 23 new of 60 total
  - (2026-09-04) U.S. Court of International Trade: Jiangsu Nova Intelligent Logistics Equip. Co. v. United States
  - (2026-09-04) U.S. Court of International Trade: Catfish Farmers of Am. v. United States
  - (2026-09-04) U.S. Court of International Trade: Industrial Pesquera Santa Priscila, S.A. v. United States
  - (2026-09-04) U.S. Court of International Trade: Seafood Exps. Ass'n of India v. United States
  - (2026-09-04) U.S. Court of International Trade: Shrimp Comm. of the Vietnam Ass'n v. United States
  - (2026-09-04) U.S. Court of International Trade: Wind Tower Trade Coal. v. United States

### State Legislative Action — 16 new of 98 total
  - (2026-09-04) [Illinois HB 4701] LIMITATIONS FACILITY FEES ACT
      LIMITATIONS FACILITY FEES ACT
  - (2026-09-03) [Illinois SB 2745] PROP TX-DISABLED PERSONS
      PROP TX-DISABLED PERSONS
  - (2026-09-03) [Illinois SB 2687] HOME UTILITY RELIEF ACT
      HOME UTILITY RELIEF ACT
  - (2026-09-03) [Illinois SB 3581] EPA-GREENHOUSE GASES
      EPA-GREENHOUSE GASES
  - (2026-09-03) [Illinois SB 3008] DHS-ABLE PROGRAM INFO MATERIAL
      DHS-ABLE PROGRAM INFO MATERIAL
  - (2026-09-03) [Illinois SB 3540] PROP TX-ASSESSMENT LIMIT
      PROP TX-ASSESSMENT LIMIT

### Paper Trading Scorecard — 16 new of 132 total
  - (2026-09-05) [Polymarket] LoL: Invictus Gaming vs Top Esports - Game 3 Winner
      This market refers to the LoL Lower bracket round 1 match between Invictus Gaming and Top Esports in the LPL Playoffs, initially scheduled for September 5, 2026 at 2:00 AM ET. This market will resolve to "Invictus Gaming…
  - (2026-09-05) [Polymarket] Will Ciro Gomes win the 2026 Ceará gubernatorial election?
      The Ceará gubernatorial election is scheduled to take place in Brazil on October 4, 2026, with a runoff on October 25, 2026, if no candidate receives a majority of the valid votes in the first round. This market will res…
  - (2026-09-05) [Polymarket] Will Faker win a Finals MVP Award at an international event in 2026?
      The market will resolve to "Yes" if Lee "Faker" Sang-hyeok is officially announced as the Finals MVP of any international event in 2026 (such as First Stand, MSI, Esports World Cup, Worlds, or any other officially recogn…
  - (2026-09-05) [Manifold] 👽 Will scientists announce a credible potential signal from extraterrestrial intelligence before 2027?
  - (2026-09-05) [Manifold] Will Iran strike US military base at least once in September?
  - (2026-09-05) [Manifold] Will Anthropic have the best public model when they IPO?

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 56 total
  - (2026-09-05) [The Hacker News] Thousands of OpenAI Agents Quietly Turned an Abandoned Wiki Into Their Coordination Channel
      A group of AI safety researchers says a fleet of autonomous agents that identified themselves as OpenAI systems left about 18,000 posts on a dormant 25-year-old German wiki between May and July 2026, using the site as a…
  - (2026-09-05) [The Hacker News] Attackers Exploit PaperCut Flaws to Steal Credentials From Schools and Universities
      Threat actors are exploiting the newly disclosed PaperCut flaws to facilitate credential theft in attacks targeting the education sector in the U.S. and Europe. The Arctic Wolf Adversary Research Team said it observed at…
  - (2026-09-05) [The Register] BepiColombo sheds its ride and starts the final glide to Mercury
      Eight year after launch, Mercury probe and its Mercury Transfer Module consciously uncouple as orbit approaches
  - (2026-09-04) [Cybersecurity Dive] OpenAI pledges $1 billion to provide resources, training for frontline cyber defenders
      Amid heightened scrutiny, the company will use frontier AI to help water, power and local government providers fight malicious actors.
  - (2026-09-04) [Schneier on Security] Friday Squid Blogging: Squid on a Stick at the New York State Fair
      Looks tasty. As usual, you can also use this squid post to talk about the security stories in the news that I haven’t covered. Blog moderation policy.
  - (2026-09-04) [The Register] Anthropic lays groundwork for bots that shop for you
      Now comes the harder sell: Convincing customers and merchants to trust AI with purchases

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-09-05) LoL: Invictus Gaming vs Top Esports - Game 2 Winner
      yes price: 0% · 24h volume: $1,390,830 · resolves 2026-09-05
  - (2026-09-05) LoL: Gen.G vs Hanwha Life Esports - Game 1 Winner
      yes price: 0% · 24h volume: $1,245,064 · resolves 2026-09-05
  - (2026-09-05) LoL: Invictus Gaming vs Top Esports (BO5) - LPL Playoffs
      yes price: 76% · 24h volume: $1,037,146 · resolves 2026-09-05
  - (2026-09-05) LoL: Invictus Gaming vs Top Esports - Game 3 Winner
      yes price: 100% · 24h volume: $998,210 · resolves 2026-09-05
  - (2026-09-05) LoL: Invictus Gaming vs Top Esports - Game 4 Winner
      yes price: 52% · 24h volume: $813,734 · resolves 2026-09-05
  - (2026-09-05) LoL: Gen.G vs Hanwha Life Esports (BO5) - LCK Playoffs
      yes price: 32% · 24h volume: $787,474 · resolves 2026-09-05

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 103 total
  - (2026-09-02) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 51D Authorizing Certain Ac - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 51D Authorizing Certain Ac Office of Foreign Assets Control (.gov)
  - (2026-09-05) [USASpending] $3,500,000,000 → DAVIE DEFENSE INC.: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF F
      Agency: Department of Homeland Security. Description: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF FIVE (5) EACH MULTI-PURPOSE POLAR SHIP (MPPS-100) VESSELS HEREAFTER REFERRED TO AS ARCTIC SECURITY CUTTERS…
  - (2026-09-05) [USASpending] $1,205,937,998 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR
      Agency: General Services Administration. Description: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR THE USACE.
  - (2026-09-05) [USASpending] $1,122,648,775 → RAUMA MARINE CONSTRUCTIONS OY: PURCHASE OF TWO ARCTIC SECURITY CUTTERS FOR THE USCG
      Agency: Department of Homeland Security. Description: PURCHASE OF TWO ARCTIC SECURITY CUTTERS FOR THE USCG
  - (2026-09-05) [USASpending] $1,074,890,380 → DELL FEDERAL SYSTEMS L.P: MICROSOFT ENTERPRISE AGREEMENT
      Agency: Department of Veterans Affairs. Description: MICROSOFT ENTERPRISE AGREEMENT
  - (2026-09-05) [USASpending] $1,060,163,601 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)

### USGS earthquakes (M4.5+, past day) — 7 new of 11 total
  - (2026-09-04) M 5.5 - 156 km E of Kuril’sk, Russia
      M5.5 · 156 km E of Kuril’sk, Russia · depth 36.429 km
  - (2026-09-04) M 5.1 - central Mid-Atlantic Ridge
      M5.1 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-09-05) M 5.0 - off the coast of Central America
      M5.0 · off the coast of Central America · depth 10 km
  - (2026-09-05) M 4.8 - Kermadec Islands, New Zealand
      M4.8 · Kermadec Islands, New Zealand · depth 33.579 km
  - (2026-09-05) M 4.5 - 76 km S of Gorontalo, Indonesia
      M4.5 · 76 km S of Gorontalo, Indonesia · depth 202.347 km
  - (2026-09-05) M 4.5 - 159 km ENE of Noda, Japan
      M4.5 · 159 km ENE of Noda, Japan · depth 33.857 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-05) [China] Guangdong turns AI advances into affordable innovation
      news.cnwest.com · English
  - (2026-09-05) [China] 4 . 2 Gallon Portable Washing Machine | 12 x12 x13 Foldable Mini Washer
      dealgenius.com · English
  - (2026-09-05) [China] 200 PK Assorted Small Toys for Parties & Rewards
      dealgenius.com · English
  - (2026-09-05) [China] Bottany Plants Lately Premium Midweight Ringspun Cotton T - Shirt
      dealgenius.com · English
  - (2026-09-05) [China] Kids Bamboo Utensil Set - Eco - Friendly Cooking Tool
      dealgenius.com · English
  - (2026-09-05) [China] Core Kitchen Silicone 12 & 8 . 25 Spoons
      dealgenius.com · English

### U.S. Federal Action — 5 new of 11 total
  - (2026-09-08) Unleashing Unlicensed Spectrum for Direct-to-Device
      The Federal Communications Commission (Commission or FCC) issues a Notice of Proposed Rulemaking proposes to expand opportunities for direct-to-device (D2D) communications by permitting certain unlicensed devices to comm…
  - (2026-09-08) Safety Zone; Laguna Madre, South Padre Island, TX
      The Coast Guard is establishing a temporary safety zone for navigable waters on the Laguna Madre. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards associated with…
  - (2026-09-08) National Petroleum Reserve in Alaska Production Site Development
      The Bureau of Land Management (BLM) is proposing to streamline its decision-making process for authorizing the construction and operation of qualifying oil and gas production sites and their associated rights-of-way (ROW…
  - (2026-09-08) Car Loan Interest Deduction
      This document contains final regulations regarding the deduction for certain taxpayers for an amount up to $10,000 of qualified passenger vehicle loan interest. This document also contains final regulations regarding new…
  - (2026-09-08) Clearing Requirement Determination Under Section 2(h) of the Commodity Exchange Act for Interest Rate Swaps To Account for CAD and MXN Interest Rate Benchmark Transitions
      The Commodity Futures Trading Commission (Commission or CFTC) is amending its interest rate swap clearing requirement regulations under applicable provisions of the Commodity Exchange Act (CEA) to address the transition…

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-09-05) [Marginal Revolution] Mein Ingeborg Bachmann Studium
      Recently I finished read Malina, by Ingeborg Bachmann, an Austrian novel published in 1971. I was pretty stunned by how good it was (it seems less good in English), and I would say I enjoyed it more, and found it deeper,…
  - (2026-09-05) [Marginal Revolution] Is Lichtenstein an actual monarchy?
      It seems so: Internal documents reviewed by the FT show that three days earlier, behind the walls of Vaduz Castle, Europe’s wealthiest ruling dynasty had quietly approved an overhaul that strengthens the authority of a p…

### Macro indicators — latest values (FRED) — 1 new of 21 total
  - (2026-09-03) [Rates] Fed Funds Effective Rate (DFF)
      latest: 3.63 as of 2026-09-03

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 1 new of 33 total
  - (2026-09-05) MOVER ▲ Warren Buffett — $143.83B (+$0.12B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=11, 7d-median=18, 14d-median=19; carrying terms: national, safety, proposed, unless, certain, associated, temporary, special, service, action, specifically, regulatory
- state_bills: today=98, 7d-median=78, 14d-median=84; carrying terms: period, vests, advisory, adopt, safety, years, health, control, establish, enforcement, permits, recommendations
- state_news: today=620, 7d-median=620, 14d-median=634; carrying terms: minnesota, michigan, abortion, energy, years, despite, though, earlier, health, higher, border, originally
- local_news: today=234, 7d-median=234, 14d-median=238; carrying terms: death, years, target, image, google, srcset, resize, officials, outside, async, content, school
- foreign_news: today=1081, 7d-median=1096, 14d-median=1044; carrying terms: emergency, jiangsu, antimissile, guarantee, remembrance, applied, plays, maverick, energy, prize, years, officer
- chinese_internal: today=274, 7d-median=286, 14d-median=286; carrying terms: target, google, cbmibefvx, https, color, cbmidefvx, property, lxtfb, global, politics, cbmickfvx, people
- russian_internal: today=1033, 7d-median=1033, 14d-median=1054; carrying terms: journal, reuters, novayagazeta, social, found, laquo, media, truth, httperror, financial, wildberries, times
- ukrainian_internal: today=133, 7d-median=122, 14d-median=120; carrying terms: energy, years, missile, overnight, force, minister, powered, officials, resilience, security, kremlin, cabinet
- ukraine_theater: today=710, 7d-median=710, 14d-median=722; carrying terms: wvzlmzudkbwlyum, oyaglbnjlud, cuxnvnm, pwldyvtbqoucyzeztcthru, cuxpwgtpnefsrtv, meftwfh, aujva, cuxoykgxamf, nfjzujb, vmjlqmw, delive, cuxoqnfnunjotkxec
- paper_bets: today=132, 7d-median=132, 14d-median=132; carrying terms: leader, celsius, drought, james, experience, governor, chuck, leave, september, minnesota, rippling, maine
- weather: today=108, 7d-median=145, 14d-median=139; carrying terms: flooding, orange, advisory, afdlsx, producing, islands, changes, hazard, increasing, metro, severe, updated
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unemployment, walcl, treasury, energy, commodities, sheet, dexchus, nonfarm, jtsjol, consumption, dexjpus, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, equities, treasury, silver, commodities, russell, bitcoin, agriculture, crude, rates, corporate, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=103, 7d-median=109, 14d-median=107; carrying terms: ukraine, african, violations, qaida, violent, resolutions, adopted, description, belarus, accordance, controlled, energy
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, unauthorized, client, quantitative, congresstrading, https, quiverquant, error, quiver
- billionaires: today=33, 7d-median=30, 14d-median=30; carrying terms: michael, commodities, hathaway, zhang, facebook, gmexicob, amazon, microsoft, india, infrastructure, oracle, bezos
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, state, court, appeals, connecticut, company, county, board, blanche, energy, insurance, national
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, issuer, accno, holdings, brian, therapeutics, america, technologies, robert
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, michael, james, krishnamoorthi, brown, jonathan, committee, house, talarico, ocasio, johnson, pinkston
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=0, 7d-median=50, 14d-median=50; carrying terms: trump, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=29, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, ground, germany, canada, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: illness, derived, african, fifth, hospital, influenza, related, driving, september, discharged, samples, spread
- cisa_kev: today=21, 7d-median=21, 14d-median=20; carrying terms: improper, injection, product, request, critical, microsoft, forgery, remediation, missing, authentication, vendor, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=11, 7d-median=12, 14d-median=14; carrying terms: depth, indonesia, islands, japan, south, region, ruteng, ridge, russia, zealand, kuril, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: meeting, interest, rates, september, championship, champions, volume, resolves, donetsk, decrease, shakhtar, league
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, https, revolution, economist, class, conversable, economy, recent, conversableeconomist, current, price, sense
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: agents, cyber, attack, researchers, security, bleepingcomputer, hacker, million, openai, around, systems, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: titus, insurance, james, raphael, counsel, lateefah, cornyn, sarah, nicholas, sanford, chuck, abraham
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, identify, placed, converges, markets, paper, sufficient, module, placement, evidence, either, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*