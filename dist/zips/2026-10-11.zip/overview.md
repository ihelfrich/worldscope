# WORLDSCOPE morning brief — 2026-10-11

## Headline
2523 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (705) · Russian Internal News (state + in-exile) (532) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (228) · Chinese Internal News (184) · Local News: St. Louis + Atlanta (108) · U.S. Weather + Severe / Climate Outlooks (105) · State-Level News (102) · Ukrainian Internal News (national + local Kyiv) (56) · GDACS — global disaster alerts (44) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (21)

## What changed today
### International News + Multilateral Institutions — 705 new of 970 total
  - (2026-10-11) [Global] Charities and businesses wrestle with diesel cost
      Cancer charity Daft as a Brush and Teesside Minibus Hire say they are struggling with pump prices.
  - (2026-10-11) [Global] Ceuta migrants allege beatings as camps cleared ahead of royal visit
      People in Ceuta allege they were mistreated by Spanish soldiers after authorities cleared migrant camps.
  - (2026-10-11) [Global] Meet the man helping India’s detained protesters get home
      Al Jazeera spoke to the 25-year-old man who built an AI-powered app to help India’s detained protesters get home safely.
  - (2026-10-11) [Global] Saudi Arabia vows response over Houthi ‘war crime’ attack on Riyadh airport
      A Houthi attack on Riyadh airport killed at least 12 people and injured more than 300.
  - (2026-10-11) [Global] Sweet protein brazzein shows promise in reducing blood sugar spikes: Study
      Russian research reveals that the protein brazzein could help reduce blood sugar spikes.
  - (2026-10-11) [Global] Liverpool vs Man City live: Premier League
      Follow updates from the clash at Anfield, including the build-up, analysis and live text commentary of the game.

### Russian Internal News (state + in-exile) — 532 new of 898 total
  - (2026-10-11) Война. 1691-й день. Украина в третий раз ударила по дата-центрам «Яндекса». Сбои в работе сервисов наблюдаются по всей стране (а также в Казахстане, Армении и Сербии) | LEDE: «Медуза» с 24 ф] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-11) В отношениях Зеленского и Трампа — кризис, каких не было со времен ссоры в Белом доме. Президент США призывает Украину выбрать нового лидера и требует прекратить удары по российским НПЗ | LEDE:] (ru:…
      Отношения Владимира Зеленского и Дональда Трампа находятся в «нижайшей точке» со времен их ссоры в Овальном кабинете в начале 2025 года, пишет The Wall Street Journal. Издание пришло к этому выводу после заявлений Дональ…
  - (2026-10-11) Зеленский заявил, что Киев перестанет атаковать российские НПЗ только в ответ на прекращение ударов Москвы по украинской энергетике | LEDE: Владимир Зеленский заявил, что Украина готова оста] (ru: Зел…
      Владимир Зеленский заявил, что Украина готова остановить удары по российским нефтеперерабатывающим заводам в ответ на симметричное прекращение атак со стороны Москвы.
  - (2026-10-11) Польская полиция получила информацию о возможном покушении на премьер-министра Дональда Туска и главу Минобороны Владислава Косиняк-Камыша | LEDE: В полицию Польши поступила информация, каса] (ru: Пол…
      В полицию Польши поступила информация, касающаяся возможного покушения на премьер-министра страны Дональда Туска, а также министра обороны Владислава Косиняк-Камыша, сообщил пресс-секретарь министра-координатора польских…
  - (2026-10-11) Маск поддержал Трампа, который раскритиковал Зеленского за удары по российским НПЗ и заявил, что Украине нужен новый лидер | LEDE: Миллиардер и основатель SpaceX Илон Маск поддержал Дональда] (ru: Мас…
      Миллиардер и основатель SpaceX Илон Маск поддержал Дональда Трампа, заявившего, что Владимир Зеленский мог закончить войну «много раз», но выбрал не делать этого.
  - (2026-10-11) Умные часы говорят, что я плохо сплю. Им вообще можно верить? | LEDE: Умные часы, кольца и браслеты могут за одну ночь обнаружить сразу несколько поводов для беспокойства: высокий пульс, тол] (ru: Умн…
      Умные часы, кольца и браслеты могут за одну ночь обнаружить сразу несколько поводов для беспокойства: высокий пульс, только 40 минут глубокого сна, низкий уровень кислорода в крови — и вот уже ваш рейтинг восстановления…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 228 new of 494 total
  - (2026-10-11) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-10) [FIRMS] thermal anomaly 47.786, 29.015 (FRP 0.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-10 0105Z, FRP 0.85 MW
  - (2026-10-10) [FIRMS] thermal anomaly 44.774, 33.860 (FRP 0.66 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-10 0105Z, FRP 0.66 MW
  - (2026-10-10) [FIRMS] thermal anomaly 45.260, 31.674 (FRP 3.47 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-10 0105Z, FRP 3.47 MW
  - (2026-10-10) [FIRMS] thermal anomaly 45.952, 25.282 (FRP 1.4 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-10 0105Z, FRP 1.4 MW
  - (2026-10-10) [FIRMS] thermal anomaly 45.358, 22.212 (FRP 1.4 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-10 0107Z, FRP 1.4 MW

### Chinese Internal News — 184 new of 284 total
  - (2026-10-10) 巴拿马爆发7.7级强震 运河未受影响暂无死亡报告 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE84YVk0dnV4c3R5VDRIOHNyTktxcm5xeGNXUHBDUkJxUXllMFlPbzRlZ2htNklCMkw0eHVVSnJvTlpjUGpBMWpFX1R6NUhaY] (zh:…
      巴拿马爆发7.7级强震 运河未受影响暂无死亡报告 财新
  - (2026-10-10) 破解消费和消费率之谜 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9Ha01ScDFMMGZGd2hfYW5OSVcwOEdob3AxSVYzS3FiTFRza0ZJdTU3dG9vNkRCY25PZjI4VkVRMlo0dWlvYkh4akkycFFBNmpwX3Ffb3pySFF] (zh:…
      破解消费和消费率之谜 财新
  - (2026-10-10) 中国如何发展Token经济 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBBcFh1ME9xZlFaZG9SbWZ1SG11VzNSZnF6RlhoUF95R1hHcVduZURPcjhiWUh2NHZicGtBN2VvRWpocFNVZktnVFJpQUpza0E3RWlvVlNR] (zh:…
      中国如何发展Token经济 财新
  - (2026-10-11) 人事观察｜长期任职工人日报社 55岁河北女常委王娇萍兼任统战部长 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5aRTF6ZnlSTjdHVHFkT2NFY2JPRkQzUVZzTXFQSEt4LTZPcXZwTHZVUXRlaml2dkZZclF6OGVfZktDNjVseTdYU] (zh:…
      人事观察｜长期任职工人日报社 55岁河北女常委王娇萍兼任统战部长 财新
  - (2026-10-11) 防范“激进式”创新 四部门拟加强汽车研发测试管理 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZ0FVX3lxTE51d2IxN1I4dmlJMmVoMTlIREdqenhac2lFSGVBcHdFcWt2dEoyNHdoVGNyOFFnaElWOXozMjBSR09fa3FmcjdidlhPUWl6N] (zh:…
      防范“激进式”创新 四部门拟加强汽车研发测试管理 财新
  - (2026-10-10) 最新财新周刊｜2026诺贝尔自然科学奖巡礼 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFBHbUo0bVkzc1ZKS05YbzNEbHZoQ1dOS3VlcFJkcXNNR1ZtSEpPRkJybHRONzZVdldMYnlvd0VTRG5jRFdDdnpEQ2owSW0tT0] (zh:…
      最新财新周刊｜2026诺贝尔自然科学奖巡礼 财新周刊

### Local News: St. Louis + Atlanta — 108 new of 210 total
  - (2026-10-11) [St. Louis] Pope Leo XIV will undergo surgery to remove a nodule on his lung
      Pope Leo XIV announced Sunday he will undergo surgery in the coming days to remove a nodular lesion on his lung that was recently found during medical checks.
  - (2026-10-11) [St. Louis] Man charged with murder in deadly Fenton road rage shooting
      Charging documents say 71-year-old Michael Miller admitted to shooting the victim at least twice following a road rage incident Friday night in Fenton.
  - (2026-10-11) [St. Louis] Man critically injured in north St. Louis shooting
      Police said the shooting happened early Sunday morning near North Grand Boulevard and Montgomery Street.
  - (2026-10-11) [St. Louis] Neighbors spring into action after 2 children die in north St. Louis County house fire
      Two juveniles died and two others were injured in a house fire Friday night in north St. Louis County. The cause of the fire remains under investigation.
  - (2026-10-11) [St. Louis] 4 deaths reported from Isaias as storm brings threat of flooding to Southeast
      Isaias made landfall Friday night as a Category 2 hurricane near Destin, Florida, leaving hundreds of thousands without power. At least four people have died.
  - (2026-10-11) [St. Louis] Did anyone win Powerball's $519M jackpot? Here are the winning numbers for Oct. 10
      Did anyone win the estimated $519 million Powerball jackpot in Saturday night's drawing? Here are the winning numbers.

### U.S. Weather + Severe / Climate Outlooks — 105 new of 106 total
  - (2026-10-11) [Moderate] Gale Watch: Gale Watch issued October 11 at 7:51AM CDT until October 12 at 7:00PM CDT by NWS Duluth MN
      * WHAT...Northeast winds 15 to 25 kt with gusts up to 35 kt and waves 6 to 9 ft possible. * WHERE...Portions of Lake Superior. * WHEN...From late tonight through Monday evening. * IMPACTS...Strong winds can cause hazardo…
  - (2026-10-11) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-11) [Severe] Flood Watch: Flood Watch issued October 11 at 6:42AM MDT until October 12 at 6:00PM MDT by NWS Salt Lake City UT
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of Utah, including the following areas, Castle Country, Central Mountains, Eastern Juab/Millard Counties, San Rafael Swel…
  - (2026-10-11) [Severe] Flood Watch: Flood Watch issued October 11 at 6:42AM MDT until October 12 at 6:00PM MDT by NWS Salt Lake City UT
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of Utah, including the following areas, Western Millard and Juab Counties, Bear Lake and Bear River Valley, Cache Valley/Utah P…
  - (2026-10-11) [Severe] Flood Warning: Flood Warning issued October 11 at 8:34AM EDT until October 11 at 10:00AM EDT by NWS Blacksburg VA
      * WHAT...Urban areas and small streams flooding caused by excessive rainfall continues. * WHERE...South Central Ashe County in northwestern North Carolina... Watauga County in northwestern North Carolina... Southwestern…
  - (2026-10-11) [Severe] Flash Flood Warning: Flash Flood Warning issued October 11 at 5:33AM PDT until October 11 at 8:30AM PDT by NWS Las Vegas NV
      FFWVEF The National Weather Service in Las Vegas has issued a * Flash Flood Warning for... West Central Clark County in southern Nevada... * Until 830 AM PDT. * At 533 AM PDT, Doppler radar indicated thunderstorms produc…

### State-Level News — 102 new of 413 total
  - (2026-10-10) [Alabama] Third Supplemental State of Emergency: Hurricane Isaias
  - (2026-10-11) [Connecticut] ICE deported her from CT. Now, she parents from Mexico.
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/2026_07_08_NANCY_ICE_AR_DSCF4742-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="asyn…
  - (2026-10-11) [Connecticut] PAID POST: How Connecticut Hospitals Are Modernizing Critical Infrastructure for the Future
      <img width="624" height="352" src="https://ctmirror.org/wp-content/uploads/2026/06/CHEFA-2.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="https://c…
  - (2026-10-11) [Connecticut] The final boarding call
      <img width="1023" height="677" src="https://ctmirror.org/wp-content/uploads/2026/10/People_Express_Boeing_747_at_London_Gatwick_in_June_1983.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=""…
  - (2026-10-11) [Colorado] Cornell case highlights the patchwork of state laws governing intoxication, sexual consent
      A former Cornell University student’s allegations of gang rape in 2024 have renewed attention on a difficult area of sexual assault law. A person can be awake, responsive and even able to move during a sexual encounter w…
  - (2026-10-11) [Arkansas] Trump touts Memphis law enforcement surge in Tennessee rally meant to shore up midterm support
      CLARKSVILLE, Tenn. — The rainy remnants of Hurricane Isaias didn’t deter Tennessee Republicans from turning out Saturday to hear President Donald Trump decry state Democrats as “communists” and “socialists,” and praise T…

### Ukrainian Internal News (national + local Kyiv) — 56 new of 136 total
  - (2026-10-11) Російський удар по Запоріжжю: кількість загиблих зросла до 23 | LEDE: Внаслідок російського удару по житловому будинку у Запоріжжі 10 жовтня загинуло 23 людини, включно з чотирма дітьми. Пошуко] (uk:…
      Внаслідок російського удару по житловому будинку у Запоріжжі 10 жовтня загинуло 23 людини, включно з чотирма дітьми. Пошукові роботи завершено.
  - (2026-10-11) На території Молдови вибухнув невідомий дрон | LEDE: В ніч на неділю, 11 жовтня, на території Молдови впав і вибухнув невідомий безпілотник.] (uk: На території Молдови вибухнув невідомий дрон)
      В ніч на неділю, 11 жовтня, на території Молдови впав і вибухнув невідомий безпілотник.
  - (2026-10-11) Росіяни вдарили по Харкову КАБами: загинула жінка, 3 постраждалих | LEDE: Унаслідок атаки по приватному сектору Харкова 11 жовтня загинула жінка, ще троє людей поранені. Два будинки знищено, 15] (uk:…
      Унаслідок атаки по приватному сектору Харкова 11 жовтня загинула жінка, ще троє людей поранені. Два будинки знищено, 15 пошкоджено, виникла пожежа.
  - (2026-10-11) Німецькі соціал-демократи хочуть виключити Шредера зі своїх лав за святкування з Путіним | LEDE: В німецькій Соціал-демократичній партії дедалі гучніше лунають заклики виключити з партії колишн] (uk:…
      В німецькій Соціал-демократичній партії дедалі гучніше лунають заклики виключити з партії колишнього канцлера Герхарда Шредера через його тісні зв'язки з правителем Росії Володимиром Путіним.
  - (2026-10-11) Росія посилює спроби змахів на керівників оборонних компаній у Європі, – Financial Times | LEDE: ] (uk: Росія посилює спроби змахів на керівників оборонних компаній у Європі, – Financi)
  - (2026-10-11) Росіяни вдарили дроном по вантажівці на Харківщині – водій загинув | LEDE: У Богодухівському районі росіяни вдарили безпілотником по вантажівці сільгосппідприємства: один загиблий, є поранений.] (uk:…
      У Богодухівському районі росіяни вдарили безпілотником по вантажівці сільгосппідприємства: один загиблий, є поранений.

### GDACS — global disaster alerts — 44 new of 100 total
  - (2026-10-11) [Green] Earthquake in Southeast Of Ryukyu Islands
      Earthquake · Green alert · Southeast Of Ryukyu Islands · Magnitude 4.8M, Depth:10km
  - (2026-10-11) [Green] Earthquake in Russian Federation
      Earthquake · Green alert · Russian Federation · Magnitude 4.6M, Depth:68.683km
  - (2026-10-11) [Green] Earthquake in Fiji
      Earthquake · Green alert · Fiji · Magnitude 4.6M, Depth:512.919km
  - (2026-10-11) [Green] Earthquake in South Of Fiji Islands
      Earthquake · Green alert · South Of Fiji Islands · Magnitude 4.5M, Depth:546.339km
  - (2026-10-11) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.7M, Depth:10.602km
  - (2026-10-11) [Green] Earthquake in South Of Java, Indonesia
      Earthquake · Green alert · South Of Java, Indonesia · Magnitude 5.2M, Depth:10km

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 21 new of 22 total
  - (2026-10-11) JAF94H (Bulgaria)
      icao24: 4520aa · position: (33.1968, -8.3163) · alt: 11277m · 957km/h
  - (2026-10-11) GAF901 (Germany)
      icao24: 3ea12c · position: (50.8621, 7.1201) · on ground
  - (2026-10-11) JAF85C (Belgium)
      icao24: 44d1a6 · position: (43.5929, 15.1822) · alt: 10668m · 914km/h
  - (2026-10-11) JAF3EM (Belgium)
      icao24: 44d1a5 · position: (50.9065, 4.4882) · on ground · 35km/h
  - (2026-10-11) JAF6EJ (Belgium)
      icao24: 44d1b4 · position: (44.7414, -0.2996) · alt: 11277m · 954km/h
  - (2026-10-11) JAF4AB (Belgium)
      icao24: 44d1a2 · position: (46.2261, 14.0492) · alt: 11277m · 915km/h

### USGS earthquakes (M4.5+, past day) — 21 new of 21 total
  - (2026-10-10) M 5.3 - southeast of Easter Island
      M5.3 · southeast of Easter Island · depth 10 km
  - (2026-10-11) M 5.2 - 180 km S of Pelabuhanratu, Indonesia
      M5.2 · 180 km S of Pelabuhanratu, Indonesia · depth 10 km
  - (2026-10-11) M 5.0 - 3 km NW of Flores, Panama
      M5.0 · 3 km NW of Flores, Panama · depth 10 km
  - (2026-10-10) M 4.9 - Kermadec Islands region
      M4.9 · Kermadec Islands region · depth 117.707 km
  - (2026-10-11) M 4.8 - 165 km SSE of Miyakojima, Japan
      M4.8 · 165 km SSE of Miyakojima, Japan · depth 10 km
  - (2026-10-10) M 4.8 - 11 km SSW of Tebario, Panama
      M4.8 · 11 km SSW of Tebario, Panama · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-10-11) Dota 2: Team Spirit vs PARIVISION (BO3) - BLAST Slam Playoffs
      yes price: 84% · 24h volume: $1,856,336 · resolves 2026-10-11
  - (2026-10-11) Will Everton FC win on 2026-10-11?
      yes price: 50% · 24h volume: $1,356,815 · resolves 2026-10-11
  - (2026-10-11) Shanghai Rolex Masters: Alexander Bublik vs Brandon Nakashima
      yes price: 100% · 24h volume: $923,149 · resolves 2026-10-19
  - (2026-10-11) Counter-Strike: Aurora Gaming vs Spirit (BO3) - ESL Pro League Playoffs
      yes price: 79% · 24h volume: $834,218 · resolves 2026-10-11
  - (2026-10-11) Eagles vs. Jaguars
      yes price: 24% · 24h volume: $824,853 · resolves 2026-10-11
  - (2026-10-11) Olbia: Matyas Cerny vs Vadym Ursu
      yes price: 100% · 24h volume: $650,817 · resolves 2026-10-18

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-10-10) U.S. Court of Appeals, 5th Cir.: Gakou v. Warden
  - (2026-10-09) U.S. Court of Appeals, 9th Cir.: Alliance for the Wild Rockies v. United States Forest Service
  - (2026-10-09) U.S. Court of Appeals, 9th Cir.: Black v. Iec Group, Inc.
  - (2026-10-08) Arkansas Supreme Court: Arkansas Wine and Spirits Wholesale, LLC v. Arkansas Department of Finance and Administration; Arkansas Alcoholic Beverage Control Division; Freddie Black, in His Official Capa…
  - (2026-10-08) Arkansas Supreme Court: In Re Arkansas Committee on Professional Conduct
  - (2026-10-08) Arkansas Supreme Court: In Re Arkansas Supreme Court Committee on Automation

### World News (by country, top stories) — 10 new of 10 total
  - (2026-10-10) [China] Logistics : Keeping the Malacca Strait Safe
      strategypage.com · English
  - (2026-10-10) [China] The bigger picture -- Beijing Review
      bjreview.com · English
  - (2026-10-10) [China] How to Delete a Samsung Account Without the Password
      gizchina.com · English
  - (2026-10-10) [China] 【 AICC Original Article 】 Anhui consumer market maintains steady growth during National Day holiday
      english.anhuinews.com · English
  - (2026-10-10) [China] Counter - Terrorism : The Hamas Eternal War
      strategypage.com · English
  - (2026-10-10) [China] Hong Kong SAR draws 1 . 6 mln visitor arrivals during Natl Day holiday
      hongkongherald.com · English

### IT, InfoSys & cybersecurity news (last 7 days) — 10 new of 61 total
  - (2026-10-11) [The Register] AI systems are fully capable of carrying out nightmare attacks against infrastructure and nobody's ready
      Meanwhile, AI agents move robotic arms, 'make OT device operator screens lie'
  - (2026-10-11) [The Register] HPE's networking boss says AI will handle all trouble tickets without humans in two years
      And you'll trust agents to do that for the same reason you no longer worry about automatic transmissions
  - (2026-10-11) [The Register] Researchers work out how to control 2D semiconductor growth for future chips
      Korean boffins use oxygen to stop crystals forming in the wrong places, aiming to get tech to commercial sector by 2030
  - (2026-10-10) [BleepingComputer] Cyber exec arrested in case allegedly tied to ShinyHunters hackers
      Canadian cybersecurity executive Edward Dubrovsky has been arrested in Pennsylvania in connection with alleged extortion activity that multiple reports have linked to the FBI's ongoing crackdown on the ShinyHunters hacki…
  - (2026-10-10) [BleepingComputer] ARTEX AI, Claude agents used in cyberattacks on South Korean banks
      The cyberattacks that shook the South Korean financial sector earlier this month were launched by a Chinese hacker using the ARTEX AI penetration testing suite and Claude agents. [...]
  - (2026-10-10) [TechCrunch] Microsoft’s Satya Nadella says AI models need an ‘emergency brake’
      In a Saturday morning post, Microsoft's CEO wrote that it’s time “to step back and assess the trust architecture” of AI.

### Paper Trading Scorecard — 6 new of 56 total
  - (2026-10-11) [Manifold] Will Rupert Lowe become UK prime minister before 2031?
  - (2026-10-11) [Manifold] Daily Coinflip
  - (2026-10-11) [Manifold] Republicans win Texas governor by 6+ points?
  - (2026-10-11) [Manifold] Will there be a second Ice / Fairy type pokemon released by the end of 2029?
  - (2026-10-11) [Manifold] Will Alice Weidel become next German chancellor before 2030?
  - (2026-10-11) [Manifold] Will the next Claude Fable be able to autonomously make a watchable movie?

### Government Action: Sanctions + Procurement + Foreign Agents — 3 new of 111 total
  - (2026-10-11) [USASpending] $2,032,829,135 → LOCKHEED MARTIN CORP: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONAR
      Agency: National Aeronautics and Space Administration. Description: THE GOVERNMENT IS PROCURING THE NEXT-GENERATION GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) SERIES TO CONTINUE ITS MISSION THROUGH NEW REQ…
  - (2026-10-11) [USASpending] $230,300,188 → PALMETTO GBA, LLC: JJ A/B MAC
      Agency: Department of Health and Human Services. Description: JJ A/B MAC
  - (2026-10-11) [USASpending] $188,102,935 → SOUTHWEST RESEARCH INSTITUTE: THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION HAS SELECT
      Agency: National Aeronautics and Space Administration. Description: THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION HAS SELECTED JUNO NEW FRONTIERS MISSION UNDER THE DIRECTION OF PRINCIPAL INVESTIGATOR (PI) DR. SCOTT B…

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-11) [Marginal Revolution] Sky Roomba!
      I bought a robot window cleaner. I have some high windows which need a ladder just to get the bottom and with this I can just start the robot at the bottom, it cleans the window and then returns to the start point. The b…
  - (2026-10-11) [Marginal Revolution] What should I ask Fuchsia Dunlop?
      Yes I will be doing a fourth (!) Conversation with her, based in part on her forthcoming book Five Tastes: Delicious Recipes for Chinese Flavors. I am sure it is excellent, and will read it very soon. Her works are not j…
  - (2026-10-11) [Marginal Revolution] The economics of agents
      From Patrick Collison: Assorted things I’ve been mulling over regarding agents in the economy: • Companies are in some sense the original superintelligence. It’s often the case that they can use their amortized cognitive…

### State Legislative Action — 1 new of 73 total
  - (2026-10-10) [Alaska SB 237] An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Departm…
      An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Department of Administration; relating to e…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-10-10) Pneumonia of undetermined etiology - the Russian Federation
      On 2 October 2026, WHO became aware through media reports of the death of an employee of the Irkutsk Antiplague Research Institute (APRI) of Siberia and the Far East, the Russian Federation. According to these reports, t…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-11) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=26, 14d-median=25; carrying terms: national, final, model, regulatory, action, proposed, safety, certain, proposes, provide, policy, document
- state_bills: today=73, 7d-median=111, 14d-median=78; carrying terms: provide, local, inspection, affairs, administration, project, policy, defines, projects, authority, adopt, coverage
- state_news: today=413, 7d-median=667, 14d-median=682; carrying terms: another, workers, small, front, cases, flgov, women, transgender, groups, single, pressherald, concerns
- local_news: today=210, 7d-median=233, 14d-median=229; carrying terms: another, blank, georgia, across, early, arrested, articles, dining, magazine, officer, class, night
- foreign_news: today=970, 7d-median=1018, 14d-median=1018; carrying terms: another, workers, launches, above, urges, small, saying, affairs, staff, attacks, women, default
- chinese_internal: today=284, 7d-median=279, 14d-median=270; carrying terms: cbmiakfvx, cbmizefvx, investors, google, cbmix, https, cbmic, cbmiw, color, cbmidefvx, cbmia, lxtfb
- russian_internal: today=898, 7d-median=1074, 14d-median=1052; carrying terms: gazeta, openai, telegram, group, forbidden, politico, blank, reuters, found, russian, media, httperror
- ukrainian_internal: today=136, 7d-median=136, 14d-median=134; carrying terms: attacks, russian, hybrid, cabinet, babel, ukrainian, region, across, potential, package, occupied, strike
- ukraine_theater: today=494, 7d-median=584, 14d-median=572; carrying terms: scnrnlwpix, vyaezumhytzndftuhcc, fksui, jmvxhnstbuou, thczmupvs, ymvxuhe, qwhxu, tsvnlswmzpx, mujrvnzky, benfcnbfawndznpkvevcngdeyklvtmvboecxrmvsnznvdvdkz, ejjzrnn, dxaxbtwfztmgnyt
- paper_bets: today=56, 7d-median=128, 14d-median=122; carrying terms: openai, starts, erupt, world, chase, prime, degrees, kylian, prize, playoff, anthropic, patrick
- weather: today=106, 7d-median=141, 14d-median=142; carrying terms: temperatures, rainfall, rivers, minor, miami, above, waters, front, continues, afdtbw, changed, outlook
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: money, funds, inflation, jtsjol, walcl, rates, labor, dexuseu, jolts, growth, recession, cpiaucsl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, natural, range, proxy, bitcoin, rates, yield, corporate, crude, close, credit, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=111, 14d-median=114; carrying terms: nicaragua, drilling, destabilisation, science, tunisia, bombing, administration, blank, recognition, trade, attacks, russian
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, quiverquant, https, congresstrading, quiver, error, httperror
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, corporation, supreme, appeals, court, company, howard, international, county, delaware, board, brown
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, accno, financial, reporting, trust, holdings, group, james, robert, steven, technology
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: elect, receipts, cortez, krishnamoorthi, jonathan, talarico, booker, lindsey, angels, james, brown, robert
- gdelt_regions: today=10, 7d-median=6, 14d-median=8; carrying terms: english, japan, china
- gdelt_gkg: today=0, 7d-median=49, 14d-median=49; carrying terms: english, chinese, themes, russian, french, spanish, russia, sanctions, china, perimeter, romanian, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=0; carrying terms: election, kingdom, israeli, canada, israel, against, domain, english, language, medical, india, russian
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=30, 14d-median=30; carrying terms: position, belgium, germany, france, ground, kingdom, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: carrying, confirmed, august, control, workers, increasing, distributed, bangladesh, recombinant, local, indicating, adult
- cisa_kev: today=13, 7d-median=13, 14d-median=17; carrying terms: netscaler, injection, validation, within, restriction, buffer, operations, multiple, vendor, bounds, write, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100
- usgs_quakes: today=21, 7d-median=17, 14d-median=16; carrying terms: depth, indonesia, japan, islands, south, region, philippines, russia, papua, guinea, tonga, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, champions, price, shakhtar, volume, donetsk, resolves, championship, october, election, presidential, strike
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, conversableeconomist, economist, conversable, marginal, https, class, taxes, income, property, spending, economy
- tech_news: today=61, 7d-median=59, 14d-median=57; carrying terms: openai, access, going, attacks, engineers, vulnerability, world, users, https, across, spectrum, schneier
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: margaret, ricketts, desaulnier, murkowski, rashida, craig, sylvia, perez, trading, babin, darren, malliotakis
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, decision, today, either, market, module, unavailable, sufficient, converges, evidence, placed, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] ECB press: Philip R. Lane: Diagnostic Challenges for ECB Monetary Policy
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*