# WORLDSCOPE morning brief — 2026-08-17

## Headline
3582 new items across 22 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (957) · International News + Multilateral Institutions (661) · Russian Internal News (state + in-exile) (628) · World leaders & government officials (324) · Chinese Internal News (227) · U.S. Weather + Severe / Climate Outlooks (164) · State Legislative Action (137) · Local News: St. Louis + Atlanta (107) · State-Level News (105) · Ukrainian Internal News (national + local Kyiv) (50) · GDELT GKG — themes / entities / watch areas (49) · Sanctions & Designations (recent) (30)

## What changed today
### Ukraine Theater (total-war monitoring) — 957 new of 1151 total
  - (2026-08-17) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-16) [FIRMS] thermal anomaly 45.958, 34.561 (FRP 2.48 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-16 0941Z, FRP 2.48 MW
  - (2026-08-16) [FIRMS] thermal anomaly 46.208, 34.394 (FRP 4.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-16 0941Z, FRP 4.73 MW
  - (2026-08-16) [FIRMS] thermal anomaly 46.205, 34.395 (FRP 7.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-16 0941Z, FRP 7.98 MW
  - (2026-08-16) [FIRMS] thermal anomaly 46.355, 34.469 (FRP 12.24 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-16 0941Z, FRP 12.24 MW
  - (2026-08-16) [FIRMS] thermal anomaly 46.509, 34.978 (FRP 5.88 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-16 0941Z, FRP 5.88 MW

### International News + Multilateral Institutions — 661 new of 932 total
  - (2026-08-17) [Global] Trump says US to reduce military drills with South Korea after it stayed out of Iran war
      Trump cites his "very good relationship" with North Korea's leader in deciding to downsize the exercises.
  - (2026-08-17) [Global] Trump envoy Kushner arrives in Israel after rare Hamas talks on Gaza peace plan
      US President Trump's son-in-law Jared Kushner is expected to meet Israeli Prime Minister Benjamin Netanyahu later on Monday.
  - (2026-08-17) [Global] Ukrainian strikes kill six in Russia, acting governor says
      A 14-year-old child was among four others injured, the acting governor of Russia's Belgorod region says.
  - (2026-08-17) [Global] Aid shortages and fears of starvation as Indonesia reels from deadly earthquake
      Some 53 people were killed and thousands displaced by the earthquake, which struck early on Saturday.
  - (2026-08-17) [Global] Ebola outbreak in DR Congo becomes deadliest in its history
      The outbreak was already the fastest growing on record, caused by a rare species of Ebola called Bundibugyo.
  - (2026-08-17) [Global] Top Zambian opposition figures arrested days after presidential vote
      The authorities allege they were involved in an insurrection plot but the leading opposition candidate says there was an attempt on his life.

### Russian Internal News (state + in-exile) — 628 new of 815 total
  - (2026-08-17) На основательницу «Дождя» Наталью Синдееву завели уголовное дело о создании «нежелательной» организации | LEDE: На председателя совета директоров «Дождя» Натальи Синдеевой и генерального дир] (ru: На…
      На председателя совета директоров «Дождя» Натальи Синдеевой и генерального директора телеканала Марка Тена завели уголовное дело об организации деятельности «нежелательной организации», сообщило ТАСС со ссылкой на правоо…
  - (2026-08-17) В Петербурге задержали гражданина Германии по делу о переводе 900 рублей ФБК | LEDE: В Петербурге задержали 41-летнего гражданина одной из европейских стран, его подозревают в переводе 900 р] (ru: В П…
      В Петербурге задержали 41-летнего гражданина одной из европейских стран, его подозревают в переводе 900 рублей на счет «экстремистской» организации. Об этом сообщили в региональном управлении МВД РФ.
  - (2026-08-17) Основателя автодилера «Рольф» Сергея Петрова заочно приговорили к девяти годам колонии | LEDE: Черемушкинский районный суд Москвы заочно приговорил основателя автодилера «Рольф», бывшего деп] (ru: Осн…
      Черемушкинский районный суд Москвы заочно приговорил основателя автодилера «Рольф», бывшего депутата Госдумы Сергея Петрова к девяти годам лишения свободы по обвинению в выводе четырех миллиардов рублей за рубеж. Об этом…
  - (2026-08-17) Швеция, Бельгия, Нидерланды и Люксембург перестанут признавать российские небиометрические загранпаспорта | LEDE: С 1 октября 2026 года Бельгия, Люксембург, Нидерланды и Швеция перестанут пр] (ru: Шве…
      С 1 октября 2026 года Бельгия, Люксембург, Нидерланды и Швеция перестанут признавать российские небиометрические паспорта. Соответствующая информация опубликована Еврокомиссией.
  - (2026-08-17) Криптобиржа Binance передала российским силовикам данные об айтишнике, который жил в ЕС. Сейчас его судят в России за донаты ВСУ | LEDE: Крупнейшая в мире криптовалютная биржа Binance выдала] (ru: Кри…
      Крупнейшая в мире криптовалютная биржа Binance выдала российским силовикам информацию о своем пользователе, IT-специалисте Юрии Беленьком, которого в РФ обвиняют в финансировании терроризма из-за донатов в пользу ВСУ. Об…
  - (2026-08-17) YLE: «Яндекс» дорисовал лес на картах, чтобы скрыть военные объекты | LEDE: «Яндекс» на своих картах дорисовал лес на месте военного объекта, обратило внимание финское издание YLE. Скопирова] (ru: YLE…
      «Яндекс» на своих картах дорисовал лес на месте военного объекта, обратило внимание финское издание YLE. Скопированные фрагменты леса появились на спутниковом снимке окрестностей Кронштадта на участке, где расположены ра…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 227 new of 260 total
  - (2026-08-16) 太湖流域发生大洪水 湖州1人死亡、苏州发洪水红警(含视频) - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9XRXpDMWx6eldlbjYwM1l0dnRuTWFUelhoM1V2SDlMWGtsd3pnS180elhuaE1GOTF3cjVEQ013ND] (zh:…
      太湖流域发生大洪水 湖州1人死亡、苏州发洪水红警(含视频) china.caixin.com
  - (2026-08-17) 今日开盘：小幅高开 沪指涨幅0.07% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1QNmNmbEtfeDhRQmxDM1NkY1lKSXJtdFlVLWp0dGYzWU1iUGkyM1puaXdIWmY0X3Rua2QtRUdTNHc2SFo4ZDlrRFhOLUNPNXVfY1] (zh:…
      今日开盘：小幅高开 沪指涨幅0.07% 财新
  - (2026-08-16) 财经早知道｜《求是》杂志发表习近平重要文章：提高防灾减灾救灾能力 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9ON2EwTXQ1YzRjUmd2UGo3NktkSmhTX21SLUVQUjQ0ZEx4WWFuc2dua29lQlhwWk0ySng3OG4weHg2TnB5UGRhO] (zh:…
      财经早知道｜《求是》杂志发表习近平重要文章：提高防灾减灾救灾能力 财新
  - (2026-08-17) 阿里巴巴剥离游戏业务灵犀互娱 信宸资本接手 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE93cEctSmRFem9NS0htcGlhSUFlZUptakFkelRkVlVTcVF2NzhaTE41TzhRSW1zRTh2SlY5R25EVjJQcEtXU1RIV1c5djdDUTds] (zh:…
      阿里巴巴剥离游戏业务灵犀互娱 信宸资本接手 财新
  - (2026-08-16) 反腐记｜程晓波官宣落马 陆文俊、龙翔一审领刑 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBwWk1aWGs2ZmZpSWtOV1BZNnh4NE1Jbnhzd3daNWprSk1aMTdvUjIxdnlsMTI2TnFvSDhWX0h3TUNWZlozZ] (zh:…
      反腐记｜程晓波官宣落马 陆文俊、龙翔一审领刑 china.caixin.com
  - (2026-08-17) 大西洋观察│以色列的10月选择 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9LcE0wSUUzSzJDdDJxallYXzcwT0RHSHNIanZZWUJOUHRuUjBNRXhCM0hnQmNJT1NYa292WHV5MVh3QkJVbzdGeElSVWluME05UjhkaE] (zh:…
      大西洋观察│以色列的10月选择 财新

### U.S. Weather + Severe / Climate Outlooks — 164 new of 166 total
  - (2026-08-17) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-17) [Severe] Flood Warning: Flood Warning issued August 17 at 5:16AM EDT until August 17 at 8:45AM EDT by NWS Charleston WV
      * WHAT...Large stream flooding caused by excessive rainfall continues. * WHERE...Northeastern Upshur County in northeastern West Virginia... * WHEN...Until 845 AM EDT. * IMPACTS...Flooding of Sand Run and it's tributarie…
  - (2026-08-17) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 17 at 2:14AM PDT until August 21 at 8:00PM PDT by NWS Las Vegas NV
      * WHAT...Dangerously hot conditions with temperatures up to 115 to 118 degrees expected through Death Valley and the lower Colorado River Valley, with highs between 107 to 110 degrees elsewhere. * WHERE...Portions of nor…
  - (2026-08-17) [Severe] Flood Warning: Flood Warning issued August 17 at 5:11AM EDT until August 17 at 6:30PM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...North Central Washington County in southeastern Ohio... * WHEN...Until 630 PM EDT Monday. * IMPACTS...Flooding of Duck Creek and it's tributaries is occ…
  - (2026-08-17) [Moderate] Special Weather Statement: Special Weather Statement issued August 17 at 5:08AM EDT by NWS Peachtree City GA
      Some patchy dense fog will restrict visibilities to less than one- quarter of a mile across the valleys of the north Georgia mountains. The fog should lift by 9 am. If driving this morning, slow down, use low-beam headli…
  - (2026-08-17) [Moderate] Heat Advisory: Heat Advisory issued August 17 at 4:57AM EDT until August 17 at 8:00PM EDT by NWS Greenville-Spartanburg SC
      * WHAT...Heat index values up to 107 expected. * WHERE...Portions of northeast Georgia, Piedmont North Carolina, and Upstate South Carolina. * WHEN...From noon today to 8 PM EDT this evening. * IMPACTS...Hot temperatures…

### State Legislative Action — 137 new of 137 total
  - (2026-08-16) [California AB 2468] School accountability: pupils with disabilities: inclusion.
      Existing law establishes a single system for providing support to local educational agencies and schools and for specified federal educational programs. Existing law provides that the purpose of the statewide system of s…
  - (2026-08-16) [California AB 1552] Public postsecondary education: civic engagement: recommendations report.
      Existing law establishes the University of California, under the administration of the Regents of the University of California, the California State University, under the administration of the Trustees of the California…
  - (2026-08-16) [California AB 2483] Wildland firefighters: Formerly Incarcerated Firefighter Certification and Employment Program.
      Existing law establishes in the Natural Resources Agency the Department of Forestry and Fire Protection, and requires the department to be responsible for, among other things, fire protection and prevention, as provided.…
  - (2026-08-16) [California AB 2076] The Parent's Accountability and Child Protection Act: online marketplaces: nitrous oxide.
      Existing law requires a person or business that conducts business in California and that seeks to sell specified products or services, to take reasonable steps, as specified, to ensure that the purchaser is of legal age…
  - (2026-08-16) [California AB 1159] Student personal information.
      Existing law, the K–12 Pupil Online Personal Information Protection Act (KOPIPA) , generally protects the personal information of a student enrolled in a K–12 course of instruction, defined as a "pupil," by prescribing r…
  - (2026-08-16) [California AB 1769] Student transfer: tribal colleges.
      The Donahoe Higher Education Act establishes the California Community Colleges under the administration of the Board of Governors of the California Community Colleges, the California State University under the administra…

### Local News: St. Louis + Atlanta — 107 new of 169 total
  - (2026-08-17) [St. Louis] See the Aug. 17, 1926, front page: Ex-constable at Desloge is shot to death through window
      Headlines from the Aug. 17, 1926, front page include: Bottle dropped from plane hits woman in auto
  - (2026-08-17) [St. Louis] The Short List: August 17
      Welcome to The Short List newsletter, a look at what's ahead in the St. Louis area — key news happenings, big sports matchups, can't-miss events and maybe even food recommendations.
  - (2026-08-17) [St. Louis] The story behind why a 9/11 steel beam was at Busch Stadium
      Plus: Chesterfield man uses AI skills for medical app to help his wife and others
  - (2026-08-17) [St. Louis] FIRM FINDS WAY TO MAKE STERILE FLIES
      A Colorado potato beetle is photographed Friday, Aug. 7, 2026, at Agragene's Maryland Heights headquarters. Agragene rears the troublesome insects in order to conduct genetic experiments. The company develops genetic met…
  - (2026-08-17) [St. Louis] FIRM FINDS WAY TO MAKE STERILE FLIES
      Delaney Jones, an associate scientist at Agragene, screens strains of genetically modified pupae of the spotted wing drosophila fly on Friday, Aug. 7, 2026, at the company's Maryland Heights headquarters.
  - (2026-08-17) [St. Louis] FIRM FINDS WAY TO MAKE STERILE FLIES
      AGRICULTURE

### State-Level News — 105 new of 205 total
  - (2026-08-16) [Arkansas] DNC approves 2028 presidential nominating cycle starting in South Carolina, Nevada
      The Democratic National Committee on Saturday approved by voice vote its lineup of six early primaries for the 2028 election cycle, kicking off with South Carolina and Nevada. DNC Chair Ken Martin said during Saturday’s…
  - (2026-08-16) [Arkansas] Trump Team’s Use of Arcane Budget Rule Threatens Medicaid Coverage
      About 200,000 low-income Arkansans could see major changes to their health coverage next year after the Trump administration recently informed state officials it will not renew a key Medicaid agreement with the federal g…
  - (2026-08-16) [Arkansas] Farm Bill impasse tests Arkansas Sen. John Boozman’s low-key approach
      Ten years ago, Republican U.S. Sen. John Boozman faced a challenge from a Democratic rival who portrayed the lawmaker as out of touch with Arkansas and too aligned with Donald Trump. His challenger, Conner Eldridge, brou…
  - (2026-08-17) [Hawaii] NEWS RELEASE – STATE OF HAWAIʻI UPDATE ON HURRICANE LALA
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA DEPARTMENT OF DEFENSE KA ʻOIHANA PILI KAUA HAWAI‘I EMERGENCY MANAGEMENT AGENCY KE‘ENA HO‘OMALU PŌULIA O HAWAI‘I HAWAIʻI JOINT INFORMATION […]
  - (2026-08-17) [Connecticut] A letter to Luke Bronin
      <img width="1024" height="685" src="https://ctmirror.org/wp-content/uploads/2026/08/CT-PRIMARY-JL-0811-6910-1024x685.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-08-17) [Connecticut] What trans youth need from CT leaders now
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/AP-transgender-care.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcs…

### Ukrainian Internal News (national + local Kyiv) — 50 new of 105 total
  - (2026-08-17) "Бандеризм" переміг у Польщі. Пояснюємо, як минуле захопило політику сусідів щодо України | LEDE: Польська держава може потребувати сильної України, натомість польський політик може потребувати] (uk:…
      Польська держава може потребувати сильної України, натомість польський політик може потребувати ще кількох відсотків голосів.
  - (2026-08-17) Як Татаров із Цуцкірідзе будують правоохоронну систему за московськими методичками | LEDE: Як Олег Татаров і Максим Цуцкірідзе зміцнюють контроль над правоохоронною системою України та блокують] (uk:…
      Як Олег Татаров і Максим Цуцкірідзе зміцнюють контроль над правоохоронною системою України та блокують антикорупційні зміни.
  - (2026-08-17) Міністр оборони Румунії прокоментував частіші інциденти з дронами на території країни | LEDE: ] (uk: Міністр оборони Румунії прокоментував частіші інциденти з дронами на території к)
  - (2026-08-17) Жителі постраждалої від пожеж Жиронди освистали прем’єра Франції | LEDE: Прем'єр-міністра Франції Себастьєна Лекорню освистали під час його візиту до муніципалітету Ле-Порж у департаменті Жирон] (uk:…
      Прем'єр-міністра Франції Себастьєна Лекорню освистали під час його візиту до муніципалітету Ле-Порж у департаменті Жиронда, який серйозно постраждав внаслідок пожеж.
  - (2026-08-17) Окупанти обстріляли в Херсоні маршрутку й мікроавтобус: поранення дістали водії | LEDE: Російські окупаційні війська вранці 17 серпня атакували у Корабельному районі Херсона мікроавтобус і марш] (uk:…
      Російські окупаційні війська вранці 17 серпня атакували у Корабельному районі Херсона мікроавтобус і маршрутку, двох людей поранено.
  - (2026-08-17) У Німеччині суттєво зросла кількість мігрантів, які добровільно повертаються додому | LEDE: У 2026 році більше мігрантів у Німеччині добровільно повернулися на батьківщину після відмови в приту] (uk:…
      У 2026 році більше мігрантів у Німеччині добровільно повернулися на батьківщину після відмови в притулку.

### GDELT GKG — themes / entities / watch areas — 49 new of 49 total
  - (2026-08-17) [Israel-Iran-Hezbollah axis · themes] AK Party 25 years : Modernity born of tradition
      dailysabah.com · English · tone NA
  - (2026-08-17) [Israel-Iran-Hezbollah axis · themes] Admirál Cooper pochválil odolnost posádky USS Abraham Lincoln
      idnes.cz · Czech · tone NA
  - (2026-08-17) [Israel-Iran-Hezbollah axis · themes] How China Shielded Itself From Oil Shock
      rediff.com · English · tone NA
  - (2026-08-17) [Israel-Iran-Hezbollah axis · themes] Lenorme incendio nella più grande riserva naturale del Belgio
      ilpost.it · Italian · tone NA
  - (2026-08-17) [Israel-Iran-Hezbollah axis · themes] India temple stampede kills seven : authorities
      arynews.tv · English · tone NA
  - (2026-08-17) [Israel-Iran-Hezbollah axis · themes] Autodesk Fusion for Manufacturing Connects CNC Design and Machining Workflows
      mmsonline.com · English · tone NA

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-17) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (47.5528, 1.8602) · alt: 8473m · 919km/h
  - (2026-08-17) CFC2979 (Canada)
      icao24: c2b5b7 · position: (42.2883, -6.4144) · alt: 7620m · 633km/h
  - (2026-08-17) JAF1YV (Belgium)
      icao24: 44d1ba · position: (39.1165, 19.3426) · alt: 10972m · 824km/h
  - (2026-08-17) JAF97T (Belgium)
      icao24: 44d1a7 · position: (45.0123, 15.8755) · alt: 12192m · 830km/h
  - (2026-08-17) JAF7GY (Belgium)
      icao24: 44d1a5 · position: (45.0086, -3.0745) · alt: 10972m · 760km/h
  - (2026-08-17) JAF9TC (Belgium)
      icao24: 44d1b3 · position: (38.8757, 1.3692) · on ground

### USGS earthquakes (M4.5+, past day) — 24 new of 24 total
  - (2026-08-17) M 5.7 - 65 km NNW of Ende, Indonesia
      M5.7 · 65 km NNW of Ende, Indonesia · depth 48.947 km
  - (2026-08-17) M 5.3 - 68 km NNW of Ende, Indonesia
      M5.3 · 68 km NNW of Ende, Indonesia · depth 10 km
  - (2026-08-16) M 5.3 - 75 km NNE of Ruteng, Indonesia
      M5.3 · 75 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-17) M 5.2 - 70 km NNW of Ende, Indonesia
      M5.2 · 70 km NNW of Ende, Indonesia · depth 16.335 km
  - (2026-08-16) M 5.2 - 67 km WSW of Puerto Madero, Mexico
      M5.2 · 67 km WSW of Puerto Madero, Mexico · depth 35 km
  - (2026-08-16) M 5.1 - 112 km ESE of Madang, Papua New Guinea
      M5.1 · 112 km ESE of Madang, Papua New Guinea · depth 138.737 km

### IT, InfoSys & cybersecurity news (last 7 days) — 21 new of 58 total
  - (2026-08-17) [BleepingComputer] Microsoft working on Defender patch for ShieldBreak zero-day
      Microsoft is working on a security patch for the "ShieldBreak" zero-day vulnerability disclosed last week by security researcher "Nightmare Eclipse" and now tracked as CVE-2026-69414. [...]
  - (2026-08-17) [Cybersecurity Dive] Why more security data has blurred companies’ view of risk
      More security data can create blind spots. Here’s how to regain visibility.
  - (2026-08-17) [The Register] Code fixers have fired up the AI warp drive. Strange new worlds await
      With more patches per month than at a pirate convention, the bug must be an endangered species. Well, about that
  - (2026-08-17) [The Register] Black Hat and DEF CON are AI conferences now, too
      On this week's episode of The Reg's Kettle podcast, we revisit 'hacker summer camp,' where the hottest topic was ... sigh... agentic AI
  - (2026-08-17) [The Register] Part didn't fit so techie got out his screwdriver. Then something flew off the motherboard
      Whatever it was broke a PC and led to a face-saving lie
  - (2026-08-17) [The Register] Linux 7.2 debuts, Linus Torvalds says ‘new normal’ means he had to do it now ... or never?
      Say hello to smarter use of caches to speed things up, and a very odd gaming controller. Say goodbye to some PCMCIA support

### Paper Trading Scorecard — 17 new of 146 total
  - (2026-08-17) [Polymarket] Will Trump visit North Korea by December 31?
      If Donald J. Trump visits North Korea by December 31, 2026, 11:59 PM ET, this market will resolve to "Yes". Otherwise, this market will resolve to "No". For the purpose of this market, a "visit" is defined as Trump physi…
  - (2026-08-17) [Polymarket] Will Samuel Alito announce his retirement by September 30, 2026?
      This market will resolve to "Yes" if Samuel Alito announces that he will retire from his position as Associate Justice of the Supreme Court of the United States by the specified date at 11:59 PM ET. Otherwise, this marke…
  - (2026-08-17) [Polymarket] Will Trump and Putin not meet?
      This market will resolve according to the location of the next meeting between Donald Trump and Vladimir Putin between market creation and December 31, 2026, 11:59 PM ET. This market will resolve to "No meeting by Decemb…
  - (2026-08-17) [Manifold] Will China have an economic recession induced by overcapacity before EOY 2030?
  - (2026-08-17) [Manifold] The Greens receive at least 5% and enter the Saxony-Anhalt Landtag
  - (2026-08-17) [Manifold] Will North Dakota still exist in 2050?

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-08-17) LoL: T1 vs DN SOOPers (BO5) - KeSPA Cup Playoffs
      yes price: 40% · 24h volume: $1,188,747 · resolves 2026-08-17
  - (2026-08-17) Will Pablo Marçal win the 2026 Brazilian presidential election?
      yes price: 1% · 24h volume: $785,934 · resolves 2026-10-04
  - (2026-08-17) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $655,965 · resolves 2026-06-01
  - (2026-08-17) LoL: T1 vs DN SOOPers - Game 1 Winner
      yes price: 62% · 24h volume: $532,373 · resolves 2026-08-17
  - (2026-08-17) Putin out as President of Russia by December 31, 2026?
      yes price: 8% · 24h volume: $340,809 · resolves 2026-12-31
  - (2026-08-17) LoL: Dplus KIA Challengers vs KT Rolster Challengers - Game 1 Winner
      yes price: 0% · 24h volume: $257,995 · resolves 2026-08-17

### Court opinions of consequence (federal & state) — 14 new of 60 total
  - (2026-08-14) Alaska Supreme Court: Bloom v. Jigliotti Family Trust
  - (2026-08-14) Alaska Supreme Court: DOT Lake Village v. Dená Nená Henash
  - (2026-08-13) U.S. Court of Appeals, 2nd Cir.: Umb
  - (2026-08-13) U.S. Court of Appeals, 2nd Cir.: United States v. Leeper
  - (2026-08-13) U.S. Court of Appeals, 2nd Cir.: United States v. Matos
  - (2026-08-13) U.S. Court of Appeals, 1st Cir.: Guerrero Orellana v. Moniz

### World News (by country, top stories) — 12 new of 12 total
  - (2026-08-17) [Japan] New law spurs surge in lawsuits for unmasking online defamers | The Asahi Shimbun : Breaking News , Japan News and Analysis
      asahi.com · English
  - (2026-08-17) [Japan] Aggelos 2 - Game
      nintendoworldreport.com · English
  - (2026-08-17) [Japan] Shark Simulator : Ocean RPG Survival - Game
      nintendoworldreport.com · English
  - (2026-08-17) [Japan] Small Saga - Game
      nintendoworldreport.com · English
  - (2026-08-17) [Japan] Episode 988 : Monster Rancher Stole My Identity but I Got This Cool Kaiju - Radio Free Nintendo
      nintendoworldreport.com · English
  - (2026-08-17) [Japan] Damways - Game
      nintendoworldreport.com · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 35 total
  - (2026-08-17) MOVER ▼ Bernard Arnault & family — $141.79B ($-0.57B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-17) MOVER ▼ Amancio Ortega — $145.85B ($-0.52B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-17) MOVER ▼ Francoise Bettencourt Meyers & family — $93.37B ($-0.43B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-17) MOVER ▲ Mukesh Ambani — $90.25B (+$0.22B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-17) MOVER ▲ Gautam Adani — $83.34B (+$0.06B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-17) [Marginal Revolution] Somalia facts of the day
      The fruits of better security are plain to see. “Business is booming,” says Gamal Hassan, the commerce minister. New buildings are going up at a frenetic pace. The district around the airport, in particular, has grown mu…
  - (2026-08-17) [Marginal Revolution] What I’ve been reading
      1. Gerald Martin, Mario Vargas Llosa: A Life. A good book if you wish to read about his strange sex life, starting early in his years. But if you are more interested in the history of ideas, Peruvian politics, or the dev…
  - (2026-08-16) [Marginal Revolution] Things you cannot buy in America?
      3. Exterior roller shutters (Rollladen) In much of Europe, homes feature heavy shutters integrated into the exterior of the window, enabling total blackout and better insulation. Sleeping in true, complete darkness—not “…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-17) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: provide, certain, proposing, proposes, action, document, establish, remove, service, proposed, procedures, program
- state_bills: today=137, 7d-median=129, 14d-median=129; carrying terms: projects, county, provisions, based, planning, financial, facilities, governor, review, members, services, establish
- state_news: today=205, 7d-median=585, 14d-median=633; carrying terms: featured, letter, setting, seeks, connecticut, large, spent, louisiana, historic, following, projects, constitution
- local_news: today=169, 7d-median=229, 14d-median=230; carrying terms: historic, gives, following, google, county, charged, metro, school, https, woman, former, found
- foreign_news: today=932, 7d-median=1007, 14d-median=1009; carrying terms: verify, massive, front, bureaucracy, expectations, weapons, jilin, spent, scene, demand, improvements, county
- chinese_internal: today=260, 7d-median=269, 14d-median=267; carrying terms: lxtfa, google, https, cbmizkfvx, cbmia, politics, cbmizefvx, cbmickfvx, cbmixkfvx, chinese, color, caixin
- russian_internal: today=815, 7d-median=1040, 14d-median=1048; carrying terms: reuters, httperror, istories, wildberries, europe, guardian, google, journal, bloomberg, telegram, forbidden, raquo
- ukrainian_internal: today=105, 7d-median=108, 14d-median=108; carrying terms: overnight, weapons, combat, attacks, following, europe, kyivindependent, russia, territory, forbidden, officials, facilities
- ukraine_theater: today=1151, 7d-median=1151, 14d-median=1013; carrying terms: prawi, zxzvqw, vmjlqmw, dbawg, zdmztgzjmffjszfxukladvfvq, ntrhym, cuxoymzrwxbieuddvfz, uxsudorgvdbdlieekzrhczqvzvskw, procured, cuxnbi, acquisition, combat
- paper_bets: today=146, 7d-median=139, 14d-median=138; carrying terms: chair, erupt, election, leaders, office, otherwise, stock, funds, israel, sachs, december, nuclear
- weather: today=166, 7d-median=196, 14d-median=197; carrying terms: montgomery, afdmfl, front, synopsis, monitoring, overnight, chances, combined, tampa, likely, seattle, following
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: personal, payems, effective, treasury, jtsjol, dexjpus, growth, pcepilfe, dexuseu, money, commodities, dexchus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, large, futures, close, treasury, natural, equities, crude, china, bitcoin, yield, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=93, 7d-median=97, 14d-median=99; carrying terms: development, affairs, prohibited, administration, security, mediterranean, stability, aggression, campaign, updates, drilling, destabilisation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, https, quiverquant, quiver, error, congresstrading, quantitative, unauthorized, client
- billionaires: today=35, 7d-median=34, 14d-median=34; carrying terms: finance, fashion, walton, thomas, buffett, ambani, microsoft, source, zuckerberg, steve, brokerage, warren
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, blanche, connecticut, company, trade, state, appeals, group, health, international, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, issuer, filed, financial, richard, partners, robert, capital, david, management, patrick
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cooper, cycle, jonathan, sherrod, platner, trone, ossoff, michael, shawn, angels, pinkston, james
- gdelt_regions: today=12, 7d-median=12, 14d-median=6; carrying terms: english, japan, korea, south, koreaherald
- gdelt_gkg: today=49, 7d-median=37, 14d-median=42; carrying terms: english, themes, israel, trump, hezbollah, spanish, indonesian, online, hormuz, china, vietnamese, turkish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=28; carrying terms: belgium, position, ground, france, kingdom, canada, germany, bulgaria, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: public, isolates, consuming, workers, disembarked, valley, aboard, bobonaro, complete, bloody, spread, geographical
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: cisco, secure, teamcity, using, product, encryption, authentication, langflow, jetbrains, vulnerability, alternate, sensitive
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=251; carrying terms: flood, agricultural, impact, marshall, croatia, belize, kazakhstan, cyclone, albania, australia, orange, forest
- usgs_quakes: today=24, 7d-median=17, 14d-median=14; carrying terms: depth, indonesia, papua, guinea, zealand, south
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: traffic, price, normal, champions, returns, volume, donetsk, interest, resolves, winner, rates, august
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, class, economist, revolution, https, marginal, future, believe, marginalrevolution, conversableeconomist, young, impossible
- tech_news: today=58, 7d-median=58, 14d-median=56; carrying terms: researchers, point, security, attacks, actors, schneier, google, network, safety, daily, target, critical
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: monica, chair, frankel, julie, murkowski, aderholt, zinke, sarah, sewell, menendez, tuberville, jasmine
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, claude, placement, module, sufficient, identify, today, converges, either, paper, decision, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*