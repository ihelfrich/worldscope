# WORLDSCOPE morning brief — 2026-08-17

## Headline
3355 new items across 22 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (955) · International News + Multilateral Institutions (631) · Russian Internal News (state + in-exile) (550) · World leaders & government officials (324) · Chinese Internal News (222) · U.S. Weather + Severe / Climate Outlooks (162) · State Legislative Action (137) · Local News: St. Louis + Atlanta (97) · State-Level News (72) · Ukrainian Internal News (national + local Kyiv) (48) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (22)

## What changed today
### Ukraine Theater (total-war monitoring) — 955 new of 1151 total
  - (2026-08-17) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-15) [Liveuamap] Lebanese Prime Minister: Those killed in the Israeli airstrike in southern Lebanon were not "military infrastructure" - Liveuamap
      Lebanese Prime Minister: Those killed in the Israeli airstrike in southern Lebanon were not "military infrastructure"</
  - (2026-08-17) [Liveuamap] ADNOC announces that one of its vessels was attacked while transiting the Strait of Hormuz; no injuries reported - iran.liveuamap.com
      ADNOC announces that one of its vessels was attacked while transiting the Strait of Hormuz; no injuries reported &n
  - (2026-08-16) [Liveuamap] 2 people killed, 13 wounded as result of Russian missile strikes at the ArcelorMittal metallurgical plant in Kryvyi Rih, crucial equipment damaged Kryvyi Rih, Dnipropetrovsk Oblast - Ukrai…
      2 people killed, 13 wounded as result of Russian missile strikes at the ArcelorMittal metallurgical plant in Kryvyi Rih, crucia
  - (2026-08-16) [Liveuamap] Russian artillery shelled Korenok, Sopych, Bachivsk, Neskuchne, Bezsalivka, Rohizne, Ryzhivka, Hirky, Ulanove, Volfyne of Sumy region, Khrinivka, Mykolayivka of Chernihiv region, - General…
      Russian artillery shelled Korenok, Sopych, Bachivsk, Neskuchne, Bezsalivka, Rohizne, Ryzhivka, Hirky, Ulanove, Volfyne of S
  - (2026-08-16) [Liveuamap] Air defense worked in Chekhov, Moscow Oblast - Liveuamap
      Air defense worked in Chekhov, Moscow Oblast Liveuamap

### International News + Multilateral Institutions — 631 new of 921 total
  - (2026-08-17) [Global] Trump envoy Kushner arrives in Israel after rare Hamas talks on Gaza peace plan
      US President Trump's son-in-law Jared Kushner is expected to meet Israeli Prime Minister Benjamin Netanyahu later on Monday.
  - (2026-08-17) [Global] Ukrainian strikes kill six in Russia, acting governor says
      A 14-year-old child was among four others injured, the acting governor of Russia's Belgorod region says.
  - (2026-08-17) [Global] Trump says US to reduce military drills with South Korea after it stayed out of Iran war
      Trump cites his "very good relationship" with North Korea's leader in deciding to downsize the exercises.
  - (2026-08-17) [Global] Ebola outbreak in DR Congo becomes deadliest in its history
      The outbreak was already the fastest growing on record, caused by a rare species of Ebola called Bundibugyo.
  - (2026-08-17) [Global] Record rains drench South Korean city as landslide kills one
      It comes as large swathes of East and South East Asia have been pummelled by dats of heavy rain.
  - (2026-08-16) [Global] Four 'extraordinary' Renaissance paintings stolen from Italian museum
      The works were taken overnight without alarms being triggered, raising suspicion of a professional hit.

### Russian Internal News (state + in-exile) — 550 new of 745 total
  - (2026-08-17) У здания Верховного суда в Москве начались задержания. Сегодня в суде рассматривают жалобу на снятие «Яблока» с выборов | LEDE: Полиция задержала несколько человек у здания Верховного суда в] (ru: У з…
      Полиция задержала несколько человек у здания Верховного суда в Москве, где 17 августа должны рассмотреть жалобу «Яблока» на решение о снятии федерального списка партии с выборов.
  - (2026-08-17) Bloomberg: экспортеры наладили тайные поставки нефти через Ормузский пролив | LEDE: Экспортеры нефти из стран Ближнего Востока наладили тайные поставки через Ормузский пролив, пишет Bloomber] (ru: Blo…
      Экспортеры нефти из стран Ближнего Востока наладили тайные поставки через Ормузский пролив, пишет Bloomberg. Такие поставки наряду с другими мерами помогают удержать мировые цены на нефть на уровне 80-90 долларов за барр…
  - (2026-08-17) В Москве отменили военный фестиваль «Спасская башня» на Красной площади. За 20 лет его не проводили лишь один раз — в 2020 году из-за ковида | LEDE: Международный военно-музыкальный фестивал] (ru: В М…
      Международный военно-музыкальный фестиваль «Спасская башня» в августе 2026 года проводиться не будет. Об отмене организаторы объявили за четыре дня до начала мероприятия.
  - (2026-08-17) Трамп поручил сократить учения США с Южной Кореей, чтобы не портить свои «очень хорошие» отношения с Ким Чен Ыном | LEDE: Президент США Дональд Трамп заявил, что поручил министру обороны Пит] (ru: Тра…
      Президент США Дональд Трамп заявил, что поручил министру обороны Питу Хегсету «существенно сократить» программу совместных военных учений США с Южной Кореей.
  - (2026-08-17) Актриса Хайден Панеттьери умерла в возрасте 36 лет | LEDE: Умерла американская актриса Хайден Панеттьери, пишет ABC News со ссылкой на заявление ее семьи. Ей было 36 лет. О причинах смерти н] (ru: Акт…
      Умерла американская актриса Хайден Панеттьери, пишет ABC News со ссылкой на заявление ее семьи. Ей было 36 лет. О причинах смерти не сообщается.
  - (2026-08-17) ВСУ нанесли ракетный удар по Белгородской области. Погибли шесть человек | LEDE: Шесть человек погибли в результате ракетного удара ВСУ по селу Колосково Валуйского округа в Белгородской обл] (ru: ВСУ…
      Шесть человек погибли в результате ракетного удара ВСУ по селу Колосково Валуйского округа в Белгородской области. Об этом утром 17 августа сообщил временно исполняющий обязанности губернатора региона Александр Шуваев.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 222 new of 255 total
  - (2026-08-16) 太湖流域发生大洪水 湖州1人死亡、苏州发洪水红警(含视频) - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9XRXpDMWx6eldlbjYwM1l0dnRuTWFUelhoM1V2SDlMWGtsd3pnS180elhuaE1GOTF3cjVEQ013ND] (zh:…
      太湖流域发生大洪水 湖州1人死亡、苏州发洪水红警(含视频) china.caixin.com
  - (2026-08-17) 今日开盘：小幅高开 沪指涨幅0.07% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1QNmNmbEtfeDhRQmxDM1NkY1lKSXJtdFlVLWp0dGYzWU1iUGkyM1puaXdIWmY0X3Rua2QtRUdTNHc2SFo4ZDlrRFhOLUNPNXVfY1] (zh:…
      今日开盘：小幅高开 沪指涨幅0.07% 财新
  - (2026-08-16) 财经早知道｜《求是》杂志发表习近平重要文章：提高防灾减灾救灾能力 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9ON2EwTXQ1YzRjUmd2UGo3NktkSmhTX21SLUVQUjQ0ZEx4WWFuc2dua29lQlhwWk0ySng3OG4weHg2TnB5UGRhO] (zh:…
      财经早知道｜《求是》杂志发表习近平重要文章：提高防灾减灾救灾能力 财新
  - (2026-08-17) 阿里巴巴剥离游戏业务灵犀互娱 信宸资本接手 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE93cEctSmRFem9NS0htcGlhSUFlZUptakFkelRkVlVTcVF2NzhaTE41TzhRSW1zRTh2SlY5R25EVjJQcEtXU1RIV1c5djdDUTds] (zh:…
      阿里巴巴剥离游戏业务灵犀互娱 信宸资本接手 财新
  - (2026-08-16) 反腐记｜程晓波官宣落马 陆文俊、龙翔一审领刑 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBwWk1aWGs2ZmZpSWtOV1BZNnh4NE1Jbnhzd3daNWprSk1aMTdvUjIxdnlsMTI2TnFvSDhWX0h3TUNWZlozZ] (zh:…
      反腐记｜程晓波官宣落马 陆文俊、龙翔一审领刑 china.caixin.com
  - (2026-08-17) 宇树“暗盘”出价三倍 触及账户监管红线 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9QS0ROSFNCV2p4VGpaZVhmQTVGRk5hT0JGSmNialZqZXZ4NU5keE1wa0l3aGxwNjlub1J4NUt4VXFoNGg4T3hCeGpQX1Y3OGpXNG] (zh:…
      宇树“暗盘”出价三倍 触及账户监管红线 财新

### U.S. Weather + Severe / Climate Outlooks — 162 new of 165 total
  - (2026-08-17) [Moderate] Special Weather Statement: Special Weather Statement issued August 17 at 2:42AM CDT by NWS Norman OK
      At 242 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from 8 miles south of Aetna to near Harmon. Movement was east at 25 mph. HAZARD...Wind gusts of 40 mph and pea size hail. SOURCE...Rad…
  - (2026-08-17) [Severe] Flood Warning: Flood Warning issued August 17 at 3:40AM EDT until August 17 at 10:00AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...West Central Tyler County in northern West Virginia... Northeastern Pleasants County in northwestern West Virginia... * WHEN...Until 1000 AM EDT Monday.…
  - (2026-08-17) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 17 at 3:40AM EDT until August 17 at 4:15AM EDT by NWS Louisville KY
      SVRLMK The National Weather Service in Louisville has issued a * Severe Thunderstorm Warning for... Southeastern Crawford County in south central Indiana... Perry County in south central Indiana... Northwestern Meade Cou…
  - (2026-08-17) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-17) [Severe] Flood Warning: Flood Warning issued August 17 at 3:37AM EDT until August 17 at 5:45PM EDT by NWS Wilmington OH
      ...The Flood Warning is extended for the following rivers... South Fork Licking River near Hebron. * WHAT...Minor flooding is occurring and minor flooding is forecast. * WHERE...South Fork Licking River near Hebron. * WH…
  - (2026-08-17) [Severe] Flash Flood Warning: Flash Flood Warning issued August 17 at 1:26AM MDT until August 17 at 3:45AM MDT by NWS Pueblo CO
      At 126 AM MDT, Doppler radar indicated thunderstorms producing heavy rain over the 24 Burn Scar. Between 1 and 3.5 inches of rain have fallen. Additional rainfall amounts of 0.3 to 0.5 inches are possible in the warned a…

### State Legislative Action — 137 new of 137 total
  - (2026-08-16) [California AB 2468] School accountability: pupils with disabilities: inclusion.
      Existing law establishes a single system for providing support to local educational agencies and schools and for specified federal educational programs. Existing law provides that the purpose of the statewide system of s…
  - (2026-08-16) [California AB 1552] Public postsecondary education: civic engagement: recommendations report.
      Existing law establishes the University of California, under the administration of the Regents of the University of California, the California State University, under the administration of the Trustees of the California…
  - (2026-08-16) [California AB 2483] Wildland firefighters: Formerly Incarcerated Firefighter Certification and Employment Program.
      Existing law establishes in the Natural Resources Agency the Department of Forestry and Fire Protection, and requires the department to be responsible for, among other things, fire protection and prevention, as provided.…
  - (2026-08-16) [California AB 2076] The Parent's Accountability and Child Protection Act: online marketplaces: nitrous oxide.
      Existing law requires a person or business that conducts business in California and that seeks to sell specified products or services, to take reasonable steps, as specified, to ensure that the purchaser is of legal age…
  - (2026-08-16) [California AB 1159] Student personal information.
      Existing law, the K–12 Pupil Online Personal Information Protection Act (KOPIPA) , generally protects the personal information of a student enrolled in a K–12 course of instruction, defined as a "pupil," by prescribing r…
  - (2026-08-16) [California AB 1769] Student transfer: tribal colleges.
      The Donahoe Higher Education Act establishes the California Community Colleges under the administration of the Board of Governors of the California Community Colleges, the California State University under the administra…

### Local News: St. Louis + Atlanta — 97 new of 166 total
  - (2026-08-17) [St. Louis] Shooting, fiery crash in downtown St. Louis leave man critically injured; suspect in custody
      A downtown St. Louis shooting left a man critically injured, forced nearby SWAT officers to take cover and ended with a fiery crash.
  - (2026-08-17) [St. Louis] Tropical Storm Lala rakes Hawaii with high winds and rain without making landfall
      More than 130,000 households were without power Sunday morning across Hawaii's three largest islands, and at least one person was killed during the storm.
  - (2026-08-17) [St. Louis] Hayden Panettiere, 'Heroes' and 'Nashville' actress, dies at 36, reports say
      Panettiere had roles in "Scream 4," "Remember the Titans," "Heroes" and other projects across three decades.
  - (2026-08-17) [St. Louis] 8-year-old boy catches unexpected 'exotic fish' in Pennsylvania lake
      A Pennsylvania father and son fishing trip took an unexpected turn when they caught a piranha in a lake.
  - (2026-08-17) [St. Louis] Thieves steal 4 Renaissance artworks in a Sicilian museum heist during an Italian holiday
      An art expert estimated the value of the stolen works to be between $81 million to $92 million.
  - (2026-08-17) [St. Louis] Family of 7 narrowly escapes Washington wildfire, loses new home hours after moving in
      A family of seven didn't even get a night in their new home, when the Old Trails Fire forced them out as they were unloading boxes of their belongings.

### State-Level News — 72 new of 178 total
  - (2026-08-17) [Connecticut] A letter to Luke Bronin
      <img width="1024" height="685" src="https://ctmirror.org/wp-content/uploads/2026/08/CT-PRIMARY-JL-0811-6910-1024x685.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-08-17) [Connecticut] What trans youth need from CT leaders now
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/AP-transgender-care.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcs…
  - (2026-08-17) [Hawaii] NEWS RELEASE – STATE OF HAWAIʻI UPDATE ON HURRICANE LALA
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA DEPARTMENT OF DEFENSE KA ʻOIHANA PILI KAUA HAWAI‘I EMERGENCY MANAGEMENT AGENCY KE‘ENA HO‘OMALU PŌULIA O HAWAI‘I HAWAIʻI JOINT INFORMATION […]
  - (2026-08-16) [Arkansas] DNC approves 2028 presidential nominating cycle starting in South Carolina, Nevada
      The Democratic National Committee on Saturday approved by voice vote its lineup of six early primaries for the 2028 election cycle, kicking off with South Carolina and Nevada. DNC Chair Ken Martin said during Saturday’s…
  - (2026-08-16) [Arkansas] Trump Team’s Use of Arcane Budget Rule Threatens Medicaid Coverage
      About 200,000 low-income Arkansans could see major changes to their health coverage next year after the Trump administration recently informed state officials it will not renew a key Medicaid agreement with the federal g…
  - (2026-08-16) [Arkansas] Farm Bill impasse tests Arkansas Sen. John Boozman’s low-key approach
      Ten years ago, Republican U.S. Sen. John Boozman faced a challenge from a Democratic rival who portrayed the lawmaker as out of touch with Arkansas and too aligned with Donald Trump. His challenger, Conner Eldridge, brou…

### Ukrainian Internal News (national + local Kyiv) — 48 new of 105 total
  - (2026-08-17) Іспанія видала Україні держреєстратора, який переховувався від слідства з 2022 року | LEDE: З Іспанії екстрадували державного реєстратора, підозрюваного у зловживанні повноваженнями, який із 20] (uk:…
      З Іспанії екстрадували державного реєстратора, підозрюваного у зловживанні повноваженнями, який із 2022 року переховувався від слідства.
  - (2026-08-17) У Німеччині в Ельбі знайшли 250-кілограмову авіабомбу часів Другої світової | LEDE: ] (uk: У Німеччині в Ельбі знайшли 250-кілограмову авіабомбу часів Другої світової)
  - (2026-08-17) ЗМІ: прем’єр Британії листувався з людиною, яка видавала себе за керівницю апарату Трампа | LEDE: ] (uk: ЗМІ: прем’єр Британії листувався з людиною, яка видавала себе за керівницю апара)
  - (2026-08-17) Майже мільярд збитків: до незаконного видобутку копалин причетний депутат – прокуратура | LEDE: Правоохоронці Закарпаття припинили незаконний видобуток андезиту, збитки державі — 950 млн грн.] (uk: Ма…
      Правоохоронці Закарпаття припинили незаконний видобуток андезиту, збитки державі — 950 млн грн.
  - (2026-08-17) Завершився термін "похованої" рамкової угоди між США та Іраном | LEDE: ] (uk: Завершився термін "похованої" рамкової угоди між США та Іраном)
  - (2026-08-17) РФ атакувала портову інфраструктуру Одещини: пошкоджено цивільне судно, 4 постраждалих | LEDE: Уночі 17 серпня ворог атакував порт Одещини: пошкоджено цивільне судно, четверо постраждалих, одна] (uk:…
      Уночі 17 серпня ворог атакував порт Одещини: пошкоджено цивільне судно, четверо постраждалих, одна людина у важкому стані.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 22 new of 22 total
  - (2026-08-17) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (48.6204, 2.328) · alt: 678m · 302km/h
  - (2026-08-17) JAF56C (Bulgaria)
      icao24: 4520aa · position: (44.2242, -1.0464) · alt: 10980m · 731km/h
  - (2026-08-17) PUMAA (France)
      icao24: 39ddf7 · position: (43.9068, 4.9357) · alt: 495m · 219km/h
  - (2026-08-17) SAMU45 (France)
      icao24: 39ca85 · position: (47.8353, 1.9197) · on ground · 4km/h
  - (2026-08-17) GAF890 (Germany)
      icao24: 3f97fd · position: (53.3497, 10.0069) · alt: 3124m · 555km/h
  - (2026-08-17) CFC2979 (Canada)
      icao24: c2b5b7 · position: (51.2973, -3.2275) · alt: 7620m · 586km/h

### USGS earthquakes (M4.5+, past day) — 21 new of 22 total
  - (2026-08-17) M 5.7 - 65 km NNW of Ende, Indonesia
      M5.7 · 65 km NNW of Ende, Indonesia · depth 48.947 km
  - (2026-08-17) M 5.3 - 68 km NNW of Ende, Indonesia
      M5.3 · 68 km NNW of Ende, Indonesia · depth 10 km
  - (2026-08-16) M 5.3 - 75 km NNE of Ruteng, Indonesia
      M5.3 · 75 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-17) M 5.2 - 70 km NNW of Ende, Indonesia
      M5.2 · 70 km NNW of Ende, Indonesia · depth 16.335 km
  - (2026-08-16) M 5.2 - 67 km WSW of Puerto Madero, Mexico
      M5.2 · 67 km WSW of Puerto Madero, Mexico · depth 35 km
  - (2026-08-16) M 5.1 - 112 km ESE of Madang, Papua New Guinea
      M5.1 · 112 km ESE of Madang, Papua New Guinea · depth 138.737 km

### Paper Trading Scorecard — 19 new of 151 total
  - (2026-08-17) [Polymarket] Will Trump visit North Korea by December 31?
      If Donald J. Trump visits North Korea by December 31, 2026, 11:59 PM ET, this market will resolve to "Yes". Otherwise, this market will resolve to "No". For the purpose of this market, a "visit" is defined as Trump physi…
  - (2026-08-17) [Polymarket] Will Elon Musk post 260-279 tweets from August 11 to August 18, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from August 11 12:00 PM ET to August 18, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts an…
  - (2026-08-17) [Polymarket] Will Samuel Alito announce his retirement by September 30, 2026?
      This market will resolve to "Yes" if Samuel Alito announces that he will retire from his position as Associate Justice of the Supreme Court of the United States by the specified date at 11:59 PM ET. Otherwise, this marke…
  - (2026-08-17) [Polymarket] Will Sunderland win the 2026-27 English Premier League (EPL) Championship?
      This market will resolve according to the team that wins the 2026-27 English Premier League (EPL) Championship. If at any point it becomes impossible for a listed team to win the 2026-27 English Premier League (EPL) Cham…
  - (2026-08-17) [Polymarket] Will Loopscale launch a token by December 31, 2026?
      This market will resolve to “Yes” if Loopscale (http://x.com/Loopscale) officially launches a governance token by 11:59 PM ET on the date specified in the title. Otherwise, this market will resolve to “No”. The token mus…
  - (2026-08-17) [Manifold] Will China have an economic recession induced by overcapacity before EOY 2030?

### IT, InfoSys & cybersecurity news (last 7 days) — 17 new of 58 total
  - (2026-08-17) [The Register] Black Hat and DEF CON are AI conferences now, too
      On this week's episode of The Reg's Kettle podcast, we revisit 'hacker summer camp,' where the hottest topic was ... sigh... agentic AI
  - (2026-08-17) [The Register] Part didn't fit so techie got out his screwdriver. Then something flew off the motherboard
      Whatever it was broke a PC and led to a face-saving lie
  - (2026-08-17) [The Register] Linux 7.2 debuts, Linus Torvalds says ‘new normal’ means he had to do it now ... or never?
      Say hello to smarter use of caches to speed things up, and a very odd gaming controller. Say goodbye to some PCMCIA support
  - (2026-08-17) [The Register] Microsoft blames AI for delayed Exchange update, can’t say when it will arrive
      Dealing with machine-made bug backlog makes it hard to find a moment to deliver promised subscription service
  - (2026-08-17) [The Register] Chinese AI company Zhipu claims its new model is a better bug-finder than Anthropic, OpenAI
      PLUS: HCL, TCS, admit data breaches; South Korea to fine Apple, Google; India bans some rideshare tips; and more!
  - (2026-08-17) [Computer Weekly] Privacy vs Grok GenAI: A Computer Weekly Downtime Upload podcast
      Earlier this year Grok was asked to produce millions of sexualised images of women and children. Jess Asato, Labour MP for Lowestoft spoke out, after she became a victim of this form of online abuse. “As a member of Parl…

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-08-17) Will Pablo Marçal win the 2026 Brazilian presidential election?
      yes price: 1% · 24h volume: $744,820 · resolves 2026-10-04
  - (2026-08-17) Will Demeke Mekonnen be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $389,482 · resolves 2026-06-01
  - (2026-08-17) LoL: T1 vs DN SOOPers (BO5) - KeSPA Cup Playoffs
      yes price: 48% · 24h volume: $373,029 · resolves 2026-08-17
  - (2026-08-17) Will Club Tijuana win on 2026-08-16?
      yes price: 100% · 24h volume: $299,950 · resolves 2026-08-17
  - (2026-08-17) Will James Fishback be the Republican nominee for Florida Governor?
      yes price: 1% · 24h volume: $258,231 · resolves 2026-08-18
  - (2026-08-17) Will Bitcoin dip to $45,000 by December 31, 2026?
      yes price: 22% · 24h volume: $239,519 · resolves 2027-01-01

### World News (by country, top stories) — 12 new of 12 total
  - (2026-08-17) [Japan] Canada review of Argentina lithium sale tests warming ties with China
      asia.nikkei.com · English
  - (2026-08-17) [Japan] 10 - year JGB yields slip past 2 . 9 % on faster BOJ tightening expectations
      asia.nikkei.com · English
  - (2026-08-17) [Japan] Another Woman Joins Lawsuit Accusing Grok Of Generating CSAM
      engadget.com · English
  - (2026-08-17) [Japan] FF7 Rebirth : How to Steal the Tonberry King Crown
      explosion.com · English
  - (2026-08-17) [Japan] Amazon Drops Lost Ark and Throne & Liberty Publishing Rights
      explosion.com · English
  - (2026-08-17) [Japan] Trump blames vandals for damaged grass in the same spot where he held his big July 4 celebration
      japantoday.com · English

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-08-14) Alaska Supreme Court: DOT Lake Village v. Dená Nená Henash
  - (2026-08-13) U.S. Court of Appeals, 1st Cir.: Guerrero Orellana v. Moniz
  - (2026-08-13) U.S. Court of Appeals, 1st Cir.: LUMA Energy LLC v. Puerto Rico Dep't of Consumer Affairs
  - (2026-08-13) U.S. Court of International Trade: Axle of Dearborn, Inc. v. Dep't of Com.
  - (2026-08-13) U.S. Court of International Trade: Salvi Chem. Indus. Ltd. v. United States
  - (2026-08-13) U.S. Court of Appeals, 2nd Cir.: Umb

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 36 total
  - (2026-08-17) MOVER ▲ Masayoshi Son — $70.45B (+$1.63B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-08-17) MOVER ▼ Gautam Adani — $83.29B ($-0.65B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-08-17) MOVER ▼ Francoise Bettencourt Meyers & family — $93.80B ($-0.57B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-17) MOVER ▼ Amancio Ortega — $146.36B ($-0.47B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-17) MOVER ▲ Mukesh Ambani — $90.02B (+$0.24B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-17) MOVER ▼ Bernard Arnault & family — $142.37B ($-0.22B since yesterday)
      France · Fashion & Retail · source: LVMH

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-17) [Marginal Revolution] Somalia facts of the day
      The fruits of better security are plain to see. “Business is booming,” says Gamal Hassan, the commerce minister. New buildings are going up at a frenetic pace. The district around the airport, in particular, has grown mu…
  - (2026-08-17) [Marginal Revolution] What I’ve been reading
      1. Gerald Martin, Mario Vargas Llosa: A Life. A good book if you wish to read about his strange sex life, starting early in his years. But if you are more interested in the history of ideas, Peruvian politics, or the dev…
  - (2026-08-16) [Marginal Revolution] Things you cannot buy in America?
      3. Exterior roller shutters (Rollladen) In much of Europe, homes feature heavy shutters integrated into the exterior of the window, enabling total blackout and better insulation. Sleeping in true, complete darkness—not “…

### Government Action: Sanctions + Procurement + Foreign Agents — 2 new of 93 total
  - (2026-08-12) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Rice Lake Weighing Systems, Inc. - ofac.treasury.gov
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Rice Lake Weighing Systems, Inc. ofac.treasury.gov
  - (2026-08-12) [OFAC] DEPARTMENT OF THE TREASURY - ofac.treasury.gov
      DEPARTMENT OF THE TREASURY ofac.treasury.gov

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-17) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: program, certain, coast, proposes, provide, service, procedures, proposing, final, special, necessary, proposed
- state_bills: today=137, 7d-median=129, 14d-median=129; carrying terms: violation, required, community, local, assessment, entities, support, planning, insurance, social, grants, projects
- state_news: today=178, 7d-median=585, 14d-median=681; carrying terms: uploads, asked, released, filed, leaves, required, community, local, efforts, change, redirects, calls
- local_news: today=166, 7d-median=229, 14d-median=230; carrying terms: local, killed, incident, injured, accused, arrested, following, falcons, announced, atlanta, school, charges
- foreign_news: today=921, 7d-median=1007, 14d-median=1011; carrying terms: default, files, goods, scaling, backs, received, website, economy, turned, looks, times, infrastructure
- chinese_internal: today=255, 7d-median=269, 14d-median=269; carrying terms: politics, cbmix, cbmizkfvx, cbmiaefvx, color, google, cbmibefvx, cbmib, cbmidefvx, cbmiyefvx, cbmickfvx, cbmibkfvx
- russian_internal: today=745, 7d-median=1040, 14d-median=1056; carrying terms: error, russian, google, gazeta, times, istories, journal, telegram, client, https, laquo, forbidden
- ukrainian_internal: today=105, 7d-median=108, 14d-median=107; carrying terms: strike, times, infrastructure, civilian, killed, efforts, foreign, strikes, injured, officials, authorities, attacks
- ukraine_theater: today=1151, 7d-median=1151, 14d-median=1001; carrying terms: ntrhym, equipment, prmxr, quarter, received, ltuzfnmdrrvtlvvelfzmr, oskxnounky, zixzrmodrpev, cuxqehhlsklvzgh, qwhxu, wlotalcytmlrmxq, xkvzrrrtdoq
- paper_bets: today=151, 7d-median=139, 14d-median=138; carrying terms: earthquake, zohran, pennsylvania, secretary, midterm, kylian, chase, sachs, predictit, successor, james, anthropic
- weather: today=165, 7d-median=196, 14d-median=196; carrying terms: francisco, gusts, boston, winds, afdlwx, monitoring, chance, thursday, includes, please, angeles, county
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, crude, dexuseu, latest, rates, implied, treasury, payems, assets, unemployment, commodities, payrolls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, rates, equities, treasury, crypto, silver, proxy, credit, agriculture, commodities, yield, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=93, 7d-median=97, 14d-median=99; carrying terms: weapons, services, lebanon, destabilising, order, russian, actions, abuses, proliferation, technology, haitian, security
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, https, client, httperror, quiverquant, congresstrading, quantitative, quiver, unauthorized
- billionaires: today=36, 7d-median=34, 14d-median=34; carrying terms: telecom, holdings, canada, giancarlo, finance, michael, india, semiconductors, gcarsoa, spacex, technologies, facebook
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, appeals, company, group, blanche, connecticut, supreme, state, trade, international, alabama, health
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, reporting, accno, robert, financial, richard, partners, capital, david, patrick, management
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, sherrod, filing, raised, warner, michael, trone, jonathan, alexandria, graham, brown, cycle
- gdelt_regions: today=12, 7d-median=12, 14d-median=6; carrying terms: english, korea, japan, south, koreaherald, korean, china
- gdelt_gkg: today=0, 7d-median=25, 14d-median=42; carrying terms: english, russian, themes, spanish, chinese, hezbollah, trump, israel, indonesian, russia, arabic, strait
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=29, 14d-median=26; carrying terms: belgium, position, ground, france, kingdom, canada, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: different, sometimes, monkeypox, informed, ventilation, provinces, formula, organization, discharged, three, press, imported
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: remediation, tomcat, injection, product, alternate, sensitive, vendor, apache, cisco, deserialization, command, using
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=258; carrying terms: earthquake, liechtenstein, macedonia, forestfire, canada, speed, uganda, monaco, russia, democratic, belize, thailand
- usgs_quakes: today=22, 7d-median=17, 14d-median=14; carrying terms: depth, indonesia, guinea, south, papua
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: champions, volume, donetsk, rates, price, september, meeting, interest, championship, resolves, league, traffic
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, marginal, class, https, revolution, economist, marginalrevolution, conversableeconomist, future, believe, young, impossible
- tech_news: today=58, 7d-median=58, 14d-median=56; carrying terms: schneier, infrastructure, weekly, techcrunch, government, computerweekly, stealing, attacks, hackers, software, complex, today
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: radewagen, sherman, francisco, wasserman, gallego, calvert, malliotakis, linda, rashida, acting, begich, mills
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, module, today, claude, placement, identify, placed, unavailable, paper, evidence, either, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*