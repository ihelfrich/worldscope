# WORLDSCOPE morning brief — 2026-08-11

## Headline
3887 new items across 27 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (760) · International News + Multilateral Institutions (753) · Ukraine Theater (total-war monitoring) (651) · State-Level News (355) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (227) · Chinese Internal News (214) · U.S. Weather + Severe / Climate Outlooks (161) · State Legislative Action (77) · Ukrainian Internal News (national + local Kyiv) (65) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (38)

## What changed today
### Russian Internal News (state + in-exile) — 760 new of 1009 total
  - (2026-08-11) Власти Сирии заочно приговорили Башара Асада к смертной казни | LEDE: Суд в Дамаске заочно приговорил бывшего президента Сирии Башара Асада к смертной казни по обвинению в военных преступлен] (ru: Вла…
      Суд в Дамаске заочно приговорил бывшего президента Сирии Башара Асада к смертной казни по обвинению в военных преступлениях и преступлениях против человечности в ходе гражданской войны в стране. Об этом сообщают сирийско…
  - (2026-08-11) «Вы убивали людей? — Да». Депутат Виталий Милонов рассказал о своем участии в войне | LEDE: Депутат Госдумы от «Единой России» Виталий Милонов заявил, что убивал людей на российско-украинско] (ru: «Вы…
      Депутат Госдумы от «Единой России» Виталий Милонов заявил, что убивал людей на российско-украинской войне. Об этом он рассказал в интервью блогеру Амирану Сардарову.
  - (2026-08-11) МАГАТЭ вывезет ядерные материалы с засекреченного объекта в Сирии. Соглашение с местным правительством заключили при посредничестве США | LEDE: Международное агентство по атомной энергии (МА] (ru: МАГ…
      Международное агентство по атомной энергии (МАГАТЭ) сможет вывезти ядерные материалы с засекреченного объекта в Сирии. Переговоры по этому вопросу с участием Сирии, Израиля и представителей администрации Трампа продолжал…
  - (2026-08-11) «Коммерсант»: поставки китайских автозапчастей в Россию выросли на 15% за семь месяцев | LEDE: За семь месяцев с января по июль ввоз автомобильных запчастей и комплектующих из Китая в Россию] (ru: «Ко…
      За семь месяцев с января по июль ввоз автомобильных запчастей и комплектующих из Китая в Россию вырос примерно на 15% (до 1,3 миллиарда долларов), пишет «Коммерсант» со ссылкой на данные атводилера «Рольф».
  - (2026-08-11) Из-за угрозы покушения Трамп улетал с саммита НАТО в Турции тайно — он демонстративно сел в президентский самолет, но затем его перевели на военный «боинг» | LEDE: После окончания саммита НА] (ru: Из-…
      После окончания саммита НАТО, проходившего в июле в Анкаре, Дональд Трамп улетел обратно в США тайно — военным самолетом вместо традиционного президентского борта, выяснила газета The Washington Post.
  - (2026-08-11) «Я так в последний раз нервничал, когда с девушкой расставался». Сотни молодых россиян вышли на улицу, чтобы поддержать партию «Яблоко», выступившую против войны. Репортаж из центра Москвы | LE] (ru:…
      Весь день 10 августа Верховный суд рассматривал иск об отмене регистрации партии «Яблоко» на выборах в Госдуму. И все это время у здания на Поварской находились сотни сторонников единственной антивоенной партии, которая…

### International News + Multilateral Institutions — 753 new of 980 total
  - (2026-08-11) [India] Nasa invites Isro to join Moon Base program under Artemis Accords
  - (2026-08-11) [India] At least 31 school kids in Kolkata’s govt school fall ill, hospitalised: Officials
  - (2026-08-11) [India] Kanwariyas form human chain to let Muslim man's funeral procession cross highway
  - (2026-08-11) [India] Chaos in Ranchi: ABVP workers climb on police bus, protesters detained
  - (2026-08-11) [India] Cal HC extends interim protection from arrest to Abhishek Banerjee till August 31
  - (2026-08-11) [India] SC seeks Centre’s response on CBI probe into fake lawyers, CJP activities

### Ukraine Theater (total-war monitoring) — 651 new of 1001 total
  - (2026-08-11) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-10) [FIRMS] thermal anomaly 44.858, 33.828 (FRP 3.99 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 3.99 MW
  - (2026-08-10) [FIRMS] thermal anomaly 44.905, 33.811 (FRP 3.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 3.41 MW
  - (2026-08-10) [FIRMS] thermal anomaly 44.903, 33.807 (FRP 3.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 3.41 MW
  - (2026-08-10) [FIRMS] thermal anomaly 44.902, 33.802 (FRP 1.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 1.76 MW
  - (2026-08-10) [FIRMS] thermal anomaly 45.256, 31.672 (FRP 5.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 5.53 MW

### State-Level News — 355 new of 450 total
  - (2026-08-10) [California] First Partner Jennifer Siebel Newsom, Senate President pro Tem Monique Limón celebrate women founders leading innovation in California
      Source
  - (2026-08-10) [California] Governor Newsom condemns Trump administration proposal to weaken federal gun safety
      Source
  - (2026-08-10) [California] Golden State in the spotlight: Governor Newsom announces nine new TV projects – including iconic reboots, sequels, and star-studded dramas – to launch second year of California’s expanded…
      Source
  - (2026-08-10) [California] Governor Newsom announces new AI cyber defense program to protect California’s critical infrastructure
  - (2026-08-10) [Alabama] Governor Kay Ivey Encourages 1st, 2nd, 6th and 7th Congressional District Alabamians to Vote
      Governor Ivey encouraged Alabamians in the state’s 1st, 2nd, 6th and 7th congressional districts to vote in the upcoming Tuesday, August 11, 2026 Special Congressional Primary Election. (Governor’s Office, Gina Maiola &…
  - (2026-08-10) [Alabama] Governor Ivey Encourages 1st, 2nd, 6th and 7th Congressional District Alabamians to Head to the Polls for Special Primary Election
      MONTGOMERY – Governor Kay Ivey on Monday encouraged Alabamians in the state’s 1st, 2nd, 6th and 7th congressional districts to vote in the upcoming Tuesday, August 11, 2026, Special Congressional Primary Election. “The s…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 227 new of 230 total
  - (2026-08-11) [St. Louis] Where Art Thou? – 8/11/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-11) [St. Louis] Want to make cheese-wheel pasta? There’s just one problem
      Ask Cheryl: Is there anyone in St. Louis that has small 10-inch cheese wheels, so I can make pasta alla ruota? —J.S., St. Louis One of the biggest food trends of the past year or so has been pasta alla ruota, or pasta fi…
  - (2026-08-10) [St. Louis] Sabor Cubano opens in Boulevard Heights
      The name says it all at Sabor Cubano (6836 Gravois), which translates to “Cuban flavor.” A trip to Dayanna Herrera’s new restaurant in Boulevard Heights is like a visit to the island, with the food, warm service, music,…
  - (2026-08-10) [St. Louis] St. Louis volunteers rally around immigrant families in crisis
      Earlier this year, three St. Louis-area mothers found themselves preparing for childbirth while also navigating the detention of their husbands by immigration authorities. For volunteers with nonprofit Abide in Love St.…
  - (2026-08-10) [St. Louis] Top family-friendly events this week in St. Louis
      Romeo & Zooliet Puppet Meet & Greet | August 11Meet one or two larger-than-life puppets from St. Louis Shakespeare Festival’s Romeo & Zooliet before a free outdoor performance of The Two Gentlemen of Verona. 6 p.m. Cityg…
  - (2026-08-10) [St. Louis] Renovating your kitchen? Top designers share words of wisdom
      A kitchen renovation is one of the most exciting—and sometimes most challenging—projects a homeowner can take on. From balancing budgets and timelines to making countless design decisions, there’s a lot that goes into cr…

### Chinese Internal News — 214 new of 243 total
  - (2026-08-10) China Takes World’s Fastest Train One Step Closer to Market - Caixin Global
      China Takes World’s Fastest Train One Step Closer to Market Caixin Global
  - (2026-08-09) 多家上市公司宣布：收到美国关税退税 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBkdjZzY1JTQ1AwYkc1bUc2b3FHLWU2eU1IYzllODBVZ0FFdVd5Y21vQmZpNlVWckN4X25QWDhBUHhzT3VVUGFlcUg] (zh:…
      多家上市公司宣布：收到美国关税退税 mini.caixin.com
  - (2026-08-09) 7月CPI、PPI同比均低于预期 PPI同比结束持续改善、高位回落 - economy.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1WakZrY3JfSXA0WWdwRllVUWNDR2gyRWZFRWx0V1FNWUpjYm84VnZVVHBtYU5Sanp0UXIt] (zh:…
      7月CPI、PPI同比均低于预期 PPI同比结束持续改善、高位回落 economy.caixin.com
  - (2026-08-09) Arm - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE5YQlBQdWFheGN2cUMydGY4eXVNX3NsN0tnV3hHYkRZS1pqU0hCT0pVTmdub3dWLVJNXzRNczMtMlJGRE52YWVMZFJha3BkMGlGc] (zh:…
      Arm deepview.caixin.com
  - (2026-08-09) 光伏危与机 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE05ZEZhY21SUU1RVHNreVBhMW1sSTB1UHVyV2QtRzNxaW5qWk5PenpiVy1IYVZFUDlCUG1kSWhTekJWUHNMNUoxOUd4MkYwZ0t] (zh:…
      光伏危与机 deepview.caixin.com
  - (2026-08-09) 德国 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE9obFJsME0wYWVrNzNDSHlsLXRLeFZlcnNKY0xoMFdsOEhqQ2xEYnVpWHI0dmdUMXFuVHBLVkVJYnpzT29XWEphZXItM0Y5QlJUdk] (zh:…
      德国 deepview.caixin.com

### U.S. Weather + Severe / Climate Outlooks — 161 new of 168 total
  - (2026-08-11) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-11) [Moderate] Special Weather Statement: Special Weather Statement issued August 11 at 5:27AM EDT by NWS Northern Indiana
      At 527 AM EDT, Doppler radar was tracking a strong thunderstorm 7 miles southwest of Rochester, moving east at 35 mph. HAZARD...Wind gusts up to 50 mph and penny size hail. SOURCE...Radar indicated. IMPACT...Gusty winds…
  - (2026-08-11) [Severe] Flood Warning: Flood Warning issued August 11 at 5:25AM EDT until August 11 at 5:30AM EDT by NWS Wilmington OH
      The Flood Warning will expire at 530 AM EDT early this morning for portions of central and west central Ohio, including the following areas, in central Ohio, Union. In west central Ohio, Hardin and Logan. The heavy rain…
  - (2026-08-11) [Moderate] Special Weather Statement: Special Weather Statement issued August 11 at 5:23AM EDT by NWS Detroit/Pontiac MI
      At 523 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Hudson to Morenci to 7 miles north of Wauseon. Movement was east at 30 mph. HAZARD...Winds in excess of 40 mph and penny siz…
  - (2026-08-11) [Moderate] Special Weather Statement: Special Weather Statement issued August 11 at 2:20AM MST by NWS Phoenix AZ
      At 220 AM MST, Doppler radar was tracking a strong thunderstorm 16 miles southwest of Morristown, or 16 miles north of Tonopah, moving north at 20 mph. HAZARD...Wind gusts up to 50 mph and pea size hail. SOURCE...Radar i…
  - (2026-08-11) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 11 at 2:19AM MST until August 11 at 2:45AM MST by NWS Phoenix AZ
      At 219 AM MST, a severe thunderstorm was located 8 miles northwest of Buckeye, moving northwest at 15 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, siding, and trees. Locatio…

### State Legislative Action — 77 new of 87 total
  - (2026-08-11) [Alaska HB 282] An Act relating to municipal regulation of automated traffic safety cameras.
      An Act relating to municipal regulation of automated traffic safety cameras.
  - (2026-08-11) [Alaska HB 329] An Act relating to certificates of fitness for employees of an electric utility.
      An Act relating to certificates of fitness for employees of an electric utility.
  - (2026-08-11) [Alaska HB 93] An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.
      An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.
  - (2026-08-11) [Alaska HB 155] An Act relating to alcohol; relating to local option elections; relating to the statewide database of alcohol purchases; relating to alcohol licenses, endorsements, and permits; relati…
      An Act relating to alcohol; relating to local option elections; relating to the statewide database of alcohol purchases; relating to alcohol licenses, endorsements, and permits; relating to municipal regulation and taxat…
  - (2026-08-11) [Alaska SB 208] An Act relating to industrial hemp; relating to the sale and lease of state land for agricultural uses; designating the O-S Cross cabbage, commonly known as 'giant green cabbage,' as t…
      An Act relating to industrial hemp; relating to the sale and lease of state land for agricultural uses; designating the O-S Cross cabbage, commonly known as 'giant green cabbage,' as the official state vegetable; and pro…
  - (2026-08-11) [Alaska HB 9050] An Act relating to a test.
      An Act relating to a test.

### Ukrainian Internal News (national + local Kyiv) — 65 new of 106 total
  - (2026-08-11) Суд у Сирії заочно засудив Асада до смертної кари | LEDE: Колишнього президента Сирії Башара Асада, який утік до Москви, суд засудив до смертної кари.] (uk: Суд у Сирії заочно засудив Асада до смертно…
      Колишнього президента Сирії Башара Асада, який утік до Москви, суд засудив до смертної кари.
  - (2026-08-11) На Прикарпатті посилять контроль за дотриманням комендантської години | LEDE: На Прикарпатті діє комендантська година з 00:00 до 05:00. Контроль за дотриманням правил буде посилено.] (uk: На Прикарпат…
      На Прикарпатті діє комендантська година з 00:00 до 05:00. Контроль за дотриманням правил буде посилено.
  - (2026-08-11) Єдина АЕС Румунії знову під загрозою повної зупинки через обміління Дунаю | LEDE: ] (uk: Єдина АЕС Румунії знову під загрозою повної зупинки через обміління Дунаю)
  - (2026-08-11) Лана Зеркаль: Кремль готує восени не лише балістичні удари, а й моральну паніку | LEDE: ] (uk: Лана Зеркаль: Кремль готує восени не лише балістичні удари, а й моральну паніку)
  - (2026-08-11) УП: Новий очільник ГУР намагається витіснити вплив Буданова і знімає з посад його людей | LEDE: Іващенко усуває соратників Буданова в ГУР, співпрацює з Покладом та проводить кадрові зміни.] (uk: УП: Н…
      Іващенко усуває соратників Буданова в ГУР, співпрацює з Покладом та проводить кадрові зміни.
  - (2026-08-11) Навіщо Путіну перемир'я, в яке він сам не вірить | LEDE: Кремль шантажує Європу та Україну, розігруючи карту паніки і ресурсної кризи на фоні ізоляції США.] (uk: Навіщо Путіну перемир'я, в яке він сам…
      Кремль шантажує Європу та Україну, розігруючи карту паніки і ресурсної кризи на фоні ізоляції США.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-11) [Kotarba Scott] Form 4 (Reporting)
      filed 2026-08-11 01:49 UTC · role: Reporting — Filed: 2026-08-10 AccNo: 0001217160-26-000067 Size: 15 KB
  - (2026-08-11) [JEWETT CAMERON TRADING CO LTD] Form 4 (Issuer)
      filed 2026-08-11 01:49 UTC · role: Issuer — Filed: 2026-08-10 AccNo: 0001217160-26-000067 Size: 15 KB
  - (2026-08-11) [Red Rock Resorts, Inc.] Form 4 (Issuer)
      filed 2026-08-11 01:41 UTC · role: Issuer — Filed: 2026-08-10 AccNo: 0001193125-26-343081 Size: 13 KB
  - (2026-08-11) [KREEGER SCOTT] Form 4 (Reporting)
      filed 2026-08-11 01:41 UTC · role: Reporting — Filed: 2026-08-10 AccNo: 0001193125-26-343081 Size: 13 KB
  - (2026-08-11) [Aptevo Therapeutics Inc.] Form 4 (Issuer)
      filed 2026-08-11 01:39 UTC · role: Issuer — Filed: 2026-08-10 AccNo: 0001193125-26-343080 Size: 6 KB
  - (2026-08-11) [Harsanyi Zsolt] Form 4 (Reporting)
      filed 2026-08-11 01:39 UTC · role: Reporting — Filed: 2026-08-10 AccNo: 0001193125-26-343080 Size: 6 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 38 new of 55 total
  - (2026-08-11) [The Hacker News] Hackers Breach Polish Power Plant Controls via Private Cellular Network and Shut Turbine
      Attackers shut down a steam turbine and the process-water treatment system at a Polish combined heat and power plant by coming in over the private cellular network the local grid operator uses to reach remote equipment.…
  - (2026-08-11) [The Hacker News] BdThemes Supply Chain Attack Poisons JSON to Create Rogue WordPress Admins
      Cybersecurity researchers have warned of a supply chain compromise impacting WordPress plugin vendor BdThemes, prompting the content management systems (CMS) platform's plugins team to temporarily disable their downloads…
  - (2026-08-11) [The Register] Why hybrid clouds break and what to do about it
      SPONSORED EXPLAINER: There's nothing wrong with hybrid cloud. It's the one-size-fits-all strategy on top of it that's the problem.
  - (2026-08-11) [The Register] OVH Cloud warns of 87% price hikes to help it cover RAMpocalypse costs
      Gaming servers get the steepest rises but sticker shock is also coming to conventional instances running on old and new boxes
  - (2026-08-11) [The Register] Japan kind-of completes its sovereign satnav constellation
      H3 rocket gets the job done after losing a bird last year
  - (2026-08-11) [The Register] Alibaba Cloud is using AI to help it use less AI
      Solves tech support tickets faster and more accurately by keeping them away from LLMs

### U.S. Federal Action — 31 new of 31 total
  - (2026-08-11) Ending Birth Tourism
  - (2026-08-11) Continuing To Protect the Meaning and Value of American Citizenship
  - (2026-08-11) National Purple Heart Day, 2026
  - (2026-08-11) Adjusting Imports of Polysilicon and Its Derivatives Into the United States
  - (2026-08-11) Schedules of Controlled Substances: Rescheduling of Suvorexant, Lemborexant, and Daridorexant From Schedule IV Into Schedule V
      The Drug Enforcement Administration proposes to transfer suvorexant ([(7R)-4-(5-chloro-1,3-benzoxazol-2-yl)-7-methyl-1,4- diazepan-1-yl]-[5-methyl-2-(triazol-2-yl)phenyl]methanone), lemborexant ((1R,2S)-2-[(2,4-dimethylp…
  - (2026-08-11) NRC Modernization: Rulemaking Procedure, Federal Advisory Committee Act Alignment, Access, and Security
      The U.S. Nuclear Regulatory Commission (NRC) is amending its regulations by streamlining procedural provisions related to information withholding and post-promulgation comment periods; aligning the NRC's regulations with…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 27 new of 60 total
  - (2026-08-10) U.S. Court of International Trade: ICON EV LLC v. United States
  - (2026-08-10) U.S. Court of Appeals, 9th Cir.: State of Colorado v. Meta Platforms, Inc.
  - (2026-08-10) Delaware Supreme Court: Jean-Baptiste v. State
  - (2026-08-10) Supreme Court of California: Family Violence Appellate Project v. Super. Ct.
  - (2026-08-10) Supreme Court of California: Tesoro Refining & Marketing Co. LLC v. City of Carson
  - (2026-08-10) U.S. Court of Appeals, 3rd Cir.: United States v. Derby Clerfe

### Government & military aircraft airborne (OpenSky) — 26 new of 30 total
  - (2026-08-11) JAF94H (Bulgaria)
      icao24: 4520aa · position: (48.713, 1.8546) · alt: 5311m · 738km/h
  - (2026-08-11) GAF102 (Germany)
      icao24: 3ea556 · position: (52.4602, 9.4462) · on ground · 22km/h
  - (2026-08-11) PUMA22 (Slovenia)
      icao24: 506e18 · position: (45.9102, 15.4811) · alt: 365m · 157km/h
  - (2026-08-11) PUMA23 (Slovenia)
      icao24: 506e1f · position: (46.0882, 15.0631) · alt: 1493m · 185km/h
  - (2026-08-11) GAF404 (Germany)
      icao24: 3f46db · position: (52.4524, 9.388) · alt: 251m · 332km/h
  - (2026-08-11) JAF9WL (Belgium)
      icao24: 44d1ba · position: (51.0836, 2.6596) · alt: 807m · 452km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Трампа таємно доправили на навантажувачі до літака після саміту НАТО в Туреччині через потенційні загрози з боку Ірану – ЗМІ
      interfax.com.ua · Ukrainian · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] 11 أغسطس 2026 .. أسعار الذهب تقفز 125 جنيها وعيار 21 يسجل 6250 جنيها
      shorouknews.com · Arabic · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Ukraine greift 2 . 500 Kilometer hinter der Front an : Raffinerie beschädigt
      schwaebische-post.de · German · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Libya oil refinery fire : Firefighters battle huge blaze after drone attack
      bbc.co.uk · English · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Πετρελαιοκηλίδα 400 τετρ . χιλιομέτρων απειλεί θαλάσσιο καταφύγιο
      kerkida.net · Greek · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Devizapiac Augusztus 10 . – Az euró és a dollár kiütötte a forintot
      tozsdeforum.hu · Hungarian · tone NA

### Paper Trading Scorecard — 21 new of 129 total
  - (2026-08-11) [Polymarket] Iran charges Hormuz fees by December 31?
      This market resolves to “Yes” if the Iranian government officially announces and begins collecting fees, tolls, charges, tariffs, or similar payments from commercial vessels which are mandatory for passage through or acc…
  - (2026-08-11) [Polymarket] Will David Crowley win the 2026 Wisconsin Governor Democratic primary election?
      This market will resolve according to the winner of the Democratic Primary for Governor of Wisconsin, scheduled to take place on August 11, 2026. Resolution will be based on the overall winner of the primary, including a…
  - (2026-08-11) [Polymarket] Will the Bank of Japan announce no change at the September 2026 meeting?
      This market will resolve according to the change in basis points in the uncollateralized overnight call rate resulting from the September 2026 meeting of the Bank of Japan, relative to the level it was prior to this meet…
  - (2026-08-11) [Polymarket] Will an international court find Israel or its leaders guilty of Genocide by December 31, 2027?
      This market will resolve to "Yes" if he International Criminal Court ("ICC"), the International Court of Justice ("ICJ"), or any ad hoc international tribunal with recognized legal standing, issues a judgment or convicti…
  - (2026-08-11) [Manifold] Will I solve an unsolved math problem with AI in August?
  - (2026-08-11) [Manifold] Will I regret investing $500 into my startup?

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-08-10) M 7.4 - 5 km S of San José del Palmar, Colombia
      M7.4 · 5 km S of San José del Palmar, Colombia · depth 110.285 km · PAGER orange
  - (2026-08-10) M 5.1 - 232 km SSW of Pagar Alam, Indonesia
      M5.1 · 232 km SSW of Pagar Alam, Indonesia · depth 21.72 km
  - (2026-08-10) M 5.0 - 16 km W of San José del Palmar, Colombia
      M5.0 · 16 km W of San José del Palmar, Colombia · depth 98.522 km
  - (2026-08-10) M 5.0 - northern Mid-Atlantic Ridge
      M5.0 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-08-10) M 4.8 - 173 km ENE of Sola, Vanuatu
      M4.8 · 173 km ENE of Sola, Vanuatu · depth 655.67 km
  - (2026-08-11) M 4.7 - 81 km SSE of Bengkulu, Indonesia
      M4.7 · 81 km SSE of Bengkulu, Indonesia · depth 61.94 km

### World News (by country, top stories) — 12 new of 12 total
  - (2026-08-11) [Japan] Fire Emblem : Three Houses - Nintendo Switch Forum
      nintendolife.com · English
  - (2026-08-11) [Japan] Rumour : Hazelight Award - Winning Co - Op Game Might Be Coming To Switch 2
      nintendolife.com · English
  - (2026-08-11) [Japan] Neptunia Unlimited Opening Movie Is Out Now
      gamerheadlines.com · English
  - (2026-08-11) [Japan] How To Play PS1 And PS2 Games Legally In 2026
      gamerheadlines.com · English
  - (2026-08-11) [Japan] PV Sindhu hails
      japanherald.com · English
  - (2026-08-11) [Japan] Middle East conflict fears weigh on wall street as energy prices surge
      japanherald.com · English

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-11) National Bank Open: Rafael Jodar vs Arthur Fils
      yes price: 56% · 24h volume: $1,212,642 · resolves 2026-08-18
  - (2026-08-11) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 40% · 24h volume: $1,146,232 · resolves 2026-09-16
  - (2026-08-11) LoL: Hanwha Life Esports vs DN SOOPers (BO5) - KeSPA Cup Playoffs
      yes price: 16% · 24h volume: $863,581 · resolves 2026-08-11
  - (2026-08-11) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 18% · 24h volume: $844,100 · resolves 2027-01-01
  - (2026-08-11) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 1% · 24h volume: $655,777 · resolves 2026-09-16
  - (2026-08-11) Will Yabloko gain the most seats in the next Russian parliamentary election?
      yes price: 0% · 24h volume: $386,442 · resolves 2026-09-30

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 99 total
  - (2026-08-07) [OFAC] Counter Terrorism and Iran-related Designations; Counter Narcotics Designations Removals; Issuance of Amended Iran-related Frequently Asked Question - ofac.treasury.gov
      Counter Terrorism and Iran-related Designations; Counter Narcotics Designations Removals; Issuance of Amended Iran-related Frequently Asked Question ofac.treasury.gov
  - (2026-08-06) [OFAC] Cuba-related Designations; Issuance of Cuba-related Frequently Asked Question - ofac.treasury.gov
      Cuba-related Designations; Issuance of Cuba-related Frequently Asked Question ofac.treasury.gov
  - (2026-08-06) [OFAC] Frequently Asked Questions - Newly Added - ofac.treasury.gov
      Frequently Asked Questions - Newly Added ofac.treasury.gov
  - (2026-08-05) [OFAC] Counter Terrorism Designations Removals and Update - ofac.treasury.gov
      Counter Terrorism Designations Removals and Update ofac.treasury.gov
  - (2026-08-07) [OFAC] 1257 - ofac.treasury.gov
      1257 ofac.treasury.gov
  - (2026-08-11) [USASpending] $634,704,286 → AMENTUM SPACEPORT LLC: BASE OPERATIONS AND SPACEPORT SERVICES (BOSS) CONTRACT
      Agency: National Aeronautics and Space Administration. Description: BASE OPERATIONS AND SPACEPORT SERVICES (BOSS) CONTRACT

### GDACS — global disaster alerts — 6 new of 285 total
  - (2026-08-10) [Orange] Earthquake in Colombia
      Earthquake · Orange alert · Colombia · Magnitude 7.4M, Depth:110.285km
  - (2026-08-10) [Orange] Earthquake in Colombia
      Earthquake · Orange alert · Colombia · Magnitude 7.4M, Depth:110.285km
  - (2026-08-03) [Green] Forest fires in Angola
      Wildfire · Green alert · Angola · Green impact for forestfire in 12944 ha
  - (2026-08-03) [Green] Forest fires in Angola
      Wildfire · Green alert · Angola · Green impact for forestfire in 12944 ha
  - (2026-08-03) [Green] Forest fires in The Democratic Republic of Congo
      Wildfire · Green alert · The Democratic Republic of Congo · Green impact for forestfire in 32215 ha
  - (2026-08-03) [Green] Forest fires in The Democratic Republic of Congo
      Wildfire · Green alert · The Democratic Republic of Congo · Green impact for forestfire in 32215 ha

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-11) [Marginal Revolution] How well does AI peer review work?
      Claude and I planted 100 known errors into 10 open-access psychology papers and then ran them through frontier models and two commercial AI review tools. In brief: The best single system caught 71 of 100 errors, while th…
  - (2026-08-11) [Marginal Revolution] Who enters Congress?
      We trace the family origins of Members of Congress (MC) born between 1830 and 1950, linking each MC, their parents, and their brothers to the complete-count censuses. Future MCs have always been economic outliers. By 194…
  - (2026-08-10) [Marginal Revolution] Brian Chau at work
      I am automating investigative journalism at http://Effort.News We’re breaking five stories today based on verifiable financial data which everyone missed for years. Here is the entire thread, which also describes the fiv…
  - (2026-08-10) [Conversable Economist] When Happiness Was Invented
      My tradition on this blog is to take a break (mostly!) from current events sometime in mid- August. Instead, I pre-schedule daily posts based on things I read during the previous year about three of my preoccupations: ec…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 34 total
  - (2026-08-11) MOVER ▼ Gautam Adani — $84.04B ($-0.49B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-08-11) MOVER ▼ Francoise Bettencourt Meyers & family — $95.54B ($-0.44B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-11) MOVER ▼ Mukesh Ambani — $90.99B ($-0.14B since yesterday)
      India · Diversified · source: Diversified

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-11) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=31, 7d-median=21, 14d-median=20; carrying terms: standards, certain, remove, action, final, commission, proposing, proposed, proposes, procedures, regulatory, safety
- state_bills: today=87, 7d-median=108, 14d-median=108; carrying terms: order, powers, actions, jurisdiction, using, prohibit, personal, making, appropriations, certain, programs, effective
- state_news: today=450, 7d-median=717, 14d-median=604; carrying terms: actions, party, saturday, races, massive, running, centers, million, opinion, hawaii, legislative, redirects
- local_news: today=230, 7d-median=239, 14d-median=234; carrying terms: google, saturday, cbmipgfbvv, cbmirgfbvv, million, according, following, vehicle, neighborhood, multiple, appeared, brings
- foreign_news: today=980, 7d-median=1034, 14d-median=1017; carrying terms: hamas, started, stock, saturday, driver, personal, selected, plateau, remote, kyivindependent, powder, photos
- chinese_internal: today=243, 7d-median=261, 14d-median=264; carrying terms: google, cbmixkfvx, china, cbmickfvx, color, https, people, lxtfb, target, cbmibkfvx, cbmiaefvx, cbmiw
- russian_internal: today=1009, 7d-median=1056, 14d-median=940; carrying terms: gazeta, wildberries, axios, title, https, forbidden, patriot, media, istories, found, novaya, telegram
- ukrainian_internal: today=106, 7d-median=106, 14d-median=114; carrying terms: strike, logistics, kyivindependent, least, million, zelensky, following, national, drones, weapons, occupied, compiles
- ukraine_theater: today=1001, 7d-median=776, 14d-median=808; carrying terms: hvymd, vkdxvannm, qmpobldvz, zbzmtnmknhvljqbuxntwmtego, cwsehumnnpdkxjs, iwlrlzdvdumzjmufvcc, btqttgjzuvntlulnwkpkofdda, dthvn, google, havlsbkzqyzzlt, vlbttvfnqk, grmvmaux
- paper_bets: today=129, 7d-median=137, 14d-median=138; carrying terms: jackson, democratic, andrew, caribbean, party, polymarket, population, african, jinping, koivun, kalshi, theme
- weather: today=168, 7d-median=168, 14d-median=172; carrying terms: caribbean, increase, short, small, highway, relative, miami, details, following, national, winds, interior
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, dcoilwtico, payems, money, total, energy, sheet, openings, funds, balance, growth, payrolls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, crude, bitcoin, treasury, natural, china, yield, rates, corporate, close, agriculture, crypto
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=99, 14d-median=102; carrying terms: hamas, legislation, prior, order, science, democratic, google, actions, stability, cfius, performance, designations
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, unauthorized, quiver, quiverquant, congresstrading, httperror, https, error, client
- billionaires: today=34, 7d-median=34, 14d-median=36; carrying terms: brokerage, devasini, investments, canada, diversified, giancarlo, google, holdings, london, steve, huang, ballmer
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: johnson, supreme, court, appeals, county, delaware, elizabeth, association, blanche, company, group, trust
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, accno, reporting, michael, holdings, daniel, therapeutics, steven
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: platner, krishnamoorthi, raised, brown, disbursements, david, jonathan, senate, talarico, cooper, pinkston, michael
- gdelt_regions: today=12, 7d-median=6, 14d-median=6; carrying terms: english, japan, korea, south
- gdelt_gkg: today=25, 7d-median=48, 14d-median=36; carrying terms: english, spanish, themes, trump, hormuz, chinese, russian, strait, russia, turkish, attack, german
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=26, 14d-median=19; carrying terms: position, belgium, france, ground, kingdom, germany, eagle, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: unaffected, thailand, neurological, prior, democratic, proportion, ermera, africa, accordance, pregnant, arachidonic, coronavirus
- cisa_kev: today=7, 7d-median=9, 14d-median=9; carrying terms: untrusted, product, langflow, management, deserialization, authentication, center, firewall, sensitive, secure, command, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=285, 7d-median=251, 14d-median=236; carrying terms: thailand, republic, belize, speed, green, forestfire, canada, democratic, guatemala, alert, depth, medium
- usgs_quakes: today=13, 7d-median=13, 14d-median=14; carrying terms: depth, islands, russia, indonesia, china, alaska, south, shikotan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, september, ceasefire, effective, august, price, normal, returns, traffic, prime, winner
- commentary: today=6, 7d-median=6, 14d-median=5; carrying terms: marginal, conversable, https, economist, class, revolution, strong, conversableeconomist, marginalrevolution, economic, current, college
- tech_news: today=55, 7d-median=56, 14d-median=56; carrying terms: google, using, infrastructure, models, cyber, bleepingcomputer, computer, information, million, paper, turns, government
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: watson, nchez, aguilar, lateefah, stutzman, olszewski, susie, barrag, gomez, transportation, davis, coleman
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, markets, claude, consensus, market, paper, decision, converges, placed, identify, either, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*