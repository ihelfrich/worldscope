# WORLDSCOPE morning brief — 2026-08-11

## Headline
3824 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (733) · Russian Internal News (state + in-exile) (731) · Ukraine Theater (total-war monitoring) (644) · State-Level News (335) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (220) · Chinese Internal News (207) · U.S. Weather + Severe / Climate Outlooks (152) · State Legislative Action (77) · Ukrainian Internal News (national + local Kyiv) (57) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 733 new of 971 total
  - (2026-08-11) [Global] Why a soccer field in one German city may become a flood zone
      Western Europe has recorded its hottest-ever June and July, and extreme weather from wildfires to storms are here to stay. How can we adapt to what seems to be the new normal? Cities like Kiel in Germany are trying.
  - (2026-08-11) [Global] India news: Jharkhand student leader hospitalized after police use force
      Devendra Nath Mahto joined a march to the state Assembly despite being on a nine-day hunger strike. The CJP denounced the police use of tear gas, batons and water cannons against protesters as "inhuman." DW has more.
  - (2026-08-11) [Global] Germany news: Rhine levels could cause production cuts
      The summer heat is not only causing water levels in Germany's key river arteries to drop to dangerously low levels, but also contributing to wildfires in several areas. Follow DW for more.
  - (2026-08-11) [Global] Middle East: Trump took secret flight out of Turkey over Iran threat
      President Donald Trump reportedly used an elaborate ruse to leave the NATO summit in Turkey, amid a credible assassination threat. Meanwhile, oil prices rose as hopes for a deal on the Strait of Hormuz fade. DW has more.
  - (2026-08-11) [Global] Trump pushes overhaul of US policy on vaccines for children
      In an executive order, President Trump calls for fewer recommended childhood vaccinations and more spacing between shots. Medical experts say the changes lack scientific backing and could leave children less protected.
  - (2026-08-10) [Global] Turkey MPs back historic law on reintegrating PKK militants
      Turkey's parliament has taken a major step toward ending four decades of conflict with the PKK. The new law sets out how some militants can return to civilian life, but leaves Abdullah Ocalan's future unresolved.

### Russian Internal News (state + in-exile) — 731 new of 981 total
  - (2026-08-11) МАГАТЭ вывезет ядерные материалы с засекреченного объекта в Сирии. Соглашение с местным правительством заключили при посредничестве США | LEDE: Международное агентство по атомной энергии (МА] (ru: МАГ…
      Международное агентство по атомной энергии (МАГАТЭ) сможет вывезти ядерные материалы с засекреченного объекта в Сирии. Переговоры по этому вопросу с участием Сирии, Израиля и представителей администрации Трампа продолжал…
  - (2026-08-11) «Коммерсант»: поставки китайских автозапчастей в Россию выросли на 15% за семь месяцев | LEDE: За семь месяцев с января по июль ввоз автомобильных запчастей и комплектующих из Китая в Россию] (ru: «Ко…
      За семь месяцев с января по июль ввоз автомобильных запчастей и комплектующих из Китая в Россию вырос примерно на 15% (до 1,3 миллиарда долларов), пишет «Коммерсант» со ссылкой на данные атводилера «Рольф».
  - (2026-08-11) Из-за угрозы покушения Трамп улетал с саммита НАТО в Турции тайно — он демонстративно сел в президентский самолет, но затем его перевели на военный «боинг» | LEDE: После окончания саммита НА] (ru: Из-…
      После окончания саммита НАТО, проходившего в июле в Анкаре, Дональд Трамп улетел обратно в США тайно — военным самолетом вместо традиционного президентского борта, выяснила газета The Washington Post.
  - (2026-08-11) «Я так в последний раз нервничал, когда с девушкой расставался». Сотни молодых россиян вышли на улицу, чтобы поддержать партию «Яблоко», выступившую против войны. Репортаж из центра Москвы | LE] (ru:…
      Весь день 10 августа Верховный суд рассматривал иск об отмене регистрации партии «Яблоко» на выборах в Госдуму. И все это время у здания на Поварской находились сотни сторонников единственной антивоенной партии, которая…
  - (2026-08-11) Китай провел неудачный запуск ракеты-носителя «Чанчжэн-7А». Это ее первая авария за шесть лет | LEDE: Китайская ракета-носитель «Чанчжэн-7А» взорвалась в воздухе вскоре после запуска с космо] (ru: Кит…
      Китайская ракета-носитель «Чанчжэн-7А» взорвалась в воздухе вскоре после запуска с космодрома Вэньчан на острове Хайнань, сообщает агентство «Синьхуа».
  - (2026-08-11) В США начался суд над предполагаемым участником убийства Тупака Шакура. В основе обвинения — мемуары, в которых он сам фактически признался в содеянном. Рэпера застрелили в 1996 году. Это одно ] (ru:…
      В Лас-Вегасе в понедельник, 10 августа, начался судебный процесс по делу об убийстве рэп-исполнителя Тупака Шакура, которое произошло в 1996 году. Обвиняемый — 63-летний Дуэйн Дэвис, известный в криминальных кругах как К…

### Ukraine Theater (total-war monitoring) — 644 new of 1001 total
  - (2026-08-11) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-10) [FIRMS] thermal anomaly 44.858, 33.828 (FRP 3.99 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 3.99 MW
  - (2026-08-10) [FIRMS] thermal anomaly 44.905, 33.811 (FRP 3.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 3.41 MW
  - (2026-08-10) [FIRMS] thermal anomaly 44.903, 33.807 (FRP 3.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 3.41 MW
  - (2026-08-10) [FIRMS] thermal anomaly 44.902, 33.802 (FRP 1.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 1.76 MW
  - (2026-08-10) [FIRMS] thermal anomaly 45.256, 31.672 (FRP 5.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-10 0954Z, FRP 5.53 MW

### State-Level News — 335 new of 431 total
  - (2026-08-10) [Alabama] Governor Kay Ivey Encourages 1st, 2nd, 6th and 7th Congressional District Alabamians to Vote
      Governor Ivey encouraged Alabamians in the state’s 1st, 2nd, 6th and 7th congressional districts to vote in the upcoming Tuesday, August 11, 2026 Special Congressional Primary Election. (Governor’s Office, Gina Maiola &…
  - (2026-08-10) [Alabama] Governor Ivey Encourages 1st, 2nd, 6th and 7th Congressional District Alabamians to Head to the Polls for Special Primary Election
      MONTGOMERY – Governor Kay Ivey on Monday encouraged Alabamians in the state’s 1st, 2nd, 6th and 7th congressional districts to vote in the upcoming Tuesday, August 11, 2026, Special Congressional Primary Election. “The s…
  - (2026-08-10) [California] First Partner Jennifer Siebel Newsom, Senate President pro Tem Monique Limón celebrate women founders leading innovation in California
      Source
  - (2026-08-10) [California] Governor Newsom condemns Trump administration proposal to weaken federal gun safety
      Source
  - (2026-08-10) [California] Golden State in the spotlight: Governor Newsom announces nine new TV projects – including iconic reboots, sequels, and star-studded dramas – to launch second year of California’s expanded…
      Source
  - (2026-08-10) [California] Governor Newsom announces new AI cyber defense program to protect California’s critical infrastructure

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 220 new of 227 total
  - (2026-08-11) [St. Louis] Where Art Thou? – 8/11/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-11) [St. Louis] Want to make cheese-wheel pasta? There’s just one problem
      Ask Cheryl: Is there anyone in St. Louis that has small 10-inch cheese wheels, so I can make pasta alla ruota? —J.S., St. Louis One of the biggest food trends of the past year or so has been pasta alla ruota, or pasta fi…
  - (2026-08-10) [St. Louis] Sabor Cubano opens in Boulevard Heights
      The name says it all at Sabor Cubano (6836 Gravois), which translates to “Cuban flavor.” A trip to Dayanna Herrera’s new restaurant in Boulevard Heights is like a visit to the island, with the food, warm service, music,…
  - (2026-08-10) [St. Louis] St. Louis volunteers rally around immigrant families in crisis
      Earlier this year, three St. Louis-area mothers found themselves preparing for childbirth while also navigating the detention of their husbands by immigration authorities. For volunteers with nonprofit Abide in Love St.…
  - (2026-08-10) [St. Louis] Top family-friendly events this week in St. Louis
      Romeo & Zooliet Puppet Meet & Greet | August 11Meet one or two larger-than-life puppets from St. Louis Shakespeare Festival’s Romeo & Zooliet before a free outdoor performance of The Two Gentlemen of Verona. 6 p.m. Cityg…
  - (2026-08-10) [St. Louis] Renovating your kitchen? Top designers share words of wisdom
      A kitchen renovation is one of the most exciting—and sometimes most challenging—projects a homeowner can take on. From balancing budgets and timelines to making countless design decisions, there’s a lot that goes into cr…

### Chinese Internal News — 207 new of 241 total
  - (2026-08-10) China Takes World’s Fastest Train One Step Closer to Market - caixinglobal.com
      China Takes World’s Fastest Train One Step Closer to Market caixinglobal.com
  - (2026-08-10) Cover Story: China’s Drive to Shore Up Social Security Funds Brings a Payroll Shock - caixinglobal.com
      Cover Story: China’s Drive to Shore Up Social Security Funds Brings a Payroll Shock caixinglobal.com
  - (2026-08-09) Arm - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE5YQlBQdWFheGN2cUMydGY4eXVNX3NsN0tnV3hHYkRZS1pqU0hCT0pVTmdub3dWLVJNXzRNczMtMlJGRE52YWVMZFJha3BkMGlGc] (zh:…
      Arm deepview.caixin.com
  - (2026-08-09) 光伏危与机 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE05ZEZhY21SUU1RVHNreVBhMW1sSTB1UHVyV2QtRzNxaW5qWk5PenpiVy1IYVZFUDlCUG1kSWhTekJWUHNMNUoxOUd4MkYwZ0t] (zh:…
      光伏危与机 deepview.caixin.com
  - (2026-08-09) 德国 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE9obFJsME0wYWVrNzNDSHlsLXRLeFZlcnNKY0xoMFdsOEhqQ2xEYnVpWHI0dmdUMXFuVHBLVkVJYnpzT29XWEphZXItM0Y5QlJUdk] (zh:…
      德国 deepview.caixin.com
  - (2026-08-09) 张军 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFA0VkVfbG9QUEU2YVk5Y3loQTdoWnlTVTR6VTNSUHRUcjlnMU45SmlQT2d1Q0k3S2FoRko2TXFqeVV4NjRzUDgwa3NmaDdyTU9nWU] (zh:…
      张军 deepview.caixin.com

### U.S. Weather + Severe / Climate Outlooks — 152 new of 160 total
  - (2026-08-11) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 11 at 3:02AM CDT until August 11 at 3:30AM CDT by NWS Milwaukee/Sullivan WI
      SVRMKX The National Weather Service in Milwaukee/Sullivan has issued a * Severe Thunderstorm Warning for... Southwestern Walworth County in southeastern Wisconsin... Southeastern Rock County in south central Wisconsin...…
  - (2026-08-11) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-11) [Severe] Flash Flood Warning: Flash Flood Warning issued August 11 at 3:57AM EDT until August 11 at 6:30AM EDT by NWS State College PA
      FFWCTP The National Weather Service in State College has extended the * Flash Flood Warning for... Southwestern Somerset County in south central Pennsylvania... * Until 630 AM EDT. * At 357 AM EDT, Doppler radar indicate…
  - (2026-08-11) [Severe] Flood Warning: Flood Warning issued August 11 at 3:57AM EDT until August 11 at 12:00PM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall is expected. * WHERE...Northwestern Morgan County in southeastern Ohio... Central Perry County in southeastern Ohio... * WHEN...Until noon EDT Tuesday. * IMPACTS...Flooding…
  - (2026-08-11) [Moderate] Special Weather Statement: Special Weather Statement issued August 11 at 2:57AM CDT by NWS Milwaukee/Sullivan WI
      At 257 AM CDT, Doppler radar was tracking a cluster of strong thunderstorms over Clinton, or 10 miles west of Delavan, moving southeast at 20 mph. HAZARD...Wind gusts up to 50 mph and nickel size hail. SOURCE...Radar ind…
  - (2026-08-11) [Moderate] Special Weather Statement: Special Weather Statement issued August 11 at 3:54AM EDT by NWS Detroit/Pontiac MI
      At 353 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Hudson to near Clayton to near Adrian. Movement was southeast at 30 mph. HAZARD...Winds in excess of 40 mph and nickel size…

### State Legislative Action — 77 new of 87 total
  - (2026-08-11) [Alaska HB 282] An Act relating to municipal regulation of automated traffic safety cameras.
      An Act relating to municipal regulation of automated traffic safety cameras.
  - (2026-08-11) [Alaska HB 329] An Act relating to certificates of fitness for employees of an electric utility.
      An Act relating to certificates of fitness for employees of an electric utility.
  - (2026-08-11) [Alaska HB 93] An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.
      An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.
  - (2026-08-11) [Alaska HB 155] An Act relating to alcohol; relating to local option elections; relating to the statewide database of alcohol purchases; relating to alcohol licenses, endorsements, and permits; relati…
      An Act relating to alcohol; relating to local option elections; relating to the statewide database of alcohol purchases; relating to alcohol licenses, endorsements, and permits; relating to municipal regulation and taxat…
  - (2026-08-11) [Alaska SB 208] An Act relating to industrial hemp; relating to the sale and lease of state land for agricultural uses; designating the O-S Cross cabbage, commonly known as 'giant green cabbage,' as t…
      An Act relating to industrial hemp; relating to the sale and lease of state land for agricultural uses; designating the O-S Cross cabbage, commonly known as 'giant green cabbage,' as the official state vegetable; and pro…
  - (2026-08-11) [Alaska HB 9050] An Act relating to a test.
      An Act relating to a test.

### Ukrainian Internal News (national + local Kyiv) — 57 new of 103 total
  - (2026-08-11) ДБР розслідує падіння винищувача МіГ-29: шукають "чорну скриньку" серед уламків | LEDE: Працівники Державного бюро розслідувань відкрили кримінальне провадження за фактом падіння винищувача МіГ] (uk:…
      Працівники Державного бюро розслідувань відкрили кримінальне провадження за фактом падіння винищувача МіГ-29 Збройних сил України, яке сталося ввечері 10 серпня у Березівському районі Одеської області.
  - (2026-08-11) У Польщі судять трьох поляків за жорстоке побиття українця | LEDE: ] (uk: У Польщі судять трьох поляків за жорстоке побиття українця)
  - (2026-08-11) Зеленський: Росіяни били по Запоріжжю "Цирконами", КАБами і балістикою з КНДР | LEDE: По Запоріжжю РФ застосувала "Циркони", КАБи і ракети з КНДР, є жертви та руйнування.] (uk: Зеленський: Росіяни бил…
      По Запоріжжю РФ застосувала "Циркони", КАБи і ракети з КНДР, є жертви та руйнування.
  - (2026-08-11) Російський безпілотник порушив повітряний простір Молдови під час атаки на Одещину | LEDE: Безпілотник РФ на короткий час залетів у повітряний простір Молдови під час атаки на Одещину 10 серпня] (uk:…
      Безпілотник РФ на короткий час залетів у повітряний простір Молдови під час атаки на Одещину 10 серпня.
  - (2026-08-11) Російська дезінформація – у Польщі спростували, що українець напав на підлітка | LEDE: Нападником на польського підлітка був інший поляк, я не українець, як це припускали у коментарях у соцмере] (uk:…
      Нападником на польського підлітка був інший поляк, я не українець, як це припускали у коментарях у соцмережах, заявили в МВС Польщі, назвавши подібні неперевірені чутки російською дезінформацією.
  - (2026-08-11) Трамп оголосив про повний контроль США над Ормузькою протокою | LEDE: Трамп заявив, що США очистили Ормузьку протоку від мін і контролюють її флотом на 100%.] (uk: Трамп оголосив про повний контроль С…
      Трамп заявив, що США очистили Ормузьку протоку від мін і контролюють її флотом на 100%.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Niedrigwasser am Rhein macht Tanken teurer
      az-online.de · German · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Правительство продлило сниженный норматив продаж бензина на бирже
      1prime.ru · Russian · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] DBH Kab . Tanjung Jabung Barat 2026 Tembus Rp173 , 64 Miliar , Penyalurannya Lampaui Rata - rata Nasional
      batam.tribunnews.com · Indonesian · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Gino Oliva e la svolta nella nuova fotografia : una mostra sulle tappe della rivoluzione
      ilgazzettino.it · Italian · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] Benzín a nafta opäť zdraželi : Čo čaká slovenských vodičov ?
      cas.sk · Slovak · tone NA
  - (2026-08-11) [Russia oil sanctions perimeter · themes] ВС РФ поразили в Киеве терминал « Новой почты » с товарами двойного назначения
      news.mail.ru · Russian · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-11) [Kotarba Scott] Form 4 (Reporting)
      filed 2026-08-11 01:49 UTC · role: Reporting — Filed: 2026-08-10 AccNo: 0001217160-26-000067 Size: 15 KB
  - (2026-08-11) [JEWETT CAMERON TRADING CO LTD] Form 4 (Issuer)
      filed 2026-08-11 01:49 UTC · role: Issuer — Filed: 2026-08-10 AccNo: 0001217160-26-000067 Size: 15 KB
  - (2026-08-11) [Red Rock Resorts, Inc.] Form 4 (Issuer)
      filed 2026-08-11 01:41 UTC · role: Issuer — Filed: 2026-08-10 AccNo: 0001193125-26-343081 Size: 13 KB
  - (2026-08-11) [KREEGER SCOTT] Form 4 (Reporting)
      filed 2026-08-11 01:41 UTC · role: Reporting — Filed: 2026-08-10 AccNo: 0001193125-26-343081 Size: 13 KB
  - (2026-08-11) [Aptevo Therapeutics Inc.] Form 4 (Issuer)
      filed 2026-08-11 01:39 UTC · role: Issuer — Filed: 2026-08-10 AccNo: 0001193125-26-343080 Size: 6 KB
  - (2026-08-11) [Harsanyi Zsolt] Form 4 (Reporting)
      filed 2026-08-11 01:39 UTC · role: Reporting — Filed: 2026-08-10 AccNo: 0001193125-26-343080 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-11) [] Russia Hit Military Enterprises , Logistics Centers in Kiev , Zaporozhye
      domain: sputnikglobe.com · language: English · tone:
  - (2026-08-11) [Germany] Qben Infra AB : Qben Power : LAJE has won a 125 MNOK contract
      domain: finanznachrichten.de · language: English · tone:
  - (2026-08-11) [South Africa] Baby : A New Life Born from Desperation
      domain: citizen.co.za · language: English · tone:
  - (2026-08-11) [Brazil] Copper Presses Higher on Monday ; CPER Gains 0 . 70 %
      domain: riotimesonline.com · language: English · tone:
  - (2026-08-11) [Australia] EPBCA : landholder guide described as not a helpful tool | Stock & Land
      domain: stockandland.com.au · language: English · tone:
  - (2026-08-11) [Azerbaijan] Typhoon Dolphin moves inland , threatens central China with floods
      domain: news.az · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 55 total
  - (2026-08-11) [The Hacker News] Hackers Breach Polish Power Plant Controls via Private Cellular Network and Shut Turbine
      Attackers shut down a steam turbine and the process-water treatment system at a Polish combined heat and power plant by coming in over the private cellular network the local grid operator uses to reach remote equipment.…
  - (2026-08-11) [The Hacker News] BdThemes Supply Chain Attack Poisons JSON to Create Rogue WordPress Admins
      Cybersecurity researchers have warned of a supply chain compromise impacting WordPress plugin vendor BdThemes, prompting the content management systems (CMS) platform's plugins team to temporarily disable their downloads…
  - (2026-08-11) [The Register] Why hybrid clouds break and what to do about it
      SPONSORED EXPLAINER: There's nothing wrong with hybrid cloud. It's the one-size-fits-all strategy on top of it that's the problem.
  - (2026-08-11) [The Register] OVH Cloud warns of 87% price hikes to help it cover RAMpocalypse costs
      Gaming servers get the steepest rises but sticker shock is also coming to conventional instances running on old and new boxes
  - (2026-08-11) [The Register] Japan kind-of completes its sovereign satnav constellation
      H3 rocket gets the job done after losing a bird last year
  - (2026-08-11) [The Register] Alibaba Cloud is using AI to help it use less AI
      Solves tech support tickets faster and more accurately by keeping them away from LLMs

### U.S. Federal Action — 31 new of 31 total
  - (2026-08-11) Ending Birth Tourism
  - (2026-08-11) Continuing To Protect the Meaning and Value of American Citizenship
  - (2026-08-11) National Purple Heart Day, 2026
  - (2026-08-11) Adjusting Imports of Polysilicon and Its Derivatives Into the United States
  - (2026-08-11) Schedules of Controlled Substances: Rescheduling of Suvorexant, Lemborexant, and Daridorexant From Schedule IV Into Schedule V
      The Drug Enforcement Administration proposes to transfer suvorexant ([(7R)-4-(5-chloro-1,3-benzoxazol-2-yl)-7-methyl-1,4- diazepan-1-yl]-[5-methyl-2-(triazol-2-yl)phenyl]methanone), lemborexant ((1R,2S)-2-[(2,4-dimethylp…
  - (2026-08-11) NRC Modernization: Rulemaking Procedure, Federal Advisory Committee Act Alignment, Access, and Security
      The U.S. Nuclear Regulatory Commission (NRC) is amending its regulations by streamlining procedural provisions related to information withholding and post-promulgation comment periods; aligning the NRC's regulations with…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 28 new of 60 total
  - (2026-08-10) Supreme Court of California: Family Violence Appellate Project v. Super. Ct.
  - (2026-08-10) Supreme Court of California: Tesoro Refining & Marketing Co. LLC v. City of Carson
  - (2026-08-10) U.S. Court of Appeals, 3rd Cir.: United States v. Derby Clerfe
  - (2026-08-10) U.S. Court of Appeals, Federal Cir.: Dental Monitoring Sas v. Align Technology, Inc.
  - (2026-08-10) U.S. Court of Appeals, Federal Cir.: Chitlik v. Hhs
  - (2026-08-10) U.S. Court of Appeals, Federal Cir.: Hernandez v. Collins

### Government & military aircraft airborne (OpenSky) — 24 new of 25 total
  - (2026-08-11) SAMB2 (Australia)
      icao24: 7cf9e7 · position: (-31.6725, 116.0177) · on ground · 35km/h
  - (2026-08-11) SAMB (Australia)
      icao24: 7cf9e0 · position: (-31.6663, 116.0215) · on ground
  - (2026-08-11) SAMU05 (France)
      icao24: 39ca81 · position: (44.5587, 6.0747) · alt: 815m · 131km/h
  - (2026-08-11) PUMA52 (Slovenia)
      icao24: 506e1c · position: (46.0786, 15.2905) · alt: 853m · 180km/h
  - (2026-08-11) RFF02 (Portugal)
      icao24: 496ca4 · position: (37.0156, -7.9839) · on ground · 46km/h
  - (2026-08-11) GAF404 (Germany)
      icao24: 3f46db · position: (52.4602, 9.4595) · on ground · 239km/h

### Paper Trading Scorecard — 22 new of 130 total
  - (2026-08-11) [Polymarket] Iran charges Hormuz fees by December 31?
      This market resolves to “Yes” if the Iranian government officially announces and begins collecting fees, tolls, charges, tariffs, or similar payments from commercial vessels which are mandatory for passage through or acc…
  - (2026-08-11) [Polymarket] Will David Crowley win the 2026 Wisconsin Governor Democratic primary election?
      This market will resolve according to the winner of the Democratic Primary for Governor of Wisconsin, scheduled to take place on August 11, 2026. Resolution will be based on the overall winner of the primary, including a…
  - (2026-08-11) [Polymarket] Will Angie Craig be the Democratic nominee for Senate in Minnesota?
      This market will resolve according to the winner of the Democratic Primary for United States Senator from Minnesota. If no 2026 Minnesota Democratic Senate Primary takes place, this market will resolve to "Other". The re…
  - (2026-08-11) [Polymarket] Will the Bank of Japan announce no change at the September 2026 meeting?
      This market will resolve according to the change in basis points in the uncollateralized overnight call rate resulting from the September 2026 meeting of the Bank of Japan, relative to the level it was prior to this meet…
  - (2026-08-11) [Polymarket] Will an international court find Israel or its leaders guilty of Genocide by December 31, 2027?
      This market will resolve to "Yes" if he International Criminal Court ("ICC"), the International Court of Justice ("ICJ"), or any ad hoc international tribunal with recognized legal standing, issues a judgment or convicti…
  - (2026-08-11) [Manifold] Will I solve an unsolved math problem with AI in August?

### USGS earthquakes (M4.5+, past day) — 11 new of 12 total
  - (2026-08-10) M 7.4 - 5 km S of San José del Palmar, Colombia
      M7.4 · 5 km S of San José del Palmar, Colombia · depth 110.285 km · PAGER orange
  - (2026-08-10) M 5.1 - 232 km SSW of Pagar Alam, Indonesia
      M5.1 · 232 km SSW of Pagar Alam, Indonesia · depth 21.72 km
  - (2026-08-10) M 5.0 - 16 km W of San José del Palmar, Colombia
      M5.0 · 16 km W of San José del Palmar, Colombia · depth 98.522 km
  - (2026-08-10) M 5.0 - northern Mid-Atlantic Ridge
      M5.0 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-08-10) M 4.8 - 173 km ENE of Sola, Vanuatu
      M4.8 · 173 km ENE of Sola, Vanuatu · depth 655.67 km
  - (2026-08-11) M 4.7 - 81 km SSE of Bengkulu, Indonesia
      M4.7 · 81 km SSE of Bengkulu, Indonesia · depth 61.94 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-08-11) MOVER ▲ Elon Musk — $853.29B (+$29.72B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-11) MOVER ▼ Jensen Huang — $187.89B ($-5.45B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-08-11) MOVER ▲ Larry Ellison — $192.23B (+$4.56B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-11) MOVER ▲ Jeff Bezos — $283.81B (+$3.18B since yesterday)
      United States · Technology · source: Amazon
  - (2026-08-11) MOVER ▲ Thomas Peterffy — $104.96B (+$3.07B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-08-11) MOVER ▲ Warren Buffett — $150.21B (+$2.59B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-08-11) National Bank Open: Rafael Jodar vs Arthur Fils
      yes price: 57% · 24h volume: $1,145,615 · resolves 2026-08-18
  - (2026-08-11) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 42% · 24h volume: $1,135,617 · resolves 2026-09-16
  - (2026-08-11) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 1% · 24h volume: $567,174 · resolves 2026-09-16
  - (2026-08-11) LoL: Hanwha Life Esports vs DN SOOPers (BO5) - KeSPA Cup Playoffs
      yes price: 26% · 24h volume: $461,481 · resolves 2026-08-11
  - (2026-08-11) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 18% · 24h volume: $449,184 · resolves 2027-01-01
  - (2026-08-11) Will Yabloko gain the most seats in the next Russian parliamentary election?
      yes price: 0% · 24h volume: $389,007 · resolves 2026-09-30

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 99 total
  - (2026-08-07) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-08-11) [USASpending] $634,704,286 → AMENTUM SPACEPORT LLC: BASE OPERATIONS AND SPACEPORT SERVICES (BOSS) CONTRACT
      Agency: National Aeronautics and Space Administration. Description: BASE OPERATIONS AND SPACEPORT SERVICES (BOSS) CONTRACT
  - (2026-08-11) [USASpending] $626,506,870 → SIGA TECHNOLOGIES, INC.: PROCUREMENT AND LATE-STAGE DEVELOPMENT OF SMALLPOX ANTIVIRAL
      Agency: Department of Health and Human Services. Description: PROCUREMENT AND LATE-STAGE DEVELOPMENT OF SMALLPOX ANTIVIRAL DRUG(S) IGF::OT::IGF
  - (2026-08-11) [USASpending] $584,202,830 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: U.S. CUSTOMS AND BORDER PROTECTION (CBP) OFFICE OF INFORMATI
      Agency: Department of Homeland Security. Description: U.S. CUSTOMS AND BORDER PROTECTION (CBP) OFFICE OF INFORMATION TECHNOLOGY, (OIT) TARGETING AND ANALYSIS SYSTEMS PROGRAM DIRECTORATE (TASPD)'S OPERATIONS AND MAINTENAN…

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-11) [Marginal Revolution] How well does AI peer review work?
      Claude and I planted 100 known errors into 10 open-access psychology papers and then ran them through frontier models and two commercial AI review tools. In brief: The best single system caught 71 of 100 errors, while th…
  - (2026-08-11) [Marginal Revolution] Who enters Congress?
      We trace the family origins of Members of Congress (MC) born between 1830 and 1950, linking each MC, their parents, and their brothers to the complete-count censuses. Future MCs have always been economic outliers. By 194…
  - (2026-08-10) [Marginal Revolution] Brian Chau at work
      I am automating investigative journalism at http://Effort.News We’re breaking five stories today based on verifiable financial data which everyone missed for years. Here is the entire thread, which also describes the fiv…
  - (2026-08-10) [Conversable Economist] When Happiness Was Invented
      My tradition on this blog is to take a break (mostly!) from current events sometime in mid- August. Instead, I pre-schedule daily posts based on things I read during the previous year about three of my preoccupations: ec…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-11) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=31, 7d-median=21, 14d-median=20; carrying terms: operations, final, amendment, proposes, proposing, service, provide, certain, remove, procedures, action, rulemaking
- state_bills: today=87, 7d-median=108, 14d-median=113; carrying terms: support, agency, certified, commission, within, contract, provides, related, amended, business, terms, every
- state_news: today=431, 7d-median=717, 14d-median=717; carrying terms: recent, efforts, nomination, defense, agency, include, temporary, security, question, records, democratic, districts
- local_news: today=227, 7d-median=239, 14d-median=230; carrying terms: stlmag, atlanta, async, charged, injured, srcset, faces, metro, years, brings, concerns, content
- foreign_news: today=971, 7d-median=1034, 14d-median=1022; carrying terms: ceremony, recent, defense, protests, thailand, worry, capital, towards, include, security, alleged, madrid
- chinese_internal: today=241, 7d-median=261, 14d-median=261; carrying terms: china, price, chinese, caixin, people, google, https, cbmib, articles, cbmix, lxtfa, title
- russian_internal: today=981, 7d-median=1056, 14d-median=943; carrying terms: novaya, axios, wildberries, europe, journal, forbidden, httperror, telegram, error, media, street, reuters
- ukrainian_internal: today=103, 7d-median=106, 14d-median=122; carrying terms: efforts, defense, operations, confirmed, security, casualties, injured, districts, cabinet, strikes, drone, faces
- ukraine_theater: today=1001, 7d-median=776, 14d-median=776; carrying terms: unauthorized, frontline, maintained, error, token, viirs, polygon, alerts, extra, liveuamap, administration, deepstatemap
- paper_bets: today=130, 7d-median=137, 14d-median=138; carrying terms: sachs, kylian, house, nomination, magnitude, north, season, manifold, jinping, prime, erupt, alaska
- weather: today=160, 7d-median=168, 14d-median=173; carrying terms: afdfwd, unhealthy, degraded, magnitude, tampa, eureka, front, include, above, cooling, lincoln, chance
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: walcl, rates, openings, consumption, supply, nonfarm, jtsjol, payems, sheet, money, pcepilfe, personal
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, rates, agriculture, commodities, yield, russell, crude, equities, credit, close, large, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=99, 14d-median=101; carrying terms: undermining, lebanon, violent, effects, burma, embargo, protests, oblasts, congo, operations, prohibited, support
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, error, unauthorized, congresstrading, quiver, httperror, https, quiverquant, client
- billionaires: today=40, 7d-median=40, 14d-median=37; carrying terms: tokyo, giancarlo, tesla, meyers, france, canada, larry, googl, mexico, ambani, steve, arnault
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, appeals, johnson, county, delaware, blanche, corporation, group, company, elizabeth, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, michael, holdings, therapeutics, daniel, steven
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: david, warner, committee, michael, cortez, house, raised, senate, booker, ocasio, elect, alexandria
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, japan, china
- gdelt_gkg: today=50, 7d-median=50, 14d-median=48; carrying terms: english, spanish, themes, russian, chinese, trump, hormuz, keywords, russia, italian, strait, attacks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: against, language, kingdom, russia, attack, english, domain, india, trump, arrested
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=25, 7d-median=25, 14d-median=19; carrying terms: position, belgium, ground, france, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: onboard, avian, german, cruise, samples, france, viral, aboard, britain, recent, infected, cumulative
- cisa_kev: today=7, 7d-median=9, 14d-median=9; carrying terms: command, authentication, secure, vendor, langflow, management, firewall, untrusted, deserialization, product, cisco, password
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=233, 14d-median=236; carrying terms: herzegovina, panama, honduras, marino, canada, france, nicaragua, gabon, denmark, mexico, romania, typhoon
- usgs_quakes: today=12, 7d-median=13, 14d-median=14; carrying terms: depth, islands, russia, indonesia, china, south, shikotan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, september, ceasefire, effective, august, traffic, returns, strait, hormuz, normal
- commentary: today=6, 7d-median=6, 14d-median=5; carrying terms: conversable, marginal, economist, class, https, revolution, strong, conversableeconomist, marginalrevolution, economic, college, current
- tech_news: today=55, 7d-median=56, 14d-median=56; carrying terms: artificial, record, security, weekday, noopener, across, provides, target, years, models, attack, vulnerability
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: grace, crapo, larsen, sessions, atlanta, sheldon, himes, emanuel, nadler, brendan, house, herbert
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, sufficient, placed, paper, decision, module, either, converges, markets, unavailable, identify, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*