# WORLDSCOPE morning brief — 2026-10-12

## Headline
3117 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (847) · Russian Internal News (state + in-exile) (718) · World leaders & government officials (324) · Chinese Internal News (253) · Ukraine Theater (total-war monitoring) (229) · State-Level News (176) · Local News: St. Louis + Atlanta (162) · U.S. Weather + Severe / Climate Outlooks (110) · Ukrainian Internal News (national + local Kyiv) (66) · GDACS — global disaster alerts (50) · IT, InfoSys & cybersecurity news (last 7 days) (35) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 847 new of 980 total
  - (2026-10-12) [Global] Healey faces £35bn Budget challenge to meet spending pledges, says think tank
      The Institute for Fiscal Studies says the government will need a "top-up" of billions of pounds if it wants to meet its spending plans.
  - (2026-10-12) [Global] How to avoid getting stung if you miss credit card payments
      People are increasingly falling behind on credit card repayments, so here's the best way to get debt advice.
  - (2026-10-12) [Global] Fridges in French supermarkets hit by cyber attack
      Hundreds of stores were targeted by the overnight hack, which spoiled fresh and frozen food estimated to be worth millions of euros.
  - (2026-10-12) [Global] AI minister warns 'likely' UK's cyber defences will be breached
      Kanishka Narayan said the government will use advanced AI to strengthen the UK against cyber attacks.
  - (2026-10-11) [Global] Roofing scammers con homeowners out of thousands of pounds
      One in 10 scams reported to Citizens Advice relate to fraudsters charging for work not done, or done badly.
  - (2026-10-12) [Global] AI is less regulated than milk, says Microsoft president
      Brad Smith calls for global rules on AI, and says the UK is in the "best position" to lead the charge.

### Russian Internal News (state + in-exile) — 718 new of 875 total
  - (2026-10-12) Акционеры «Рижского бальзама» рассмотрят вопрос о банкротстве компании из-за долгов на 28 миллионов евро | LEDE: Правление компании Amber Latvijas balzams созвало на 3 ноября собрание акцион] (ru: Акц…
      Правление компании Amber Latvijas balzams созвало на 3 ноября собрание акционеров. На повестке собрания — вопрос о возможностях дальнейшей деятельности компании и начале процесса неплатежеспособности. Решение будет приня…
  - (2026-10-12) Дроны дважды атаковали аэропорт в столице Саудовской Аравии. Погибли 13 человек, сотни получили ранения. Авиасообщение остановлено. Это хуситы — союзники и прокси Ирана | LEDE: Власти Саудов] (ru: Дро…
      Власти Саудовской Аравии на неопределенный срок остановили работу аэропорта в столице страны Эр-Рияде после двух атак, совершенных йеменскими хуситами.
  - (2026-10-12) Главком сил НАТО в Европе представил «теорию победы» в случае нападения России — с ударами по Санкт-Петербургу и Калининграду. «Любая атака на любого из союзников окажется совершенно бессмыслен] (ru:…
      Главнокомандующий Объединенными вооруженными силами НАТО в Европе генерал Алексус Гринкевич заявил, что если Россия совершит атаку на территорию альянса, силы НАТО уничтожат «всё и вся», что будет задействовано в нападен…
  - (2026-10-12) В Баку начались протесты из-за запрета хиджабов в школах. Протестующие устраивают поджоги, арестованы 37 человек | LEDE: В Баку 37 человек арестовали из-за протестов против новых правил един] (ru: В Б…
      В Баку 37 человек арестовали из-за протестов против новых правил единой школьной формы, сообщает Minval со ссылкой на МВД Азербайджана. По информации агентства, протестующие вступили в конфликт с сотрудниками школ, а так…
  - (2026-10-12) Как «Яндекс» справляется с последствиями ударов Украины по своим дата-центрам? Сервисы все еще не работают как в России, так и за рубежом. Замена поврежденного оборудования займет до полугода. ] (ru:…
      Украина нанесла удары по трем дата-центрам «Яндекса» из шести — в Сасово (Рязанская область), Калуге и Владимире. В Киеве атаки назвали ответом на российские удары по украинским дата-центрам, по которым ВС РФ бьют в посл…
  - (2026-10-12) Российский дипломат, высланный из Болгарии после взрывов на оружейных складах, теперь работает в посольстве в Сербии | LEDE: Балканская служба «Радио Свобода» и расследовательский проект «Си] (ru: Рос…
      Балканская служба «Радио Свобода» и расследовательский проект «Система» обнаружили среди сотрудников российского посольства в Сербии дипломата, который еще в 2021 году был объявлен в Болгарии персоной нон грата на фоне р…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 253 new of 292 total
  - (2026-10-10) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE9aWDJfNmpBNk5wNVk4WEtVSW9PTjRlcE1fNHJRUG1VMTF4eHpHSmE3bmFfV19kZFlfY3lXTXZGSTZkdmZCeXcyUUV3TWJjaVJXWGR3WkZyb3lrd0Ra?oc=5"] (zh:…
      财新
  - (2026-10-12) 分享课 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiWEFVX3lxTFAtZlUzajBoMlh6YmdXSjllTmhSOGdJNHA2d2g2bDFPYUtIZXRxVmRZYlc0dUZxaXMyTDExdDN0TEpRMThCWmhnWE1BX0ZOWWZ4aUtHd3RBQmM?oc=5] (zh:…
      分享课 财新商城
  - (2026-10-12) 【家庭财富】慈善与传承是对立的吗？ - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE43bkl6S1M0WUZrdVFVSzFjQWd5SHNMZlVubGphaERhNG9XX0tjOUhvR1JzWFBVdHVjSU1Ta1Q5QW5vOUpFMUFiWFFuMkdMeTBBcU] (zh:…
      【家庭财富】慈善与传承是对立的吗？ 财新数据
  - (2026-10-12) 【市场动态】欧盟将把中国混合动力汽车进口量限制在每年35万辆 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTFBaTVJRenlrNWlkbjllUjA1V2ZndWN6d1BLY0NGZzBSZG5kcVZNbjNkNm9GaWVqN0Z3SFkwTTd2V0o3VktralZ6d] (zh:…
      【市场动态】欧盟将把中国混合动力汽车进口量限制在每年35万辆 财新数据
  - (2026-10-12) 【交易簿】惺惺相惜：李飞飞与苏姿丰的82亿美元联手 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9iZ2dfazFDaEFya2w2WjFrOXl5OGdoZEktLThtUkVNNjZaN2dUZkVWRFh5LUc0cVdoYllnTUFKQ29SY3hWUWYtOUc5Mm] (zh:…
      【交易簿】惺惺相惜：李飞飞与苏姿丰的82亿美元联手 财新数据
  - (2026-10-12) 今日开盘：两市双双低开 沪指跌幅0.18% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9ISGYzLU9WbE1Gc2MxMTVVQ3NaTFBfTDhpU2djZ1hNYkVDcVQ1MkpXV0Rqdk5vU19zTFNRLURwc2o5LTJISWVQQmtnZHJ3YjVI] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.18% 财新

### Ukraine Theater (total-war monitoring) — 229 new of 533 total
  - (2026-10-11) [FIRMS] thermal anomaly 47.767, 33.465 (FRP 3.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-11 1034Z, FRP 3.74 MW
  - (2026-10-11) [FIRMS] thermal anomaly 44.045, 27.819 (FRP 5.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-11 1032Z, FRP 5.72 MW
  - (2026-10-11) [FIRMS] thermal anomaly 45.455, 34.298 (FRP 11.21 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-11 1032Z, FRP 11.21 MW
  - (2026-10-11) [FIRMS] thermal anomaly 44.179, 28.305 (FRP 3.32 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-11 1032Z, FRP 3.32 MW
  - (2026-10-11) [FIRMS] thermal anomaly 45.606, 34.664 (FRP 3.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-11 1032Z, FRP 3.29 MW
  - (2026-10-11) [FIRMS] thermal anomaly 44.038, 27.166 (FRP 4.44 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-11 1032Z, FRP 4.44 MW

### State-Level News — 176 new of 293 total
  - (2026-10-12) [Alaska] Employment First Awareness Week 2026
      WHEREAS, Alaska became an Employment First state in 2014 with the goal of ensuring that individuals with disabilities have information, training, resources, and programs that increase opportunities for meaningful, integr…
  - (2026-10-12) [California] ICE arrests alarm California’s community colleges. How much can campus officials do?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/100926_SD-City-College_AH_CM_04.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-10-12) [Connecticut] Will the US Supreme Court’s recent ruling affect CT absentee voting?
      <img width="1024" height="702" src="https://ctmirror.org/wp-content/uploads/2025/10/AP25135471977857-1024x702.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority…
  - (2026-10-12) [Connecticut] CT’s primary care shortage is costing lives
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2017/03/doctors-office.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctmirror…
  - (2026-10-12) [Delaware] Get Involved: Dover data center, NCC impact fees, more
      <img width="1000" height="800" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/10/Get-Involved-10.12-10.16.png?fit=1000%2C800&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-10-12) [Delaware] ‘Beyond the Headlines’: The new Spotlight Delaware en Español team
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/10/Nathaly-Cristal-podcast.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### Local News: St. Louis + Atlanta — 162 new of 199 total
  - (2026-10-12) [St. Louis] Daylight saving time: When will clocks 'fall back' next month?
      Daylight saving time is coming up, meaning clocks in the U.S. will "fall back" an hour for the colder months.
  - (2026-10-12) [St. Louis] Broken Lizard comedy group discusses writing and starring in 'Super Troopers 3'
      Jay Chandrasekhar, Kevin Heffernan, Steve Lemme, Paul Soter and Erik Stolhanske discuss writing and starring in "Super Troopers 3."
  - (2026-10-12) [St. Louis] Tony Goldwyn previews 26th season of 'Law & Order'
      Tony Goldwyn, who stars as district attorney Nick Baxter, previews the 26th season of "Law & Order," with new episodes airing Thursdays at 10 p.m. ET on NBC.
  - (2026-10-12) [St. Louis] Inside one of Texas’ most fascinating small towns
      People from more than 20 nationalities call this tiny Texas town home. Here’s what brought them together.
  - (2026-10-12) [St. Louis] Is mail delivered on Columbus Day? What to know about Monday's holiday
      Here's what to know about mail delivery on Monday's federal holiday.
  - (2026-10-12) [St. Louis] What to know about Pope Leo’s planned lung nodule surgery
      Pope Leo XIV is scheduled to have an operation this week to remove “a localized nodule” in his lung that was “detected at a very early stage.” Here's what to know.

### U.S. Weather + Severe / Climate Outlooks — 110 new of 111 total
  - (2026-10-12) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-12) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 12 at 7:21AM AKDT until October 12 at 1:00PM AKDT by NWS Fairbanks AK
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Fairbanks Metro Area. * WHEN...Until 1 PM AKDT this afternoon. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-10-12) [Moderate] Special Weather Statement: Special Weather Statement issued October 12 at 9:13AM MDT by NWS Great Falls MT
      Areas of fog, which was reducing visibility to generally 1 to 3 miles at most locations, was ongoing over the plains of Central and North Central Montana. Localized reductions to near one quarter of a mile are possible n…
  - (2026-10-12) [Severe] Flood Warning: Flood Warning issued October 12 at 11:06AM EDT until October 13 at 12:00AM EDT by NWS Greenville-Spartanburg SC
      ...The Flood Warning continues for the following rivers in North Carolina... French Broad River At at Grove Bridge Rd in Blantyre affecting Henderson and Transylvania Counties. .Excessive runoff from widespread 4 to 6 in…
  - (2026-10-12) [Moderate] Gale Warning: Gale Warning issued October 12 at 10:02AM CDT until October 12 at 7:00PM CDT by NWS Duluth MN
      * WHAT...Northeast winds 20 to 25 kt with gusts up to 35 kt and waves 7 to 10 ft. * WHERE...Portions of Lake Superior. * WHEN...Until 7 PM CDT this evening. * IMPACTS...Strong winds will cause hazardous waves which could…
  - (2026-10-12) [Moderate] Gale Warning: Gale Warning issued October 12 at 11:00AM EDT until October 13 at 1:00AM EDT by NWS Marquette MI
      * WHAT...Northeast winds around 25 kt with gusts up to 35 kt and waves 9 to 11 ft expected. * WHERE...Lake Superior west of a line from Saxon Harbor WI to Grand Portage MN beyond 5NM. * WHEN...Until 1 AM EDT /midnight CD…

### Ukrainian Internal News (national + local Kyiv) — 66 new of 137 total
  - (2026-10-12) Мерц назвав неприйнятним рішення Трампа закупати дизель у Путіна | LEDE: Канцлер Німеччини Фрідріх Мерц висловив незгоду з президентом США Дональдом Трампом у зв'язку з угодою з господарем Крем] (uk:…
      Канцлер Німеччини Фрідріх Мерц висловив незгоду з президентом США Дональдом Трампом у зв'язку з угодою з господарем Кремля Владіміром Путіним щодо експорту дизельного палива.
  - (2026-10-12) ЄС схвалив грантову програму на 115 млн євро для оборонних розробок, відкриту й для України | LEDE: Євросоюз створив програму AGILE із бюджетом 115 млн євро для підтримки інноваційних оборонних] (uk:…
      Євросоюз створив програму AGILE із бюджетом 115 млн євро для підтримки інноваційних оборонних проєктів малих і середніх підприємств, у якій зможуть брати участь українські компанії.
  - (2026-10-12) Створити експертну групу, яка проведе конкурс в Рахункову палату: спроба №3 | LEDE: Парламент втретє голосуватиме за створення дорадчої групи експертів для оновлення складу Рахункової палати, я] (uk:…
      Парламент втретє голосуватиме за створення дорадчої групи експертів для оновлення складу Рахункової палати, яка працює без більшості членів майже 2 роки.
  - (2026-10-12) Прем'єр Литви: слід попросити Україну атакувати більшу кількість дата-центрів в РФ | LEDE: Прем'єр-міністр Литви Міндаугас Сінкявічюс вважає, що союзникам України слід попросити президента Воло] (uk:…
      Прем'єр-міністр Литви Міндаугас Сінкявічюс вважає, що союзникам України слід попросити президента Володимира Зеленського завдати ударів по більшій кількості дата-центрів у Росії.
  - (2026-10-12) Єврокомісарка привітала закон України про освіту нацменшин і підтвердила відкриття кластерів | LEDE: Єврокомісарка з питань розширення Марта Кос привітала крок Верховної Ради України, яка 12 жо] (uk:…
      Єврокомісарка з питань розширення Марта Кос привітала крок Верховної Ради України, яка 12 жовтня проголосувала за зміни до закону про освіту для національних меншин.
  - (2026-10-12) Британія не підтримує дизельну угоду Трампа з Путіним | LEDE: Велика Британія не підтримує угоду президента США Дональда Трампа з кремлівським правителем Владіміром Путіним щодо закупівлі мільй] (uk:…
      Велика Британія не підтримує угоду президента США Дональда Трампа з кремлівським правителем Владіміром Путіним щодо закупівлі мільйонів тонн дизельного палива.

### GDACS — global disaster alerts — 50 new of 100 total
  - (2026-10-11) [Green] Flood in Nepal
      Flood · Green alert · Nepal · Magnitude 0
  - (2026-10-12) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 4.6M, Depth:10km
  - (2026-10-12) [Green] Earthquake in Mid-Indian Ridge
      Earthquake · Green alert · Mid-Indian Ridge · Magnitude 4.8M, Depth:10km
  - (2026-10-12) [Green] Earthquake in Panama
      Earthquake · Green alert · Panama · Magnitude 4.5M, Depth:10km
  - (2026-10-12) [Green] Tropical Cyclone TWENTYEIGHT-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 56 km/h)
  - (2026-10-12) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.6M, Depth:55.223km

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 61 total
  - (2026-10-12) [BleepingComputer] Cyberattack shuts down refrigerators at French supermarkets
      Attackers remotely defrosted refrigerators at multiple French supermarket chains overnight in a cyberattack that reportedly targeted Danfoss refrigeration controllers. [...]
  - (2026-10-12) [BleepingComputer] Inside AvisLoader: A Windows Malware Loader Built to Resist Disruption
      A new Windows malware loader called AvisLoader uses encrypted peer-to-peer communications to make command-and-control infrastructure harder to disrupt. Varonis researchers explain how the malware uses ClickFix delivery,…
  - (2026-10-12) [BleepingComputer] Retail giant Ahold Delhaize takes systems offline after cyberattack
      Retail giant Ahold Delhaize, one of the world's largest food retail chains, confirmed today that it had to take some systems offline in response to a "cybersecurity incident" affecting its network. [...]
  - (2026-10-12) [BleepingComputer] GitLab warns of max severity code execution vulnerability
      GitLab warned users today to immediately patch a maximum-severity vulnerability in the CI/CD Regular Expression Compiler that could let remote attackers run arbitrary code on targeted instances. [...]
  - (2026-10-12) [BleepingComputer] Microsoft: Windows 11 23H2 reaches end of support in 30 days
      Microsoft has reminded customers that systems running Windows 11 23H2 Enterprise, Education, and IoT Enterprise editions will stop receiving security updates next month. [...]
  - (2026-10-12) [The Hacker News] Bring Your Own Agent: Your Employees' Assistants Are Already Logged In
      The personal AI agents rollout is going about as smoothly as expected: Amazon now blocks Meta's Muse because it doesn't identify itself as a bot while browsing; Instinct keeps raising privacy concerns; and the horror sto…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-10-12) JAF1TA (Bulgaria)
      icao24: 4520ce · position: (45.1574, -0.6633) · alt: 10980m · 840km/h
  - (2026-10-12) JAF3LC (Bulgaria)
      icao24: 4520aa · position: (33.4068, -5.9818) · alt: 10957m · 728km/h
  - (2026-10-12) PAT597 (United States)
      icao24: adfe4c · position: (36.1937, -94.5652) · alt: 5486m · 432km/h
  - (2026-10-12) PAT601 (United States)
      icao24: adfe95 · position: (35.8404, -82.7927) · alt: 7620m · 529km/h
  - (2026-10-12) PAT440 (United States)
      icao24: adfe99 · position: (31.7741, -95.8793) · alt: 7315m · 485km/h
  - (2026-10-12) PAT611 (United States)
      icao24: adfe8d · position: (35.6308, -82.3546) · alt: 7620m · 533km/h

### USGS earthquakes (M4.5+, past day) — 26 new of 26 total
  - (2026-10-12) M 5.5 - 122 km W of Neiafu, Tonga
      M5.5 · 122 km W of Neiafu, Tonga · depth 195.212 km
  - (2026-10-12) M 5.4 - Mid-Indian Ridge
      M5.4 · Mid-Indian Ridge · depth 10 km
  - (2026-10-11) M 5.2 - 152 km W of Gorontalo, Indonesia
      M5.2 · 152 km W of Gorontalo, Indonesia · depth 111.257 km
  - (2026-10-11) M 5.2 - 101 km SSW of Severo-Kuril’sk, Russia
      M5.2 · 101 km SSW of Severo-Kuril’sk, Russia · depth 83.386 km
  - (2026-10-12) M 4.8 - Mid-Indian Ridge
      M4.8 · Mid-Indian Ridge · depth 10 km
  - (2026-10-12) M 4.8 - southern East Pacific Rise
      M4.8 · southern East Pacific Rise · depth 10 km

### Court opinions of consequence (federal & state) — 19 new of 40 total
  - (2026-10-09) Hawaii Supreme Court: R.H. v. Hayashi
  - (2026-10-08) Hawaii Supreme Court: Estalilla v. Administrative Director of the Courts
  - (2026-10-06) Hawaii Supreme Court: State v. Chau
  - (2026-10-05) Hawaii Supreme Court: The Bank of New York Mellon Trust Company v. Eala
  - (2026-10-02) U.S. Court of Appeals, 2nd Cir.: United States v. Acevedo
  - (2026-10-02) U.S. Court of Appeals, 1st Cir.: Pena-Torres v. University of Science, Arts and Tech

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-10-12) LoL: BNK FEARX vs JD Gaming (BO5) - Demacia Cup Global Invitational Playoffs
      yes price: 100% · 24h volume: $3,218,530 · resolves 2026-10-12
  - (2026-10-12) LoL: BNK FEARX vs JD Gaming - Game 3 Winner
      yes price: 100% · 24h volume: $1,239,154 · resolves 2026-10-12
  - (2026-10-12) LoL: BNK FEARX vs JD Gaming - Game 4 Winner
      yes price: 0% · 24h volume: $1,010,981 · resolves 2026-10-12
  - (2026-10-12) Olbia: Lorenzo Carboni vs Mackenzie McDonald
      yes price: 100% · 24h volume: $908,862 · resolves 2026-10-19
  - (2026-10-12) Spread: Rams (-3.5)
      yes price: 46% · 24h volume: $640,507 · resolves 2026-10-13
  - (2026-10-12) Wuhan Tennis Open: Alexandra Eala vs Han Shi
      yes price: 16% · 24h volume: $587,687 · resolves 2026-10-19

### Paper Trading Scorecard — 15 new of 68 total
  - (2026-10-12) [Manifold] Will SpaceXSI rename itself back to SpaceXAI by end of 2026?
  - (2026-10-12) [Manifold] Kommer Theodor få Jonte skjuten inom 10 år av sin lillebror???
  - (2026-10-12) [Manifold] Will an AI be able to generate a high-quality PhD thesis to a single prompt by EOY 2027 in any formal scientific field?
  - (2026-10-12) [Manifold] Will Russia control the world globally before 2031?
  - (2026-10-12) [Manifold] Will Russia invade all continents and start wars in every continent before 2031?
  - (2026-10-12) [Manifold] Will all covid vaccines be pulled off the market before 2030?

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 113 total
  - (2026-10-11) [EU Sanctions] Restrictive measures against the proliferation and use of chemical weapons
      Last amended: 2026-10-11. Acronym: -.
  - (2026-10-12) [UN Sanctions] page checksum 5bf218f2ca8b
      Active UN Security Council sanctions committees page snapshot
  - (2026-10-11) [USTR] - United States Trade Representative (.gov)
      United States Trade Representative (.gov)
  - (2026-10-11) [USTR] - United States Trade Representative (.gov)
      United States Trade Representative (.gov)

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-12) [Marginal Revolution] Michael Woodford, Nobel Laureate
      I think of Michael Woodford as the kind of economist who studies something very specific very intensively and tries to get it just right. But in his case he is not studying something small and irrelevant, he is studying…
  - (2026-10-12) [Marginal Revolution] Robert E. Hall, Nobel Laureate
      Alex has already covered this, I will add a few remarks. First, every Bob Hall paper is interesting! Only a handful of economists can say the same. Every paper has an idea, and some sort of novel contribution. His lesser…
  - (2026-10-12) [Marginal Revolution] The Nobel Prize Goes to Robert Hall and Michael Woodford
      Twenty-five years ago Tyler told me he thought Robert Hall should win the Nobel. He has been a contender for so long today’s award was a surprise! Hall has an unusual number of unexpectedly creative papers. His best know…

### State Legislative Action — 1 new of 5 total
  - (2026-10-12) [ingest error] District of Columbia: HTTPError
      404 Client Error: Not Found for url: https://v3.openstates.org/bills?jurisdiction=District+of+Columbia&updated_since=2026-10-10&include=sponsorships&include=abstracts&per_page=20&page=2&sort=updated_desc

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-12) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=26, 14d-median=26; carrying terms: proposed, final, order, regulatory, national, certain, action, model, safety, provisions, proposes, amending
- state_bills: today=5, 7d-median=74, 14d-median=78; carrying terms: education, school, administration, district, include, state, program, providing, relating, amendment, grant, motor
- state_news: today=293, 7d-median=667, 14d-median=682; carrying terms: along, battle, content, rally, client, azgovernor, california, fight, healthcare, reports, carolina, legal
- local_news: today=199, 7d-median=233, 14d-median=229; carrying terms: across, content, early, suspect, appeared, hospitalized, still, arrested, state, color, inside, atlanta
- foreign_news: today=980, 7d-median=1018, 14d-median=1018; carrying terms: denies, boxing, systems, vnexpress, fight, further, minister, internacional, military, facilities, positive, duterte
- chinese_internal: today=292, 7d-median=284, 14d-median=276; carrying terms: cbmickfvx, china, cbmibkfvx, color, cbmia, cbmiakfvx, blank, cbmix, cbmiyefvx, articles, investors, lxtfb
- russian_internal: today=875, 7d-median=1074, 14d-median=1052; carrying terms: politico, raquo, error, novayagazeta, europe, blank, istories, server, client, russian, novaya, times
- ukrainian_internal: today=137, 7d-median=136, 14d-median=136; carrying terms: across, foreign, missiles, building, drone, europe, client, early, systems, troops, minister, council
- ukraine_theater: today=533, 7d-median=533, 14d-median=572; carrying terms: twxou, zuwwnor, umvmttxffwldswtntofjzbnjudnz, ajhws, rktrdjf, qlzjvhvhcktym, cbmir, rzsznrzgrilw, systems, storage, lxtfbintb, concept
- paper_bets: today=68, 7d-median=110, 14d-median=122; carrying terms: anthropic, supervolcano, least, henry, prime, decrease, receiving, population, season, jackson, participation, world
- weather: today=111, 7d-median=141, 14d-median=142; carrying terms: along, across, gusts, tampa, early, possible, baltimore, afdmeg, monday, short, night, temperatures
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexuseu, growth, walcl, recession, spread, dexchus, balance, nonfarm, unrate, crude, latest, treasury
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: agriculture, credit, close, range, china, crypto, russell, silver, corporate, bitcoin, natural, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=113, 7d-median=111, 14d-median=114; carrying terms: foreign, acronym, ukraine, content, republic, schools, democratic, solutions, involvement, contract, zimbabwe, eastern
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, error, https, quiverquant, congresstrading, httperror, quantitative, client, unauthorized
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=40, 7d-median=60, 14d-median=60; carrying terms: state, supreme, appeals, corporation, county, court, company, board, roman, union, william, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, financial, accno, reporting, trust, holdings, group, robert, james, natera, technology
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, booker, shawn, lindsey, graham, michael, warner, platner, cooper, trone, krishnamoorthi, ossoff
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=49, 14d-median=37; carrying terms: english, chinese, themes, perimeter, china, sanctions, spanish, russian, russia, italian, romanian, french
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, germany, france, kingdom, ground, bulgaria, eagle, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: along, aboard, across, indicating, summarizes, index, presented, global, spain, brings, adult, update
- cisa_kev: today=11, 7d-median=13, 14d-median=17; carrying terms: netscaler, multiple, remediation, within, buffer, bounds, injection, restriction, vulnerability, cisco, citrix, write
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100
- usgs_quakes: today=26, 7d-median=18, 14d-median=16; carrying terms: depth, japan, indonesia, islands, south, region, russia, tonga, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: donetsk, volume, league, champions, shakhtar, championship, price, resolves, election, presidential, october, winner
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, https, class, conversableeconomist, revolution, marginal, economist, taxes, property, income, school, pattern
- tech_news: today=61, 7d-median=60, 14d-median=58; carrying terms: cybersecurity, engineers, across, report, systems, review, software, ransomware, weekday, weekly, technology, breach
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: steube, board, gilbert, coons, nellie, jimmy, coleman, merkley, rounds, bergman, fletcher, tiffany
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, either, markets, placed, decision, placement, module, market, today, converges, paper, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] ECB press: Philip R. Lane: Diagnostic Challenges for ECB Monetary Policy
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*