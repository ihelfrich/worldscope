# WORLDSCOPE morning brief — 2026-11-19

## Headline
3686 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (869) · Russian Internal News (state + in-exile) (747) · State-Level News (381) · World leaders & government officials (324) · Chinese Internal News (254) · Local News: St. Louis + Atlanta (214) · GDELT GKG — themes / entities / watch areas (150) · U.S. Weather + Severe / Climate Outlooks (114) · World News (by country, top stories) (106) · Ukraine Theater (total-war monitoring) (84) · Ukrainian Internal News (national + local Kyiv) (81) · GDACS — global disaster alerts (50)

## What changed today
### International News + Multilateral Institutions — 869 new of 1057 total
  - (2026-11-19) [Global] This is a remarkable diplomatic moment for China's Xi - but it comes with pitfalls
      The meeting comes with challenges as there are things Xi does not appear keen to discuss with Putin and Trump.
  - (2026-11-18) [Global] Inside the old gas pipeline where Ukraine is fighting an underground war with Russia
      Watch: The BBC's Jonathan Beale joins Ukrainian forces taking the battle below ground and out of sight of Russian drones.
  - (2026-11-18) [Global] Myanmar faces historic genocide verdict at UN court over Rohingya massacres
      No state has ever been found guilty by an international court of committing genocide.
  - (2026-11-19) [Global] AI giant Anthropic valued at $1.5 trillion ahead of stock market debut
      The company behind the Claude chatbot will become one of the most valuable firms in the world.
  - (2026-11-19) [Global] Van Gogh painting sells for record $190.4m after row over its Nazi history
      Châtaigniers en fleurs was painted in 1890 in the final two months of Vincent van Gogh's life.
  - (2026-11-19) [Global] Crimean Bridge attacked again, Russia says
      The head of Crimea said traffic was suspended after another attack on the link between Russia and the occupied territory.

### Russian Internal News (state + in-exile) — 747 new of 1134 total
  - (2026-11-19) В США 25-летнего россиянина обвинили в слежке за сотрудниками Palantir. Он фотографировал их ноутбуки в кофейне и следил за их передвижением | LEDE: В США арестовали 25-летнего россиянина Иг] (ru: В С…
      В США арестовали 25-летнего россиянина Игоря Дью, которого подозревают в слежке за одной из технологических компаний.
  - (2026-11-19) ЕС запретил жителям России участвовать в программе для студентов и преподавателей Erasmus+ | LEDE: Жители России и российские организации не могут участвовать в европейской программе для сту] (ru: ЕС…
      Жители России и российские организации не могут участвовать в европейской программе для студентов и преподавателей Erasmus+.
  - (2026-11-19) Украинские беспилотники атаковали резервуары для хранения нефти в Татарстане | LEDE: Дроны ВСУ в ночь на 19 ноября нанесли удары по нефтяным резервуарам вблизи Альметьевска, сообщила пресс-с] (ru: Укр…
      Дроны ВСУ в ночь на 19 ноября нанесли удары по нефтяным резервуарам вблизи Альметьевска, сообщила пресс-служба главы Татарстана.
  - (2026-11-19) Движение поездов по Крымскому мосту остановлено после нового удара | LEDE: Крымский мост, связывающий аннексированный полуостров с Краснодарским краем России, вновь атакован украинскими воен] (ru: Дви…
      Крымский мост, связывающий аннексированный полуостров с Краснодарским краем России, вновь атакован украинскими военными. Движение поездов по мосту остановлено, заявил Минтранс РФ.
  - (2026-11-19) Двусторонняя встреча Путина и Трампа на саммите в Шэньчжэне продолжалась менее часа | LEDE: Президенты США и России Дональд Трамп и Владимир Путин встретились «на полях» саммита АТЭС в китай] (ru: Дву…
      Президенты США и России Дональд Трамп и Владимир Путин встретились «на полях» саммита АТЭС в китайском Шэньчжэне. Встреча продолжалась около 40 минут.
  - (2026-11-19) Разработчик Claude проводит крупнейшее IPO в истории. Таким образом, рекорд SpaceX продержался лишь пять месяцев. За что Anthropic так любят инвесторы? Они не боятся, что пузырь ИИ лопнет? И ре] (ru:…
      Разработчик семейства больших языковых моделей Claude — Anthropic — 19 ноября проводит первичное размещение акций (IPO). Стоимость акций установят на уровне 83 долларов за штуку. От выхода на биржу Nasdaq компания может…

### State-Level News — 381 new of 768 total
  - (2026-11-18) [Alabama] Operation Iron Ruck Day
      Download
  - (2026-11-19) [California] First Partner Siebel Newsom hosts California Love, California Strong community event celebrating California agriculture and farming communities
      Source
  - (2026-11-18) [California] Governor Newsom addresses crisis facing boys and men at national summit in Washington, DC
      Source
  - (2026-11-18) [California] Governor Newsom’s nation-leading AI safety framework is getting even stronger as California releases next steps on mandatory safety standards and oversight
      Source
  - (2026-11-19) [California] Becerra faces a $2 billion budget deficit as potential AI bust looms
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/110326_Becerra-Watch-Party_FG_CM_05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-11-19) [California] Newsom touts an AI kill switch to halt dangerous OpenAI, Anthropic releases
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/092926-OpenAI-AP-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="A lar…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 254 new of 331 total
  - (2026-11-18) Nvidia to Stop Selling Advanced AI Chips to China - Caixin Global
      Nvidia to Stop Selling Advanced AI Chips to China Caixin Global
  - (2026-11-18) Yuan Bond Financing Demand Rises in Central Asia, Southeast Asia - Caixin Global
      Yuan Bond Financing Demand Rises in Central Asia, Southeast Asia Caixin Global
  - (2026-11-19) CX Daily: How Chinese Counterfeit Busters Turned From Crusaders to Criminals - Caixin Global
      CX Daily: How Chinese Counterfeit Busters Turned From Crusaders to Criminals Caixin Global
  - (2026-11-18) Hong Kong’s Multimillionaire Population Rises to 412,000 - Caixin Global
      Hong Kong’s Multimillionaire Population Rises to 412,000 Caixin Global
  - (2026-11-18) Xi and Putin Stress Asia-Pacific Cooperation at Shenzhen Meeting - Caixin Global
      Xi and Putin Stress Asia-Pacific Cooperation at Shenzhen Meeting Caixin Global
  - (2026-11-18) UBS Sees China’s Growth Holding Near 4.6% in 2027 - Caixin Global
      UBS Sees China’s Growth Holding Near 4.6% in 2027 Caixin Global

### Local News: St. Louis + Atlanta — 214 new of 266 total
  - (2026-11-18) [St. Louis] St. Louis police chief keeps $110,000 raise in shorter contract that drops retirement perk
  - (2026-11-18) [St. Louis] Webster Groves pediatric mental health hospital to open in December
  - (2026-11-18) [St. Louis] Sam Page tries again to dismiss criminal case over April 2025 mailers, flyers
  - (2026-11-18) [St. Louis] Invest STL helps Black residents reshape historic neighborhood narratives through storytelling
  - (2026-11-19) [St. Louis] Where in the Lou – 11/19/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-11-18) [St. Louis] Photos: St. Louis Family Playdate at Garden Glow
      On November 15, St. Louis Magazine hosted a Family Playdate at the Missouri Botanical Garden, presented by Royal Banks of Missouri and sponsored by Lutheran Elementary School Association. Families enjoyed a magical eveni…

### GDELT GKG — themes / entities / watch areas — 150 new of 150 total
  - (2026-11-19) [Russia oil sanctions perimeter · themes] Trump meets Putin for first time in over a year
      businesstimes.com.sg · English · tone -1.76211453744493 · 1 other outlets
  - (2026-11-19) [Russia oil sanctions perimeter · themes] Ukraine Invasion Day 1,729: Third Kerch Bridge Strike. Polish False Flag?
      dailykos.com · English · tone -4.78214665249734 · 1 other outlets
  - (2026-11-19) [Russia oil sanctions perimeter · themes] Zelenskyy says he expects debrief from US envoys on Trump's talks with Xi and Putin
      euronews.com · English · tone -4.55580865603645
  - (2026-11-19) [Russia oil sanctions perimeter · near] Trump says he would not strike Ukraine deal with Putin without Zelensky's input
      hindustantimes.com · English · tone -1.86335403726708 · 29 other outlets
  - (2026-11-19) [Russia oil sanctions perimeter · near] Russian-installed official says Crimea bridge traffic suspended after 2nd Ukrainian attack
      aa.com.tr · English · tone -6.95652173913043 · 12 other outlets
  - (2026-11-19) [Russia oil sanctions perimeter · near] Ukraine blew up Putin's bridge using relay drones to bypass Starlink limits
      wn.com · English · tone -5.35714285714286 · 9 other outlets

### U.S. Weather + Severe / Climate Outlooks — 114 new of 116 total
  - (2026-11-19) [Moderate] Special Weather Statement: Special Weather Statement issued November 19 at 12:00AM PST by NWS San Francisco CA
      At midnight PST, Doppler radar was tracking a shower over Aptos, or 7 miles east of Santa Cruz, moving northeast at 25 mph. HAZARD...Wind gusts up to 30 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty win…
  - (2026-11-19) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-19) [Severe] High Wind Watch: High Wind Watch issued November 19 at 12:54AM MST until November 20 at 4:00PM MST by NWS Pueblo CO
      * WHAT...Southwest winds 25 to 40 mph with gusts up to 75 mph possible across the southern Sangre De Cristo mountains, to up to 65 mph along the I-25 corridor in Huerfano county. * WHERE...Southern Sangre de Cristo Mount…
  - (2026-11-19) [Moderate] Gale Warning: Gale Warning issued November 19 at 1:54AM CST until November 19 at 12:00PM CST by NWS Mobile AL
      * WHAT...For the Gale Warning, east winds 25 to 30 kt with gusts to 35 kt and seas 7 to 10 ft. For the Small Craft Advisory, east winds 20 to 30 kt and seas 7 to 10 ft expected. * WHERE...Waters from Pensacola FL to Pasc…
  - (2026-11-19) [Moderate] Rip Current Statement: Rip Current Statement issued November 19 at 1:53AM CST until November 21 at 6:00PM CST by NWS Mobile AL
      * WHAT...For the High Rip Current Risk, dangerous rip currents. For the High Surf Advisory, large breaking waves of 5 to 7 feet in the surf zone. * WHERE...In Alabama, Mobile Coastal and Baldwin Coastal Counties. In Flor…
  - (2026-11-19) [Severe] Flood Watch: Flood Watch issued November 19 at 2:51AM EST until November 19 at 7:00PM EST by NWS Miami FL
      Bands of scattered showers and storms, on the north side of developing low pressure, are expected to move inland across south Florida today. The highest probability of being impacted by heavy rain will be across Broward…

### World News (by country, top stories) — 106 new of 106 total
  - (2026-11-19) [Brazil] Mariah Carey worries fans with "stiff" performance in Brazil
      bgnes.com · English · 1 other outlets ran this story
  - (2026-11-19) [Brazil] Brazil's Senate approves Lula's $10 billion fiscal package after costly election spending
      thepeterboroughexaminer.com · English · 1 other outlets ran this story
  - (2026-11-19) [Brazil] Kazakhstan and Brazil agree to prepare civil aviation cooperation memorandum
      trend.az · English
  - (2026-11-19) [Brazil] Aclara CEO weighs Brazil rare-earth plant, says incentives key
      mining.com · English
  - (2026-11-19) [Brazil] 'Historic encounter': Uncontacted indigenous people in Brazil ask villagers for food
      hindustantimes.com · English
  - (2026-11-19) [Brazil] Honda reveals Lance Stroll battery issue was expected despite Brazilian GP countermeasures
      planetf1.com · English

### Ukraine Theater (total-war monitoring) — 84 new of 277 total
  - (2026-11-18) [Liveuamap] At least 8 powerful explosions were reported in Kerch – Kerch, Crimea - Liveuamap
      At least 8 powerful explosions were reported in Kerch – Kerch, Crimea Liveuamap
  - (2026-11-18) [Liveuamap] Ukraine used its own… – Kerch, Crimea - Liveuamap
      Ukraine used its own… – Kerch, Crimea Liveuamap
  - (2026-11-17) [Liveuamap] Video of destroyed Kerch bridge – Kerch, Crimea - Liveuamap
      Video of destroyed Kerch bridge – Kerch, Crimea Liveuamap
  - (2016-04-27) [Liveuamap] Israel and Gaza live map: news today | Liveuamap - Liveuamap
      Israel and Gaza live map: news today | Liveuamap Liveuamap
  - (2026-11-18) [Liveuamap] TV correspondent: Man kills 7 family members… - Liveuamap
      TV correspondent: Man kills 7 family members… Liveuamap
  - (2026-11-18) [Liveuamap] Three women among… – Center District, Israel - Liveuamap
      Three women among… – Center District, Israel Liveuamap

### Ukrainian Internal News (national + local Kyiv) — 81 new of 139 total
  - (2026-11-19) Литва розробила план укріплення кордону з Калінінградською областю Росії | LEDE: Міністерство внутрішніх справ Литви підготувало план зміцнення кордону з Калінінградською областю Росії, в якому] (uk:…
      Міністерство внутрішніх справ Литви підготувало план зміцнення кордону з Калінінградською областю Росії, в якому передбачається встановлення фізичних бар'єрів на окремих ділянках та застосування інших заходів охорони кор…
  - (2026-11-19) Трамп і Сі Цзіньпін завершили двосторонню зустріч у Китаї | LEDE: Президент США Дональд Трамп і лідер Китаю Сі Цзіньпін завершили двосторонні переговори на полях саміту АТЕС у Шеньчжені, які тр] (uk:…
      Президент США Дональд Трамп і лідер Китаю Сі Цзіньпін завершили двосторонні переговори на полях саміту АТЕС у Шеньчжені, які тривали понад годину.
  - (2026-11-19) У США росіянина звинуватили у шпигунстві за компанією, що надає допомогу Україні | LEDE: ] (uk: У США росіянина звинуватили у шпигунстві за компанією, що надає допомогу Україні)
  - (2026-11-19) У Кремлі стверджують, що Україна була головною темою зустрічі Путіна і Трампа | LEDE: Помічник правителя Росії Юрій Ушаков заявив, що під час двосторонньої зустрічі в Китаї 19 листопада Володим] (uk:…
      Помічник правителя Росії Юрій Ушаков заявив, що під час двосторонньої зустрічі в Китаї 19 листопада Володимир Путін і президент США Дональд Трамп тема війни проти України була головною.
  - (2026-11-19) Трамп розхвалив дружбу із Сі Цзіньпіном перед тристороннім самітом із Путіним | LEDE: Президент США Дональд Трамп під час двосторонньої зустрічі з лідером Китаю Сі Цзіньпіном у Шеньчжені заявив] (uk:…
      Президент США Дональд Трамп під час двосторонньої зустрічі з лідером Китаю Сі Цзіньпіном у Шеньчжені заявив, що обидві країни будуть дедалі тіснішу дружбу і "це дивовижно".
  - (2026-11-19) Заступник глави Пентагону покинув "Рамштайн" після критики України через удари по РФ | LEDE: Заступник міністра оборони США з питань політики Елбрідж Колбі достроково покинув засідання у формат] (uk:…
      Заступник міністра оборони США з питань політики Елбрідж Колбі достроково покинув засідання у форматі "Рамштайн" у Брюсселі після того, як розкритикував українські далекобійні удари по Росії.

### GDACS — global disaster alerts — 50 new of 100 total
  - (2026-11-19) [Green] Earthquake in Ecuador
      Earthquake · Green alert · Ecuador · Magnitude 4.8M, Depth:69.493km
  - (2026-11-19) [Green] Earthquake in Tanzania
      Earthquake · Green alert · Tanzania · Magnitude 4.9M, Depth:10km
  - (2026-11-19) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.2M, Depth:10km
  - (2026-11-19) [Green] Earthquake in Tanzania
      Earthquake · Green alert · Tanzania · Magnitude 4.8M, Depth:10km
  - (2026-11-15) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 7006 ha
  - (2026-11-12) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 5573 ha

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 62 total
  - (2026-11-19) [The Hacker News] PHP Warns of Critical Security Flaws Affecting All Supported Versions, Fixes Coming November 19
      The maintainers of the PHP programming language on Wednesday issued an advisory announcing an upcoming security release that addresses critical flaws. The release is scheduled for November 19, 2026, between 2 and 2:30 p.…
  - (2026-11-19) [The Register] South Korea tries to out exam cheats with Extreme Emergency smartphone alert
      At least it’s less disruptive than an internet shutdown
  - (2026-11-19) [The Register] Chinese web giant Tencent says new US GPU ban ‘sets everyone back in China’
      Don’t hoist the Mission Accomplished banner, because company president thinks it also will spur China’s chip biz into action
  - (2026-11-19) [TechCrunch] Microsoft CEO Satya Nadella explains why he asked 60K employees to quit
      Microsoft CEO Satya Nadella explained why he offered buyouts to 60,000 of his employees in October, essentially urging them to voluntarily quit, rather than reducing the workforce via another massive layoff. The short an…
  - (2026-11-19) [TechCrunch] Elon Musk says: ‘I’m not MAGA’
      During his appearance Wednesday at The New York Times' DealBook Summit, Elon Musk said that he wasn't sure what the term "MAGA" meant and also commented that he felt "pretty foolish" for having spent so much money during…
  - (2026-11-18) [BleepingComputer] Ukraine, FBI arrest ransomware gang members tied to $40M in ransoms
      Ukrainian authorities, working with the FBI, have arrested four suspected members of an international ransomware organization linked to more than $40.5 million in ransom payments from at least 28 companies worldwide. [..…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-19) [Ainscow Robert] Form 4 (Reporting)
      filed 2026-11-19 02:59 UTC · role: Reporting — Filed: 2026-11-18 AccNo: 0001477932-26-007158 Size: 5 KB
  - (2026-11-19) [ASP Isotopes Inc.] Form 4 (Issuer)
      filed 2026-11-19 02:59 UTC · role: Issuer — Filed: 2026-11-18 AccNo: 0001477932-26-007158 Size: 5 KB
  - (2026-11-19) [Bowen Eric Austin] Form 4 (Reporting)
      filed 2026-11-19 02:50 UTC · role: Reporting — Filed: 2026-11-18 AccNo: 0001493152-26-053134 Size: 5 KB
  - (2026-11-19) [WRAP TECHNOLOGIES, INC.] Form 4 (Issuer)
      filed 2026-11-19 02:50 UTC · role: Issuer — Filed: 2026-11-18 AccNo: 0001493152-26-053134 Size: 5 KB
  - (2026-11-19) [Dalton Kristen Ann] Form 4 (Reporting)
      filed 2026-11-19 02:50 UTC · role: Reporting — Filed: 2026-11-18 AccNo: 0001526520-26-000186 Size: 10 KB
  - (2026-11-19) [TripAdvisor, Inc.] Form 4 (Issuer)
      filed 2026-11-19 02:50 UTC · role: Issuer — Filed: 2026-11-18 AccNo: 0001526520-26-000186 Size: 10 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-19) [Ukraine] Trump says he would not strike Ukraine deal with Putin without Zelensky's input
      domain: hindustantimes.com · language: English · tone: -1.86335403726708 · 122 other outlets ran this story
  - (2026-11-19) [Nigeria] Military airstrikes kill 21 ISWAP fighters, commanders in Borno Air strikes by the Nigerian military have left 21 Islamic State West Africa Province (ISWAP) fighters dead in separate operati…
      domain: nationalaccordnewspaper.com · language: English · tone: -7.31707317073171 · 103 other outlets ran this story
  - (2026-11-19) [United States] Taylor Swift leaves fans 'sobbing' as she returns to CMA Awards stage after 13-year hiatus to perform medley of two of her biggest hits
      domain: dailymail.com · language: English · tone: 4.61165048543689 · 76 other outlets ran this story
  - (2026-11-19) [China] Trump Addresses APEC Economic Leaders' Summit Ahead of Talks With Xi
      domain: theepochtimes.com · language: English · tone: 1.33155792276964 · 71 other outlets ran this story
  - (2026-11-19) [United States] Kansas Sen. Moran, victim's families urges safety aviation legislation after deadly D.C. crash
      domain: kctv5.com · language: English · tone: -0.362318840579711 · 70 other outlets ran this story
  - (2026-11-19) [United States] Women and Other Workers May Face Higher Fall Risk Under One-Size Ladder Programs -- Occupational Health & Safety
      domain: ohsonline.com · language: English · tone: 1.07296137339056 · 64 other outlets ran this story

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Wikidata leader-roster changes (48h) — 30 new of 45 total
  - (2026-11-19) [Cambodia] Norodom Sihamoni (Q57319) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/71270|batch #71270]]: add GND source to unsourced gender statements
  - (2026-11-19) [Cape Verde] José Maria Neves (Q57649) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/71270|batch #71270]]: add GND source to unsourced gender statements
  - (2026-11-19) [Democratic Republic of the Congo] Félix Tshisekedi (Q29032770) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/71270|batch #71270]]: add GND source to unsourced gender statements
  - (2026-11-19) [Jordan] Abdullah II of Jordan (Q57464) edited
      /* wbsetclaim-create:2||1 */ [[Property:P13613]]: 66314
  - (2026-11-19) [Peru] Keiko Fujimori (Q235137) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/71271|batch #71271]]: add GND source to unsourced gender statements
  - (2026-11-19) [Portugal] António José Seguro (Q1580316) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/71270|batch #71270]]: add GND source to unsourced gender statements

### Paper Trading Scorecard — 24 new of 78 total
  - (2026-11-19) [Polymarket] Will 4 Fed rate hikes happen in 2026?
      This market will resolve according to the exact amount of hikes of 25 basis points in 2026 by the Fed (including any hikes made during the December meeting). Emergency rate hikes outside of scheduled FOMC meetings will a…
  - (2026-11-19) [Polymarket] Will Nikesh Arora be the next CEO of NVIDIA?
      This market will resolve according to the first individual who is officially announced as the successor to Jensen Huang as CEO of NVIDIA Corporation by December 31, 2028, 11:59 PM ET. An announcement of a successor will…
  - (2026-11-19) [Polymarket] Will Teddy Riner be on the ballot for the 2027 French presidential election?
      The next French presidential election is currently expected to be held in April 2027. Prior to the election, the French Constitutional Council is expected to publish the official list of candidates to be included on the…
  - (2026-11-19) [Kalshi] Grand Theft Auto VII · Release Date
      Grand Theft Auto VII by Rockstar Games - USA
  - (2026-11-19) [Manifold] Will GTA VI generate more than $4.5 billion in revenue during its first week?
  - (2026-11-19) [Manifold] Free lottery (Hartle 1986)

### Government Action: Sanctions + Procurement + Foreign Agents — 21 new of 96 total
  - (2026-11-18) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-11-19) [USASpending] $27,995,864,149 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.
  - (2026-11-19) [USASpending] $22,674,726,734 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-11-19) [USASpending] $17,738,629,472 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy. Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-11-19) [USASpending] $3,531,500,000 → DAVIE DEFENSE INC.: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF F
      Agency: Department of Homeland Security. Description: THE PURPOSE OF THIS LETTER CONTRACT IS FOR THE DELIVERY OF FIVE (5) EACH MULTI-PURPOSE POLAR SHIP (MPPS-100) VESSELS HEREAFTER REFERRED TO AS ARCTIC SECURITY CUTTERS…
  - (2026-11-19) [USASpending] $2,366,486,183 → HARRIS CORPORATION: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING F
      Agency: Department of Transportation. Description: THE PURPOSE OF THIS DELIVERY ORDER AWARD IS TO ADD FUNDING FOR FTI TELECOMMUNICATIONS SERVICES.

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-11-19) NCR579 (United States)
      icao24: ad3c48 · position: (-6.1782, 106.7571) · alt: 6362m · 738km/h
  - (2026-11-19) GAF736 (Germany)
      icao24: 3f5d91 · position: (50.8633, 7.1227) · on ground · 4km/h
  - (2026-11-19) JAF4PT (Belgium)
      icao24: 44b438 · position: (35.984, -0.2648) · alt: 11269m · 774km/h
  - (2026-11-19) SAMU974 (France)
      icao24: 3a1e46 · position: (-20.9282, 55.396) · alt: 861m · 223km/h
  - (2026-11-19) GAF130 (Germany)
      icao24: 3ea1cc · position: (51.457, 7.2044) · alt: 9921m · 827km/h
  - (2026-11-19) JAF5PN (Belgium)
      icao24: 449683 · position: (35.9089, -2.6462) · alt: 7383m · 684km/h

### Campaign finance (FEC: top fundraisers + recent filings) — 14 new of 27 total
  - (2026-11-17) [F99] (unknown)
      cycle 2026 · filing #2048185
  - (2026-11-17) [F1] FEELY FOR CONGRESS
      cycle 2026 · filing #2048272
  - (2026-11-17) [F3X] ST ROCCO FOUNDATION
      cycle 2026 · filing #-1003877
  - (2026-11-17) [F6] DR. AISHA WAHAB FOR CONGRESS
      cycle 2026 · filing #2048329
  - (2026-11-17) [F99] (unknown)
      cycle 2026 · filing #2048195
  - (2026-11-17) [F99] (unknown)
      cycle 2026 · filing #2048181

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-11-18) M 6.1 - Pacific-Antarctic Ridge
      M6.1 · Pacific-Antarctic Ridge · depth 10 km
  - (2026-11-18) M 5.3 - 4 km NNW of Tsunagi, Japan
      M5.3 · 4 km NNW of Tsunagi, Japan · depth 10 km
  - (2026-11-18) M 5.3 - 149 km SSW of Merizo Village, Guam
      M5.3 · 149 km SSW of Merizo Village, Guam · depth 10 km
  - (2026-11-19) M 5.2 - 130 km W of Teluk Dalam, Indonesia
      M5.2 · 130 km W of Teluk Dalam, Indonesia · depth 10 km
  - (2026-11-18) M 5.2 - 169 km S of Attu Station, Alaska
      M5.2 · 169 km S of Attu Station, Alaska · depth 10 km
  - (2026-11-18) M 5.2 - 86 km NW of Ryōtsu-minato, Japan
      M5.2 · 86 km NW of Ryōtsu-minato, Japan · depth 10 km

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-11-18) U.S. Court of Appeals, 9th Cir.: Salazar v. Driver Provider Phoenix, LLC
  - (2026-11-18) U.S. Court of Appeals, 7th Cir.: American Alliance for Equal Rights v. State of Illinois
  - (2026-11-18) U.S. Court of Appeals, 7th Cir.: United States v. State of Illinois
  - (2026-11-18) U.S. Court of Appeals, 7th Cir.: James Hsieh v. PitchBook Data, Inc.
  - (2026-11-18) U.S. Court of Appeals, 2nd Cir.: Rene v. Mustafa
  - (2026-11-16) Colorado Supreme Court: Octavio Hernandez-Escajeda v. The People of the State of Colorado

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-11-19) Will Tim Walz win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $756,204 · resolves 2028-11-08
  - (2026-11-19) Will Fabien Roussel win the 2027 French presidential election?
      yes price: 0% · 24h volume: $591,521 · resolves 2027-04-19
  - (2026-11-19) Will Anthropic's market cap be between $1.75T and $2.0T at market close on IPO day?
      yes price: 3% · 24h volume: $572,614 · resolves 2028-01-01
  - (2026-11-19) Will John Thune win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $505,050 · resolves 2028-11-08
  - (2026-11-19) Will Adam Schiff win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $505,050 · resolves 2028-11-08
  - (2026-11-19) Will Graham Platner win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $505,050 · resolves 2028-11-08

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 40 total
  - (2026-11-19) MOVER ▲ Jeff Bezos — $385.33B (+$8.70B since yesterday)
      United States · Technology · source: Amazon
  - (2026-11-19) MOVER ▼ Jensen Huang — $131.77B ($-3.83B since yesterday)
      United States · Technology · source: Nvidia
  - (2026-11-19) MOVER ▼ Carlos Slim Helu & family — $123.45B ($-2.44B since yesterday)
      Mexico · Telecom · source: Telecom
  - (2026-11-19) MOVER ▲ Gautam Adani — $84.15B (+$0.87B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 18 total
  - (2026-11-18) CVE-2024-10441 · Synology DiskStation Manager (DSM): Synology DiskStation Manager (DSM) Improper Encoding or Escaping of Output Vulnerability
      vendor: Synology · product: DiskStation Manager (DSM) · CISA remediation by 2026-11-21
  - (2026-11-18) CVE-2026-40217 · BerriAI LiteLLM: BerriAI LiteLLM Unprotected Alternate Channel Vulnerability
      vendor: BerriAI · product: LiteLLM · CISA remediation by 2026-12-02
  - (2026-11-18) CVE-2026-90817 · Vanderbilt University Research Electronic Data Capture (REDCap): Vanderbilt University Research Electronic Data Capture (REDCap) Code Injection Vulnerability
      vendor: Vanderbilt University · product: Research Electronic Data Capture (REDCap) · CISA remediation by 2026-11-21
  - (2026-11-18) CVE-2026-90436 · Apache Axis: Apache Axis Unsafe Reflection Vulnerability
      vendor: Apache · product: Axis · CISA remediation by 2026-11-21

### Commentary & analysis (last 7 days) — 3 new of 4 total
  - (2026-11-19) [Marginal Revolution] The Anthropic IPO
      In general I am bullish on the commercial prospects of AI companies, including Anthropic (do note I am on the Advisory Board, though with zero governance role and zero access to internal information). But I view today’s…
  - (2026-11-19) [Marginal Revolution] Will Baird, book maven (from my email)
      Tyler and Alex, I have built Marginalia Library: using AI and the archives you have helpfully posted, I found every time a book has been mentioned on Marginal Revolution and created a searchable, browsable catalog. The c…
  - (2026-11-18) [Marginal Revolution] UK productivity update
      Output per hour worked increased by 2.5% in Quarter 3 (July to Sept) 2026 compared with the same quarter a year ago, reflecting a 2.0% increase in GVA and a 0.5% decrease in hours worked. Output per worker increased by 2…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=20, 14d-median=25; carrying terms: quality, implementation, certain, protection, changes, agency, airworthiness, environmental, action, published, directives, standards
- state_bills: today=0, 7d-median=73, 14d-median=84; carrying terms: business, school, including, public, state, relating, health, local, powers, general, vehicle, property
- state_news: today=768, 7d-median=712, 14d-median=712; carrying terms: general, chief, supreme, medium, healthcare, voted, wants, bureau, report, error, comes, president
- local_news: today=266, 7d-median=266, 14d-median=266; carrying terms: president, evening, cbmigwfbvv, night, south, three, county, being, office, students, google, atlanta
- foreign_news: today=1057, 7d-median=977, 14d-median=997; carrying terms: thejakartapost, homes, workers, general, vnecdn, chief, supreme, staff, clashes, wants, ukrainian, error
- chinese_internal: today=331, 7d-median=319, 14d-median=331; carrying terms: cbmix, cbmib, google, lxtfb, cbmibkfvx, target, cbmiakfvx, investors, lxtfa, cbmizefvx, https, caixin
- russian_internal: today=1134, 7d-median=938, 14d-median=946; carrying terms: https, server, istories, telegram, found, politico, bloomberg, press, reuters, financial, error, group
- ukrainian_internal: today=139, 7d-median=127, 14d-median=134; carrying terms: aircraft, general, intelligence, systems, ukrainian, winter, attacks, error, comes, president, assessment, services
- ukraine_theater: today=277, 7d-median=271, 14d-median=271; carrying terms: uvjflxdbr, cbmiqwfbvv, dzbfegzungn, htktvv, zvzfrvphmei, llxlqtutjdgxqvvbbwkrwylfvszexc, wounded, tyellwoujqegfda, zylmxbgc, general, chief, uljsytlcsef
- paper_bets: today=78, 7d-median=77, 14d-median=74; carrying terms: experience, prize, industrial, israel, henry, drought, nuclear, headline, regular, starts, general, nominal
- weather: today=116, 7d-median=127, 14d-median=130; carrying terms: morning, norton, continues, afdilx, rainfall, blowing, boston, afddtx, offshore, coast, afdtbw, outages
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, indicator, latest, jtsjol, effective, assets, commodities, balance, labor, headline, unrate, payrolls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, natural, bitcoin, large, corporate, nasdaq, agriculture, china, close, futures, credit, crypto
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=96, 7d-median=97, 14d-median=99; carrying terms: controlled, color, mission, extra, belarus, recognition, protecting, violations, general, against, activities, serious
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, https, quiverquant, error, quantitative, unauthorized, httperror, client, congresstrading
- billionaires: today=40, 7d-median=40, 14d-median=30; carrying terms: facebook, bezos, brokerage, steve, pharmaceuticals, shanghai, ellison, madrid, larry, adani, nvidia, spain
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, supreme, state, delaware, blanche, court, international, company, trade, miller, jones, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, reporting, accno, holdings, william, thomas, trust, technologies, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: booker, krishnamoorthi, receipts, ossoff, jackson, raised, brown, disbursements, jonathan, sherrod, senate, trone
- gdelt_regions: today=106, 7d-median=103, 14d-median=98; carrying terms: english, south, korea, japan, trump, russia, million, china, minister, korean, nvidia, turkey
- gdelt_gkg: today=150, 7d-median=132, 14d-median=71; carrying terms: english, russian, sanctions, keywords, russia, themes, perimeter, trump, israel, hezbollah, against, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: shooting, domain, killed, police, english, australia, murder, language, trump, ukraine, story, injured
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=19, 14d-median=24; carrying terms: position, france, belgium, germany, kingdom, ground, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: however, formula, viruses, sequencing, contamination, patient, divisions, kingdom, workers, producing, strain, recalls
- cisa_kev: today=18, 7d-median=15, 14d-median=15; carrying terms: value, multiple, return, vulnerability, product, check, authentication, critical, vendor, remediation, missing, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=45, 7d-median=53, 14d-median=35; carrying terms: kingdom, wbsetaliases, toollabs, wbsetclaim, wbeditentity, congo, wbsetsitelink, property, update, remove, democratic, quickstatements
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: fires, burkina, botswana, alert, depth, impact, sudan, wildfire, south, magnitude, green, australia
- usgs_quakes: today=14, 7d-median=12, 14d-median=12; carrying terms: depth, japan, indonesia, ridge, papua, guinea, chile, antarctic, village
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, championship, price, donetsk, resolves, volume, champions, shakhtar, november, december, presidential, meeting
- commentary: today=4, 7d-median=6, 14d-median=6; carrying terms: https, marginal, conversable, revolution, economist, class, economic, conversableeconomist, marginalrevolution, entire, power, called
- tech_news: today=62, 7d-median=63, 14d-median=62; carrying terms: intelligence, systems, industry, schneier, report, attacks, cyber, products, computer, exploited, target, newsletter
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: balderson, agriculture, delaney, pelosi, veterans, letlow, victoria, howard, jordan, patty, nydia, norton
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, today, sufficient, consensus, decision, paper, placement, identify, evidence, converges, market, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] ECB press: Boris Vujčić: Risks and resilience in the euro area financial system
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] ECB press: Frank Elderson: Smart supervision for small banks
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*