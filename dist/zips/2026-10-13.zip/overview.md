# WORLDSCOPE morning brief — 2026-10-13

## Headline
3128 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (821) · Russian Internal News (state + in-exile) (697) · State-Level News (328) · World leaders & government officials (324) · Chinese Internal News (235) · Local News: St. Louis + Atlanta (195) · U.S. Weather + Severe / Climate Outlooks (119) · Ukraine Theater (total-war monitoring) (66) · Ukrainian Internal News (national + local Kyiv) (56) · Court opinions of consequence (federal & state) (41) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (40)

## What changed today
### International News + Multilateral Institutions — 821 new of 1018 total
  - (2026-10-13) [Global] Hungary's parliament votes to reverse anti-LGBTQ legislation from Orban era
      Hungary's parliament passed a bill amending the 2021 "child protection law." The move is considered the first significant reversal of Orban's curbs targeting the LGBTQ+ community.
  - (2026-10-13) [Global] Nuremberg airport briefly closed after in-flight emergency
      Police are investigating a suspected in-flight emergency on a Corfu flight. After the airport reopened, the airline said they believed the emergency code was a result of a technical malfunction.
  - (2026-10-13) [Global] Nord Stream: Trial of Ukrainian attack suspect begins in Germany
      A Ukrainian citizen faces court in Hamburg, accused of attacking the Nord Stream gas pipelines in 2022. It raises questions about Kyiv's possible role in the explosions. German support for Ukraine is also under scrutiny.
  - (2026-10-13) [Global] Critics warn of espionage risks as Slovakia restores military-diplomatic representation with Russia
      Slovakia is restoring military-diplomatic relations with Russia for the first time since 2022. The government has defended the move; critics warn of espionage risks and further damage to trust within NATO.
  - (2026-10-13) [Global] Houthis and Saudis strike each other in latest escalation
      Fighting has continued between Iran-backed rebels and Saudi Arabia, adversely impacting the kingdom's economy and security. Still, Saudi officials have stopped warning of Houthi attacks in an effort to calm fears.
  - (2026-10-13) [Global] Spain's King Felipe and Queen Letizia visit Ceuta
      The royal couple have arrived for their first-ever visit to the exclave to show solidarity with residents.

### Russian Internal News (state + in-exile) — 697 new of 1029 total
  - (2026-10-13) «Возможно, мы зашли слишком далеко». Трамп посетовал, что в Иране не с кем вести переговоры — ведь США и Израиль убили всех лидеров | LEDE: Президент США Дональд Трамп заявил, что Вашингтону] (ru: «Во…
      Президент США Дональд Трамп заявил, что Вашингтону трудно понять, с какими именно должностными лицами в Иране вести переговоры — ведь многих из них США и Израиль убили.
  - (2026-10-13) «Агрессор номер один». Глава MI5 заявил, что Россия ведет «гибридную войну» в Европе — на фоне минимальных успехов в Украине | LEDE: Британская контрразведка сейчас выделяет больше ресурсов ] (ru: «Аг…
      Британская контрразведка сейчас выделяет больше ресурсов противодействию государственным угрозам, чем во время холодной войны, заявил глава MI5 Кен Маккаллум.
  - (2026-10-13) Как обезопасить себя от российской армии? . Набор понятных советов от «Идите лесом» — проекта, который помог десяткам тысяч россиян не оказаться на фронте | LEDE: В сентябре 2022 года Григор] (ru: Как…
      В сентябре 2022 года Григорий Свердлин, бывший директор организации «Ночлежка», помогающей бездомным, запустил проект «Идите лесом». Его цель — помочь россиянам избежать мобилизации или дезертировать. За четыре года услу…
  - (2026-10-13) Российские дроны ударили по университету в Ровно. Ранены 20 человек | LEDE: Российские дроны утром 13 октября атаковали Ровенскую область на западе Украины, удар пришелся по городу Ровно. <p] (ru: Рос…
      Российские дроны утром 13 октября атаковали Ровенскую область на западе Украины, удар пришелся по городу Ровно.
  - (2026-10-13) Софья Розенфельд — всемирно известный биолог с уникальной экспертизой в арктических птицах. За перевод двух тысяч рублей ФБК ее приговорили к трем с половиной годам колонии | LEDE: Софья Роз] (ru: Соф…
      Софья Розенфельд всю жизнь изучала арктических птиц: отправлялась в экспедиции на Крайний Север, следовала за гусиными стаями на гидросамолете и боролась за сохранение редких видов. Теперь один из ведущих российских орни…
  - (2026-10-13) Талибы остановили вещание радио «Би-би-си» в Афганистане | LEDE: Власти Афганистана приостановили радиовещание «Би-би-си» на всей территории страны. ] (ru: Талибы остановили вещание радио «Би-би-си» в…
      Власти Афганистана приостановили радиовещание «Би-би-си» на всей территории страны.

### State-Level News — 328 new of 515 total
  - (2026-10-13) [California] At Alcatraz, Native advocates criticize Newsom’s vetoes of tribal bills
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/101226_Sunrise-Gathering_MH_CM_03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-10-13) [California] One area Democrats, GOP agree: California needs a larger rainy day fund
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2022/06/redistricting-budget-cm.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="I…
  - (2026-10-13) [California] Thousands mark Indigenous Peoples Day on Alcatraz as tribes decry Newsom’s vetoes of tribal bills
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/101226_Sunrise-Gathering_MH_CM_02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-10-12) [California] Governor Newsom proclaims Indigenous Peoples’ Day
      Source
  - (2026-10-12) [California] Governor Newsom has slashed childcare costs, saving families money
      Source
  - (2026-10-13) [Connecticut] Scholarship tax credit vouchers, a wolf in sheep’s clothing
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/04/CT-Public-Linda-McMahon-at-Yale-1024x683.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="asyn…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 235 new of 299 total
  - (2026-10-13) 人保财险落地欧洲中资新能源车险首单_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1zZHdodExaaDF1Zmw0U1ZqV29pVXZObjJYMnF0YkdDb3g3VXE5Zk0tcjZ2eUllZm9WMllNTDBZeVRrVTFQV19FdTJJc] (zh:…
      人保财险落地欧洲中资新能源车险首单_特别呈现_手机财新网 财新
  - (2026-10-13) 尊重预期：2026年诺贝尔经济学奖 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE0ySmhhdHJJeTE2aTlUbDJFQVY1WUpZUGhmNkZ4Rk9IZV9fWmJhLWxlWmRwUG9FTXQwMUw3V2pzWHhQM2JmSlZlcFlQbWNGUXlOQ0ZF] (zh:…
      尊重预期：2026年诺贝尔经济学奖 财新
  - (2026-10-13) 今日开盘：两市双双低开 沪指跌幅0.96% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1Hc0t2a2h1cXo3YnhDWS1RVHduWGtYWk5fZmcyRDEzQURsN0Jxbkl4SXpIdGcwSHJGRmlfbUc3SmpLRkladHJVVG0zNTBydzY1] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.96% 财新
  - (2026-10-12) 财经早知道｜新能源汽车增值税出口退税率下调至9% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBkUGNVT2tZaFQ4aWNBbWVkUUx0THl1N0RtejYzSnI2ZDU5eG1hcGNkWEc3bXJKU1JydXduWlA1a2E1MmRZQkhKTGFWQVVvX] (zh:…
      财经早知道｜新能源汽车增值税出口退税率下调至9% 财新
  - (2026-10-13) 人事观察｜河北换届前石家庄换帅 交通部副部长王刚履新 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE51ZWpGZWJxdm0tcHFPUjI0LUNZWXhiT0g1SXhsN1FsampDRExVektqcE92em11b2pZcHBhNHNiRGliQ2FxZ1A0TnVYdUt] (zh:…
      人事观察｜河北换届前石家庄换帅 交通部副部长王刚履新 财新
  - (2026-10-12) 深圳原常委王守睿接受调查 官方称其主动交代问题(含视频) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE11bHRKeTZpdHlKelZMTHJZbHpkZjZZVDRqYzhPcEV2SnNaRElvUHRKNlFPNlRlaTVYaE5PdzdMc2hNV2dMUlhITTlIT] (zh:…
      深圳原常委王守睿接受调查 官方称其主动交代问题(含视频) 财新

### Local News: St. Louis + Atlanta — 195 new of 223 total
  - (2026-10-13) [St. Louis] Marquette girls fifth at state.jpeg
      Alton Marquette's girls golf team finish fifth in the Class 1A state tournament at Red Tail Run Golf Course in Decatur, led by individual state champion Maggie Pruetzel (third from left).
  - (2026-10-13) [St. Louis] Fire in Westbrooke Village Apartments
      St. Louis County firefighter Alexis Bates rolls up a hose after a fire broke out in an apartment in the Westbrooke Village Apartments in Manchester, Mo., on Tuesday, Oct. 13, 2026. There were no injuries or deaths and tw…
  - (2026-10-13) [St. Louis] Musk has spent $276 million on midterms to help Republicans retain control of Congress
      Elon Musk has spent roughly $366 million in the 2026 U.S. midterm election cycle so far, $276 million of it since July.
  - (2026-10-13) [St. Louis] 5 ways to set your child up with good credit
      A family hiking outdoors in the summer nature.
  - (2026-10-13) [St. Louis] 5 ways to set your child up with good credit
      Ally Financial reports five ways to build your child's credit score, emphasizing early action like adding them as authorized users on credit accounts.
  - (2026-10-13) [St. Louis] High-risk pregnancy doctors publish new standards for care under state abortion bans
      Stateline reports that maternal-fetal medicine specialists have created guidelines for high-risk pregnancy care under state abortion bans to address legal and medical challenges.

### U.S. Weather + Severe / Climate Outlooks — 119 new of 122 total
  - (2026-10-13) [Severe] Flood Warning: Flood Warning issued October 13 at 10:11AM EDT by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Astor affecting Lake and Volusia Counties. .The St Johns River at Astor has fallen into Minor Flood Stage, as upstream heavy rainf…
  - (2026-10-13) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-13) [Severe] Flood Warning: Flood Warning issued October 13 at 10:02AM EDT until October 15 at 2:00PM EDT by NWS Tampa Bay Ruskin FL
      ...The Flood Warning continues for the following rivers in Florida... Myakka River At Myakka River State Park affecting Sarasota County. ...The Flood Warning is cancelled for the following rivers in Florida... Withlacooc…
  - (2026-10-13) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 13 at 8:57AM CDT until October 13 at 10:00AM CDT by NWS New Orleans LA
      * WHAT...Visibility less than one mile in dense fog. * WHERE...Portions of southeast Louisiana and southern Mississippi. * WHEN...Until 10 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions haz…
  - (2026-10-13) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued October 13 at 8:51AM CDT until October 13 at 10:00AM CDT by NWS Jackson MS
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Jefferson Davis, Lawrence, Marion, Covington, Forrest, Jones, and Lamar Counties. * WHEN...Until 10 AM CDT this morning. * IMPACTS...Low visibility cou…
  - (2026-10-13) [Severe] Flood Warning: Flood Warning issued October 13 at 9:44AM EDT by NWS Jacksonville FL
      ...The Flood Warning continues for the following rivers in southeast Georgia... Satilla River At Atkinson affecting Brantley County. Additional information is available at https://water.weather.gov/wfo/JAX The next state…

### Ukraine Theater (total-war monitoring) — 66 new of 368 total
  - (2026-10-13) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-13) [Liveuamap] Houthis report 119 airstrikes on sites under their control in Hodeidah and Al-Jawf over the past 24 hours. - Liveuamap
      Houthis report 119 airstrikes on sites under their control in Hodeidah and Al-Jawf over the past 24 hours. &nb
  - (2026-10-13) [Liveuamap] Twenty people were injured in a Russian drone strike on a university building in Rivne. - Liveuamap
      Twenty people were injured in a Russian drone strike on a university building in Rivne. Live
  - (2026-10-11) [Liveuamap] A high-voltage power line was damaged in a Russian attack on Kyiv, Mayor Vitali Klitschko said. He also reported reduced water pressure on both the right and left banks of the city. Emerge…
      A high-voltage power line was damaged in a Russian attack on Kyiv, Mayor Vitali Klitschko said. He also reported reduced water pressure on both the right and left banks of the city. Emergency repair
  - (2026-10-13) [Liveuamap] Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com - iran.liveuamap.com
      Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com iran.liveuamap.com
  - (2026-10-12) [Liveuamap] Explosions were reported near Rivne - Liveuamap
      Explosions were reported near Rivne Liveuamap

### Ukrainian Internal News (national + local Kyiv) — 56 new of 129 total
  - (2026-10-13) Лідери ЄС та Зеленський 16 жовтня у Брюсселі обговорять підтримку України | LEDE: "Українське питання" розглянуть на засіданні Європейської ради в Брюсселі 16 жовтня – воно буде першим у порядк] (uk:…
      "Українське питання" розглянуть на засіданні Європейської ради в Брюсселі 16 жовтня – воно буде першим у порядку денному другого дня саміту, також очікується присутність президента України Володимира Зеленського.
  - (2026-10-13) Міністр оборони Естонії: Росія може напасти на НАТО, і не факт, що божевільного можна стримати | LEDE: ] (uk: Міністр оборони Естонії: Росія може напасти на НАТО, і не факт, що божевільного )
  - (2026-10-13) На Харківщині російські дрони "полюють" на автівки: 1 людина загинула, 2 постраждали | LEDE: 13 жовтня російські безпілотники пошкодили п'ять авто у Харківській області, одна людина загинула, д] (uk:…
      13 жовтня російські безпілотники пошкодили п'ять авто у Харківській області, одна людина загинула, двоє отримали поранення.
  - (2026-10-13) Їхала містом, зняла роботу ППО і надіслала Telegram-каналу: ще одній киянці оголосили підозру | LEDE: СБУ повідомила про підозру жінці за незаконне розповсюдження відео роботи ППО Gepard у Києв] (uk:…
      СБУ повідомила про підозру жінці за незаконне розповсюдження відео роботи ППО Gepard у Києві. Їй загрожує до 8 років ув'язнення.
  - (2026-10-13) До 25 зросла кількість потерпілих від удару РФ по навчальному закладу в Рівному – НПУ | LEDE: Кількість постраждалих унаслідок ворожого удару по навчальному закладу в Рівному зросла до 25 осіб.] (uk:…
      Кількість постраждалих унаслідок ворожого удару по навчальному закладу в Рівному зросла до 25 осіб.
  - (2026-10-13) Росіяни атакували два райони Харкова і поцілили в супермаркет: 3 постраждалих, зокрема дитина | LEDE: Внаслідок атаки безпілотника у Шевченківському районі Харкова поранено двох людей. Постражд] (uk:…
      Внаслідок атаки безпілотника у Шевченківському районі Харкова поранено двох людей. Постраждалі отримують медичну допомогу.

### Court opinions of consequence (federal & state) — 41 new of 60 total
  - (2026-10-13) Delaware Supreme Court: Roberta Ann K.W. Wong Leung Revocable Trust U/A Dated 03/09/2018 v. Amazon.com, Inc.
  - (2026-10-12) U.S. Court of Appeals, 5th Cir.: United States v. Tekippe
  - (2026-10-10) U.S. Court of Appeals, 5th Cir.: Gakou v. Warden
  - (2026-10-09) Supreme Court of Alabama: OMS Pharmacy, Inc., d/b/a The Pharmacy at Midtown; and Hannah D. Browne v. Nationwide Property and Casualty Insurance Company; Baldo-Downs Insurance, LLC; and Roger Downs, In…
  - (2026-10-09) Supreme Court of Alabama: State of Alabama ex rel. Brook Lynn Dorgan and Justin Jude LeBlanc v. Thomas Hawley Tuberville, individually and in his capacity as the certified nominee of the Alabama Repub…
  - (2026-10-09) Arizona Supreme Court: BLUNT v. TOWN OF GILBERT

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-13) [TPM, S.A. de C.V.] Form 4 (Reporting)
      filed 2026-10-13 14:13 UTC · role: Reporting — Filed: 2026-10-13 AccNo: 0001104659-26-115328 Size: 13 KB
  - (2026-10-13) [Devasini Giancarlo] Form 4 (Reporting)
      filed 2026-10-13 14:13 UTC · role: Reporting — Filed: 2026-10-13 AccNo: 0001104659-26-115328 Size: 13 KB
  - (2026-10-13) [Tether Global Investments Fund, S.I.C.A.F., S.A.] Form 4 (Reporting)
      filed 2026-10-13 14:13 UTC · role: Reporting — Filed: 2026-10-13 AccNo: 0001104659-26-115328 Size: 13 KB
  - (2026-10-13) [Gold.com, Inc.] Form 4 (Issuer)
      filed 2026-10-13 14:13 UTC · role: Issuer — Filed: 2026-10-13 AccNo: 0001104659-26-115328 Size: 13 KB
  - (2026-10-13) [Fundrise Income Real Estate Fund, LLC] Form 4 (Issuer)
      filed 2026-10-13 14:13 UTC · role: Issuer — Filed: 2026-10-13 AccNo: 0001435109-26-000152 Size: 4 KB
  - (2026-10-13) [Hall Bjorn] Form 4 (Reporting)
      filed 2026-10-13 14:13 UTC · role: Reporting — Filed: 2026-10-13 AccNo: 0001435109-26-000152 Size: 4 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 40 new of 58 total
  - (2026-10-13) [BleepingComputer] The MFA Gaps Attackers are Still Exploiting
      Attackers continue exploiting gaps in MFA coverage, using stolen credentials to access VPNs, RDP, and Windows systems that still rely on passwords alone. Specops explains why protecting cloud applications isn't enough an…
  - (2026-10-13) [BleepingComputer] SAP warns of maximum severity OAuth2 SSRF security flaw
      SAP has addressed 20 security flaws across multiple products in its October 2026 security updates, including a maximum-severity vulnerability in the Cloud SDK for Python. [...]
  - (2026-10-13) [The Hacker News] [Webinar] How to Stop AI-Driven Privilege Escalation With Runtime Identity Controls
      The dangerous part of a stolen identity isn't always the initial login. It's what an attacker can do with that access next. With AI accelerating reconnaissance, exploitation of vulnerabilities, and privilege escalation,…
  - (2026-10-13) [The Hacker News] LG Smart TVs Vulnerable to Pre-Auth Root Takeover From Local Network
      Three vulnerabilities in LG's webOS can be chained to give an attacker on the same local network root access to certain smart TVs without a PIN or any interaction from the owner. LG has issued a fix, according to an advi…
  - (2026-10-13) [The Hacker News] Product Walkthrough: Bitdefender AI Visibility and Control
      A user opens a browser tab, pastes data into a chat assistant, and nothing is installed. A developer adds a coding assistant as an editor extension, and nothing shows up in the installed programs list. Someone downloads…
  - (2026-10-13) [The Hacker News] Attackers Heat French Supermarket Fridges Up to 50°C by Hijacking Danfoss Controllers
      Attackers took remote control of fridges and freezers at hundreds of French supermarkets on the night of October 11 and warmed them, forcing stores to throw food away, several retail chains said. The attackers reached th…

### GDACS — global disaster alerts — 37 new of 100 total
  - (2026-10-13) [Green] Earthquake in Central Mid-Atlantic Ridge
      Earthquake · Green alert · Central Mid-Atlantic Ridge · Magnitude 6.9M, Depth:10km
  - (2026-10-13) [Green] Earthquake in Off East Coast Of Kamchatka
      Earthquake · Green alert · Off East Coast Of Kamchatka · Magnitude 4.9M, Depth:10km
  - (2026-10-13) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.5M, Depth:35km
  - (2026-10-13) [Green] Earthquake in Tajikistan
      Earthquake · Green alert · Tajikistan · Magnitude 4.7M, Depth:10km
  - (2026-10-13) [Green] Earthquake in Southern Mid-Atlantic Ridge
      Earthquake · Green alert · Southern Mid-Atlantic Ridge · Magnitude 5.3M, Depth:10km
  - (2026-10-13) [Green] Earthquake in China
      Earthquake · Green alert · China · Magnitude 4.6M, Depth:10km

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-13) JAF9BV (Bulgaria)
      icao24: 4520ce · position: (50.5857, 3.2453) · alt: 472m · 228km/h
  - (2026-10-13) PAT485 (United States)
      icao24: adfecb · position: (37.9913, -85.0865) · alt: 3017m · 358km/h
  - (2026-10-13) JAF49Y (Bulgaria)
      icao24: 4520aa · position: (32.6879, -9.3141) · alt: 10668m · 813km/h
  - (2026-10-13) CFC3443 (Canada)
      icao24: c2c377 · position: (44.7816, -3.9081) · alt: 12192m · 898km/h
  - (2026-10-13) PAT463 (United States)
      icao24: adfe48 · position: (34.3853, -78.9359) · alt: 6096m · 504km/h
  - (2026-10-13) PAT595 (United States)
      icao24: adfe95 · position: (36.4604, -91.3306) · alt: 5486m · 427km/h

### USGS earthquakes (M4.5+, past day) — 22 new of 23 total
  - (2026-10-13) M 6.9 - central Mid-Atlantic Ridge
      M6.9 · central Mid-Atlantic Ridge · depth 10 km · TSUNAMI
  - (2026-10-13) M 6.7 - central Mid-Atlantic Ridge
      M6.7 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-10-12) M 6.1 - 17 km W of Río Grande, Panama
      M6.1 · 17 km W of Río Grande, Panama · depth 11 km
  - (2026-10-13) M 5.3 - southern Mid-Atlantic Ridge
      M5.3 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-10-13) M 5.1 - 119 km SSW of Gambiran Satu, Indonesia
      M5.1 · 119 km SSW of Gambiran Satu, Indonesia · depth 10 km
  - (2026-10-13) M 4.9 - 180 km SE of Vilyuchinsk, Russia
      M4.9 · 180 km SE of Vilyuchinsk, Russia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-10-13) LoL: HANJIN BRION vs LGD Gaming (BO5) - Demacia Cup Global Invitational Playoffs
      yes price: 100% · 24h volume: $2,404,504 · resolves 2026-10-13
  - (2026-10-13) LoL: HANJIN BRION vs LGD Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $1,684,294 · resolves 2026-10-13
  - (2026-10-13) LoL: HANJIN BRION vs LGD Gaming - Game 3 Winner
      yes price: 100% · 24h volume: $1,208,172 · resolves 2026-10-13
  - (2026-10-13) LoL: HANJIN BRION vs LGD Gaming - Game 4 Winner
      yes price: 100% · 24h volume: $838,280 · resolves 2026-10-13
  - (2026-10-13) Will the Fed increase interest rates by 25 bps after the October 2026 meeting?
      yes price: 20% · 24h volume: $565,793 · resolves 2026-10-29
  - (2026-10-13) Will there be no change in Fed interest rates after the October 2026 meeting?
      yes price: 80% · 24h volume: $538,596 · resolves 2026-10-29

### Paper Trading Scorecard — 16 new of 68 total
  - (2026-10-13) [Polymarket] Will Xi meet with Takaichi by December 31, 2026?
      This market will resolve to "Yes" if Sanae Takaichi meets with Xi Jinping between market creation and the listed date, 11:59 PM ET. Otherwise, this market will resolve to "No". A meeting is defined as any encounter where…
  - (2026-10-13) [Polymarket] Russia pneumonic plague spreads abroad?
      This market will resolve to “Yes” if a human case of pneumonic plague outside the Russian Federation is confirmed and established as epidemiologically linked to the outbreak associated with the Irkutsk Anti-Plague Resear…
  - (2026-10-13) [Manifold] Will Roman Shogdzhiev become the youngest chess Grandmaster ever?
  - (2026-10-13) [Manifold] Will the US enter a depression if the Republicans win the midterms?
  - (2026-10-13) [Manifold] Will Tokyo experience a major earthquake before the end of October 31, 2026?
  - (2026-10-13) [Manifold] Will the US enter a depression if the Democrats win the midterms?

### State Legislative Action — 6 new of 7 total
  - (2026-10-12) [Alaska HB 222] An Act relating to workplace violence protective orders; relating to attorney fees; relating to the crime of violating a protective order; relating to the powers of district judges and…
      An Act relating to workplace violence protective orders; relating to attorney fees; relating to the crime of violating a protective order; relating to the powers of district judges and magistrates; amending Rules 4 and 6…
  - (2026-10-12) [Alaska HB 325] An Act relating to industrial hemp; and providing for an effective date.
      An Act relating to industrial hemp; and providing for an effective date.
  - (2026-10-12) [Alaska SB 214] An Act making appropriations, including capital appropriations, supplemental appropriations, and reappropriations; making appropriations to capitalize funds; amending appropriations; a…
      An Act making appropriations, including capital appropriations, supplemental appropriations, and reappropriations; making appropriations to capitalize funds; amending appropriations; and providing for an effective date.
  - (2026-10-13) [California SB 964] Prescription drug coverage: dose adjustments.
      Existing law, the Knox-Keene Health Care Service Plan Act of 1975, provides for the licensure and regulation of health care service plans by the Department of Managed Health Care, and makes a willful violation of the act…
  - (2026-10-13) [California SB 1194] Immigration Legal Fellowship Project.
      Existing law requires the State Department of Social Services, subject to an appropriation, to provide grants to qualified nonprofit organizations through contracts, in order to provide certain immigration-related legal…
  - (2026-10-13) [California SB 403] End of Life Option Act: sunset.
      Existing law, the End of Life Option Act, until January 1, 2031, authorizes an adult who meets certain qualifications, including, among other things, being a resident of the State of California, and who has been determin…

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-13) [Marginal Revolution] Is Your Agent a Double Agent?
      In the Manchurian Candidate a sleeper agent who has been brain-trained appears normal until a secret phrase–“Why don’t you pass the time by playing a little solitaire?”–triggers a state of hypnosis and control by the att…
  - (2026-10-13) [Marginal Revolution] *Lost Worlds*
      The author is Patrick Wyman, and the subtitle is How Humans Tried, Failed, Succeeded, and Built Our World. An excellent book, it is a survey of (mostly) pre-Sumerian times, what we know about them, and how we have learne…
  - (2026-10-13) [Marginal Revolution] “I have no mouth and I must scream”
      Worth a reread, here is a new report from the front: Our experiments suggest that small AI models may be months away from being capable enough to self-replicate on commercial IoT devices, like smart ovens and off-brand A…
  - (2026-10-12) [Conversable Economist] 1974: When Both Nobel Economists Proposed Abolishing the Prize
      The Nobel prize in economics was awarded for the sixth time in 1974 (that is, it was first awarded in 196) to Gunnar Myrdal and Friedrich von Hayek “for their pioneering work in the theory of money and economic fluctuati…

### Government Action: Sanctions + Procurement + Foreign Agents — 3 new of 107 total
  - (2026-10-13) [USASpending] $147,933,393 → CGI FEDERAL INC.: CDM DEFEND GROUP C BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP C BRIDGE TASK ORDER
  - (2026-10-13) [USASpending] $144,000,000 → SOUTHWEST VALLEY CONSTRUCTORS CO: CONSTRUCTION OF U.S. CUSTOMS AND BORDER PROTECTION FACILITY
      Agency: Department of Homeland Security. Description: CONSTRUCTION OF U.S. CUSTOMS AND BORDER PROTECTION FACILITY IN JACKSONVILLE,FL
  - (2026-10-13) [USASpending] $138,628,964 → FOUR POINTS TECHNOLOGY, L.L.C.: THIS DELIVERY ORDER IS FOR PROVIDING AN ENTERPRISE-WIDE SOLU
      Agency: National Aeronautics and Space Administration. Description: THIS DELIVERY ORDER IS FOR PROVIDING AN ENTERPRISE-WIDE SOLUTION FOR CLOUD SERVICES

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-13) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=26, 14d-median=26; carrying terms: action, order, safety, model, regulatory, national, public, certain, final, proposed, state, flight
- state_bills: today=7, 7d-median=73, 14d-median=78; carrying terms: state, administration, district, alaska, relating, effective, providing, education, school, violations, existing, service
- state_news: today=515, 7d-median=667, 14d-median=682; carrying terms: construction, medicaid, issues, hampshire, columbia, state, forbidden, making, pressherald, vtdigger, island, nevada
- local_news: today=223, 7d-median=223, 14d-median=224; carrying terms: state, making, google, watch, around, police, injured, louis, being, vehicle, children, october
- foreign_news: today=1018, 7d-median=1018, 14d-median=1018; carrying terms: products, issues, sueddeutsche, moved, making, linked, facilities, medium, police, injured, launched, kyivindependent
- chinese_internal: today=299, 7d-median=292, 14d-median=276; carrying terms: cbmiykfvx, investors, china, cbmibkfvx, lxtfb, cbmickfvx, cbmizkfvx, cbmibefvx, cbmiyefvx, https, title, lxtfa
- russian_internal: today=1029, 7d-median=1061, 14d-median=1052; carrying terms: reuters, media, forbidden, laquo, httperror, target, error, bloomberg, blank, times, https, russian
- ukrainian_internal: today=129, 7d-median=136, 14d-median=136; carrying terms: strikes, civilians, state, forbidden, linked, critical, plans, facilities, occupied, scale, launched, kyivindependent
- ukraine_theater: today=368, 7d-median=533, 14d-median=548; carrying terms: jtswdszgfrmi, ukziuq, cbmiykfvx, dlwuutx, maintained, sedbgwtjfcnuywergv, pqyze, cbmipefvx, cbmieefvx, facilities, rrendsmxvfm, foghaqxm
- paper_bets: today=68, 7d-median=68, 14d-median=122; carrying terms: office, levels, prize, human, humans, world, state, break, majors, least, supervolcano, minister
- weather: today=122, 7d-median=141, 14d-median=142; carrying terms: hurricane, afdffc, strong, lincoln, afdphi, afdhgx, southeast, island, visibility, watch, afdlox, weather
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: supply, sheet, openings, inflation, balance, funds, treasury, cpiaucsl, recession, commodities, effective, rates
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, equities, large, proxy, corporate, treasury, crypto, natural, agriculture, commodities, rates, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=107, 7d-median=111, 14d-median=114; carrying terms: embargo, bosnia, drilling, destabilising, resolution, destabilisation, state, military, february, google, cyber, middle
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, quantitative, https, quiverquant, error, httperror, congresstrading
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, appeals, county, supreme, corporation, court, alabama, company, international, james, warden, brown
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, holdings, filer, finance, group, robert, scotia, funds, estate
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: house, angels, shawn, elect, sherrod, cycle, warner, filing, platner, james, jonathan, talarico
- gdelt_regions: today=0, 7d-median=2, 14d-median=4
- gdelt_gkg: today=0, 7d-median=49, 14d-median=49; carrying terms: themes, english, french, spanish, chinese, italian, romanian, sanctions, taiwan, german, russian, vietnamese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, germany, france, kingdom, canada, bulgaria, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: material, rajshahi, consecutive, passengers, bloody, suspected, representing, unaffected, dignified, coronavirus, previously, periods
- cisa_kev: today=11, 7d-median=13, 14d-median=16; carrying terms: operations, injection, remediation, product, within, memory, improper, products, multiple, buffer, bounds, restriction
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: hurricane, bolivia, magnitude, guinea, impact, mongolia, panama, forest, brazil, wildfire, russian, alert
- usgs_quakes: today=23, 7d-median=21, 14d-median=17; carrying terms: depth, indonesia, philippines, russia, ridge, chile, atlantic, panama, grande, alaska, tambolaka, kuril
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: donetsk, resolves, price, shakhtar, october, championship, league, presidential, champions, volume, winner, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, https, conversable, revolution, conversableeconomist, economist, marginal, money, public, development, areas, spending
- tech_news: today=58, 7d-median=60, 14d-median=58; carrying terms: state, google, years, spectrum, cybersecurity, hacker, report, newsletter, breach, vulnerability, computerweekly, agents
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: bergman, lloyd, hoeven, plaskett, weber, meeks, harshbarger, frankel, treasury, strong, gabbard, emmer
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, unavailable, module, identify, consensus, either, paper, converges, today, placement, placed, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] ECB press: Philip R. Lane: Diagnostic Challenges for ECB Monetary Policy
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*