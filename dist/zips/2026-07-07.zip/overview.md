# WORLDSCOPE morning brief — 2026-07-07

## Headline
2523 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (671) · Russian Internal News (state + in-exile) (559) · World leaders & government officials (324) · Chinese Internal News (214) · Ukraine Theater (total-war monitoring) (147) · State-Level News (120) · U.S. Weather + Severe / Climate Outlooks (107) · Local News: St. Louis + Atlanta (94) · Ukrainian Internal News (national + local Kyiv) (45) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (30)

## What changed today
### International News + Multilateral Institutions — 671 new of 1031 total
  - (2026-07-07) [Global] French court clears way for far-right leader Le Pen to run in 2027, with ankle bracelet
      A French appeal court on Tuesday upheld Marine Le Pen's conviction for embezzling EU funds but shortened her ban on running for public office, in theory giving a path ​for the far-right ‌leader to run in the 2027 preside…
  - (2026-07-07) [Global] Who is Jordan Bardella, the successor to French far right's Marine Le Pen?
      French far -right figurehead Marine Le Pen has been barred from public office for 15 months and sentenced to a year under electronic card after an appeal's course found her guilty of embezzling EU funds. Although this me…
  - (2026-07-07) [Global] Le Pen sentenced to 15-month ban from public office in EU embezzlement case
      A French ​appeals court on ​July 7 upheld Marine Le Pen's conviction for misusing EU funds ​but shortened ‌her ban ⁠on running for elected office. In theory, this potentially re-opens a path for the ⁠far-right leader to…
  - (2026-07-07) [Global] World Cup 2026: Ronaldo out of last World Cup as Spain beat Portugal
      Mikel Merino broke the deadlock in injury time as Spain continue their perfect run with a 1-0 win. Portugal's exit means Cristiano Ronaldo played his final game at the World Cup, as he confirmed he's retiring from intern…
  - (2026-07-07) [Global] 🔴 Live: Marine Le Pen convicted on appeal, but may still stand in the 2027 presidential election
  - (2026-07-07) [Global] 🔴 Follow live: French court upholds Le Pen's fraud conviction, threatening her 2027 presidential hopes

### Russian Internal News (state + in-exile) — 559 new of 984 total
  - (2026-07-07) Подозреваемую в покушении на бизнесмена Вадима Ермолаева в Монако нашли мертвой под Киевом. В ее убийстве признался сотрудник украинской разведки. Он утверждает, что руководство не было в курсе] (ru:…
      Под Киевом вечером 6 июля нашли застреленной 39-летнюю украинку Анастасию Березовскую, которую подозревают в совершении покушения на украинского бизнесмена Вадима Ермолаева в Монако.
  - (2026-07-07) В Сербии задержали двух предполагаемых агентов России, которые готовили диверсию в Германии | LEDE: На сербско-венгерской границе задержали двух предполагаемых российских агентов, которые, к] (ru: В С…
      На сербско-венгерской границе задержали двух предполагаемых российских агентов, которые, как утверждает Bild, могли готовить диверсию в Германии.
  - (2026-07-07) В Казахстане обнулили президентский срок Токаева. Благодаря новой Конституции он сможет снова баллотироваться на пост главы государства | LEDE: Новая редакция Конституции Казахстана дает пра] (ru: В К…
      Новая редакция Конституции Казахстана дает право президенту страны Касым-Жомарту Токаеву снова баллотироваться на выборах главы государства, следует из разъяснений Конституционного суда страны.
  - (2026-07-07) «Би-би-си» назвала имена трех сотрудников нелегальных тюрем, подозреваемых в пытках украинцев на оккупированных территориях. Сейчас они живут в России | LEDE: Британская корпорация «Би-би-си] (ru: «Би…
      Британская корпорация «Би-би-си» выпустила статью о трех бывших сотрудниках нелегальных тюрем, расположенных на оккупированных Россией территориях Украины. Там с 2014 года незаконно удерживают и пытают украинцев. Вот что…
  - (2026-07-07) В Крыму заработал аварийный роуминг. Абоненты смогут подключаться к сетям других операторов при блэкауте (но доступны будут только сайты из «белого списка») | LEDE: Мобильные операторы Крыма] (ru: В К…
      Мобильные операторы Крыма предупредили о включении аварийного роуминга на всей территории аннексированного региона.
  - (2026-07-07) Бельгия выбивает США и издевательски исполняет «танец Трампа». Роналду плачет после поражения от Испании — он больше никогда не сыграет на чемпионате мира. Что там на ЧМ? Суперкоротко | LEDE: <] (ru:…
      Кто как с кем сыграл. Испания обыграла Португалию 1:0, для Криштиану Роналду, по его собственным словам, этот матч стал последним на чемпионатах мира. Итоги шести ЧМ для португальца: 27 матчей, 11 голов, лучший результат…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 214 new of 276 total
  - (2026-07-07) 首届全国数智健康大赛复赛将启动 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9sSU9yN0VCYkdTUlg5SGpTVVZJOUktZmdER3JXMEtTY2lJa2lRYkdSa3hKaktQMEJPNFZCZ01vU01HN2Y5UWZTLXpSdE9FRnVRa01] (zh:…
      首届全国数智健康大赛复赛将启动 人民网健康
  - (2026-07-07) 直播预告：科学护肤 安全焕颜 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFBxbkh0MHdibWYydGlNVFJJTkFYZDdLRE44eGNTUFY1c2x4QnJNWWNnZ1NjeXVRVVNhZW0xV1ZiZElWZWc1Vy05eTY5b2hyRDBWOXJo] (zh:…
      直播预告：科学护肤 安全焕颜 人民网健康
  - (2026-07-07) 国家医保局：坚决反对企业以不正当方式干扰药品集采工作 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1IZzc2Z3ZoWGV5N0pFOXZ6R0ZySTcyWFV4NFh2RlZzUERIc3cxblNXRVFHcklyZUp6b0htVnNDSlVvckp0UmhNdkcy] (zh:…
      国家医保局：坚决反对企业以不正当方式干扰药品集采工作 人民网健康
  - (2026-07-07) 全国首位！不靠论文，他拿下临床医学博士学位 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9SZ2Y1WmVmZGtqUW1jaVZEWGNNbE14TFBBcHEwdEtnR1l6M1VXbnNUUC1UcXRPR0tUeld2bkVHOTRKMVNneG1pSmt0aUZWN] (zh:…
      全国首位！不靠论文，他拿下临床医学博士学位 人民网健康
  - (2026-07-07) 江苏传统产业全国占比持续提升 - 人民网－江苏频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE0tYkZtandaS0NIR19RTC1mS09TNHFmWmJLTnRMbGJsN1czMXRMcGk3VEhEdm1JcE5fSEFqeWFtWURHblY0RkJ0Wk1MYXVfR2Z2e] (zh:…
      江苏传统产业全国占比持续提升 人民网－江苏频道
  - (2026-07-07) 伊朗外长：若威胁继续不会启动最终谈判--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE9pYWVQUDR4Z3RFa2RQYmZwSkJNR1pOU0FsY3pldV9BMXlvdzc5dF9YS3FSLUI2Nm5YQWhPbWRWYkdJV1ZoZE85SFczYU1PTG] (zh:…
      伊朗外长：若威胁继续不会启动最终谈判--国际 人民网

### Ukraine Theater (total-war monitoring) — 147 new of 327 total
  - (2026-07-07) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-06) [Liveuamap] Oil terminal is on fire at the Kerch port after overnight attack - Liveuamap
      Oil terminal is on fire at the Kerch port after overnight attack Liveuamap
  - (2026-07-07) [Liveuamap] At Oleksandrivka direction clashes yesterday near Oleksandrohrad, Sichneve, Ternove and Kalynivske, - General Staff of Armed Forces of Ukraine reports Dnipropetrovsk Oblast, Ukraine - Ukra…
      At Oleksandrivka direction clashes yesterday near Oleksandrohrad, Sichneve, Ternove and Kalynivske, - General Staff of Armed For
  - (2017-08-07) [Liveuamap] Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com - Liveuamap
      Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com Liveuamap
  - (2026-07-03) [Liveuamap] Missile strike was reported in Belgorod - Liveuamap
      Missile strike was reported in Belgorod Liveuamap
  - (2026-06-30) [Liveuamap] Ambulance and Emergency Services: Two dead and several wounded in an Israeli drone strike on a motorcycle northwest of Khan Younis city in the southern Gaza Strip Khan Yunis, Gaza - Lebano…
      Ambulance and Emergency Services: Two dead and several wounded in an Israeli drone strike on a motorcycle northwest of

### State-Level News — 120 new of 445 total
  - (2026-07-07) [California] Governor Newsom signs legislation 7.6.26
      Source
  - (2026-07-07) [California] Push to shutter Oakland charter school hinges on a misguided approach to accountability
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/051122_St-Hope-Charter-School_MG_CM_32.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-07-07) [California] Tech devices in California’s new cars create thorny political issues
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/100922-Car-Screen-GETTY-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-07-07) [California] Abortion pills could come to California community college health centers
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/071824-Mifespristone-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-07-07) [Connecticut] Josh Elliott swings big in first commercial
      <img width="1024" height="568" src="https://ctmirror.org/wp-content/uploads/2026/07/Image-7-6-26-at-3.02-PM-1024x568.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-07-07) [Connecticut] Proposed golf facility violates UConn’s environmental responsibility
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/06/No-Golf-1-1024x768.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcs…

### U.S. Weather + Severe / Climate Outlooks — 107 new of 127 total
  - (2026-07-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-07) [Severe] Special Marine Warning: Special Marine Warning issued July 7 at 8:25AM EDT until July 7 at 9:30AM EDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Coastal Waters From Ochlockonee River to Apalachicola FL out to 20 Nm... Coastal Waters from Mexico Beach to Apalachicola ou…
  - (2026-07-07) [Moderate] Special Weather Statement: Special Weather Statement issued July 7 at 6:24AM MDT by NWS Aberdeen SD
      At 624 AM MDT, Doppler radar was tracking a strong thunderstorm near Little Moreau Rec Area, or near Timber Lake, moving northeast at 30 mph. HAZARD...Wind gusts up to 50 mph and penny size hail. SOURCE...Radar indicated…
  - (2026-07-07) [Moderate] Special Weather Statement: Special Weather Statement issued July 7 at 7:21AM CDT by NWS Aberdeen SD
      At 721 AM CDT, Doppler radar was tracking a strong thunderstorm over Java, or 8 miles east of Selby, moving northeast at 25 mph. HAZARD...Wind gusts up to 50 mph and nickel size hail. SOURCE...Radar indicated. IMPACT...G…
  - (2026-07-07) [Moderate] Special Weather Statement: Special Weather Statement issued July 7 at 7:16AM CDT by NWS Shreveport LA
      At 716 AM CDT, Doppler radar was tracking a strong thunderstorm near Omaha, or 12 miles northeast of Mount Pleasant, moving southeast at 15 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty…
  - (2026-07-07) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued July 7 at 5:02AM PDT until July 10 at 5:00PM PDT by NWS San Francisco CA
      * WHAT...An increased risk of sneaker waves and strong rip currents due to long period SW swell. * WHERE...Pacific Coast Beaches. * WHEN...Through Friday afternoon. * IMPACTS...Dangerous conditions are forecast along the…

### Local News: St. Louis + Atlanta — 94 new of 217 total
  - (2026-07-07) [St. Louis] Former Sam’s Steakhouse manager will avoid jail time under diversion program
      Mark Erney, who was charged last year with defrauding the owners of St. Louis-based Sam’s Steakhouse out of more than $1.4 million, has been allowed to enter a diversion program that will again allow him to avoid jail ti…
  - (2026-07-07) [St. Louis] Two more St. Louisans are named Eisenhower Fellows
      It’s safe to say St. Louis knows a thing or two about the Eisenhower Fellowships: Two locals have been named fellows in the organization’s 2026 Innovative Entrepreneurs Program from a pool of more than 500 applications,…
  - (2026-07-07) [St. Louis] Where Art Thou 7/7/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-07-07) [St. Louis] Mizzou opponent scouting report: Kansas will have new starting QB in 2026
  - (2026-07-07) [St. Louis] Worthy: Dreadful New York Mets a reminder to MLB fans wins aren’t bought
  - (2026-07-07) [St. Louis] While working with pitching limitations, Cardinals' lead dashed away by Brewers
      With their bullpen limited and starter on a pitch count, the Cardinals had their 3-0 lead over the Brewers flip into a 4-3 deficit during a Monday night loss at Busch Stadium.

### Ukrainian Internal News (national + local Kyiv) — 45 new of 118 total
  - (2026-07-07) Глава МЗС Латвії: США дуже зацікавлені у збереженні військ у Європі | LEDE: Міністерка закордонних справ Латвії Байба Браже переконана, що США "дуже зацікавлені" у тому, щоб залишити свої війсь] (uk:…
      Міністерка закордонних справ Латвії Байба Браже переконана, що США "дуже зацікавлені" у тому, щоб залишити свої війська в Європі.
  - (2026-07-07) Зеленський розповів НАТО про успіхи України в обороні: Невже правильно залишати поза Альянсом країну з такою обороноздатністю | LEDE: Президент Володимир Зеленський заявив, що Україна з її рівн] (uk:…
      Президент Володимир Зеленський заявив, що Україна з її рівнем обороноздатності має стати частиною НАТО, адже це посилить колективну безпеку Альянсу.
  - (2026-07-07) РФ вдень атакувала Харків КАБами: одна людина загинула, ще шестеро постраждали | LEDE: Унаслідок атаки РФ КАБами по Харкову загинула 1 людина, 6 постраждали. Знищено авто, пошкоджені будинки.] (uk: РФ…
      Унаслідок атаки РФ КАБами по Харкову загинула 1 людина, 6 постраждали. Знищено авто, пошкоджені будинки.
  - (2026-07-07) Сухачов: До розслідування журналістів ДБР не отримувало інформації про можливі катування в "Скелі" | LEDE: Державне бюро розслідувань до публікації у виданні "Бабель" не отримувало інформації п] (uk:…
      Державне бюро розслідувань до публікації у виданні "Бабель" не отримувало інформації про можливі факти катування в 425-му окрему штурмовому полку "Скеля" ні від військового командування, ні від інших служб, були лише від…
  - (2026-07-07) Глава Міноборони Польщі звинуватив оточення Навроцького у брехні про ракети для України | LEDE: Міністр оборони Польщі Владислав Косіняк-Камиш заявив, що президент Кароль Навроцький був поінфор] (uk:…
      Міністр оборони Польщі Владислав Косіняк-Камиш заявив, що президент Кароль Навроцький був поінформований про передачу Україні ракет PAC-3 для систем Patriot, попри заяви його оточення про протилежне.
  - (2026-07-07) НАТО обрав шведський GlobalEye від Saab для заміни застарілих розвідувальних літаків | LEDE: Генеральний секретар НАТО Марк Рютте оголосив, що Альянс обрав літак GlobalEye компанії шведської ко] (uk:…
      Генеральний секретар НАТО Марк Рютте оголосив, що Альянс обрав літак GlobalEye компанії шведської компанії Saab для заміни свого парку літаків раннього попередження та управління (AWACS).

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-07) 424B3 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-07-07 12:24 UTC — Filed: 2026-07-07 AccNo: 0001918704-26-019394 Size: 1 MB
  - (2026-07-07) 424B3 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-07-07 12:24 UTC — Filed: 2026-07-07 AccNo: 0001918704-26-019394 Size: 1 MB
  - (2026-07-07) 424B3 - Wheeler Real Estate Investment Trust, Inc. (0001527541) (Filer)
      filed 2026-07-07 12:24 UTC — Filed: 2026-07-07 AccNo: 0001527541-26-000209 Size: 139 KB
  - (2026-07-07) 424B3 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-07-07 12:23 UTC — Filed: 2026-07-07 AccNo: 0001918704-26-019393 Size: 1 MB
  - (2026-07-07) 424B3 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-07-07 12:23 UTC — Filed: 2026-07-07 AccNo: 0001918704-26-019393 Size: 1 MB
  - (2026-07-07) 424B3 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-07-07 12:19 UTC — Filed: 2026-07-07 AccNo: 0001918704-26-019392 Size: 1 MB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-07) PAT636 (United States)
      icao24: adfe95 · position: (36.026, -82.622) · alt: 7932m · 440km/h
  - (2026-07-07) PAT591 (United States)
      icao24: adfe93 · position: (37.3827, -86.9406) · alt: 7924m · 398km/h
  - (2026-07-07) SAMU28 (France)
      icao24: 39ca85 · position: (47.4405, 0.7969) · alt: 251m · 205km/h
  - (2026-07-07) PAT561 (United States)
      icao24: adfdd1 · position: (39.9817, -74.3687) · alt: 2217m · 358km/h
  - (2026-07-07) GAF680 (Germany)
      icao24: 3e0f77 · position: (52.5847, 13.1827) · alt: 342m · 217km/h
  - (2026-07-07) SAMU06 (France)
      icao24: 39c901 · position: (43.2876, 5.4461) · alt: 274m · 230km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 27 new of 57 total
  - (2026-07-07) [BleepingComputer] Webinar tomorrow: Why modern email attacks require a new approach to defense
      Tomorrow's webinar explores how behavioral AI can help organizations detect sophisticated phishing, business email compromise, and account takeover attacks while reducing alert fatigue through automated investigation and…
  - (2026-07-07) [BleepingComputer] New Januscape Linux flaw allows VM escape on Intel, AMD devices
      A 16-year-old Linux kernel vulnerability, dubbed Januscape, allows attackers to escape a virtual machine and execute arbitrary code on the host. [...]
  - (2026-07-07) [BleepingComputer] Microsoft to enable Windows settings backup by default for orgs
      Microsoft says the Windows settings backup and restore tool will be enabled by default on Microsoft Entra-joined or Microsoft Entra hybrid-joined enterprise systems after upgrading to Windows 11 26H2. [...]
  - (2026-07-07) [BleepingComputer] BeyondTrust warns of critical flaws in remote access software
      BeyondTrust warned customers to patch two critical security flaws in its Remote Support (RS) and Privileged Remote Access (PRA) software that could allow attackers to bypass authentication. [...]
  - (2026-07-07) [BleepingComputer] Microsoft testing new Cloud Rebuild Windows 11 recovery feature
      Microsoft has begun testing the Cloud Rebuild recovery feature in the latest Windows 11 Insider Preview builds released for users in the Experimental channel. [...]
  - (2026-07-07) [The Hacker News] What Changes When Your Software Supply Chain Includes AI Writing Your Code?
      Software supply chain security was hard enough. Then AI joined the build pipeline. For five years, "software supply chain security" meant one question: what's in your code? Which open-source packages, which versions, whi…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Ukraine exposed a Russian weakness . NATO must exploit it
      stcatharinesstandard.ca · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Russia tanker operators step in as others in non - G7 fleet retreat amid flag clampdowns
      hellenicshippingnews.com · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Russian strikes kill 28 in Kyiv area , exposing Ukraine air - defence shortages
      dunyanews.tv · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Russian strikes kill 28 in Ukraine amid air defence strain
      pakistantoday.com.pk · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Latest Articles
      freerepublic.com · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Ukraine Invasion Day 1 , 594 : Omsk Refinery hit , 2500 km from the border
      dailykos.com · English · tone NA

### U.S. Federal Action — 17 new of 24 total
  - (2026-07-07) Revisions to Financial Forms Reporting and Filing Requirements; Correction
      The Federal Energy Regulatory Commission published a document in the Federal Register of June 24, 2026, concerning a notice of proposed rulemaking seeking comment on the Commission's proposal to amend certain annual and…
  - (2026-07-07) Endangered and Threatened Wildlife and Plants; Threatened Species Status With Section 4(d) Rule for the Kern Canyon Slender Salamander and Endangered Species Status for the Relictual Slender Salamande…
      We, the U.S. Fish and Wildlife Service (Service), are reopening the comment period on our October 18, 2022, proposed rule (2022 proposed rule), and November 21, 2023, revised proposed rule (2023 revised proposed rule) to…
  - (2026-07-07) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Application; Change of Sponsor
      The Food and Drug Administration (FDA or we) is amending the animal drug regulations to reflect application-related actions for new animal drug applications (NADAs), abbreviated new animal drug applications (ANADAs), and…
  - (2026-07-07) Performance Appraisal for General Schedule, Prevailing Rate, and Certain Other Employees
      The Office of Personnel Management (OPM) is issuing a final rule to increase the efficiency and effectiveness of performance management for non-Senior Executive Service (SES) employees, including General Schedule (GS) an…
  - (2026-07-07) Recission of the National Cancer Institute Clinical Cancer Education Program Regulation
      The Department of Health and Human Services (HHS), in consultation with the National Institutes of Health (NIH), is proposing to rescind the existing regulation concerning grants under the National Cancer Institute (NCI)…
  - (2026-07-07) Implementation of the National Environmental Policy Act
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to revise the NRC's regulations to streamline and modernize its implementation of the National Environmental Policy Act of 1969, as amended (NEPA). These proposed…

### Paper Trading Scorecard — 15 new of 136 total
  - (2026-07-07) [Polymarket] Will Indiana Pacers win the 2027 NBA Finals?
      This market will resolve to "Yes" if the listed team is determined as the champion of the NBA for the 2026-27 season. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed team to be name…
  - (2026-07-07) [Polymarket] Will STRC hit $100 by September 30?
      This market will resolve to "Yes" if any TradingView 1 minute candle for STRC between market creation and the listed date, 11:59 PM ET, has a final “High” value of at least $100. Otherwise, this market will resolve to "N…
  - (2026-07-07) [Polymarket] Exact Score: Switzerland 1 - 2 Colombia?
      In the upcoming FIFA World Cup game between Switzerland and Colombia, scheduled for July 7, 2026 at 4:00 PM ET: This market will resolve based on the final score of the Switzerland vs. Colombia match originally scheduled…
  - (2026-07-07) [Polymarket] Will Dallas Mavericks win the 2027 NBA Finals?
      This market will resolve to "Yes" if the listed team is determined as the champion of the NBA for the 2026-27 season. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed team to be name…
  - (2026-07-07) [Polymarket] Will Colombia win the 2026 FIFA World Cup?
      This market will resolve according to the national team that wins the 2026 FIFA World Cup. If at any point it becomes impossible for this team to win the FIFA World Cup based on the rules of FIFA (e.g., they are eliminat…
  - (2026-07-07) [Manifold] Hegseth, Patel, or RFK is out within the next 90 days

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-07) [South Korea] DAPA : Canada Picked Germany over S . Korea in Submarine Project Due to NATO Alliance
      world.kbs.co.kr · English
  - (2026-07-07) [South Korea] [ K - matrimony ] ③ More public aid for newlywed housing , weddings : Korea . net : The official website of the Republic of Korea
      korea.net · English
  - (2026-07-07) [South Korea] Gwangju school seeks leniency for players who mocked May 18 Democratization Movement
      koreaherald.com · English
  - (2026-07-07) [South Korea] For Trump as for Putin , the costs of wars are outweighing the benefits of winning them
      hani.co.kr · English
  - (2026-07-07) [South Korea] Samsung posts record 89 trillion won in Q2 operating profits
      english.hani.co.kr · English
  - (2026-07-07) [South Korea] Animals arent objects : Govt to hold debate on law revision
      koreaherald.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 112 total
  - (2026-07-07) [USASpending] $1,402,839,311 → AUSTAL USA, LLC: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESI
      Agency: Department of Homeland Security. Description: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESIGN AND PRODUCTION (DD&P) OF 11 OPCS.
  - (2026-07-07) [USASpending] $1,291,242,179 → AT&T ENTERPRISES, LLC: ENTERPRISE DATA NETWORK SERVICES CARRIER B
      Agency: Department of Veterans Affairs. Description: ENTERPRISE DATA NETWORK SERVICES CARRIER B
  - (2026-07-07) [USASpending] $1,288,706,729 → CALIFORNIA INSTITUTE OF TECHNOLOGY: M2020 MARS SCIENCE ROVER PROJECT-PHASE A-D 60-19107 THE CON
      Agency: National Aeronautics and Space Administration. Description: M2020 MARS SCIENCE ROVER PROJECT-PHASE A-D 60-19107 THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION N…
  - (2026-07-07) [USASpending] $1,167,667,763 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD
  - (2026-07-07) [USASpending] $1,018,603,974 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)
  - (2026-07-07) [USASpending] $990,004,958 → CH2M HILL BWXT WEST VALLEY, LLC: THE DEPARTMENT OF ENERGY (DOE) HEREBY ISSUES FINAL REQUEST F
      Agency: Department of Energy. Description: THE DEPARTMENT OF ENERGY (DOE) HEREBY ISSUES FINAL REQUEST FOR PROPOSALS (RFP) NO. DE-SOL-0002084 PERTAINING TO THE PHASE 1 DECOMMISSIONING - FACILITY DISPOSITION ACTIVITIES TO…

### GDACS — global disaster alerts — 11 new of 151 total
  - (2026-06-06) [Orange] Flood in China
      Flood · Orange alert · China · Magnitude 0
  - (2026-06-06) [Orange] Flood in China
      Flood · Orange alert · China · Magnitude 0
  - (2026-06-06) [Orange] Flood in China
      Flood · Orange alert · China · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0

### Court opinions of consequence (federal & state) — 7 new of 60 total
  - (2026-07-06) U.S. Court of Appeals, 7th Cir.: E. E. V. v. Todd W. Blanche
  - (2026-07-06) U.S. Court of Appeals, 7th Cir.: E. E. V. v. Todd W. Blanche
  - (2026-07-06) U.S. Court of Appeals, 5th Cir.: Pharm Research and Mfr v. Murrill
  - (2026-07-01) U.S. Court of Appeals, 3rd Cir.: United States v. Brandon Aumiller
  - (2026-07-01) U.S. Court of Appeals, 3rd Cir.: United States v. Miguel Rosario
  - (2026-07-01) U.S. Court of Appeals, 3rd Cir.: United States v. Noah Craddock

### USGS earthquakes (M4.5+, past day) — 6 new of 12 total
  - (2026-07-07) M 5.8 - 296 km SSE of Ushuaia, Argentina
      M5.8 · 296 km SSE of Ushuaia, Argentina · depth 10 km
  - (2026-07-07) M 5.4 - 162 km NNW of Tobelo, Indonesia
      M5.4 · 162 km NNW of Tobelo, Indonesia · depth 36.821 km
  - (2026-07-07) M 5.3 - Reykjanes Ridge
      M5.3 · Reykjanes Ridge · depth 10 km
  - (2026-07-07) M 5.0 - Reykjanes Ridge
      M5.0 · Reykjanes Ridge · depth 10 km
  - (2026-07-07) M 5.0 - Reykjanes Ridge
      M5.0 · Reykjanes Ridge · depth 10 km
  - (2026-07-07) M 4.5 - 32 km NE of Yaguaraparo, Venezuela
      M4.5 · 32 km NE of Yaguaraparo, Venezuela · depth 126.81 km

### Prediction Markets — most-traded (Polymarket) — 6 new of 20 total
  - (2026-07-07) Argentina vs. Egypt: Team to Advance
      yes price: 86% · 24h volume: $3,054,112 · resolves 2026-07-07
  - (2026-07-07) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $2,846,502 · resolves 2026-06-01
  - (2026-07-07) Will Mahmoud Abbas be the next leader out before 2027?
      yes price: 0% · 24h volume: $2,445,743 · resolves 2026-12-31
  - (2026-07-07) Will Argentina win on 2026-07-07?
      yes price: 72% · 24h volume: $1,832,366 · resolves 2026-07-07
  - (2026-07-07) Will Egypt win on 2026-07-07?
      yes price: 8% · 24h volume: $1,569,569 · resolves 2026-07-07
  - (2026-07-07) Will the Los Angeles Chargers win the 2027 NFL league championship?
      yes price: 4% · 24h volume: $1,116,336 · resolves 2027-03-31

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-07) [Marginal Revolution] From Prediction Markets to Decision Markets and Beyond!
      Arin Dube points to a great illustration of the power of prediction markets. Yesterday due to a new scandal the probability that Graham Platner would drop out of the Maine Democratic primary exploded from 9% to 96% (+87…
  - (2026-07-07) [Marginal Revolution] What should I ask Liaquat Ahamed?
      Yes I will be doing a Conversation with him. From Wikipedia: Ahamed is the author of Lords of Finance: The Bankers Who Broke the World (2009). The book was awarded the 2010 Pulitzer Prize for History, the 2010 Spear’s Bo…
  - (2026-07-07) [Marginal Revolution] Wiesbaden notes
      Who goes to Wiesbaden these days? The era of Russian nobles taking the cure here and gambling is long since gone. And yet here we are. The proximate cause of this trip is the desire to see Grigory Sokolov, one of the wor…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 1 new of 32 total
  - (2026-07-07) MOVER ▲ Francoise Bettencourt Meyers & family — $95.51B (+$0.35B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=26, 14d-median=26; carrying terms: document, amend, issuing, specifically, reporting, including, guard, entry, authorized, needed, protect, filing
- state_bills: today=0, 7d-median=153, 14d-median=153
- state_news: today=445, 7d-median=452, 14d-median=452; carrying terms: group, enough, trust, complete, joseph, decades, discovered, nevada, facilities, leadership, signing, tennessee
- local_news: today=217, 7d-median=222, 14d-median=222; carrying terms: group, underway, arrest, height, neighborhood, restaurant, class, street, change, sandy, streets, health
- foreign_news: today=1031, 7d-median=1038, 14d-median=1038; carrying terms: turns, singapore, group, organizers, ended, trust, cloudfront, tibet, profile, arrest, delhi, entrants
- chinese_internal: today=276, 7d-median=281, 14d-median=281; carrying terms: caixin, cbmickfvx, cbmiy, cbmib, cbmia, articles, color, blank, google, target, cbmibefvx, cbmidefvx
- russian_internal: today=984, 7d-median=984, 14d-median=984; carrying terms: client, https, forex, gazeta, forbidden, group, title, mercedes, telegraph, found, politico, novaya
- ukrainian_internal: today=118, 7d-median=122, 14d-median=122; carrying terms: terminal, group, caused, warsaw, damaging, russia, leadership, facilities, arguing, industrial, plans, assessment
- ukraine_theater: today=327, 7d-median=557, 14d-median=557; carrying terms: cuxnm, vndfpcczbbuy, pszvnnnbhvxdrv, emvqedfqr, cuxnzghps, cbmilafbvv, cuxndxrazjjix, vxdfx, russia, leadership, cbmimwfbvv, cnbfufllb
- paper_bets: today=136, 7d-median=138, 14d-median=138; carrying terms: johnny, football, matthew, washington, refers, council, trust, becomes, emirates, koivun, evans, predictit
- weather: today=127, 7d-median=163, 14d-median=163; carrying terms: forecast, caused, southern, japan, columbia, impact, stroke, afdmeg, heights, minor, cyclones, radar
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, headline, openings, nonfarm, money, cpiaucsl, labor, dexuseu, cpilfesl, jolts, pcepilfe, recession
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, commodities, crypto, credit, natural, agriculture, futures, rates, crude, silver, close, range
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=112, 7d-median=106, 14d-median=106; carrying terms: cbmizefvx, funds, council, bombing, contract, effects, nicaragua, institute, transnistria, russia, evolution, latinscript
- congressional_trades: today=1, 7d-median=68, 14d-median=68
- billionaires: today=32, 7d-median=40, 14d-median=40; carrying terms: changpeng, bernard, technologies, cryptocurrency, infrastructure, holdings, since, japan, france, masayoshi, finance, huang
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, corporation, blanche, hernandez, court, services, academy, james, michael, general, american, county
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, holdings, accno, filed, reporting, chase, filer, jpmorgan, financial
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: krishnamoorthi, group, disbursements, house, brown, angels, sherrod, cortez, raised, chartered, groom, james
- gdelt_regions: today=12, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, trump, russian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, kingdom, germany, canada, france
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: distributed, measles, patient, containing, caused, focus, published, elements, january, spain, eight, influenza
- cisa_kev: today=8, 7d-median=9, 14d-median=9; carrying terms: authentication, manager, product, improper, control, vendor, remediation, injection, traversal, access, cisco, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=151, 7d-median=133, 14d-median=133; carrying terms: philippines, green, latvia, japan, hungary, forest, islands, wildfire, fires, speed, impact, vietnam
- usgs_quakes: today=12, 7d-median=14, 14d-median=14; carrying terms: japan, depth, indonesia, tobelo
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, argentina, resolves, world, volume, ethiopia, belgium, morocco, england, switzerland, prime, minister
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, class, revolution, conversableeconomist, conversable, marginal, world, economist, short, governments
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: strategic, hackers, advertising, review, centers, computer, including, israeli, botnet, foreign, computerweekly, attacks
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: budzinski, becca, doris, bernard, garamendi, tillis, krishnamoorthi, analilia, buchanan, duyne, hegseth, guest
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, paper, module, unavailable, converges, market, today, markets, claude, placement, either, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-24] Fed speeches: Cook, Welcome Remarks
- [2026-06-24] Fed press (events + announcements): Federal Reserve Board's annual bank stress test confirms that large banks are well positioned to weather a severe recession and able to continue to lend to households and businesses
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board issues enforcement action with employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Jiko Group, Inc.
- [2026-06-27] ECB press: Isabel Schnabel: Is inflation back?
- [2026-06-29] ECB press: Christine Lagarde: Back to basics in an uncertain environment
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2028
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2027
- [2026-06-30] Fed press (events + announcements): Agencies release list of distressed or underserved nonmetropolitan middle-income geographies
- [2026-07-01] Fed press (events + announcements): Federal Reserve issues initial findings from its 2025 triennial payments study
- [2026-07-02] ECB press: Frank Elderson: The green transition – benefits and barriers
- [2026-07-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Small Business Bank and announces termination enforcement actions with BNP Paribas S.A., BNP Paribas USA, Inc., BNP Paribas Securities Corp., and Community Bankshares, Inc.
- [2026-07-02] ECB press: Piero Cipollone: The digital transformation of money, payments and finance
- [2026-07-02] ECB press: Christine Lagarde: Interview with Les Échos
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*