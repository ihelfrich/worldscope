# WORLDSCOPE morning brief — 2026-07-07

## Headline
2254 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (573) · Russian Internal News (state + in-exile) (472) · World leaders & government officials (324) · Chinese Internal News (203) · Ukraine Theater (total-war monitoring) (166) · U.S. Weather + Severe / Climate Outlooks (110) · State-Level News (92) · Local News: St. Louis + Atlanta (76) · Ukrainian Internal News (national + local Kyiv) (40) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30) · GDELT GKG — themes / entities / watch areas (25)

## What changed today
### International News + Multilateral Institutions — 573 new of 1003 total
  - (2026-07-06) [Global] Banks accused of pushing customers away from basic accounts
      Some of the UK's biggest banks have been failing their most vulnerable customers, according to the financial regulator.
  - (2026-07-07) [Global] Samsung profits jump 1,800% as AI chip sales soar
      The firm's shares fell sharply on Tuesday as some investors had expected an even stronger performance.
  - (2026-07-06) [Global] Phone contract comparisons 'amounted to mis-selling' student loans, MPs say
      A new report says students were not well-enough informed that their loan terms could change retrospectively.
  - (2026-07-06) [Global] Robots available for rent: But what can they do?
      Robotics tech is changing fast, so for many it makes sense to rent a robot.
  - (2026-07-07) [Global] E-bike injury payouts top £110m and push up insurance premiums
      It is only seven years since the first claim over an injury from a micromobility vehicle was made.
  - (2026-07-07) [Global] Volunteers racing to save surplus Silverstone food
      A Towcester community larder is collecting produce from the circuit following the Grand Prix.

### Russian Internal News (state + in-exile) — 472 new of 907 total
  - (2026-07-07) В Крыму заработал аварийный роуминг. Абоненты смогут подключаться к сетям других операторов при блэкауте (но доступны будут только сайты из «белого списка») | LEDE: Мобильные операторы Крыма] (ru: В К…
      Мобильные операторы Крыма предупредили о включении аварийного роуминга на всей территории аннексированного региона.
  - (2026-07-07) Бельгия выбивает США и издевательски исполняет «танец Трампа». Роналду плачет после поражения от Испании — он больше никогда не сыграет на чемпионате мира. Что там на ЧМ? Суперкоротко | LEDE: <] (ru:…
      Кто как с кем сыграл. Испания обыграла Португалию 1:0, для Криштиану Роналду, по его собственным словам, этот матч стал последним на чемпионатах мира. Итоги шести ЧМ для португальца: 27 матчей, 11 голов, лучший результат…
  - (2026-07-07) Группа Lumen удалила со стримингов песню «Государство». Из-за ее текста прокуратура требовала привлечь к ответственности лидера коллектива | LEDE: Песня «Государство» группы Lumen пропала из] (ru: Гру…
      Песня «Государство» группы Lumen пропала из стримингов «Яндекс.Музыка», Spotify и Apple. На это обратил внимание телеграм-канал «Родной звук».
  - (2026-07-07) В Дамаске произошли два взрыва — рядом с отелем, где остановился Макрон | LEDE: В столице Сирии Дамаске утром 7 июля произошли два взрыва, пишут AFP, Reuters и «Аль Джазира». ] (ru: В Дамаске произошл…
      В столице Сирии Дамаске утром 7 июля произошли два взрыва, пишут AFP, Reuters и «Аль Джазира».
  - (2026-07-07) «Украинская правда»: под Киевом нашли убитой женщину, которую подозревают в покушении на украинского бизнесмена Вадима Ермолаева в Монако | LEDE: Вечером 6 июля под Киевом нашли застреленной] (ru: «Ук…
      Вечером 6 июля под Киевом нашли застреленной женщину, подозреваемую в покушении на украинского бизнесмена Вадима Ермолаева в Монако, сообщает «Украинская правда» со ссылкой на источники в правоохранительных органах.
  - (2026-07-07) Бывшего советника Ильи Яшина в Красносельском районе Москвы арестовали по делу о «фейках» про армию | LEDE: Замоскворецкий суд арестовал бывшего советника главы Красносельского округа Москвы] (ru: Быв…
      Замоскворецкий суд арестовал бывшего советника главы Красносельского округа Москвы Кирилла Суворова по делу о распространении «фейков» про армию, пишут «Осторожно, новости».

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 203 new of 266 total
  - (2026-07-07) 今日开盘：两市双双低开 沪指跌幅0.54% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5jcjNEMjhZSUVMczVVaXlaVlE5TGRKMU5zVVlIR2VIZWhTN2ltMHNlTXJ0X3VhSWwwRFVIOEhDeXAwSUplUURKNFBRVUJXdUNr] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.54% 财新
  - (2026-07-07) 现代心理学三位奠基人都对儿女说什么｜心理 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Tc0psRlRaWGxVdDdYMEQ4YS1TWlUtck1UNFN2dGFIbXlLNEtKSHJ0OUpsVTdYalpKMmlFVVk2SW5WNXFuNGY3U3JUNkk4OEI2d] (zh:…
      现代心理学三位奠基人都对儿女说什么｜心理 财新
  - (2026-07-07) 事关儿童接种疫苗 国家疾控局等部门发布新版说明 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5TMkNBWkJoMWhhRXJIR0hEM256V1o1N2tQdmQ2UXpqdTNNbXJoWGhZMkRaRlA1aHo4U1J1dWpPbWZWWjQ2bW9GOTNlZ0EtMn] (zh:…
      事关儿童接种疫苗 国家疾控局等部门发布新版说明 财新
  - (2026-07-07) 人事观察｜曾长期任职南京 “75后”谢元履新天津市委常委 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9id3htRFRGWEF0cUwtYWkxWWMzUjEwaS1aX0tXVGRFd1l6dHNsVHNMS2V3UXBqSnpmdHVFYVF2bXV] (zh:…
      人事观察｜曾长期任职南京 “75后”谢元履新天津市委常委 china.caixin.com
  - (2026-07-07) 火线评论｜受贿超22亿，杨有林真正伤害的是什么？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBpXzU1X2E0U3RFSGFMWWlpUFktX3NsWEoyX1o0MEFwOVFZb1ZZNVVqU1ZDWVFSQkpfbEdfMW56Rm5ueWZERk4xSzJOU3dCb] (zh:…
      火线评论｜受贿超22亿，杨有林真正伤害的是什么？ 财新
  - (2026-07-07) 王君：格林斯潘是错在相信市场万能吗 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9VbDVaMkNrT3hLdkg2UEx2NEkwUmVBQkNJSTVMRkEyYTlnejU4QkdCNEc4YmVxeTJCeTVQc1Z6SnA3N0dpdjllMFU0enVQWHphSVFR] (zh:…
      王君：格林斯潘是错在相信市场万能吗 财新

### Ukraine Theater (total-war monitoring) — 166 new of 498 total
  - (2026-07-07) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-06) [FIRMS] thermal anomaly 51.892, 29.336 (FRP 2 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-06 2303Z, FRP 2 MW
  - (2026-07-06) [FIRMS] thermal anomaly 51.813, 33.650 (FRP 0.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-06 2303Z, FRP 0.86 MW
  - (2026-07-06) [FIRMS] thermal anomaly 51.807, 33.649 (FRP 0.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-06 2303Z, FRP 0.86 MW
  - (2026-07-06) [FIRMS] thermal anomaly 51.331, 34.631 (FRP 0.33 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-06 2303Z, FRP 0.33 MW
  - (2026-07-06) [FIRMS] thermal anomaly 51.328, 34.631 (FRP 0.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-06 2303Z, FRP 0.92 MW

### U.S. Weather + Severe / Climate Outlooks — 110 new of 131 total
  - (2026-07-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-07) [Moderate] Special Weather Statement: Special Weather Statement issued July 7 at 5:02AM CDT by NWS Shreveport LA
      At 502 AM CDT, Doppler radar was tracking a strong thunderstorm near Queen City, or near Atlanta, moving east at 20 mph. HAZARD...Wind gusts up to 40 mph and half inch size hail. SOURCE...Radar indicated. IMPACT...Gusty…
  - (2026-07-07) [Moderate] Special Weather Statement: Special Weather Statement issued July 7 at 6:00AM EDT by NWS Jackson KY
      Mostly clear skies, light winds, and plenty of low-level moisture from recent rains helped areas of dense fog to develop early this morning. Visibilities will be below a quarter of a mile at times in the thickest of the…
  - (2026-07-07) [Moderate] Hazardous Seas Watch: Hazardous Seas Watch issued July 7 at 2:53AM PDT until July 8 at 11:00PM PDT by NWS Medford OR
      * WHAT...Very steep and hazardous seas 7 to 10 ft at 7 seconds possible. * WHERE...Waters south of Gold Beach and within 30 nm of shore * WHEN...From Wednesday morning through Wednesday evening. * IMPACTS...Very steep an…
  - (2026-07-07) [Moderate] Hazardous Seas Watch: Hazardous Seas Watch issued July 7 at 2:53AM PDT until July 8 at 11:00PM PDT by NWS Medford OR
      * WHAT...Very steep and hazardous seas 7 to 10 ft at 7 seconds possible. * WHERE...Waters south of Gold Beach and within 30 nm of shore. * WHEN...From Wednesday morning through Wednesday evening. * IMPACTS...Very steep a…
  - (2026-07-07) [Moderate] Special Weather Statement: Special Weather Statement issued July 7 at 4:47AM CDT by NWS Shreveport LA
      At 447 AM CDT, Doppler radar was tracking a strong thunderstorm 9 miles northwest of Bogata, or 15 miles west of Clarksville, moving southeast at 20 mph. HAZARD...Wind gusts up to 40 mph and half inch size hail. SOURCE..…

### State-Level News — 92 new of 420 total
  - (2026-07-07) [California] Governor Newsom signs legislation 7.6.26
      Source
  - (2026-07-07) [Connecticut] Josh Elliott swings big in first commercial
      <img width="1024" height="568" src="https://ctmirror.org/wp-content/uploads/2026/07/Image-7-6-26-at-3.02-PM-1024x568.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-07-07) [Connecticut] Proposed golf facility violates UConn’s environmental responsibility
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/06/No-Golf-1-1024x768.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcs…
  - (2026-07-07) [Arizona] A year after Trump’s One Big Beautiful Bill, Arizona Democrats warn coverage losses are mounting
      A year after President Donald Trump signed the “One Big Beautiful Bill Act” to cut taxes and slash spending on healthcare and other programs aimed at helping lower income Americans, Democrats in Arizona are sounding the…
  - (2026-07-07) [Arkansas] As Trump buyouts shake offshore wind industry, states hope developers stay in the game
      President Donald Trump has shown the immense power of the executive branch to stymie offshore wind development, as nearly all projects are in waters where federal agencies operate as the landlord. Now, as the feds block…
  - (2026-07-07) [Alaska] Wrongfully convicted Alaskans can now apply for withheld PFDs under new law
      Alaskans who have been wrongfully convicted can now apply to claim Alaska Permanent Fund dividends that were withheld while they were incarcerated, under a new law. The Alaska Legislature passed Senate Bill 167 by a comb…

### Local News: St. Louis + Atlanta — 76 new of 213 total
  - (2026-07-07) [St. Louis] Two more St. Louisans are named Eisenhower Fellows
      It’s safe to say St. Louis knows a thing or two about the Eisenhower Fellowships: Two locals have been named fellows in the organization’s 2026 Innovative Entrepreneurs Program from a pool of more than 500 applications,…
  - (2026-07-07) [St. Louis] Where Art Thou 7/7/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-07-07) [St. Louis] More video expected during hearing in case against man accused of assassinating Charlie Kirk
      The court proceedings began Monday and so far have produced no major revelations about the right-wing commentator's assassination.
  - (2026-07-07) [St. Louis] Maine Democrats have until July 13 to replace Graham Platner on the ballot if he drops out
      Platner denied the sexual assault allegation but said he would be considering next steps for his campaign.
  - (2026-07-07) [St. Louis] Did anyone win the $416 million Powerball Jackpot?
      Powerball drew its numbers Monday night, with a jackpot worth an estimated $416 million available to win.
  - (2026-07-07) [St. Louis] Tanker set ablaze after being struck by projectile in the Strait of Hormuz off the coast of Oman
      The attack was the latest targeting a vessel moving through the narrow mouth of the Persian Gulf.

### Ukrainian Internal News (national + local Kyiv) — 40 new of 113 total
  - (2026-07-07) В партії Трампа висувають умові для потепління з Туреччиною: російські С-400 має піти | LEDE: Ліндсі Грем заявив, що продаж F-35 Туреччині можливий лише після відмови від С-400.] (uk: В партії Трампа…
      Ліндсі Грем заявив, що продаж F-35 Туреччині можливий лише після відмови від С-400.
  - (2026-07-07) НАТО закупить розвідувальні безпілотники Triton | LEDE: Союзники по НАТО планують придбати до п’яти розвідувальних безпілотників великої дальності MQ-4C Triton, які виробляє американська компан] (uk:…
      Союзники по НАТО планують придбати до п’яти розвідувальних безпілотників великої дальності MQ-4C Triton, які виробляє американська компанія Northrop Grumman.
  - (2026-07-07) В Нідерландах заявили, що вичерпали можливості надавати Україні військову допомогу | LEDE: Міністерка оборони Нідерландів Ділан Єшилгьоз-Зегеріус каже, що її країна більше не має можливості над] (uk:…
      Міністерка оборони Нідерландів Ділан Єшилгьоз-Зегеріус каже, що її країна більше не має можливості надавати пряму військову підтримку Україні.
  - (2026-07-07) У Литві сподіваються на прояснення ситуації щодо присутності американських військ | LEDE: Литва сподівається найближчими днями отримати більше ясності щодо майбутнього американських військ у кр] (uk:…
      Литва сподівається найближчими днями отримати більше ясності щодо майбутнього американських військ у країні на тлі того, як президент Гітанас Науседа вирушає на саміт НАТО в Анкару, де він сподівається зустрітися зі свої…
  - (2026-07-07) Drone Edge: НАТО виділить понад $40 млрд на засоби протидії безпілотникам | LEDE: НАТО запускає проєкт Drone Edge з інвестиціями $40 млрд для протидії дронам і підготовки операторів.] (uk: Drone Edge:…
      НАТО запускає проєкт Drone Edge з інвестиціями $40 млрд для протидії дронам і підготовки операторів.
  - (2026-07-07) Президент запровадив санкції проти Берези, екснардеп каже, що має "бінго" санкцій від Путіна і Зеленського | LEDE: Президент Володимир Зеленський увів у дію рішення РНБО про санкції, зокрема пр] (uk:…
      Президент Володимир Зеленський увів у дію рішення РНБО про санкції, зокрема проти колишнього народного депутата Борислава Берези. Екснардеп заявив, що пов'язує це зі своєю критикою влади, і зазначив, що тепер має санкції…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-07) [O'Rourke Peter] Form 4 (Reporting)
      filed 2026-07-07 10:02 UTC · role: Reporting — Filed: 2026-07-07 AccNo: 0001213900-26-075719 Size: 5 KB
  - (2026-07-07) [Quantum Cyber N.V.] Form 4 (Issuer)
      filed 2026-07-07 10:02 UTC · role: Issuer — Filed: 2026-07-07 AccNo: 0001213900-26-075719 Size: 5 KB
  - (2026-07-07) 424B2 - Jefferies Financial Group Inc. (0000096223) (Filer)
      filed 2026-07-07 10:02 UTC — Filed: 2026-07-07 AccNo: 0001140361-26-027698 Size: 896 KB
  - (2026-07-07) 424B2 - PROSPECT CAPITAL CORP (0001287032) (Filer)
      filed 2026-07-07 10:01 UTC — Filed: 2026-07-07 AccNo: 0001287032-26-000222 Size: 2 MB
  - (2026-07-07) [EchoStar CORP] Form 4 (Issuer)
      filed 2026-07-07 10:00 UTC · role: Issuer — Filed: 2026-07-07 AccNo: 0001197815-26-000001 Size: 7 KB
  - (2026-07-07) [ORBAN PAUL W] Form 4 (Reporting)
      filed 2026-07-07 10:00 UTC · role: Reporting — Filed: 2026-07-07 AccNo: 0001197815-26-000001 Size: 7 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Russian strikes kill 28 in Kyiv area , exposing Ukraine air - defence shortages
      dunyanews.tv · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Russian strikes kill 28 in Ukraine amid air defence strain
      pakistantoday.com.pk · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Latest Articles
      freerepublic.com · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Ukraine Invasion Day 1 , 594 : Omsk Refinery hit , 2500 km from the border
      dailykos.com · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Latest Articles
      freerepublic.com · English · tone NA
  - (2026-07-07) [Russia oil sanctions perimeter · keywords] Latest Articles
      freerepublic.com · English · tone NA

### U.S. Federal Action — 17 new of 24 total
  - (2026-07-07) Revisions to Financial Forms Reporting and Filing Requirements; Correction
      The Federal Energy Regulatory Commission published a document in the Federal Register of June 24, 2026, concerning a notice of proposed rulemaking seeking comment on the Commission's proposal to amend certain annual and…
  - (2026-07-07) Endangered and Threatened Wildlife and Plants; Threatened Species Status With Section 4(d) Rule for the Kern Canyon Slender Salamander and Endangered Species Status for the Relictual Slender Salamande…
      We, the U.S. Fish and Wildlife Service (Service), are reopening the comment period on our October 18, 2022, proposed rule (2022 proposed rule), and November 21, 2023, revised proposed rule (2023 revised proposed rule) to…
  - (2026-07-07) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Application; Change of Sponsor
      The Food and Drug Administration (FDA or we) is amending the animal drug regulations to reflect application-related actions for new animal drug applications (NADAs), abbreviated new animal drug applications (ANADAs), and…
  - (2026-07-07) Performance Appraisal for General Schedule, Prevailing Rate, and Certain Other Employees
      The Office of Personnel Management (OPM) is issuing a final rule to increase the efficiency and effectiveness of performance management for non-Senior Executive Service (SES) employees, including General Schedule (GS) an…
  - (2026-07-07) Recission of the National Cancer Institute Clinical Cancer Education Program Regulation
      The Department of Health and Human Services (HHS), in consultation with the National Institutes of Health (NIH), is proposing to rescind the existing regulation concerning grants under the National Cancer Institute (NCI)…
  - (2026-07-07) Implementation of the National Environmental Policy Act
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to revise the NRC's regulations to streamline and modernize its implementation of the National Environmental Policy Act of 1969, as amended (NEPA). These proposed…

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 52 total
  - (2026-07-07) [BleepingComputer] Microsoft to enable Windows settings backup by default for orgs
      Microsoft says the Windows settings backup and restore tool will be enabled by default on Microsoft Entra-joined or Microsoft Entra hybrid-joined enterprise systems after upgrading to Windows 11 26H2. [...]
  - (2026-07-07) [BleepingComputer] BeyondTrust warns of critical flaws in remote access software
      BeyondTrust warned customers to patch two critical security flaws in its Remote Support (RS) and Privileged Remote Access (PRA) software that could allow attackers to bypass authentication. [...]
  - (2026-07-07) [BleepingComputer] Microsoft testing new Cloud Rebuild Windows 11 recovery feature
      Microsoft has begun testing the Cloud Rebuild recovery feature in the latest Windows 11 Insider Preview builds released for users in the Experimental channel. [...]
  - (2026-07-07) [The Hacker News] Suspected China-Aligned Hackers Exploit Roundcube Flaws Against Universities
      A suspected China-aligned threat activity cluster has been observed exploiting Roundcube webmail software belonging to physics and engineering departments of U.S. and Canadian universities as part of a new campaign. The…
  - (2026-07-07) [The Hacker News] CERT/CC Warns of Hidden Admin Backdoor in Tenda Router Firmware
      Several versions of firmware released by Chinese network device manufacturer Tenda have been found to embed an undocumented authentication backdoor that enables administrative access to the devices' web management interf…
  - (2026-07-07) [The Hacker News] BeyondTrust Patches Critical Auth Bypass Flaws in Remote Support and PRA
      BeyondTrust has released updates to address two critical security flaws affecting Remote Support (RS) and Privileged Remote Access (PRA) products that, if successfully exploited, could allow unauthenticated attackers to…

### Paper Trading Scorecard — 13 new of 135 total
  - (2026-07-07) [Polymarket] Will Indiana Pacers win the 2027 NBA Finals?
      This market will resolve to "Yes" if the listed team is determined as the champion of the NBA for the 2026-27 season. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed team to be name…
  - (2026-07-07) [Polymarket] Will STRC hit $100 by September 30?
      This market will resolve to "Yes" if any TradingView 1 minute candle for STRC between market creation and the listed date, 11:59 PM ET, has a final “High” value of at least $100. Otherwise, this market will resolve to "N…
  - (2026-07-07) [Polymarket] Will Dallas Mavericks win the 2027 NBA Finals?
      This market will resolve to "Yes" if the listed team is determined as the champion of the NBA for the 2026-27 season. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed team to be name…
  - (2026-07-07) [Polymarket] Switzerland vs. Colombia: O/U 3.5
      In the upcoming FIFA World Cup game between Switzerland and Colombia, scheduled for July 7 at 4:00 PM ET: This market will resolve to "Over" if Switzerland and Colombia combine to score 4 or more goals in this game. If t…
  - (2026-07-07) [Polymarket] Will Colombia win the 2026 FIFA World Cup?
      This market will resolve according to the national team that wins the 2026 FIFA World Cup. If at any point it becomes impossible for this team to win the FIFA World Cup based on the rules of FIFA (e.g., they are eliminat…
  - (2026-07-07) [Manifold] Argentina and Colombia both win their round of 16 match?

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 110 total
  - (2026-07-07) [USASpending] $1,402,839,311 → AUSTAL USA, LLC: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESI
      Agency: Department of Homeland Security. Description: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESIGN AND PRODUCTION (DD&P) OF 11 OPCS.
  - (2026-07-07) [USASpending] $1,291,242,179 → AT&T ENTERPRISES, LLC: ENTERPRISE DATA NETWORK SERVICES CARRIER B
      Agency: Department of Veterans Affairs. Description: ENTERPRISE DATA NETWORK SERVICES CARRIER B
  - (2026-07-07) [USASpending] $1,288,706,729 → CALIFORNIA INSTITUTE OF TECHNOLOGY: M2020 MARS SCIENCE ROVER PROJECT-PHASE A-D 60-19107 THE CON
      Agency: National Aeronautics and Space Administration. Description: M2020 MARS SCIENCE ROVER PROJECT-PHASE A-D 60-19107 THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION N…
  - (2026-07-07) [USASpending] $1,167,667,763 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD
  - (2026-07-07) [USASpending] $1,018,603,974 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)
  - (2026-07-07) [USASpending] $990,004,958 → CH2M HILL BWXT WEST VALLEY, LLC: THE DEPARTMENT OF ENERGY (DOE) HEREBY ISSUES FINAL REQUEST F
      Agency: Department of Energy. Description: THE DEPARTMENT OF ENERGY (DOE) HEREBY ISSUES FINAL REQUEST FOR PROPOSALS (RFP) NO. DE-SOL-0002084 PERTAINING TO THE PHASE 1 DECOMMISSIONING - FACILITY DISPOSITION ACTIVITIES TO…

### GDACS — global disaster alerts — 11 new of 155 total
  - (2026-06-06) [Orange] Flood in China
      Flood · Orange alert · China · Magnitude 0
  - (2026-06-06) [Orange] Flood in China
      Flood · Orange alert · China · Magnitude 0
  - (2026-06-06) [Orange] Flood in China
      Flood · Orange alert · China · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0

### Court opinions of consequence (federal & state) — 10 new of 60 total
  - (2026-07-06) U.S. Court of Appeals, 7th Cir.: E. E. V. v. Todd W. Blanche
  - (2026-07-06) U.S. Court of Appeals, 7th Cir.: E. E. V. v. Todd W. Blanche
  - (2026-07-06) U.S. Court of Appeals, 5th Cir.: Pharm Research and Mfr v. Murrill
  - (2026-07-01) U.S. Court of Appeals, 3rd Cir.: United States v. Brandon Aumiller
  - (2026-07-01) U.S. Court of Appeals, 3rd Cir.: United States v. Miguel Rosario
  - (2026-07-01) U.S. Court of Appeals, 3rd Cir.: United States v. Noah Craddock

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 39 total
  - (2026-07-07) MOVER ▼ Masayoshi Son — $68.32B ($-2.27B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-07) MOVER ▲ Francoise Bettencourt Meyers & family — $95.16B (+$2.23B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-07) MOVER ▼ Gautam Adani — $89.01B ($-1.36B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-07) MOVER ▼ Mukesh Ambani — $89.52B ($-0.79B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-07) MOVER ▲ Tadashi Yanai & family — $73.28B (+$0.71B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-07) MOVER ▲ Bill Gates — $106.75B (+$0.08B since yesterday)
      United States · Technology · source: Microsoft

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-07) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-07) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-07) [China] Importanti istruzioni di Xi Jinping sulla prevenzione delle inondazioni e i soccorsi in caso di calamità
      italian.cri.cn · English
  - (2026-07-07) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-07) [China] Conto alla rovescia : 100 giorni allapertura della 140ª edizione della Fiera di Guangdong
      italian.cri.cn · English
  - (2026-07-07) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English

### Prediction Markets — most-traded (Polymarket) — 6 new of 20 total
  - (2026-07-07) Argentina vs. Egypt: Team to Advance
      yes price: 86% · 24h volume: $2,279,511 · resolves 2026-07-07
  - (2026-07-07) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $2,234,502 · resolves 2026-06-01
  - (2026-07-07) Will Argentina win on 2026-07-07?
      yes price: 72% · 24h volume: $1,520,377 · resolves 2026-07-07
  - (2026-07-07) Will the Los Angeles Chargers win the 2027 NFL league championship?
      yes price: 4% · 24h volume: $1,249,237 · resolves 2027-03-31
  - (2026-07-07) Will there be no change in Fed interest rates after the July 2026 meeting?
      yes price: 84% · 24h volume: $1,206,092 · resolves 2026-07-29
  - (2026-07-07) Will Mahmoud Abbas be the next leader out before 2027?
      yes price: 0% · 24h volume: $1,100,269 · resolves 2026-12-31

### USGS earthquakes (M4.5+, past day) — 5 new of 12 total
  - (2026-07-07) M 5.8 - 296 km SSE of Ushuaia, Argentina
      M5.8 · 296 km SSE of Ushuaia, Argentina · depth 10 km
  - (2026-07-07) M 5.4 - 162 km NNW of Tobelo, Indonesia
      M5.4 · 162 km NNW of Tobelo, Indonesia · depth 36.821 km
  - (2026-07-07) M 5.3 - Reykjanes Ridge
      M5.3 · Reykjanes Ridge · depth 10 km
  - (2026-07-07) M 5.0 - Reykjanes Ridge
      M5.0 · Reykjanes Ridge · depth 10 km
  - (2026-07-07) M 5.0 - Reykjanes Ridge
      M5.0 · Reykjanes Ridge · depth 10 km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-07) [Marginal Revolution] What should I ask Liaquat Ahamed?
      Yes I will be doing a Conversation with him. From Wikipedia: Ahamed is the author of Lords of Finance: The Bankers Who Broke the World (2009). The book was awarded the 2010 Pulitzer Prize for History, the 2010 Spear’s Bo…
  - (2026-07-07) [Marginal Revolution] Wiesbaden notes
      Who goes to Wiesbaden these days? The era of Russian nobles taking the cure here and gambling is long since gone. And yet here we are. The proximate cause of this trip is the desire to see Grigory Sokolov, one of the wor…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=26, 14d-median=26; carrying terms: national, security, changes, including, safety, programs, comments, assistance, order, entry, final, protect
- state_bills: today=0, 7d-median=153, 14d-median=153
- state_news: today=420, 7d-median=452, 14d-median=452; carrying terms: authority, fifty, charge, rivers, evidence, advanced, session, politics, article, economy, srcset, plans
- local_news: today=213, 7d-median=222, 14d-median=222; carrying terms: national, lgbtq, underway, board, srcset, including, night, image, health, height, content, family
- foreign_news: today=1003, 7d-median=1038, 14d-median=1038; carrying terms: footer, countries, overseas, evidence, thumbs, tests, petro, article, shares, southern, economy, relations
- chinese_internal: today=266, 7d-median=281, 14d-median=281; carrying terms: politics, lithium, access, cbmiaefvx, blank, cbmidefvx, cbmiw, global, title, lxtfb, cbmizefvx, rivals
- russian_internal: today=907, 7d-median=915, 14d-median=915; carrying terms: httperror, forex, bloomberg, journal, google, hyundai, telegraph, hynix, media, client, https, times
- ukrainian_internal: today=113, 7d-median=122, 14d-median=122; carrying terms: kharkiv, fighting, plans, including, night, energy, become, artillery, supply, refinery, official, donald
- ukraine_theater: today=498, 7d-median=557, 14d-median=557; carrying terms: nqzfjwjlmmemztwjottd, countries, rvlotmwwum, zgrhoetn, vfbmz, advanced, ltuzfnmdrrvtlvvelfzmr, ohfmwe, fvwljxv, health, supply, cvpnzvfybeptm
- paper_bets: today=135, 7d-median=138, 14d-median=138; carrying terms: lifetime, degrees, mamdani, johnson, california, baker, general, leaders, wisconsin, andrew, according, kansas
- weather: today=131, 7d-median=163, 14d-median=163; carrying terms: national, light, queen, rivers, pressure, shreveport, limbs, southern, changes, layer, including, night
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: jolts, effective, sheet, recession, unemployment, labor, dcoilwtico, cpiaucsl, total, commodities, personal, treasury
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, futures, bitcoin, russell, large, rates, commodities, crypto, corporate, crude, close, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=110, 7d-median=106, 14d-median=106; carrying terms: national, performance, general, security, destabilisation, tiananmen, prohibited, space, programs, energy, legislation, proliferation
- congressional_trades: today=1, 7d-median=68, 14d-median=68
- billionaires: today=39, 7d-median=40, 14d-median=40; carrying terms: bezos, ortega, ballmer, diversified, spacex, fashion, bernard, commodities, microsoft, zuckerberg, japan, oracle
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, supreme, hernandez, court, corporation, national, american, general, county, international, appeals, alabama
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, holdings, issuer, financial, jpmorgan, chase, filer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, james, sherrod, johnson, booker, cooper, chartered, talarico, receipts, house, groom, david
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: russian, trump, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=28, 14d-median=28; carrying terms: position, ground, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: national, organs, countries, release, total, seasonal, exposure, circulating, children, animals, general, batch
- cisa_kev: today=8, 7d-median=9, 14d-median=9; carrying terms: access, control, authentication, manager, vulnerability, injection, traversal, cisco, product, remediation, vendor, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=155, 7d-median=133, 14d-median=133; carrying terms: philippines, forestfire, forest, cambodia, cyclone, agricultural, japan, speed, malaysia, magnitude, czech, drought
- usgs_quakes: today=12, 7d-median=14, 14d-median=14; carrying terms: japan, depth, indonesia, tobelo
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, world, argentina, resolves, volume, england, belgium, colombia, ethiopia, switzerland, prime, minister
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, revolution, marginal, conversable, https, class, world, conversableeconomist, short, large, governments
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: schneier, security, article, including, edition, platform, residential, engineering, systems, another, itself, multiple
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: national, markwayne, maxwell, comer, cassidy, downing, dwight, crockett, sanders, garamendi, auchincloss, fletcher
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, identify, placement, evidence, consensus, either, converges, market, module, claude, unavailable, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-24] Fed speeches: Cook, Welcome Remarks
- [2026-06-24] Fed press (events + announcements): Federal Reserve Board's annual bank stress test confirms that large banks are well positioned to weather a severe recession and able to continue to lend to households and businesses
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board issues enforcement action with employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Jiko Group, Inc.
- [2026-06-27] ECB press: Isabel Schnabel: Is inflation back?
- [2026-06-29] ECB press: Christine Lagarde: Back to basics in an uncertain environment
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2028
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2027
- [2026-06-30] Fed press (events + announcements): Agencies release list of distressed or underserved nonmetropolitan middle-income geographies
- [2026-07-01] Fed press (events + announcements): Federal Reserve issues initial findings from its 2025 triennial payments study
- [2026-07-02] ECB press: Frank Elderson: The green transition – benefits and barriers
- [2026-07-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Small Business Bank and announces termination enforcement actions with BNP Paribas S.A., BNP Paribas USA, Inc., BNP Paribas Securities Corp., and Community Bankshares, Inc.
- [2026-07-02] ECB press: Piero Cipollone: The digital transformation of money, payments and finance
- [2026-07-02] ECB press: Christine Lagarde: Interview with Les Échos
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*