# WORLDSCOPE morning brief — 2026-11-28

## Headline
3125 new items across 30 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (765) · Russian Internal News (state + in-exile) (635) · World leaders & government officials (324) · Chinese Internal News (191) · Ukraine Theater (total-war monitoring) (145) · State-Level News (138) · U.S. Weather + Severe / Climate Outlooks (136) · Local News: St. Louis + Atlanta (130) · GDELT GKG — themes / entities / watch areas (129) · World News (by country, top stories) (100) · Ukrainian Internal News (national + local Kyiv) (65) · GDACS — global disaster alerts (54)

## What changed today
### International News + Multilateral Institutions — 765 new of 1015 total
  - (2026-11-27) [Global] Spanish PM and rivals rally supporters in final pitch for votes
      Prime Minister Pedro Sánchez wants to defy the polls, and his main rivals accuse him of not telling the truth and of "betrayal".
  - (2026-11-28) [Global] Turkish officials 'destroyed' pro-opposition TV channel, owner tells BBC
      The headquarters of Halk TV were raided last month, the latest in a series of crackdowns on news sources deemed critical of the government.
  - (2026-11-28) [Global] Eight killed in Peruvian military helicopter crash
      The pilot was the sole survivor of the crash during a rescue mission in a remote area known for drug trafficking.
  - (2026-11-28) [Global] 'Poison seller' Kenneth Law apologises in court to the families of his victims
      The Canadian man, who pleaded guilty to 14 counts of aiding and abetting suicide earlier this year, said he was remorseful for his actions.
  - (2026-11-28) [Global] Australian wrestler Bronson Reed dies aged 38, WWE says
      Tributes have flooded in for the 38-year-old Australian who is survived by his pregnant wife, Paige, their daughter.
  - (2026-11-27) [Global] 'We couldn't give up that easily': Marching bands scramble to cover costs after Thanksgiving parade rearranged
      Stormy weather in New York City prompted organisers to push back the Macy's parade by two days - leaving some musicians stuck.

### Russian Internal News (state + in-exile) — 635 new of 1064 total
  - (2026-11-28) Телеграм разослал пользователям айфонов сообщения с призывом срочно обновить операционную систему. Павел Дуров предупредил о масштабных хакерских атаках | LEDE: Телеграм в ночь на 28 ноября ] (ru: Тел…
      Телеграм в ночь на 28 ноября массово разослал пользователям айфонов сообщение с призывом обновить операционную систему.
  - (2026-11-28) В эмиграции часто кажется, что ты делаешь все не так — и не заслуживаешь поддержки. Как избавиться от вредной оптики и научиться самосостраданию? Отвечает психолог | LEDE: В стрессе после пе] (ru: В э…
      В стрессе после переезда в другую страну — который может продолжаться очень долго — мы легко превращаемся в своих самых жестоких критиков: кажется, что все вокруг давно освоились и все успевают, а у нас вечные неудачи, о…
  - (2026-11-28) Украинские дроны атаковали Новошахтинский НПЗ в Ростовской области. На подлете к Москве сбиты более 120 беспилотников | LEDE: Украинские военные в ночь на 28 ноября атаковали беспилотниками ] (ru: Укр…
      Украинские военные в ночь на 28 ноября атаковали беспилотниками Новошахтинский НПЗ в Ростовской области, на территории предприятия начался пожар. Фото и видео последствий атаки дронов опубликовали Astra и украинские мони…
  - (2026-11-28) Спустя два года после развода Татьяна Ким и Владислав Бакальчук выпустили по книге об истории Wildberries. Вместо честного рассказа о бизнесе бывшие супруги продолжают выяснять отношения — тепе] (ru:…
      В 2024 году россияне следили за переделом маркетплейса Wildberries — к этому привел конфликт его основателей, Татьяны Ким и Владислава Бакальчука. Кульминацией стала стрельба в одном из московских офисов компании, в резу…
  - (2026-11-27) В Санкт-Петербурге за два дня выявили три случая заражения оспой обезьян | LEDE: В Санкт-Петербурге 27 ноября зарегистрирован новый случай заболевания оспой обезьян. Об этом пишет «Фонтанка»] (ru: В С…
      В Санкт-Петербурге 27 ноября зарегистрирован новый случай заболевания оспой обезьян. Об этом пишет «Фонтанка».
  - (2026-11-27) На фронте впервые погиб военный, родившийся во время президентства Медведева. Когда началась война, ему было 13 лет | LEDE: На войне с Украиной погиб 18-летний россиянин Данил Курленя. Как с] (ru: На…
      На войне с Украиной погиб 18-летний россиянин Данил Курленя. Как сообщает «Медиазона», это первый известный случай гибели военного, родившегося при президентстве Дмитрия Медведева.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 191 new of 278 total
  - (2026-11-27) 中企要是在印尼建成这条铁路，一条运力就超印尼去年铁路货运总量 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTFBqLW82d1pCaTNWSlBYRWN1ejFKWkdxeF93a1RndW5aN2d4OWV4VG5tb2tFUU5rUkptelkzU3dDcTA3cHVDaFAzU] (zh:…
      中企要是在印尼建成这条铁路，一条运力就超印尼去年铁路货运总量 观察者网
  - (2026-11-27) “看到评论区的那一刻，我整个人都在发抖” - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE5hamNQeHRxMXRBeURLQlJtMmxhczNia2VtNF9aVHlIcXhWWlZna2tmci1Va3hpbEVmNzJWRzhKQ043U3dQWS1CMlBaRGkzV1l] (zh:…
      “看到评论区的那一刻，我整个人都在发抖” 观察者网
  - (2026-11-27) 女友意外离世，男子留言“我来了”后失联，遗体已在水库找到 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5JV3h6WXBDYlhEYkRlQUJVR2xpYmp3dEczR0cxa1hMZnowbXl6RmtQRmtxVzdlUnJHVjVlMnl2bklEX2xwZnN3ZEh] (zh:…
      女友意外离世，男子留言“我来了”后失联，遗体已在水库找到 观察者网
  - (2026-11-28) “麦加协议”要扩员？土耳其外长：三国已达成部分一致 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTFBXX2JBNERMMUk3eExNWUNlZndxMlFOMjVKemV4ZXdmSWlnb0ptcjZISklXUUpiblhHbFl6NUFnSm0xRVRxMVZ2TGtwRE] (zh:…
      “麦加协议”要扩员？土耳其外长：三国已达成部分一致 观察者网
  - (2026-11-27) 普京：俄新型核潜艇“彼尔姆”号将加入太平洋舰队 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE5HWEZjdTU0UFg5NGdnVFJpWlFfX19KcDBoMUlGNzRQUEZxZF9oLTRxY0hpLWN5b2E3UTZCZ2xhWWt2R190RUJJUnlSVVBB] (zh:…
      普京：俄新型核潜艇“彼尔姆”号将加入太平洋舰队 观察者网
  - (2026-11-27) “不科学”的攻关，为什么没有杀死鸿蒙？ - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5IUW9XWjRlSUN0STQ2djF6c3gtVHlRMEVuTnRnWV9HaUtYLWREM0J3VWtrZktHdHRwY05EZWhWSjV2SF8xS1dfZHpoZkx1MTRK] (zh:…
      “不科学”的攻关，为什么没有杀死鸿蒙？ 观察者网

### Ukraine Theater (total-war monitoring) — 145 new of 408 total
  - (2026-11-28) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-27) [Liveuamap] Coalition spokesperson: The coalition intercepted and destroyed a Houthi-launched drone targeting the Riyadh area. - Liveuamap
      Coalition spokesperson: The coalition intercepted and destroyed a Houthi-launched drone targeting the Riyadh ar
  - (2026-11-25) [Liveuamap] An armed attack by ISIS in the Syrian city of Al-Hasakah has left members of the Internal Security Forces dead and wounded. - Liveuamap
      An armed attack by ISIS in the Syrian city of Al-Hasakah has left members of the Internal Security Forces dead and wounde
  - (2026-11-25) [Liveuamap] 3 people wounded as result of MLRS shelling in Zaporizhzhia – Zaporizhzhia,Zaporiz&039;ka oblast - Liveuamap
      3 people wounded as result of MLRS shelling in Zaporizhzhia – Zaporizhzhia,Zaporiz&039;ka oblast <font color="#6f6
  - (2026-11-28) [Liveuamap] Kyiv Mayor Vitali Klitschko… – Kyiv, Kyiv city - Liveuamap
      Kyiv Mayor Vitali Klitschko… – Kyiv, Kyiv city Liveuamap
  - (2026-11-27) [Liveuamap] Overnight Russia launched 155 strike drones of different types, - Ukrainian Air Force – Pisky, Donetsk Oblast - Liveuamap
      Overnight Russia launched 155 strike drones of different types, - Ukrainian Air Force – Pisky, Donetsk Oblast <fon

### State-Level News — 138 new of 297 total
  - (2026-11-27) [California] Governor Newsom announces $56 million in grants to help tribes expand housing and homelessness solutions, adding to more than $500 million in tribal investments
      Source
  - (2026-11-27) [Alabama] Lawmakers say they heard the voters. Allison Montgomery is the first test.
  - (2026-11-27) [Alabama] Jefferson County area DA suggests potential legal action against judge who criticized Aniah’s Law
  - (2026-11-27) [Alabama] U.S. Attorney’s Office to appeal ruling in Baldwin County ICE lawsuit
  - (2026-11-27) [Arkansas] The anti-abortion movement is facing a reckoning
      This story was originally reported by Shefali Luthra and Grace Panetta of The 19th. Meet Shefali and Grace and read more of their reporting on gender, politics and policy. Heading into the 2028 presidential primary, Repu…
  - (2026-11-27) [Arkansas] Voter turnout surged in many states in the midterms, but not in Arkansas
      The story of the 2026 midterm elections was defined in part by increases in voter turnout, especially in the South. Voters angry at persistent affordability issues and mid-decade redistricting that broke up several major…

### U.S. Weather + Severe / Climate Outlooks — 136 new of 138 total
  - (2026-11-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-28) [Severe] High Wind Warning: High Wind Warning issued November 28 at 1:23AM MST until November 28 at 3:00PM MST by NWS Salt Lake City UT
      * WHAT...Northwest winds 25 to 35 mph with gusts up to 65 mph expected. * WHERE...Castle Country, particularly along SR-10 from Castle Dale and Orangeville south through Fremont Junction. * WHEN...From 9 AM this morning…
  - (2026-11-28) [Moderate] Wind Advisory: Wind Advisory issued November 28 at 1:23AM MST until November 28 at 12:00PM MST by NWS Salt Lake City UT
      * WHAT...Northwest winds 30 to 40 mph with gusts up to 65 mph expected in northwest Box Elder County along Highway 30. North to northwest winds 20 to 30 mph with gusts near 45 mph elsewhere, including I-80 across the Sal…
  - (2026-11-28) [Moderate] Gale Watch: Gale Watch issued November 28 at 3:14AM EST until November 30 at 6:00PM EST by NWS Mount Holly NJ
      * WHAT...For the Small Craft Advisory, west winds 15 to 25 kt with gusts up to 30 kt and rough waters. For the Gale Watch, west winds 20 to 30 kt with gusts up to 35 kt and very rough waters possible. * WHERE...Delaware…
  - (2026-11-28) [Moderate] Gale Watch: Gale Watch issued November 28 at 3:14AM EST until November 30 at 6:00PM EST by NWS Mount Holly NJ
      * WHAT...For the Small Craft Advisory, west winds 15 to 25 kt with gusts up to 30 kt and seas 4 to 7 ft. For the Gale Watch, west winds 20 to 30 kt with gusts up to 40 kt and seas 5 to 8 ft possible. * WHERE...Coastal wa…
  - (2026-11-28) [Moderate] Gale Watch: Gale Watch issued November 28 at 3:14AM EST until November 30 at 6:00PM EST by NWS Mount Holly NJ
      * WHAT...For the Small Craft Advisory, west winds 15 to 25 kt with gusts up to 30 kt and seas 4 to 7 ft. For the Gale Watch, west winds 20 to 30 kt with gusts up to 40 kt and seas 7 to 10 ft possible. * WHERE...Coastal w…

### Local News: St. Louis + Atlanta — 130 new of 206 total
  - (2026-11-28) [St. Louis] Did anyone win the Mega Millions $673M jackpot? Winning numbers for Friday, Nov. 27
      Here are the winning numbers for Friday's $6473 million Mega Millions jackpot.
  - (2026-11-28) [St. Louis] Ameren said it will still take a few days to restore power to some as thousands of customers remain without power
      Ameren said more than 1,500 workers are in the field to restore power. As of Friday, most of the outages were in St. Louis and Jefferson counties.
  - (2026-11-28) [St. Louis] Silly Bandz says company is 'alive and well' after teasing last ever Black Friday sale
      Silly Bandz announced this was their last ever Black Friday sale, but said the company is "alive and well" and was just doing a viral trend.
  - (2026-11-28) [St. Louis] WWE star known as Bronson Reed has died at 38
      The wrestler named Jermaine Haley, known to WWE fans as Bronson Reed, died Friday the organization announced.
  - (2026-11-27) [St. Louis] Power pole crashes onto Florissant roof as thousands in St. Louis area face days in the dark
      Thousands of Ameren Missouri customers in St. Louis face extended power outages as crews work to restore service amid widespread storm damage.
  - (2026-11-27) [St. Louis] Couple picks up restaurant tab for hundreds of families celebrating Thanksgiving in Texas
      A Thanksgiving meal turned into an act of generosity for hundreds of families in Texas when a couple quietly paid for everyone's food at a local restaurant.

### GDELT GKG — themes / entities / watch areas — 129 new of 129 total
  - (2026-11-28) [Russia oil sanctions perimeter · themes] COMMENTARY: Donald Trump tries and fails to break through the Ukraine war deadlock
      timesleader.com · English · tone -2.10930009587728 · 1 other outlets
  - (2026-11-28) [Russia oil sanctions perimeter · themes] Ukraine Lost $2.85 Bln in August-October Due to Port Downtime
      sputnikglobe.com · English · tone -2.74509803921569
  - (2026-11-28) [Russia oil sanctions perimeter · themes] Ukraine submits Black Sea ceasefire offer, awaits Russian response
      theuknews.com · English · tone -4.57589285714286
  - (2026-11-28) [Russia oil sanctions perimeter · keywords] US-led consortium agrees to acquire assets from Russian oil company Lukoil
      theweekender.com · English · tone -2.36486486486486 · 1 other outlets
  - (2026-11-28) [Russia oil sanctions perimeter · near] Ukraine war briefing: Zelenskyy criticises Trump for calling Putin his 'friend'; Kyiv deploys new laser weapon | Ukraine
      theguardian.com · English · tone -3.47826086956522 · 10 other outlets
  - (2026-11-28) [Russia oil sanctions perimeter · near] Zelensky walks back claim about Libya attack after rebuke from Rome
      sierraleonetimes.com · English · tone -3.46153846153846 · 3 other outlets

### World News (by country, top stories) — 100 new of 100 total
  - (2026-11-28) [Brazil] The Operation Condor Files: Brazilian journalists exposed a black op that changed a dissident's fate
      buenosairesherald.com · English
  - (2026-11-28) [Brazil] Trump Proposes New 10% Tariffs on Brazil's Aircraft and Sugar Exports; Embraer Shares Slide
      latintimes.com · English
  - (2026-11-28) [Brazil] Lula's choice of Bradesco banker as Brazil's finance minister lifts markets
      newsday.com · English
  - (2026-11-28) [Brazil] Nu Holdings Stock: Brazil's Banking License Is A Game Changer (Rating Upgrade) (NYSE:NU)
      seekingalpha.com · English
  - (2026-11-28) [Brazil] Lula boosts fiscal credibility with Brazil FinMin pick
      latinfinance.com · English
  - (2026-11-28) [Brazil] Brazil's Election Flooded With AI Fakes
      riotimesonline.com · English

### Ukrainian Internal News (national + local Kyiv) — 65 new of 124 total
  - (2026-11-28) Чи може Росія розрізати Україну по Дніпру? П'ять головних питань про атаки на мости | LEDE: "Росія намагається роз'єднати Україну по Дніпру", – таку заяву 9 листопада зробив президент Володимир] (uk:…
      "Росія намагається роз'єднати Україну по Дніпру", – таку заяву 9 листопада зробив президент Володимир Зеленський. На той момент росіяни вже понад місяць атакували мости в Києві, Запоріжжі та Дніпрі.
  - (2026-11-28) У Ніжині завершили рятувальні роботи після удару РФ: кількість загиблих зросла до 7 | LEDE: ДСНС повідомила про завершення аварійних робіт у Ніжині: сім загиблих, семеро постраждалих, одну люди] (uk:…
      ДСНС повідомила про завершення аварійних робіт у Ніжині: сім загиблих, семеро постраждалих, одну людину врятовано з-під завалів.
  - (2026-11-28) Угорщина скасувала заборону на в’їзд для "Мадяра" Бровді | LEDE: Національне управління Угорщини видалило заборону на в'їзд і проживання для командира ЗСУ Роберта "Мадяра" Бровді.] (uk: Угорщина скасу…
      Національне управління Угорщини видалило заборону на в'їзд і проживання для командира ЗСУ Роберта "Мадяра" Бровді.
  - (2026-11-28) На Донеччині РФ вбила 4 людей і ще 8 поранила | LEDE: За добу на Донеччині від обстрілів загинули четверо, поранено вісім людей у Слов'янську, Краматорську, Малотаранівці. Дані Донецької ОВА.] (uk: На…
      За добу на Донеччині від обстрілів загинули четверо, поранено вісім людей у Слов'янську, Краматорську, Малотаранівці. Дані Донецької ОВА.
  - (2026-11-28) На спомин Голодомору. Голод як колоніальна зброя: пам’ять та покарання | LEDE: Міжнародне право забороняє моріння голодом цивільного населення. Україна розслідує використання голоду під час вій] (uk:…
      Міжнародне право забороняє моріння голодом цивільного населення. Україна розслідує використання голоду під час війни з Росією — деталі в матеріалі.
  - (2026-11-28) В Австрії лідер ультраправих запропонував депортувати сирійців та афганців до України в обмін на допомогу | LEDE: Герберт Кікль із FPÖ пропонує відправляти в Україну сирійців та афганців у відп] (uk:…
      Герберт Кікль із FPÖ пропонує відправляти в Україну сирійців та афганців у відповідь на фінансову допомогу ЄС.

### GDACS — global disaster alerts — 54 new of 100 total
  - (2026-11-28) [Green] Earthquake in Chile
      Earthquake · Green alert · Chile · Magnitude 4.6M, Depth:78.805km
  - (2026-11-28) [Green] Earthquake in Argentina
      Earthquake · Green alert · Argentina · Magnitude 5.2M, Depth:174.617km
  - (2026-11-28) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.7M, Depth:55.237km
  - (2026-11-28) [Green] Earthquake in Laos
      Earthquake · Green alert · Laos · Magnitude 5.1M, Depth:10km
  - (2026-11-28) [Green] Earthquake in Off E. Coast Of N. Island, N.Z.
      Earthquake · Green alert · Off E. Coast Of N. Island, N.Z. · Magnitude 4.8M, Depth:10km
  - (2026-11-27) [Green] Forest fires in Mali
      Wildfire · Green alert · Mali · Green impact for forestfire in 6733 ha

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-28) [HANDLER RICHARD B] Form 4 (Reporting)
      filed 2026-11-28 02:32 UTC · role: Reporting — Filed: 2026-11-27 AccNo: 0001214659-26-014836 Size: 14 KB
  - (2026-11-28) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-11-28 02:32 UTC · role: Issuer — Filed: 2026-11-27 AccNo: 0001214659-26-014836 Size: 14 KB
  - (2026-11-28) [FRIEDMAN BRIAN P] Form 4 (Reporting)
      filed 2026-11-28 02:31 UTC · role: Reporting — Filed: 2026-11-27 AccNo: 0001214659-26-014835 Size: 8 KB
  - (2026-11-28) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-11-28 02:31 UTC · role: Issuer — Filed: 2026-11-27 AccNo: 0001214659-26-014835 Size: 8 KB
  - (2026-11-28) [Larson Matthew Scott] Form 4 (Reporting)
      filed 2026-11-28 02:29 UTC · role: Reporting — Filed: 2026-11-27 AccNo: 0001214659-26-014834 Size: 5 KB
  - (2026-11-28) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-11-28 02:29 UTC · role: Issuer — Filed: 2026-11-27 AccNo: 0001214659-26-014834 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-28) [United Kingdom] Princess Catherine movie: Kate takes to the mountains to face mortality in 'Heal,' new documentary about cancer recovery
      domain: abc7ny.com · language: English · tone: 0.103950103950104 · 110 other outlets ran this story
  - (2026-11-28) [United Kingdom] 'Calculating predator' who blackmailed young girls online 'for content' jailed
      domain: countytimes.co.uk · language: English · tone: -7.18446601941748 · 54 other outlets ran this story
  - (2026-11-28) Oakland County woman dies in Thanksgiving Day crash in Sterling Heights
      domain: cedarnews.net · language: English · tone: -6.45161290322581 · 53 other outlets ran this story
  - (2026-11-28) [Taiwan] Taiwan votes in elections as China flexes military
      domain: westernadvocate.com.au · language: English · tone: -1.38648180242634 · 37 other outlets ran this story
  - (2026-11-28) New York Senate Majority Leader Andrea Stewart-Cousins dies at 76
      domain: washingtonexaminer.com · language: English · tone: -6.97674418604651 · 36 other outlets ran this story
  - (2026-11-28) 1 dead, 2 injured after Black Friday shooting in Richmond
      domain: 12onyourside.com · language: English · tone: -8.10810810810811 · 36 other outlets ran this story

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 59 total
  - (2026-11-27) [BleepingComputer] pCloud confirms password manager hack after suspicious login alerts
      The pCloud Pass password manager suffered a cyberattack, with users reporting that unknown devices had connected to their accounts even with two-factor authentication (2FA) enabled. [...]
  - (2026-11-27) [BleepingComputer] New Boston Scientific data breach exposes personal, medical info
      Medical technology company Boston Scientific is sending data breach notices to individuals affected by a cyberattack on the firm. [...]
  - (2026-11-27) [BleepingComputer] Unpatched Cacti zero-day with public PoC gives remote code execution
      A zero-day vulnerability in the Cacti network monitoring platform has been publicly disclosed, along with a proof-of-concept exploit that lets unauthenticated attackers execute commands on vulnerable servers. [...]
  - (2026-11-27) [BleepingComputer] US Air Force cloud platform reportedly hacked in latest federal breach
      Hackers have reportedly breached the US Air Force's Cloud One computing platform, adding to a recent wave of cyberattacks affecting US government agencies, including the FBI, CIA, and Treasury Department. [...]
  - (2026-11-27) [BleepingComputer] Your Firewall Isn't Enough: The Hidden Risk of Unmanaged VMs
      Forgotten virtual machines, unpatched servers, and excessive access permissions can create security blind spots across IT infrastructure. ISPsystem explains how centralized infrastructure management, access controls, and…
  - (2026-11-27) [The Hacker News] Suspected Vietnam-Linked Hackers Target Southeast Asia in South China Sea Espionage Campaign
      A Vietnam-sponsored hacking group has been attributed to attacks targeting Southeast Asian military, government, and legislative organizations with an aim to gather intelligence on South China Sea defense and military ag…

### Court opinions of consequence (federal & state) — 34 new of 59 total
  - (2026-11-25) U.S. Court of International Trade: Selby v. United States
  - (2026-11-25) Supreme Court of Alabama: Alabama State Conference of the NAACP, League of Women Voters of Alabama, League of Women Voters of Alabama Education Fund, Greater Birmingham Ministries, and Alabama Disabil…
  - (2026-11-25) D.C. Court of Appeals: Wood v. United States
  - (2026-11-24) U.S. Court of Appeals, 3rd Cir.: Emery Barron v. Wetzel
  - (2026-11-24) U.S. Court of International Trade: SeAH Steel VINA Corp. v. United States
  - (2026-11-24) U.S. Court of Appeals, 8th Cir.: United States v. Robert Howell

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 21 new of 21 total
  - (2026-11-30) Truth in Lending (Regulation Z)
      The Board and the Bureau (collectively, Agencies) are publishing final rules amending the official interpretations for the Agencies' regulations that implement the Truth in Lending Act (TILA). The Dodd-Frank Wall Street…
  - (2026-11-30) Consumer Leasing (Regulation M)
      The Board and the Bureau (collectively, Agencies) are finalizing amendments to the official interpretations for the Agencies' regulations that implement the Consumer Leasing Act (CLA). The Dodd- Frank Wall Street Reform…
  - (2026-11-30) Appraisals for Higher-Priced Mortgage Loans Exemption Threshold
      The OCC, the Board, and the Bureau are finalizing amendments to the official interpretations for their regulations that implement section 129H of the Truth in Lending Act (TILA). Section 129H of TILA establishes special…
  - (2026-11-30) Endangered and Threatened Wildlife and Plants; Threatened Species Status for Streaked Horned Lark With a Section 4(d) Rule
      We, the U.S. Fish and Wildlife Service (Service), propose to list the streaked horned lark (Eremophila alpestris strigata), a subspecies of grassland songbird from Oregon and Washington, as a threatened species with prot…
  - (2026-11-30) Endangered and Threatened Wildlife and Plants; Threatened Species Status With Section 4(d) Rule for the Piebald Madtom
      We, the U.S. Fish and Wildlife Service (Service), propose to list the piebald madtom (Noturus gladiator), a fish species from Mississippi and Tennessee, as a threatened species with protective regulations under section 4…
  - (2026-11-30) Reportable Events and Certain Other Notification Requirements
      The Pension Benefit Guaranty Corporation (PBGC) is proposing to simplify and clarify its regulation governing the active participant reduction reportable event. The proposed rule would waive notice for active participant…

### State Legislative Action — 17 new of 126 total
  - (2026-11-28) [Alaska SB 277] An Act relating to education; relating to charter school budgets; relating to correspondence study program materials, funding, and student counts; relating to student transportation fu…
      An Act relating to education; relating to charter school budgets; relating to correspondence study program materials, funding, and student counts; relating to student transportation funding; relating to cooperative arran…
  - (2026-11-28) [Alaska SB 281] An Act relating to the rural health transformation program; relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating…
      An Act relating to the rural health transformation program; relating to physician assistants; relating to collaborative agreements between physicians and physician assistants; relating to the interstate medical licensure…
  - (2026-11-28) [Alaska SCR 17] Recognizing the 50th anniversary of the state's regional educational attendance areas; and celebrating the enduring contributions of the state's regional educational attendance areas t…
      Recognizing the 50th anniversary of the state's regional educational attendance areas; and celebrating the enduring contributions of the state's regional educational attendance areas to public education, local leadership…
  - (2026-11-26) [Colorado HB 1246] Consumer-Regulated Electric Utilities
      The bill defines a "consumer-regulated electric utility" as an electric generation and supply system constructed for the sole purpose of serving new industrial, commercial, data center, or other nonresidential loads not…
  - (2026-11-26) [Colorado HB 1104] Credit Agency Voter Address Verification
      The bill requires the secretary of state (secretary) to cause to be conducted an annual change of address search of the computerized statewide voter registration list (statewide list) using a third-party credit bureau (c…
  - (2026-11-26) [Colorado SB 65] Systemic Insecticide Use Limitations
      On and after January 1, 2029, the bill prohibits a person from selling, offering for sale, or otherwise distributing in the state field crop seeds coated or treated with systemic insecticide (coated or treated seeds), wh…

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-26) [F99] (unknown)
      cycle 2026 · filing #2049869
  - (2026-11-26) [F3X] CD6 GOP FEDERAL COMMITTEE
      cycle 2026 · filing #2049906
  - (2026-11-26) [F99] (unknown)
      cycle 2026 · filing #2049899
  - (2026-11-26) [F99] (unknown)
      cycle 2026 · filing #2049872
  - (2026-11-26) [F99] (unknown)
      cycle 2026 · filing #2049933
  - (2026-11-26) [F99] (unknown)
      cycle 2026 · filing #2049902

### Government & military aircraft airborne (OpenSky) — 15 new of 15 total
  - (2026-11-28) INDIA1 (India)
      icao24: 8002fb · position: (26.1483, 87.972) · alt: 10668m · 878km/h
  - (2026-11-28) CFC2937 (Canada)
      icao24: c2b5b7 · position: (55.7232, -0.0384) · alt: 8839m · 712km/h
  - (2026-11-28) JAF78M (Belgium)
      icao24: 44d1b4 · position: (33.9253, -13.1895) · alt: 11277m · 807km/h
  - (2026-11-28) GAF635 (Germany)
      icao24: 3f7b3c · position: (50.8796, 7.1953) · alt: 822m · 371km/h
  - (2026-11-28) NCR686 (United States)
      icao24: a6caa1 · position: (39.104, -93.3508) · alt: 10058m · 1067km/h
  - (2026-11-28) NCR8823 (United States)
      icao24: aabbef · position: (23.4737, 55.6822) · alt: 6446m · 757km/h

### Wikidata leader-roster changes (48h) — 14 new of 36 total
  - (2026-11-28) [Guatemala] Bernardo Arévalo de León (Q107254030) edited
      /* restore:0||2568168430|Printstream */
  - (2026-11-28) [Madagascar] Michael Randrianirina (Q136500275) edited
      /* wbsetclaim-update:2||1 */ [[Property:P18]]: Michael Randrianirina at the Kremlin (2026-10-30) (cropped).jpg
  - (2026-11-28) [Serbia] Aleksandar Čupić (Q142195374) edited
      /* wbsetsitelink-add:1|kawiki */ ალექსანდარ ჩუპიჩი
  - (2026-11-28) [Romania] Luca Niculescu (Q121140873) edited
      /* wbsetaliases-add:1|ru */ Никулеску, Лука
  - (2026-11-27) [Brazil] Luiz Inácio Lula da Silva (Q37181) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/78621|batch #78621]]
  - (2026-11-27) [Sint Maarten] William Alexander of the Netherlands (Q154952) edited
      /* wbsetlabel-set:1|wuu */ 威廉-亚历山大, [[:toollabs:quickstatements/#/batch/297398|batch #297398]]

### Paper Trading Scorecard — 11 new of 70 total
  - (2026-11-28) [Polymarket] Will the average Ornn H200 rental price in December 2026 be above $6.00?
      This market will resolve to "Yes" if the average Ornn H200 index value in December 2026 is above the specified price. Otherwise, this market will resolve to "No". The average Ornn H200 index value in December 2026 is the…
  - (2026-11-28) [Polymarket] Will Cash Cat be the first to hit a $1B FDV?
      This market will resolve to "Yes" if Cash Cat (CASHCAT) is the first of the coins listed below to reach a fully diluted valuation equal to or greater than $1,000,000,000 at any point between the creation of this market a…
  - (2026-11-28) [Manifold] Daily Coinflip
  - (2026-11-28) [Manifold] Will Bending Spoons acquire Zapier before Jan 1 2028
  - (2026-11-28) [Manifold] Will Obama call for a pause in AI development before 2028?
  - (2026-11-28) [Manifold] Will this market reach 50 unique traders before Monday, Nov 30 at 11:59 PM EST?

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-11-28) Counter-Strike: Natus Vincere vs PARIVISION (BO1) - PGL Major Singapore Stage 2
      yes price: 100% · 24h volume: $3,052,621 · resolves 2026-11-28
  - (2026-11-28) Will the Fed decrease interest rates by 25 bps after the December 2026 meeting?
      yes price: 0% · 24h volume: $2,871,989 · resolves 2026-12-09
  - (2026-11-28) Counter-Strike: MIBR vs 100 Thieves (BO1) - PGL Major Singapore Stage 2
      yes price: 0% · 24h volume: $1,862,096 · resolves 2026-11-28
  - (2026-11-28) Will Hakeem Jeffries win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $552,661 · resolves 2028-11-08
  - (2026-11-28) Will the Fed decrease interest rates by 50+ bps after the December 2026 meeting?
      yes price: 0% · 24h volume: $424,527 · resolves 2026-12-09
  - (2026-11-28) Will Su Chiao-hui win the next New Taipei Mayor election?
      yes price: 2% · 24h volume: $236,056 · resolves 2026-11-29

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-11-28) MOVER ▲ Elon Musk — $862.78B (+$39.32B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-11-28) MOVER ▲ Jeff Bezos — $373.29B (+$8.56B since yesterday)
      United States · Technology · source: Amazon
  - (2026-11-28) MOVER ▲ Michael Dell — $194.59B (+$7.76B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-11-28) MOVER ▲ Mark Zuckerberg — $216.11B (+$6.45B since yesterday)
      United States · Technology · source: Facebook
  - (2026-11-28) MOVER ▲ Larry Ellison — $146.02B (+$4.24B since yesterday)
      United States · Technology · source: Oracle
  - (2026-11-28) MOVER ▲ Thomas Peterffy — $91.41B (+$3.80B since yesterday)
      United States · Finance & Investments · source: Discount brokerage

### USGS earthquakes (M4.5+, past day) — 8 new of 8 total
  - (2026-11-28) M 5.2 - 93 km W of San Antonio de los Cobres, Argentina
      M5.2 · 93 km W of San Antonio de los Cobres, Argentina · depth 174.617 km
  - (2026-11-28) M 5.1 - 73 km NNW of Phôngsali, Laos
      M5.1 · 73 km NNW of Phôngsali, Laos · depth 10 km
  - (2026-11-28) M 4.8 - 167 km N of Hicks Bay, New Zealand
      M4.8 · 167 km N of Hicks Bay, New Zealand · depth 10 km
  - (2026-11-27) M 4.8 - 183 km SSE of Vilyuchinsk, Russia
      M4.8 · 183 km SSE of Vilyuchinsk, Russia · depth 35.488 km
  - (2026-11-28) M 4.7 - 130 km NE of Bitung, Indonesia
      M4.7 · 130 km NE of Bitung, Indonesia · depth 55.237 km
  - (2026-11-28) M 4.6 - 26 km NNW of Cuya, Chile
      M4.6 · 26 km NNW of Cuya, Chile · depth 78.805 km

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 99 total
  - (2026-11-28) [BIS Entity List] page checksum 5082f0719dc3
      Page content hash: 5082f0719dc3. Compare with prior day's hash to detect updates.
  - (2026-11-28) [USASpending] $902,786,775 → HII MISSION TECHNOLOGIES CORP: THE PURPOSE OF THIS ACTION IS TO AWARD A TASK ORDER - JOINT
      Agency: General Services Administration. Description: THE PURPOSE OF THIS ACTION IS TO AWARD A TASK ORDER - JOINT NETWORK OF ENGINEERING AND EMERGING OPERATIONS (JNEEO)
  - (2026-11-28) [USASpending] $900,000,000 → AMERICAN CENTRIFUGE OPERATING, LLC: THE PURPOSE OF THIS TASK ORDER (TO) IS TO ESTABLISH NEW ANNU
      Agency: Department of Energy. Description: THE PURPOSE OF THIS TASK ORDER (TO) IS TO ESTABLISH NEW ANNUAL DOMESTIC COMMERCIAL HIGH-ASSAY LOW-ENRICHED URANIUM (HALEU) CAPACITY AND BEGIN PRODUCTION OF HALEU UF6 FOR PURCHAS…
  - (2026-11-28) [USASpending] $825,985,691 → LEIDOS BIOMEDICAL RESEARCH INC: NCI OPERATIONAL TASK ORDER, FY26-FY27
      Agency: Department of Health and Human Services. Description: NCI OPERATIONAL TASK ORDER, FY26-FY27

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-28) [Marginal Revolution] Disempowerment vs. net disempowerment
      Here was my prompt: There are many discussions of “disempowerment” as a result of strong AI, and of whether humans “lose control” or agency. Do any of these discussions offer specific, detailed comparisons of how strong…
  - (2026-11-27) [Marginal Revolution] Friday assorted links
      1. Handbook of Blockchain and Society (open access). 2. Interview with Lars Peter Hansen. 3. A behavioral cost of living index, by Hubert Wu, on the job market from Oxford. 4. Cracking the Indus civilization script? 5. L…
  - (2026-11-27) [Marginal Revolution] India is on the Move
      When people talk about India’s economy, they almost always compare it negatively with China’s, it has not industrialized as fast, its bureaucracy is still maddening, its cities are still choked with traffic and smog. All…
  - (2026-11-27) [Conversable Economist] The Kranzberg Laws of Technology
      Forty years ago in 1986, the historian Melvin Kranzberg (1917-1995) published his Presidential Address for the Society for the History of Technology (SHOT), which was immodestly titled “Techology and History: Kranzberg’s…

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 27 total
  - (2026-11-27) CVE-2026-120705 · OSGeo GeoServer: OSGeo GeoServer XML Injection Vulnerability
      vendor: OSGeo · product: GeoServer · CISA remediation by 2026-11-30
  - (2026-11-27) CVE-2026-129243 · OSGeo GeoServer: OSGeo GeoServer Incorrect Authorization Vulnerability
      vendor: OSGeo · product: GeoServer · CISA remediation by 2026-11-30
  - (2026-11-27) CVE-2026-136716 · Drupal Core: Drupal Core Improper Check for Unusual or Exceptional Conditions Vulnerability
      vendor: Drupal · product: Core · CISA remediation by 2026-11-30

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=21, 14d-median=20; carrying terms: protection, certain, provide, national, management, action, public, final, safety, airworthiness, published, directives
- state_bills: today=126, 7d-median=126, 14d-median=78; carrying terms: district, health, state, relating, local, service, providing, program, transfer, including, board, public
- state_news: today=297, 7d-median=431, 14d-median=501; carrying terms: justice, elect, colorado, provide, elections, hawaii, protect, country, budget, found, nofollow, office
- local_news: today=206, 7d-median=210, 14d-median=221; carrying terms: local, killed, found, stlmag, office, history, south, across, business, community, according, family
- foreign_news: today=1015, 7d-median=1024, 14d-median=1015; carrying terms: wallabies, summit, targets, launches, france, prices, population, markets, businesses, ukraine, protect, alliance
- chinese_internal: today=278, 7d-median=271, 14d-median=289; carrying terms: nvidia, market, global, china, investors, https, google, chinese, growth, jensen, anthropic, target
- russian_internal: today=1064, 7d-median=943, 14d-median=943; carrying terms: forbidden, telegram, russian, media, times, politico, found, street, reuters, istories, novayagazeta, error
- ukrainian_internal: today=124, 7d-median=124, 14d-median=127; carrying terms: reported, rejected, russian, others, prime, ukraine, brussels, country, ministers, secretary, killed, confirmed
- ukraine_theater: today=408, 7d-median=273, 14d-median=276; carrying terms: terms, coverage, acled, exception, snapshot, unauthorized, error, token, accepted, upstreamautherror, maintained, google
- paper_bets: today=70, 7d-median=75, 14d-median=75; carrying terms: guilty, credible, justice, playoff, named, listed, prize, completes, become, lifetime, public, break
- weather: today=138, 7d-median=142, 14d-median=136; carrying terms: statement, watch, washington, pontiac, offshore, please, peachtree, texas, oxnard, erosion, until, continue
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: money, consumption, supply, latest, assets, jolts, commodities, crude, effective, vixcls, payrolls, pcepilfe
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, nasdaq, silver, agriculture, proxy, commodities, yield, crude, futures, bitcoin, crypto, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=102, 14d-median=100; carrying terms: systems, misappropriation, engineering, beirut, controlled, somalia, involvement, russian, facilitate, compare, protests, jihad
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, congresstrading, error, quiver, https, quantitative, client, httperror, quiverquant
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: berkshire, thomas, google, commodities, nvidia, zhong, larry, ortega, paris, tesla, london, mukesh
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=59, 7d-median=60, 14d-median=60; carrying terms: appeals, state, blanche, court, smith, supreme, police, miller, clark, prophete, division, warrick
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed, holdings, brian, james, laura, scott, robert, michael, enovis
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, sayed, raised, cortez, david, house, filing, peltola, talarico, jonathan, senate, warner
- gdelt_regions: today=100, 7d-median=101, 14d-median=103; carrying terms: strikes, mexico, ukraine, india, english, trump, saudi, story, south, canada, korea, nigeria
- gdelt_gkg: today=129, 7d-median=134, 14d-median=132; carrying terms: jihadist, strikes, russian, earths, hezbollah, ukraine, politics, english, compute, huang, trump, critical
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: crash, police, australia, killed, english, shooting, injured, trump, story, domain, outlets, language
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=15, 7d-median=17, 14d-median=19; carrying terms: belgium, position, germany, ground, kingdom, canada, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: publication, individuals, districts, activi, siberia, suspected, known, democratic, reported, immunocompromised, located, seven
- cisa_kev: today=27, 7d-median=21, 14d-median=18; carrying terms: remediation, product, vendor, injection, unsafe, vulnerability, bypass, authentication, cisco, incorrect, neutralization, alternate
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=36, 7d-median=57, 14d-median=54; carrying terms: quickstatements, edited, property, batch, toollabs, wbsetdescription, wbeditentity, update, wbsetsitelink, wbsetclaim, republic, import
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: forestfire, burkina, earthquake, forest, central, wildfire, sudan, depth, flood, impact, alert, australia
- usgs_quakes: today=8, 7d-median=8, 14d-median=11; carrying terms: depth, islands, indonesia, region, japan, chile, russia, tonga, argentina, zealand
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, december, shakhtar, meeting, league, champions, rates, donetsk, interest, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, https, revolution, marginalrevolution, policy, conversable, economist, links, years, assorted, whether, class
- tech_news: today=59, 7d-median=62, 14d-median=63; carrying terms: systems, blogging, policy, spectrum, attacks, target, technica, breach, computer, stories, remote, least
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: maggie, marcy, mccormick, herbert, wyden, justice, hinds, jared, bryan, merkley, patty, lance
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, unavailable, converges, market, consensus, today, paper, identify, placed, placement, either, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-18] Fed speeches: Barr, Investing in America’s Underserved Communities
- [2026-11-18] Fed press (events + announcements): Minutes of the Federal Open Market Committee, October 27-28, 2026
- [2026-11-19] Fed speeches: Jefferson, Monetary Policy amid Frequent and Complex Shocks
- [2026-11-19] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of First Security Bancorp
- [2026-11-20] Fed speeches: Waller, Opening Remarks
- [2026-11-20] Fed press (events + announcements): Federal Reserve Board releases results from survey of senior financial officers at banks about their strategies and practices for managing reserve balances
- [2026-11-20] Fed speeches: Cook, The U.S. Economy in Global Context
- [2026-11-20] Fed press (events + announcements): Federal Reserve announces College Fed Challenge winners
- [2026-11-23] ECB press: Philip R. Lane: Climate change and monetary policy
- [2026-11-24] ECB press: Boris Vujčić: Resilience in an age of shocks: lessons from central and eastern Europe
- [2026-11-24] Fed press (events + announcements): Minutes of the Board's discount rate meetings on October 19 and October 28, 2026
- [2026-11-25] ECB press: Card payments edge past cash in shops; euro area consumers want both
- [2026-11-25] Fed speeches: Bowman, Modernizing Banking Supervision: A Shared Agenda for the Americas
- [2026-11-25] ECB press: ECB and Sveriges Riksbank conclude agreement for Sweden to join T2
- [2026-11-25] Fed press (events + announcements): Agencies announce dollar thresholds for applicability of truth in lending and consumer leasing rules for consumer credit and lease transactions

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*