# WORLDSCOPE morning brief — 2026-05-28

## Headline
1658 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 21 total
  (no new items today)

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 40 new of 644 total
  - (2026-05-27) [California] New California law bans law enforcement from interfering in state elections
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 103 new of 237 total
  - (2026-05-28) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-05-27) [St. Louis] Top 10 Swedish OnlyFans Stars Sharing Content in 2026 - St. Louis Riverfront Times
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBMQU9lS2FrV0dSbHZZZXgyckRzUy1OSDYyeGpBeVhlbENNbk9Ud25UVnVXc2FyZTdYSFlqRENxVkpoRUVOWjVIYS1lS2Vxa21oXzBxTXk4UTg1UXpqOXc?oc=5" target="_blank">Top 10 Swedish OnlyF
  - (2026-05-27) [St. Louis] Top Free OnlyFans: The Best Free Only Fans of 2026 - St. Louis Riverfront Times
      <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE1MTW9pXzV4SnFuTUFieEdsRlBmTEVZVW5VZWxacHBzY3BFU244S3k2cUxrYVl4MkE4a0h1S2t2ejREQWc2TzVsNE1WdkwtXzhMRXlDRkMwUkJDdw?oc=5" target="_blank">Top Free OnlyFans: The Be
  - (2026-05-28) [St. Louis] 10 Best Australian OnlyFans Models: Top Aussie OnlyFans in 2026 - St. Louis Riverfront Times
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9CVVFhUzFUNjROb0RjT0VVYUFjQWd4UEhVV3JpVkZ3U1BINGltQkpFSEMxMVpkVDl3Ui1pZ2hUZ0ljQXVjcWthd0pwQTNQTVlwX1V2b2NuQkNpaENNM1M4SXN3?oc=5" target="_blank">10 Best Austral
  - (2026-05-27) [St. Louis] Top 10 Indian OnlyFans: Hottest Indian Creators on OnlyFans in 2026 - St. Louis Riverfront Times
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxPckVFTE9HT2d4WlNPbm5ZRWN2cjVnTEUwaHhFeWxjMXlncjdXUDBEUDh0OXFUcXdxTV8xUlh5NGp6NkhlY0pJc2wzdWhnTXdPWjlRWGxXb2ZCTzlvRVBVQWJEWVhKYUZOTmhZZjNINEJiekNhYXRHalNNVlN4OX
  - (2026-05-27) [St. Louis] 10 Best Fitness Model OnlyFans in 2026 (Fitness Influencer & Gym Girl Only Fans) - St. Louis Riverfront Times
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5GaWFBdll3aDBzaU1kb05MRDkxMHM4TGVlY0hGTlhSamd5VTdDWXFhSW1mMU94R2JzekloYXhFQVd2YWpqdklQQ2xHNDlWd25jODBrMFJxR0NQOVRZZGc?oc=5" target="_blank">10 Best Fitness Mode
  - (2026-05-27) [St. Louis] 10 Best Femboy OnlyFans in 2026 (Top Only Fans Femboys) - St. Louis Riverfront Times
      <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE8yRGxXYTBNQTJhMlNSTXVOSVZ6bkgzcDZXUVZ4Qm5KSXdBcjlrSVJBSkdJVWdXRzlmbm56dzFaWUVrSVl1M29kSFAzd1pvS1ZmN2V4MTYyVW5rUVpu?oc=5" target="_blank">10 Best Femboy OnlyFans
  - (2026-05-27) [St. Louis] Top 10 Anal OnlyFans Creators in 2026 - St. Louis Riverfront Times
      <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE9yZGU0Z2ZucEQ4bjRwNlExbVpVTzY2WW5MelVWcmZFWVE4NGc0Rk1rMkJDNTJzem9YM285bXVwVXhqX0Y0ZjNJMHplaWRKY1o2bjM0dGxndWtyUQ?oc=5" target="_blank">Top 10 Anal OnlyFans Crea

### International News + Multilateral Institutions — 226 new of 876 total
  - (2026-05-28) [Global] Australia politics live: government sues manufacturer 3M over defence base Pfas contamination in ‘largest ever’ $2bn legal claim
  - (2026-05-28) [Global] Flooding rains expected across three Australian states as parched interior receives drenching
  - (2026-05-28) [Global] Anti-abortion activist concedes pictures of human foetuses may have been sugar glider joeys
  - (2026-05-27) [Global] Queensland man charged with murder after allegedly beating elderly pedestrian to death with pole
  - (2026-05-28) [Global] Human rights lawyer Francesca Albanese on life under US sanctions - podcast
  - (2026-05-28) [Global] Two killed in US strike on another alleged drug boat in Pacific as campaign’s death toll nears 200
  - (2026-05-28) [Global] Patagonia sues drag queen Pattie Gonia for trademark infringement
  - (2026-05-28) [Global] Trump’s justice department reportedly opens criminal investigation into E Jean Carroll – as it happened

### Chinese Internal News — 245 new of 264 total
  - (2026-05-26) [TITLE: “若美国对华态度变了，谁还搭理印度”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE55Ynh2UEl6S2FkTHBvZDJoRFVIMEZESXN6RUVqZEwzNlFhZ2ZDZTg2SmY4QThHMi1PcXlZT3d3Nlhaem9GeW5BUm5YZ1Myb] (zh: “若美国对华态度变了，谁还搭理印度”-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE55Ynh2UEl6S2FkTHBvZDJoRFVIMEZESXN6RUVqZEwzNlFhZ2ZDZTg2SmY4QThHMi1PcXlZT3d3Nlhaem9GeW5BUm5YZ1MybzNEYldMdzhWLVY5dEFtalpla1hmNnpieEdpcmc?oc=5" target="_blank">“若美国
  - (2026-05-27) [TITLE: “印尼如此配合美国，中国肯定不满”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBfT1hwRVVjVlZIV1ZiUVhfa09FbmFTaVZsNmF2Yk91ZEM4M1hvVDJHcUZySHlRbUdFcXRVeXp5ekstTjUzMURyd3N1MUc1R2] (zh: “印尼如此配合美国，中国肯定不满”-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBfT1hwRVVjVlZIV1ZiUVhfa09FbmFTaVZsNmF2Yk91ZEM4M1hvVDJHcUZySHlRbUdFcXRVeXp5ekstTjUzMURyd3N1MUc1R2VkMlgzMXNtZm9tNUp2TUltcU96djAzZmxRTUE?oc=5" target="_blank">“印尼如
  - (2026-05-26) [TITLE: “猛攻在即”！俄罗斯建议各国从基辅撤人，乌克兰称这是“讹诈” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9zMUxqLWxlcVE4Z0JHWXducVNLOFRxUmFKeEhSSFM0NEdEMmJWTkl4Q0lmcGphNG5mZmJ3UnBWY09IcGNYQnFHZF] (zh: “猛攻在即”！俄罗斯建议各国从基辅撤人，乌克兰称这是“讹诈” - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9zMUxqLWxlcVE4Z0JHWXducVNLOFRxUmFKeEhSSFM0NEdEMmJWTkl4Q0lmcGphNG5mZmJ3UnBWY09IcGNYQnFHZFY0d201NmtrWDhudEJlNEx0Yl9FR3V3LTZnNmtPUUtObUE?oc=5" target="_blank">“猛攻在
  - (2026-05-28) [TITLE: 广东卫健委提醒高温烫拼豆小心甲醛，大家有尝试过拼豆吗？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBIRUpOR2VUT1FWQklBa2gwMmhUWDlNTFBjME9XX3FRcXYyZl9KZU52SmpfMy1jVHY5d09mOFAwY2VNTFpHWFVFemJPMD] (zh: 广东卫健委提醒高温烫拼豆小心甲醛，大家有尝试过拼豆吗？ - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBIRUpOR2VUT1FWQklBa2gwMmhUWDlNTFBjME9XX3FRcXYyZl9KZU52SmpfMy1jVHY5d09mOFAwY2VNTFpHWFVFemJPMDBJS1diQ3k1VklJVjBSM3oycFpPdFR0Ql91RGNZRDlKenhYa0dnOEl4?oc=5" target=
  - (2026-05-28) [TITLE: 被问及为何把新片背景设定在新冠时期香港，管虎的回答感觉很矫情 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBhcDJ3LU9lZDc5X1ZTakN0akRhUngxVTQyaldYNXViZklzRnVJTi1pNE5hWlVFT1preWcxcG5nNm9VU2Rhdk11dFd] (zh: 被问及为何把新片背景设定在新冠时期香港，管虎的回答感觉很矫情 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBhcDJ3LU9lZDc5X1ZTakN0akRhUngxVTQyaldYNXViZklzRnVJTi1pNE5hWlVFT1preWcxcG5nNm9VU2Rhdk11dFdTS1ZTM0pPeEJ5cC1wUWw1Nm5RaGdGRTQxNThlNENmd253MHp6akRiVE1k?oc=5" target=
  - (2026-05-27) [TITLE: 当英国无赖抢救最后一座高炉：不要紧张，时代真的变了-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1EQjJid3RqcXF3emlMVEYwMDJPLVNnQUJhaVVMSURYcUxiVDBuS3VxbUdVMnZEdlp5cVNIR3oxR21yNjhLT3FHdG] (zh: 当英国无赖抢救最后一座高炉：不要紧张，时代真的变了-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1EQjJid3RqcXF3emlMVEYwMDJPLVNnQUJhaVVMSURYcUxiVDBuS3VxbUdVMnZEdlp5cVNIR3oxR21yNjhLT3FHdGd1SXNvdEY3NHQzTV80ZkRhRTlCUWhSeC1fYzc?oc=5" target="_blank">当英国无赖抢救最后一座高
  - (2026-05-27) [TITLE: 礼赞社科大师｜彭康：在国家利益前提下，考虑学校、个人利益 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5keHdTU1BqS0hZRzdTQ2FkeUF5QWFScHdwQ0dCLXJoenRqeF9YTDNMQ3lRSzZtWnM5OUMxLTFORUhjYmItTVljX0I5] (zh: 礼赞社科大师｜彭康：在国家利益前提下，考虑学校、个人利益 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5keHdTU1BqS0hZRzdTQ2FkeUF5QWFScHdwQ0dCLXJoenRqeF9YTDNMQ3lRSzZtWnM5OUMxLTFORUhjYmItTVljX0I5aXc4VzNBZDhEYl9TQmE5dDYwZXVwdHRQQ09LZw?oc=5" target="_blank">礼赞社科大师｜彭康
  - (2026-05-28) [TITLE: 如何看待河南农机手夫妇驰援襄阳抢收麦田，却遭遇“割四赔五”？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE9zcW1sbG44UzNNeGI4MEF4cDVBa3B5aEtkWU91LWJQRjVJRnVyQ0VvVGR4TGx3WTBHZGxad2l6Skl2ZzdsQlFzR2d] (zh: 如何看待河南农机手夫妇驰援襄阳抢收麦田，却遭遇“割四赔五”？ - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE9zcW1sbG44UzNNeGI4MEF4cDVBa3B5aEtkWU91LWJQRjVJRnVyQ0VvVGR4TGx3WTBHZGxad2l6Skl2ZzdsQlFzR2dBd3I0S0VxQTNKS3FWOTN5Skg3UFRwdnFibzR2M1h6Y1RreWk5bDVUUk5p?oc=5" target=

### Russian Internal News (state + in-exile) — 188 new of 944 total
  - (2026-05-28) [TITLE: Лантратова не получила ответа от ООН и ОБСЕ из-за удара ВСУ по Старобельску | LEDE: ] (ru: Лантратова не получила ответа от ООН и ОБСЕ из-за удара ВСУ по Старобельску)
  - (2026-05-28) [TITLE: Задержанному во Вьетнаме россиянину могут предъявить другие обвинения | LEDE: ] (ru: Задержанному во Вьетнаме россиянину могут предъявить другие обвинения)
  - (2026-05-28) [TITLE: Офицеры бригады теробороны ВСУ уничтожены ударом по командному пункту | LEDE: ] (ru: Офицеры бригады теробороны ВСУ уничтожены ударом по командному пункту)
  - (2026-05-28) [TITLE: ВСУ перебросили роту солдат на убой в Черниговскую область | LEDE: ] (ru: ВСУ перебросили роту солдат на убой в Черниговскую область)
  - (2026-05-28) [TITLE: Расчеты "Кракена"* сбежали с передовой в Харьковской области | LEDE: ] (ru: Расчеты "Кракена"* сбежали с передовой в Харьковской области)
  - (2026-05-28) [TITLE: Израиль объявил о гибели резервиста на севере страны | LEDE: ] (ru: Израиль объявил о гибели резервиста на севере страны)
  - (2026-05-28) [TITLE: "Ему конец": в ЕС рассказали, как Зеленский вывел из себя Каллас | LEDE: ] (ru: "Ему конец": в ЕС рассказали, как Зеленский вывел из себя Каллас)
  - (2026-05-28) [TITLE: Операторы БПЛА сорвали попытку атаки ВСУ под Воздвижевкой | LEDE: ] (ru: Операторы БПЛА сорвали попытку атаки ВСУ под Воздвижевкой)

### Ukrainian Internal News (national + local Kyiv) — 11 new of 113 total
  - (2026-05-28) [TITLE: У Китаї перевантажений мікроавтобус врізався у вантажівку, 13 загиблих | LEDE: У китайській провінції переповнений мікроавтобус врізався у вантажівку, внаслідок чого 13 людей загинули, троє – о] (uk: У Китаї перевантажений мікроавтобус врізався у вантажівку, 13 загиблих)
      У китайській провінції переповнений мікроавтобус врізався у вантажівку, внаслідок чого 13 людей загинули, троє – отримали трвми.
  - (2026-05-28) [TITLE: Трамп завив про підтримку Пашиняна перед парламентськими виборами у Вірменії | LEDE: Напередодні парламентських виборів у Вірменії Трамп заявив про підтримку Пашиняна.] (uk: Трамп завив про підтримку Пашиняна перед парламентськими виборами у Вірменії)
      Напередодні парламентських виборів у Вірменії Трамп заявив про підтримку Пашиняна.
  - (2026-05-28) [TITLE: Ціна підпілля. Що чекає на учасників руху опору окупації в тюрмі та на волі | LEDE: Жодна людина – не острів, сама по собі; кожен з нас – частина континенту... Смерть кожної людини зменшує і ме] (uk: Ціна підпілля. Що чекає на учасників руху опору окупації в тюрмі та на волі)
      Жодна людина – не острів, сама по собі; кожен з нас – частина континенту... Смерть кожної людини зменшує і мене, бо я єдиний з усім людством; а тому ніколи не питай, по кому дзвонить дзвін: він дзвонить і по тобі.
  - (2026-05-28) [TITLE: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані | LEDE: Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.] (uk: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані)
      Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.
  - (2026-05-28) [TITLE: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ | LEDE: Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.] (uk: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ)
      Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.
  - (2026-05-28) [TITLE: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ | LEDE: За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.] (uk: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ)
      За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.
  - (2026-05-28) [TITLE: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби ППО | LEDE: Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.] (uk: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби)
      Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.
  - (2026-05-28) Unified Front: Zelensky, Tsikhanouskaya Address Russian Threats and Lukashenko’s War Role
      Belarusian democratic leader Sviatlana Tsikhanouskaya met President Volodymyr Zelensky in Kyiv during her first working visit to Ukraine, marking a major step in formalizing ties between Kyiv and Belarusian democratic fo

### Ukraine Theater (total-war monitoring) — 267 new of 441 total
  - (2026-05-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [FIRMS] thermal anomaly 47.174, 31.756 (FRP 0.47 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.47 MW
  - (2026-05-27) [FIRMS] thermal anomaly 46.684, 32.687 (FRP 1.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 1.38 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.374, 30.926 (FRP 1.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 1.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.259, 31.673 (FRP 9.83 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 9.83 MW
  - (2026-05-27) [FIRMS] thermal anomaly 44.772, 33.858 (FRP 0.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 44.772, 33.863 (FRP 0.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.953, 22.869 (FRP 0.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.41 MW

### Paper Trading Scorecard — 3 new of 136 total
  - (2026-05-28) [Polymarket] Will there be between 10 and 20 average daily transits of the Strait of Hormuz on May 31?
      This market will resolve according to the 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for May 31, 2026.

If the reported value falls exactly between two
  - (2026-05-28) [Manifold] Will "Contra Wentworth on Physical Attractiveness f..." make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-05-28) [Manifold] Will 200 or more ships cross the straight of Hormuz in a day in 2026?

### U.S. Weather + Severe / Climate Outlooks — 62 new of 103 total
  - (2026-05-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 11:39PM EDT by NWS Wilmington OH
      Some patchy dense fog is developing late this evening, especially
in lower terrain areas. Fog is expected to become more widespread
for some areas into the early morning hours, with dense fog likely
impacting local commu
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 10:26PM CDT until May 27 at 11:15PM CDT by NWS Norman OK
      SVROUN

The National Weather Service in Norman has issued a

* Severe Thunderstorm Warning for...
Southeastern Knox County in northern Texas...
Southwestern Baylor County in northern Texas...

* Until 1115 PM CDT.

* At 
  - (2026-05-27) [Moderate] Gale Warning: Gale Warning issued May 27 at 8:24PM PDT until May 27 at 11:00PM PDT by NWS Eureka CA
      * WHAT...North winds 20 to 30 kt with gusts up to 40 kt and seas
15 to 17 feet.

* WHERE...Waters from Pt. St. George to Cape Mendocino CA from
10 to 60 nm.

* WHEN...Until 11 PM PDT this evening.

* IMPACTS...Strong win
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 11:19PM EDT until May 28 at 4:00AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by prior excessive rainfall is expected.

* WHERE...Northeastern Washington County in southeastern Ohio...

* WHEN...Until 400 AM EDT.

* IMPACTS...Flooding of rivers, creeks, streams, and other 
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 11:15PM EDT by NWS Wakefield VA
      At 1115 PM EDT, Doppler radar was tracking strong thunderstorms along
a line extending from near Franklin to near Como to near Conway.
Movement was southeast at 40 mph.

HAZARD...Wind gusts up to 40 mph and half inch hai
  - (2026-05-27) [Severe] Red Flag Warning: Red Flag Warning issued May 27 at 8:15PM MST until May 28 at 8:00PM MST by NWS Flagstaff AZ
      ...RED FLAG WARNING REMAINS IN EFFECT FROM 11 AM MST /NOON MDT/ TO 8
PM MST /9 PM MDT/ THURSDAY...

* WHAT...Southerly winds 15 to 25 mph, with gusts from 35 to 45 mph.
Minimum relative humidity between 7 and 14 percent.
  - (2026-05-27) [Severe] Red Flag Warning: Red Flag Warning issued May 27 at 8:15PM MST until May 28 at 8:00PM MST by NWS Flagstaff AZ
      * WHAT...Southerly winds 15 to 25 mph, with gusts from 30 to 40 mph.
Minimum relative humidity between 7 and 10 percent.

* WHERE...Little Colorado River Valley in Apache County.

* WHEN...From 11 AM MST /noon MDT/ to 8 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 20 new of 95 total
  - (2026-05-27) [OFAC] International Criminal Court-related Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoYmsxWDE3WFh2VzgyWDZ2Y2xnSVJHZzFTTnUtUlM5Z0tOMktfbXRkUmJhMmdHa2wwM19JRnhiWkwxdENoT0owTkx0cEU0ZmdIUk5CVGFjZ2cxbDJOS2c?oc=5" target="_blank">International Crimin
  - (2026-05-28) [OFAC] Iran-related Designation; Counter Terrorism Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1wZHZVOFR1Yy1MSzRFaERsQlZWWmFCSV9fcUQ5eFpEWVdtV3N2dFFZdFlqWG9ldkNFNTBGdjRBSHVrdTlwNmhRT2xndXotaHlyakdWdXpvS2Fkek5QY0UwWG9B?oc=5" target="_blank">Iran-related De
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-28) [USASpending] $534,079,951 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
      Agency: General Services Administration.  Description: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
  - (2026-05-28) [USASpending] $486,224,471 → LOCKHEED MARTIN CORPORATION: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTR
      Agency: National Aeronautics and Space Administration.  Description: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTRUMENT THE FOR GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) R.  THE CONTRACTOR 
  - (2026-05-28) [USASpending] $432,416,292 → LEIDOS BIOMEDICAL RESEARCH INC: NCI OPERATIONAL TASK ORDER
      Agency: Department of Health and Human Services.  Description: NCI OPERATIONAL TASK ORDER
  - (2026-05-28) [USASpending] $406,089,353 → AERODYNE-SGT ENGINEERING SERVICES, LLC: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEER
      Agency: National Aeronautics and Space Administration.  Description: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEERING TASK ORDERS FOR THE FORMULATION, DESIGN, DEVELOPMENT, FABRICATION, INTEGRATION, TESTING
  - (2026-05-28) [USASpending] $405,028,920 → VERIZON BUSINESS NETWORK SERVICES LLC: CENTRALIZED HHS EIS REQUIREMENT
      Agency: Department of Health and Human Services.  Description: CENTRALIZED HHS EIS REQUIREMENT

### Congressional STOCK Act Trades (House + Senate) — 53 new of 53 total
  - (2026-05-06) [Senate] Bernardo Moreno (R): Sale (Full) ETOR ($100,001 - $250,000) (excess -2.3% vs SPY)
      Member: Bernardo Moreno (R, senate).  BioGuide: M001242.  Asset: ETOR (Stock).  Type: Sale (Full).  Amount range: $100,001 - $250,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-22.  Excess return vs SPY si
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.1% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.1% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-04-29) [House] Thomas H. Kean Jr (R): Sale ADI ($1,001 - $15,000) (excess +1.6% vs SPY)
      Member: Thomas H. Kean Jr (R, house).  BioGuide: K000398.  Asset: ADI (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-04-29.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-07) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +12.6% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-06) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +18.9% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Tim Moore (R): Purchase T ($15,001 - $50,000) (excess +0.3% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: T (ST).  Type: Purchase.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure: +0
  - (2026-05-07) [House] Tim Moore (R): Purchase RYCEY ($1,001 - $15,000) (excess -0.2% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: RYCEY (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure:

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-28) [WHEELER SIMON] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [RAWLINGS DARRYL] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:55 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Ollet John] Form 4 (Reporting)
      filed 2026-05-28 01:55 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Lerman Michael Stuart] Form 4 (Reporting)
      filed 2026-05-28 01:53 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:53 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 27 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-28) [United States] Activist Rosa María Payá says Cubans back ousting dictatorship amid crisis
      domain: kval.com · language: English · tone: 
  - (2026-05-28) [Nigeria] Tinubu : Abducted pupils not abandoned - The Nation Newspaper
      domain: thenationonlineng.net · language: English · tone: 
  - (2026-05-28) [Malaysia] MP SPEAKS | Suhakam findings highlight urgent prison , institutional reform
      domain: malaysiakini.com · language: English · tone: 
  - (2026-05-28) [United States] Truck driver in deadly Turnpike crash returns to court after Florida loses CDL lawsuit
      domain: nebraska.tv · language: English · tone: 
  - (2026-05-28) [United States] Cynthia Erivo Got Candid About What She Was Thinking When Someone Grabbed Ariana Grande At A Wicked Premiere
      domain: cinemablend.com · language: English · tone: 
  - (2026-05-28) [United States] Fact Check Team : Backlash over Trump $1 . 77B anti - weaponization fund & who it may reward
      domain: nebraska.tv · language: English · tone: 
  - (2026-05-28) [United States] Man Sues Carnival Cruise Over Hot Pool Deck Burns
      domain: 710wor.iheart.com · language: English · tone: 
  - (2026-05-28) [Australia] NZ delivers stripped - back budget with few incentives
      domain: perthnow.com.au · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 16 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 5 new of 20 total
  - (2026-05-28) Will South Korea win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,994,964 · resolves 2026-07-20
  - (2026-05-28) US announces new Iran agreement/ceasefire extension by May 31?
      yes price: 20% · 24h volume: $771,923
  - (2026-05-28) Colorado Rockies vs. Los Angeles Dodgers
      yes price: 8% · 24h volume: $746,835 · resolves 2026-06-04
  - (2026-05-28) Will Germany win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $732,517 · resolves 2026-07-20
  - (2026-05-28) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $689,323 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 0 new of 6 total
  (no new items today)

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25; carrying terms: airplanes, regulatory, address, airbus, authorized, program, including, airworthiness, designated, establishing, prohibited, provide
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=644, 7d-median=722, 14d-median=722
- local_news: today=237, 7d-median=265, 14d-median=265
- foreign_news: today=876, 7d-median=906, 14d-median=906
- chinese_internal: today=264, 7d-median=289, 14d-median=289
- russian_internal: today=944, 7d-median=1021, 14d-median=1021
- ukrainian_internal: today=113, 7d-median=138, 14d-median=138
- ukraine_theater: today=441, 7d-median=441, 14d-median=441
- paper_bets: today=136, 7d-median=136, 14d-median=136
- weather: today=103, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=53, 7d-median=53, 14d-median=53
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: jabar, arocho, larosa, internal, revenue, local, kenneth, andre, blanche, caribbean, balazs, vasquez
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: israel, kingdom, domain, canada, strikes, india, nigeria, language, english
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, coast, returns, price, normal, regime, traffic, extension, strait, ceasefire, world, agreement
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: jisang, evidence, economics, policy, marginalrevolution, essay, approaches, roderick, revolution, functions, production, along
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*