# WORLDSCOPE morning brief — 2026-05-28

## Headline
1593 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 21 total
  (no new items today)

### State Legislative Action — 382 new of 382 total
  - (2026-05-28) [Alaska SB 2] An Act relating to disclosure of election-related deepfakes; relating to use of artificial intelligence by state agencies; and relating to transfer of data about individuals between state agencies.
      An Act relating to disclosure of election-related deepfakes; relating to use of artificial intelligence by state agencies; and relating to transfer of data about individuals between state agencies.
  - (2026-05-28) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contributions for public school funding; relating to municipal property 
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut
  - (2026-05-28) [Alaska HB 17] An Act relating to retirement benefits and military service.
      An Act relating to retirement benefits and military service.
  - (2026-05-28) [Alaska HB 121] An Act relating to the practice of accounting; relating to private professional conservators; amending Rule 17(e), Alaska Rules of Probate Procedure; and providing for an effective date.
      An Act relating to the practice of accounting; relating to private professional conservators; amending Rule 17(e), Alaska Rules of Probate Procedure; and providing for an effective date.
  - (2026-05-28) [Alaska HCR 6] Commemorating the 250th birthday of the United States Marine Corps.
      Commemorating the 250th birthday of the United States Marine Corps.
  - (2026-05-28) [Alaska SB 33] An Act relating to defamation claims based on the use of synthetic media; relating to the use of synthetic media in electioneering communications; and providing for an effective date.
      An Act relating to defamation claims based on the use of synthetic media; relating to the use of synthetic media in electioneering communications; and providing for an effective date.
  - (2026-05-28) [Alaska HB 381] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of revenue from the alternative volumetric tax; and providing for an 
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re
  - (2026-05-28) [Alaska HJR 13] Urging the President of the United States to expand evacuation efforts for applicants with approved Special Immigrant Visas, including resumption of evacuation flights organized by the Coordinator for Afghan Relocation Efforts; urging the United States Department of State to secure l
      Urging the President of the United States to expand evacuation efforts for applicants with approved Special Immigrant Visas, including resumption of evacuation flights organized by the Coordinator for Afghan Relocation E

### State-Level News — 38 new of 642 total
  - (2026-05-27) [California] New California law bans law enforcement from interfering in state elections
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 54 new of 243 total
  - (2026-05-28) [St. Louis] DOJ opens criminal investigation into Trump accuser E. Jean Carroll, reports say
      The Department of Justice is investigating E. Jean Carroll for possible perjury related to her civil lawsuits against Donald Trump, according to reports.
  - (2026-05-28) [St. Louis] Popular supplements recalled as FDA reopens investigation into salmonella outbreak
      Federal health officials have reopened a multistate salmonella investigation after 22 new cases emerged.
  - (2026-05-28) [St. Louis] US military conducts another strike against Iran after Trump says Iran is 'negotiating on fumes'
      President Donald Trump met with his Cabinet on Wednesday at a precarious moment for talks aimed at ending the war with Iran.
  - (2026-05-28) [St. Louis] Former CIA officer accused of stealing 300 gold bars worth more than $40 million
      David Rush was charged with criminal theft of public money after investigators found gold bars, about $2 million and luxury watches in his home, NBC News reported.
  - (2026-05-28) [St. Louis] Kyle Busch battled bacterial pneumonia for 'days to weeks' before rapid organ failure, death certificate shows
      Kyle Busch's death certificate, obtained by multiple outlets, reveals that the two-time NASCAR champion silently fought a severe lung infection for weeks.
  - (2026-05-28) [St. Louis] Metro East community exploring $20M fieldhouse to boost year-round sports tourism
      “We’re looking for an opportunity to continue the tourism in some of the winter months when a lot of the outdoor activities pack up for the season,” Van Hook said.
  - (2026-05-27) [St. Louis] Deputies in Spokane recover $70,000 stolen metal T-Rex statue buried underground
      The dinosaur, due to its extreme size and weight of about 400 pounds, had to be towed out of the ground by tow trucks.
  - (2026-05-27) [St. Louis] St. Louis police want drones in the sky. The mayor says not so fast
      The St. Louis Board of Police Commissioners approved a drone first responder program Wednesday, but Mayor Cara Spencer and commissioners slammed the rushed process.

### International News + Multilateral Institutions — 184 new of 877 total
  - (2026-05-28) [Global] Australia politics live: government sues manufacturer 3M over defence base Pfas contamination in ‘largest ever’ $2bn legal claim
  - (2026-05-28) [Global] Anti-abortion activist concedes pictures of human foetuses may have been sugar glider joeys
  - (2026-05-27) [Global] Queensland man charged with murder after allegedly beating elderly pedestrian to death with pole
  - (2026-05-28) [Global] Human rights lawyer Francesca Albanese on life under US sanctions - podcast
  - (2026-05-28) [Global] Trump’s justice department reportedly opens criminal investigation into E Jean Carroll – as it happened
  - (2026-05-28) [Global] US justice department reportedly opens criminal inquiry into Trump accuser E Jean Carroll
  - (2026-05-28) [Global] Newsom to impose 100% tax on California payees of Trump’s $1.8bn fund
  - (2026-05-28) [Global] Tank-rupture tragedy may be deadliest in Washington history, governor says

### Chinese Internal News — 185 new of 260 total
  - (2026-05-27) [TITLE: 金正恩观摩朝鲜新型武器系统试射 含AI 制导巡航导弹 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE01NDRlRXNUVTVuQng5M1hyV2xUcnV4ZjFVNXhEeHJSSXRYTGZfUENSeW9kSTJsankzcXFPYlR2YzBOVnNjMTQ1b1dPUXE] (zh: 金正恩观摩朝鲜新型武器系统试射 含AI 制导巡航导弹 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE01NDRlRXNUVTVuQng5M1hyV2xUcnV4ZjFVNXhEeHJSSXRYTGZfUENSeW9kSTJsankzcXFPYlR2YzBOVnNjMTQ1b1dPUXEwZ19jOV9qYy1ndlEyNkdEeGZ4bA?oc=5" target="_blank">金正恩观摩朝鲜新型武器系统试射 含
  - (2026-05-28) [TITLE: 今日开盘：两市双双低开 沪指跌幅0.33% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBlbzN0LUwtX2xySmVQR2dGcGhnclBTd3hrd09BN3BIVjRzR2N6aXB0TG55RjZ4LW1ucXZyQlFQNkVvcmZoS0lBQXF2QnV0M0dl] (zh: 今日开盘：两市双双低开 沪指跌幅0.33% - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBlbzN0LUwtX2xySmVQR2dGcGhnclBTd3hrd09BN3BIVjRzR2N6aXB0TG55RjZ4LW1ucXZyQlFQNkVvcmZoS0lBQXF2QnV0M0dlSWx4NkhVUGFwQkN5b0g1R0VB?oc=5" target="_blank">今日开盘：两市双双低开 沪指跌
  - (2026-05-28) [TITLE: 夏吟兰逝世一周年：用一生改变妇女命运｜纪念 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Db3QybkM1a2w5RHQzTXQxRXlNWnh6RzVVM1UwVjR5MzNMTHpFS2UyVTBWMklCMmgzNjA5SDlRYklrbGM1OEpMOTJDdVQ3bHV0] (zh: 夏吟兰逝世一周年：用一生改变妇女命运｜纪念 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Db3QybkM1a2w5RHQzTXQxRXlNWnh6RzVVM1UwVjR5MzNMTHpFS2UyVTBWMklCMmgzNjA5SDlRYklrbGM1OEpMOTJDdVQ3bHV0X1V1VDZtc2MtM1BBZWc?oc=5" target="_blank">夏吟兰逝世一周年：用一生改变妇女命运｜纪
  - (2026-05-28) [TITLE: 市场火热 4月底公募基金规模冲上39万亿元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1yRGhWeGFManFlUlVDTlhCZUZJY2JHeXY1Y2lCa3FSc01SWWZBbDlaX0NPVXc3dkZDa0pMcnh0UDJJeUdyZTFZbm8xeFA0MU1q] (zh: 市场火热 4月底公募基金规模冲上39万亿元 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1yRGhWeGFManFlUlVDTlhCZUZJY2JHeXY1Y2lCa3FSc01SWWZBbDlaX0NPVXc3dkZDa0pMcnh0UDJJeUdyZTFZbm8xeFA0MU1qV3c3ZzB3c182em9zdDQ5RFd3?oc=5" target="_blank">市场火热 4月底公募基金规模冲
  - (2026-05-28) [TITLE: 研究者建议降低出口退税率 节省财政资金用于惠民生 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE53Wms1UFhmMWtpQzBjWWJJQnhTbWpYemdicmZQRkVNRC1UUy1PWVAzZEE4MUR5NHJVdk5admpUR0J2NGV4V3pYczktbjBCU] (zh: 研究者建议降低出口退税率 节省财政资金用于惠民生 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE53Wms1UFhmMWtpQzBjWWJJQnhTbWpYemdicmZQRkVNRC1UUy1PWVAzZEE4MUR5NHJVdk5admpUR0J2NGV4V3pYczktbjBCUGNvc0p3Tm5SenZoN2hvcXFSWHFB?oc=5" target="_blank">研究者建议降低出口退税率 节省
  - (2026-05-27) [TITLE: 低空飞行器企业沃兰特获10亿元融资 或将冲击IPO - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFB4UW9mS00xVGRsT3pKQlRaNm9ra3c4UmZGU3hRMUVyblh5N2pOUmVvdnlleVVWcVBGX1NITVhqUE9uUzZxVW5Yblo4NmRC] (zh: 低空飞行器企业沃兰特获10亿元融资 或将冲击IPO - 财新)
      <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFB4UW9mS00xVGRsT3pKQlRaNm9ra3c4UmZGU3hRMUVyblh5N2pOUmVvdnlleVVWcVBGX1NITVhqUE9uUzZxVW5Yblo4NmRCM0pWWWRlY18tU21Pa3g0YTkwQkRxT18?oc=5" target="_blank">低空飞行器企业沃兰特获1
  - (2026-05-28) [TITLE: 立讯精密被罚 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1ZUk8zbUpWamVISFpKanZhUDJhWVhaMm5qNUZaeU9SY0w0Y3F2bnVhV2RWRkdPY0VneDlpZmNzN0hhOThvcm56ZXNuTGJ5Ni05V0FFN0RlTTN2cmR] (zh: 立讯精密被罚 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1ZUk8zbUpWamVISFpKanZhUDJhWVhaMm5qNUZaeU9SY0w0Y3F2bnVhV2RWRkdPY0VneDlpZmNzN0hhOThvcm56ZXNuTGJ5Ni05V0FFN0RlTTN2cmRSWlE?oc=5" target="_blank">立讯精密被罚</a>&nbsp;&nbs
  - (2026-05-28) Appeal of China assets keeps rising among global investors, JPMorgan research says

### Russian Internal News (state + in-exile) — 149 new of 941 total
  - (2026-05-28) [TITLE: Трампа не устраивают условия сделки с Ираном, и он начал угрожать Оману | LEDE: Президент США Дональд Трамп в среду заявил, что все еще не удовлетворен параметрами ожидающегося соглашения с Тег] (ru: Трампа не устраивают условия сделки с Ираном, и он начал угрожать Оману)
      Президент США Дональд Трамп в среду заявил, что все еще не удовлетворен параметрами ожидающегося соглашения с Тегераном. Он в резкой форме отверг предложение о том, что Иран мог быть регулировать судоходство в Ормузском 
  - (2026-05-26) [TITLE: В Бельгии столкнулись поезд и школьный автобус, погибли четыре человека | LEDE: В результате столкновения поезда со школьным микроавтобусом в городе Бюггенхаут в Бельгии погибли двое детей и дв] (ru: В Бельгии столкнулись поезд и школьный автобус, погибли четыре человека)
      В результате столкновения поезда со школьным микроавтобусом в городе Бюггенхаут в Бельгии погибли двое детей и два взрослых.
  - (2026-05-28) [TITLE: ВСУ создали систему укрепрайонов в Воздвижевке, рассказал боец | LEDE: ] (ru: ВСУ создали систему укрепрайонов в Воздвижевке, рассказал боец)
  - (2026-05-28) [TITLE: В Минздраве рассказали, как вовремя распознать предиабет | LEDE: ] (ru: В Минздраве рассказали, как вовремя распознать предиабет)
  - (2026-05-28) [TITLE: Боец рассказал об освобождении Воздвижевки | LEDE: ] (ru: Боец рассказал об освобождении Воздвижевки)
  - (2026-05-28) [TITLE: СМИ: Пентагон ведет переговоры с фирмами о росте производства БПЛА | LEDE: ] (ru: СМИ: Пентагон ведет переговоры с фирмами о росте производства БПЛА)
  - (2026-05-28) [TITLE: Японские компании участвовали во встречах в России, заявили в минэкономики | LEDE: ] (ru: Японские компании участвовали во встречах в России, заявили в минэкономики)
  - (2026-05-28) Москва и Минск продолжают работу по созданию истребителя Су-75

### Ukrainian Internal News (national + local Kyiv) — 7 new of 112 total
  - (2026-05-28) [TITLE: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані | LEDE: Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.] (uk: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані)
      Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.
  - (2026-05-28) [TITLE: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ | LEDE: Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.] (uk: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ)
      Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.
  - (2026-05-28) [TITLE: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ | LEDE: За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.] (uk: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ)
      За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.
  - (2026-05-28) [TITLE: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби ППО | LEDE: Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.] (uk: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби)
      Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.
  - (2026-05-28) Trump Endorses Pashinyan Ahead of Crucial Armenia Vote
      US President Donald Trump endorsed Armenian Prime Minister Nikol Pashinyan ahead of a key parliamentary election, praising his peace agenda and plans for the US-backed “Trump Route” corridor. The endorsement came a day a
  - (2026-05-28) Ukraine to Be Fully Integrated Into EU Air Defense, Drone Priorities, Von der Leyen Says
      European Commission President Ursula von der Leyen said Ukraine will be included in Europe’s urgent defense efforts, backed by a €28.3 billion loan for Kyiv’s military needs.
  - (2026-05-28) Sybiha Calls for Airport or Seaport Truce as First Step Toward Peace
      Foreign Minister Andrii Sybiha said Europe should first push for a limited airport or seaport truce, using sanctions and frozen Russian assets to press Moscow toward practical peace steps.

### Ukraine Theater (total-war monitoring) — 23 new of 394 total
  - (2026-05-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [Liveuamap] Air raid targeted Buday Baalbek-Hermel Governorate, Lebanon - Lebanon news on live map - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMie0FVX3lxTE8yZ29DRzcwSTYyU2RSTFVtQ0hvdXF3QkptbTNGUjE4YUtjSC14ekdxWGNsbmlrcGloTVR2TTJQWkg5czNZanBWcFB6eTl5RE9hMVJZd2p5S3FSUjBWN0t0ODdvem1pUE15SXVyMW5ackg2TEp1dGlTblo3aw?oc=
  - (2026-05-26) [Liveuamap] President Trump says he wouldn't be comfortable with China or Russia taking Iran's stockpile of highly enriched uranium - iran.liveuamap.com
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxQSEtpc2lKT3B0NWtMOVBpM1QyTUpHXzBjR3BXb0pUazVuTjRYd0N4dGpJSExQVnZoMzU0ajkxV3hGdjdwUmhLVEgxRmJJV0VLSDloYlJ0eHJzYlQ3Yk54M2FDMjU0NnVOazdNQnBPcVJlbDRSZVlZdHMteWRDcH
  - (2026-05-24) [Liveuamap] One person killed in the airstrike that targeted the town of Al-Namiriya - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMinAFBVV95cUxOMTFIZmIxZnBsczJmRE92U3BUZTJtWkNfcmpfeXBDQ1VZTzdoMWp6a1VjTEc4aWM3U3IyUVFpVHJDMjhiZVUtSXd2dTZCUFNfUmszSVkzYmsySnVYSjZCTHl1NHlXMk1NMVJJd3BQOUJEdlVqVUgwX3JqaUVGan
  - (2026-05-23) [Liveuamap] IRBM strike was reported in Kyiv region - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMihgFBVV95cUxOeVR6ZzE1aWxLYm9PdFpPWi1zTFFlQjExanE4UnRpc24zOUNUb1VwdktlRzFwU09NM3ZwVTdSLVZYUElLVWZBY2Y2S1lDXzNLS0pPQmRIWkVCaGlhdmxKM0hNY1VsMW5mb2l0MmxUSmF6d1Z4ZmZ5OWEwV2VOV0
  - (2026-05-02) [Liveuamap] News Live - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMimAFBVV95cUxQbU55eTJxb05ra1R2RGlHb2FsQjlwbm4xRmpJdWhLYnVWeEl1Q2tUa1VhclVBZjdIWEswVXBUaVRvSFZhTDJMZUwwQzNOX2Jhc3h2U1U5NGFnaVZpUm1CSGpfQlU1NUhibHczRXZlX0ZtU1RtcXZHc3JBS0dlWW
  - (2026-05-17) [Liveuamap] Earthquake of magnitude 4.6 - 145 km WNW of Hihifo, Tonga - disasters.liveuamap.com
      <a href="https://news.google.com/rss/articles/CBMifEFVX3lxTE1SM3RlYzltZFFIWWdPWXdCdlpIOGJnd0tldG9FRERSRDhfcGNZTndzX295ZHkxeGRob1hVeFdqNGpRb3Rsd3hwMkNwRDduckZ5NmotLW4ydDdnSUJWQWlabldoVkVqNVZBWnhNUFBWV3BEc19iYjZfWEFFWTY?oc
  - (2026-05-06) [Liveuamap] News Live - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE1LQ2c5U2t0aldUQ0tfR1NtMWJ0R1lQS1FEaGZsdGJPb19lNnNTTEtLY011REt0cjZUUjVBeS15aGVQWDJxUUR5MEQtU2xncmtuN3N5NzBqODRjUQ?oc=5" target="_blank">News Live</a>&nbsp;&nbsp;

### Paper Trading Scorecard — 4 new of 137 total
  - (2026-05-28) [Polymarket] LoL: Supernova vs Winthrop University (BO5) - North American Challengers League Playoffs
      This market refers to the LoL Lower bracket quarterfinal match between Supernova and Winthrop University in the North American Challengers League Playoffs, initially scheduled for May 27 at 4:00PM ET.

This market will r
  - (2026-05-28) [Polymarket] Will there be between 10 and 20 average daily transits of the Strait of Hormuz on May 31?
      This market will resolve according to the 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for May 31, 2026.

If the reported value falls exactly between two
  - (2026-05-28) [Polymarket] Will Gretchen Whitmer win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”.

The resolution source for this mark
  - (2026-05-28) [Manifold] Will "Contra Wentworth on Physical Attractiveness f..." make the top fifty posts in LessWrong's 2026 Annual Review?

### U.S. Weather + Severe / Climate Outlooks — 51 new of 101 total
  - (2026-05-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 9:22PM CDT until May 29 at 1:00AM CDT by NWS Chicago IL
      * WHAT...High wave action and dangerous currents expected at Lake
Michigan beaches. Waves 4 to 6 feet expected.

* WHERE...Lake IL, Northern Cook and Central Cook Counties.

* WHEN...Through late Thursday night.

* IMPAC
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 9:22PM CDT until May 29 at 4:00AM CDT by NWS Chicago IL
      * WHAT...High wave action and dangerous currents expected at Lake
Michigan beaches. Waves 4 to 6 feet expected.

* WHERE...Lake IN and Porter Counties.

* WHEN...From 1 AM CDT Thursday through late Thursday night.

* IMP
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 7:19PM PDT by NWS Hanford CA
      At 719 PM PDT, Doppler radar was tracking a strong thunderstorm over
Wasco, or 14 miles southwest of Delano, moving southeast at 10 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IM
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 7:15PM PDT by NWS Eureka CA
      At 714 PM PDT, Doppler radar was tracking strong thunderstorms along
a line extending from near Somes Bar to 7 miles north of Helena.
Movement was southwest at 40 mph.

HAZARD...Winds in excess of 40 mph and pea size hai
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 7:15PM PDT until May 29 at 3:00AM PDT by NWS San Francisco CA
      * WHAT...Increased risk of sneaker waves and strong rip currents
due to incoming long period northwesterly swell.

* WHERE...Beaches along the Pacific Coast.

* WHEN...From Thursday morning through late Thursday night.


  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 9:13PM CDT by NWS Norman OK
      At 913 PM CDT, Doppler radar was tracking strong thunderstorms along
a line extending from 12 miles northwest of Truscott to 3 miles west
of Lockett. Movement was southeast at 25 mph.

HAZARD...Wind gusts up to 50 mph an
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 10:11PM EDT until May 28 at 2:18PM EDT by NWS Indianapolis IN
      ...The Flood Warning continues for the following rivers in Indiana...

Youngs Creek at Amity.

East Fork White River at Williams, Bedford, and Rivervale.

Mississinewa River near Ridgeville.

...The Flood Warning is exte

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 13 new of 94 total
  - (2026-05-27) [OFAC] International Criminal Court-related Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoYmsxWDE3WFh2VzgyWDZ2Y2xnSVJHZzFTTnUtUlM5Z0tOMktfbXRkUmJhMmdHa2wwM19JRnhiWkwxdENoT0owTkx0cEU0ZmdIUk5CVGFjZ2cxbDJOS2c?oc=5" target="_blank">International Crimin
  - (2026-05-28) [USASpending] $534,079,951 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
      Agency: General Services Administration.  Description: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
  - (2026-05-28) [USASpending] $486,224,471 → LOCKHEED MARTIN CORPORATION: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTR
      Agency: National Aeronautics and Space Administration.  Description: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTRUMENT THE FOR GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) R.  THE CONTRACTOR 
  - (2026-05-28) [USASpending] $432,416,292 → LEIDOS BIOMEDICAL RESEARCH INC: NCI OPERATIONAL TASK ORDER
      Agency: Department of Health and Human Services.  Description: NCI OPERATIONAL TASK ORDER
  - (2026-05-28) [USASpending] $406,089,353 → AERODYNE-SGT ENGINEERING SERVICES, LLC: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEER
      Agency: National Aeronautics and Space Administration.  Description: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEERING TASK ORDERS FOR THE FORMULATION, DESIGN, DEVELOPMENT, FABRICATION, INTEGRATION, TESTING
  - (2026-05-28) [USASpending] $405,028,920 → VERIZON BUSINESS NETWORK SERVICES LLC: CENTRALIZED HHS EIS REQUIREMENT
      Agency: Department of Health and Human Services.  Description: CENTRALIZED HHS EIS REQUIREMENT
  - (2026-05-28) [USASpending] $402,848,838 → GUIDEHOUSE INC.: THE PURPOSE OF THIS REQUIREMENT FOR GRANTS PROGRAM SOLUTIONS
      Agency: Department of the Interior.  Description: THE PURPOSE OF THIS REQUIREMENT FOR GRANTS PROGRAM SOLUTIONS AND IT SUPPORT SERVICES IS TO PROVIDE EFFICIENT AND EFFECTIVE GRANT, FINANCIAL, AND CONTRACT MANAGEMENT SERVI
  - (2026-05-28) [USASpending] $400,000,000 → WHITING-TURNER CONTRACTING COMPANY, THE: ACCELERATED DESIGN-BUILD TO BUDGET CONSTRUCT BARRACKS, MULTI
      Agency: Department of Homeland Security.  Description: ACCELERATED DESIGN-BUILD TO BUDGET CONSTRUCT BARRACKS, MULTI-USE TRAINING FACILITY, GALLEY & FIREHOUSE AT USCG TRACEN CAPE MAY, CAPE MAY, NJ

### Congressional STOCK Act Trades (House + Senate) — 53 new of 53 total
  - (2026-05-06) [Senate] Bernardo Moreno (R): Sale (Full) ETOR ($100,001 - $250,000) (excess -2.3% vs SPY)
      Member: Bernardo Moreno (R, senate).  BioGuide: M001242.  Asset: ETOR (Stock).  Type: Sale (Full).  Amount range: $100,001 - $250,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-22.  Excess return vs SPY si
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.1% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.1% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-04-29) [House] Thomas H. Kean Jr (R): Sale ADI ($1,001 - $15,000) (excess +1.6% vs SPY)
      Member: Thomas H. Kean Jr (R, house).  BioGuide: K000398.  Asset: ADI (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-04-29.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-07) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +12.6% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-06) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +18.9% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Tim Moore (R): Purchase T ($15,001 - $50,000) (excess +0.3% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: T (ST).  Type: Purchase.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure: +0
  - (2026-05-07) [House] Tim Moore (R): Purchase RYCEY ($1,001 - $15,000) (excess -0.2% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: RYCEY (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure:

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-28) [WHEELER SIMON] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [RAWLINGS DARRYL] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:55 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Ollet John] Form 4 (Reporting)
      filed 2026-05-28 01:55 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Lerman Michael Stuart] Form 4 (Reporting)
      filed 2026-05-28 01:53 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:53 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 27 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-28) [] IPAC , APM demand credible polls , neutrality of INEC
      domain: thesun.ng · language: English · tone: 
  - (2026-05-28) [United States] Police Seek Information On Property Offences In Darwin 28 May
      domain: miragenews.com · language: English · tone: 
  - (2026-05-28) [United States] Benbrook nail salon reopens three months after SUV crashed through its front wall
      domain: wfaa.com · language: English · tone: 
  - (2026-05-28) [Canada] BRIONES : When your back gives out , life comes to a standstill
      domain: nanaimobulletin.com · language: English · tone: 
  - (2026-05-28) [United States] Pattie Gonia : Patagonia trying to  erase  her with lawsuit
      domain: advocate.com · language: English · tone: 
  - (2026-05-28) [United States] Toyota recalls 43 , 500 trucks over engine defect that could cause sudden stall
      domain: fox5atlanta.com · language: English · tone: 
  - (2026-05-28) [United States] Man fatally shoots himself as Detroit police raid home , 2nd suspect being sought
      domain: wxyz.com · language: English · tone: 
  - (2026-05-28) [United States] South Korea holds rates , alert to inflation risks
      domain: finance.yahoo.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 11 new of 11 total
  - (2026-05-28) PAT326 (United States)
      icao24: adfe55 · position: (38.6347, -77.8713) · alt: 1539m · 361km/h
  - (2026-05-28) CFC2558 (Canada)
      icao24: c2b599 · position: (52.9933, -108.5803) · alt: 8839m · 604km/h
  - (2026-05-28) NCR9537 (United States)
      icao24: a6caa1 · position: (20.4309, 120.7114) · alt: 12496m · 910km/h
  - (2026-05-28) NCR711 (United States)
      icao24: aabbef · position: (32.3711, -97.9255) · alt: 4175m · 645km/h
  - (2026-05-28) RCH437 (United States)
      icao24: ae2fa8 · position: (52.4864, 5.0792) · alt: 11277m · 838km/h
  - (2026-05-28) SAM397 (United States)
      icao24: ae6cf1 · position: (42.3925, -71.0489) · alt: 1021m · 381km/h
  - (2026-05-28) JAF7GY (Belgium)
      on ground
  - (2026-05-28) CFCBA (Canada)
      icao24: c00563 · position: (46.2851, -89.5694) · alt: 13106m · 797km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 16 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 4 new of 20 total
  - (2026-05-28) US announces new Iran agreement/ceasefire extension by May 31?
      yes price: 20% · 24h volume: $764,119
  - (2026-05-28) Will Switzerland win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $730,321 · resolves 2026-07-20
  - (2026-05-28) Will Germany win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $714,177 · resolves 2026-07-20
  - (2026-05-28) Cincinnati Reds vs. New York Mets
      yes price: 0% · 24h volume: $705,989 · resolves 2026-06-03

### Commentary & analysis (last 7 days) — 0 new of 6 total
  (no new items today)

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25; carrying terms: require, temporary, products, corrective, field, areas, urban, regulatory, fishing, specifically, coast, changes
- state_bills: today=382, 7d-median=382, 14d-median=382
- state_news: today=642, 7d-median=722, 14d-median=722
- local_news: today=243, 7d-median=265, 14d-median=265
- foreign_news: today=877, 7d-median=906, 14d-median=906
- chinese_internal: today=260, 7d-median=289, 14d-median=289
- russian_internal: today=941, 7d-median=1021, 14d-median=1021
- ukrainian_internal: today=112, 7d-median=138, 14d-median=138
- ukraine_theater: today=394, 7d-median=394, 14d-median=394
- paper_bets: today=137, 7d-median=137, 14d-median=137
- weather: today=101, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=94, 7d-median=95, 14d-median=95
- congressional_trades: today=53, 7d-median=53, 14d-median=53
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: trustees, salud, president, hospital, raquan, solis, webuild, revenue, transport, vasquez, rodriguez, mahmoud
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: canada, english, cancer, language, kingdom, domain, india
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=11, 7d-median=11, 14d-median=11
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, normal, announces, ivory, price, ceasefire, returns, peace, bitcoin, volume, continue, strait
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: laugh, recent, approaches, economists, insider, seminars, along, economist, rejesus, policy, marginalrevolution, class
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*