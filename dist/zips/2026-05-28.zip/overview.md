# WORLDSCOPE morning brief — 2026-05-28

## Headline
2415 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 24 new of 24 total
  - (2026-05-28) Memorial Day, 2026
  - (2026-05-28) Air Plan Approval; Ohio; Removal of Air Nuisance Rule
      The Environmental Protection Agency (EPA) is proposing to act in accordance with Ohio EPA's November 14, 2025, request to remove the air pollution nuisance rule (ANR) from the Ohio State Implementation Plan (SIP). The EP
  - (2026-05-28) Approval of Source-Specific Air Quality Implementation Plan; New York; Big Six Towers Inc.
      The Environmental Protection Agency (EPA) is proposing to determine a revision to the State of New York's State Implementation Plan (SIP) for the ozone National Ambient Air Quality Standard (NAAQS) related to a source-sp
  - (2026-05-28) Hazardous and Solid Waste Management System: Disposal of Coal Combustion Residuals From Electric Utilities; Federal CCR Permit Program; Reopening of Comment Period
      The Environmental Protection Agency (EPA) issued a proposed rule on February 20, 2020, to establish a Federal permit program for disposal of coal combustion residuals (CCR). The EPA is reopening the comment period on tha
  - (2026-05-28) Air Plan Approval; SC; Department Name Change
      The Environmental Protection Agency (EPA) is proposing to approve a State Implementation Plan (SIP) revision submitted by the State of South Carolina on July 23, 2025. The proposed revision updates all references to refl
  - (2026-05-28) Air Plan Approval; Maryland; Reasonably Available Control Technology for Municipal Waste Combustors; Extension of Comment Period
      The Environmental Protection Agency (EPA) is extending the comment period for a proposed rule that published April 29, 2026. The current comment period for the proposed rule was scheduled to close on May 29, 2026. The EP
  - (2026-05-28) Medical Devices; Gastroenterology-Urology Devices; Classification of the Endoscopic Suturing Device for Altering Gastric Anatomy for Weight Loss
      The Food and Drug Administration (FDA) is classifying the endoscopic suturing device for altering gastric anatomy for weight loss into class II (special controls). The special controls that apply to the device type are i
  - (2026-05-28) Proposed Waiver and Extension of the Project Period With Funding for Arts in Education National Program
      The Secretary proposes to waive the requirements in the Education Department General Administrative Regulations that generally prohibit project period extensions involving the obligation of additional Federal funds. The 

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 117 new of 695 total
  - (2026-05-27) [California] New California law bans law enforcement from interfering in state elections
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 139 new of 246 total
  - (2026-05-28) [St. Louis] How WashU’s Tim Miller helped pioneer a major breakthrough for ALS
      <p>Dr. Tim Miller and the drug tofersen are the talk of the medical world after a test led by Miller showed that tofersen could achieve remarkable results for patients with ALS, also known as amyotrophic lateral sclerosi
  - (2026-05-28) [St. Louis] St. Louis business leaders seek to shake up the data center narrative
      <p>Data centers are the topic that just won’t go away, and given the public acrimony surrounding them, local business leaders and other supporters are keen on reframing the conversation. Case-in-point was the panel conve
  - (2026-05-28) [St. Louis] Summer travelers need a break from 18.4¢ federal gas tax  | James Rosen
  - (2026-05-28) [St. Louis] Suspending federal gas tax will only worsen transportation | Marc Goldwein
  - (2026-05-28) [St. Louis] Letter: Road projects should include traffic calming for deadly stretches
      Regarding "Pedestrian killed in Jennings" (May 24): Saturday morning’s tragedy occurred at West Florissant Avenue and Carl Avenue. Another pedestrian was killed last month just a half mile to the east while crossing Jenn
  - (2026-05-28) [St. Louis] Letter: Planned White House UFC cage match is a disgrace to America
      A large structure is currently being built on the South Lawn of the White House for Donald Trump’s "UFC (Ultimate Fighting Championship) Freedom 250." In a few weeks, mixed martial arts fighters will enter a cage and fig
  - (2026-05-28) [St. Louis] Letter: Wear black this July 4 to express mourning for our democracy
      Many Americans are wondering how we can peacefully protest when there is no organized rally, no march, and no “No Kings” event scheduled nearby?
  - (2026-05-28) [St. Louis] Stages turns 40: A look back at some of the company's seminal productions
      What have been your favorite Stages shows over the years?

### International News + Multilateral Institutions — 497 new of 860 total
  - (2026-05-28) [Global] Dormitory fire at Kenyan school kills at least 15 students
  - (2026-05-28) [Global] Greener pasture of a shepherd’s life lures Chinese workers penned in by ‘996’ jobs
  - (2026-05-28) [Global] Wild weather unleashes thunderstorms across south-east Australia, triggering flash flooding
  - (2026-05-28) [Global] Modelling shows 90% of young Australians will be better off under Labor’s tax reforms
  - (2026-05-28) [Global] Victorian greyhound trainer avoids ban despite dog being found with cocaine in system
  - (2026-05-28) [Global] Treasury secretary says ‘no clear evidence’ for CGT reform criticisms – as it happened
  - (2026-05-28) [Global] US firm fined for Australian immigration security failures. How much? Border force refuses to say
  - (2026-05-28) [Global] Kaja Kallas warns against walking into Russian ‘trap’ as EU ministers meet for talks – Europe live

### Chinese Internal News — 250 new of 269 total
  - (2026-05-26) China’s Fiscal Revenue Improves but Spending Momentum Fades - Caixin Global
      <a href="https://news.google.com/rss/articles/CBMiswFBVV95cUxPNm9UZmo0bTVfTTgzWjZYeVRsRTdNQU9QYXdSdG4zTEhhc1psRk5iTnpFOHN2NWNKWXhlbnNLVU9SaXdHWWp6dlRXQmNCdzBOSEtqVDg5ZEhrSnNGUmlDZzVMWEdYVkxSbjZUd1pUOEZydGZYRlFUUWktWjNNcT
  - (2026-05-26) [TITLE: “若美国对华态度变了，谁还搭理印度”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE55Ynh2UEl6S2FkTHBvZDJoRFVIMEZESXN6RUVqZEwzNlFhZ2ZDZTg2SmY4QThHMi1PcXlZT3d3Nlhaem9GeW5BUm5YZ1Myb] (zh: “若美国对华态度变了，谁还搭理印度”-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE55Ynh2UEl6S2FkTHBvZDJoRFVIMEZESXN6RUVqZEwzNlFhZ2ZDZTg2SmY4QThHMi1PcXlZT3d3Nlhaem9GeW5BUm5YZ1MybzNEYldMdzhWLVY5dEFtalpla1hmNnpieEdpcmc?oc=5" target="_blank">“若美国
  - (2026-05-27) [TITLE: “印尼如此配合美国，中国肯定不满” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBfT1hwRVVjVlZIV1ZiUVhfa09FbmFTaVZsNmF2Yk91ZEM4M1hvVDJHcUZySHlRbUdFcXRVeXp5ekstTjUzMURyd3N1MUc1R2VkMlg] (zh: “印尼如此配合美国，中国肯定不满” - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBfT1hwRVVjVlZIV1ZiUVhfa09FbmFTaVZsNmF2Yk91ZEM4M1hvVDJHcUZySHlRbUdFcXRVeXp5ekstTjUzMURyd3N1MUc1R2VkMlgzMXNtZm9tNUp2TUltcU96djAzZmxRTUE?oc=5" target="_blank">“印尼如
  - (2026-05-28) [TITLE: 如何看待刘强东表态称，被机器人取代的员工，一个都不开除？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5Sdi1OTmNzUXBfNmhrYXRVbWVOdmRWM1p3TjlUREVrX1BSSEw0RlBJNDFmUGFnMVM5QWNZNFhJbG9rbnJXR0IyNUE5Q] (zh: 如何看待刘强东表态称，被机器人取代的员工，一个都不开除？ - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5Sdi1OTmNzUXBfNmhrYXRVbWVOdmRWM1p3TjlUREVrX1BSSEw0RlBJNDFmUGFnMVM5QWNZNFhJbG9rbnJXR0IyNUE5QVhrOTk4Nm1FcEkzWF95d1IzV2hjTl9rdVItVzZ0RVIxUzVQZElyVng5?oc=5" target=
  - (2026-05-28) [TITLE: 被问及为何把新片背景设定在新冠时期香港，管虎的回答感觉很矫情 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBhcDJ3LU9lZDc5X1ZTakN0akRhUngxVTQyaldYNXViZklzRnVJTi1pNE5hWlVFT1preWcxcG5nNm9VU2Rhdk11dFd] (zh: 被问及为何把新片背景设定在新冠时期香港，管虎的回答感觉很矫情 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBhcDJ3LU9lZDc5X1ZTakN0akRhUngxVTQyaldYNXViZklzRnVJTi1pNE5hWlVFT1preWcxcG5nNm9VU2Rhdk11dFdTS1ZTM0pPeEJ5cC1wUWw1Nm5RaGdGRTQxNThlNENmd253MHp6akRiVE1k?oc=5" target=
  - (2026-05-28) [TITLE: 广东卫健委提醒高温烫拼豆小心甲醛，大家有尝试过拼豆吗？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBIRUpOR2VUT1FWQklBa2gwMmhUWDlNTFBjME9XX3FRcXYyZl9KZU52SmpfMy1jVHY5d09mOFAwY2VNTFpHWFVFemJPMD] (zh: 广东卫健委提醒高温烫拼豆小心甲醛，大家有尝试过拼豆吗？ - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBIRUpOR2VUT1FWQklBa2gwMmhUWDlNTFBjME9XX3FRcXYyZl9KZU52SmpfMy1jVHY5d09mOFAwY2VNTFpHWFVFemJPMDBJS1diQ3k1VklJVjBSM3oycFpPdFR0Ql91RGNZRDlKenhYa0dnOEl4?oc=5" target=
  - (2026-05-28) [TITLE: 在印留学的女生讲述：50度的高温，晚上睡觉都感觉内脏在沸腾 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5rYmhSc2JSUXhBeUd1bkExNDhfWi1UTmxFVE9WblBLWUdCRWhWUGRTcFV6QS1hSHJlU0hCU0NsWWVDdFQ2Zk5wNGcx] (zh: 在印留学的女生讲述：50度的高温，晚上睡觉都感觉内脏在沸腾 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5rYmhSc2JSUXhBeUd1bkExNDhfWi1UTmxFVE9WblBLWUdCRWhWUGRTcFV6QS1hSHJlU0hCU0NsWWVDdFQ2Zk5wNGcxaTdqS1pYSlNJRnRpUm1FUmc?oc=5" target="_blank">在印留学的女生讲述：50度的高温，晚上睡觉都感觉
  - (2026-05-28) [TITLE: 向往成为西欧人？今天的塞尔维亚年轻人在想什么？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5Dcm9lNzJXT09oSGRGTzBJZElwaHJoWEoyQ3NOUk9iNkU1NmVZQkx2b3dUOHA3TFFDaHFsajZYeDR0S0NmdTRJc3BndHFDNk] (zh: 向往成为西欧人？今天的塞尔维亚年轻人在想什么？ - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5Dcm9lNzJXT09oSGRGTzBJZElwaHJoWEoyQ3NOUk9iNkU1NmVZQkx2b3dUOHA3TFFDaHFsajZYeDR0S0NmdTRJc3BndHFDNkkzSjVtZnJGb0xva0E?oc=5" target="_blank">向往成为西欧人？今天的塞尔维亚年轻人在想什么？<

### Russian Internal News (state + in-exile) — 511 new of 1067 total
  - (2026-05-28) [TITLE: Норвегия присоединится к французскому «ядерному зонтику» | LEDE: <p>Премьер-министр Норвегии Йонас Гар Стере и президент Франции Эммануэль Макрон подписали оборонное соглашение, которое, в част] (ru: Норвегия присоединится к французскому «ядерному зонтику»)
      <p>Премьер-министр Норвегии Йонас Гар Стере и президент Франции Эммануэль Макрон подписали оборонное соглашение, которое, в частности, предусматривает присоединение Норвегии к французской инициативе в сфере ядерного сдер
  - (2026-05-28) [TITLE: Члены Общественной палаты пожаловались на «ряженых ветеранов СВО» | LEDE: <p>Члены Общественной палаты РФ считают, что ситуация с негосударственными наградами «участникам СВО» вышла из-под конт] (ru: Члены Общественной палаты пожаловались на «ряженых ветеранов СВО»)
      <p>Члены Общественной палаты РФ считают, что ситуация с негосударственными наградами «участникам СВО» вышла из-под контроля. Фонды, некоммерческие организации и даже частные лица выпускают огромное количество своих награ
  - (2026-05-28) [TITLE: Кая Каллас заявила, что США эвакуировали дипломатов из Киева после угроз России нанести удары. Посольство США и МИД Украины это отрицают | LEDE: <p>Глава дипломатии ЕС Кая Каллас заявила, что а] (ru: Кая Каллас заявила, что США эвакуировали дипломатов из Киева после угроз России )
      <p>Глава дипломатии ЕС Кая Каллас заявила, что американские дипломаты покинули Киев после угроз России нанести удары.<p>
  - (2026-05-28) [TITLE: В России стали вдвое чаще задерживать авиарейсы. Число отмененных рейсов выросло в четыре раза | LEDE: <p>Количество длительных задержек авиарейсов за неполные пять месяцев 2026 года в России в] (ru: В России стали вдвое чаще задерживать авиарейсы. Число отмененных рейсов выросло)
      <p>Количество длительных задержек авиарейсов за неполные пять месяцев 2026 года в России выросло в среднем в два раза по сравнению с аналогичным периодом прошлого года, число отмен — в четыре раза, число отмен после заде
  - (2026-05-28) [TITLE: Беспилотник ударил по зданию областного суда в Нижнем Новгороде | LEDE: <p>Здание областного суда в Нижнем Новгороде повреждено в результате удара украинского дрона, сообщил губернатор Глеб Ник] (ru: Беспилотник ударил по зданию областного суда в Нижнем Новгороде)
      <p>Здание областного суда в Нижнем Новгороде повреждено в результате удара украинского дрона, сообщил губернатор Глеб Никитин. Люди, по его данным, не пострадали.<p>
  - (2026-05-28) [TITLE: Трамп поддержал Пашиняна на выборах в Армении | LEDE: <p>Президент США Дональд Трамп заявил, что «полностью и безоговорочно» поддерживает премьер-министра Армении Никола Пашиняна на предстоящих] (ru: Трамп поддержал Пашиняна на выборах в Армении)
      <p>Президент США Дональд Трамп заявил, что «полностью и безоговорочно» поддерживает премьер-министра Армении Никола Пашиняна на предстоящих парламентских выборах. <p>
  - (2026-05-28) [TITLE: США и Иран обменялись ударами, но перемирие не отменили | LEDE: <p>США нанесли удар по военному объекту в городе Бендер-Аббас на юге Ирана, сообщило агентство Reuters со ссылкой на американског] (ru: США и Иран обменялись ударами, но перемирие не отменили)
      <p>США нанесли удар по военному объекту в городе Бендер-Аббас на юге Ирана, сообщило агентство Reuters со ссылкой на американского чиновника. <p>
  - (2026-05-28) [TITLE: Горящий Туапсе, разбомбленный Брянск, масштабный налет дронов на Москву и нефтяные дожди над Пермью и Рязанью — все это случилось в 2026 году. Кажется, Украина стала куда чаще бить вглубь терри] (ru: Горящий Туапсе, разбомбленный Брянск, масштабный налет дронов на Москву и нефтян)
      <p>Серия массированных ударов Вооруженных сил Украины (ВСУ) по Брянску, Москве, Перми, Туапсе и многим другим целям в глубине России создает у многих наблюдателей устойчивое впечатление: в 2026 году Киеву удалось качеств

### Ukrainian Internal News (national + local Kyiv) — 41 new of 122 total
  - (2026-05-28) [TITLE: Зеленський анонсував "сильний крок" щодо отримання Україною винищувачів Gripen | LEDE: Президент Володимир Зеленський, який перебуває з візитом у Швеції, анонсував "сильний крок" щодо отримання] (uk: Зеленський анонсував "сильний крок" щодо отримання Україною винищувачів Gripen)
      Президент Володимир Зеленський, який перебуває з візитом у Швеції, анонсував "сильний крок" щодо отримання Україною шведських винищувачів Gripen.
  - (2026-05-28) [TITLE: ДБР розслідує окреме провадження у справі Гринкевичів щодо бронежилетів і шоломів: збитки – 150 млн грн | LEDE: У Державному бюро розслідувань заявили, що розслідують окреме провадження у справ] (uk: ДБР розслідує окреме провадження у справі Гринкевичів щодо бронежилетів і шоломі)
      У Державному бюро розслідувань заявили, що розслідують окреме провадження у справі львівського бізнесмена Ігоря Гринкевича та його сина Романа щодо постачання бронежилетів і шоломів для ЗСУ за завищеними цінами. Збитки д
  - (2026-05-28) [TITLE: Європейським послам показали іноземні компоненти ракет і дронів, якими Росія атакувала Україну 24 травня | LEDE: Європейським послам продемонстрували іноземні компоненти, які були в російських ] (uk: Європейським послам показали іноземні компоненти ракет і дронів, якими Росія ата)
      Європейським послам продемонстрували іноземні компоненти, які були в російських ракетах і БпЛА, випущених по Україні вночі 24 травня.
  - (2026-05-28) [TITLE: ЗМІ: У Москві на дахах будинків встановлюють ЗРК | LEDE: У Москві на даху бізнес-центру розмістили ЗРК "Панцирь-СМД-Е" за допомогою гелікоптера Ми-26. Опубліковано відео.] (uk: ЗМІ: У Москві на дахах будинків встановлюють ЗРК)
      У Москві на даху бізнес-центру розмістили ЗРК "Панцирь-СМД-Е" за допомогою гелікоптера Ми-26. Опубліковано відео.
  - (2026-05-28) [TITLE: Окупанти убили чоловіка і жінку на Сумщині – цивільних атакували дроном | LEDE: Удар російського дрона у Сумській області: загинули двоє цивільних] (uk: Окупанти убили чоловіка і жінку на Сумщині – цивільних атакували дроном)
      Удар російського дрона у Сумській області: загинули двоє цивільних
  - (2026-05-28) [TITLE: У застосунку Київ Цифровий з’явився новий сервіс "Мій депутат" | LEDE: У застосунку Київ Цифровий з'явився новий сервіс "Мій депутат", який допоможе мешканцям краще розуміти, як працює Київрада] (uk: У застосунку Київ Цифровий з’явився новий сервіс "Мій депутат")
      У застосунку Київ Цифровий з'явився новий сервіс "Мій депутат", який допоможе мешканцям краще розуміти, як працює Київрада та які рішення ухвалюють депутати.
  - (2026-05-28) [TITLE: Останні дні травня будуть з дощами і грозами | LEDE: 29-31 травня в Україні збережеться тепла погода з дощами. Детальний прогноз від Укргідрометцентру.] (uk: Останні дні травня будуть з дощами і грозами)
      29-31 травня в Україні збережеться тепла погода з дощами. Детальний прогноз від Укргідрометцентру.
  - (2026-05-28) [TITLE: У МЗС Швеції заявили, що Європа має бути на боці України, а не посередником у переговорах з РФ | LEDE: Міністерка закордонних справ Швеції Марія Мальмер Стенергард заявила, що Європа має посилю] (uk: У МЗС Швеції заявили, що Європа має бути на боці України, а не посередником у пе)
      Міністерка закордонних справ Швеції Марія Мальмер Стенергард заявила, що Європа має посилювати тиск на Росію і підтримку України, а не поспішати до переговорів на умовах Кремля.

### Ukraine Theater (total-war monitoring) — 299 new of 365 total
  - (2026-05-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [FIRMS] thermal anomaly 47.174, 31.756 (FRP 0.47 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.47 MW
  - (2026-05-27) [FIRMS] thermal anomaly 46.684, 32.687 (FRP 1.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 1.38 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.374, 30.926 (FRP 1.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 1.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.259, 31.673 (FRP 9.83 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 9.83 MW
  - (2026-05-27) [FIRMS] thermal anomaly 44.772, 33.858 (FRP 0.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 44.772, 33.863 (FRP 0.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.953, 22.869 (FRP 0.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.41 MW

### Paper Trading Scorecard — 9 new of 141 total
  - (2026-05-28) [Polymarket] Will NVIDIA (NVDA) hit (HIGH) $240 in May?
      This market will resolve to "Yes" if, at any point during May 2026, any 1-minute candle for NVIDIA (NVDA) has a final "High" price equal to or above the listed price. Otherwise, this market will resolve to "No".

Only pr
  - (2026-05-28) [Polymarket] Will Sergio Pérez be the 2026 F1 Drivers' Champion?
      This market will resolve according to the listed driver that finishes 1st in the driver standings for the 2026 F1 season.

This market will resolve as soon as the official results of the final scheduled race of the 2026 
  - (2026-05-28) [Polymarket] Russia x Ukraine ceasefire agreement by October 31, 2026?
      This market will resolve to “Yes” if there is a ceasefire agreement between Russia and Ukraine by the specified date, 11:59 PM ET. Otherwise, this market will resolve to “No”.

A ceasefire agreement refers to any mutuall
  - (2026-05-28) [Polymarket] Will Gretchen Whitmer win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”.

The resolution source for this mark
  - (2026-05-28) [Manifold] Will "Donating 80% While It Still Counts" make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-05-28) [Manifold] Will the Green Bay Packers win the Super Bowl in 2027?
  - (2026-05-28) [Manifold] Will "Contra Wentworth on Physical Attractiveness f..." make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-05-28) [Manifold] Will 2+ bots beat master league in 2026?

### U.S. Weather + Severe / Climate Outlooks — 105 new of 112 total
  - (2026-05-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-28) [Moderate] Special Weather Statement: Special Weather Statement issued May 28 at 5:40AM CDT by NWS Norman OK
      At 539 AM CDT, Doppler radar was tracking a strong thunderstorm 5
miles southwest of Lockett, moving southeast at 15 mph.

HAZARD...Wind gusts of 40 mph and half inch hail.

SOURCE...Radar indicated.

IMPACT...Gusty wind
  - (2026-05-28) [Severe] Special Marine Warning: Special Marine Warning issued May 28 at 6:33AM EDT until May 28 at 7:30AM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW

The National Weather Service in Ruskin has issued a

* Special Marine Warning for...
Charlotte Harbor and Pine Island Sound...
Coastal waters from Bonita Beach to Englewood FL out 20 NM...
Coastal waters from Eng
  - (2026-05-28) [Moderate] Special Weather Statement: Special Weather Statement issued May 28 at 6:17AM EDT by NWS Charleston WV
      Fog has developed across portions of the region this morning. Fog
could be dense in some locations, with visibility a quarter of a
mile or less. Use caution if traveling, and be alert for rapidly
changing visibility over
  - (2026-05-28) [Moderate] Special Weather Statement: Special Weather Statement issued May 28 at 6:00AM EDT by NWS Wilmington OH
      Some patchy dense fog is occurring this morning, especially in
lower terrain areas. Fog will dissipate between 8am and 10am.

For those traveling, utilize low-beam headlights, leave extra
distance between cars and use ex
  - (2026-05-28) [Severe] Flood Warning: Flood Warning issued May 28 at 5:51AM EDT until May 28 at 6:00PM EDT by NWS Charleston WV
      ...The Flood Warning is extended for the following rivers in West
Virginia...

West Fork River above Clarksburg affecting Harrison County.

For the West Fork River...Minor flooding is forecast.

* WHAT...Minor flooding i
  - (2026-05-28) [Severe] Flood Warning: Flood Warning issued May 28 at 5:45AM EDT until May 28 at 2:00PM EDT by NWS Charleston WV
      ...The Flood Warning is extended for the following rivers in West
Virginia...

Little Kanawha River at Glenville affecting Gilmer County.

For the Little Kanawha River...Minor flooding is forecast.

* WHAT...Minor floodi
  - (2026-05-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued May 28 at 4:41AM CDT until May 28 at 11:00AM CDT by NWS Amarillo TX
      * WHAT...Visibility a quarter mile or less in dense fog.

* WHERE...A portion of the Panhandle of Texas.

* WHEN...Until 11 AM CDT this morning.

* IMPACTS...Low visibility could make driving conditions hazardous.

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 20 new of 95 total
  - (2026-05-27) [OFAC] International Criminal Court-related Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoYmsxWDE3WFh2VzgyWDZ2Y2xnSVJHZzFTTnUtUlM5Z0tOMktfbXRkUmJhMmdHa2wwM19JRnhiWkwxdENoT0owTkx0cEU0ZmdIUk5CVGFjZ2cxbDJOS2c?oc=5" target="_blank">International Crimin
  - (2026-05-28) [OFAC] Iran-related Designation; Counter Terrorism Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1wZHZVOFR1Yy1MSzRFaERsQlZWWmFCSV9fcUQ5eFpEWVdtV3N2dFFZdFlqWG9ldkNFNTBGdjRBSHVrdTlwNmhRT2xndXotaHlyakdWdXpvS2Fkek5QY0UwWG9B?oc=5" target="_blank">Iran-related De
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-28) [USASpending] $30,433,184,240 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST               
      Agency: Department of Energy.  Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST               LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-05-28) [USASpending] $10,688,516,058 → ALLIANCE FOR ENERGY INNOVATION, LLC: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWAB
      Agency: Department of Energy.  Description: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWABLE ENERGY LABORATORY
  - (2026-05-28) [USASpending] $4,681,725,957 → RUSSIA SPACE AGENCY: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
      Agency: National Aeronautics and Space Administration.  Description: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
  - (2026-05-28) [USASpending] $3,283,051,341 → JEFFERSON SCIENCE ASSOCIATES, LLC: TAS::89 0222::TAS MANAGEMENT AND OPERATION OF THE THOMAS JEF
      Agency: Department of Energy.  Description: TAS::89 0222::TAS MANAGEMENT AND OPERATION OF THE THOMAS JEFFERSON NATIONAL ACCELERATOR FACILITY.
  - (2026-05-28) [USASpending] $3,061,819,994 → OAK RIDGE ASSOCIATED UNIVERSITIES, INCORPORATED: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIEN
      Agency: Department of Energy.  Description: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIENCE AND EDUCATION

### Congressional STOCK Act Trades (House + Senate) — 0 new of 1 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-28) [Wu Junhua] Form 4 (Reporting)
      filed 2026-05-28 10:45 UTC · role: Reporting — Filed: 2026-05-28 AccNo: 0001104659-26-067208 Size: 5 KB
  - (2026-05-28) [Baozun Inc.] Form 4 (Issuer)
      filed 2026-05-28 10:45 UTC · role: Issuer — Filed: 2026-05-28 AccNo: 0001104659-26-067208 Size: 5 KB
  - (2026-05-28) [Marx Dylan] Form 4 (Reporting)
      filed 2026-05-28 10:31 UTC · role: Reporting — Filed: 2026-05-28 AccNo: 0001104659-26-067196 Size: 8 KB
  - (2026-05-28) [Canadian Solar Inc.] Form 4 (Issuer)
      filed 2026-05-28 10:31 UTC · role: Issuer — Filed: 2026-05-28 AccNo: 0001104659-26-067196 Size: 8 KB
  - (2026-05-28) [Marx Dylan] Form 4/A (Reporting)
      filed 2026-05-28 10:27 UTC · amended · role: Reporting — Filed: 2026-05-28 AccNo: 0001104659-26-067193 Size: 6 KB
  - (2026-05-28) [Canadian Solar Inc.] Form 4/A (Issuer)
      filed 2026-05-28 10:27 UTC · amended · role: Issuer — Filed: 2026-05-28 AccNo: 0001104659-26-067193 Size: 6 KB
  - (2026-05-28) [JUSKIE JO ANN] Form 4 (Reporting)
      filed 2026-05-28 10:24 UTC · role: Reporting — Filed: 2026-05-28 AccNo: 0002069480-26-000004 Size: 5 KB
  - (2026-05-28) [Keysight Technologies, Inc.] Form 4 (Issuer)
      filed 2026-05-28 10:24 UTC · role: Issuer — Filed: 2026-05-28 AccNo: 0002069480-26-000004 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 27 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 16 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-05-28) Will South Korea win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,993,905 · resolves 2026-07-20
  - (2026-05-28) LoL: DN SOOPers vs Nongshim Red Force (BO3) - LCK Rounds 1-2
      yes price: 0% · 24h volume: $1,459,263 · resolves 2026-05-28
  - (2026-05-28) US-Iran nuclear deal by May 31?
      yes price: 7% · 24h volume: $1,420,048 · resolves 2026-05-31
  - (2026-05-28) Will Donald Trump dance on May 25, 2026?
      yes price: 0% · 24h volume: $1,036,770 · resolves 2026-05-31
  - (2026-05-28) LoL: DN SOOPers vs Nongshim Red Force - Game 1 Winner
      yes price: 100% · 24h volume: $890,805 · resolves 2026-05-28
  - (2026-05-28) US announces new Iran agreement/ceasefire extension by May 31?
      yes price: 16% · 24h volume: $847,522
  - (2026-05-28) Will Sergio Pérez be the 2026 F1 Drivers' Champion?
      yes price: 0% · 24h volume: $805,718 · resolves 2026-12-06

### Commentary & analysis (last 7 days) — 1 new of 6 total
  - (2026-05-28) [Marginal Revolution] My excellent Conversation with Toby Wilkinson
      Here is the audio, video, and transcript.  Most of all, we cover Ptolemaic Egypt.  Here is part of the episode summary: Tyler and Toby cover how Alexander took over the empire almost without a fight, why Alexandria becam

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=25, 14d-median=25; carrying terms: public, unless, service, authorized, requires, specifically, waters, designated, field, persons, enforce, relevant
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=695, 7d-median=722, 14d-median=722
- local_news: today=246, 7d-median=265, 14d-median=265
- foreign_news: today=860, 7d-median=906, 14d-median=906
- chinese_internal: today=269, 7d-median=289, 14d-median=289
- russian_internal: today=1067, 7d-median=1067, 14d-median=1067
- ukrainian_internal: today=122, 7d-median=138, 14d-median=138
- ukraine_theater: today=365, 7d-median=394, 14d-median=394
- paper_bets: today=141, 7d-median=141, 14d-median=141
- weather: today=112, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: chavez, vasquez, transport, deschambault, local, cabinets, oregon, jules, docks, smith, evans, sociedad
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: announces, permanent, ceasefire, price, normal, continue, hormuz, agreement, resolves, traffic, regime, volume
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: roderick, economists, conversable, recent, laugh, economics, essay, review, https, functions, approaches, admit
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] ECB press: Financial stability vulnerabilities remain elevated as geoeconomic shock unfolds

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*