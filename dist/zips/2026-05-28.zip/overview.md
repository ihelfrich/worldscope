# WORLDSCOPE morning brief — 2026-05-28

## Headline
949 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 21 total
  (no new items today)

### State Legislative Action — 131 new of 131 total
  - (2026-05-27) [Alaska SB 68] An Act relating to employment; relating to voluntary flexible work hour plans; relating to the employment of minors; and relating to hours worked by minors employed in the state.
      An Act relating to employment; relating to voluntary flexible work hour plans; relating to the employment of minors; and relating to hours worked by minors employed in the state.
  - (2026-05-27) [Alaska SB 116] An Act amending campaign contribution limits for state and local office; directing the Alaska Public Offices Commission to adjust campaign contribution limits for state and local office once each decade beginning in 2031; and relating to campaign contribution reporting requirements.
      An Act amending campaign contribution limits for state and local office; directing the Alaska Public Offices Commission to adjust campaign contribution limits for state and local office once each decade beginning in 2031
  - (2026-05-27) [Alaska HB 388] An Act relating to loans made from the bulk fuel loan account; and providing for an effective date.
      An Act relating to loans made from the bulk fuel loan account; and providing for an effective date.
  - (2026-05-27) [Alaska HB 265] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-05-27) [Alaska SB 120] An Act establishing the Alaska Climate Change Emergency Response Commission; and relating to the powers and duties of the Alaska Climate Change Emergency Response Commission.
      An Act establishing the Alaska Climate Change Emergency Response Commission; and relating to the powers and duties of the Alaska Climate Change Emergency Response Commission.
  - (2026-05-27) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an effective date.
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an
  - (2026-05-27) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contributions for public school funding; relating to municipal property 
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut
  - (2026-05-27) [Alaska HB 104] An Act creating and relating to the address confidentiality program; and providing for an effective date.
      An Act creating and relating to the address confidentiality program; and providing for an effective date.

### State-Level News — 24 new of 635 total
  - (2026-05-27) [California] New California law bans law enforcement from interfering in state elections
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 18 new of 232 total
  - (2026-05-28) [St. Louis] Metro East community exploring $20M fieldhouse to boost year-round sports tourism
      “We’re looking for an opportunity to continue the tourism in some of the winter months when a lot of the outdoor activities pack up for the season,” Van Hook said.
  - (2026-05-27) [St. Louis] Deputies in Spokane recover $70,000 stolen metal T-Rex statue buried underground
      The dinosaur, due to its extreme size and weight of about 400 pounds, had to be towed out of the ground by tow trucks.
  - (2026-05-27) [St. Louis] St. Louis police want drones in the sky. The mayor says not so fast
      The St. Louis Board of Police Commissioners approved a drone first responder program Wednesday, but Mayor Cara Spencer and commissioners slammed the rushed process.
  - (2026-05-27) [St. Louis] Ladue weighs its first apartment complex
      Plans submitted to the city show a five-story apartment building with 235 units on the roughly 50-acre Rock Hill Quarries site.
  - (2026-05-27) [St. Louis] These St. Louis area Pizza Huts set to bring back 80s/90s retro vibes
      The red plastic cups, stained-glass lamps, checkerboard tablecloths, arcade games, and red roofs that defined Pizza Hut in the 1980s and 1990s are officially making a comeback in Missouri, with a few locations in the St.
  - (2026-05-27) [St. Louis] Get ready for a summer of political ads in Missouri
      Millions of dollars will be raised and spent on candidates and ballot questions this August alone, like high-dollar campaigns associated with Amendment Five, a proposed constitutional amendment on the state’s income tax.
  - (2026-05-27) [St. Louis] Youth-focused community outreach center coming to Pagedale
      After a decade of dedicated service to the community, Angelic Healthcare Services is breaking ground on a new project. The organization is now developing a site design to provide meals and tutoring opportunities to local
  - (2026-05-28) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss

### International News + Multilateral Institutions — 72 new of 852 total
  - (2026-05-28) [Singapore] Live snakes, dead bears and brain worms: Robert F. Kennedy Jr’s wild animal antics
      <p>Mr Kennedy is  surrounded by controversy over his fringe views that edge into conspiracy theories.</p>
  - (2026-05-28) [Singapore] In Cornyn’s enormous loss, proof of Trump’s hold over GOP base
      <p>Senator John Cornyn of Texas was clobbered by his MAGA-aligned challenger, Mr Ken Paxton.</p>
  - (2026-05-28) [Singapore] US carries out new strikes in Iran against military site, official says
      <p>The site posed a threat to US forces and commercial maritime traffic in the Strait of Hormuz.</p>
  - (2026-05-28) [Singapore] Jill Biden’s reaction to husband Joe’s 2024 debate debacle: ‘He’s having a stroke’
      <p>The disastrous performance ultimately ended his bid for re-election.</p>
  - (2026-05-28) [Singapore] Russia says US did not grant visa for official to attend UN meeting
      <p>A UN diplomat said Iranian Foreign Minister Abbas Araqchi had also apparently been denied a visa.</p>
  - (2026-05-28) [Singapore] US reimposes sanctions on UN expert on Palestinians
      <p>This comes after an appeals court overruled an earlier order prohibiting the action.</p>
  - (2026-05-28) [Singapore] CBS News declined to renew contract for ‘60 Minutes’ correspondent who clashed with top editor
      <p>Ms Sharyn Alfonsi said she continues to be employed at CBS.</p>
  - (2026-05-28) [Global] US returns Palestinian rights expert Francesca Albanese to sanctions list
      Trump administration has sought to pressure international officials who scrutinise reported abuses by Israeli forces.

### Chinese Internal News — 52 new of 259 total
  - (2026-05-26) [TITLE: QDII额度受限 投资海外基金溢价率集体抬升 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5RTVl6SVBibXFzbzh2dFFzR1VnMnpEVmRwR28zMGxDSGtyc3RNUVZld2dQa09YTk1rNGVsMXY1Tjh0UDJHOGpIc2l2YjRzQUZ] (zh: QDII额度受限 投资海外基金溢价率集体抬升 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5RTVl6SVBibXFzbzh2dFFzR1VnMnpEVmRwR28zMGxDSGtyc3RNUVZld2dQa09YTk1rNGVsMXY1Tjh0UDJHOGpIc2l2YjRzQUZZOFFtUzB4UHdkQm9VcnpKLVpn?oc=5" target="_blank">QDII额度受限 投资海外基金
  - (2026-05-27) [TITLE: 父母都哭了，我反问自己，我配得上吗？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5lbVdfaGh2OTlLRHFuSlhiR3VaMGNEUi1jQml6MVI5cW5Ha0puUmR6VGZ3Qm9fUDlOM2FZX2M4M1R2d2tMMl81YWg2akRtUWZ5Nl] (zh: 父母都哭了，我反问自己，我配得上吗？ - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5lbVdfaGh2OTlLRHFuSlhiR3VaMGNEUi1jQml6MVI5cW5Ha0puUmR6VGZ3Qm9fUDlOM2FZX2M4M1R2d2tMMl81YWg2akRtUWZ5NlpUcnpJQ1JGc2Y2R1ZkUFloUjlPUnB6dXc?oc=5" target="_blank">父母都哭
  - (2026-05-28) [TITLE: 《浪姐7》不好看，都怪导演是男性？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE1MVDJuTXN1SnhwUW9GY3FoTVpJQWQ3WEtDRVZVa20zU0hVdXV3Q3lMaGVDLW1BMGtUcU9sS1pkVjBtSUNBbHFUZ0h1Z2hVMU5CWHpx] (zh: 《浪姐7》不好看，都怪导演是男性？ - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE1MVDJuTXN1SnhwUW9GY3FoTVpJQWQ3WEtDRVZVa20zU0hVdXV3Q3lMaGVDLW1BMGtUcU9sS1pkVjBtSUNBbHFUZ0h1Z2hVMU5CWHpxdTN6LUxIcWNwUElqVUhFTjFjZ1hjVHhsV0ZDNU00b0NZ?oc=5" target=
  - (2026-05-27) [TITLE: 德经济部长访华：看好中国创新实力-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9COUtyMk1HZFBjX1hrc1RNRDljbjd0dE4wd3lrelY5RkpqcGFNV0dEdkhJZzhVM2JYZjB6X1FPV1hVYndSRXVmdEthRGpzVkd] (zh: 德经济部长访华：看好中国创新实力-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9COUtyMk1HZFBjX1hrc1RNRDljbjd0dE4wd3lrelY5RkpqcGFNV0dEdkhJZzhVM2JYZjB6X1FPV1hVYndSRXVmdEthRGpzVkdzdkZiSXBYblZTYlhHT1RveUtqM0hyZXB3R3c?oc=5" target="_blank">德经济部
  - (2026-05-27) [TITLE: 世界懵了！伊朗突然披露协议草案，白宫怒拒认账 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE0wM1JlejYyb01FVzNpVFdlZG1yeUNFZ1RjNjlCcVF4RXFoX2pCUnNfd2d1ZWp5SHAwLWZGb1laMzQ5SUtzcnMteUtTVVBPd1l] (zh: 世界懵了！伊朗突然披露协议草案，白宫怒拒认账 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE0wM1JlejYyb01FVzNpVFdlZG1yeUNFZ1RjNjlCcVF4RXFoX2pCUnNfd2d1ZWp5SHAwLWZGb1laMzQ5SUtzcnMteUtTVVBPd1lESTNGbGxVSTRrV3hkTnMzZVBfaGp6blBnd0F6Q0NJQmMtV2lI?oc=5" target=
  - (2026-05-27) [TITLE: 马斯克五月：解散xAI，诉OpenAI，访华，发射星舰…… - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1qSFhTTHZhMDNGdE5lMXRpdUtzcmFYdVJUNnhXYkdLT21YZlZad3hYeUY2LVlfN0VXSWhNeXZJWldoTFNZdlNBUWcy] (zh: 马斯克五月：解散xAI，诉OpenAI，访华，发射星舰…… - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1qSFhTTHZhMDNGdE5lMXRpdUtzcmFYdVJUNnhXYkdLT21YZlZad3hYeUY2LVlfN0VXSWhNeXZJWldoTFNZdlNBUWcyWjFxLVhfcEJkT2w2bXdSY1FNOVJidkYzSkxOQUJyUnc?oc=5" target="_blank">马斯克五
  - (2026-05-27) [TITLE: 西方的人性是我们的兽性，我们的人性是西方的神性 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE16WWVGbjdqOEg2MEpINDVQaUVjUVRiaG94QW0tMXZwdkoxQy0xemdveUpHT2Y5TGc2RnRqYWtseWt1LVRkMmtLN29nZ0VQdH] (zh: 西方的人性是我们的兽性，我们的人性是西方的神性 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE16WWVGbjdqOEg2MEpINDVQaUVjUVRiaG94QW0tMXZwdkoxQy0xemdveUpHT2Y5TGc2RnRqYWtseWt1LVRkMmtLN29nZ0VQdHBRVHNvSzZKUVNQVWc?oc=5" target="_blank">西方的人性是我们的兽性，我们的人性是西方的神性<
  - (2026-05-28) [TITLE: 很多我这样的IT工程师不想找北京的女孩子 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE1UWkVxWVZULW9MUFZUNnJCSzU1UkxVLVMwckZzSHhzLWVySkEyQVRwVXhUUklNelF5MVpNS0hEbjZqdGEwNmRpUDFZUFVVd3NWU] (zh: 很多我这样的IT工程师不想找北京的女孩子 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE1UWkVxWVZULW9MUFZUNnJCSzU1UkxVLVMwckZzSHhzLWVySkEyQVRwVXhUUklNelF5MVpNS0hEbjZqdGEwNmRpUDFZUFVVd3NWUjdRR2pWMjEyT3FKMjRwQ2dfai1YNi15TzVJU0x2TGtvTm1V?oc=5" target=

### Russian Internal News (state + in-exile) — 58 new of 984 total
  - (2026-05-28) [TITLE: ВС России за месяц уничтожили пять пунктов управления БПЛА "Птиц Мадьяра" | LEDE: ] (ru: ВС России за месяц уничтожили пять пунктов управления БПЛА "Птиц Мадьяра")
  - (2026-05-28) [TITLE: Срочная просьба Зеленского к Трампу вызвала шок в Киеве | LEDE: ] (ru: Срочная просьба Зеленского к Трампу вызвала шок в Киеве)
  - (2026-05-28) [TITLE: В Госдуме предупредили о вредоносных файлах под видом "ответов на ЕГЭ" | LEDE: ] (ru: В Госдуме предупредили о вредоносных файлах под видом "ответов на ЕГЭ")
  - (2026-05-28) [TITLE: Раскрыто, как отключить рекламные звонки за одну минуту | LEDE: ] (ru: Раскрыто, как отключить рекламные звонки за одну минуту)
  - (2026-05-28) [TITLE: Омбудсмен ДНР назвала количество детей, погибших от атак ВСУ с 2014 года | LEDE: ] (ru: Омбудсмен ДНР назвала количество детей, погибших от атак ВСУ с 2014 года)
  - (2026-05-28) [TITLE: Раскрыто, во сколько обойдется индивидуальное сопровождение на ПМЭФ-2026 | LEDE: ] (ru: Раскрыто, во сколько обойдется индивидуальное сопровождение на ПМЭФ-2026)
  - (2026-05-28) [TITLE: Военные отражают атаку ВСУ в Севастополе | LEDE: ] (ru: Военные отражают атаку ВСУ в Севастополе)
  - (2026-05-28) [TITLE: СМИ: США уничтожили иранскую установку для запуска БПЛА и четыре дрона | LEDE: ] (ru: СМИ: США уничтожили иранскую установку для запуска БПЛА и четыре дрона)

### Ukrainian Internal News (national + local Kyiv) — 3 new of 111 total
  - (2026-05-28) [TITLE: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби ППО | LEDE: Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.] (uk: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби)
      Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.
  - (2026-05-28) Ukraine to Be Fully Integrated Into EU Air Defense, Drone Priorities, Von der Leyen Says
      European Commission President Ursula von der Leyen said Ukraine will be included in Europe’s urgent defense efforts, backed by a €28.3 billion loan for Kyiv’s military needs.
  - (2026-05-28) Sybiha Calls for Airport or Seaport Truce as First Step Toward Peace
      Foreign Minister Andrii Sybiha said Europe should first push for a limited airport or seaport truce, using sanctions and frozen Russian assets to press Moscow toward practical peace steps.

### Ukraine Theater (total-war monitoring) — 30 new of 398 total
  - (2026-05-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [ISW] Russian Offensive Campaign Assessment, May 26, 2026 - Institute for the Study of War
      <a href="https://news.google.com/rss/articles/CBMipgFBVV95cUxQeVV6UGlFbzhnTGRuWVFsbFVibkZaYWR3a2ZtVWpvdHdSblJ1R29yVEl1SDBmakNoZmZ5cThNd29nXzV2SEp1NkY3dno4cnpIbHVpaEVMVlB4ZFUxOWwya3Frc1IwWm1rY190UHI4NXhQWHlnSDRhR2Z4YTJWTF
  - (2026-05-26) [ISW] Russian Offensive Campaign Assessment, May 25, 2026 - Institute for the Study of War
      <a href="https://news.google.com/rss/articles/CBMipgFBVV95cUxOcXBPcXNKdUNsVWp3ZlBHek5VZ0RfVEFLaWRkLVdLc2htQzJIdWhFRk1CZGNJZVl1TWE5UXNxaWNHby0zRWw1em9OcDlPMktKTU95aTRRb0lIMmgxaERiU1RweXFTU2piemowY1ZEelRkWktTd19DaFBZZmxQUz
  - (2026-05-25) [ISW] Ukraine’s Intermediate-Range Strike Campaign - Institute for the Study of War
      <a href="https://news.google.com/rss/articles/CBMi-wFBVV95cUxNaExOUk9YLW9yd09BS1FCQVIyNjhVMzNyOGxlTmJoSWotQ0xkYjNhRGdLSlA4Z0pWZUZoc1JvZGVveExHYUVFZ2pFM2RCc2lKcFZ2UDlFTzJnYWs1N1hxRWtLRkgzQzRpQnpVcVYzX2YwdlFnNlFzZTQtTEU2OU
  - (2026-05-23) [ISW] Russian Offensive Campaign Assessment, May 23, 2026 - Institute for the Study of War
      <a href="https://news.google.com/rss/articles/CBMipgFBVV95cUxNbEhfV2VNUEJ4R1RfVWZtWG9BUjNXTHpTWlo3My1PaXM2Nml1ZFE4eVhEdWlZeTJMbU43MHNHTmJfeGJtMHFvQ0NjaF9PSG1SeWpuTC1rWkpEOGVSdTBxOUZuWXEzUWI0SzBLcjlMb2tEY0dua20yU3lORzhfYV
  - (2026-05-23) [ISW] Russian Offensive Campaign Assessment, May 22, 2026 - Institute for the Study of War
      <a href="https://news.google.com/rss/articles/CBMipgFBVV95cUxNZ21xOW1rUjg2ZnYybkRSR3AySDZtd2w1RmNVOXVEalJ1Ujl5Y3N4S1c2UkFleEgzaWlZQlBBWWVGVGI4RmdoWmxKWmxwNE5DZkN5aWtJWnNSTEVaLURXTldrdGg1ZW5QSmRNN2FoeVdvaFp2YXNORHQ4SzZDLX
  - (2024-10-18) [UA Ministry of Defence] Reserve+ features a function to search for vacancies in the Defence Forces | MoD News - Міністерство оборони України
      <a href="https://news.google.com/rss/articles/CBMipwFBVV95cUxPVWhvZDZja3dqSkFpLWhiN19RUmxGcXhXWGlYa194T1lTWkUzUHFjWEo4RU5qbENpd0VLSjhSUkVLVlZwNGRNQXNvcHF2OGRNM3RQYVlUSGlLYWhwZW5GcUY2bjZXWWhBSnhpNFlKWkpEang3Vk5ibDVRSjhFZU
  - (2024-11-16) [UA Ministry of Defence] Ukrainian Legion in Poland | MoD News - Міністерство оборони України
      <a href="https://news.google.com/rss/articles/CBMiowFBVV95cUxNUVUxRTQ4MnB6MDlWMV9RNjV5U0xfTHEwOU5BRFZhV25LQmlmOUxBc2xiQldZY25fWHhDSlcxOXQyQUh4cHBqRzNRN3M4LUI2YUhlcDhxOGdXSUhROUpPZ2pNMWdBU3pVMzdEMlBWQUt3eUNpcmRMVTdMRWJZY2

### Paper Trading Scorecard — 1 new of 135 total
  - (2026-05-28) [Manifold] Will "Contra Wentworth on Physical Attractiveness f..." make the top fifty posts in LessWrong's 2026 Annual Review?

### U.S. Weather + Severe / Climate Outlooks — 38 new of 101 total
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 6:22PM MDT by NWS Missoula MT
      At 622 PM MDT, Doppler radar was tracking a strong thunderstorm 11
miles east of Woodside, or 12 miles east of Hamilton, moving
northwest at 20 mph.

HAZARD...Wind gusts up to 40 mph and penny size hail.

SOURCE...Radar 
  - (2026-05-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 5:20PM PDT by NWS San Francisco CA
      At 520 PM PDT, Doppler radar was tracking a strong thunderstorm near
Los Gatos, moving southeast at 10 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IMPACT...Gusty winds could knoc
  - (2026-05-27) [Severe] Special Marine Warning: Special Marine Warning issued May 27 at 8:18PM EDT until May 27 at 9:45PM EDT by NWS Baltimore MD/Washington DC
      SMWLWX

The National Weather Service in Sterling Virginia has issued a

* Special Marine Warning for...
Tidal Potomac from Indian Head to Cobb Island MD...
Tidal Potomac from Key Bridge to Indian Head MD...

* Until 945 
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 8:17PM EDT by NWS Jacksonville FL
      At 817 PM EDT, Doppler radar was tracking a strong thunderstorm near
Bryceville, or 19 miles north of Middleburg, moving north at 15 mph.

HAZARD...Wind gusts around 40 mph.

SOURCE...Radar indicated.

IMPACT...Gusty win
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 7:16PM CDT until May 27 at 7:30PM CDT by NWS Milwaukee/Sullivan WI
      At 715 PM CDT, severe thunderstorms were located along a line
extending from 6 miles northeast of Mauston to 8 miles southwest of
Westfield to near Montello, moving southeast at 35 mph.

HAZARD...Ping pong ball size hail
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 8:16PM EDT until May 27 at 9:00PM EDT by NWS Wakefield VA
      SVRAKQ

The National Weather Service in Wakefield has issued a

* Severe Thunderstorm Warning for...
Southwestern Cumberland County in central Virginia...
Prince Edward County in central Virginia...
Northwestern Lunenbur
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 5:13PM PDT until May 27 at 5:45PM PDT by NWS Medford OR
      SVRMFR

The National Weather Service in Medford has issued a

* Severe Thunderstorm Warning for...
Southwestern Klamath County in south central Oregon...

* Until 545 PM PDT.

* At 512 PM PDT, severe thunderstorms were l

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 93 total
  - (2026-05-28) [USASpending] $534,079,951 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
      Agency: General Services Administration.  Description: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
  - (2026-05-28) [USASpending] $486,224,471 → LOCKHEED MARTIN CORPORATION: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTR
      Agency: National Aeronautics and Space Administration.  Description: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTRUMENT THE FOR GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) R.  THE CONTRACTOR 
  - (2026-05-28) [USASpending] $432,416,292 → LEIDOS BIOMEDICAL RESEARCH INC: NCI OPERATIONAL TASK ORDER
      Agency: Department of Health and Human Services.  Description: NCI OPERATIONAL TASK ORDER
  - (2026-05-28) [USASpending] $406,089,353 → AERODYNE-SGT ENGINEERING SERVICES, LLC: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEER
      Agency: National Aeronautics and Space Administration.  Description: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEERING TASK ORDERS FOR THE FORMULATION, DESIGN, DEVELOPMENT, FABRICATION, INTEGRATION, TESTING
  - (2026-05-28) [USASpending] $405,028,920 → VERIZON BUSINESS NETWORK SERVICES LLC: CENTRALIZED HHS EIS REQUIREMENT
      Agency: Department of Health and Human Services.  Description: CENTRALIZED HHS EIS REQUIREMENT
  - (2026-05-28) [USASpending] $402,848,838 → GUIDEHOUSE INC.: THE PURPOSE OF THIS REQUIREMENT FOR GRANTS PROGRAM SOLUTIONS
      Agency: Department of the Interior.  Description: THE PURPOSE OF THIS REQUIREMENT FOR GRANTS PROGRAM SOLUTIONS AND IT SUPPORT SERVICES IS TO PROVIDE EFFICIENT AND EFFECTIVE GRANT, FINANCIAL, AND CONTRACT MANAGEMENT SERVI
  - (2026-05-28) [USASpending] $400,000,000 → WHITING-TURNER CONTRACTING COMPANY, THE: ACCELERATED DESIGN-BUILD TO BUDGET CONSTRUCT BARRACKS, MULTI
      Agency: Department of Homeland Security.  Description: ACCELERATED DESIGN-BUILD TO BUDGET CONSTRUCT BARRACKS, MULTI-USE TRAINING FACILITY, GALLEY & FIREHOUSE AT USCG TRACEN CAPE MAY, CAPE MAY, NJ
  - (2026-05-28) [USASpending] $384,632,648 → SOUTHWEST RESEARCH INSTITUTE: TAS::80 0120::TAS AS THE PRINCIPAL INVESTIGATOR (PI) INSTITU
      Agency: National Aeronautics and Space Administration.  Description: TAS::80 0120::TAS AS THE PRINCIPAL INVESTIGATOR (PI) INSTITUTION FOR THE MAGNETOSPHERIC MULTISCALE  (MMS) INSTRUMENT SUITE SCIENCE TEAM (ISST), THE CON

### Congressional STOCK Act Trades (House + Senate) — 53 new of 53 total
  - (2026-05-06) [Senate] Bernardo Moreno (R): Sale (Full) ETOR ($100,001 - $250,000) (excess -1.0% vs SPY)
      Member: Bernardo Moreno (R, senate).  BioGuide: M001242.  Asset: ETOR (Stock).  Type: Sale (Full).  Amount range: $100,001 - $250,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-22.  Excess return vs SPY si
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +0.9% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +0.9% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-04-29) [House] Thomas H. Kean Jr (R): Sale ADI ($1,001 - $15,000) (excess +0.3% vs SPY)
      Member: Thomas H. Kean Jr (R, house).  BioGuide: K000398.  Asset: ADI (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-04-29.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-07) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +9.5% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-06) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +15.6% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Tim Moore (R): Purchase T ($15,001 - $50,000) (excess +1.0% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: T (ST).  Type: Purchase.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure: +0
  - (2026-05-07) [House] Tim Moore (R): Purchase RYCEY ($1,001 - $15,000) (excess +0.2% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: RYCEY (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure:

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-28) [Tanner Kirk] Form 4 (Reporting)
      filed 2026-05-28 00:22 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0000103379-26-000053 Size: 4 KB
  - (2026-05-28) [V F CORP] Form 4 (Issuer)
      filed 2026-05-28 00:22 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0000103379-26-000053 Size: 4 KB
  - (2026-05-28) [Shah Rutul R] Form 4 (Reporting)
      filed 2026-05-28 00:21 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0000950103-26-007843 Size: 7 KB
  - (2026-05-28) [PRECIGEN, INC.] Form 4 (Issuer)
      filed 2026-05-28 00:21 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0000950103-26-007843 Size: 7 KB
  - (2026-05-28) [Sabzevari Helen] Form 4 (Reporting)
      filed 2026-05-28 00:18 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0000950103-26-007842 Size: 7 KB
  - (2026-05-28) [PRECIGEN, INC.] Form 4 (Issuer)
      filed 2026-05-28 00:18 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0000950103-26-007842 Size: 7 KB
  - (2026-05-28) [Lehr Donald P.] Form 4 (Reporting)
      filed 2026-05-28 00:15 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0000950103-26-007841 Size: 7 KB
  - (2026-05-28) [PRECIGEN, INC.] Form 4 (Issuer)
      filed 2026-05-28 00:15 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0000950103-26-007841 Size: 7 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 27 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-28) [United States] ACS adds blood test to colon , rectal cancer screening recommendations
      domain: wlky.com · language: English · tone: 
  - (2026-05-28) [United States] Judge sets bond at $1M for suspect in deadly Shively bus stop crash
      domain: wlky.com · language: English · tone: 
  - (2026-05-28) [Bermuda] De Couto On Tax , Insurance Companies , More
      domain: bernews.com · language: English · tone: 
  - (2026-05-28) [United States] Is Texas in play ? How Paxton win could shape the fight for Senate control
      domain: wvtm13.com · language: English · tone: 
  - (2026-05-28) [United States] Pope Leo issues new appeal for peace in Ukraine | News Headlines
      domain: catholicculture.org · language: English · tone: 
  - (2026-05-28) [United States] Former Republican strategist Collin Corbett files to run for Illinois governor as independent
      domain: wifr.com · language: English · tone: 
  - (2026-05-28) [United States] NASA just ordered moon buggies and drones for a lunar base here the timeline
      domain: king5.com · language: English · tone: 
  - (2026-05-28) [Canada] After protests outside synagogues , New York makes it a crime to block entry to a house of worship – Winnipeg Free Press
      domain: winnipegfreepress.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-05-28) PAT087 (United States)
      icao24: adfedd · position: (21.1869, -157.4118) · alt: 6393m · 453km/h
  - (2026-05-28) PAT326 (United States)
      on ground
  - (2026-05-28) EAGLE1 (United States)
      icao24: a8695d · position: (34.0897, -117.4821) · alt: 624m · 176km/h
  - (2026-05-28) GAF197 (Germany)
      icao24: 3f7588 · position: (52.6024, 10.0993) · alt: 220m · 260km/h
  - (2026-05-28) NCR327 (United States)
      icao24: ab4ec6 · position: (32.1411, -81.4334) · alt: 1165m · 388km/h
  - (2026-05-28) CFC4042 (Canada)
      icao24: c2b3f5 · position: (44.0036, -82.4801) · alt: 11277m · 923km/h
  - (2026-05-28) RCH808 (United States)
      icao24: ae07d7 · position: (39.1937, -74.3124) · alt: 5242m · 839km/h
  - (2026-05-28) NCR711 (United States)
      icao24: aabbef · position: (41.1345, -111.6747) · alt: 12496m · 797km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 16 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 3 new of 20 total
  - (2026-05-28) Chicago Cubs vs. Pittsburgh Pirates
      yes price: 62% · 24h volume: $799,812 · resolves 2026-06-03
  - (2026-05-28) US announces new Iran agreement/ceasefire extension by May 31?
      yes price: 24% · 24h volume: $768,825
  - (2026-05-28) Will Switzerland win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $731,411 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 0 new of 6 total
  (no new items today)

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25; carrying terms: amendment, event, provide, airplanes, applicable, final, establishing, established, zones, required, marine, enforcement
- state_bills: today=131, 7d-median=131, 14d-median=131
- state_news: today=635, 7d-median=722, 14d-median=722
- local_news: today=232, 7d-median=265, 14d-median=265
- foreign_news: today=852, 7d-median=906, 14d-median=906
- chinese_internal: today=259, 7d-median=289, 14d-median=289
- russian_internal: today=984, 7d-median=1021, 14d-median=1021
- ukrainian_internal: today=111, 7d-median=138, 14d-median=138
- ukraine_theater: today=398, 7d-median=398, 14d-median=398
- paper_bets: today=135, 7d-median=136, 14d-median=136
- weather: today=101, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=93, 7d-median=95, 14d-median=95
- congressional_trades: today=53, 7d-median=53, 14d-median=53
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: concepcion, montgomery, trustees, crespo, morales, blanche, internal, ortiz, caribe, patton, bondi, kenneth
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: cancer, language, english, canada, kingdom, domain
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=19, 14d-median=19
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: iranian, bitcoin, regime, ceasefire, agreement, extension, permanent, resolves, peace, continue, strait, world
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: essay, production, jisang, laugh, approaches, story, rejesus, stuff, https, conversable, economist, seminars
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*