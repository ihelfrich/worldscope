# WORLDSCOPE morning brief — 2026-05-28

## Headline
1738 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 21 total
  (no new items today)

### State Legislative Action — 136 new of 136 total
  - (2026-05-28) [Alaska SB 2] An Act relating to disclosure of election-related deepfakes; relating to use of artificial intelligence by state agencies; and relating to transfer of data about individuals between state agencies.
      An Act relating to disclosure of election-related deepfakes; relating to use of artificial intelligence by state agencies; and relating to transfer of data about individuals between state agencies.
  - (2026-05-28) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contributions for public school funding; relating to municipal property 
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut
  - (2026-05-28) [Alaska HB 17] An Act relating to retirement benefits and military service.
      An Act relating to retirement benefits and military service.
  - (2026-05-28) [Alaska HB 121] An Act relating to the practice of accounting; relating to private professional conservators; amending Rule 17(e), Alaska Rules of Probate Procedure; and providing for an effective date.
      An Act relating to the practice of accounting; relating to private professional conservators; amending Rule 17(e), Alaska Rules of Probate Procedure; and providing for an effective date.
  - (2026-05-28) [Alaska HCR 6] Commemorating the 250th birthday of the United States Marine Corps.
      Commemorating the 250th birthday of the United States Marine Corps.
  - (2026-05-28) [Alaska SB 33] An Act relating to defamation claims based on the use of synthetic media; relating to the use of synthetic media in electioneering communications; and providing for an effective date.
      An Act relating to defamation claims based on the use of synthetic media; relating to the use of synthetic media in electioneering communications; and providing for an effective date.
  - (2026-05-28) [Alaska HB 381] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of revenue from the alternative volumetric tax; and providing for an 
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re
  - (2026-05-28) [Alaska HJR 13] Urging the President of the United States to expand evacuation efforts for applicants with approved Special Immigrant Visas, including resumption of evacuation flights organized by the Coordinator for Afghan Relocation Efforts; urging the United States Department of State to secure l
      Urging the President of the United States to expand evacuation efforts for applicants with approved Special Immigrant Visas, including resumption of evacuation flights organized by the Coordinator for Afghan Relocation E

### State-Level News — 38 new of 642 total
  - (2026-05-27) [California] New California law bans law enforcement from interfering in state elections
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 103 new of 245 total
  - (2026-05-27) [St. Louis] These St. Louis area Pizza Huts set to bring back 80s/90s retro vibes
      The red plastic cups, stained-glass lamps, checkerboard tablecloths, arcade games, and red roofs that defined Pizza Hut in the 1980s and 1990s are officially making a comeback in Missouri, with a few locations in the St.
  - (2026-05-28) [St. Louis] St. Louis Police Board approves 'drone as first responder' plan
      A proposal for new police drones in St. Louis was debated and passed by the Police Board on Wednesday, despite opposition from St. Louis Mayor Cara Spencer. The plan authorizes Police Chief Robert Tracy to move forward w
  - (2026-05-28) [St. Louis] List: Route 66 Anniversary Events in the St. Louis area
      As Route 66 approaches its 100th anniversary this year, communities across the St. Louis area are gearing up to celebrate the "Mother Road" with festivals, concerts, museum exhibits, and roadside attractions. Whether you
  - (2026-05-28) [St. Louis] Shooting in north St. Louis leaves woman in critical condition
      A woman was critically injured in a shooting Wednesday evening in north St. Louis.
  - (2026-05-27) [St. Louis] Get ready for a summer of political ads in Missouri
      Millions of dollars will be raised and spent on candidates and ballot questions this August alone, like high-dollar campaigns associated with Amendment Five, a proposed constitutional amendment on the state’s income tax.
  - (2026-05-27) [St. Louis] Youth-focused community outreach center coming to Pagedale
      After a decade of dedicated service to the community, Angelic Healthcare Services is breaking ground on a new project. The organization is now developing a site design to provide meals and tutoring opportunities to local
  - (2026-05-27) [St. Louis] Shavkat Rakhmonov
      Shavkat Rakhmonov
  - (2026-05-27) [St. Louis] Belleville West vs. Belleville East
      A squirrel stands on the on-deck circle during a Class 4A Belleville East baseball regional semifinal game on Wednesday, May 27, 2026, at Belleville East High School in Belleville, Ill.

### International News + Multilateral Institutions — 213 new of 876 total
  - (2026-05-28) [Global] Google employee charged with insider trading over Polymarket bets
      Michele Spagnuolo allegedly used insider information to profit from bets on people on Google&#039;s most-searched list.
  - (2026-05-28) [Global] Aid cuts and climate change drive deadly malaria surge in Zimbabwe
      A surge in malaria cases in Zimbabwe is exposing fragile health systems and growing treatment shortages in rural areas.
  - (2026-05-28) [Global] Parisians defy swimming ban to cool off as record heat hits Europe
      Parisians cooled off in the city’s Saint-Martin canal as an unprecedented heatwave pushed temperatures across Europe.
  - (2026-05-28) [Global] Uganda closes border with DRC in an effort to contain Ebola outbreak
      Uganda has closed its border with neighbouring DR Congo for four weeks in an effort to contain an Ebola outbreak.
  - (2026-05-28) [Global] US returns Palestinian rights expert Francesca Albanese to sanctions list
      Trump administration has sought to pressure international officials who scrutinise reported abuses by Israeli forces.
  - (2026-05-28) [Global] Iran war live: US strikes Iranian site as tensions rise in Strait of Hormuz
      The Lebanese Health Ministry reports that Israeli attacks have killed 3,269 people since March 2.
  - (2026-05-27) [Global] Jill Biden worried husband Joe was ‘having a stroke’ during 2024 US debate
      The former US first lady said she had never seen former President Joe Biden act the way he did on the 2024 debate stage.
  - (2026-05-27) [Global] Bolivia’s president warns ‘time is running out’ amid protest crisis
      Bolivia’s president has warned protesters “time is running out” amid a weeks-long standoff.

### Chinese Internal News — 243 new of 262 total
  - (2026-05-27) [TITLE: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxOVEZhX19PQWdIQmE5RFNfcGZaVFdoYUNLQkQ3NDhibjVyS2g0VTU3RlNGRHEwa2FReU1CMEJTck9LazRiMThZT] (zh: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报)
      <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxOVEZhX19PQWdIQmE5RFNfcGZaVFdoYUNLQkQ3NDhibjVyS2g0VTU3RlNGRHEwa2FReU1CMEJTck9LazRiMThZTllLWjVlNGQ2VjZrMEN5Mi1XMEVFM1RLQjF6Q1o2Vkh3aHNIYVhsWDVaSXZZQm9Dd1dsQ0ZlaU
  - (2026-05-26) [TITLE: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxNbVd3eEF4eWdWdHNJMWM0akJ5Z2xpMU5vc3NvbW5wbUJNekVFZ1hnak5lWFRLMGRFRXI3c0IzVTNpWjMwc0l1c] (zh: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报)
      <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxNbVd3eEF4eWdWdHNJMWM0akJ5Z2xpMU5vc3NvbW5wbUJNekVFZ1hnak5lWFRLMGRFRXI3c0IzVTNpWjMwc0l1cWVyS0NVckx4QVowZFpFeVRtU01FdlNqR2xUMEV1N3J5VEVUNVlNd21kazdEQkpURUpWQmJUUE
  - (2026-05-26) [TITLE: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxQbW40MlpHRlFXQXZQeE1YODFDSzU4VF80Y2wyUkFxMzlqRG1IeVRCbUxpd19jbzlCUVpQVlV3bDNTbXpDUkNkc] (zh: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报)
      <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxQbW40MlpHRlFXQXZQeE1YODFDSzU4VF80Y2wyUkFxMzlqRG1IeVRCbUxpd19jbzlCUVpQVlV3bDNTbXpDUkNkcVJIWThyZ1J5Y0h6WlczWjMtY25NUGRrWWNDX1VoSDFjc1U4Vlk1RmRyX05BNC1jOXhXT1hXTk
  - (2026-05-28) [TITLE: 新工业革命伙伴城市网络正式启动运作 - 人民网-福建频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5fMkt3MXJTbHo5emkta0VsNGVFTlYxUUM1QkRmREFnYjhZdmxaNElxakxOay1rTXNWb0FpY1Z4N0dlV1VqWWJfUFZ3UHVqTU] (zh: 新工业革命伙伴城市网络正式启动运作 - 人民网-福建频道)
      <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5fMkt3MXJTbHo5emkta0VsNGVFTlYxUUM1QkRmREFnYjhZdmxaNElxakxOay1rTXNWb0FpY1Z4N0dlV1VqWWJfUFZ3UHVqTUpjRkZFRWdWSjRfbnVvWTlrMU8yYkZRV0VWSm40YnJXMA?oc=5" target="_blan
  - (2026-05-28) [TITLE: 芒果的新品种，集中品鉴 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE40TnhtbGthOXpuQVR0NDE1cGZNaUtZQVFqb190RVVfODV6QnpSYV9tRnJHb3p1UkFkc3Mtcm5MVS01TTJ4Um85cUEtWDlMWjVDbHBqQjg] (zh: 芒果的新品种，集中品鉴 - 人民网健康)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE40TnhtbGthOXpuQVR0NDE1cGZNaUtZQVFqb190RVVfODV6QnpSYV9tRnJHb3p1UkFkc3Mtcm5MVS01TTJ4Um85cUEtWDlMWjVDbHBqQjgtQ3k2RHhnb2dKOG9hVlh3Nm9PM2FNOUNn?oc=5" target="_blank"
  - (2026-05-28) [TITLE: 社区老人有了5元专属理发师 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE5BUmZIQ0VXYURLQ3VjYVEtc3BVYzB2cE5mbXRlWm1BNHdkU3A0V3ZjVHRSNjVfZm5FNTJFdjZOSTNlR3pKSm1iV2stN1k2UDdIWDM4a] (zh: 社区老人有了5元专属理发师 - 人民网健康)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE5BUmZIQ0VXYURLQ3VjYVEtc3BVYzB2cE5mbXRlWm1BNHdkU3A0V3ZjVHRSNjVfZm5FNTJFdjZOSTNlR3pKSm1iV2stN1k2UDdIWDM4aUhqRmlhVFZpZmRIV1IxaVFaR2d1amdiUlBB?oc=5" target="_blank"
  - (2026-05-28) [TITLE: 西瓜的老谣言，别再轻信 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9KckZWQktUckNqendNamFqSzVrTUd2dDZzUS1BaXdSNU1NcGlPTXBaSUdnN0hXcTFPMEk2d001VjJ0LTNNcFBSODRyejhyQVFWMmhMNFh] (zh: 西瓜的老谣言，别再轻信 - 人民网健康)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9KckZWQktUckNqendNamFqSzVrTUd2dDZzUS1BaXdSNU1NcGlPTXBaSUdnN0hXcTFPMEk2d001VjJ0LTNNcFBSODRyejhyQVFWMmhMNFhGR0RldzVuRkVwTzVBYW9GTlZlSmlwWV9B?oc=5" target="_blank"
  - (2026-05-28) [TITLE: 四川乐山沐川县：打造“沐源尚品”区域公用品牌 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1ZeXR5U1BGTXJfMGlkUk9JTnpCOEhGNkNUTEdwUUJaVG5ENDFTZmVMMHBTcnhyNUgwN0wzZU82aGdLTGpxOFhQb1pjenFR] (zh: 四川乐山沐川县：打造“沐源尚品”区域公用品牌 - 人民网健康)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1ZeXR5U1BGTXJfMGlkUk9JTnpCOEhGNkNUTEdwUUJaVG5ENDFTZmVMMHBTcnhyNUgwN0wzZU82aGdLTGpxOFhQb1pjenFRR2FvUDNTNG5ILVp3a3NLRHVyYktaUWZfc1ZRb09aZkFR?oc=5" target="_blank"

### Russian Internal News (state + in-exile) — 201 new of 991 total
  - (2026-05-28) [TITLE: Европейскую гуманитарную помощь Украине не ели даже коты | LEDE: ] (ru: Европейскую гуманитарную помощь Украине не ели даже коты)
  - (2026-05-28) [TITLE: "Его уберут": во Франции выступили с предупреждением по поводу Зеленского | LEDE: ] (ru: "Его уберут": во Франции выступили с предупреждением по поводу Зеленского)
  - (2026-05-28) [TITLE: В аэропорту Ульяновска ввели ограничения на полеты | LEDE: ] (ru: В аэропорту Ульяновска ввели ограничения на полеты)
  - (2026-05-28) [TITLE: Бундесверу очень далеко до статуса первой армии Европы, считает политик | LEDE: ] (ru: Бундесверу очень далеко до статуса первой армии Европы, считает политик)
  - (2026-05-28) [TITLE: Источник: представители Mitsubishi могли войти в состав делегации Японии | LEDE: ] (ru: Источник: представители Mitsubishi могли войти в состав делегации Японии)
  - (2026-05-28) [TITLE: ВСУ создали систему укрепрайонов в Воздвижевке, рассказал боец | LEDE: ] (ru: ВСУ создали систему укрепрайонов в Воздвижевке, рассказал боец)
  - (2026-05-28) [TITLE: В Минздраве рассказали, как вовремя распознать предиабет | LEDE: ] (ru: В Минздраве рассказали, как вовремя распознать предиабет)
  - (2026-05-28) [TITLE: Боец рассказал об освобождении Воздвижевки | LEDE: ] (ru: Боец рассказал об освобождении Воздвижевки)

### Ukrainian Internal News (national + local Kyiv) — 8 new of 112 total
  - (2026-05-28) [TITLE: Ціна підпілля. Що чекає на учасників руху опору окупації в тюрмі та на волі | LEDE: Жодна людина – не острів, сама по собі; кожен з нас – частина континенту... Смерть кожної людини зменшує і ме] (uk: Ціна підпілля. Що чекає на учасників руху опору окупації в тюрмі та на волі)
      Жодна людина – не острів, сама по собі; кожен з нас – частина континенту... Смерть кожної людини зменшує і мене, бо я єдиний з усім людством; а тому ніколи не питай, по кому дзвонить дзвін: він дзвонить і по тобі.
  - (2026-05-28) [TITLE: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані | LEDE: Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.] (uk: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані)
      Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.
  - (2026-05-28) [TITLE: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ | LEDE: Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.] (uk: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ)
      Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.
  - (2026-05-28) [TITLE: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ | LEDE: За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.] (uk: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ)
      За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.
  - (2026-05-28) [TITLE: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби ППО | LEDE: Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.] (uk: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби)
      Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.
  - (2026-05-28) Trump Endorses Pashinyan Ahead of Crucial Armenia Vote
      US President Donald Trump endorsed Armenian Prime Minister Nikol Pashinyan ahead of a key parliamentary election, praising his peace agenda and plans for the US-backed “Trump Route” corridor. The endorsement came a day a
  - (2026-05-28) Ukraine to Be Fully Integrated Into EU Air Defense, Drone Priorities, Von der Leyen Says
      European Commission President Ursula von der Leyen said Ukraine will be included in Europe’s urgent defense efforts, backed by a €28.3 billion loan for Kyiv’s military needs.
  - (2026-05-28) Sybiha Calls for Airport or Seaport Truce as First Step Toward Peace
      Foreign Minister Andrii Sybiha said Europe should first push for a limited airport or seaport truce, using sanctions and frozen Russian assets to press Moscow toward practical peace steps.

### Ukraine Theater (total-war monitoring) — 267 new of 441 total
  - (2026-05-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [FIRMS] thermal anomaly 47.174, 31.756 (FRP 0.47 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.47 MW
  - (2026-05-27) [FIRMS] thermal anomaly 46.684, 32.687 (FRP 1.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 1.38 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.374, 30.926 (FRP 1.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 1.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.259, 31.673 (FRP 9.83 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 9.83 MW
  - (2026-05-27) [FIRMS] thermal anomaly 44.772, 33.858 (FRP 0.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 44.772, 33.863 (FRP 0.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.953, 22.869 (FRP 0.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.41 MW

### Paper Trading Scorecard — 4 new of 137 total
  - (2026-05-28) [Polymarket] Will Club Bolívar win on 2026-05-27?
      In the upcoming game, scheduled for May 27, 2026
If Club Bolívar wins, this market will resolve to "Yes".
Otherwise, this market will resolve to "No".
If the game is postponed, this market will remain open until the game
  - (2026-05-28) [Polymarket] LoL: Supernova vs Winthrop University (BO5) - North American Challengers League Playoffs
      This market refers to the LoL Lower bracket quarterfinal match between Supernova and Winthrop University in the North American Challengers League Playoffs, initially scheduled for May 27 at 4:00PM ET.

This market will r
  - (2026-05-28) [Polymarket] Will there be between 10 and 20 average daily transits of the Strait of Hormuz on May 31?
      This market will resolve according to the 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for May 31, 2026.

If the reported value falls exactly between two
  - (2026-05-28) [Manifold] Will "Contra Wentworth on Physical Attractiveness f..." make the top fifty posts in LessWrong's 2026 Annual Review?

### U.S. Weather + Severe / Climate Outlooks — 58 new of 103 total
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 11:02PM EDT until May 28 at 8:00PM EDT by NWS Grand Rapids MI
      * WHAT...High wave action, strong currents, and dangerous
swimming conditions expected. Piers may be heavily swamped by
waves.

* WHERE...Mason, Oceana, Muskegon, Ottawa, Allegan and Van Buren
counties.

* WHEN...Through
  - (2026-05-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 11:00PM EDT until May 28 at 8:00PM EDT by NWS Northern Indiana
      * WHAT...Waves will quickly build from 1 to 2 feet tonight to 3 to
4 feet Thursday. The highest waves will be in southern Berrien
County. Dangerous swimming conditions are expected with north-
northeast winds creating st
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 11:00PM EDT until May 29 at 2:00AM EDT by NWS Northern Indiana
      * WHAT...Waves will quickly build from 1 to 2 feet tonight to 3 to
4 feet Thursday. Dangerous swimming conditions are expected with
north-northeast winds creating strong a southward flowing
longshore current and strong s
  - (2026-05-27) [Severe] Red Flag Warning: Red Flag Warning issued May 27 at 9:58PM CDT until May 28 at 10:00PM CDT by NWS Bismarck ND
      ...RED FLAG WARNING FOR FAR WESTERN NORTH DAKOTA ON THURSDAY...

.Critical fire weather conditions will return to far western
North Dakota Thursday afternoon and evening. High temperatures
will climb into the lower to mi
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 9:55PM CDT until May 27 at 10:30PM CDT by NWS Norman OK
      At 954 PM CDT, a severe thunderstorm was located over Truscott,
moving southeast at 25 mph.

HAZARD...Ping pong ball size hail and 60 mph wind gusts.

SOURCE...Radar indicated.

IMPACT...People and animals outdoors will 
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 7:55PM PDT until May 29 at 2:00AM PDT by NWS Medford OR
      * WHAT...A moderate risk for sneaker waves is expected.

* WHERE...The beaches of Douglas, Coos, and Curry counties.

* WHEN...From 5 PM PDT this afternoon through late Thursday
night.

* IMPACTS...Sneaker waves can run 
  - (2026-05-27) [Moderate] Hazardous Seas Warning: Hazardous Seas Warning issued May 27 at 7:54PM PDT until May 28 at 11:00AM PDT by NWS Medford OR
      * WHAT...North winds 20 to 30 kt with gusts up to 40 kt. A brief
period of northerly gales, 30 to 35 kt with gusts to 45 kt, is
possible south of Gold Beach this afternoon. Steep to very
steep and hazardous seas 9 to 13 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 20 new of 95 total
  - (2026-05-27) [OFAC] International Criminal Court-related Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoYmsxWDE3WFh2VzgyWDZ2Y2xnSVJHZzFTTnUtUlM5Z0tOMktfbXRkUmJhMmdHa2wwM19JRnhiWkwxdENoT0owTkx0cEU0ZmdIUk5CVGFjZ2cxbDJOS2c?oc=5" target="_blank">International Crimin
  - (2026-05-28) [OFAC] Iran-related Designation; Counter Terrorism Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1wZHZVOFR1Yy1MSzRFaERsQlZWWmFCSV9fcUQ5eFpEWVdtV3N2dFFZdFlqWG9ldkNFNTBGdjRBSHVrdTlwNmhRT2xndXotaHlyakdWdXpvS2Fkek5QY0UwWG9B?oc=5" target="_blank">Iran-related De
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-28) [USASpending] $534,079,951 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
      Agency: General Services Administration.  Description: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
  - (2026-05-28) [USASpending] $486,224,471 → LOCKHEED MARTIN CORPORATION: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTR
      Agency: National Aeronautics and Space Administration.  Description: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTRUMENT THE FOR GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) R.  THE CONTRACTOR 
  - (2026-05-28) [USASpending] $432,416,292 → LEIDOS BIOMEDICAL RESEARCH INC: NCI OPERATIONAL TASK ORDER
      Agency: Department of Health and Human Services.  Description: NCI OPERATIONAL TASK ORDER
  - (2026-05-28) [USASpending] $406,089,353 → AERODYNE-SGT ENGINEERING SERVICES, LLC: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEER
      Agency: National Aeronautics and Space Administration.  Description: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEERING TASK ORDERS FOR THE FORMULATION, DESIGN, DEVELOPMENT, FABRICATION, INTEGRATION, TESTING
  - (2026-05-28) [USASpending] $405,028,920 → VERIZON BUSINESS NETWORK SERVICES LLC: CENTRALIZED HHS EIS REQUIREMENT
      Agency: Department of Health and Human Services.  Description: CENTRALIZED HHS EIS REQUIREMENT

### Congressional STOCK Act Trades (House + Senate) — 0 new of 1 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-28) [WHEELER SIMON] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [RAWLINGS DARRYL] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:55 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Ollet John] Form 4 (Reporting)
      filed 2026-05-28 01:55 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Lerman Michael Stuart] Form 4 (Reporting)
      filed 2026-05-28 01:53 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:53 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 27 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-28) [United States] AP News Summary at 9 : 48 p . m . EDT
      domain: woonsocketcall.com · language: English · tone: 
  - (2026-05-28) [Canada] Loved ones remember little Sudbury girl as joyful  spitfire  
      domain: timminspress.com · language: English · tone: 
  - (2026-05-28) [United States] Cincinnati man discovers he earned his diploma decades ago
      domain: wcpo.com · language: English · tone: 
  - (2026-05-28) [United Kingdom] United Christian Broadcasters | Christian Media Charity
      domain: ucb.co.uk · language: English · tone: 
  - (2026-05-28) [United States] National News - Glenora Radio Network - WWSE | WJTN | WHUG | WKSN | WQFX
      domain: wjtn.com · language: English · tone: 
  - (2026-05-28) [Malaysia] US carries out new strikes in Iran against military site
      domain: freemalaysiatoday.com · language: English · tone: 
  - (2026-05-28) [Singapore] US strikes Iran again , official says , after Trump denies deal on Strait of Hormuz
      domain: businesstimes.com.sg · language: English · tone: 
  - (2026-05-28) [United States] Red Sox stop Braves on five hits , end five - game slump
      domain: pressherald.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 8 new of 8 total
  - (2026-05-28) EAGLE1 (United States)
      icao24: a8695d · position: (34.1259, -117.3419) · alt: 579m · 182km/h
  - (2026-05-28) CFC2558 (Canada)
      on ground
  - (2026-05-28) NCR9537 (United States)
      icao24: a6caa1 · position: (24.4545, 120.6882) · alt: 12496m · 881km/h
  - (2026-05-28) RCH437 (United States)
      icao24: ae2fa8 · position: (49.5835, 7.0339) · alt: 2125m · 547km/h
  - (2026-05-28) SAM397 (United States)
      icao24: ae6cf1 · position: (42.2395, -71.1408) · alt: 9136m · 714km/h
  - (2026-05-28) CFCBA (Canada)
      icao24: c00563 · position: (47.2476, -94.686) · alt: 13716m · 793km/h
  - (2026-05-28) AF16 (China)
      on ground · 37km/h
  - (2026-05-28) PAT141 (United States)
      on ground

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 16 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 4 new of 20 total
  - (2026-05-28) US announces new Iran agreement/ceasefire extension by May 31?
      yes price: 20% · 24h volume: $764,038
  - (2026-05-28) Houston Astros vs. Texas Rangers
      yes price: 100% · 24h volume: $759,409 · resolves 2026-06-04
  - (2026-05-28) Thunder vs. Spurs
      yes price: 40% · 24h volume: $737,243 · resolves 2026-05-29
  - (2026-05-28) Will Germany win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $719,491 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 0 new of 6 total
  (no new items today)

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25; carrying terms: order, actions, program, interim, projects, relevant, issued, establishing, established, hazards, repetitive, being
- state_bills: today=136, 7d-median=136, 14d-median=136
- state_news: today=642, 7d-median=722, 14d-median=722
- local_news: today=245, 7d-median=265, 14d-median=265
- foreign_news: today=876, 7d-median=906, 14d-median=906
- chinese_internal: today=262, 7d-median=289, 14d-median=289
- russian_internal: today=991, 7d-median=1021, 14d-median=1021
- ukrainian_internal: today=112, 7d-median=138, 14d-median=138
- ukraine_theater: today=441, 7d-median=441, 14d-median=441
- paper_bets: today=137, 7d-median=137, 14d-median=137
- weather: today=103, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: mcpherson, patton, trustees, brunenkant, metropolitana, veterans, salud, delgado, balazs, affairs, properties, pimental
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: strikes, india, english, domain, canada, kingdom, language
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=8, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, hormuz, normal, coast, traffic, iranian, bitcoin, returns, ceasefire, peace, announces, ivory
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: story, economist, admit, seminars, evidence, https, insider, approaches, introduce, roderick, economists, economics
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*