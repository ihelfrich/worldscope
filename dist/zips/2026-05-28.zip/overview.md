# WORLDSCOPE morning brief — 2026-05-28

## Headline
1661 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 21 total
  (no new items today)

### State Legislative Action — 1 new of 1 total
  - (2026-05-28) [ingest error] Alaska: ReadTimeout
      HTTPSConnectionPool(host='v3.openstates.org', port=443): Read timed out. (read timeout=45)

### State-Level News — 42 new of 646 total
  - (2026-05-27) [Alaska] Solar power could soon be cheaper than natural gas power in Anchorage
      Alaska’s largest planned solar farm, expected to break ground west of Anchorage this summer, is likely to deliver cheaper electricity than possible with imported natural gas, according to information the state’s largest 
  - (2026-05-27) [California] New California law bans law enforcement from interfering in state elections
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp

### Local News: St. Louis + Atlanta — 106 new of 237 total
  - (2026-05-28) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-05-28) [St. Louis] Freak accident at Pointfest leads to tragic loss but brings new life through organ donation
      Danielle Uskiwich, a beloved St. Charles school secretary, died after a crowd surfer's kick unveiled fatal brain clots. Her organs were donated.
  - (2026-05-28) [St. Louis] Millions of insulin pods may be leaking, FDA warns: Here's how to check yours
      An estimated 7 million Omnipod insulin pods could have manufacturing errors leading to under-delivery of the medicine, the manufacturer said in an alert.
  - (2026-05-28) [St. Louis] Washington tourist pleads not guilty in Hawaiian monk seal rock case, barred from Hawaii beaches
      Hawaiian monk seals are a critically endangered species. Only 1,600 remain in the wild.
  - (2026-05-28) [St. Louis] St. Louis police budget fight prompts defunding fears
      As the new state Board of Police Commissioners demands an extra $69 million, a north St. Louis anti-violence group fears its city funding is on the chopping block.
  - (2026-05-28) [St. Louis] Missouri knew half of north St. Louis was uninsured for a decade. Then the tornado came
      5 On Your Side fought the state for insurance records. What we found had been sitting in a government file since 1988.
  - (2026-05-28) [St. Louis] DOJ opens criminal investigation into Trump accuser E. Jean Carroll, reports say
      The Department of Justice is investigating E. Jean Carroll for possible perjury related to her civil lawsuits against Donald Trump, according to reports.
  - (2026-05-28) [St. Louis] Popular supplements recalled as FDA reopens investigation into salmonella outbreak
      Federal health officials have reopened a multistate salmonella investigation after 22 new cases emerged.

### International News + Multilateral Institutions — 220 new of 856 total
  - (2026-05-28) [Global] Google employee charged with insider trading over Polymarket bets
      Michele Spagnuolo allegedly used insider information to profit from bets on people on Google&#039;s most-searched list.
  - (2026-05-28) [Global] Aid cuts and climate change drive deadly malaria surge in Zimbabwe
      A surge in malaria cases in Zimbabwe is exposing fragile health systems and growing treatment shortages in rural areas.
  - (2026-05-28) [Global] Parisians defy swimming ban to cool off as record heat hits Europe
      Parisians cooled off in the city’s Saint-Martin canal as an unprecedented heatwave pushed temperatures across Europe.
  - (2026-05-28) [Global] Uganda closes border with DRC in an effort to contain Ebola outbreak
      Uganda has closed its border with neighbouring DR Congo for four weeks in an effort to contain an Ebola outbreak.
  - (2026-05-28) [Global] US returns Palestinian rights expert Francesca Albanese to sanctions list
      Trump administration has sought to pressure international officials who scrutinise reported abuses by Israeli forces.
  - (2026-05-28) [Global] Iran war live: US strikes Iranian site; Kuwait targeted by missiles, drones
      Kuwait&#039;s military says air defences are battling &#039;hostile&#039; missiles and drones, as alarms sound across the country.
  - (2026-05-27) [Global] Jill Biden worried husband Joe was ‘having a stroke’ during 2024 US debate
      The former US first lady said she had never seen former President Joe Biden act the way he did on the 2024 debate stage.
  - (2026-05-27) [Global] Bolivia’s president warns ‘time is running out’ amid protest crisis
      Bolivia’s president has warned protesters “time is running out” amid a weeks-long standoff.

### Chinese Internal News — 246 new of 265 total
  - (2026-05-26) China’s Fiscal Revenue Improves but Spending Momentum Fades - Caixin Global
      <a href="https://news.google.com/rss/articles/CBMiswFBVV95cUxPNm9UZmo0bTVfTTgzWjZYeVRsRTdNQU9QYXdSdG4zTEhhc1psRk5iTnpFOHN2NWNKWXhlbnNLVU9SaXdHWWp6dlRXQmNCdzBOSEtqVDg5ZEhrSnNGUmlDZzVMWEdYVkxSbjZUd1pUOEZydGZYRlFUUWktWjNNcT
  - (2026-05-27) [TITLE: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlD] (zh: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlDRUx5b1ZMbmc3TmFqQVpGd1YyVk1NTm9R?oc=5" target="_blank">香港银行同步加强内地客监管 有
  - (2026-05-27) [TITLE: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3OD] (zh: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3ODJlTk9Hc1N4VEUxUEdRUzM4NzBDMThV?oc=5" target="_blank">电信诈骗版图南迁 自柬埔寨转向印尼</
  - (2026-05-27) [TITLE: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q] (zh: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q0t2MlR5Z0hQX2pYTl90ZWl0R3BBbXVFUE1r?oc=5" target="_blank">跨省履新仅8个月 “70后”高官李伟江
  - (2026-05-27) [TITLE: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNk] (zh: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNkd4djhVSzQ2dV96bmZwVzhvLUc3TW1ZTEQ0?oc=5" target="_blank">深圳一快速路段发生火灾 警方称无人受伤
  - (2026-05-26) [TITLE: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGh] (zh: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGhBenBsLXFZOVJxRl9xSmVnZHJHMUNB?oc=5" target="_blank">财经早知道｜深圳常住人口首破1
  - (2026-05-27) [TITLE: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHd] (zh: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHdyandPQXJnQW5YN2RmdU03U1FhOVFYV1Zn?oc=5" target="_blank">AI、石化产业链带动4月工业利
  - (2026-05-27) [TITLE: 全国31省份“十五五”规划纲要全部发布 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9WMXVXTjZnR1BidGRCMVlGelR6QnVJVnF1TU9ldkVELVJjLVgtMVhBQ0lpZllCV0xrZW9GNUNHQlVqMElxLS1KWVhkTXJWZ2RmWE] (zh: 全国31省份“十五五”规划纲要全部发布 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9WMXVXTjZnR1BidGRCMVlGelR6QnVJVnF1TU9ldkVELVJjLVgtMVhBQ0lpZllCV0xrZW9GNUNHQlVqMElxLS1KWVhkTXJWZ2RmWE1YMzNEeU9lWVJSZ0E?oc=5" target="_blank">全国31省份“十五五”规划纲要全部发布<

### Russian Internal News (state + in-exile) — 240 new of 996 total
  - (2026-05-28) [TITLE: Россиян ожидает самое длинное рабочее лето за три года | LEDE: ] (ru: Россиян ожидает самое длинное рабочее лето за три года)
  - (2026-05-28) [TITLE: Бойцы "Севера" уничтожили более 120 дронов "Баба-яга" ВСУ за май | LEDE: ] (ru: Бойцы "Севера" уничтожили более 120 дронов "Баба-яга" ВСУ за май)
  - (2026-05-28) [TITLE: Расчет БПЛА "Ланцет" уничтожил броневик ВСУ "Хамви" в Сумской области | LEDE: ] (ru: Расчет БПЛА "Ланцет" уничтожил броневик ВСУ "Хамви" в Сумской области)
  - (2026-05-28) [TITLE: В аэропорту Ульяновска сняли ограничения на полеты | LEDE: ] (ru: В аэропорту Ульяновска сняли ограничения на полеты)
  - (2026-05-28) [TITLE: Россиянам рассказали, могут ли клещи заразить сразу несколькими болезнями | LEDE: ] (ru: Россиянам рассказали, могут ли клещи заразить сразу несколькими болезнями)
  - (2026-05-28) [TITLE: Конгрессвумен Луна назвала Зеленского препятствием к миру на Украине | LEDE: ] (ru: Конгрессвумен Луна назвала Зеленского препятствием к миру на Украине)
  - (2026-05-28) [TITLE: Климатолог объяснил интенсивное проявление глобального потепления в Москве | LEDE: ] (ru: Климатолог объяснил интенсивное проявление глобального потепления в Москве)
  - (2026-05-28) [TITLE: Япония намерена защищать активы своих компаний в России, заявили в кабмине | LEDE: ] (ru: Япония намерена защищать активы своих компаний в России, заявили в кабмине)

### Ukrainian Internal News (national + local Kyiv) — 12 new of 113 total
  - (2026-05-28) [TITLE: Генштаб оновив дані про втрати ворога: мінус ще 1 160 російських окупантів | LEDE: Генштаб повідомив оновлені дані про втрати ворога за 27 травня.] (uk: Генштаб оновив дані про втрати ворога: мінус ще 1 160 російських окупантів)
      Генштаб повідомив оновлені дані про втрати ворога за 27 травня.
  - (2026-05-28) [TITLE: У Китаї перевантажений мікроавтобус врізався у вантажівку, 13 загиблих | LEDE: Переповнена маршрутка в Китаї врізалася у вантажівку, 13 людей загинули.] (uk: У Китаї перевантажений мікроавтобус врізався у вантажівку, 13 загиблих)
      Переповнена маршрутка в Китаї врізалася у вантажівку, 13 людей загинули.
  - (2026-05-28) [TITLE: Трамп завив про підтримку Пашиняна перед парламентськими виборами у Вірменії | LEDE: Напередодні парламентських виборів у Вірменії Трамп заявив про підтримку Пашиняна.] (uk: Трамп завив про підтримку Пашиняна перед парламентськими виборами у Вірменії)
      Напередодні парламентських виборів у Вірменії Трамп заявив про підтримку Пашиняна.
  - (2026-05-28) [TITLE: Ціна підпілля. Що чекає на учасників руху опору окупації в тюрмі та на волі | LEDE: Жодна людина – не острів, сама по собі; кожен з нас – частина континенту... Смерть кожної людини зменшує і ме] (uk: Ціна підпілля. Що чекає на учасників руху опору окупації в тюрмі та на волі)
      Жодна людина – не острів, сама по собі; кожен з нас – частина континенту... Смерть кожної людини зменшує і мене, бо я єдиний з усім людством; а тому ніколи не питай, по кому дзвонить дзвін: він дзвонить і по тобі.
  - (2026-05-28) [TITLE: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані | LEDE: Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.] (uk: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані)
      Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.
  - (2026-05-28) [TITLE: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ | LEDE: Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.] (uk: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ)
      Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.
  - (2026-05-28) [TITLE: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ | LEDE: За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.] (uk: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ)
      За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.
  - (2026-05-28) [TITLE: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби ППО | LEDE: Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.] (uk: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби)
      Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.

### Ukraine Theater (total-war monitoring) — 267 new of 441 total
  - (2026-05-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-25) [Liveuamap] Russian FM Lavrov informed State Secretary Rubio that Russia will intensify strikes on Kyiv. Lavrov urged Rubio to evacuate U.S. citizens and diplomatic staff from Kyiv Moskva, Moscow - Ukraine Interactive map - Ukraine Latest news on live 
      <a href="https://news.google.com/rss/articles/CBMikgFBVV95cUxQTkE1MmhVLXlxWmVTMW45QlppeVlWOVFva1ZNbUpRdU85eksxb0U3dS1qdW52bFlOWlhLNTQ3aHdKMWdzUFRfbXBwRzF5YW1rdklmQXpoRE5qQ2x1eHk0MVl4YWtTQmhnVEcxcmpGUF9xb0JuOXllcDY5UDNsXz
  - (2026-05-26) [Liveuamap] The U.S. Navy has resumed escorting ships through the Strait of Hormuz under a renewed “Project Freedom” mission. A Greek supertanker carrying two million barrels of crude was recently guided through the route after being stranded in the Gu
      <a href="https://news.google.com/rss/articles/CBMilwFBVV95cUxPaW5lLXY3NUJLY0ItLUJxZThHc2M4c1ExQjFYVzNrQUlUZENnZlppel9mc3dMUTRoem1LUllkT3liOTFCeGgwX0JZbTVvdjRrWUJrRUh2cnBWS1ZhOEpzZGFHX3M4UWFvdUdkLV9ERU1vcjFnYmVVd0Zza1VaRz
  - (2026-05-27) [Liveuamap] Explosions were reported at the airbase in Voronezh - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxNZHgyQi1oNThuX1BJa2lEdHRaTERPWVREQkF1RE5MUTQ5WUhRQjJha0RYRDhTeFQyOWJoU1k4aW42V0RZNXpRRTdUUUdzYWdnUXRzRThhTkNkUkdZRm1BbE9qVWhNeFVORGh4Z2tQcENGajlqSWxwbVltZ1N0V1
  - (2026-05-27) [Liveuamap] The Israelis notified the Trump administration that they escalate their attacks on Lebanon following a drone attack by Hezbollah tonight Tel Aviv-Yafo, Tel Aviv District - Lebanon news on live map - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMimgFBVV95cUxPbkJMUHd6ak9uQzR0T1hwQzNvbzZFZDF2SHlQTVdKVFdKMy1vUjBLYXJ0YnJmWU9hS3haNC1MNF9NUlZnbkZzaDg2N3c2R1N1TVd5ODRkZ3BycDBMOW55cXpWU2d0ZC1aRTZYT1ZWY1l0YjdyS0libjJ2ajFZQW
  - (2026-05-26) [Liveuamap] Israeli airstrike on the outskirts of the Abbasiya area in the Tyre district of southern Lebanon - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMinwFBVV95cUxPZ3FUcEZYN3YzdDdsMHpJMDFVMzlvOWMxTHh4bDVRZmhzenVGdURYXy05WTZmbkJ3cEZEeldpS2FBcVhYZ2VMcHZHVjZVcHcyOVpGQWpGT21FYUZ5cmxrc1JHS0hnbFVwOVR3TXRyVFdqbE5nWEdtZXdKSG9man
  - (2026-05-27) [Liveuamap] The Israeli army says it struck two "central Hamas militants" in the northern Gaza Strip, coinciding with local reports of an Israeli airstrike in Gaza City - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMiqAFBVV95cUxQUXlTb1lOX3g5WkdMOTRNTElRMWJiTEllQ0dNZnFzQ3pUWlVYQURsVzljazFlRkhHTDAyOWRUYUlaYmhnS1p0cjNjVmd2VnN3WENsTG1LQWpFSjhLcTFMbTYzTlNnbjVyd2tNYS1Jd2pnNGlOVnFkRXAtb2NXM3
  - (2026-05-27) [Liveuamap] Air raid targeted Buday Baalbek-Hermel Governorate, Lebanon - Lebanon news on live map - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMie0FVX3lxTE8yZ29DRzcwSTYyU2RSTFVtQ0hvdXF3QkptbTNGUjE4YUtjSC14ekdxWGNsbmlrcGloTVR2TTJQWkg5czNZanBWcFB6eTl5RE9hMVJZd2p5S3FSUjBWN0t0ODdvem1pUE15SXVyMW5ackg2TEp1dGlTblo3aw?oc=

### Paper Trading Scorecard — 4 new of 137 total
  - (2026-05-28) [Polymarket] Will there be between 10 and 20 average daily transits of the Strait of Hormuz on May 31?
      This market will resolve according to the 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for May 31, 2026.

If the reported value falls exactly between two
  - (2026-05-28) [Polymarket] Will Gretchen Whitmer win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”.

The resolution source for this mark
  - (2026-05-28) [Manifold] Will "Contra Wentworth on Physical Attractiveness f..." make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-05-28) [Manifold] Will 200 or more ships cross the straight of Hormuz in a day in 2026?

### U.S. Weather + Severe / Climate Outlooks — 63 new of 102 total
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 10:04PM MDT by NWS Missoula MT
      At 904 PM PDT, Doppler radar was tracking a strong thunderstorm 8
miles southeast of Kooskia, or 16 miles northeast of Grangeville,
moving northwest at 10 mph.

HAZARD...Wind gusts up to 40 mph and half inch size hail.


  - (2026-05-28) [Severe] Flood Warning: Flood Warning issued May 28 at 12:03AM EDT until May 28 at 6:00AM EDT by NWS Charleston WV
      * WHAT...Flooding caused by prior excessive rainfall continues.

* WHERE...Northern Calhoun County in north central West Virginia...
Northern Gilmer County in north central West Virginia...
Barbour County in northeastern
  - (2026-05-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Moderate] Rip Current Statement: Rip Current Statement issued May 27 at 11:00PM CDT until May 30 at 6:00AM CDT by NWS Mobile AL
      * WHAT...Dangerous rip currents.

* WHERE...In Alabama, Mobile Coastal and Baldwin Coastal
Counties. In Florida, Escambia Coastal, Santa Rosa Coastal and
Okaloosa Coastal Counties.

* WHEN...Through late Friday night.

*
  - (2026-05-27) [Moderate] Wind Advisory: Wind Advisory issued May 27 at 8:54PM PDT until May 28 at 5:00AM PDT by NWS San Diego CA
      * WHAT...West winds 20 to 30 mph with gusts up to 55 mph.

* WHERE...Riverside County Mountains, San Diego County Deserts, San
Diego County Mountains, and San Gorgonio Pass near Banning.

* WHEN...Until 5 AM PDT Thursday
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 11:49PM EDT by NWS Wakefield VA
      At 1148 PM EDT, Doppler radar was tracking strong thunderstorms along
a line extending from near Corapeake to near Hobbsville to
Harrellsville. Movement was east at 40 mph.

HAZARD...Wind gusts up to 40 mph.

SOURCE...Ra
  - (2026-05-27) [Severe] Red Flag Warning: Red Flag Warning issued May 27 at 9:48PM MDT until May 28 at 10:00PM MDT by NWS Glasgow MT
      ...RED FLAG WARNING WILL EXPIRE AT 10 PM MDT THIS EVENING FOR LOW
RELATIVE HUMIDITY AND STRONG WINDS FOR FIRE WEATHER ZONES 120 AND
122...

* AFFECTED AREA...Fire weather zones 120 and 122.

* WIND...Southeast at 15 to 2
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 11:39PM EDT by NWS Wilmington OH
      Some patchy dense fog is developing late this evening, especially
in lower terrain areas. Fog is expected to become more widespread
for some areas into the early morning hours, with dense fog likely
impacting local commu

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 20 new of 95 total
  - (2026-05-27) [OFAC] International Criminal Court-related Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoYmsxWDE3WFh2VzgyWDZ2Y2xnSVJHZzFTTnUtUlM5Z0tOMktfbXRkUmJhMmdHa2wwM19JRnhiWkwxdENoT0owTkx0cEU0ZmdIUk5CVGFjZ2cxbDJOS2c?oc=5" target="_blank">International Crimin
  - (2026-05-28) [OFAC] Iran-related Designation; Counter Terrorism Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1wZHZVOFR1Yy1MSzRFaERsQlZWWmFCSV9fcUQ5eFpEWVdtV3N2dFFZdFlqWG9ldkNFNTBGdjRBSHVrdTlwNmhRT2xndXotaHlyakdWdXpvS2Fkek5QY0UwWG9B?oc=5" target="_blank">Iran-related De
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-28) [USASpending] $534,079,951 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
      Agency: General Services Administration.  Description: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
  - (2026-05-28) [USASpending] $486,224,471 → LOCKHEED MARTIN CORPORATION: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTR
      Agency: National Aeronautics and Space Administration.  Description: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTRUMENT THE FOR GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) R.  THE CONTRACTOR 
  - (2026-05-28) [USASpending] $432,416,292 → LEIDOS BIOMEDICAL RESEARCH INC: NCI OPERATIONAL TASK ORDER
      Agency: Department of Health and Human Services.  Description: NCI OPERATIONAL TASK ORDER
  - (2026-05-28) [USASpending] $406,089,353 → AERODYNE-SGT ENGINEERING SERVICES, LLC: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEER
      Agency: National Aeronautics and Space Administration.  Description: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEERING TASK ORDERS FOR THE FORMULATION, DESIGN, DEVELOPMENT, FABRICATION, INTEGRATION, TESTING
  - (2026-05-28) [USASpending] $405,028,920 → VERIZON BUSINESS NETWORK SERVICES LLC: CENTRALIZED HHS EIS REQUIREMENT
      Agency: Department of Health and Human Services.  Description: CENTRALIZED HHS EIS REQUIREMENT

### Congressional STOCK Act Trades (House + Senate) — 0 new of 1 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-28) [WHEELER SIMON] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [RAWLINGS DARRYL] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:55 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Ollet John] Form 4 (Reporting)
      filed 2026-05-28 01:55 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Lerman Michael Stuart] Form 4 (Reporting)
      filed 2026-05-28 01:53 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:53 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 15 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-28) [United States] Shrimp boat freed after nearly two weeks stuck on Bolivar Peninsula
      domain: 12newsnow.com · language: English · tone: 
  - (2026-05-28) [United States] Evening Edition : U . S .- Iran Talks Reach Critical Stage
      domain: radio.foxnews.com · language: English · tone: 
  - (2026-05-28) [Singapore] Governance , trust and the rise of agentic AI
      domain: techgoondu.com · language: English · tone: 
  - (2026-05-28) [United States] Don Lemon seeks grand jury transcripts in Minnesota civil rights case , citing misconduct - Las Vegas Sun News
      domain: lasvegassun.com · language: English · tone: 
  - (2026-05-28) [United States] Jamaica Seeks to Secure Share of Global Medical and Dental Tourism Market
      domain: sflcn.com · language: English · tone: 
  - (2026-05-28) [United States] Aid cuts and climate change drive deadly malaria surge in Zimbabwe - Dominican Republic Post – Caribbean News , Business , Travel & Culture
      domain: dominicanrepublicpost.com · language: English · tone: 
  - (2026-05-28) [United States] Rishi Sunak to become Britain next prime minister
      domain: theworld.org · language: English · tone: 
  - (2026-05-28) [United States] Socialism and Social Trust
      domain: hotair.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 16 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 5 new of 20 total
  - (2026-05-28) Will South Korea win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,994,220 · resolves 2026-07-20
  - (2026-05-28) Colorado Rockies vs. Los Angeles Dodgers
      yes price: 6% · 24h volume: $784,145 · resolves 2026-06-04
  - (2026-05-28) US announces new Iran agreement/ceasefire extension by May 31?
      yes price: 20% · 24h volume: $769,143
  - (2026-05-28) Will Germany win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $732,599 · resolves 2026-07-20
  - (2026-05-28) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $726,180 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 0 new of 6 total
  (no new items today)

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25; carrying terms: action, specifically, airbus, certificate, angle, condition, changes, interest, field, temporary, potential, proposes
- state_bills: today=1, 7d-median=1, 14d-median=1
- state_news: today=646, 7d-median=722, 14d-median=722
- local_news: today=237, 7d-median=265, 14d-median=265
- foreign_news: today=856, 7d-median=906, 14d-median=906
- chinese_internal: today=265, 7d-median=289, 14d-median=289
- russian_internal: today=996, 7d-median=1021, 14d-median=1021
- ukrainian_internal: today=113, 7d-median=138, 14d-median=138
- ukraine_theater: today=441, 7d-median=441, 14d-median=441
- paper_bets: today=137, 7d-median=137, 14d-median=137
- weather: today=102, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: blanche, hospital, sociedad, rodriguez, delgado, khalil, andre, catherine, internal, bondi, josselyn, transport
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed
- fec: today=15, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: kingdom, english, canada, israel, india, domain, language, cancer
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ceasefire, coast, world, traffic, hormuz, announces, continue, peace, permanent, price, ivory, volume
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: academic, laugh, evidence, revolution, functions, marginal, along, production, roderick, conversable, economists, experience
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*