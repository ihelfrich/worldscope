# WORLDSCOPE morning brief — 2026-05-28

## Headline
2421 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 24 new of 24 total
  - (2026-05-28) Memorial Day, 2026
  - (2026-05-28) Air Plan Approval; Ohio; Removal of Air Nuisance Rule
      The Environmental Protection Agency (EPA) is proposing to act in accordance with Ohio EPA's November 14, 2025, request to remove the air pollution nuisance rule (ANR) from the Ohio State Implementation Plan (SIP). The EP
  - (2026-05-28) Approval of Source-Specific Air Quality Implementation Plan; New York; Big Six Towers Inc.
      The Environmental Protection Agency (EPA) is proposing to determine a revision to the State of New York's State Implementation Plan (SIP) for the ozone National Ambient Air Quality Standard (NAAQS) related to a source-sp
  - (2026-05-28) Hazardous and Solid Waste Management System: Disposal of Coal Combustion Residuals From Electric Utilities; Federal CCR Permit Program; Reopening of Comment Period
      The Environmental Protection Agency (EPA) issued a proposed rule on February 20, 2020, to establish a Federal permit program for disposal of coal combustion residuals (CCR). The EPA is reopening the comment period on tha
  - (2026-05-28) Air Plan Approval; SC; Department Name Change
      The Environmental Protection Agency (EPA) is proposing to approve a State Implementation Plan (SIP) revision submitted by the State of South Carolina on July 23, 2025. The proposed revision updates all references to refl
  - (2026-05-28) Air Plan Approval; Maryland; Reasonably Available Control Technology for Municipal Waste Combustors; Extension of Comment Period
      The Environmental Protection Agency (EPA) is extending the comment period for a proposed rule that published April 29, 2026. The current comment period for the proposed rule was scheduled to close on May 29, 2026. The EP
  - (2026-05-28) Medical Devices; Gastroenterology-Urology Devices; Classification of the Endoscopic Suturing Device for Altering Gastric Anatomy for Weight Loss
      The Food and Drug Administration (FDA) is classifying the endoscopic suturing device for altering gastric anatomy for weight loss into class II (special controls). The special controls that apply to the device type are i
  - (2026-05-28) Proposed Waiver and Extension of the Project Period With Funding for Arts in Education National Program
      The Secretary proposes to waive the requirements in the Education Department General Administrative Regulations that generally prohibit project period extensions involving the obligation of additional Federal funds. The 

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 90 new of 674 total
  - (2026-05-27) [California] New California law bans law enforcement from interfering in state elections
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 118 new of 237 total
  - (2026-05-28) [St. Louis] US military posts video of deadly strike against suspected drug boat in the Pacific
      The Pentagon inspector general’s office said the review was “self-initiated.” It will not probe the legality of the strikes.
  - (2026-05-28) [St. Louis] 9 spellers advance to the Scripps National Spelling Bee finals. Here's where they're from.
      The Scripps National Spelling Bee started with 247 spellers. After nine rounds, only a few remain.
  - (2026-05-28) [St. Louis] Freak accident at Pointfest leads to tragic loss but brings new life through organ donation
      Danielle Uskiwich, a beloved St. Charles school secretary, died after a crowd surfer's kick unveiled fatal brain clots. Her organs were donated.
  - (2026-05-28) [St. Louis] Millions of insulin pods may be leaking, FDA warns: Here's how to check yours
      An estimated 7 million Omnipod insulin pods could have manufacturing errors leading to under-delivery of the medicine, the manufacturer said in an alert.
  - (2026-05-28) [St. Louis] Washington tourist pleads not guilty in Hawaiian monk seal rock case, barred from Hawaii beaches
      Hawaiian monk seals are a critically endangered species. Only 1,600 remain in the wild.
  - (2026-05-28) [St. Louis] St. Louis police budget fight prompts defunding fears
      As the new state Board of Police Commissioners demands an extra $69 million, a north St. Louis anti-violence group fears its city funding is on the chopping block.
  - (2026-05-28) [St. Louis] Missouri knew half of north St. Louis was uninsured for a decade. Then the tornado came
      5 On Your Side fought the state for insurance records. What we found had been sitting in a government file since 1988.
  - (2026-05-28) [St. Louis] DOJ opens criminal investigation into Trump accuser E. Jean Carroll, reports say
      The Department of Justice is investigating E. Jean Carroll for possible perjury related to her civil lawsuits against Donald Trump, according to reports.

### International News + Multilateral Institutions — 457 new of 859 total
  - (2026-05-28) [Singapore] Judge allows Trump to implement mail-in voting executive order
      <p>May 28 - A U.S. judge on Thursday declined to block President Donald Trump's executive tightening rules on mail-in voting in a loss for the Democratic Party, whose lawyers argued that it could disenfranchise millions 
  - (2026-05-28) [Singapore] Germans switch to EVs at record pace thanks to government bonus
      <p>The programme provides subsidies of between €1,500 (S$2,229) and €6,000 (S$8,916).</p>
  - (2026-05-28) [Singapore] French power demand rises as deadly heatwave intensifies
      <p>Of the 51 heatwaves recorded in France since 1947, more than half were in the past 15 years.</p>
  - (2026-05-28) [Singapore] Ukraine's Zelenskiy in Sweden for Gripen fighter jet announcement, source says
      <p>UPPSALA, Sweden, May 28 - Sweden's Prime Minister Ulf Kristersson will host Ukrainian President Volodymyr Zelenskiy in Sweden on Thursday, the government said, and a source told Reuters they will announce news related
  - (2026-05-28) [Singapore] US arrests former CIA official with $51 million in gold at home
      <p>He had provided false information about his education and military background in his job application.</p>
  - (2026-05-28) [Singapore] France moves towards symbolic repealing of slavery legislation
      <p>The French were the third largest slave traders in Europe, after the British and the Portuguese.</p>
  - (2026-05-28) [Singapore] London’s expats struggle to adapt to extreme heat without air conditioning
      <p>As Britain gets continually hotter, large parts of the population have no clear path to adequate cooling.</p>
  - (2026-05-28) [Singapore] Three tankers reportedly attacked by drones in Black Sea, shipping agency says
      <p>ISTANBUL, May 28 - Drone attacks were reported on three tankers in the Black Sea on Thursday near Turkey's northern coast, shipping agency Tribeca said.</p>

### Chinese Internal News — 249 new of 268 total
  - (2026-05-27) [TITLE: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlD] (zh: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlDRUx5b1ZMbmc3TmFqQVpGd1YyVk1NTm9R?oc=5" target="_blank">香港银行同步加强内地客监管 有
  - (2026-05-28) [TITLE: 今日开盘：两市双双低开 沪指跌幅0.33% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBlbzN0LUwtX2xySmVQR2dGcGhnclBTd3hrd09BN3BIVjRzR2N6aXB0TG55RjZ4LW1ucXZyQlFQNkVvcmZoS0lBQXF2QnV0M0dl] (zh: 今日开盘：两市双双低开 沪指跌幅0.33% - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBlbzN0LUwtX2xySmVQR2dGcGhnclBTd3hrd09BN3BIVjRzR2N6aXB0TG55RjZ4LW1ucXZyQlFQNkVvcmZoS0lBQXF2QnV0M0dlSWx4NkhVUGFwQkN5b0g1R0VB?oc=5" target="_blank">今日开盘：两市双双低开 沪指跌
  - (2026-05-28) [TITLE: 立讯精密被罚 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1ZUk8zbUpWamVISFpKanZhUDJhWVhaMm5qNUZaeU9SY0w0Y3F2bnVhV2RWRkdPY0VneDlpZmNzN0hhOThvcm56ZXNuTGJ5Ni05V0FFN0RlTTN2cmR] (zh: 立讯精密被罚 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1ZUk8zbUpWamVISFpKanZhUDJhWVhaMm5qNUZaeU9SY0w0Y3F2bnVhV2RWRkdPY0VneDlpZmNzN0hhOThvcm56ZXNuTGJ5Ni05V0FFN0RlTTN2cmRSWlE?oc=5" target="_blank">立讯精密被罚</a>&nbsp;&nbs
  - (2026-05-27) [TITLE: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3OD] (zh: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3ODJlTk9Hc1N4VEUxUEdRUzM4NzBDMThV?oc=5" target="_blank">电信诈骗版图南迁 自柬埔寨转向印尼</
  - (2026-05-27) [TITLE: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNk] (zh: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNkd4djhVSzQ2dV96bmZwVzhvLUc3TW1ZTEQ0?oc=5" target="_blank">深圳一快速路段发生火灾 警方称无人受伤
  - (2026-05-27) [TITLE: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q] (zh: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q0t2MlR5Z0hQX2pYTl90ZWl0R3BBbXVFUE1r?oc=5" target="_blank">跨省履新仅8个月 “70后”高官李伟江
  - (2026-05-26) [TITLE: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGh] (zh: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGhBenBsLXFZOVJxRl9xSmVnZHJHMUNB?oc=5" target="_blank">财经早知道｜深圳常住人口首破1
  - (2026-05-27) [TITLE: 财经早知道｜日赚近4亿！长鑫科技预定今年A股最大IPO - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFAzZUUzRERuWDFvWll5b0JWUkFsa1Q1cDRPWDE2WjROa3B1Z2ZWR0VkMlVyUTNOaUQybm1zSi1pWFVMNWFwWU4wUlRPbU] (zh: 财经早知道｜日赚近4亿！长鑫科技预定今年A股最大IPO - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFAzZUUzRERuWDFvWll5b0JWUkFsa1Q1cDRPWDE2WjROa3B1Z2ZWR0VkMlVyUTNOaUQybm1zSi1pWFVMNWFwWU4wUlRPbU9iTnMzTURXd1kwTFhUNGRzTTF5TFFn?oc=5" target="_blank">财经早知道｜日赚近4亿！长鑫科

### Russian Internal News (state + in-exile) — 493 new of 1054 total
  - (2026-05-28) [TITLE: Члены Общественной палаты пожаловались на «ряженых ветеранов СВО» | LEDE: <p>Члены Общественной палаты РФ считают, что ситуация с негосударственными наградами «участникам СВО» вышла из-под конт] (ru: Члены Общественной палаты пожаловались на «ряженых ветеранов СВО»)
      <p>Члены Общественной палаты РФ считают, что ситуация с негосударственными наградами «участникам СВО» вышла из-под контроля. Фонды, некоммерческие организации и даже частные лица выпускают огромное количество своих награ
  - (2026-05-28) [TITLE: Кая Каллас заявила, что США эвакуировали дипломатов из Киева после угроз России нанести удары. Посольство США и МИД Украины это отрицают | LEDE: <p>Глава дипломатии ЕС Кая Каллас заявила, что а] (ru: Кая Каллас заявила, что США эвакуировали дипломатов из Киева после угроз России )
      <p>Глава дипломатии ЕС Кая Каллас заявила, что американские дипломаты покинули Киев после угроз России нанести удары.<p>
  - (2026-05-28) [TITLE: В России стали вдвое чаще задерживать авиарейсы. Число отмененных рейсов выросло в четыре раза | LEDE: <p>Количество длительных задержек авиарейсов за неполные пять месяцев 2026 года в России в] (ru: В России стали вдвое чаще задерживать авиарейсы. Число отмененных рейсов выросло)
      <p>Количество длительных задержек авиарейсов за неполные пять месяцев 2026 года в России выросло в среднем в два раза по сравнению с аналогичным периодом прошлого года, число отмен — в четыре раза, число отмен после заде
  - (2026-05-28) [TITLE: Беспилотник ударил по зданию областного суда в Нижнем Новгороде | LEDE: <p>Здание областного суда в Нижнем Новгороде повреждено в результате удара украинского дрона, сообщил губернатор Глеб Ник] (ru: Беспилотник ударил по зданию областного суда в Нижнем Новгороде)
      <p>Здание областного суда в Нижнем Новгороде повреждено в результате удара украинского дрона, сообщил губернатор Глеб Никитин. Люди, по его данным, не пострадали.<p>
  - (2026-05-28) [TITLE: Трамп поддержал Пашиняна на выборах в Армении | LEDE: <p>Президент США Дональд Трамп заявил, что «полностью и безоговорочно» поддерживает премьер-министра Армении Никола Пашиняна на предстоящих] (ru: Трамп поддержал Пашиняна на выборах в Армении)
      <p>Президент США Дональд Трамп заявил, что «полностью и безоговорочно» поддерживает премьер-министра Армении Никола Пашиняна на предстоящих парламентских выборах. <p>
  - (2026-05-28) [TITLE: США и Иран обменялись ударами, но перемирие не отменили | LEDE: <p>США нанесли удар по военному объекту в городе Бендер-Аббас на юге Ирана, сообщило агентство Reuters со ссылкой на американског] (ru: США и Иран обменялись ударами, но перемирие не отменили)
      <p>США нанесли удар по военному объекту в городе Бендер-Аббас на юге Ирана, сообщило агентство Reuters со ссылкой на американского чиновника. <p>
  - (2026-05-28) [TITLE: Горящий Туапсе, разбомбленный Брянск, масштабный налет дронов на Москву и нефтяные дожди над Пермью и Рязанью — все это случилось в 2026 году. Кажется, Украина стала куда чаще бить вглубь терри] (ru: Горящий Туапсе, разбомбленный Брянск, масштабный налет дронов на Москву и нефтян)
      <p>Серия массированных ударов Вооруженных сил Украины (ВСУ) по Брянску, Москве, Перми, Туапсе и многим другим целям в глубине России создает у многих наблюдателей устойчивое впечатление: в 2026 году Киеву удалось качеств
  - (2026-05-28) [TITLE: Что Путин и Токаев обсудили на переговорах в Астане | LEDE: Президент РФ Владимир Путин и президент Казахстана Касым-Жомарт Токаев 28 мая проводят двусторонние переговоры во Дворце независимост] (ru: Что Путин и Токаев обсудили на переговорах в Астане)
      Президент РФ Владимир Путин и президент Казахстана Касым-Жомарт Токаев 28 мая проводят двусторонние переговоры во Дворце независимости в Астане. Это второй государственный визит президента России в Казахстан с 2024 г., х

### Ukrainian Internal News (national + local Kyiv) — 38 new of 120 total
  - (2026-05-28) [TITLE: ЗМІ: У Москві на дахах будинків встановлюють ЗРК | LEDE: У Москві на даху бізнес-центру розмістили ЗРК "Панцирь-СМД-Е" за допомогою гелікоптера Ми-26. Опубліковано відео.] (uk: ЗМІ: У Москві на дахах будинків встановлюють ЗРК)
      У Москві на даху бізнес-центру розмістили ЗРК "Панцирь-СМД-Е" за допомогою гелікоптера Ми-26. Опубліковано відео.
  - (2026-05-28) [TITLE: Окупанти убили чоловіка і жінку на Сумщині – цивільних атакували дроном | LEDE: Удар російського дрона у Сумській області: загинули двоє цивільних] (uk: Окупанти убили чоловіка і жінку на Сумщині – цивільних атакували дроном)
      Удар російського дрона у Сумській області: загинули двоє цивільних
  - (2026-05-28) [TITLE: У застосунку Київ Цифровий з’явився новий сервіс "Мій депутат" | LEDE: У застосунку Київ Цифровий з'явився новий сервіс "Мій депутат", який допоможе мешканцям краще розуміти, як працює Київрада] (uk: У застосунку Київ Цифровий з’явився новий сервіс "Мій депутат")
      У застосунку Київ Цифровий з'явився новий сервіс "Мій депутат", який допоможе мешканцям краще розуміти, як працює Київрада та які рішення ухвалюють депутати.
  - (2026-05-28) [TITLE: Останні дні травня будуть з дощами і грозами | LEDE: 29-31 травня в Україні збережеться тепла погода з дощами. Детальний прогноз від Укргідрометцентру.] (uk: Останні дні травня будуть з дощами і грозами)
      29-31 травня в Україні збережеться тепла погода з дощами. Детальний прогноз від Укргідрометцентру.
  - (2026-05-28) [TITLE: У МЗС Швеції заявили, що Європа має бути на боці України, а не посередником у переговорах з РФ | LEDE: Міністерка закордонних справ Швеції Марія Мальмер Стенергард заявила, що Європа має посилю] (uk: У МЗС Швеції заявили, що Європа має бути на боці України, а не посередником у пе)
      Міністерка закордонних справ Швеції Марія Мальмер Стенергард заявила, що Європа має посилювати тиск на Росію і підтримку України, а не поспішати до переговорів на умовах Кремля.
  - (2026-05-28) [TITLE: Чоловік пограбував офіс у Києві, пошкоджений ударом РФ – його затримали перехожі | LEDE: Поки столиця оговтувалася від ворожої атаки 24 травня, чоловік скористався тим, що будівля у Солом'янськ] (uk: Чоловік пограбував офіс у Києві, пошкоджений ударом РФ – його затримали перехожі)
      Поки столиця оговтувалася від ворожої атаки 24 травня, чоловік скористався тим, що будівля у Солом'янському районі постраждала від вибуху, проник до офісного приміщення, звідки вкрав техніку.
  - (2026-05-28) [TITLE: Посольство США підтвердило, що залишається в Києві попри залякування Кремля | LEDE: Посольство США заперечило слова глави дипломатії ЄС Каї Каллас про те, нібито американські дипломати покинули] (uk: Посольство США підтвердило, що залишається в Києві попри залякування Кремля)
      Посольство США заперечило слова глави дипломатії ЄС Каї Каллас про те, нібито американські дипломати покинули українську столицю через погрози Росії ракетними ударами.
  - (2026-05-28) [TITLE: Україну вважають "щитом Європи". Чому це небезпечний зсув відповідальності | LEDE: GLOBSEC 2026 у Празі: Україна — ключовий гравець безпеки Європи, потрібна практична підтримка від партнерів.] (uk: Україну вважають "щитом Європи". Чому це небезпечний зсув відповідальності)
      GLOBSEC 2026 у Празі: Україна — ключовий гравець безпеки Європи, потрібна практична підтримка від партнерів.

### Ukraine Theater (total-war monitoring) — 293 new of 365 total
  - (2026-05-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [FIRMS] thermal anomaly 47.174, 31.756 (FRP 0.47 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.47 MW
  - (2026-05-27) [FIRMS] thermal anomaly 46.684, 32.687 (FRP 1.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 1.38 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.374, 30.926 (FRP 1.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 1.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.259, 31.673 (FRP 9.83 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 9.83 MW
  - (2026-05-27) [FIRMS] thermal anomaly 44.772, 33.858 (FRP 0.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 44.772, 33.863 (FRP 0.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.64 MW
  - (2026-05-27) [FIRMS] thermal anomaly 45.953, 22.869 (FRP 0.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-27 2354Z, FRP 0.41 MW

### Paper Trading Scorecard — 7 new of 139 total
  - (2026-05-28) [Polymarket] Will NVIDIA (NVDA) hit (HIGH) $240 in May?
      This market will resolve to "Yes" if, at any point during May 2026, any 1-minute candle for NVIDIA (NVDA) has a final "High" price equal to or above the listed price. Otherwise, this market will resolve to "No".

Only pr
  - (2026-05-28) [Polymarket] Will Sergio Pérez be the 2026 F1 Drivers' Champion?
      This market will resolve according to the listed driver that finishes 1st in the driver standings for the 2026 F1 season.

This market will resolve as soon as the official results of the final scheduled race of the 2026 
  - (2026-05-28) [Polymarket] Will Gretchen Whitmer win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”.

The resolution source for this mark
  - (2026-05-28) [Manifold] Will "Donating 80% While It Still Counts" make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-05-28) [Manifold] Will "Contra Wentworth on Physical Attractiveness f..." make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-05-28) [Manifold] Will 2+ bots beat master league in 2026?
  - (2026-05-28) [Manifold] Will 200 or more ships cross the straight of Hormuz in a day in 2026?

### U.S. Weather + Severe / Climate Outlooks — 106 new of 113 total
  - (2026-05-28) [Moderate] Hazardous Seas Warning: Hazardous Seas Warning issued May 28 at 2:35AM PDT until May 28 at 11:00AM PDT by NWS Medford OR
      * WHAT...North winds ease to 10 to 20 kt today, but will be
southerly at 5 to 10 kt near the coast south of Gold Beach. Seas
of 10 to 13 feet at 8 seconds this morning become swell
dominated this afternoon, but remain st
  - (2026-05-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-28) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 28 at 4:30AM CDT until May 28 at 1:00PM CDT by NWS Milwaukee/Sullivan WI
      * WHAT...Life threatening waves of 3 to 6 feet and dangerous
currents are expected.

* WHERE...Sheboygan, Ozaukee, Milwaukee, Racine and Kenosha
Counties.

* WHEN...Until 1 PM CDT Thursday afternoon.

* IMPACTS...Dangero
  - (2026-05-28) [Moderate] Special Weather Statement: Special Weather Statement issued May 28 at 5:23AM EDT by NWS Louisville KY
      Saturated ground from recent rains and ample low-level moisture
have supported the development of patchy fog across portions of
southern Indiana and central Kentucky. Motorists should be
prepared for sudden changes in vi
  - (2026-05-28) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 28 at 2:22AM PDT until May 29 at 3:00AM PDT by NWS San Francisco CA
      * WHAT...Increased risk of sneaker waves and strong rip currents
due to incoming long period northwesterly swell.

* WHERE...Beaches along the Pacific Coast.

* WHEN...From 9 AM PDT this morning through late tonight.

* 
  - (2026-05-28) [Severe] Special Marine Warning: Special Marine Warning issued May 28 at 5:18AM EDT until May 28 at 6:00AM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW

The National Weather Service in Ruskin has issued a

* Special Marine Warning for...
Coastal waters from Bonita Beach to Englewood FL out 20 NM...
Coastal waters from Englewood to Tarpon Springs FL out 20 NM...
W
  - (2026-05-28) [Moderate] Special Weather Statement: Special Weather Statement issued May 28 at 4:14AM CDT by NWS Amarillo TX
      At 413 AM CDT, Doppler radar was tracking a strong thunderstorm 5
miles south of Canadian, moving southeast at 15 mph.

HAZARD...Winds in excess of 30 mph and pea size hail.

SOURCE...Radar indicated.

IMPACT...Gusty win
  - (2026-05-28) [Moderate] Special Weather Statement: Special Weather Statement issued May 28 at 2:54AM MDT by NWS Great Falls MT
      At 254 AM MDT, Doppler radar was tracking strong thunderstorms along
a line extending from 7 miles east of Heart Butte to near Valier to 9
miles northeast of Conrad. Movement was north at 45 mph.

HAZARD...Wind gusts up 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 20 new of 95 total
  - (2026-05-27) [OFAC] International Criminal Court-related Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoYmsxWDE3WFh2VzgyWDZ2Y2xnSVJHZzFTTnUtUlM5Z0tOMktfbXRkUmJhMmdHa2wwM19JRnhiWkwxdENoT0owTkx0cEU0ZmdIUk5CVGFjZ2cxbDJOS2c?oc=5" target="_blank">International Crimin
  - (2026-05-28) [OFAC] Iran-related Designation; Counter Terrorism Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1wZHZVOFR1Yy1MSzRFaERsQlZWWmFCSV9fcUQ5eFpEWVdtV3N2dFFZdFlqWG9ldkNFNTBGdjRBSHVrdTlwNmhRT2xndXotaHlyakdWdXpvS2Fkek5QY0UwWG9B?oc=5" target="_blank">Iran-related De
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-28) [USASpending] $30,433,184,240 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST               
      Agency: Department of Energy.  Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST               LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-05-28) [USASpending] $10,688,516,058 → ALLIANCE FOR ENERGY INNOVATION, LLC: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWAB
      Agency: Department of Energy.  Description: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWABLE ENERGY LABORATORY
  - (2026-05-28) [USASpending] $4,681,725,957 → RUSSIA SPACE AGENCY: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
      Agency: National Aeronautics and Space Administration.  Description: JOINT US/RUSSIAN HUMAN SPACE FLIGHT ACTIVITIES
  - (2026-05-28) [USASpending] $3,283,051,341 → JEFFERSON SCIENCE ASSOCIATES, LLC: TAS::89 0222::TAS MANAGEMENT AND OPERATION OF THE THOMAS JEF
      Agency: Department of Energy.  Description: TAS::89 0222::TAS MANAGEMENT AND OPERATION OF THE THOMAS JEFFERSON NATIONAL ACCELERATOR FACILITY.
  - (2026-05-28) [USASpending] $3,061,819,994 → OAK RIDGE ASSOCIATED UNIVERSITIES, INCORPORATED: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIEN
      Agency: Department of Energy.  Description: IGF::OT::IGF MANAGEMENT OF THE OAK RIDGE INSTITUTE FOR SCIENCE AND EDUCATION

### Congressional STOCK Act Trades (House + Senate) — 53 new of 53 total
  - (2026-05-06) [Senate] Bernardo Moreno (R): Sale (Full) ETOR ($100,001 - $250,000) (excess -2.3% vs SPY)
      Member: Bernardo Moreno (R, senate).  BioGuide: M001242.  Asset: ETOR (Stock).  Type: Sale (Full).  Amount range: $100,001 - $250,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-22.  Excess return vs SPY si
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.1% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.1% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-04-29) [House] Thomas H. Kean Jr (R): Sale ADI ($1,001 - $15,000) (excess +1.6% vs SPY)
      Member: Thomas H. Kean Jr (R, house).  BioGuide: K000398.  Asset: ADI (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-04-29.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-07) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +12.6% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-06) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +18.9% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Tim Moore (R): Purchase T ($15,001 - $50,000) (excess +0.3% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: T (ST).  Type: Purchase.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure: +0
  - (2026-05-07) [House] Tim Moore (R): Purchase RYCEY ($1,001 - $15,000) (excess -0.2% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: RYCEY (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure:

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-28) [WHEELER SIMON] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [RAWLINGS DARRYL] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:55 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Ollet John] Form 4 (Reporting)
      filed 2026-05-28 01:55 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Lerman Michael Stuart] Form 4 (Reporting)
      filed 2026-05-28 01:53 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:53 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 27 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-28) [United Kingdom] Schools to fine parents over important rule from Monday
      domain: birminghammail.co.uk · language: English · tone: 
  - (2026-05-28) [United States] Father admits leaving handgun within reach of young daughters before toddler fatally shot baby sister
      domain: foxwilmington.com · language: English · tone: 
  - (2026-05-28) [Canada] Groundbreaking therapy for advanced heart failure : Outcomes of the BIOVAT - HF clinical trial published in NEJM
      domain: montrealgazette.com · language: English · tone: 
  - (2026-05-28) [United States] Top Biotech Gainers : QTTB Has A Good Hair Day , GH Wins ACS Recommendation , Ebola Lifts SNGX , NNVX
      domain: rttnews.com · language: English · tone: 
  - (2026-05-28) [United States] Happy , who taught researchers that elephants can recognize themselves , is euthanized
      domain: ualrpublicradio.org · language: English · tone: 
  - (2026-05-28) [Pakistan] Palestinians mourn slain Hamas chief as Israel escalates Gaza attacks
      domain: dunyanews.tv · language: English · tone: 
  - (2026-05-28) [India] Here are four significant economic distortions that India must sort out to shield its economy
      domain: livemint.com · language: English · tone: 
  - (2026-05-28) [United States] Feds seize $40M in gold bars , cash , Rolexes from former CIA official who faked being a Navy pilot
      domain: foxwilmington.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 29 new of 29 total
  - (2026-05-28) JAF9XT (Bulgaria)
      icao24: 4520ce · position: (48.5605, 6.6836) · alt: 5204m · 774km/h
  - (2026-05-28) GAF188 (Germany)
      icao24: 3e8b41 · position: (39.1378, 20.7981) · alt: 9441m · 751km/h
  - (2026-05-28) RFF07 (Portugal)
      on ground · 29km/h
  - (2026-05-28) FNY5568 (France)
      icao24: 39a407 · position: (48.5347, -4.1296) · alt: 68m · 216km/h
  - (2026-05-28) JAF7CB (Belgium)
      icao24: 44d1ba · position: (44.3173, -1.1585) · alt: 10972m · 855km/h
  - (2026-05-28) JAF1YV (Belgium)
      icao24: 44d1a6 · position: (36.0406, 24.8562) · alt: 6202m · 652km/h
  - (2026-05-28) JAF9WL (Belgium)
      icao24: 44d1a7 · position: (49.6019, 2.4849) · alt: 9700m · 842km/h
  - (2026-05-28) JAF3NE (Belgium)
      icao24: 44d1a5 · position: (47.0875, 0.3532) · alt: 10363m · 834km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 16 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-05-28) Will South Korea win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,978,414 · resolves 2026-07-20
  - (2026-05-28) US-Iran nuclear deal by May 31?
      yes price: 8% · 24h volume: $1,110,685 · resolves 2026-05-31
  - (2026-05-28) Will Donald Trump dance on May 25, 2026?
      yes price: 0% · 24h volume: $1,030,845 · resolves 2026-05-31
  - (2026-05-28) LoL: DN SOOPers vs Nongshim Red Force - Game 1 Winner
      yes price: 100% · 24h volume: $879,304 · resolves 2026-05-28
  - (2026-05-28) US announces new Iran agreement/ceasefire extension by May 31?
      yes price: 17% · 24h volume: $817,027
  - (2026-05-28) Will Sergio Pérez be the 2026 F1 Drivers' Champion?
      yes price: 0% · 24h volume: $805,739 · resolves 2026-12-06
  - (2026-05-28) Iran closes its airspace by May 27?
      yes price: 1% · 24h volume: $758,596 · resolves 2026-05-27
  - (2026-05-28) US x Iran permanent peace deal by June 7, 2026?
      yes price: 20% · 24h volume: $737,993 · resolves 2026-06-07

### Commentary & analysis (last 7 days) — 1 new of 6 total
  - (2026-05-28) [Marginal Revolution] My excellent Conversation with Toby Wilkinson
      Here is the audio, video, and transcript.  Most of all, we cover Ptolemaic Egypt.  Here is part of the episode summary: Tyler and Toby cover how Alexander took over the empire almost without a fight, why Alexandria becam

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=25, 14d-median=25; carrying terms: service, associated, issues, field, order, aircraft, designated, program, needed, repetitive, schedule, proposes
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=674, 7d-median=722, 14d-median=722
- local_news: today=237, 7d-median=265, 14d-median=265
- foreign_news: today=859, 7d-median=906, 14d-median=906
- chinese_internal: today=268, 7d-median=289, 14d-median=289
- russian_internal: today=1054, 7d-median=1054, 14d-median=1054
- ukrainian_internal: today=120, 7d-median=138, 14d-median=138
- ukraine_theater: today=365, 7d-median=394, 14d-median=394
- paper_bets: today=139, 7d-median=139, 14d-median=139
- weather: today=113, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=53, 7d-median=53, 14d-median=53
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: salud, smith, president, delgado, crespo, ortiz, green, jules, concepcion, trustees, roldan, solis
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: israel, strikes, nigeria, domain, canada, kingdom, language, english, india
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=29, 7d-median=29, 14d-median=29
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: announces, iranian, normal, hormuz, continue, regime, price, agreement, volume, extension, permanent, world
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: laugh, introduce, marginalrevolution, functions, economics, essay, policy, jisang, admit, review, https, story
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] ECB press: Financial stability vulnerabilities remain elevated as geoeconomic shock unfolds

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*