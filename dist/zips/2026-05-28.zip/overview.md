# WORLDSCOPE morning brief — 2026-05-28

## Headline
1569 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 0 new of 21 total
  (no new items today)

### State Legislative Action — 136 new of 136 total
  - (2026-05-28) [Alaska SB 2] An Act relating to disclosure of election-related deepfakes; relating to use of artificial intelligence by state agencies; and relating to transfer of data about individuals between state agencies.
      An Act relating to disclosure of election-related deepfakes; relating to use of artificial intelligence by state agencies; and relating to transfer of data about individuals between state agencies.
  - (2026-05-28) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contributions for public school funding; relating to municipal property 
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut
  - (2026-05-28) [Alaska HB 17] An Act relating to retirement benefits and military service.
      An Act relating to retirement benefits and military service.
  - (2026-05-28) [Alaska HB 121] An Act relating to the practice of accounting; relating to private professional conservators; amending Rule 17(e), Alaska Rules of Probate Procedure; and providing for an effective date.
      An Act relating to the practice of accounting; relating to private professional conservators; amending Rule 17(e), Alaska Rules of Probate Procedure; and providing for an effective date.
  - (2026-05-28) [Alaska HCR 6] Commemorating the 250th birthday of the United States Marine Corps.
      Commemorating the 250th birthday of the United States Marine Corps.
  - (2026-05-28) [Alaska SB 33] An Act relating to defamation claims based on the use of synthetic media; relating to the use of synthetic media in electioneering communications; and providing for an effective date.
      An Act relating to defamation claims based on the use of synthetic media; relating to the use of synthetic media in electioneering communications; and providing for an effective date.
  - (2026-05-28) [Alaska HB 381] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of revenue from the alternative volumetric tax; and providing for an 
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re
  - (2026-05-28) [Alaska HJR 13] Urging the President of the United States to expand evacuation efforts for applicants with approved Special Immigrant Visas, including resumption of evacuation flights organized by the Coordinator for Afghan Relocation Efforts; urging the United States Department of State to secure l
      Urging the President of the United States to expand evacuation efforts for applicants with approved Special Immigrant Visas, including resumption of evacuation flights organized by the Coordinator for Afghan Relocation E

### State-Level News — 38 new of 642 total
  - (2026-05-27) [California] New California law bans law enforcement from interfering in state elections
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 92 new of 236 total
  - (2026-05-28) [St. Louis] DOJ opens criminal investigation into Trump accuser E. Jean Carroll, reports say
      The Department of Justice is investigating E. Jean Carroll for possible perjury related to her civil lawsuits against Donald Trump, according to reports.
  - (2026-05-28) [St. Louis] Popular supplements recalled as FDA reopens investigation into salmonella outbreak
      Federal health officials have reopened a multistate salmonella investigation after 22 new cases emerged.
  - (2026-05-28) [St. Louis] US military conducts another strike against Iran after Trump says Iran is 'negotiating on fumes'
      President Donald Trump met with his Cabinet on Wednesday at a precarious moment for talks aimed at ending the war with Iran.
  - (2026-05-28) [St. Louis] Former CIA officer accused of stealing 300 gold bars worth more than $40 million
      David Rush was charged with criminal theft of public money after investigators found gold bars, about $2 million and luxury watches in his home, NBC News reported.
  - (2026-05-28) [St. Louis] Kyle Busch battled bacterial pneumonia for 'days to weeks' before rapid organ failure, death certificate shows
      Kyle Busch's death certificate, obtained by multiple outlets, reveals that the two-time NASCAR champion silently fought a severe lung infection for weeks.
  - (2026-05-28) [St. Louis] Metro East community exploring $20M fieldhouse to boost year-round sports tourism
      “We’re looking for an opportunity to continue the tourism in some of the winter months when a lot of the outdoor activities pack up for the season,” Van Hook said.
  - (2026-05-27) [St. Louis] Deputies in Spokane recover $70,000 stolen metal T-Rex statue buried underground
      The dinosaur, due to its extreme size and weight of about 400 pounds, had to be towed out of the ground by tow trucks.
  - (2026-05-27) [St. Louis] St. Louis police want drones in the sky. The mayor says not so fast
      The St. Louis Board of Police Commissioners approved a drone first responder program Wednesday, but Mayor Cara Spencer and commissioners slammed the rushed process.

### International News + Multilateral Institutions — 191 new of 858 total
  - (2026-05-28) [Global] US carries out new strikes on Iran military site
      It is the second time in three days that the US has attacked targets in Iran, threatening a fragile ceasefire.
  - (2026-05-28) [Global] Jill Biden says she thought husband was 'having a stroke' during 2024 debate
      The former US first lady told CBS News that she was frightened by Joe Biden's performance against Donald Trump.
  - (2026-05-27) [Global] Matthew Perry's assistant jailed for 41 months over actor's ketamine death
      Kenneth Iwamasa, who pleaded guilty last year to one count of conspiracy to distribute ketamine causing death, said he "will forever regret" his actions.
  - (2026-05-27) [Global] We analysed thousands of Trump's posts - here's what we found
      The BBC's Ros Atkins and BBC Verify sifted through thousands of the president's posts.
  - (2026-05-27) [Global] How my brother went from liberal Hollywood actor to manosphere 'messiah'
      The sister of Mexican influencer El Temach tells the BBC she does not recognise him any more.
  - (2026-05-27) [Global] Is 'out of control' US tipping culture spreading overseas?
      With US waiting staff getting cross at receiving less than 20%, tips are also on the rise elsewhere.
  - (2026-05-27) [Global] Paul McCartney on playing guitar with Paul Mescal: 'He knew it better than I did!'
      The music legend on delivering "memory songs" for his 20th solo album, The Boys of Dungeon Lane - and why he's intrigued by the new Beatles biopics.
  - (2026-05-27) [Global] An unhealthy focus on sex - Married at First Sight UK insiders on show's 'toxic' culture
      Fresh revelations come after two women told the BBC they had been raped on the Channel 4 reality show.

### Chinese Internal News — 246 new of 265 total
  - (2026-05-26) China’s Fiscal Revenue Improves but Spending Momentum Fades - Caixin Global
      <a href="https://news.google.com/rss/articles/CBMiswFBVV95cUxPNm9UZmo0bTVfTTgzWjZYeVRsRTdNQU9QYXdSdG4zTEhhc1psRk5iTnpFOHN2NWNKWXhlbnNLVU9SaXdHWWp6dlRXQmNCdzBOSEtqVDg5ZEhrSnNGUmlDZzVMWEdYVkxSbjZUd1pUOEZydGZYRlFUUWktWjNNcT
  - (2026-05-27) [TITLE: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlD] (zh: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlDRUx5b1ZMbmc3TmFqQVpGd1YyVk1NTm9R?oc=5" target="_blank">香港银行同步加强内地客监管 有
  - (2026-05-27) [TITLE: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3OD] (zh: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3ODJlTk9Hc1N4VEUxUEdRUzM4NzBDMThV?oc=5" target="_blank">电信诈骗版图南迁 自柬埔寨转向印尼</
  - (2026-05-27) [TITLE: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q] (zh: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q0t2MlR5Z0hQX2pYTl90ZWl0R3BBbXVFUE1r?oc=5" target="_blank">跨省履新仅8个月 “70后”高官李伟江
  - (2026-05-27) [TITLE: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNk] (zh: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNkd4djhVSzQ2dV96bmZwVzhvLUc3TW1ZTEQ0?oc=5" target="_blank">深圳一快速路段发生火灾 警方称无人受伤
  - (2026-05-26) [TITLE: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGh] (zh: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGhBenBsLXFZOVJxRl9xSmVnZHJHMUNB?oc=5" target="_blank">财经早知道｜深圳常住人口首破1
  - (2026-05-27) [TITLE: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHd] (zh: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHdyandPQXJnQW5YN2RmdU03U1FhOVFYV1Zn?oc=5" target="_blank">AI、石化产业链带动4月工业利
  - (2026-05-27) [TITLE: 全国31省份“十五五”规划纲要全部发布 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9WMXVXTjZnR1BidGRCMVlGelR6QnVJVnF1TU9ldkVELVJjLVgtMVhBQ0lpZllCV0xrZW9GNUNHQlVqMElxLS1KWVhkTXJWZ2RmWE] (zh: 全国31省份“十五五”规划纲要全部发布 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9WMXVXTjZnR1BidGRCMVlGelR6QnVJVnF1TU9ldkVELVJjLVgtMVhBQ0lpZllCV0xrZW9GNUNHQlVqMElxLS1KWVhkTXJWZ2RmWE1YMzNEeU9lWVJSZ0E?oc=5" target="_blank">全国31省份“十五五”规划纲要全部发布<

### Russian Internal News (state + in-exile) — 160 new of 941 total
  - (2026-05-28) [TITLE: "Его уберут": во Франции выступили с предупреждением по поводу Зеленского | LEDE: ] (ru: "Его уберут": во Франции выступили с предупреждением по поводу Зеленского)
  - (2026-05-28) [TITLE: В аэропорту Ульяновска ввели ограничения на полеты | LEDE: ] (ru: В аэропорту Ульяновска ввели ограничения на полеты)
  - (2026-05-28) [TITLE: Бундесверу очень далеко до статуса первой армии Европы, считает политик | LEDE: ] (ru: Бундесверу очень далеко до статуса первой армии Европы, считает политик)
  - (2026-05-28) [TITLE: Источник: представители Mitsubishi могли войти в состав делегации Японии | LEDE: ] (ru: Источник: представители Mitsubishi могли войти в состав делегации Японии)
  - (2026-05-28) [TITLE: ВСУ создали систему укрепрайонов в Воздвижевке, рассказал боец | LEDE: ] (ru: ВСУ создали систему укрепрайонов в Воздвижевке, рассказал боец)
  - (2026-05-28) [TITLE: В Минздраве рассказали, как вовремя распознать предиабет | LEDE: ] (ru: В Минздраве рассказали, как вовремя распознать предиабет)
  - (2026-05-28) [TITLE: Боец рассказал об освобождении Воздвижевки | LEDE: ] (ru: Боец рассказал об освобождении Воздвижевки)
  - (2026-05-28) [TITLE: СМИ: Пентагон ведет переговоры с фирмами о росте производства БПЛА | LEDE: ] (ru: СМИ: Пентагон ведет переговоры с фирмами о росте производства БПЛА)

### Ukrainian Internal News (national + local Kyiv) — 8 new of 112 total
  - (2026-05-28) [TITLE: Ціна підпілля. Що чекає на учасників руху опору окупації в тюрмі та на волі | LEDE: Жодна людина – не острів, сама по собі; кожен з нас – частина континенту... Смерть кожної людини зменшує і ме] (uk: Ціна підпілля. Що чекає на учасників руху опору окупації в тюрмі та на волі)
      Жодна людина – не острів, сама по собі; кожен з нас – частина континенту... Смерть кожної людини зменшує і мене, бо я єдиний з усім людством; а тому ніколи не питай, по кому дзвонить дзвін: він дзвонить і по тобі.
  - (2026-05-28) [TITLE: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані | LEDE: Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.] (uk: Військові США заявили, що вдарили по судну наркоторговців у Тихому океані)
      Американські військову вчергове заявили, що знищили судно наркотрафіку в Тихому океані.
  - (2026-05-28) [TITLE: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ | LEDE: Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.] (uk: Швеція планує оголосити про передачу і продаж Україні винищувачів Gripen – ЗМІ)
      Gripen для України: Швеція планує оголосити про передачу і продаж винищувачів.
  - (2026-05-28) [TITLE: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ | LEDE: За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.] (uk: США завдали нових ударів по військовому об'єкту в Ірані – ЗМІ)
      За даними ЗМІ, США здійснили нову атаку на військовий об'єкт Ірану.
  - (2026-05-28) [TITLE: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби ППО | LEDE: Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.] (uk: Під час перебування конгресменів США в Києві Зеленський обговорив з ними потреби)
      Двоє конгресменів США прибули до Києва, Зеленський провів з ними зустріч.
  - (2026-05-28) Trump Endorses Pashinyan Ahead of Crucial Armenia Vote
      US President Donald Trump endorsed Armenian Prime Minister Nikol Pashinyan ahead of a key parliamentary election, praising his peace agenda and plans for the US-backed “Trump Route” corridor. The endorsement came a day a
  - (2026-05-28) Ukraine to Be Fully Integrated Into EU Air Defense, Drone Priorities, Von der Leyen Says
      European Commission President Ursula von der Leyen said Ukraine will be included in Europe’s urgent defense efforts, backed by a €28.3 billion loan for Kyiv’s military needs.
  - (2026-05-28) Sybiha Calls for Airport or Seaport Truce as First Step Toward Peace
      Foreign Minister Andrii Sybiha said Europe should first push for a limited airport or seaport truce, using sanctions and frozen Russian assets to press Moscow toward practical peace steps.

### Ukraine Theater (total-war monitoring) — 220 new of 394 total
  - (2026-05-28) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-25) [Liveuamap] Russian FM Lavrov informed State Secretary Rubio that Russia will intensify strikes on Kyiv. Lavrov urged Rubio to evacuate U.S. citizens and diplomatic staff from Kyiv Moskva, Moscow - Ukraine Interactive map - Ukraine Latest news on live 
      <a href="https://news.google.com/rss/articles/CBMikgFBVV95cUxQTkE1MmhVLXlxWmVTMW45QlppeVlWOVFva1ZNbUpRdU85eksxb0U3dS1qdW52bFlOWlhLNTQ3aHdKMWdzUFRfbXBwRzF5YW1rdklmQXpoRE5qQ2x1eHk0MVl4YWtTQmhnVEcxcmpGUF9xb0JuOXllcDY5UDNsXz
  - (2026-05-28) [Liveuamap] Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com - iran.liveuamap.com
      <a href="https://news.google.com/rss/articles/CBMiQEFVX3lxTE1kU0J1MFhkT0JLY29aZnc5TzYzbE1KTTFaQ19pR0JEZ2Zaay1JWFJSSkp2eWp1S1BxVVlub3Y0djQ?oc=5" target="_blank">Iran news on live map in English - War in Iran - Conflict in
  - (2026-05-26) [Liveuamap] The U.S. Navy has resumed escorting ships through the Strait of Hormuz under a renewed “Project Freedom” mission. A Greek supertanker carrying two million barrels of crude was recently guided through the route after being stranded in the Gu
      <a href="https://news.google.com/rss/articles/CBMilwFBVV95cUxPaW5lLXY3NUJLY0ItLUJxZThHc2M4c1ExQjFYVzNrQUlUZENnZlppel9mc3dMUTRoem1LUllkT3liOTFCeGgwX0JZbTVvdjRrWUJrRUh2cnBWS1ZhOEpzZGFHX3M4UWFvdUdkLV9ERU1vcjFnYmVVd0Zza1VaRz
  - (2026-05-27) [Liveuamap] Explosions were reported at the airbase in Voronezh - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxNZHgyQi1oNThuX1BJa2lEdHRaTERPWVREQkF1RE5MUTQ5WUhRQjJha0RYRDhTeFQyOWJoU1k4aW42V0RZNXpRRTdUUUdzYWdnUXRzRThhTkNkUkdZRm1BbE9qVWhNeFVORGh4Z2tQcENGajlqSWxwbVltZ1N0V1
  - (2026-05-27) [Liveuamap] President Zelensky sent a letter to President Trump and to Congress asking for urgent supply of Patriot interceptors - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxQaDZhbTFQc0FlTzNaSWxIa1k0R0g2LWFIZnN0REZieU9IRUNIRmswNXRqMEV6OVJTTHdWWFR6Q2k5T3dpTjVfb2JjQk44eGJsaWRXV3RhWmdFM1RxZ1VVdDhmajg2ZDlBVnNQREFYSW1uSG42YUp6VUwyeGFhT0
  - (2026-05-27) [Liveuamap] The Israelis notified the Trump administration that they escalate their attacks on Lebanon following a drone attack by Hezbollah tonight Tel Aviv-Yafo, Tel Aviv District - Lebanon news on live map - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMimgFBVV95cUxPbkJMUHd6ak9uQzR0T1hwQzNvbzZFZDF2SHlQTVdKVFdKMy1vUjBLYXJ0YnJmWU9hS3haNC1MNF9NUlZnbkZzaDg2N3c2R1N1TVd5ODRkZ3BycDBMOW55cXpWU2d0ZC1aRTZYT1ZWY1l0YjdyS0libjJ2ajFZQW
  - (2026-05-26) [Liveuamap] Israeli airstrike on the outskirts of the Abbasiya area in the Tyre district of southern Lebanon - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMinwFBVV95cUxPZ3FUcEZYN3YzdDdsMHpJMDFVMzlvOWMxTHh4bDVRZmhzenVGdURYXy05WTZmbkJ3cEZEeldpS2FBcVhYZ2VMcHZHVjZVcHcyOVpGQWpGT21FYUZ5cmxrc1JHS0hnbFVwOVR3TXRyVFdqbE5nWEdtZXdKSG9man

### Paper Trading Scorecard — 5 new of 138 total
  - (2026-05-28) [Polymarket] Will Club Bolívar win on 2026-05-27?
      In the upcoming game, scheduled for May 27, 2026
If Club Bolívar wins, this market will resolve to "Yes".
Otherwise, this market will resolve to "No".
If the game is postponed, this market will remain open until the game
  - (2026-05-28) [Polymarket] LoL: Supernova vs Winthrop University (BO5) - North American Challengers League Playoffs
      This market refers to the LoL Lower bracket quarterfinal match between Supernova and Winthrop University in the North American Challengers League Playoffs, initially scheduled for May 27 at 4:00PM ET.

This market will r
  - (2026-05-28) [Polymarket] Will Anthropic have the best Math AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab for "Math"
  - (2026-05-28) [Polymarket] Will there be between 10 and 20 average daily transits of the Strait of Hormuz on May 31?
      This market will resolve according to the 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz that IMF Portwatch reports for May 31, 2026.

If the reported value falls exactly between two
  - (2026-05-28) [Manifold] Will "Contra Wentworth on Physical Attractiveness f..." make the top fifty posts in LessWrong's 2026 Annual Review?

### U.S. Weather + Severe / Climate Outlooks — 54 new of 102 total
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 8:53PM MDT until May 27 at 9:30PM MDT by NWS Albuquerque NM
      At 853 PM MDT, a severe thunderstorm was located 6 miles north of
Watrous, or 19 miles southwest of Wagon Mound, moving southeast at 10
mph.

HAZARD...60 mph wind gusts and half dollar size hail.

SOURCE...Radar indicate
  - (2026-05-27) [Severe] Special Marine Warning: Special Marine Warning issued May 27 at 10:52PM EDT until May 27 at 11:00PM EDT by NWS Newport/Morehead City NC
      The affected areas were...
Waters from Currituck Beach Light to Oregon Inlet NC from 20 to 60
NM...
Waters from Oregon Inlet to Cape Hatteras NC from 20 to 60 NM...

The thunderstorms have weakened and no longer pose a s
  - (2026-05-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 9:46PM CDT until May 27 at 10:30PM CDT by NWS Norman OK
      SVROUN

The National Weather Service in Norman has issued a

* Severe Thunderstorm Warning for...
Northern Knox County in northern Texas...

* Until 1030 PM CDT.

* At 946 PM CDT, a severe thunderstorm was located near T
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 8:46PM MDT until May 27 at 9:15PM MDT by NWS Albuquerque NM
      At 846 PM MDT, a severe thunderstorm was located 10 miles southeast
of Valmora, or 19 miles south of Wagon Mound, moving southeast at 15
mph.

HAZARD...Ping pong ball size hail and 60 mph wind gusts.

SOURCE...Radar indi
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 10:43PM EDT by NWS Jackson KY
      At 1043 PM EDT, Doppler radar was tracking a strong thunderstorm over
Whisman, or near Campton, moving east at 30 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IMPACT...Gusty winds
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 9:42PM CDT by NWS Norman OK
      At 941 PM CDT, Doppler radar was tracking a strong thunderstorm 4
miles northwest of Truscott, moving southeast at 25 mph.

HAZARD...Wind gusts up to 50 mph and penny size hail.

SOURCE...Radar indicated.

IMPACT...Gusty
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 10:42PM EDT until May 28 at 11:22AM EDT by NWS Wilmington OH
      ...The Flood Warning is extended for the following rivers...

Mad River near Springfield.

* WHAT...Minor flooding is occurring and minor flooding is forecast.

* WHERE...Mad River near Springfield.

* WHEN...Until late 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 20 new of 95 total
  - (2026-05-27) [OFAC] International Criminal Court-related Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoYmsxWDE3WFh2VzgyWDZ2Y2xnSVJHZzFTTnUtUlM5Z0tOMktfbXRkUmJhMmdHa2wwM19JRnhiWkwxdENoT0owTkx0cEU0ZmdIUk5CVGFjZ2cxbDJOS2c?oc=5" target="_blank">International Crimin
  - (2026-05-28) [OFAC] Iran-related Designation; Counter Terrorism Designation - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1wZHZVOFR1Yy1MSzRFaERsQlZWWmFCSV9fcUQ5eFpEWVdtV3N2dFFZdFlqWG9ldkNFNTBGdjRBSHVrdTlwNmhRT2xndXotaHlyakdWdXpvS2Fkek5QY0UwWG9B?oc=5" target="_blank">Iran-related De
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-28) [USASpending] $534,079,951 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
      Agency: General Services Administration.  Description: SYSTEM SOFTWARE LIFECYCLE ENGINEERING SSLE
  - (2026-05-28) [USASpending] $486,224,471 → LOCKHEED MARTIN CORPORATION: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTR
      Agency: National Aeronautics and Space Administration.  Description: TAS::80 0110::TAS GEOSTATIONARY LIGHTNING MAPPER (GLM) INSTRUMENT THE FOR GEOSTATIONARY OPERATIONAL ENVIRONMENTAL SATELLITES (GOES) R.  THE CONTRACTOR 
  - (2026-05-28) [USASpending] $432,416,292 → LEIDOS BIOMEDICAL RESEARCH INC: NCI OPERATIONAL TASK ORDER
      Agency: Department of Health and Human Services.  Description: NCI OPERATIONAL TASK ORDER
  - (2026-05-28) [USASpending] $406,089,353 → AERODYNE-SGT ENGINEERING SERVICES, LLC: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEER
      Agency: National Aeronautics and Space Administration.  Description: THE MIST II CONTRACT WILL PROVIDE MULTIDISCIPLINARY ENGINEERING TASK ORDERS FOR THE FORMULATION, DESIGN, DEVELOPMENT, FABRICATION, INTEGRATION, TESTING
  - (2026-05-28) [USASpending] $405,028,920 → VERIZON BUSINESS NETWORK SERVICES LLC: CENTRALIZED HHS EIS REQUIREMENT
      Agency: Department of Health and Human Services.  Description: CENTRALIZED HHS EIS REQUIREMENT

### Congressional STOCK Act Trades (House + Senate) — 0 new of 1 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 0 new of 30 total
  (no new items today)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-28) [WHEELER SIMON] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000144 Size: 24 KB
  - (2026-05-28) [RAWLINGS DARRYL] Form 4 (Reporting)
      filed 2026-05-28 01:57 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [TRUPANION, INC.] Form 4 (Issuer)
      filed 2026-05-28 01:57 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001371285-26-000143 Size: 8 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:55 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Ollet John] Form 4 (Reporting)
      filed 2026-05-28 01:55 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025500 Size: 5 KB
  - (2026-05-28) [Lerman Michael Stuart] Form 4 (Reporting)
      filed 2026-05-28 01:53 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB
  - (2026-05-28) [HEALTHY CHOICE WELLNESS CORP.] Form 4 (Issuer)
      filed 2026-05-28 01:53 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025499 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 0 new of 27 total
  (no new items today)

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 16 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 4 new of 20 total
  - (2026-05-28) US announces new Iran agreement/ceasefire extension by May 31?
      yes price: 20% · 24h volume: $764,020
  - (2026-05-28) Houston Astros vs. Texas Rangers
      yes price: 100% · 24h volume: $728,997 · resolves 2026-06-04
  - (2026-05-28) Thunder vs. Spurs
      yes price: 40% · 24h volume: $719,433 · resolves 2026-05-29
  - (2026-05-28) Will Germany win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $714,717 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 0 new of 6 total
  (no new items today)

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25; carrying terms: unsafe, manufacturing, required, directive, coast, needed, specifically, including, events, fishing, bombardier, previously
- state_bills: today=136, 7d-median=136, 14d-median=136
- state_news: today=642, 7d-median=722, 14d-median=722
- local_news: today=236, 7d-median=265, 14d-median=265
- foreign_news: today=858, 7d-median=906, 14d-median=906
- chinese_internal: today=265, 7d-median=289, 14d-median=289
- russian_internal: today=941, 7d-median=1021, 14d-median=1021
- ukrainian_internal: today=112, 7d-median=138, 14d-median=138
- ukraine_theater: today=394, 7d-median=394, 14d-median=394
- paper_bets: today=138, 7d-median=138, 14d-median=138
- weather: today=102, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: chavez, smith, pimental, balazs, docks, sociedad, federation, caribbean, suburban, scott, mcpherson, webuild
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: strait, regime, announces, world, bitcoin, coast, permanent, volume, ivory, traffic, price, continue
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: stuff, seminars, approaches, jisang, recent, academic, production, agricultural, admit, rejesus, functions, introduce
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*