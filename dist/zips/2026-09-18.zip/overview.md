# WORLDSCOPE morning brief — 2026-09-18

## Headline
3387 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (835) · Russian Internal News (state + in-exile) (730) · State-Level News (357) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (280) · Chinese Internal News (226) · Local News: St. Louis + Atlanta (217) · U.S. Weather + Severe / Climate Outlooks (105) · Ukrainian Internal News (national + local Kyiv) (66) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (39) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 835 new of 1075 total
  - (2026-09-18) [Global] British woman who was kidnapped in Malawi rescued by police after shootout
  - (2026-09-18) [Global] Louisiana firefighters find feline native to sub-Saharan Africa while responding to house fire
  - (2026-09-18) [Global] ‘We demand the truth’: Olga Tokarczuk and JM Coetzee lead calls for proof of life of disappeared Eritrean writers
  - (2026-09-18) [Global] Almost 50 dead in Nigeria after drinking alcohol suspected to contain methanol
  - (2026-09-17) [Global] New cat species identified for first time in more than a century in Bolivia
  - (2026-09-17) [Global] All smiles in Strasbourg but uncertainty clouds Canada’s EU membership plan

### Russian Internal News (state + in-exile) — 730 new of 1164 total
  - (2026-09-18) Война . 1668-й день. Конгресс: принимает «адские санкции» против России. Трамп: планирует бизнес-сделки с Кремлем еще до окончания войны | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфир] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-18) Уоррен Баффетт ушел с поста председателя совета директоров Berkshire Hathaway | LEDE: 96-летний инвестор Уоррен Баффетт покинул пост председателя совета директоров компании Berkshire Hathawa] (ru: Уор…
      96-летний инвестор Уоррен Баффетт покинул пост председателя совета директоров компании Berkshire Hathaway, сообщает The New York Times.
  - (2026-09-18) Игроков «Реала» попросили выйти на матч в футболках со слоганом в поддержку жителей Сеуты. Они вышли — но некоторые тут же спрятали майки. Мбаппе объяснил, что хочет поддерживать и жителей Сеут] (ru:…
      Вечером 15 сентября состоялся обычный матч испанской Ла Лиги — «Эльче» из одноименного города принимал мадридский «Реал». Перед выходом на поле игрокам раздали футболки с надписью Todos somos caballas («Все мы из Сеуты»)…
  - (2026-09-18) Bloomberg: на фоне слухов о мобилизации российские чиновники пытаются вывести активы за границу и открыть счета в иностранных банках | LEDE: В последние месяцы высокопоставленные российские ] (ru: Blo…
      В последние месяцы высокопоставленные российские чиновники на фоне слухов про новую мобилизацию пытаются открыть счета в зарубежных банках и перевести свои активы за границу. Об этом пишет Bloomberg со ссылкой на некие д…
  - (2026-09-18) Россиянин приплыл из Калининградской области в Литву и попросил убежище. Его отправили обратно в Россию | LEDE: Сотрудники пограничной службы Литвы задержали и отправили обратно в Россию гра] (ru: Рос…
      Сотрудники пограничной службы Литвы задержали и отправили обратно в Россию гражданина РФ, который приплыл в страну по реке Неман и попросил политическое убежище. Об этом пишет издание Lrytas.
  - (2026-09-18) В Москве пропала кандидатка в Госдуму от партии «Зеленые» Юлия Кузнецова | LEDE: Кандидатка в Госдуму от партии «Зеленые» Юлия Кузнецова перестала выходить на связь вечером 17 сентября, сооб] (ru: В М…
      Кандидатка в Госдуму от партии «Зеленые» Юлия Кузнецова перестала выходить на связь вечером 17 сентября, сообщает проект «Слово защите».

### State-Level News — 357 new of 774 total
  - (2026-09-17) [Alabama] Prisoner of War & Missing in Action Day
      Download
  - (2026-09-18) [California] Governor Newsom announces appointments 9.17.2026
      Source
  - (2026-09-17) [California] Governor Newsom proclaims Constitution Day and Citizenship Day
      Source
  - (2026-09-17) [California] Governor Newsom delivers on pledge to provide new financing options for Eaton and Palisades survivors
      Source
  - (2026-09-17) [California] Trump wants to send a check? Pay Americans back the $108 billion his Iran War cost them at the pump first
      Source
  - (2026-09-18) [California] California must defend the ocean and beaches from Trump’s new plans for offshore drilling
      <img width="1024" height="667" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/04/052115-Refugio-State-Beach-Oil-Spill-AP-CM-01.jpg?fit=1024%2C667&ssl=1" class="attachment-rss-image-size size-rss-image-size…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 280 new of 465 total
  - (2026-09-18) [DeepStateMap] frontline snapshot, 527 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-17) [FIRMS] thermal anomaly 45.258, 31.676 (FRP 4.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-17 0941Z, FRP 4.25 MW
  - (2026-09-17) [FIRMS] thermal anomaly 46.914, 34.712 (FRP 18.89 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-17 0941Z, FRP 18.89 MW
  - (2026-09-17) [FIRMS] thermal anomaly 46.912, 34.707 (FRP 14.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-17 0941Z, FRP 14.91 MW
  - (2026-09-17) [FIRMS] thermal anomaly 46.919, 34.708 (FRP 18.89 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-17 0941Z, FRP 18.89 MW
  - (2026-09-17) [FIRMS] thermal anomaly 46.920, 34.713 (FRP 18.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-17 0941Z, FRP 18.89 MW

### Chinese Internal News — 226 new of 284 total
  - (2026-09-18) 【商圈】德国大众裁员迈出关键一步 CEO奥博穆如何推进艰难改革？ - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE01Rm54T1JyeGplYzVpWk1zR3hfWUFjSUR2cHVoUzQ0bkhDT3dtVVlRNVFnc2Fna3NOaXhx] (zh:…
      【商圈】德国大众裁员迈出关键一步 CEO奥博穆如何推进艰难改革？ database.caixin.com
  - (2026-09-18) 美联储加息落地 人民币兑美元汇率不贬反升破6.7 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1JR1plajJ1QmVCc1hKVnozX2c5YU5iNEUteEZxODE5ZzRfbGttWjQ2TGRPMHVKREM0QndrY2dJWEVzcU5hS1U4S1dNQVhvc] (zh:…
      美联储加息落地 人民币兑美元汇率不贬反升破6.7 财新
  - (2026-09-18) 没有一只帝王蝶，能走完整个旅程｜自然 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5pNHNEb0x5MDkxdnJZdXRwaFowN2hZUGZRaXhkWEN5MV9iTnpwelpJaXhaLW1Wc0laTWpqeHFzUzBFcVlqRmFoYmd4c2pfTUJPTVV] (zh:…
      没有一只帝王蝶，能走完整个旅程｜自然 财新
  - (2026-09-18) 火线评论｜徐湖平案了犹未了，博物馆管理新办法可否不负期待？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE03ZGtfUmdCQVA0bTlwaVh5SVpST1l4dDZzYlkwQ1FLMU9jQTMxZGZKeEVUZW05dTkxc0VuTlpUUmFrNzZOSWRtd0h0] (zh:…
      火线评论｜徐湖平案了犹未了，博物馆管理新办法可否不负期待？ 财新
  - (2026-09-18) 免费AI到底在赚什么 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8xbVRRRUZ0UkdLbGhWYjJ1NW9yQlEtbmVjOG5idlhPbF9QVlJWR3c3THdlQ3NKdUVZb0dQQ3ZaTF9DUUFOdFlCQjJxRU9NQWVzd29USGtqdWF] (zh:…
      免费AI到底在赚什么 财新
  - (2026-09-18) 今日开盘：两市双双高开 沪指涨幅0.42% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFB2a1htdHpZajB6d0VoX09oVjFFeDJKOWgxY0hleThUdl9MdWxZb3BBNFhIY2IydnczYVBUNl9FdjVyaldHWG5LSTJHazVuVmlL] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.42% 财新

### Local News: St. Louis + Atlanta — 217 new of 244 total
  - (2026-09-18) [St. Louis] Why St. Louis keeps seeing more restaurant openings than closings
      If the restaurant business is so tough, why do openings consistently outpace closings in St. Louis? — Emmy E., St. LouisOn the surface, it seems like a contradiction. Restaurant owners routinely cite rising food and labo…
  - (2026-09-18) [St. Louis] Artist-designed calisthenics park offers Gravois Park a place to exercise
      South City’s new calisthenics pocket park owes its existence to an only-in-St. Louis combination: A faith-based organization with free space to offer. A rising star artist with a passion for exercise. And a regional agen…
  - (2026-09-18) [St. Louis] What’s True in the Lou? – 9/18/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-09-17) [St. Louis] Royal Banks of Missouri expands its St. Louis footprint while staying local
      At a time when banking can happen almost entirely through a screen, Royal Banks of Missouri is investing in a different idea of what customers may still want from their bank. The locally owned institution is growing acro…
  - (2026-09-17) [St. Louis] Hit Missouri’s rail-trails in documentary ‘The Trail State’
      A new documentary seeks to capture the beauty and importance of former Missouri railways that have received a second life as bike trails. The film, The Trail State, will have its St. Louis premiere at the St. Louis Histo…
  - (2026-09-17) [St. Louis] St. Louis spots for kids who love planes, trains, and automobiles
      TRAINS Wabash, Frisco, and Pacific Railroad All aboard this hidden-gem family destination in Glencoe, where miniature trains carry passengers through the woods along the Meramec River. The approximately 40-minute journey…

### U.S. Weather + Severe / Climate Outlooks — 105 new of 107 total
  - (2026-09-18) [Moderate] Special Weather Statement: Special Weather Statement issued September 18 at 5:57AM MDT by NWS Salt Lake City UT
      At 556 AM MDT, Doppler radar was tracking a strong thunderstorm 9 miles north of Utah Test and Training Range North, or 50 miles east of Montello, moving northeast at 35 mph. HAZARD...Penny size hail. SOURCE...Radar indi…
  - (2026-09-18) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-18) [Moderate] Special Weather Statement: Special Weather Statement issued September 18 at 5:51AM MDT by NWS Salt Lake City UT
      At 551 AM MDT, Doppler radar was tracking a strong thunderstorm 10 miles east of Utah Test and Training Range North, or 44 miles northwest of Grantsville, moving northeast at 35 mph. HAZARD...Penny size hail. SOURCE...Ra…
  - (2026-09-18) [Moderate] Special Weather Statement: Special Weather Statement issued September 18 at 3:49AM AKDT by NWS Juneau AK
      Heavy rain and strong winds are expected to start Friday and last through the weekend as multiple strong low pressure systems move into the northern gulf. These lows will bring multiple days of moderate to heavy rain, wi…
  - (2026-09-18) [Moderate] Gale Warning: Gale Warning issued September 18 at 3:47AM AKDT until September 19 at 5:00PM AKDT by NWS Anchorage AK
      Offshore waters forecast for the Gulf of Alaska West of 144W Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and…
  - (2026-09-18) [Moderate] Gale Warning: Gale Warning issued September 18 at 3:47AM AKDT until September 19 at 5:00PM AKDT by NWS Anchorage AK
      Offshore waters forecast for the Gulf of Alaska West of 144W Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and…

### Ukrainian Internal News (national + local Kyiv) — 66 new of 136 total
  - (2026-09-18) Китай, Індія і Туреччина можуть потрапити під тарифи після підписання "закону Грема" | LEDE: Після того, як президент США Дональд Трамп підпише законопроєкт щодо "пекельних санкцій" імені покій] (uk:…
      Після того, як президент США Дональд Трамп підпише законопроєкт щодо "пекельних санкцій" імені покійного сенатора Ліндсі Грема, під дію тарифів можуть потрапити, зокрема Китай, Індія і Туреччина.
  - (2026-09-18) Самобутні, ціннісні та сміливі – УП100 шукає майбутніх лауреатів премії 2026 | LEDE: Залишилося 13 днів до завершення прийому заявок на щорічну премію УП100. Це премія "Української правди", яко] (uk:…
      Залишилося 13 днів до завершення прийому заявок на щорічну премію УП100. Це премія "Української правди", якою редакція відзначає сто українців, що беруть на себе відповідальність, провадять зміни та визначають майбутнє к…
  - (2026-09-18) Столар стверджує, що не може внести заставу через перепони банків | LEDE: Нардеп Вадим Столар заявив, що банки блокують переказ його коштів для застави, визначеної ВАКС у справі НАБУ і САП "Фем] (uk:…
      Нардеп Вадим Столар заявив, що банки блокують переказ його коштів для застави, визначеної ВАКС у справі НАБУ і САП "Феміда".
  - (2026-09-18) У ЄС не змогли домовились про продовження санкцій проти Путіна і Лаврова | LEDE: Комітет постійних представників ЄС (Coreper) знову не зміг домовитися щодо продовження санкцій Євросоюзу проти Р] (uk:…
      Комітет постійних представників ЄС (Coreper) знову не зміг домовитися щодо продовження санкцій Євросоюзу проти Росії за порушення територіальної цілісності України та призначив наступну зустріч на понеділок, 21 вересня.
  - (2026-09-18) В.о. генпрокурора розповів про робочі плани і про те, як співпрацюватиме з НАБУ і САП | LEDE: В.о. генпрокурора Антон Ковальський повідомив, на чому планує зосередитись у перші дні своєї роботи] (uk:…
      В.о. генпрокурора Антон Ковальський повідомив, на чому планує зосередитись у перші дні своєї роботи на посаді, та пообіцяв "професійно і в межах закону" взаємодіяти з НАБУ і САП.
  - (2026-09-18) Поблизу столиці Молдови знайшли уламки дрона | LEDE: Поблизу Кишинева молдовська поліція знайшла уламки безпілотника – вибух мешканці передмістя чули вночі напередодні.] (uk: Поблизу столиці Молдови з…
      Поблизу Кишинева молдовська поліція знайшла уламки безпілотника – вибух мешканці передмістя чули вночі напередодні.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-18) 424B3 - CoinShares PLC (0002087587) (Filer)
      filed 2026-09-18 12:00 UTC — Filed: 2026-09-18 AccNo: 0001213900-26-101142 Size: 14 MB
  - (2026-09-18) [Lyons Michael P.] Form 4 (Reporting)
      filed 2026-09-18 11:52 UTC · role: Reporting — Filed: 2026-09-18 AccNo: 0001534574-26-000016 Size: 8 KB
  - (2026-09-18) [TRUIST FINANCIAL CORP] Form 4 (Issuer)
      filed 2026-09-18 11:52 UTC · role: Issuer — Filed: 2026-09-18 AccNo: 0001534574-26-000016 Size: 8 KB
  - (2026-09-18) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-09-18 11:47 UTC — Filed: 2026-09-18 AccNo: 0001918704-26-028033 Size: 907 KB
  - (2026-09-18) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-09-18 11:47 UTC — Filed: 2026-09-18 AccNo: 0001918704-26-028033 Size: 907 KB
  - (2026-09-18) [Adelborg Auste] Form 4 (Reporting)
      filed 2026-09-18 11:43 UTC · role: Reporting — Filed: 2026-09-18 AccNo: 0002089844-26-000003 Size: 4 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 57 total
  - (2026-09-18) [BleepingComputer] New Check Point flaw lets hackers execute code with root privileges
      Check Point Software has released security updates to address a critical vulnerability that can let attackers execute code with root privileges on management systems. [...]
  - (2026-09-18) [BleepingComputer] Microsoft fixes broken copy and paste for Excel 2016 users
      Microsoft has fixed a known issue that causes copy-and-paste failures for some Excel users after installing the September 2026 KB5002914 security update. [...]
  - (2026-09-18) [The Hacker News] WeaselBiscuit Stealer Spreads via 13 npm Packages to Harvest Chrome Extension Storage
      Cybersecurity researchers have discovered a cluster of 13 npm packages that have been found to deliver a previously undocumented JavaScript stealer codenamed WeaselBiscuit. The new malware family, per OpenSourceMalware,…
  - (2026-09-18) [The Hacker News] Claimed Bug Bounty Hunter Likely Used LLM to Build PhantomRaven npm Stealer
      A financially motivated threat actor has been linked to the development and distribution of a JavaScript (JS)-based information stealer known as PhantomRaven via the npm package registry. "The developer likely wrote the…
  - (2026-09-18) [The Hacker News] RatHat Android Malware Abuses ADB to Retain Shell Access After Uninstall
      Cybersecurity researchers have flagged a new Android malware called RatHat that's assessed to be operated by China-based threat actors and features an artificial intelligence (AI)-powered system to navigate and control c…
  - (2026-09-18) [Schneier on Security] Are AIs Still Struggling with CAPTCHAs?
      Anthropic’s recent security-incident document contains a bit about how CAPTCHAs are still frustrating Claude. In the transcript, the Claude model that is so powerful that Anthropic is gatekeeping access to it appeared to…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-09-18) JAF50T (Bulgaria)
      icao24: 4520ce · position: (42.0579, -2.2345) · alt: 11277m · 974km/h
  - (2026-09-18) PAT768 (United States)
      icao24: adfe8d · position: (35.6841, -80.2248) · alt: 4305m · 533km/h
  - (2026-09-18) PAT121 (United States)
      icao24: adfec9 · position: (35.1144, -91.7322) · alt: 5341m · 371km/h
  - (2026-09-18) GAF172 (Germany)
      icao24: 3f7588 · position: (49.7453, 17.5646) · alt: 1821m · 434km/h
  - (2026-09-18) PUMA74 (Slovenia)
      icao24: 506e1c · position: (45.8999, 15.5358) · alt: 182m · 138km/h
  - (2026-09-18) PAT977 (United States)
      icao24: ae08fc · position: (32.7726, -97.3251) · alt: 1470m · 427km/h

### Court opinions of consequence (federal & state) — 22 new of 60 total
  - (2026-09-17) U.S. Court of Appeals, 11th Cir.: United States v. Kevan Carter Gibbs, II
  - (2026-09-17) U.S. Court of Appeals, 5th Cir.: Rash v. Lafayette County, MS
  - (2026-09-17) U.S. Court of Appeals, 2nd Cir.: E.
  - (2026-09-17) U.S. Court of Appeals, 2nd Cir.: Nemis v. Blanche
  - (2026-09-17) U.S. Court of Appeals, 2nd Cir.: Soroban Capital Partners LP v. Commissioner of Internal Revenue
  - (2026-09-17) U.S. Court of Appeals, 2nd Cir.: United States v. Alisigwe

### U.S. Federal Action — 18 new of 18 total
  - (2026-09-18) Presidential Determination on Major Drug Transit or Major Illicit Drug Producing Countries for Fiscal Year 2027
  - (2026-09-18) Employment in the Excepted Service
      The Office of Personnel Management (OPM) proposes to amend its regulations governing the excepted service, Pathways Programs, and administrative law judge (ALJ) appointments. The proposed rule would conform OPM regulatio…
  - (2026-09-18) International Traffic in Arms Regulations: Modification of U.S. Munitions List Category XX(a)
      The Department of State (the Department) amends the International Traffic in Arms Regulations (ITAR) to remove from the U.S. Munitions List (USML) certain uncrewed underwater vehicles (UUVs) and make conforming changes t…
  - (2026-09-18) Homeland Security Acquisition Regulation, Make Personal Protective Equipment in America Act Restrictions on Foreign Acquisition (HSAR Case 2024-003)
      DHS is issuing a final rule to amend the Homeland Security Acquisition Regulation (HSAR) codifying how DHS complies with the requirements of the Make Personal Protective Equipment (PPE) in America Act. These changes are…
  - (2026-09-18) Coral, Coral Reefs, and Live/Hardbottom Habitats of the South Atlantic and the Shrimp Fishery of the South Atlantic Region; Amendments 11/12
      The South Atlantic Fishery Management Council (Council) has submitted Amendment 11 to the Fishery Management Plan for Coral, Coral Reefs, and Live/Hardbottom Habitats of the South Atlantic (Coral FMP) and Amendment 12 to…
  - (2026-09-18) Milk in the Northeast and Other Marketing Areas; Uniform Pricing Formula Provisions
      The Agricultural Marketing Service's (AMS) Dairy Program published a final rule in the Federal Register on January 17, 2025, amending the pricing provisions in the 11 Federal Milk Marketing Orders (FMMOs). This document…

### Paper Trading Scorecard — 18 new of 129 total
  - (2026-09-18) [Polymarket] Will a team from LCK (South Korea) win LoL Worlds 2026?
      This market will resolve according to the region or country of the esports team winning 1st place in the League of Legends 2026 Season World Championship (Worlds 2026). If the winner of Worlds 2026 is not determined by D…
  - (2026-09-18) [Manifold] Will Elon Musk and Donald Trump appear together in the same new photo or video on X before October 1, 2026?
  - (2026-09-18) [Manifold] Will there be a second Jev-style decision output model on OpenRouter by end October?
  - (2026-09-18) [Manifold] Will USA break its continuous human presence in outer space before 2040?
  - (2026-09-18) [Manifold] PMF or Die (AI Forecasting Edition)
  - (2026-09-18) [Manifold] Will Metroid Ravenous win Game of the Year at the Game Awards?

### State Legislative Action — 16 new of 78 total
  - (2026-09-18) [Alaska HB 249] An Act relating to the transfer of a vehicle to an insurance company.
      An Act relating to the transfer of a vehicle to an insurance company.
  - (2026-09-18) [Alaska HB 125] An Act relating to membership of the Board of Fisheries.
      An Act relating to membership of the Board of Fisheries.
  - (2026-09-18) [Alaska SB 147] An Act relating to the prescription and administration of drugs and devices by pharmacists; relating to reciprocity for pharmacists; and providing for an effective date.
      An Act relating to the prescription and administration of drugs and devices by pharmacists; relating to reciprocity for pharmacists; and providing for an effective date.
  - (2026-09-18) [Alaska HB 191] An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
      An Act establishing the Alaska Invasive Species Council in the Department of Fish and Game; relating to management of invasive species; and providing for an effective date.
  - (2026-09-18) [Alaska SB 29] An Act establishing an executive administrator position for the Board of Dental Examiners; and relating to an executive administrator for the Big Game Commercial Services Board.
      An Act establishing an executive administrator position for the Board of Dental Examiners; and relating to an executive administrator for the Big Game Commercial Services Board.
  - (2026-09-18) [Alaska SB 40] An Act establishing the period between September 15 and October 15 of each year as Hispanic Heritage Month.
      An Act establishing the period between September 15 and October 15 of each year as Hispanic Heritage Month.

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-09-18) LoL: Team WE vs JD Gaming - Game 3 Winner
      yes price: 0% · 24h volume: $1,388,596 · resolves 2026-09-18
  - (2026-09-18) LoL: Team WE vs JD Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $1,349,021 · resolves 2026-09-18
  - (2026-09-18) Counter-Strike: MOUZ vs Natus Vincere (BO3) - StarLadder StarSeries Playoffs
      yes price: 64% · 24h volume: $975,839 · resolves 2026-09-18
  - (2026-09-18) LoL: Team WE vs JD Gaming (BO5) - LPL Regional Finals Playoffs
      yes price: 23% · 24h volume: $968,585 · resolves 2026-09-18
  - (2026-09-18) LoL: Team WE vs JD Gaming - Game 2 Winner
      yes price: 0% · 24h volume: $905,951 · resolves 2026-09-18
  - (2026-09-18) Will FC Bayern München win on 2026-09-18?
      yes price: 94% · 24h volume: $636,664 · resolves 2026-09-18

### USGS earthquakes (M4.5+, past day) — 10 new of 10 total
  - (2026-09-17) M 6.5 - 165 km W of Nikolski, Alaska
      M6.5 · 165 km W of Nikolski, Alaska · depth 111.666 km · TSUNAMI
  - (2026-09-18) M 5.0 - Izu Islands, Japan region
      M5.0 · Izu Islands, Japan region · depth 35.294 km
  - (2026-09-17) M 4.9 - northern Mid-Atlantic Ridge
      M4.9 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-09-18) M 4.7 - Fiji region
      M4.7 · Fiji region · depth 548.378 km
  - (2026-09-18) M 4.7 - 40 km SSW of Sipí, Colombia
      M4.7 · 40 km SSW of Sipí, Colombia · depth 68.374 km
  - (2026-09-17) M 4.7 - 24 km SW of Sipí, Colombia
      M4.7 · 24 km SW of Sipí, Colombia · depth 57.808 km

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 68 total
  - (2026-09-17) [OFAC] Iran-related Designations; Cuba Designations; Belarus-related Designations Removals - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Cuba Designations; Belarus-related Designations Removals Office of Foreign Assets Control (.gov)
  - (2026-09-18) [BIS Entity List] page checksum 6008268dd5c4
      Page content hash: 6008268dd5c4. Compare with prior day's hash to detect updates.
  - (2026-09-18) [USASpending error] ReadTimeout
      HTTPSConnectionPool(host='api.usaspending.gov', port=443): Read timed out. (read timeout=30)
  - (2026-09-18) [UN Sanctions] page checksum 9c0dbf9c1341
      Active UN Security Council sanctions committees page snapshot

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-18) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=19, 14d-median=17; carrying terms: certain, navigable, program, proposes, proposed, management, proposing, final, needed, establishing, special, provisions
- state_bills: today=78, 7d-median=79, 14d-median=80; carrying terms: member, records, condition, defines, prohibit, various, generally, standards, right, include, entities, appropriate
- state_news: today=774, 7d-median=772, 14d-median=586; carrying terms: survey, river, hospital, homes, columbia, trees, right, bring, house, leaving, polls, things
- local_news: today=244, 7d-median=236, 14d-median=229; carrying terms: metro, fulton, charged, house, shooting, google, president, three, north, court, blank, around
- foreign_news: today=1075, 7d-median=986, 14d-median=1004; carrying terms: arabia, hospital, figures, bring, happened, source, guardian, president, width, maverick, battle, missile
- chinese_internal: today=284, 7d-median=284, 14d-median=283; carrying terms: google, cbmiaefvx, cbmiykfvx, lxtfb, blank, lxtfa, chinese, title, cbmiw, cbmizkfvx, cbmibkfvx, cbmibefvx
- russian_internal: today=1164, 7d-median=1059, 14d-median=1050; carrying terms: openai, europe, istories, httperror, ukraina, russian, forbidden, novayagazeta, axios, bloomberg, times, guardian
- ukrainian_internal: today=136, 7d-median=136, 14d-median=136; carrying terms: targeted, hromadske, institute, least, censor, offensive, ukrinform, attacks, weapons, launched, kravchenko, president
- ukraine_theater: today=465, 7d-median=351, 14d-median=433; carrying terms: pzededc, wxpetxjrsdayykzqtthpvlzyn, lvpcawjcvtq, syria, mxrudhc, wthjqk, owhksjjmqlu, xujlrdmv, mykhailo, offensive, weapons, lumnexwdrjs
- paper_bets: today=129, 7d-median=128, 14d-median=128; carrying terms: schumer, performing, openai, zohran, prime, sachs, magnitude, arizona, special, remain, levels, december
- weather: today=107, 7d-median=114, 14d-median=106; carrying terms: afdsew, magnitude, changed, beach, details, southeast, river, bring, include, impacts, flooding, chances
- macro: today=0, 7d-median=21, 14d-median=21; carrying terms: total, unemployment, funds, labor, personal, commodities, recession, energy, money, rates, balance, openings
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, russell, equities, nasdaq, close, china, large, futures, proxy, commodities, agriculture, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=68, 7d-median=108, 14d-median=106; carrying terms: member, public, facilitate, union, compare, serious, threatening, rkiye, myanmar, embargo, jihad, burma
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, client, https, error, httperror, quantitative, quiverquant, congresstrading, quiver
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, appeals, company, connecticut, blanche, martin, corrections, florida, corporation, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, holdings, trust, filer, technology, tidal, america, financial, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cortez, booker, michael, sherrod, house, johnson, lindsey, filing, brown, jonathan, elect, warner
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, turkish, sanctions, attack, iranian, minister
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: kingdom, position, belgium, france, germany, bulgaria, ground, adfec
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: africa, coronavirus, member, identified, evolve, alert, public, prevention, acute, increased, documented, process
- cisa_kev: today=19, 7d-median=23, 14d-median=21; carrying terms: microsoft, artifactory, jfrog, netscaler, buffer, google, vulnerability, injection, remediation, critical, bounds, citrix
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=10, 7d-median=13, 14d-median=11; carrying terms: depth, islands, indonesia, region, japan, colombia, ridge, northern, russia, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: change, champions, volume, rates, meeting, interest, price, league, shakhtar, championship, decrease, donetsk
- commentary: today=0, 7d-median=6, 14d-median=6; carrying terms: evidence, revolution, conversableeconomist, class, economist, conversable, marginal, https, explain, recent, story, price
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: openai, enough, attacks, cyber, vulnerability, against, speed, companies, target, technology, microsoft, latest
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: cortez, meeks, boozman, grassley, michael, kavanaugh, jefferson, dwight, kiley, reserved, feenstra, fitzgerald
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, evidence, decision, unavailable, module, consensus, claude, placement, identify, markets, either, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy
- [2026-09-12] ECB press: Christine Lagarde: Interview with Ouest-France
- [2026-09-14] ECB press: Isabel Schnabel: Macroeconomic, fiscal and financial stability in a shock-prone world
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI
- [2026-09-16] ECB press: ECB wage tracker at 2.7% in H1 2027, pointing to a modest uptick in negotiated wage growth
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] ECB press: Boris Vujčić: Interview with Reuters
- [2026-09-18] ECB press: ECB Consumer Expectations Survey results – August 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*