# WORLDSCOPE morning brief — 2026-06-23

## Headline
2438 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (605) · Russian Internal News (state + in-exile) (495) · World leaders & government officials (324) · Chinese Internal News (199) · U.S. Weather + Severe / Climate Outlooks (162) · Ukraine Theater (total-war monitoring) (127) · State-Level News (92) · Local News: St. Louis + Atlanta (81) · State Legislative Action (57) · GDELT GKG — themes / entities / watch areas (49) · Ukrainian Internal News (national + local Kyiv) (41) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 605 new of 1034 total
  - (2026-06-23) [Global] Protests erupt in Colombia as far-right set to win presidential election
      Protests have erupted in Colombia against the election of the far-right candidate Abelardo de la Espriella. Though election officials have yet to formally announce a winner, with almost all of the votes counted, the pro-…
  - (2026-06-23) [Global] Iran set to return to mainstream oil market as US temporarily waives sanctions
      As 60 days of peace negotiations between the US and Iran continue, Tehran appears to have won significant concessions from Washington. Chief among those is the waiving of sanctions on Iranian oil exports. US sanctions ha…
  - (2026-06-23) [Global] Messi becomes World Cup all-time goal scorer in game against Austria
      France's second World Cup game belonged to Mbappé as he scored twice, moving into a tie for second in World Cup goals. Argentina won its second game against Austria, with two goals scored by Messi. Norway's Haaland also…
  - (2026-06-23) [Global] France faces historically hot temperatures as heatwave carries on
      Millions of people across France woke up drenched in sweat on June 23 after another night of scorching heat, with most of the population exposed to extreme and exceptional temperatures. In a country without widespread ai…
  - (2026-06-23) [Global] UK facing 'pivotal moment' as it prepares for 7th PM since Brexit vote
      British Prime Minister Keir Starmer won his job after leading his party to a massive victory in 2024. Less than two years later, he resigned as his party rebelled in the wake of widespread losses in local elections. It c…
  - (2026-06-23) [Global] US, Iran agree on Lebanon ceasefire and lifting sanctions on Iranian oil, but much remains
      Both Tehran and Washington hailed the negotiations that took place in Switzerland on June 22 to create a roadmap to close down the war in the Middle East. US Vice president JD Vance said it laid a good foundation for a d…

### Russian Internal News (state + in-exile) — 495 new of 915 total
  - (2026-06-23) Показатель младенческой смертности в России низкий, заявил Мурашко | LEDE: ] (ru: Показатель младенческой смертности в России низкий, заявил Мурашко)
  - (2026-06-23) В РСТ рассказали, как будут возвращаться средства за путевки в лагеря Крыма | LEDE: ] (ru: В РСТ рассказали, как будут возвращаться средства за путевки в лагеря Крыма)
  - (2026-06-23) Армянский депутат заявил, что его дом обыскали по "смешной статье" | LEDE: ] (ru: Армянский депутат заявил, что его дом обыскали по "смешной статье")
  - (2026-06-23) В ДНР за сутки сбили 15 беспилотников | LEDE: ] (ru: В ДНР за сутки сбили 15 беспилотников)
  - (2026-06-23) Нетаньяху призвал к независимости Израиля в сфере вооружений | LEDE: ] (ru: Нетаньяху призвал к независимости Израиля в сфере вооружений)
  - (2026-06-23) Белоруссия сможет защититься от любого агрессора, заявил Лукашенко | LEDE: ] (ru: Белоруссия сможет защититься от любого агрессора, заявил Лукашенко)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 199 new of 281 total
  - (2026-06-23) 图片报道 - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxOa1FTckpkU19rbXV3UlZVNFN5SzJBSnlES21ubmZveVZianl2WVN2eUFadGNaSmxBOVltVHNham1WekJ6NlFpNE1jM2Y5MXBkZm5KVDZ0cTZpajZ] (zh:…
      图片报道 人民日报
  - (2026-06-23) 第十七届夏季达沃斯论坛｜开启多元对话 探寻务实良策 - 人民网财经 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9JM0FMcXZKcDF5OVdfM0k4V3hxa0Y2b0E1SExGRDB1SGxuTXlJOGNjUEF4ek9XaEdDejdnM1YxN3duUnBTa2duMDBIT] (zh:…
      第十七届夏季达沃斯论坛｜开启多元对话 探寻务实良策 人民网财经
  - (2026-06-23) 直播预告：肿瘤专科助力医院高质量发展 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9udld1WVFPamVUeWpndEY4NXdvaXc5M3c0UmpWa2l5QlAzLTJQOU12VG0zVlFoUk83WVRhMXBHUkJueXVOQTlkaG5hSE5YZ3hT] (zh:…
      直播预告：肿瘤专科助力医院高质量发展 人民网健康
  - (2026-06-23) 飞鹤亮相链博会：攻坚蛋白科技实现核心原料自产 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE5pSHRKUHdqQXJxeTRZV09SbWhEZ3BPOXNZai02U25aNzJWMl93OVhCNGlVMWJIdXZLd01wTUdqMmRDSWllVVRNc0xzaWY0] (zh:…
      飞鹤亮相链博会：攻坚蛋白科技实现核心原料自产 人民网健康
  - (2026-06-23) 意大利：高温来袭--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE9MSGRxcnJqRkloT0VuT3FDQ3ZvWmd6NnQ1OHlDLW5jR21wbW03NnZiMndXUDEzNm1BY2lTbzdTU1QzTENER2FQSzlKVGZONWRPcE44NG5s] (zh:…
      意大利：高温来袭--国际 人民网
  - (2026-06-23) 每日一句丨以长远眼光布局，锚定永续发展航向 - 人民网教育 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE5TcnpVZDRPSEVqajZHOTJQWjR6SlowZ05uVmNpaHlNR3E5ek1xcWFZVkczZUlMN2oyVjVEWDFYS19COTg0YmE3N0h3NWRIc] (zh:…
      每日一句丨以长远眼光布局，锚定永续发展航向 人民网教育

### U.S. Weather + Severe / Climate Outlooks — 162 new of 185 total
  - (2026-06-23) [Moderate] Special Weather Statement: Special Weather Statement issued June 23 at 5:30AM CDT by NWS Dodge City KS
      At 530 AM CDT, Doppler radar was tracking a strong thunderstorm 7 miles northwest of Plymell, moving southeast at 30 mph. HAZARD...Penny size hail. SOURCE...Radar indicated. IMPACT...Minor hail damage to vegetation is po…
  - (2026-06-23) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 23 at 4:29AM MDT until June 23 at 5:15AM MDT by NWS North Platte NE
      At 429 AM MDT, a severe thunderstorm was located 8 miles north of Ellsworth, or 31 miles east of Alliance, moving southeast at 35 mph. HAZARD...Ping pong ball size hail and 60 mph wind gusts. SOURCE...Radar indicated. IM…
  - (2026-06-23) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-23) [Moderate] Special Weather Statement: Special Weather Statement issued June 23 at 5:26AM CDT by NWS Amarillo TX
      At 526 AM CDT, Doppler radar was tracking a strong thunderstorm 4 miles southwest of Slapout, or 17 miles southwest of Laverne, moving southeast at 20 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE...…
  - (2026-06-23) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 23 at 5:17AM CDT until June 23 at 6:00AM CDT by NWS Shreveport LA
      SVRSHV The National Weather Service in Shreveport has issued a * Severe Thunderstorm Warning for... West Central Miller County in southwestern Arkansas... Southeastern Bowie County in northeastern Texas... Northeastern C…
  - (2026-06-23) [Severe] Flood Watch: Flood Watch issued June 23 at 6:14AM EDT until June 23 at 10:00PM EDT by NWS Wakefield VA
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...A portion of southeast Virginia, including the following areas, Chesapeake, Hampton/Poquoson, Isle of Wight, James City, Newport News, No…

### Ukraine Theater (total-war monitoring) — 127 new of 557 total
  - (2026-06-23) [FIRMS] thermal anomaly 52.808, 32.225 (FRP 0.65 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-23 0005Z, FRP 0.65 MW
  - (2026-06-23) [FIRMS] thermal anomaly 52.804, 32.223 (FRP 0.6 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-23 0005Z, FRP 0.6 MW
  - (2026-06-23) [FIRMS] thermal anomaly 52.849, 29.993 (FRP 2.96 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-23 0005Z, FRP 2.96 MW
  - (2026-06-23) [FIRMS] thermal anomaly 52.845, 29.992 (FRP 1.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-23 0005Z, FRP 1.84 MW
  - (2026-06-23) [FIRMS] thermal anomaly 52.293, 32.812 (FRP 0.94 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-23 0005Z, FRP 0.94 MW
  - (2026-06-23) [FIRMS] thermal anomaly 51.937, 34.267 (FRP 0.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-23 0005Z, FRP 0.35 MW

### State-Level News — 92 new of 452 total
  - (2026-06-23) [California] California and Pacific partners issue joint statement, deepening cooperation on climate adaptation and resilience
      Source
  - (2026-06-23) [California] California leaders yet to reach deal to keep billionaire tax off the ballot. Time is running out
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/061826-Billionaire-Tax-Act-JA-Getty-01-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-…
  - (2026-06-22) [California] L.A. Unified superintendent resigns amid FBI probe into chatbot contract
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/011422_Alberto-Carvalho_GETTY_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-06-23) [Arizona] Hobbs signs final batch of bills for the 2026 session
      Arizona Gov. Katie Hobbs signed 51 pieces of legislation on Monday, the last of the bills that the state legislature sent to her before it ended the annual legislative session on June 13. During a series of long days dur…
  - (2026-06-23) [Arkansas] States ease child labor laws ahead of summer hiring season
      For some teenagers across the country, the summer is the first opportunity to gain work experience for their nascent resume. In a handful of states, however, teens who find jobs will find fewer protections under child la…
  - (2026-06-23) [Arkansas] States are changing fire codes to make housing cheaper. Some safety experts are worried.
      States and cities are loosening building code requirements in an effort to lower construction costs and boost affordable housing. Some of these changes include allowing low-rise apartment buildings to have just one stair…

### Local News: St. Louis + Atlanta — 81 new of 221 total
  - (2026-06-23) [St. Louis] Where Art Thou? – 6/22/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-06-23) [St. Louis] Iran’s president heads to Pakistan as US-Iran teams work to finalize a war-ending deal
      Iranian President Masoud Pezeshkian is traveling to Pakistan for talks with leaders mediating negotiations between Tehran and Washington.
  - (2026-06-23) [St. Louis] Missouri marijuana microbusiness application period to open July 13
      Missouri will open applications for 77 microbusiness marijuana licenses, designed to boost representation in the cannabis industry. The deadline to apply is July 27.
  - (2026-06-23) [St. Louis] During Pride Month, St. Louis patients and advocates focus on HIV care and the work that continues
      St. Louis patients and providers are navigating funding changes while working to sustain decades of progress in HIV care.
  - (2026-06-23) [St. Louis] Pride curfew, early closures draw pushback from Grove businesses and LGBTQ+ leaders
      St. Louis Pride safety measures sparked backlash as bar owners in the Grove and LGBTQ+ leaders said they were excluded from planning.
  - (2026-06-23) [St. Louis] NHTSA investigating after Tesla crashes into Texas home, killing woman inside
      Tesla founder Elon Musk responded to news of the crash on Monday, saying on social media, "This makes no sense."

### State Legislative Action — 57 new of 133 total
  - (2026-06-23) [Arizona SB 1399] prepaid capitated contractors; cost reports
      prepaid capitated contractors; cost reports
  - (2026-06-23) [Arizona SB 1335] water banking; annual report; posting
      water banking; annual report; posting
  - (2026-06-23) [Arizona SB 1497] classical learning; tests; examinations
      classical learning; tests; examinations
  - (2026-06-23) [Arizona SB 1552] ADOT; revisions.
      ADOT; revisions.
  - (2026-06-23) [Arizona SB 1275] mandatory prison sentences; judicial discretion
      mandatory prison sentences; judicial discretion
  - (2026-06-23) [Arizona SB 1422] credit enhancement eligibility board; continuation
      credit enhancement eligibility board; continuation

### GDELT GKG — themes / entities / watch areas — 49 new of 49 total
  - (2026-06-23) [Israel-Iran-Hezbollah axis · themes] Adalar Belediyesine Rüşvet Soruşturmasında Yeni Gelişme : Başkan Ali Ercan Akpolat Dahil 35 Kişi Tutuklandı
      gercekgundem.com · Turkish · tone NA
  - (2026-06-23) [Israel-Iran-Hezbollah axis · themes] Вибух на найбільшому заводі з переробки СПГ у Катарі : 13 загиблих , 66 поранених
      bagnet.org · Ukrainian · tone NA
  - (2026-06-23) [Israel-Iran-Hezbollah axis · themes] La Chine estime que la remilitarisation du Japon constitue un retour en arrière et une voie sans issue
      french.people.com.cn · French · tone NA
  - (2026-06-23) [Israel-Iran-Hezbollah axis · themes] UE prepara separao das negociaes de adesão da Moldova e Ucrânia
      pt.euronews.com · Portuguese · tone NA
  - (2026-06-23) [Israel-Iran-Hezbollah axis · themes] В Ярославской области три пьяные женщины грели пятую точку у Вечного огня : их задержали
      progorod76.ru · Russian · tone NA
  - (2026-06-23) [Israel-Iran-Hezbollah axis · themes] 5 Ways to Support Brain Health Without Breaking the Bank
      herald-citizen.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 41 new of 111 total
  - (2026-06-23) В окупованому Криму заборонили всі спортивні змагання | LEDE: В Криму до 1 вересня окупанти скасували спортивні заходи та тренування — безпека.] (uk: В окупованому Криму заборонили всі спортивні змага…
      В Криму до 1 вересня окупанти скасували спортивні заходи та тренування — безпека.
  - (2026-06-23) Ексдепутат отримав уже третю підозру: понад 8 млн збитків через підлеглих-ФОПів | LEDE: Колишньому депутату районної ради на Львівщині повідомили вже третю підозру, цього разу – у завданні 8 мл] (uk:…
      Колишньому депутату районної ради на Львівщині повідомили вже третю підозру, цього разу – у завданні 8 млн грн збитків на оренді техніки.
  - (2026-06-23) Спека, короткочасні дощі і град – погода на 24-26 червня | LEDE: В Україні збережеться спекотна погода, місцями грози, град і шквали. Детальний прогноз на 24-26 червня.] (uk: Спека, короткочасні дощі…
      В Україні збережеться спекотна погода, місцями грози, град і шквали. Детальний прогноз на 24-26 червня.
  - (2026-06-23) У Навроцького дізналися, що Зеленський не приїде на конференцію з відновлення у Гданську | LEDE: Президент Зеленський не відвідає конференцію у Гданську, Україну представить прем’єр Юлія Свирид] (uk:…
      Президент Зеленський не відвідає конференцію у Гданську, Україну представить прем’єр Юлія Свириденко.
  - (2026-06-23) Лавров пригрозив захищати Білорусь "усім комплексом заходів" | LEDE: Міністр закордонних справ РФ Сергій Лавров заявив, що Росія готова застосувати всі передбачені союзним договором механізми д] (uk:…
      Міністр закордонних справ РФ Сергій Лавров заявив, що Росія готова застосувати всі передбачені союзним договором механізми для забезпечення безпеки Білорусі та Союзної держави.
  - (2026-06-23) У Навроцького покритикували уряд Туска через конференцію з відновлення і Зеленського | LEDE: Глава канцелярії президента Польщі Збігнев Богуцький заявив, що відсутність президента Володимира Зе] (uk:…
      Глава канцелярії президента Польщі Збігнев Богуцький заявив, що відсутність президента Володимира Зеленського на Конференцію з відновлення України у Гданську, свідчитиме про неспроможність польського уряду.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-23) [Wang Barney Tianhao] Form 4 (Reporting)
      filed 2026-06-23 10:30 UTC · role: Reporting — Filed: 2026-06-23 AccNo: 0001104659-26-076613 Size: 9 KB
  - (2026-06-23) [SharkNinja, Inc.] Form 4 (Issuer)
      filed 2026-06-23 10:30 UTC · role: Issuer — Filed: 2026-06-23 AccNo: 0001104659-26-076613 Size: 9 KB
  - (2026-06-23) [Wang Jingbo] Form 4 (Reporting)
      filed 2026-06-23 10:21 UTC · role: Reporting — Filed: 2026-06-23 AccNo: 0001193125-26-278453 Size: 7 KB
  - (2026-06-23) [ATRenew Inc.] Form 4 (Issuer)
      filed 2026-06-23 10:21 UTC · role: Issuer — Filed: 2026-06-23 AccNo: 0001193125-26-278453 Size: 7 KB
  - (2026-06-23) [AST SpaceMobile, Inc.] Form 4 (Issuer)
      filed 2026-06-23 10:14 UTC · role: Issuer — Filed: 2026-06-23 AccNo: 0001493152-26-029685 Size: 9 KB
  - (2026-06-23) [Avellan Abel Antonio] Form 4 (Reporting)
      filed 2026-06-23 10:14 UTC · role: Reporting — Filed: 2026-06-23 AccNo: 0001493152-26-029685 Size: 9 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-23) [Australia] Northbridge home design : How architect Clinton Cole blurred the lines between indoor and outdoor living
      domain: theage.com.au · language: English · tone:
  - (2026-06-23) [South Africa] Shalulile given legendary crowning blessings at …
      domain: kickoff.com · language: English · tone:
  - (2026-06-23) [United States] 5 Ways to Support Brain Health Without Breaking the Bank
      domain: herald-citizen.com · language: English · tone:
  - (2026-06-23) [United States] Trouble getting weight loss drugs covered by insurance ? Here what to know
      domain: kenw.org · language: English · tone:
  - (2026-06-23) [United States] Park National Corp OH Grows Stock Holdings in Johnson & Johnson $JNJ
      domain: themarketsdaily.com · language: English · tone:
  - (2026-06-23) [India] Why would you crush us ?: Parbhani MP Sanjay Jadhav hits back at Sanjay Raut over Operation Todwa remark
      domain: aninews.in · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 27 total
  - (2026-06-23) JAF94H (Bulgaria)
      icao24: 4520aa · position: (42.626, -2.9636) · alt: 11277m · 849km/h
  - (2026-06-23) GAF103 (Germany)
      icao24: 3f717c · position: (67.7159, 5.0001) · alt: 9136m · 725km/h
  - (2026-06-23) GAF101 (Germany)
      icao24: 3ea048 · position: (66.6224, 5.0002) · alt: 8831m · 711km/h
  - (2026-06-23) CFC2953 (Canada)
      icao24: c2b585 · position: (48.2975, -4.1743) · alt: 9448m · 606km/h
  - (2026-06-23) CFC2963 (Canada)
      icao24: c2b553 · position: (51.0643, 3.1354) · alt: 4000m · 560km/h
  - (2026-06-23) JAF5KH (Belgium)
      icao24: 44d1b3 · position: (45.0349, 17.3729) · alt: 11582m · 806km/h

### U.S. Federal Action — 22 new of 23 total
  - (2026-06-23) Rescission of Affirmative Outreach Requirements for Recipients of WIOA Title I Financial Assistance
      The Department of Labor (Department) rescinds the regulatory affirmative outreach requirements on recipients of financial assistance under Title I of the Workforce Innovation and Opportunity Act (WIOA) and makes conformi…
  - (2026-06-23) Longshore and Harbor Workers' Compensation Act: Quality Standards for Hearing Loss Testing
      The Longshore and Harbor Workers' Compensation Act (LHWCA) provides compensation to employees for disability or death from injury arising out of and in the course of employment. Hearing loss claims constitute a significa…
  - (2026-06-23) Fisheries Off West Coast States; Coastal Pelagic Species Fisheries; Amendment 22 to the Coastal Pelagic Species Fishery Management Plan
      The Pacific Fishery Management Council (Council) has submitted Amendment 22 to the Coastal Pelagic Species (CPS) Fishery Management Plan (FMP) for review by the Secretary of Commerce. This notification announces that the…
  - (2026-06-23) Operating Limitations at New York LaGuardia Airport
      This action extends the Order Limiting Operations at New York LaGuardia Airport (LGA) published on December 27, 2006, as most recently extended May 13, 2024. The Order remains effective until October 28, 2028.
  - (2026-06-23) Operating Limitations at John F. Kennedy International Airport
      This action extends the Order Limiting Operations at John F. Kennedy International Airport (JFK) published on January 18, 2008, and most recently extended on October 27, 2024. The Order remains effective until October 28…
  - (2026-06-23) Federal Employees' Retirement System; Present Value Conversion Factors for Spouses of Deceased Separated Employees
      The Office of Personnel Management (OPM) is revising the table of reduction factors for early commencing dates of survivor annuities for spouses of separated employees who die before the date on which they would be eligi…

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 46 total
  - (2026-06-23) [The Hacker News] Malicious npm Packages Pose as PostCSS Tools to Deliver Windows RAT
      Cybersecurity researchers have discovered a set of malicious npm packages that are designed to deliver a Windows-based remote access trojan (RAT). The list of identified packages, is below - aes-decode-runner-pro (145 do…
  - (2026-06-23) [The Hacker News] WhatsApp VBScript Campaign Uses Fake Documents to Install ManageEngine RMM Tool
      Direct messages sent via WhatsApp are being used to distribute malicious Visual Basic Script (VBScript) files that lead to the installation of legitimate Remote Monitoring and Management (RMM) software. Per findings from…
  - (2026-06-23) [The Hacker News] OpenAI Expands Daybreak With GPT-5.5-Cyber to Help Defenders Patch Security Flaws
      OpenAI on Monday said it's releasing an improved version of its GPT‑5.5‑Cyber model to trusted defenders as part of the Daybreak initiative the artificial intelligence (AI) company announced last month. Calling GPT‑5.5‑C…
  - (2026-06-23) [Ars Technica] With Starfall, SpaceX eyes an edge in global cargo delivery from orbit
      The purpose of Starfall is to support the "transport and delivery of goods through space."
  - (2026-06-23) [Computer Weekly] nLighten CEO Dawn Childs on edge datacentres and sovereignty
      nLighten’s £15m refurbishment of its Bristol datacentre shows one section of the market placing its bets on relatively small edge infrastructure targeted at specific local tech-heavy customers.&nbsp; Following the launch…
  - (2026-06-23) [Computer Weekly] Datacentre resilience means more than uptime: Here’s what to change
      The escalation of conflict in the Middle East earlier this year disrupted datacentre operations across parts of the Gulf , w

### Paper Trading Scorecard — 8 new of 133 total
  - (2026-06-23) [Polymarket] Will the price of Ethereum be above $2,000 on June 26?
      This market will resolve to "Yes" if the Binance 1 minute candle for ETH/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-06-23) [Polymarket] Will Qatar win on 2026-06-24?
      In the upcoming game, scheduled for June 24, 2026 If Qatar wins, this market will resolve to "Yes". Otherwise, this market will resolve to "No". If the game is postponed, this market will remain open until the game has b…
  - (2026-06-23) [Polymarket] Will Ecuador advance to the knockout stages at the 2026 FIFA World Cup?
      This market will resolve “Yes” if the listed nation advances to the Knockout Stage of the 2026 FIFA World Cup. If at any point it becomes impossible for the listed nation to advance to the Knockout Stage (e.g. they are m…
  - (2026-06-23) [Polymarket] Will Panama vs. Croatia end in a draw?
      In the upcoming game, scheduled for June 23, 2026 If the game ends in a draw, this market will resolve to "Yes". Otherwise, this market will resolve to "No". If the game is postponed, this market will remain open until t…
  - (2026-06-23) [Manifold] Will the Crimean bridge be damaged in 2026?
  - (2026-06-23) [Manifold] Will I burnout by the end of 2026?

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-06-23) Will Senegal win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $5,118,727 · resolves 2026-07-20
  - (2026-06-23) Will England win the 2026 FIFA World Cup?
      yes price: 12% · 24h volume: $2,769,613 · resolves 2026-07-20
  - (2026-06-23) Will Japan win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $2,288,661 · resolves 2026-07-20
  - (2026-06-23) Will Spain win the 2026 FIFA World Cup?
      yes price: 14% · 24h volume: $2,171,223 · resolves 2026-07-20
  - (2026-06-23) Will Portugal win on 2026-06-23?
      yes price: 86% · 24h volume: $2,129,884 · resolves 2026-06-23
  - (2026-06-23) Will Portugal win the 2026 FIFA World Cup?
      yes price: 7% · 24h volume: $2,051,683 · resolves 2026-07-20

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 6 new of 37 total
  - (2026-06-23) MOVER ▼ Masayoshi Son — $76.51B ($-8.00B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-06-23) MOVER ▼ Gautam Adani — $88.58B ($-1.96B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-06-23) MOVER ▲ Tadashi Yanai & family — $69.15B (+$0.47B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-06-23) MOVER ▼ Amancio Ortega — $140.08B ($-0.39B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-06-23) MOVER ▲ Bernard Arnault & family — $148.32B (+$0.33B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-06-23) MOVER ▼ Francoise Bettencourt Meyers & family — $93.07B ($-0.23B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### World News (by country, top stories) — 6 new of 6 total
  - (2026-06-23) [China] Kaori Kaohsiung plant targets 2027 output for AI cooling and green energy demand
      digitimes.com · English
  - (2026-06-23) [China] PLZ - 89 self - propelled howitzers in live - fire training - Focus - 中国军网 （ 英文版 ）
      eng.chinamil.com.cn · English
  - (2026-06-23) [China] NYCU , Phison join forces to build AI heterogeneous computing resource management platform
      digitimes.com · English
  - (2026-06-23) [China] Chinese peacekeepers to South Sudan ( Wau ) conduct joint casualty treatment training with multiple UN departments
      eng.chinamil.com.cn · English
  - (2026-06-23) [China] ITM 2026 exceeds expectations for Karl Mayer
      knittingindustry.com · English
  - (2026-06-23) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English

### USGS earthquakes (M4.5+, past day) — 5 new of 14 total
  - (2026-06-23) M 5.3 - Kermadec Islands region
      M5.3 · Kermadec Islands region · depth 140.331 km
  - (2026-06-23) M 5.1 - 186 km N of Fais, Micronesia
      M5.1 · 186 km N of Fais, Micronesia · depth 43.714 km
  - (2026-06-23) M 5.0 - 174 km E of Hihifo, Tonga
      M5.0 · 174 km E of Hihifo, Tonga · depth 10 km
  - (2026-06-23) M 4.9 - 171 km WNW of Tobelo, Indonesia
      M4.9 · 171 km WNW of Tobelo, Indonesia · depth 35 km
  - (2026-06-22) M 4.6 - 10 km E of Miyakojima, Japan
      M4.6 · 10 km E of Miyakojima, Japan · depth 35 km

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-06-23) [Marginal Revolution] Is the UK improving?
      From Barney Hussey-Yeo: From a very credible Labour source: – Wes Streeting promised the Chancellorship for not running. – Capital gains raised to match income tax. Possible exit tax. – Economic focus: devolution, plus s…
  - (2026-06-23) [Marginal Revolution] Dean Karlan has a Substack
      He starts his new essay with this: In 2014 I wrote in The New York Times that if your own team is not in the World Cup, you should root for the one whose victory would do the most good. Add up the happiness a title would…
  - (2026-06-23) [Marginal Revolution] Elderly Health and Longevity in the US
      Rising elderly life expectancy is a well-known source of fiscal pressure on Social Security and Medicare – but how have declining mortality and morbidity affected the two programs’ relative finances? Using nearly three d…

## How it fits the arc (last 14 days)
- federal_register: today=23, 7d-median=23, 14d-median=23
- state_bills: today=133, 7d-median=133, 14d-median=133
- state_news: today=452, 7d-median=452, 14d-median=452
- local_news: today=221, 7d-median=218, 14d-median=218
- foreign_news: today=1034, 7d-median=1015, 14d-median=1015
- chinese_internal: today=281, 7d-median=251, 14d-median=251
- russian_internal: today=915, 7d-median=915, 14d-median=915
- ukrainian_internal: today=111, 7d-median=111, 14d-median=111
- ukraine_theater: today=557, 7d-median=557, 14d-median=557
- paper_bets: today=133, 7d-median=133, 14d-median=133
- weather: today=185, 7d-median=185, 14d-median=185
- macro: today=21, 7d-median=21, 14d-median=21
- markets: today=21, 7d-median=21, 14d-median=21
- markets_global: today=47, 7d-median=47, 14d-median=47
- sanctions_procurement: today=102, 7d-median=102, 14d-median=102
- congressional_trades: today=68, 7d-median=68, 14d-median=68
- billionaires: today=37, 7d-median=37, 14d-median=37
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=6, 7d-median=6, 14d-median=6
- gdelt_gkg: today=49, 7d-median=49, 14d-median=49
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=27, 7d-median=27, 14d-median=27
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=9, 7d-median=9, 14d-median=9
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=118, 7d-median=120, 14d-median=120
- usgs_quakes: today=14, 7d-median=16, 14d-median=16
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=5, 7d-median=5, 14d-median=5
- tech_news: today=46, 7d-median=48, 14d-median=48
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-09] Fed press (events + announcements): Federal Reserve Board announces that results from its annual bank stress test will be released on Wednesday, June 24, at 4 p.m. EDT.
- [2026-06-11] Fed press (events + announcements): Federal Reserve Board announces final rule that establishes data standards for certain information collections
- [2026-06-16] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-06-17] ECB press: New data release: ECB wage tracker points to stable negotiated wage pressures in 2026
- [2026-06-17] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-06-17] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the June 16-17 FOMC meeting
- [2026-06-18] ECB press: Piero Cipollone: Digital euro: the future of money
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board requests comment on proposal to require certain payment stablecoin issuers to maintain an effective customer identification program
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Manufacturers and Traders Trust Company
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-19] ECB press: ECB publishes consolidated banking data for end-December 2025
- [2026-06-19] ECB press: Piero Cipollone: The foundations of national sovereignty: the role of central bank money
- [2026-06-19] ECB press: Frank Elderson: Fireside chat
- [2026-06-22] Fed press (events + announcements): Federal Reserve notes with deep sadness the passing of Alan Greenspan
- [2026-06-22] Fed speeches: Waller, Welcoming Remarks on the International Role of the U.S. Dollar
- [2026-06-22] ECB press: Christine Lagarde: Hearing of the Committee on Economic and Monetary Affairs of the European Parliament
- [2026-06-23] ECB press: Philip R. Lane: Introductory remarks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*