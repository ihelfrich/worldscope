# WORLDSCOPE morning brief — 2026-11-03

## Headline
3241 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (815) · Russian Internal News (state + in-exile) (609) · State-Level News (377) · World leaders & government officials (324) · Chinese Internal News (241) · Local News: St. Louis + Atlanta (213) · U.S. Weather + Severe / Climate Outlooks (95) · Ukraine Theater (total-war monitoring) (88) · Ukrainian Internal News (national + local Kyiv) (68) · Court opinions of consequence (federal & state) (60) · Government Action: Sanctions + Procurement + Foreign Agents (57) · GDACS — global disaster alerts (49)

## What changed today
### International News + Multilateral Institutions — 815 new of 992 total
  - (2026-11-03) [Global] Brazil publishes first global ‘roadmap’ for phasing out fossil fuels
  - (2026-11-02) [Global] Fossilised red blood cells found in 115m-year-old dinosaur’s bone, say scientists
  - (2026-11-03) [Global] Trump’s troubles with Iran could open the door to China
  - (2026-11-03) [Global] Public service union refuses to back Labor at Victorian election, condemning job cuts and $1.2bn consultant spend
  - (2026-11-03) [Global] Snowy Hydro 2.0 executives awarded bonuses totalling $751,925 despite cost blowout
  - (2026-11-03) [Global] ‘I am deeply sorry’: Craig Silvey pens 9,000-word apology for child exploitation material offences

### Russian Internal News (state + in-exile) — 609 new of 928 total
  - (2026-11-03) В Европе пять самолетов за один день получили угрозы о бомбах на борту | LEDE: Сразу пять самолетов различных авиакомпаний в Европе получили сообщения о взрывных устройствах на борту, пишет ] (ru: В Е…
      Сразу пять самолетов различных авиакомпаний в Европе получили сообщения о взрывных устройствах на борту, пишет Reuters.
  - (2026-11-03) Промежуточные выборы в США уже сегодня! Трамп тянет свою партию на дно, а демократы готовятся к победе. Объясняем, что это вообще за выборы и чем они грозят президенту Штатов | LEDE: 3 ноябр] (ru: Про…
      3 ноября в США пройдут промежуточные выборы в конгресс. Они станут своего рода референдумом о поддержке президента Дональда Трампа, чей рейтинг уже опустился до рекордно низких значений. Возглавляемая им Республиканская…
  - (2026-11-03) «Могнули». Словарь Collins назвал словом года «mogging» | LEDE: Составители толкового словаря английского языка Collins выбрали словом 2026 года «mogging». ] (ru: «Могнули». Словарь Collins назвал сло…
      Составители толкового словаря английского языка Collins выбрали словом 2026 года «mogging».
  - (2026-11-03) Белый дом объявил, что Мелания Трамп встретится с представителями России и Украины в Вашингтоне | LEDE: Первая леди США Мелания Трамп планирует провести встречу представителей России и Украи] (ru: Бел…
      Первая леди США Мелания Трамп планирует провести встречу представителей России и Украины в Белом доме, говорится в сообщении американской администрации.
  - (2026-11-03) В селе под Киевом десятки человек собрались у частного дома, где удерживали мобилизованных и сбежавших военных. Произошли столкновения со стрельбой. На место приезжал глава офиса президента Кир] (ru:…
      2 ноября несколько десятков человек собрались у частного дома в селе Петропавловская Борщаговка недалеко от Киева. Поводом стала появившаяся еще днем в соцсетях информация о том, что в подвале дома вооруженные люди удерж…
  - (2026-11-03) Война. 1714-й день. Россия ударила по пункту раздачи гуманитарной помощи в Камышевахе. 31 человек погиб, десятки остаются под завалами | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…

### State-Level News — 377 new of 571 total
  - (2026-11-03) [California] California leaders on the U.S. Supreme Court denying the Trump DOJ’s attempt to undermine California’s elections, disenfranchise voters
      Source
  - (2026-11-02) [California] Governor Newsom highlights California’s work to deliver a free and fair election tomorrow; defend democracy from ongoing and anticipated attacks
      Source
  - (2026-11-02) [California] Governor Newsom celebrates “Coolest Thing Made in California” awardees
      Source
  - (2026-11-02) [California] Governor Newsom proposes historic $1 billion California film and television tax credit – building on the nation’s most generous capped credit
      Source
  - (2026-11-03) [Alabama] Britt secures $1.02 million for Riverside bridge replacement
  - (2026-11-03) [Alabama] Audit finds repeat violations at Alabama Board of Pharmacy

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 241 new of 304 total
  - (2026-11-03) 天津29所高校学子同台比拼英语演讲 16人晋级全国决赛 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1Ka2VyRUZiQmpIOFhmblo0RWZzekhNOHBMUmRfMFdITzI5NHZpOC1JaUNZUXRUczhEajJBNFFkY0JkRzE0ZEpuQlVjU] (zh:…
      天津29所高校学子同台比拼英语演讲 16人晋级全国决赛 人民网
  - (2026-11-02) 在乌镇继续认识AI--经济·科技 - 人民网财经 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9xLXpSUDZKejV3YVQtdC1mRWxpbWJrX04zc0ZtRlFyY2dncWxoVlh0MzhiU3lweVVnWUMxVzBxalVSN2lpUGlSckkyTnVMTmh4MV] (zh:…
      在乌镇继续认识AI--经济·科技 人民网财经
  - (2026-11-03) 刘延东同志遗体在京火化 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE02b18wQmJJa3JFaXlYVjhMX3pqZWE1anhkUkw2cGxVdVh6V3dtU2lGcnR0ZnVNUG5DTWZqd0Ftclg4STdvWUNyNEhVMThGeUhrczU3] (zh:…
      刘延东同志遗体在京火化 人民网-图片频道
  - (2026-11-03) 第三次SFISF操作11月3日开展申请额度超千亿元--经济·科技 - 人民网财经 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE5nejQ5Vm9odUU0dXdtcWl5aWVtTFRWZS0xWEhQb2JJM2NYakJaY2Nic2tscFlqdkFIRF9uZWZsTWNrNnhDb2] (zh:…
      第三次SFISF操作11月3日开展申请额度超千亿元--经济·科技 人民网财经
  - (2026-11-03) 天津市大学生电商直播大赛开赛 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5UVkJlY2FydWNJVzBLckRVSFh3QVpQaFRicEZrRXFUT3RCZ2Y3WTNNZ1pqLUd1UlRYa1NmUWZ5dTVDX3EtTDN6Mm5aQUtES2U0REMtMD] (zh:…
      天津市大学生电商直播大赛开赛 人民网
  - (2026-11-03) 天津港保税区港口粮食物流枢纽建设提速 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE53VG0zelhhZ3lBUHhhNF9zZU9pOUlveFFqbTM3YVlobEFsWGRrQTBmX3NXNDhFOWpmY3MxMzQybmZGQ2xzNmdWWE1lcGgxNGJIX3] (zh:…
      天津港保税区港口粮食物流枢纽建设提速 人民网

### Local News: St. Louis + Atlanta — 213 new of 256 total
  - (2026-11-03) [St. Louis] Gas leak closes polling place in St. Charles County
      Affected voters can still cast their ballots Tuesday at the St. Charles County Election Headquarters in St. Peters.
  - (2026-11-03) [St. Louis] When do polls close on Election Day? A guide to voting times in all 50 states
      When do polls close on Election Day? A complete guide to poll closing times for every state on Nov. 3, 2026, for the midterm elections.
  - (2026-11-03) [St. Louis] LIVE UPDATES: Election Day arrives as control of Congress hangs in the balance
      Election Day will determine the balance of power in Congress and a host of other issues across the U.S. Here's the latest from across the country.
  - (2026-11-03) [St. Louis] Are stores closed today? Here's what's open and closed on Election Day
      Are stores closed Tuesday, Nov. 3? Here's a look at what's open and closed on Election Day.
  - (2026-11-03) [St. Louis] Nov. 3 election: When do polls open and close in Missouri and Illinois?
      Here's when polls close Tuesday in Missouri and Illinois, where to vote and how to follow 5 On Your Side's live election coverage.
  - (2026-11-03) [St. Louis] Saint Louis Zoo, Missouri Botanical Garden up for USA Today 10Best light displays
      ​Voting in both categories is open through the end of the month. You can vote once per day.

### U.S. Weather + Severe / Climate Outlooks — 95 new of 98 total
  - (2026-11-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-03) [Moderate] Rip Current Statement: Rip Current Statement issued November 3 at 8:03AM CST until November 4 at 6:00PM CST by NWS Mobile AL
      * WHAT...Dangerous rip currents. * WHERE...In Alabama, Mobile Coastal and Baldwin Coastal Counties. In Florida, Escambia Coastal, Santa Rosa Coastal and Okaloosa Coastal Counties. * WHEN...Through Wednesday afternoon. *…
  - (2026-11-03) [Moderate] Special Weather Statement: Special Weather Statement issued November 3 at 8:01AM CST by NWS Shreveport LA
      At 801 AM CST, Doppler radar was tracking a strong thunderstorm 6 miles north of Tatum, or 13 miles southwest of Marshall, moving east at 40 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty…
  - (2026-11-03) [Moderate] Gale Warning: Gale Warning issued November 3 at 4:23AM AKST until November 3 at 3:00PM AKST by NWS Juneau AK
      * WHAT...For the first Gale Warning, east winds 35 to 45 kt with gusts up to 50 kt and seas 20 to 25 ft. For the Storm Warning, east winds 40 to 50 kt with gusts up to 55 kt and seas 22 to 27 ft expected. For the second…
  - (2026-11-03) [Moderate] Gale Warning: Gale Warning issued November 3 at 4:23AM AKST until November 3 at 9:00PM AKST by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, southeast winds 20 to 30 kt and seas 6 to 11 ft. For the Gale Warning, southeast winds 25 to 35 kt with gusts up to 40 kt and seas 13 to 18 ft expected. For the second Small C…
  - (2026-11-03) [Severe] Storm Warning: Storm Warning issued November 3 at 4:23AM AKST until November 3 at 9:00PM AKST by NWS Juneau AK
      * WHAT...For the first Gale Warning, east winds 35 to 45 kt with gusts up to 50 kt and seas 20 to 25 ft. For the Storm Warning, east winds 40 to 50 kt with gusts up to 55 kt and seas 22 to 27 ft expected. For the second…

### Ukraine Theater (total-war monitoring) — 88 new of 329 total
  - (2026-11-03) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-31) [Liveuamap] A humanitarian rescue operation has been carried out in Oleshky, Kherson region. A ceasefire was established in the Kherson sector, allowing roads leading to Oleshky to be cleared of mines…
      A humanitarian rescue operation has been carried out in Oleshky, Kherson region. A ceasefire was established in the Kherson
  - (2026-11-02) [Liveuamap] Again drone strikes at Nalivaykivka substation – Kyiv Oblast, Ukraine - Liveuamap
      Again drone strikes at Nalivaykivka substation – Kyiv Oblast, Ukraine Liveuamap
  - (2026-11-03) [Liveuamap] At Lyman direction clashes yesterday near Nove, Kolodyazi, Lyman, Zarichne and Dibrova, - General Staff of Armed Forces of Ukraine reports – Donetsk Oblast, Ukraine - Liveuamap
      At Lyman direction clashes yesterday near Nove, Kolodyazi, Lyman, Zarichne and Dibrova, - General Staff of Armed Forces of Ukra
  - (2026-11-03) [Liveuamap] The Palestinian Red Crescent reported that a Palestinian man was injured in an attack by settlers in the village of Burqa, near Nablus in the West Bank. - Liveuamap
      The Palestinian Red Crescent reported that a Palestinian man was injured in an attack by settlers in the
  - (2026-11-03) [Liveuamap] Trump is weighing three options on Iran, with his advisers divided over the next steps. JD Vance and Steve Witkoff favor a diplomatic deal, while Netanyahu and Pete Hegseth support renewed…
      Trump is weighing three options on Iran, with his advisers divided over the next steps. JD Vance and Steve Witkoff favor

### Ukrainian Internal News (national + local Kyiv) — 68 new of 128 total
  - (2026-11-03) У Комишувасі уже 33 загиблих від російського удару – Зеленський | LEDE: Російський удар по школі у Комишувасі на Запоріжжі забрав життя 33 людей, понад 50 ще можуть залишатися під завалами – Во] (uk:…
      Російський удар по школі у Комишувасі на Запоріжжі забрав життя 33 людей, понад 50 ще можуть залишатися під завалами – Володимир Зеленський.
  - (2026-11-03) Україна звернулася до Швеції щодо екстрадиції підозрюваного у держзраді екснардепа Святаша | LEDE: Україна звернулася до Швеції із запитами про екстрадицію колишнього народного депутата від "Па] (uk:…
      Україна звернулася до Швеції із запитами про екстрадицію колишнього народного депутата від "Партії регіонів" Дмитра Святаша, засудженого до 12 років ув'язнення та обвинуваченого у державній зраді.
  - (2026-11-03) Росіяни вдарили дроном по будинку на Київщині, загинула 14-річна дитина | LEDE: У селі Хотів Обухівського району на Київщині російський дрон влучив у приватний будинок, унаслідок чого загинула ] (uk:…
      У селі Хотів Обухівського району на Київщині російський дрон влучив у приватний будинок, унаслідок чого загинула 14-річна дитина, один із батьків дістав поранення.
  - (2026-11-03) Меланія Трамп збере у Білому домі представників України та РФ | LEDE: У Білому домі заявили, що перша леді США Меланія Трамп особисто організує зустріч у США між представниками Росії та України] (uk:…
      У Білому домі заявили, що перша леді США Меланія Трамп особисто організує зустріч у США між представниками Росії та України.
  - (2026-11-03) "Лікарка" на колінах, 40 фейкових заручників і чотири реальні постраждалі: що сталося в Петропавлівській Борщагівці? | LEDE: ] (uk: "Лікарка" на колінах, 40 фейкових заручників і чотири реальні постра…
  - (2026-11-03) Жінку зі "швидкої", яка заявила про незаконне утримання військових на Київщині, затримали – Буданов | LEDE: Жінку, яка першою приїхала на "швидкій" до будинку у Петропавлівській Борщагівці на К] (uk:…
      Жінку, яка першою приїхала на "швидкій" до будинку у Петропавлівській Борщагівці на Київщині і заявила про незаконне утримання військових, затримали, заявив глава Офісу президента Кирило Буданов.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-11-02) U.S. Court of Appeals, 1st Cir.: Grygiel v. HealthEquity, Inc.
  - (2026-11-02) U.S. Court of Appeals, 10th Cir.: Blum v. CIR
  - (2026-11-02) U.S. Court of Appeals, 10th Cir.: Mostafa v. Blanche
  - (2026-11-02) U.S. Court of Appeals, 2nd Cir.: Murray v. Newrez LLC & PHH Mortgage Corporation
  - (2026-11-02) U.S. Court of Appeals, 6th Cir.: Estate of Elijah Isham v. Craig Richardson
  - (2026-11-02) U.S. Court of Appeals, 6th Cir.: Sinmier, LLC v. Everest Indemnity Ins. Co.

### Government Action: Sanctions + Procurement + Foreign Agents — 57 new of 99 total
  - (2026-11-03) [USASpending] $2,844,683,081 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2024-09-12) [EU Sanctions] Restrictive measures imposed with respect to the Taliban
      Last amended: 2024-09-12. Acronym: -.
  - (2026-04-22) [EU Sanctions] Restrictive measures in view of the situation in Belarus and the involvement of Belarus in the Russian aggression against Ukraine
      Last amended: 2026-04-22. Acronym: -.
  - (2026-03-30) [EU Sanctions] Restrictive measures in view of the situation in Bosnia and Herzegovina
      Last amended: 2026-03-30. Acronym: -.
  - (2025-09-23) [EU Sanctions] Restrictive measures in view of the situation in Burundi
      Last amended: 2025-09-23. Acronym: -.
  - (2025-03-25) [EU Sanctions] Restrictive measures in view of the situation in the Central African Republic
      Last amended: 2025-03-25. Acronym: -.

### GDACS — global disaster alerts — 49 new of 100 total
  - (2026-11-02) [Green] Flood in Bulgaria
      Flood · Green alert · Bulgaria · Magnitude 0
  - (2026-11-03) [Green] Earthquake in South Sandwich Islands Region
      Earthquake · Green alert · South Sandwich Islands Region · Magnitude 4.9M, Depth:143.595km
  - (2026-11-03) [Green] Earthquake in Greece
      Earthquake · Green alert · Greece · Magnitude 4.9M, Depth:45.662km
  - (2026-11-03) [Green] Earthquake in Colombia
      Earthquake · Green alert · Colombia · Magnitude 5.4M, Depth:10km
  - (2026-11-03) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 4.8M, Depth:52.267km
  - (2026-11-03) [Green] Earthquake in Myanmar
      Earthquake · Green alert · Myanmar · Magnitude 4.5M, Depth:116.353km

### IT, InfoSys & cybersecurity news (last 7 days) — 41 new of 62 total
  - (2026-11-03) [Krebs on Security] Tech Firms Dismantle Botnet That Turned 1.3M TV Boxes Into Proxies
      Google said today it worked with industry partners to dismantle a botnet made up of more than 1.3 million Android TV set-top boxes that ship with malicious software which secretly rents the user's Internet connection out…
  - (2026-11-03) [BleepingComputer] UK school estate hit by 3AM ransomware in suspected AI-assisted attack
      A 3AM ransomware affiliate targeted a school estate in the UK and successfully encrypted around 37 of nearly 50 machines reached from an unmanaged host. [...]
  - (2026-11-03) [BleepingComputer] Police seizes over 100 servers in investment scam crackdown
      European law enforcement authorities arrested seven suspects and seized more than 100 servers in a joint action targeting an unnamed company suspected of providing fraudulent trading websites to criminal gangs. [...]
  - (2026-11-03) [BleepingComputer] Google adds new $250,000 Cloud VRP reward for Root-in-Cloud bugs
      Google has expanded its Cloud Vulnerability Reward Program (VRP) with a new top-tier reward for high-impact architectural security flaws. [...]
  - (2026-11-03) [BleepingComputer] Harvard University data breach exposed info of 851,000 accounts
      Hackers who breached Harvard University's Alumni Affairs and Development systems in November 2025 stole data linked to more than 850,000 unique email addresses, according to breach notification service Have I Been Pwned.…
  - (2026-11-03) [The Hacker News] Red Hat Patches 9.8-Rated Linux TCP RCE Flaw While Ubuntu Releases Fixes for Testing
      Fixed kernels for a use-after-free vulnerability in the Linux kernel's IPv4 TCP code are now available for Red Hat Enterprise Linux 8, 9, and 10, while Ubuntu's fixes for its three newest long-term-support releases remai…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-03) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-11-03 14:17 UTC — Filed: 2026-11-03 AccNo: 0001918704-26-033975 Size: 506 KB
  - (2026-11-03) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-11-03 14:17 UTC — Filed: 2026-11-03 AccNo: 0001918704-26-033975 Size: 506 KB
  - (2026-11-03) 425 - Trump Media & Technology Group Corp. (0001849635) (Subject)
      filed 2026-11-03 14:15 UTC — Filed: 2026-11-03 AccNo: 0001437749-26-034541 Size: 17 KB
  - (2026-11-03) 424B5 - DigitalOcean Holdings, Inc. (0001582961) (Filer)
      filed 2026-11-03 14:15 UTC — Filed: 2026-11-03 AccNo: 0001104659-26-121722 Size: 452 KB
  - (2026-11-03) 425 - Zoar Ltd (0002078148) (Subject)
      filed 2026-11-03 14:15 UTC — Filed: 2026-11-03 AccNo: 0001493152-26-049726 Size: 59 KB
  - (2026-11-03) 425 - IMPACT BIOMEDICAL INC. (0001834105) (Filed by)
      filed 2026-11-03 14:15 UTC — Filed: 2026-11-03 AccNo: 0001493152-26-049726 Size: 59 KB

### State Legislative Action — 38 new of 40 total
  - (2026-11-03) [Alaska SB 238] An Act relating to access to library material; and relating to affirmative defenses to the offenses of enticement of a minor, contributing to the delinquency of a minor, and distributi…
      An Act relating to access to library material; and relating to affirmative defenses to the offenses of enticement of a minor, contributing to the delinquency of a minor, and distribution of indecent material to minors.
  - (2026-11-03) [Alaska SB 110] An Act establishing the museum construction and major expansion matching grant program; and providing for an effective date.
      An Act establishing the museum construction and major expansion matching grant program; and providing for an effective date.
  - (2026-11-03) [District of Columbia B 26-0016] Strategic Parking Enforcement Enhancement Act of 2025
      Strategic Parking Enforcement Enhancement Act of 2025
  - (2026-11-03) [District of Columbia B 26-0810] Veola Jackson Way Designation Act of 2026
      Veola Jackson Way Designation Act of 2026
  - (2026-11-03) [District of Columbia B 26-0556] Fair Share Housing Targets Act of 2025
      Fair Share Housing Targets Act of 2025
  - (2026-11-03) [District of Columbia B 26-0852] University of the District of Columbia Multiyear Contract No. PO-GF-2026-C-0019 with Ellucian Company LLC Contract Emergency Act of 2026
      University of the District of Columbia Multiyear Contract No. PO-GF-2026-C-0019 with Ellucian Company LLC Contract Emergency Act of 2026

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-11-03) CFC3016 (Canada)
      icao24: c2b373 · position: (45.1891, -77.3084) · alt: 9204m · 652km/h
  - (2026-11-03) JEDI02 (United States)
      icao24: ae1eab · position: (30.3131, -87.9715) · alt: 2994m · 452km/h
  - (2026-11-03) JEDI52 (United States)
      icao24: ae1ead · position: (30.6023, -89.3219) · alt: 1173m · 359km/h
  - (2026-11-03) SAMU45 (France)
      icao24: 39ca86 · position: (47.7466, 1.9868) · alt: 373m · 215km/h
  - (2026-11-03) SAMU37 (France)
      icao24: 39ca87 · position: (47.3493, 0.7355) · alt: 220m · 163km/h
  - (2026-11-03) CFCF4259 (Canada)
      icao24: c2b5b7 · position: (45.0172, -68.8894) · alt: 8229m · 702km/h

### Paper Trading Scorecard — 20 new of 71 total
  - (2026-11-03) [Manifold] Will my Twitter account have 10+ followers 24 hours after this market was created?
  - (2026-11-03) [Manifold] Daily Coinflip
  - (2026-11-03) [Manifold] Will Astra 6.1+ be released this week (by November 8, 2026)?
  - (2026-11-03) [Manifold] Will Trump nuke Iran before 2028?
  - (2026-11-03) [Manifold] Republican Party mass extinction event?
  - (2026-11-03) [Manifold] Democrats win the House, Senate AND Presidency in 2028?

### Campaign finance (FEC: top fundraisers + recent filings) — 13 new of 27 total
  - (2026-11-02) [F24] FLORIDIANS FOR GOOD GOVERNMENT JAXPAC
      cycle 2026 · filing #2045851
  - (2026-11-02) [F24] UNITED FUTURE PAC
      cycle 2026 · filing #2045811
  - (2026-11-02) [F6] MORRISON FOR CONGRESS
      cycle 2026 · filing #2045897
  - (2026-11-02) [F6] OJEDA FOR NC
      cycle 2026 · filing #2045748
  - (2026-11-02) [F3] HUFFMAN FOR CONGRESS
      cycle 2026 · filing #2045964 · receipts $0.14M
  - (2026-11-02) [F5] YOUTH CIVIC ACCELERATOR INC.
      cycle 2026 · filing #2045865

### U.S. Federal Action — 12 new of 15 total
  - (2026-11-03) Streamlining Contested Adjudications in Licensing Proceedings
      The U.S. Nuclear Regulatory Commission (NRC, agency, or Commission) is revising the agency's rules of practice and procedure to streamline contested adjudications in NRC licensing proceedings in response to the Accelerat…
  - (2026-11-03) List of Approved Spent Fuel Storage Casks: TN Americas, LLC: Standardized NUHOMS® Horizontal Modular Storage System for Irradiated Nuclear Fuel, Certificate of Compliance No. 1004, Renewed Amendment N…
      The U.S. Nuclear Regulatory Commission (NRC) is confirming the effective date of November 9, 2026, for the direct final rule that was published in the Federal Register on August 26, 2026. This direct final rule amended t…
  - (2026-11-03) Review of the Commission's Broadcast and Cable Equal Employment Opportunity Rules and Policies; Delete, Delete, Delete
      In this document, the Media Bureau of the Federal Communications Commission (Commission) adopts an Order that removes a section of the Commission's Rules and references to that section to conform the Commission's Rules t…
  - (2026-11-03) National Emission Standards for Hazardous Air Pollutants: Lime Manufacturing Plants Technology Review; Correction
      The Environmental Protection Agency (EPA) is making a correction to the National Emission Standards for Hazardous Air Pollutants for Lime Manufacturing Plants (Lime Manufacturing NESHAP) technology review final rule that…
  - (2026-11-03) Compliance Procedure (52 U.S.C. 30109, 30107(a))
  - (2026-11-03) Airworthiness Directives; Airbus Helicopters
      The FAA proposes to adopt a new airworthiness directive (AD) for certain Airbus Helicopters Model AS350B2, AS350B3, and EC130B4 helicopters. This proposed AD was prompted by a report of an occurrence of partial blocking…

### USGS earthquakes (M4.5+, past day) — 10 new of 11 total
  - (2026-11-03) M 5.4 - 24 km NNW of Rioblanco, Colombia
      M5.4 · 24 km NNW of Rioblanco, Colombia · depth 10 km
  - (2026-11-02) M 5.3 - 81 km SSE of Palekastro, Greece
      M5.3 · 81 km SSE of Palekastro, Greece · depth 48.525 km
  - (2026-11-03) M 4.9 - South Sandwich Islands region
      M4.9 · South Sandwich Islands region · depth 143.595 km
  - (2026-11-03) M 4.9 - 101 km SSE of Palekastro, Greece
      M4.9 · 101 km SSE of Palekastro, Greece · depth 45.662 km
  - (2026-11-03) M 4.8 - 6 km S of Asahi, Japan
      M4.8 · 6 km S of Asahi, Japan · depth 52.267 km
  - (2026-11-03) M 4.7 - 74 km E of Petropavlovsk-Kamchatsky, Russia
      M4.7 · 74 km E of Petropavlovsk-Kamchatsky, Russia · depth 75.58 km

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-11-03) Dota 2: potn9ki vs HellNight- (BO3) - Esports Pro Circuit Group C
      yes price: 50% · 24h volume: $1,662,570 · resolves 2026-11-03
  - (2026-11-03) Will Republicans win Alaska, Iowa, Kansas, Michigan, and Texas, and lose Maine and Ohio?
      yes price: 0% · 24h volume: $1,384,058 · resolves 2026-11-03
  - (2026-11-03) US x Iran ceasefire continues through October 31?
      yes price: 90% · 24h volume: $1,302,241 · resolves 2026-10-31
  - (2026-11-03) US x Iran ceasefire continues through November 2?
      yes price: 87% · 24h volume: $1,296,481 · resolves 2026-11-03
  - (2026-11-03) Will the Democrats win the Texas Senate race in 2026?
      yes price: 74% · 24h volume: $1,137,951 · resolves 2026-11-04
  - (2026-11-03) US x Iran ceasefire continues through November 3?
      yes price: 3% · 24h volume: $766,928 · resolves 2026-11-04

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-03) [Marginal Revolution] Thoughts on Owning a Self-Driving Tesla
      My Subaru was showing its years so I recently bought a Tesla. My thinking was I can buy a car or I can buy a car+driver for the same price. Simple choice. I’ve driven about 2000 miles including one long trip (6 hours) to…
  - (2026-11-03) [Marginal Revolution] The economics of tips
      Tipping is large and growing, but we know little about its consequences for workers and firms. We link point-of-sale and payroll records at 20,000 U.S. firms, which lets us observe tips from customer payment to worker ea…
  - (2026-11-03) [Marginal Revolution] Are economists declining in status?
      That is the theme of my latest Free Press article. Excerpt, which offers the beginning of the story: If we look at the 1960s, the John F. Kennedy and Lyndon Baines Johnson administrations brought James Tobin, Robert Solo…
  - (2026-11-02) [Conversable Economist] “A Sick Society Must Think Much About Politics”: Election Day Thoughts
      The US Democrats and Republicans, together with other political activity around the world, probably takes up too much space in my head. In 1945, C.S. Lewis gave a talk on “Membership,” later published in his collection,…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=15, 14d-median=15; carrying terms: certain, action, regulatory, final, commission, published, safety, proposed, national, public, proposing, rulemaking
- state_bills: today=40, 7d-median=115, 14d-median=100; carrying terms: providing, alaska, emergency, insurance, review, vehicle, relating, health, district, income, authority, enforcement
- state_news: today=571, 7d-median=724, 14d-median=678; carrying terms: hawaii, board, commonwealthbeacon, largest, county, wyofile, policy, years, funding, ruled, reports, future
- local_news: today=256, 7d-median=256, 14d-median=248; carrying terms: county, blank, years, restaurants, atlantamagazine, administration, health, death, across, stlmag, missouri, figure
- foreign_news: today=992, 7d-median=1006, 14d-median=1006; carrying terms: zeitung, largest, human, talks, possible, timeout, years, funding, tinubu, levels, future, shows
- chinese_internal: today=304, 7d-median=281, 14d-median=278; carrying terms: blank, cbmib, cbmix, cbmixkfvx, cbmic, https, google, cbmia, cbmizkfvx, cbmidefvx, cbmiykfvx, color
- russian_internal: today=928, 7d-median=990, 14d-median=991; carrying terms: server, title, europe, blank, found, group, street, journal, media, russian, reuters, gazeta
- ukrainian_internal: today=128, 7d-median=129, 14d-median=130; carrying terms: negotiations, humanitarian, missile, ukraine, talks, continues, reports, foreign, russian, struck, announced, month
- ukraine_theater: today=329, 7d-median=377, 14d-median=390; carrying terms: qxuxdwc, blank, years, nuxucffweunzbnjyq, wddntm, starshield, wwrsqzvvyulfevu, ywpzehlnum, ntuejdulfxr, dhntb, struck, cuxon
- paper_bets: today=71, 7d-median=67, 14d-median=65; carrying terms: playoff, achieved, season, jackson, koivun, visit, supervolcano, career, lifetime, leaders, zohran, growth
- weather: today=98, 7d-median=134, 14d-median=136; carrying terms: warning, county, moderate, aviation, peninsula, forecast, peachtree, temperatures, possible, river, memphis, currents
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: sheet, jtsjol, spread, nonfarm, supply, payrolls, commodities, payems, total, growth, inflation, dexchus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, agriculture, credit, close, nasdaq, treasury, russell, range, china, large, silver, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=104, 14d-median=104; carrying terms: aeronautics, mufswgh, checksum, management, science, company, blank, paeez, operate, boeing, articles, foreign
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quantitative, unauthorized, httperror, https, error, quiver, client, quiverquant
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, court, supreme, international, appeals, blanche, trade, services, company, thomas, alabama, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, holdings, filer, subject, financial, trust, michael, finance, jpmorgan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cycle, filing, congress, sayed, disbursements, krishnamoorthi, raised, james, ossoff, sherrod, peltola, abdul
- gdelt_regions: today=0, 7d-median=6, 14d-median=9
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: english, keywords, themes, israel, sanctions, elections, spanish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, germany, canada, eagle, aabbef
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: viadana, bangladesh, mainly, arachidonic, largest, addition, senegal, discharged, caused, declaration, human, october
- cisa_kev: today=18, 7d-median=18, 14d-median=18; carrying terms: server, secure, command, remediation, vendor, injection, control, vulnerability, authentication, improper, product, external
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: papua, alert, japan, forest, impact, hurricane, guinea, fires, islands, maximum, speed, forestfire
- usgs_quakes: today=11, 7d-median=17, 14d-median=21; carrying terms: depth, vanuatu, japan, islands, russia, region, china, south, nagqu, sandwich, greece, village
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: election, resolves, volume, price, october, house, balance, senate, presidential, power, control, midterm
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, marginal, conversable, https, revolution, class, world, marginalrevolution, money, large, being, conversableeconomist
- tech_news: today=62, 7d-median=56, 14d-median=57; carrying terms: built, hacker, released, state, computer, research, techcrunch, systems, software, report, security, spectrum
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: angie, stansbury, board, sydney, rulli, mcclain, tonko, fitzgerald, steve, carey, khanna, suzanne
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, claude, placed, consensus, decision, today, identify, evidence, either, module, paper, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] ECB press: ECB President Lagarde to step down on 7 February 2027
- [2026-10-29] ECB press: Monetary policy decisions
- [2026-10-29] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-10-29] ECB press: Piero Cipollone: Next-day securities settlement, tokenisation and the transformation of Europe’s financial infrastructure
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Results of the ECB Survey of Professional Forecasters for the fourth quarter of 2026
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*