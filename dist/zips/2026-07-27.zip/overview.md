# WORLDSCOPE morning brief — 2026-07-27

## Headline
2531 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (636) · Russian Internal News (state + in-exile) (556) · World leaders & government officials (324) · Chinese Internal News (200) · U.S. Weather + Severe / Climate Outlooks (178) · Ukraine Theater (total-war monitoring) (135) · State-Level News (121) · Local News: St. Louis + Atlanta (87) · GDELT GKG — themes / entities / watch areas (44) · Ukrainian Internal News (national + local Kyiv) (38) · GDACS — global disaster alerts (38) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 636 new of 973 total
  - (2026-07-27) [Global] Uganda begins emergency food handouts after 19 die from hunger
  - (2026-07-27) [Global] Baby missing after mother and toddler found dead off coast of South Australia
  - (2026-07-27) [Global] British YouTuber Yung Filly describes night he met fan in Australian nightclub before allegedly raping her
  - (2026-07-27) [Global] NSW police deputy commissioner says letting Jewish security group carry guns could be seen as ‘favouritism’
  - (2026-07-27) [Global] Comedian who hosted Albanese’s ‘shag, marry, date’ interview says it was ‘moment taken out of context’ – as it happened
  - (2026-07-27) [Global] Senior politicians supported young NSW Liberal power brokers trying to shift party to right, corruption watchdog hears

### Russian Internal News (state + in-exile) — 556 new of 844 total
  - (2026-07-27) Казахстан из-за ударов Украины по порту Новороссийск вдвое сократил дневную добычу нефти | LEDE: Казахстан более чем вдвое сократил суточную добычу нефти после приостановки загрузки на экспо] (ru: Каз…
      Казахстан более чем вдвое сократил суточную добычу нефти после приостановки загрузки на экспортном терминале Каспийского трубопроводного консорциума (КТК) в Новороссийске, пишет Reuters, ссылаясь на источник в отрасли.
  - (2026-07-27) Легенда итальянского футбола Андреа Пирло должен был возглавить сборную Италии. Но от его кандидатуры отказались — из-за связей с российской букмекерской компанией | LEDE: Чемпион мира, леге] (ru: Лег…
      Чемпион мира, легендарный итальянский футболист Андреа Пирло заявил, что больше не является кандидатом на пост главного тренера сборной Италии. Об этом он сообщил в сторис в инстаграме. Пирло написал, что узнал об этом в…
  - (2026-07-27) В Москве топ-менеджера компании уволили за разглашение коммерческой тайны через DeepSeek | LEDE: Московская группа компаний «Энергопроф» уволила директора по продажам Екатерину Ремизову из-з] (ru: В М…
      Московская группа компаний «Энергопроф» уволила директора по продажам Екатерину Ремизову из-за нарушения условий коммерческой тайны. Среди прочего, компания была недовольна тем, что Ремизова отправляла внутренние отчеты…
  - (2026-07-27) Умер Гунтер фон Хагенс — изобретатель способа консервации человеческих тел после смерти и создатель выставки «Мир тела» | LEDE: Немецкий анатом Гунтер фон Хагенс умер 24 июля в возрасте 81 г] (ru: Уме…
      Немецкий анатом Гунтер фон Хагенс умер 24 июля в возрасте 81 года, сообщили его семья и Институт пластинации в Гейдельберге. Как пишет Heidelberg24, несколько лет назад у Хагенса диагностировали болезнь Паркинсона.
  - (2026-07-27) Евросоюз разрешил ввоз соболиного меха из России — через три месяца после запрета. Этого добились Италия и Греция | LEDE: Евросоюз исключил из списка товаров, запрещенных к импорту в страны ] (ru: Евр…
      Евросоюз исключил из списка товаров, запрещенных к импорту в страны блока, шкурки российского соболя. Запрет, действовавший с апреля, отменили в рамках 21-го пакета санкций, пишет Euractiv.
  - (2026-07-27) Война. 1615-й день. В Россию с фронта вернулись не менее 400 тысяч военных. Зеленский обещает россиянам новую мобилизацию после выборов в Госдуму | LEDE: «Медуза» с 24 февраля 2022 года в пр] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 200 new of 254 total
  - (2026-07-26) 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8tVlVpeVhuSlJuYjM3RFN1a3JNV05fRll1Y1hQaW9pdlFvTy1fLWx6ZU9RNGJiZVNyRmQtYWI1bzdnTThabVJoMnpOLWQxUXVOZ0tGekRqTEpKVlB] (zh:…
      商品详情 财新商城
  - (2026-07-27) 重庆彭水山体崩塌现场发现人体残骸 正检测DNA - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Bal9LLWllQXlpczFYenNTRy01UDZFQUFVQl9DaDB3MjR0WXpwXzF1c2hhcXdwRnA4MTJzM24xbVV0bHcwYURheHM4VWxFbG] (zh:…
      重庆彭水山体崩塌现场发现人体残骸 正检测DNA 财新
  - (2026-07-27) 今日开盘：沪指报3808.90点 跌幅0.14% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1MR1Y3cFh1TTFaUkxidXYyWnlCTklHN3Q0ODBOWXZCVGZIR3RxOVp3UjdPcVhySkNhd2xGYXo2dWRQR0FvTmFWQkt4U0hSV] (zh:…
      今日开盘：沪指报3808.90点 跌幅0.14% 财新
  - (2026-07-27) 植物学家的中国西南探险｜带着问题去读书 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9KQzZ2MFlhUlhSOEloaFIwak81UUlYSUZ1cHNueTRFTUlaU29GWUtVa2pCenFCcHo0MGltU0JIMmJsQ1F3RDR3VHBSTmxIYkNZWj] (zh:…
      植物学家的中国西南探险｜带着问题去读书 财新
  - (2026-07-27) 票房｜周星驰《功夫女足》被偷4亿元票房 三部电影撤档 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9LUl9pNWZxT3FVeDdJdUV5ajdmWWtUWEpLR0Z5RUZTN2Rvc2NDanA4M3NzamZBQkN3eTA4TXpfYlJHYktscmQ5dGxUQlR] (zh:…
      票房｜周星驰《功夫女足》被偷4亿元票房 三部电影撤档 财新
  - (2026-07-27) 李在明开启首次访美行程 韩美达成9500亿美元芯片合作 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9NZDFOSEFaM29kempSZ1J1VklIdjhVb3puUWJoWHd6TGF3aEJzUXRSMUFsaVM3UjRyYzFJMl9LTW1WVkdMZ09KRkFpel] (zh:…
      李在明开启首次访美行程 韩美达成9500亿美元芯片合作 财新

### U.S. Weather + Severe / Climate Outlooks — 178 new of 185 total
  - (2026-07-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 27 at 8:22AM EDT until July 27 at 8:30AM EDT by NWS Marquette MI
      At 821 AM EDT/721 AM CDT/, a severe thunderstorm was located near Bergland, or 8 miles southeast of Porcupine Mountains State Park, moving southeast at 55 mph. HAZARD...60 mph wind gusts and half dollar size hail. SOURCE…
  - (2026-07-27) [Severe] Flash Flood Warning: Flash Flood Warning issued July 27 at 7:21AM CDT until July 27 at 7:30AM CDT by NWS Nashville TN
      Heavy rainfall causing flooding has ended, but water levels will remain elevated along small streams and in flood prone areas. Any additional storms today will likely cause more flash flooding. Please continue to heed re…
  - (2026-07-27) [Severe] Special Marine Warning: Special Marine Warning issued July 27 at 8:19AM EDT until July 27 at 9:15AM EDT by NWS Marquette MI
      SMWMQT The National Weather Service in Marquette has issued a * Special Marine Warning for... Black River To Ontonagon MI... Lake Superior from Saxon Harbor WI to Upper Entrance to Portage Canal MI 5NM off shore to the U…
  - (2026-07-27) [Severe] Special Marine Warning: Special Marine Warning issued July 27 at 7:18AM CDT until July 27 at 7:45AM CDT by NWS Duluth MN
      For the following areas... Lake Superior west of a line from Saxon Harbor WI to Grand Portage MN beyond 5NM... Outer Apostle Islands Beyond 5 NM from Mainland... At 718 AM CDT, a severe thunderstorm was located 12 nm nor…
  - (2026-07-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-27) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 27 at 7:14AM CDT until July 28 at 8:00PM CDT by NWS Memphis TN
      * WHAT...Dangerously hot conditions with heat index values up to 115. * WHERE...Portions of East Arkansas, North Mississippi, Southeast Missouri, and West Tennessee. * WHEN...Until 8 PM CDT Tuesday. * IMPACTS...Heat rela…

### Ukraine Theater (total-war monitoring) — 135 new of 495 total
  - (2026-07-27) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-26) [FIRMS] thermal anomaly 48.532, 34.649 (FRP 1.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.98 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.521, 34.632 (FRP 2.24 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 2.24 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.474, 34.630 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.95 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.975, 24.707 (FRP 1.32 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.32 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.750, 26.604 (FRP 1.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.55 MW

### State-Level News — 121 new of 252 total
  - (2026-07-27) [California] California secures federal assistance to support response to Dove Fire in Tuolumne County
      Source
  - (2026-07-27) [California] What California can learn from LA’s hot mess era of governmental reforms
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/041723-Janice-Hahn-Karen-Bass-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-07-27) [California] Why California prisons are using their own employees as human fire alarms
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/101724-HECHINGER-Pelican-MO-CM-12.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-27) [California] California bill would let abuse victims use trauma as legal defense for violent crime
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092122-ROB-BONTA-GUN-CONTROL-DEPARTMENT-MHN-08-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-…
  - (2026-07-27) [Connecticut] Connecticut Primary Election 2026 Voter Guide
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2025/11/ELECTION-DAY-1104-SR-13-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-07-27) [Connecticut] Child neglect is vast in CT and DCF may not be so bad
      <img width="769" height="585" src="https://ctmirror.org/wp-content/uploads/2026/07/child-depressed-alone-poverty-e1784902289256.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="as…

### Local News: St. Louis + Atlanta — 87 new of 194 total
  - (2026-07-27) [St. Louis] How a St. Louis insurance exec used AI to help his wife’s facial paralysis
      Jeff Heaton turned to research when his wife, Tracy, suffered from left-sided facial paralysis following brain surgery. “I wanted to make sure she had the best options and the best care,” says Jeff, vice president of Art…
  - (2026-07-27) [St. Louis] St. Louis County executive candidates aren’t ready to endorse city-county unification
      Seven years after the failed Better Together plan to reunite St. Louis city and county, local leaders are again contemplating some sort of merger. Most recently, the Regional Business Council, which includes the area’s t…
  - (2026-07-27) [St. Louis] Western water reservoirs fall to record low levels
      Lake Mead and Lake Powell, the country’s two largest reservoirs, have fallen to their lowest combined levels on record.
  - (2026-07-27) [St. Louis] St. Louis obituaries for July 27
      Read through the obituaries published in the St. Louis Post-Dispatch
  - (2026-07-27) [St. Louis] Who's funding the campaign to scrap Missouri's income tax? Supporters aren't saying
      The campaign pushing for the income tax phaseout in Amendment 5 has accepted over $15 million in secretive contributions.
  - (2026-07-27) [St. Louis] St. Louis Zoo researchers trap turtles in Forest Park to monitor microplastics
      Researchers placed four accordion-like nets in a stream that runs past the Forest Park golf course.

### GDELT GKG — themes / entities / watch areas — 44 new of 44 total
  - (2026-07-27) [Israel-Iran-Hezbollah axis · themes] România a cheltuit 1 , 2 miliarde de euro pentru renovarea clădirilor prin componenta „ Valul Renovării din PNRR
      business24.ro · Romanian · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · themes] Trump is set to defend his economic policies in Michigan , where new Canadian tariffs may sting
      gazettextra.com · English · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · themes] Iran sebut tak akan biarkan AS tentukan waktu perang dan perdamaian
      antaranews.com · Indonesian · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · themes] Як ховають невпізнаного захисника : що каже закон ОГО . ua
      ogo.ua · Ukrainian · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · themes] En China presentaron un robot humanoide realista
      lv12.com.ar · Spanish · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · themes] Zelensky Wants to Build Major Drone Factory in united kingdom
      kyivpost.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 38 new of 117 total
  - (2026-07-27) Ексрегіонала з Сумщини засудили на 15 років за роботу на ФСБ | LEDE: Колишній член забороненої "Партії регіонів", який збирав для російської ФСБ дані про українських військових і закликав завда] (uk:…
      Колишній член забороненої "Партії регіонів", який збирав для російської ФСБ дані про українських військових і закликав завдавати ударів по позиціях ЗСУ в Сумській області, отримав 15 років позбавлення волі.
  - (2026-07-27) Синоптики розповіли, де найближчим часом чекати дощів та гроз | LEDE: Дощі з грозами очікуються у більшості областей України у вівторок, в середу стане прохолодніше.] (uk: Синоптики розповіли, де найб…
      Дощі з грозами очікуються у більшості областей України у вівторок, в середу стане прохолодніше.
  - (2026-07-27) ГУР ідентифікувало військових РФ, які вдарили дроном по АТБ в Чернігові | LEDE: Запуск реактивного дрона по супермаркету АТБ в Чернігові 26 липня, за даними української воєнної розвідки, здійсн] (uk:…
      Запуск реактивного дрона по супермаркету АТБ в Чернігові 26 липня, за даними української воєнної розвідки, здійснили російські військові бригади безпілотної авіації "Гром "каскад".
  - (2026-07-27) Росіяни вдень вдарили по Балаклії – 1 людину вбили, 8 поранили | LEDE: Унаслідок обстрілу Балаклії 27 липня одна людина загинула, вісім отримали поранення. Обставини події уточнюються.] (uk: Росіяни в…
      Унаслідок обстрілу Балаклії 27 липня одна людина загинула, вісім отримали поранення. Обставини події уточнюються.
  - (2026-07-27) Організатору виставки на Київщині, куди РФ завдала ракетного удару, обрали запобіжний захід | LEDE: Святошинський районний суд міста Києва обрав запобіжний захід керівнику асоціації "Армада", о] (uk:…
      Святошинський районний суд міста Києва обрав запобіжний захід керівнику асоціації "Армада", організатору виставки на Київщині Василю Гончаруку у вигляді тримання під вартою впродовж 60 діб без альтернативи застави.
  - (2026-07-27) "Будь-які прояви ксенофобії неприйнятні": посол відреагував на напад на українську пару у Вроцлаві | LEDE: Посол України в Польщі Василь Боднар відреагував на останній напад на українців, який ] (uk:…
      Посол України в Польщі Василь Боднар відреагував на останній напад на українців, який стався у Вроцлаві.

### GDACS — global disaster alerts — 38 new of 303 total
  - (2026-07-25) [Orange] Forest fires in Spain
      Wildfire · Orange alert · Spain · Orange impact for forestfire in 12089 ha
  - (2026-07-25) [Orange] Forest fires in Spain
      Wildfire · Orange alert · Spain · Orange impact for forestfire in 12089 ha
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-07-27) CFC3181 (Canada)
      icao24: c2b369 · position: (44.0039, -84.1679) · alt: 11582m · 799km/h
  - (2026-07-27) PAT912 (United States)
      icao24: adfe4a · position: (30.658, -89.3768) · alt: 990m · 428km/h
  - (2026-07-27) PAT555 (United States)
      icao24: adfe8d · position: (36.9131, -84.5849) · alt: 7620m · 539km/h
  - (2026-07-27) GAF117 (Germany)
      icao24: 3ea556 · position: (51.6727, -4.2767) · alt: 259m · 327km/h
  - (2026-07-27) SAMU06 (France)
      icao24: 39c901 · position: (43.6135, 6.871) · alt: 922m · 243km/h
  - (2026-07-27) CFC3393 (Canada)
      icao24: c2b3c3 · position: (45.5539, -79.5194) · alt: 9753m · 849km/h

### SEC Form 4 insider transactions (recent) — 24 new of 40 total
  - (2026-07-27) 425 - Cartesian Growth Corp II (0001889112) (Subject)
      filed 2026-07-27 12:18 UTC — Filed: 2026-07-27 AccNo: 0001104659-26-086863 Size: 1 MB
  - (2026-07-27) 424B3 - Jaguar Health, Inc. (0001585608) (Filer)
      filed 2026-07-27 12:00 UTC — Filed: 2026-07-27 AccNo: 0001193125-26-316920 Size: 281 KB
  - (2026-07-27) [Corebridge Financial, Inc.] Form 4 (Reporting)
      filed 2026-07-27 12:00 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001104659-26-086856 Size: 10 KB
  - (2026-07-27) [ClearBridge Energy Midstream Opportunity Fund Inc.] Form 4 (Issuer)
      filed 2026-07-27 12:00 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001104659-26-086856 Size: 10 KB
  - (2026-07-27) [AMERICAN GENERAL LIFE INSURANCE CO] Form 4 (Reporting)
      filed 2026-07-27 12:00 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001104659-26-086856 Size: 10 KB
  - (2026-07-27) 424B3 - Jaguar Health, Inc. (0001585608) (Filer)
      filed 2026-07-27 12:00 UTC — Filed: 2026-07-27 AccNo: 0001193125-26-316918 Size: 358 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 23 new of 57 total
  - (2026-07-27) [The Hacker News] Cruciferra Crypter Uses BYOVD and Process Ghosting to Hide Windows Malware
      The China-linked cybercrime group behind the use of income tax-related phishing lures targeting Indian taxpayers, tax professionals, and corporate finance teams has been observed using a sophisticated crypter service cal…
  - (2026-07-27) [The Hacker News] TELESHIM Abuses Telegram for C2 in Attacks Against Middle East Governments
      Cybersecurity researchers have flagged fresh malicious cyber activity by a threat actor with ties to East Asia targeting government entities in the Middle East. The intrusions have resulted in the deployment of previousl…
  - (2026-07-27) [The Hacker News] GitHub Adds 3-Day Dependabot Cooldown to Limit Poisoned Package Adoption
      GitHub has announced a new cooldown mechanism in Dependabot, allowing the tool to wait at least three days after a release is published before opening a pull request. "The cooldown configuration option in the dependabot.…
  - (2026-07-27) [The Record] Hackers used autonomous AI agent to spy on Thailand's finance ministry
      Hackers used an autonomous artificial intelligence agent to carry out a cyber-espionage campaign against Thailand's Ministry of Finance, researchers discovered.
  - (2026-07-27) [Cybersecurity Dive] In the Mythos era, security belongs at runtime
      Frontier AI cut time-to-exploit from years to hours. Why defense now has to happen at runtime.
  - (2026-07-27) [Cybersecurity Dive] What the Trojan horse gets right (and wrong) about AI security
      Agentic AI didn't invent new risk. It removed the friction that used to keep environments in check.

### USGS earthquakes (M4.5+, past day) — 17 new of 22 total
  - (2026-07-27) M 5.4 - 82 km SSW of San Pedro de Atacama, Chile
      M5.4 · 82 km SSW of San Pedro de Atacama, Chile · depth 106.991 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.1 - south of Tonga
      M5.1 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.0 - south of Tonga
      M5.0 · south of Tonga · depth 10 km

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-27) [China] Cina , incentivi alla sostituzione dei beni di consumo : stimolato un fatturato di 1 , 1 trilioni di RMB nel primo semestre
      italian.cri.cn · English
  - (2026-07-27) [China] Cina ha tratto in salvo 47 marinai vietnamiti nel Mar Cinese Meridionale
      italian.cri.cn · English
  - (2026-07-27) [China] While the world asks , China answers with actions
      sxdaily.com.cn · English
  - (2026-07-27) [China] How UOB is turning regional scale into customer relevance
      scmp.com · English
  - (2026-07-27) [China] Si Đinping razgovarao telefonom sa brazilskim predsednikom Lulom da Silvom
      serbian.cri.cn · English
  - (2026-07-27) [China] Vang Ji na sastanku posvećenom Globalnoj inicijativi za razvoj
      serbian.cri.cn · English

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-07-24) U.S. Court of Appeals, 10th Cir.: Horocofsky v. City of Lawrence, Kansas
  - (2026-07-24) Alaska Supreme Court: Darren M. v. Destiny D
  - (2026-07-23) U.S. Court of Appeals, 10th Cir.: Dressen v. AstraZeneca AB
  - (2026-07-21) U.S. Court of Appeals, D.C. Cir.: Thrivent Financial for Lutherans v. SEC
  - (2026-07-21) U.S. Court of Appeals, D.C. Cir.: Titan Consortium 1, LLC v. Argentine Republic
  - (2026-07-21) U.S. Court of Appeals, D.C. Cir.: United States v. Brittany Jones

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-07-27) LoL: T1 vs DN SOOPers (BO1) - KeSPA Cup Group Stage
      yes price: 58% · 24h volume: $1,028,512 · resolves 2026-07-27
  - (2026-07-27) LoL: T1 vs Nongshim Red Force (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $983,177 · resolves 2026-07-27
  - (2026-07-27) LoL: HANJIN BRION vs Dplus KIA (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $825,647 · resolves 2026-07-27
  - (2026-07-27) LoL: Hanwha Life Esports vs Kiwoom DRX (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $811,456 · resolves 2026-07-27
  - (2026-07-27) Will the Fed decrease interest rates by 25 bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $617,720 · resolves 2026-07-29
  - (2026-07-27) Will Tom Cotton win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $582,338 · resolves 2028-11-07

### Paper Trading Scorecard — 7 new of 132 total
  - (2026-07-27) [Polymarket] Will Ethereum dip to $1,600 in July?
      This market will resolve to "Yes" if any Binance 1 minute candle for ETH/USDT from the creation of this market through 11:59 PM ET on the last day of the month specified in the title has a final "High" or "Low" price equ…
  - (2026-07-27) [Manifold] Will Trump be reelected again
  - (2026-07-27) [Manifold] Will Steph Curry get traded before 2027?
  - (2026-07-27) [Manifold] Trump impeached before Iran war's end?
  - (2026-07-27) [Manifold] Will Tadej Pogacar win the 2027 Tour de France?
  - (2026-07-27) [Manifold] Will any cloned human organs, including the organs of viable cloned human infants, exist by EOY 2029?

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 33 total
  - (2026-07-27) #30 Germán Larrea Mota Velasco & family — $63.25B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-27) MOVER ▲ Amancio Ortega — $141.82B (+$0.76B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-27) MOVER ▲ Francoise Bettencourt Meyers & family — $92.33B (+$0.52B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-27) MOVER ▲ Bernard Arnault & family — $142.61B (+$0.39B since yesterday)
      France · Fashion & Retail · source: LVMH

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-27) [Marginal Revolution] Could our preoccupation with mental health be part of the problem?
      Could our preoccupation with mental health be part of the problem? In some ways, encouraging people to think and talk more about their mental health is a good thing. There is now less stigma around mental illness, and mo…
  - (2026-07-27) [Marginal Revolution] The Decline in the Transmission of Scientific Ideas
      We document that the diffusion of new scientific ideas beyond their field of origin has declined substantially over the past four decades. This contraction is closely linked to increasing specialization in scientific lan…

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 119 total
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=14, 14d-median=14; carrying terms: airworthiness, august, airspace, applicable, aircraft, additional, amending, security, reducing, published, national, prompted
- state_bills: today=14, 7d-median=66, 14d-median=66
- state_news: today=252, 7d-median=592, 14d-median=592; carrying terms: growing, maine, according, official, reject, concern, prison, dropped, nutrition, omaha, split, answers
- local_news: today=194, 7d-median=230, 14d-median=230; carrying terms: reported, google, offering, answers, cbmirafbvv, georgia, officers, arrest, photos, officials, cbmihafbvv, injured
- foreign_news: today=973, 7d-median=1014, 14d-median=1014; carrying terms: brought, identified, improper, official, overseas, interview, shaanxi, shock, google, firms, fashion, hague
- chinese_internal: today=254, 7d-median=282, 14d-median=282; carrying terms: cbmickfvx, google, cbmiw, color, https, chain, cbmiyefvx, china, cbmiakfvx, cbmib, caixin, cbmixkfvx
- russian_internal: today=844, 7d-median=838, 14d-median=838; carrying terms: guardian, centcom, gazeta, httperror, street, https, times, starship, novaya, margin, laquo, axios
- ukrainian_internal: today=117, 7d-median=138, 14d-median=138; carrying terms: reported, growing, according, offered, moscow, warning, interview, shadow, entry, institute, despite, regions
- ukraine_theater: today=495, 7d-median=540, 14d-median=540; carrying terms: reported, aznlrnnib, mghvruhymwixvejym, blldv, cuxon, cbmiigfbvv, fsdzbqn, pfslzcefbxu, wktrymzucdvzew, cneyotvsrhzfsupxethzq, google, firms
- paper_bets: today=132, 7d-median=140, 14d-median=140; carrying terms: pirates, maine, august, alaska, colonize, according, arizona, performing, fuentes, official, fifty, publicly
- weather: today=185, 7d-median=180, 14d-median=180; carrying terms: large, swell, warning, depth, illnesses, norman, georgia, briefly, outdoor, hazards, monitoring, ocean
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: sheet, money, dexjpus, labor, assets, dcoilwtico, unrate, cpiaucsl, nonfarm, headline, growth, pcepilfe
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: futures, commodities, large, silver, crypto, china, rates, agriculture, russell, nasdaq, range, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=119, 7d-median=119, 14d-median=119; carrying terms: sectoral, committees, description, campaign, google, contract, stability, institute, herzegovina, counter, zunvhbvnhyks, involvement
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quantitative, congresstrading, client, httperror, error, https, quiver, quiverquant
- billionaires: today=33, 7d-median=32, 14d-median=32; carrying terms: changpeng, yiming, diversified, ballmer, retail, charles, exchange, china, bezos, spain, nasdaq, india
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: trade, blanche, delaware, state, services, california, robert, international, holdings, court, school, ahmed
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, david, accno, reporting, issuer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, senate, david, congress, disbursements, trone, committee, cooper, alexandria, johnson, colorado, jonathan
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=44, 7d-median=47, 14d-median=47; carrying terms: trump, english, hezbollah, israel, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=20, 14d-median=20
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: reported, genetic, conflict, remaining, imported, identified, august, according, ventilation, official, releases, history
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: vendor, fortinet, appliances, vulnerability, access, insufficient, injection, improper, remediation, forgery, services, microsoft
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=303, 7d-median=179, 14d-median=179; carrying terms: medium, guinea, cambodia, republic, speed, spain, papua, romania, bosnia, salvador, venezuela, tropical
- usgs_quakes: today=22, 7d-median=22, 14d-median=22; carrying terms: south, islands, depth, atlantic, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, volume, meeting, interest, resolves, minister, rates, ethiopia, price
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, conversable, marginalrevolution, growth, benefit, marginal, class, economist, useful, perhaps, revolution
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: light, suspend, researchers, doctors, campaign, haven, minister, theft, download, security, engineers, rubio
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: vasquez, danny, coons, hickenlooper, components, doris, balart, harder, bentz, moran, warnock, mcgarvey
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, claude, identify, today, decision, unavailable, evidence, module, placed, sufficient, paper, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*