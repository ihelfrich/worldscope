# WORLDSCOPE morning brief — 2026-07-27

## Headline
2292 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (529) · Russian Internal News (state + in-exile) (475) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (207) · U.S. Weather + Severe / Climate Outlooks (192) · Chinese Internal News (176) · State-Level News (56) · Local News: St. Louis + Atlanta (51) · GDELT GKG — themes / entities / watch areas (49) · Conflict & unrest (GDELT, last 48h) (40) · GDACS — global disaster alerts (38) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 529 new of 949 total
  - (2026-07-27) [Global] Death toll from Pakistan monsoon rains, floods tops 100
      Punjab’s monsoon season usually lasts until September, and more rain is expected this week.
  - (2026-07-27) [Global] Greta Thunberg joins London rally in support of Indian students
      Climate activist Greta Thunberg joined a London rally in support of India’s Cockroach Janta Party-led student movement.
  - (2026-07-27) [Global] Spanish PM Pedro Sanchez thanks young Gaza artist for painting him
      Spanish Prime Minister Pedro Sanchez has thanked Layan Al Quqa, a young artist in Gaza for painting a mural of him
  - (2026-07-27) [Global] World’s oldest professional footballer scores first goal in years
      World’s oldest professional footballer scores first goal in years
  - (2026-07-27) [Global] Netanyahu accuses Mamdani of ‘fomenting hate’ ahead of US visit
      Israeli Prime Minister Benjamin Netanyahu accused mayor Zohran Mamdani of 'fomenting hate'.
  - (2026-07-27) [Global] The AI military complex: Which are the main companies in it?
      Billions of dollars are flowing into a handful of companies now leading the AI transformation of militaries.

### Russian Internal News (state + in-exile) — 475 new of 794 total
  - (2026-07-27) Ведущая блога «Адские бабки» Александра Баязитова вышла на свободу. Она провела в заключении четыре года по делу о вымогательстве | LEDE: Автор блога «Адские бабки» Александра Баязитова, осу] (ru: Вед…
      Автор блога «Адские бабки» Александра Баязитова, осужденная по делу о вымогательстве, освободилась из колонии. Видео с журналисткой опубликовало издание «Пост-».
  - (2026-07-27) Власти Удмуртии сообщили о «самой массированной атаке» украинских беспилотников на регион. Зеленский заявил, что Украина ударила по нефтяному объекту | LEDE: Глава Удмуртии Александр Бречало] (ru: Вла…
      Глава Удмуртии Александр Бречалов сообщил утром 27 июля, что Украина атаковала регион беспилотниками. По его словам, силы ПВО отражают «самую массированную атаку за последнее время».
  - (2026-07-27) В Литве хотят обязать российских артистов, выступающих в стране, подписывать антивоенную декларацию. Если они откажутся — их не впустят | LEDE: МИД Литвы предлагает ужесточить закон о национ] (ru: В Л…
      МИД Литвы предлагает ужесточить закон о национальных санкциях и обязать приезжающих в страну с публичными выступлениями российских и белорусских деятелей культуры подписывать антивоенную декларацию.
  - (2026-07-27) ФСБ задержала 55-летнего жителя Хабаровска по делу о госизмене. Его обвинили в передаче данных разведке Новой Зеландии | LEDE: Сотрудники ФСБ задержали 55-летнего жителя Хабаровска по обвине] (ru: ФСБ…
      Сотрудники ФСБ задержали 55-летнего жителя Хабаровска по обвинению в передаче данных разведке Новой Зеландии, заявили в Центре общественных связей спецслужбы.
  - (2026-07-27) FT: в ЕС рассматривают вариант больше не принимать санкции против России «пакетами» — чтобы избежать вето со стороны некоторых государств | LEDE: Европейские страны рассматривают новый подхо] (ru: FT:…
      Европейские страны рассматривают новый подход к процессу принятия санкций против России после того, как Греция задержала предыдущий крупный пакет, требуя исключений для своей судоходной компании, пишет Financial Times со…
  - (2026-07-27) Цена нефти Brent опустилась ниже 90 долларов на фоне паузы в ударах США и Ирана | LEDE: Стоимость сентябрьских фьючерсов на нефть марки Brent в ходе торгов упала на 7,4%, опустившись ниже 90] (ru: Цен…
      Стоимость сентябрьских фьючерсов на нефть марки Brent в ходе торгов упала на 7,4%, опустившись ниже 90 долларов за баррель, сообщает Bloomberg.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 207 new of 562 total
  - (2026-07-27) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-26) [Liveuamap] Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com - Liveuamap
      Sudan latest news in English on live map - South Sudan and Sudan News in English - sudan.liveuamap.com Liveuamap
  - (2016-04-27) [Liveuamap] Israel-Palestine - Liveuamap
      Israel-Palestine Liveuamap
  - (2026-07-26) [Liveuamap] Romania&039;s F-16 shot down another drone over territorial waters near Sulina-Khilia this morning, the third in three days. Friday&039;s drone confirmed as a Russian Shahed. A diplomatic…
      Romania&039;s F-16 shot down another drone over territorial waters near Sulina-Khilia this morning, the third in three
  - (2026-07-27) [Liveuamap] Violent clashes broke out between Houthis forces and Saudi-backed militias on the Marib and Al-Dhale' fronts. - Liveuamap
      Violent clashes broke out between Houthis forces and Saudi-backed militias on the Marib and Al-Dhale' fronts. &nbs
  - (2026-07-27) [Liveuamap] Fars News Agency, quoting the Iranian Ministry of Health: The death toll from the recent US attacks has risen to 55 dead and 645 wounded. Hormozgan Province, Iran - Liveuamap
      Fars News Agency, quoting the Iranian Ministry of Health: The death toll from the recent US attacks has risen to 55 dead and

### U.S. Weather + Severe / Climate Outlooks — 192 new of 200 total
  - (2026-07-27) [Moderate] Special Weather Statement: Special Weather Statement issued July 27 at 4:29AM CDT by NWS Huntsville AL
      At 429 AM CDT, Doppler radar was tracking a strong thunderstorm near Killen, or 7 miles northeast of Muscle Shoals, moving south at 40 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds…
  - (2026-07-27) [Moderate] Special Weather Statement: Special Weather Statement issued July 27 at 4:27AM CDT by NWS Green Bay WI
      At 426 AM CDT, Doppler radar was tracking strong thunderstorm from the southern bay of Green Bay to Luxemburg, moving southeast at 30 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar indicated. IMP…
  - (2026-07-27) [Moderate] Heat Advisory: Heat Advisory issued July 27 at 4:27AM CDT until July 28 at 8:00PM CDT by NWS New Orleans LA
      * WHAT...Heat index values up to 110 expected. * WHERE...Portions of southeast Louisiana and southern Mississippi. * WHEN...From 11 AM through 8 PM today and again Tuesday. * IMPACTS...Hot temperatures and high humidity…
  - (2026-07-27) [Moderate] Heat Advisory: Heat Advisory issued July 27 at 4:27AM CDT until July 27 at 8:00PM CDT by NWS New Orleans LA
      * WHAT...For the Heat Advisory, heat index values up to 110 expected. For the Extreme Heat Watch, dangerously hot conditions with heat index values up to 115 possible. * WHERE...Portions of southeast Louisiana and southe…
  - (2026-07-27) [Moderate] Heat Advisory: Heat Advisory issued July 27 at 4:27AM CDT until July 27 at 8:00PM CDT by NWS New Orleans LA
      * WHAT...Heat index values up to 110 expected. * WHERE...Portions of southeast Louisiana and southern Mississippi. * WHEN...From 11 AM through 8 PM today and again Tuesday. * IMPACTS...Hot temperatures and high humidity…
  - (2026-07-27) [Severe] Extreme Heat Watch: Extreme Heat Watch issued July 27 at 4:27AM CDT until July 28 at 8:00PM CDT by NWS New Orleans LA
      * WHAT...For the Heat Advisory, heat index values up to 110 expected. For the Extreme Heat Watch, dangerously hot conditions with heat index values up to 115 possible. * WHERE...Portions of southeast Louisiana and southe…

### Chinese Internal News — 176 new of 249 total
  - (2026-07-26) 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8tVlVpeVhuSlJuYjM3RFN1a3JNV05fRll1Y1hQaW9pdlFvTy1fLWx6ZU9RNGJiZVNyRmQtYWI1bzdnTThabVJoMnpOLWQxUXVOZ0tGekRqTEpKVlB] (zh:…
      商品详情 财新商城
  - (2026-07-27) 重庆彭水山体崩塌现场发现人体残骸 正检测DNA - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Bal9LLWllQXlpczFYenNTRy01UDZFQUFVQl9DaDB3MjR0WXpwXzF1c2hhcXdwRnA4MTJzM24xbVV0bHcwYURheHM4VWxFbG] (zh:…
      重庆彭水山体崩塌现场发现人体残骸 正检测DNA 财新
  - (2026-07-27) 今日开盘：沪指报3808.90点 跌幅0.14% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1MR1Y3cFh1TTFaUkxidXYyWnlCTklHN3Q0ODBOWXZCVGZIR3RxOVp3UjdPcVhySkNhd2xGYXo2dWRQR0FvTmFWQkt4U0hSV] (zh:…
      今日开盘：沪指报3808.90点 跌幅0.14% 财新
  - (2026-07-27) 植物学家的中国西南探险｜带着问题去读书 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9KQzZ2MFlhUlhSOEloaFIwak81UUlYSUZ1cHNueTRFTUlaU29GWUtVa2pCenFCcHo0MGltU0JIMmJsQ1F3RDR3VHBSTmxIYkNZWj] (zh:…
      植物学家的中国西南探险｜带着问题去读书 财新
  - (2026-07-27) 票房｜周星驰《功夫女足》被偷4亿元票房 三部电影撤档 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9LUl9pNWZxT3FVeDdJdUV5ajdmWWtUWEpLR0Z5RUZTN2Rvc2NDanA4M3NzamZBQkN3eTA4TXpfYlJHYktscmQ5dGxUQlR] (zh:…
      票房｜周星驰《功夫女足》被偷4亿元票房 三部电影撤档 财新
  - (2026-07-27) 新股王“登基” 长鑫科技开盘价涨超470%、市值突破3万亿、中一签赚2万 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBSWllZT05ZMU5vUWtsckpUSEhwQlpmcnpyUXVUSXhTOUk3MEVnVUNRdjhDRUR6N2hVaXdKejdXLXNlVzNMZ] (zh:…
      新股王“登基” 长鑫科技开盘价涨超470%、市值突破3万亿、中一签赚2万 财新

### State-Level News — 56 new of 194 total
  - (2026-07-27) [California] California secures federal assistance to support response to Dove Fire in Tuolumne County
      Source
  - (2026-07-27) [Connecticut] Child neglect is vast in CT and DCF may not be so bad
      <img width="769" height="585" src="https://ctmirror.org/wp-content/uploads/2026/07/child-depressed-alone-poverty-e1784902289256.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="as…
  - (2026-07-27) [Connecticut] Let’s have democracy funds throughout CT
      <img width="1024" height="643" src="https://ctmirror.org/wp-content/uploads/2026/07/AP-democracy-vouchers.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://c…
  - (2026-07-27) [Delaware] How does Delaware operate without a sales tax? The state’s corporate franchise has it covered
      Civics 101 Special Series: The Corporate CapitalPart 3: Delaware prospers from its “franchise” For over 100 years, a quiet force has been benefiting Delawareans. Few are aware of its presence in their daily life, but its…
  - (2026-07-27) [Delaware] Discover the century-long legal advantage that fuels Delaware’s growth
      <img width="994" height="582" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/07/chancery-court-1-1-1.jpg?fit=994%2C582&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-07-27) [Florida] Corruption by Another Name (Part II)
      In announcing closure of the Everglades immigration detention center known as “Alligator Alcatraz,” Gov. Ron DeSantis said the notorious facility — denounced as inhumane by civil rights groups — was always meant to be on…

### Local News: St. Louis + Atlanta — 51 new of 175 total
  - (2026-07-27) [St. Louis] Here are the statuses of the victims, including a 2-year-old, in the Seattle Center shooting
      Two people died at the scene of the shooting; another died in the hospital, where four others are being treated, officials said.
  - (2026-07-27) [St. Louis] Suspect in custody following deadly shooting near Seattle's Space Needle that killed 3
      Seven people were injured and three people were killed after a shooting Sunday evening during a festival near Seattle's Space Needle.
  - (2026-07-27) [St. Louis] Ruler Foods closure leaves some south St. Louis residents searching for affordable groceries
      Ruler Foods will close its South Grand Boulevard store on July 31, leaving South St. Louis residents worried about losing affordable, walkable grocery access.
  - (2026-07-27) [St. Louis] Lakkzoom water heaters recalled after 235 reports catching fire
      The Lakkzoom immersion water heaters were sold on Amazon.com and eBay.com from September 2022 through July 2026.
  - (2026-07-27) [St. Louis] Department of Energy issues emergency order across 17 states to help prevent power blackouts
      The U.S. Department of Energy issued an emergency order to activate backup power from North Dakota to Louisiana as extreme heat can endanger the grid.
  - (2026-07-27) [St. Louis] 15-year-old shot and killed in Kentucky months after being honored for saving child
      Da’Jon Anthony Hayes-Burr, 15, saved a young girl in April. Three months later, he was shot and killed in Louisville, Kentucky.

### GDELT GKG — themes / entities / watch areas — 49 new of 49 total
  - (2026-07-27) [Russia oil sanctions perimeter · themes] Sõja ülevaade : 1615 . päev - vene pool suudab hoida kõrget tempot
      lounaeestlane.ee · Estonian · tone NA
  - (2026-07-27) [Russia oil sanctions perimeter · themes] Трамп в тупике : в Конгрессе нарастает критика , а Иран не намерен уступать
      news.israelinfo.co.il · Russian · tone NA
  - (2026-07-27) [Russia oil sanctions perimeter · themes] 知情人士 ： 美军中东最高指挥官认为空袭伊朗难再见效
      news.ifeng.com · Chinese · tone NA
  - (2026-07-27) [Russia oil sanctions perimeter · themes] Marchés : le pétrole chute avec laccalmie united states - Iran
      rfj.ch · French · tone NA
  - (2026-07-27) [Russia oil sanctions perimeter · themes] Яка харчова звичка знижує ризик хронічних захворювань - чому важливо харчуватися різноманітно - який раціон зміцнює здоров я
      healthnews.obozrevatel.com · Ukrainian · tone NA
  - (2026-07-27) [Russia oil sanctions perimeter · themes] CENTRO TECNOLÓGICO PARA O PRÉ - SAL AVANÇA EM TESTES DE INOVAES QUE PROMETEM REVOLUCIONAR O MERCADO SUBSEA DO BRASIL
      petronoticias.com.br · Portuguese · tone NA

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-27) [Syria] Lebanon Tightens Control of Ports , Drying Up Hezbollah Funding Sources
      domain: english.aawsat.com · language: English · tone:
  - (2026-07-27) [Syria] Kuwait Condemns Repeated Houthi Militia Attacks on Ships in Red Sea
      domain: english.aawsat.com · language: English · tone:
  - (2026-07-27) [] Man who rescued woman bitten by shark wins world paddleboard championship
      domain: rnz.co.nz · language: English · tone:
  - (2026-07-27) [India] Oil Prices Plunge 4 % as US and Iran Halt Military Strikes : Diplomatic Hope Emerges , ETAuto
      domain: auto.economictimes.indiatimes.com · language: English · tone:
  - (2026-07-27) [United Kingdom] RAF plane declares emergency over Liverpool as pilot issues squawk alert
      domain: mirror.co.uk · language: English · tone:
  - (2026-07-27) [] Need more context and information ; Ranjini Haridas to join PSC rank - holder protest ?
      domain: keralakaumudi.com · language: English · tone:

### GDACS — global disaster alerts — 38 new of 303 total
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-07-27) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (48.7292, 2.3537) · on ground · 22km/h
  - (2026-07-27) JAF56C (Bulgaria)
      icao24: 4520aa · position: (38.2488, -7.5599) · alt: 10980m · 893km/h
  - (2026-07-27) GAF117 (Germany)
      icao24: 3ea556 · position: (51.955, 5.0058) · alt: 9753m · 600km/h
  - (2026-07-27) GAF114 (Germany)
      icao24: 3f727c · position: (48.5544, 8.7785) · alt: 5783m · 591km/h
  - (2026-07-27) GAF891 (Germany)
      icao24: 3f97fd · position: (51.8841, 0.1831) · alt: 10363m · 728km/h
  - (2026-07-27) RFF07 (Portugal)
      icao24: 496ca7 · position: (37.015, -7.9802) · on ground · 53km/h

### Ukrainian Internal News (national + local Kyiv) — 28 new of 100 total
  - (2026-07-27) У Польщі напали на молоду пару українців "через акцент" | LEDE: Правоохоронці Польщі розслідують інцидент: у Вроцлаві напали на молоду українську пару.] (uk: У Польщі напали на молоду пару українців "…
      Правоохоронці Польщі розслідують інцидент: у Вроцлаві напали на молоду українську пару.
  - (2026-07-27) У Харкові російський дрон знову влучив в АЗС: двоє людей постраждали | LEDE: Російські війська 27 липня атакували АЗС у Харкові: двоє людей постраждали.] (uk: У Харкові російський дрон знову влучив в…
      Російські війська 27 липня атакували АЗС у Харкові: двоє людей постраждали.
  - (2026-07-27) Зросла кількість жертв удару росіян по полігону під Києвом | LEDE: Після ракетного удару РФ по полігону на Київщині 24 липня загинуло 11 людей, серед жертв — дипломат Мальтійського ордену.] (uk: Зросл…
      Після ракетного удару РФ по полігону на Київщині 24 липня загинуло 11 людей, серед жертв — дипломат Мальтійського ордену.
  - (2026-07-27) Суд дав 8 років тюрми водійці, з вини якої в ДТП загинули мати та 13-річний син | LEDE: Суд визнав 31-річну водійку винною у порушенні правил безпеки дорожнього руху, що спричинило загибель дво] (uk:…
      Суд визнав 31-річну водійку винною у порушенні правил безпеки дорожнього руху, що спричинило загибель двох людей та травмування ще однієї у грудні 2025 року.
  - (2026-07-27) РФ знову атакувала Запоріжжя: є поранені | LEDE: Російська армія 27 липня знову атакувала Запоріжжя. Унаслідок цього пошкоджені будинки, двоє людей поранені.] (uk: РФ знову атакувала Запоріжжя: є пора…
      Російська армія 27 липня знову атакувала Запоріжжя. Унаслідок цього пошкоджені будинки, двоє людей поранені.
  - (2026-07-27) ЮНЕСКО внесла до Списку всесвітньої спадщини пляжі висадки союзників в Нормандії та гору Олімп | LEDE: ] (uk: ЮНЕСКО внесла до Списку всесвітньої спадщини пляжі висадки союзників в Нормандії)

### USGS earthquakes (M4.5+, past day) — 14 new of 20 total
  - (2026-07-27) M 5.4 - 82 km SSW of San Pedro de Atacama, Chile
      M5.4 · 82 km SSW of San Pedro de Atacama, Chile · depth 106.991 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.1 - south of Tonga
      M5.1 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.0 - south of Tonga
      M5.0 · south of Tonga · depth 10 km

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 57 total
  - (2026-07-27) [The Hacker News] TELESHIM Abuses Telegram for C2 in Attacks Against Middle East Governments
      Cybersecurity researchers have flagged fresh malicious cyber activity by a threat actor with ties to East Asia targeting government entities in the Middle East. The intrusions have resulted in the deployment of previousl…
  - (2026-07-27) [The Hacker News] GitHub Adds 3-Day Dependabot Cooldown to Limit Poisoned Package Adoption
      GitHub has announced a new cooldown mechanism in Dependabot, allowing the tool to wait at least three days after a release is published before opening a pull request. "The cooldown configuration option in the dependabot.…
  - (2026-07-27) [Cybersecurity Dive] In the Mythos era, security belongs at runtime
      Frontier AI cut time-to-exploit from years to hours. Why defense now has to happen at runtime.
  - (2026-07-27) [Cybersecurity Dive] What the Trojan horse gets right (and wrong) about AI security
      Agentic AI didn't invent new risk. It removed the friction that used to keep environments in check.
  - (2026-07-27) [The Register] The roller coaster works, but the Six Flags kiosk has gone off the rails
      Would you like an error with your terror?
  - (2026-07-27) [The Register] FOSS smashed one Microsoft monopoly. After 20 years of failure, it's time to smash another
      Word up

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-27) Will CXMT’s market cap be 400 billion yuan or greater at market close on IPO day by December 31, 2026?
      yes price: 100% · 24h volume: $2,135,847 · resolves 2026-12-31
  - (2026-07-27) LoL: KT Rolster vs Gen.G (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $1,098,194 · resolves 2026-07-27
  - (2026-07-27) LoL: Dplus KIA vs T1 (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $962,433 · resolves 2026-07-27
  - (2026-07-27) LoL: Dplus KIA vs Hanwha Life Esports (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $961,142 · resolves 2026-07-27
  - (2026-07-27) Will Tom Cotton win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $582,344 · resolves 2028-11-07
  - (2026-07-27) Will the Fed decrease interest rates by 25 bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $462,688 · resolves 2026-07-29

### Paper Trading Scorecard — 8 new of 134 total
  - (2026-07-27) [Polymarket] Israel military action against Yemen by July 31?
      This market will resolve to “Yes” if Israel takes a qualifying military action against Yemen by the specified date, 11:59 PM Arabia Standard Time (AST). Otherwise this market will resolve to “No.” A qualifying military a…
  - (2026-07-27) [Polymarket] Will a European country take military action on Iran by July 31?
      This market will resolve to “Yes” if any European country takes a qualifying military action against Iran by the specified date, 11:59 PM Central European Summer Time (CEST). Otherwise this market will resolve to “No.” A…
  - (2026-07-27) [Manifold] Will Trump be reelected again
  - (2026-07-27) [Manifold] Will Steph Curry get traded before 2027?
  - (2026-07-27) [Manifold] Trump impeached before Iran war's end?
  - (2026-07-27) [Manifold] Will Tadej Pogacar win the 2027 Tour de France?

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 8 new of 37 total
  - (2026-07-27) #30 Germán Larrea Mota Velasco & family — $63.25B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-27) MOVER ▲ Amancio Ortega — $141.06B (+$3.37B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-27) MOVER ▼ Masayoshi Son — $62.46B ($-1.82B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-27) MOVER ▲ Bernard Arnault & family — $142.45B (+$1.25B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-27) MOVER ▲ Tadashi Yanai & family — $64.47B (+$0.83B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-27) MOVER ▲ Mukesh Ambani — $86.61B (+$0.11B since yesterday)
      India · Diversified · source: Diversified

### Court opinions of consequence (federal & state) — 7 new of 60 total
  - (2026-07-24) Alaska Supreme Court: Darren M. v. Destiny D
  - (2026-07-24) U.S. Court of Appeals, 10th Cir.: Horocofsky v. City of Lawrence, Kansas
  - (2026-07-23) U.S. Court of Appeals, 10th Cir.: Dressen v. AstraZeneca AB
  - (2026-07-21) U.S. Court of Appeals, 1st Cir.: Recchia v. Campbell
  - (2026-07-21) U.S. Court of International Trade: Comm. Overseeing Action for Lumber Int'l Trade Investigations or Negots. v. United States
  - (2026-07-21) Connecticut Supreme Court: Campelli v. Mansfield

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-27) [South Korea] Govt Upgrades Heat Wave Crisis Advisory to Highest Level l KBS WORLD
      world.kbs.co.kr · English
  - (2026-07-27) [South Korea] 4 More S . Korean Tidal Flats Added to UNESCO World Heritage List
      world.kbs.co.kr · English
  - (2026-07-27) [South Korea] 2 More Fatalities from Heat - Related Illnesses Reported amid Heat Wave
      world.kbs.co.kr · English
  - (2026-07-27) [South Korea] Shin Ji - eun Wins 2nd LGPA Title
      world.kbs.co.kr · English
  - (2026-07-27) [South Korea] KFA Presidential Election Voter Pool to Expand from 300 to Over 10 , 000
      world.kbs.co.kr · English
  - (2026-07-27) [South Korea] Yoon conviction in election law case could put PPP on hook for 39 . 7B won in campaign expenses
      hani.co.kr · English

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-27) [Marginal Revolution] Could our preoccupation with mental health be part of the problem?
      Could our preoccupation with mental health be part of the problem? In some ways, encouraging people to think and talk more about their mental health is a good thing. There is now less stigma around mental illness, and mo…
  - (2026-07-27) [Marginal Revolution] The Decline in the Transmission of Scientific Ideas
      We document that the diffusion of new scientific ideas beyond their field of origin has declined substantially over the past four decades. This contraction is closely linked to increasing specialization in scientific lan…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=14, 14d-median=14; carrying terms: landing, final, fishery, revising, commission, published, limited, requires, adopting, council, special, standard
- state_bills: today=0, 7d-median=117, 14d-median=117
- state_news: today=194, 7d-median=592, 14d-median=592; carrying terms: height, reached, pressherald, mexico, michigan, commentary, educational, belonging, decades, speaker, journal, terms
- local_news: today=175, 7d-median=230, 14d-median=230; carrying terms: mexico, getting, election, final, building, experience, health, police, braves, media, words, areas
- foreign_news: today=949, 7d-median=1014, 14d-median=1014; carrying terms: kyivindependent, height, defend, poland, measuring, involving, terms, experts, delivers, visas, guarantee, promotes
- chinese_internal: today=249, 7d-median=282, 14d-median=282; carrying terms: cbmiz, cbmidefvx, cbmibkfvx, cbmickfvx, lxtfa, cbmibefvx, deepseek, chain, google, cbmiyefvx, https, cbmib
- russian_internal: today=794, 7d-median=814, 14d-median=814; carrying terms: style, journal, found, europe, novaya, httperror, laquo, street, https, spacex, guardian, forbidden
- ukrainian_internal: today=100, 7d-median=138, 14d-median=138; carrying terms: kyivindependent, poland, unlikely, damaging, final, freedom, crisis, building, include, aerial, eight, damaged
- ukraine_theater: today=562, 7d-median=574, 14d-median=574; carrying terms: poland, viirs, pmcupszxbptejqdezrvhnkewrmynboeddpai, ntbho, nyala, wlpuehloedfat, cuxqumzey, wegjhrzjanexfrervndhmzhdtvw, djjnvzk, cuxoeulwwvlvbgzhzetbtkflvmdszfzun, jtywo, league
- paper_bets: today=134, 7d-median=140, 14d-median=140; carrying terms: seats, humans, mexico, michigan, cousins, valuable, publicly, matthew, world, theme, nuclear, debut
- weather: today=200, 7d-median=180, 14d-median=180; carrying terms: fallen, mexico, creeks, afdmtr, message, afdhgx, okaloosa, mount, damaging, synopsis, producing, chance
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexchus, headline, treasury, funds, pcepilfe, growth, payems, implied, commodities, total, spread, dexjpus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: large, treasury, natural, bitcoin, range, nasdaq, futures, crude, commodities, crypto, close, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=118, 7d-median=118, 14d-median=118; carrying terms: haitian, trade, landing, equipment, rights, groups, hybrid, abuses, sectoral, maintenance, svewsgvsuthdntnoyjntexgxalveltdpmhrirulprkm, agency
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, quiverquant, congresstrading, unauthorized, client, httperror, quiver, https, error
- billionaires: today=37, 7d-median=32, 14d-median=32; carrying terms: googl, investments, mexico, yanai, fashion, charles, masayoshi, peterffy, huang, china, semiconductors, arnault
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: trade, state, ahmed, supreme, california, delaware, douglas, school, appeals, blanche, international, robert
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, amended, reporting, accno, issuer, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: plumbing, james, angels, cortez, platner, krishnamoorthi, raised, ossoff, brown, committee, pipefitting, michael
- gdelt_regions: today=6, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=49, 7d-median=48, 14d-median=48; carrying terms: chinese, israel, hezbollah, english, sanctions, russia, trump, perimeter
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=20, 14d-median=20
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: incubation, october, animals, watery, humans, january, followed, significant, autochthonous, total, direct, primarily
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: request, function, federation, suite, account, sharepoint, microsoft, critical, authorization, granularity, untrusted, active
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=303, 7d-median=179, 14d-median=179; carrying terms: kazakhstan, sweden, orange, guinea, ecuador, mexico, poland, hungary, russia, gabon, zealand, cyclone
- usgs_quakes: today=20, 7d-median=22, 14d-median=22; carrying terms: ridge, atlantic, islands, depth, south
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: meeting, prime, ethiopia, volume, price, rates, interest, minister, resolves
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: benefit, useful, class, https, conversable, growth, revolution, marginal, perhaps, economist, marginalrevolution
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: hackers, chinese, surveillance, speed, online, researchers, experience, retail, blogging, exploitation, never, cyber
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: tonko, grassley, brownley, merkley, marcy, zachary, stevens, senior, trade, jayapal, aumua, mcguire
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, converges, unavailable, decision, module, markets, today, identify, sufficient, placed, claude, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*