# WORLDSCOPE morning brief — 2026-07-27

## Headline
2324 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (560) · Russian Internal News (state + in-exile) (520) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (194) · Chinese Internal News (187) · Ukraine Theater (total-war monitoring) (132) · State-Level News (94) · Local News: St. Louis + Atlanta (64) · Conflict & unrest (GDELT, last 48h) (40) · GDACS — global disaster alerts (38) · Ukrainian Internal News (national + local Kyiv) (31) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 560 new of 933 total
  - (2026-07-27) [Global] Suspect in Berlin Pride attack shot dead by police
      German police said a 21-year-old man with a record of Islamist extremist activity was shot dead on Sunday, a day after he allegedly drove a minivan into people near Berlin's Pride celebrations, killing one person. The ra…
  - (2026-07-27) [Global] French firefighters battle the blaze with local residents through the night
      It is the night that is most gruelling for firefighters, that is when the Canadair aircraft cannot fly, due to low visibility. Everything happens on the ground, as close as possible to the blaze, sometimes with the help…
  - (2026-07-27) [Global] Wildfire threatens French defence sites ArianeGroup, Dassault and Thales
      More than 42,000 hectares have now burned in Gironde, southwestern France as wildfires push closer to Bordeaux. Authorities say 240 homes have already been destroyed by the flames, which are now also threatening some of…
  - (2026-07-27) [Global] Spain to start first return of fire evacuees as wildfires advance has slowed
      Spanish authorities said they planned to start to allow some people evacuated from wildfires near Madrid to return on Monday, in a sign of progress in fighting some of the worst forest fires in the country's history. FRA…
  - (2026-07-27) [Global] France, Spain wildfires: Climate change increasing frequency, intensity of extreme weather events
      The fires tearing through forests in southwest France, around the region of Bordeaux, and in central Spain around the capital Madrid have been some of the worst in decades. Climate change which has brought successive hea…
  - (2026-07-27) [Global] France, Spain race to contain 'monster' fires ahead of new heatwave
      Shelters in France and Spain on Monday overflowed with exhausted locals and holidaymakers forced to flee blazes so massive some were forming their own mini weather systems, as authorities warned a new heatwave was set to…

### Russian Internal News (state + in-exile) — 520 new of 814 total
  - (2026-07-27) Война. 1615-й день. В Россию с фронта вернулись не менее 400 тысяч военных. Зеленский обещает россиянам новую мобилизацию после выборов в Госдуму | LEDE: «Медуза» с 24 февраля 2022 года в пр] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-27) Детство в Чечне начала двухтысячных — это коробки с гуманитаркой, разрушенное жилье, нестабильное электричество и пропаганда в школе. Лана Эстемирова пережила все это лично — и написала книгу «] (ru:…
      Книга «Пожалуйста, живи. Чеченские войны, мама и я» родилась из обещания, которое восемнадцатилетняя Лана Эстемирова дала на могиле убитой матери, чеченской журналистки и правозащитницы Натальи Эстемировой. Годы спустя Л…
  - (2026-07-27) Володин завершил работу Госдумы VIII созыва пятикратным «Россия! Путин! Победа!» Депутаты скандировать не стали (только похлопали) | LEDE: Спикер Госдумы Вячеслав Володин завершил работу Гос] (ru: Вол…
      Спикер Госдумы Вячеслав Володин завершил работу Госдумы VIII созыва. На последнем заседании он выступил с речью об итогах работы депутатов.
  - (2026-07-27) Ведущая блога «Адские бабки» Александра Баязитова вышла на свободу. Она провела в заключении четыре года по делу о вымогательстве | LEDE: Автор блога «Адские бабки» Александра Баязитова, осу] (ru: Вед…
      Автор блога «Адские бабки» Александра Баязитова, осужденная по делу о вымогательстве, освободилась из колонии. Видео с журналисткой опубликовало издание «Пост-».
  - (2026-07-27) Власти Удмуртии сообщили о «самой массированной атаке» украинских беспилотников на регион. Зеленский заявил, что Украина ударила по нефтяному объекту | LEDE: Глава Удмуртии Александр Бречало] (ru: Вла…
      Глава Удмуртии Александр Бречалов сообщил утром 27 июля, что Украина атаковала регион беспилотниками. По его словам, силы ПВО отражают «самую массированную атаку за последнее время».
  - (2026-07-27) В Литве хотят обязать российских артистов, выступающих в стране, подписывать антивоенную декларацию. Если они откажутся — их не впустят | LEDE: МИД Литвы предлагает ужесточить закон о национ] (ru: В Л…
      МИД Литвы предлагает ужесточить закон о национальных санкциях и обязать приезжающих в страну с публичными выступлениями российских и белорусских деятелей культуры подписывать антивоенную декларацию.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 194 new of 202 total
  - (2026-07-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 27 at 5:35AM CDT until July 27 at 6:15AM CDT by NWS Birmingham AL
      SVRBMX The National Weather Service in Birmingham has issued a * Severe Thunderstorm Warning for... Northwestern Marion County in northwestern Alabama... * Until 615 AM CDT. * At 535 AM CDT, a severe thunderstorm was loc…
  - (2026-07-27) [Severe] Special Marine Warning: Special Marine Warning issued July 27 at 5:34AM CDT until July 27 at 5:45AM CDT by NWS Milwaukee/Sullivan WI
      For the following areas... Lake Michigan from North Point Light WI to Winthrop Harbor IL 5 nm off shore to mid lake... At 534 AM CDT, a strong thunderstorm was located 34 nm west of South Haven Light, moving south at 30…
  - (2026-07-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 27 at 5:32AM CDT until July 27 at 6:00AM CDT by NWS Duluth MN
      At 532 AM CDT, a severe thunderstorm was located over southeastern Boundary Waters Canoe Area Wilderness, or 13 miles south of Gunflint Lake, moving southeast at 55 mph. HAZARD...60 mph wind gusts and quarter size hail.…
  - (2026-07-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 27 at 5:31AM CDT until July 27 at 6:15AM CDT by NWS Birmingham AL
      SVRBMX The National Weather Service in Birmingham has issued a * Severe Thunderstorm Warning for... Northwestern Walker County in central Alabama... Southeastern Marion County in northwestern Alabama... Southwestern Wins…
  - (2026-07-27) [Moderate] Special Weather Statement: Special Weather Statement issued July 27 at 5:26AM CDT by NWS Huntsville AL
      At 526 AM CDT, Doppler radar was tracking a strong thunderstorm 9 miles southeast of Red Bay, moving south at 15 mph. HAZARD...Wind gusts up to 50 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty winds cou…

### Chinese Internal News — 187 new of 255 total
  - (2026-07-26) 姚明王治郅对决史：中国篮球的黄金时代 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE56TGlmbzNRYTl2clhrZWEtVmN2UllZVUVjbWVfRWFhRjVDRC1PNjhhTGwzRG9UbGNrbXd6RjdQSFhraUVyZHNlemNKeFJDaEhRZkt] (zh:…
      姚明王治郅对决史：中国篮球的黄金时代 风闻
  - (2026-07-26) 中国AI步步紧逼，美国科技巨头先内讧了 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE0wY0RWMVhsMEM4YjVrTEE3SkM0NXdqZF96RHJibTFLcjJFcWRQaHlBTW5wLUdFYVE2VDdvd2k1SDU4YS1xNS1acGV6a1A2WE9t] (zh:…
      中国AI步步紧逼，美国科技巨头先内讧了 观察者网
  - (2026-07-27) 陈岩石为何风评被害？大风厂背后有多少博弈？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5hSE9jNmlBYndJczQwLTNUQ1hLYkhnQzBUcHJRU25uOEltU2lEZjJCUGIwV25ibF9pR2JlOTJsb2VHbDh1ZnRZVnlaQkJKeTl5] (zh:…
      陈岩石为何风评被害？大风厂背后有多少博弈？ 风闻
  - (2026-07-27) 掏钱的是商场，被托住的是商户 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5fVlRBYm8wenBDSkYyZXYyWnFiTFNSRGFPdzVwZ1pKam5oQzEzaHMycTVkSmxVSzVIc2MyQ3Nac1FKZDhLVmNYUWhodThEcHlfd0QxUEF] (zh:…
      掏钱的是商场，被托住的是商户 风闻
  - (2026-07-26) 写二次元、张靓颖，菲尔兹奖得主邓煜的诗火了 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5WWDZfNkd6YVlHX1RpUmhsd0NkbFBhN3B5X2c1UmpSR0hHX09qcXhoV25pM0VXVTZ5U1AtRVg5MG14dlVQdVVzUkJOSUdHNn] (zh:…
      写二次元、张靓颖，菲尔兹奖得主邓煜的诗火了 观察者网
  - (2026-07-26) 九寨沟景区局部强降雨引发泥石流，无人员伤亡 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE9Bc0tPWUlldC1wZ0dZVEpReDU3WF9QOHB1NjI5MDlFR0ktcUF5NGtRMEtxRXdCRUpzLW0tQTdjQjhvTDdOZHYtbFZBeENEeH] (zh:…
      九寨沟景区局部强降雨引发泥石流，无人员伤亡 观察者网

### Ukraine Theater (total-war monitoring) — 132 new of 495 total
  - (2026-07-26) [FIRMS] thermal anomaly 48.532, 34.649 (FRP 1.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.98 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.521, 34.632 (FRP 2.24 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 2.24 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.474, 34.630 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.95 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.975, 24.707 (FRP 1.32 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.32 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.750, 26.604 (FRP 1.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.55 MW
  - (2026-07-26) [FIRMS] thermal anomaly 47.933, 33.421 (FRP 0.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 0.52 MW

### State-Level News — 94 new of 225 total
  - (2026-07-27) [Colorado] ​He fled gang violence. Now this ICE detainee in Aurora tries to avoid deportation.
      Rudy Villeda Mejía has his own roofing business, a wife and three stepchildren in Washington, near the state’s border with Canada. He has never been charged with a crime. He entered the U.S. without authorization for a s…
  - (2026-07-27) [Colorado] Fifty for 150: Katharine Lee Bates writes ‘America the Beautiful’ following 1893 visit to Pikes Peak
      Poet Katharine Lee Bates spent the summer of 1893 teaching English at the Colorado Summer School at Colorado College in Colorado Springs, on a leave of absence from Wellesley College in Massachusetts. By that time, she w…
  - (2026-07-27) [Colorado] Colorado officials knew ‘public Christian school’ was religious before it opened but didn’t stop it
      This story was originally published by Chalkbeat. When the leaders of a new elementary school applied for a four-digit public school code from the Colorado Department of Education last summer, they didn’t mention a key d…
  - (2026-07-27) [Arkansas] States move to limit classroom screen time
      After school cellphone bans passed many statehouses with bipartisan support in recent legislative sessions, state lawmakers are turning to legislation governing how long students should spend looking at screens. This yea…
  - (2026-07-27) [Arkansas] An Arkansas community founded by Italian immigrants becomes a flashpoint over ICE
      A quiet, empty field near a cream church with green roofing will come alive with the sounds of summer when the Tontitown Grape Festival returns in early August. Children lapping up melting grape ice cream cones, teens gl…
  - (2026-07-27) [Arkansas] Flood of poll watchers, observers, monitors to descend on midterm voters
      WASHINGTON — Political party poll watchers are showing up more and more, usually outside polling places. They have a different mission than the nonpartisan election observers long regarded as bulwarks of credibility, and…

### Local News: St. Louis + Atlanta — 64 new of 184 total
  - (2026-07-27) [feed error] NextSTL (St. Louis): HTTPError
      403 Client Error: Forbidden for url: https://nextstl.com/feed/
  - (2026-07-27) [St. Louis] St. Louis County executive candidates aren’t ready to endorse city-county unification
      Seven years after the failed Better Together plan to reunite St. Louis city and county, local leaders are again contemplating some sort of merger. Most recently, the Regional Business Council, which includes the area’s t…
  - (2026-07-27) [St. Louis] Thyroid medication described as 'subpotent drug' recalled by FDA
      As a Class II recall, the FDA warned that the thyroid drug could cause "temporary or medically reversible adverse health consequences."
  - (2026-07-27) [St. Louis] Fiery wrong-way crash on I-64 leaves 2 dead, 1 critically injured
      The deadly crash happened late Sunday night on westbound I-64 at Jefferson Avenue.
  - (2026-07-27) [St. Louis] Here's what we know about the victims of the Seattle Center shooting
      Two people died at the scene of the shooting; another died in the hospital, where four others are being treated, officials said.
  - (2026-07-27) [St. Louis] Suspect in custody following deadly shooting near Seattle's Space Needle that killed 3
      Seven people were injured and three people were killed after a shooting Sunday evening during a festival near Seattle's Space Needle.

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-27) [India] Until Amit Shah answers , we will continue our protest : Pawan Khera on July 20 student protest crackdown
      domain: news.webindia123.com · language: English · tone:
  - (2026-07-27) [United States] Florida To Execute Two Inmates In One Day | News Radio 94 . 3 WSC
      domain: 943wsc.iheart.com · language: English · tone:
  - (2026-07-27) [Pakistan] 4 Pakistani Businessmen Reportedly Killed in Alleged Targeted Attack in South Africa
      domain: propakistani.pk · language: English · tone:
  - (2026-07-27) [United States] Call for Community - Based Savings Groups : Efficiency , Sustainability , and Growth ( Afghanistan )
      domain: fundsforngos.org · language: English · tone:
  - (2026-07-27) [] Latest Yonkers Harness Results : Your Daily Guide To Winners , Payouts , And Track Trends
      domain: unitaid.eu · language: English · tone:
  - (2026-07-27) [United States] Conan the Barbarian # 33 Preview : Occult Forces Crash the Party
      domain: bleedingcool.com · language: English · tone:

### GDACS — global disaster alerts — 38 new of 303 total
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0
  - (2026-07-04) [Green] Flood in Myanmar
      Flood · Green alert · Myanmar · Magnitude 0

### Ukrainian Internal News (national + local Kyiv) — 31 new of 103 total
  - (2026-07-27) У Коордштабі розповіли, скільки білорусів, які воювали на боці Росії, потрапили в український полон | LEDE: Станом на липень 2026 року 22 громадянина Білорусі, які воювали на боці Росії та потр] (uk:…
      Станом на липень 2026 року 22 громадянина Білорусі, які воювали на боці Росії та потрапили в полон до українців, перебувають у місцях утримання військовополонених на території України.
  - (2026-07-27) На збиття трьох російських дронів Румунія витратила близько 1,5 мільйона євро | LEDE: Збройні сили Румунії витратили приблизно 1,5 мільйона євро за три дні, протягом яких у повітряному просторі] (uk:…
      Збройні сили Румунії витратили приблизно 1,5 мільйона євро за три дні, протягом яких у повітряному просторі країни було збито три російські безпілотники.
  - (2026-07-27) МЗС вимагає розслідувати напад на українську пару у Вроцлаві | LEDE: Генеральне консульство України у Вроцлаві закликало до оперативної реакції польських правоохоронців на черговий інцидент, вн] (uk:…
      Генеральне консульство України у Вроцлаві закликало до оперативної реакції польських правоохоронців на черговий інцидент, внаслідок якого постраждали українці.
  - (2026-07-27) У Польщі напали на молоду пару українців "через акцент" | LEDE: Правоохоронці Польщі розслідують інцидент: у Вроцлаві напали на молоду українську пару.] (uk: У Польщі напали на молоду пару українців "…
      Правоохоронці Польщі розслідують інцидент: у Вроцлаві напали на молоду українську пару.
  - (2026-07-27) У Харкові російський дрон знову влучив в АЗС: двоє людей постраждали | LEDE: Російські війська 27 липня атакували АЗС у Харкові: двоє людей постраждали.] (uk: У Харкові російський дрон знову влучив в…
      Російські війська 27 липня атакували АЗС у Харкові: двоє людей постраждали.
  - (2026-07-27) Зросла кількість жертв удару росіян по полігону під Києвом | LEDE: Після ракетного удару РФ по полігону на Київщині 24 липня загинуло 11 людей, серед жертв — дипломат Мальтійського ордену.] (uk: Зросл…
      Після ракетного удару РФ по полігону на Київщині 24 липня загинуло 11 людей, серед жертв — дипломат Мальтійського ордену.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-27) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (41.6897, -2.3934) · alt: 11285m · 848km/h
  - (2026-07-27) JAF56C (Bulgaria)
      icao24: 4520aa · position: (46.1774, -2.1793) · alt: 10363m · 907km/h
  - (2026-07-27) SAMU37 (France)
      icao24: 39ca87 · position: (48.7323, 2.093) · alt: 289m · 179km/h
  - (2026-07-27) SAMU05 (France)
      icao24: 39ca81 · position: (44.5076, 6.2321) · alt: 1653m · 257km/h
  - (2026-07-27) GAF117 (Germany)
      icao24: 3ea556 · position: (51.3944, -3.3362) · alt: -7m · 101km/h
  - (2026-07-27) GAF114 (Germany)
      icao24: 3f727c · position: (45.4247, -0.0406) · alt: 6614m · 687km/h

### USGS earthquakes (M4.5+, past day) — 14 new of 20 total
  - (2026-07-27) M 5.4 - 82 km SSW of San Pedro de Atacama, Chile
      M5.4 · 82 km SSW of San Pedro de Atacama, Chile · depth 106.991 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.1 - south of Tonga
      M5.1 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.0 - south of Tonga
      M5.0 · south of Tonga · depth 10 km

### IT, InfoSys & cybersecurity news (last 7 days) — 14 new of 52 total
  - (2026-07-27) [The Hacker News] TELESHIM Abuses Telegram for C2 in Attacks Against Middle East Governments
      Cybersecurity researchers have flagged fresh malicious cyber activity by a threat actor with ties to East Asia targeting government entities in the Middle East. The intrusions have resulted in the deployment of previousl…
  - (2026-07-27) [The Hacker News] GitHub Adds 3-Day Dependabot Cooldown to Limit Poisoned Package Adoption
      GitHub has announced a new cooldown mechanism in Dependabot, allowing the tool to wait at least three days after a release is published before opening a pull request. "The cooldown configuration option in the dependabot.…
  - (2026-07-27) [Cybersecurity Dive] In the Mythos era, security belongs at runtime
      Frontier AI cut time-to-exploit from years to hours. Why defense now has to happen at runtime.
  - (2026-07-27) [Cybersecurity Dive] What the Trojan horse gets right (and wrong) about AI security
      Agentic AI didn't invent new risk. It removed the friction that used to keep environments in check.
  - (2026-07-27) [The Register] Digital sovereignty is real in Europe. The UK? Not so much
      Trump's unpredictability is pushing governments and businesses toward open source while Britain remains glued to US tech
  - (2026-07-27) [The Register] The roller coaster works, but the Six Flags kiosk has gone off the rails
      Would you like an error with your terror?

### SEC Form 4 insider transactions (recent) — 11 new of 40 total
  - (2026-07-27) 424B5 - NANOVIRICIDES, INC. (0001379006) (Filer)
      filed 2026-07-27 10:30 UTC — Filed: 2026-07-27 AccNo: 0001104659-26-086797 Size: 655 KB
  - (2026-07-27) [Patel Snehal] Form 4 (Reporting)
      filed 2026-07-27 10:15 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001493152-26-034675 Size: 6 KB
  - (2026-07-27) [Greenwich LifeSciences, Inc.] Form 4 (Issuer)
      filed 2026-07-27 10:15 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001493152-26-034675 Size: 6 KB
  - (2026-07-27) 425 - Evernorth Holdings Inc. (0002092592) (Subject)
      filed 2026-07-27 10:10 UTC — Filed: 2026-07-27 AccNo: 0000950103-26-011179 Size: 342 KB
  - (2026-07-27) [Feng Dagang] Form 4 (Reporting)
      filed 2026-07-27 10:07 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001104659-26-086771 Size: 5 KB
  - (2026-07-27) [36Kr Holdings Inc.] Form 4 (Issuer)
      filed 2026-07-27 10:07 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001104659-26-086771 Size: 5 KB

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-07-27) LoL: KT Rolster vs Gen.G (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $1,098,278 · resolves 2026-07-27
  - (2026-07-27) LoL: Dplus KIA vs T1 (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $1,020,232 · resolves 2026-07-27
  - (2026-07-27) LoL: Hanwha Life Esports vs Kiwoom DRX (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $715,536 · resolves 2026-07-27
  - (2026-07-27) Will Tom Cotton win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $582,344 · resolves 2028-11-07
  - (2026-07-27) Will the Fed decrease interest rates by 25 bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $464,074 · resolves 2026-07-29
  - (2026-07-27) US x Iran Effective Ceasefire by July 24?
      yes price: 49% · 24h volume: $335,473 · resolves 2026-07-24

### Paper Trading Scorecard — 8 new of 134 total
  - (2026-07-27) [Polymarket] Israel military action against Yemen by July 31?
      This market will resolve to “Yes” if Israel takes a qualifying military action against Yemen by the specified date, 11:59 PM Arabia Standard Time (AST). Otherwise this market will resolve to “No.” A qualifying military a…
  - (2026-07-27) [Polymarket] Will a European country take military action on Iran by July 31?
      This market will resolve to “Yes” if any European country takes a qualifying military action against Iran by the specified date, 11:59 PM Central European Summer Time (CEST). Otherwise this market will resolve to “No.” A…
  - (2026-07-27) [Manifold] Will Trump be reelected again
  - (2026-07-27) [Manifold] Will Steph Curry get traded before 2027?
  - (2026-07-27) [Manifold] Trump impeached before Iran war's end?
  - (2026-07-27) [Manifold] Will Tadej Pogacar win the 2027 Tour de France?

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-07-24) U.S. Court of Appeals, 10th Cir.: Horocofsky v. City of Lawrence, Kansas
  - (2026-07-24) Florida Supreme Court: James Aren Duckett v. State of Florida
  - (2026-07-24) Hawaii Supreme Court: In re: Kenny
  - (2026-07-24) Hawaii Supreme Court: In re: Whiting
  - (2026-07-24) Hawaii Supreme Court: Li v. Ho
  - (2026-07-24) Alaska Supreme Court: Darren M. v. Destiny D

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-27) [China] 시진핑 주석 룰라 브라질 대통령과 전화 통화
      korean.cri.cn · English
  - (2026-07-27) [China] Man linked to Indonesia former top corruption prosecutor found dead
      scmp.com · English
  - (2026-07-27) [China] Huawei Pura 90s Pro Max review
      gsmarena.com · English
  - (2026-07-27) [China] Siegwerk accelerates investment programme to expand global printing inks and coatings capabilities
      european-coatings.com · English
  - (2026-07-27) [China] vivo X300 E - Full phone specifications
      gsmarena.com · English
  - (2026-07-27) [China] Gurman : Apple to unveil its smart glasses at WWDC 2027
      gsmarena.com · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 32 total
  - (2026-07-27) #30 Germán Larrea Mota Velasco & family — $63.25B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-27) MOVER ▼ Bernard Arnault & family — $142.22B ($-0.23B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-27) MOVER ▲ Gautam Adani — $85.57B (+$0.23B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-27) [Marginal Revolution] Could our preoccupation with mental health be part of the problem?
      Could our preoccupation with mental health be part of the problem? In some ways, encouraging people to think and talk more about their mental health is a good thing. There is now less stigma around mental illness, and mo…
  - (2026-07-27) [Marginal Revolution] The Decline in the Transmission of Scientific Ideas
      We document that the diffusion of new scientific ideas beyond their field of origin has declined substantially over the past four decades. This contraction is closely linked to increasing specialization in scientific lan…

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 119 total
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=14, 14d-median=14; carrying terms: limitations, august, amendments, whether, fisheries, adopting, necessary, regulatory, directive, certain, class, coast
- state_bills: today=0, 7d-median=117, 14d-median=117
- state_news: today=225, 7d-median=592, 14d-median=592; carrying terms: alleges, embrace, analysis, childhood, washington, group, answers, article, released, updated, yearlong, allows
- local_news: today=184, 7d-median=230, 14d-median=230; carrying terms: pending, group, answers, released, using, daughter, crews, dekalb, driver, women, grand, event
- foreign_news: today=933, 7d-median=1014, 14d-median=1014; carrying terms: achilles, results, worry, hospitalised, holds, greater, swissinfo, straits, phone, estimated, partnership, matters
- chinese_internal: today=255, 7d-median=282, 14d-median=282; carrying terms: china, lxtfa, people, articles, caixin, mainland, cbmiw, cbmizkfvx, blank, cbmiyefvx, lxtfb, cbmiakfvx
- russian_internal: today=814, 7d-median=824, 14d-median=824; carrying terms: openai, gazeta, centcom, group, style, client, error, found, title, street, russian, forbidden
- ukrainian_internal: today=103, 7d-median=138, 14d-median=138; carrying terms: mandate, analysis, washington, expected, group, incidents, potential, influence, using, deputy, kills, autumn
- ukraine_theater: today=495, 7d-median=540, 14d-median=540; carrying terms: ckxltwpnc, uzuptz, cuxortnytvjjofbzt, wtvrazjz, zdmztgzjmffjszfxukladvfvq, foowdtsfduwnjiwvzfbg, rcdfpvvnbzunljmkxbdey, cuxpwgtpnefsrtv, uytxhtufjjbgfnnhhtou, incidents, kekrysy, updated
- paper_bets: today=134, 7d-median=140, 14d-median=140; carrying terms: cousins, decrease, alone, evans, human, openai, chase, humanoid, survivors, approve, government, washington
- weather: today=202, 7d-median=180, 14d-median=180; carrying terms: issued, hotter, shortly, include, sunday, locally, louis, remain, beyond, washington, lying, expected
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: supply, rates, energy, consumption, payrolls, payems, jtsjol, nonfarm, growth, personal, walcl, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: rates, crude, russell, proxy, bitcoin, natural, china, large, range, silver, agriculture, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=119, 7d-median=119, 14d-median=119; carrying terms: accellerator, vzhjoeklrc, taliban, satisfying, latinscript, analysis, bosnia, government, group, transnistrian, facilitate, transition
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, unauthorized, quiver, congresstrading, quiverquant, httperror, https, client, error
- billionaires: today=32, 7d-median=31, 14d-median=31; carrying terms: facebook, finance, london, tesla, madrid, oracle, tokyo, peterffy, sergey, huang, walmart, francoise
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, group, medical, blanche, holdings, services, international, douglas, california, robert, delaware, ahmed
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: booker, jonathan, texas, colorado, talarico, angels, brown, krishnamoorthi, house, bureau, committee, warner
- gdelt_regions: today=6, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=49, 7d-median=48, 14d-median=48; carrying terms: hezbollah, sanctions, chinese, israel, perimeter, trump, russia, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=20, 14d-median=20
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: intensive, countries, netherlands, prevention, jerusalem, variant, regions, observed, human, elements, nigeria, analysis
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: option, cisco, association, active, overly, sonicwall, mechanism, oracle, product, vulnerability, fortisandbox, federation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=303, 7d-median=179, 14d-median=179; carrying terms: flood, green, kazakhstan, orange, bosnia, croatia, colombia, australia, canada, france, magnitude, north
- usgs_quakes: today=20, 7d-median=22, 14d-median=22; carrying terms: atlantic, depth, islands, south, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, minister, meeting, prime, price, ethiopia, resolves, interest, volume
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, growth, revolution, economist, class, useful, perhaps, marginalrevolution, marginal, https, benefit
- tech_news: today=52, 7d-median=55, 14d-median=55; carrying terms: openai, vulnerability, major, almost, government, group, memory, article, every, using, dubbed, street
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: deposit, ciscomani, westerman, banks, gorsuch, cramer, burgess, sydney, evans, elise, marie, fedorchak
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, placed, today, claude, evidence, placement, unavailable, converges, paper, decision, module, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*