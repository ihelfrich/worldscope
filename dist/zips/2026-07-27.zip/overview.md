# WORLDSCOPE morning brief — 2026-07-27

## Headline
3488 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (772) · Russian Internal News (state + in-exile) (712) · State-Level News (357) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (305) · Chinese Internal News (227) · Local News: St. Louis + Atlanta (213) · U.S. Weather + Severe / Climate Outlooks (173) · Ukrainian Internal News (national + local Kyiv) (56) · IT, InfoSys & cybersecurity news (last 7 days) (46) · GDACS — global disaster alerts (44) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 772 new of 1007 total
  - (2026-07-27) [Global] Wildfire now nine miles from French city of Bordeaux, mayor warns
      Thomas Cazenave says they are preparing if further evacuations are issued, as the mayor of a nearby town called the situation "catastrophic".
  - (2026-07-27) [Global] Trump says Iran war talks taking place during lull in strikes
      The US president says "there is a good chance that something could happen", as Iran denies direct talks are taking place.
  - (2026-07-27) [Global] Ukraine dismisses Iranian threats as Caspian Sea strike directly links wars
      Iran has reacted with fury to the assault on the vessel, with Tehran's foreign minister saying it "cannot go unanswered".
  - (2026-07-27) [Global] A Japanese town wrestles with identity after protests over its first mosque
      As Japan increasingly relies on foreign workers, it is also grappling with how to integrate new cultures and religions.
  - (2026-07-27) [Global] Anger as Berlin Pride attacker revealed to have been freed weeks earlier
      As details emerge about the suspected Berlin Pride attacker's past, many are asking why he was not in prison.
  - (2026-07-27) [Global] US singer D4vd to go on trial for murder in death of 14-year-old
      The star is accused of killing Celeste Rivas Hernandez, whose remains were found in a Tesla registered to his address.

### Russian Internal News (state + in-exile) — 712 new of 879 total
  - (2026-07-27) В Ялте из-за отключений электричества начали устанавливать дворовые кухни для жителей многоэтажек | LEDE: Администрация Ялты начала устанавливать во дворах многоквартирных домов площадки для] (ru: В Я…
      Администрация Ялты начала устанавливать во дворах многоквартирных домов площадки для приготовления еды. На соответствующее сообщение назначенных РФ властей города обратило внимание «Агентство».
  - (2026-07-27) «Думаю, это произойдет уже осенью». Главный конструктор украинского производителя ракет Fire Point — о возможных ударах баллистикой по Москве | LEDE: Первые удары украинскими баллистическими] (ru: «Ду…
      Первые удары украинскими баллистическими ракетами по Москве могут начаться уже этой осенью, заявил владелец и главный конструктор компании Fire Point Денис Штилерман в интервью журналисту Дмитрию Гордону.
  - (2026-07-27) Виктор Янукович сменил имя в документах на «Олег Леонов». Как выяснили украинские журналисты, он живет в огромном поместье в Сочи | LEDE: Бывший президент Украины Виктор Янукович сейчас живе] (ru: Вик…
      Бывший президент Украины Виктор Янукович сейчас живет в Сочи и пользуется документами на имя «Олега Николаевича Леонова». Об этом говорится в расследовании украинского ютьюб-канала «Телебачення Торонто».
  - (2026-07-27) В Республике Алтай запретили заправлять машину чаще, чем раз в 24 часа | LEDE: В Республике Алтай запретили заправлять один и тот же автомобиль чаще, чем один раз в течение 24 часов. Об этом] (ru: В Р…
      В Республике Алтай запретили заправлять один и тот же автомобиль чаще, чем один раз в течение 24 часов. Об этом сообщило правительство региона.
  - (2026-07-27) The Washington Post: операция США против наркокартелей не принесла результатов. Возможно, количество кокаина в стране даже увеличилось | LEDE: Операция «Южное копье», начатая в рамках борьбы] (ru: The…
      Операция «Южное копье», начатая в рамках борьбы с наркокартелями, не помогла сократить количество кокаина, поступающего в США. Об этом пишет газета The Washington Post, которой удалось ознакомиться с ранее не публиковавш…
  - (2026-07-27) Похмелье после вечеринки. Примерно так можно коротко описать новый альбом Charli XCX «Music, Fashion, Film». Певица откровенно дистанцируется от пластинки «brat», что многих наверняка разочаруе] (ru:…
      24 июля вышел восьмой альбом британской поп-звезды Чарли XCX «Music, Fashion, Film». Это ее второй альбом за год (если считать саундтрек к прокатному хиту «Грозовой перевал») и первый, который не привязан ни к какому дру…

### State-Level News — 357 new of 454 total
  - (2026-07-27) [Alabama] Jones lays out governing agenda, calls for one-year data center pause
  - (2026-07-27) [Alabama] History is not optional
  - (2026-07-27) [Alabama] Alabama lawmakers target postmaster general bonuses in USPS accountability bill
  - (2026-07-27) [Alabama] Opinion | The Scopes warning never ended
  - (2026-07-27) [Alabama] Opinion | Closing primaries isn’t just a bad idea, it’s anti-American
  - (2026-07-27) [Alabama] State, DOJ reach settlement to end federal oversight of Tutwiler prison

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 305 new of 647 total
  - (2026-07-26) [FIRMS] thermal anomaly 48.532, 34.649 (FRP 1.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.98 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.521, 34.632 (FRP 2.24 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 2.24 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.474, 34.630 (FRP 1.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.95 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.975, 24.707 (FRP 1.32 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.32 MW
  - (2026-07-26) [FIRMS] thermal anomaly 48.750, 26.604 (FRP 1.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 1.55 MW
  - (2026-07-26) [FIRMS] thermal anomaly 47.933, 33.421 (FRP 0.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-26 2329Z, FRP 0.52 MW

### Chinese Internal News — 227 new of 262 total
  - (2026-07-26) China’s AI-Driven Robotics Boom Faces IPO Reality Check - Caixin Global
      China’s AI-Driven Robotics Boom Faces IPO Reality Check Caixin Global
  - (2026-07-27) Flash Flood at Campsite in Northwestern China Kills 10, Injures 23 - Caixin Global
      Flash Flood at Campsite in Northwestern China Kills 10, Injures 23 Caixin Global
  - (2026-07-26) 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8tVlVpeVhuSlJuYjM3RFN1a3JNV05fRll1Y1hQaW9pdlFvTy1fLWx6ZU9RNGJiZVNyRmQtYWI1bzdnTThabVJoMnpOLWQxUXVOZ0tGekRqTEpKVlB] (zh:…
      商品详情 财新商城
  - (2026-07-27) 重庆彭水山体崩塌现场发现人体残骸 正检测DNA - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9Bal9LLWllQXlpczFYenNTRy01UDZFQUFVQl9DaDB3MjR0WXpwXzF1c2hhcXdwRnA4MTJzM24xbVV0bHcwYURheHM4VWxFbG] (zh:…
      重庆彭水山体崩塌现场发现人体残骸 正检测DNA 财新
  - (2026-07-27) 【财新圆桌-AI系列】智能体时代终端产业的下一站 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE5qcGNOYWlfX1A1NWFMdFA0OEJBZFZmOU0xRHBXR0VfYnZfTlR5RFJiUUszOWNFdlpXdElNZ0h4Xzg3SWYyNy1neHdJS2RWN] (zh:…
      【财新圆桌-AI系列】智能体时代终端产业的下一站 财新
  - (2026-07-27) 今日开盘：沪指报3808.90点 跌幅0.14% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1MR1Y3cFh1TTFaUkxidXYyWnlCTklHN3Q0ODBOWXZCVGZIR3RxOVp3UjdPcVhySkNhd2xGYXo2dWRQR0FvTmFWQkt4U0hSV] (zh:…
      今日开盘：沪指报3808.90点 跌幅0.14% 财新

### Local News: St. Louis + Atlanta — 213 new of 229 total
  - (2026-07-27) [St. Louis] St. Louis chefs share their favorite ways to enjoy summertime peaches
      Ask Cheryl: What is your favorite way to enjoy summertime peaches? The other day, I casually grabbed some peaches from Dierberg’s, only to return home and enjoy one of the best fruit experiences of my life. These beautie…
  - (2026-07-27) [St. Louis] Author Annie Jacobsen hopes for pressure, not panic, from latest apocalyptic release
      In her bestselling 2024 book, Nuclear War: A Scenario, Pulitzer Prize–nominated author Annie Jacobsen gave readers a highly detailed, heavily researched, minute-by-minute account of how the world might descend into nucle…
  - (2026-07-27) [St. Louis] PuffPies brings Chilean-style empanadas to South St. Louis
      PuffPies (6915 Gravois), the new South City shop specializing in Chilean-style empanadas, didn’t need a grand opening to make an impression. Despite a quiet debut on July 19, the family-owned shop sold out on its first d…
  - (2026-07-27) [St. Louis] Unforgettable farm-to-table experiences in the Midwest
      Claverach Farm | Eureka, Missouri Located 20 miles from St. Louis, Claverach Farm has been in Sam Hilmer’s family for more than a century. Located on roughly 300 acres, the farm is where Sam and his wife, Rachel, grow a…
  - (2026-07-27) [St. Louis] 5 Midwest wine destinations
      Hermann Wine Trail Known for its rich German heritage and historic wineries, Hermann is the easiest wine getaway from St. Louis (beyond Augusta and Defiance) at just 90 minutes west by car or train. The region is known f…
  - (2026-07-27) [St. Louis] Crushed Red closes Ballwin and St. Charles locations
      The two newest locations of Crushed Red closed over the weekend. The last day of service at the Ballwin (14124 Manchester) and St. Charles (165 Beale, Suite 117) locations was July 25. The company’s other locations remai…

### U.S. Weather + Severe / Climate Outlooks — 173 new of 175 total
  - (2026-07-27) [Moderate] Heat Advisory: Heat Advisory issued July 27 at 5:35PM MDT until July 27 at 9:00PM MDT by NWS Pueblo CO
      * WHAT...High temperatures of 94 to 100 expected. * WHERE...El Paso County including Colorado Springs and Monument. * WHEN...Until 9 PM MDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses.
  - (2026-07-27) [Moderate] Heat Advisory: Heat Advisory issued July 27 at 5:35PM MDT until July 27 at 9:00PM MDT by NWS Pueblo CO
      * WHAT...Temperatures of 98 to 103 expected. * WHERE...Eastern Fremont County including Canon City. * WHEN...Until 9 PM MDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses.
  - (2026-07-27) [Moderate] Heat Advisory: Heat Advisory issued July 27 at 5:35PM MDT until July 27 at 9:00PM MDT by NWS Pueblo CO
      * WHAT...High temperatures of 100 to 106 expected. * WHERE...Pueblo County including the city of Pueblo. * WHEN...Until 9 PM MDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses.
  - (2026-07-27) [Moderate] Heat Advisory: Heat Advisory issued July 27 at 5:35PM MDT until July 27 at 9:00PM MDT by NWS Pueblo CO
      * WHAT...High temperatures of 104 to 110 expected. * WHERE...Crowley, Otero, Kiowa, Bent, Prowers, and Baca Counties. * WHEN...Until 9 PM MDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses.
  - (2026-07-27) [Moderate] Special Weather Statement: Special Weather Statement issued July 27 at 7:33PM EDT by NWS Peachtree City GA
      At 732 PM EDT, a strong thunderstorm was near Hampton, or near McDonough, moving south at 10 mph. HAZARD...40 to 50 mph wind, pea sized hail and frequent cloud to ground lightning. SOURCE...Radar indicated. IMPACT...Expe…
  - (2026-07-27) [Severe] Blowing Dust Warning: Blowing Dust Warning issued July 27 at 6:33PM CDT until July 27 at 9:00PM CDT by NWS Goodland KS
      * WHAT...For the Blowing Dust Warning, widespread blowing dust and brown out conditions. For the Heat Advisory, heat index values up to 105. * WHERE...Graham, Sheridan, and Gove Counties. * WHEN...For the Blowing Dust Wa…

### Ukrainian Internal News (national + local Kyiv) — 56 new of 131 total
  - (2026-07-28) В окупованій Феодосії горить електропідстанція – соцмережі | LEDE: У соцмережах повідомляють про пожежу в окупованій Феодосії, горить електропідстанція.] (uk: В окупованій Феодосії горить електропідст…
      У соцмережах повідомляють про пожежу в окупованій Феодосії, горить електропідстанція.
  - (2026-07-28) Ворог вдарив по Сумщині КАБами і дронами: є потерпілі, триває рятувальна операція | LEDE: У ніч на 28 липня росіяни вдарили по Сумщині КАБами і дронами.] (uk: Ворог вдарив по Сумщині КАБами і дронами:…
      У ніч на 28 липня росіяни вдарили по Сумщині КАБами і дронами.
  - (2026-07-28) Ціна на нафту знизилася, зафіксувавши найбільше падіння з квітня | LEDE: Обвал ціни на нафту: зафіксували найбільше падіння з квітня.] (uk: Ціна на нафту знизилася, зафіксувавши найбільше падіння з кв…
      Обвал ціни на нафту: зафіксували найбільше падіння з квітня.
  - (2026-07-28) Трамп має намір прийняти у вівторок в Білому домі Зеленського і Нетаньягу – CNN | LEDE: ЗМІ повідомляють, що у вівторок Трамп обговорить війни в Україні та на Близькому Сході із Зеленським і Не] (uk:…
      ЗМІ повідомляють, що у вівторок Трамп обговорить війни в Україні та на Близькому Сході із Зеленським і Нетаньягу.
  - (2026-07-28) У Києві та низці областей лунала повітряна тривога через загрозу балістики і дронів | LEDE: У ніч на вівторок, 28 липня, у Києві та низці областей оголосили повітряну тривогу через загрозу воро] (uk:…
      У ніч на вівторок, 28 липня, у Києві та низці областей оголосили повітряну тривогу через загрозу ворожої балістики і дронів.
  - (2026-07-27) У Києві та інших містах 12-й день поспіль відбулися акції на підтримку Федорова | LEDE: 27 липня в Україні дванадцятий день поспіль відбулися мирні акції на підтримку колишнього міністра оборон] (uk:…
      27 липня в Україні дванадцятий день поспіль відбулися мирні акції на підтримку колишнього міністра оборони Михайла Федорова.

### IT, InfoSys & cybersecurity news (last 7 days) — 46 new of 57 total
  - (2026-07-27) [BleepingComputer] Arista patches VeloCloud Orchestrator zero-day exploited in attacks
      Arista has patched a maximum-severity command injection vulnerability in on-premises VeloCloud Orchestrator deployments that is being actively exploited in attacks. [...]
  - (2026-07-27) [BleepingComputer] New Dysphoria DDoS botnet spreads to 200k devices worldwide
      A botnet called Dysphoria has compromised around 200,000 devices across the world and is using them for distributed denial of service (DDoS) attacks and traffic relay operations. [...]
  - (2026-07-27) [BleepingComputer] New Certighost PoC exploit lets attackers hijack Windows domains
      A proof-of-concept exploit for "Certighost," a Windows Active Directory Certificate Services vulnerability, has been released that can allow authenticated attackers to potentially compromise a Windows domain. [...]
  - (2026-07-27) [BleepingComputer] Apple sued over fake App Store crypto wallet app stealing $1.8M in Bitcoin
      Apple is being sued by three people who claim approximately $1.8 million in Bitcoin was stolen after downloading and using a fraudulent Sparrow Wallet application from the App Store. [...]
  - (2026-07-27) [BleepingComputer] Coca-Cola confirms data theft in Fairlife ransomware attack
      The Coca-Cola Company has confirmed that hackers stole data from its dairy subsidiary, Fairlife, during a ransomware attack earlier this month. [...]
  - (2026-07-27) [The Hacker News] NVIDIA Forms 37-Member Open Secure AI Alliance and Open-Sources NOOA Framework
      NVIDIA and 36 other organizations have formed the Open Secure AI Alliance to develop and share open technologies, techniques, and tools for securing software and artificial intelligence (AI) agents. The 37-member group s…

### GDACS — global disaster alerts — 44 new of 313 total
  - (2026-07-21) [Orange] Forest fires in Tunisia
      Wildfire · Orange alert · Tunisia · Orange impact for forestfire in 11763 ha
  - (2026-07-21) [Orange] Forest fires in Tunisia
      Wildfire · Orange alert · Tunisia · Orange impact for forestfire in 11763 ha
  - (2026-07-25) [Orange] Forest fires in Spain
      Wildfire · Orange alert · Spain · Orange impact for forestfire in 12406 ha
  - (2026-07-25) [Orange] Forest fires in Spain
      Wildfire · Orange alert · Spain · Orange impact for forestfire in 12406 ha
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0
  - (2026-06-13) [Green] Flood in Philippines
      Flood · Green alert · Philippines · Magnitude 0

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-27) [ALLEN SCOTT R.] Form 4 (Reporting)
      filed 2026-07-27 23:30 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001652149-26-000005 Size: 4 KB
  - (2026-07-27) [MICRON TECHNOLOGY INC] Form 4 (Issuer)
      filed 2026-07-27 23:30 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001652149-26-000005 Size: 4 KB
  - (2026-07-27) [Harmon Cyrus] Form 4 (Reporting)
      filed 2026-07-27 23:30 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001831410-26-000008 Size: 7 KB
  - (2026-07-27) [Olema Pharmaceuticals, Inc.] Form 4 (Issuer)
      filed 2026-07-27 23:30 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001831410-26-000008 Size: 7 KB
  - (2026-07-27) [Rotsztain Diego] Form 4 (Reporting)
      filed 2026-07-27 23:29 UTC · role: Reporting — Filed: 2026-07-27 AccNo: 0001511110-26-000010 Size: 5 KB
  - (2026-07-27) [StoneX Group Inc.] Form 4 (Issuer)
      filed 2026-07-27 23:29 UTC · role: Issuer — Filed: 2026-07-27 AccNo: 0001511110-26-000010 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-27) [United States] How Much Charity Would It Take for People to Like Elon Musk ?
      domain: gizmodo.com · language: English · tone:
  - (2026-07-27) [Philippines] Manila Bulletin - Officials say man killed wife and 6 kids , then himself , before all were found in Michigan home fire
      domain: mb.com.ph · language: English · tone:
  - (2026-07-27) [] Shocking Details About Traumasoft Brewster You Havent Heard
      domain: unitaid.eu · language: English · tone:
  - (2026-07-27) [United States] Kohberger Moves to Withdraw Guilty Plea in Idaho Student Murders
      domain: wsyr.iheart.com · language: English · tone:
  - (2026-07-27) [United States] Police chief lashes out after being asked why he wasnt in Seattle during mass shooting
      domain: cbs2iowa.com · language: English · tone:
  - (2026-07-27) [Israel] Two Palestinians killed in Israeli strikes on northern and central Gaza
      domain: english.wafa.ps · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 25 new of 60 total
  - (2026-07-27) U.S. Court of Appeals, Federal Cir.: Board of Regents of the University of Texas v. Boston Scientific Corp.
  - (2026-07-27) Supreme Court of California: Fox Paine & Co, LLC v. Twin City Fire Ins Co
  - (2026-07-27) Supreme Court of California: Ventura Cty Emp Ret Assn v. Crim J Atty Ret Assn Ventura Cty
  - (2026-07-27) U.S. Court of International Trade: Gov't of Canada v. United States
  - (2026-07-27) U.S. Court of International Trade: Qatar Melamine Co. v. United States
  - (2026-07-27) U.S. Court of Appeals, 9th Cir.: Krzesni v. Wellpinit School District

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-27) [Israel-Iran-Hezbollah axis · keywords] UN slams Israel expansion of illegal settlements in occupied West Bank | Antonio Guterres News
      aljazeera.com · English · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · keywords] Why another Palestinian uprising is all but inevitable
      arabnews.com · English · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · keywords] Trump to meet Netanyahu at decisive moment for Iran war
      channel4.com · English · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · keywords] Why Houthis send aid to Hezbollah despite Yemen crisis
      jpost.com · English · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · keywords] From Gaza to Hormuz , hostage - taking has reached new levels
      arabnews.com · English · tone NA
  - (2026-07-27) [Israel-Iran-Hezbollah axis · keywords] UN slams Israel expansion of illegal settlements in occupied West Bank - Dominican Republic Post – Caribbean News , Business , Travel & Culture
      dominicanrepublicpost.com · English · tone NA

### USGS earthquakes (M4.5+, past day) — 24 new of 24 total
  - (2026-07-27) M 5.4 - 82 km SSW of San Pedro de Atacama, Chile
      M5.4 · 82 km SSW of San Pedro de Atacama, Chile · depth 106.991 km
  - (2026-07-27) M 5.3 - 23 km E of Kinablangan, Philippines
      M5.3 · 23 km E of Kinablangan, Philippines · depth 71.061 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.2 - south of Tonga
      M5.2 · south of Tonga · depth 10 km
  - (2026-07-27) M 5.1 - 147 km E of Kimbe, Papua New Guinea
      M5.1 · 147 km E of Kimbe, Papua New Guinea · depth 91.011 km

### Paper Trading Scorecard — 21 new of 130 total
  - (2026-07-27) [Polymarket] Will Mohamed Salah win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-07-27) [Polymarket] Will Anthropic have the best Math AI model at the end of July 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab for "Math"…
  - (2026-07-27) [Kalshi] US real GDP growth in 2031?
      2031
  - (2026-07-27) [Manifold] Will Donald Trump visit China before January 1, 2027?
  - (2026-07-27) [Manifold] are apples human made?
  - (2026-07-27) [Manifold] are bananas really yellow?

### Government & military aircraft airborne (OpenSky) — 18 new of 18 total
  - (2026-07-27) PAT842 (United States)
      icao24: adfe4b · position: (58.0746, -152.8068) · alt: 4061m · 458km/h
  - (2026-07-27) PAT099 (United States)
      icao24: adfe94 · position: (34.7658, -114.4562) · alt: 7620m · 470km/h
  - (2026-07-27) SAMU44 (France)
      icao24: 39ca84 · position: (47.3375, -1.1036) · alt: 548m · 254km/h
  - (2026-07-27) SAMU28 (France)
      icao24: 39ca85 · position: (48.72, 1.4085) · alt: 297m · 128km/h
  - (2026-07-27) PAT23 (United States)
      icao24: ae5369 · position: (38.5939, -77.1633) · alt: 342m · 195km/h
  - (2026-07-27) CFC3869 (Canada)
      icao24: c2b5c1 · position: (44.2412, -77.2254) · alt: 952m · 395km/h

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-27) Will the Fed decrease interest rates by 25 bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $1,788,260 · resolves 2026-07-29
  - (2026-07-27) Mubadala Citi DC Open: Kei Nishikori vs Juncheng Shang
      yes price: 90% · 24h volume: $979,190 · resolves 2026-08-03
  - (2026-07-27) US announces halt in Iran offensive operations by July 31?
      yes price: 96% · 24h volume: $728,201 · resolves 2026-08-31
  - (2026-07-27) Will Tom Cotton win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $572,416 · resolves 2028-11-07
  - (2026-07-27) The Memphis Classic: Katie Volynets vs Viktorija Golubic
      yes price: 100% · 24h volume: $535,063 · resolves 2026-08-02
  - (2026-07-27) Toronto Blue Jays vs. Washington Nationals
      yes price: 52% · 24h volume: $517,399 · resolves 2026-08-03

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-07-27) #30 Germán Larrea Mota Velasco & family — $63.32B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-07-27) MOVER ▼ Elon Musk — $715.58B ($-9.54B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-07-27) MOVER ▼ Jensen Huang — $170.00B ($-8.79B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-07-27) MOVER ▲ Larry Page — $268.78B (+$5.59B since yesterday)
      United States · Technology · source: Google
  - (2026-07-27) MOVER ▲ Sergey Brin — $247.99B (+$5.14B since yesterday)
      United States · Technology · source: Google
  - (2026-07-27) MOVER ▲ Larry Ellison — $156.89B (+$5.00B since yesterday)
      United States · Technology · source: Oracle

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-27) [Marginal Revolution] *Liberal Worlds: James Bryce and the Democratic Intellect*
      A very good book, here is one excerpt that bears directly on a conversation I was just having: He [Bryce] regretted the low quality of the Indian Civil Service: they were hard-working and motivated by a desire to promote…
  - (2026-07-27) [Marginal Revolution] Monday assorted links
      1. Cameroonian prison with its own record label. 2. Noah on what will AI do for us exactly. 3. The impact of the sewing machine on women. 4. Will GPTVoice boost labor supply? 5. Smart phones in North Korea. 6. SSI update…
  - (2026-07-27) [Marginal Revolution] Could our preoccupation with mental health be part of the problem?
      Could our preoccupation with mental health be part of the problem? In some ways, encouraging people to think and talk more about their mental health is a good thing. There is now less stigma around mental illness, and mo…
  - (2026-07-27) [Conversable Economist] Major Stereotypes
      Lots of students come to college looking for what I sometimes call a “golden ticket” major–that is, choosing a major that will assure future prosperity and status. Lots of first-year students show up declaring that their…

### Government Action: Sanctions + Procurement + Foreign Agents — 3 new of 120 total
  - (2026-07-27) [OFAC] Sanctions List Removals; Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Sanctions List Removals; Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] 1239 - Office of Foreign Assets Control (.gov)
      1239 Office of Foreign Assets Control (.gov)
  - (2026-07-27) [BIS Entity List] page checksum 5dce0c7ac819
      Page content hash: 5dce0c7ac819. Compare with prior day's hash to detect updates.

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-07-27) CVE-2025-68686 · Fortinet FortiOS: Fortinet FortiOS Exposure of Sensitive Information to an Unauthorized Actor Vulnerability
      vendor: Fortinet · product: FortiOS · CISA remediation by 2026-08-10
  - (2026-07-27) CVE-2026-16812 · Arista VeloCloud Orchestrator: Arista VeloCloud Orchestrator On-Prem OS Command Injection Vulnerability
      vendor: Arista · product: VeloCloud Orchestrator · CISA remediation by 2026-07-30

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=14, 14d-median=14; carrying terms: necessary, airplanes, amendment, additional, control, published, coast, prompted, council, proposing, review, national
- state_bills: today=14, 7d-median=66, 14d-median=66
- state_news: today=454, 7d-median=592, 14d-median=592; carrying terms: topeka, residency, criticized, arizona, offer, access, aerospace, lawmakers, career, scientists, morning, belonging
- local_news: today=229, 7d-median=238, 14d-median=238; carrying terms: access, jackson, morning, overnight, office, ongoing, inside, found, region, woman, attachment, around
- foreign_news: today=1007, 7d-median=1016, 14d-median=1016; carrying terms: boxing, offer, expectations, documents, access, cited, ngjing, scientists, peninsula, office, diversion, inside
- chinese_internal: today=262, 7d-median=282, 14d-median=282; carrying terms: cbmidefvx, cbmib, china, caixin, beijing, cbmibkfvx, cbmizefvx, deepseek, cbmiyefvx, chain, investment, target
- russian_internal: today=879, 7d-median=856, 14d-median=856; carrying terms: wildberries, novayagazeta, margin, axios, style, gazeta, httperror, found, centcom, reuters, fonbet, raquo
- ukrainian_internal: today=131, 7d-median=138, 14d-median=138; carrying terms: destroyed, criticized, citizens, vital, offer, kyivindependent, lawmakers, bombs, morning, defenses, overnight, sources
- ukraine_theater: today=647, 7d-median=616, 14d-median=616; carrying terms: njluxvcmpqrklqugiynuply, components, arizona, dunazkuym, dknjfjyzjbwgrtudnxcujhdjfsoxu, ycfdbqktzrl, ftzhfucmphegfxzznid, xwyvdjqv, vugxoyuzqrfzpcnjsd, bznjbgfsowdjvmgxz, kuwlxx, zfvktludn
- paper_bets: today=130, 7d-median=140, 14d-median=140; carrying terms: colorado, lesswrong, experience, determined, wisconsin, arizona, california, jackson, alaska, erupt, james, democratic
- weather: today=175, 7d-median=176, 14d-median=176; carrying terms: morning, overnight, ongoing, inches, extending, region, around, service, water, unhealthy, baltimore, information
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: sheet, inflation, energy, supply, commodities, spread, dexchus, vixcls, assets, cpiaucsl, openings, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, proxy, commodities, credit, silver, china, treasury, nasdaq, rates, futures, crypto, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=120, 7d-median=119, 14d-median=119; carrying terms: niger, colorado, gfbvv, dfbfehlhafb, transition, democratic, occupation, prohibited, tiananmen, space, foreign, weapons
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, https, quiver, client, congresstrading, error, httperror, unauthorized, quiverquant
- billionaires: today=40, 7d-median=32, 14d-median=32; carrying terms: trading, gates, changpeng, steve, larry, mexico, buffett, giancarlo, tadashi, spacex, thomas, gcarsoa
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: california, services, holdings, blanche, court, group, trade, supreme, international, district, douglas, ahmed
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, issuer, accno
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: colorado, warner, pinkston, booker, brown, alexandria, committee, jonathan, ocasio, shawn, james, trone
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english
- gdelt_gkg: today=25, 7d-median=47, 14d-median=47; carrying terms: hezbollah, israel, trump, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=18, 7d-median=14, 14d-median=14
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: niger, determined, confirmation, vaccine, complete, hantavirus, exposed, ebola, democratic, haemorrhage, disease, being
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: command, association, sonicwall, deserialization, services, product, injection, langflow, access, mechanism, cisco, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=313, 7d-median=179, 14d-median=179; carrying terms: poland, marino, philippines, north, mexico, macedonia, monaco, speed, switzerland, minor, congo, hungary
- usgs_quakes: today=24, 7d-median=24, 14d-median=24; carrying terms: islands, atlantic, south, depth, region
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, interest, meeting, rates, price, volume, resolves, prime, ethiopia
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginalrevolution, conversable, links, marginal, revolution, benefit, class, assorted, https, economist
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: experience, field, access, online, project, plants, attackers, updates, amazing, version, blogging, tools
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: loudermilk, veterans, angus, components, salinas, alexandria, credit, communications, smith, jackson, tlaib, patronis
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, placement, unavailable, market, markets, identify, evidence, converges, placed, sufficient, paper, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*