# WORLDSCOPE morning brief — 2026-09-24

## Headline
3390 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (855) · Russian Internal News (state + in-exile) (714) · State-Level News (385) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (211) · Chinese Internal News (209) · U.S. Weather + Severe / Climate Outlooks (166) · Ukraine Theater (total-war monitoring) (89) · GDELT GKG — themes / entities / watch areas (75) · Ukrainian Internal News (national + local Kyiv) (73) · IT, InfoSys & cybersecurity news (last 7 days) (43) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 855 new of 1073 total
  - (2026-09-23) [Global] Milei threatens at UN that Argentina will take ‘matters into our own hands’ on Falklands
  - (2026-09-23) [Global] Delcy Rodríguez poses with Trump in New York as Maduro languishes in jail nearby
  - (2026-09-24) [Global] Alarm bells sound in Brussels as EU sales of Chinese hybrid cars rocket
  - (2026-09-23) [Global] Trump greets Xi Jinping on arrival in rare move as US-China trade truce extended
  - (2026-09-24) [Global] Boy, 11, shot in the face and neck in Sydney dies from his injuries
  - (2026-09-24) [Global] Beau Lamarre-Condon sized up surfboard bag against friend before allegedly murdering Sydney couple, court told

### Russian Internal News (state + in-exile) — 714 new of 1125 total
  - (2026-09-24) В Польше украинец с ножом напал на служителей монастыря. Есть погибшие и раненые | LEDE: В польском городе Ярослав (расположен в Подкарпатском воеводстве на юге страны) 31-летний гражданин У] (ru: В П…
      В польском городе Ярослав (расположен в Подкарпатском воеводстве на юге страны) 31-летний гражданин Украины напал с ножом на людей на территории монастыря сестер-бенедиктинок.
  - (2026-09-24) Украина предложила Евросоюзу ввести санкции против Потанина и Лисина — вместо Фридмана и Усманова, с которых санкции сняли | LEDE: Евросоюз создал «опасный прецедент», сняв санкции с Михаила] (ru: Укр…
      Евросоюз создал «опасный прецедент», сняв санкции с Михаила Фридмана и Алишера Усманова, однако он мог бы вернуть себе доверие введением санкций против двух других российских миллиардеров — Владимира Потанина и Владимира…
  - (2026-09-24) Под Варшавой загорелась наземная станция Starlink. Спецслужбы подозревают российскую диверсию | LEDE: В Польше вечером 23 сентября загорелась наземная станция спутниковой связи Starlink, рас] (ru: Под…
      В Польше вечером 23 сентября загорелась наземная станция спутниковой связи Starlink, расположенная в деревне Воле-Кробовской в Мазовецком воеводстве (это менее чем в 50 километрах от Варшавы).
  - (2026-09-24) Минфин представил трехлетний бюджет. В него заложен дефицит в 2% ВВП ежегодно и повышение ставки налога на пассивные доходы | LEDE: Министерство финансов РФ внесло в правительство проект бюд] (ru: Мин…
      Министерство финансов РФ внесло в правительство проект бюджета на 2027 год и плановый период 2028 и 2029 годов.
  - (2026-09-24) «Табуретку не брать. Установлена для отдыха при подъеме». Многоэтажка в Жуковском попала под обстрел в июне. Жители до сих пор ходят на 23-й этаж без лифта — и развлекают друг друга распечатанн] (ru:…
      В ночь на 18 июня во время очередной атаки украинских беспилотников был поврежден многоквартирный дом в Жуковском. Удар пришелся на 24 и 25 этажи. Жертв среди жителей не было, но в доме перестал работать лифт. За три мес…
  - (2026-09-24) ИИ-агенты OpenAI взломали сайт австралийского Минздрава. Это первый подобный случай взлома государственных структур | LEDE: Премьер-министр Австралии Энтони Албаниз заявил, что ИИ-агенты ком] (ru: ИИ-…
      Премьер-министр Австралии Энтони Албаниз заявил, что ИИ-агенты компании OpenAI взломали национальную базу данных здравоохранения Австралии. Это первый известный в мире случай, когда агенты проникли в системы государствен…

### State-Level News — 385 new of 763 total
  - (2026-09-24) [California] During Climate Week NYC, Governor Newsom announces major development for California’s carbon market, deepens cooperation with Australia, signs new Finland partnership
      Source
  - (2026-09-23) [California] Governor Newsom calls out Trump’s climate failure at the United Nations
      Source
  - (2026-09-23) [California] Governor Newsom announces world-leading experts to deliver on his AI executive order, including advancing creation of a “kill switch”
      Source
  - (2026-09-23) [California] Governor Newsom announces key step forward in California plan to link carbon markets with Washington State
      Source
  - (2026-09-24) [California] Bonta’s cave on Paramount-Warner deal fits California’s history of corporate surrender
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/092026_PARAMOUNTMERGER_PU_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-09-24) [California] The billionaire tax could be defeated by two other tax measures. Here’s how
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/022126_Billionaire-Tax-Now_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 211 new of 242 total
  - (2026-09-24) [St. Louis] Lawyers step up to stop scammers targeting St. Louis tornado victims
      Whenever St. Louis Mayor Cara Spencer found herself interacting with people whose homes were in the path of the May 16, 2025 tornado, she heard a familiar refrain: Unscrupulous contractors were out there, preying on the…
  - (2026-09-24) [St. Louis] Grandview Arcade rehab along South Grand gives neighbors a sneak peek
      A little more than a year since the much anticipated Marquette Homes project broke ground in South St. Louis, the rehabilitation of one of the most recognizable buildings in the $26.3 million scattered site project is ne…
  - (2026-09-24) [St. Louis] Where in the Lou? – 9/24/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-09-23) [St. Louis] Top things to do in St. Louis this weekend: September 25–27
      See Also:Tower Grove PrideEureka DaysArt in the Park @ St. Louis Hills’ Francis ParkTom Papa @ The FactoryBreaking Benjamin @ Hollywood Casino AmphitheatreSon Volt @ Delmar HallTommy Davidson @ Helium Comedy ClubMarquise…
  - (2026-09-24) [St. Louis] Lack of ‘consistency,’ ‘transparency’ drives recent St. Louis service industry unionizing efforts
  - (2026-09-24) [St. Louis] How data center noise is different from regular noise pollution, according to a St. Louis scientist

### Chinese Internal News — 209 new of 265 total
  - (2026-09-23) 备案审查拟专门立法 如何增强纠错刚性？ - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5Va3lWQkk4ZUQwdEZRR09peGh0aDJ2MWVOT0s1Ny1rNkJ1bFhuLXdqWEN2RktBZDVXSjU3QzBmd2plZk9Dd1pv] (zh:…
      备案审查拟专门立法 如何增强纠错刚性？ china.caixin.com
  - (2026-09-23) 财经早知道｜习近平抵达华盛顿开始对美国事访问 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5wXzMzaW9MbXVKOEVYZDdEN2lRZHZ5TWRzbFpNeUJmRFhGUldyaEtTTUxhZER0Z0Vselp3cmtXaUlWanNCWlpwQ1ltOUl0THJ] (zh:…
      财经早知道｜习近平抵达华盛顿开始对美国事访问 财新
  - (2026-09-23) 习近平抵达华盛顿开始对美国事访问 特朗普到场迎接 - international.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1MYUVmREt6eWprOFhWRlNpckg2LVpac1FIMklmMVBueUIyenByek5rcUs1Y0x2T1FGcE5vZzd] (zh:…
      习近平抵达华盛顿开始对美国事访问 特朗普到场迎接 international.caixin.com
  - (2026-09-23) 人事观察｜党政主官同时调整 57岁王陆进跨省履新河南省政府 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9NSUJLRHU3QWZtTjhZTlJpM2wtRFRUQXhxLWNvclcxNFNBSFNKbEk0Tjd3b2pQMklTa3N5MjBUM0] (zh:…
      人事观察｜党政主官同时调整 57岁王陆进跨省履新河南省政府 china.caixin.com
  - (2026-09-23) 区分药用与非药用 涉芬太尼类物质犯罪量刑有新标准 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE10ZnlJY2pFSDZKNnExZnRXUXBXOGZqanNXZGItVE5qWEJFTUF6d0FWcXFrUVJvcld6Z1dDWjBhSGRrYU9] (zh:…
      区分药用与非药用 涉芬太尼类物质犯罪量刑有新标准 china.caixin.com
  - (2026-09-23) 时隔四年新城控股重启境内纯信用债 民企境内发债通道能否修复？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE10cnhNRDVERFJIdGttZGlkM2RNQTVHaG1fcWJNeEI2eDhfZ0NMOV84X2s0NzZ1eldockEzZ3pwcVVYcEpmWXZMMWF] (zh:…
      时隔四年新城控股重启境内纯信用债 民企境内发债通道能否修复？ 财新

### U.S. Weather + Severe / Climate Outlooks — 166 new of 167 total
  - (2026-09-24) [Severe] Flash Flood Warning: Flash Flood Warning issued September 24 at 5:25AM MST until September 24 at 8:30AM MST by NWS Flagstaff AZ
      FFWFGZ The National Weather Service in Flagstaff has issued a * Flash Flood Warning for... Yavapai County in west central Arizona... * Until 830 AM MST. * At 525 AM MST, Doppler radar indicated thunderstorms producing he…
  - (2026-09-24) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-24) [Moderate] Gale Warning: Gale Warning issued September 24 at 4:21AM AKDT until September 25 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-24) [Severe] Storm Warning: Storm Warning issued September 24 at 4:21AM AKDT until September 25 at 5:00AM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-24) [Moderate] Gale Warning: Gale Warning issued September 24 at 4:21AM AKDT until September 25 at 5:00AM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-24) [Moderate] Gale Warning: Gale Warning issued September 24 at 4:21AM AKDT until September 24 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…

### Ukraine Theater (total-war monitoring) — 89 new of 368 total
  - (2026-09-24) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-23) [FIRMS] thermal anomaly 44.226, 25.900 (FRP 5.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-23 1110Z, FRP 5.53 MW
  - (2026-09-23) [FIRMS] thermal anomaly 44.230, 25.899 (FRP 5.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-23 1110Z, FRP 5.53 MW
  - (2026-09-23) [FIRMS] thermal anomaly 44.249, 25.788 (FRP 5.09 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-23 1110Z, FRP 5.09 MW
  - (2026-09-23) [FIRMS] thermal anomaly 44.258, 25.822 (FRP 10.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-23 1110Z, FRP 10.89 MW
  - (2026-09-23) [FIRMS] thermal anomaly 44.261, 25.816 (FRP 10.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-23 1110Z, FRP 10.89 MW

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-09-24) [Israel-Iran-Hezbollah axis · keywords] Netanyahu To Address UN General Assembly Amid Protests | News Radio 1410 AM & 100 . 9 FM
      newsradio1410.iheart.com · English · tone NA
  - (2026-09-24) [Israel-Iran-Hezbollah axis · keywords] Netanyahu To Address UN General Assembly Amid Protests
      970kfbx.iheart.com · English · tone NA
  - (2026-09-24) [Israel-Iran-Hezbollah axis · keywords] Netanyahu fleeting visit to New York mirrors strained US ties
      straitstimes.com · English · tone NA
  - (2026-09-24) [Israel-Iran-Hezbollah axis · keywords] Netanyahu To Address UN General Assembly Amid Protests
      720thevoice.iheart.com · English · tone NA
  - (2026-09-24) [Israel-Iran-Hezbollah axis · keywords] Netanyahu To Address UN General Assembly Amid Protests
      wiba.iheart.com · English · tone NA
  - (2026-09-24) [Israel-Iran-Hezbollah axis · keywords] Netanyahu takes UN stage with one eye on Israel election | United Nations News
      aljazeera.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 73 new of 139 total
  - (2026-09-24) Російський FPV-дрон атакував вантажівку в Краматорську, водій загинув | LEDE: Вранці 24 вересня російські окупанти атакували FPV-дроном вантажівку в Краматорську Донецької області, внаслідок уд] (uk:…
      Вранці 24 вересня російські окупанти атакували FPV-дроном вантажівку в Краматорську Донецької області, внаслідок удару загинув водій.
  - (2026-09-24) Тридцять медалей на бригаду: що не так з нагородною системою у війську | LEDE: Нагородна система українського війська залишається складною. Військові скаржаться на квоти, відсутність критеріїв ] (uk:…
      Нагородна система українського війська залишається складною. Військові скаржаться на квоти, відсутність критеріїв та прозорості призначення.
  - (2026-09-24) В Міноборони заявили, що не оскаржуватимуть рішення судів щодо загибелі і зникнення без вісти військових | LEDE: Міністерство оборони України відмовляється від оскарження судових рішень щодо см] (uk:…
      Міністерство оборони України відмовляється від оскарження судових рішень щодо смерті чи зникнення військовослужбовців – це спростить оформлення виплат сім’ям.
  - (2026-09-24) Українець у монастирі Польщі напав з ножем на 5-х людей: загинув священник | LEDE: У Ярославі 31-річний громадянин України напав із ножем на п'ятьох людей, один священник загинув. Нападника зат] (uk:…
      У Ярославі 31-річний громадянин України напав із ножем на п'ятьох людей, один священник загинув. Нападника затримала поліція, триває розслідування.
  - (2026-09-24) 7 корпус ДШВ: Українські артилеристи уразили техніку й позиції росіян у Гуляйполі | LEDE: Військові 7 корпусу ДШВ спільно з 44-ю окремою артилерійською бригадою імені гетьмана Данила Апостола у] (uk:…
      Військові 7 корпусу ДШВ спільно з 44-ю окремою артилерійською бригадою імені гетьмана Данила Апостола уразили артилерійські системи, бронетехніку та особовий склад росіян у Гуляйполі Запорізької області.
  - (2026-09-24) Справа "Північних потоків": суд Хорватії дозволив екстрадицію українця Журавльова в Німеччину | LEDE: Окружний суд хорватського міста Пула дав дозвіл на екстрадицію українця Володимира Журавльо] (uk:…
      Окружний суд хорватського міста Пула дав дозвіл на екстрадицію українця Володимира Журавльова до Німеччини, де його підозрюють у підриві газопроводів "Північний потік" та "Північний потік-2".

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 56 total
  - (2026-09-24) [BleepingComputer] Windows 11 KB5124010 update released with 46 changes and fixes
      Microsoft released the KB5124010 September 2026 non-security preview update for Windows 11 24H2 and 25H2, with 46 changes including Bluetooth improvements and the ability to remap the Copilot key. [...]
  - (2026-09-24) [BleepingComputer] CISA: Ransomware gangs now exploiting critical TeamCity flaw
      ​The U.S. Cybersecurity and Infrastructure Security Agency (CISA) warned federal agencies on Wednesday that ransomware gangs are now also exploiting a critical JetBrains TeamCity vulnerability patched in July. [...]
  - (2026-09-24) [BleepingComputer] OpenAI hacked Australian Medicare govt site, probed data providers
      OpenAI agents targeted public data providers in multiple countries, probing some for vulnerabilities and exploiting a security weakness in an Australian government portal while performing information-retrieval tasks as p…
  - (2026-09-24) [BleepingComputer] Microsoft fixes bug that broke Windows File History backup feature
      Microsoft has fixed a known issue that breaks the built-in File History backup feature on some Windows systems after installing the September 2026 security updates. [...]
  - (2026-09-24) [The Hacker News] Corp MDM Spyware Targets Logistics Firms, Steals New SMS and Redirects Calls
      The logistics sector has become the target of a new malicious cyber campaign that distributes an Android spyware codenamed Corp MDM. According to Have I Been Squatted, the campaign uses fake Google Play pages branded as…
  - (2026-09-24) [The Hacker News] Secrets Sprawl Is an Identity Problem That AI Just Made Impossible to Ignore
      AI coding agents are changing how quickly developers can build and ship software as well as how quickly credentials can become exposed. According to GitGuardian’s 2026 State of Secrets Sprawl Report, commits identified a…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-24) 424B3 - Nuveen Enhanced CLO Income Fund (0002035726) (Filer)
      filed 2026-09-24 11:31 UTC — Filed: 2026-09-24 AccNo: 0001999371-26-021187 Size: 13 KB
  - (2026-09-24) 424B3 - Nuveen Credit Strategies Income Fund (0001227476) (Filer)
      filed 2026-09-24 11:30 UTC — Filed: 2026-09-24 AccNo: 0001999371-26-021185 Size: 5 KB
  - (2026-09-24) 424B3 - Pasqal Holding SA (0002119292) (Filer)
      filed 2026-09-24 11:20 UTC — Filed: 2026-09-24 AccNo: 0001213900-26-102836 Size: 901 KB
  - (2026-09-24) 424B3 - Yimutian Inc. (0001991605) (Filer)
      filed 2026-09-24 11:15 UTC — Filed: 2026-09-24 AccNo: 0001213900-26-102833 Size: 35 KB
  - (2026-09-24) [Goldwasser Karnit] Form 4 (Reporting)
      filed 2026-09-24 11:00 UTC · role: Reporting — Filed: 2026-09-24 AccNo: 0001213900-26-102825 Size: 12 KB
  - (2026-09-24) [KAMADA LTD] Form 4 (Issuer)
      filed 2026-09-24 11:00 UTC · role: Issuer — Filed: 2026-09-24 AccNo: 0001213900-26-102825 Size: 12 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-24) [United States] 8 sailors in USS Lincoln strike group attempted suicide , Navy says
      domain: ky3.com · language: English · tone:
  - (2026-09-24) [Germany] Brightline Interactive Secures Strategic Investment Led by Drone Executive Allan Evans
      domain: finanznachrichten.de · language: English · tone:
  - (2026-09-24) [United Kingdom] Wayne Rooney hits back at weight loss claims as he showcases new look
      domain: manchestereveningnews.co.uk · language: English · tone:
  - (2026-09-24) [Malaysia] Be professional , not vengeful , PAS told over PN suspension
      domain: freemalaysiatoday.com · language: English · tone:
  - (2026-09-24) [United States] Unknown wanderer in 1982 Boise cold case identified
      domain: fox23.com · language: English · tone:
  - (2026-09-24) [] we are close to tears while watching this circus of deceit ....
      domain: yourdemocracy.net · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 27 new of 30 total
  - (2026-09-24) JAF95J (Bulgaria)
      icao24: 4520aa · position: (38.2146, -7.6846) · alt: 11277m · 803km/h
  - (2026-09-24) PAT027 (United States)
      icao24: adfe8d · position: (37.8063, -81.5363) · alt: 8229m · 432km/h
  - (2026-09-24) JEDI52 (United States)
      icao24: adff0b · position: (30.3728, -87.5186) · alt: 3627m · 372km/h
  - (2026-09-24) PUMA47 (Slovenia)
      icao24: 506e1d · position: (46.0128, 14.5517) · alt: 731m · 195km/h
  - (2026-09-24) CFC2908 (Canada)
      icao24: c2b585 · position: (54.1612, -2.201) · alt: 7315m · 544km/h
  - (2026-09-24) FNY55G8 (France)
      icao24: 39a407 · position: (44.3376, 2.377) · alt: 13106m · 695km/h

### Court opinions of consequence (federal & state) — 24 new of 60 total
  - (2026-09-23) U.S. Court of Appeals, 6th Cir.: Cargill, Inc. v. MSHR
  - (2026-09-23) U.S. Court of Appeals, 8th Cir.: John Doe v. Hennepin Healthcare System, Inc.
  - (2026-09-23) U.S. Court of Appeals, 1st Cir.: FOMB v. U.S. Bank National Association
  - (2026-09-23) U.S. Court of Appeals, 9th Cir.: Bandary v. Delta Air Lines, Inc.
  - (2026-09-23) U.S. Court of Appeals, 9th Cir.: Codoni v. Port of Seattle
  - (2026-09-23) U.S. Court of Appeals, 9th Cir.: Collard v. Bisignano

### Paper Trading Scorecard — 22 new of 134 total
  - (2026-09-24) [Kalshi] When will the Riemann Hypothesis be resolved?
      Before 2040
  - (2026-09-24) [Manifold] Daily Coinflip
  - (2026-09-24) [Manifold] US Average Gas Price Is $4.4800 or more on September 28 2026?
  - (2026-09-24) [Manifold] Blue Wave in 2026?
  - (2026-09-24) [Manifold] Will Xi Jinping safely return to China after visiting the US?
  - (2026-09-24) [Manifold] NFL Week 3: Will the total combined score of the Chargers vs. Buffalo Bills game be OVER 51.5 points?

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-09-24) Dota 2: Natus Vincere vs LGD Gaming (BO3) - PGL Wallachia Playoffs
      yes price: 6% · 24h volume: $1,421,411 · resolves 2026-09-24
  - (2026-09-24) Valorant: TYLOO vs G2 Esports (BO3) - VCT Champions Group C
      yes price: 32% · 24h volume: $777,275 · resolves 2026-09-24
  - (2026-09-24) Kharg Island no longer under Iranian control by September 30?
      yes price: 0% · 24h volume: $473,379 · resolves 2026-10-01
  - (2026-09-24) Will the Fed decrease interest rates by 50+ bps after the October 2026 meeting?
      yes price: 0% · 24h volume: $439,201 · resolves 2026-10-29
  - (2026-09-24) Will the Fed increase interest rates by 50+ bps after the October 2026 meeting?
      yes price: 1% · 24h volume: $359,800 · resolves 2026-10-29
  - (2026-09-24) Will Japan win on 2026-09-24?
      yes price: 100% · 24h volume: $351,340 · resolves 2026-09-24

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 103 total
  - (2026-09-23) [OFAC] Democratic Republic of the Congo-related Designations Removals - ofac.treasury.gov
      Democratic Republic of the Congo-related Designations Removals ofac.treasury.gov
  - (2026-09-18) [OFAC] Expiration of Emergency With Respect to the Situation in Ethiopia; Ethiopia-related Designations Removals; Issuance of Amended Russia-related General License and Associated Frequently Asked Que…
      Expiration of Emergency With Respect to the Situation in Ethiopia; Ethiopia-related Designations Removals; Issuance of Amended Russia-related General License and Associated Frequently Asked Questions ofac.treasury.gov
  - (2026-09-17) [OFAC] Iran-related Designations; Cuba Designations; Belarus-related Designations Removals - ofac.treasury.gov
      Iran-related Designations; Cuba Designations; Belarus-related Designations Removals ofac.treasury.gov
  - (2026-09-18) [OFAC] Russian Harmful Foreign Activities Sanctions - ofac.treasury.gov
      Russian Harmful Foreign Activities Sanctions ofac.treasury.gov
  - (2026-09-18) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - ofac.treasury.gov
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 ofac.treasury.gov
  - (2026-09-19) [OFAC] Sanctions Programs Atlas - ofac.treasury.gov
      Sanctions Programs Atlas ofac.treasury.gov

### U.S. Federal Action — 11 new of 11 total
  - (2026-09-24) Rules of Practice
      The Federal Trade Commission ("Commission" or "FTC") is amending its rules of practice in order to eliminate the agency's post- employment clearance rule.
  - (2026-09-24) Rules of Practice
      The Federal Trade Commission ("Commission" or "FTC") is amending its rules of practice to revise the description of the FTC's EEO Office and Regional Offices and to update the list of current control numbers assigned by…
  - (2026-09-24) Flight Operations: Pilot requirements; Use of oxygen
      FAA proposes to raise the altitudes at which a pilot is required to don an oxygen mask for commuter and on demand operations, as directed by the FAA Reauthorization Act of 2024, and revise the pilot oxygen mask requireme…
  - (2026-09-24) Substantial Product Hazard List: Amendments to Requirements for Window Covering Cords
      To address window covering cord strangulation risks, the Commission proposes to designate certain window coverings a substantial product hazard. These include products with: accessible free hanging operating cords longer…
  - (2026-09-24) Regulatory Enhancements for Reactor Licensing, Decommissioning, and Operational Oversight
      Consistent with Executive Order 14300, "Ordering the Reform of the Nuclear Regulatory Commission," the NRC is conducting a review and wholesale revision of its regulations. This proposed rule primarily aims to provide re…
  - (2026-09-24) Air Plan Approval; Alabama; Transportation Conformity
      The U.S. Environmental Protection Agency (EPA or Agency) is approving a State Implementation Plan (SIP) revision submitted by the State of Alabama, through the Alabama Department of Environmental Management (ADEM) on Apr…

### USGS earthquakes (M4.5+, past day) — 10 new of 10 total
  - (2026-09-23) M 5.7 - 180 km NW of Hihifo, Tonga
      M5.7 · 180 km NW of Hihifo, Tonga · depth 10 km
  - (2026-09-24) M 5.3 - 15 km SSW of Hilvan, Turkey
      M5.3 · 15 km SSW of Hilvan, Turkey · depth 10 km
  - (2026-09-23) M 5.0 - 140 km NNE of Ba, Fiji
      M5.0 · 140 km NNE of Ba, Fiji · depth 10 km
  - (2026-09-23) M 5.0 - Mariana Islands region
      M5.0 · Mariana Islands region · depth 306.016 km
  - (2026-09-24) M 4.9 - Kermadec Islands, New Zealand
      M4.9 · Kermadec Islands, New Zealand · depth 35 km
  - (2026-09-23) M 4.9 - 193 km SE of Mata-Utu, Wallis and Futuna
      M4.9 · 193 km SE of Mata-Utu, Wallis and Futuna · depth 10 km

### State Legislative Action — 5 new of 120 total
  - (2026-09-24) [Alaska SB 169] An Act establishing the welcoming Alaska office; establishing the welcoming Alaska center; establishing the Welcoming Alaska Advisory Committee; repealing the office of citizenship ass…
      An Act establishing the welcoming Alaska office; establishing the welcoming Alaska center; establishing the Welcoming Alaska Advisory Committee; repealing the office of citizenship assistance; and providing for an effect…
  - (2026-09-24) [Alaska SB 243] An Act removing devices designed, made, or adapted to muffle the report of a firearm from the definition of 'prohibited weapon.'
      An Act removing devices designed, made, or adapted to muffle the report of a firearm from the definition of 'prohibited weapon.'
  - (2026-09-24) [California SB 907] Driving under the influence and other driving offenses: comprehensive reform.
      Existing law makes it a crime to operate a vehicle while under the influence of alcohol or drugs, and sets forth the penalties for a violation of these provisions. Existing law requires the driver of a vehicle involved i…
  - (2026-09-24) [California SB 378] Online marketplaces: illicit cannabis: reporting and liability.
      (1) Existing law, the Control, Regulate and Tax Adult Use of Marijuana Act (AUMA) , an initiative measure, authorizes a person who obtains a state license under AUMA and any applicable local ordinances to engage in comme…
  - (2026-09-24) [California SB 908] Residential windows: retrofitting: residential window replacement projects: California Building Code compliance.
      (1) Existing law, the Davis-Stirling Common Interest Development Act, governs the management and operation of common interest developments. Existing law places various limits and prohibitions on the governing documents,…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-09-24) [Marginal Revolution] CA 91326: A Public Choice Mystery Investigation
      Carl Danner writes to me with a political economy mystery. On Sept 9, 2026, The California Public Utilities Commission announced a set of clean energy grants but only “for eligible organizations headquartered in ZIP Code…
  - (2026-09-24) [Marginal Revolution] *Fear of Data*
      The author is Omri Ben-Shahar, and the subtitle is How Privacy Panic Led Tech Regulation Astray — and How to Fix It. I would describe this book as bracing, and full of substantive engagement. Basically the author wishes…
  - (2026-09-24) [Marginal Revolution] My economics-rich Conversation with Gita Gopinath
      Here is the audio, video, and transcript. Here is the episode summary: Gita Gopinath has spent the last several years inside the room where the world’s monetary plumbing gets fixed — or doesn’t. As first deputy managing…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=11, 7d-median=18, 14d-median=19; carrying terms: proposes, model, certain, proposed, program, establishing, airworthiness, proposing, public, final, directive, directives
- state_bills: today=120, 7d-median=106, 14d-median=105; carrying terms: adopt, pursuant, relating, january, annually, within, provides, regulates, transportation, effective, authorizes, quality
- state_news: today=763, 7d-median=683, 14d-median=708; carrying terms: sizes, least, electricity, international, along, sports, nation, career, group, provides, commentary, lawmakers
- local_news: today=242, 7d-median=238, 14d-median=236; carrying terms: night, event, fulton, against, injured, court, found, death, culture, community, shooting, county
- foreign_news: today=1073, 7d-median=1045, 14d-median=994; carrying terms: linked, least, timeout, international, colombia, nation, career, globe, event, israel, caused, article
- chinese_internal: today=265, 7d-median=271, 14d-median=282; carrying terms: lxtfa, cbmibkfvx, cbmiaefvx, target, color, cbmizefvx, cbmixkfvx, global, google, cbmib, title, cbmibefvx
- russian_internal: today=1125, 7d-median=1067, 14d-median=1067; carrying terms: httperror, russian, europe, istories, https, server, gazeta, media, error, ukraina, financial, title
- ukrainian_internal: today=139, 7d-median=135, 14d-median=136; carrying terms: prime, shahed, defense, least, international, group, ministers, ukrinform, vechirniy, massive, continues, operations
- ukraine_theater: today=368, 7d-median=427, 14d-median=426; carrying terms: defense, kuwlxx, luzupcnkpheunxnwdfau, dghqy, tyellwoujqegfda, joint, commentary, nvcwd, jsykxfy, qwhxu, xujlrdmv, hewljiugrgx
- paper_bets: today=134, 7d-median=129, 14d-median=128; carrying terms: prime, special, seats, state, north, prize, population, leave, nuclear, secretary, celsius, least
- weather: today=167, 7d-median=117, 14d-median=116; carrying terms: southeast, mount, north, around, afternoon, flood, hazardous, upper, weekend, along, valley, monday
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: headline, growth, sheet, supply, energy, vixcls, assets, pcepilfe, dcoilwtico, cpiaucsl, labor, openings
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, nasdaq, range, equities, large, china, russell, agriculture, credit, treasury, crude, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=103, 7d-median=105, 14d-median=107; carrying terms: transactions, abuses, respect, russian, february, updates, latinscript, islamic, application, embargo, specific, libya
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, congresstrading, error, quiverquant, https, client, quiver, unauthorized, quantitative
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, appeals, supreme, court, delaware, company, arizona, trade, international, connecticut, blanche, association
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, holdings, trust, filer, subject, group, financial, technology
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: johnson, filing, receipts, krishnamoorthi, platner, james, cortez, trone, david, ossoff, brown, raised
- gdelt_regions: today=0, 7d-median=0, 14d-median=6; carrying terms: english
- gdelt_gkg: today=75, 7d-median=50, 14d-median=50; carrying terms: sanctions, english, themes, spanish, chinese, trump, north, russian, french, polish, israel, german
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, germany, ground, france, kingdom, bulgaria, canada, slovenia, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: phase, great, france, north, characterized, fever, ongoing, contamination, parganas, hospital, early, index
- cisa_kev: today=18, 7d-median=21, 14d-median=21; carrying terms: missing, artifactory, engine, critical, bounds, cisco, product, products, secure, jfrog, buffer, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=10, 7d-median=14, 14d-median=13; carrying terms: depth, indonesia, islands, region, south, argentina, tonga, hihifo, zealand
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, champions, shakhtar, league, interest, rates, meeting, championship, donetsk, september
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: conversableeconomist, conversable, revolution, economist, https, marginal, class, report, evidence, social, global, current
- tech_news: today=56, 7d-median=57, 14d-median=57; carrying terms: critical, cybersecurity, intelligence, hacker, vulnerability, security, company, weekly, target, access, years, anthropic
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: christopher, hillary, golden, joseph, shelley, defense, pelosi, castor, rutherford, subramanyam, correa, rulli
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, placement, module, identify, unavailable, either, placed, paper, today, converges, markets, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] ECB press: ECB Consumer Expectations Survey results – August 2026
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-21] ECB press: ECB to invest part of own funds in tokenised securities, with settlement via Pontes
- [2026-09-21] ECB press: Eurosystem brings central bank money to tokenised finance
- [2026-09-22] ECB press: Philip R. Lane: Interview with Le Temps
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-23] ECB press: Almost ten million people took part in ECB survey on new euro banknotes
- [2026-09-23] Fed speeches: Barr, A Long-Term View on the Costs of Shelter
- [2026-09-23] ECB press: The digitalisation of money, payments and finance
- [2026-09-23] ECB press: Philip R. Lane: The Outlook for the Euro Area Economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*