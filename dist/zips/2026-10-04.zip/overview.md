# WORLDSCOPE morning brief — 2026-10-04

## Headline
2529 new items across 20 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (650) · Russian Internal News (state + in-exile) (549) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (291) · Chinese Internal News (189) · Local News: St. Louis + Atlanta (120) · U.S. Weather + Severe / Climate Outlooks (118) · State-Level News (95) · Ukrainian Internal News (national + local Kyiv) (59) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (25) · USGS earthquakes (M4.5+, past day) (19)

## What changed today
### International News + Multilateral Institutions — 650 new of 947 total
  - (2026-10-04) [Global] Brazil goes to polls in decisive election for future of Latin America
  - (2026-10-04) [Global] US Coast Guard searches for missing air ambulance off coast of Massachusetts
  - (2026-10-04) [Global] UK car industry faces ‘difficult trade-off’ between Chinese and EU markets
  - (2026-10-04) [Global] No bail for P-plater over Newcastle crash that left five-year-old in induced coma and injured nine other NRL fans
  - (2026-10-04) [Global] Chalmers says global economic turmoil will drive budget cuts, but Australia should avoid recession
  - (2026-10-04) [Global] Flydubai co-pilot’s time in Australia being investigated by security agencies after alleged cockpit attack

### Russian Internal News (state + in-exile) — 549 new of 883 total
  - (2026-10-04) Война. 1684-й день. Зеленский пообещал усилить удары по российским НПЗ. В Минобороны РФ заявили, что «услышали» это — и поэтому расширят собственные атаки | LEDE: «Медуза» с 24 февраля 2022 ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-04) В больницах Иркутска ввели карантин после смерти сотрудницы противочумного института. Роспотребнадзор заверяет: она умерла от пневмонии, а эпидемиологическая обстановка — «стабильная» | LEDE: <] (ru:…
      Издание «Люди Байкала» 4 октября сообщило, что в нескольких больницах Иркутска ввели трехнедельный карантин. По информации журналистов, закрыты городские клинические больницы № 1, 3, 10 и Ивано-Матренинская детская больн…
  - (2026-10-04) Приставы начали арестовывать средства организаторов несостоявшихся концертов Канье Уэста в Санкт-Петербурге | LEDE: Судебные приставы наложили арест в 115,5 тысячи рублей в отношении агентст] (ru: При…
      Судебные приставы наложили арест в 115,5 тысячи рублей в отношении агентства Say Agency, занимавшегося организацией концертов Канье Уэста в Санкт-Петербурге. Об этом пишет ТАСС.
  - (2026-10-04) Минобороны объявило о появлении у РФ глобальной системы мониторинга обстановки в космосе | LEDE: В России создана глобальная система мониторинга космической обстановки. Об этом заявило Миноб] (ru: Мин…
      В России создана глобальная система мониторинга космической обстановки. Об этом заявило Минобороны РФ.
  - (2026-10-04) Сантехник Янив Хаюн спас самолет Flydubai, вспомнив алгоритм действий из сериала «Расследования авиакатастроф». Что это за сериал и что еще можно посмотреть на ту же тему? | LEDE: Одним из г] (ru: Сан…
      Одним из героев, благодаря которому удалось посадить рейс Flydubai, стал сантехник Янив Хаюн. Он сумел войти в кабину пилотов, сел за штурвал, потянул его на себя и вывел самолет из пике. Только после этого управление ла…
  - (2026-10-04) Российские военные второй раз за два дня атаковали Северный мост в Киеве | LEDE: Российские военные утром 4 октября нанесли удар по Северному мосту в Киеве, сообщил мэр города Виталий Кличко] (ru: Рос…
      Российские военные утром 4 октября нанесли удар по Северному мосту в Киеве, сообщил мэр города Виталий Кличко.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 291 new of 514 total
  - (2026-10-04) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-03) [FIRMS] thermal anomaly 44.301, 28.254 (FRP 22.1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-03 1121Z, FRP 22.1 MW
  - (2026-10-03) [FIRMS] thermal anomaly 44.034, 23.899 (FRP 3.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-03 1121Z, FRP 3.15 MW
  - (2026-10-03) [FIRMS] thermal anomaly 44.038, 23.898 (FRP 13.32 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-03 1121Z, FRP 13.32 MW
  - (2026-10-03) [FIRMS] thermal anomaly 44.205, 24.611 (FRP 3.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-03 1121Z, FRP 3.73 MW
  - (2026-10-03) [FIRMS] thermal anomaly 44.029, 23.423 (FRP 4.48 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-03 1121Z, FRP 4.48 MW

### Chinese Internal News — 189 new of 230 total
  - (2026-10-04) 泉州南少林 禅武传千年（足迹·武侠胜境） - 人民网-福建频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1mal9Pa2ZITDBWLUhycDRvWWJJM0E2Ujh3MDZkZ1VJeVl2NldMSFdRNzUwMUdfem5YVEJnU3hsa2JYVTdZSW1BbjF3TmN] (zh:…
      泉州南少林 禅武传千年（足迹·武侠胜境） 人民网-福建频道
  - (2026-10-03) 活力中国 和美假期（新时代画卷） - pic.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTFBCRF9TazZWeGNvWHd1T2lTS3BSeFVMelgxTmx5a003cXhId0h5bGVRUTNhNFpQMkhhemljZmxlN21hVmZqVG02dU] (zh:…
      活力中国 和美假期（新时代画卷） pic.people.com.cn
  - (2026-10-03) 河南： 焦济洛平高铁洛阳黄河公铁大桥加紧施工 - vip.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1aNWRZQmx2OVdQdzhJbTNyNEU3dUZqOWdYYUNqWkJOYTJ6bUVSaWQxWllZdEp2WUJsTHlTM0h2RFBISTRl] (zh:…
      河南： 焦济洛平高铁洛阳黄河公铁大桥加紧施工 vip.people.com.cn
  - (2026-10-04) 四川稻城： 亚丁风光壮丽 - vip.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFBvc09kM3JXblJoa19NZDAydVlzTERqcHY5TktMdkZzUzVlOUZGSEw1NFl1OWxuV21IdGFOanRrWDZCWk44djh1b242cm] (zh:…
      四川稻城： 亚丁风光壮丽 vip.people.com.cn
  - (2026-10-03) 青山不负，江源向新 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9MTkJsNDZ0ekRqa1k1M216RDY3aGRPVUk5SnIwaEhyYlREbDZrdDl4X251dmlvaVREa3g2VUM0d1IzQ0pzSkZoSmMzOUFJWG9CRkt4bW9GaXN] (zh:…
      青山不负，江源向新 人民网
  - (2026-10-04) 家国同庆 畅享美好生活 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5oNk5yNUVhU2Y3bkZwQ0szTmx6UFY0elV3TTdrTG9fZDRSQ191cTJ0MmNlMV90aWJiNEFRWmpYaUN0STNGOG9OSVkwZmRaaWI1S3ZzMlVXN] (zh:…
      家国同庆 畅享美好生活 人民网

### Local News: St. Louis + Atlanta — 120 new of 209 total
  - (2026-10-03) [St. Louis] Three Rust Belt cities to visit via nonstop flights from St. Louis
      Pittsburgh, Pennsylvania Once a steel and manufacturing powerhouse, Pittsburgh shaped the industrial age but faced decline as factories closed in the late 20th century. Today, the city has reinvented itself with vibrant…
  - (2026-10-03) [St. Louis] Sylvie Dee’s now open in Clayton
      Just over two years after debuting in Webster Groves—and a little more than a year after expanding to City Foundry STL—Sylvie Dee’s continues to grow. Sylvie Dee’s Clayton location, located at 8115 Maryland, the longtime…
  - (2026-10-04) [St. Louis] 'Jane Doe' solidarity posts flood social media after Cornell rape lawsuit
      The outcry reminds many of the energy at the heights of the #MeToo movement, which exploded a decade ago.
  - (2026-10-04) [St. Louis] Georgia man fakes medical emergency to avoid paying Red Lobster bill, police allege
      After finishing his meal, the man allegedly called 911 and reported he was having a medical emergency, according to a report in TMZ.
  - (2026-10-04) [St. Louis] 20-year-old motorcyclist killed in Jefferson County crash
      A 20-year-old motorcyclist was killed in a crash Saturday night on Route 30 in Cedar Hill, according to the Missouri State Highway Patrol.
  - (2026-10-04) [St. Louis] Nolo becomes a Category 3 Hurricane in the remote Pacific Ocean
      Nolo strengthened into a major hurricane Saturday in the remote Pacific Ocean, far to the west of Hawaii's main islands.

### U.S. Weather + Severe / Climate Outlooks — 118 new of 120 total
  - (2026-10-04) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-04) [Severe] Special Marine Warning: Special Marine Warning issued October 4 at 8:46AM EDT until October 4 at 10:15AM EDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Apalachee Bay or Coastal Waters From Keaton Beach to Ochlockonee River Fl out to 20 Nm... Coastal Waters From Ochlockonee Ri…
  - (2026-10-04) [Severe] Special Marine Warning: Special Marine Warning issued October 4 at 7:42AM CDT until October 4 at 8:45AM CDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Coastal waters from Okaloosa-Walton County Line to Mexico Beach out 20 NM... * Until 845 AM CDT. * At 742 AM CDT, a severe t…
  - (2026-10-04) [Severe] Flash Flood Warning: Flash Flood Warning issued October 4 at 8:38AM EDT until October 4 at 11:45AM EDT by NWS Tallahassee FL
      FFWTAE The National Weather Service in Tallahassee has issued a * Flash Flood Warning for... West Central Bay County in the panhandle of Florida... Southwestern Walton County in the panhandle of Florida... * Until 1045 A…
  - (2026-10-04) [Severe] Special Marine Warning: Special Marine Warning issued October 4 at 7:30AM CDT until October 4 at 9:00AM CDT by NWS Mobile AL
      SMWMOB The National Weather Service in Mobile has issued a * Special Marine Warning for... Coastal waters from Okaloosa-Walton County Line to Pensacola FL out 20 NM... * Until 900 AM CDT. * At 730 AM CDT, a strong thunde…
  - (2026-10-04) [Moderate] Special Weather Statement: Special Weather Statement issued October 4 at 10:19PM ChST by NWS Tiyan GU
      UPDATED to raise the development potential of 94W to HIGH. ...HEAVY SHOWERS, GUSTY WINDS, AND CHOPPY SEAS LIKELY THIS WEEK FOR KWAJALEIN AND NORTHERN MARSHALL ISLANDS... A developing disturbance known as Invest 94W by th…

### State-Level News — 95 new of 416 total
  - (2026-10-04) [Connecticut] Where exactly is Canaan, Conn.? There are at least two answers
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/07/northcanaan-canaan-0721-0715-SG-09-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decodin…
  - (2026-10-04) [Connecticut] Your next car will be a luxury
      <img width="799" height="533" src="https://ctmirror.org/wp-content/uploads/2026/10/new-mta-cars.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="http…
  - (2026-10-04) [Arkansas] After botched execution of Christa Pike, Tennessee correction chief steps down
      Tennessee Department of Correction Commissioner Frank Strada will step down, Gov. Bill Lee announced Saturday — three days after a botched execution attempt left Christa Pike on a ventilator in critical condition. Strada…
  - (2026-10-04) [Arkansas] Federal funds for local police enforcement accelerated Trump immigration crackdown
      WASHINGTON — This summer, arrests of immigrants in the United States soared to the highest levels since President Donald Trump returned to office. An unprecedented increase in cooperation between local and state law enfo…
  - (2026-10-04) [Arkansas] Republicans can’t stop talking about banning trans athletes
      This story was originally reported by Brooke Migdon of The 19th. Meet Brooke and read more of their reporting on gender, politics and policy. Speaking to a crowd of supporters in central Florida in August, U.S. Rep. Byro…
  - (2026-10-04) [Arkansas] After states sue, Trump administration walks away from disability rights enforcement
      A court battle that began when conservative-led states sued to block protections for transgender people has ended in a rollback of protections for people with disabilities — a result disability advocates have feared for…

### Ukrainian Internal News (national + local Kyiv) — 59 new of 133 total
  - (2026-10-04) ЗМІ: Польща і Румунія відмовилися надати транзит для експорту українського зерна | LEDE: ] (uk: ЗМІ: Польща і Румунія відмовилися надати транзит для експорту українського зерна)
  - (2026-10-04) Медведєв пригрозив знищенням супутників Starlink | LEDE: Дмитро Медведєв заявив, що атака на російське угруповання "Рассвет" може призвести до знищення супутників Starlink та "космічної війни".] (uk:…
      Дмитро Медведєв заявив, що атака на російське угруповання "Рассвет" може призвести до знищення супутників Starlink та "космічної війни".
  - (2026-10-04) Мирний план Гончаренка: як зупинити війну крок за кроком | LEDE: Олексій Гончаренко пропонує шлях малих домовленостей для деескалації війни з Росією та збереження життя українців. Аналізує ролі] (uk:…
      Олексій Гончаренко пропонує шлях малих домовленостей для деескалації війни з Росією та збереження життя українців. Аналізує ролі гарантів та ключові умови.
  - (2026-10-04) Зеленський: У Києві встановили 12 турелей проти реактивних дронів | LEDE: У столиці з'явилися автоматичні бойові турелі для протидії реактивним безпілотникам, ще 8 модулів встановлять у Київськ] (uk:…
      У столиці з'явилися автоматичні бойові турелі для протидії реактивним безпілотникам, ще 8 модулів встановлять у Київській області.
  - (2026-10-04) ЗМІ: Мерц у Києві наполягатиме, щоб Україна провела реформи | LEDE: ] (uk: ЗМІ: Мерц у Києві наполягатиме, щоб Україна провела реформи)
  - (2026-10-04) Німеччина надає Україні новий пакет підтримки на понад 1,3 млрд євро | LEDE: Пакет від Німеччини включає зброю, підтримку енергетики та перехоплювачі для захисту від «Шахедів». 350 млн євро спр] (uk:…
      Пакет від Німеччини включає зброю, підтримку енергетики та перехоплювачі для захисту від «Шахедів». 350 млн євро спрямують на енергетику.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 25 new of 27 total
  - (2026-10-04) CFC3455 (Canada)
      icao24: c2c36d · position: (48.9746, -62.7081) · alt: 11277m · 960km/h
  - (2026-10-04) JAF1BH (Belgium)
      icao24: 44d1ba · position: (50.9403, 4.601) · alt: 716m · 357km/h
  - (2026-10-04) JAF2LG (Belgium)
      icao24: 44d1a6 · position: (45.0154, -3.6562) · alt: 11887m · 833km/h
  - (2026-10-04) JAF85C (Belgium)
      icao24: 44d1a5 · position: (44.4723, 16.29) · alt: 11277m · 853km/h
  - (2026-10-04) JAF95N (Belgium)
      icao24: 44d1b3 · position: (43.8805, -8.4399) · alt: 11277m · 864km/h
  - (2026-10-04) JAF6JG (Belgium)
      icao24: 44d1b4 · position: (50.8992, 4.4568) · on ground · 2km/h

### USGS earthquakes (M4.5+, past day) — 19 new of 19 total
  - (2026-10-03) M 5.9 - 39 km WSW of Tambolaka, Indonesia
      M5.9 · 39 km WSW of Tambolaka, Indonesia · depth 45.951 km
  - (2026-10-04) M 5.5 - Volcano Islands, Japan region
      M5.5 · Volcano Islands, Japan region · depth 10 km
  - (2026-10-03) M 5.3 - 81 km SSW of Banda Aceh, Indonesia
      M5.3 · 81 km SSW of Banda Aceh, Indonesia · depth 56.274 km
  - (2026-10-03) M 5.1 - 182 km SSE of Vilyuchinsk, Russia
      M5.1 · 182 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-10-04) M 5.0 - 21 km ESE of Feke, Turkey
      M5.0 · 21 km ESE of Feke, Turkey · depth 10 km
  - (2026-10-04) M 5.0 - 37 km N of Ruteng, Indonesia
      M5.0 · 37 km N of Ruteng, Indonesia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-10-04) LoL: Team WE vs HANJIN BRION - Game 1 Winner
      yes price: 100% · 24h volume: $1,196,780 · resolves 2026-10-04
  - (2026-10-04) China Open: Alexander Zverev vs Novak Djokovic
      yes price: 78% · 24h volume: $1,046,177 · resolves 2026-10-11
  - (2026-10-04) Valorant: FUT Esports vs T1 (BO3) - VCT Champions Group A
      yes price: 34% · 24h volume: $970,231 · resolves 2026-10-04
  - (2026-10-04) LoL: Team WE vs HANJIN BRION (BO3) - Demacia Cup Global Invitational Group Stage
      yes price: 68% · 24h volume: $864,911 · resolves 2026-10-04
  - (2026-10-04) LoL: Team WE vs HANJIN BRION - Game 2 Winner
      yes price: 0% · 24h volume: $829,053 · resolves 2026-10-04
  - (2026-10-04) Counter-Strike: Team Falcons vs Aurora Gaming (BO3) - ESL Pro League Group Stage
      yes price: 82% · 24h volume: $787,788 · resolves 2026-10-04

### IT, InfoSys & cybersecurity news (last 7 days) — 16 new of 51 total
  - (2026-10-04) [BleepingComputer] Anthropic asks Claude users to share voice data for AI model training
      Anthropic has started asking Claude users to voluntarily share their voice conversations to help train and improve its AI models. [...]
  - (2026-10-04) [The Hacker News] ShinyHunters Suspect Rey Reportedly Detained in Jordan, Helping FBI Identify Group Members
      A suspected member of the ShinyHunters digital extortion group, who goes by the online alias "Rey," has been allegedly detained by authorities in Jordan, Reuters reported, citing three people familiar with the matter. Re…
  - (2026-10-04) [The Hacker News] China-Aligned TA419 Targets U.S. AI Policy Experts With Microsoft AitM Phishing
      A new China-nexus cyber espionage group known as TA419 has been attributed to multiple credential phishing campaigns targeting artificial intelligence (AI) experts working for U.S. think tanks, universities, and legal se…
  - (2026-10-04) [Ars Technica] All hail electrification. But let’s talk about the hard part.
      The IEA and climate negotiators want to set a target for shifting the economy to run on electricity.
  - (2026-10-03) [BleepingComputer] Google Gemini could soon get full access to your Mac’s files, apps and the web
      Google's Gemini could soon access any file on your macOS device, open apps, browse the web, and perform actions without asking for permission every time. [...]
  - (2026-10-03) [BleepingComputer] ShinyHunters hacker reportedly detained in Jordan, aiding FBI
      A suspected ShinyHunters hacking group member known online as "Rey" has reportedly been detained in Jordan and is cooperating with the FBI to help locate other members of the extortion group. [...]

### Paper Trading Scorecard — 10 new of 118 total
  - (2026-10-04) [Polymarket] Will US unemployment reach at least 6.0% in 2026?
      This market will resolve to “Yes” if any seasonally adjusted unemployment rate (total unemployed, as a percent of the civilian labor force, official unemployment rate denoted as U-3) reported by the Bureau of Labor Stati…
  - (2026-10-04) [Manifold] Will the U.S. government appeal the Flock license-plate suppression ruling in United States v. Kyle?
  - (2026-10-04) [Manifold] Will Billy Strings make a surprise appearance at Hardly Strictly Bluegrass on Sunday, October 4, 2026?
  - (2026-10-04) [Manifold] Will jatloe's OTIS diamond be solved legitimately by a second OTIS user by the end of 2026?
  - (2026-10-04) [Manifold] By Dec 31, 2035, will any nuclear fusion power plant have delivered at least 100 MW of net electrical power, 30 day ave.
  - (2026-10-04) [Manifold] Daily Coinflip

### Court opinions of consequence (federal & state) — 7 new of 60 total
  - (2026-10-01) D.C. Court of Appeals: 2461 Corporation T/A Madam's Organ v. District of Columbia Alcoholic Beverage and Cannabis Board
  - (2026-10-01) D.C. Court of Appeals: Euceda v. United States
  - (2026-10-01) D.C. Court of Appeals: In re Socci
  - (2026-10-01) Delaware Supreme Court: Kalima v. State
  - (2026-10-01) Delaware Supreme Court: Gemini Insurance Company v. Bausch & Lomb Americas, Inc.
  - (2026-10-01) Delaware Supreme Court: Natalie Ayers v. Travelers Casualty Insurance Company

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-04) [Marginal Revolution] Does Costco Cause Cancer?
      In December 2025, researchers led by Yazan Alwadi at Harvard’s T.H. Chan School of Public Health published a paper in Environmental Health that claimed to find that cancer incidence increased for people living closer to…
  - (2026-10-04) [Marginal Revolution] Marital sorting by class and race
      Americans rarely marry outside their race or class group, a pattern with well-documented implications for inequality and intergenerational mobility. Limited exposure may partly explain these low intergroup marriage rates…
  - (2026-10-04) [Marginal Revolution] Do the elderly prefer robotic care?
      The Japanese elderly, to be clear: Population aging and shortages of long-term care workers have increased interest in care-giving robots and information and communication technology (ICT). This paper provides novel larg…

### Government Action: Sanctions + Procurement + Foreign Agents — 2 new of 122 total
  - (2026-10-03) [OFAC] Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] 701 - Office of Foreign Assets Control (.gov)
      701 Office of Foreign Assets Control (.gov)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-04) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=24, 14d-median=20; carrying terms: proposed, certain, state, regulatory, procedures, final, action, program, provide, office, information, proposes
- state_bills: today=61, 7d-median=75, 14d-median=106; carrying terms: eligible, including, programs, provide, defined, reporting, medical, relating, certain, existing, generally, insurance
- state_news: today=416, 7d-median=698, 14d-median=604; carrying terms: organizations, columbia, three, clean, largest, louisiana, inside, recent, toomanyredirects, decades, attorney, women
- local_news: today=209, 7d-median=225, 14d-median=225; carrying terms: three, arrested, woman, games, suspect, stlmag, against, public, accused, culture, class, target
- foreign_news: today=947, 7d-median=1018, 14d-median=1012; carrying terms: route, together, owner, three, caused, shift, worth, topnews, australian, recent, decades, httperror
- chinese_internal: today=230, 7d-median=267, 14d-median=269; carrying terms: cbmiy, cbmiakfvx, title, china, cbmickfvx, target, cbmidefvx, cbmigwfbvv, lxtfa, cbmiaefvx, cbmix, cbmizefvx
- russian_internal: today=883, 7d-median=1022, 14d-median=1022; carrying terms: istories, openai, laquo, target, server, error, telegram, httperror, russian, https, europe, reuters
- ukrainian_internal: today=133, 7d-median=131, 14d-median=131; carrying terms: three, zelensky, chief, httperror, russian, pressure, support, europe, region, early, foreign, since
- ukraine_theater: today=514, 7d-median=564, 14d-median=487; carrying terms: quzljz, wjhsr, mxrudhc, bpamvqdutnoeo, active, cbmimgfbvv, vxkwwmntudfcqtlulvfuy, kmfldz, dldwzjsm, beskrestnov, coverage, xzvlutntmejfshzxvv
- paper_bets: today=118, 7d-median=122, 14d-median=123; carrying terms: achieved, governor, minnesota, openai, romania, decrease, zohran, fusion, problem, nominal, become, seats
- weather: today=120, 7d-median=144, 14d-median=144; carrying terms: areas, including, upper, especially, eastern, southwest, details, afdlsx, creeks, seattle, creek, currents
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: pcepilfe, labor, nonfarm, implied, unrate, inflation, openings, rates, indicator, balance, treasury, assets
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, russell, crypto, china, rates, treasury, commodities, close, proxy, crude, nasdaq, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=122, 7d-median=117, 14d-median=106; carrying terms: armed, areas, serious, threatening, programs, eastern, active, qaida, certain, involvement, specific, laboratory
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, quiver, https, error, quiverquant, client, congresstrading, quantitative, unauthorized
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: corporation, supreme, court, appeals, state, company, international, connecticut, security, board, delaware, homeland
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, holdings, financial, group, richard, therapeutics, michael, scott, robert
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, johnson, receipts, jonathan, raised, ocasio, robert, ossoff, warner, trone, committee, david
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, japan, china
- gdelt_gkg: today=0, 7d-median=49, 14d-median=50; carrying terms: english, trump, sanctions, ukraine, perimeter, chinese, spanish, russian, russia, themes, german, vietnamese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=27, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, france, canada, kingdom, samuidf, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: challenge, infant, chikv, algeria, areas, including, dignified, cereulide, confirmation, ventilation, active, occur
- cisa_kev: today=17, 7d-median=18, 14d-median=18; carrying terms: products, traversal, bounds, check, vulnerability, write, incorrect, authorization, cisco, injection, overflow, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=19, 7d-median=16, 14d-median=16; carrying terms: depth, indonesia, islands, south, japan, philippines, region, guinea, russia, papua, ruteng, sandwich
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, championship, donetsk, league, shakhtar, champions, group, strike, counter, october
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, revolution, marginal, https, conversableeconomist, economist, class, basic, markets, economic, published, economy
- tech_news: today=51, 7d-median=57, 14d-median=57; carrying terms: going, openai, weekly, spectrum, surveillance, https, exploitation, cybersecurity, government, critical, technica, schneier
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: kathy, delauro, cisneros, castor, angela, brett, hickenlooper, pettersen, george, aaron, cindy, mccormick
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, either, converges, markets, claude, paper, placement, unavailable, decision, today, module, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board requests public comment on two proposals related to establishing a regulatory framework for Board-supervised payment stablecoin issuers under the GENIUS Act
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.
- [2026-09-28] Fed speeches: Cook, An Update on AI and the Economy
- [2026-09-29] ECB press: ECB amends monetary policy implementation guidelines as part of regular review
- [2026-09-29] Fed speeches: Bowman, Opening Remarks
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-29] Fed press (events + announcements): Agencies publish resolution plan feedback letters for 15 banking organizations
- [2026-09-30] ECB press: Frank Elderson: Supervisory risk appetite, efficiency and effectiveness
- [2026-09-30] Fed press (events + announcements): Federal Reserve Board finalizes changes to enhance the transparency and public accountability of its stress test and reduce volatility in its stress test-related capital requirements
- [2026-09-30] ECB press: Isabel Schnabel: Monetary policy in a world of overlapping shocks
- [2026-09-30] ECB press: Christine Lagarde: Interview with La Croix
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] ECB press: Christine Lagarde: Where AI risks meet
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*