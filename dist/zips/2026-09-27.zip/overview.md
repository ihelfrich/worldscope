# WORLDSCOPE morning brief — 2026-09-27

## Headline
2515 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (691) · Russian Internal News (state + in-exile) (550) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (190) · Chinese Internal News (157) · U.S. Weather + Severe / Climate Outlooks (116) · State-Level News (113) · Local News: St. Louis + Atlanta (111) · Ukrainian Internal News (national + local Kyiv) (48) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (30) · GDELT GKG — themes / entities / watch areas (25)

## What changed today
### International News + Multilateral Institutions — 691 new of 979 total
  - (2026-09-27) [Global] Floods and landslides kill at least 56 people in India, 12 in Nepal
      Authorities report increasing death toll over three days as rivers rise above danger levels in parts of both countries.
  - (2026-09-27) [Global] ‘No role for UNRWA in Gaza’: Does the Board of Peace toe Israeli lines?
      Board of Peace excludes UNRWA from Gaza, aligning with repeated Israeli calls to sideline the refugee aid agency.
  - (2026-09-27) [Global] ‘My hands are empty’: Displaced Palestinians struggle to survive
      In Tulkarem and other West Bank cities, displaced Palestinians are being forced deeper into debt and poverty.
  - (2026-09-27) [Global] Israeli minister Bezalel Smotrich calls for war in occupied West Bank
      Comments come as Israeli authorities announce military closure across occupied West Bank, citing Jewish holiday Sukkot.
  - (2026-09-27) [Global] Yemen government forces widen attacks against Houthis: What we know
      Yemeni government forces claim multiple air and ground operations across Taiz in 24 hours.
  - (2026-09-27) [Global] Plane carrying DR Congo military delegation crashes
      A plane carrying a Congolese military delegation crashed in DR Congo, killing 17 people, including four civilians.

### Russian Internal News (state + in-exile) — 550 new of 864 total
  - (2026-09-27) В Москве напали на активистку Варвару Кошелеву (она была главой штаба кандидатки от «Яблока»). Избившие ее мужчины представились участниками войны | LEDE: В Москве напали на Варвару Кошелеву] (ru: В М…
      В Москве напали на Варвару Кошелеву — активистку и бывшую главу штаба Анны Шатуновской-Бюрно, которая шла на выборы в Госдуму от «Яблока» по одномандатному округу.
  - (2026-09-27) Война. 1677-й день. Европа готовит население к чрезвычайным ситуациям. Глава МИД Германии после встречи с Лавровым убедился, что Россия не готова прекратить войну | LEDE: «Медуза» с 24 февра] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-27) В Кремле назвали предоставление Starlink для ударов по целям в глубине России «пагубным, потенциально опасным и опрометчивым шагом» | LEDE: Предоставление данных Starlink для ударов вглубь Р] (ru: В К…
      Предоставление данных Starlink для ударов вглубь России было бы «очень пагубным, потенциально опасным и опрометчивым шагом», заявил пресс-секретарь Кремля Дмитрий Песков корреспонденту «Вестей» Павлу Зарубину.
  - (2026-09-27) В Великобритании эвакуировали жителей деревни рядом с авиабазой, где размещены истребители США — из-за «инцидента», связанного со взрывчатыми веществами | LEDE: В одном из районов графства Г] (ru: В В…
      В одном из районов графства Глостершир на юго-западе Англии объявили чрезвычайную ситуацию и эвакуировали жителей местной деревни.
  - (2026-09-27) The Washington Post: США и Россия исключили из проекта соглашения по ИИ-оружию пункт о проверке целей человеком | LEDE: США и Россия вычеркнули из соглашения по применению смертоносных автон] (ru: The…
      США и Россия вычеркнули из соглашения по применению смертоносных автономных систем вооружения пункт о проверке человеком целей, назначенных ИИ для удара, рассказали три источника The Washington Post.
  - (2026-09-27) Чихать приятно. Но как остановиться, если ну никак нельзя? Если вы умеете сдерживать чих, расскажите нам как — и спасите других читателей! | LEDE: Способность чихать развилась у нас не прост] (ru: Чих…
      Способность чихать развилась у нас не просто так: она помогает избавиться от посторонних частиц, которые оказались в носу. Но кроме пользы у чихания есть еще одно свойство — нередко людям просто приятно это делать. Правд…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 190 new of 379 total
  - (2026-09-26) [FIRMS] thermal anomaly 48.586, 22.245 (FRP 0.36 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-26 0028Z, FRP 0.36 MW
  - (2026-09-26) [FIRMS] thermal anomaly 48.583, 22.244 (FRP 1.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-26 0028Z, FRP 1.08 MW
  - (2026-09-26) [FIRMS] thermal anomaly 46.433, 30.097 (FRP 1.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-26 0028Z, FRP 1.03 MW
  - (2026-09-26) [FIRMS] thermal anomaly 46.432, 30.102 (FRP 1.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-26 0028Z, FRP 1.03 MW
  - (2026-09-26) [FIRMS] thermal anomaly 44.774, 33.863 (FRP 0.94 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-26 0028Z, FRP 0.94 MW
  - (2026-09-26) [FIRMS] thermal anomaly 45.257, 31.673 (FRP 5.2 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-26 0028Z, FRP 5.2 MW

### Chinese Internal News — 157 new of 237 total
  - (2026-09-26) 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFA3Y3lvU2lETFNtRzUzOVJnZW5lTmoyTEp3bnFHWGZBSGl4Mmt2YWZtWlBRRjJlRGFfb2YtSzRRaG9IUnZfMDVyRHFwWXBnMEQwV2Y5dDQyVThVbkV] (zh:…
      商品详情 财新商城
  - (2026-09-26) 火线评论｜中美元首华盛顿会谈的启示：重温历史感召 共应未来变局 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1zd1MxRHJ3cW5uYUcybk5DeUo1dnhsMDRmakRDVXFQblBqaGhualZ5WlJ4R3U1b3NjM0JBWUw0eF9LRlIzNXo3aG] (zh:…
      火线评论｜中美元首华盛顿会谈的启示：重温历史感召 共应未来变局 财新
  - (2026-09-27) 财新闻｜新一轮购车补贴来了，多地放大招 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE0wNVU1Uzc2czQwQ0FxcTQxaTZxXzh4TXlBZDRCMTJwS2VTLTQzNVJwR2xxMmhUdmloQzZXS1h5WEhVNFQzRmZHYW9taDR6RUtIRn] (zh:…
      财新闻｜新一轮购车补贴来了，多地放大招 财新
  - (2026-09-27) 坐着轮椅看世界：长春独行三日｜纪行 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBINDFsNEJITEhsSjVaa2Z2ZFJNeUJIN21heV9XZzBRcXB2ek95MDdGMHRacGUyV3U4VV9CV2FTSzlLWGx0S1FVaW1RbE41bXJyeWI5] (zh:…
      坐着轮椅看世界：长春独行三日｜纪行 财新
  - (2026-09-27) 数理化“铁三角”论诗｜燕南园往事④ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBCQnQ3SWZLNHFGZE1WOWpDVkttanRnUHJLajNCOWNfbjhNajZVeDlJeUd1VExJblctMzJ5R21oRGhxcWQzdzFBQlp5OWZYZVFTZmpr] (zh:…
      数理化“铁三角”论诗｜燕南园往事④ 财新
  - (2026-09-27) 最新封面报道｜汽车大整合“破冰” - weekly.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9wanJlWWlLa05QQjNrUU1uNFZfakZOVFpxZkxPdXpUei1zeUFJWEY3cXdqVVY0QkthVXlkeXNtaG5KM1RSOEhqVz] (zh:…
      最新封面报道｜汽车大整合“破冰” weekly.caixin.com

### U.S. Weather + Severe / Climate Outlooks — 116 new of 117 total
  - (2026-09-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-27) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 27 at 7:28AM CDT until September 27 at 11:00AM CDT by NWS Wichita KS
      * WHAT...Visibility one-quarter mile or less in dense fog. * WHERE...Barton and Russell Counties. * WHEN...Until 11 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-09-27) [Moderate] Special Weather Statement: Special Weather Statement issued September 27 at 7:08AM CDT by NWS Chicago IL
      Locally dense fog will reduce visibilities down to one quarter mile or less early this morning over portions of northeast Illinois and northwest Indiana, mainly outside of Chicago. Fog will gradually erode through mid-mo…
  - (2026-09-27) [Moderate] Special Weather Statement: Special Weather Statement issued September 27 at 8:07AM EDT by NWS Grand Rapids MI
      Fog will reduce visibilities to less than a half mile along and south of a Battle Creek to Lansing line. A few locations will experience rapid visibility drops to less than a quarter mile. Remain alert to rapidly fluctua…
  - (2026-09-27) [Moderate] Special Weather Statement: Special Weather Statement issued September 27 at 7:04AM CDT by NWS Chicago IL
      Locally dense fog will reduce visibilities down to one quarter mile or less early this morning over portions of northeast Illinois and northwets Indiana outside of Chicago. Fog will gradually erode through mid-morning. I…
  - (2026-09-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued September 27 at 4:52AM PDT until September 28 at 5:00AM PDT by NWS San Diego CA
      * WHAT...For the Beach Hazards Statement, minor tidal overflow expected due to the combination of high tides and elevated surf. For the Coastal Flood Advisory, minor coastal flooding expected due to the combination of hi…

### State-Level News — 113 new of 367 total
  - (2026-09-27) [California] Governor Newsom signs legislation protecting the LGBTQ community, pushing back on attacks by the Trump administration
      Source
  - (2026-09-26) [California] Governor Newsom signs new bills to further prevent gun violence and strengthen California’s gun safety leadership
      Source
  - (2026-09-26) [Alaska] Hunting and Fishing Day 2026
      WHEREAS, Alaska is blessed with a diversity of wildlife and wide-ranging landscapes that offer bountiful resources; and WHEREAS, the heritage of big game hunting and sport fishing are essential to the State’s economic an…
  - (2026-09-26) [Alaska] Blue Star Welcome Week 2026
      WHEREAS, Blue Star Families seeks to empower military families by connecting them with their neighbors, individuals and organizations to cultivate vibrant communities of mutual support; and WHEREAS, we recognize the 600,…
  - (2026-09-27) [Connecticut] They served their time in prison. Then the bills arrived.
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/09/PRISON-TRACY-0924-SG-06-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…
  - (2026-09-27) [Connecticut] The Vernon grumble over rumble/mumble
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/09/Centerline_Rumble_Strip-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loadin…

### Local News: St. Louis + Atlanta — 111 new of 205 total
  - (2026-09-27) [St. Louis] Two giant pandas—Ping Ping and Fu Shuang—arrive in Atlanta on loan from China
      Ping Ping (male), whose name means "peace," and Fu Shuang (female), whose name means "double blessing," will live at Zoo Atlanta on loan from China for 10 years.
  - (2026-09-27) [St. Louis] 81-year-old High Ridge man found safe
      The Jefferson County Sheriff's Office said the man was found safe Saturday.
  - (2026-09-27) [St. Louis] Explosives-related arrests near air base used by US being probed by UK counterterror police
      British counterterrorism police have taken over an investigation into the arrest of several men suspected of explosives offenses near a Royal Air Force base.
  - (2026-09-27) [St. Louis] Did anyone win the $360M Powerball? Here are winning numbers for Saturday, Sept. 26
      The lump sum value of Saturday's jackpot was $149.8 million before taxes.
  - (2026-09-27) [St. Louis] Two moms lost their sons at this Cahokia Heights intersection in 2024. Now, another teen is dead
      Two moms who lost their sons in a 2024 crash at State Route 15 and Pocket Road returned to the site to pick up the pieces after another deadly wreck.
  - (2026-09-27) [St. Louis] Hurricane Nolo skirts Hawaii but could still unleash powerful winds and flash flooding
      Weather officials said the storm still posed a risk for flash floods, dangerous winds and extreme surf in areas recovering from previous storms.

### Ukrainian Internal News (national + local Kyiv) — 48 new of 109 total
  - (2026-09-27) Швейцарці відхиляють ініціативу щодо суворого визначення нейтралітету – попередні результати | LEDE: ] (uk: Швейцарці відхиляють ініціативу щодо суворого визначення нейтралітету – попередн)
  - (2026-09-27) ОВА показала операцію з доставки 4 тисяч кг продуктів в окуповані Олешки | LEDE: В Олешки на Херсонщині безпілотниками переправили 4 тис. кг продуктів на 100 локацій. У місті залишаються близьк] (uk:…
      В Олешки на Херсонщині безпілотниками переправили 4 тис. кг продуктів на 100 локацій. У місті залишаються близько 2 тисяч людей – ОВА.
  - (2026-09-27) Токаєв звільнив міністра оборони Казахстану після загибелі 14 військових на навчаннях | LEDE: Касим-Жомарт Токаєв відправив Даурена Косанова у відставку через загибель 14 військових на навчання] (uk:…
      Касим-Жомарт Токаєв відправив Даурена Косанова у відставку через загибель 14 військових на навчаннях. Новим міністром призначено Айдоса Мирзахметова.
  - (2026-09-27) Біля молдовського села знайшли уламки безпілотника | LEDE: Прикордонна поліція Молдови знайшла уламки дрона у Штефан-Водському районі. Вживають заходів і закликають повідомляти про підозрілі пр] (uk:…
      Прикордонна поліція Молдови знайшла уламки дрона у Штефан-Водському районі. Вживають заходів і закликають повідомляти про підозрілі предмети.
  - (2026-09-27) Закриття аеропорту Сицилії, спричинене попелом з вулкана, продовжили до кінця неділі | LEDE: ] (uk: Закриття аеропорту Сицилії, спричинене попелом з вулкана, продовжили до кінця не)
  - (2026-09-27) На Київщині через російську атаку загинула людина, ще четверо постраждали | LEDE: Унаслідок російської атаки по Київській області 27 вересня загинула людина, ще чотири постраждали. Руйнування у] (uk:…
      Унаслідок російської атаки по Київській області 27 вересня загинула людина, ще чотири постраждали. Руйнування у Вишневому, Фастівському та Броварському районах.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-09-27) PAT22 (United States)
      icao24: ae74ac · position: (38.5952, -77.2632) · alt: 373m · 185km/h
  - (2026-09-27) JAF94H (Bulgaria)
      icao24: 4520aa · position: (33.5878, -8.1602) · alt: 11277m · 794km/h
  - (2026-09-27) PAT532 (United States)
      icao24: adfe8d · position: (35.8652, -88.8795) · alt: 5067m · 478km/h
  - (2026-09-27) KAF3216 (Kuwait)
      icao24: 7061f6 · position: (46.4408, 20.4869) · alt: 8534m · 567km/h
  - (2026-09-27) JAF6JG (Belgium)
      icao24: 44d1ba · position: (50.6432, 4.7868) · alt: 2994m · 556km/h
  - (2026-09-27) JAF85C (Belgium)
      icao24: 44d1a6 · position: (48.1027, 11.0822) · alt: 11277m · 859km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-09-27) [Israel-Iran-Hezbollah axis · themes] UK can defend Falklands militarily - defense secretary
      brazilsun.com · English · tone NA
  - (2026-09-27) [Israel-Iran-Hezbollah axis · themes] Multiple arrests on suspicion of explosives offenses near U . K . base used by U . S . forces
      kedm.org · English · tone NA
  - (2026-09-27) [Israel-Iran-Hezbollah axis · themes] Defence Secretary urges Britons to get in 9 items - as fuel supplies threatened and greater risk of war
      coventrytelegraph.net · English · tone NA
  - (2026-09-27) [Israel-Iran-Hezbollah axis · themes] Tödliche Badeunfälle auf Mallorca : Zwei deutsche Urlauber sterben
      merkur.de · German · tone NA
  - (2026-09-27) [Israel-Iran-Hezbollah axis · themes] Die Gemeinde Großerlach arbeitet Uranprobleme im Trinkwasser auf - Nachrichten aus dem Rems - Murr - Kreis
      zvw.de · German · tone NA
  - (2026-09-27) [Israel-Iran-Hezbollah axis · themes] A nova pesquisa Datafolha sobre Lula x Flávio Bolsonaro , a 3 dias da eleio
      cartacapital.com.br · Portuguese · tone NA

### Court opinions of consequence (federal & state) — 24 new of 60 total
  - (2026-09-21) U.S. Court of Appeals, 3rd Cir.: United States v. Duane Taylor
  - (2026-09-21) U.S. Court of Appeals, 2nd Cir.: In Re: IIG Structured Trade Fin. Fund, Ltd.
  - (2026-09-21) U.S. Court of Appeals, 2nd Cir.: Newton v. LVMH Moët Hennessy Louis Vuitton Inc.
  - (2026-09-21) Colorado Supreme Court: John Litterer v. Vail Summit Resorts, Inc., a corporation, and Dwight McClure.
  - (2026-09-18) U.S. Court of International Trade: United States v. Koehler Oberkirch GmbH
  - (2026-09-18) U.S. Court of Appeals, 3rd Cir.: Celebrity of Springfield LLC v. SBA

### State Legislative Action — 20 new of 120 total
  - (2026-09-27) [California AB 1836] California State Nonprofit Security Grant Program.
      Existing law establishes the California State Nonprofit Security Grant Program under the administration of the Director of Emergency Services to improve the physical security of nonprofit organizations that are at high r…
  - (2026-09-27) [California AB 31] Peace officers: tribal police.
      Existing law provides that any person who comes within the provisions of specified statutes and who otherwise meets all standards imposed by law on a peace officer is a peace officer, grants certain authority to those in…
  - (2026-09-27) [California AB 1685] Driving privilege: points.
      Existing law requires all records of the Department of Motor Vehicles relating to the registration of vehicles, other information contained on an application for a driver's license, abstracts of convictions, and certain…
  - (2026-09-27) [California AB 1769] Student transfer: tribal colleges.
      The Donahoe Higher Education Act establishes the California Community Colleges under the administration of the Board of Governors of the California Community Colleges, the California State University under the administra…
  - (2026-09-27) [California SB 1023] Health care coverage: antiretroviral drugs, drug devices, and drug products.
      Existing law, the Knox-Keene Health Care Service Plan Act of 1975, provides for the licensure and regulation of health care service plans by the Department of Managed Health Care and makes a willful violation of the act…
  - (2026-09-27) [California AB 1546] Vehicles: driving under the influence.
      Under existing law, if a person is convicted of either driving under the influence (DUI) of any alcoholic beverage or drug, or under the combined influence of any alcoholic beverage and drug or driving while having 0.08%…

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-09-26) M 5.6 - 74 km ESE of Kokopo, Papua New Guinea
      M5.6 · 74 km ESE of Kokopo, Papua New Guinea · depth 57.78 km
  - (2026-09-26) M 5.2 - 148 km NW of Kilmia, Yemen
      M5.2 · 148 km NW of Kilmia, Yemen · depth 10 km
  - (2026-09-27) M 5.1 - 90 km ENE of Tadine, New Caledonia
      M5.1 · 90 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-26) M 5.1 - 74 km ENE of Tadine, New Caledonia
      M5.1 · 74 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-27) M 5.0 - 61 km ENE of Tadine, New Caledonia
      M5.0 · 61 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-26) M 5.0 - 52 km NNW of Ruteng, Indonesia
      M5.0 · 52 km NNW of Ruteng, Indonesia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-09-27) Spread: Bills (-7.5)
      yes price: 48% · 24h volume: $1,118,069 · resolves 2026-09-27
  - (2026-09-27) Spread: Chiefs (-10.5)
      yes price: 46% · 24h volume: $1,072,158 · resolves 2026-09-27
  - (2026-09-27) Panthers vs. Browns: O/U 42.5
      yes price: 48% · 24h volume: $471,716 · resolves 2026-09-27
  - (2026-09-27) Panthers vs. Browns
      yes price: 55% · 24h volume: $431,102 · resolves 2026-09-27
  - (2026-09-27) Will Greece win on 2026-09-27?
      yes price: 12% · 24h volume: $424,985 · resolves 2026-09-27
  - (2026-09-27) Seahawks vs. Commanders
      yes price: 78% · 24h volume: $411,857 · resolves 2026-09-27

### Paper Trading Scorecard — 15 new of 118 total
  - (2026-09-27) [Kalshi] Derrick Henry Career Regular Season Rushing Yards
      Derrick Henry
  - (2026-09-27) [Kalshi] Mike Evans Career Regular Season Receiving Yards
      Mike Evans
  - (2026-09-27) [Kalshi] Josh Allen Career Regular Season Passing Yards
      Josh Allen
  - (2026-09-27) [Manifold] Will a16z have a dedicated AI safety fund before 2030?
  - (2026-09-27) [Manifold] Guillotines have a come back by 2030
  - (2026-09-27) [Manifold] Will Texas A&M have a post-season game this year?

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 52 total
  - (2026-09-27) [The Hacker News] Warning: Two Unpatched Citrix NetScaler RCE Zero-Days Under Active Exploitation
      Two new unpatched zero-day vulnerabilities in Citrix NetScaler ADC and NetScaler Gateway appliances that allow remote code execution are being actively exploited in the wild, security firm watchTowr said on September 26.…
  - (2026-09-27) [TechCrunch] PNOE’s new face mask wants to make lab-grade breath testing a self-serve affair
      PNOĒ, the Malden, Mass.-based startup whose breath-analyzing mask used to bear an unfortunate resemblance to Bane's, is launching a sleeker self-serve version on October 1 that lets gym-goers measure their VO₂ max and ot…
  - (2026-09-27) [TechCrunch] Google tests buying from Walmart-owned Flipkart through Gemini and AI Mode in India
      The limited test covers select products and users, with a broader rollout planned for later in October.
  - (2026-09-26) [BleepingComputer] ShinyHunters uses WAF bypass trick in Oracle PeopleSoft attacks
      The ShinyHunters extortion gang is using a URL-encoding trick to bypass web application firewall rules that mitigate the Oracle PeopleSoft CVE-2026-35273 flaw, allowing the threat actors to resume widespread exploitation…
  - (2026-09-26) [BleepingComputer] Claude Opus 5.5 uses 95% fewer em dashes, but its answers are getting longer
      Anthropic's Claude Opus 5.5 appears to be changing how it writes, with new analysis showing fewer obvious AI writing patterns, shorter sentences, and simpler wording compared with Opus 5. [...]
  - (2026-09-26) [BleepingComputer] Microsoft pauses KB5002907 update after Office license deactivations
      Microsoft has paused the rollout of the KB5002907 Microsoft 365 update after users report that it deactivated, or in some cases completely removed, perpetual Office 2016 and Office 2019 installations. [...]

### Government Action: Sanctions + Procurement + Foreign Agents — 10 new of 98 total
  - (2026-09-25) [OFAC] Recent Actions - Office of Foreign Assets Control (.gov)
      Recent Actions Office of Foreign Assets Control (.gov)
  - (2026-09-27) [USASpending] $41,519,790,022 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-09-27) [USASpending] $3,384,867,722 → AEROJET ROCKETDYNE OF DE, INC: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY T
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGF RS-25 PRODUCTION RESTART TO BE UNDERTAKEN BY THE CONTRACTOR IN SUPPORT OF PROVIDING SIX RS-25 ENGINES MODIFIED AS NECESSARY FOR THE TECHNIC…
  - (2026-09-27) [USASpending] $2,089,442,660 → BOLLINGER SHIPYARDS LOCKPORT, L.L.C.: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE U
      Agency: Department of Homeland Security. Description: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE UP TO TWENTY-SIX (26) FAST RESPONSE CUTTERS (FRCS) ON A FIRM FIXED PRICE (FFP) BASIS WITH AN ECONOMIC PRICE…
  - (2026-09-27) [USASpending] $1,795,059,878 → GENERAL DYNAMICS INFORMATION TECHNOLOGY, INC.: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
      Agency: Department of State. Description: GLOBAL SECURITY ENGINEERING&SUPPLY CHAIN SERVICES.
  - (2026-09-27) [USASpending] $1,426,735,812 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SOFTWARE LIFE CYCLE DEVELOPMENT
      Agency: General Services Administration. Description: SOFTWARE LIFE CYCLE DEVELOPMENT

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-27) [South Korea] 2 Pivotal Performances By Song Kang And Lee Jun Young In Four Hands , Two Sonatas
      soompi.com · English
  - (2026-09-27) [South Korea] Soompi K - Pop Music Chart 2026 , September Week 4
      soompi.com · English
  - (2026-09-27) [South Korea] Breaking the Eye - Level Habit : A Beginner Field Guide to Street and Travel Photography in South Korea
      koreabridge.net · English
  - (2026-09-27) [South Korea] POW transfer , DMZ blast complicate Lee peace initiative
      koreatimes.co.kr · English
  - (2026-09-27) [South Korea] Chip boom set to push Korea excess tax revenue above $37 billion
      koreatimes.co.kr · English
  - (2026-09-27) [South Korea] Korea - Japan Festival turns 20 in Tokyo with K - pop makeovers , hanbok
      koreatimes.co.kr · English

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-27) [Marginal Revolution] Earth fact of the day, #2
      The shortages have gone on for so long that they are aggressively driving down how much carbon is being released into the atmosphere, a Washington Post analysis of data from the International Energy Agency shows. People…
  - (2026-09-27) [Marginal Revolution] The Federal Lands: An Economic Property Rights Perspective
      The US federal government owns and administers 472,892,659 acres or 21% of the land area of the lower 48 states, the country’s largest landowner. The resource is held and managed as a collective resource, the Federal Lan…
  - (2026-09-26) [Marginal Revolution] What should I ask Terence Tao?
      Yes, I will be doing a Conversation with him. And he has a new book coming out Six Math Essentials. So what should I ask him? The post What should I ask Terence Tao? appeared first on Marginal REVOLUTION.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=19, 14d-median=18; carrying terms: final, proposes, program, state, proposed, certain, provide, regulatory, airplanes, office, airworthiness, model
- state_bills: today=120, 7d-median=120, 14d-median=105; carrying terms: required, report, service, planning, emergency, licensed, safety, agencies, activities, officer, eligible, above
- state_news: today=367, 7d-median=604, 14d-median=604; carrying terms: ensure, required, lawmakers, return, something, north, service, editor, kansas, republished, funding, media
- local_news: today=205, 7d-median=227, 14d-median=231; carrying terms: restaurant, missouri, officials, louis, stlmag, business, woman, crash, class, shooting, articles, school
- foreign_news: today=979, 7d-median=994, 14d-median=994; carrying terms: ensure, return, opens, investigate, service, towards, removal, punchng, lagos, cbspeeches, media, escalation
- chinese_internal: today=237, 7d-median=270, 14d-median=271; carrying terms: chinese, lxtfb, global, articles, china, cbmiykfvx, cbmib, cbmibefvx, title, people, cbmix, google
- russian_internal: today=864, 7d-median=1029, 14d-median=1042; carrying terms: target, reuters, politico, blank, httperror, error, ukraina, server, financial, raquo, telegram, novayagazeta
- ukrainian_internal: today=109, 7d-median=130, 14d-median=135; carrying terms: president, foreign, three, censor, polish, report, vechirniy, killed, peace, military, drones, across
- ukraine_theater: today=379, 7d-median=379, 14d-median=417; carrying terms: snfqz, xsfhntktxmhy, uxcfdpdnrsmvdwbke, nvcwd, service, byuryufr, cuxonk, zylmxbgc, tuzeefvylulsyu, rdmhbrxdhdf, bjhncfbzn, uvhfwmricdv
- paper_bets: today=118, 7d-median=124, 14d-median=125; carrying terms: labor, special, decrease, alaska, republican, president, break, washington, humans, millennium, georgia, north
- weather: today=117, 7d-median=146, 14d-median=119; carrying terms: coastal, rivers, afddtx, north, afdfwd, service, baltimore, hurricane, craft, lower, across, unsecured
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: labor, effective, nonfarm, treasury, dexchus, energy, supply, funds, sheet, spread, unrate, dcoilwtico
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, large, equities, china, close, russell, range, natural, silver, credit, futures, rates
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=98, 7d-median=104, 14d-median=105; carrying terms: tunisia, acronym, foreign, federation, checksum, recognition, occupation, affairs, blank, member, independence, tiananmen
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, unauthorized, congresstrading, quantitative, quiverquant, httperror, error, quiver, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, appeals, company, international, trade, robert, commissioner, texas, association, people, colorado
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed, holdings, group, therapeutics, amended, robert, scott, technology, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cooper, ocasio, disbursements, sherrod, robert, johnson, cycle, brown, committee, raised, david, alexandria
- gdelt_regions: today=6, 7d-median=0, 14d-median=6; carrying terms: english, south
- gdelt_gkg: today=25, 7d-median=50, 14d-median=50; carrying terms: english, themes, spanish, trump, vietnamese, german, ukrainian, russian, ukraine, arabic, turkish, serbian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, kingdom, france, bulgaria, canada, kuwait, aabbef
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: hantavirus, confirmation, death, arachidonic, august, three, majority, average, vaccine, ventilatory, pregnant, confined
- cisa_kev: today=17, 7d-median=18, 14d-median=21; carrying terms: product, improper, vulnerability, secure, buffer, authorization, multiple, traversal, remediation, incorrect, overflow, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=17, 7d-median=14, 14d-median=13; carrying terms: depth, indonesia, islands, ruteng, south, papua, china, guinea, chile, solomon
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, resolves, donetsk, champions, shakhtar, league, championship, september, winner, challengers, ceasefire
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, https, revolution, marginal, class, conversableeconomist, conversable, basic, showing, decline, patterns, carbon
- tech_news: today=52, 7d-median=56, 14d-median=57; carrying terms: bleepingcomputer, companies, intelligence, computerweekly, safety, techcrunch, going, technology, daily, access, initiative, weekday
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: bishop, nicole, goodlander, marcy, simon, alito, president, sheri, robert, norman, steve, brandon
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, claude, market, today, paper, markets, unavailable, consensus, decision, placement, placed, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-21] ECB press: ECB to invest part of own funds in tokenised securities, with settlement via Pontes
- [2026-09-21] ECB press: Eurosystem brings central bank money to tokenised finance
- [2026-09-22] ECB press: Philip R. Lane: Interview with Le Temps
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-23] ECB press: Almost ten million people took part in ECB survey on new euro banknotes
- [2026-09-23] Fed speeches: Barr, A Long-Term View on the Costs of Shelter
- [2026-09-23] ECB press: The digitalisation of money, payments and finance
- [2026-09-23] ECB press: Philip R. Lane: The Outlook for the Euro Area Economy
- [2026-09-24] ECB press: Philip R. Lane: The outlook for the euro area economy
- [2026-09-24] ECB press: ECB Executive Board member Isabel Schnabel to resign to take senior role at IMF
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*