# WORLDSCOPE morning brief — 2026-07-18

## Headline
1931 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (408) · Russian Internal News (state + in-exile) (335) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (177) · Chinese Internal News (168) · U.S. Weather + Severe / Climate Outlooks (156) · GDELT GKG — themes / entities / watch areas (99) · Local News: St. Louis + Atlanta (40) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (39) · State-Level News (36) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 408 new of 1038 total
  - (2026-07-18) [Global] Venezuela quake death toll tops 5,000 as IMF releases recovery funds
      More than 5,000 people were killed in the twin earthquakes that struck Venezuela last month, officials said, adding that the country would tap $346 million from the International Monetary Fund (IMF) for reconstruction. T…
  - (2026-07-18) [Global] Disappointed France and England to face off in third place World Cup match
      France and England meet for their final World Cup match on Saturday competing for third place after failing to reach Sunday's final. Neither of the disappointed teams seems to relish the prospect of the clash: "The best…
  - (2026-07-18) [Global] World Cup 2026: Do supporters know the World Cup records?
      Which is the only team to have competed in every World Cup? And which has won the most? Throughout the tournament, we asked fans about World Cup records.
  - (2026-07-18) [Global] Russia says Ukrainian drone attack killed several in Moscow logistics centre
      A local official said that a Ukrainian drone attack killed seven night-shift workers and wounded 24 at a Moscow logistics centre on Saturday, as part of a larger-scale attack including 370 drones, most of which were "neu…
  - (2026-07-18) [Global] Middle East live: Kuwait says Iran hit second water and electricity plant
      Kuwait said on Saturday that an Iranian attack hit a water and electricity plant one day after a similar strike damaged another plant. Tehran launched attacks on US military sites hosted by several of its Gulf neighbours…
  - (2026-07-18) [Global] No fuel, no patience: Russians endure fuel shortages
      Russian couple Yelena and Dmitry passed four petrol stations before finally finding one that actually had fuel as they returned to the city of Vologda, some 300 miles (480 kilometres) north of Moscow, from their country…

### Russian Internal News (state + in-exile) — 335 new of 964 total
  - (2026-07-18) Зеленский: на складах Wildberries, которые атаковала Украина, хранились комплектующие для дронов | LEDE: Президент Украины Владимир Зеленский прокомментировал атаку украинских беспилотников ] (ru: Зел…
      Президент Украины Владимир Зеленский прокомментировал атаку украинских беспилотников по складам Wildberries в Московской и Тамбовской областях. Он назвал это ответом на российские удары по гражданской инфраструктуре в Ук…
  - (2026-07-18) Война. 1606-й день. Украина бьет по складам Wildberries в Московской и Тамбовской областях. Есть погибшие, десятки человек пострадали | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире р] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-18) С синдромом поликистозных яичников сталкиваются до 20% женщин — но многие даже не подозревают об этом. Как обнаружить состояние, из-за которого растет риск развития рака и других тяжелых болезн] (ru:…
      Ничего особенного, просто мы решили рассказать о синдроме поликистозных яичников (СПКЯ). Хотя это заболевание широко распространено, большинство женщин живут без правильного диагноза. И даже врачи зачастую не понимают, ч…
  - (2026-07-18) Axios: США перебрасывают в Израиль дополнительные самолеты для возможного усиления атак по Ирану | LEDE: Администрация Дональда Трампа уведомила Израиль, что направит в страну еще десятки са] (ru: Axi…
      Администрация Дональда Трампа уведомила Израиль, что направит в страну еще десятки самолетов-заправщиков для возможного расширения военных действий против Ирана. Об этом сообщил Axios со ссылкой на американских и израиль…
  - (2026-07-18) Украинские дроны атаковали склады Wildberries в двух регионах России. В Тамбовской области погибли семь сотрудников компании, в Подмосковье — более 20 пострадавших | LEDE: Украинские беспило] (ru: Укр…
      Украинские беспилотники в ночь на 18 июля атаковали город Котовск в Тамбовской области, сообщил глава региона Евгений Первышов.
  - (2026-07-18) ЦИК заверил списки кандидатов в депутаты Госдумы всех 11 партий | LEDE: ] (ru: ЦИК заверил списки кандидатов в депутаты Госдумы всех 11 партий)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 177 new of 490 total
  - (2026-07-18) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-16) [Liveuamap] Explosions were reported in Berdyansk - Liveuamap
      Explosions were reported in Berdyansk Liveuamap
  - (2026-07-17) [Liveuamap] Ukrainian drones have targeted 12 Russian vessels in Azov and Black Seas - Liveuamap
      Ukrainian drones have targeted 12 Russian vessels in Azov and Black Seas Liveuamap
  - (2026-07-17) [Liveuamap] Axios: Iran fired a ballistic missile at a US base in Saudi Arabia tonight. This is Iran&039;s first direct attack on Saudi Arabia in four months. Riyadh Province Saudi Arabia - Liveuamap
      Axios: Iran fired a ballistic missile at a US base in Saudi Arabia tonight. This is Iran&039;s first direct attack on
  - (2026-07-17) [Liveuamap] Kurdistan Region: Due to the shutdown of the Kormor field, electricity production has decreased by 2500 megawatts. - iraq.liveuamap.com
      Kurdistan Region: Due to the shutdown of the Kormor field, electricity production has decreased by 2500 megawatts.</
  - (2026-07-16) [Liveuamap] White House: Iran continues to talk with US and is interested in reaching an agreement Washington, District of Columbia - Liveuamap
      White House: Iran continues to talk with US and is interested in reaching an agreement Washington, District of Columbia

### Chinese Internal News — 168 new of 287 total
  - (2026-07-16) 视线｜北京动物园大熊猫搬新家 五大“顶流”率先入住 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9BQl82dl9yd05WamhWcjg5TFRkVDc2QW1EQXJGeXR1SHYwM00wWnVKVXQ1Z0hsdTBoQWdKLTFyZ09CQzdnZVNRaW11d0tC] (zh:…
      视线｜北京动物园大熊猫搬新家 五大“顶流”率先入住 财新
  - (2026-07-18) 拉扎尔世家｜猎读 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5HVG1wZlg3MjRVazZyaGpsLXZTdzBFWU5MYm05bXFueFU3ajlXV3lDYmxvRTJhbmYtZ0Y3TjFJaVRXaEZhSVJ3a1BKdFh0Q3ZnOUZteHdwd251T] (zh:…
      拉扎尔世家｜猎读 财新
  - (2026-07-18) 水利部针对鄂湘渝黔4省市启动洪水防御Ⅳ级应急响应 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5JTGh5MEl4Q25XdU4zTEVBOEJuM2oza1l3QlRweXVka0p5YTNQWUZlVGFybUx5R3J3SVVLcXY1dXdtaUI1dnBfdGpQM0Vxc] (zh:…
      水利部针对鄂湘渝黔4省市启动洪水防御Ⅳ级应急响应 财新
  - (2026-07-18) 中国巴西上半年贸易额创新高 新能源车和输华原油成托举 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBTbXdHSXZkS1laZk5oNWRhbXpUU3luRjR4MEVrQjF2WnpDcEZQc1o1Ty1xeEgxOGhrZUUyVWtWZHJxaTNoLUdkNDdzMUh] (zh:…
      中国巴西上半年贸易额创新高 新能源车和输华原油成托举 财新
  - (2026-07-18) 西安两座中晚唐墓考古进展公布 罕见陶俑或与道教相关 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFAzMk5PeTB0Z1RnWFN1MndQajExVHBLdkFwSGo2ZUNJSlJDMi00Nm9pcWxfd292S0Y4YTRFSV80ZExsZj] (zh:…
      西安两座中晚唐墓考古进展公布 罕见陶俑或与道教相关 china.caixin.com
  - (2026-07-18) 独家｜招商证券新总裁即将出炉 集团派出“80后”部门总 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE41b2FDV2k4NmZlNnYtY3NqRFgtUGtreVgwNllIRnpiUkF4SWRiRl81RmM2ODNkM1RYSEJlSFJUMm10Z0NFU1loQkxCdz] (zh:…
      独家｜招商证券新总裁即将出炉 集团派出“80后”部门总 财新

### U.S. Weather + Severe / Climate Outlooks — 156 new of 181 total
  - (2026-07-18) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-18) [Moderate] Special Weather Statement: Special Weather Statement issued July 18 at 2:43AM MDT by NWS Boise ID
      At 242 AM MDT, Doppler radar was tracking a strong thunderstorm near Homedale, or 15 miles south of Parma, moving northeast at 20 mph. HAZARD...Half inch hail and gusts to 30 mph. SOURCE...Radar indicated. IMPACT...Minor…
  - (2026-07-18) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued July 18 at 4:41AM EDT until July 18 at 10:00PM EDT by NWS Detroit/Pontiac MI
      * WHAT...High swim risk from high wave action and strong currents. Dangerous swimming conditions are expected. * WHERE...Huron County. * WHEN...From 8 AM EDT this morning through this evening. * IMPACTS...Strong currents…
  - (2026-07-18) [Severe] Flood Watch: Flood Watch issued July 18 at 2:37AM MDT until July 18 at 10:00PM MDT by NWS Riverton WY
      * WHAT...Flooding caused by excessive rainfall is possible. * WHERE...A portion of northwest Wyoming, including the following areas, Absaroka Mountains and Cody Foothills. * WHEN...From noon MDT today through this evenin…
  - (2026-07-18) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 18 at 4:37AM EDT until July 18 at 5:00AM EDT by NWS Baltimore MD/Washington DC
      SVRLWX The National Weather Service in Sterling Virginia has issued a * Severe Thunderstorm Warning for... Central Garrett County in western Maryland... Southwestern Mineral County in eastern West Virginia... * Until 500…
  - (2026-07-18) [Moderate] Special Weather Statement: Special Weather Statement issued July 18 at 4:36AM EDT by NWS Tampa Bay Ruskin FL
      At 435 AM EDT, Doppler radar was tracking a strong thunderstorm 16 miles west of Lovers Key State Park, or 20 miles west of Bonita Springs, moving north at 20 mph. HAZARD...Wind gusts of 40 to 50 mph. SOURCE...Radar indi…

### GDELT GKG — themes / entities / watch areas — 99 new of 99 total
  - (2026-07-18) [Russia oil sanctions perimeter · themes] « Теневой флот » РФ СБС поразили 13 судов
      focus.ua · Russian · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Irán tvrdí , že dva ropné tankery narazili na míny a začali horieť . united states to popierajú
      aktuality.sk · Slovak · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Готовность 40 - километровой дороги в Печорском районе достигла 45 процентов
      bnkomi.ru · Russian · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Mi ha detto che avevo vinto solo 35 euro , poi ho scoperto la verit : negoziante ruba la vincita a un cliente ( ma viene scoperto )
      leggo.it · Italian · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] 美軍連續七晚打擊伊朗 伊打擊中東多處美軍基地
      hkcd.com · Chinese · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Over 500 feared dead after two boats with refugees sink off Myanmar
      cambodiantimes.com · English · tone NA

### Local News: St. Louis + Atlanta — 40 new of 226 total
  - (2026-07-18) [St. Louis] Mega Millions results for Friday, July 17: Did anyone win the $672 million jackpot?
      The Mega Millions jackpot has been growing since March, when the game saw its last big winner.
  - (2026-07-18) [St. Louis] 2 Forest Service employees zip-tied, held hostage for hours in California, officials say
      The U.S. Forest Service employees were taken hostage while doing field work in Northern California and were safely released.
  - (2026-07-18) [St. Louis] 'Disturbing': Man left baby in car seat in the middle of busy St. Louis street, charges say
      Police said a man abandoned a baby in a car seat in the middle of Goodfellow Boulevard and told the mother he left the baby at a police station.
  - (2026-07-18) [St. Louis] DeChambeau gets 2-shot penalty in dramatic late-night British Open ruling
      Bryson DeChambeau was given a two-shot penalty after his second round at the British Open on Friday that dropped the American star out of the final group.
  - (2026-07-18) [St. Louis] Wreckage of sunken vessel found as 2 people remain missing after San Francisco boat tragedy
      The wreckage was found using boat-mounted sonar, and authorities are now using a remotely operated vehicle to assess the submerged vessel.
  - (2026-07-18) [St. Louis] 'Doing my job' | DoorDash driver completes sandwich delivery after being struck by fleeing suspect
      DoorDash driver Miracle Herron said it was pretty miraculous that she escaped serious injury when police say a fleeing suspect struck her.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-18) [Langlois Sophia J.] Form 4 (Reporting)
      filed 2026-07-18 01:58 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084781 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:58 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084781 Size: 6 KB
  - (2026-07-18) [Yoskowitz Marc J] Form 4 (Reporting)
      filed 2026-07-18 01:57 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084780 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:57 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084780 Size: 6 KB
  - (2026-07-18) [Hirsch Scott] Form 4 (Reporting)
      filed 2026-07-18 01:57 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084779 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:57 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084779 Size: 6 KB

### Ukrainian Internal News (national + local Kyiv) — 39 new of 129 total
  - (2026-07-18) Росіяни атакують автівки та перехожих у Херсоні: поранені дев’ятеро людей | LEDE: 18 липня у Херсоні дрони РФ поранили дев’ятьох людей, серед них 14-річний хлопець. Є травми та поранення.] (uk: Росіян…
      18 липня у Херсоні дрони РФ поранили дев’ятьох людей, серед них 14-річний хлопець. Є травми та поранення.
  - (2026-07-18) Фінляндія обмежувала судноплавство через дрони | LEDE: Збройні сили Фінляндії вводили тимчасове обмеження судноплавства у східній частині Фінської затоки через можливу потребу у збитті невідоми] (uk:…
      Збройні сили Фінляндії вводили тимчасове обмеження судноплавства у східній частині Фінської затоки через можливу потребу у збитті невідомих дронів.
  - (2026-07-18) "Мадяр": Росія послаблює безпілотну компоненту на фронті для захисту тіньового флоту | LEDE: Росія посилює захист суден у Чорному та Азовському морях підрозділами "Рубікон" і ППО після ударів у] (uk:…
      Росія посилює захист суден у Чорному та Азовському морях підрозділами "Рубікон" і ППО після ударів українських дронів.
  - (2026-07-18) Через негоду в Німеччині поїзд врізався в дерево, дороги та будинки затопило | LEDE: ] (uk: Через негоду в Німеччині поїзд врізався в дерево, дороги та будинки затопило)
  - (2026-07-18) Дрони масовано атакували Москву та область: горіли нафтобаза та склад Wildberries | LEDE: У Москві та області після атаки дронів стались пожежі на обʼєктах Wildberries та нафтобазі, десятки пос] (uk:…
      У Москві та області після атаки дронів стались пожежі на обʼєктах Wildberries та нафтобазі, десятки постраждалих.
  - (2026-07-18) У Норвегії у масштабній пожежі згоріли понад 100 житлових будинків | LEDE: ] (uk: У Норвегії у масштабній пожежі згоріли понад 100 житлових будинків)

### State-Level News — 36 new of 690 total
  - (2026-07-18) [Arizona] Judge hands Ohio’s former prisons chief sweeping control over Arizona prison healthcare
      A federal judge on Friday appointed Ohio’s former prisons chief to run Arizona’s prison healthcare system, giving her the sole power to determine what the state needs to do to stop violating the constitutional rights of…
  - (2026-07-17) [Arizona] GOP legislative leaders, Mayes to defend Arizona deportation law in court
      Republican legislative leaders and Attorney General Kris Mayes are on the same side in a lawsuit challenging the state’s power to enforce immigration law, playing defense for a 2024 law that would give state judges the a…
  - (2026-07-17) [Arizona] High court says public comment on Arizona elections manual is not required
      The Arizona Secretary of State is not required to allow public comment on new versions of the state’s elections rulebook, the state’s highest court wrote in a Friday opinion that explained an order the court issued nine…
  - (2026-07-18) [Florida] Corruption by Any Other Name (Part I)
      “Stupidity is the same as evil if you judge by the results.” – Margaret Atwood Republicans have long held a stranglehold on the political levers of power in Florida. Yet, in one of the surest signs of hubris, the longer…
  - (2026-07-18) [Alaska] Democrat throws support to independent running for Alaska’s U.S. House seat
      Matt Schultz, a Democrat running for Alaska’s sole U.S. House seat, suspended his campaign on Friday and threw his support to independent candidate Bill Hill. Schultz, an Anchorage pastor, released a statement urging “al…
  - (2026-07-18) [Alaska] Hilcorp killed Alaska LNG bill, some legislators say, but governor calls the claim ‘bulls**t’
      On Wednesday, one day before the Alaska Legislature voted on a multibillion-dollar tax break for the proposed trans-Alaska gas pipeline, Rep. Calvin Schrage, I-Anchorage, gave the pipeline’s lead developer a sneak previe…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 19 new of 42 total
  - (2026-07-18) M 5.3 - 87 km WSW of Puerto Madero, Mexico
      M5.3 · 87 km WSW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-18) M 5.3 - 119 km SW of Sarangani, Philippines
      M5.3 · 119 km SW of Sarangani, Philippines · depth 10 km
  - (2026-07-18) M 5.2 - south of the Kermadec Islands
      M5.2 · south of the Kermadec Islands · depth 10 km
  - (2026-07-18) M 5.1 - 99 km WSW of Puerto Madero, Mexico
      M5.1 · 99 km WSW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-18) M 5.0 - 17 km SE of Malatya, Turkey
      M5.0 · 17 km SE of Malatya, Turkey · depth 10 km
  - (2026-07-18) M 4.9 - 208 km SW of Bandar Lampung, Indonesia
      M4.9 · 208 km SW of Bandar Lampung, Indonesia · depth 23.732 km

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Local 1374, Jefferson Parish v. Roberts
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Thompson v. McGehee
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: United States v. Kirkwood
  - (2026-07-15) Alaska Supreme Court: Jonah B. v. Department of Family & Community Services, Office of Children's Services
  - (2026-07-15) U.S. Court of Appeals, Federal Cir.: Dougherty Electric, Inc. v. United States
  - (2026-07-15) U.S. Court of Appeals, 8th Cir.: Loralyn Maixner v. Harold Eidsness

### U.S. Federal Action — 14 new of 20 total
  - (2026-07-20) Action by the United States in the Investigation Under Section 301 of the Trade Act of 1974 of Brazil's Acts, Policies, and Practices Related to Digital Trade and Electronic Payment Services; Unfair,…
  - (2026-07-20) Drawbridge Operation Regulation; Newark Bay, Between the City of Newark and City of Bayonne, NJ
      The Coast Guard is modifying the operating regulation that governs the Lehigh Valley Drawbridge across Newark Bay, mile 4.6, between the City of Newark and City of Bayonne, NJ. This change in the regulation will not alte…
  - (2026-07-20) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Harpoon Category Fishery for 2026
      NMFS closes the Harpoon category fishery for large medium and giant (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length (CFL) or greater) Atlantic bluefin tuna (BFT) for the remainder of the 2026 fishing…
  - (2026-07-20) Safety Zones; Delaware River Dredging, Marcus Hook, PA
      The Coast Guard is establishing three temporary safety zones on the waters of the Delaware River, in portions of Marcus Hook Range, Anchorage 7, off Marcus Hook, PA, and Anchorage 9, near entrance to Mantua Creek. The sa…
  - (2026-07-20) Takes of Marine Mammals Incidental to Specified Activities; Taking Marine Mammals Incidental to Texas Parks and Wildlife Department Fisheries Research
      NMFS, upon request from Texas Parks and Wildlife Department (TPWD), is promulgating regulations to govern the taking of marine mammals incidental to fisheries research in the coastal bays of Texas over the course of 5 ye…
  - (2026-07-20) Food Standards of Identity Modernization; Pasteurized Orange Juice
      The Food and Drug Administration (FDA or we) is issuing a final rule to amend the standard of identity for pasteurized orange juice by lowering the minimum orange juice soluble solids content from 10.5[deg] to 10[deg] Br…

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 115 total
  - (2026-07-18) [USASpending] $17,319,586,106 → BECHTEL NATIONAL, INC.:
      Agency: Department of Energy. Description:
  - (2026-07-18) [USASpending] $1,402,874,932 → AUSTAL USA, LLC: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESI
      Agency: Department of Homeland Security. Description: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESIGN AND PRODUCTION (DD&P) OF 11 OPCS.
  - (2026-07-18) [USASpending] $798,366,385 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-18) [USASpending] $623,936,794 → LEIDOS, INC.: ESA V MANAGED SERVICES (ATF AND FCS)
      Agency: Department of Justice. Description: ESA V MANAGED SERVICES (ATF AND FCS)
  - (2026-07-18) [USASpending] $623,150,308 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-07-18) [USASpending] $521,824,443 → FOUR POINTS TECHNOLOGY, L.L.C.: ENTERPRISE CLOUD CAPACITY - AMAZON WEB SERVICES
      Agency: Department of Veterans Affairs. Description: ENTERPRISE CLOUD CAPACITY - AMAZON WEB SERVICES

### Paper Trading Scorecard — 6 new of 142 total
  - (2026-07-18) [Polymarket] Will England score the most goals at the 2026 FIFA World Cup?
      This market will resolve to the nation that records the most total goals through all rounds of the 2026 FIFA World Cup competition. In the event of a tie, this market will resolve according to the official leader as dete…
  - (2026-07-18) [Polymarket] Will the Houthis successfully target shipping by July 31, 2026?
      This market will resolve to "Yes" if Houthi forces conduct a kinetic strike on or otherwise seize control of a commercial ship between market creation and the specified date 11:59 PM AST (UTC+03:00). Otherwise, this mark…
  - (2026-07-18) [Polymarket] Will Gold (XAUUSD) hit (LOW) $3,800 in July?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of July 2026, any 1-minute candle for Gold (XAUUSD) has a final "High" or "Low" price equal to or beyond (above for ↑…
  - (2026-07-18) [Manifold] Will Ingvar Carlsson live to 100?
  - (2026-07-18) [Manifold] Will Spain win the 2026 World Cup Final in regulation time?
  - (2026-07-18) [Manifold] Will Messi score during the world cup final VS Spain ?

### Prediction Markets — most-traded (Polymarket) — 4 new of 20 total
  - (2026-07-18) Will the Fed decrease interest rates by 25 bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $1,030,426 · resolves 2026-07-29
  - (2026-07-18) Spain vs. Argentina: O/U 2.5
      yes price: 42% · 24h volume: $755,678 · resolves 2026-07-19
  - (2026-07-18) Exact Score: Spain 3 - 2 Argentina?
      yes price: 2% · 24h volume: $553,805 · resolves 2026-07-19
  - (2026-07-18) Will LeBron James play for the Golden State Warriors in 2026-27?
      yes price: 19% · 24h volume: $500,305 · resolves 2026-10-31

### GDACS — global disaster alerts — 3 new of 50 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-18) [Marginal Revolution] What should I ask Luis Garicano?
      Yes I will be doing a Conversation with him. From Wikipedia: Luis Garicano Gabilondo (pronounced [ˈlwis ɣaɾiˈkano]; born 1967) is a Spanish economist and politician who was a Member of the European Parliament (MEP) from…
  - (2026-07-18) [Marginal Revolution] The small business boom
      Across the country, founders like Ms. Winkler are powering an entrepreneurial renaissance. Jump-started by the pandemic, when a confluence of factors including mass layoffs and remote work led to a flood of business crea…
  - (2026-07-18) [Marginal Revolution] *The Odyssey*, the movie (no real spoilers)
      I can’t say I loved it. The Circe scene was excellent, Cyclops was good, and the battles in Troy were well done. But most of the roles were miscast. I like Matt Damon, but he is too “Good Will Hunting” to play Odysseus.…

### IT, InfoSys & cybersecurity news (last 7 days) — 2 new of 58 total
  - (2026-07-18) [The Register] NextBSD returns to dollop Apple source on FreeBSD
      New maintainer revives the project with Darwin components, Gershwin, and Claude Code
  - (2026-07-18) [TechCrunch] Neil Rimer thinks the AI money is coming back out
      Neil Rimer, the venture capitalist who co-founded Index Ventures, predicts the historic wealth AI is generating in Silicon Valley will have to be redistributed, voluntarily or involuntarily.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-18) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=22, 14d-median=22; carrying terms: local, existing, period, within, marine, specifically, public, being, commission, eliminating, published, temporary
- state_bills: today=0, 7d-median=1, 14d-median=1
- state_news: today=690, 7d-median=568, 14d-median=568; carrying terms: support, marking, challenging, record, local, start, width, prevent, questions, incarcerated, later, minnesota
- local_news: today=226, 7d-median=231, 14d-median=231; carrying terms: support, local, start, width, stlmag, later, including, advertising, history, brand, arrested, drowning
- foreign_news: today=1038, 7d-median=1038, 14d-median=1038; carrying terms: marking, record, local, questions, suzhou, innovation, current, initiative, changsha, future, lived, woman
- chinese_internal: today=287, 7d-median=282, 14d-median=282; carrying terms: google, investors, title, cbmizkfvx, europe, cbmidefvx, markets, stock, cbmizefvx, launch, cbmiy, cbmickfvx
- russian_internal: today=964, 7d-median=936, 14d-median=936; carrying terms: metals, client, bloomberg, times, hyundai, style, error, ntech, title, raquo, media, novayagazeta
- ukrainian_internal: today=129, 7d-median=132, 14d-median=132; carrying terms: support, record, local, questions, crimea, including, transfers, cooperation, driven, split, pressure, missile
- ukraine_theater: today=490, 7d-median=445, 14d-median=445; carrying terms: support, local, mglwau, mawtstlbgtkl, tonga, questions, jyulpug, innovation, viirs, history, march, dovelxcxvuakftmtjqohrfde
- paper_bets: today=142, 7d-median=140, 14d-median=140; carrying terms: polymarket, resolution, cousins, player, humans, minnesota, award, baker, france, announcement, current, second
- weather: today=181, 7d-median=156, 14d-median=156; carrying terms: baltimore, local, result, forecasts, inland, updated, galveston, occur, including, thunderstorms, runoff, magnitude
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: supply, labor, payrolls, dcoilwtico, dexuseu, commodities, indicator, pcepilfe, effective, spread, cpiaucsl, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, futures, proxy, russell, natural, corporate, commodities, agriculture, bitcoin, close, large, crypto
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=115, 7d-median=114, 14d-median=114; carrying terms: support, terrorism, territorial, attacks, information, counter, agreement, award, crimea, cbmizefvx, include, portal
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quiver, unauthorized, quantitative, error, congresstrading, client, httperror, https
- billionaires: today=30, 7d-median=31, 14d-median=31; carrying terms: yiming, alice, francoise, spacex, commodities, bloomberg, finance, tiktok, euronext, oracle, france, italy
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: truck, company, robert, association, california, north, america, court, charles, energy, delaware, william
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, issuer, accno
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: michael, ocasio, disbursements, raised, krishnamoorthi, pinkston, lindsey, committee, angels, elect, warner, robert
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=99, 7d-median=49, 14d-median=49; carrying terms: ukraine, russian, english, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: support, representing, cruise, operator, local, algeria, result, september, information, majority, awareness, remains
- cisa_kev: today=16, 7d-median=12, 14d-median=12; carrying terms: cisco, authentication, request, deserialization, sharepoint, microsoft, improper, vendor, product, control, vulnerability, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=50, 7d-median=126, 14d-median=126; carrying terms: slovakia, eruption, czech, islands, drought, region, republic, france, italy, orange, magnitude, vietnam
- usgs_quakes: today=42, 7d-median=20, 14d-median=20; carrying terms: ridge, depth
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, democratic, ethiopia, meeting, france, england, increase, minister, interest, world, resolves, spain
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, https, marginalrevolution, conversable, class, marginal, revolution
- tech_news: today=58, 7d-median=58, 14d-median=58; carrying terms: support, record, forecasts, information, older, engineers, including, strategy, innovation, current, initiative, history
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: brandon, terri, ricketts, pappas, mcgovern, grassley, keating, blunt, gregory, robert, deputy, schatz
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, module, either, today, unavailable, sufficient, placed, placement, markets, market, claude, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*