# WORLDSCOPE morning brief — 2026-07-18

## Headline
2951 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (640) · Russian Internal News (state + in-exile) (538) · Ukraine Theater (total-war monitoring) (361) · World leaders & government officials (324) · Chinese Internal News (194) · U.S. Weather + Severe / Climate Outlooks (175) · Local News: St. Louis + Atlanta (145) · State Legislative Action (138) · State-Level News (83) · Ukrainian Internal News (national + local Kyiv) (59) · GDELT GKG — themes / entities / watch areas (47) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 640 new of 1024 total
  - (2026-07-18) [Global] Saka hat-trick helps England down France to win World Cup 2026 Bronze Final
      Kylian Mbappe scores twice for France to hit World Cup record, but England win 6-4 in third-place playoff final.
  - (2026-07-18) [Global] Kylian Mbappe breaks all-time World Cup scoring record with 22nd goal
      Mbappe is back on track to defend his Golden Boot title, which he and Messi have traded between themselves throughout the tournament.
  - (2026-07-18) [Global] World Cup final tickets near $2.3m mark on FIFA’s resale platform
      While no tickets are available on FIFA's sales platform, they are being resold for sky-high prices on resale sites.
  - (2026-07-18) [Global] Cockroach Party protest intensifies after Wangchuk forcibly hospitalised
      Protest by India's Cockroach Janta Party has intensified after activist Sonam Wangchuk was forcibly hospitalised.
  - (2026-07-18) [Global] Latin America unites to cheer against Argentina in FIFA World Cup final
      Fans from Mexico to Brazil unite to cheer Yamal's Spain against Argentina and Messi, whom they call 'FIFA’s golden boy'.
  - (2026-07-18) [Global] Palestinian teenage footballer dies a week after Israeli settler attack
      A week after he was shot in his West Bank village, Fadi al-Nassan's death comes amid a surge in settler violence.

### Russian Internal News (state + in-exile) — 538 new of 833 total
  - (2026-07-18) В Украине третий день подряд протесты из-за отставки министра обороны. Участники акций также требуют смены главкома ВСУ | LEDE: В Киеве и других городах Украины третий день подряд проходят а] (ru: В У…
      В Киеве и других городах Украины третий день подряд проходят акции протеста, участники которых требуют вернуть Михаила Федорова на должность министра обороны. Об этом сообщает «Громадське».
  - (2026-07-18) Летчика и Z-блогера Алексея Земцова приговорили к трем годам колонии по делу об угрозе убийством и вымогательстве | LEDE: Гарнизонный военный суд в Ростове-на-Дону приговорил бывшего летчика] (ru: Лет…
      Гарнизонный военный суд в Ростове-на-Дону приговорил бывшего летчика вертолета Ка-52 и основателя телеграм-канала «Воевода вещает» Алексея Земцова к трем годам колонии по делу об угрозе убийством, порче имущества и вымог…
  - (2026-07-18) Оценить замысел Нолана невозможно: больших экранов не хватает. Из фильма пропала поэзия. Прорыва не случилось. Чем теперь недовольны критики «Одиссеи»? Претензий действительно немало — хотя вос] (ru:…
      «Одиссея» Кристофера Нолана собирает очень хорошую прессу и бьет кассовые рекорды. Критики хвалят остроумное прочтение Гомера и игру Мэтта Дэймона, а поклонники режиссера радуются, что хейтерам не удалось сорвать премьер…
  - (2026-07-18) Ozon (как и Wildberries) изменил условия договора с продавцами. Маркетплейс не будет компенсировать утрату товара при ударах дронами | LEDE: Ozon изменил условия соглашения между маркетплейс] (ru: Ozo…
      Ozon изменил условия соглашения между маркетплейсом и продавцом: теперь там указано, что компания не будет компенсировать утрату или повреждение товара продавцу, если причиной этого стали военные действия, режим ЧС, обст…
  - (2026-07-18) The Bell: в результате ударов по двум логистическим центрам Wildberries пострадали 10-15% всех складских помещений компании | LEDE: В результате удара украинских беспилотников по логистическ] (ru: The…
      В результате удара украинских беспилотников по логистическим центрам Wildberries в Московской и Тамбовской областях могли пострадать порядка 10-15% всех складских площадей маркетплейса. Такую оценку привел источник The B…
  - (2026-07-18) Глава Wildberries: маркетплейс не обязан компенсировать продавцам утраченный товар из-за удара дронов, но вопрос выплат «прорабатывается» | LEDE: Wildberries «прорабатывает» вопрос выплат пр] (ru: Гла…
      Wildberries «прорабатывает» вопрос выплат продавцам, которые потеряли свои товары в результате удара украинских дронов по складам маркетплейса в Московской и Тамбовской областях. Об этом сообщила глава Wildberries Татьян…

### Ukraine Theater (total-war monitoring) — 361 new of 646 total
  - (2026-07-17) [FIRMS] thermal anomaly 52.846, 29.987 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 1.02 MW
  - (2026-07-17) [FIRMS] thermal anomaly 52.807, 32.219 (FRP 1.05 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 1.05 MW
  - (2026-07-17) [FIRMS] thermal anomaly 52.807, 32.224 (FRP 1.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 1.08 MW
  - (2026-07-17) [FIRMS] thermal anomaly 51.894, 29.332 (FRP 4.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 4.86 MW
  - (2026-07-17) [FIRMS] thermal anomaly 51.890, 29.326 (FRP 3.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 3.97 MW
  - (2026-07-17) [FIRMS] thermal anomaly 51.891, 29.337 (FRP 2.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 2.86 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 194 new of 299 total
  - (2026-07-17) Chinese Politburo Member’s Downfall Exposes Shadowy Network Tied to Evergrande, Vanke - Caixin Global
      Chinese Politburo Member’s Downfall Exposes Shadowy Network Tied to Evergrande, Vanke Caixin Global
  - (2026-07-18) 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBFbjlnSnJOYXJzV0lqOGJnS1c4YWk5aDMxSjhCMHlHTW1paGhQZFVaSFNyN3NVQ3duTkFHa3lnUDgyTHZYOXlPZ1pWMEhBMzVTRWRmdW44UXVrQVF] (zh:…
      商品详情 财新商城
  - (2026-07-18) 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBUNUNNYUc0N2lMcTF4ZnE3ZzJfZkd5X3hndzVXekFXeXVwc082RjY3SC1tcnVoNEVlRVBpWUU0LTFReW93WElEaUNXNFk0Vm1xNnVsaTZZVHh1cEh] (zh:…
      商品详情 财新商城
  - (2026-07-17) 周刊订阅 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMisgFBVV95cUxOQTBIcmlaM0tNcW1XRnNLWmYzSU9FQnNVQVM4SUNYdE1OV1dQVkduMXIwTzFIa3hRYTkybkpJMXJBVjhMUS1SSlhzV3o0RFpWTy0zN2hZclhNWHp] (zh:…
      周刊订阅 财新商城
  - (2026-07-16) 视线｜北京动物园大熊猫搬新家 五大“顶流”率先入住 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9BQl82dl9yd05WamhWcjg5TFRkVDc2QW1EQXJGeXR1SHYwM00wWnVKVXQ1Z0hsdTBoQWdKLTFyZ09CQzdnZVNRaW11d0tC] (zh:…
      视线｜北京动物园大熊猫搬新家 五大“顶流”率先入住 财新
  - (2026-07-17) 视线｜重庆彭水山体崩塌已致8死 仍有34人失联 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5tRVk1N3NicE94ZFBQTFZxaW5uU1NGY1U4ZFNzdTdHM1BubjJjMkVVLXlRQ2lwcGJ4N0xRYTJPV0trRWdWcWJJV2h3Y0FJLX] (zh:…
      视线｜重庆彭水山体崩塌已致8死 仍有34人失联 财新

### U.S. Weather + Severe / Climate Outlooks — 175 new of 177 total
  - (2026-07-18) [Moderate] Special Weather Statement: Special Weather Statement issued July 18 at 6:32PM CDT by NWS Lubbock TX
      At 631 PM CDT, Doppler radar was tracking a strong thunderstorm 4 miles east of Cee Vee, or 13 miles north of Paducah. This thunderstorm was nearly stationary. HAZARD...Wind gusts of 50 to 55 mph and pea size hail. SOURC…
  - (2026-07-18) [Moderate] Special Weather Statement: Special Weather Statement issued July 18 at 7:30PM EDT by NWS Blacksburg VA
      At 729 PM EDT, Doppler radar was tracking a cluster of strong thunderstorms near Richwood, moving southeast at 45 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tre…
  - (2026-07-18) [Moderate] Special Weather Statement: Special Weather Statement issued July 18 at 6:30PM CDT by NWS Lubbock TX
      At 629 PM CDT, Doppler radar was tracking strong thunderstorms along a line extending from Matador to 6 miles northwest of Dougherty. These storms were nearly stationary. HAZARD...Wind gusts of 50 to 55 mph and pea size…
  - (2026-07-18) [Moderate] Special Weather Statement: Special Weather Statement issued July 18 at 7:30PM EDT by NWS Charleston WV
      At 730 PM EDT, Doppler radar was tracking a strong thunderstorm near Heath, moving southeast at 40 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limbs and blo…
  - (2026-07-18) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 18 at 5:30PM MDT until July 18 at 6:30PM MDT by NWS Great Falls MT
      SVRTFX The National Weather Service in Great Falls has issued a * Severe Thunderstorm Warning for... Central Liberty County in north central Montana... Southeastern Toole County in north central Montana... * Until 630 PM…
  - (2026-07-18) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 18 at 7:29PM EDT until July 18 at 8:00PM EDT by NWS Pittsburgh PA
      At 729 PM EDT, severe thunderstorms were located along a line from 6 miles east of Brockway to 6 miles north of New Bethlehem, or along a line from 22 miles east of Brookville to 8 miles east of Rimersburg, moving southe…

### Local News: St. Louis + Atlanta — 145 new of 246 total
  - (2026-07-18) [St. Louis] Football vs. fútbol: Nine reasons I'll always take the NFL over World Cup | Opinion
      The Beautiful Game? Meh. Eye of the beholder, etc., etc.
  - (2026-07-18) [St. Louis] England defeats France 6-4 in the Bronze Final of the FIFA World Cup
      England claimed third place at the World Cup by beating France 6-4 on Saturday, while Les Bleus' captain Kylian Mbappe became the tournament's all-time top scorer with 22 goals.
  - (2026-07-18) [St. Louis] SOCCER-WORLDCUP-FRA-ENG/
      England's Bukayo Saka, center, celebrates scoring his third goal against France with Jude Bellingham, left, and Reece James during the third place match at the FIFA World Cup on Saturday in Miami Gardens, Fla.
  - (2026-07-18) [St. Louis] SOCCER-WORLDCUP-FRA-ENG/
      England's Bukayo Saka beats France goalkeeper Mike Maignan to score during the third place match of the FIFA World Cup on Saturday in Miami Gardens, Fla.
  - (2026-07-18) [St. Louis] SOCCER-WORLDCUP-FRA-ENG/
      France's Kylian Mbappe battles with England's Marc Guehi during the third place match of the FIFA World Cup on Saturday in Miami Gardens, Fla.
  - (2026-07-18) [St. Louis] Nolan Arenado drives D-Backs to victory as they exploit Cardinals Dustin May's rocky 3rd
      Arenado had two hits in his first two at-bats and his two-out, two-run double in the third pushed Arizona toward a five-run lead, they'd hold for a 5-3 victory.

### State Legislative Action — 138 new of 138 total
  - (2026-07-18) [Alaska SB 249] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; relating to unfair trade or deceptive acts or practices; and providing for an effective…
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; relating to unfair trade or deceptive acts or practices; and providing for an effective date.
  - (2026-07-18) [Alaska HB 285] An Act relating to the electronic health information exchange system; and providing for an effective date.
      An Act relating to the electronic health information exchange system; and providing for an effective date.
  - (2026-07-18) [Alaska HJR 32] Expressing commitment to the rural health transformation program; acknowledging the critical health care challenges facing rural areas of the state; and urging action by the Governor a…
      Expressing commitment to the rural health transformation program; acknowledging the critical health care challenges facing rural areas of the state; and urging action by the Governor and the Alaska delegation in Congress…
  - (2026-07-17) [Alaska HCR 302] Authorizing the Senate and the House of Representatives to recess for a period of more than three days.
      Authorizing the Senate and the House of Representatives to recess for a period of more than three days.
  - (2026-07-17) [Alaska HCR 301] Suspending Rules 47 and 55, Uniform Rules of the Alaska State Legislature, relating to the carry-over of bills to a special session.
      Suspending Rules 47 and 55, Uniform Rules of the Alaska State Legislature, relating to the carry-over of bills to a special session.
  - (2026-07-17) [Alaska HB 176] An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date…
      An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date.

### State-Level News — 83 new of 711 total
  - (2026-07-18) [Arizona] Judge hands Ohio’s former prisons chief sweeping control over Arizona prison healthcare
      A federal judge on Friday appointed Ohio’s former prisons chief to run Arizona’s prison healthcare system, giving her the sole power to determine what the state needs to do to stop violating the constitutional rights of…
  - (2026-07-17) [Arizona] GOP legislative leaders, Mayes to defend Arizona deportation law in court
      Republican legislative leaders and Attorney General Kris Mayes are on the same side in a lawsuit challenging the state’s power to enforce immigration law, playing defense for a 2024 law that would give state judges the a…
  - (2026-07-17) [Arizona] High court says public comment on Arizona elections manual is not required
      The Arizona Secretary of State is not required to allow public comment on new versions of the state’s elections rulebook, the state’s highest court wrote in a Friday opinion that explained an order the court issued nine…
  - (2026-07-18) [Arkansas] Political parties boast new clout and cash in midterms thanks to US Supreme Court
      A recent U.S. Supreme Court decision makes it easier for political parties to put their stamp on the most important campaigns, just as the struggle heats up for control of Congress in the midterm elections. Simply put, t…
  - (2026-07-18) [Colorado] Colorado graduated income tax proponents rally canvassers ahead of petition deadline
      With just two weeks to go before a petition deadline, supporters of a ballot measure to put a graduated income-tax system in the Colorado constitution rallied canvassers in Denver for a final sprint of signature-gatherin…
  - (2026-07-18) [Alaska] Democrat throws support to independent running for Alaska’s U.S. House seat
      Matt Schultz, a Democrat running for Alaska’s sole U.S. House seat, suspended his campaign on Friday and threw his support to independent candidate Bill Hill. Schultz, an Anchorage pastor, released a statement urging “al…

### Ukrainian Internal News (national + local Kyiv) — 59 new of 138 total
  - (2026-07-19) Балістична атака на Київ: горять будинки, ТРЦ, автомобілі | LEDE: У Києві пролунали численні вибухи, ворог атакує балістикою.] (uk: Балістична атака на Київ: горять будинки, ТРЦ, автомобілі)
      У Києві пролунали численні вибухи, ворог атакує балістикою.
  - (2026-07-19) В Ірані прихильники жорсткого курсу попереджають про "державний переворот" – CNN | LEDE: ЗМІ повідомляють, що іранці говорять "державний переворот" на тлі переговорів із США.] (uk: В Ірані прихильники…
      ЗМІ повідомляють, що іранці говорять "державний переворот" на тлі переговорів із США.
  - (2026-07-19) У Запоріжжі внаслідок ворожої атаки пожежа охопила будівлю вишу – ОВА | LEDE: У Запоріжжі після ворожої атаки горить будівля вишу.] (uk: У Запоріжжі внаслідок ворожої атаки пожежа охопила будівлю вишу…
      У Запоріжжі після ворожої атаки горить будівля вишу.
  - (2026-07-18) Росіяни вдарили по Одещині: загинув підліток, 7 постраждалих | LEDE: Внаслідок російських ударів по Одещині в суботу загинув підліток, ще 7 людей постраждали.] (uk: Росіяни вдарили по Одещині: загинув…
      Внаслідок російських ударів по Одещині в суботу загинув підліток, ще 7 людей постраждали.
  - (2026-07-18) Дрон РФ влучив у багатоповерхівку в Херсоні: 5 постраждалих, діти у важкому стані | LEDE: Унаслідок атаки дрона в Херсоні постраждали 5 людей, серед них двоє дітей у важкому стані.] (uk: Дрон РФ влучи…
      Унаслідок атаки дрона в Херсоні постраждали 5 людей, серед них двоє дітей у важкому стані.
  - (2026-07-18) ZN.UA: Федорову можуть запропонувати нову роль, а Сирського замінити | LEDE: На Банковій розглядають Федорова як "miltech czar" для розвитку військових технологій і озброєнь.] (uk: ZN.UA: Федорову мож…
      На Банковій розглядають Федорова як "miltech czar" для розвитку військових технологій і озброєнь.

### GDELT GKG — themes / entities / watch areas — 47 new of 47 total
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Río Bravo crece y supera los 4 metros ; boyas naranjas llegan a los puentes y ponen en alerta a los dos Laredos | VIDEO
      elmanana.com.mx · Spanish · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] 巴西喊话特朗普 ： 拒绝接受
      baijiahao.baidu.com · Chinese · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Mỹ và Iraq thúc đẩy đường ống dầu thay thế eo biển Hormuz
      voh.com.vn · Vietnamese · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] 2 lính Mỹ tử trận tại Jordan , Tehran tuyên bố dạy Washington bài học nhớ đời
      vov.vn · Vietnamese · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Fire crews still in attendance at Cairngorms wildfire say progress has been made
      cotswoldjournal.co.uk · English · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] El plan energético de Trump tropieza con Venezuela
      talcualdigital.com · Spanish · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-18) [Langlois Sophia J.] Form 4 (Reporting)
      filed 2026-07-18 01:58 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084781 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:58 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084781 Size: 6 KB
  - (2026-07-18) [Yoskowitz Marc J] Form 4 (Reporting)
      filed 2026-07-18 01:57 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084780 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:57 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084780 Size: 6 KB
  - (2026-07-18) [Hirsch Scott] Form 4 (Reporting)
      filed 2026-07-18 01:57 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084779 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:57 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084779 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-18) [United States] Why the GOP loves to use communism as an attack
      domain: dailykos.com · language: English · tone:
  - (2026-07-18) [United States] Uttarakhand CM takes serious note of concerns over Dehradun - Rishikesh four / six - lane project
      domain: bignewsnetwork.com · language: English · tone:
  - (2026-07-18) [United States] U . S . launches new airstrikes against Iran following Jordan strike
      domain: fox23.com · language: English · tone:
  - (2026-07-18) [United States] Body found at Boston home owned by husband of Massachusetts Rep . Ayanna Pressley
      domain: cbsnews.com · language: English · tone:
  - (2026-07-18) [Australia] Mark Kenny | Truth now comes down to affiliation | Katherine Times
      domain: katherinetimes.com.au · language: English · tone:
  - (2026-07-18) [United States] Bangor protest among several across the nation during national day of action
      domain: wabi.tv · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 23 new of 143 total
  - (2026-07-18) [Polymarket] Will Javier Milei win the 2027 Argentina presidential election?
      A presidential election scheduled to be held in Argentina on October 24, 2027. This market will resolve according to the listed candidate who wins the next Argentinian Presidential election. This market includes any pote…
  - (2026-07-18) [Polymarket] President Trump to Attend World Cup Final?
      This market will resolve to “Yes” if Donald Trump attends the 2026 FIFA World Cup Final. Otherwise, this market will resolve to “No”. Attending the match is defined as being in physical attendance during any part of the…
  - (2026-07-18) [Polymarket] Extended FDV above $1B one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Extended's token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token must be acti…
  - (2026-07-18) [Polymarket] Will Kendrick Lamar be the top artist for 2026?
      Spotify releases an annual report of its most streamed artist (see: https://newsroom.spotify.com/2025-12-03/wrapped-top-artists-songs-albums-podcasts-audiobooks/). This market refers to the most streamed Spotify artist f…
  - (2026-07-18) [Polymarket] New York Liberty vs. Indiana Fever
      In the upcoming WNBA game, scheduled for July 18 at 8:00PM ET: If the New York Liberty win, the market will resolve to "New York Liberty". If the Indiana Fever win, the market will resolve to "Indiana Fever". If the game…
  - (2026-07-18) [Polymarket] Ukraine agrees to limit size of armed forces before 2027?
      This market will resolve to "Yes" if Ukraine publicly agrees to limit the number of personnel in its armed forces by December 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to “No”. An official pledge by Ukra…

### USGS earthquakes (M4.5+, past day) — 23 new of 23 total
  - (2026-07-18) M 5.7 - 72 km SW of Puerto Madero, Mexico
      M5.7 · 72 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-18) M 5.5 - Scotia Sea
      M5.5 · Scotia Sea · depth 10 km
  - (2026-07-18) M 5.3 - 87 km WSW of Puerto Madero, Mexico
      M5.3 · 87 km WSW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-18) M 5.3 - 119 km SW of Sarangani, Philippines
      M5.3 · 119 km SW of Sarangani, Philippines · depth 10 km
  - (2026-07-18) M 5.2 - 69 km SW of Puerto Madero, Mexico
      M5.2 · 69 km SW of Puerto Madero, Mexico · depth 44.887 km
  - (2026-07-18) M 5.2 - south of the Kermadec Islands
      M5.2 · south of the Kermadec Islands · depth 10 km

### U.S. Federal Action — 14 new of 20 total
  - (2026-07-20) Action by the United States in the Investigation Under Section 301 of the Trade Act of 1974 of Brazil's Acts, Policies, and Practices Related to Digital Trade and Electronic Payment Services; Unfair,…
  - (2026-07-20) Drawbridge Operation Regulation; Newark Bay, Between the City of Newark and City of Bayonne, NJ
      The Coast Guard is modifying the operating regulation that governs the Lehigh Valley Drawbridge across Newark Bay, mile 4.6, between the City of Newark and City of Bayonne, NJ. This change in the regulation will not alte…
  - (2026-07-20) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Harpoon Category Fishery for 2026
      NMFS closes the Harpoon category fishery for large medium and giant (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length (CFL) or greater) Atlantic bluefin tuna (BFT) for the remainder of the 2026 fishing…
  - (2026-07-20) Safety Zones; Delaware River Dredging, Marcus Hook, PA
      The Coast Guard is establishing three temporary safety zones on the waters of the Delaware River, in portions of Marcus Hook Range, Anchorage 7, off Marcus Hook, PA, and Anchorage 9, near entrance to Mantua Creek. The sa…
  - (2026-07-20) Takes of Marine Mammals Incidental to Specified Activities; Taking Marine Mammals Incidental to Texas Parks and Wildlife Department Fisheries Research
      NMFS, upon request from Texas Parks and Wildlife Department (TPWD), is promulgating regulations to govern the taking of marine mammals incidental to fisheries research in the coastal bays of Texas over the course of 5 ye…
  - (2026-07-20) Food Standards of Identity Modernization; Pasteurized Orange Juice
      The Food and Drug Administration (FDA or we) is issuing a final rule to amend the standard of identity for pasteurized orange juice by lowering the minimum orange juice soluble solids content from 10.5[deg] to 10[deg] Br…

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-07-18) Will Argentina win on 2026-07-19?
      yes price: 27% · 24h volume: $1,774,863 · resolves 2026-07-19
  - (2026-07-18) Will Lionel Messi be the top goalscorer at the 2026 FIFA World Cup?
      yes price: 7% · 24h volume: $1,557,589 · resolves 2026-07-20
  - (2026-07-18) Will Hassan Shariatmadari be head of state in Iran end of 2026?
      yes price: 0% · 24h volume: $1,474,634 · resolves 2026-12-31
  - (2026-07-18) Tampa Bay Rays vs. Boston Red Sox
      yes price: 24% · 24h volume: $1,215,552 · resolves 2026-07-25
  - (2026-07-18) Exact Score: Spain 3 - 3 Argentina?
      yes price: 1% · 24h volume: $1,190,789 · resolves 2026-07-19
  - (2026-07-18) Will Kylian Mbappe be the top goalscorer at the 2026 FIFA World Cup?
      yes price: 92% · 24h volume: $962,021 · resolves 2026-07-20

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Local 1374, Jefferson Parish v. Roberts
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Thompson v. McGehee
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: United States v. Kirkwood
  - (2026-07-15) U.S. Court of Appeals, 4th Cir.: Golden Corral Corporation v. Illinois Union Insurance Company
  - (2026-07-15) Alaska Supreme Court: Jonah B. v. Department of Family & Community Services, Office of Children's Services
  - (2026-07-15) U.S. Court of Appeals, 2nd Cir.: Bergin v. N.Y. State Unified Court System

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-18) [Japan] Razer Eevee and Pikachu Pokemon Collection Suits the Characters
      siliconera.com · English
  - (2026-07-18) [Japan] JR East to replace standard tickets with QR code ones | The Asahi Shimbun : Breaking News , Japan News and Analysis
      asahi.com · English
  - (2026-07-18) [Japan] JPU Records Festival : Japan Underground Festival
      metropolisjapan.com · English
  - (2026-07-18) [Japan] Planes , trains , hotels catering more to travelers and their pets | The Asahi Shimbun : Breaking News , Japan News and Analysis
      asahi.com · English
  - (2026-07-18) [Japan] Survey : Only 16 % of travelers from abroad want to visit Tohoku | The Asahi Shimbun : Breaking News , Japan News and Analysis
      asahi.com · English
  - (2026-07-18) [Japan] Are You Hyped for These 9 New PS Plus Games ?
      pushsquare.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 115 total
  - (2026-07-18) [USASpending] $17,319,586,106 → BECHTEL NATIONAL, INC.:
      Agency: Department of Energy. Description:
  - (2026-07-18) [USASpending] $1,402,874,932 → AUSTAL USA, LLC: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESI
      Agency: Department of Homeland Security. Description: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESIGN AND PRODUCTION (DD&P) OF 11 OPCS.
  - (2026-07-18) [USASpending] $798,366,385 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-18) [USASpending] $623,936,794 → LEIDOS, INC.: ESA V MANAGED SERVICES (ATF AND FCS)
      Agency: Department of Justice. Description: ESA V MANAGED SERVICES (ATF AND FCS)
  - (2026-07-18) [USASpending] $623,150,308 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-07-18) [USASpending] $521,824,443 → FOUR POINTS TECHNOLOGY, L.L.C.: ENTERPRISE CLOUD CAPACITY - AMAZON WEB SERVICES
      Agency: Department of Veterans Affairs. Description: ENTERPRISE CLOUD CAPACITY - AMAZON WEB SERVICES

### IT, InfoSys & cybersecurity news (last 7 days) — 10 new of 53 total
  - (2026-07-18) [BleepingComputer] Update now: 7-Zip fixes RCE flaw exploitable with malicious archives
      7-Zip version 26.02 was released to fix a remote code execution vulnerability that could allow attackers to execute malicious code by convincing users to open specially crafted compressed files. [...]
  - (2026-07-18) [BleepingComputer] WordPress Core "wp2shell" RCE flaws get public exploits, patch now
      Public exploits have been released for the critical "wp2shell" remote code execution vulnerabilities affecting WordPress Core, making it imperative that administrators patch their sites immediately. [...]
  - (2026-07-18) [BleepingComputer] Microsoft warns of surge in ACR Stealer attacks on customers
      Microsoft has observed a surge in attacks using the ACR Stealer malware to steal browser-stored passwords, authentication tokens, and sensitive documents from its enterprise customers. [...]
  - (2026-07-18) [BleepingComputer] The Future of Age Verification: Your Face Never Leaves Your Device
      As age verification laws expand worldwide, organizations face growing pressure to protect users' privacy while meeting regulatory requirements. Incode explains how on-device age estimation verifies age without transmitti…
  - (2026-07-18) [Ars Technica] Will AI fix prior authorization—or make it worse?
      The government is piloting a program that uses AI for insurance-coverage decisions.
  - (2026-07-18) [TechCrunch] Waymo says San Francisco service has resumed after one-hour pause
      This isn’t the first time power outages have caused issues for Waymo.

### GDACS — global disaster alerts — 7 new of 100 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-07-18) [Green] Earthquake in Scotia Sea
      Earthquake · Green alert · Scotia Sea · Magnitude 5.5M, Depth:10km
  - (2026-07-18) [Green] Earthquake in Scotia Sea
      Earthquake · Green alert · Scotia Sea · Magnitude 5.5M, Depth:10km
  - (2026-07-18) [Green] Earthquake in Mexico
      Earthquake · Green alert · Mexico · Magnitude 5.7M, Depth:10km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 34 total
  - (2026-07-18) MOVER ▼ Changpeng Zhao — $107.76B ($-0.39B since yesterday)
      Canada · Finance & Investments · source: Cryptocurrency exchange
  - (2026-07-18) MOVER ▼ Carlos Slim Helu & family — $125.21B ($-0.25B since yesterday)
      Mexico · Telecom · source: Telecom
  - (2026-07-18) MOVER ▲ Mukesh Ambani — $89.86B (+$0.07B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-18) MOVER ▲ Gautam Adani — $88.76B (+$0.07B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-18) [Marginal Revolution] Saturday assorted links
      1. How Roman concrete lasted for so long. 2. All restaurants in Germany are worthy of five stars? 3. They are making improvements to Refine. 4. New limits on graduate student visas? Should we/can we make the PhD three ye…
  - (2026-07-18) [Marginal Revolution] Trial Lawyers Lobby Against Autonomous Vehicles
      Roughly 37,000–40,000 Americans die in auto accidents every year. We now have large‑scale, real‑world evidence—from Waymo and a joint analysis with Swiss Re—that driverless operations can be substantially safer than matc…
  - (2026-07-18) [Marginal Revolution] What should I ask Luis Garicano?
      Yes I will be doing a Conversation with him. From Wikipedia: Luis Garicano Gabilondo (pronounced [ˈlwis ɣaɾiˈkano]; born 1967) is a Spanish economist and politician who was a Member of the European Parliament (MEP) from…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-18) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=22, 14d-median=22; carrying terms: security, published, species, whether, prompted, necessary, issuing, authorized, commission, being, proposing, change
- state_bills: today=138, 7d-median=70, 14d-median=70
- state_news: today=711, 7d-median=578, 14d-median=578; carrying terms: flags, updated, pregnancy, thousands, bubble, university, independence, receives, claims, affordability, products, occurred
- local_news: today=246, 7d-median=241, 14d-median=241; carrying terms: hospitalized, quite, university, products, health, underway, races, being, figure, cbmilwfbvv, river, content
- foreign_news: today=1024, 7d-median=1034, 14d-median=1034; carrying terms: flags, entire, operation, applied, thousands, suburban, buried, taiwan, tibet, announces, health, important
- chinese_internal: today=299, 7d-median=288, 14d-median=288; carrying terms: china, lxtfa, cbmidefvx, google, color, launch, cbmib, cbmix, cbmibefvx, industry, markets, market
- russian_internal: today=833, 7d-median=895, 14d-median=895; carrying terms: financial, insider, google, novayagazeta, intelligence, https, style, title, error, httperror, media, metals
- ukrainian_internal: today=138, 7d-median=136, 14d-median=136; carrying terms: hromadske, stability, warning, operation, deploying, claims, serhiy, talks, follow, officials, international, signs
- ukraine_theater: today=646, 7d-median=489, 14d-median=489; carrying terms: xyxzvfyxhuymvnbkjrufvsu, dvnht, nqzfjwjlmmemztwjottd, cmfyrwrrs, wkrxnjzud, bntdrsou, adlvcxv, zkezme, wnmntdkn, procured, ltvyrzfda, tghjsgu
- paper_bets: today=143, 7d-median=140, 14d-median=140; carrying terms: leave, determined, specified, house, succeed, jackson, security, world, experience, nebraska, colonize, diabetes
- weather: today=177, 7d-median=156, 14d-median=156; carrying terms: larimer, nickel, night, develop, updated, warning, heavy, smoke, threat, afdmfl, massachusetts, mountains
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: labor, indicator, funds, personal, jolts, sheet, dcoilwtico, unrate, money, headline, spread, energy
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crude, treasury, bitcoin, china, commodities, corporate, agriculture, rates, nasdaq, range, russell, equities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=115, 7d-median=114, 14d-median=114; carrying terms: union, compare, stability, description, operation, energy, university, independence, terrorism, claims, europa, occupation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiver, error, https, unauthorized, congresstrading, quiverquant, httperror, quantitative
- billionaires: today=34, 7d-median=33, 14d-median=33; carrying terms: michael, source, ellison, paris, amancio, spain, japan, hathaway, fashion, retail, telecom, infrastructure
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: services, california, energy, truck, association, robert, international, america, community, trade, rhode, blanche
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: chartered, michael, cooper, elect, lowden, house, action, david, filing, warner, platner, raised
- gdelt_regions: today=12, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=47, 7d-median=48, 14d-median=48; carrying terms: english, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: affecting, determined, pacific, mongbwalu, border, kerala, watery, avian, elements, announcing, leste, toxin
- cisa_kev: today=16, 7d-median=12, 14d-median=12; carrying terms: sharepoint, vendor, deserialization, improper, cisco, authentication, access, untrusted, forgery, control, injection, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=126, 14d-median=126; carrying terms: philippines, alert, slovakia, minor, germany, colombia, sweden, somalia, japan, earthquake, islands, guinea
- usgs_quakes: today=23, 7d-median=18, 14d-median=18; carrying terms: ridge, depth
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: advance, spain, meeting, resolves, world, volume, prime, interest, argentina, price, ethiopia, minister
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginalrevolution, https, marginal, economist, revolution, conversable, class
- tech_news: today=53, 7d-median=57, 14d-median=57; carrying terms: leadership, world, computerweekly, today, threat, misinformation, russia, careers, algorithm, international, linked, described
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: plaskett, mccaul, shreve, union, lankford, counsel, latta, affairs, duckworth, kweisi, boebert, delauro
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, module, today, identify, placement, paper, either, market, evidence, unavailable, decision, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*