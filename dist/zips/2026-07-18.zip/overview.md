# WORLDSCOPE morning brief — 2026-07-18

## Headline
2317 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (541) · Russian Internal News (state + in-exile) (354) · World leaders & government officials (324) · State Legislative Action (218) · Ukraine Theater (total-war monitoring) (199) · Chinese Internal News (177) · U.S. Weather + Severe / Climate Outlooks (124) · GDELT GKG — themes / entities / watch areas (66) · Local News: St. Louis + Atlanta (60) · Ukrainian Internal News (national + local Kyiv) (52) · State-Level News (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 541 new of 1041 total
  - (2026-07-18) [Global] India achieves milestone with launch of first private-sector orbital rocket
      PM Narendra Modi says successful launch will 'encourage countless youngsters to dream bigger and innovate fearlessly'.
  - (2026-07-18) [Global] India’s salt workers: The human cost of the world’s most popular seasoning
      101 East investigates the supply chain behind India’s booming salt industry.
  - (2026-07-18) [Global] Ukrainian drone attacks on Russia kill at least 8, wound dozens
      Russian officials say strikes on retailer's warehouses caused civilian casualties; Kyiv says sites used to make drones.
  - (2026-07-18) [Global] Indian police forcibly hospitalise activist after 20-day hunger strike
      Police said protesters tried to stop them from seizing Sonam Wangchuk, causing a 'slight commotion'.
  - (2026-07-18) [Global] Argentina’s New York fans share hopes before 2026 World Cup final
      Argentinians in Queens hold on to football tradition, as new communities grow support the national team in NYC.
  - (2026-07-18) [Global] Watch FIFA World Cup: Messi, Rodri comment ahead of Argentina-Spain final
      Latest match highlights, reaction and previews from the FIFA World Cup 2026 in North America.

### Russian Internal News (state + in-exile) — 354 new of 935 total
  - (2026-07-18) «Сгорела еще одна иллюзия, что кто-то защитит предпринимателя». Зачем Украина ударила по складам Wildberries? И почему компания не будет платить компенсации бизнесменам? | LEDE: В результате] (ru: «Сг…
      В результате атаки Украины на склады Wildberries в Подмосковье и Тамбовской области погибли уже восемь человек, еще больше 50 пострадали. Владимир Зеленский объяснил удары наличием в логистических центрах деталей для про…
  - (2026-07-18) FT: Зеленский рассматривает возможность отставки главкома ВСУ Александра Сырского | LEDE: Президент Украины Владимир Зеленский рассматривает вариант отправить в отставку главнокомандующего В] (ru: FT:…
      Президент Украины Владимир Зеленский рассматривает вариант отправить в отставку главнокомандующего ВСУ Александра Сырского, сообщает Financial Times со ссылкой на высокопоставленный источник в украинской администрации.
  - (2026-07-18) Россия атаковала торговое судно у берегов Одессы. Погиб один человек | LEDE: Российские войска нанесли массированный удар по портовой инфраструктуре Одесской области, сообщил глава областной] (ru: Рос…
      Российские войска нанесли массированный удар по портовой инфраструктуре Одесской области, сообщил глава областной администрации Олег Кипер.
  - (2026-07-18) Удар ВСУ по Wildberries. Фотографии и видео. В Подмосковье после удара по крупнейшему складу Wildberries в России все небо заволокло дымом. Его видно за 50 километров | LEDE: В ночь на 18 ию] (ru: Уда…
      В ночь на 18 июля украинские дроны атаковали два логистических центра Wildberries в Московской и Тамбовской областях. На складе в городе Котовске погибли семь человек, работавших в ночную смену, 25 пострадали. В Электрос…
  - (2026-07-18) «Она становится опасной для тех, кто в ней участвует». Борис Надеждин допустил, что приостановит избирательную кампанию | LEDE: Политик Борис Надеждин заявил, что в ближайшее время планирует] (ru: «Он…
      Политик Борис Надеждин заявил, что в ближайшее время планирует приостановить кампанию по сбору подписей для выдвижения на выборах в Госдуму. Об этом он рассказал в эфире The Breakfast Show.
  - (2026-07-18) Зеленский: на складах Wildberries, которые атаковала Украина, хранились комплектующие для дронов | LEDE: Президент Украины Владимир Зеленский прокомментировал атаку украинских беспилотников ] (ru: Зел…
      Президент Украины Владимир Зеленский прокомментировал атаку украинских беспилотников на склады Wildberries в Московской и Тамбовской областях. Он назвал это ответом на российские удары по гражданской инфраструктуре в Укр…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State Legislative Action — 218 new of 219 total
  - (2026-07-17) [Arizona SB 1010] Charlie Kirk highway
      Charlie Kirk highway
  - (2026-07-17) [Arizona SB 1803] veterans' benefits; claims; prohibition
      veterans' benefits; claims; prohibition
  - (2026-07-16) [Arizona HB 4027] Charlie Kirk highway.
      Charlie Kirk highway.
  - (2026-07-16) [Arizona SB 1474] immigration laws; local enforcement; training
      immigration laws; local enforcement; training
  - (2026-07-16) [Arizona SB 1670] municipalities; counties; occupation; licensure; prohibition
      municipalities; counties; occupation; licensure; prohibition
  - (2026-07-16) [Arizona HB 2049] radiation therapy; rural counties
      radiation therapy; rural counties

### Ukraine Theater (total-war monitoring) — 199 new of 490 total
  - (2026-07-18) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-17) [FIRMS] thermal anomaly 52.846, 29.987 (FRP 1.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 1.02 MW
  - (2026-07-17) [FIRMS] thermal anomaly 52.807, 32.219 (FRP 1.05 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 1.05 MW
  - (2026-07-17) [FIRMS] thermal anomaly 52.807, 32.224 (FRP 1.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 1.08 MW
  - (2026-07-17) [FIRMS] thermal anomaly 51.894, 29.332 (FRP 4.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 4.86 MW
  - (2026-07-17) [FIRMS] thermal anomaly 51.890, 29.326 (FRP 3.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-17 2259Z, FRP 3.97 MW

### Chinese Internal News — 177 new of 299 total
  - (2026-07-17) Chinese Politburo Member’s Downfall Exposes Shadowy Network Tied to Evergrande, Vanke - Caixin Global
      Chinese Politburo Member’s Downfall Exposes Shadowy Network Tied to Evergrande, Vanke Caixin Global
  - (2026-07-17) 习近平出席2026世界人工智能大会暨人工智能全球治理高级别会议开幕式并发表主旨讲话 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5rRTN0Zlo2c0pMaHUwZGhWWGNhZGJSOFZPTjJ1S0RaclVPSXlzVnp6YWlr] (zh:…
      习近平出席2026世界人工智能大会暨人工智能全球治理高级别会议开幕式并发表主旨讲话 politics.people.com.cn
  - (2026-07-18) 开局之年看中国 | “小快优”撬动大枢纽 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE00MG9US2lrTy0zWFJJUUZ4VVJnUFZNX21LLWc5U2tOQ3Y1d0JuSmg0eUlNNVp5a1hQVTYwaGo0WHloR3NVVUtFTTJtUllMdVJ2] (zh:…
      开局之年看中国 | “小快优”撬动大枢纽 人民网
  - (2026-07-18) 习近平会见泰国总理阿努廷 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFBhRnVSTWg5ZHFYNjAyTWFiTVdJM1pIWEVpR3ZCeTVvRmV0STJ3SHdsX0lkLXp2aTBCSFU4ZUsxc0xnYWQ0Tk9zOW15dFRoclRjMjZ] (zh:…
      习近平会见泰国总理阿努廷 中国共产党新闻网
  - (2026-07-17) 习近平出席2026世界人工智能大会暨人工智能全球治理高级别会议开幕式并发表主旨讲话 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTFBCU28xVVg0SkRMMU5rTnYyNEtfeVU0QS1jbnFLdkkySjhiRzA4Vi1PdFhJMnRrTTVjYW1McX] (zh:…
      习近平出席2026世界人工智能大会暨人工智能全球治理高级别会议开幕式并发表主旨讲话 中国共产党新闻网
  - (2026-07-18) 江西永修：蓝天碧水 田园如画 - 人民网江西 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5SdURzc09uRTFuUVZEQktfcUs4MENqNmxlTjFKNzM1S1NvRXBJQnRUMWdrNmRzRmQyc21iM0JORzZXcVRFakd2Z29NX2FWN3RnUm1C] (zh:…
      江西永修：蓝天碧水 田园如画 人民网江西

### U.S. Weather + Severe / Climate Outlooks — 124 new of 146 total
  - (2026-07-18) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-18) [Moderate] Special Weather Statement: Special Weather Statement issued July 18 at 8:22AM EDT by NWS State College PA
      At 821 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from Nanty-Glo to Portage to Windber. Movement was east at 30 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar…
  - (2026-07-18) [Severe] Red Flag Warning: Red Flag Warning issued July 18 at 5:11AM PDT until July 18 at 10:00PM PDT by NWS Pendleton OR
      ...BREEZY WINDS AND LOW RELATIVE HUMIDITY THROUGH SATURDAY EVENING... .Breezy diurnally driven westerly winds coupled with low relative humidity is expected to continue through the Lower Columbia Basin of Oregon each aft…
  - (2026-07-18) [Severe] Flood Warning: Flood Warning issued July 18 at 6:54AM CDT until July 21 at 4:06AM CDT by NWS Corpus Christi TX
      ...The Flood Warning is extended for the following rivers in Texas... Rio Grande At Laredo affecting Webb County. For the Rio Grande...including Columbia Bridge, Laredo...Major flooding is forecast. * WHAT...Moderate flo…
  - (2026-07-18) [Severe] Flood Warning: Flood Warning issued July 18 at 6:53AM CDT until July 20 at 4:50AM CDT by NWS Corpus Christi TX
      ...Forecast flooding changed from Moderate to Major severity and increased in duration for the following rivers in Texas... Rio Grande At Columbia Bridge affecting Webb County. For the Rio Grande...including Columbia Bri…
  - (2026-07-18) [Moderate] Heat Advisory: Heat Advisory issued July 18 at 7:50AM EDT until July 18 at 7:00PM EDT by NWS Baltimore MD/Washington DC
      * WHAT...Heat index values around 105 expected. * WHERE...Washington DC, and portions of central, northern, and southern Maryland, and central and northern Virginia. * WHEN...From 11 AM this morning to 7 PM EDT this even…

### GDELT GKG — themes / entities / watch areas — 66 new of 66 total
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Caso Eulália : Localizao de cadáver muda rumo de investigao e aponta para crime premeditado
      tnonline.uol.com.br · Portuguese · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Eight killed , over 60 injured in Ukrainian drone attacks on Russia
      orissapost.com · English · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] মার্কিন হামলার জবাবে ইরানের ব্যাপক পাল্টা আঘাত
      mzamin.com · Bengali · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Iran - US war latest : Iran strikes US ally Kuwait after Trump launches fresh bombing assault
      independent.co.uk · English · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] The U . S . and Iran blow past red lines as they lurch back toward all - out war
      kasu.org · English · tone NA
  - (2026-07-18) [Russia oil sanctions perimeter · themes] Mueren 8 personas en ataques con drones contra almacenes de comercio electrónico en Rusia
      ultimahora.es · Spanish · tone NA

### Local News: St. Louis + Atlanta — 60 new of 230 total
  - (2026-07-18) [St. Louis] Woman found dying in St. Louis street
      Officers found a woman in the street, unconscious and barely breathing with severe head injuries. She later died at the hospital.
  - (2026-07-18) [St. Louis] Why do soccer players walk out with kids?
      The tradition has been featured in every World Cup since 2002.
  - (2026-07-18) [St. Louis] Skeletal remains found near West Florissant in St. Louis
      Police said skeletal remains were found on Friday afternoon near West Florissant and Thrush avenues.
  - (2026-07-18) [St. Louis] US and Iran exchange strikes as they struggle over Strait of Hormuz
      The region has endured days of back-and-forth attacks in a conflict increasingly focused on control of the strait.
  - (2026-07-18) [St. Louis] Boil order issued for parts of Potosi due to water main break
      The city issued a 48-hour mandatory boil order for residents in affected areas.
  - (2026-07-18) [St. Louis] Who is the referee for World Cup final?
      It's the second straight World Cup final where Argentina will have a European referee to face a European opponent.

### Ukrainian Internal News (national + local Kyiv) — 52 new of 138 total
  - (2026-07-18) Росія двічі вдарила по локомотиву та пасажирських вагонах на Запоріжжі | LEDE: Російські війська завдали подвійного удару по локомотиву та пасажирських вагонах поїзда в Запорізькій області. За ] (uk:…
      Російські війська завдали подвійного удару по локомотиву та пасажирських вагонах поїзда в Запорізькій області. За попередніми даними, ніхто не постраждав.
  - (2026-07-18) У Чехії зіштовхнулися два автобуси: постраждали понад 30 людей | LEDE: ] (uk: У Чехії зіштовхнулися два автобуси: постраждали понад 30 людей)
  - (2026-07-18) Зеленський другий день поспіль зустрічається з командирами корпусів | LEDE: Зеленський провів нараду з командирами корпусів, обговорив ситуацію на фронті та анонсував спеціальну Ставку головнок] (uk:…
      Зеленський провів нараду з командирами корпусів, обговорив ситуацію на фронті та анонсував спеціальну Ставку головнокомандувача.
  - (2026-07-18) Звільнення Федорова, С-400 на Київ і пастка в Азовському морі – про війну за тиждень | LEDE: ] (uk: Звільнення Федорова, С-400 на Київ і пастка в Азовському морі – про війну за тиж)
  - (2026-07-18) Оністрат звільняється з армії через переведення, вважає це покаранням за підтримку Федорова | LEDE: Андрій Оністрат, засновник батальйону БПЛА, йде з ЗСУ після переведення у 17-й корпус.] (uk: Оністра…
      Андрій Оністрат, засновник батальйону БПЛА, йде з ЗСУ після переведення у 17-й корпус.
  - (2026-07-18) Генштаб повідомив про ураження, окрім нафтобази, танкерів та корабля "Светляк" | LEDE: У ніч на 18 липня Сили оборони уразили нафтобазу в Московській області, судна в Азовському та Чорному моря] (uk:…
      У ніч на 18 липня Сили оборони уразили нафтобазу в Московській області, судна в Азовському та Чорному морях, російський сторожовий корабель у Керчі та залізничний міст на окупованій Луганщині.

### State-Level News — 45 new of 697 total
  - (2026-07-18) [Alaska] Democrat throws support to independent running for Alaska’s U.S. House seat
      Matt Schultz, a Democrat running for Alaska’s sole U.S. House seat, suspended his campaign on Friday and threw his support to independent candidate Bill Hill. Schultz, an Anchorage pastor, released a statement urging “al…
  - (2026-07-18) [Alaska] Hilcorp killed Alaska LNG bill, some legislators say, but governor calls the claim ‘bulls**t’
      On Wednesday, one day before the Alaska Legislature voted on a multibillion-dollar tax break for the proposed trans-Alaska gas pipeline, Rep. Calvin Schrage, I-Anchorage, gave the pipeline’s lead developer a sneak previe…
  - (2026-07-17) [Alaska] Alaska state legislator chases bear away from fellow lawmaker outside state Capitol
      Rep. Garret Nelson, R-Sutton, chased a black bear away from Rep. Julie Coulombe, R-Anchorage, in front of the Alaska State Capitol during a late-night encounter this week. “It was a real safari night,” Nelson said on soc…
  - (2026-07-18) [Arkansas] Political parties boast new clout and cash in midterms thanks to US Supreme Court
      A recent U.S. Supreme Court decision makes it easier for political parties to put their stamp on the most important campaigns, just as the struggle heats up for control of Congress in the midterm elections. Simply put, t…
  - (2026-07-18) [Arizona] Judge hands Ohio’s former prisons chief sweeping control over Arizona prison healthcare
      A federal judge on Friday appointed Ohio’s former prisons chief to run Arizona’s prison healthcare system, giving her the sole power to determine what the state needs to do to stop violating the constitutional rights of…
  - (2026-07-17) [Arizona] GOP legislative leaders, Mayes to defend Arizona deportation law in court
      Republican legislative leaders and Attorney General Kris Mayes are on the same side in a lawsuit challenging the state’s power to enforce immigration law, playing defense for a 2024 law that would give state judges the a…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-18) [Langlois Sophia J.] Form 4 (Reporting)
      filed 2026-07-18 01:58 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084781 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:58 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084781 Size: 6 KB
  - (2026-07-18) [Yoskowitz Marc J] Form 4 (Reporting)
      filed 2026-07-18 01:57 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084780 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:57 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084780 Size: 6 KB
  - (2026-07-18) [Hirsch Scott] Form 4 (Reporting)
      filed 2026-07-18 01:57 UTC · role: Reporting — Filed: 2026-07-17 AccNo: 0001104659-26-084779 Size: 6 KB
  - (2026-07-18) [Keenova Therapeutics plc] Form 4 (Issuer)
      filed 2026-07-18 01:57 UTC · role: Issuer — Filed: 2026-07-17 AccNo: 0001104659-26-084779 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 23 new of 43 total
  - (2026-07-18) M 5.3 - 87 km WSW of Puerto Madero, Mexico
      M5.3 · 87 km WSW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-18) M 5.3 - 119 km SW of Sarangani, Philippines
      M5.3 · 119 km SW of Sarangani, Philippines · depth 10 km
  - (2026-07-18) M 5.2 - 69 km SW of Puerto Madero, Mexico
      M5.2 · 69 km SW of Puerto Madero, Mexico · depth 44.887 km
  - (2026-07-18) M 5.2 - south of the Kermadec Islands
      M5.2 · south of the Kermadec Islands · depth 10 km
  - (2026-07-18) M 5.1 - 99 km WSW of Puerto Madero, Mexico
      M5.1 · 99 km WSW of Puerto Madero, Mexico · depth 10 km
  - (2026-07-18) M 5.0 - 17 km SE of Malatya, Turkey
      M5.0 · 17 km SE of Malatya, Turkey · depth 10 km

### U.S. Federal Action — 14 new of 20 total
  - (2026-07-20) Action by the United States in the Investigation Under Section 301 of the Trade Act of 1974 of Brazil's Acts, Policies, and Practices Related to Digital Trade and Electronic Payment Services; Unfair,…
  - (2026-07-20) Drawbridge Operation Regulation; Newark Bay, Between the City of Newark and City of Bayonne, NJ
      The Coast Guard is modifying the operating regulation that governs the Lehigh Valley Drawbridge across Newark Bay, mile 4.6, between the City of Newark and City of Bayonne, NJ. This change in the regulation will not alte…
  - (2026-07-20) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Harpoon Category Fishery for 2026
      NMFS closes the Harpoon category fishery for large medium and giant (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length (CFL) or greater) Atlantic bluefin tuna (BFT) for the remainder of the 2026 fishing…
  - (2026-07-20) Safety Zones; Delaware River Dredging, Marcus Hook, PA
      The Coast Guard is establishing three temporary safety zones on the waters of the Delaware River, in portions of Marcus Hook Range, Anchorage 7, off Marcus Hook, PA, and Anchorage 9, near entrance to Mantua Creek. The sa…
  - (2026-07-20) Takes of Marine Mammals Incidental to Specified Activities; Taking Marine Mammals Incidental to Texas Parks and Wildlife Department Fisheries Research
      NMFS, upon request from Texas Parks and Wildlife Department (TPWD), is promulgating regulations to govern the taking of marine mammals incidental to fisheries research in the coastal bays of Texas over the course of 5 ye…
  - (2026-07-20) Food Standards of Identity Modernization; Pasteurized Orange Juice
      The Food and Drug Administration (FDA or we) is issuing a final rule to amend the standard of identity for pasteurized orange juice by lowering the minimum orange juice soluble solids content from 10.5[deg] to 10[deg] Br…

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 115 total
  - (2026-07-18) [USASpending] $17,319,586,106 → BECHTEL NATIONAL, INC.:
      Agency: Department of Energy. Description:
  - (2026-07-18) [USASpending] $1,402,874,932 → AUSTAL USA, LLC: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESI
      Agency: Department of Homeland Security. Description: OFFSHORE PATROL CUTTER (OPC) STAGE 2 CONTRACT: DETAILED DESIGN AND PRODUCTION (DD&P) OF 11 OPCS.
  - (2026-07-18) [USASpending] $798,366,385 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-18) [USASpending] $623,936,794 → LEIDOS, INC.: ESA V MANAGED SERVICES (ATF AND FCS)
      Agency: Department of Justice. Description: ESA V MANAGED SERVICES (ATF AND FCS)
  - (2026-07-18) [USASpending] $623,150,308 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-07-18) [USASpending] $521,824,443 → FOUR POINTS TECHNOLOGY, L.L.C.: ENTERPRISE CLOUD CAPACITY - AMAZON WEB SERVICES
      Agency: Department of Veterans Affairs. Description: ENTERPRISE CLOUD CAPACITY - AMAZON WEB SERVICES

### Paper Trading Scorecard — 10 new of 139 total
  - (2026-07-18) [Polymarket] Will England score the most goals at the 2026 FIFA World Cup?
      This market will resolve to the nation that records the most total goals through all rounds of the 2026 FIFA World Cup competition. In the event of a tie, this market will resolve according to the official leader as dete…
  - (2026-07-18) [Polymarket] Extended FDV above $1B one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Extended's token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token must be acti…
  - (2026-07-18) [Polymarket] Will Kendrick Lamar be the top artist for 2026?
      Spotify releases an annual report of its most streamed artist (see: https://newsroom.spotify.com/2025-12-03/wrapped-top-artists-songs-albums-podcasts-audiobooks/). This market refers to the most streamed Spotify artist f…
  - (2026-07-18) [Polymarket] Will MetaMask launch a token by September 30, 2026?
      This market will resolve to "Yes" if Metamask officially launches a token by September 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". The token must be actively and publicly transferable and tradable…
  - (2026-07-18) [Polymarket] Will Javier Milei win the 2027 Argentina presidential election?
      A presidential election scheduled to be held in Argentina on October 24, 2027. This market will resolve according to the listed candidate who wins the next Argentinian Presidential election. This market includes any pote…
  - (2026-07-18) [Manifold] Will there be a data center on the planet Mars by EOY 2076?

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-07-18) LoL: T1 vs Karmine Corp - Game 1 Winner
      yes price: 100% · 24h volume: $1,824,599 · resolves 2026-07-18
  - (2026-07-18) Will Hassan Shariatmadari be head of state in Iran end of 2026?
      yes price: 0% · 24h volume: $1,469,767 · resolves 2026-12-31
  - (2026-07-18) LoL: T1 vs Karmine Corp - Game 2 Winner
      yes price: 36% · 24h volume: $1,307,389 · resolves 2026-07-18
  - (2026-07-18) LoL: T1 vs Karmine Corp (BO3) - Esports World Cup Playoffs
      yes price: 82% · 24h volume: $1,123,916 · resolves 2026-07-18
  - (2026-07-18) Will the Fed decrease interest rates by 25 bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $991,188 · resolves 2026-07-29
  - (2026-07-18) Spain vs. Argentina: O/U 2.5
      yes price: 42% · 24h volume: $755,232 · resolves 2026-07-19

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-18) [South Korea] 로스엔젤레스 | 한국일보 전자신문
      epaper.koreatimes.com · English
  - (2026-07-18) [South Korea] Samsung launches The Freestyle+ portable projector in the US
      sammobile.com · English
  - (2026-07-18) [South Korea] [ Spoiler ] The Flower in Prison Jin Se - yeon inspiring act of being possessed
      hancinema.net · English
  - (2026-07-18) [South Korea] Kim Yoo Jung shocks fans with dramatic blonde transformation in stunning new photoshoot
      allkpop.com · English
  - (2026-07-18) [South Korea] Suzy stuns fans with striking new look in red dress
      allkpop.com · English
  - (2026-07-18) [South Korea] BT Jungkook stuns in new Graff campaign photos
      allkpop.com · English

### Court opinions of consequence (federal & state) — 3 new of 60 total
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Local 1374, Jefferson Parish v. Roberts
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Thompson v. McGehee
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: United States v. Kirkwood

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### GDACS — global disaster alerts — 3 new of 96 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-18) [Marginal Revolution] Trial Lawyers Lobby Against Autonomous Vehicles
      Roughly 37,000–40,000 Americans die in auto accidents every year. We now have large‑scale, real‑world evidence—from Waymo and a joint analysis with Swiss Re—that driverless operations can be substantially safer than matc…
  - (2026-07-18) [Marginal Revolution] What should I ask Luis Garicano?
      Yes I will be doing a Conversation with him. From Wikipedia: Luis Garicano Gabilondo (pronounced [ˈlwis ɣaɾiˈkano]; born 1967) is a Spanish economist and politician who was a Member of the European Parliament (MEP) from…
  - (2026-07-18) [Marginal Revolution] The small business boom
      Across the country, founders like Ms. Winkler are powering an entrepreneurial renaissance. Jump-started by the pandemic, when a confluence of factors including mass layoffs and remote work led to a flood of business crea…

### IT, InfoSys & cybersecurity news (last 7 days) — 2 new of 58 total
  - (2026-07-18) [The Register] NextBSD returns to dollop Apple source on FreeBSD
      New maintainer revives the project with Darwin components, Gershwin, and Claude Code
  - (2026-07-18) [TechCrunch] Neil Rimer thinks the AI money is coming back out
      Neil Rimer, the venture capitalist who co-founded Index Ventures, predicts the historic wealth AI is generating in Silicon Valley will have to be redistributed, voluntarily or involuntarily.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-18) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=22, 14d-median=22; carrying terms: whether, requires, protect, security, commission, authorized, amending, reporting, period, environment, coast, species
- state_bills: today=219, 7d-median=110, 14d-median=110
- state_news: today=697, 7d-median=571, 14d-median=571; carrying terms: idaho, immigration, complex, bring, hampshire, urges, costs, fined, applications, sister, problem, memphis
- local_news: today=230, 7d-median=233, 14d-median=233; carrying terms: investigating, races, saporta, historic, families, decoding, today, friday, opens, behind, cbmipgfbvv, lawsuit
- foreign_news: today=1041, 7d-median=1040, 14d-median=1040; carrying terms: antimissile, rescue, estimated, bring, ngjing, urges, groundup, seven, islands, exposing, applications, raping
- chinese_internal: today=299, 7d-median=288, 14d-median=288; carrying terms: beijing, cbmibefvx, gains, title, china, investors, cbmiyefvx, politics, cbmix, cbmiy, blank, cbmizkfvx
- russian_internal: today=935, 7d-median=922, 14d-median=922; carrying terms: forbidden, istories, europe, https, bloomberg, error, blank, google, gazeta, london, reuters, raquo
- ukrainian_internal: today=138, 7d-median=136, 14d-median=136; carrying terms: hybrid, odesa, interview, criticized, demanded, winning, sparks, service, figures, hours, missiles, called
- ukraine_theater: today=490, 7d-median=445, 14d-median=445; carrying terms: exhnznffove, dquzjlznvoeln, zmrwnvowhkc, otjrqn, cuxnumjista, yswvhcxrwbk, mvhkbljzq, cuxntu, sgrobvoyrzkwtmnpy, companies, demining, mjvowflbuw
- paper_bets: today=139, 7d-median=138, 14d-median=138; carrying terms: become, mamdani, koivun, president, manifold, point, humanoid, hampshire, general, cousins, rippling, lesswrong
- weather: today=146, 7d-median=146, 14d-median=146; carrying terms: moderate, bring, afdtbw, worth, afddtx, islands, center, around, memphis, afdffc, outdoor, conditions
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, unrate, dexjpus, labor, walcl, crude, dexchus, unemployment, effective, nonfarm, jtsjol, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, silver, range, proxy, china, rates, crude, treasury, russell, credit, agriculture, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=115, 7d-median=114, 14d-median=114; carrying terms: hybrid, president, dxlzz, events, satisfying, american, compare, articles, prohibited, activities, beirut, undermining
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, congresstrading, quiverquant, unauthorized, quiver, https, client, error, quantitative
- billionaires: today=30, 7d-median=31, 14d-median=31; carrying terms: commodities, microsoft, paris, amancio, masayoshi, giancarlo, zhang, francoise, gates, larry, thomas, googl
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: board, appeals, company, hernandez, general, energy, arizona, robert, trade, north, daimler, island
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, cooper, filing, committee, action, lindsey, sherrod, angels, david, jonathan, krishnamoorthi, elect
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=66, 7d-median=49, 14d-median=49; carrying terms: russian, english, trump
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: posting, fatality, distributed, ethiopian, detected, diarrhoea, polio, confirmation, available, intensive, unusual, point
- cisa_kev: today=16, 7d-median=12, 14d-median=12; carrying terms: remediation, microsoft, access, deserialization, product, bypass, cisco, vulnerability, injection, improper, server, untrusted
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=96, 7d-median=126, 14d-median=126; carrying terms: russia, minor, green, brazil, belarus, orange, storm, ethiopia, slovakia, magnitude, thailand, islands
- usgs_quakes: today=43, 7d-median=20, 14d-median=20; carrying terms: depth, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: england, france, interest, increase, ethiopia, presidential, prime, spain, minister, rates, argentina, price
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, https, marginal, economist, class, revolution
- tech_news: today=58, 7d-median=58, 14d-median=58; carrying terms: bleepingcomputer, worth, sectors, american, investigating, around, attack, companies, activities, observed, careers, targeting
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: gonzalez, moylan, coleman, filings, nikema, cliff, collins, president, chrissy, diana, kennedy, thanedar
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, placement, converges, either, placed, claude, consensus, decision, paper, module, evidence, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*