# WORLDSCOPE morning brief — 2026-11-08

## Headline
2420 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (691) · Russian Internal News (state + in-exile) (489) · World leaders & government officials (324) · Chinese Internal News (211) · U.S. Weather + Severe / Climate Outlooks (142) · Local News: St. Louis + Atlanta (98) · State-Level News (87) · Ukraine Theater (total-war monitoring) (73) · Ukrainian Internal News (national + local Kyiv) (57) · GDACS — global disaster alerts (57) · Conflict & unrest (GDELT, last 48h) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 691 new of 959 total
  - (2026-11-08) [Global] How African philosophies inspired a new approach to staging film festivals in Manchester
  - (2026-11-08) [Global] Pope’s visit to Argentina sets up showdown with ‘hyper-capitalist’ Milei
  - (2026-11-08) [Global] Banana producers in Latin America want better pay to cope with effects of climate crisis
  - (2026-11-08) [Global] Uyghurs facing deportation by Thailand say they will be ‘like slaves’ in China
  - (2026-11-08) [Global] NZ election 2026: New Zealand faces weeks of uncertainty with results ‘too close to call’
  - (2026-11-07) [Global] New Zealand election coalition talks will likely take weeks – as it happened

### Russian Internal News (state + in-exile) — 489 new of 818 total
  - (2026-11-08) Вы никогда не задумывались, почему бабочки такие красивые? Ведь это им вроде бы ни для чего не нужно. Ученые, кажется, нашли разгадку. И она связана с кораблями Первой мировой войны | LEDE: ] (ru: Вы…
      Глядя на махаона или даже простую крапивницу, задумываешься: зачем природа создала такое красивое существо? Привычные объяснения вроде камуфляжной окраски с бабочками не работают: ну на каком фоне можно спрятаться с тако…
  - (2026-11-08) На Китай-городе в Москве задержали сотни подростков. Их часами держали без воды, некоторых избили, другим вручили повестки. Главное | LEDE: Вечером 7 ноября полиция провела массовые задержан] (ru: На…
      Вечером 7 ноября полиция провела массовые задержания на Китай-городе. По наиболее популярным оценкам, всего задержали 150–200 человек (но есть сообщения и о 300), большинство из которых — молодые люди, в том числе несове…
  - (2026-11-08) Российские военные атаковали дроном спасателей, разбирающих завалы в Камышевахе. Там в результате удара РФ по убежищу погибли более 50 человек | LEDE: Российские военные атаковали дроном Кам] (ru: Рос…
      Российские военные атаковали дроном Камышеваху, где продолжается разбор завалов после авиаудара по убежищу, нанесенного войсками РФ 2 ноября. «Абсолютный цинизм и жестокость», — написал президент Украины Владимир Зеленск…
  - (2026-11-08) Хакеры, объявившие о взломе Росстата, утверждают, что в войне с Украиной погибли более 390 тысяч россиян | LEDE: Хакерские группировки «Киберпартизаны BY» и Silent Crow, заявившие, что им уд] (ru: Хак…
      Хакерские группировки «Киберпартизаны BY» и Silent Crow, заявившие, что им удалось взломать Росстат, сообщили, что в войне с Украиной погибли более 390 тысяч россиян к концу августа 2026 года.
  - (2026-11-08) «Годзилла минус ноль» — спорный сиквел лучшего фильма о гигантской ящерице. Больше монстров! Больше экшена! И меньше цельности | LEDE: В международном прокате — «Годзилла минус ноль», продол] (ru: «Го…
      В международном прокате — «Годзилла минус ноль», продолжение фильма «Годзилла минус один», который принес франшизе о монстре первый за ее 70-летнюю историю «Оскар» (за лучшие визуальные эффекты). Впрочем, запомнился япон…
  - (2026-11-08) Математик Азат Мифтахов, находящийся в российской колонии, стал почетным гражданином Сен-Дени | LEDE: Российскому политзаключенному Азату Мифтахову присвоено звание почетного гражданина Сен-] (ru: Мат…
      Российскому политзаключенному Азату Мифтахову присвоено звание почетного гражданина Сен-Дени. Об этом было объявлено 7 ноября на встрече в поддержку Мифтахова, организованной мэром Сен-Дени Балли Багайоко, сообщает телег…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 211 new of 286 total
  - (2026-11-08) 最后一位开国将军王扶之逝世，享年104岁 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE5LQWtlRDExUnFjREpjX2dIczc1dDAzRjBGTmQtYlYxUXFZVFlpdjVxeW9TQ3pyM3NyQ1hKM1lkUEgwT1E5N2hoY2JwWUhGNXN] (zh:…
      最后一位开国将军王扶之逝世，享年104岁 观察者网
  - (2026-11-08) 现在群众不看电视的原因难道只是由于开机广告？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBhaWtzZmJwS0dyR0xBdkxzQ2F1Q3AzQWRRUXRKX1RXcEtvaXVNQVNqeld5UnF0eXVKU3JVX1ZiaHY0RDk1M2ZFamlncnROeFF] (zh:…
      现在群众不看电视的原因难道只是由于开机广告？ 风闻
  - (2026-11-08) 进博会"朋友圈"不断扩容 周密：凝聚长期合作共识 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1wYTlVOVdnXzl4QUpIOWxPXzA5TXhJcGpWZ3FMZlBYdjlfVUY4NVVVZU10b0tvVXh2ZkVETVZGWVVZdkRXOHJZbDZ6OTJ] (zh:…
      进博会"朋友圈"不断扩容 周密：凝聚长期合作共识 观察者网
  - (2026-11-08) 厨师长分享现场版“火爆腰花”，急火短炒，一锅成菜 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5ZamdFUnVqeG1tWGtVRWczMXdlcEphRm9HbHlKMUZSN2ROblRJQVdkVzJzVHlDaFBNZ19zV3BmYVN6S3RicVdCU3lmUkt3c] (zh:…
      厨师长分享现场版“火爆腰花”，急火短炒，一锅成菜 风闻
  - (2026-11-07) 两岸最近距离：金门马山望祖国大陆 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1OcGxOZmNYN3c2U1NhOEh2MDVxNTVUWWVFQnZLam81LTg4V1VOVW1FWElBMlkzbGZQSVhfdUpDeG5uUVlYdm5oRjlleUNhejlaWDJGV] (zh:…
      两岸最近距离：金门马山望祖国大陆 风闻
  - (2026-11-08) 中央组织部负责人就党的二十一大代表选举工作答记者问 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMidkFVX3lxTFAxYlkxTFVtQThIanJfcm12cC01TV8yQjdHOXZBR1NVaEN2cDI0UDI5SHdvaWZQRUh2RTI0RmdNTEJEeE9kWGN5NEF5UD] (zh:…
      中央组织部负责人就党的二十一大代表选举工作答记者问 观察者网

### U.S. Weather + Severe / Climate Outlooks — 142 new of 144 total
  - (2026-11-08) [Moderate] Gale Warning: Gale Warning issued November 8 at 4:25AM AKST until November 9 at 5:00PM AKST by NWS Juneau AK
      Southeast Alaska Inside Waters from Dixon Entrance to Skagway Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and…
  - (2026-11-08) [Moderate] Gale Warning: Gale Warning issued November 8 at 4:25AM AKST until November 9 at 5:00PM AKST by NWS Juneau AK
      Southeast Alaska Inside Waters from Dixon Entrance to Skagway Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and…
  - (2026-11-08) [Moderate] Gale Warning: Gale Warning issued November 8 at 4:25AM AKST until November 9 at 5:00PM AKST by NWS Juneau AK
      Southeast Alaska Inside Waters from Dixon Entrance to Skagway Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and…
  - (2026-11-08) [Moderate] Gale Warning: Gale Warning issued November 8 at 4:25AM AKST until November 9 at 5:00PM AKST by NWS Juneau AK
      Southeast Alaska Inside Waters from Dixon Entrance to Skagway Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and…
  - (2026-11-08) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-08) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 8 at 8:20AM EST until November 8 at 9:00AM EST by NWS Tallahassee FL
      * WHAT...Visibility of a quarter mile or less in dense fog. * WHERE...Colquitt and Worth Counties. * WHEN...Until 9 AM EST this morning. * IMPACTS...Low visibility could make driving conditions hazardous.

### Local News: St. Louis + Atlanta — 98 new of 229 total
  - (2026-11-08) [St. Louis] Pedestrian fatally struck on I-70 in St. Charles County
      An O'Fallon man died after being struck by a pickup truck early Sunday while standing in the roadway on westbound I-70, troopers said.
  - (2026-11-08) [St. Louis] Motorcyclist killed in crash with tree in Jefferson County
      A 70-year-old motorcyclist died after crashing into a tree Saturday afternoon on Route 21, troopers said.
  - (2026-11-08) [St. Louis] Silex alderman arrested in connection with kidnapping, domestic assault investigation
      William Michael “Billy” Holcomb was being held without bond on first-degree domestic assault and second-degree kidnapping, according to the sheriff’s office.
  - (2026-11-08) [St. Louis] Charges filed against man who exchanged gunfire with Jefferson County deputies and fled to St. Louis
      The St. Louis Circuit Attorney's Office filed charges against Denzell Reed, which include two counts of first-degree assault and two counts of armed criminal action.
  - (2026-11-08) [St. Louis] Gourmia recalls air fryers nationwide after dozens of reported burns
      Gourmia recalled an estimated 175,951 of their air fryer ovens after getting dozens of customers reporting burns when using the product.
  - (2026-11-08) [St. Louis] Endangered SILVER Advisory canceled after 75-year-old woman missing out of Franklin County found safe
      The Franklin County Sheriff's Office issued an update shortly after 6:45 p.m. that the woman was found safe.

### State-Level News — 87 new of 418 total
  - (2026-11-08) [Connecticut] Data shows little change in CT housing voucher segregation
      <img width="1024" height="797" src="https://ctmirror.org/wp-content/uploads/2026/09/VOUCHER-SEGREGATION-0908-SG-03-1024x797.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-11-08) [Connecticut] CT transit: The good, bad and unfinished
      <img width="600" height="335" src="https://ctmirror.org/wp-content/uploads/2026/11/union-station-pipe-dream.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy"…
  - (2026-11-08) [Arkansas] America has lost roughly 4 in 10 cattle ranches since 1978
      The U.S. is facing a historic cattle shortage that is pushing beef prices to record highs. Years of drought throughout the Midwest have degraded pastures, forcing ranchers to sell more of their cattle rather than retain…
  - (2026-11-08) [Arkansas] GOP Congress faces funding deadline, farm bill, lengthy to-do list in year-end session
      WASHINGTON — Voters may have given Democrats control of Congress in the midterm elections, but Republicans will remain in charge of both chambers during the lame-duck session that spans November and December. The relativ…
  - (2026-11-08) [Arkansas] Republicans were punished in the midterms for Trump’s economic policies, The AP Voter Poll shows
      WASHINGTON (AP) — President Donald Trump was publicly humbled by inflation in the midterm elections, as rising prices provoked a blistering set of losses for Republicans in House, Senate and gubernatorial races. Most vot…
  - (2026-11-08) [Hawaii] The Sunshine Blog: How Low Can We Go?

### Ukraine Theater (total-war monitoring) — 73 new of 269 total
  - (2026-11-08) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-06) [Liveuamap] Fires reported near the military plant in Oryol – Oryol,Orlovskaya oblast&039 - Liveuamap
      Fires reported near the military plant in Oryol – Oryol,Orlovskaya oblast&039 Liveuamap
  - (2026-11-06) [Liveuamap] Myanmar latest news in English on live map - Rohingya genocide - myanmar.liveuamap.com - Liveuamap
      Myanmar latest news in English on live map - Rohingya genocide - myanmar.liveuamap.com Liveuamap
  - (2026-10-31) [Liveuamap] The Saudi coalition says it intercepted two Houthi drones yesterday, one over the oil rich Eastern Province and another in the Southern Region - Liveuamap
      The Saudi coalition says it intercepted two Houthi drones yesterday, one over the oil rich Eastern Province and another i
  - (2026-11-03) [Liveuamap] Israel&039;s Defense Ministry tells @kann_news: "We were surprised by the president&039;s statements, especially today. We are in ongoing talks with the Americans. We will study the implic…
      Israel&039;s Defense Ministry tells @kann_news: "We were surprised by the president&039;s statements, esp
  - (2026-11-07) [Liveuamap] The United Arab Emirates helped fund and train Colombian mercenaries who fought with a Sudanese paramilitary force accused of war crimes and genocide, a recent United Nations report found…
      The United Arab Emirates helped fund and train Colombian mercenaries who fought with a Sudanese paramilitary force a

### Ukrainian Internal News (national + local Kyiv) — 57 new of 132 total
  - (2026-11-08) Франція долучиться до переговорів України, США та Росії в Абу-Дабі – міністр | LEDE: Жан-Ноель Барро заявив, що Франція буде брати участь у тристоронніх переговорах з Україною, США та Росією що] (uk:…
      Жан-Ноель Барро заявив, що Франція буде брати участь у тристоронніх переговорах з Україною, США та Росією щодо війни в Абу-Дабі.
  - (2026-11-08) США розповіли про удар по судну, яке намагалося обійти блокаду Ірану | LEDE: ] (uk: США розповіли про удар по судну, яке намагалося обійти блокаду Ірану)
  - (2026-11-08) На Хмельниччині через атаку РФ є постраждалі, зруйновано й пошкоджено будинки | LEDE: У Хмельницькому районі через обстріл зруйновано будинок, ще 12 пошкоджено, постраждали двоє людей. Пожежу л] (uk:…
      У Хмельницькому районі через обстріл зруйновано будинок, ще 12 пошкоджено, постраждали двоє людей. Пожежу ліквідували рятувальники.
  - (2026-11-08) Сили оборони уразили 4 пункти управління БпЛА в Росії й на окупованих територіях | LEDE: ЗСУ знищили пункти управління дронами армії РФ у Бердянську, на Херсонщині, Донеччині та Брянщині. Втрат] (uk:…
      ЗСУ знищили пункти управління дронами армії РФ у Бердянську, на Херсонщині, Донеччині та Брянщині. Втрати ворога уточнюються.
  - (2026-11-08) Трамп хоче розслідувань "погроз" від демократів, які націлилися на його адміністрацію | LEDE: ] (uk: Трамп хоче розслідувань "погроз" від демократів, які націлилися на його адмініст)
  - (2026-11-08) У регіонах зі співробітників СБУ збирають по 50-150 тисяч на заставу Дуці – джерела | LEDE: У регіонах із працівників СБУ вимагають перерахувати кошти на заставу Сергію Дуці, якого підозрюють у] (uk:…
      У регіонах із працівників СБУ вимагають перерахувати кошти на заставу Сергію Дуці, якого підозрюють у справі "Карфаген".

### GDACS — global disaster alerts — 57 new of 100 total
  - (2026-11-08) [Green] Earthquake in Southwest Indian Ridge
      Earthquake · Green alert · Southwest Indian Ridge · Magnitude 4.7M, Depth:10km
  - (2026-11-08) [Green] Earthquake in Chile
      Earthquake · Green alert · Chile · Magnitude 4.7M, Depth:68.785km
  - (2026-11-08) [Green] Earthquake in Off East Coast Of Honshu, Japan
      Earthquake · Green alert · Off East Coast Of Honshu, Japan · Magnitude 4.7M, Depth:10km
  - (2026-11-08) [Green] Earthquake in Dominican Republic
      Earthquake · Green alert · Dominican Republic · Magnitude 4.5M, Depth:30.424km
  - (2026-11-08) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 4.5M, Depth:10km
  - (2026-11-07) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 7322 ha

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-08) [United States] Trump grip on GOP questioned after midterms | The Arkansas Democrat - Gazette
      domain: arkansasonline.com · language: English · tone:
  - (2026-11-08) [United States] In Maine , a new approach to practicing medicine in the sky
      domain: wkyufm.org · language: English · tone:
  - (2026-11-08) [United Kingdom] Briton among dead in Poland terror attack as suspect family bodies found
      domain: cravenherald.co.uk · language: English · tone:
  - (2026-11-08) [United Kingdom] Andy Burnham plots new ban for supermarkets - millions of products affected ( edited ) | united kingdom | News
      domain: express.co.uk · language: English · tone:
  - (2026-11-08) [United Kingdom] King leads nation in honouring the fallen at Cenotaph on Remembrance Sunday
      domain: eadt.co.uk · language: English · tone:
  - (2026-11-08) [Israel] Ben - Gvir blasts police leadership , alleges cover - up of election interference
      domain: israelnationalnews.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 23 new of 24 total
  - (2026-11-08) JAF7521 (Bulgaria)
      icao24: 4520aa · position: (48.7095, 2.3054) · alt: 243m · 259km/h
  - (2026-11-08) CFC3423 (Canada)
      icao24: c2c36d · position: (11.3985, -61.594) · alt: 3840m · 604km/h
  - (2026-11-08) CFC2922 (Canada)
      icao24: c2b5cb · position: (54.4569, -3.0858) · alt: 7315m · 552km/h
  - (2026-11-08) SAMU13 (France)
      icao24: 39c90b · position: (43.4598, 5.378) · alt: 335m · 220km/h
  - (2026-11-08) CFC2527 (Canada)
      icao24: c2b585 · position: (55.4551, -4.8171) · alt: 396m · 378km/h
  - (2026-11-08) JAF9LJ (Belgium)
      icao24: 44d1a7 · position: (45.8669, 0.1945) · alt: 10668m · 816km/h

### Prediction Markets — most-traded (Polymarket) — 18 new of 20 total
  - (2026-11-08) Will Chelsea FC win on 2026-11-08?
      yes price: 42% · 24h volume: $6,156,052 · resolves 2026-11-08
  - (2026-11-08) Will SSC Napoli win on 2026-11-08?
      yes price: 0% · 24h volume: $772,698 · resolves 2026-11-08
  - (2026-11-08) Giants vs. Eagles
      yes price: 58% · 24h volume: $752,032 · resolves 2026-11-08
  - (2026-11-08) Will FC Barcelona win on 2026-11-08?
      yes price: 48% · 24h volume: $722,307 · resolves 2026-11-08
  - (2026-11-08) LoL: Bilibili Gaming vs T1 (BO5) - Worlds Playoffs
      yes price: 56% · 24h volume: $586,677 · resolves 2026-11-09
  - (2026-11-08) Will SS Lazio win on 2026-11-08?
      yes price: 0% · 24h volume: $561,780 · resolves 2026-11-08

### Paper Trading Scorecard — 16 new of 66 total
  - (2026-11-08) [Polymarket] Will Texas Longhorns win the 2027 CFP National Championship?
      This market will resolve to "Yes" if the listed club is determined as the national champion of the 2026-27 College Football Playoff. Otherwise, it will resolve to "No". If at any point it becomes impossible for a listed…
  - (2026-11-08) [Manifold] Big AARUSH results within 1 year
  - (2026-11-08) [Manifold] Is Elliot's proof that ℤ is Diophantine in ℚ correct?
  - (2026-11-08) [Manifold] Will Caleb Williams throw for at least 250 yards on sunday night football against Tampa bay?
  - (2026-11-08) [Manifold] Will SP500 close at 7500.00 or more between Nov 9 and Nov 30 2026
  - (2026-11-08) [Manifold] Daily Coinflip

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-07) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046709
  - (2026-11-07) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046727
  - (2026-11-07) [F2] PAPPAS, CHRIS
      cycle 2026 · filing #2046706
  - (2026-11-07) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046713
  - (2026-11-07) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2046728
  - (2026-11-07) [F2] IBRAHIM, MOHAMMED SALMAN IBRAHIM
      cycle 2026 · filing #2046722

### USGS earthquakes (M4.5+, past day) — 15 new of 15 total
  - (2026-11-07) M 5.8 - central Mid-Atlantic Ridge
      M5.8 · central Mid-Atlantic Ridge · depth 10 km
  - (2026-11-07) M 5.5 - 10 km NW of Hamakita, Japan
      M5.5 · 10 km NW of Hamakita, Japan · depth 38.081 km
  - (2026-11-07) M 5.1 - 91 km ENE of Hihifo, Tonga
      M5.1 · 91 km ENE of Hihifo, Tonga · depth 10 km
  - (2026-11-07) M 4.9 - 41 km WSW of Gadung, Philippines
      M4.9 · 41 km WSW of Gadung, Philippines · depth 607.007 km
  - (2026-11-07) M 4.9 - 77 km NNW of Khorixas, Namibia
      M4.9 · 77 km NNW of Khorixas, Namibia · depth 8.035 km
  - (2026-11-08) M 4.7 - Southwest Indian Ridge
      M4.7 · Southwest Indian Ridge · depth 10 km

### World News (by country, top stories) — 11 new of 11 total
  - (2026-11-08) [South Korea] Osmanthus ? Meet Korea trending seasonal scent
      koreaherald.com · English
  - (2026-11-08) [Germany] EQS - PVR : Adtran Holdings , Inc .: Release according to Article 40 , Section 1 of the WpHG [ the German Securities Trading Act ] with the objective of Europe - wide distribution
      finanznachrichten.de · English
  - (2026-11-08) [Germany] Funky Taurus Media - Music Photo Agency & Products - Funky Taurus & George Clinton - UFO Brooklyn
      funkytaurusmedia.com · English
  - (2026-11-08) [Germany] Poland begins two days of mourning over Krakow shooting
      dw.com · English
  - (2026-11-08) [Germany] Never Again !: Holocaust remembrance under pressure
      dw.com · English
  - (2026-11-07) [South Korea] Labor Minister vows zero tolerance on repeated workplace accidents
      koreaherald.com · English

### IT, InfoSys & cybersecurity news (last 7 days) — 11 new of 61 total
  - (2026-11-08) [The Register] Doom delivers five minutes of terminal violence on an IBM mainframe
      Browser demo renders the classic shooter in ASCII, with no login required and considerable squinting encouraged
  - (2026-11-08) [The Register] Internet governance about to get its quadrennial stress test at ITU meeting
      278 proposals on table, and some fear they might shift power to governments
  - (2026-11-08) [Ars Technica] Physicists listened to electrical noise to crack a superconductor mystery
      Tuning in to electronic noise can tell us whether electrons have paired up or not.
  - (2026-11-07) [BleepingComputer] Hackers pull off $133 million French bank heist via service provider
      French cooperative bank Crédit Mutuel Arkéa was targeted in a cyberattack that enabled fraudulent transactions of up to $133 million, forcing it to respond by suspending certain systems.v [...]
  - (2026-11-07) [BleepingComputer] CTM360 Exposes Fake Gift Card Scams Exploiting Trusted Brands
      Scammers are impersonating major brands and celebrities to lure consumers into fake gift card giveaways that collect personal information and trigger unwanted subscriptions. CTM360 reveals how these campaigns use decepti…
  - (2026-11-07) [The Register] Fireworks says you’re wasting money on AI unless you’re using all the models
      The case for managed inference, or automatically routing queries to the right model for the right job

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-11-07) U.S. Court of Appeals, 5th Cir.: United States v. Barrett
  - (2026-11-04) Colorado Supreme Court: In Re The People of the State of Colorado v. Michael Martin Clark
  - (2026-11-02) U.S. Court of International Trade: American All. for Solar Mfg. Trade Comm. v. United States
  - (2026-11-02) U.S. Court of Appeals, 4th Cir.: Sintia Nivar Santana v. Todd Blanche
  - (2026-11-02) U.S. Court of Appeals, 2nd Cir.: Murray v. Newrez LLC & PHH Mortgage Corporation
  - (2026-11-02) U.S. Court of Appeals, 1st Cir.: Grygiel v. HealthEquity, Inc.

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-11-08) [Marginal Revolution] The Pope probably knows this song
      The post The Pope probably knows this song appeared first on Marginal REVOLUTION.
  - (2026-11-08) [Marginal Revolution] What I’ve been reading
      1. Fredrik deBoer, All in Your Head: Illness as Identity, Trauma as Fashion, and the Desire to be Disordered. A good book, I am happy to see positions laid out so clearly and starkly. Is this a radical view, or the mains…
  - (2026-11-07) [Marginal Revolution] Saturday assorted links
      1. Simon Winchester, RIP (NYT). 2. Pork roll vs. Taylor Ham, a NJ map. 3. Those new service sector jobs, Bradford edition. 4. “New assessment of the greatest of all time: Antarctic blue whales, showing how whaling reduce…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-08) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=26, 7d-median=25, 14d-median=16; carrying terms: safety, regulatory, commission, certain, final, action, document, proposed, necessary, published, provide, procedures
- state_bills: today=63, 7d-median=90, 14d-median=90; carrying terms: alaska, review, providing, vehicle, insurance, relating, emergency, property, election, address, county, access
- state_news: today=418, 7d-median=675, 14d-median=675; carrying terms: faces, virginia, found, level, majority, expand, supreme, center, connecticut, access, candidate, centers
- local_news: today=229, 7d-median=256, 14d-median=256; carrying terms: found, journal, atlantamagazine, friday, county, football, louis, being, against, public, business, announced
- foreign_news: today=959, 7d-median=992, 14d-median=992; carrying terms: indonesia, march, found, equity, launched, timesofisrael, beijing, evening, clearfix, supreme, child, football
- chinese_internal: today=286, 7d-median=334, 14d-median=294; carrying terms: cbmic, title, cbmiy, cbmickfvx, https, cbmizkfvx, global, google, cbmix, cbmia, cbmiakfvx, lxtfb
- russian_internal: today=818, 7d-median=938, 14d-median=946; carrying terms: gazeta, https, found, times, novayagazeta, journal, forbidden, server, reuters, laquo, street, bloomberg
- ukrainian_internal: today=132, 7d-median=139, 14d-median=131; carrying terms: region, found, launched, critical, struck, peace, hmarochos, poland, winter, injured, nearly, negotiations
- ukraine_theater: today=269, 7d-median=269, 14d-median=342; carrying terms: aknsvgvpmnk, hyekptsxniwujkdmt, bomugxvk, rekttnpotvjjtzvzr, fryjlqbwduehhtwg, zotlir, march, tfuutkx, plbjkttu, jjvgnycxjibzdf, cbmiwefvx, jkbvlvnkgxz
- paper_bets: today=66, 7d-median=66, 14d-median=65; carrying terms: human, season, office, mamdani, regular, state, mbappe, russell, manifold, israel, degrees, named
- weather: today=144, 7d-median=103, 14d-median=130; carrying terms: visibility, swell, southeast, changed, hazardous, weekend, additional, continue, afdtbw, front, around, times
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unemployment, consumption, dexchus, supply, dexuseu, spread, crude, cpilfesl, funds, money, dcoilwtico, commodities
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, rates, crude, proxy, silver, range, equities, credit, bitcoin, crypto, commodities, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=97, 14d-median=102; carrying terms: support, mtjwwxz, cbmiqkfvx, amended, xskfisuh, transactions, related, jjmudpzw, detect, prior, homeland, ambassador
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quiver, error, https, httperror, congresstrading, quantitative, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, international, supreme, appeals, company, alabama, connecticut, blanche, secretary, florida, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, holdings, michael, franklin, scott, david, craig, holding
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, warner, booker, cortez, trone, jonathan, krishnamoorthi, jackson, senate, talarico, david
- gdelt_regions: today=11, 7d-median=3, 14d-median=3
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: spanish, english, sanctions, themes, chinese, russia, perimeter, turkish, romanian, greek, russian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=24, 7d-median=30, 14d-median=30; carrying terms: kingdom, belgium, position, france, germany, ground, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: plague, region, number, tshopo, september, mongbwalu, complete, critically, continued, update, resulting, source
- cisa_kev: today=13, 7d-median=14, 14d-median=17; carrying terms: product, authentication, request, secure, edition, remediation, software, vendor, vulnerability, improper, cisco, state
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: alert, forestfire, fires, cyclone, green, earthquake, magnitude, australia, tropical, forest, depth, speed
- usgs_quakes: today=15, 7d-median=11, 14d-median=15; carrying terms: depth, japan, region, indonesia, philippines, ridge, indian, panama, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, election, presidential, israel, power, prime, minister, benjamin, netanyahu, shakhtar
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, revolution, marginal, class, economist, conversable, being, marginalrevolution, economic, economists, published, economics
- tech_news: today=61, 7d-median=61, 14d-median=57; carrying terms: download, blogging, critical, friday, products, group, exploitation, cybersecurity, world, security, hacker, schneier
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: warner, scanlon, dusty, guest, norcross, debbie, huizenga, harshbarger, george, nikema, loudermilk, knott
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, markets, placement, claude, sufficient, consensus, market, evidence, paper, identify, placed, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*