# WORLDSCOPE morning brief — 2026-09-11

## Headline
3832 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (780) · Russian Internal News (state + in-exile) (704) · Ukraine Theater (total-war monitoring) (623) · State-Level News (428) · World leaders & government officials (324) · Chinese Internal News (235) · Local News: St. Louis + Atlanta (224) · U.S. Weather + Severe / Climate Outlooks (103) · State Legislative Action (81) · Ukrainian Internal News (national + local Kyiv) (62) · IT, InfoSys & cybersecurity news (last 7 days) (43) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 780 new of 993 total
  - (2026-09-11) [Global] Anthropic blocks possible attempt to use AI to make biological weapons
      The revelations in Anthropic's threat intelligence report come after a former top researcher at the company warned of the risks of AI to humanity.
  - (2026-09-11) [Global] Hong Kong's Tiananmen activists sentenced to up to seven years in prison
      Hong Kong used to be one of the only places in Chinese territory where people could gather to mark the 1989 crackdown.
  - (2026-09-11) [Global] Israel says it has destroyed major underground Hezbollah base
      The powerful blast registered as the equivalent of a magnitude 4.1 earthquake, according to the US Geological Survey.
  - (2026-09-11) [Global] Buddhist monk arrested in suspected $3m embezzlement scandal
      Thai police also arrested a suspected female accomplice with whom the monk, who had taken a vow of celibacy, was filmed having sex.
  - (2026-09-11) [Global] Princess Diana's 'revenge dress' goes up for auction
      Auction house Sotheby's expects the dress to sell for up to $300,000 (£220,000) when it goes under the hammer on 9 December.
  - (2026-09-11) [Global] Philippine rescuers board ferry 40 hours after blaze began
      Thick, toxic fumes and extreme temperatures pose a challenge to rescuers who have boarded the ship.

### Russian Internal News (state + in-exile) — 704 new of 1130 total
  - (2026-09-11) Война. 1661-й день. Чиновников в США воодушевили слухи, что переговоры с Россией и Украиной возглавит директор ЦРУ. «Братан, возвращайся домой», — говорят они Уиткоффу | LEDE: «Медуза» с 24 ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-11) OpenAI готова замедлить разработку своих ИИ-моделей. Исследователи стали все чаще предупреждать о рисках чрезмерно быстрого развития нейросетей | LEDE: Компания OpenAI (разработчик ChatGPT) ] (ru: Ope…
      Компания OpenAI (разработчик ChatGPT) готова снизить темпы разработки своих наиболее продвинутых систем искусственного интеллекта. Об этом глава компании Сэм Альтман сообщил во время встречи с сотрудниками на этой неделе…
  - (2026-09-11) Список «Яблока» сняли с выборов в предпоследнем регионе. Осталась только Новгородская область | LEDE: Томский областной суд отменил регистрацию списка партии «Яблоко» на выборах в законодате] (ru: Спи…
      Томский областной суд отменил регистрацию списка партии «Яблоко» на выборах в законодательную думу области по иску ЛДПР.
  - (2026-09-11) Украинские беспилотники атаковали химкомбинат «Азот» в Пермском крае. Его продукцию используют при производстве взрывчатки | LEDE: Утром 11 сентября украинские беспилотники атаковали Пермски] (ru: Укр…
      Утром 11 сентября украинские беспилотники атаковали Пермский край. Под удар попали промышленные объекты, сообщил губернатор Дмитрий Махонин, не уточнив, о каких предприятиях идет речь.
  - (2026-09-11) ЦБ впервые с 2025 года не стал снижать ключевую ставку. Она осталась на уровне 14% | LEDE: Центробанк России впервые за последние полтора года не стал снижать ключевую ставку. По итогам засе] (ru: ЦБ…
      Центробанк России впервые за последние полтора года не стал снижать ключевую ставку. По итогам заседания Совета директоров принято решение сохранить ее на уровне 14%.
  - (2026-09-11) Российские войска атаковали две АЗС в Киеве. По одной из них ударили дважды. Есть погибшие и пострадавшие — в том числе спасатель | LEDE: Российские войска атаковали две АЗС — в Днепровском ] (ru: Рос…
      Российские войска атаковали две АЗС — в Днепровском и Оболонском районах Киеве, сообщил глава города Виталий Кличко.

### Ukraine Theater (total-war monitoring) — 623 new of 776 total
  - (2026-09-10) [FIRMS] thermal anomaly 52.805, 32.225 (FRP 1.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-10 0026Z, FRP 1.53 MW
  - (2026-09-10) [FIRMS] thermal anomaly 52.531, 33.040 (FRP 0.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-10 0026Z, FRP 0.37 MW
  - (2026-09-10) [FIRMS] thermal anomaly 52.847, 29.993 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-10 0026Z, FRP 0.87 MW
  - (2026-09-10) [FIRMS] thermal anomaly 52.396, 32.390 (FRP 0.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-10 0026Z, FRP 0.91 MW
  - (2026-09-10) [FIRMS] thermal anomaly 52.393, 32.388 (FRP 0.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-10 0026Z, FRP 0.91 MW
  - (2026-09-10) [FIRMS] thermal anomaly 52.395, 32.377 (FRP 0.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-10 0026Z, FRP 0.95 MW

### State-Level News — 428 new of 796 total
  - (2026-09-11) [Alabama] Governor Kay Ivey Marks 25th Anniversary of September 11, Calls on Alabamians to Never Forget
      Governor Ivey released a video message commemorating the 25th anniversary of the September 11, 2001, terrorist attacks and honoring the nearly 3,000 innocent Americans whose lives were taken. (Governor’s Office, Mike Lew…
  - (2026-09-10) [Alabama] Governor Ivey Marks 25th Anniversary of September 11, Calls on Alabamians to Never Forget
      MONTGOMERY – Governor Kay Ivey on Thursday released a video message commemorating the 25th anniversary of the September 11, 2001, terrorist attacks and honoring the nearly 3,000 innocent Americans whose lives were taken.…
  - (2026-09-10) [Alabama] Prostate Cancer Awareness Month
      Download
  - (2026-09-10) [Alabama] Childhood Cancer Awareness Month
      Download
  - (2026-09-10) [Alabama] Nurse Honor Guard Day
      Download
  - (2026-09-10) [Alabama] Alabama Hydropower Day
      Download

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 235 new of 294 total
  - (2026-09-09) 阿根廷 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE5JeV8xM0ZIZkNVaHlDYzVvai1WQXVVVnVTRFhSd0hfYlVqMnBmOGpqRjEyQm91OVNGRzlpR3R4N2R5Y3FvaE9zLTEzM3dpeWVyR] (zh:…
      阿根廷 deepview.caixin.com
  - (2026-09-11) 香港推出最新烟盒设计规定：外包装不得有纹理，统一采用暗啡色，删除焦油、尼古丁标志，更新12款健康忠告图像 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBjYTZMN2tET2RBZGhEZ21SQ0hHTy05cmpMVVhBcG9NSURLUm9VQklzZmh4a1VfMHdLM] (zh:…
      香港推出最新烟盒设计规定：外包装不得有纹理，统一采用暗啡色，删除焦油、尼古丁标志，更新12款健康忠告图像 财新
  - (2026-09-11) AI芯片公司燧原上市开盘涨188% 市值约1700亿元_公司频道_财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1zZnF2SWRfQmVQZzlocndnZXZjU05pY3Vkb1BzRGJFeWxBQWlfWGtDZzRNYWpkc196QWFqNHE0ck9VMWtJa] (zh:…
      AI芯片公司燧原上市开盘涨188% 市值约1700亿元_公司频道_财新网 财新
  - (2026-09-10) 刘翔安置纠纷落幕：核心是运动员工作关系法律议题 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9FYXlzODE2ZVQ2Q2hVYUl3bTBkUHZrZXlHUU40UXYtNEhWdWtzNTVvQkRHRE9Ubmg3OTBZYXhLaDgzS3BJMGNIZHJpMFJ2cU] (zh:…
      刘翔安置纠纷落幕：核心是运动员工作关系法律议题 财新
  - (2026-09-11) 图集｜青岛一外籍货轮检修时起火 25人遇难 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5SYjNXZHREYjNieXFTVWhPS3VDUFZVb3VpeXp0VENnRmczSWVleDZESmVHNHFlUG10QXBvZlhsTGRoUlpCbnlnTUR1MmprWG9r] (zh:…
      图集｜青岛一外籍货轮检修时起火 25人遇难 财新
  - (2026-09-09) 今日开盘：小幅高开 沪指涨幅0.09% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE41aExDRnNzUF85NGN6ZG1mNUdmR0ZJblk5NGV6elZvQTYxTS1nUk5Tc0RteXNRVUEwUks3anlwRE4xd2w2NERkVGhDRUNMd2RpV3] (zh:…
      今日开盘：小幅高开 沪指涨幅0.09% 财新

### Local News: St. Louis + Atlanta — 224 new of 242 total
  - (2026-09-11) [St. Louis] St. Louis’ speed hump frenzy may be ending as city looks to remove aldermanic control
      For St. Louis, the past 10 years have been the decade of the speed hump. There were none in the City of St. Louis in 2017. Now there are more than 2,000. City planning executive Scott Ogilvie says it’s his understanding…
  - (2026-09-11) [St. Louis] BioGenerator’s second Startup Connect brought together startups—and people who want to fund them
      The voluminous lobby of WashU’s Neuroscience Research Building hummed on Wednesday afternoon and Thursday morning as 150 people tapped into the local innovation landscape mingled during the second annual Startup Connect.…
  - (2026-09-11) [St. Louis] What’s True in the Lou? – 9/11/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-09-11) [St. Louis] Where in St Charles 9/11/2026
      Let’s see how well you know St. Charles. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess”…
  - (2026-09-10) [St. Louis] Katie Lee tells her story in new memoir, ‘Unemployable’
      Katie Lee has never been particularly interested in keeping things to herself. The local restaurateur and founder of Katie’s Pizza & Pasta will release her semi-autobiographical debut memoir, UNEMPLOYABLE: The Katie Lee…
  - (2026-09-11) [St. Louis] The Black Rep celebrates 50 years of Black storytelling through theater in St. Louis

### U.S. Weather + Severe / Climate Outlooks — 103 new of 105 total
  - (2026-09-11) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-11) [Moderate] Special Weather Statement: Special Weather Statement issued September 11 at 7:50AM EDT by NWS Tallahassee FL
      At 750 AM EDT/650 AM CDT/, Doppler radar was tracking a strong thunderstorm 11 miles southeast of Santa Rosa Beach, moving northeast at 15 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty w…
  - (2026-09-11) [Severe] Special Marine Warning: Special Marine Warning issued September 11 at 6:47AM CDT until September 11 at 8:15AM CDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Coastal waters from Okaloosa-Walton County Line to Mexico Beach out 20 NM... St. Andrews Bay Waterways... * Until 815 AM CDT…
  - (2026-09-11) [Moderate] Gale Warning: Gale Warning issued September 11 at 3:46AM AKDT until September 12 at 5:00AM AKDT by NWS Fairbanks AK
      Northwestern Alaska Coastal Waters out 100 NM Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one- third of the combined wind-wave and swell height.…
  - (2026-09-11) [Severe] Special Marine Warning: Special Marine Warning issued September 11 at 6:43AM CDT until September 11 at 8:15AM CDT by NWS Mobile AL
      SMWMOB The National Weather Service in Mobile has issued a * Special Marine Warning for... Coastal waters from Okaloosa-Walton County Line to Pensacola FL out 20 NM... Coastal waters from Pensacola FL to Pascagoula MS ou…
  - (2026-09-11) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 11 at 6:33AM CDT until September 11 at 9:00AM CDT by NWS Quad Cities IA IL
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...In Illinois, Hancock, Henderson, McDonough, and Warren Counties. In Iowa, Lee County. In Missouri, Clark County. * WHEN...Until 9 AM CDT this morning.…

### State Legislative Action — 81 new of 139 total
  - (2026-09-10) [Alabama SB 122] Sunset law; State Board of Registration for Foresters continued until October 1, 2030
      Occupational Licensing Boards
  - (2026-09-10) [Alabama SB 167] Alabama Administrative Procedure Act; standard of judicial review revised regarding agency's interpretation of law
      Administrative Law and Procedures
  - (2026-09-10) [Alabama SB 159] Taxation; Energy use in commercial greenhouses, pivot irrigation systems, and poultry houses, exempt from utility gross receipts and utility service use tax
      Taxation & Revenue
  - (2026-09-10) [Alabama SB 115] Competitive bidding; repairs of vehicles under $15,000 for certain awarding authorities exempt
      Competitive Bidding
  - (2026-09-10) [Alabama SB 165] Elections; municipal elections, to set qualification fee amounts, to require indigent candidates to submit documentation for fee exemption
      Elections, Voting, & Campaigns
  - (2026-09-10) [Alabama SB 166] Campaign finance; require preservation of campaign records for specified period of time
      Elections, Voting, & Campaigns

### Ukrainian Internal News (national + local Kyiv) — 62 new of 135 total
  - (2026-09-11) ВАСК обрав запобіжний захід фігуранту справи "Феміда" Столару | LEDE: Вищий антикорупційний суд обрав запобіжний фігуранту справи "Феміда" нардепу Вадиму Столару у вигляді 300 млн гривень без в] (uk:…
      Вищий антикорупційний суд обрав запобіжний фігуранту справи "Феміда" нардепу Вадиму Столару у вигляді 300 млн гривень без взяття під варту.
  - (2026-09-11) У Євросоюзі досі не вирахували реальну "діру" в українському бюджеті | LEDE: Європейська комісія продовжує вивчати фінансову ситуацію в Україні, щоб оцінити нагальні потреби державного бюджету ] (uk:…
      Європейська комісія продовжує вивчати фінансову ситуацію в Україні, щоб оцінити нагальні потреби державного бюджету в додаткових коштах у 2026 році, і тільки після цього почне обговорення джерел можливого додаткового фін…
  - (2026-09-11) Окупанти завдали авіаудару по Слов'янську: загинув чоловік, жінка у важкому стані – МВА | LEDE: В п'ятницю 11 вересня російські окупаційні війська завдали авіаудару по Слов'янську Донецької обл] (uk:…
      В п'ятницю 11 вересня російські окупаційні війська завдали авіаудару по Слов'янську Донецької області: загинув мирний мешканець, що одну людину поранено.
  - (2026-09-11) Карфаген на мільйони: як посадовці ховають незаконні активи і чому державі важко їх забрати | LEDE: ] (uk: Карфаген на мільйони: як посадовці ховають незаконні активи і чому державі важко)
  - (2026-09-11) Секрет живучості Ле Пен. Чому ультраправа кандидатка може очолити Францію після трьох поразок | LEDE: ] (uk: Секрет живучості Ле Пен. Чому ультраправа кандидатка може очолити Францію після )
  - (2026-09-11) Єврокомісар прокоментував інцидент з літаком Зеленського та дроном | LEDE: ] (uk: Єврокомісар прокоментував інцидент з літаком Зеленського та дроном)

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 57 total
  - (2026-09-11) [BleepingComputer] GitLab urges users to patch max severity path traversal flaw
      GitLab urged users on Thursday to patch their servers immediately against a maximum-severity path traversal vulnerability tracked as CVE-2026-85706. [...]
  - (2026-09-11) [BleepingComputer] Microsoft fixes Teams, Outlook launch failures on ARM Windows PCs
      Microsoft has fixed a bug that prevented Teams and Outlook from launching on ARM-based Windows devices after installing updates released since the August 2026 Patch Tuesday. [...]
  - (2026-09-11) [BleepingComputer] Trezor: 347,000 users targeted in phishing attacks after Brevo breach
      Trezor has revealed that phishing attacks against its customers earlier this week targeted 347,000 email addresses and affected 2,500 users who clicked an embedded malicious link. [...]
  - (2026-09-11) [BleepingComputer] Conti ransomware gang member sentenced to 4 years in prison
      A Ukrainian national has been sentenced to four years in prison for his role in Conti ransomware attacks between 2021 and 2022. [...]
  - (2026-09-11) [The Hacker News] Attackers Chain JFrog Artifactory Flaws to Gain Admin Control and Plant Backdoors
      Attackers have chained two flaws in JFrog Artifactory, the repository that software build pipelines pull from, to take administrator control of self-hosted servers and plant backdoors, cloud security company Wiz said in…
  - (2026-09-11) [The Hacker News] China-Linked UNC3569 Exploited Sogou Input Method Flaw to Deploy GRAYRABBIT Backdoor
      A China-linked hacking group exploited a flaw in Sogou Input Method, one of the most widely used tools for typing Chinese characters on Windows, to install a backdoor on victims' computers, security company Gen Digital s…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-11) [Lyon Charles M] Form 4 (Reporting)
      filed 2026-09-11 11:59 UTC · role: Reporting — Filed: 2026-09-11 AccNo: 0001620576-26-000007 Size: 4 KB
  - (2026-09-11) [StoneX Group Inc.] Form 4 (Issuer)
      filed 2026-09-11 11:59 UTC · role: Issuer — Filed: 2026-09-11 AccNo: 0001620576-26-000007 Size: 4 KB
  - (2026-09-11) 425 - Aperture AC (0002093524) (Subject)
      filed 2026-09-11 11:47 UTC — Filed: 2026-09-11 AccNo: 0001213900-26-098973 Size: 17 MB
  - (2026-09-11) 485BXT - Tidal Trust II (0001924868) (Filer)
      filed 2026-09-11 11:43 UTC — Filed: 2026-09-11 AccNo: 0001999371-26-020345 Size: 24 KB
  - (2026-09-11) 485BXT - Tidal Trust II (0001924868) (Filer)
      filed 2026-09-11 11:43 UTC — Filed: 2026-09-11 AccNo: 0001999371-26-020345 Size: 24 KB
  - (2026-09-11) [Pangilinan Manuel Velez] Form 4 (Reporting)
      filed 2026-09-11 11:37 UTC · role: Reporting — Filed: 2026-09-11 AccNo: 0001193125-26-388615 Size: 10 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 29 new of 29 total
  - (2026-09-11) Adjusting Certain Delegations Under the Defense Production Act
  - (2026-09-11) Accelerating Access to Veterans' Benefits and Employment Opportunities
  - (2026-09-11) Special Local Regulations; Marine Events Within the Sector Columbia River Captain of the Port Zone, Portland, OR
      The Coast Guard will enforce special local regulations at one location in the Sector Columbia River Captain of the Port Zone in Portland, OR from September 12, 2026, to September 13, 2026. This action is necessary to pro…
  - (2026-09-11) Special Areas; Roadless Area Conservation
      The U.S. Department of Agriculture (USDA or Department) is extending the public comment period for the proposed rule titled Special Areas; Roadless Area Conservation, published in the Federal Register on August 20, 2026…
  - (2026-09-11) Allocation and Apportionment of Deductions to Foreign Source Section 951A Category Income and Deduction Eligible Income
      This document contains proposed regulations related to the allocation and apportionment of deductions to foreign source section 951A category income for foreign tax credit limitation purposes and for purposes of calculat…
  - (2026-09-11) Eliminating the Discretionary 60-Day Grace Period
      The Department of Homeland Security (DHS) proposes to remove regulations at 8 CFR 214.1(l)(2) to restore its previous and long- standing policy of not providing aliens in certain nonimmigrant classifications (and their d…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-11) JAF50T (Bulgaria)
      icao24: 4520ce · position: (43.9465, -0.462) · alt: 11277m · 889km/h
  - (2026-09-11) JAF5GA (Bulgaria)
      icao24: 4520aa · position: (35.344, -5.5837) · alt: 11285m · 934km/h
  - (2026-09-11) GAF133 (Germany)
      icao24: 3f62fc · position: (45.9654, 17.0718) · alt: 4869m · 521km/h
  - (2026-09-11) JAF29J (Bulgaria)
      icao24: 4521ac · position: (50.5554, 6.9362) · alt: 7025m · 695km/h
  - (2026-09-11) PAT590 (United States)
      icao24: adfec9 · position: (40.7998, -79.2436) · alt: 6096m · 500km/h
  - (2026-09-11) RCH4199 (United States)
      icao24: ae08e3 · position: (38.5916, -81.907) · alt: 8839m · 945km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 23 new of 107 total
  - (2026-09-10) [OFAC] Iran-related and Counter Terrorism Designations; Licensing Policy Update under Operation Economic Outcast; Settlement Agreement between OFAC and an Individual - Office of Foreign Assets Control…
      Iran-related and Counter Terrorism Designations; Licensing Policy Update under Operation Economic Outcast; Settlement Agreement between OFAC and an Individual Office of Foreign Assets Control (.gov)
  - (2026-09-10) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-09-10) [OFAC] IRANIAN TRANSACTIONS AND SANCTIONS REGULATIONS STATEMENT OF LICENSING POLICY ON IRAN-RELATED REQUESTS Consistent with current U. - Office of Foreign Assets Control (.gov)
      IRANIAN TRANSACTIONS AND SANCTIONS REGULATIONS STATEMENT OF LICENSING POLICY ON IRAN-RELATED REQUESTS Consistent with current U. Office of Foreign Assets Control (.gov)
  - (2026-09-10) [OFAC] Federal Register/Vol. 91, No. 174/Thursday, September 10, 2026/Rules and Regulations - Office of Foreign Assets Control (.gov)
      Federal Register/Vol. 91, No. 174/Thursday, September 10, 2026/Rules and Regulations Office of Foreign Assets Control (.gov)
  - (2026-09-11) [USASpending] $20,646,113,720 → LOCKHEED MARTIN SERVICES, LLC: MANAGEMENT AND OPERATION OF Y-12 PLANT AND OTHER PROGRAMS
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATION OF Y-12 PLANT AND OTHER PROGRAMS
  - (2026-09-11) [USASpending] $8,629,200,535 → BROOKHAVEN SCIENCE ASSOCIATES LLC: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
      Agency: Department of Energy. Description: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL

### Court opinions of consequence (federal & state) — 23 new of 60 total
  - (2026-09-10) Delaware Supreme Court: Beebe Hospital (more properly known as Beebe Medical Center, Inc.) v. James Bowers
  - (2026-09-10) Delaware Supreme Court: Trellis Software, Inc. v. Clearlist Holdings, LLC
  - (2026-09-10) Delaware Supreme Court: Fairstead Capital Management LLC v. William Blodgett
  - (2026-09-10) U.S. Court of Appeals, 7th Cir.: Yousef A. Ismail v. David Steiner
  - (2026-09-10) U.S. Court of Appeals, Federal Cir.: Versata Software, LLC v. Ford Motor Company
  - (2026-09-10) Florida Supreme Court: In Re: Amendments to Florida Family Law Rules of Procedure and Rule Regulating the Florida Bar 10 2.2

### Paper Trading Scorecard — 19 new of 139 total
  - (2026-09-11) [Manifold] Will AI solve another Millennium Prize Problem (besides Navier–Stokes) before September 15, 2027?
  - (2026-09-11) [Manifold] Will the United States pass federal legislation regulating AI in 2026?
  - (2026-09-11) [Manifold] Will the world population be 7 billion or less at any point before 2035?
  - (2026-09-11) [Manifold] US Average DIESEL Price Is $6.000 or more on Election Day 2026?
  - (2026-09-11) [Manifold] US Average Gas Price Is $4.400 or more on any day in September 2026?
  - (2026-09-11) [Manifold] Is Digger (2026) a musical?

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-11) Will Abigail Spanberger win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $1,646,341 · resolves 2028-11-07
  - (2026-09-11) Will Stade Rennais FC 1901 win on 2026-09-11?
      yes price: 48% · 24h volume: $638,356 · resolves 2026-09-11
  - (2026-09-11) LoL: KT Rolster Challengers vs DN SOOPers Challengers - Game 2 Winner
      yes price: 100% · 24h volume: $496,092 · resolves 2026-09-11
  - (2026-09-11) Will Tom Cotton win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $496,000 · resolves 2028-11-07
  - (2026-09-11) Will Elon Musk post 140-159 tweets from September 4 to September 11, 2026?
      yes price: 0% · 24h volume: $494,641 · resolves 2026-09-11
  - (2026-09-11) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 20% · 24h volume: $484,124 · resolves 2027-01-01

### USGS earthquakes (M4.5+, past day) — 8 new of 8 total
  - (2026-09-10) M 5.4 - southern East Pacific Rise
      M5.4 · southern East Pacific Rise · depth 10 km
  - (2026-09-11) M 5.3 - 151 km WSW of Adak, Alaska
      M5.3 · 151 km WSW of Adak, Alaska · depth 40.892 km · TSUNAMI
  - (2026-09-10) M 5.3 - 83 km E of Lospalos, Timor Leste
      M5.3 · 83 km E of Lospalos, Timor Leste · depth 10 km
  - (2026-09-10) M 5.1 - 162 km SSW of Merizo Village, Guam
      M5.1 · 162 km SSW of Merizo Village, Guam · depth 10 km
  - (2026-09-11) M 4.9 - 69 km N of Isangel, Vanuatu
      M4.9 · 69 km N of Isangel, Vanuatu · depth 18.748 km
  - (2026-09-10) M 4.9 - 65 km NNW of Sola, Vanuatu
      M4.9 · 65 km NNW of Sola, Vanuatu · depth 49.877 km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-11) [Marginal Revolution] My AI podcast with James Pethokoukis
      You will find it here, with transcript. The post My AI podcast with James Pethokoukis appeared first on Marginal REVOLUTION.
  - (2026-09-11) [Marginal Revolution] Markets do respond to AGI news
      Here is the link. What are the changes in the other market prices telling you? The post Markets do respond to AGI news appeared first on Marginal REVOLUTION.
  - (2026-09-11) [Marginal Revolution] Is there now a better trend in youth mental health?
      A key U.S. government report on mental health, substance use and addiction showed continued improvements in several metrics, especially among young people. There was some uncertainty about the future of the National Surv…
  - (2026-09-10) [Conversable Economist] A Supply-Side Story: The Rising Price of Candy
      The price of candy has risen considerably, and when a price goes up, there are always two school of thought. One argument is that greed and “big candy” has jacked up the price in pursuit of higher profits. The challenge…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 20 total
  - (2026-09-10) CVE-2026-86060 · MikroTik RouterOS: MikroTik RouterOS Improper Neutralization of Argument Delimiters in a Command Vulnerability
      vendor: MikroTik · product: RouterOS · CISA remediation by 2026-09-13
  - (2026-09-10) CVE-2026-67277 · MikroTik RouterOS: MikroTik RouterOS Missing Authentication for Critical Function Vulnerability
      vendor: MikroTik · product: RouterOS · CISA remediation by 2026-09-13

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-11) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=11, 14d-median=18; carrying terms: existing, proposed, program, final, certain, national, safety, unless, special, commission, changes, document
- state_bills: today=139, 7d-median=82, 14d-median=79; carrying terms: insurance, another, existing, waste, officers, subject, establish, contract, programs, enforcement, providing, funds
- state_news: today=796, 7d-median=549, 14d-median=586; carrying terms: carolina, insurance, justice, another, political, arizona, candidates, issue, outside, toward, facility, enforcement
- local_news: today=242, 7d-median=226, 14d-median=226; carrying terms: outside, season, being, killed, years, crash, officials, president, atlanta, class, google, games
- foreign_news: today=993, 7d-median=1005, 14d-median=1017; carrying terms: reportedly, justice, participants, investigated, unocha, nation, northern, parliament, large, rescued, kenya, october
- chinese_internal: today=294, 7d-median=280, 14d-median=284; carrying terms: cbmixkfvx, cbmiakfvx, lxtfb, google, china, property, cbmia, cbmix, blank, cbmidefvx, cbmizefvx, cbmiw
- russian_internal: today=1130, 7d-median=1042, 14d-median=1058; carrying terms: bloomberg, error, social, europe, media, journal, russian, group, axios, client, title, truth
- ukrainian_internal: today=135, 7d-median=132, 14d-median=130; carrying terms: reportedly, september, political, military, regions, group, across, energy, security, facility, hmarochos, russia
- ukraine_theater: today=776, 7d-median=486, 14d-median=528; carrying terms: wdjoaznrndlxdtq, rtduiwythhbf, uhvnvnj, procurement, lkzulrcm, fqzvzdk, jtdfjkbejyshqznlz, tmrougt, large, polygon, rdmhbrxdhdf, fdmlmc
- paper_bets: today=139, 7d-median=131, 14d-median=132; carrying terms: robot, maine, democratic, playoff, magnitude, schumer, colonize, human, world, visit, kylian, arizona
- weather: today=105, 7d-median=105, 14d-median=105; carrying terms: related, today, evening, portions, september, tonight, discussion, excessive, flooding, showers, aviation, ruskin
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: payems, cpilfesl, commodities, walcl, cpiaucsl, dcoilwtico, growth, unrate, treasury, assets, labor, money
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, equities, large, commodities, natural, close, crypto, credit, russell, silver, treasury, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=107, 7d-median=104, 14d-median=106; carrying terms: administration, related, niger, annexation, xskfisuh, assets, political, sudan, military, company, response, issuance
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, httperror, quiver, error, congresstrading, quantitative, unauthorized, quiverquant, https
- billionaires: today=0, 7d-median=30, 14d-median=15
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: company, blanche, connecticut, court, supreme, state, appeals, national, center, international, gonzalez, perez
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, filer, holdings, therapeutics, trust, group, subject, tidal, jonathan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: committee, lindsey, james, jonathan, house, michael, talarico, trone, robert, johnson, warner, angels
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, israel, killed, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, germany, france, kingdom, ground, bulgaria, spain, adfec
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: related, niger, verified, critically, cases, fatal, pregnant, alerted, cvdpv, geographical, includ, cereulide
- cisa_kev: today=20, 7d-median=21, 14d-median=21; carrying terms: remediation, vendor, vulnerability, buffer, request, jfrog, critical, forgery, function, product, improper, authentication
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=8, 7d-median=11, 14d-median=11; carrying terms: depth, alaska, isangel, vanuatu, tsunami, mexico, puerto
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: change, decrease, interest, september, price, rates, shakhtar, volume, league, resolves, champions, meeting
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, conversable, class, revolution, marginal, https, people, government, conversableeconomist, economists, evidence, price
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: today, artificial, newsletter, company, group, power, published, openai, record, security, schneier, review
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: administration, matsui, insurance, justice, rubio, anomaly, pettersen, shomari, lloyd, salud, maria, michelle
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, placement, today, paper, placed, sufficient, module, converges, consensus, markets, decision, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-08] ECB press: Frank Elderson: Fireside chat
- [2026-09-09] ECB press: Christine Lagarde: The choice facing Europeans
- [2026-09-10] ECB press: Monetary policy decisions
- [2026-09-10] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*