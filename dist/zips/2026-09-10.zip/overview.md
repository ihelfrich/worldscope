# WORLDSCOPE morning brief — 2026-09-10

## Headline
3275 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (795) · Russian Internal News (state + in-exile) (713) · State-Level News (356) · World leaders & government officials (324) · Chinese Internal News (221) · Local News: St. Louis + Atlanta (199) · Ukraine Theater (total-war monitoring) (102) · U.S. Weather + Severe / Climate Outlooks (96) · State Legislative Action (92) · Ukrainian Internal News (national + local Kyiv) (73) · IT, InfoSys & cybersecurity news (last 7 days) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 795 new of 1007 total
  - (2026-09-09) [Global] Uganda to withdraw from Invictus Games ‘out of respect for King Charles’, says military chief
  - (2026-09-10) [Global] Rubio says US will work with allies to stop drug-trafficking as three killed in latest boat strike
  - (2026-09-09) [Global] Notorious Ecuadorian crime gang designated a terrorist group by US
  - (2026-09-08) [Global] US bans Canadian dairy, alcohol and motorcycles as trade war escalates
  - (2026-09-10) [Global] Wall Street Journal publisher convicted in Hong Kong of deterring reporter from union role
  - (2026-09-10) [Global] Deadly Philippines ferry fire triggers search for scores of missing

### Russian Internal News (state + in-exile) — 713 new of 1169 total
  - (2026-09-10) Венеция — 2026. Итоговый «Дау» — четырехчасовой фильм Ильи Хржановского, в котором весь сюжет, наконец, описан от начала до конца. Антон Долин рассказывает, почему эта картина войдет в историю ] (ru:…
      В Венеции показали «Дау» — фильм Ильи Хржановского, ставший итогом его одноименного проекта, растянувшегося на 20 лет. В предыдущие годы публике показывали отдельные серии этого эпоса о жизни физика Льва Ландау — вы наве…
  - (2026-09-10) Украинский «Макдоналдс» сократит меню в некоторых ресторанах из-за перебоев с продуктами | LEDE: Украинский «Макдоналдс» объявил, что из-за перебоев с поставкой продуктов в некоторых рестора] (ru: Укр…
      Украинский «Макдоналдс» объявил, что из-за перебоев с поставкой продуктов в некоторых ресторанах в меню временно могут отсутствовать некоторые позиции.
  - (2026-09-10) Война. 1660-й день. В Евросоюзе задумались об эффективности трат Украины на оборону — после просьбы Зеленского дать Киеву еще 27 миллиардов евро | LEDE: «Медуза» с 24 февраля 2022 года в пря] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-10) Мобилизация после выборов — это и правда «чушь», как говорит Путин? Откуда тогда пошли эти слухи? И хватает ли на войне людей без принудительного набора? | LEDE: Владимир Путин и его подчине] (ru: Моб…
      Владимир Путин и его подчиненные в последнее время активно опровергают слухи о предстоящей мобилизации. Многих это только больше тревожит: уровень доверия к заявлениям властей низкий, а спекуляции относительно планов при…
  - (2026-09-10) Reuters: российские военные испытывали в Арктике новую технологию для вывода из строя подводных кабелей связи | LEDE: Российские военные в апреле пытались испытать в северной части Атлантиче] (ru: Reu…
      Российские военные в апреле пытались испытать в северной части Атлантического океана новую технологию для вывода из строя подводных кабелей связи. Об этом агентству Reuters на условиях анонимности сообщили два западных ч…
  - (2026-09-10) Консервативный активист Чарли Кирк погиб год назад, но интернет до сих пор порождает новые мемы о нем. Мы поговорили с исследовательницей, которая их изучает | LEDE: 10 сентября 2025 года в ] (ru: Кон…
      10 сентября 2025 года в США застрелили правоконсервативного активиста Чарли Кирка. Ему был 31 год. Кирк основал Turning Point USA — самую влиятельную консервативную молодежную организацию в Соединенных Штатах, которая по…

### State-Level News — 356 new of 708 total
  - (2026-09-09) [California] Governor Newsom signs first-in-the-nation AI safeguards to protect Californians, calls on the federal government to do its part
      <a href="https://www.gov.ca.gov/2026/09/09/governor-newsom-signs-first-in-the-nation-ai-safeguards-to-protect-californians-calls-on-the-federal-g
  - (2026-09-09) [California] Government, made easier. Governor Newsom introduces AskCA, a new AI-powered tool for Californians
      Source
  - (2026-09-10) [California] California sues over Trump’s changes to Endangered Species Act, arguing they threaten habitat
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/050223_California-Condor_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-09-10) [California] California has one-quarter of all the nation’s death sentences. Will Newsom commute them all?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/031319_Death-Penalty-Chair_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-09-10) [California] Colegios comunitarios se oponen repentinamente al plan que les permitiría ofrecer más títulos de licenciatura
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/04/092624_Adjunct-Instructor-MiraCosta_AH_CM_14.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size…
  - (2026-09-10) [California] Qué hace el comisionado de seguros de California y cómo afecta a tu bolsillo
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082526-Ricardo-Lara-CS-GETTY-CM-01.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 221 new of 285 total
  - (2026-09-08) 受贿1208万余元 工行许海被判十年半 - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE91anpfTnJLUThuUmpoYnI5T0JUU1NUWEhsZktoMnhoRGlzT2tQV1VKbVBBLVdfMXRlQVFXb0NGNXZ5NHp1MF] (zh:…
      受贿1208万余元 工行许海被判十年半 finance.caixin.com
  - (2026-09-08) 中金“三合一”后跻身万亿券商 多项风险指标好转 - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBDelNPcy1YbUc0Z0t1eDE5cllFSm03Z3BpLVNRQ1NVUnBtdmRUXzRXWVVFWnJiRmhPRmcyRk5tbldpUm] (zh:…
      中金“三合一”后跻身万亿券商 多项风险指标好转 finance.caixin.com
  - (2026-09-08) 奥运冠军谈公益转型：慈善更需“长期主义” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFBsVVNfc1dxeVM5NjZ3UjFDQkM3ZTNJY3E1Q042T2NrbEI5TDc0Q2ZMS2I1ZkJIVWNhZC1hR0owWFRxcWxFYjFualN1WVJheUdfN] (zh:…
      奥运冠军谈公益转型：慈善更需“长期主义” 财新
  - (2026-09-08) 星展银行“解锁科技企业的全球增长潜力”_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5VUFZfZVN2QmRHVjN1cjh2am92Q0NPeHM2UVdueVZLd3B3dTBKcTJIWERZbmtLaU02NmpjSjZPSGFnQXBaYWFMRXd] (zh:…
      星展银行“解锁科技企业的全球增长潜力”_特别呈现_手机财新网 财新
  - (2026-09-10) 财新调查｜8 月新增信贷与社融预计环比回升但低于去年同期 - finance.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFB4VWs3VW5sOFBoUUxsdWlJbnNqNkhoYW9MU19xakxXOEJyNURhc3NwOE53X3JTRTF2SUhnWTcwd] (zh:…
      财新调查｜8 月新增信贷与社融预计环比回升但低于去年同期 finance.caixin.com
  - (2026-09-10) 【市场动态】苹果首款折叠屏手机10月开售 iPhone迎来史上最大设计变化 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1HY3dDN1duSHhBTFd6NVYyVjd5OWxEblNOR21QRUFoZVk2X2MxTmt1cFRCRU5URnp] (zh:…
      【市场动态】苹果首款折叠屏手机10月开售 iPhone迎来史上最大设计变化 database.caixin.com

### Local News: St. Louis + Atlanta — 199 new of 227 total
  - (2026-09-10) [St. Louis] Trump, Kehoe are both underwater in Missouri, poll shows
      President Donald Trump is underwater in Missouri—and now so is Gov. Mike Kehoe. A SLU/YouGov poll of 900 likely voters released this morning shows that for the first time in six years, the number of Missourians who disap…
  - (2026-09-10) [St. Louis] New Soulard police substation raises questions from residents
      Peppered around St. Louis are police substations, places where St. Louis Metropolitan Police Department officers can file paperwork, use computers, and seek respite while they’re out on the job. One of the city’s newest…
  - (2026-09-10) [St. Louis] Where in the Lou 9/10/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-09-10) [St. Louis] Sculptor Nick Cave’s “Amalgam (Meditation)” will anchor the Ville’s new pocket park
      The Ville, one of St. Louis’ most historically significant Black neighborhoods, is receiving a new commissioned sculpture from Missouri-born Black artist Nick Cave. The Gateway Foundation, an organization dedicated to pr…
  - (2026-09-10) [St. Louis] Pokey LaFarge is bringing ‘Rent Money’ to St. Louis
      On his latest album, Rent Money, troubadour Pokey LaFarge knows there are few certainties in life beyond putting in a hard day’s work and paying the rent. With that in mind, he’s hard at work touring and preparing to bri…
  - (2026-09-09) [St. Louis] Little Fox owners to open Sur Lie on Friday in Fox Park
      The long-awaited second concept from Little Fox owners Craig and Mowgli Rivard opens later this week in Fox Park. Located across the street from Little Fox, Sur Lie (2805 Shenandoah) is a wine-focused bistro and bottle s…

### Ukraine Theater (total-war monitoring) — 102 new of 238 total
  - (2026-09-10) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-09) [Liveuamap] Ukrainian President Volodymyr Zelenskyy&039;s plane was almost hit by a drone en route to Oslo, Norway&039;s Prime Minister Jonas Gahr Støre says Akershus, Norway - Ukraine Interactive map…
      Ukrainian President Volodymyr Zelenskyy&039;s plane was almost hit by a drone en route to Oslo, Norway&039;s Prime Minister
  - (2026-09-09) [Liveuamap] Pakistan has delivered a Saudi warning to Iran to rein in its Yemeni Houthi allies after they stepped up attacks on the kingdom, in a coordinated effort to prevent the crisis from spiralli…
      Pakistan has delivered a Saudi warning to Iran to rein in its Yemeni Houthi allies after they stepped up attacks on the king
  - (2026-09-07) [Liveuamap] Reporter: The army is carrying out a large-scale demolition operation within its controlled areas east of Khan Younis in the southern Gaza Strip. - Liveuamap
      Reporter: The army is carrying out a large-scale demolition operation within its controlled area
  - (2026-09-09) [Liveuamap] Overnight Russia launched several Onix antiship missiles, several Iskander-M/S-400/KN-23 ballistic missiles, 32 Kh-101 cruise missiles, 166 strike drones of different types, - Ukrainian Ai…
      Overnight Russia launched several Onix antiship missiles, several Iskander-M/S-400/KN-23 ballistic missiles, 32 Kh-101 crui
  - (2026-09-10) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap

### U.S. Weather + Severe / Climate Outlooks — 96 new of 98 total
  - (2026-09-10) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-10) [Moderate] Special Weather Statement: Special Weather Statement issued September 10 at 7:50AM EDT by NWS Charleston SC
      Areas of fog will gradually lift across interior Southeast Georgia through mid-morning. The fog will be locally dense at times with visibility 1/4 mile or less. Motorists should be alert for areas of reduced visibility.
  - (2026-09-10) [Moderate] Gale Warning: Gale Warning issued September 10 at 3:50AM AKDT until September 10 at 5:00PM AKDT by NWS Anchorage AK
      Offshore Waters Forecast for the Bering Sea Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. .TO…
  - (2026-09-10) [Moderate] Gale Warning: Gale Warning issued September 10 at 3:50AM AKDT until September 10 at 5:00PM AKDT by NWS Anchorage AK
      Offshore Waters Forecast for the Bering Sea Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. .TO…
  - (2026-09-10) [Moderate] Gale Warning: Gale Warning issued September 10 at 3:49AM AKDT until September 10 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-10) [Moderate] Gale Warning: Gale Warning issued September 10 at 3:49AM AKDT until September 10 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…

### State Legislative Action — 92 new of 121 total
  - (2026-09-09) [Alabama HB 247] State Board of Adjustment, provide death benefit to survivors of volunteer firefighters who die of cancer
      Government Administration
  - (2026-09-09) [Alabama HB 405] Crimes and offenses; bail jumping in the third degree, established
      Crimes & Offenses
  - (2026-09-09) [Alabama HB 277] Seafood; oyster aquaculture, licensees authorized to serve oysters at facility
      Health
  - (2026-09-09) [Alabama HB 226] Habitual offender law; pleas of nolo contendere treated as a plea of guilty
      Crimes & Offenses
  - (2026-09-09) [Alabama HB 328] Crimes and offenses; arson in the first degree, elements of crime further provided to include arson in connection to a theft; minimum penalties provided
      Crimes & Offenses
  - (2026-09-09) [Alabama HB 415] Department of Insurance; additional requirements for captive insurers specified
      Insurance

### Ukrainian Internal News (national + local Kyiv) — 73 new of 139 total
  - (2026-09-10) Реєстр збитків від ударів РФ відкрив прийом заяв для бізнесу за трьома категоріями | LEDE: Реєстр збитків України внаслідок російської агресії починає прийом заяв від постраждалих за трьома ост] (uk:…
      Реєстр збитків України внаслідок російської агресії починає прийом заяв від постраждалих за трьома останніми категоріями для юридичних осіб – про вимушене переміщення бізнесу, інші економічні втрати та гуманітарні витрат…
  - (2026-09-10) У Польщі закрили справу про пошкодження будинку під час вторгнення дронів РФ | LEDE: ] (uk: У Польщі закрили справу про пошкодження будинку під час вторгнення дронів РФ)
  - (2026-09-10) Ворог атакував Краматорськ: серед 19 поранених – немовля | LEDE: Щонайменше 19 людей дістали поранення внаслідок ранкових ударів ворога по Краматорську Донецької області.] (uk: Ворог атакував Краматор…
      Щонайменше 19 людей дістали поранення внаслідок ранкових ударів ворога по Краматорську Донецької області.
  - (2026-09-10) "Уразили пункти управління БпЛА": Сили оборони атакували військові об'єкти в Росії та на ТОТ | LEDE: Сили оборони 9–10 вересня 2026 року атакували радари, склади та пункти управління Росії та н] (uk:…
      Сили оборони 9–10 вересня 2026 року атакували радари, склади та пункти управління Росії та на окупованих територіях України.
  - (2026-09-10) У ЄС придумали як використати заморожені активи РФ, розвіявши побоювання Бельгії | LEDE: У ЄС придумали нову структуру для управління активами Росії, щоб зняти юридичні ризики для Бельгії. Дета] (uk:…
      У ЄС придумали нову структуру для управління активами Росії, щоб зняти юридичні ризики для Бельгії. Деталі та перспективи – у матеріалі.
  - (2026-09-10) Російські гроші ставлять на розморозку. Чи отримає Україна активи РФ та що пропонує Брюссель | LEDE: У Брюсселі знову готуються до конфіскації заморожених активів Росії, на використанні яких да] (uk:…
      У Брюсселі знову готуються до конфіскації заморожених активів Росії, на використанні яких давно наполягала українська сторона. Пояснюємо непублічні деталі цієї ідеї...

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 57 total
  - (2026-09-10) [BleepingComputer] Microsoft says September updates fix mouse settings reset issues
      Microsoft has fixed a known issue that wiped mouse settings on some Windows 11 systems after installing the KB5120998 August 2026 preview update. [...]
  - (2026-09-10) [BleepingComputer] CISA: WatchGuard RCE flaw now exploited in ransomware attacks
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) has confirmed that ransomware gangs are also exploiting a critical WatchGuard Firebox firewall vulnerability, which it flagged as actively exploited in Dec…
  - (2026-09-10) [BleepingComputer] Microsoft fixes bug that wiped Windows desktop settings
      Microsoft says the September 2026 Patch Tuesday updates fix a known issue causing desktop settings to be lost or reset on some Windows devices. [...]
  - (2026-09-10) [BleepingComputer] Trezor warns users of email provider breach, phishing attacks
      Trezor warned customers on Wednesday that threat actors who breached its third-party email provider are targeting them in phishing attacks. [...]
  - (2026-09-10) [The Hacker News] CISA Flags Exploited Cisco, Citrix, Fortinet Flaws, Sets Sept. 12 Federal Patch Deadline
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Wednesday added three flaws, each impacting Cisco, Citrix, and Fortinet, to its Known Exploited Vulnerabilities (KEV) catalog, requiring Federal Civilia…
  - (2026-09-10) [The Hacker News] Nearly 1 in 10 Exposed LiteLLM Gateways Accepted the Example "sk-1234" Admin Key
      Nearly one in ten of the internet-facing LiteLLM servers that Wiz Research scanned in February accepted sk-1234, the example admin key in LiteLLM's own setup guide. LiteLLM is an open-source AI gateway, the software a co…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-10) 424B3 - 1st FRANKLIN FINANCIAL CORP (0000038723) (Filer)
      filed 2026-09-10 11:48 UTC — Filed: 2026-09-10 AccNo: 0001628280-26-061225 Size: 24 KB
  - (2026-09-10) 424B3 - 1st FRANKLIN FINANCIAL CORP (0000038723) (Filer)
      filed 2026-09-10 11:44 UTC — Filed: 2026-09-10 AccNo: 0001628280-26-061222 Size: 29 KB
  - (2026-09-10) 497 - Tidal Trust II (0001924868) (Filer)
      filed 2026-09-10 11:39 UTC — Filed: 2026-09-10 AccNo: 0001999371-26-020263 Size: 235 KB
  - (2026-09-10) [Kohli Prashant] Form 4 (Reporting)
      filed 2026-09-10 11:30 UTC · role: Reporting — Filed: 2026-09-10 AccNo: 0001140361-26-036125 Size: 4 KB
  - (2026-09-10) [Grace Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-09-10 11:30 UTC · role: Issuer — Filed: 2026-09-10 AccNo: 0001140361-26-036125 Size: 4 KB
  - (2026-09-10) [Galaxy Digital Inc.] Form 4 (Issuer)
      filed 2026-09-10 11:16 UTC · role: Issuer — Filed: 2026-09-10 AccNo: 0001706614-26-000004 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-10) JAF9XT (Bulgaria)
      icao24: 4520ce · position: (34.1669, -6.4833) · alt: 8496m · 977km/h
  - (2026-09-10) CFC3701 (Canada)
      icao24: c2b373 · position: (61.2512, 7.7612) · alt: 11209m · 716km/h
  - (2026-09-10) PAT954 (United States)
      icao24: adfdd1 · position: (38.7044, -77.5018) · alt: 106m · 135km/h
  - (2026-09-10) GAF105 (Germany)
      icao24: 3f46db · position: (61.6961, 16.6019) · alt: 10355m · 827km/h
  - (2026-09-10) JAF1YV (Belgium)
      icao24: 44d1ba · position: (50.8993, 4.4862) · on ground
  - (2026-09-10) JAF29J (Belgium)
      icao24: 44d1b3 · position: (51.071, 4.6676) · alt: 876m · 459km/h

### U.S. Federal Action — 28 new of 28 total
  - (2026-09-10) Fee for Certain H-1B Petitions
  - (2026-09-10) Continuation of the National Emergency With Respect to Certain Terrorist Attacks
  - (2026-09-10) Labor Day, 2026
  - (2026-09-10) Supporting America's Ranchers
  - (2026-09-10) Promoting Fair Competition in Livestock Markets and Expanding Market Access for American Meat Producers
  - (2026-09-10) Airworthiness Directives; Bell Textron Canada Limited Helicopters
      The FAA proposes to adopt a new airworthiness directive (AD) for all Bell Textron Canada Limited (Bell) Model 206L, 206L-1, 206L-3, and 206L-4 helicopters with FAA Supplemental Type Certificate (STC) SR02684LA installed.…

### Paper Trading Scorecard — 26 new of 131 total
  - (2026-09-10) [Manifold] OpenAI flips Apple before 2030?
  - (2026-09-10) [Manifold] Will Bayern Munich defeat Bodø/Glimt?
  - (2026-09-10) [Manifold] Daily Coinflip
  - (2026-09-10) [Manifold] Will there be a tie score in the 2026/27 NFL season?
  - (2026-09-10) [Manifold] Will Lisan become addicted to nicotine before he graduates?
  - (2026-09-10) [Manifold] Will Trump give American adults $5000 each if the republicans win the midterms

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-09-10) [Israel-Iran-Hezbollah axis · keywords] In diplomatic row over West Bank , Israel shuts British consulate
      britainnews.net · English · tone NA
  - (2026-09-10) [Israel-Iran-Hezbollah axis · keywords] Secret systems used by Israel in mass killings of Gaza civilians revealed in new film
      theguardian.com · English · tone NA
  - (2026-09-10) [Israel-Iran-Hezbollah axis · keywords] Israel PM Benjamin Netanyahu was warned days before that Hamas were planning major October 7 attack
      aol.co.uk · English · tone NA
  - (2026-09-10) [Israel-Iran-Hezbollah axis · keywords] Israel hits back at united kingdom , shuts consulate in East Jerusalem
      trinidadtimes.com · English · tone NA
  - (2026-09-10) [Israel-Iran-Hezbollah axis · keywords] Palestinian Family of Four Killed in Israeli Strike on Gaza Home
      countercurrents.org · English · tone NA
  - (2026-09-10) [Israel-Iran-Hezbollah axis · keywords] Israel PM Benjamin Netanyahu was warned days before that Hamas were planning major October 7 attack
      mirror.co.uk · English · tone NA

### Court opinions of consequence (federal & state) — 24 new of 60 total
  - (2026-09-09) U.S. Court of Appeals, D.C. Cir.: John Doe v. SEC (PUBLIC REISSUED OPINION)
  - (2026-09-09) U.S. Court of Appeals, 11th Cir.: United States v. Joseph Olson
  - (2026-09-09) U.S. Court of Appeals, 11th Cir.: United States v. Rodney Leroy Brown
  - (2026-09-09) U.S. Court of Appeals, 2nd Cir.: In Re: SVB Fin. Grp.
  - (2026-09-09) U.S. Court of Appeals, 5th Cir.: Breaux v. Worrell
  - (2026-09-09) U.S. Court of Appeals, 5th Cir.: Eriakha v. University of MS

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 103 total
  - (2026-09-09) [OFAC] Transnational Criminal Organizations Designations; Counter Terrorism Designation; Issuance of New and Amended Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Transnational Criminal Organizations Designations; Counter Terrorism Designation; Issuance of New and Amended Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-09-09) [OFAC] 1270 - Office of Foreign Assets Control (.gov)
      1270 Office of Foreign Assets Control (.gov)
  - (2026-09-09) [OFAC] 1269 - Office of Foreign Assets Control (.gov)
      1269 Office of Foreign Assets Control (.gov)
  - (2026-09-10) [USASpending] $43,198,566,452 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…
  - (2026-09-10) [USASpending] $2,533,788,480 → ASSOCIATION OF UNIVERSITIES FOR RESEARCH IN ASTRONOMY, INC.: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT INCLUDE THE FI
      Agency: National Aeronautics and Space Administration. Description: THE PRIMARY ACTIVITIES COVERED BY THIS EFFORT INCLUDE THE FINAL SERVICING MISSION AND SUBSEQUENT OPERATIONS THROUGH END-OF-MISSION. THESE ACTIVITIES INC…
  - (2026-09-10) [USASpending] $1,271,565,945 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-09-10) LAPTOP FDV above $1B one day after launch?
      yes price: 22% · 24h volume: $1,178,341 · resolves 2026-12-31
  - (2026-09-10) Will FK Bodø/Glimt win on 2026-09-10?
      yes price: 3% · 24h volume: $908,686 · resolves 2026-09-10
  - (2026-09-10) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 0% · 24h volume: $718,577 · resolves 2026-09-16
  - (2026-09-10) LAPTOP FDV above $500M one day after launch?
      yes price: 86% · 24h volume: $670,483 · resolves 2026-12-31
  - (2026-09-10) Counter-Strike: MIBR vs BetBoom Team (BO3) - FISSURE PLAYGROUND Group A
      yes price: 8% · 24h volume: $605,803 · resolves 2026-09-10
  - (2026-09-10) Counter-Strike: MIBR vs BetBoom Team - Map 1 Winner
      yes price: 0% · 24h volume: $549,113 · resolves 2026-09-10

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-09-10) M 5.3 - 126 km WSW of Alianza Cristiana, Peru
      M5.3 · 126 km WSW of Alianza Cristiana, Peru · depth 10 km
  - (2026-09-09) M 5.2 - 76 km ESE of Isangel, Vanuatu
      M5.2 · 76 km ESE of Isangel, Vanuatu · depth 10 km
  - (2026-09-09) M 5.1 - 81 km ESE of Isangel, Vanuatu
      M5.1 · 81 km ESE of Isangel, Vanuatu · depth 10 km
  - (2026-09-10) M 5.0 - 45 km SSE of Quepos, Costa Rica
      M5.0 · 45 km SSE of Quepos, Costa Rica · depth 10 km
  - (2026-09-09) M 4.8 - Mid-Indian Ridge
      M4.8 · Mid-Indian Ridge · depth 10 km
  - (2026-09-09) M 4.8 - 86 km ESE of Isangel, Vanuatu
      M4.8 · 86 km ESE of Isangel, Vanuatu · depth 10 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-10) [Ukraine] Lithuania hands over 9 vehicles to Ukraine Defense Forces
      en.interfax.com.ua · English
  - (2026-09-10) [Ukraine] White House denies reports of larger role for CIA director in ending Russia war against Ukraine
      en.interfax.com.ua · English
  - (2026-09-10) [Ukraine] Russian Drone Strike on Sumy Shopping Center Kills 2
      kyivpost.com · English
  - (2026-09-10) [Ukraine] Zelensky Drone Incident Highlights High - Risk Wartime Travel Gap With Putin
      kyivpost.com · English
  - (2026-09-10) [Ukraine] Kim Jong Un Praises North Korean Troops Fighting for Russia
      kyivpost.com · English
  - (2026-09-10) [Ukraine] Ukraine News Today : Breaking Updates & Live Coverage - September 10 , 2026 from Kyiv Post
      kyivpost.com · English

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 21 total
  - (2026-09-09) CVE-2026-19490 · Citrix NetScaler: Citrix NetScaler Authentication Bypass Using an Alternate Path or Channel Vulnerability
      vendor: Citrix · product: NetScaler · CISA remediation by 2026-09-12
  - (2026-09-09) CVE-2025-25249 · Fortinet Multiple Products: Fortinet Multiple Products Heap-based Buffer Overflow Vulnerability
      vendor: Fortinet · product: Multiple Products · CISA remediation by 2026-09-12
  - (2026-09-09) CVE-2026-87491 · Google Chromium V8: Google Chromium V8 Out of Bounds Write Vulnerability
      vendor: Google · product: Chromium V8 · CISA remediation by 2026-09-23
  - (2026-09-09) CVE-2026-20079 · Cisco Secure Firewall Management Center (FMC) and Security Cloud Control (SCC) Firewall Management: Cisco Firewall Management Center Authentication Bypass Using an Alternate Path or C…
      vendor: Cisco · product: Secure Firewall Management Center (FMC) and Security Cloud Control (SCC) Firewall Management · CISA remediation by 2026-09-12

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-10) [Marginal Revolution] Economic Scenarios for Transformative AI
      By Anton Korinek, Charles I. Jones, Szymon Sacher, Tess Cotter, and Peter McCrory, a strong line-up from Anthropic. They are sober, reasoned, scientific, and (for the most part) dynamically consistent. Here is the paper,…
  - (2026-09-10) [Marginal Revolution] Ricardo Reis and the IMF?
      The IMF dropped the lead candidate to become its new chief economist at the eleventh hour after he was found to have made critical remarks about the Trump administration’s economic policies, according to people briefed o…
  - (2026-09-10) [Marginal Revolution] My very interesting Conversation with Jared Diamond
      Here is the audio, video, and transcript. Here is part of the episode summary: So which leaders do make a difference? Tyler and Jared debate that question, including conditions what a religious founder needs to succeed,…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-09-10) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo
      Since the last Disease Outbreak News was published on 28 August 2026, the Bundibugyo virus outbreak in the Democratic Republic of the Congo has expanded to one additional health zone, Kayna, in North Kivu. This increase…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-10) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=28, 7d-median=11, 14d-median=18; carrying terms: safety, certain, proposed, changes, unless, special, program, national, commission, final, foreign, associated
- state_bills: today=121, 7d-median=82, 14d-median=79; carrying terms: among, housing, payment, board, specified, crime, requires, agencies, funds, within, development, including
- state_news: today=708, 7d-median=549, 14d-median=586; carrying terms: union, sites, election, pressure, susan, south, attention, political, florida, create, concern, remain
- local_news: today=227, 7d-median=226, 14d-median=226; carrying terms: election, family, south, still, atlantamagazine, being, officials, state, stlmag, blank, charged, color
- foreign_news: today=1007, 7d-median=1007, 14d-median=1038; carrying terms: helped, union, internet, election, towards, killing, board, institutions, south, political, create, century
- chinese_internal: today=285, 7d-median=280, 14d-median=284; carrying terms: cbmiw, color, lxtfa, cbmib, cbmixkfvx, cbmibefvx, title, google, articles, cbmiykfvx, lxtfb, cbmidefvx
- russian_internal: today=1169, 7d-median=1042, 14d-median=1058; carrying terms: reuters, gazeta, telegram, novayagazeta, found, politico, europe, street, media, axios, truth, journal
- ukrainian_internal: today=139, 7d-median=132, 14d-median=128; carrying terms: killing, infrastructure, ukrinform, remain, assessment, odesa, struck, including, independent, threat, aircraft, attack
- ukraine_theater: today=238, 7d-median=486, 14d-median=451; carrying terms: fnsxi, cbmimafbvv, rltjhqz, aknsvgvpmnk, cbmikajbvv, cbmiigjbvv, sdnqtci, vdknldmfwegfhnu, kuwlxx, afbvv, avrasu, idvuyzxk
- paper_bets: today=131, 7d-median=131, 14d-median=131; carrying terms: artist, human, texas, james, wisconsin, virginia, goals, seats, pennsylvania, johnson, decrease, speed
- weather: today=98, 7d-median=105, 14d-median=112; carrying terms: updated, galveston, warning, additional, possible, hazardous, northern, south, aviation, today, related, night
- macro: today=0, 7d-median=21, 14d-median=21; carrying terms: implied, dexchus, balance, payems, crude, latest, payrolls, assets, commodities, jtsjol, indicator, cpiaucsl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, close, treasury, natural, russell, yield, crude, nasdaq, futures, bitcoin, credit, equities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=103, 7d-median=104, 14d-median=107; carrying terms: asked, belarus, union, rkiye, integrity, controlled, google, lebanon, paeez, satisfying, foreign, myanmar
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, httperror, quiverquant, error, client, quiver, congresstrading, https, quantitative
- billionaires: today=0, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, court, connecticut, state, supreme, company, blanche, energy, williams, board, center, michael
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, filed, issuer, holdings, filer, trust, financial, america, therapeutics, finance, jpmorgan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, trone, krishnamoorthi, jonathan, ocasio, elect, warner, robert, pinkston, cycle, johnson, receipts
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: killed, hezbollah, israel, english
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, germany, bulgaria, ground, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: symptoms, summarizes, increasingly, disembarked, mosquitoes, comprising, batch, representing, presented, yellow, driving, tshopo
- cisa_kev: today=21, 7d-median=21, 14d-median=21; carrying terms: pathname, citrix, vendor, vulnerability, forgery, injection, missing, bounds, directory, artifactory, unspecified, linux
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=11, 7d-median=11, 14d-median=12; carrying terms: depth, vanuatu, isangel, tonga, ridge, indian, houma
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: september, volume, price, decrease, donetsk, shakhtar, championship, champions, interest, change, resolves, meeting
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, marginal, https, economist, class, conversable, current, recent, government, economists, people, conversableeconomist
- tech_news: today=57, 7d-median=56, 14d-median=56; carrying terms: computerweekly, infrastructure, today, million, noopener, according, openai, become, weekly, hacker, krebs, technica
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: morrison, reserved, adrian, hageman, union, bessent, levin, ayanna, matsui, virginia, richmond, rivas
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, evidence, decision, claude, today, sufficient, placed, market, either, paper, placement, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-08] ECB press: Frank Elderson: Fireside chat
- [2026-09-09] ECB press: Christine Lagarde: The choice facing Europeans

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*