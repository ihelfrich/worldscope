# WORLDSCOPE morning brief — 2026-09-16

## Headline
3387 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (853) · Russian Internal News (state + in-exile) (716) · State-Level News (400) · World leaders & government officials (324) · Chinese Internal News (244) · Local News: St. Louis + Atlanta (213) · Ukraine Theater (total-war monitoring) (131) · U.S. Weather + Severe / Climate Outlooks (112) · Ukrainian Internal News (national + local Kyiv) (73) · State Legislative Action (60) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (35)

## What changed today
### International News + Multilateral Institutions — 853 new of 1045 total
  - (2026-09-16) [Global] US to bar some South Africans over claims of anti-white discrimination
  - (2026-09-16) [Global] ‘We are prey’: discovery of seven women’s bodies fuels anger over femicide in South Africa
  - (2026-09-16) [Global] Al-Qaida and IS-linked violence in Africa’s Sahel belt set to hit record levels this year
  - (2026-09-16) [Global] Slave-trade wealth was embedded in Britain’s financial system, research finds
  - (2026-09-16) [Global] People protecting nature and land set up self-defence units amid threat of murder
  - (2026-09-15) [Global] Ferocious fight among Brazil’s supreme court erupts on eve of presidential election

### Russian Internal News (state + in-exile) — 716 new of 1192 total
  - (2026-09-16) Читатели «Медузы» из России хотят вам кое-что сказать… Прочитайте несколько писем! И поддержите их, если живете за границей | LEDE: Каждый раз, когда мы просим помочь «Медузе», мы получаем о] (ru: Чит…
      Каждый раз, когда мы просим помочь «Медузе», мы получаем от вас не только донаты, но и десятки сообщений от читателей из России через проект «Помощь друга». Их авторы просят тех, кто живет в других странах, отправить дон…
  - (2026-09-16) Мосгорсуд освободил из СИЗО водителей фур, которых Украина втемную использовала для операции «Паутина» | LEDE: Московский городской суд освободил из-под стражи четырех водителей, чьи машины ] (ru: Мос…
      Московский городской суд освободил из-под стражи четырех водителей, чьи машины спецслужбы Украины использовали для запуска беспилотников по российским военным аэродромам во время операции «Паутины». Об этом сообщил «Комм…
  - (2026-09-16) Рэпера Macklemore исключили из концертного тура Эда Ширана за то, что он крикнул «Свободу Палестине». Остальные группы ушли в знак солидарности | LEDE: С января 2026 года Эд Ширан проводит м] (ru: Рэп…
      С января 2026 года Эд Ширан проводит мировой концертный тур Loop в поддержку своего восьмого студийного альбома «Play». К этому моменту певец уже выступил в Австралии, Новой Зеландии, Европе и на нескольких площадках в С…
  - (2026-09-16) Урсула фон дер Ляйен предложила создать европейский Совбез (с участием Украины) и независимый от НАТО механизм противодействия гибридным угрозам | LEDE: Глава Еврокомиссии Урсула фон дер Ляй] (ru: Урс…
      Глава Еврокомиссии Урсула фон дер Ляйен предложила создать европейский совет безопасности, в рамках которого лидеры стран ЕС будут встречаться с руководителями государств-партнеров, таких как Канада, Норвегия, Украина и…
  - (2026-09-16) Власти потребовали уничтожить серию вакцины «Мультикан-8», которую связывали с массовой гибелью собак | LEDE: Россельхознадзор поручил изъять из оборота и уничтожить 20-ю серию вакцины «Муль] (ru: Вла…
      Россельхознадзор поручил изъять из оборота и уничтожить 20-ю серию вакцины «Мультикан-8», которую связывали с гибелью собак. Письмо (.pdf) с соответствующим распоряжением ведомство направило производителю препарата — ком…
  - (2026-09-16) США раскрыли группировку, которая готовила покушения на российских «диссидентов» в Вашингтоне и Вильнюсе. Среди подозреваемых — полковник в отставке, «работавший с Путиным», его сын-сотрудник Ф] (ru:…
      Власти США объявили, что раскрыли связанную с российскими спецслужбами преступную сеть RIS Network, которая вербовала исполнителей для убийств российских оппозиционеров и диверсий в странах — союзниках Украины. Всего обв…

### State-Level News — 400 new of 824 total
  - (2026-09-15) [Alabama] Governor Ivey Announces Commissioner Chris Blankenship to Retire from Department of Conservation and Natural Resources
      MONTGOMERY – Governor Kay Ivey on Tuesday announced her Department of Conservation and Natural Resources Commissioner Chris Blankenship will retire from state service at the end of the month. The governor has selected Be…
  - (2026-09-15) [California] Governor Newsom proclaims Latino Heritage Month
      Source
  - (2026-09-15) [California] California honored for nation-leading efficiency and data-driven improvements in state services and programs
      Source
  - (2026-09-15) [California] Governor Newsom signs wildfire recovery package to strengthen protections and focus on rebuilding for survivors
      Source
  - (2026-09-16) [California] How the most powerful woman in California government is making her mark on the Legislature
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/010625_Limon-Senate-Pro-Tem_MG_CM_13.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-09-16) [California] Did Altadena’s unincorporated status play a role in safety lapses during the Eaton fire?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/010925_Eaton-Fire_AP_CM_01-1.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 244 new of 298 total
  - (2026-09-15) “鸽王”于泽涉嫌受贿被提起公诉 数额特别巨大 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBzd2dnek1UMlR5WnZHbmJvWUhaMnp2TGY0TkhzbXpoSi1qYjFLeXJBLW5Vak1aMFVtLUZ3WGwwODdvdVkxX3BDeWd3ZURfR3d] (zh:…
      “鸽王”于泽涉嫌受贿被提起公诉 数额特别巨大 财新
  - (2026-09-14) 财经早知道｜国务院国资委：中央企业带头及时支付账款 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9DclQtZnowMTJITDhJMm5wMzAtbDlERmdoa0Rlam9VbFA0OGo0WUVzZVU4Zmw4ZW5tbWNGUm9sdWs1TUtiSTNORDd6QWU1] (zh:…
      财经早知道｜国务院国资委：中央企业带头及时支付账款 财新
  - (2026-09-15) 特稿｜退休副省长家丢了243万元茅台等名酒 管家获刑10年半 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5rbzhHRmhZQUZCR3ZwWnlIalJEbUI0d1ZnOWpNYUpSU1AwNVUxMGFIMS02eGk4LTBNSkN5VVZ6c] (zh:…
      特稿｜退休副省长家丢了243万元茅台等名酒 管家获刑10年半 china.caixin.com
  - (2026-09-15) 胡塞武装逼近曼德海峡 船公司却加速重返红海 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFBnXzNKcjR3blBZdV95enRSUncyUktJWm15TV9CUHQzWC1CZXZ6bXNTU0VwVWJMZDVOWmUwem84a01ieEs5dGhmeWlnWjZCZlZf] (zh:…
      胡塞武装逼近曼德海峡 船公司却加速重返红海 财新
  - (2026-09-15) 新加坡拟面向美国机构投资者推加密货币永续期货 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9TZHlqaDNpamZaMVcxZzRSa05yOUpWVC1VY0dEQmZOOV9iX2RSTUJxdjV4c1VMU1cwQXFuaVVtNWltclpRMi1FaDNqMG44WlY] (zh:…
      新加坡拟面向美国机构投资者推加密货币永续期货 财新
  - (2026-09-14) 央行披露规范电子凭证进展：余额下降20%、145家平台将退出 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1uR2NLYkNBRlBpOWZFWGtreFhwc3Jscm9CbnZsRE0xWEl1bHQ0RXJYVFZUZXBjSDdqNWtCX2wwaUw4ajJxSWFuMjN] (zh:…
      央行披露规范电子凭证进展：余额下降20%、145家平台将退出 财新

### Local News: St. Louis + Atlanta — 213 new of 244 total
  - (2026-09-16) [St. Louis] STL-Style marks 16 years celebrating St. Louis — and poking fun at it
  - (2026-09-16) [St. Louis] Burial site of first Black man to vote in Illinois confirmed 121 years after his death
  - (2026-09-16) [St. Louis] A growing St. Louis restaurant empire is taking root in the Grove
  - (2026-09-16) [St. Louis] State board signals support to St. Louis Public Schools after critical auditor report
  - (2026-09-15) [St. Louis] Tyus’ ‘bullet in your head’ remark could lead to censure by St. Louis Board of Aldermen
  - (2026-09-15) [St. Louis] Opening of consolidated 911 center in St. Louis delayed till 2027

### Ukraine Theater (total-war monitoring) — 131 new of 330 total
  - (2026-09-16) [DeepStateMap] frontline snapshot, 527 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-15) [FIRMS] thermal anomaly 45.260, 31.674 (FRP 6.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-15 1019Z, FRP 6.15 MW
  - (2026-09-15) [FIRMS] thermal anomaly 45.673, 33.175 (FRP 2.3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-15 1019Z, FRP 2.3 MW
  - (2026-09-15) [FIRMS] thermal anomaly 44.777, 25.679 (FRP 12.78 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-15 1019Z, FRP 12.78 MW
  - (2026-09-15) [FIRMS] thermal anomaly 44.778, 25.675 (FRP 8.94 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-15 1019Z, FRP 8.94 MW
  - (2026-09-15) [FIRMS] thermal anomaly 46.624, 31.030 (FRP 5.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-15 1019Z, FRP 5.64 MW

### U.S. Weather + Severe / Climate Outlooks — 112 new of 114 total
  - (2026-09-16) [Severe] Special Marine Warning: Special Marine Warning issued September 16 at 8:19AM EDT until September 16 at 9:15AM EDT by NWS Melbourne FL
      SMWMLB The National Weather Service in Melbourne has issued a * Special Marine Warning for... Volusia-Brevard County Line to Sebastian Inlet 0-20 nm... * Until 915 AM EDT. * At 818 AM EDT, a strong thunderstorm was locat…
  - (2026-09-16) [Severe] Flood Watch: Flood Watch issued September 16 at 6:17AM MDT until September 17 at 6:00AM MDT by NWS El Paso Tx/Santa Teresa NM
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...Much of southwest New Mexico, including the Dona Ana, Grant, Luna, Hidalgo, and Sierra Counties and the Sacramento Mountain in south-cent…
  - (2026-09-16) [Severe] Flood Watch: Flood Watch issued September 16 at 6:17AM MDT until September 17 at 6:00AM MDT by NWS El Paso Tx/Santa Teresa NM
      * WHAT...Flooding caused by excessive rainfall continues to be possible. * WHERE...Much of southwest New Mexico, including the Dona Ana, Grant, Luna, Hidalgo, and Sierra Counties and the Sacramento Mountain in south-cent…
  - (2026-09-16) [Moderate] Wind Advisory: Wind Advisory issued September 16 at 4:15AM AKDT until September 16 at 7:00PM AKDT by NWS Juneau AK
      * WHAT...Southwest winds 25 to 35 mph with gusts up to 45 mph. * WHERE...Municipality of Skagway. * WHEN...Until 7 PM AKDT this evening. * IMPACTS...Gusty winds will blow around unsecured objects. Tree limbs could be blo…
  - (2026-09-16) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-16) [Moderate] Special Weather Statement: Special Weather Statement issued September 16 at 5:55AM MDT by NWS Grand Junction CO
      At 554 AM MDT, Doppler radar was tracking a strong thunderstorm 24 miles southwest of Dinosaur, or 29 miles south of Vernal, moving northeast at 50 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE...Rad…

### Ukrainian Internal News (national + local Kyiv) — 73 new of 139 total
  - (2026-09-16) Сибіга: Путін прагне спровокувати міграцію до Європи, спричинивши продовольчу кризу | LEDE: Міністр закордонних справ Андрій Сибіга заявив, що план кремлівського правителя Владіміра Путіна поля] (uk:…
      Міністр закордонних справ Андрій Сибіга заявив, що план кремлівського правителя Владіміра Путіна полягає в провокуванні нової хвилі міграції до Європи через продовольчу кризу, спричинену блокадою українського експорту Чо…
  - (2026-09-16) Заступник міністра інфраструктури збив неповнолітню: вона перетинала трасу поза переходом – джерела УП | LEDE: На трасі Київ-Чоп Руслан Олійник наїхав на неповнолітню. Дівчина госпіталізована і] (uk:…
      На трасі Київ-Чоп Руслан Олійник наїхав на неповнолітню. Дівчина госпіталізована із травмами. Тривають слідчі дії, перевіряється стан потерпілої.
  - (2026-09-16) Навроцький зустрінеться з керівництвом Генштабу та Міноборони щодо безпекової ситуації | LEDE: Президент Польщі Кароль Навроцький проведе зустріч з начальником Генштабу та міністром оборони сто] (uk:…
      Президент Польщі Кароль Навроцький проведе зустріч з начальником Генштабу та міністром оборони стосовно поточної безпекової ситуації.
  - (2026-09-16) "Будьте обережні, обираючи героїв з минулого": Сікорський відповів, як зупинити напади на українців у Польщі | LEDE: Радослав Сікорський наголосив на потребі обачності України у виборі націонал] (uk:…
      Радослав Сікорський наголосив на потребі обачності України у виборі національних героїв.
  - (2026-09-16) Сікорський: Ми не блокуємо переговори України з ЄС, але на шляху у вас точно будуть проблеми | LEDE: ] (uk: Сікорський: Ми не блокуємо переговори України з ЄС, але на шляху у вас точно буд)
  - (2026-09-16) Лукашенко після переговорів з посланником Трампа звільнив 25 політв’язнів | LEDE: У Мінську узгодили обмін: США скасовують санкції проти Лакокраска й Беллесбумпром, Білорусь звільняє 25 політв'] (uk:…
      У Мінську узгодили обмін: США скасовують санкції проти Лакокраска й Беллесбумпром, Білорусь звільняє 25 політв'язнів.

### State Legislative Action — 60 new of 79 total
  - (2026-09-16) [Alaska HB 9050] An Act relating to a test.
      An Act relating to a test.
  - (2026-09-15) [Alaska SJR 9] Recognizing and honoring the relationship between Canada and Alaska; and recognizing the importance of the United States-Mexico-Canada Agreement negotiated by President Donald J. Trump…
      Recognizing and honoring the relationship between Canada and Alaska; and recognizing the importance of the United States-Mexico-Canada Agreement negotiated by President Donald J. Trump in October of 2018.
  - (2026-09-15) [Alaska SJR 26] Supporting the ability of Alaska Native corporations to participate in the United States Small Business Administration's 8(a) Business Development Program.
      Supporting the ability of Alaska Native corporations to participate in the United States Small Business Administration's 8(a) Business Development Program.
  - (2026-09-15) [Alaska SJR 24] Recognizing and honoring the relationship between the state and Greenland; and recognizing the importance of cooperation between the United States of America and the Kingdom of Denmark…
      Recognizing and honoring the relationship between the state and Greenland; and recognizing the importance of cooperation between the United States of America and the Kingdom of Denmark in the Arctic.
  - (2026-09-16) [California AB 2774] Physical Therapy Board of California.
      Existing law, the Physical Therapy Practice Act, establishes the Physical Therapy Board of California within the Department of Consumer Affairs for the licensure, approval, and regulation of physical therapists and physi…
  - (2026-09-16) [California AB 2163] Energy: Strategic Clean Energy and Critical Mineral Development Zones.
      Existing law, the Warren-Alquist State Energy Resources Conservation and Development Act, establishes the State Energy Resources Conservation and Development Commission and prescribes the authorities, duties, and respons…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-16) 497 - ETF Series Solutions (0001540305) (Filer)
      filed 2026-09-16 12:22 UTC — Filed: 2026-09-16 AccNo: 0000894189-26-025236 Size: 10 KB
  - (2026-09-16) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-09-16 12:15 UTC — Filed: 2026-09-16 AccNo: 0001213900-26-100358 Size: 23 KB
  - (2026-09-16) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-09-16 12:15 UTC — Filed: 2026-09-16 AccNo: 0001213900-26-100358 Size: 23 KB
  - (2026-09-16) [Gray Jonice M] Form 4 (Reporting)
      filed 2026-09-16 12:14 UTC · role: Reporting — Filed: 2026-09-16 AccNo: 0001894030-26-000014 Size: 5 KB
  - (2026-09-16) [MARRIOTT VACATIONS WORLDWIDE Corp] Form 4 (Issuer)
      filed 2026-09-16 12:14 UTC · role: Issuer — Filed: 2026-09-16 AccNo: 0001894030-26-000014 Size: 5 KB
  - (2026-09-16) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-09-16 12:14 UTC — Filed: 2026-09-16 AccNo: 0001213900-26-100357 Size: 24 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 35 new of 50 total
  - (2026-09-16) [BleepingComputer] Microsoft says Copilot buttons still missing in classic Outlook
      Microsoft says it's still investigating a known issue that causes the Copilot and Copilot Chat buttons in Classic Outlook to disappear for some Windows users. [...]
  - (2026-09-16) [BleepingComputer] Webinar: What happens in the first hours of a Google Workspace breach
      The first hours after discovering a Google Workspace breach can determine how an incident unfolds. This webinar examines real-world breaches to show which early response decisions can limit the impact and which can make…
  - (2026-09-16) [BleepingComputer] Critical ScreenConnect flaw now actively exploited in attacks
      Attackers now exploit a critical-severity ConnectWise ScreenConnect vulnerability in the wild, according to the U.S. Cybersecurity and Infrastructure Security Agency (CISA). [...]
  - (2026-09-16) [BleepingComputer] Windows Server 2022 reaches end of mainstream support next month
      Microsoft has reminded customers that Windows Server 2022 will reach the end of mainstream support next month and enter extended support until October 2031. [...]
  - (2026-09-16) [BleepingComputer] Google fixes actively exploited Android zero-day on Pixel devices
      Google has released the September 2026 security patches to address 110 vulnerabilities affecting its Pixel devices, including one zero-day flaw actively exploited in targeted attacks. [...]
  - (2026-09-16) [The Hacker News] Google Patches Pixel Modem Flaw Amid Signs of Limited Targeted Exploitation
      Google has disclosed that a high-severity security flaw in its Pixel Cellular Modem has come under exploitation in the wild. The vulnerability, tracked as CVE-2026-58704 (CVSS score: 8.0), is a privilege escalation flaw.…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-09-16) #1 Elon Musk — $886.39B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-09-16) #2 Jeff Bezos — $368.45B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-09-16) #3 Larry Page — $282.81B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-16) #4 Michael Dell — $265.72B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-09-16) #5 Sergey Brin — $260.26B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-16) #6 Mark Zuckerberg — $230.08B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-16) JAF50T (Bulgaria)
      icao24: 4520ce · position: (43.9102, -0.8677) · alt: 11894m · 754km/h
  - (2026-09-16) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (36.3525, -4.5918) · alt: 11277m · 790km/h
  - (2026-09-16) SAMU44 (France)
      icao24: 39ca84 · position: (47.566, -1.4546) · alt: 373m · 220km/h
  - (2026-09-16) PUMA62 (Slovenia)
      icao24: 506e18 · position: (45.9089, 15.4892) · alt: 304m · 159km/h
  - (2026-09-16) PUMA72 (Slovenia)
      icao24: 506e1c · position: (45.9082, 15.4924) · alt: 335m · 151km/h
  - (2026-09-16) GAF169 (Germany)
      icao24: 3ea1cc · position: (38.5766, 20.9088) · alt: 10050m · 772km/h

### Court opinions of consequence (federal & state) — 27 new of 60 total
  - (2026-09-15) U.S. Court of Appeals, 3rd Cir.: United States v. Davone Walker
  - (2026-09-15) U.S. Court of Appeals, 3rd Cir.: United States v. Davone Walker
  - (2026-09-15) U.S. Court of Appeals, 8th Cir.: Dr. Scott Jensen v. Minn. Bd. of Medical Practice
  - (2026-09-15) U.S. Court of Appeals, 5th Cir.: East Fork Enterprises v. EPA
  - (2026-09-15) U.S. Court of Appeals, 5th Cir.: Ramirez v. Guerrero
  - (2026-09-15) U.S. Court of Appeals, 5th Cir.: Harward v. City of Austin

### Government Action: Sanctions + Procurement + Foreign Agents — 19 new of 108 total
  - (2026-09-14) [OFAC] Iran-related Designation; Issuance of Amended Venezuela-related General License and Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Iran-related Designation; Issuance of Amended Venezuela-related General License and Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-09-14) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 52C Authorizing Certain Tr - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 52C Authorizing Certain Tr Office of Foreign Assets Control (.gov)
  - (2026-09-10) [OFAC] Iran-related and Counter Terrorism Designations; Licensing Policy Update under Operation Economic Outcast; Settlement Agreement between OFAC and an Individual - Office of Foreign Assets Control…
      Iran-related and Counter Terrorism Designations; Licensing Policy Update under Operation Economic Outcast; Settlement Agreement between OFAC and an Individual Office of Foreign Assets Control (.gov)
  - (2026-09-09) [OFAC] Transnational Criminal Organizations Designations; Counter Terrorism Designation; Issuance of New and Amended Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Transnational Criminal Organizations Designations; Counter Terrorism Designation; Issuance of New and Amended Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-09-10) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-09-10) [OFAC] IRANIAN TRANSACTIONS AND SANCTIONS REGULATIONS STATEMENT OF LICENSING POLICY ON IRAN-RELATED REQUESTS Consistent with current U. - Office of Foreign Assets Control (.gov)
      IRANIAN TRANSACTIONS AND SANCTIONS REGULATIONS STATEMENT OF LICENSING POLICY ON IRAN-RELATED REQUESTS Consistent with current U. Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 13 new of 124 total
  - (2026-09-16) [Polymarket] Will an AI lab announce another Millennium Prize solution by December 31, 2026?
      This market will resolve to "Yes" if an eligible AI lab, or an official representative of an eligible AI lab, announces that the lab has solved any of the qualifying Millennium Prize Problems by 11:59 PM ET of the date s…
  - (2026-09-16) [Manifold] Will anyone be impeached by the US House of Representatives in 2027?
  - (2026-09-16) [Manifold] US Average Gas Price Is $4.4500 or more on September 21 2026?
  - (2026-09-16) [Manifold] Will the unreleased new Ninebot M5 MK2 come with native (factory) Apple CarPlay
  - (2026-09-16) [Manifold] 9月16号总统Trump会死吗
  - (2026-09-16) [Manifold] Will a rogue AI kill a human before 2030?

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-09-16) M 5.1 - 172 km ESE of Saipan, Northern Mariana Islands
      M5.1 · 172 km ESE of Saipan, Northern Mariana Islands · depth 10 km
  - (2026-09-16) M 5.0 - 281 km SSE of Dunhuang, China
      M5.0 · 281 km SSE of Dunhuang, China · depth 10.46 km
  - (2026-09-16) M 5.0 - 60 km SSW of Ocós, Guatemala
      M5.0 · 60 km SSW of Ocós, Guatemala · depth 10 km
  - (2026-09-16) M 4.8 - 47 km WSW of Bahía Solano, Colombia
      M4.8 · 47 km WSW of Bahía Solano, Colombia · depth 10 km
  - (2026-09-16) M 4.7 - 6 km WSW of Port-Olry, Vanuatu
      M4.7 · 6 km WSW of Port-Olry, Vanuatu · depth 60.686 km
  - (2026-09-15) M 4.7 - 161 km N of Caluula, Somalia
      M4.7 · 161 km N of Caluula, Somalia · depth 10 km

### U.S. Federal Action — 11 new of 11 total
  - (2026-09-16) Revised Medical Criteria for Evaluating Cardiovascular Disorders
  - (2026-09-16) Continuation of the National Emergency With Respect to Persons Who Commit, Threaten To Commit, or Support Terrorism
  - (2026-09-16) Indiana: Approval of State Coal Combustion Residuals Permit Program
      The Environmental Protection Agency (EPA or the Agency) is proposing to approve Indiana's Coal Combustion Residuals (CCR) partial permit program under the Resource Conservation and Recovery Act (RCRA). After reviewing th…
  - (2026-09-16) Racial Nondiscrimination in Private Schools; Hearing
      This document provides a notice of public hearing on the notice of proposed rulemaking (REG-119986-25) published in the Federal Register on September 4, 2026. The proposed regulations would update existing regulations to…
  - (2026-09-16) Whistleblower Award Determination
      The Commodity Futures Trading Commission ("Commission" or "CFTC") is amending its rules implementing section 23 of the Commodity Exchange Act ("CEA"). Section 23 of the CEA and the Commission's implementing regulations p…
  - (2026-09-16) Annual Fireworks Displays and Other Events in the USCG Heartland District Requiring Safety Zones
      The Coast Guard will enforce a safety zone for the University of Pittsburgh Drone Show on September 17, 2026, to provide for the safety of life on navigable waterways during this event. Our regulation for annual firework…

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-09-16) Will FC Barcelona win on 2026-09-16?
      yes price: 92% · 24h volume: $471,200 · resolves 2026-09-16
  - (2026-09-16) Sao Paulo Open: Xiaodi You vs Alina Charaeva
      yes price: 38% · 24h volume: $375,804 · resolves 2026-09-21
  - (2026-09-16) Will Gavin Newsom win the 2028 Democratic presidential nomination?
      yes price: 16% · 24h volume: $337,535 · resolves 2028-11-07
  - (2026-09-16) Will Bitcoin dip to $45,000 by December 31, 2026?
      yes price: 8% · 24h volume: $336,698 · resolves 2027-01-01
  - (2026-09-16) Will the U.S. invade Iran before 2027?
      yes price: 18% · 24h volume: $293,721 · resolves 2027-01-01
  - (2026-09-16) Will Ségolène Royal win the 2027 French presidential election?
      yes price: 0% · 24h volume: $284,259 · resolves 2027-04-30

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-16) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=11, 7d-median=19, 14d-median=17; carrying terms: program, guard, unless, vessels, certain, authorized, commission, proposes, proposed, prohibited, navigable, coast
- state_bills: today=79, 7d-median=97, 14d-median=88; carrying terms: program, coverage, districts, providing, including, assistance, transportation, policies, generally, provisions, powers, available
- state_news: today=824, 7d-median=708, 14d-median=586; carrying terms: style, illinois, bring, despite, srcset, developers, media, ctmirror, ballot, individual, green, connecticut
- local_news: today=244, 7d-median=236, 14d-median=230; carrying terms: games, center, missouri, health, september, season, shooting, culture, charged, former, drive, county
- foreign_news: today=1045, 7d-median=986, 14d-median=1004; carrying terms: peace, media, accused, banking, daily, diversity, estimated, month, plant, content, renewed, southern
- chinese_internal: today=298, 7d-median=285, 14d-median=282; carrying terms: cbmiykfvx, lxtfa, property, cbmibkfvx, cbmidefvx, cbmiakfvx, cbmickfvx, caixin, target, china, politics, google
- russian_internal: today=1192, 7d-median=1059, 14d-median=1050; carrying terms: httperror, laquo, group, russian, reuters, media, novaya, bloomberg, blank, target, found, politico
- ukrainian_internal: today=139, 7d-median=136, 14d-median=134; carrying terms: including, despite, peace, early, following, infrastructure, overnight, ballistic, international, talks, center, visit
- ukraine_theater: today=330, 7d-median=330, 14d-median=451; carrying terms: coverage, armed, branch, kuwlxx, tytwk, cbmir, ilwttethdewnsmkszoedmz, dquzjlznvoeln, tyellwoujqegfda, prawi, daily, xzvlutntmejfshzxvv
- paper_bets: today=124, 7d-median=128, 14d-median=130; carrying terms: supervolcano, growth, texas, leader, virginia, chair, kylian, become, playoff, pirates, nomination, colorado
- weather: today=114, 7d-median=106, 14d-median=110; carrying terms: texas, bring, northern, conditions, including, ruskin, seattle, lower, below, values, beaches, generally
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: personal, dcoilwtico, nonfarm, recession, jtsjol, growth, rates, payems, walcl, openings, labor, consumption
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, close, russell, china, range, large, equities, crypto, yield, futures, rates, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=108, 14d-median=107; carrying terms: program, sovereignty, armed, sectoral, aeronautics, venezuela, bombing, transportation, guinea, license, cbmixkfvx, mission
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, error, quiverquant, unauthorized, congresstrading, httperror, https, quantitative, quiver
- billionaires: today=30, 7d-median=0, 14d-median=15; carrying terms: julia, diversified, gates, walton, canada, madrid, finance, ambani, velasco, francoise, china, peterffy
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, state, supreme, court, company, rivera, robert, connecticut, trade, international, florida, allen
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, trust, filer, subject, charles, jonathan, brian, financial
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: booker, angels, robert, shawn, cooper, elect, talarico, ocasio, filing, warner, senate, receipts
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: hezbollah, english, israel, sanctions, turkish, attack, minister, iranian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, canada, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: severe, recombination, individuals, nationwide, onboard, paralytic, kinshasa, material, seasonal, geographical, districts, government
- cisa_kev: today=23, 7d-median=23, 14d-median=22; carrying terms: missing, kludex, sangoma, request, artifactory, sonicwall, appliances, improper, critical, jfrog, smuggling, berriai
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=13, 7d-median=12, 14d-median=12; carrying terms: depth, islands, indonesia, vanuatu, japan, colombia, argentina
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: championship, shakhtar, rates, change, volume, september, interest, league, donetsk, resolves, price, champions
- commentary: today=0, 7d-median=6, 14d-median=6; carrying terms: economist, marginal, class, conversable, revolution, conversableeconomist, evidence, https, story, recent, marginalrevolution, explain
- tech_news: today=50, 7d-median=57, 14d-median=56; carrying terms: spectrum, computer, against, infrastructure, artificial, vulnerability, record, software, today, cybersecurity, years, development
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: gorsuch, friedman, ernst, gallego, cindy, pallone, celeste, mfume, massie, bacon, grothman, rubio
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, evidence, paper, today, module, placement, placed, markets, decision, claude, converges, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-10] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-11] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy
- [2026-09-12] ECB press: Christine Lagarde: Interview with Ouest-France
- [2026-09-14] ECB press: Isabel Schnabel: Macroeconomic, fiscal and financial stability in a shock-prone world
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI
- [2026-09-16] ECB press: ECB wage tracker at 2.7% in H1 2027, pointing to a modest uptick in negotiated wage growth

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*