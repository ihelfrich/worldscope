# WORLDSCOPE morning brief — 2026-11-13

## Headline
2078 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (451) · Russian Internal News (state + in-exile) (389) · World leaders & government officials (324) · Chinese Internal News (206) · GDELT GKG — themes / entities / watch areas (143) · U.S. Weather + Severe / Climate Outlooks (104) · World News (by country, top stories) (103) · Local News: St. Louis + Atlanta (61) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · State-Level News (37) · Ukraine Theater (total-war monitoring) (32)

## What changed today
### International News + Multilateral Institutions — 451 new of 997 total
  - (2026-11-13) [Global] Nvidia scandal sparks US national security furore and calls to take tough line on China
  - (2026-11-13) [Global] Teen prodigy, Netflix star, prisoner: the story of Hong Kong dissident Joshua Wong – podcast
  - (2026-11-13) [Global] A baffling trail from Australia to Singapore: what is Megaspeed, the company implicated in downfall of Nvidia’s Jensen Huang?
  - (2026-11-13) [Global] Victoria election 2026: Labor and Greens trade accusations of ‘dodgy deals’ as preference fight puts key seats at risk
  - (2026-11-13) [Global] ‘If I wanted to plan a murder’: Beau Lamarre-Condon tells court what he would have done
  - (2026-11-13) [Global] Minister’s office said contractor should handle CFMEU or lose work in Victoria, Big Build inquiry hears

### Russian Internal News (state + in-exile) — 389 new of 1075 total
  - (2026-11-13) Страховка для российских дата-центров от атак беспилотников сильно подорожала. В отдельных случаях — более чем в 100 раз | LEDE: В России резко выросла страховка для дата-центров, сообщает «] (ru: Стр…
      В России резко выросла страховка для дата-центров, сообщает «Коммерсант».
  - (2026-11-13) «Коммерсант»: правительство одобрило законопроект о беспилотных автомобилях, трамваях и такси. В Москве такой транспорт ходит по маршруту уже год | LEDE: Правительство России на заседании 12] (ru: «Ко…
      Правительство России на заседании 12 ноября одобрило финальную редакцию законопроекта «О высокоавтоматизированных транспортных средствах» (ВАТС), пишет «Коммерсант», ознакомившийся с документом.
  - (2026-11-13) В работе Microsoft произошел глобальный сбой. Последствия затронули OpenAI и Anthropic | LEDE: Пользователи Microsoft в разных странах мира столкнулись со сбоем в работе сервисов, включая Ou] (ru: В р…
      Пользователи Microsoft в разных странах мира столкнулись со сбоем в работе сервисов, включая Outlook, Teams и Copilot.
  - (2026-11-13) Украина атаковала Волгоградский НПЗ, на предприятии пожар, есть погибшие. На заправках появились очереди | LEDE: Украинские беспилотники атаковали Волгоградскую область, загорелось предприят] (ru: Укр…
      Украинские беспилотники атаковали Волгоградскую область, загорелось предприятие, есть погибшие, сообщил глава региона Андрей Бочаров.
  - (2026-11-13) Кушнер заявил, что Украина и Россия готовят крупнейший за время войны обмен пленными | LEDE: США работают над организацией крупнейшего с начала войны обмена пленными между Россией и Украиной] (ru: Куш…
      США работают над организацией крупнейшего с начала войны обмена пленными между Россией и Украиной. Об этом спецпосланник президента США Джаред Кушнер написал в соцсети икс после встречи с президентом Украины Владимиром З…
  - (2026-11-13) Власти решили изъять из банков деньги и золото умерших россиян. По их мнению, это поможет в борьбе с США и другими «недружественными» странами. Но при чем здесь эти страны? И сколько таких дене] (ru:…
      В начале ноября Владимир Путин издал указ «О некоторых особенностях передачи в собственность РФ выморочного имущества». Этот документ создает механизм изъятия государством из банков сбережений умерших россиян, у которых…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 206 new of 331 total
  - (2026-11-13) 【市场动态】FOMO心态促使对冲基金抓紧扩大香港办公室 推动核心地段租金飙升 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9LbXp2eVVuYTQ2MXJOVFFXdnMtUXFOT1JpSl8tbHk0U0VtRTBORHBzclBULXpJeFBxQXNaNmltbEI4c] (zh:…
      【市场动态】FOMO心态促使对冲基金抓紧扩大香港办公室 推动核心地段租金飙升 财新数据
  - (2026-11-13) 人事观察｜中国工程院院士柏连阳升任西北农大校长 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE1WLV9uVmh2VXhvVVBJOTMyRDlaLUJjUEtnZThEMnJva2NUWjhWYU13Uzg4TWFKaEFldWdKYW1fbVJqYmdtWVVVTFluQlFHNW] (zh:…
      人事观察｜中国工程院院士柏连阳升任西北农大校长 财新
  - (2026-11-12) 财经早知道｜长鑫科技最新发声 算力超级周期迈入分层时代 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE4xTnB0UVZYNG1FTlJfTjBIM2RUeHBsQTU5NmlzMENMRmtvcmFQSlEwb2VuX0VHMkRGUlZ0UFp3eTBTbTcwY041V2JnSl] (zh:…
      财经早知道｜长鑫科技最新发声 算力超级周期迈入分层时代 财新
  - (2026-11-13) 人事观察｜京黑纪委主官换将 中央纪委官员“空降” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFA0TUlLckxZMVRPUXFubHVsdkh3QlNNc3Z1TzhEUHp3Qkt1T1M0ZHNEcFZXM3Y1dEFuWlQ0YW5Hb0I1MFozWFJiZkhUWGhjZ] (zh:…
      人事观察｜京黑纪委主官换将 中央纪委官员“空降” 财新
  - (2026-11-13) 刘世锦：建立具有全球影响力和竞争力的中国消费市场 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5kb3EtYVhrYm5PQ3pzX2FyRVdibnhaLVFtMF9OX0RleU52RG13OUNQeUVLX3FMZlJSalF2MXFPQk9XSHpzLVhFaG9XTGw1T] (zh:…
      刘世锦：建立具有全球影响力和竞争力的中国消费市场 财新
  - (2026-11-13) 金价，跌回一年前 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE15X2tKWjBqYV9TT1J2eGUzT3NEVkI3UkZwVzFHSEFabXQ1UVJWRnhrVDdVMFdnY1NUWWx1NkxraE9SRXM5Y3lRQk14SG1LTmpJMFBCTE1tQjVWd] (zh:…
      金价，跌回一年前 财新

### GDELT GKG — themes / entities / watch areas — 143 new of 143 total
  - (2026-11-13) [Russia oil sanctions perimeter · themes] Ukraine War: Drone And Missile Warfare Dominating Combat Operations - Analysis
      eurasiareview.com · English · tone -5.18909410729991
  - (2026-11-13) [Russia oil sanctions perimeter · near] Zelenskyy meets Witkoff, Kushner in Ireland; announces major prisoner exchange, greater European role in Ukraine peace talks
      webindia123.com · English · tone 0.935828877005348 · 123 other outlets
  - (2026-11-13) [Russia oil sanctions perimeter · near] US and Russia know Ukraine deal impossible without Europe, Taoiseach says
      irishtimes.com · English · tone -1.6025641025641 · 27 other outlets
  - (2026-11-13) [Russia oil sanctions perimeter · near] Putin had four plans to defeat Ukraine. He only has two left.
      hindustantimes.com · English · tone -4.00471142520612 · 24 other outlets
  - (2026-11-13) [Russia oil sanctions perimeter · near] US envoys meet with Putin, Zelenskyy
      wmtw.com · English · tone -2.92887029288703 · 23 other outlets
  - (2026-11-13) [Russia oil sanctions perimeter · near] Kremlin Pours Cold Water On Europe Joining Talks Amid Kushner-Witkoff Visit
      zerohedge.com · English · tone 1.50214592274678 · 19 other outlets

### U.S. Weather + Severe / Climate Outlooks — 104 new of 113 total
  - (2026-11-13) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 13 at 1:19AM CST until November 13 at 12:00PM CST by NWS Chicago IL
      * WHAT...Locally slippery travel due to lake effect snow expected. Localized snow totals in excess of 3 inches expected. * WHERE...In Illinois, Eastern Will and Southern Cook Counties. In Indiana, Lake IN County. * WHEN.…
  - (2026-11-13) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-13) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 13 at 12:13AM MST until November 13 at 11:00AM MST by NWS Billings MT
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Carter and Fallon. * WHEN...Until 11 AM MST this morning. * IMPACTS...Low visibility could make driving conditions hazardous. * ADDITIONAL DETAILS...Be…
  - (2026-11-12) [Severe] Winter Storm Warning: Winter Storm Warning issued November 12 at 11:11PM PST until November 14 at 4:00PM PST by NWS Las Vegas NV
      * WHAT...Heavy snow possible above 7000 feet. Total snow accumulations of 5 to 10 inches expected...with up to 1 foot near the Sierra Crest. * WHERE...Eastern Sierra Slopes. * WHEN...From 1 PM Friday to 4 PM PST Saturday…
  - (2026-11-12) [Moderate] Wind Advisory: Wind Advisory issued November 12 at 11:06PM PST until November 14 at 1:00AM PST by NWS Las Vegas NV
      * WHAT...South winds 25 to 35 mph with gusts up to 45 mph expected. * WHERE...Northern Owens Valley. * WHEN...From 10 AM Friday to 1 AM PST Saturday. * IMPACTS...Gusty winds will blow around unsecured objects. Tree limbs…
  - (2026-11-12) [Moderate] Wind Advisory: Wind Advisory issued November 12 at 11:06PM PST until November 14 at 10:00AM PST by NWS Las Vegas NV
      * WHAT...South winds 20 to 30 mph with gusts up to 50 mph expected. * WHERE...Death Valley National Park and Western Mojave Desert. * WHEN...From 4 PM Friday to 10 AM PST Saturday. * IMPACTS...Gusty winds will blow aroun…

### World News (by country, top stories) — 103 new of 103 total
  - (2026-11-13) [Brazil] How Brazilian coffee producers see China as more than an export destination
      china.org.cn · English · 1 other outlets ran this story
  - (2026-11-13) [Brazil] Latin America Mood Today: Brazil Votes, Argentina Stalls
      riotimesonline.com · English
  - (2026-11-13) [Brazil] Brazil unveils plan to mobilize 7 bln USD for climate projects-Xinhua
      english.news.cn · English
  - (2026-11-13) [Brazil] India, Brazil join hands to develop satellite launch vehicle
      venezuelastar.com · English
  - (2026-11-13) [Brazil] TVS Motor opens first Brazil store, targets 130,000-unit capacity by 2027
      business-standard.com · English
  - (2026-11-13) [Brazil] Yokogawa Receives Order from Brazilian Mining Company Samarco to Supply Control and Safety Systems - Mining / Metal / Mineral - Yokogawa Electric Corporation
      newswiretoday.com · English

### Local News: St. Louis + Atlanta — 61 new of 266 total
  - (2026-11-13) [St. Louis] Fitness instructor helps lead 60 people to safety during deadly shooting at DC gym
      A longtime fitness instructor said he relied on active shooter training to help dozens of gym members hide as gunfire erupted at the Washington, D.C., facility.
  - (2026-11-13) [St. Louis] Daddy Yankee and Rosalía shine at the 2026 Latin Grammy Awards with stunning performances and wins
      Daddy Yankee won person of the year at the 2026 Latin Grammys on Thursday night in Las Vegas, with an award presented by Janet Jackson.
  - (2026-11-13) [St. Louis] 2 children, 6 adults dead in Brooklyn building collapse; rescue operations complete
      Two of the eight people killed when an apartment building collapsed in Brooklyn were children, according to New York City's mayor.
  - (2026-11-13) [St. Louis] Van Hollen to challenge Schumer for Senate Democratic leader
      Democratic Sen. Chris Van Hollen of Maryland said he will run for Senate majority leader in the next Congress.
  - (2026-11-13) [St. Louis] Scammers stole his image to lure in lovesick victims. Then the victims came looking for him.
      For eight years, romance scammers have used one Mississippi man's photo to create hundreds of fake profiles. The victims have come after him.
  - (2026-11-13) [St. Louis] 'Star Wars: A New Hope' came out almost 50 years ago. Here's how you can celebrate.
      "Star Wars: A New Hope" premiered in movie theaters almost 50 years ago, and next year, Lucasfilm is celebrating by bringing it back to the big screen.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-13) [KAO MIN H] Form 4 (Reporting)
      filed 2026-11-13 02:55 UTC · role: Reporting — Filed: 2026-11-12 AccNo: 0001193125-26-459015 Size: 5 KB
  - (2026-11-13) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-11-13 02:55 UTC · role: Issuer — Filed: 2026-11-12 AccNo: 0001193125-26-459015 Size: 5 KB
  - (2026-11-13) [Perez Anton Jose Antonio] Form 4 (Reporting)
      filed 2026-11-13 02:36 UTC · role: Reporting — Filed: 2026-11-12 AccNo: 0001104659-26-126429 Size: 8 KB
  - (2026-11-13) [SOUTHEAST AIRPORT GROUP] Form 4 (Issuer)
      filed 2026-11-13 02:36 UTC · role: Issuer — Filed: 2026-11-12 AccNo: 0001104659-26-126429 Size: 8 KB
  - (2026-11-13) [Hamilton Thomas Edward] Form 4 (Reporting)
      filed 2026-11-13 02:32 UTC · role: Reporting — Filed: 2026-11-12 AccNo: 0001193125-26-459008 Size: 6 KB
  - (2026-11-13) [Larimar Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-11-13 02:32 UTC · role: Issuer — Filed: 2026-11-12 AccNo: 0001193125-26-459008 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-13) [Russia] US asks Russia to propose new security deal with Europe as Trump pushes for Ukraine peace talks: Report
      domain: irishsun.com · language: English · tone: -0.934579439252336 · 144 other outlets ran this story
  - (2026-11-13) [United States] Van Hollen to challenge Schumer for Senate Democratic leader - Boston News, Weather, Sports
      domain: whdh.com · language: English · tone: 2.15384615384615 · 122 other outlets ran this story
  - (2026-11-13) [Ukraine] RIGHT SPEAK: 168 Combat Clashes (12 Kostiantynivka, 11 Pokrovsk, 7 Huliaipole); Zelensky: Starshield Speed Limits Again; Kushner & Witkoff Meet Putin; Ohryzko: US Diplomacy Still Favors RU;…
      domain: rightspeak.net · language: English · tone: -5.60165975103734 · 110 other outlets ran this story
  - (2026-11-13) [Egypt] US Senator Chris Van Hollen seeks to lead Democrats: Who is he?
      domain: aljazeera.com · language: English · tone: -1.76730486008837 · 90 other outlets ran this story
  - (2026-11-13) [Iran] Would not hesitate to strike Iran if things go other way: Trump says "they will not exist" if Tehran kills US officials
      domain: indiatimes.com · language: English · tone: -5.1063829787234 · 82 other outlets ran this story
  - (2026-11-13) [Ireland] Fifty leaders came to Dublin, but Zelenskyy's meeting with Trump's envoys stole the show
      domain: thejournal.ie · language: English · tone: 0.704225352112676 · 79 other outlets ran this story

### State-Level News — 37 new of 717 total
  - (2026-11-13) [Connecticut] A new president for UConn might be worse than Ritter
      <img width="1024" height="707" src="https://ctmirror.org/wp-content/uploads/2026/11/Gampel-with-mt-scaled-e1794514798210-1024x707.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=…
  - (2026-11-13) [Connecticut] Fazio is not Superman
      <img width="980" height="543" src="https://ctmirror.org/wp-content/uploads/2026/11/Fazio-a-hero.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctmirror.or…
  - (2026-11-13) [Connecticut] Health care needs payment reform
      <img width="1024" height="885" src="https://ctmirror.org/wp-content/uploads/2019/02/stethescope-and-patient-e1549898743125.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-11-13) [Connecticut] Blue Ribbon Commission on education settles on key policy ideas
      <img width="1024" height="684" src="https://ctmirror.org/wp-content/uploads/2026/04/Natalie-Wagner-ECS-presser-4.16.26-1024x684.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="as…
  - (2026-11-12) [Colorado] Gov. Polis pardons 27 people convicted of crimes in Colorado
      Colorado Gov. Jared Polis on Friday granted 27 pardons to people convicted of various crimes in the state over the last several decades. One of those pardons went to Vanessa Peoples, who police charged with reckless enda…
  - (2026-11-13) [Florida] Election denialism losing steam as Trump flip flops on accepting midterm results
      The day after Democrats won sweeping victories in the midterm elections, an Arizona county official delivered a stark warning to his fellow Republicans about election denialism — it needed to stop. The state has been a h…

### Ukraine Theater (total-war monitoring) — 32 new of 268 total
  - (2026-11-13) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-12) [Liveuamap] Houthi forces… – Lahij Governorate, Yemen - Liveuamap
      Houthi forces… – Lahij Governorate, Yemen Liveuamap
  - (2026-11-12) [Liveuamap] Yemen live map: Houthis and Red Sea today | Liveuamap - Liveuamap
      Yemen live map: Houthis and Red Sea today | Liveuamap Liveuamap
  - (2026-11-10) [Liveuamap] President Donald Trump says the US-Israel war on Iran is "effectively over" militarily, adding that further military action against Tehran "doesn&039;t seem to be a very necessary thing."…
      President Donald Trump says the US-Israel war on Iran is "effectively over" militarily, adding that further military ac
  - (2026-11-08) [Liveuamap] Cincinnati police are investigating a shooting that left a teenager with injuries in Westwood late Saturday night - Liveuamap
      Cincinnati police are investigating a shooting that left a teenager with injuries in Westwood late Saturday
  - (2026-11-07) [Liveuamap] Eight people injured after vehicle strikes seven high school students – University Blvd, Orlando, FL, USA - Liveuamap
      Eight people injured after vehicle strikes seven high school students – University Blvd, Orl

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Ukrainian Internal News (national + local Kyiv) — 28 new of 132 total
  - (2026-11-13) Від турецького підданства до московського заслання. Чому гетьман Дорошенко не такий поганий, яким його малювали вороги | LEDE: ] (uk: Від турецького підданства до московського заслання. Чому гетьман Д…
  - (2026-11-13) Естонія видворить українця, засудженого за масштабне телефонне шахрайство | LEDE: Хар'юський повітовий суд в Естонії засудив 37-річного громадянина України Максима Андрейкіна до двох років і ше] (uk:…
      Хар'юський повітовий суд в Естонії засудив 37-річного громадянина України Максима Андрейкіна до двох років і шести місяців позбавлення волі умовно за участь у схемі телефонного шахрайства та постановив вислати його з кра…
  - (2026-11-13) Кошта про представника Європи у переговорах: Ми діємо як одна команда | LEDE: ] (uk: Кошта про представника Європи у переговорах: Ми діємо як одна команда)
  - (2026-11-13) Росіяни вдарили по Одесі реактивними дронами: двоє людей загинули, п’ятеро поранені | LEDE: Уранці 13 листопада російські окупаційні війська атакували Одесу ударними безпілотниками, унаслідок ч] (uk:…
      Уранці 13 листопада російські окупаційні війська атакували Одесу ударними безпілотниками, унаслідок чого двоє людей загинули, ще п'ятеро дістали поранення.
  - (2026-11-13) Віткофф заявив, що наступна зустріч переговорних команд вже запланована | LEDE: Спеціальний представник президента США Стів Віткофф заявив, що наступна зустріч переговорних команд у межах зусил] (uk:…
      Спеціальний представник президента США Стів Віткофф заявив, що наступна зустріч переговорних команд у межах зусиль із припинення війни вже запланована.
  - (2026-11-13) Іран заявив про знищення американського радара раннього попередження в Бахрейні | LEDE: Корпус вартових ісламської революції (КВІР) заявив про ураження американського радара раннього попереджен] (uk:…
      Корпус вартових ісламської революції (КВІР) заявив про ураження американського радара раннього попередження на острові Бахрейн у відповідь на авіаудар по телевежі на півдні Ірану.

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 97 total
  - (2026-11-13) [USASpending] $237,279,120 → BOOZ ALLEN HAMILTON INC: EUROPEAN THEATER OPERATIONS AND PLANNING SERVICES ETOPS
      Agency: General Services Administration. Description: EUROPEAN THEATER OPERATIONS AND PLANNING SERVICES ETOPS
  - (2026-11-13) [USASpending] $235,870,832 → DELOITTE CONSULTING LLP: PROGRAM MANAGEMENT SUPPORT SERVICES
      Agency: Department of State. Description: PROGRAM MANAGEMENT SUPPORT SERVICES
  - (2026-11-13) [USASpending] $220,916,162 → MAPP BIOPHARMACEUTICAL, INC.: PROCUREMENT OF THERAPEUTICS FOR EBOLA, SUDAN AND MARBURG VIR
      Agency: Department of Health and Human Services. Description: PROCUREMENT OF THERAPEUTICS FOR EBOLA, SUDAN AND MARBURG VIRUSES
  - (2026-11-13) [USASpending] $215,862,913 → WALSH CONSTRUCTION COMPANY II, LLC: CONSTRUCTION LONG TERM SPINAL CORD INJURY VAMC NORTH DALLAS,
      Agency: Department of Veterans Affairs. Description: CONSTRUCTION LONG TERM SPINAL CORD INJURY VAMC NORTH DALLAS, TX
  - (2026-11-13) [USASpending] $210,650,842 → NELNET SERVICING LLC: OPERATIONS AND MAINTENANCE (O&M) TASK ORDER FOR STUDENT LOAN
      Agency: Department of Education. Description: OPERATIONS AND MAINTENANCE (O&M) TASK ORDER FOR STUDENT LOAN SERVICING IN ACCORDANCE WITH THE REQUIREMENTS OF THE USDS CONTRACT. ALL WORK AND DELIVERABLES PROVIDED BY THE USD…
  - (2026-11-13) [USASpending] $200,714,384 → LUMEN TECHNOLOGIES GOVERNMENT SOLUTIONS, INC.: USDANET ENTERPRISE INFRASTRUCTURE SOLUTIONS
      Agency: Department of Agriculture. Description: USDANET ENTERPRISE INFRASTRUCTURE SOLUTIONS

### Government & military aircraft airborne (OpenSky) — 13 new of 13 total
  - (2026-11-13) CFC01 (Canada)
      icao24: c2c36d · position: (62.4129, -149.8214) · alt: 7094m · 623km/h
  - (2026-11-13) SAMU44 (France)
      icao24: 39ca84 · position: (47.247, -1.4279) · alt: 304m · 161km/h
  - (2026-11-13) FNY5060 (France)
      icao24: 39a408 · position: (47.57, -1.9762) · alt: 11277m · 787km/h
  - (2026-11-13) JAF6GT (Belgium)
      icao24: 44d1ba · position: (39.7262, -7.5675) · alt: 10668m · 753km/h
  - (2026-11-13) JAF78M (Belgium)
      icao24: 44d1a6 · position: (39.6718, -9.653) · alt: 11277m · 746km/h
  - (2026-11-13) JAF7YC (Belgium)
      icao24: 44d1a7 · position: (42.3988, -10.4668) · alt: 11277m · 810km/h

### Paper Trading Scorecard — 12 new of 84 total
  - (2026-11-13) [Polymarket] Will Lovable be acquired before 2027?
      This market will resolve to “Yes” if credible reporting confirms that any entity enters into an agreement to acquire the listed company by December 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to “No”. Merg…
  - (2026-11-13) [Polymarket] Will Spider-Man: Brand New Day be the top grossing movie of 2026?
      This market will resolve according to the title of the film with the highest 2026 gross according to the "Gross" column on https://www.boxofficemojo.com/year/2026/?grossesOption=calendarGrosses once data for December 31…
  - (2026-11-13) [Manifold] Will Jensen Huang be hired by Apple, Microsoft, SpaceX, Tesla, Google, Antrophic, or OpenAI before end of 2026?
  - (2026-11-13) [Manifold] Will J-Coasta get a girlfriend by the end of 2026?
  - (2026-11-13) [Manifold] Will GPT Astra 6.1+ be released by November 20, 2026?
  - (2026-11-13) [Manifold] Will The identity of the person in the 3rd Jensen Huang affair be released before GTA6?

### GDACS — global disaster alerts — 12 new of 100 total
  - (2026-11-13) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.7M, Depth:9.626km
  - (2026-11-13) [Green] Earthquake in Mariana Islands
      Earthquake · Green alert · Mariana Islands · Magnitude 4.9M, Depth:219.572km
  - (2026-11-13) [Green] Earthquake in Fiji
      Earthquake · Green alert · Fiji · Magnitude 4.5M, Depth:527.134km
  - (2026-11-13) [Green] Earthquake in Democratic Republic of the Congo
      Earthquake · Green alert · Democratic Republic of the Congo · Magnitude 5M, Depth:10km
  - (2026-11-13) [Green] Earthquake in Greece
      Earthquake · Green alert · Greece · Magnitude 5.1M, Depth:43.358km
  - (2026-11-06) [Green] Forest fires in Burkina Faso, Mali
      Wildfire · Green alert · Burkina Faso, Mali · Green impact for forestfire in 5370 ha

### Prediction Markets — most-traded (Polymarket) — 8 new of 20 total
  - (2026-11-13) Louisiana-Lafayette Ragin' Cajuns vs. UNCW Seahawks
      yes price: 48% · 24h volume: $1,278,059 · resolves 2026-11-15
  - (2026-11-13) Counter-Strike: Vitality vs MOUZ (BO3) - BLAST Rivals Playoffs
      yes price: 56% · 24h volume: $708,119 · resolves 2026-11-13
  - (2026-11-13) Will the Fed decrease interest rates by 50+ bps after the December 2026 meeting?
      yes price: 0% · 24h volume: $640,844 · resolves 2026-12-09
  - (2026-11-13) Brisbane 3: Bernard Tomic vs August Holmgren
      yes price: 0% · 24h volume: $391,128 · resolves 2026-11-20
  - (2026-11-13) Will JD Vance win the 2028 US Presidential Election?
      yes price: 13% · 24h volume: $299,140 · resolves 2028-11-08
  - (2026-11-13) Will there be no new be CEO of NVIDIA by December 31, 2028?
      yes price: 8% · 24h volume: $276,492 · resolves 2029-01-01

### Court opinions of consequence (federal & state) — 6 new of 60 total
  - (2026-11-12) Hawaii Supreme Court: Choi v. Association of Apartment Owners of Queen Emma Gardens and Touchstone Properties LTD.
  - (2026-11-12) Illinois Supreme Court: People v. Johnson
  - (2026-11-12) Idaho Supreme Court: John Kumm and Cheryl Kumm v. the Work Shop & Sons Ltd, & Kyle Cromer and Jessica Cromer
  - (2026-11-09) Idaho Supreme Court: Chasidy Decker and Robert Calacal v. City of Meridian and Mayor Robert Simison
  - (2026-11-09) Idaho Supreme Court: Craig Colton v. the Overlook at Fox Creek Subdivision
  - (2026-11-06) Alaska Supreme Court: State v. Albertsons Companies, Inc

### Wikidata leader-roster changes (48h) — 5 new of 55 total
  - (2026-11-13) [Belarus] Alexander Lukashenka (Q2866) edited
      /* wbeditentity-update-languages-and-other-short:0||da */ other names, source for date of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])
  - (2026-11-13) [Colombia] Abelardo de la Espriella (Q137204778) edited
      Reverted edits by [[Special:Contributions/~2026-60197-73|~2026-60197-73]] ([[User talk:~2026-60197-73|talk]]) to last revision by [[:User:Madamebiblio|Madamebiblio]]
  - (2026-11-13) [Israel] Isaac Herzog (Q983258) edited
      /* wbsetsitelink-add:1|mnwiki */ Ицхак Херцог
  - (2026-11-13) [Paraguay] Pedro Alliana (Q51885479) edited
      /* wbsetlabel-add:1|th */ เปโดร อาเลียนา
  - (2026-11-13) [Thailand] Rama X of Thailand (Q548733) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/65836|batch #65836]]: Import places from GND

### USGS earthquakes (M4.5+, past day) — 5 new of 12 total
  - (2026-11-13) M 5.1 - 39 km S of Moíres, Greece
      M5.1 · 39 km S of Moíres, Greece · depth 43.358 km
  - (2026-11-13) M 5.0 - 85 km W of Mwene-Ditu, Democratic Republic of the Congo
      M5.0 · 85 km W of Mwene-Ditu, Democratic Republic of the Congo · depth 10 km
  - (2026-11-13) M 4.9 - Pagan region, Northern Mariana Islands
      M4.9 · Pagan region, Northern Mariana Islands · depth 219.572 km
  - (2026-11-13) M 4.7 - 27 km NNE of Labuan Lombok, Indonesia
      M4.7 · 27 km NNE of Labuan Lombok, Indonesia · depth 9.626 km
  - (2026-11-13) M 4.5 - 278 km E of Levuka, Fiji
      M4.5 · 278 km E of Levuka, Fiji · depth 527.134 km

### IT, InfoSys & cybersecurity news (last 7 days) — 5 new of 63 total
  - (2026-11-13) [The Hacker News] Hackers Exploit N-central Flaws to Infect 21 Servers, Including 19 Running Hotfix 2
      N-able on Thursday said it's taking additional precautions in the wake of public disclosure of a new set of flaws tracked as 4EverAble2Shell and Agent2Shell. "We are restricting certain N-central features and integration…
  - (2026-11-13) [The Register] Developer cleverly shrank 2,600 lines of C into a six-line script but still ending up losing sleep
      It wasn't the not-very-legal source code raid that caused it, but a colleague who punted a pager
  - (2026-11-13) [The Register] Singapore says US authorities, and Supermicro, hardly helped investigation of Jensen Huang’s Chinese friend
      Seized passport during probe of suspected paperwork fibs that hid server shipments to parts unknown
  - (2026-11-13) [The Register] Alibaba's Qwen3.8 re-educated with a more Western worldview
      Open weight model can now say things Chinese authorities don't like
  - (2026-11-12) [The Register] DOJ takes aim at $1.2B in Binance loot as FBI disrupts North Korean scam
      ‘FaceStealer’ scam tied to $400M+ theft, 900+ webcam recordings

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 34 total
  - (2026-11-13) MOVER ▲ Tadashi Yanai & family — $69.55B (+$1.43B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-11-13) MOVER ▼ Gautam Adani — $83.88B ($-0.55B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-11-13) MOVER ▼ Zhong Shanshan — $64.94B ($-0.43B since yesterday)
      China · Food & Beverage · source: Beverages, pharmaceuticals
  - (2026-11-13) MOVER ▲ Mukesh Ambani — $92.84B (+$0.09B since yesterday)
      India · Diversified · source: Diversified

### State Legislative Action — 2 new of 40 total
  - (2026-11-11) [Connecticut SB 246] AN ACT REQUIRING A STUDY OF NATURAL GAS RATES FOR COMMERCIAL AND AGRICULTURAL CUSTOMERS.
      AN ACT REQUIRING A STUDY OF NATURAL GAS RATES FOR COMMERCIAL AND AGRICULTURAL CUSTOMERS.
  - (2026-11-13) [ingest error] California: HTTPError
      404 Client Error: Not Found for url: https://v3.openstates.org/bills?jurisdiction=California&updated_since=2026-11-11&include=sponsorships&include=abstracts&per_page=20&page=3&sort=updated_desc

### Commentary & analysis (last 7 days) — 1 new of 6 total
  - (2026-11-13) [Marginal Revolution] Do not overrate zero-sum status-seeking
      If people really preferred relatively higher income in a poorer society, then those born in Western Europe and the US would be saving up their money so they could live like kings in Africa. Very few people of middle- or…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-13) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=28, 7d-median=26, 14d-median=25; carrying terms: regulatory, certain, changes, commission, safety, existing, action, directives, service, provide, final, agency
- state_bills: today=40, 7d-median=97, 14d-median=97; carrying terms: health, insurance, providing, energy, income, program, establishing, relating, authority, vehicle, reporting, emergency
- state_news: today=717, 7d-median=675, 14d-median=717; carrying terms: members, important, attempt, decoding, investigate, spring, alaska, reelection, right, michigan, though, height
- local_news: today=266, 7d-median=265, 14d-median=265; carrying terms: decoding, journal, georgia, trump, today, night, street, target, governor, appeared, color, missouri
- foreign_news: today=997, 7d-median=997, 14d-median=1008; carrying terms: members, monetary, thailand, kingdom, decoding, right, cancer, handling, preview, european, cannot, height
- chinese_internal: today=331, 7d-median=331, 14d-median=321; carrying terms: global, caixin, cbmizefvx, target, cbmib, cbmidefvx, title, color, lxtfb, google, cbmix, cbmiakfvx
- russian_internal: today=1075, 7d-median=1012, 14d-median=951; carrying terms: reuters, bloomberg, client, istories, httperror, axios, apple, gazeta, group, times, media, journal
- ukrainian_internal: today=132, 7d-median=139, 14d-median=134; carrying terms: confirmed, operation, assessment, three, european, midterm, minister, chief, urged, winter, major, offensive
- ukraine_theater: today=268, 7d-median=269, 14d-median=272; carrying terms: vvmgllskr, rwmxkxr, depots, confirmed, zmmxpev, zvnjazg, mnhqm, assessment, yyqus, birthday, cuxonk, kuwlxx
- paper_bets: today=84, 7d-median=71, 14d-median=69; carrying terms: fusion, jinping, drought, visit, general, colonize, levels, regular, goals, growth, succeed, allen
- weather: today=113, 7d-median=135, 14d-median=132; carrying terms: lincoln, marine, waters, flooding, magnitude, chances, detroit, southeast, hazardous, heavy, message, ridge
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: personal, effective, nonfarm, dexjpus, sheet, commodities, rates, recession, assets, supply, cpiaucsl, walcl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, futures, bitcoin, nasdaq, commodities, natural, rates, close, agriculture, corporate, russell, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=97, 7d-median=99, 14d-median=99; carrying terms: detect, congo, google, snapshot, sanctions, democratic, usaspending, aeronautics, performance, related, award, compare
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, httperror, quiverquant, https, congresstrading, unauthorized, error, quiver, quantitative
- billionaires: today=34, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, state, international, court, appeals, blanche, company, connecticut, florida, arkansas, thomas, trade
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, holdings, financial, group, jonathan, richard, garmin
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, disbursements, brown, cooper, alexandria, trone, sayed, abdul, krishnamoorthi, ossoff, peltola
- gdelt_regions: today=103, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=143, 7d-median=25, 14d-median=25; carrying terms: english, russian, sanctions, trump, chinese, themes, russia, perimeter, keywords, hezbollah, french, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=13, 7d-median=24, 14d-median=30; carrying terms: france, position, belgium, canada, aabbef
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: uganda, affecting, congo, months, previously, containing, great, broader, diphtheria, health, genomic, presented
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: secure, google, cisco, product, return, value, vulnerability, vendor, missing, authentication, remediation, numbers
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=55, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: speed, magnitude, earthquake, japan, sudan, south, forest, fires, impact, green, maximum, depth
- usgs_quakes: today=12, 7d-median=14, 14d-median=12; carrying terms: depth, japan, islands, region, indonesia, ridge, indian, guinea, papua, greece
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: presidential, price, volume, resolves, election, championship, donetsk, league, champions, shakhtar, republican, israel
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, conversable, class, marginal, economist, https, published, since, american, world, perspectives, marginalrevolution
- tech_news: today=63, 7d-median=61, 14d-median=61; carrying terms: going, techcrunch, tools, three, vulnerability, compromised, investigation, review, cybersecurity, download, today, computer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: scalise, rivas, raphael, olszewski, victoria, william, diana, yvette, vindman, hinds, blanche, lutnick
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, claude, today, placed, consensus, markets, placement, sufficient, market, evidence, unavailable, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*