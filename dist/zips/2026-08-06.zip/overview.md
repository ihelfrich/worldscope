# WORLDSCOPE morning brief — 2026-08-06

## Headline
4113 new items across 26 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (798) · International News + Multilateral Institutions (784) · Russian Internal News (state + in-exile) (746) · State-Level News (382) · World leaders & government officials (324) · Chinese Internal News (222) · Local News: St. Louis + Atlanta (204) · U.S. Weather + Severe / Climate Outlooks (179) · State Legislative Action (110) · Ukrainian Internal News (national + local Kyiv) (67) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Ukraine Theater (total-war monitoring) — 798 new of 1059 total
  - (2026-08-05) [FIRMS] thermal anomaly 46.801, 33.272 (FRP 8.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 8.02 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.754, 33.625 (FRP 2.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 0947Z, FRP 2.71 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.388, 28.573 (FRP 8.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 8.89 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.041, 23.397 (FRP 6.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 6.74 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.044, 23.396 (FRP 6.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 6.74 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.056, 23.403 (FRP 8.94 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 8.94 MW

### International News + Multilateral Institutions — 784 new of 1049 total
  - (2026-08-06) [Global] Cashing in on SpaceX: 'Every chance I get, I'll sell a little more'
      Andre Lavoie joined SpaceX in 2009 as an engineer, now he's looking to cash in his shares in the company.
  - (2026-08-06) [Global] Iran says deal with Oman on Strait of Hormuz is in final stages
      Neither the US or Oman have commented on the proposed agreement on the vital waterway.
  - (2026-08-05) [Global] Shorts, strappy tops and sandals: What is acceptable to wear in the office?
      Here's how to style for success while keeping your cool - and where you and your boss stand on your wardrobe.
  - (2026-08-06) [Global] Meta becomes latest firm to say its AI hacked another company
      Meta is the latest company to disclose an AI agent breach, raising cyber-security concerns.
  - (2026-08-06) [Global] Raleigh owner starts insolvency proceedings
      Accell, based in the Netherlands, has owned the famous bike brand since 2012.
  - (2026-08-05) [Global] What's causing record high US beef prices?
      The meat has never been more expensive, due to supply shortages, but no-one is making more money.

### Russian Internal News (state + in-exile) — 746 new of 1151 total
  - (2026-08-06) Бывшего посла Украины в США Ольгу Стефанишину обвинили в незаконном обогащении на 14 миллионов гривен (это около 25 миллионов рублей) | LEDE: Национальное антикоррупционное бюро Украины (НАБ] (ru: Быв…
      Национальное антикоррупционное бюро Украины (НАБУ) и Специализированная антикоррупционная прокуратура (САП) объявили, что бывший посол Украины в США Ольга Стефанишина подозревается в незаконном обогащении на 13,9 миллион…
  - (2026-08-06) 77 срочников погибли на границе Курской области во время вторжения ВСУ в 2024 году. Еще более 30 до сих пор числятся пропавшими без вести | LEDE: Как минимум 77 солдат срочной службы погибли] (ru: 77…
      Как минимум 77 солдат срочной службы погибли в первые месяцы боев на границе Курской области во время вторжения ВСУ в 2024 году, выяснили «Важные истории» и «Верстка». На момент гибели срочникам было 18-25 лет, большинст…
  - (2026-08-06) Светлане Тихановской не открыли счет в польском банке из-за просроченного белорусского паспорта | LEDE: Лидер белорусской оппозиции Светлана Тихановская рассказала, что ей не открыли счет в ] (ru: Све…
      Лидер белорусской оппозиции Светлана Тихановская рассказала, что ей не открыли счет в польском банке из-за просроченного белорусского паспорта. Об этом она сообщила в эфире «Еврорадио».
  - (2026-08-06) «К НАТО возникает много вопросов». Залужный заявил, что он сторонник альянса, но Россия нашла противодействие почти всему оружию блока | LEDE: Посол Украины в Великобритании, бывший главноко] (ru: «К…
      Посол Украины в Великобритании, бывший главнокомандующий ВСУ Валерий Залужный заявил, что считает себя сторонником НАТО, но альянс должен измениться. Об этом он сказал журналистам в Киеве, которые попросили его объяснить…
  - (2026-08-06) Джанни Инфантино останется главой ФИФА. Он извинился за планы продать долю в чемпионате мира частным инвесторам | LEDE: Джанни Инфантино продолжит занимать должность президента Международной] (ru: Джа…
      Джанни Инфантино продолжит занимать должность президента Международной федерации футбола (ФИФА). Об этом говорится в заявлении организации, опубликованном по итогам заседания руководства ФИФА в столице Марокко Рабате.
  - (2026-08-06) Россияне стали реже летать по маршруту Москва — Петербург. Среди причин — частые закрытия аэропортов из-за беспилотников Украины | LEDE: Количество пассажиров на авиарейсах между Москвой и П] (ru: Рос…
      Количество пассажиров на авиарейсах между Москвой и Петербургом за первую половину 2026 года снизилось на 18% — до 1,6 миллиона человек, сообщил «Коммерсант», ссылаясь на источники в отрасли.

### State-Level News — 382 new of 764 total
  - (2026-08-06) [California] Governor Newsom announces appointments 8.5.2026
      Source
  - (2026-08-05) [California] Governor Newsom signs tribal-state gaming compact
      Source
  - (2026-08-05) [California] California’s tax agency cracks down on $168 million in illicit cannabis, tobacco
      Source
  - (2026-08-05) [Alabama] Carrie Loraine Bowles – Tuscaloosa County Award
      Download
  - (2026-08-05) [California] Juez de California declara en desacato al DHS en caso relacionado con las redadas de inmigración en Los Ángeles
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/062025-Bell-Immigration-Raid-GETTY-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-08-05) [California] How Carl DeMaio is pushing the GOP to give up on CA moderates
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/08/01-Redistricting-Battle-Presser-MG-CM-04.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 222 new of 273 total
  - (2026-08-05) Exclusive: China Widens Tax Net to Offshore Insurance - Caixin Global
      Exclusive: China Widens Tax Net to Offshore Insurance Caixin Global
  - (2026-08-06) US efforts to prop up the yen risk doing more harm than good
  - (2026-08-06) Chinese fund managers’ pursuit of AI plays backfires as hot tech stocks wobble
  - (2026-08-06) Hong Kong stock regulator flags more companies for share concentration
  - (2026-08-06) Shares of major Hong Kong insurance, finance firms tumble following report of 20% levy
  - (2026-08-06) Does Beijing really have the power to lift up the Australian dollar?

### Local News: St. Louis + Atlanta — 204 new of 234 total
  - (2026-08-06) [St. Louis] Where in the Lou? – 8/6/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-08-06) [St. Louis] Gamlin’s restaurant opens in Maplewood
      The long-awaited Gamlin’s (2704 Sutton) opened on August 4 in downtown Maplewood, marking restaurateur Derek Gamlin’s return to the industry after a five-year absence. Located in the former Elmwood space, the restaurant…
  - (2026-08-05) [St. Louis] St. Louis restaurant openings, closings, and coming soons
      The following information is accurate as of an early-August press date. Eight restaurant closures in July (including the shutdown of the long-running downtown Syberg’s) were more than offset by 14 openings, among them Ma…
  - (2026-08-05) [St. Louis] Where in Clayton 8/6/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-08-05) [St. Louis] Top things to do in St. Louis this weekend: August 7–9
      Two Gentlemen of Verona | August 4–September 6 TourCo, the late-summer arm of St. Louis Shakespeare Festival, kicks off this week with a traveling production of “Shakespeare’s original rom-com.” It’s performed at parks a…
  - (2026-08-05) [St. Louis] St. Louis patients share the medical breakthroughs that changed their lives
      LISTEN TO YOUR HEART As the manager of a cardiac catheterization lab and diagnostic cardiology department, Jill Steiger thought she knew how to avoid becoming a heart disease patient. However, with a family history of he…

### U.S. Weather + Severe / Climate Outlooks — 179 new of 189 total
  - (2026-08-06) [Severe] Red Flag Warning: Red Flag Warning issued August 6 at 4:29AM CDT until August 6 at 9:00PM CDT by NWS Bismarck ND
      ...RED FLAG WARNING REMAINS IN EFFECT FROM NOON CDT /11 AM MDT/ TODAY TO 9 PM CDT /8 PM MDT/ THIS EVENING DUE TO WIND AND LOW RELATIVE HUMIDITY FOR MUCH OF WESTERN NORTH DAKOTA... .Critical fire weather conditions are ex…
  - (2026-08-06) [Severe] Red Flag Warning: Red Flag Warning issued August 6 at 4:29AM CDT until August 6 at 9:00PM CDT by NWS Bismarck ND
      ...RED FLAG WARNING REMAINS IN EFFECT FROM NOON CDT /11 AM MDT/ TODAY TO 9 PM CDT /8 PM MDT/ THIS EVENING DUE TO WIND AND LOW RELATIVE HUMIDITY FOR MUCH OF WESTERN NORTH DAKOTA... .Critical fire weather conditions are ex…
  - (2026-08-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-06) [Moderate] Heat Advisory: Heat Advisory issued August 6 at 2:22AM PDT until August 7 at 11:00PM PDT by NWS Medford OR
      * WHAT...Hot temperatures of 95 to 100 degrees with low temperatures around 60 to 65 degrees. * WHERE...The Umpqua Valley in central Douglas County, including the communities of Roseburg, Elkton, Drain, Sutherlin, Tiller…
  - (2026-08-06) [Moderate] Heat Advisory: Heat Advisory issued August 6 at 2:22AM PDT until August 7 at 11:00PM PDT by NWS Medford OR
      * WHAT...Hot temperatures 95 to 100 degrees with low temperatures around 55 to 60 degrees. * WHERE...Klamath, Lake, Modoc and eastern Siskiyou Counties. This includes the communities of Klamath Falls, Chemult, Chiloquin,…
  - (2026-08-06) [Moderate] Heat Advisory: Heat Advisory issued August 6 at 2:22AM PDT until August 7 at 11:00PM PDT by NWS Medford OR
      * WHAT...Hot temperatures of 90 to 95 degrees expected with low temperatures around 60 to 67 degrees. * WHERE...Siskiyou Mountains and Southern Oregon Cascades south of Crater Lake. This includes Lake of the Woods, Howar…

### State Legislative Action — 110 new of 114 total
  - (2026-08-05) [Alaska HB 74] An Act establishing the crime of airbag fraud.
      An Act establishing the crime of airbag fraud.
  - (2026-08-05) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-08-05) [Alaska HB 250] An Act establishing the crime of wearing a mask in public while acting as a peace officer; and providing for an effective date.
      An Act establishing the crime of wearing a mask in public while acting as a peace officer; and providing for an effective date.
  - (2026-08-05) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-08-05) [Alaska SB 121] An Act relating to settlement of health insurance claims; relating to allowable charges for health care services or supplies; and providing for an effective date.
      An Act relating to settlement of health insurance claims; relating to allowable charges for health care services or supplies; and providing for an effective date.
  - (2026-08-05) [Alaska HB 55] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 67 new of 115 total
  - (2026-08-06) Бондар розповів, за яких умов поляки підтримають інтеграцію України в ЄС | LEDE: Поляки підтримують членство України в ЄС, якщо країна виконає всі необхідні умови для інтеграції.] (uk: Бондар розповів…
      Поляки підтримують членство України в ЄС, якщо країна виконає всі необхідні умови для інтеграції.
  - (2026-08-06) В Одесі автомобіль під час руху провалився під землю | LEDE: В Одесі 5 серпня пасажирський автомобіль Volkswagen провалився під землю у яму із водою.] (uk: В Одесі автомобіль під час руху провалився п…
      В Одесі 5 серпня пасажирський автомобіль Volkswagen провалився під землю у яму із водою.
  - (2026-08-06) Дві квартири, Mercedes і будинок за $550 тисяч: НАБУ розкрило деталі справи Стефанішиної | LEDE: Колишній посолці Стефанішиній інкримінують незаконне збагачення на 13,9 млн грн та недостовірне ] (uk:…
      Колишній посолці Стефанішиній інкримінують незаконне збагачення на 13,9 млн грн та недостовірне декларування.
  - (2026-08-06) Посол України: Польща готує 50-й пакет військової допомоги Україні | LEDE: Варшава готує 50-й пакет військової допомоги для України, заявив Василь Боднар. Поставка техніки триває.] (uk: Посол України:…
      Варшава готує 50-й пакет військової допомоги для України, заявив Василь Боднар. Поставка техніки триває.
  - (2026-08-06) Посол України розповів, чи варто очікувати антиукраїнських погромів у Польщі | LEDE: Посол України у Польщі Василь Боднар вважає перебільшеними очікування щодо можливих антиукраїнських погромів] (uk:…
      Посол України у Польщі Василь Боднар вважає перебільшеними очікування щодо можливих антиукраїнських погромів у країні.
  - (2026-08-06) У США розслідують інцидент із вертольотом Трампа | LEDE: FAA розслідує короткочасну втрату інтервалу між Marine One із Трампом та літаком у DCA.] (uk: У США розслідують інцидент із вертольотом Трампа)
      FAA розслідує короткочасну втрату інтервалу між Marine One із Трампом та літаком у DCA.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-06) [Israel-Iran-Hezbollah axis · keywords] 2 soldiers killed in Lebanon in first Israeli deaths since June
      kmbc.com · English · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · keywords] US lifts sanctions on Iraqi airline , says Iran policy unchanged
      siasat.com · English · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · keywords] Israel considering military escalation in south Lebanon , despite peace talks
      middleeasteye.net · English · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · keywords] 2 soldiers killed in Lebanon in the first Israeli deaths since June truce with Hezbollah
      panow.com · English · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · keywords] Israeli soldiers killed in Lebanon as talks continue
      bordermail.com.au · English · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · keywords] UKMTO Says Explosions Reported In Strait Of Hormuz
      iraqsun.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-06) [KISSINGER THOMAS F] Form 4 (Reporting)
      filed 2026-08-06 01:58 UTC · role: Reporting — Filed: 2026-08-05 AccNo: 0000897069-26-001585 Size: 22 KB
  - (2026-08-06) [MARCUS CORP] Form 4 (Issuer)
      filed 2026-08-06 01:58 UTC · role: Issuer — Filed: 2026-08-05 AccNo: 0000897069-26-001585 Size: 22 KB
  - (2026-08-06) [Drucker Mann Lindsay] Form 4 (Reporting)
      filed 2026-08-06 01:57 UTC · role: Reporting — Filed: 2026-08-05 AccNo: 0001104659-26-091457 Size: 5 KB
  - (2026-08-06) [Oddity Tech Ltd] Form 4 (Issuer)
      filed 2026-08-06 01:57 UTC · role: Issuer — Filed: 2026-08-05 AccNo: 0001104659-26-091457 Size: 5 KB
  - (2026-08-06) [Allan David Robert Malcolm] Form 4 (Reporting)
      filed 2026-08-06 01:45 UTC · role: Reporting — Filed: 2026-08-05 AccNo: 0001213900-26-085874 Size: 8 KB
  - (2026-08-06) [Virtuix Holdings Inc.] Form 4 (Issuer)
      filed 2026-08-06 01:45 UTC · role: Issuer — Filed: 2026-08-05 AccNo: 0001213900-26-085874 Size: 8 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 57 total
  - (2026-08-06) [The Hacker News] Attackers Compile khunt Inside Oracle to Turn SQL Injection Into Windows SYSTEM Access
      Attackers broke into an organization's Oracle database through a SQL injection flaw in a public-facing web application, then installed a post-exploitation toolkit without writing an executable to disk. They fed Java sour…
  - (2026-08-06) [The Hacker News] AWS, Google, and Vercel Agent Flaws Let Attackers Trigger Tools Without Running the Model
      Security flaws in agent infrastructure from Amazon Web Services (AWS), Google, and Vercel let untrusted or forged instructions reach an agent's tools with no check that a model turn had authorized them. In several of the…
  - (2026-08-06) [The Hacker News] Chinese-Made Zbtlink Routers Ship With Backdoor That Opens Unauthenticated Root Shells
      Cybersecurity researchers have disclosed details of a "factory-shipped backdoor" implanted in at least 20 Chinese router models from Zbtlink. According to a new report from VulnCheck, the implant appears in all 21 firmwa…
  - (2026-08-06) [The Hacker News] Ransom Cartel Creator Gets 16 Years in Prison for Operating Ransomware-as-a-Service
      A federal judge in Alexandria, Virginia, sentenced Maksim Silnikau to 16 years in prison on August 5 for creating and running Ransom Cartel, the ransomware-as-a-service operation he stood up in 2021. Between 2021 and 202…
  - (2026-08-06) [The Hacker News] CISA Flags TeamCity CVE-2026-63077 RCE Flaw Under Active Exploitation in the Wild
      A newly patched security flaw impacting on-premise versions of JetBrains TeamCity has come under active exploitation in the wild, according to the U.S. Cybersecurity and Infrastructure Security Agency (CISA). The vulnera…
  - (2026-08-06) [The Register] Azure CTO pastes Doom into Paint one frame at a time
      It computes nothing, renders everything, and even has sound

### Paper Trading Scorecard — 33 new of 133 total
  - (2026-08-06) [Polymarket] Bitcoin all time high by September 30, 2026?
      This market will resolve to "Yes" if any Binance 1 minute candle for BTC/USDT between 16 December '25 10:30 and 11:59PM ET on the date specified in the title has a final “High” price that is higher than any previous Bina…
  - (2026-08-06) [Polymarket] Will Simona Mohamsson be the next Prime Minister of Sweden?
      Parliamentary elections are scheduled to be held in Sweden on September 13, 2026. This market will resolve to the next individual who is officially appointed and assumes office as Prime Minister of Sweden following the n…
  - (2026-08-06) [Polymarket] Will OpenAI have the best AI model at the end of August 2026?
      This market will resolve according to the company which owns the model which has the highest arena rank based on the arena.ai Text Arena (Overall) when the table under the "Leaderboard" tab is checked on August 31, 2026,…
  - (2026-08-06) [Polymarket] Variational FDV above $2B one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Variational's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-08-06) [Polymarket] Will Anthropic's valuation hit (LOW) $800B by December 31?
      This market will resolve to "Yes" if Anthropic's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or…
  - (2026-08-06) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…

### Court opinions of consequence (federal & state) — 31 new of 60 total
  - (2026-08-05) U.S. Court of Appeals, 9th Cir.: Committee for a Better Arvin v. United States Environmental Protection Agency
  - (2026-08-05) U.S. Court of Appeals, 9th Cir.: Inland Empire Waterkeeper v. Corona Clay Company
  - (2026-08-05) U.S. Court of Appeals, 9th Cir.: United States v. Chapman
  - (2026-08-05) U.S. Court of Appeals, 11th Cir.: Davita M. Key v. Dynamic Security, Inc.
  - (2026-08-05) U.S. Court of Appeals, 11th Cir.: United States v. Augustus C. Romain, Jr.
  - (2026-08-05) U.S. Court of Appeals, 11th Cir.: L.E. v. Superintendent of Cobb County School District

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-08-06) PUMAD (France)
      icao24: 39de61 · position: (43.1526, 7.1865) · alt: 2590m · 243km/h
  - (2026-08-06) SAMU05 (France)
      icao24: 39ca81 · position: (44.473, 6.2735) · alt: 1173m · 231km/h
  - (2026-08-06) GAF299 (Germany)
      icao24: 3ea556 · position: (56.7517, 13.6279) · alt: 9441m · 916km/h
  - (2026-08-06) GAF890 (Germany)
      icao24: 3f97fd · position: (58.9323, 6.1518) · alt: 8321m · 832km/h
  - (2026-08-06) CNA11 (Spain)
      icao24: 3475ca · position: (27.7736, -15.8526) · alt: 609m · 126km/h
  - (2026-08-06) SAMU29 (France)
      icao24: 39c90a · position: (47.9217, -3.3926) · alt: 2286m · 282km/h

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-08-05) M 5.6 - 40 km SW of Sarangani, Philippines
      M5.6 · 40 km SW of Sarangani, Philippines · depth 10 km
  - (2026-08-05) M 5.3 - 62 km W of Tobelo, Indonesia
      M5.3 · 62 km W of Tobelo, Indonesia · depth 115.65 km
  - (2026-08-05) M 5.2 - 31 km SSW of Ialibu, Papua New Guinea
      M5.2 · 31 km SSW of Ialibu, Papua New Guinea · depth 10.028 km
  - (2026-08-05) M 5.0 - 60 km NNE of Shi Yomi, India
      M5.0 · 60 km NNE of Shi Yomi, India · depth 10 km
  - (2026-08-05) M 4.9 - 15 km WSW of Honmachi, Japan
      M4.9 · 15 km WSW of Honmachi, Japan · depth 10 km
  - (2026-08-05) M 4.9 - 42 km SW of Sarangani, Philippines
      M4.9 · 42 km SW of Sarangani, Philippines · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-06) LoL: LGD Gaming vs ThunderTalk Gaming (BO3) - LPL Group Ascend
      yes price: 16% · 24h volume: $999,300 · resolves 2026-08-06
  - (2026-08-06) LoL: Kiwoom DRX vs DN SOOPers - Game 1 Winner
      yes price: 100% · 24h volume: $875,063 · resolves 2026-08-06
  - (2026-08-06) Will Manchester City win the 2026-27 English Premier League (EPL) Championship?
      yes price: 28% · 24h volume: $867,764 · resolves 2027-05-30
  - (2026-08-06) LoL: LGD Gaming vs ThunderTalk Gaming - Game 2 Winner
      yes price: 0% · 24h volume: $826,736 · resolves 2026-08-06
  - (2026-08-06) LoL: Kiwoom DRX vs DN SOOPers - Game 2 Winner
      yes price: 100% · 24h volume: $614,367 · resolves 2026-08-06
  - (2026-08-06) LoL: LGD Gaming vs ThunderTalk Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $568,212 · resolves 2026-08-06

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 99 total
  - (2026-08-05) [OFAC] Counter Terrorism Designations Removals and Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations Removals and Update Office of Foreign Assets Control (.gov)
  - (2026-08-06) [USASpending] $1,987,372,021 → BLUE ORIGIN MANUFACTURING, LLC: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING
      Agency: National Aeronautics and Space Administration. Description: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING SYSTEM INTEGRATED LANDER.
  - (2026-08-06) [USASpending] $1,018,396,052 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…
  - (2026-08-06) [USASpending] $983,897,124 → TRIWEST HEALTHCARE ALLIANCE CORP: EXPRESS REPORT: JUNE 2026
      Agency: Department of Veterans Affairs. Description: EXPRESS REPORT: JUNE 2026
  - (2026-08-06) [USASpending] $974,169,904 → CACI, INC. - FEDERAL: IGF::OT::IGF
      Agency: General Services Administration. Description: IGF::OT::IGF
  - (2026-08-06) [USASpending] $962,190,592 → OPTUM PUBLIC SECTOR SOLUTIONS, INC.: R3 EXPRESS REPORT: 3RD QTR FY 2026 JUNE
      Agency: Department of Veterans Affairs. Description: R3 EXPRESS REPORT: 3RD QTR FY 2026 JUNE

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 40 total
  - (2026-08-06) #30 Germán Larrea Mota Velasco & family — $67.77B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-08-06) MOVER ▼ Masayoshi Son — $68.96B ($-3.40B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-08-06) MOVER ▲ Mukesh Ambani — $91.08B (+$2.98B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-06) MOVER ▼ Carlos Slim Helu & family — $122.03B ($-2.80B since yesterday)
      Mexico · Telecom · source: Telecom
  - (2026-08-06) MOVER ▲ Bernard Arnault & family — $149.29B (+$2.11B since yesterday)
      France · Fashion & Retail · source: LVMH

### GDACS — global disaster alerts — 5 new of 277 total
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-05) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 5.6M, Depth:10km
  - (2026-08-05) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 5.6M, Depth:10km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-06) [Marginal Revolution] Will U.S. cities face a knock-on fiscal crisis from the feds?
      Federal money flows to cities in three flavors: direct transfers, indirect transfers, and what we call fiscal dark matter. Direct transfers are exactly what they sound like — money sent directly from the federal governme…
  - (2026-08-06) [Marginal Revolution] Who Pays for Unions?
      If unions raise worker wages, who pays? We provide a comprehensive assessment of firm responses to increased unionization, using changes in the tax deductibility of union dues in Norway as a quasi-exogenous source of var…
  - (2026-08-05) [Marginal Revolution] Wednesday assorted links
      1. A catalog of past AI predictions. 2. Jasmine Sun on why people do not want data centers. And Jasmine Sun on Ezra Klein, on data centers (NYT). 3. A bot running an SF retail boutique? (NYT) 4. Elise Cawley, RIP. 5. On…
  - (2026-08-05) [Conversable Economist] The Not-so-Fluid, Low-Hire, Low-Fire Economy
      The US unemployment rate was 4.2% in June, which is low by historical levels. Nonetheless, lot of workers, and perhaps expecially young workers right out of college, are experiencing the US economy as a situation where i…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 8 total
  - (2026-08-05) CVE-2026-63077 · JetBrains TeamCity: JetBrains TeamCity Deserialization of Untrusted Data Vulnerability
      vendor: JetBrains · product: TeamCity · CISA remediation by 2026-08-08

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: order, requires, notice, action, published, provide, proposed, standard, program, certain, amend, proposing
- state_bills: today=114, 7d-median=114, 14d-median=114; carrying terms: include, school, defines, known, develop, prohibits, defined, constitution, office, child, based, existing
- state_news: today=764, 7d-median=758, 14d-median=626; carrying terms: wants, include, legislation, controversial, school, jersey, country, politicians, known, making, criminal, attempt
- local_news: today=234, 7d-median=234, 14d-median=228; carrying terms: content, school, multiple, million, woman, based, stlmag, found, charged, august, saportareport, magazine
- foreign_news: today=1049, 7d-median=1041, 14d-median=1014; carrying terms: seeing, httpsconnection, culture, installs, school, transport, handan, reaches, country, counterfeit, guangzhong, tensions
- chinese_internal: today=273, 7d-median=273, 14d-median=266; carrying terms: chinese, caixin, global, people, google, record, china, firms, https, office, stock, price
- russian_internal: today=1151, 7d-median=937, 14d-median=926; carrying terms: media, reuters, httperror, gazeta, bloomberg, error, istories, novaya, europe, novayagazeta, title, forbidden
- ukrainian_internal: today=115, 7d-median=125, 14d-median=131; carrying terms: vechirniy, refinery, civilian, reactions, campaign, missile, growing, early, around, ballistic, hromadske, headlines
- ukraine_theater: today=1059, 7d-median=1059, 14d-median=633; carrying terms: known, deepstatemap, frontline, client, alerts, active, maintained, error, polygons, coverage, httperror, google
- paper_bets: today=133, 7d-median=133, 14d-median=134; carrying terms: levels, successor, tradable, mamdani, pennsylvania, election, approve, achieved, leaders, miles, maine, majors
- weather: today=189, 7d-median=176, 14d-median=174; carrying terms: include, francisco, small, lying, south, afdlwx, early, further, nueces, corpus, unknown, seattle
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: nonfarm, dexuseu, crude, commodities, payems, consumption, sheet, recession, walcl, effective, cpiaucsl, latest
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, silver, range, bitcoin, rates, close, commodities, proxy, treasury, credit, nasdaq, equities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=104, 14d-median=104; carrying terms: order, content, adopted, violent, federation, independence, legislation, stages, acronym, active, aeronautics, campaign
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quiverquant, client, httperror, congresstrading, quantitative, quiver, unauthorized, https
- billionaires: today=40, 7d-median=37, 14d-median=38; carrying terms: larry, japan, discount, cryptocurrency, investments, gcarsoa, google, sergey, facebook, brokerage, amazon, tadashi
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: delaware, county, court, supreme, appeals, services, blanche, thomas, corporation, capital, group, energy
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, holdings, robert, therapeutics, steven, david, daniel, michael, technologies
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, committee, jonathan, booker, ocasio, receipts, disbursements, raised, house, talarico, warner, senate
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea
- gdelt_gkg: today=50, 7d-median=50, 14d-median=25; carrying terms: english, israel, hezbollah, keywords, netanyahu, spanish, themes, crisis, israeli, russian, italian, hormuz
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=19, 14d-median=17; carrying terms: position, canada, belgium, france, ground, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: respiratory, division, fatality, travel, institut, history, challenge, detected, kasai, countries, several, anthrax
- cisa_kev: today=8, 7d-median=9, 14d-median=10; carrying terms: fortinet, langflow, deserialization, authentication, command, untrusted, management, remediation, product, vendor, vulnerability, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=277, 7d-median=265, 14d-median=277; carrying terms: ukraine, wildfire, flood, genevieve, north, honduras, slovakia, canada, congo, austria, spain, serbia
- usgs_quakes: today=11, 7d-median=16, 14d-median=18; carrying terms: depth, japan, indonesia, philippines, tonga, guinea, papua, honmachi
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, prime, august, strait, returns, ceasefire, hormuz, traffic, normal, interest
- commentary: today=6, 7d-median=5, 14d-median=6; carrying terms: conversableeconomist, government, marginal, having, conversable, revolution, class, economist, https, marginalrevolution, college, toward
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: targeted, campaign, vulnerability, spectrum, schneier, against, intelligence, report, infrastructure, attack, technology, companies
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jonathan, kirsten, janelle, guthrie, olszewski, emilia, samuel, commodity, begich, grijalva, delia, francisco
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, today, claude, unavailable, sufficient, either, placement, module, converges, market, consensus, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*