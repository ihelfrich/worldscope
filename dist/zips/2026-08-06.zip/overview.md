# WORLDSCOPE morning brief — 2026-08-06

## Headline
4153 new items across 28 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (799) · International News + Multilateral Institutions (785) · Russian Internal News (state + in-exile) (750) · State-Level News (386) · World leaders & government officials (324) · Chinese Internal News (215) · Local News: St. Louis + Atlanta (195) · U.S. Weather + Severe / Climate Outlooks (179) · State Legislative Action (114) · Ukrainian Internal News (national + local Kyiv) (67) · GDELT GKG — themes / entities / watch areas (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Ukraine Theater (total-war monitoring) — 799 new of 1059 total
  - (2026-08-06) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-05) [FIRMS] thermal anomaly 46.801, 33.272 (FRP 8.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 8.02 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.754, 33.625 (FRP 2.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 0947Z, FRP 2.71 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.388, 28.573 (FRP 8.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 8.89 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.041, 23.397 (FRP 6.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 6.74 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.044, 23.396 (FRP 6.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 6.74 MW

### International News + Multilateral Institutions — 785 new of 1049 total
  - (2026-08-06) [Global] In Odesa, no-one is safe from Russia's new Black Sea strikes
      Blackened ships and smashed docks mark Russia's recent surge of attacks on Ukraine's coastline.
  - (2026-08-06) [Global] Iran says deal with Oman on Strait of Hormuz is in final stages
      Neither the US or Oman have commented on the proposed agreement on the vital waterway.
  - (2026-08-06) [Global] Indian journalist Tarun Tejpal convicted in 2013 rape case
      The Goa bench of the Bombay High Court overturned a 2021 trial court verdict clearing Tejpal of all charges.
  - (2026-08-06) [Global] Iranian footballers who defied Tehran become Australian citizens
      They were among seven members of Iran's team to be granted humanitarian visas while in Australia for the Women's Asian Cup - but the other five changed their minds and returned home.
  - (2026-08-06) [Global] Rihanna is 'in the studio', says partner A$AP Rocky
      The singer, who last released a full album in 2016, is in the studio and "cooking", her partner said.
  - (2026-08-06) [Global] Outrage as Ugandan football captain beaten to death in street gang attack
      The 27-year-old was killed by suspected robbers after resisting an attempt to rob him, police say.

### Russian Internal News (state + in-exile) — 750 new of 1154 total
  - (2026-08-06) На пик Победы в Кыргызстане будут пускать только по разрешениям. Год назад там погибла российская альпинистка Наталья Наговицина | LEDE: Власти Кыргызстана будут выдавать альпинистам специал] (ru: На…
      Власти Кыргызстана будут выдавать альпинистам специальные разрешения для восхождения на пик Победы, сообщили в осударственном агентстве страны по развитию туризма. Без них подниматься на гору будет нельзя.
  - (2026-08-06) Бывшего посла Украины в США Ольгу Стефанишину обвинили в незаконном обогащении на 14 миллионов гривен (это около 25 миллионов рублей) | LEDE: Национальное антикоррупционное бюро Украины (НАБ] (ru: Быв…
      Национальное антикоррупционное бюро Украины (НАБУ) и Специализированная антикоррупционная прокуратура (САП) объявили, что бывший посол Украины в США Ольга Стефанишина подозревается в незаконном обогащении на 13,9 миллион…
  - (2026-08-06) 77 срочников погибли на границе Курской области во время вторжения ВСУ в 2024 году. Еще более 30 до сих пор числятся пропавшими без вести | LEDE: Как минимум 77 солдат срочной службы погибли] (ru: 77…
      Как минимум 77 солдат срочной службы погибли в первые месяцы боев на границе Курской области во время вторжения ВСУ в 2024 году, выяснили «Важные истории» и «Верстка». На момент гибели срочникам было 18-25 лет, большинст…
  - (2026-08-06) Светлане Тихановской не открыли счет в польском банке из-за просроченного белорусского паспорта | LEDE: Лидер белорусской оппозиции Светлана Тихановская рассказала, что ей не открыли счет в ] (ru: Све…
      Лидер белорусской оппозиции Светлана Тихановская рассказала, что ей не открыли счет в польском банке из-за просроченного белорусского паспорта. Об этом она сообщила в эфире «Еврорадио».
  - (2026-08-06) «К НАТО возникает много вопросов». Залужный заявил, что он сторонник альянса, но Россия нашла противодействие почти всему оружию блока | LEDE: Посол Украины в Великобритании, бывший главноко] (ru: «К…
      Посол Украины в Великобритании, бывший главнокомандующий ВСУ Валерий Залужный заявил, что считает себя сторонником НАТО, но альянс должен измениться. Об этом он сказал журналистам в Киеве, которые попросили его объяснить…
  - (2026-08-06) Джанни Инфантино останется главой ФИФА. Он извинился за планы продать долю в чемпионате мира частным инвесторам | LEDE: Джанни Инфантино продолжит занимать должность президента Международной] (ru: Джа…
      Джанни Инфантино продолжит занимать должность президента Международной федерации футбола (ФИФА). Об этом говорится в заявлении организации, опубликованном по итогам заседания руководства ФИФА в столице Марокко Рабате.

### State-Level News — 386 new of 768 total
  - (2026-08-05) [Alabama] Carrie Loraine Bowles – Tuscaloosa County Award
      Download
  - (2026-08-06) [California] Governor Newsom announces appointments 8.5.2026
      Source
  - (2026-08-05) [California] Governor Newsom signs tribal-state gaming compact
      Source
  - (2026-08-05) [California] California’s tax agency cracks down on $168 million in illicit cannabis, tobacco
      Source
  - (2026-08-05) [California] Juez de California declara en desacato al DHS en caso relacionado con las redadas de inmigración en Los Ángeles
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/062025-Bell-Immigration-Raid-GETTY-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-08-05) [California] How Carl DeMaio is pushing the GOP to give up on CA moderates
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/08/01-Redistricting-Battle-Presser-MG-CM-04.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 215 new of 272 total
  - (2026-08-04) 瑞银宋宇：政策基调转向加大力度保增长 力度、时点尚待明确 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBQbU9MOEM3RkVJVGFFUGVBVzhadEF0M25jQk1WbEtCNWZwS0NsdUVRZko3TFJuaGw4WWJ6M005dDBrQ2JSaERZd2ozV] (zh:…
      瑞银宋宇：政策基调转向加大力度保增长 力度、时点尚待明确 财新
  - (2026-08-04) 如何解读上半年经济数据 - opinion.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE14S3RlZE9TVGRJWjdKa2pTRWYwaTBQVGd6Nk5CUDFJQWRXRU40NzdPdlIwQXN3MER5NFN5QjBXZUpWdklPT3RxZGVJTz] (zh:…
      如何解读上半年经济数据 opinion.caixin.com
  - (2026-08-04) 美欧经济：从分化到收敛 - opinion.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9yZ284aTF2SnVNR2ZXdnFkOTRfd3ZXd1JHS2t4Nk1ycjkzbnZaamJTSk1OajRKSVM5Q3N0TDlEV3gzVkxZWlRkTVFrWV] (zh:…
      美欧经济：从分化到收敛 opinion.caixin.com
  - (2026-08-06) 控制陷阱：组织为什么会越管越胖 - opinion.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1CSXM4aG1GVUstbHpQa3prUUZJZllhTUVtMW5aMXRYd0M2WEYtb2lCMmNpUXV2bDlNWmpuSjZRSkU5dG5PZGtfNz] (zh:…
      控制陷阱：组织为什么会越管越胖 opinion.caixin.com
  - (2026-08-04) 最值钱的三个字，如何拯救AI产业万亿市值 - opinion.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE42T2tvNFpvcnhoMDJFVjJfS29DNVgyaUJMR2ZpVm9tcjJ5a3licHo0QjZNSXpNOUsxZVBhZC1yYng3d08we] (zh:…
      最值钱的三个字，如何拯救AI产业万亿市值 opinion.caixin.com
  - (2026-08-04) 从香港、霍尔木兹到人工智能：毁公器者不若成人之美 - opinion.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9pU2tya1llV3VNWU53ZDN6aFZONlFBSGZ2LVRzSWtwc3RGREh1dmNoTElvcXZoVXgxb0pXaGN0Tkd1b] (zh:…
      从香港、霍尔木兹到人工智能：毁公器者不若成人之美 opinion.caixin.com

### Local News: St. Louis + Atlanta — 195 new of 225 total
  - (2026-08-06) [St. Louis] Where in the Lou? – 8/6/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-08-06) [St. Louis] Gamlin’s restaurant opens in Maplewood
      The long-awaited Gamlin’s (2704 Sutton) opened on August 4 in downtown Maplewood, marking restaurateur Derek Gamlin’s return to the industry after a five-year absence. Located in the former Elmwood space, the restaurant…
  - (2026-08-05) [St. Louis] St. Louis restaurant openings, closings, and coming soons
      The following information is accurate as of an early-August press date. Eight restaurant closures in July (including the shutdown of the long-running downtown Syberg’s) were more than offset by 14 openings, among them Ma…
  - (2026-08-05) [St. Louis] Where in Clayton 8/6/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-08-05) [St. Louis] Top things to do in St. Louis this weekend: August 7–9
      Two Gentlemen of Verona | August 4–September 6 TourCo, the late-summer arm of St. Louis Shakespeare Festival, kicks off this week with a traveling production of “Shakespeare’s original rom-com.” It’s performed at parks a…
  - (2026-08-05) [St. Louis] St. Louis patients share the medical breakthroughs that changed their lives
      LISTEN TO YOUR HEART As the manager of a cardiac catheterization lab and diagnostic cardiology department, Jill Steiger thought she knew how to avoid becoming a heart disease patient. However, with a family history of he…

### U.S. Weather + Severe / Climate Outlooks — 179 new of 189 total
  - (2026-08-06) [Severe] Special Marine Warning: Special Marine Warning issued August 6 at 5:37AM EDT until August 6 at 6:00AM EDT by NWS Key West FL
      For the following areas... Bayside and Gulf side from Craig Key to west end of Seven Mile Bridge... Florida Bay including Barnes Sound, Blackwater Sound, and Buttonwood Sound... At 536 AM EDT, a strong thunderstorm was l…
  - (2026-08-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-06) [Moderate] Lake Wind Advisory: Lake Wind Advisory issued August 6 at 3:35AM MDT until August 6 at 7:00PM MDT by NWS Glasgow MT
      * WHAT...Northwest winds 15 to 25 mph with gusts up to 35 mph expected. * WHERE...Fort Peck Lake. * WHEN...From 9 AM this morning to 7 PM MDT this evening. * IMPACTS...Strong winds and rough waves on area lakes will crea…
  - (2026-08-06) [Severe] Flash Flood Warning: Flash Flood Warning issued August 6 at 4:35AM CDT until August 6 at 8:30AM CDT by NWS St Louis MO
      FFWLSX The National Weather Service in St Louis has issued a * Flash Flood Warning for... Southern Montgomery County in east central Missouri... Southwestern Saint Charles County in east central Missouri... Warren County…
  - (2026-08-06) [Severe] Red Flag Warning: Red Flag Warning issued August 6 at 4:29AM CDT until August 6 at 9:00PM CDT by NWS Bismarck ND
      ...RED FLAG WARNING REMAINS IN EFFECT FROM NOON CDT /11 AM MDT/ TODAY TO 9 PM CDT /8 PM MDT/ THIS EVENING DUE TO WIND AND LOW RELATIVE HUMIDITY FOR MUCH OF WESTERN NORTH DAKOTA... .Critical fire weather conditions are ex…
  - (2026-08-06) [Severe] Red Flag Warning: Red Flag Warning issued August 6 at 4:29AM CDT until August 6 at 9:00PM CDT by NWS Bismarck ND
      ...RED FLAG WARNING REMAINS IN EFFECT FROM NOON CDT /11 AM MDT/ TODAY TO 9 PM CDT /8 PM MDT/ THIS EVENING DUE TO WIND AND LOW RELATIVE HUMIDITY FOR MUCH OF WESTERN NORTH DAKOTA... .Critical fire weather conditions are ex…

### State Legislative Action — 114 new of 118 total
  - (2026-08-05) [Alaska HB 74] An Act establishing the crime of airbag fraud.
      An Act establishing the crime of airbag fraud.
  - (2026-08-05) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-08-05) [Alaska HB 250] An Act establishing the crime of wearing a mask in public while acting as a peace officer; and providing for an effective date.
      An Act establishing the crime of wearing a mask in public while acting as a peace officer; and providing for an effective date.
  - (2026-08-05) [Alaska HB 381] An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal propert…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to local contributions for public school funding; relating to municipal property taxes; relating to the Alaska Gasl…
  - (2026-08-05) [Alaska SB 121] An Act relating to settlement of health insurance claims; relating to allowable charges for health care services or supplies; and providing for an effective date.
      An Act relating to settlement of health insurance claims; relating to allowable charges for health care services or supplies; and providing for an effective date.
  - (2026-08-05) [Alaska HB 55] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 67 new of 115 total
  - (2026-08-06) Wildberries Warehouse Damaged in Latest Ukrainian Drone Strike as Russia Reports 600+ UAVs Downed
      Russian authorities said debris from a Ukrainian drone damaged a Wildberries logistics warehouse in Russia's Tver region, with no casualties reported. The claims came after Moscow said it intercepted 605 drones overnight…
  - (2026-08-06) ‘Putin’s Defeat in Ukraine Necessary for a Free Belarus,’ Exiled Opposition Leader Says
      Belarusian opposition leader Sviatlana Tsikhanouskaya said Ukraine’s victory over Russia is essential for Belarus’s freedom, warning that a Kremlin win would cement Moscow’s control over her country. She urged Western le…
  - (2026-08-06) Zaluzhny: Russia Has Found Counters to Nearly Every NATO Weapon, Alliance Must Reinvent Itself
      Former Commander-in-Chief Valerii Zaluzhnyi said Russia has developed countermeasures to nearly every major NATO weapon used in Ukraine, arguing the alliance must overhaul its military doctrine. He said Ukraine’s battlef…
  - (2026-08-06) Russian Strike Hits Wheat Ship in Black Sea, 1 Killed
      A Russian strike hit a Guinea-Bissau-flagged dry cargo vessel carrying Ukrainian wheat in the Black Sea, killing one person and injuring three others. The attack damaged the ship’s hull and sparked a fire, highlighting c…
  - (2026-08-06) Trump Dismisses Reports of Munitions Shortages, Says US Has ‘Massive Amount’
      President Donald Trump dismissed reports of US weapons shortages amid the Iran war, claiming America has “massive amounts” of munitions and threatening legal action against alleged leakers. Reports said depleted missile…
  - (2026-08-06) Ukraine Has Restored Full US Intelligence Support Since 2025 Freeze, Boosting Strikes Inside Russia
      The United States has restored full intelligence sharing with Ukraine after a temporary freeze in 2025, helping Kyiv carry out more effective long-range strikes inside Russia, Politico reported. US lawmakers and experts…

### GDELT GKG — themes / entities / watch areas — 45 new of 45 total
  - (2026-08-06) [Russia oil sanctions perimeter · themes] The new frontyard : Why Latin America has become the playground for imperial and fascist experiments
      links.org.au · English · tone NA
  - (2026-08-06) [Russia oil sanctions perimeter · themes] Удары ВС РФ по Украине 5 - 6 августа : подробности , цели атаки , видео
      lenta.ru · Russian · tone NA
  - (2026-08-06) [Russia oil sanctions perimeter · themes] Украинская авиатранспортная ассоциация призывает Минфин унифицировать правила налогообложения авиационного лизинга
      pressorg24.com · Russian · tone NA
  - (2026-08-06) [Russia oil sanctions perimeter · themes] Seattle DJC . com local business news and data - Construction - Michigan Supreme Court rejects permit for oil pipeline under Great Lakes
      djc.com · English · tone NA
  - (2026-08-06) [Russia oil sanctions perimeter · themes] Conavi cambiará control de bienes usados en obras millonarias tras observaciones de CGR
      teletica.com · Spanish · tone NA
  - (2026-08-06) [Russia oil sanctions perimeter · themes] Borse di oggi 6 agosto e prezzo del petrolio in diretta | Europa in lieve rialzo con speranza di accordo su Hormuz , Asia in rosso per le vendite sul tech
      corriere.it · Italian · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-06) [KISSINGER THOMAS F] Form 4 (Reporting)
      filed 2026-08-06 01:58 UTC · role: Reporting — Filed: 2026-08-05 AccNo: 0000897069-26-001585 Size: 22 KB
  - (2026-08-06) [MARCUS CORP] Form 4 (Issuer)
      filed 2026-08-06 01:58 UTC · role: Issuer — Filed: 2026-08-05 AccNo: 0000897069-26-001585 Size: 22 KB
  - (2026-08-06) [Drucker Mann Lindsay] Form 4 (Reporting)
      filed 2026-08-06 01:57 UTC · role: Reporting — Filed: 2026-08-05 AccNo: 0001104659-26-091457 Size: 5 KB
  - (2026-08-06) [Oddity Tech Ltd] Form 4 (Issuer)
      filed 2026-08-06 01:57 UTC · role: Issuer — Filed: 2026-08-05 AccNo: 0001104659-26-091457 Size: 5 KB
  - (2026-08-06) [Allan David Robert Malcolm] Form 4 (Reporting)
      filed 2026-08-06 01:45 UTC · role: Reporting — Filed: 2026-08-05 AccNo: 0001213900-26-085874 Size: 8 KB
  - (2026-08-06) [Virtuix Holdings Inc.] Form 4 (Issuer)
      filed 2026-08-06 01:45 UTC · role: Issuer — Filed: 2026-08-05 AccNo: 0001213900-26-085874 Size: 8 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-06) [Afghanistan] Italy , UNESCO launch emergency restoration of Mazar - e - Sharif Blue Mosque after earthquake | Ariana News
      domain: ariananews.af · language: English · tone:
  - (2026-08-06) [United States] Nigerian president hails largest ever single - day rescue as 308 abductees freed in country north
      domain: wral.com · language: English · tone:
  - (2026-08-06) [United States] Rodolphe Herve Sells 1 , 207 Shares of Palomar ( NASDAQ : PLMR ) Stock
      domain: dailypolitical.com · language: English · tone:
  - (2026-08-06) [United States] BELMONT COUNTY SHERIFF OFFICE - The Times Leader
      domain: timesleaderonline.com · language: English · tone:
  - (2026-08-06) [United States] Abdul El - Sayed Wins Michigan Democratic Senate Primary One News Page
      domain: onenewspage.com · language: English · tone:
  - (2026-08-06) [Malaysia] Missing man found dead in drain along WCE near Bagan Datuk
      domain: thestar.com.my · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 57 total
  - (2026-08-06) [The Hacker News] Attackers Compile khunt Inside Oracle to Turn SQL Injection Into Windows SYSTEM Access
      Attackers broke into an organization's Oracle database through a SQL injection flaw in a public-facing web application, then installed a post-exploitation toolkit without writing an executable to disk. They fed Java sour…
  - (2026-08-06) [The Hacker News] AWS, Google, and Vercel Agent Flaws Let Attackers Trigger Tools Without Running the Model
      Security flaws in agent infrastructure from Amazon Web Services (AWS), Google, and Vercel let untrusted or forged instructions reach an agent's tools with no check that a model turn had authorized them. In several of the…
  - (2026-08-06) [The Hacker News] Chinese-Made Zbtlink Routers Ship With Backdoor That Opens Unauthenticated Root Shells
      Cybersecurity researchers have disclosed details of a "factory-shipped backdoor" implanted in at least 20 Chinese router models from Zbtlink. According to a new report from VulnCheck, the implant appears in all 21 firmwa…
  - (2026-08-06) [The Hacker News] Ransom Cartel Creator Gets 16 Years in Prison for Operating Ransomware-as-a-Service
      A federal judge in Alexandria, Virginia, sentenced Maksim Silnikau to 16 years in prison on August 5 for creating and running Ransom Cartel, the ransomware-as-a-service operation he stood up in 2021. Between 2021 and 202…
  - (2026-08-06) [The Hacker News] CISA Flags TeamCity CVE-2026-63077 RCE Flaw Under Active Exploitation in the Wild
      A newly patched security flaw impacting on-premise versions of JetBrains TeamCity has come under active exploitation in the wild, according to the U.S. Cybersecurity and Infrastructure Security Agency (CISA). The vulnera…
  - (2026-08-06) [The Register] Azure CTO pastes Doom into Paint one frame at a time
      It computes nothing, renders everything, and even has sound

### Paper Trading Scorecard — 33 new of 133 total
  - (2026-08-06) [Polymarket] Bitcoin all time high by September 30, 2026?
      This market will resolve to "Yes" if any Binance 1 minute candle for BTC/USDT between 16 December '25 10:30 and 11:59PM ET on the date specified in the title has a final “High” price that is higher than any previous Bina…
  - (2026-08-06) [Polymarket] Will Simona Mohamsson be the next Prime Minister of Sweden?
      Parliamentary elections are scheduled to be held in Sweden on September 13, 2026. This market will resolve to the next individual who is officially appointed and assumes office as Prime Minister of Sweden following the n…
  - (2026-08-06) [Polymarket] Will OpenAI have the best AI model at the end of August 2026?
      This market will resolve according to the company which owns the model which has the highest arena rank based on the arena.ai Text Arena (Overall) when the table under the "Leaderboard" tab is checked on August 31, 2026,…
  - (2026-08-06) [Polymarket] Variational FDV above $2B one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Variational's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-08-06) [Polymarket] Will Anthropic's valuation hit (LOW) $800B by December 31?
      This market will resolve to "Yes" if Anthropic's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or…
  - (2026-08-06) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…

### Court opinions of consequence (federal & state) — 32 new of 60 total
  - (2026-08-05) U.S. Court of Appeals, 2nd Cir.: DoorDash, Inc. v. City of New York
  - (2026-08-05) U.S. Court of Appeals, 2nd Cir.: United States Ex Rel. Chiles v. Cooke Inc.
  - (2026-08-05) U.S. Court of Appeals, 11th Cir.: Davita M. Key v. Dynamic Security, Inc.
  - (2026-08-05) U.S. Court of Appeals, 11th Cir.: United States v. Augustus C. Romain, Jr.
  - (2026-08-05) U.S. Court of Appeals, 11th Cir.: L.E. v. Superintendent of Cobb County School District
  - (2026-08-05) U.S. Court of Appeals, 11th Cir.: United States v. Alexander Alli

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-08-06) PUMAD (France)
      icao24: 39de61 · position: (43.2837, 6.5686) · alt: 1501m · 245km/h
  - (2026-08-06) GAF299 (Germany)
      icao24: 3ea556 · position: (58.3822, 15.0031) · alt: 9441m · 947km/h
  - (2026-08-06) GAF890 (Germany)
      icao24: 3f97fd · position: (60.0781, 5.3029) · alt: 1150m · 385km/h
  - (2026-08-06) CNA11 (Spain)
      icao24: 3475ca · position: (27.726, -15.7776) · alt: 853m · 179km/h
  - (2026-08-06) SAMU29 (France)
      icao24: 39c90a · position: (47.5926, -2.7552) · alt: 2286m · 280km/h
  - (2026-08-06) RFF07 (Portugal)
      icao24: 496ca7 · position: (37.0177, -7.9616) · on ground · 21km/h

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-08-05) M 5.6 - 40 km SW of Sarangani, Philippines
      M5.6 · 40 km SW of Sarangani, Philippines · depth 10 km
  - (2026-08-05) M 5.3 - 62 km W of Tobelo, Indonesia
      M5.3 · 62 km W of Tobelo, Indonesia · depth 115.65 km
  - (2026-08-05) M 5.2 - 31 km SSW of Ialibu, Papua New Guinea
      M5.2 · 31 km SSW of Ialibu, Papua New Guinea · depth 10.028 km
  - (2026-08-05) M 5.0 - 60 km NNE of Shi Yomi, India
      M5.0 · 60 km NNE of Shi Yomi, India · depth 10 km
  - (2026-08-05) M 4.9 - 15 km WSW of Honmachi, Japan
      M4.9 · 15 km WSW of Honmachi, Japan · depth 10 km
  - (2026-08-05) M 4.9 - 42 km SW of Sarangani, Philippines
      M4.9 · 42 km SW of Sarangani, Philippines · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-06) LoL: LGD Gaming vs ThunderTalk Gaming (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $999,300 · resolves 2026-08-06
  - (2026-08-06) LoL: Kiwoom DRX vs DN SOOPers - Game 1 Winner
      yes price: 100% · 24h volume: $875,063 · resolves 2026-08-06
  - (2026-08-06) Will Manchester City win the 2026-27 English Premier League (EPL) Championship?
      yes price: 28% · 24h volume: $867,764 · resolves 2027-05-30
  - (2026-08-06) LoL: LGD Gaming vs ThunderTalk Gaming - Game 2 Winner
      yes price: 0% · 24h volume: $826,736 · resolves 2026-08-06
  - (2026-08-06) LoL: Kiwoom DRX vs DN SOOPers - Game 2 Winner
      yes price: 100% · 24h volume: $614,367 · resolves 2026-08-06
  - (2026-08-06) LoL: LGD Gaming vs ThunderTalk Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $568,212 · resolves 2026-08-06

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 99 total
  - (2026-08-05) [OFAC] Counter Terrorism Designations Removals and Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations Removals and Update Office of Foreign Assets Control (.gov)
  - (2026-08-06) [USASpending] $1,987,372,021 → BLUE ORIGIN MANUFACTURING, LLC: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING
      Agency: National Aeronautics and Space Administration. Description: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING SYSTEM INTEGRATED LANDER.
  - (2026-08-06) [USASpending] $1,018,396,052 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…
  - (2026-08-06) [USASpending] $983,897,124 → TRIWEST HEALTHCARE ALLIANCE CORP: EXPRESS REPORT: JUNE 2026
      Agency: Department of Veterans Affairs. Description: EXPRESS REPORT: JUNE 2026
  - (2026-08-06) [USASpending] $974,169,904 → CACI, INC. - FEDERAL: IGF::OT::IGF
      Agency: General Services Administration. Description: IGF::OT::IGF
  - (2026-08-06) [USASpending] $962,190,592 → OPTUM PUBLIC SECTOR SOLUTIONS, INC.: R3 EXPRESS REPORT: 3RD QTR FY 2026 JUNE
      Agency: Department of Veterans Affairs. Description: R3 EXPRESS REPORT: 3RD QTR FY 2026 JUNE

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-06) [Japan] Nikkei Falls as AI Heavyweights Drag Market Lower
      newsonjapan.com · English
  - (2026-08-06) [Japan] Woman Arrested Over Massive Manga Order Cancellations
      newsonjapan.com · English
  - (2026-08-06) [Japan] Kumamoto Earthquake Buildings Still Collapsing
      newsonjapan.com · English
  - (2026-08-06) [Japan] ANA and JAL to Lower Fuel Surcharges for September and October
      newsonjapan.com · English
  - (2026-08-06) [Japan] Cabinet approves tax cut on food , but Diet tussle looms ahead | The Asahi Shimbun : Breaking News , Japan News and Analysis
      asahi.com · English
  - (2026-08-06) [Japan] Taiwan kicks off annual military drills to counter a potential Chinese attack | The Asahi Shimbun : Breaking News , Japan News and Analysis
      asahi.com · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 40 total
  - (2026-08-06) #30 Germán Larrea Mota Velasco & family — $67.77B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-08-06) MOVER ▼ Masayoshi Son — $68.96B ($-3.40B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-08-06) MOVER ▲ Mukesh Ambani — $91.03B (+$2.92B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-06) MOVER ▼ Carlos Slim Helu & family — $122.05B ($-2.78B since yesterday)
      Mexico · Telecom · source: Telecom
  - (2026-08-06) MOVER ▲ Bernard Arnault & family — $149.25B (+$2.07B since yesterday)
      France · Fashion & Retail · source: LVMH

### GDACS — global disaster alerts — 5 new of 277 total
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-05) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 5.6M, Depth:10km
  - (2026-08-05) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 5.6M, Depth:10km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-06) [Marginal Revolution] Will U.S. cities face a knock-on fiscal crisis from the feds?
      Federal money flows to cities in three flavors: direct transfers, indirect transfers, and what we call fiscal dark matter. Direct transfers are exactly what they sound like — money sent directly from the federal governme…
  - (2026-08-06) [Marginal Revolution] Who Pays for Unions?
      If unions raise worker wages, who pays? We provide a comprehensive assessment of firm responses to increased unionization, using changes in the tax deductibility of union dues in Norway as a quasi-exogenous source of var…
  - (2026-08-05) [Marginal Revolution] Wednesday assorted links
      1. A catalog of past AI predictions. 2. Jasmine Sun on why people do not want data centers. And Jasmine Sun on Ezra Klein, on data centers (NYT). 3. A bot running an SF retail boutique? (NYT) 4. Elise Cawley, RIP. 5. On…
  - (2026-08-05) [Conversable Economist] The Not-so-Fluid, Low-Hire, Low-Fire Economy
      The US unemployment rate was 4.2% in June, which is low by historical levels. Nonetheless, lot of workers, and perhaps expecially young workers right out of college, are experiencing the US economy as a situation where i…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 8 total
  - (2026-08-05) CVE-2026-63077 · JetBrains TeamCity: JetBrains TeamCity Deserialization of Untrusted Data Vulnerability
      vendor: JetBrains · product: TeamCity · CISA remediation by 2026-08-08

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: provide, order, published, proposing, action, notice, requires, proposed, rulemaking, amend, safety, certain
- state_bills: today=118, 7d-median=118, 14d-median=117; carrying terms: child, specified, programs, regulatory, health, written, address, services, environmental, social, office, enforcement
- state_news: today=768, 7d-median=758, 14d-median=626; carrying terms: child, enacted, students, hampshire, scaled, previous, nearly, security, photos, island, senator, environmental
- local_news: today=225, 7d-median=230, 14d-median=226; carrying terms: scaled, nearly, dining, health, arrested, missouri, woman, officials, weekend, louis, found, accused
- foreign_news: today=1049, 7d-median=1041, 14d-median=1014; carrying terms: child, students, security, higher, diplomat, forbidding, annually, sport, shaanxi, rejection, tackling, topnews
- chinese_internal: today=272, 7d-median=272, 14d-median=266; carrying terms: china, google, caixin, firms, https, people, record, chinese, global, office, stock, price
- russian_internal: today=1154, 7d-median=937, 14d-median=926; carrying terms: associated, novayagazeta, title, europe, street, gazeta, forbidden, bloomberg, wildberries, media, client, axios
- ukrainian_internal: today=115, 7d-median=125, 14d-median=131; carrying terms: sources, center, nearly, border, confirmed, cabinet, toward, security, zelensky, aerial, despite, across
- ukraine_theater: today=1059, 7d-median=1059, 14d-median=633; carrying terms: frontline, snapshot, polygons, known, active, viirs, daily, error, client, token, cartography, liveuamap
- paper_bets: today=133, 7d-median=133, 14d-median=134; carrying terms: state, fusion, specified, hampshire, house, starts, population, jpmorgan, security, retirement, miami, secretary
- weather: today=189, 7d-median=176, 14d-median=174; carrying terms: especially, front, afdilx, lying, details, center, galveston, ridge, impacts, miami, scattered, index
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: spread, funds, commodities, assets, labor, nonfarm, cpilfesl, latest, rates, consumption, unrate, treasury
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, range, corporate, large, nasdaq, close, crude, credit, russell, commodities, rates, treasury
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=104, 14d-median=104; carrying terms: destruction, state, restrictive, protests, groups, embargo, specific, administration, jihad, syria, security, accellerator
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, httperror, quiverquant, unauthorized, quiver, client, quantitative, congresstrading, error
- billionaires: today=40, 7d-median=37, 14d-median=38; carrying terms: meyers, changpeng, ballmer, buffett, amancio, tokyo, yanai, microsoft, paris, diversified, euronext, brokerage
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: california, delaware, services, county, supreme, court, appeals, johnson, blanche, thomas, corporation, association
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, holdings, therapeutics, robert, michael, daniel, steven, david, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, filing, angels, house, michael, trone, james, cortez, platner, krishnamoorthi, sherrod, lindsey
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan
- gdelt_gkg: today=45, 7d-median=45, 14d-median=25; carrying terms: english, israel, hezbollah, trump, spanish, chinese, themes, russian, hormuz, turkish, italian, russia
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: domain, language, english, against, russia, years, india, kingdom
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=19, 14d-median=17; carrying terms: position, canada, france, belgium, ground, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: third, state, includ, disembarked, zoonotic, increased, additional, beginning, substantial, bangladesh, welfare, however
- cisa_kev: today=8, 7d-median=9, 14d-median=10; carrying terms: langflow, remediation, injection, vulnerability, vendor, authentication, command, deserialization, product, fortinet, management, untrusted
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=277, 7d-median=265, 14d-median=277; carrying terms: sweden, madagascar, ecuador, cambodia, indonesia, germany, venezuela, belarus, maximum, democratic, czech, bosnia
- usgs_quakes: today=11, 7d-median=16, 14d-median=18; carrying terms: depth, japan, indonesia, philippines, guinea, tonga, papua, honmachi
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, traffic, august, strait, prime, hormuz, ceasefire, normal, returns, invade
- commentary: today=6, 7d-median=5, 14d-median=6; carrying terms: marginal, government, economist, conversableeconomist, revolution, conversable, having, https, class, marginalrevolution, assorted, toward
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: third, going, security, spectrum, cybersecurity, despite, targeted, today, exposed, artificial, attack, weekday
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: hageman, markey, jacky, howard, ricketts, wasserman, vasquez, house, components, analilia, daniel, angela
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, claude, either, consensus, identify, market, paper, unavailable, today, markets, sufficient, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*