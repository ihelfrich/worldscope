# WORLDSCOPE morning brief — 2026-08-06

## Headline
4903 new items across 27 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (1088) · Russian Internal News (state + in-exile) (905) · International News + Multilateral Institutions (859) · State-Level News (614) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (261) · Chinese Internal News (218) · U.S. Weather + Severe / Climate Outlooks (197) · Ukrainian Internal News (national + local Kyiv) (81) · Court opinions of consequence (federal & state) (50) · GDELT GKG — themes / entities / watch areas (50) · Paper Trading Scorecard (43)

## What changed today
### Ukraine Theater (total-war monitoring) — 1088 new of 1334 total
  - (2026-08-06) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-05) [FIRMS] thermal anomaly 46.801, 33.272 (FRP 8.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 8.02 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.754, 33.625 (FRP 2.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 0947Z, FRP 2.71 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.388, 28.573 (FRP 8.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 8.89 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.041, 23.397 (FRP 6.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 6.74 MW
  - (2026-08-05) [FIRMS] thermal anomaly 44.044, 23.396 (FRP 6.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-05 1128Z, FRP 6.74 MW

### Russian Internal News (state + in-exile) — 905 new of 1056 total
  - (2026-08-07) В главном районе ночной жизни Лондона хотят запретить пить в пабах стоя. Идею уже раскритиковал мэр города Садик Хан | LEDE: Городской совет Вестминстера обсуждает запрет на «вертикальное по] (ru: В г…
      Городской совет Вестминстера обсуждает запрет на «вертикальное потребление алкоголя» в пабах, пишет The Guardian. В его юрисдикцию входит один из самых оживленных районов ночной жизни Лондона, Вест-Энд, который включает…
  - (2026-08-06) Министр обороны Литвы предупредил о возможных российских ударах по странам Балтийского региона с помощью захваченных украинских дронов | LEDE: Россия рассматривает возможность нанесения удар] (ru: Мин…
      Россия рассматривает возможность нанесения ударов по критически важной инфраструктуре в Балтийском регионе, пишет Bloomberg со ссылкой на заявление министра обороны Литвы Робертаса Каунаса.
  - (2026-08-06) В России снимут ситком «ПВЗ» о пункте выдачи заказов. Глава «Газпром-медиа» сообщил об этом на фоне регулярных ударов ВСУ по складам Wildberries | LEDE: «Газпром-медиа» снимет комедийный сер] (ru: В Р…
      «Газпром-медиа» снимет комедийный сериал с рабочим названием «ПВЗ», который будет посвящен работе пунктов выдачи заказов. Об этом гендиректор компании Александр Жаров рассказал в интервью подкасту «Путь в топ с Олесей На…
  - (2026-08-06) Генпрокуратура РФ объявила «нежелательным» американский фонд Human Rights Foundation. Его с 2024-го возглавляет Юлия Навальная | LEDE: Генеральная прокуратура России объявила «нежелательной»] (ru: Ген…
      Генеральная прокуратура России объявила «нежелательной» на территории страны деятельность американского фонда Human Rights Foundation.
  - (2026-08-06) Бывшую главу Росмолодежи Ксению Разуваеву подозревают в растрате. Ее отец в июне получил срок за мошенничество | LEDE: Против бывшей главы Росмолодежи Ксении Разуваевой расследуется уголовно] (ru: Быв…
      Против бывшей главы Росмолодежи Ксении Разуваевой расследуется уголовное дело. Внимание на это обратила «Медиазона», которая обнаружила карточку о продлении меры пресечения в Лефортовском районном суде Москвы.
  - (2026-08-06) На ютьюбе заблокировали канал националистического объединения «Русская община» | LEDE: Видеохостинг YouTube удалил канал крупнейшего в современной России националистического объединения «Рус] (ru: На…
      Видеохостинг YouTube удалил канал крупнейшего в современной России националистического объединения «Русская община». У него было около 1,2 миллиона подписчиков.

### International News + Multilateral Institutions — 859 new of 1098 total
  - (2026-08-06) [Global] How Abdul El-Sayed’s ‘extraordinary’ win stunned pro-Israel establishment
      Michigan progressive fended off AIPAC as well as Democratic establishment in US Senate race, supporters say.
  - (2026-08-06) [Global] Far-right fitness clubs mask extremist recruitment, experts warn
      Al Jazeera's Nils Adler reports on how far-right 'Active Clubs' use fitness and camaraderie to recruit young white men.
  - (2026-08-06) [Global] Trump signs new executive orders seeking to limit US birthright citizenship
      The US president's latest effort comes after Supreme Court ruled against his push to reinterpret constitutional right.
  - (2026-08-06) [Global] Toronto police arrest two in US Consulate shooting investigation
      Suspects recruited via encrypted app and offered money for violent acts, Toronto police reveal after arrests.
  - (2026-08-06) [Global] US diplomat Rubio targets Cuban military officials, companies in sanctions
      US says the five entities and eight individuals sanctioned help Cuba acquire military equipment from Russia and China.
  - (2026-08-06) [Global] Fire engulfs earthquake housing site in Turkiye
      A fire broke out at a workers' accommodation camp at a construction site for earthquake housing in Hatay, Turkiye.

### State-Level News — 614 new of 979 total
  - (2026-08-06) [California] Governor Newsom signs legislation 8.6.2026
      Source
  - (2026-08-06) [California] Trump’s FCC illegally axes limits that protect Americans from broadcast media conglomerates
      Source
  - (2026-08-06) [California] Governor Newsom calls on Californians to fight back against Trump’s reckless offshore drilling agenda
      Source
  - (2026-08-06) [California] Governor Newsom announces appointments 8.5.2026
      Source
  - (2026-08-05) [California] Governor Newsom signs tribal-state gaming compact
      Source
  - (2026-08-05) [California] California’s tax agency cracks down on $168 million in illicit cannabis, tobacco
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 261 new of 273 total
  - (2026-08-06) [St. Louis] New Big Backyard Bash festival brings giant inflatables and family fun to St. Charles
      When Kayci Crew started traveling the country to work large events, she kept coming back to the same question every time she returned home to St. Louis: Why wasn’t there a festival built entirely around families spending…
  - (2026-08-06) [St. Louis] Why educators say play is one of the most important parts of learning
      For many children, play is often viewed as a break from learning. Educators, however, see it differently. “Play is the work of childhood,” says Steve Coxon, a professor and executive director of the Center for Access and…
  - (2026-08-06) [St. Louis] How does play prepare children for handling life’s challenges?
      Anxiety, stress, and emotional challenges are becoming more common topics in conversations about childhood. According to Dr. Mini Tandon, a child and adolescent psychiatrist, one of the most powerful tools that children…
  - (2026-08-06) [St. Louis] How The Magic House’s ‘Play Together’ campaign is encouraging kids to play more often
      Across St. Louis, educators and families are noticing the same challenge: Children are spending more time on screens and less time playing together. At The Magic House, the new “Play Together” campaign was created in res…
  - (2026-08-06) [St. Louis] Texas Roadhouse slated to open at Olive Crossing in Olivette
      Texas Roadhouse is bringing its signature combination of hand-cut steaks, warm rolls, and value-priced meals to Olivette. The casual steakhouse chain has signed on as the newest retail tenant at Olive Crossing, the 14.8-…
  - (2026-08-06) [St. Louis] Local civic groups buy Kiener Plaza’s garages, with big plans for improvements
      Two of downtown St. Louis’ most prominent parking garages are under local control after Arch to Park Equity Fund, Gateway Arch Park Foundation, and the Berges Family Foundation closed on the purchase of the Kiener East a…

### Chinese Internal News — 218 new of 280 total
  - (2026-08-06) 中东局势催化东南亚能源焦虑 多国出台光伏新政加速转型 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE1hb052bU1oU1hXM3B4Q1JKVExGcldOZU1tRkR4ejk4ZlpUM0N4WlkyLVdSWUtlUGJmbUxzQVJRUzJBblN6TUZsQlpHX3d] (zh:…
      中东局势催化东南亚能源焦虑 多国出台光伏新政加速转型 财新
  - (2026-08-05) 独家｜境外收入征税 保险收益也需缴交？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBoa1c2N0VVXzh5RmxQYy1uUGFTekRKV1A3S05fTEs2aHotT3ZUNW5XckFqOXN5TjNlSGVSbG9ITnBYY0VaNnRpVHRkMG5fSENSSn] (zh:…
      独家｜境外收入征税 保险收益也需缴交？ 财新
  - (2026-08-04) 财新闻｜A股现分红潮，有公司一口气发了62个亿，多家公司董事长提议派发“红包” - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1KcE1oZ1BzSEJJQkx1OWpfVWdPTzAzeEtLdVdWSDhaQUIzdWVuQkpxaDNpclVzOGdDS] (zh:…
      财新闻｜A股现分红潮，有公司一口气发了62个亿，多家公司董事长提议派发“红包” mini.caixin.com
  - (2026-08-06) 哈尔滨遭遇短时极端强降雨 3小时累计雨量超80 毫米 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5HV01VNDQ1X0s5d3dJSnZ1R0RiX3labTduT0FvM0dXX3lLNEQzSnRGa25zdHJZSk1SaTZHR3dibGRaU0hLTDNMZEpvVmh] (zh:…
      哈尔滨遭遇短时极端强降雨 3小时累计雨量超80 毫米 财新
  - (2026-08-06) 电动汽车需求高涨驱动澳洲车市增长 中国品牌表现强劲｜出海· 汽车 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE5vUGpCUlh6Xy0yNVpKY05VUWxabzVtTjVJdlphNXF0X3VVX3YyaHZnWjhiN01mSWZucmkwLXVJN2ZIb3lESVRKb] (zh:…
      电动汽车需求高涨驱动澳洲车市增长 中国品牌表现强劲｜出海· 汽车 财新
  - (2026-08-06) 今日开盘：两市双双低开 沪指跌幅0.36% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBLWi1vSnRFb1lkWVZrUkk5Z1VCTE1UQ2s0YVQybXBDOUdRbWJwaE16bDRsWThjNlFSenRiUmVlV3d0OEEweTQ2Yzg4WGdId1Bh] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.36% 财新

### U.S. Weather + Severe / Climate Outlooks — 197 new of 199 total
  - (2026-08-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-06) [Severe] Flash Flood Warning: Flash Flood Warning issued August 6 at 7:36PM EDT until August 6 at 9:30PM EDT by NWS Baltimore MD/Washington DC
      At 736 PM EDT, emergency management reported multiple cars stranded in deep standing water in Bowleys Quarters. Between 1.5 and 4 inches of rain have fallen. Flooding impacts will continue, but no additional rainfall is…
  - (2026-08-06) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 6 at 6:36PM CDT until August 6 at 7:30PM CDT by NWS Grand Forks ND
      SVRFGF The National Weather Service in Grand Forks has issued a * Severe Thunderstorm Warning for... Southeastern Lake of the Woods County in north central Minnesota... * Until 730 PM CDT. * At 636 PM CDT, a severe thund…
  - (2026-08-06) [Moderate] Special Weather Statement: Special Weather Statement issued August 6 at 7:35PM EDT by NWS Greenville-Spartanburg SC
      At 735 PM EDT, Doppler radar was tracking a strong thunderstorm 10 miles northeast of Downtown Asheville, or near B.R. Parkway-East Asheville To Craggy Gardens, moving north at 10 mph. HAZARD...Wind gusts up to 40 mph an…
  - (2026-08-06) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 6 at 6:35PM CDT until August 6 at 7:15PM CDT by NWS Tulsa OK
      SVRTSA The National Weather Service in Tulsa has issued a * Severe Thunderstorm Warning for... Northeastern Benton County in northwestern Arkansas... Northwestern Carroll County in northwestern Arkansas... * Until 715 PM…
  - (2026-08-06) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 6 at 7:35PM EDT until August 6 at 8:15PM EDT by NWS Raleigh NC
      SVRRAH The National Weather Service in Raleigh has issued a * Severe Thunderstorm Warning for... Eastern Orange County in central North Carolina... Southwestern Granville County in central North Carolina... Northwestern…

### Ukrainian Internal News (national + local Kyiv) — 81 new of 129 total
  - (2026-08-07) США запроваджують санкції проти Куби за співпрацю з Росією, Китаєм та Іраном | LEDE: У США оголосили нові санкції проти Куби за співпрацю з Росією, Китаєм та Іраном.] (uk: США запроваджують санкції пр…
      У США оголосили нові санкції проти Куби за співпрацю з Росією, Китаєм та Іраном.
  - (2026-08-07) Двоє чоловіків на Херсонщині отримали травми через удари російських дронів | LEDE: У Херсонській області зазнали поранень і травм двоє чоловіків через полювання російських дронів.] (uk: Двоє чоловіків…
      У Херсонській області зазнали поранень і травм двоє чоловіків через полювання російських дронів.
  - (2026-08-07) У Києві та низці областей оголошували повітряну тривогу через загрозу балістики | LEDE: У ніч на 7 серпня у столиці України та низці областей оголосили повітряну тривогу через загрозу ворожої б] (uk:…
      У ніч на 7 серпня у столиці України та низці областей оголосили повітряну тривогу через загрозу ворожої балістики.
  - (2026-08-07) Трамп заявив про "обмеженішими" та "величезні запаси боєприпасів" США | LEDE: Трамп описав "обмеженіші" та "величезні" запаси зброї США.] (uk: Трамп заявив про "обмеженішими" та "величезні запаси боєп…
      Трамп описав "обмеженіші" та "величезні" запаси зброї США.
  - (2026-08-07) Трамп про ракети Patriot для України: "Нам і самим потрібні" | LEDE: Відповідаючи на питання про ракети Patriot для України, Трамп вчергове згадав допомогу, яку надав Байден.] (uk: Трамп про ракети Pa…
      Відповідаючи на питання про ракети Patriot для України, Трамп вчергове згадав допомогу, яку надав Байден.
  - (2026-08-06) В Одеській області внаслідок російської атаки постраждав 16-річний хлопець | LEDE: Російська армія 6 серпня атакувала Ізмаїльський район на Одещині, постраждав 16-річний хлопець.] (uk: В Одеській обла…
      Російська армія 6 серпня атакувала Ізмаїльський район на Одещині, постраждав 16-річний хлопець.

### Court opinions of consequence (federal & state) — 50 new of 60 total
  - (2026-08-06) Delaware Supreme Court: Fox News Network, LLC v. Gavin C. Newsom
  - (2026-08-06) Delaware Supreme Court: Sussex County Planning & Zoning Commission v. Smokey Hollow, LLC
  - (2026-08-06) Supreme Court of California: Gorobets v. Jaguar Land Rover North America, LLC
  - (2026-08-06) Supreme Court of California: People v. Hyatt
  - (2026-08-06) D.C. Court of Appeals: Ball v. Hubbard
  - (2026-08-06) D.C. Court of Appeals: Hatcherson-Ross v. United States

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-06) [Israel-Iran-Hezbollah axis · themes] Chik - Wauk Museum adds Anishinaabe exhibit
      wdio.com · English · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · themes] El efecto La Odisea : la película de Nolan despierta el interés por aprender griego
      vanguardia.com · Spanish · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · themes] Tramp , po ko zna koji put : Rat s Iranom uskoro gotov , Teheran odgovorio : Propala ti je diplomatija . Samo pričaš , nema dela
      naslovi.net · Serbian · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · themes] 缙云丨杨小霜 ： 追车记
      baijiahao.baidu.com · Chinese · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · themes] No alternative but to euthanise cattle , says minister
      yahoo.com · English · tone NA
  - (2026-08-06) [Israel-Iran-Hezbollah axis · themes] Los Pumas confirmaron la formación para enfrentar a Sudáfrica en Vélez
      elesquiu.com · Spanish · tone NA

### Paper Trading Scorecard — 43 new of 138 total
  - (2026-08-06) [Polymarket] Will Zelenskyy talk to Putin by December 31?
      This market will resolve to "Yes" if Volodymyr Zelenskyy and Vladimir Putin talk by December 31, 2026, 11:59 PM ET. Otherwise, it will resolve to "No". A talk is defined as any interaction between Volodymyr Zelenskyy and…
  - (2026-08-06) [Polymarket] Will Simona Mohamsson be the next Prime Minister of Sweden?
      Parliamentary elections are scheduled to be held in Sweden on September 13, 2026. This market will resolve to the next individual who is officially appointed and assumes office as Prime Minister of Sweden following the n…
  - (2026-08-06) [Polymarket] Las Vegas Aces vs. Indiana Fever
      In the upcoming WNBA game, scheduled for August 6 at 7:00PM ET: If the Las Vegas Aces win, the market will resolve to "Las Vegas Aces". If the Indiana Fever win, the market will resolve to "Indiana Fever". If the game is…
  - (2026-08-06) [Polymarket] Will Camilo Santana finish in second place in the first round of the 2026 Brazilian presidential election?
      A presidential election is scheduled to take place in Brazil on October 4, 2026. This market will resolve according to the listed candidate who receives the second-most valid votes in the first round of this election. Th…
  - (2026-08-06) [Polymarket] Will OpenAI IPO by September 30 2026?
      This market will resolve to "Yes" if OpenAI completes an Initial Public Offering (IPO) by the listed date ET, as confirmed by official company announcements and credible news sources. Otherwise, this market will resolve…
  - (2026-08-06) [Polymarket] Will Anthropic's valuation hit (LOW) $800B by December 31?
      This market will resolve to "Yes" if Anthropic's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or…

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 56 total
  - (2026-08-06) [Krebs on Security] Canadian Man Pleads Guilty in Snowflake Extortions
      A 26-year-old Canadian man once described as one of the most consequential cybercrime threat actors of 2024 has pleaded guilty to computer fraud and conspiracy to hack and extort more than 165 organizations that used the…
  - (2026-08-06) [BleepingComputer] OpenAI rolls out a major ChatGPT upgrade, even if you don’t pay for it
      OpenAI is rolling out a more reliable version of ChatGPT GPT-5.6 Sol for Plus and Pro users, while Free users are getting unlimited text chats with GPT-5.6 Luna. [...]
  - (2026-08-06) [BleepingComputer] ClickFix attack pushes macOS infostealer for crypto theft attacks
      A Go-based malware delivered in ClickFix attacks targeting macOS users is stealing cryptocurrency assets, browser-stored passwords, Apple Keychain data, and cached credentials. [...]
  - (2026-08-06) [BleepingComputer] Hedge fund cyberattacks tied to BlackFile-linked UNC6671 extortion group
      A recent wave of cyberattacks targeting hedge funds, private-equity firms, and other financial organizations has been linked to UNC6671, an extortion group reportedly associated with the BlackFile threat actors. [...]
  - (2026-08-06) [BleepingComputer] Swiss government SharePoint breach compromised 200 accounts
      Switzerland's federal IT office says hackers exploited vulnerabilities to breach its Microsoft SharePoint servers and compromised approximately 200 accounts. [...]
  - (2026-08-06) [BleepingComputer] New TONTOU CPU attack bypasses Spectre v2 fixes, leaks Linux password hashes
      Researchers found a way to bypass recent mitigations for Spectre v2 speculative execution side-channel attacks and developed an exploit to leak secrets from Linux machines. [...]

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-06) [Winter Michael R] Form 4 (Reporting)
      filed 2026-08-06 23:36 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001239944-26-000074 Size: 5 KB
  - (2026-08-06) [ALLIENT INC] Form 4 (Issuer)
      filed 2026-08-06 23:36 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001239944-26-000074 Size: 5 KB
  - (2026-08-06) [Tzetzo Nicole R] Form 4 (Reporting)
      filed 2026-08-06 23:36 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001239944-26-000073 Size: 6 KB
  - (2026-08-06) [ALLIENT INC] Form 4 (Issuer)
      filed 2026-08-06 23:36 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001239944-26-000073 Size: 6 KB
  - (2026-08-06) [Finch Steven C.] Form 4 (Reporting)
      filed 2026-08-06 23:36 UTC · role: Reporting — Filed: 2026-08-06 AccNo: 0001239944-26-000072 Size: 5 KB
  - (2026-08-06) [ALLIENT INC] Form 4 (Issuer)
      filed 2026-08-06 23:36 UTC · role: Issuer — Filed: 2026-08-06 AccNo: 0001239944-26-000072 Size: 5 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 29 new of 29 total
  - (2026-08-06) Establishing the President's Military Spouse Commission
  - (2026-08-06) Amendment of Class D and Class E Airspace; Morgantown, WV
      This action proposes to amend the Class D and Class E airspace at Morgantown Municipal Airport-Walter L. Bill Hart Field, Morgantown, WV. The FAA is proposing this action as the result of a biennial airspace review. This…
  - (2026-08-06) Partial Approval and Partial Disapproval of Air Quality State Implementation Plans; Arizona; Prevention of Significant Deterioration Infrastructure Requirements for the 2012 Fine Particulate Matter Na…
      The Environmental Protection Agency (EPA) is proposing to partially approve and partially disapprove a revision to the Arizona State implementation plan (SIP) as meeting the requirements of the Clean Air Act (CAA) for th…
  - (2026-08-06) DPAS Directive Allocation Order and Additional Requirements for Recoverable Critical Minerals and Materials
      The Bureau of Industry and Security ("BIS") is publishing this temporary final rule to restrict the exportation of black mass and tungsten waste and scrap without a license. Specifically, as of August 27, 2026, U.S. pers…
  - (2026-08-06) Pacific Halibut Fisheries of the West Coast; Inseason Action for the 2026 Area 2A Pacific Halibut Directed Commercial Fishery
      NMFS announces an inseason action for the 2026 Pacific halibut non-Tribal directed commercial fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds a fishing period, August…
  - (2026-08-06) Investment Company Governance Technical Amendments
      The Securities and Exchange Commission (the "Commission") is adopting technical amendments to a rule under the Investment Company Act of 1940 (the "Investment Company Act") related to registered investment company and bu…

### Government & military aircraft airborne (OpenSky) — 13 new of 14 total
  - (2026-08-06) PAT249 (United States)
      icao24: adfe4c · position: (37.5057, -86.4856) · alt: 1912m · 476km/h
  - (2026-08-06) PAT883 (United Republic of Tanzania)
      icao24: 080010 · position: (33.7928, -118.0448) · alt: 7m · 164km/h
  - (2026-08-06) CFC3602 (Canada)
      icao24: c2b3eb · position: (49.8581, -115.6747) · alt: 10965m · 653km/h
  - (2026-08-06) JAF7GN (Belgium)
      icao24: 44d1a5 · position: (43.9381, -1.4533) · alt: 10972m · 881km/h
  - (2026-08-06) PAT901 (United States)
      icao24: ae0876 · position: (42.2215, -90.2391) · alt: 7315m · 460km/h
  - (2026-08-06) RCH5011 (United States)
      icao24: ae0816 · position: (41.451, -112.166) · alt: 3718m · 585km/h

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-08-06) M 5.4 - 145 km E of Yamada, Japan
      M5.4 · 145 km E of Yamada, Japan · depth 10 km
  - (2026-08-06) M 5.3 - 7 km SSW of Huayucachi, Peru
      M5.3 · 7 km SSW of Huayucachi, Peru · depth 10 km
  - (2026-08-06) M 5.1 - 110 km W of Buala, Solomon Islands
      M5.1 · 110 km W of Buala, Solomon Islands · depth 54.348 km
  - (2026-08-06) M 4.9 - 64 km NE of Mangapapa, New Zealand
      M4.9 · 64 km NE of Mangapapa, New Zealand · depth 22.793 km
  - (2026-08-06) M 4.9 - 195 km SE of Lorengau, Papua New Guinea
      M4.9 · 195 km SE of Lorengau, Papua New Guinea · depth 10 km
  - (2026-08-06) M 4.9 - 128 km WSW of Port Orford, Oregon
      M4.9 · 128 km WSW of Port Orford, Oregon · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-06) Miami Marlins vs. Atlanta Braves
      yes price: 36% · 24h volume: $794,818 · resolves 2026-08-13
  - (2026-08-06) National Bank Open: Jiri Lehecka vs Alexander Blockx
      yes price: 87% · 24h volume: $479,647 · resolves 2026-08-13
  - (2026-08-06) Will there be no change in Fed interest rates after the September 2026 meeting?
      yes price: 48% · 24h volume: $406,534 · resolves 2026-09-16
  - (2026-08-06) Will the Fed decrease interest rates by 25 bps after the September 2026 meeting?
      yes price: 2% · 24h volume: $393,116 · resolves 2026-09-16
  - (2026-08-06) National Bank Open: Rafael Jodar vs Lorenzo Musetti
      yes price: 62% · 24h volume: $379,589 · resolves 2026-08-13
  - (2026-08-06) Miami Marlins vs. Atlanta Braves: O/U 8.5
      yes price: 35% · 24h volume: $355,316 · resolves 2026-08-06

### Government Action: Sanctions + Procurement + Foreign Agents — 9 new of 101 total
  - (2026-08-06) [OFAC] Cuba-related Designations; Issuance of Cuba-related Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Cuba-related Designations; Issuance of Cuba-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-08-05) [OFAC] Counter Terrorism Designations Removals and Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations Removals and Update Office of Foreign Assets Control (.gov)
  - (2026-08-06) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-08-06) [USASpending] $1,987,372,021 → BLUE ORIGIN MANUFACTURING, LLC: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING
      Agency: National Aeronautics and Space Administration. Description: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING SYSTEM INTEGRATED LANDER.
  - (2026-08-06) [USASpending] $1,018,396,052 → CENTRAL PLATEAU CLEANUP COMPANY, LLC: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - EN
      Agency: Department of Energy. Description: HANFORD CENTRAL PLATEAU CLEANUP CONTRACT - TASK ORDER 7 - END STATES & BASE OPS. THIS TASK ORDER IS ISSUED AS AN UNDEFINITIZED TASK ORDER PURSUANT TO CLAUSE H.49, TASK ORDERING…
  - (2026-08-06) [USASpending] $983,897,124 → TRIWEST HEALTHCARE ALLIANCE CORP: EXPRESS REPORT: JUNE 2026
      Agency: Department of Veterans Affairs. Description: EXPRESS REPORT: JUNE 2026

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-06) [South Korea] [ Editorial ] Leveraged ETF fallout
      koreaherald.com · English
  - (2026-08-06) [South Korea] Bathhouses save Seoul vulnerable residents during extreme weather
      koreatimes.co.kr · English
  - (2026-08-06) [South Korea] BLACKPINK marks 10th anniversary with National Museum heritage collection
      koreatimes.co.kr · English
  - (2026-08-06) [South Korea] Gimbap poses potential health risk during heat waves
      koreatimes.co.kr · English
  - (2026-08-06) [South Korea] New Quick Share update adds Samsung Wallet sharing support
      sammobile.com · English
  - (2026-08-06) [South Korea] Seo Kang Joon and Ahn Eun Jin Begin Script Reading for A Love Other Than Yours
      kpopstarz.com · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 40 total
  - (2026-08-06) MOVER ▲ Steve Ballmer — $153.42B (+$3.13B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-08-06) MOVER ▼ Thomas Peterffy — $99.91B ($-2.95B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-08-06) MOVER ▲ Warren Buffett — $148.74B (+$1.56B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway
  - (2026-08-06) MOVER ▲ Mukesh Ambani — $91.51B (+$0.49B since yesterday)
      India · Diversified · source: Diversified
  - (2026-08-06) MOVER ▲ Bill Gates — $108.30B (+$0.48B since yesterday)
      United States · Technology · source: Microsoft

### GDACS — global disaster alerts — 5 new of 191 total
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-01) [Green] Flood in Pakistan
      Flood · Green alert · Pakistan · Magnitude 0
  - (2026-08-05) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 5.6M, Depth:10km
  - (2026-08-05) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 5.6M, Depth:10km

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-08-06) [Marginal Revolution] Solve for the (Refine) equilibrium
      We’re proud to announce that Refine has signed partnerships with two leading publishers in economics. Both the American Economic Association and the Econometric Society now use Refine’s AI-assisted technical verification…
  - (2026-08-06) [Marginal Revolution] Thursday assorted links
      1. “Next to rising oxygen levels and other contributing factors, the importance of feces in ancient ecosystems is often overlooked…” 2. New publication on AI and institutions. Good people involved. 3. Chicago boys in Chi…
  - (2026-08-06) [Marginal Revolution] The Binmen of Birmingham
      I was on the British CapX Podcast talking about the Equality Act, riffing off my two posts Equality Act 2010 and The Apples and Oranges Tribunal. One thing I discussed in the podcast which I haven’t blogged on is the ama…
  - (2026-08-05) [Conversable Economist] The Not-so-Fluid, Low-Hire, Low-Fire Economy
      The US unemployment rate was 4.2% in June, which is low by historical levels. Nonetheless, lot of workers, and perhaps expecially young workers right out of college, are experiencing the US economy as a situation where i…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 8 total
  - (2026-08-05) CVE-2026-63077 · JetBrains TeamCity: JetBrains TeamCity Deserialization of Untrusted Data Vulnerability
      vendor: JetBrains · product: TeamCity · CISA remediation by 2026-08-08

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=20, 14d-median=20; carrying terms: certain, final, action, program, safety, requires, proposed, rulemaking, proposing, provide, amend, order
- state_bills: today=118, 7d-median=118, 14d-median=117; carrying terms: school, defined, allows, rates, pursuant, county, colorado, regulatory, human, purposes, hours, within
- state_news: today=979, 7d-median=758, 14d-median=626; carrying terms: approved, return, billion, resize, county, colorado, power, wednesday, crime, nonprofit, photos, available
- local_news: today=273, 7d-median=239, 14d-median=228; carrying terms: resize, county, woman, restaurant, officials, articles, metro, crash, residents, killed, arrest, against
- foreign_news: today=1098, 7d-median=1041, 14d-median=1014; carrying terms: survivor, football, theglobeandmail, approved, installs, goods, return, billion, skyscraper, adult, county, affairs
- chinese_internal: today=280, 7d-median=280, 14d-median=266; carrying terms: caixin, google, chinese, record, global, https, china, people, firms, stock, price, market
- russian_internal: today=1056, 7d-median=937, 14d-median=926; carrying terms: gazeta, https, telegram, novayagazeta, client, wildberries, russian, group, media, associated, istories, patriot
- ukrainian_internal: today=129, 7d-median=129, 14d-median=131; carrying terms: warfare, billion, missiles, reactions, range, wildberries, power, cabinet, russian, strikes, across, error
- ukraine_theater: today=1334, 7d-median=1073, 14d-median=633; carrying terms: token, polygon, deepstatemap, liveuamap, snapshot, client, google, known, daily, extra, error, cartography
- paper_bets: today=138, 7d-median=138, 14d-median=136; carrying terms: polymarket, democratic, humanoid, launch, netanyahu, performing, mamdani, verve, carolina, jinping, nebraska, winners
- weather: today=199, 7d-median=176, 14d-median=174; carrying terms: cyclones, return, grand, tampa, atlantic, county, range, colorado, inland, interior, southwest, across
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: spread, growth, cpilfesl, walcl, money, balance, headline, jolts, pcepilfe, dexuseu, assets, crude
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, proxy, agriculture, rates, china, close, russell, range, credit, corporate, silver, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=101, 7d-median=104, 14d-median=104; carrying terms: production, operating, democratic, launch, transition, measures, herzegovina, serious, bosnia, lebanon, activities, junior
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, error, httperror, congresstrading, unauthorized, quiver, quantitative, client, quiverquant
- billionaires: today=40, 7d-median=37, 14d-median=38; carrying terms: ortega, nasdaq, berkshire, adani, walmart, bettencourt, ellison, amazon, zuckerberg, fashion, holdings, retail
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, county, delaware, california, johnson, services, appeals, blanche, thomas, group, holdings
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, reporting, issuer, holdings, robert, michael, steven, richard, bancorp
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: congress, pinkston, ossoff, talarico, david, shawn, raised, cortez, receipts, warner, lindsey, elect
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, korea, south, koreaherald
- gdelt_gkg: today=50, 7d-median=50, 14d-median=25; carrying terms: english, israel, hezbollah, trump, netanyahu, keywords, spanish, themes, russian, israeli, chinese, italian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=14, 7d-median=16, 14d-median=16; carrying terms: position, canada, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: spread, resulting, oecusse, democratic, implicated, march, great, recommendations, kasai, individuals, focus, tested
- cisa_kev: today=8, 7d-median=9, 14d-median=10; carrying terms: product, untrusted, vulnerability, remediation, authentication, fortinet, management, vendor, injection, langflow, deserialization, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=191, 7d-median=236, 14d-median=265; carrying terms: north, democratic, macedonia, cambodia, typhoon, denmark, indonesia, congo, herzegovina, bosnia, philippines, orange
- usgs_quakes: today=12, 7d-median=16, 14d-median=18; carrying terms: depth, japan, islands, russia, philippines, papua, guinea, tonga, zealand
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, returns, hormuz, ceasefire, traffic, normal, august, prime, strait, effective
- commentary: today=5, 7d-median=5, 14d-median=5; carrying terms: revolution, marginal, https, conversable, economist, class, marginalrevolution, college, assorted, links, market, conversableecon
- tech_news: today=56, 7d-median=57, 14d-median=57; carrying terms: bleepingcomputer, record, technica, attacks, groups, technology, infrastructure, access, company, schneier, going, today
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: massie, yassamin, kustoff, walkinshaw, blumenthal, cortez, suzan, speech, diana, paulina, higgins, associate
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, placed, module, today, sufficient, unavailable, either, paper, placement, converges, decision, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*