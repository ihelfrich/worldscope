# WORLDSCOPE morning brief — 2026-07-20

## Headline
2433 new items across 21 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (517) · Ukraine Theater (total-war monitoring) (508) · Russian Internal News (state + in-exile) (426) · World leaders & government officials (324) · Chinese Internal News (196) · U.S. Weather + Severe / Climate Outlooks (167) · Court opinions of consequence (federal & state) (60) · State-Level News (57) · Local News: St. Louis + Atlanta (35) · Ukrainian Internal News (national + local Kyiv) (32) · Sanctions & Designations (recent) (30) · IT, InfoSys & cybersecurity news (last 7 days) (17)

## What changed today
### International News + Multilateral Institutions — 517 new of 961 total
  - (2026-07-20) [Global] ‘It’s total devastation’: inside the Amazonian war against illegal gold mining
  - (2026-07-20) [Global] Huge search operation after passenger ferry sinks off coast of Guyana
  - (2026-07-20) [Global] Australia spent more than $9m for each asylum seeker held on Nauru last year – so why can’t they afford to buy food?
  - (2026-07-20) [Global] Israel criticises Labor’s draft Palestine policy in rare foreign intervention ahead of party conference
  - (2026-07-20) [Global] Derryn Hinch remembered as ‘journalistic James Bond’ – as it happened
  - (2026-07-20) [Global] Taxpayers could pay millions to abuse survivors if Christian Brothers goes bankrupt, court documents reveal

### Ukraine Theater (total-war monitoring) — 508 new of 705 total
  - (2026-07-19) [FIRMS] thermal anomaly 52.806, 32.227 (FRP 1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.366, 33.311 (FRP 1.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1.87 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.848, 29.990 (FRP 1.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1.89 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.133, 34.070 (FRP 0.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 0.72 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.297, 32.806 (FRP 2.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 2.5 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.299, 32.671 (FRP 0.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 0.84 MW

### Russian Internal News (state + in-exile) — 426 new of 745 total
  - (2026-07-20) В Каменске-Уральском прошли ливни — в городе затопило единственный роддом | LEDE: Следственный комитет в Свердловской области возбудил уголовное дело о халатности (статья 293 УК) после того,] (ru: В К…
      Следственный комитет в Свердловской области возбудил уголовное дело о халатности (статья 293 УК) после того, как в Каменске-Уральском затопило перинатальный центр. Об этом сообщает E1.ru, ссылаясь на источник в правоохра…
  - (2026-07-20) В России начались проблемы с доступом к магазину приложений App Store | LEDE: Доступность официального сайта компании Apple и ее магазина приложений App Store в России резко снизилась в конц] (ru: В Р…
      Доступность официального сайта компании Apple и ее магазина приложений App Store в России резко снизилась в конце прошлой недели. На это обратило внимание издание «Верстка».
  - (2026-07-20) Приложение «ГдеБЕНЗ» для поиска топлива на АЗС сейчас скачивают чаще, чем «Яндекс Заправки». Мы узнали у одного из разработчиков, как оно устроено | LEDE: На фоне топливного кризиса в России] (ru: При…
      На фоне топливного кризиса в России крупные компании вроде «Яндекса» и «Сбера», а также отдельные энтузиасты разрабатывают инструменты, с помощью которых россияне ищут заправки, где еще есть бензин. Несколько недель наза…
  - (2026-07-20) Война. 1608-й день. Украина второй раз за три дня ударила по Подмосковью. Пострадали 10 человек. Произошел пожар на территории, которой владеет друг Путина Сергей Ролдугин | LEDE: «Медуза» с] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-20) Урбанист из Челябинска Михаил Попов отказался от планов баллотироваться в городскую думу. Неделю назад он сломал позвоночник, пытаясь сбежать от полиции | LEDE: Урбанист Михаил Попов, баллот] (ru: Урб…
      Урбанист Михаил Попов, баллотировавшийся в депутаты Челябинской городской думы, решил не продолжать избирательную кампанию. Неделю назад, 13 июля, Попов, когда к нему домой пришли полицейские, прыгнул со второго этажа и…
  - (2026-07-20) «Одиссея» собрала в прокате 264 миллиона долларов за первый уик-энд. Это лучший старт среди фильмов Нолана | LEDE: Фильм «Одиссея» режиссера Кристофера Нолана, за первый уик-энд заработал по] (ru: «Од…
      Фильм «Одиссея» режиссера Кристофера Нолана, за первый уик-энд заработал по всему миру 264,1 миллиона долларов, пишет издание Variety.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 196 new of 251 total
  - (2026-07-19) 世界华语文学高地的隆起 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBHSjRwWmhseGN3ei1fTEdmdmdHY0l6Wlo5ZkZORWlGeXh5emhNTG9xRzc4SFJDcmgzT0U2SDBSbjBZZnNlaEp4S2ZRMndwUVA4RGJuOGp0MX] (zh:…
      世界华语文学高地的隆起 财新
  - (2026-07-19) 西班牙vs阿根廷：绿茵场下的200年经济分岔 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBjNURldUg3LVJZTnFCTjF2aGxTQjdVUkdQZU1KT240cmVZMHBpR3NyODZ5Z2g2X3dQU25yLXk3VjZIZHllN1VyLWJSSjFwRDV] (zh:…
      西班牙vs阿根廷：绿茵场下的200年经济分岔 财新
  - (2026-07-18) 显影｜让老人“家庭式养老” - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE8yUHBNaGVxeTFjM1ptN0hWbEdqeHFNU3hZXzdaVUhoOWFGdDZDVVJZSmt6bmNRaVg0TGxIUHM1OWJ1ZENSSDhtN2hydzJfbmVWZFpZLX] (zh:…
      显影｜让老人“家庭式养老” 财新周刊
  - (2026-07-20) 今日开盘：两市双双高开 沪指涨幅0.73% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5PMEtkeEF6V05XN1ZFZFBYNUZvcUJWOWJYYzdKd3poa1R5N0VvTzJrWTRUWnRUM29TajNKVnFHWlA1WVhjMzVFS19DWlFqWHB0] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.73% 财新
  - (2026-07-20) 国家队重仓ETF上周资金净流入850亿元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9CVEtRNmp2RjJpU0hyV2VRWUdCRXE5aVVfbE1YMndqZHE1TGgzSWJtdERPUWFCSlVSZjUxeHg0ckFjdGliVTludGdnakQ3UW5mR] (zh:…
      国家队重仓ETF上周资金净流入850亿元 财新
  - (2026-07-20) 花旗调高中国股票评级至“超配” 大摩建议加仓港股 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE4tQVBwZUVSeDZORGNzYk92WExVOVJGUWxMSDd3RU0zZ1RtRi13OW5KVW1KQU42SW5DQkd0dXpEcjd2ZkJjZGpYcmw1bjFUL] (zh:…
      花旗调高中国股票评级至“超配” 大摩建议加仓港股 财新

### U.S. Weather + Severe / Climate Outlooks — 167 new of 176 total
  - (2026-07-20) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-20) [Moderate] Special Weather Statement: Special Weather Statement issued July 20 at 4:49AM CDT by NWS La Crosse WI
      At 448 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from near Plum City to near Mantorville to near Clarks Grove. Movement was southeast at 40 mph. HAZARD...Wind gusts up to 50 mph. SOUR…
  - (2026-07-20) [Severe] Special Marine Warning: Special Marine Warning issued July 20 at 5:30AM EDT until July 20 at 6:30AM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Englewood to Tarpon Springs FL out 20 NM... Coastal waters from Tarpon Springs to Suwannee River FL out 20 NM…
  - (2026-07-20) [Severe] Special Marine Warning: Special Marine Warning issued July 20 at 5:28AM EDT until July 20 at 6:30AM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Tarpon Springs to Suwannee River FL out 20 NM... Waters from Tarpon Springs to Suwannee River FL out 20 to 60…
  - (2026-07-20) [Moderate] Heat Advisory: Heat Advisory issued July 20 at 3:24AM MDT until July 20 at 9:00PM MDT by NWS Denver CO
      * WHAT...High Temperatures 99 to 103. * WHERE...Fort Collins, Boulder, Denver metro, and Greeley. * WHEN...Until 9 PM MDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses.
  - (2026-07-20) [Severe] Tropical Storm Watch: Tropical Storm Watch issued July 20 at 4:20AM CDT by NWS Mobile AL
      * WHAT...Southwest winds 30 to 40 kt with gusts up to 55 kt and seas 10 to 15 ft. The strongest winds are forecast to be over the open Gulf waters. * WHERE...Portions of the coastal waters of Alabama and northwest Florid…

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-17) Alaska Supreme Court: ALYESKA INTERNATIONAL INC., D/B/A Alaska Sleep Clinic v. STATE OF ALASKA, DEPARTMENT OF REVENUE
  - (2026-07-17) Alaska Supreme Court: Erin I. v. State of Alaska, Department of Family & Community Services, Office of Children's Services
  - (2026-07-17) Alaska Supreme Court: JONATHAN J. CLINE v. MELINDA L. DUCKETT, F/K/A Melinda L. Cline
  - (2026-07-17) U.S. Court of International Trade: Saha Thai Steel Pipe Pub. Co. v. United States
  - (2026-07-17) Arizona Supreme Court: REPUBLICAN NATL COMMITTEE v. FONTES
  - (2026-07-17) Arizona Supreme Court: GOLDWATER v. PHOENIX

### State-Level News — 57 new of 190 total
  - (2026-07-20) [Connecticut] I’ve knocked on 4,000 doors. We need more urgency to bring down the cost of living
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/DSC_3907-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high"…
  - (2026-07-20) [Connecticut] There’s more the story on the Supreme Court decision on Roundup
      <img width="1024" height="684" src="https://ctmirror.org/wp-content/uploads/2026/01/AP26016713345414-1024x684.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy…
  - (2026-07-20) [Colorado] Fifty for 150: First National Western Stock Show takes place in Denver in 1906
      Ranchers and farmers gathered under a big top tent borrowed from the circus for the first official National Western Stock Show in Denver in January 1906. There had been previous stock show attempts, such as the 1875 Bloo…
  - (2026-07-20) [Colorado] Is the Colorado River in a climate doom loop?
      As negotiations and potential lawsuits over the Colorado River intensify, the U.S. Bureau of Reclamation – which is ultimately in charge of managing the river – would be smart to pull back from the high-stakes gambit and…
  - (2026-07-20) [Florida] Moody leads Nixon by 8 points, Vindman by 10, in new poll of Florida Senate race
      A new poll of likely midterm election voters in Florida shows Republicans maintaining steady leads in the marquee gubernatorial and Senate races on the ballot in November. The survey of 848 likely Florida midterm voters…
  - (2026-07-20) [Florida] A victory for ‘the right to tell people what they do not want to hear’
      “‘It was a bright cold day in April, and the clocks were striking thirteen.’” That’s how federal judge Mark Walker began his 2022 injunction blocking enforcement of Ron DeSantis’ “Stop Woke Act” in Florida institutions o…

### Local News: St. Louis + Atlanta — 35 new of 171 total
  - (2026-07-20) [St. Louis] Lou’s Clues – 7/20/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-07-20) [St. Louis] 13-year-old injured in downtown St. Louis road rage shooting
      A teen was injured in a road rage shooting near Ballpark Village Saturday night. Police said the teen was riding with his father when another driver opened fire.
  - (2026-07-20) [St. Louis] US expands bombing in Iran, which retaliates against Gulf states
      “We hit them very hard again tonight,” U.S. President Donald Trump said. “And we did that in honor of the” soldiers killed, he said.
  - (2026-07-20) [St. Louis] FDA says Taylor Farms cyclospora finding was 'false positive'
      FDA retracts cyclospora contamination finding in Taylor Farms de Mexico lettuce, calling it a "false positive."
  - (2026-07-20) [St. Louis] Loved ones honor victims one week after East St. Louis family killings
      One week after five relatives were killed, grieving family members gathered at Jones Park to remember the victims.
  - (2026-07-20) [St. Louis] Tropical Storm Fausto forms off Mexico's Pacific as tropical depression swirls in Gulf of Mexico
      Tropical Storm Fausto forms off Mexico, threatening to become a hurricane by Monday, while a Gulf depression nears Florida, potentially intensifying into a storm.

### Ukrainian Internal News (national + local Kyiv) — 32 new of 105 total
  - (2026-07-20) Russian Strike on Turkish Cargo Ship Leaving Odesa Kills 10
      A Russian missile struck the Turkish-owned cargo ship Golden Leo as it departed Odesa with grain, killing 10 people. Ukraine says the attack targeted civilian shipping and comes amid an intensifying campaign against Blac…
  - (2026-07-20) The Follies of Historical Memory: Poland, Ukraine and the Politics of Selective Remembrance
      Bohdan Vitvitsky argues that recent criticism from Polish politicians over Ukraine’s commemoration of the Ukrainian Insurgent Army (UPA) risks damaging relations at a time when both countries share vital security interes…
  - (2026-07-20) Russia Fires More Ballistic Missiles in 19 Days Than It Produces in a Month – Analysis
      Russia launched 107 ballistic missiles and 20 Zircon missiles in the first 19 days of July, exceeding its estimated monthly ballistic missile production and using two-thirds of its planned annual Zircon output, according…
  - (2026-07-20) Russian Anti-War Politician Ends Political Campaign After Pressure from Kremlin
      Russian opposition politician Boris Nadezhdin has withdrawn from the September State Duma election after authorities blocked his campaign, labeled him a “foreign agent,” fined him over alleged extremist symbols, and rest…
  - (2026-07-20) Farnborough 2026: Drones, Fighter Jets and Sovereignty
      The Farnborough Airshow opens Monday with a strong focus on European rearmament, next-generation fighter jets, drones, and defense autonomy. Ukraine will showcase its battlefield-tested drone technologies, while Boeing s…
  - (2026-07-20) Ukraine’s Massive 400-Drone Raid Hits Moscow Region Logistics Network, Fuel Sites
      More than 400 drones targeted the Moscow region overnight, according to Russian officials, as Ukraine struck logistics hubs, an oil depot, and a residential building. The attack marked the second reported strike on a Wil…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### IT, InfoSys & cybersecurity news (last 7 days) — 17 new of 58 total
  - (2026-07-20) [BleepingComputer] Critical ServiceNow code execution flaw now exploited in attacks
      Attackers have begun exploiting a critical vulnerability (CVE-2026-6875) in the ServiceNow AI Platform, according to threat intelligence company Defused. [...]
  - (2026-07-20) [The Hacker News] New 7-Zip Vulnerability Could Let Crafted XZ Archives Run Code During Extraction
      Opening a crafted XZ archive in 7-Zip could let an attacker run code on the machine. The flaw, CVE-2026-14266, is a heap-based buffer overflow in how the archiver processes XZ chunked data, and Trend Micro's Zero Day Ini…
  - (2026-07-20) [The Hacker News] Russian-Speaking Hacker Uses Google Gemini CLI to Control Botnet of Eight Dental Clinic PCs
      A solo Russian-speaking threat actor known as "bandcampro" outsourced a chunk of their operations to Google's open-source Gemini CLI artificial intelligence (AI) and commandeered a live botnet. The findings come from an…
  - (2026-07-20) [The Hacker News] World's Largest AI Model Repository Hugging Face Breached by Autonomous AI Agent
      In an ironic twist, open-source artificial intelligence (AI) platform Hugging Face revealed that it was the victim of a hack perpetrated by an autonomous AI agent system. The company said it detected and responded to the…
  - (2026-07-20) [The Hacker News] SleeperGem Uses Three Malicious RubyGems Packages to Target Developer Machines
      Cybersecurity researchers have flagged a new software supply chain attack codenamed SleeperGem targeting the Ruby ecosystem after three malicious gems were published to RubyGems with the end goal of serving additional pa…
  - (2026-07-20) [Cybersecurity Dive] Your attack surface is bigger than you think
      New data reveals where attack surfaces are hiding the most risk.

### Paper Trading Scorecard — 14 new of 149 total
  - (2026-07-20) [Polymarket] Will the ECB announce a 25 bps increase at the July 2026 meeting?
      This market will resolve according to the change in basis points in the deposit facility rate resulting from the July 2026 meeting of the European Central Bank, relative to the level it was prior to this meeting. The res…
  - (2026-07-20) [Polymarket] Will LeBron James play for the Denver Nuggets in 2026-27?
      This market will resolve to the next team LeBron James officially joins by October 31, 2026, 11:59 PM ET. If LeBron James does not officially join a new team by October 31, 2026, 11:59 PM ET, this market will resolve to…
  - (2026-07-20) [Polymarket] Will Elon Musk post 200-219 tweets from July 14 to July 21, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 14 12:00 PM ET to July 21, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-20) [Polymarket] Will the Pittsburgh Steelers win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-20) [Manifold] Will Jonas Vingegaard start another race for Team Visma | Lease a Bike before 2028?*
  - (2026-07-20) [Manifold] If Judit Polgár becomes President of Hungary, will she play an in-person game of chess with a world leader this year?

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-07-20) LoL: Nongshim Red Force vs KT Rolster (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $1,049,331 · resolves 2026-07-20
  - (2026-07-20) Will St. Louis Cardinals win the 2026 NL Central title?
      yes price: 1% · 24h volume: $825,180 · resolves 2026-10-11
  - (2026-07-20) LoL: DN SOOPers vs HANJIN BRION (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $810,320 · resolves 2026-07-20
  - (2026-07-20) LoL: Nongshim Red Force vs HANJIN BRION (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $619,011 · resolves 2026-07-20
  - (2026-07-20) LoL: Kiwoom DRX vs BNK FEARX (BO1) - KeSPA Cup Group Stage
      yes price: 28% · 24h volume: $592,639 · resolves 2026-07-20
  - (2026-07-20) LoL: DN SOOPers vs BNK FEARX (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $574,734 · resolves 2026-07-20

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-20) [Japan] Liberals Have Relaxed About Trump Because They Trust Him To Keep The Wars Going
      nuclear-news.net · English
  - (2026-07-20) [Japan] Honda extends its agreement with China GAC through 2038
      asia.nikkei.com · English
  - (2026-07-20) [Japan] Supporters of India cockroach movement caned by police
      asia.nikkei.com · English
  - (2026-07-20) [Japan] Corporations Lead U . S . Militarization of Space
      nuclear-news.net · English
  - (2026-07-20) [Japan] Extreme risk : AUKUS warnings as Garrett inquiry docks in Adelaide « nuclear - news
      nuclear-news.net · English
  - (2026-07-20) [Japan] State - owned Hongqi ultra - luxury sedan beats Rolls - Royce in China
      asia.nikkei.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 117 total
  - (2026-07-20) [USASpending] $4,813,063,025 → LEIDOS BIOMEDICAL RESEARCH INC: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
      Agency: Department of Health and Human Services. Description: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
  - (2026-07-20) [USASpending] $3,116,039,041 → LEIDOS, INC.: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STA
      Agency: National Science Foundation. Description: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STATES ANTARCTIC PROGRAM
  - (2026-07-20) [USASpending] $1,634,792,955 → NORTHROP GRUMMAN SYSTEMS CORPORATION: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUI
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUILDS UPON THE SUCCESS OF COMMERCIAL ORBITAL TRANSPORTATION SERVICES SPACE ACT AGREEMENT DEVELO…
  - (2026-07-20) [USASpending] $1,060,970,017 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-07-20) [USASpending] $697,707,307 → SALUS WORLDWIDE SOLUTIONS CORP.: SECTION 4(A). THE PURPOSE OF THIS REQUIREMENT IS TO OBTAIN C
      Agency: Department of Homeland Security. Description: SECTION 4(A). THE PURPOSE OF THIS REQUIREMENT IS TO OBTAIN COMPREHENSIVE SUPPORT TO REMOVAL OPERATIONS (CSRO) SUPPORT SERVICES FOR THE OFFICE FOR STRATEGY, POLICY, AN…
  - (2026-07-20) [USASpending] $652,980,558 → BOOZ ALLEN HAMILTON INC: CDM DEFEND GROUP BD BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP BD BRIDGE TASK ORDER

### USGS earthquakes (M4.5+, past day) — 8 new of 14 total
  - (2026-07-20) M 5.6 - 208 km SW of Port McNeill, Canada
      M5.6 · 208 km SW of Port McNeill, Canada · depth 10 km
  - (2026-07-20) M 5.2 - 27 km S of Javānrūd, Iran
      M5.2 · 27 km S of Javānrūd, Iran · depth 10 km
  - (2026-07-20) M 5.1 - 83 km W of Tobelo, Indonesia
      M5.1 · 83 km W of Tobelo, Indonesia · depth 69.965 km
  - (2026-07-20) M 4.9 - 27 km S of Javānrūd, Iran
      M4.9 · 27 km S of Javānrūd, Iran · depth 10 km
  - (2026-07-20) M 4.7 - 81 km WSW of Puerto Madero, Mexico
      M4.7 · 81 km WSW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-20) M 4.7 - 173 km W of Fakfak, Indonesia
      M4.7 · 173 km W of Fakfak, Indonesia · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 33 total
  - (2026-07-20) MOVER ▲ Bernard Arnault & family — $150.60B (+$0.28B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-20) MOVER ▲ Amancio Ortega — $136.99B (+$0.23B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-20) MOVER ▲ Francoise Bettencourt Meyers & family — $93.26B (+$0.20B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### GDACS — global disaster alerts — 2 new of 165 total
  - (2026-07-20) [Green] Earthquake in Canada
      Earthquake · Green alert · Canada · Magnitude 5.6M, Depth:10km
  - (2026-07-20) [Green] Earthquake in Canada
      Earthquake · Green alert · Canada · Magnitude 5.6M, Depth:10km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-20) [Marginal Revolution] Democrats are more politically segregated than are Republicans
      We estimate the extent of workplace political segregation in the United States by merging data covering over 45 million workers. We present four main findings. First, partisans are segregated by workplace. The average De…
  - (2026-07-20) [Marginal Revolution] Emergent Ventures winners, 56th cohort
      Audrey London, Los Angeles, to write a book on water in California. Seyi Oluwasanmi, London, to bring Brits to SF to learn tech. Thomas Haferlach, Berlin, payments and compute layer for the long tail of AI apps. Juan Ram…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: airworthiness, amendment, national, eliminating, amending, amendments, authorized, needed, existing, fishery, prompted, navigable
- state_bills: today=0, 7d-median=124, 14d-median=124
- state_news: today=190, 7d-median=452, 14d-median=452; carrying terms: court, opportunity, sizes, weeks, activity, protest, revenue, november, voted, party, green, reform
- local_news: today=171, 7d-median=226, 14d-median=226; carrying terms: court, soccer, party, charles, children, customers, trump, leaving, cbmirwfbvv, morning, across, search
- foreign_news: today=961, 7d-median=1028, 14d-median=1028; carrying terms: court, usually, battle, weeks, terrorist, illegal, survivors, agree, created, protest, travel, algerian
- chinese_internal: today=251, 7d-median=276, 14d-median=276; carrying terms: cbmibkfvx, cbmiakfvx, cbmiy, cbmia, cbmix, cbmiykfvx, cbmizefvx, target, people, china, cbmiw, cbmibefvx
- russian_internal: today=745, 7d-median=858, 14d-median=858; carrying terms: apple, style, novayagazeta, forbidden, europe, telegram, financial, raquo, street, istories, times, client
- ukrainian_internal: today=105, 7d-median=132, 14d-median=132; carrying terms: naval, stability, travel, cabinet, party, children, joint, authorities, deeper, media, confirmed, turning
- ukraine_theater: today=705, 7d-median=489, 14d-median=489; carrying terms: pqwezfzty, trzhn, gmzlaaddimm, zjzxj, featuring, chrcrelhnlzlclfarw, beeuxsnozvxftodzhewq, tyellwoujqegfda, vktqwhhiuw, cbmif, vision, ddzvc
- paper_bets: today=149, 7d-median=144, 14d-median=144; carrying terms: court, eliminated, florida, maine, comes, artist, becomes, market, visit, winners, survivors, nomination
- weather: today=176, 7d-median=166, 14d-median=166; carrying terms: northern, afdokx, activity, jefferson, quality, lincoln, winds, layer, possible, knots, level, region
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexjpus, personal, recession, labor, jolts, assets, unrate, latest, indicator, spread, inflation, unemployment
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, crude, credit, crypto, yield, russell, bitcoin, close, china, treasury, range, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=117, 7d-median=116, 14d-median=116; carrying terms: cbmib, description, situation, exploration, legislation, terrorist, illegal, agree, stability, launch, libya, region
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, congresstrading, client, httperror, unauthorized, error, https, quiverquant, quantitative
- billionaires: today=33, 7d-median=32, 14d-median=32; carrying terms: semiconductors, adani, euronext, tesla, buffett, trading, huang, zuckerberg, berkshire, changpeng, france, googl
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, north, services, jonathan, trucks, island, supreme, alaska, community, revenue, association, appeals
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed, david, thomas, scott, amended, jennifer, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: trone, pinkston, graham, talarico, filing, alexandria, committee, angels, jonathan, johnson, ocasio, congress
- gdelt_regions: today=12, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=50, 7d-median=48, 14d-median=48; carrying terms: english, chinese, russian, russia, ukraine, against, spanish, themes, dailykos, perimeter, arabic, yahoo
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: analysis, pregnant, regio, situation, ventilatory, locations, covid, coronavirus, activity, since, outbreak, person
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: authentication, request, cisco, vendor, traversal, control, bypass, sharepoint, microsoft, improper, vulnerability, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=165, 7d-median=156, 14d-median=156; carrying terms: alert, republic, medium, france, hungary, colombia, russia, tropical, kenya, indonesia, denmark, impact
- usgs_quakes: today=14, 7d-median=15, 14d-median=15; carrying terms: depth, puerto, mexico, madero, kermadec, south, chile, indonesia, islands
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ethiopia, resolves, volume, meeting, rates, minister, price, prime, interest, presidential, demeke, mekonnen
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, class, economist, revolution, marginal, https, points, particular, funded, paper, movement, corporations
- tech_news: today=58, 7d-median=58, 14d-median=58; carrying terms: online, activity, delivered, hundreds, operators, plates, access, parsity, inbox, schneier, stake, skills
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: cindy, court, communications, carbajal, marcy, vance, peter, hegseth, wasserman, sorensen, wiles, madeleine
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, markets, paper, identify, either, market, claude, module, evidence, consensus, unavailable, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*