# WORLDSCOPE morning brief — 2026-07-20

## Headline
2488 new items across 21 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (520) · International News + Multilateral Institutions (507) · Russian Internal News (state + in-exile) (456) · World leaders & government officials (324) · Chinese Internal News (193) · U.S. Weather + Severe / Climate Outlooks (167) · Court opinions of consequence (federal & state) (60) · GDELT GKG — themes / entities / watch areas (50) · State-Level News (47) · Local News: St. Louis + Atlanta (34) · Ukrainian Internal News (national + local Kyiv) (30) · Sanctions & Designations (recent) (30)

## What changed today
### Ukraine Theater (total-war monitoring) — 520 new of 705 total
  - (2026-07-20) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-19) [Liveuamap] Eilat Municipality Spokesperson: A short time ago, an Israeli army spokesperson reported that launches from Iran were detected towards the city of Aqaba in Jordan, near the territory of th…
      Eilat Municipality Spokesperson: A short time ago, an Israeli army spokesperson reported that launches from Iran were d
  - (2026-07-18) [Liveuamap] The FSB reported that it had thwarted large-scale Ukrainian drone attacks on military airfields in the Amur and Chelyabinsk regions. The FSB claims to have received information that Ukrain…
      The FSB reported that it had thwarted large-scale Ukrainian drone attacks on military airfields in the Amur and Chelyabinsk regi
  - (2026-07-19) [Liveuamap] Numerous blasts were heard in Qeshm Hormozgan Province, Iran - iran.liveuamap.com
      Numerous blasts were heard in Qeshm Hormozgan Province, Iran iran.liveuamap.com
  - (2026-07-19) [Liveuamap] Tasnim News Agency, quoting the Iranian Revolutionary Guard: - Targeting a US Navy fueling berth in Kuwait's Al-Ahmadi port - Targeting a US fighter jet site at Sheikh Isa Air Base in Bahr…
      Tasnim News Agency, quoting the Iranian Revolutionary Guard: - Targeting a US Navy fueling berth in Kuwait's Al-
  - (2026-07-16) [Liveuamap] CENTCOM: At 2 p.m. ET today, U.S. forces began conducting a new wave of strikes against Iran for the sixth consecutive night to further degrade Iranian military capabilities Nabatiyeh Gove…
      CENTCOM: At 2 p.m. ET today, U.S. forces began conducting a new wave of strikes against Iran for the sixth consec

### International News + Multilateral Institutions — 507 new of 960 total
  - (2026-07-20) [Global] Food delivery rider wins China's top literary prize
      Wang Jibing is among blue-collar Chinese workers gaining wider attention for their literary works.
  - (2026-07-20) [Global] Norway opens new memorial for victims of 2011 massacre
      The artwork in the capital Oslo was unveiled on Sunday ahead of the 15th anniversary of the attack.
  - (2026-07-20) [Global] Test that found source of US explosive diarrhoea outbreak was false positive, health officials say
      The latest update from the US Food and Drug Administration means the exact source of the parasite is still not known.
  - (2026-07-20) [Global] ‘Everyone's afraid to die’: Struggle to recruit soldiers in Ukraine turns violent
      Aggression against recruitment officers has become increasingly threatening, police say.
  - (2026-07-19) [Global] This farmer wanted to quit the cocaine industry - he couldn't
      Colombians who grow cocaine's raw material bemoan a lack of support to help them switch crops.
  - (2026-07-20) [Global] From hundreds to thousands: How India's 'cockroach' protest movement has grown
      BBC's Azadeh Moshiri reports as thousands attempt to march to India's parliament in support of the Cockroach Janta Party's demand for education reforms.

### Russian Internal News (state + in-exile) — 456 new of 788 total
  - (2026-07-20) Приложение «ГдеБЕНЗ» для поиска топлива на АЗС сейчас скачивают чаще, чем «Яндекс Заправки». Мы узнали у одного из разработчиков, как оно устроено | LEDE: На фоне топливного кризиса в России] (ru: При…
      На фоне топливного кризиса в России крупные компании вроде «Яндекса» и «Сбера», а также отдельные энтузиасты разрабатывают инструменты, с помощью которых россияне ищут заправки, где еще есть бензин. Несколько недель наза…
  - (2026-07-20) Война. 1608-й день. Украина второй раз за три дня ударила по Подмосковью. Пострадали 10 человек. Произошел пожар на территории, которой владеет друг Путина Сергей Ролдугин | LEDE: «Медуза» с] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-20) Урбанист из Челябинска Михаил Попов отказался от планов баллотироваться в городскую думу. Неделю назад он сломал позвоночник, пытаясь сбежать от полиции | LEDE: Урбанист Михаил Попов, баллот] (ru: Урб…
      Урбанист Михаил Попов, баллотировавшийся в депутаты Челябинской городской думы, решил не продолжать избирательную кампанию. Неделю назад, 13 июля, Попов, когда к нему домой пришли полицейские, прыгнул со второго этажа и…
  - (2026-07-20) «Одиссея» собрала в прокате 264 миллиона долларов за первый уик-энд. Это лучший старт среди фильмов Нолана | LEDE: Фильм «Одиссея» режиссера Кристофера Нолана, за первый уик-энд заработал по] (ru: «Од…
      Фильм «Одиссея» режиссера Кристофера Нолана, за первый уик-энд заработал по всему миру 264,1 миллиона долларов, пишет издание Variety.
  - (2026-07-20) Индекс Мосбиржи упал до минимума с осени 2022 года | LEDE: Индекс Мосбиржи на открытии торгов в понедельник, 20 июля, опустился ниже 1900 пунктов впервые с 10 октября 2022 года. ] (ru: Индекс Мосбиржи…
      Индекс Мосбиржи на открытии торгов в понедельник, 20 июля, опустился ниже 1900 пунктов впервые с 10 октября 2022 года.
  - (2026-07-20) Цена нефти Brent вновь превысила 90 долларов за баррель на фоне эскалации между США и Ираном | LEDE: Нефть Brent на мировых биржах вновь торгуется выше отметки в 90 долларов за баррель на фо] (ru: Цен…
      Нефть Brent на мировых биржах вновь торгуется выше отметки в 90 долларов за баррель на фоне продолжающейся войны США и Ирана.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 193 new of 249 total
  - (2026-07-19) 世界华语文学高地的隆起 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBHSjRwWmhseGN3ei1fTEdmdmdHY0l6Wlo5ZkZORWlGeXh5emhNTG9xRzc4SFJDcmgzT0U2SDBSbjBZZnNlaEp4S2ZRMndwUVA4RGJuOGp0MX] (zh:…
      世界华语文学高地的隆起 财新
  - (2026-07-19) 西班牙vs阿根廷：绿茵场下的200年经济分岔 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBjNURldUg3LVJZTnFCTjF2aGxTQjdVUkdQZU1KT240cmVZMHBpR3NyODZ5Z2g2X3dQU25yLXk3VjZIZHllN1VyLWJSSjFwRDV] (zh:…
      西班牙vs阿根廷：绿茵场下的200年经济分岔 财新
  - (2026-07-18) 显影｜让老人“家庭式养老” - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE8yUHBNaGVxeTFjM1ptN0hWbEdqeHFNU3hZXzdaVUhoOWFGdDZDVVJZSmt6bmNRaVg0TGxIUHM1OWJ1ZENSSDhtN2hydzJfbmVWZFpZLX] (zh:…
      显影｜让老人“家庭式养老” 财新周刊
  - (2026-07-20) 今日开盘：两市双双高开 沪指涨幅0.73% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5PMEtkeEF6V05XN1ZFZFBYNUZvcUJWOWJYYzdKd3poa1R5N0VvTzJrWTRUWnRUM29TajNKVnFHWlA1WVhjMzVFS19DWlFqWHB0] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.73% 财新
  - (2026-07-20) 花旗调高中国股票评级至“超配” 大摩建议加仓港股 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE4tQVBwZUVSeDZORGNzYk92WExVOVJGUWxMSDd3RU0zZ1RtRi13OW5KVW1KQU42SW5DQkd0dXpEcjd2ZkJjZGpYcmw1bjFUL] (zh:…
      花旗调高中国股票评级至“超配” 大摩建议加仓港股 财新
  - (2026-07-20) 国家队重仓ETF上周资金净流入850亿元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9CVEtRNmp2RjJpU0hyV2VRWUdCRXE5aVVfbE1YMndqZHE1TGgzSWJtdERPUWFCSlVSZjUxeHg0ckFjdGliVTludGdnakQ3UW5mR] (zh:…
      国家队重仓ETF上周资金净流入850亿元 财新

### U.S. Weather + Severe / Climate Outlooks — 167 new of 177 total
  - (2026-07-20) [Severe] Special Marine Warning: Special Marine Warning issued July 20 at 5:30AM EDT until July 20 at 6:30AM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Englewood to Tarpon Springs FL out 20 NM... Coastal waters from Tarpon Springs to Suwannee River FL out 20 NM…
  - (2026-07-20) [Severe] Special Marine Warning: Special Marine Warning issued July 20 at 5:28AM EDT until July 20 at 6:30AM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Tarpon Springs to Suwannee River FL out 20 NM... Waters from Tarpon Springs to Suwannee River FL out 20 to 60…
  - (2026-07-20) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-20) [Moderate] Heat Advisory: Heat Advisory issued July 20 at 3:24AM MDT until July 20 at 9:00PM MDT by NWS Denver CO
      * WHAT...High Temperatures 99 to 103. * WHERE...Fort Collins, Boulder, Denver metro, and Greeley. * WHEN...Until 9 PM MDT this evening. * IMPACTS...Hot temperatures may cause heat illnesses.
  - (2026-07-20) [Severe] Tropical Storm Watch: Tropical Storm Watch issued July 20 at 4:20AM CDT by NWS Mobile AL
      * WHAT...Southwest winds 30 to 40 kt with gusts up to 55 kt and seas 10 to 15 ft. The strongest winds are forecast to be over the open Gulf waters. * WHERE...Portions of the coastal waters of Alabama and northwest Florid…
  - (2026-07-20) [Severe] Tropical Storm Watch: Tropical Storm Watch issued July 20 at 4:20AM CDT by NWS Mobile AL
      * WHAT...Southwest winds 25 to 35 kt with gusts up to 55 kt and seas 10 to 15 ft. The strongest winds are forecast to be over the open Gulf waters. * WHERE...Pensacola Bay System, Western Choctawhatchee Bay, Eastern Choc…

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Local 1374, Jefferson Parish v. Roberts
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Thompson v. McGehee
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: United States v. Kirkwood
  - (2026-07-17) U.S. Court of Appeals, 5th Cir.: Keathley v. Buddy Ayers
  - (2026-07-17) U.S. Court of Appeals, 3rd Cir.: Association of New Jersey Rifle and Pistol Clubs I v. Attorney General New Jersey
  - (2026-07-17) U.S. Court of Appeals, 3rd Cir.: City of Chester Pennsylvania v.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Šī ir pirmā reize , kad mēs ar kaut ko tādu saskaramies – negaidīta atziņa no Maskavas
      la.lv · Latvian · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] ЦБ купил юаней на внутреннем рынке на 4 , 8 миллиарда рублей
      1prime.ru · Russian · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] هيئة بريطانية : جنوح سفينة قبالة الساحل العماني بعد استهداف بمقذوف
      shorouknews.com · Arabic · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Ship ablaze in Strait of Hormuz after attack ; crew rescued : united kingdom maritime agency
      aninews.in · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Producția industrială din Republica Moldova a crescut cu peste 8 % în luna mai
      news.yam.md · Romanian · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Grande dame returns : inside the historic the Queenscliff Hotel | The Daily Advertiser
      dailyadvertiser.com.au · English · tone NA

### State-Level News — 47 new of 180 total
  - (2026-07-20) [Connecticut] I’ve knocked on 4,000 doors. We need more urgency to bring down the cost of living
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/DSC_3907-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high"…
  - (2026-07-20) [Connecticut] There’s more the story on the Supreme Court decision on Roundup
      <img width="1024" height="684" src="https://ctmirror.org/wp-content/uploads/2026/01/AP26016713345414-1024x684.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy…
  - (2026-07-20) [Maine] Time to vote Susan Collins out | Letter
      Sen. Susan Collins pledged to serve just two terms when she was elected in 1996. Correct me if I am wrong, but it is now 2026 and she wants another term? It is time to let someone else take her place, someone not so entr…
  - (2026-07-20) [Maine] I don’t remotely regret supporting Graham Platner | Letter
      <img width="1024" height="729" src="https://www.pressherald.com/wp-content/uploads/sites/4/2026/07/43463086_20260713_Graham_Platner_Litter-2.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-07-20) [Maine] Dozens of senators sign Angus King letter demanding DHS reform after deadly ICE shootings
      <img width="1024" height="683" src="https://www.pressherald.com/wp-content/uploads/sites/4/2026/07/43700944_20260715_Biddeford-Follow_4.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-07-20) [Maine] Keep an eye on the boundary between church and state | Letter
      Ray Vensel’s recent op-ed on Trump’s Religious Liberty Commission (“Trump ‘report’ on religion must be revealed for what it is,” July 11) was a needed reminder of this administration’s agenda of breaking separation bound…

### Local News: St. Louis + Atlanta — 34 new of 172 total
  - (2026-07-20) [St. Louis] Lou’s Clues – 7/20/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-07-20) [St. Louis] Missouri reports 216 cyclospora cases, a fivefold jump in one week
  - (2026-07-20) [St. Louis] US bombing of Iran expands as American troops killed and Tehran retaliates against the Gulf states
      “We hit them very hard again tonight,” U.S. President Donald Trump said. “And we did that in honor of the” soldiers killed, he said.
  - (2026-07-20) [St. Louis] FDA says Taylor Farms cyclospora finding was 'false positive'
      FDA retracts cyclospora contamination finding in Taylor Farms de Mexico lettuce, calling it a "false positive."
  - (2026-07-20) [St. Louis] Loved ones honor victims one week after East St. Louis family killings
      One week after five relatives were killed, grieving family members gathered at Jones Park to remember the victims.
  - (2026-07-20) [St. Louis] Tropical Storm Fausto forms off Mexico's Pacific as tropical depression swirls in Gulf of Mexico
      Tropical Storm Fausto forms off Mexico, threatening to become a hurricane by Monday, while a Gulf depression nears Florida, potentially intensifying into a storm.

### Ukrainian Internal News (national + local Kyiv) — 30 new of 104 total
  - (2026-07-20) У Вільнюсі попрощалися з литовським добровольцем, що загинув на війні в Україні | LEDE: Десятки людей, серед яких високопосадовці, зібралися в неділю в церкві у Вільнюсі, щоб віддати останню ша] (uk:…
      Десятки людей, серед яких високопосадовці, зібралися в неділю в церкві у Вільнюсі, щоб віддати останню шану Ігнасу Кайлюсу – литовському добровольцю, який загинув, воюючи на боці українських сил проти російських загарбни…
  - (2026-07-20) Міністр оборони Литви: Путіну потрібна нова "перемога" і він дивиться на Балтію та Польщу | LEDE: Оскільки Росія не здатна здобути перемогу у війні проти України, Кремль шукає альтернативний ва] (uk:…
      Оскільки Росія не здатна здобути перемогу у війні проти України, Кремль шукає альтернативний варіант перемоги і зараз розглядає Балтійський регіон та Польщу як найімовірнішу наступну ціль.
  - (2026-07-20) Одна людина загинула, п’ятеро поранені внаслідок удару РФ КАБами по Запоріжжю | LEDE: Унаслідок російського удару керованими авіабомбами по Запоріжжю загинула одна людина, ще п’ятеро дістали по] (uk:…
      Унаслідок російського удару керованими авіабомбами по Запоріжжю загинула одна людина, ще п’ятеро дістали поранення.
  - (2026-07-20) По всій Польщі протестують сирени тривоги | LEDE: У вівторок, 21 липня, по всій Польщі відбудуться масштабні навчання з перевірки систем попередження населення про можливі повітряні загрози.] (uk: По…
      У вівторок, 21 липня, по всій Польщі відбудуться масштабні навчання з перевірки систем попередження населення про можливі повітряні загрози.
  - (2026-07-20) Бернем стане четвертим прем'єром Британії за правління короля Чарльза | LEDE: У понеділок, 20 липня, Енді Бернем стане новим прем'є-міністром Великої Британії – вже четвертим за час правління к] (uk:…
      У понеділок, 20 липня, Енді Бернем стане новим прем'є-міністром Великої Британії – вже четвертим за час правління короля Чарльза III, яке розпочалося лише у 2022 році.
  - (2026-07-20) У Німеччині затримали чоловіка, який жбурнув помідор у прем'єра | LEDE: У німецькій землі Баварії під час публічного заходу невідомий чоловік жбурнув помідор у прем'єр-міністра землі Маркуса Зь] (uk:…
      У німецькій землі Баварії під час публічного заходу невідомий чоловік жбурнув помідор у прем'єр-міністра землі Маркуса Зьодера, нападника одразу затримали співробітники правоохоронних органів.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 58 total
  - (2026-07-20) [BleepingComputer] Critical ServiceNow code execution flaw now exploited in attacks
      Attackers have begun exploiting a critical vulnerability (CVE-2026-6875) in the ServiceNow AI Platform, according to threat intelligence company Defused. [...]
  - (2026-07-20) [The Hacker News] World's Largest AI Model Repository Hugging Face Breached by Autonomous AI Agent
      In an ironic twist, open-source artificial intelligence (AI) platform Hugging Face revealed that it was the victim of a hack perpetrated by an autonomous AI agent system. The company said it detected and responded to the…
  - (2026-07-20) [The Hacker News] SleeperGem Uses Three Malicious RubyGems Packages to Target Developer Machines
      Cybersecurity researchers have flagged a new software supply chain attack codenamed SleeperGem targeting the Ruby ecosystem after three malicious gems were published to RubyGems with the end goal of serving additional pa…
  - (2026-07-20) [Cybersecurity Dive] Your attack surface is bigger than you think
      New data reveals where attack surfaces are hiding the most risk.
  - (2026-07-20) [Cybersecurity Dive] How agentic endpoint security shuts down IDE-based supply chain attacks
      Attention shifts from EDR to Agentic Endpoint Security to close visibility gaps that AI can exploit.
  - (2026-07-20) [Cybersecurity Dive] The secret problem in AI infrastructure: Why MCP security starts with secrets
      AI changes how infrastructure is accessed. Here's what to secure.

### Paper Trading Scorecard — 14 new of 147 total
  - (2026-07-20) [Polymarket] Will the ECB announce a 25 bps increase at the July 2026 meeting?
      This market will resolve according to the change in basis points in the deposit facility rate resulting from the July 2026 meeting of the European Central Bank, relative to the level it was prior to this meeting. The res…
  - (2026-07-20) [Polymarket] Will LeBron James play for the Denver Nuggets in 2026-27?
      This market will resolve to the next team LeBron James officially joins by October 31, 2026, 11:59 PM ET. If LeBron James does not officially join a new team by October 31, 2026, 11:59 PM ET, this market will resolve to…
  - (2026-07-20) [Polymarket] Will Elon Musk post 200-219 tweets from July 14 to July 21, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 14 12:00 PM ET to July 21, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-20) [Polymarket] Will Alibaba have the best Chinese AI model at the end of July 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank among primarily Chinese companies, based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table und…
  - (2026-07-20) [Manifold] Will Jonas Vingegaard start another race for Team Visma | Lease a Bike before 2028?*
  - (2026-07-20) [Manifold] If Judit Polgár becomes President of Hungary, will she play an in-person game of chess with a world leader this year?

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-07-20) LoL: Nongshim Red Force vs KT Rolster (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $1,044,119 · resolves 2026-07-20
  - (2026-07-20) Will St. Louis Cardinals win the 2026 NL Central title?
      yes price: 1% · 24h volume: $825,180 · resolves 2026-10-11
  - (2026-07-20) LoL: DN SOOPers vs HANJIN BRION (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $784,680 · resolves 2026-07-20
  - (2026-07-20) Iasi Open: Mayar Sherif vs Paula Badosa
      yes price: 100% · 24h volume: $733,243 · resolves 2026-07-26
  - (2026-07-20) LoL: Nongshim Red Force vs HANJIN BRION (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $618,995 · resolves 2026-07-20
  - (2026-07-20) LoL: DN SOOPers vs BNK FEARX (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $561,058 · resolves 2026-07-20

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 117 total
  - (2026-07-20) [USASpending] $4,813,063,025 → LEIDOS BIOMEDICAL RESEARCH INC: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
      Agency: Department of Health and Human Services. Description: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
  - (2026-07-20) [USASpending] $3,116,039,041 → LEIDOS, INC.: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STA
      Agency: National Science Foundation. Description: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STATES ANTARCTIC PROGRAM
  - (2026-07-20) [USASpending] $1,634,792,955 → NORTHROP GRUMMAN SYSTEMS CORPORATION: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUI
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUILDS UPON THE SUCCESS OF COMMERCIAL ORBITAL TRANSPORTATION SERVICES SPACE ACT AGREEMENT DEVELO…
  - (2026-07-20) [USASpending] $1,060,970,017 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-07-20) [USASpending] $697,707,307 → SALUS WORLDWIDE SOLUTIONS CORP.: SECTION 4(A). THE PURPOSE OF THIS REQUIREMENT IS TO OBTAIN C
      Agency: Department of Homeland Security. Description: SECTION 4(A). THE PURPOSE OF THIS REQUIREMENT IS TO OBTAIN COMPREHENSIVE SUPPORT TO REMOVAL OPERATIONS (CSRO) SUPPORT SERVICES FOR THE OFFICE FOR STRATEGY, POLICY, AN…
  - (2026-07-20) [USASpending] $652,980,558 → BOOZ ALLEN HAMILTON INC: CDM DEFEND GROUP BD BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP BD BRIDGE TASK ORDER

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 37 total
  - (2026-07-20) MOVER ▼ Bernard Arnault & family — $150.32B ($-1.07B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-20) MOVER ▲ Gautam Adani — $89.65B (+$0.89B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-20) MOVER ▼ Francoise Bettencourt Meyers & family — $93.06B ($-0.65B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-20) MOVER ▼ Mukesh Ambani — $89.50B ($-0.36B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-20) MOVER ▼ Amancio Ortega — $136.76B ($-0.13B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-20) MOVER ▼ Carlos Slim Helu & family — $125.15B ($-0.06B since yesterday)
      Mexico · Telecom · source: Telecom

### USGS earthquakes (M4.5+, past day) — 7 new of 14 total
  - (2026-07-20) M 5.6 - 208 km SW of Port McNeill, Canada
      M5.6 · 208 km SW of Port McNeill, Canada · depth 10 km
  - (2026-07-20) M 5.2 - 27 km S of Javānrūd, Iran
      M5.2 · 27 km S of Javānrūd, Iran · depth 10 km
  - (2026-07-20) M 4.9 - 27 km S of Javānrūd, Iran
      M4.9 · 27 km S of Javānrūd, Iran · depth 10 km
  - (2026-07-20) M 4.7 - 81 km WSW of Puerto Madero, Mexico
      M4.7 · 81 km WSW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-20) M 4.7 - 173 km W of Fakfak, Indonesia
      M4.7 · 173 km W of Fakfak, Indonesia · depth 10 km
  - (2026-07-20) M 4.6 - 3 km NE of Jordán, Colombia
      M4.6 · 3 km NE of Jordán, Colombia · depth 152.012 km

### GDACS — global disaster alerts — 2 new of 142 total
  - (2026-07-20) [Green] Earthquake in Canada
      Earthquake · Green alert · Canada · Magnitude 5.6M, Depth:10km
  - (2026-07-20) [Green] Earthquake in Canada
      Earthquake · Green alert · Canada · Magnitude 5.6M, Depth:10km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-20) [Marginal Revolution] Democrats are more politically segregated than are Republicans
      We estimate the extent of workplace political segregation in the United States by merging data covering over 45 million workers. We present four main findings. First, partisans are segregated by workplace. The average De…
  - (2026-07-20) [Marginal Revolution] Emergent Ventures winners, 56th cohort
      Audrey London, Los Angeles, to write a book on water in California. Seyi Oluwasanmi, London, to bring Brits to SF to learn tech. Thomas Haferlach, Berlin, payments and compute layer for the long tail of AI apps. Juan Ram…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: amendments, establishing, waters, public, plans, based, marine, adopting, local, eliminating, certain, action
- state_bills: today=0, 7d-median=124, 14d-median=124
- state_news: today=180, 7d-median=452, 14d-median=452; carrying terms: means, struggling, hospital, driving, fatal, secretary, appointed, congress, demand, release, crowd, church
- local_news: today=172, 7d-median=226, 14d-median=226; carrying terms: deputies, alert, custody, struck, messi, families, image, search, school, braves, british, announced
- foreign_news: today=960, 7d-median=1028, 14d-median=1028; carrying terms: message, struggling, ukrainian, plateau, average, fatal, invaders, demand, investments, figcaption, virtual, export
- chinese_internal: today=249, 7d-median=276, 14d-median=276; carrying terms: cbmidefvx, cbmiyefvx, https, cbmiw, google, global, color, cbmicefvx, people, cbmixkfvx, cbmizefvx, cbmiykfvx
- russian_internal: today=788, 7d-median=858, 14d-median=858; carrying terms: technology, raquo, bloomberg, laquo, journal, street, istories, novayagazeta, found, insider, httperror, target
- ukrainian_internal: today=104, 7d-median=132, 14d-median=132; carrying terms: ukrainian, secretary, recorded, according, occupied, study, signs, defenses, pressure, agreed, diplomatic, capabilities
- ukraine_theater: today=705, 7d-median=489, 14d-median=489; carrying terms: rnbplwzhlv, ukrainian, sbtfmd, jybujly, hzdgzauek, cuxqae, demining, jyulpug, enemy, today, fhbzhsti, xzvfqnmrlskrit
- paper_bets: today=147, 7d-median=144, 14d-median=144; carrying terms: goals, miles, secretary, massa, successor, russell, miami, event, hampshire, playoff, according, office
- weather: today=177, 7d-median=166, 14d-median=166; carrying terms: message, miles, cause, miami, amounts, storm, occur, afdmeg, possible, damage, southeastern, today
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: effective, inflation, dexuseu, walcl, pcepilfe, total, openings, money, sheet, dexchus, implied, commodities
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: silver, bitcoin, futures, yield, close, large, proxy, russell, china, equities, range, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=117, 7d-median=116, 14d-median=116; carrying terms: jjmudpzw, prohibited, destabilisation, practices, office, respect, sectoral, abuses, congo, clipper, economic, mtjwwxz
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, httperror, client, unauthorized, error, congresstrading, quantitative, quiverquant, https
- billionaires: today=37, 7d-median=33, 14d-median=33; carrying terms: fashion, technology, bettencourt, family, spacex, bezos, bloomberg, trading, investments, ortega, berkshire, retail
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: family, appeals, community, rhode, energy, office, electric, north, delaware, district, robert, supreme
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, reporting, accno, david, scott, thomas, michael, jennifer, amended
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, disbursements, platner, cortez, receipts, congress, trone, lindsey, david, jonathan, committee, cooper
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=50, 7d-median=48, 14d-median=48; carrying terms: english, chinese, russian, against, perimeter, themes, sanctions, arabic, spanish, ukraine, russia, yahoo
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: formula, support, accordance, symptom, hospital, cause, average, aboard, genetic, chikv, fatal, diarrhoea
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: injection, server, improper, bypass, traversal, microsoft, access, request, remediation, authentication, vulnerability, control
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=142, 7d-median=146, 14d-median=146; carrying terms: czech, salvador, belarus, hungary, philippines, ukraine, republic, germany, storm, colombia, agricultural, austria
- usgs_quakes: today=14, 7d-median=15, 14d-median=15; carrying terms: depth, hihifo, south, chile, puerto, madero, indonesia, islands, mexico, kermadec, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ethiopia, volume, interest, prime, price, rates, resolves, meeting, minister, presidential, molla, demeke
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, marginal, revolution, conversable, class, https, particular, points, pushback, heidi, among, useful
- tech_news: today=58, 7d-median=58, 14d-median=58; carrying terms: today, crossposted, leaders, student, previously, stake, newsletter, source, public, activities, program, access
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: shontel, sonia, ansari, cramer, doris, lofgren, bynum, anomaly, ramirez, secretary, alford, stefanik
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, unavailable, identify, consensus, placement, sufficient, module, claude, decision, paper, evidence, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*