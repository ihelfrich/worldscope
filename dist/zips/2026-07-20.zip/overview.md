# WORLDSCOPE morning brief — 2026-07-20

## Headline
2714 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (584) · Ukraine Theater (total-war monitoring) (522) · Russian Internal News (state + in-exile) (401) · World leaders & government officials (324) · Chinese Internal News (212) · U.S. Weather + Severe / Climate Outlooks (153) · State-Level News (127) · Local News: St. Louis + Atlanta (77) · Court opinions of consequence (federal & state) (60) · GDELT GKG — themes / entities / watch areas (50) · Ukrainian Internal News (national + local Kyiv) (42) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 584 new of 934 total
  - (2026-07-20) [Global] Burnham promises help with your money. How could it affect you?
      New Prime Minister Andy Burnham says he wants life to be more affordable, but how could he do it?
  - (2026-07-20) [Global] Ryanair profits drop as Iran war puts off passengers and lifts fuel costs
      The Irish airline said oil prices had increased costs meanwhile Brent crude surpassed $90.
  - (2026-07-20) [Global] Jobs, benefits and taxes: What Andy Burnham means for your finances
      The person in charge of the country will change but the financial challenges remain the same.
  - (2026-07-20) [Global] Burnham promises help with your money. How could it affect you?
      New Prime Minister Andy Burnham says he wants life to be more affordable, but how could he do it?
  - (2026-07-20) [Global] Former academy pupil offers students free haircuts
      Razwan Amin set up his barbers after leaving Erdington Academy and wants to help people with the cost of living.
  - (2026-07-18) [Global] Money Box
      Call for help for people on low incomes who must now wait longer for their state pension.

### Ukraine Theater (total-war monitoring) — 522 new of 705 total
  - (2026-07-19) [FIRMS] thermal anomaly 52.806, 32.227 (FRP 1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.366, 33.311 (FRP 1.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1.87 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.848, 29.990 (FRP 1.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1.89 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.133, 34.070 (FRP 0.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 0.72 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.297, 32.806 (FRP 2.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 2.5 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.299, 32.671 (FRP 0.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 0.84 MW

### Russian Internal News (state + in-exile) — 401 new of 494 total
  - (2026-07-20) Госдума вернулась к рассмотрению закона против россиян, критикующих власти из-за рубежа. Им запретят продавать имущество и делать банковские переводы | LEDE: Депутаты Госдумы одобрили поправ] (ru: Гос…
      Депутаты Госдумы одобрили поправки ко второму чтению законопроекта «О временных ограничительных мерах в отношении лиц, находящихся за пределами РФ и уклоняющихся от исполнения наказания».
  - (2026-07-20) В Белгородской области беспилотник ударил по пассажирскому автобусу. Погибли пять человек, более 20 ранены | LEDE: Украинский беспилотник ударил по пассажирскому автобусу в городе Шебекино в] (ru: В Б…
      Украинский беспилотник ударил по пассажирскому автобусу в городе Шебекино в Белгородской области, сообщил временно исполняющий обязанности главы региона Александр Шуваев.
  - (2026-07-20) Женская теннисная ассоциация обязала теннисисток подтверждать свой пол | LEDE: Женская теннисная ассоциация (WTA) обязала теннисисток подтверждать свой пол с помощью генетического теста для ] (ru: Жен…
      Женская теннисная ассоциация (WTA) обязала теннисисток подтверждать свой пол с помощью генетического теста для участия в турнирах под своей эгидой. Об этом, как сообщает BBC News, говорится в новой редакции правил.
  - (2026-07-20) Кир Стармер ушел с поста премьер-министра Великобритании. Правительство возглавил Энди Бернэм | LEDE: Кир Стармер официально подал в отставку с поста премьер-министра Великобритании. Король ] (ru: Кир…
      Кир Стармер официально подал в отставку с поста премьер-министра Великобритании. Король Карл III принял его отставку, сообщает The Guardian.
  - (2026-07-20) В России в 2025 году более двух тысяч человек осудили по террористическим статьям. Такого не было никогда | LEDE: Российские суды в 2025 году вынесли 1776 приговоров по террористическим стат] (ru: В Р…
      Российские суды в 2025 году вынесли 1776 приговоров по террористическим статьям (с 205 по 205.5 УК), подсчитали правозащитный проект «Первый отдел» и аналитики Parubets Analytics.
  - (2026-07-20) На Эльбрусе отец и его 11-летний сын сорвались со скалы на высоте 4200 метров. Ребенок погиб | LEDE: 11-летний ребенок из Ставропольского края погиб в ходе восхождения на Эльбрус вместе со с] (ru: На…
      11-летний ребенок из Ставропольского края погиб в ходе восхождения на Эльбрус вместе со своим 40-летним отцом. Об этом сообщает Следственное управление СК по Кабардино-Балкарии, начавшее доследственную проверку по факту…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 212 new of 260 total
  - (2026-07-19) 世界华语文学高地的隆起 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBHSjRwWmhseGN3ei1fTEdmdmdHY0l6Wlo5ZkZORWlGeXh5emhNTG9xRzc4SFJDcmgzT0U2SDBSbjBZZnNlaEp4S2ZRMndwUVA4RGJuOGp0MX] (zh:…
      世界华语文学高地的隆起 财新
  - (2026-07-19) 西班牙vs阿根廷：绿茵场下的200年经济分岔 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBjNURldUg3LVJZTnFCTjF2aGxTQjdVUkdQZU1KT240cmVZMHBpR3NyODZ5Z2g2X3dQU25yLXk3VjZIZHllN1VyLWJSSjFwRDV] (zh:…
      西班牙vs阿根廷：绿茵场下的200年经济分岔 财新
  - (2026-07-18) 显影｜让老人“家庭式养老” - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE8yUHBNaGVxeTFjM1ptN0hWbEdqeHFNU3hZXzdaVUhoOWFGdDZDVVJZSmt6bmNRaVg0TGxIUHM1OWJ1ZENSSDhtN2hydzJfbmVWZFpZLX] (zh:…
      显影｜让老人“家庭式养老” 财新周刊
  - (2026-07-20) 今日开盘：两市双双高开 沪指涨幅0.73% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5PMEtkeEF6V05XN1ZFZFBYNUZvcUJWOWJYYzdKd3poa1R5N0VvTzJrWTRUWnRUM29TajNKVnFHWlA1WVhjMzVFS19DWlFqWHB0] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.73% 财新
  - (2026-07-20) 科学家首次在宜居岩质行星发现大气层 距地球48光年 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFAwd0VhR1EtdjZiTVhCTEFYajJ0ZDYxeDFZdEk2NlVselgyMzA1YzdaczhlVE5FQWszVnFERUN3WjVqZUt2N0RESVZjNHAw] (zh:…
      科学家首次在宜居岩质行星发现大气层 距地球48光年 财新
  - (2026-07-20) 国家队重仓ETF上周资金净流入850亿元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9CVEtRNmp2RjJpU0hyV2VRWUdCRXE5aVVfbE1YMndqZHE1TGgzSWJtdERPUWFCSlVSZjUxeHg0ckFjdGliVTludGdnakQ3UW5mR] (zh:…
      国家队重仓ETF上周资金净流入850亿元 财新

### U.S. Weather + Severe / Climate Outlooks — 153 new of 161 total
  - (2026-07-20) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-20) [Severe] Red Flag Warning: Red Flag Warning issued July 20 at 8:04AM CDT until July 20 at 9:00PM CDT by NWS Aberdeen SD
      ...RED FLAG WARNING REMAINS IN EFFECT FROM 2 PM THIS AFTERNOON TO 8 PM MDT THIS EVENING DUE TO WIND AND LOW RELATIVE HUMIDITY FOR CORSON AND DEWEY... ...RED FLAG WARNING REMAINS IN EFFECT FROM 3 PM THIS AFTERNOON TO 9 PM…
  - (2026-07-20) [Severe] Red Flag Warning: Red Flag Warning issued July 20 at 8:04AM CDT until July 20 at 9:00PM CDT by NWS Aberdeen SD
      ...RED FLAG WARNING REMAINS IN EFFECT FROM 2 PM THIS AFTERNOON TO 8 PM MDT THIS EVENING DUE TO WIND AND LOW RELATIVE HUMIDITY FOR CORSON AND DEWEY... ...RED FLAG WARNING REMAINS IN EFFECT FROM 3 PM THIS AFTERNOON TO 9 PM…
  - (2026-07-20) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 20 at 8:00AM CDT until July 20 at 8:00PM CDT by NWS Sioux Falls SD
      * WHAT...Dangerously hot conditions with heat index values up to 107 expected. * WHERE...Portions of northwest and west central Iowa, northeast Nebraska, and southeast South Dakota. * WHEN...From 11 AM this morning to 8…
  - (2026-07-20) [Moderate] Heat Advisory: Heat Advisory issued July 20 at 8:00AM CDT until July 20 at 8:00PM CDT by NWS Sioux Falls SD
      * WHAT...Heat index values up to 104 expected. * WHERE...Portions of northwest Iowa and south central and southeast South Dakota. * WHEN...From 11 AM this morning to 8 PM CDT this evening. * IMPACTS...Hot temperatures an…
  - (2026-07-20) [Moderate] Heat Advisory: Heat Advisory issued July 20 at 8:00AM CDT until July 20 at 4:00PM CDT by NWS Sioux Falls SD
      * WHAT...Heat index values up to 103 expected. * WHERE...Portions of southwest Minnesota and southeast South Dakota. * WHEN...From 11 AM this morning to 4 PM CDT this afternoon. * IMPACTS...Hot temperatures and high humi…

### State-Level News — 127 new of 247 total
  - (2026-07-20) [California] Meet the maverick California lawmakers who buck their party
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526-Villegas-Valadao-split-CM-.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-20) [California] Most California lawmakers never buck their party. These few do
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/02/010625-First-Day-Session-FG-CM-22.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-20) [California] California reading scores are up, thanks to literacy investments. Can the state do more?
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/04/030725_Literacy_FM_CM_11.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="…
  - (2026-07-20) [California] California courts must address the racial bias in death penalty sentencing
      <img width="1024" height="679" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/02/020926-San-Quentin-JS-Getty-CM-01.jpg?fit=1024%2C679&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-20) [Alabama] Opinion | SAVE Act’s burden may fall on citizens, too
  - (2026-07-20) [Alabama] Doug Jones to host public town hall in Dothan this week

### Local News: St. Louis + Atlanta — 77 new of 186 total
  - (2026-07-20) [St. Louis] Photos: Cardinal Dolan returns to Holy Infant Church
      Parishioners attend Mass as Cardinal Timothy Dolan returns to his childhood parish, Holy Infant Church, to celebrate the 50th anniversary of his ordination to the priesthood on Sunday, July 19, 2026, in Ballwin.
  - (2026-07-20) [St. Louis] Red Sox 13th straight
      Caleb Durbin, left, and Willson Contreras celebrate after Sunday's game, which was the 13th consecutive victory for the Boston Red Sox.
  - (2026-07-20) [St. Louis] They harvest the nation’s food, but a new rule may strip them of health insurance
      Seasonal work. Inconsistent hours. Frequent moves. Cash payments and informal jobs. For farmworkers who rely on Medicaid, these common employment patterns could put their health coverage at risk.
  - (2026-07-20) [St. Louis] Boy, 13, shot when his dad gets in a gunfight with another driver in St. Louis
      The road rage shooting was before 11 p.m. Saturday near South Broadway and Walnut Street.
  - (2026-07-20) [St. Louis] The Culture Edit: July 27
      If you were a child in the 1960s you knew how game-changing “Batman,” the TV series, was.
  - (2026-07-20) [St. Louis] Cities that block ICE could lose police, rape kit funding, DOJ says
      The Trump administration is pressuring cities to sign cooperation agreements with Immigration and Customs Enforcement officials with the strongest tool at its disposal: money.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-21) Connecticut Supreme Court: Campelli v. Mansfield
  - (2026-07-21) Connecticut Supreme Court: Markatos v. Zoning Board of Appeals
  - (2026-07-17) U.S. Court of Appeals, 1st Cir.: Rhode Island Truck Ctr., LLC v. Daimler Trucks North America, LLC
  - (2026-07-17) U.S. Court of Appeals, 10th Cir.: Wilson v. Stoltenberg
  - (2026-07-17) U.S. Court of Appeals, 10th Cir.: Maccagnan v. Cherry Creek School District No. 5
  - (2026-07-17) Alaska Supreme Court: Cline v. Duckett

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-07-20) [Russia oil sanctions perimeter · keywords] Russian attacks kill 6 in Kyiv and other cities , expose gaps in Ukraine air defenses
      naharnet.com · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · keywords] Russian attacks kill 6 in Kyiv and other cities and expose gaps in Ukraine air defenses
      isp.netscape.com · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · keywords] Russia intensifies Black Sea attacks as fears mount over potential wider European conflict
      bankingnews.gr · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · keywords] Ukraine fires 400 drones toward Moscow as Zelenskyy grapples with protests
      idahostatejournal.com · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · keywords] Kazakhstan Warns Drone Attack on CPC Oil Tankers Risks Global Energy Security
      astanatimes.com · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · keywords] Ukraine fires 400 drones toward Moscow as Zelenskyy grapples with protests
      clickondetroit.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 42 new of 114 total
  - (2026-07-20) Теракт біля ТЦК у Кам’янці-Подільському: 2 виконавці отримали довічне ув'язнення та 15 років тюрми | LEDE: Суд дав довічне та 15 років агентам ФСБ за теракт біля ТЦК у Кам'янці-Подільському, де] (uk:…
      Суд дав довічне та 15 років агентам ФСБ за теракт біля ТЦК у Кам'янці-Подільському, де загинув кур'єр, ще 7 поранені.
  - (2026-07-20) Удар РФ по цивільному судну з кукурудзою: на берег доставили тіла 10 загиблих | LEDE: В ході пошуково-рятувальної операції виявлено тіла всіх 10 загиблих – лоцмана та членів екіпажу цивільного ] (uk:…
      В ході пошуково-рятувальної операції виявлено тіла всіх 10 загиблих – лоцмана та членів екіпажу цивільного торговельного судна, яке напередодні атакували ракетами росіяни неподалік Одеси.
  - (2026-07-20) В уряді Естонії поки не бачать причин закривати кордон з РФ, але готові до цього | LEDE: Ситуація на кордоні Естонії з Росією поки не дає підстав задумуватись про його закриття, проте за виникн] (uk:…
      Ситуація на кордоні Естонії з Росією поки не дає підстав задумуватись про його закриття, проте за виникнення таких обставин рішення може бути ухвалене дуже швидко.
  - (2026-07-20) СБС уразили кілька елементів російського ППО в Краснодарському краю | LEDE: Уночі 20 липня Сили БПЛА знищили 8 ППО РФ: 6 — у Краснодарському краї, 2 — у Запорізькій області.] (uk: СБС уразили кілька е…
      Уночі 20 липня Сили БПЛА знищили 8 ППО РФ: 6 — у Краснодарському краї, 2 — у Запорізькій області.
  - (2026-07-20) "Сирного рішення не буде": у столиці люди готують нові картонки | LEDE: У Києві небайдужі громадяни готуються до нової акції на підтримку ексміністра оборони Михайла Федорова та за звільнення з] (uk:…
      У Києві небайдужі громадяни готуються до нової акції на підтримку ексміністра оборони Михайла Федорова та за звільнення з посади головокома Олександра Сирського.
  - (2026-07-20) AliExpress отримала штраф у понад 500 млн євро за порушення правил ЄС | LEDE: Європейська комісія оштрафувала електронну торговельну платформу AliExpress на 550 млн євро за порушення вимог Зако] (uk:…
      Європейська комісія оштрафувала електронну торговельну платформу AliExpress на 550 млн євро за порушення вимог Закону про цифрові послуги.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-20) 424B4 - Agencia Comercial Spirits Ltd. (0002060016) (Filer)
      filed 2026-07-20 13:07 UTC — Filed: 2026-07-20 AccNo: 0001213900-26-079442 Size: 2 MB
  - (2026-07-20) 425 - Tempus AI, Inc. (0001717115) (Subject)
      filed 2026-07-20 13:05 UTC — Filed: 2026-07-20 AccNo: 0001193125-26-308472 Size: 64 KB
  - (2026-07-20) 497J - Voya INVESTORS TRUST (0000837276) (Filer)
      filed 2026-07-20 13:03 UTC — Filed: 2026-07-20 AccNo: 0000837276-26-000080 Size: 158 KB
  - (2026-07-20) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-07-20 12:57 UTC — Filed: 2026-07-20 AccNo: 0001918704-26-020490 Size: 594 KB
  - (2026-07-20) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-07-20 12:57 UTC — Filed: 2026-07-20 AccNo: 0001918704-26-020490 Size: 594 KB
  - (2026-07-20) [LEE SENG CHI] Form 4 (Reporting)
      filed 2026-07-20 12:52 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0001213900-26-079435 Size: 5 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### IT, InfoSys & cybersecurity news (last 7 days) — 30 new of 58 total
  - (2026-07-20) [BleepingComputer] Hugging Face warns an autonomous AI agent hacked its network
      The Hugging Face artificial intelligence repository disclosed that attackers gained access to internal datasets and credentials after breaching its production infrastructure using an autonomous AI agent system. [...]
  - (2026-07-20) [BleepingComputer] Microsoft confirms Windows Server Update Services sync delays
      Microsoft is working to fix a known issue affecting Windows Server Update Services (WSUS) servers, which has caused synchronization problems for more than a week. [...]
  - (2026-07-20) [BleepingComputer] Windows KB5121767 OOB update fixes shutdowns on some Dell PCs
      Microsoft has released emergency updates to fix a known issue causing some Dell PCs to shut down after installing the July 2026 Windows 11 security updates. [...]
  - (2026-07-20) [BleepingComputer] Critical ServiceNow code execution flaw now exploited in attacks
      Attackers have begun exploiting a critical vulnerability (CVE-2026-6875) in the ServiceNow AI Platform, according to threat intelligence company Defused. [...]
  - (2026-07-20) [The Hacker News] Russian Intelligence Hacks IP Cameras to Spy on Military Logistics Across NATO States and Ukraine
      At least one Russian intelligence service is systematically hijacking internet-connected security cameras across Europe and Ukraine, using the feeds to watch military transport routes, weapons shipments bound for Kyiv, a…
  - (2026-07-20) [The Hacker News] Mythos Didn't Break Your Security Program. Your Exposure Window Could.
      The industry spent the initial months after Anthropic's April 7 Mythos reveal focused on volume. How many new CVEs would Mythos add to an already overloaded pipeline? How quickly would the flood of AI-driven discovery ov…

### Paper Trading Scorecard — 15 new of 148 total
  - (2026-07-20) [Polymarket] Will the Pittsburgh Steelers win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-20) [Manifold] Will Opus 4.6 pay back his loan?
  - (2026-07-20) [Manifold] Will the USMV stay at or under Ṁ300 per share for 1 hour before Aug 2026?
  - (2026-07-20) [Manifold] Will Oleksandr Syrskyi still be Commander-in-Chief of the Armed Forces of Ukraine on August 1, 2026
  - (2026-07-20) [Manifold] Will Jonas Vingegaard start another race for Team Visma | Lease a Bike before 2028?*
  - (2026-07-20) [Manifold] If Judit Polgár becomes President of Hungary, will she play an in-person game of chess with a world leader this year?

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-07-20) LoL: Kiwoom DRX vs BNK FEARX (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $972,384 · resolves 2026-07-20
  - (2026-07-20) LoL: DN SOOPers vs HANJIN BRION (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $843,133 · resolves 2026-07-20
  - (2026-07-20) Will St. Louis Cardinals win the 2026 NL Central title?
      yes price: 1% · 24h volume: $825,180 · resolves 2026-10-11
  - (2026-07-20) LoL: DN SOOPers vs KT Rolster (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $812,589 · resolves 2026-07-20
  - (2026-07-20) LoL: Kiwoom DRX vs HANJIN BRION (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $643,455 · resolves 2026-07-20
  - (2026-07-20) Will the U.S. invade Iran before 2027?
      yes price: 22% · 24h volume: $624,693 · resolves 2026-12-31

### USGS earthquakes (M4.5+, past day) — 13 new of 18 total
  - (2026-07-20) M 5.6 - 208 km SW of Port McNeill, Canada
      M5.6 · 208 km SW of Port McNeill, Canada · depth 10 km
  - (2026-07-20) M 5.2 - 22 km NNW of Scarborough, Trinidad and Tobago
      M5.2 · 22 km NNW of Scarborough, Trinidad and Tobago · depth 83.51 km
  - (2026-07-20) M 5.2 - 27 km S of Javānrūd, Iran
      M5.2 · 27 km S of Javānrūd, Iran · depth 10 km
  - (2026-07-20) M 5.1 - 83 km W of Tobelo, Indonesia
      M5.1 · 83 km W of Tobelo, Indonesia · depth 69.965 km
  - (2026-07-20) M 4.9 - 48 km WSW of Brisas Barra de Suchiate, Mexico
      M4.9 · 48 km WSW of Brisas Barra de Suchiate, Mexico · depth 39.894 km
  - (2026-07-20) M 4.9 - 27 km S of Javānrūd, Iran
      M4.9 · 27 km S of Javānrūd, Iran · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 117 total
  - (2026-07-20) [USASpending] $4,813,063,025 → LEIDOS BIOMEDICAL RESEARCH INC: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
      Agency: Department of Health and Human Services. Description: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
  - (2026-07-20) [USASpending] $3,116,039,041 → LEIDOS, INC.: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STA
      Agency: National Science Foundation. Description: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STATES ANTARCTIC PROGRAM
  - (2026-07-20) [USASpending] $1,634,792,955 → NORTHROP GRUMMAN SYSTEMS CORPORATION: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUI
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUILDS UPON THE SUCCESS OF COMMERCIAL ORBITAL TRANSPORTATION SERVICES SPACE ACT AGREEMENT DEVELO…
  - (2026-07-20) [USASpending] $1,060,970,017 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-07-20) [USASpending] $697,707,307 → SALUS WORLDWIDE SOLUTIONS CORP.: SECTION 4(A). THE PURPOSE OF THIS REQUIREMENT IS TO OBTAIN C
      Agency: Department of Homeland Security. Description: SECTION 4(A). THE PURPOSE OF THIS REQUIREMENT IS TO OBTAIN COMPREHENSIVE SUPPORT TO REMOVAL OPERATIONS (CSRO) SUPPORT SERVICES FOR THE OFFICE FOR STRATEGY, POLICY, AN…
  - (2026-07-20) [USASpending] $652,980,558 → BOOZ ALLEN HAMILTON INC: CDM DEFEND GROUP BD BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP BD BRIDGE TASK ORDER

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 34 total
  - (2026-07-20) MOVER ▼ Bernard Arnault & family — $149.43B ($-1.16B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-20) MOVER ▼ Amancio Ortega — $136.46B ($-0.53B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-20) MOVER ▼ Francoise Bettencourt Meyers & family — $93.02B ($-0.24B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-07-20) MOVER ▲ Carlos Slim Helu & family — $125.21B (+$0.05B since yesterday)
      Mexico · Telecom · source: Telecom

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-20) [Marginal Revolution] Whit Stillman’s *Metropolitan* (that was then, this is now)
      It is fun to watch/rewatch this 1990 movie circa 2026. It is about New York City debutantes (CT and the Hamptons too), and how they interact with each other. The movie is set a bit earlier in time, perhaps in the mid-198…
  - (2026-07-20) [Marginal Revolution] Democrats are more politically segregated than are Republicans
      We estimate the extent of workplace political segregation in the United States by merging data covering over 45 million workers. We present four main findings. First, partisans are segregated by workplace. The average De…
  - (2026-07-20) [Marginal Revolution] Emergent Ventures winners, 56th cohort
      Audrey London, Los Angeles, to write a book on water in California. Seyi Oluwasanmi, London, to bring Brits to SF to learn tech. Thomas Haferlach, Berlin, payments and compute layer for the long tail of AI apps. Juan Ram…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### GDACS — global disaster alerts — 2 new of 165 total
  - (2026-07-20) [Green] Earthquake in Canada
      Earthquake · Green alert · Canada · Magnitude 5.6M, Depth:10km
  - (2026-07-20) [Green] Earthquake in Canada
      Earthquake · Green alert · Canada · Magnitude 5.6M, Depth:10km

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: marine, change, national, necessary, flight, published, coast, navigable, fisheries, prompted, guard, eliminating
- state_bills: today=0, 7d-median=124, 14d-median=124
- state_news: today=247, 7d-median=452, 14d-median=452; carrying terms: himself, customers, means, hospitals, exceptions, rejected, justice, haven, continues, cover, permalink, black
- local_news: today=186, 7d-median=226, 14d-median=226; carrying terms: storms, underway, center, health, clayton, fulton, tuesday, everything, reported, vehicle, srcset, decoding
- foreign_news: today=934, 7d-median=1028, 14d-median=1028; carrying terms: mobilized, travel, becoming, continues, operate, india, protests, spent, commercial, taking, cuban, focus
- chinese_internal: today=260, 7d-median=276, 14d-median=276; carrying terms: cbmiw, global, cbmibefvx, https, cbmixkfvx, blank, cbmia, google, title, cbmiaefvx, launch, target
- russian_internal: today=494, 7d-median=858, 14d-median=858; carrying terms: europe, client, apple, laquo, gazeta, error, insider, forbidden, bloomberg, https, novayagazeta, title
- ukrainian_internal: today=114, 7d-median=132, 14d-median=132; carrying terms: travel, commercial, black, serhiy, donald, center, targeted, drones, using, within, volodymyr, regions
- ukraine_theater: today=705, 7d-median=489, 14d-median=489; carrying terms: esmrowhi, uxsudorgvdbdlieekzrhczqvzvskw, rhdmmtbvow, ysdvhqwrrou, nkqlzzmmltvlfpqv, dvllluxkd, xvujfv, tzwfjbuxdvfvmmgg, flight, zlewhfcmlua, targeted, ntfzrmwv
- paper_bets: today=148, 7d-median=144, 14d-median=144; carrying terms: specified, payable, decrease, trump, humanoid, party, massa, reserves, brazilian, nomination, prime, india
- weather: today=161, 7d-median=163, 14d-median=163; carrying terms: increased, storms, level, continues, afdlsx, afdhgx, layer, monitoring, tropical, center, lower, coast
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dcoilwtico, openings, effective, commodities, inflation, pcepilfe, funds, crude, headline, money, dexuseu, implied
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: large, commodities, equities, natural, crypto, russell, rates, bitcoin, yield, range, corporate, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=117, 7d-median=116, 14d-median=116; carrying terms: xskfisuh, transactions, sponsoring, facilitate, somalia, nicaragua, protests, demonstration, industrial, libya, health, updates
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, error, httperror, https, quantitative, client, unauthorized, quiver, congresstrading
- billionaires: today=34, 7d-median=33, 14d-median=33; carrying terms: investments, walmart, microsoft, hathaway, tesla, euronext, ambani, arnault, tadashi, discount, india, diversified
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: management, court, rhode, district, delaware, company, family, school, energy, america, association, north
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, accno, reporting
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: graham, ossoff, committee, cycle, talarico, lindsey, david, shawn, congress, trone, chartered, raised
- gdelt_regions: today=12, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=50, 7d-median=48, 14d-median=48; carrying terms: english, chinese, russian, themes, ukraine, sanctions, russia, spanish, yahoo, dailykos, perimeter
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=17, 14d-median=17
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: andes, natural, contact, increased, toxin, poultry, burial, cambodia, clades, resulting, travel, rabies
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: vulnerability, injection, server, microsoft, sharepoint, product, forgery, cisco, request, improper, traversal, authentication
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=165, 7d-median=156, 14d-median=156; carrying terms: cambodia, russia, maximum, vietnam, somalia, nicaragua, earthquake, denmark, philippines, ukraine, tropical, orange
- usgs_quakes: today=18, 7d-median=17, 14d-median=17; carrying terms: depth, madero, chile, mexico, islands, puerto, south, kermadec, indonesia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, minister, volume, meeting, ethiopia, rates, interest, price, resolves, presidential, belete, demeke
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, https, marginal, conversable, revolution, economist, points, marginalrevolution, particular, paper, progress, pushback
- tech_news: today=58, 7d-median=58, 14d-median=58; carrying terms: software, ransomware, updates, researchers, company, using, million, bleepingcomputer, tuesday, calls, insider, reported
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: tenney, mcguire, boozman, crawford, ciscomani, westerman, huizenga, harshbarger, menefee, analilia, justice, mejia
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, module, sufficient, decision, markets, paper, either, today, unavailable, identify, evidence, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*