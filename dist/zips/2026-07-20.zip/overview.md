# WORLDSCOPE morning brief — 2026-07-20

## Headline
3975 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (756) · Ukraine Theater (total-war monitoring) (741) · Russian Internal News (state + in-exile) (706) · State-Level News (382) · World leaders & government officials (324) · Chinese Internal News (232) · U.S. Weather + Severe / Climate Outlooks (183) · Local News: St. Louis + Atlanta (174) · Court opinions of consequence (federal & state) (60) · State Legislative Action (59) · Ukrainian Internal News (national + local Kyiv) (56) · GDELT GKG — themes / entities / watch areas (45)

## What changed today
### International News + Multilateral Institutions — 756 new of 1019 total
  - (2026-07-20) [Global] 'I made £100,000 of TikTok sales in one day': The business of live shopping
      Buying on social media live streams is fast becoming regular consumer behaviour for many.
  - (2026-07-20) [Global] John Healey becomes chancellor weeks after shock resignation from defence job
      The former defence secretary is seen as a safe pair of hands - and is now in charge of the government's finances.
  - (2026-07-20) [Global] Burnham has big ideas - but what will they cost?
      Every tricky decision and trade off is being watched by the country and the markets at the same time
  - (2026-07-20) [Global] Burnham promises help with your money. How could it affect you?
      The new PM says he will look at how much people can earn before paying tax but admitted changing it would be difficult.
  - (2026-07-20) [Global] The 20-somethings betting big on tech stocks
      The BBC hears from people about the risks and rewards of investing in technology shares.
  - (2026-07-20) [Global] Craft and keyboard: The trainees mastering tech and age-old skills
      Firms have to balance hi-tech and age-old skills when training up young workers.

### Ukraine Theater (total-war monitoring) — 741 new of 907 total
  - (2026-07-20) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-19) [FIRMS] thermal anomaly 52.806, 32.227 (FRP 1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.366, 33.311 (FRP 1.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1.87 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.848, 29.990 (FRP 1.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 1.89 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.133, 34.070 (FRP 0.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 0.72 MW
  - (2026-07-19) [FIRMS] thermal anomaly 52.297, 32.806 (FRP 2.5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-19 0020Z, FRP 2.5 MW

### Russian Internal News (state + in-exile) — 706 new of 878 total
  - (2026-07-20) Склад Wildberries в Котовске, пострадавший от удара ВСУ, возобновит работу | LEDE: 23 июля маркетплейс Wildberries возобновит работу своего склада в городе Котовске Тамбовской области, в ноч] (ru: Скл…
      23 июля маркетплейс Wildberries возобновит работу своего склада в городе Котовске Тамбовской области, в ночь на 18 июля подвергшегося атаке украинских дронов.
  - (2026-07-20) «Пепел»: плотина Белгородского водохранилища получила повреждения, Шебекино начало подтапливать | LEDE: Плотина Белгородского водохранилища получила повреждения, вероятно, в результате украи] (ru: «Пе…
      Плотина Белгородского водохранилища получила повреждения, вероятно, в результате украинских ударов 19 июля, пишет белгородское издание «Пепел» со ссылкой на анонимные источники и спутниковые снимки.
  - (2026-07-20) Bloomberg cообщил об 11 кандидатах на пост главкома ВСУ. Основной — командующий Объединенными силами Михаил Драпатый | LEDE: Владимир Зеленский начал изучать кандидатуры тех, кто может замен] (ru: Blo…
      Владимир Зеленский начал изучать кандидатуры тех, кто может заменить Александра Сырского по посту главнокомандующего ВСУ. В списке кандидатов 11 человек. Основным из них считается командующий Объединенными силами ВСУ Мих…
  - (2026-07-20) Продавцы Wildberries пожаловались, что не могут забрать товар со складов компании после атаки ВСУ | LEDE: Продавцы маркетплейса Wildberries, который в минувшие выходные подвергся атаке ВСУ, ] (ru: Про…
      Продавцы маркетплейса Wildberries, который в минувшие выходные подвергся атаке ВСУ, не могут вывезти товары со складов компании. Об этом «Верстке» рассказали трое предпринимателей, еще больше 10 подобных жалоб издание об…
  - (2026-07-20) «Я не знал, что у нас конфликт. Извините, если обидел» . Главком ВСУ Сырский написал колонку о разногласиях с экс-министром обороны Федоровым. Краткий пересказ | LEDE: Я занимаюсь войной. Да] (ru: «Я…
      Я занимаюсь войной. Давать интервью и писать колонки мне неинтересно. Но мое молчание стали трактовать как согласие, поэтому я решил высказаться. Говорят, у меня нет стратегии победы — но объявить о стратегии публично зн…
  - (2026-07-20) У некоторых жителей России перестал работать App Store. Роскомнадзор блокировку отрицает. Так власти могут мстить Apple за удаление сервисов VK | LEDE: Пользователи в России стали жаловаться] (ru: У н…
      Пользователи в России стали жаловаться на работу магазина приложений App Store. Доступность сервиса снизилась еще 16 июля и на текущий момент держится в районе 50%. Представители Роскомнадзора заявили, что не блокируют A…

### State-Level News — 382 new of 466 total
  - (2026-07-20) [California] Governor Newsom signs executive order strengthening statewide sex trafficking prevention and response
      Source
  - (2026-07-20) [California] Governor, First Partner statement on the passing of Clint Reilly
      Source
  - (2026-07-20) [California] Governor Newsom announces continued growth in California ZEV sales as Trump’s reckless Iran war raises prices on Americans nationwide
      Source
  - (2026-07-20) [California] La mayoría de los legisladores de California nunca se oponen a su partido. Estos pocos sí
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/02/010625-First-Day-Session-FG-CM-22.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-20) [California] Resultados de las pruebas de lectura en California han mejorado gracias a las inversiones en alfabetización. ¿Puede el estado hacer más?
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/04/030725_Literacy_FM_CM_11.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="…
  - (2026-07-20) [California] Gavin Newsom’s return-to-office rules are stricter than many states, including Texas
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526-RTO-State-Workers-MG-02-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 232 new of 270 total
  - (2026-07-20) China-Brazil Trade Hits Record High on EV Surge and Shifting Oil Flows - Caixin Global
      China-Brazil Trade Hits Record High on EV Surge and Shifting Oil Flows Caixin Global
  - (2026-07-20) Chinese Companies Need a New Cloud Playbook for AI Abroad - Caixin Global
      Chinese Companies Need a New Cloud Playbook for AI Abroad Caixin Global
  - (2026-07-20) 进展动态 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE4wbjVpSG9KdWZtZjFnUXpPWTBnUF9yMndpeHVhV2UtNEc4Y1A1VGZhSjNoTWprNnZXeXVBd2JFa3JuNDAzVERBWWRGbWhfU25nY1FvTTRLbU9] (zh:…
      进展动态 中国共产党新闻网
  - (2026-07-19) 国别频道 - 人民网黑龙江频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE14cVFqWkJ6dm9JekZQRlpKcEtyOVRsY1VDVEh1VkszUjFnU3RNQjVFWVNUQTQwWm1QS3g0czBjYk1tdmdNUHdqakFyV1NuZi1iWWFYWXcyWlp] (zh:…
      国别频道 人民网黑龙江频道
  - (2026-07-20) 第三十五届“哈洽会”数字经济展区亮点纷呈 - 人民网黑龙江频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE9GTGwwdENfQmx6YUYwYlBGOXFlZXQ1RXJoRG5NODN4NGVFUTVUbVpoYmx0dExVYUJJWnNUQzhjc1c5a0lXYzEtY3JIVmZ] (zh:…
      第三十五届“哈洽会”数字经济展区亮点纷呈 人民网黑龙江频道
  - (2026-07-20) 中央网信办开展“清朗·未成年人网络保护”专项行动 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTE1DdHJGS0I2Y3NKVHEyaFEwbjhrYkhGczFzTE8wQzZFNlVReklIbDRieEF3ZDlZUzFabDZ0cXRTV] (zh:…
      中央网信办开展“清朗·未成年人网络保护”专项行动 politics.people.com.cn

### U.S. Weather + Severe / Climate Outlooks — 183 new of 186 total
  - (2026-07-20) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-20) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 20 at 6:45PM CDT until July 20 at 7:15PM CDT by NWS Quad Cities IA IL
      At 645 PM CDT, a severe thunderstorm was located over Talleyrand, or 12 miles east of Sigourney, moving southeast at 30 mph. HAZARD...60 mph wind gusts and half dollar size hail. SOURCE...Radar indicated. IMPACT...Hail d…
  - (2026-07-20) [Moderate] Special Weather Statement: Special Weather Statement issued July 20 at 5:43PM MDT by NWS Grand Junction CO
      At 542 PM MDT, Doppler radar was tracking a strong thunderstorm near Glenwood Springs, moving southwest at 15 mph. HAZARD...Half inch hail. SOURCE...Radar indicated. IMPACT...Minor hail damage to vegetation is possible.…
  - (2026-07-20) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 20 at 7:43PM EDT until July 20 at 8:45PM EDT by NWS Raleigh NC
      SVRRAH The National Weather Service in Raleigh has issued a * Severe Thunderstorm Warning for... Orange County in central North Carolina... Durham County in central North Carolina... * Until 845 PM EDT. * At 743 PM EDT,…
  - (2026-07-20) [Extreme] Tornado Warning: Tornado Warning issued July 20 at 7:43PM EDT until July 20 at 8:15PM EDT by NWS Marquette MI
      At 743 PM EDT/643 PM CDT/, a severe thunderstorm capable of producing a tornado was located 8 miles southeast of Powers, or 20 miles southwest of Escanaba, moving southeast at 25 mph. HAZARD...Tornado and baseball size h…
  - (2026-07-20) [Severe] Special Marine Warning: Special Marine Warning issued July 20 at 6:42PM CDT until July 20 at 7:45PM CDT by NWS New Orleans LA
      SMWLIX The National Weather Service in New Orleans has issued a * Special Marine Warning for... Coastal Waters from Port Fourchon LA to Lower Atchafalaya River LA out 20 nm... Coastal waters from Port Fourchon Louisiana…

### Local News: St. Louis + Atlanta — 174 new of 203 total
  - (2026-07-20) [St. Louis] 'Every day is a battle': Former 'Real Housewives of Orange County' star diagnosed with tongue cancer
      Former "Real Housewives of Orange County" star Jeana Keough, 70, is battling tongue cancer, her children announced.
  - (2026-07-20) [St. Louis] 5 dead in attempt to save a struggling swimmer in an Ohio river, sheriff says
      A driver called 911 after spotting a frightened child who had been with the group and was running on a nearby road, the sheriff said.
  - (2026-07-20) [St. Louis] Ex-soldier started a fire and fired pellet gun outside New York federal building, FBI says
      ​According to the FBI, the man set off fireworks outside a federal building that includes a U.S. Immigration and Customs Enforcement field office.
  - (2026-07-20) [St. Louis] FDA: Cyclospora outbreak data still points to Taylor Farms lettuce after false positive sample
      In a response posted to social media, Taylor Farms said the "FDA apologized to us." Now, the FDA has released its own statement about the false positive sample.
  - (2026-07-20) [St. Louis] Trump imposes 50% tariffs on Canadian goods, citing disputes over autos, alcohol and cheese
      The new tariffs would include goods that had been protected by the recently expired United States-Mexico-Canada Agreement.
  - (2026-07-20) [St. Louis] Ford recalls 387,000 vehicles as second-row seat may move unexpectedly
      Certain Lincoln Aviator and Ford Explorer models are under recall due to a defect with the second-row seat.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-21) Connecticut Supreme Court: Campelli v. Mansfield
  - (2026-07-21) Connecticut Supreme Court: Markatos v. Zoning Board of Appeals
  - (2026-07-20) U.S. Court of Appeals, 3rd Cir.: Cheryl Hileman v. West Penn Allegheny Health System Inc
  - (2026-07-20) U.S. Court of Appeals, 3rd Cir.: Savannah Byers v. Finishing Systems Inc
  - (2026-07-20) U.S. Court of Appeals, 10th Cir.: United States v. Smith
  - (2026-07-20) U.S. Court of Appeals, 10th Cir.: Ward v. National Credit Systems

### State Legislative Action — 59 new of 75 total
  - (2026-07-20) [Alabama HB 225] Education; notice requirement for certain board of education personnel vacancies revised
      Education
  - (2026-07-20) [Alabama SB 62] Alabama Charter School Finance Authority, bonding authority established, legislative findings, board membership, powers, contracts, investments
      Education
  - (2026-07-20) [Alabama HB 151] University of Alabama; Physicians Advisory Board of the University of Alabama School of Medicine repealed
      Health
  - (2026-07-20) [Alabama HB 487] Appropriations, supplemental appropriations from the Opioid Treatment and Abatement Fund for the fiscal year ending September 30, 2026
      Appropriations
  - (2026-07-20) [Alabama HB 362] National Guard; duties of Legal Services Office positions revised and further provide for
      Military
  - (2026-07-20) [Alabama SB 272] Open Records; use of public records relating to schools for certain solicitation purposes prohibited; redaction of certain information relating to financial transactions required
      Government Administration

### Ukrainian Internal News (national + local Kyiv) — 56 new of 125 total
  - (2026-07-21) США запровадили 50% мита на імпорт з Канади | LEDE: США підвищили мита до 50% на низку канадських товарів у відповідь на дискримінацію продукції з США.] (uk: США запровадили 50% мита на імпорт з Канад…
      США підвищили мита до 50% на низку канадських товарів у відповідь на дискримінацію продукції з США.
  - (2026-07-21) Армія РФ вдарила ракетами касетного типу по будинках на Харківщині | LEDE: Окупанти обстріляли Шевченкове на Харківщині касетними ракетами: є загиблий, 8 поранених, пошкоджено будинки.] (uk: Армія РФ…
      Окупанти обстріляли Шевченкове на Харківщині касетними ракетами: є загиблий, 8 поранених, пошкоджено будинки.
  - (2026-07-21) До України приїхала блогерка з оточення Трампа Лора Лумер | LEDE: Блогерка Лора Лумер відвідала Україну, щоб особисто перевірити факти російської пропаганди й поділитися побаченим.] (uk: До України пр…
      Блогерка Лора Лумер відвідала Україну, щоб особисто перевірити факти російської пропаганди й поділитися побаченим.
  - (2026-07-21) США завдають нових ударів по Ірану | LEDE: CENTCOM повідомило про нову серію ударів США по Ірану у відповідь на атаки та тиск щодо безпеки в Ормузькій протоці.] (uk: США завдають нових ударів по Ірану…
      CENTCOM повідомило про нову серію ударів США по Ірану у відповідь на атаки та тиск щодо безпеки в Ормузькій протоці.
  - (2026-07-20) На фронті від початку доби відбулося 186 бойових зіткнень – Генштаб | LEDE: Від початку доби 20 липня на фронті відбулось 186 бойових зіткнень.] (uk: На фронті від початку доби відбулося 186 бойових з…
      Від початку доби 20 липня на фронті відбулось 186 бойових зіткнень.
  - (2026-07-20) РФ атакує Суми: виникла масштабна пожежа в ТРЦ, пошкоджена багатоповерхівка, постраждали діти | LEDE: Російська армія увечері 20 липня атакувала в Сумах багатоповерхівку та ТРЦ: постраждали дво] (uk:…
      Російська армія увечері 20 липня атакувала в Сумах багатоповерхівку та ТРЦ: постраждали двоє дорослих і четверо дітей.

### GDELT GKG — themes / entities / watch areas — 45 new of 45 total
  - (2026-07-20) [Russia oil sanctions perimeter · themes] 17 U . S . service members have died in the Iran war so far
      latimes.com · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Det varme havvand i Østersøen og kold luft i højden skaber gode betingelser for det spektakulære vejrfænomen i juli og august : Højsæson for skypumper over Bo…
      bornholm.nu · Danish · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Anand says Canada trade - first diplomatic push is reviving old ties around the world
      thepeterboroughexaminer.com · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Boat ramp on Lake Hartwell closed due to low water levels
      wyff4.com · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Five People Killed While Trying To Save Struggling Swimmer
      rock1017fm.iheart.com · English · tone NA
  - (2026-07-20) [Russia oil sanctions perimeter · themes] Five People Killed While Trying To Save Struggling Swimmer
      1059therock.iheart.com · English · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 52 total
  - (2026-07-20) [BleepingComputer] Estée Lauder discloses data breach via Oracle E-Business flaw
      Cosmetics giant Estée Lauder is notifying customers of a data breach after hackers exploited a flaw in Oracle E-Business Suite that the company used for human resources (HR) operations. [...]
  - (2026-07-20) [BleepingComputer] SonicWall SMA1000 flaws exploited as zero-days to push custom malware
      Two recently disclosed SonicWall SMA1000 vulnerabilities were exploited in zero-day attacks for weeks, allowing threat actors to install custom malware on vulnerable VPN appliances. [...]
  - (2026-07-20) [BleepingComputer] Hackers steal $23.7 million in crypto from Ostium in off-chain attack
      The Ostium trading platform announced that an attacker stole $23.75 million from its liquidity provider vault last week, after compromising off-chain infrastructure used to feed prices into the protocol. [...]
  - (2026-07-20) [BleepingComputer] Cursor, Codex, Gemini CLI, Antigravity hit by sandbox escapes
      Researchers escaped the sandboxes in Cursor, Codex, Gemini CLI and Antigravity by having the AI agent write files that trusted host tools later run. Multiple CVEs, patches, and Google downgrading two Antigravity findings…
  - (2026-07-20) [BleepingComputer] JadePuffer agentic attacks now target AI model data with ransomware
      The JadePuffer autonomous AI agent has upgraded with custom malware called EncForge that focuses on encrypting AI assets, such as training datasets, vector databases, and model checkpoints. [...]
  - (2026-07-20) [The Hacker News] FakeGit Campaign Uses 7,600 GitHub Repositories to Spread SmartLoader Malware
      Cybersecurity researchers have discovered nearly 7,600 malicious GitHub repositories, out of which more than 800 pose as artificial intelligence (AI) skills or Model Context Protocol (MCP) servers to deliver a malware fa…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-20) [Johnson Nancy JoAnn] Form 4 (Reporting)
      filed 2026-07-20 23:38 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0002070849-26-000044 Size: 10 KB
  - (2026-07-20) [BillionToOne, Inc.] Form 4 (Issuer)
      filed 2026-07-20 23:38 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0002070849-26-000044 Size: 10 KB
  - (2026-07-20) [Schaffer Shane J.] Form 4 (Reporting)
      filed 2026-07-20 23:37 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0001493152-26-033972 Size: 8 KB
  - (2026-07-20) [Cingulate Inc.] Form 4 (Issuer)
      filed 2026-07-20 23:37 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0001493152-26-033972 Size: 8 KB
  - (2026-07-20) [Downey Bryan Wade] Form 4 (Reporting)
      filed 2026-07-20 23:35 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0001493152-26-033970 Size: 8 KB
  - (2026-07-20) [Cingulate Inc.] Form 4 (Issuer)
      filed 2026-07-20 23:35 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0001493152-26-033970 Size: 8 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-20) [South Korea] Lee Dong Wook promises blockbuster return of A Shop for Killer during season 2 premiere press conference
      domain: allkpop.com · language: English · tone:
  - (2026-07-20) [United States] Emmy - winning film features USU research below Greenland ice
      domain: upr.org · language: English · tone:
  - (2026-07-20) [Australia] School closed after teen allegedly sets office ablaze
      domain: theleader.com.au · language: English · tone:
  - (2026-07-20) [Canada] 3249 136 STREET , Surrey $2 , 080 , 000
      domain: bchomez.com · language: English · tone:
  - (2026-07-20) [Singapore] Who is accountable when an AI agent decides ?
      domain: businesstimes.com.sg · language: English · tone:
  - (2026-07-20) [United States] Five People Killed While Trying To Save Struggling Swimmer
      domain: sunny1063online.iheart.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 20 new of 139 total
  - (2026-07-20) [Polymarket] Will the Pittsburgh Steelers win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-20) [Polymarket] Will the Texas Rangers win the 2026 World Series?
      This market will resolve according to the team that wins the 2026 MLB World Series. If at any point it becomes impossible for a listed team to win the 2026 MLB World Series per the rules of MLB (e.g., they are eliminated…
  - (2026-07-20) [Kalshi] Which G7 leader will leave office next?
      G7 Leaders
  - (2026-07-20) [Manifold] Will Judit Polgár become the next President of Hungary?
  - (2026-07-20) [Manifold] Will Andy Burnham's No 10 North be in place by the end of 2026?
  - (2026-07-20) [Manifold] US government nationalizes OpenAI or Anthropic before 2029?

### USGS earthquakes (M4.5+, past day) — 20 new of 20 total
  - (2026-07-20) M 5.6 - northern Mid-Atlantic Ridge
      M5.6 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-07-20) M 5.6 - 208 km SW of Port McNeill, Canada
      M5.6 · 208 km SW of Port McNeill, Canada · depth 10 km
  - (2026-07-20) M 5.5 - Pacific-Antarctic Ridge
      M5.5 · Pacific-Antarctic Ridge · depth 10 km
  - (2026-07-20) M 5.2 - 22 km NNW of Scarborough, Trinidad and Tobago
      M5.2 · 22 km NNW of Scarborough, Trinidad and Tobago · depth 83.51 km
  - (2026-07-20) M 5.2 - 27 km S of Javānrūd, Iran
      M5.2 · 27 km S of Javānrūd, Iran · depth 10 km
  - (2026-07-20) M 5.1 - 83 km W of Tobelo, Indonesia
      M5.1 · 83 km W of Tobelo, Indonesia · depth 69.965 km

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-07-20) Will the Fed decrease interest rates by 25 bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $1,097,998 · resolves 2026-07-29
  - (2026-07-20) Will the U.S. invade Iran before 2027?
      yes price: 26% · 24h volume: $768,458 · resolves 2026-12-31
  - (2026-07-20) San Diego Padres vs. Atlanta Braves
      yes price: 42% · 24h volume: $742,567 · resolves 2026-07-27
  - (2026-07-20) Will the Fed increase interest rates by 25 bps after the July 2026 meeting?
      yes price: 7% · 24h volume: $682,680 · resolves 2026-07-29
  - (2026-07-20) Minnesota Twins vs. Cleveland Guardians
      yes price: 4% · 24h volume: $666,382 · resolves 2026-07-27
  - (2026-07-20) Pittsburgh Pirates vs. New York Yankees
      yes price: 32% · 24h volume: $664,357 · resolves 2026-07-27

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-20) [China] Turning green into gold
      europe.chinadaily.com.cn · English
  - (2026-07-20) [China] Economy resilient , stronger momentum ahead
      europe.chinadaily.com.cn · English
  - (2026-07-20) [China] I will claim Social Security early . Why do so few people talk about the elephant in the room ?
      morningstar.com · English
  - (2026-07-20) [China] RTX Unit Gets $1 . 8 Billion Modification to Navy Contract
      morningstar.com · English
  - (2026-07-20) [China] How a Top Fidelity Dividend Fund Manager Is Navigating the Tech Stock Wave
      morningstar.com · English
  - (2026-07-20) [China] Why cheap Chinese AI models could actually be a boon for Nvidia , Micron and other chip stocks
      morningstar.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 121 total
  - (2026-07-17) [OFAC] Hong Kong-Related Sanctions - Office of Foreign Assets Control (.gov)
      Hong Kong-Related Sanctions Office of Foreign Assets Control (.gov)
  - (2026-07-20) [OFAC] Russia-related Designations Updates - Office of Foreign Assets Control (.gov)
      Russia-related Designations Updates Office of Foreign Assets Control (.gov)
  - (2026-07-20) [USASpending] $4,813,063,025 → LEIDOS BIOMEDICAL RESEARCH INC: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
      Agency: Department of Health and Human Services. Description: TAS::75 0849::TAS OPER OF GOVT R&D GOCO FACILITIES
  - (2026-07-20) [USASpending] $3,116,039,041 → LEIDOS, INC.: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STA
      Agency: National Science Foundation. Description: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STATES ANTARCTIC PROGRAM
  - (2026-07-20) [USASpending] $1,634,792,955 → NORTHROP GRUMMAN SYSTEMS CORPORATION: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUI
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUILDS UPON THE SUCCESS OF COMMERCIAL ORBITAL TRANSPORTATION SERVICES SPACE ACT AGREEMENT DEVELO…
  - (2026-07-20) [USASpending] $1,060,970,017 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-07-20) MOVER ▼ Elon Musk — $771.95B ($-25.64B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-07-20) MOVER ▼ Larry Ellison — $161.07B ($-5.98B since yesterday)
      United States · Technology · source: Oracle
  - (2026-07-20) MOVER ▲ Larry Page — $288.42B (+$4.09B since yesterday)
      United States · Technology · source: Google
  - (2026-07-20) MOVER ▲ Sergey Brin — $266.05B (+$3.76B since yesterday)
      United States · Technology · source: Google
  - (2026-07-20) MOVER ▼ Michael Dell — $220.27B ($-2.90B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-07-20) MOVER ▲ Jeff Bezos — $259.02B (+$2.43B since yesterday)
      United States · Technology · source: Amazon

### Government & military aircraft airborne (OpenSky) — 9 new of 9 total
  - (2026-07-20) KOR151 (Democratic People's Republic of Korea)
      icao24: 7277a8 · position: (39.8893, 124.9429) · alt: 6751m · 630km/h
  - (2026-07-20) CFC3866 (Canada)
      icao24: c2b571 · position: (35.1015, -78.4516) · alt: 5410m · 405km/h
  - (2026-07-20) JAF1PB (Belgium)
      icao24: 44d1a6 · position: (37.8659, -3.3928) · alt: 10972m · 843km/h
  - (2026-07-20) RCH690 (United States)
      icao24: ae0816 · position: (49.9484, 6.8385) · alt: 3063m · 690km/h
  - (2026-07-20) PAT22 (United States)
      icao24: ae5b3f · position: (38.6819, -77.2302) · alt: 350m · 196km/h
  - (2026-07-20) RCH305 (United States)
      icao24: ae1172 · position: (54.7219, -1.3851) · alt: 9753m · 819km/h

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-07-20) [Marginal Revolution] Words of wisdom on Chinese AI and our responses
      The strategy for China is obvious: commoditize your complements. Note that Xi explicitly ties openness to AI “moving from the digital world into the physical world”; the physical world is the world dominated by China, an…
  - (2026-07-20) [Marginal Revolution] Monday assorted links
      1. “In all three countries, declining places displayed higher animosity prior to salient populist campaigns.” In their tweets. 2. Sunstein on Hayek and conservatism. 3. Jacobian conjecture proved false. Fable found a cou…
  - (2026-07-20) [Marginal Revolution] Whit Stillman’s *Metropolitan* (that was then, this is now)
      It is fun to watch/rewatch this 1990 movie circa 2026. It is about New York City debutantes (CT and the Hamptons too), and how they interact with each other. The movie is set a bit earlier in time, perhaps in the mid-198…
  - (2026-07-20) [Conversable Economist] Interview with Christiane Baumeister: Oil Price Shocks
      Tim Sablik acts as interlocutor in “Interview with Christiane Baumeister,” subtitled “On measuring the effects of oil shocks, changes in global energy markets, and forecasting tail risks” (Econ Focus: Federal Reserve Ban…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=20, 14d-median=20; carrying terms: based, eliminating, existing, limited, public, adopting, issuing, safety, amending, amended, aircraft, published
- state_bills: today=75, 7d-median=100, 14d-median=100
- state_news: today=466, 7d-median=462, 14d-median=462; carrying terms: texas, sought, training, details, thumbnail, traffic, confirmed, legislators, mississippi, green, campaign, redirects
- local_news: today=203, 7d-median=226, 14d-median=226; carrying terms: traffic, another, access, begins, events, sentenced, three, friday, vehicle, sheriff, fulton, arrest
- foreign_news: today=1019, 7d-median=1028, 14d-median=1028; carrying terms: closed, burnham, texas, investigate, thumbnail, electoral, traffic, islands, batch, campaign, tinubu, access
- chinese_internal: today=270, 7d-median=276, 14d-median=276; carrying terms: cbmicefvx, cbmiw, title, politics, blank, cbmibefvx, cbmiaefvx, color, global, cbmiy, people, cbmiakfvx
- russian_internal: today=878, 7d-median=880, 14d-median=880; carrying terms: europe, client, apple, reuters, title, gazeta, media, russian, novayagazeta, telegram, times, bloomberg
- ukrainian_internal: today=125, 7d-median=132, 14d-median=132; carrying terms: training, position, another, analysis, censor, confirmed, campaign, service, troop, ukrainian, efforts, continue
- ukraine_theater: today=907, 7d-median=489, 14d-median=489; carrying terms: cbmifkfvx, ddaln, zfdexgulhnmg, ogdglwq, wkqtyk, training, nddfrhzwtqdjvom, cuxqm, cbmicefvx, xuzyycc, iltvcuev, dumkwnfu
- paper_bets: today=139, 7d-median=141, 14d-median=141; carrying terms: visit, refers, wisconsin, nomination, texas, senate, fuentes, matthew, creation, magnitude, african, anthropic
- weather: today=186, 7d-median=166, 14d-median=166; carrying terms: afdmfl, details, message, remains, magnitude, islands, green, idaho, service, impacts, cities, continue
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: nonfarm, dexchus, dcoilwtico, personal, dexjpus, jtsjol, inflation, growth, unrate, payems, commodities, crude
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, futures, crypto, close, natural, range, large, commodities, proxy, nasdaq, crude, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=121, 7d-median=116, 14d-median=116; carrying terms: management, rights, based, respect, nvldzutsrkrhcnlpcfd, zimbabwe, guatemala, recognition, station, assets, middle, adopted
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quantitative, https, unauthorized, quiver, error, httperror, quiverquant, congresstrading
- billionaires: today=40, 7d-median=33, 14d-median=33; carrying terms: walmart, arnault, devasini, canada, ellison, amazon, semiconductors, jensen, trading, masayoshi, thomas, retail
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: north, truck, community, district, limited, island, association, court, trucks, delaware, holdings, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, thomas, amended, michael, jennifer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ossoff, raised, angels, talarico, congress, brown, senate, trone, warner, krishnamoorthi, ocasio, house
- gdelt_regions: today=12, 7d-median=9, 14d-median=9; carrying terms: english
- gdelt_gkg: today=45, 7d-median=46, 14d-median=46; carrying terms: english, chinese, russian, israel, hezbollah, trump, spanish, sanctions, russia, arabic, perimeter, themes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: australia, killed, kingdom, english, domain, trump, house, crash, language
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=9, 7d-median=9, 14d-median=9
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: uganda, eight, accordance, hantavirus, summarizes, regio, circulation, virus, circulating, discharged, additi, mechanical
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: cisco, product, vendor, improper, untrusted, server, vulnerability, bypass, sharepoint, remediation, microsoft, traversal
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=165, 7d-median=156, 14d-median=156; carrying terms: brazil, philippines, ukraine, kenya, thailand, nicaragua, belarus, medium, germany, magnitude, colombia, cyclone
- usgs_quakes: today=20, 7d-median=18, 14d-median=18; carrying terms: depth, ridge, islands, indonesia, madero, puerto, south, mexico, kermadec, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: prime, rates, volume, resolves, ethiopia, interest, price, meeting, minister, increase, angeles, demeke
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, revolution, marginal, conversable, https, economist, marginalrevolution, assorted, links, particular, often, order
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: based, bleepingcomputer, encryption, computer, activity, edition, service, public, hacker, newsletter, online, known
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: mcmahon, scalise, gottheimer, marco, addison, steil, fleischmann, nadler, laurel, barry, frank, philadelphia
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, claude, consensus, decision, markets, converges, unavailable, market, either, identify, evidence, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*