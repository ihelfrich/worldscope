# WORLDSCOPE morning brief — 2026-11-11

## Headline
3547 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (800) · Russian Internal News (state + in-exile) (669) · State-Level News (431) · World leaders & government officials (324) · Chinese Internal News (245) · Local News: St. Louis + Atlanta (225) · State Legislative Action (171) · U.S. Weather + Severe / Climate Outlooks (133) · Ukraine Theater (total-war monitoring) (88) · Ukrainian Internal News (national + local Kyiv) (76) · Court opinions of consequence (federal & state) (60) · GDACS — global disaster alerts (56)

## What changed today
### International News + Multilateral Institutions — 800 new of 1008 total
  - (2026-11-10) [Global] Lewis Hamilton visits Egypt’s Rafah crossing and Gaza aid facilities
  - (2026-11-11) [Global] Killing of journalist underscores deteriorating conditions in Ecuador
  - (2026-11-10) [Global] Falkland Islanders face ‘devastating consequences’ if Argentina blocks oil project, says UK
  - (2026-11-11) [Global] Ukraine captures first Indonesian prisoner of war amid surge in Russian recruitment
  - (2026-11-11) [Global] First Covid lockdowns, then alcohol to your door: rise in young Victorians with liver diseases prompts fears
  - (2026-11-11) [Global] ‘We were quite surprised’: Finland’s embassy goes viral with staff training day post on Instagram

### Russian Internal News (state + in-exile) — 669 new of 1104 total
  - (2026-11-11) «Что-то везут». Кушнер и Уиткофф уже на следующий день после Абу-Даби встретятся с Путиным в Москве. А потом с Зеленским в Дублине | LEDE: Спецпредставители президента США Джаред Кушнер и Ст] (ru: «Чт…
      Спецпредставители президента США Джаред Кушнер и Стив Уиткофф утром в четверг, 12 ноября, прилетят в Москву. Это подтвердил помощник Путина Юрий Ушаков в комментарии «Коммерсанту».
  - (2026-11-11) Во Франции похитили и уничтожили частицу мощей Николая Чудотворца | LEDE: Из базилики во французском городе Сен-Никола-де-Пор похитили фрагмент кости, который считается частью мощей святого ] (ru: Во…
      Из базилики во французском городе Сен-Никола-де-Пор похитили фрагмент кости, который считается частью мощей святого Николая Чудотворца, пишет Nancy Actualité.
  - (2026-11-11) Бывшему министру Михаилу Абызову вынесли приговор по новому делу о мошенничестве. Его срок увеличили до 14 лет | LEDE: Таганский суд Москвы приговорил бывшего министра по делам «Открытого пр] (ru: Быв…
      Таганский суд Москвы приговорил бывшего министра по делам «Открытого правительства» Михаила Абызова к 14 годам колонии строгого режима по делу о хищении инвестиций «Российской венчурной компании», сообщает «Коммерсант».…
  - (2026-11-11) Переговоры России и Украины в Абу-Даби завершились. Никакого прорыва опять нет. Главной темой вместо войны была «система европейской безопасности». Вопрос о территориях в тупике. Будет новый об] (ru:…
      Трехсторонние переговоры России, Украины и США, которые проходили в Абу-Даби 10–11 ноября, завершились. Глава российской делегации Владимир Мединский заявил, что Россия и Украина договорились обменяться пленными, а центр…
  - (2026-11-11) В Украине после переговоров с Россией допустили, что могут «достичь решения до Нового года» | LEDE: Участники мирных переговоров между Россией и Украиной могут прийти к решению до конца года] (ru: В У…
      Участники мирных переговоров между Россией и Украиной могут прийти к решению до конца года. Об этом на пресс-конференции по итогам переговоров в Абу-Даби заявил глава фракции «Слуга народа» в Верховной раде и член украин…
  - (2026-11-11) Российские Z-блогеры сообщили, что во время атаки Украины на Ленинградскую область погибли российские летчики | LEDE: Российские телеграм-каналы, пишущие о военной авиации, сообщили, что во ] (ru: Рос…
      Российские телеграм-каналы, пишущие о военной авиации, сообщили, что во время атаки украинских беспилотников на Ленинградскую область погибли летчики. Эта информация ничем не подтверждена.

### State-Level News — 431 new of 868 total
  - (2026-11-11) [California] CA overhauled a key conservatorship law. Has anything changed?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/102826-Annis-Pereyra_PU_CM_10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-11-11) [California] Election integrity is becoming a partisan prize. California voters did not take the bait
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/110326_Shasta-County-Election_SO_CM_33.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-11-11) [California] This law was supposed to force more Californians into mental health treatment. What happened?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/102826-Annis-Pereyra_PU_CM_15.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-11-11) [California] With California’s insurance crisis at an impasse, it might be time for a different approach
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/010824_Eaton-Fire_JH_CM_23.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-11-11) [California] Bad news for California school repairs: nearly half of bond measures on track to fail
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2023/11/111523_Keyes-School_LV_05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-11-11) [California] New governor begins the ‘Becerra era’ by making nice with Capitol Democrats
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/110526-Becerra-Presser-MG-CM-03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 245 new of 351 total
  - (2026-11-10) China’s Exports Jump on Strong AI Trade - Caixin Global
      China’s Exports Jump on Strong AI Trade Caixin Global
  - (2026-11-11) CX Daily: Chinese Woman Linked to Nvidia CEO Has Ties to Shady Shanghai Fund Manager - Caixin Global
      CX Daily: Chinese Woman Linked to Nvidia CEO Has Ties to Shady Shanghai Fund Manager Caixin Global
  - (2026-11-11) Alibaba Files to Spin Off Chip Unit in Hong Kong - Caixin Global
      Alibaba Files to Spin Off Chip Unit in Hong Kong Caixin Global
  - (2026-11-11) Jiangxi Names New Acting Governor as China’s Provincial Shake-Up Accelerates - Caixin Global
      Jiangxi Names New Acting Governor as China’s Provincial Shake-Up Accelerates Caixin Global
  - (2026-11-10) Ex-Chief of State-Owned Construction Giant Accused of Bribery, Abuse of Power - Caixin Global
      Ex-Chief of State-Owned Construction Giant Accused of Bribery, Abuse of Power Caixin Global
  - (2026-11-11) Former Hainan Security Chief Xiao Jie Indicted in Bribery Case - Caixin Global
      Former Hainan Security Chief Xiao Jie Indicted in Bribery Case Caixin Global

### Local News: St. Louis + Atlanta — 225 new of 273 total
  - (2026-11-11) [St. Louis] A home in Centralia, Illinois hits the market
      Rich HistoryIn 1955, architect William Bernoudy designed this home for the editor and publisher of the Centralia Sentinel. Two additions, one in 1998 and the other in 2000, expanded the living space while maintaining the…
  - (2026-11-11) [St. Louis] TerraWatt vs. TERRAWATT embroils St. Louis data center developer in trademark dispute
      So many new companies want into the data center development game that there apparently aren’t enough company names to go around. The company behind the proposed data center adjacent to The Armory in St. Louis, TerraWatt,…
  - (2026-11-11) [St. Louis] Invest STL’s program to keep Black wealth in North City helped some people stay
      Researchers with the Urban Institute say that a program that ran for three years—giving select Black St. Louisans north of Delmar Boulevard money to invest in their homes or businesses—was an “innovative tool to counter…
  - (2026-11-11) [St. Louis] AstraZeneca acquires St. Louis-based vaccine startup Omniose
      Omniose, a St. Louis-based startup developing better ways to make vaccines that fight bacterial infections, has been acquired by the global pharmaceutical and biotech company AstraZeneca. The two companies made the annou…
  - (2026-11-11) [St. Louis] Where in Chesterfield 11/11/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-11-10) [St. Louis] St. Louis CITY SC manager Yoann Damet makes a case for MLS Coach of the Year
      Ten matches into Yoann Damet’s first season as St. Louis CITY SC’s manager, the team sat 14th in the Western Conference. Now, he has a case for MLS Coach of the Year. Damet arrived in St. Louis less than a year ago with…

### State Legislative Action — 171 new of 226 total
  - (2026-11-11) [Alaska HB 379] An Act relating to service areas; and providing for an effective date.
      An Act relating to service areas; and providing for an effective date.
  - (2026-11-11) [Alaska HB 377] An Act relating to public records; relating to managing and preserving audio and video recordings; and relating to fees for the inspection and copying of public records under the Alask…
      An Act relating to public records; relating to managing and preserving audio and video recordings; and relating to fees for the inspection and copying of public records under the Alaska Public Records Act.
  - (2026-11-11) [Alaska SB 133] An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step…
      An Act relating to prior authorization requests for medical care covered by a health care insurer; relating to a prior authorization application programming interface; relating to step therapy; and providing for an effec…
  - (2026-11-11) [Alaska SB 180] An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regul…
      An Act relating to the development of the Susitna River power project by the Alaska Energy Authority; relating to the regulation of liquefied natural gas import facilities by the Regulatory Commission of Alaska; and prov…
  - (2026-11-11) [Alaska SB 137] An Act extending the termination date of the Board of Certified Direct-Entry Midwives; extending the termination date of the Board of Nursing; extending the termination date of the Boa…
      An Act extending the termination date of the Board of Certified Direct-Entry Midwives; extending the termination date of the Board of Nursing; extending the termination date of the Board of Veterinary Examiners; extendin…
  - (2026-11-11) [Alaska HB 334] An Act relating to the issuance of certified copies of birth certificates to unhoused young adults; and relating to the issuance of identification cards to unhoused young adults.
      An Act relating to the issuance of certified copies of birth certificates to unhoused young adults; and relating to the issuance of identification cards to unhoused young adults.

### U.S. Weather + Severe / Climate Outlooks — 133 new of 135 total
  - (2026-11-11) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-11) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 11 at 8:23AM CST until November 11 at 10:00AM CST by NWS Austin/San Antonio TX
      * WHAT...Visibility 1/4 mile in dense fog across some locations. For other spots, visibility could range from 1/2 mile to 3 miles. * WHERE...Blanco, Burnet, Gillespie, and Llano Counties. * WHEN...Until 10 AM CST this mo…
  - (2026-11-11) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued November 11 at 8:18AM CST until November 11 at 9:15AM CST by NWS Quad Cities IA IL
      SVRDVN The National Weather Service in the Quad Cities has issued a * Severe Thunderstorm Warning for... East central Rock Island County in northwestern Illinois... Northern Henry County in northwestern Illinois... * Unt…
  - (2026-11-11) [Moderate] Wind Advisory: Wind Advisory issued November 11 at 6:17AM PST until November 13 at 1:00PM PST by NWS Eureka CA
      * WHAT...South winds 25 to 35 mph with gusts up to 45 mph expected. * WHERE...Del Norte Coast. * WHEN...From midnight Thursday Night to 1 PM PST Friday. * IMPACTS...Wind gusts will be particularly strong along windward r…
  - (2026-11-11) [Moderate] Wind Advisory: Wind Advisory issued November 11 at 6:17AM PST until November 13 at 1:00PM PST by NWS Eureka CA
      * WHAT...South winds 30 to 40 mph with gusts up to 60 mph expected. * WHERE...Humboldt Interior, Interior Del Norte, and Southwestern Humboldt. * WHEN...From midnight Thursday Night to 1 PM PST Friday. * IMPACTS...Wind g…
  - (2026-11-11) [Moderate] Gale Warning: Gale Warning issued November 11 at 8:12AM CST until November 12 at 9:00PM CST by NWS Milwaukee/Sullivan WI
      * WHAT...North winds 25 to 30 kt with gusts up to 35 kt and waves 9 to 14 ft expected. * WHERE...Southern Open Waters of Lake Michigan. * WHEN...From 3 AM to 9 PM CST Thursday. * IMPACTS...Strong winds will cause hazardo…

### Ukraine Theater (total-war monitoring) — 88 new of 272 total
  - (2026-11-11) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-10) [Liveuamap] Explosions were reported in Zaporizhia – Zaporizhia Oblast, Ukraine - Liveuamap
      Explosions were reported in Zaporizhia – Zaporizhia Oblast, Ukraine Liveuamap
  - (2026-11-11) [Liveuamap] Iran news live map today | Liveuamap - Liveuamap
      Iran news live map today | Liveuamap Liveuamap
  - (2026-11-11) [Liveuamap] Syria live map: news and control map today | Liveuamap - Liveuamap
      Syria live map: news and control map today | Liveuamap Liveuamap
  - (2026-11-10) [Liveuamap] Explosions were reported in Chernihiv – Chernihiv, Chernihivs&039;ka oblast - Liveuamap
      Explosions were reported in Chernihiv – Chernihiv, Chernihivs&039;ka oblast Liveuamap
  - (2026-11-11) [Liveuamap] An Israeli airstrike hit a metal foundry in the Sabra neighborhood of Gaza City, killing three people, medics said. Four more people, including a 13-year-old, were killed in Gaza City&039;…
      An Israeli airstrike hit a metal foundry in the Sabra neighborhood of Gaza City, killing three people

### Ukrainian Internal News (national + local Kyiv) — 76 new of 139 total
  - (2026-11-11) Понад 700 шкіл у Північній Ірландії та Шотландії отримали електронні листи з погрозами | LEDE: Понад сім сотень шкіл у Шотландії та Північній Ірландії отримали електронні листи з погрозами у се] (uk:…
      Понад сім сотень шкіл у Шотландії та Північній Ірландії отримали електронні листи з погрозами у середу, 11 листопада.
  - (2026-11-11) Попри опір бійців полк "Айдар" отримав нового командира | LEDE: 24 окремий штурмовий полк "Айдар" очолив Сергій Мирошниченко, який до того був заступником командира 225 окремого штурмового полк] (uk:…
      24 окремий штурмовий полк "Айдар" очолив Сергій Мирошниченко, який до того був заступником командира 225 окремого штурмового полку.
  - (2026-11-11) Росіяни весь день атакують Харків: 2 людини загинули, ще 5 постраждали | LEDE: 11 листопада російські війська завдавали ударів по Салтівському, Основʼянському та Шевченківському районах Харкова] (uk:…
      11 листопада російські війська завдавали ударів по Салтівському, Основʼянському та Шевченківському районах Харкова, внаслідок чого 2 людей загинули, ще 5 постраждали.
  - (2026-11-11) ВАКС дозволив Єрмаку без електронного браслета пересуватись по всій Україні | LEDE: Вищий антикорупційний суд змінив запобіжний захід Андрію Єрмаку, підозрюваному у легалізації 460 млн грн під ] (uk:…
      Вищий антикорупційний суд змінив запобіжний захід Андрію Єрмаку, підозрюваному у легалізації 460 млн грн під час будівництва містечка.
  - (2026-11-11) Рада підтримала у першому читанні законопроєкт про реформу прокуратури | LEDE: Верховна Рада ухвалила у першому читанні законопроєкт щодо вдосконалення діяльності органів прокуратури та забезпе] (uk:…
      Верховна Рада ухвалила у першому читанні законопроєкт щодо вдосконалення діяльності органів прокуратури та забезпечення незалежності прокурорського самоврядування.
  - (2026-11-11) На Полтавщині російський дрон травмував 4 людей | LEDE: 11 листопада російський безпілотник влучив в об'єкт інфраструктури в Карлівській громаді на Полтавщині. Четверо людей отримали травми, од] (uk:…
      11 листопада російський безпілотник влучив в об'єкт інфраструктури в Карлівській громаді на Полтавщині. Четверо людей отримали травми, одна людина у тяжкому стані.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-11-10) U.S. Court of Appeals, 3rd Cir.: United States v. Mashaq White
  - (2026-11-10) U.S. Court of Appeals, 3rd Cir.: United States v. Thomas Autry
  - (2026-11-10) U.S. Court of Appeals, D.C. Cir.: Michael Abramowitz v. Kari Lake
  - (2026-11-10) Connecticut Supreme Court: Order on Motion - State v. Miller
  - (2026-11-10) U.S. Court of International Trade: Am. Brass Rod Fair Trade Coal. v. United States
  - (2026-11-10) U.S. Court of Appeals, 7th Cir.: Robert Panton v. Todd W. Blanche

### GDACS — global disaster alerts — 56 new of 100 total
  - (2026-10-07) [Green] Flood in Italy
      Flood · Green alert · Italy · Magnitude 0
  - (2026-11-11) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.5M, Depth:149.444km
  - (2026-11-11) [Green] Earthquake in Chile
      Earthquake · Green alert · Chile · Magnitude 5.1M, Depth:91.309km
  - (2026-11-11) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.1M, Depth:14.704km
  - (2026-11-11) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 4.6M, Depth:42.696km
  - (2026-11-11) [Green] Earthquake in South Of Mariana Islands
      Earthquake · Green alert · South Of Mariana Islands · Magnitude 4.7M, Depth:137.374km

### IT, InfoSys & cybersecurity news (last 7 days) — 41 new of 63 total
  - (2026-11-11) [BleepingComputer] N-able releases security hotfixes for zero-day vulnerabilities
      N-able released hotfixes to address zero-day bugs affecting its N-central remote monitoring and management (RMM) platform, which were publicly disclosed over the weekend and forced it to take vulnerable hosted environmen…
  - (2026-11-11) [BleepingComputer] Microsoft fixes audio issues caused by September security updates
      Microsoft says the November 2026 cumulative updates resolve USB audio issues plaguing Windows users who have installed security updates released since September. [...]
  - (2026-11-11) [BleepingComputer] CISA flags Cisco BroadWorks flaw as actively exploited in attacks
      The US Cybersecurity and Infrastructure Security Agency (CISA) warned on Tuesday that hackers are now exploiting a high-severity Cisco BroadWorks vulnerability in attacks. [...]
  - (2026-11-11) [BleepingComputer] Microsoft fixes Exchange sign-ins broken by Windows Server updates
      Microsoft has fixed Outlook sign-in and mail delivery issues on Exchange Server systems after installing the October 2026 Windows Server security updates. [...]
  - (2026-11-11) [The Hacker News] Hackers Target Qlik Sense Servers With Reverse Shells, Stage ActiveMQ and Veeam Exploits
      Threat actors have been observed targeting Qlik Sense servers to unsuccessfully deliver PowerShell reverse shell commands against multiple environments in October 2026. Cynet's CyOps and Research teams said they identifi…
  - (2026-11-11) [The Hacker News] Over 35,000 Grok-Built Apps Exposed Online, Some Leaking Confidential Data and Passwords
      Of the 37,571 Grok-built apps that security company Claroc found online, 35,578 were open to anyone without a sign-in, the researchers said yesterday. They included 24 apps built by staff at the social network X and at S…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-11) [LanzaTech Global, Inc.] Form 4 (Issuer)
      filed 2026-11-11 02:59 UTC · role: Issuer — Filed: 2026-11-10 AccNo: 0001193125-26-456010 Size: 6 KB
  - (2026-11-11) [KHOSLA VINOD] Form 4 (Reporting)
      filed 2026-11-11 02:59 UTC · role: Reporting — Filed: 2026-11-10 AccNo: 0001193125-26-456010 Size: 6 KB
  - (2026-11-11) [Hoge Brett Widney] Form 4 (Reporting)
      filed 2026-11-11 02:56 UTC · role: Reporting — Filed: 2026-11-10 AccNo: 0001493152-26-051085 Size: 4 KB
  - (2026-11-11) [Newton Golf Company, Inc.] Form 4 (Issuer)
      filed 2026-11-11 02:56 UTC · role: Issuer — Filed: 2026-11-10 AccNo: 0001493152-26-051085 Size: 4 KB
  - (2026-11-11) [Hanson Michael J.] Form 4 (Reporting)
      filed 2026-11-11 02:49 UTC · role: Reporting — Filed: 2026-11-10 AccNo: 0001213900-26-118235 Size: 6 KB
  - (2026-11-11) [Critical Metals Corp.] Form 4 (Issuer)
      filed 2026-11-11 02:49 UTC · role: Issuer — Filed: 2026-11-10 AccNo: 0001213900-26-118235 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 28 new of 28 total
  - (2026-11-12) AP1000 Design Certification Renewal
  - (2026-11-12) Establishment of the Oval Office National Monument
  - (2026-11-12) Schedules of Controlled Substances: Placement of Oveporexton in Schedule IV
      On August 5, 2026, the United States Food and Drug Administration (FDA) approved a new drug application for Orzeyful (oveporexton) for the treatment of narcolepsy type 1 in adults. The Department of Health and Human Serv…
  - (2026-11-12) Airworthiness Directives; Dassault Aviation Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Dassault Aviation Model MYSTERE-FALCON 50, FALCON 2000, and FALCON 2000EX airplanes. This proposed AD was prompted by a reported quality escape and a d…
  - (2026-11-12) Standard Instrument Approach Procedures, and Takeoff Minimums and Obstacle Departure Procedures; Miscellaneous Amendments
      This rule amends, suspends, or removes Standard Instrument Approach Procedures (SIAPs) and associated Takeoff Minimums and Obstacle Departure Procedures for operations at certain airports. These regulatory actions are ne…
  - (2026-11-12) Standard Instrument Approach Procedures, and Takeoff Minimums and Obstacle Departure Procedures; Miscellaneous Amendments
      This rule establishes, amends, suspends, or removes Standard Instrument Approach Procedures (SIAPS) and associated Takeoff Minimums and Obstacle Departure procedures (ODPs) for operations at certain airports. These regul…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-11-11) [Israel-Iran-Hezbollah axis · themes] Вълна от самоубийства в топ разузнаването на САЩ : Белият дом иска отговори
      actualno.com · Bulgarian · tone NA
  - (2026-11-11) [Israel-Iran-Hezbollah axis · themes] Federal government failed to hold Epstein accountable , Republican committee says
      wvtf.org · English · tone NA
  - (2026-11-11) [Israel-Iran-Hezbollah axis · themes] Minivan crashes into people outside Los Angeles metro station , killing 3
      postregister.com · English · tone NA
  - (2026-11-11) [Israel-Iran-Hezbollah axis · themes] Сколько баллистических ракет производит Иран в месяц : данные разведки
      iz.ru · Russian · tone NA
  - (2026-11-11) [Israel-Iran-Hezbollah axis · themes] Activist 100 per cent backs protest amid police fears
      nvi.com.au · English · tone NA
  - (2026-11-11) [Israel-Iran-Hezbollah axis · themes] La rickettsia se ha convertido en un problema grave en Hermosillo : Secretaría de Salud
      tribuna.com.mx · Spanish · tone NA

### Government Action: Sanctions + Procurement + Foreign Agents — 23 new of 100 total
  - (2026-11-09) [FARA] National Security Division | Former Assistant Attorney General John A. Eisenberg - Department of Justice (.gov)
      National Security Division | Former Assistant Attorney General John A. Eisenberg Depar
  - (2026-11-11) [USASpending] $31,223,517,819 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT
  - (2026-11-11) [USASpending] $15,120,780,109 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE
      Agency: Department of Energy. Description: OPERATION AND MAINTENANCE LINEAR ACCELLERATOR
  - (2026-11-11) [USASpending] $10,517,828,993 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration. Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF…
  - (2026-11-11) [USASpending] $8,803,419,756 → BROOKHAVEN SCIENCE ASSOCIATES LLC: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
      Agency: Department of Energy. Description: IGF::OT::IGF TAS::89 0222::TAS M&O CONTRACT FOR BNL
  - (2026-11-11) [USASpending] $1,581,664,550 → CALIFORNIA INSTITUTE OF TECHNOLOGY: DEEP SPACE NETWORK (DSN) THE CONTRACT IS THE SPONSORING AGR
      Agency: National Aeronautics and Space Administration. Description: DEEP SPACE NETWORK (DSN) THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION (NASA) AND THE CALIFORNIA IN…

### Government & military aircraft airborne (OpenSky) — 21 new of 22 total
  - (2026-11-11) PAT296 (United States)
      icao24: adfdd1 · position: (41.4282, -75.943) · alt: 7924m · 363km/h
  - (2026-11-11) FNY050 (France)
      icao24: 39a407 · position: (47.957, 0.4471) · alt: 6697m · 746km/h
  - (2026-11-11) GAF726 (Germany)
      icao24: 3f59f3 · position: (50.5136, 11.9526) · alt: 5882m · 761km/h
  - (2026-11-11) JAF63D (Belgium)
      icao24: 44d1ba · position: (38.826, -7.7808) · alt: 11582m · 996km/h
  - (2026-11-11) JAF6LX (Belgium)
      icao24: 44d1a7 · position: (42.7041, -4.9666) · alt: 11582m · 1016km/h
  - (2026-11-11) JAF7XE (Belgium)
      icao24: 44d1a5 · position: (38.973, -9.0613) · alt: 11277m · 676km/h

### USGS earthquakes (M4.5+, past day) — 18 new of 18 total
  - (2026-11-10) M 5.6 - 43 km S of Puerto San José, Guatemala
      M5.6 · 43 km S of Puerto San José, Guatemala · depth 35 km
  - (2026-11-10) M 5.2 - 21 km WNW of Popondetta, Papua New Guinea
      M5.2 · 21 km WNW of Popondetta, Papua New Guinea · depth 124.245 km
  - (2026-11-10) M 5.2 - Mid-Indian Ridge
      M5.2 · Mid-Indian Ridge · depth 10 km
  - (2026-11-10) M 5.2 - 140 km ESE of Labuha, Indonesia
      M5.2 · 140 km ESE of Labuha, Indonesia · depth 10 km
  - (2026-11-11) M 5.1 - 27 km WSW of Calama, Chile
      M5.1 · 27 km WSW of Calama, Chile · depth 91.309 km
  - (2026-11-11) M 5.1 - Pulau Pulau Tanimbar, Indonesia
      M5.1 · Pulau Pulau Tanimbar, Indonesia · depth 14.704 km

### World News (by country, top stories) — 12 new of 12 total
  - (2026-11-11) [China] 중국 , 150여 개국 · 30여 개 국제기구와 일대일로 공동 건설 협력 문서 체결
      korean.cri.cn · English
  - (2026-11-11) [China] US - China AI cooperation and competition : Bessent
      chinatechnews.com · English
  - (2026-11-11) [China] Nvidia board backs Huang as spy probe raises questions
      taiwansun.com · English
  - (2026-11-11) [China] Ample opportunities to expand China - Europe business cooperation , says Polish business leader
      taiwansun.com · English
  - (2026-11-11) [China] British comedian Russell Brand gets 10 - and - a - half years in jail
      taiwansun.com · English
  - (2026-11-11) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-11-11) BNP Paribas Nordic Open: Lorenzo Sonego vs Alejandro Tabilo
      yes price: 52% · 24h volume: $978,212 · resolves 2026-11-18
  - (2026-11-11) UFC 334: Josh Hokit vs. Ciryl Gane (Heavyweight, Main Card)
      yes price: 36% · 24h volume: $557,756 · resolves 2026-11-15
  - (2026-11-11) Will Sport Lisboa e Benfica vs. FK Austria Wien end in a draw?
      yes price: 26% · 24h volume: $444,836 · resolves 2026-11-11
  - (2026-11-11) LoL: Ground Zero Gaming vs Frank Esports (BO5) - LCP Promotion Playoffs
      yes price: 70% · 24h volume: $409,985 · resolves 2026-11-11
  - (2026-11-11) Will the U.S. invade Iran before 2027?
      yes price: 8% · 24h volume: $371,941 · resolves 2027-01-01
  - (2026-11-11) Pete Hegseth out as Secretary of Defense by December 31?
      yes price: 12% · 24h volume: $330,514 · resolves 2027-01-01

### Paper Trading Scorecard — 9 new of 64 total
  - (2026-11-11) [Polymarket] Will Bitcoin reach $87,500 in November?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…
  - (2026-11-11) [Manifold] Will I kiss Aella this year?
  - (2026-11-11) [Manifold] Will Fernando Mendoza throw his first touchdown before he throws his first interception?
  - (2026-11-11) [Manifold] Will Anthropic achieve a 0.60 on RSI Index before September 2027?
  - (2026-11-11) [Manifold] Will Lightcone receive $50k+ from Anthropic employees, within 1 year after IPO?
  - (2026-11-11) [Manifold] Will Waymo give public driverless rides across the Golden Gate Bridge by the end of 2027?

### CISA Known Exploited Vulnerabilities (last 14d) — 6 new of 19 total
  - (2026-11-10) CVE-2026-124194 · Microsoft Office: Microsoft Office Outlook Missing User Interaction for Potentially Unsafe Action Vulnerability
      vendor: Microsoft · product: Office · CISA remediation by 2026-11-24
  - (2026-11-10) CVE-2026-111793 · Openwave Messaging Limited Webtop Media Transcoder: Openwave Messaging Limited Webtop Media Transcoder Incorrect Resource Transfer Between Spheres Vulnerability
      vendor: Openwave Messaging Limited · product: Webtop Media Transcoder · CISA remediation by 2026-11-24
  - (2026-11-10) CVE-2026-20320 · Cisco BroadWorks: Cisco BroadWorks Improper Restriction of XML External Entity Reference Vulnerability
      vendor: Cisco · product: BroadWorks · CISA remediation by 2026-11-24
  - (2026-11-10) CVE-2026-111560 · Barracuda Networks Multiple Products: Barracuda Networks Multiple Products OS Command Injection Vulnerability
      vendor: Barracuda Networks · product: Multiple Products · CISA remediation by 2026-11-13
  - (2026-11-10) CVE-2026-116606 · Barracuda Networks Barracuda Email Security Gateway (ESG): Barracuda Networks Email Security Gateway (ESG) Authentication Bypass Using an Alternate Path or Channel Vulnerability
      vendor: Barracuda Networks · product: Barracuda Email Security Gateway (ESG) · CISA remediation by 2026-11-13
  - (2026-11-10) CVE-2026-125350 · Google Chromium: Google Chromium Use-After-Free Vulnerability
      vendor: Google · product: Chromium · CISA remediation by 2026-11-24

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-11-11) [Marginal Revolution] What should I ask Simon Sebag Montefiore?
      I will be doing a Conversation with him, most of all about his new and very good book The Cauldron: The Making of the Modern Middle East. He has many other excellent books too, including on Russian history and some ficti…
  - (2026-11-11) [Marginal Revolution] UK fact of the day
      UK panel data, 1991-2019. Couples who support different parties separate more often. The effect is as strong as some other mismatches, like education. Disagreement over Brexit mattered even more than party preference. He…
  - (2026-11-11) [Marginal Revolution] Spying makes a comeback
      That is the theme of my latest Free Press article, here is one excerpt: It may look like merely the latest story of a wealthy, powerful man making an irresponsible decision. But below the surface, it is also a harbinger…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-11) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=28, 7d-median=26, 14d-median=18; carrying terms: safety, existing, commission, regulatory, service, final, action, certain, agency, flight, proposes, published
- state_bills: today=226, 7d-median=97, 14d-median=100; carrying terms: establishing, review, authority, vehicle, health, access, approval, insurance, income, energy, enforcement, emergency
- state_news: today=868, 7d-median=675, 14d-median=724; carrying terms: families, office, expect, constitution, consider, supreme, leadership, individuals, launched, attempt, saturday, obituary
- local_news: today=273, 7d-median=265, 14d-median=256; carrying terms: constitution, weekend, magazine, stlmag, against, https, woman, world, person, target, times, killed
- foreign_news: today=1008, 7d-median=1008, 14d-median=1008; carrying terms: families, korea, stories, force, supreme, avoid, third, corruption, street, england, rdquo, hackers
- chinese_internal: today=351, 7d-median=334, 14d-median=307; carrying terms: cbmizefvx, https, cbmiakfvx, caixin, cbmiy, cbmibefvx, target, cbmia, growth, global, cbmizkfvx, lxtfb
- russian_internal: today=1104, 7d-median=946, 14d-median=951; carrying terms: telegram, media, httperror, found, financial, server, https, error, street, reuters, forbidden, gazeta
- ukrainian_internal: today=139, 7d-median=139, 14d-median=134; carrying terms: strike, moscow, offensive, damaged, launched, european, november, dnipro, political, countries, assessment, nearly
- ukraine_theater: today=272, 7d-median=269, 14d-median=328; carrying terms: bdwpvthbfczvzegpysxoyyzvizetgr, cbmirefvx, seutyvgoxevnzmkf, strike, password, fxtthroe, force, yyqus, leadership, exnjwu, interim, aknsvgvpmnk
- paper_bets: today=64, 7d-median=66, 14d-median=67; carrying terms: yards, become, kylian, riemann, headline, drought, jackson, population, general, chair, prime, least
- weather: today=135, 7d-median=135, 14d-median=134; carrying terms: forecast, details, caribbean, holly, lincoln, roads, marine, francisco, third, aviation, saturday, changed
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unemployment, recession, funds, headline, latest, cpiaucsl, payems, crude, jolts, inflation, pcepilfe, rates
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: agriculture, futures, crude, yield, nasdaq, china, large, credit, equities, natural, russell, rates
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=100, 7d-median=99, 14d-median=99; carrying terms: congo, operations, office, portal, designations, xskfisuh, checksum, related, trade, hybrid, color, space
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, client, error, quiver, quantitative, https, httperror, congresstrading, quiverquant
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, supreme, international, florida, secretary, appeals, alabama, blanche, connecticut, company, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, holdings, finance, michael, global, scott, jonathan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, peltola, booker, jackson, abdul, house, james, disbursements, robert, talarico, trone
- gdelt_regions: today=12, 7d-median=3, 14d-median=3
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, russian, themes, spanish, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=30, 14d-median=30; carrying terms: position, belgium, kingdom, france, germany, canada, adfdd
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: antiplague, located, siberia, cause, congo, kozhikode, cereulide, viruses, genetic, geographic, mongbwalu, march
- cisa_kev: today=19, 7d-median=14, 14d-median=17; carrying terms: return, value, software, remediation, vendor, authentication, edition, vulnerability, unchecked, product, secure, google
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: green, wildfire, forest, guyana, magnitude, fires, alert, brazil, south, cyclone, forestfire, earthquake
- usgs_quakes: today=18, 7d-median=14, 14d-median=15; carrying terms: depth, islands, japan, ridge, region, indonesia, vanuatu, russia, indian, guinea, papua, village
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, presidential, election, shakhtar, donetsk, league, championship, champions, rates, playoffs
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, https, conversable, revolution, economist, class, published, world, marginalrevolution, promised, security, social
- tech_news: today=63, 7d-median=61, 14d-median=60; carrying terms: brought, technica, hackers, computerweekly, record, review, service, attacks, download, access, known, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: wilson, martin, tillis, ciscomani, wasserman, brett, latta, incumbent, anomaly, ruben, margaret, schatz
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, today, consensus, placement, either, module, claude, market, decision, unavailable, sufficient, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*