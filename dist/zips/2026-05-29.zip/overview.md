# WORLDSCOPE morning brief — 2026-05-29

## Headline
3253 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 34 new of 34 total
  - (2026-05-29) Regulation for Federal Financial Assistance
      The Office of Management and Budget (OMB) proposes to revise the Guidance for Federal Financial Assistance to improve government- wide policies and requirements related to the management of grants, cooperative agreements
  - (2026-05-29) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Angling Category Retention Limit Adjustment
      NMFS is adjusting the Angling category Atlantic bluefin tuna (BFT) daily retention limit from the default of one school, large school, or small medium BFT to: two BFT per vessel per day/trip measuring 27 inches (68.5 cm)
  - (2026-05-29) Airworthiness Directives; Goodrich Cabin Attendant Seats
      The FAA is adopting a new airworthiness directive (AD) for Goodrich cabin attendant seats installed on Airbus SAS Model A330-200 series, A330-200 Freighter series, A330-300 series, A330-743L, A330- 841, A330-941, A340-20
  - (2026-05-29) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for all The Boeing Company Model 747-100, -100B, -100B SUD, -200B, -200C, - 200F, -300, -400, -400D, -400F, 747SP, and 747SR series airplanes. This AD was prompted b
  - (2026-05-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A330-200, -200 Freighter, -300, -800, and -900 series airplanes. This AD was prompted by the identification of an incorrect shot peening
  - (2026-05-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A318 series airplanes; Model A319-111, -112, - 113, -114, -115, -131, -132, and -133 airplanes; Model A320-211, -212, -214, -216, -231, 
  - (2026-05-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for all Airbus SAS Model A319 series airplanes; Model A320 series airplanes; and Model A321-111, -112, -131, -211, -212, -213, -231, -232, -251N, - 252N, -253N, -271
  - (2026-05-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A318-111, -112, and -122 airplanes; Model A319-111, -112, -113, -114, -115, -131, -132, and -133 airplanes; Model A320-211, -212, -214, 

### State Legislative Action — 323 new of 323 total
  - (2026-05-29) [Alaska HB 24] An Act relating to aggravating factors considered at sentencing.
      An Act relating to aggravating factors considered at sentencing.
  - (2026-05-29) [Alaska SB 200] An Act relating to service areas; relating to municipal assessments of farm or agricultural land; and providing for an effective date.
      An Act relating to service areas; relating to municipal assessments of farm or agricultural land; and providing for an effective date.
  - (2026-05-29) [Alaska SB 24] An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco, a product containing nicotine, or an electronic smoking product; relating to the tobacco use educat
      An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco, a product containing nicotine, or 
  - (2026-05-29) [Alaska HB 217] An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.
      An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.
  - (2026-05-29) [Alaska SB 164] An Act eliminating deductions for the remittance of the motor fuel tax, tobacco taxes, and tire fees; relating to discounts on cigarette stamps; and providing for an effective date.
      An Act eliminating deductions for the remittance of the motor fuel tax, tobacco taxes, and tire fees; relating to discounts on cigarette stamps; and providing for an effective date.
  - (2026-05-29) [Alaska SB 272] An Act relating to the electronic health information exchange system; and providing for an effective date.
      An Act relating to the electronic health information exchange system; and providing for an effective date.
  - (2026-05-29) [Alaska HB 381] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of revenue from the alternative volumetric tax; and providing for an 
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re
  - (2026-05-29) [Alaska HB 119] An Act relating to an in-state natural gas pipeline developed by the Alaska Gasline Development Corporation; and providing for an effective date.
      An Act relating to an in-state natural gas pipeline developed by the Alaska Gasline Development Corporation; and providing for an effective date.

### State-Level News — 395 new of 728 total
  - (2026-05-28) [Alabama] Governor Ivey Encourages Alabama Small Businesses to Pitch Big for America 250
      MONTGOMERY – Governor Kay Ivey on Thursday is encouraging eligible Alabama small businesses and entrepreneurs to submit a pitch for the U.S. Small Business Administration’s (SBA) national “Freedom 250” Patriot Pitch Comp
  - (2026-05-28) [California] Sigamos el rastro del dinero: ¿Quién apoya al próximo gobernador de California y por qué?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/041426_Governors-Forum-Sacramento_MG_CM_14.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-i
  - (2026-05-28) [California] Infórmate rápidamente sobre las elecciones de California con nuestra guía para indecisos
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/030524-SF-Primary-Voting-JY-CM-15.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size
  - (2026-05-28) [California] Who’s ahead in the California governor race?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/Becerra-Hilton_CM_02.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag
  - (2026-05-28) [California] Follow the money: Who’s backing California’s next governor — and why
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/041426_Governors-Forum-Sacramento_MG_CM_14.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-i
  - (2026-05-28) [California] Poll shows Becerra and Hilton are pulling ahead of the pack in California’s governor race
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052726-Becerra-Hilton-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size
  - (2026-05-28) [California] Will Californians pick candidates who are government outsiders or ones with  governing experience?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/041426-Governors-Forum-Sacramento-MG-CM-12.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-i
  - (2026-05-28) [California] What would get Gen Z to vote in California’s primary? These candidates are trying
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/030524-Election-Primary-MG-15-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 198 new of 229 total
  - (2026-05-28) [St. Louis] Florentin moves to former Steve’s Hot Dogs space in the Delmar Maker District
      <p>Florentin, Ben Poremba’s acclaimed brunch spot, is getting a new address—just a few doors from its current one. Last month, the chef and restaurateur announced that the restaurant will relocate to the former Steve’s H
  - (2026-05-28) [St. Louis] ‘Dinoroarus’ stomps back to the Saint Louis Zoo with roaring animatronic, prehistoric fun
      <p>This summer, the Saint Louis Zoo is turning back the clock about 200 million years. Cue the tiny dinosaur obsessions and Jurassic Park soundtracks: Dinoroarus is officially returning to the Saint Louis Zoo. Opening Ju
  - (2026-05-28) [St. Louis] Lou’s Clues – 6/1/2026
      <p>Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it 
  - (2026-05-28) [St. Louis] Richard Kind is ready for his Muny debut in ‘Hairspray’
      <p>While character actor Richard Kind is perhaps best known for his many supporting parts, he will be stepping into a leading role as Edna Turnblad in The Muny’s production of Hairspray, on stage at the Forest Park theat
  - (2026-05-28) [St. Louis] What’s True in the Lou? – 5/29/2026
      <p>How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance t
  - (2026-05-28) [St. Louis] Mark your calendars for these summer fairs and festivals
      <p>ALL SUMMER LONG Enjoy some Shakespeare in the Park as the St. Louis Shakespeare Festival puts on their annual production in Forest Park. The Tempest, directed by former fest artistic director Rick Dildine, will transf
  - (2026-05-28) [St. Louis] How one St. Louis family is making local race and triathlon culture more accessible for parents
      <p>At most races, Molly Carr notices the same thing: parents trying to juggle snacks, strollers, parking logistics, bathroom breaks, and nervous kids before the starting horn even sounds. “That’s the stuff nobody tells y
  - (2026-05-27) [St. Louis] Top cannabis events across St. Louis
      <p>May 29: Fried Friday May 31: Sunset Serenity Full Moon Floating Sound Immersion June 1: M4MM Minority Industry Mixer June 2-7: Cosmic Kinection 2026 June 2, 16: Tabletop Tuesday &#8211; DnD and Ice Cream Social June 2

### International News + Multilateral Institutions — 628 new of 876 total
  - (2026-05-29) [Global] WHO chief arrives in DRC promising Ebola outbreak ‘can be stopped’
  - (2026-05-29) [Global] Friday briefing: ​What do the cuts in aid mean for the fight against Ebola in the DRC?
  - (2026-05-28) [Global] Dormitory fire at Kenyan girls’ school kills at least 16 students
  - (2026-05-28) [Global] Guatemala requests US military cooperation against drug trafficking
  - (2026-05-28) [Global] Clashes between armed groups in Colombia kill at least 52
  - (2026-05-28) [Global] Carney calls for new US-Canada partnership to ‘help make America great again’
  - (2026-05-28) [Global] Family accuse UK government of lack of support over death of Briton in Grenada
  - (2026-05-28) [Global] Argentina’s ‘European’ self-image under renewed scrutiny after racist incidents in Brazil

### Chinese Internal News — 237 new of 281 total
  - (2026-05-29) [TITLE: 聚力打造京津冀机器人产业高地 天津市机器人产业技术联盟成立 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBkcW9LcHk0UXdsYlRNLUFwc1B1NUpwemhsVlNpNmdRZjNCbTVIM1BDaFFTXzhDeG5UU1NYR016eDBaeHFBUHU5WUh] (zh: 聚力打造京津冀机器人产业高地 天津市机器人产业技术联盟成立 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBkcW9LcHk0UXdsYlRNLUFwc1B1NUpwemhsVlNpNmdRZjNCbTVIM1BDaFFTXzhDeG5UU1NYR016eDBaeHFBUHU5WUhwT2ZjSE81MUVQYXl2NjdpT1dsNi03QlNKa0RfOENyYkE?oc=5" target="_blank">聚力打造
  - (2026-05-29) [TITLE: 四川省成立调查指导组督导稻城亚丁景区摆渡车问题整改 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE02c3FBTE5BMlBLTUhPY2RITGZpSzNsWUpUbGgyUGw4dWJza3pGc25Hd1c5R0p3QkRTU0RkTVdOZ1d2N3QwRXNtRU5ZVlR] (zh: 四川省成立调查指导组督导稻城亚丁景区摆渡车问题整改 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE02c3FBTE5BMlBLTUhPY2RITGZpSzNsWUpUbGgyUGw4dWJza3pGc25Hd1c5R0p3QkRTU0RkTVdOZ1d2N3QwRXNtRU5ZVlRxM243ZHNJSkdyU3FWdTZXeEJHM2FUZ044Q0lFd1RRY3pR?oc=5" target="_blank"
  - (2026-05-29) [TITLE: 美蓝色起源公司重型运载火箭测试时爆炸--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1KWW4xUXZHU0NVQzZ2MnFoZV8tWE1fbFNzVDNZeElCWEtiR0tVanVoTklaZWhBVktYa2F4MUZaWHV3TWViTnBVZUZUY0d6WF] (zh: 美蓝色起源公司重型运载火箭测试时爆炸--国际 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1KWW4xUXZHU0NVQzZ2MnFoZV8tWE1fbFNzVDNZeElCWEtiR0tVanVoTklaZWhBVktYa2F4MUZaWHV3TWViTnBVZUZUY0d6WFZuUkFzSTQ1NlRocW5abld6VDZPUEVWYkVYWnRV?oc=5" target="_blank">美蓝色
  - (2026-05-28) [TITLE: 王毅出席“全球治理之友小组”会议 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE94R0wwX1FlcXN1YW5PUDRXakdMdlFjbzJCREYyQkJ3dUpScUVybFdxZW1ldG9sN2JmbkhvVnkyeUVobmYzb] (zh: 王毅出席“全球治理之友小组”会议 - politics.people.com.cn)
      <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE94R0wwX1FlcXN1YW5PUDRXakdMdlFjbzJCREYyQkJ3dUpScUVybFdxZW1ldG9sN2JmbkhvVnkyeUVobmYzbnBRRFRUdDlqalVteWFudTk5dTBjcmNPOGlGY2hZWHdHM2k1VTBkc2oxZw?oc=5" target="_blan
  - (2026-05-29) [TITLE: 中央宣传部、中国科协联合发布“最美科技工作者”先进事迹 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5adDNwaV9lM0hBUnFRNUlmTW12XzRFUWdzeGJrREFVRkV0V0FDbVZwSE1PRkpacW4zaTVqaG] (zh: 中央宣传部、中国科协联合发布“最美科技工作者”先进事迹 - politics.people.com.cn)
      <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5adDNwaV9lM0hBUnFRNUlmTW12XzRFUWdzeGJrREFVRkV0V0FDbVZwSE1PRkpacW4zaTVqaGp3U2VFM1JKRGVsczVfa1JJcmViZXVQTmtfcHF6XzJzUjZ4dlRxY1lDNXpoQ2VhbUVxOA?oc=5" target="_blan
  - (2026-05-29) [TITLE: 村里有了“农忙托管班” - 人民网教育 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE9ReTQwdnVRVHpBTWloZHl6STdPMnd4RjFzU1NYbnNoZmJwS2RldWduSlczNTg0SnFSSThCR2JrcEFoTFZWSDU3RVpLVklFWG1pdzYxZ0Z] (zh: 村里有了“农忙托管班” - 人民网教育)
      <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE9ReTQwdnVRVHpBTWloZHl6STdPMnd4RjFzU1NYbnNoZmJwS2RldWduSlczNTg0SnFSSThCR2JrcEFoTFZWSDU3RVpLVklFWG1pdzYxZ0ZoekRFM3NEbmRnTkZpdFhUMGti?oc=5" target="_blank">村里有了“农忙
  - (2026-05-29) [TITLE: 第八届中华经典诵写讲大赛启幕 - 人民网教育 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE1yR085ZUFoNVdTSG4zcGxJeXdkNHptUjBWemZwbGkzbGR0NmItZzJxYThkNFZmcUp4RklpN195Zk9UVTRHUGlROEYwM0lSWGZQVWIy] (zh: 第八届中华经典诵写讲大赛启幕 - 人民网教育)
      <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE1yR085ZUFoNVdTSG4zcGxJeXdkNHptUjBWemZwbGkzbGR0NmItZzJxYThkNFZmcUp4RklpN195Zk9UVTRHUGlROEYwM0lSWGZQVWIyUmp1MGNKMGpqZmR3Ny0xYmQ5ZUhM?oc=5" target="_blank">第八届中华经典
  - (2026-05-28) [TITLE: 国务院印发《城市更新“十五五”规划》 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE80RnJlbktuX0djU3h5YjltRzZFb3hkczcxcHc1M1NGdXVSYU5vbjJWTlQzc0RvQWdTNmNXV2tiWTJjcl9] (zh: 国务院印发《城市更新“十五五”规划》 - politics.people.com.cn)
      <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE80RnJlbktuX0djU3h5YjltRzZFb3hkczcxcHc1M1NGdXVSYU5vbjJWTlQzc0RvQWdTNmNXV2tiWTJjcl9kMG5SeUZKV0dqWmZaRllnSjVvVVlvdzRHVi1LRjV4czVBelRNaUFfWXBDYw?oc=5" target="_blan

### Russian Internal News (state + in-exile) — 542 new of 898 total
  - (2026-05-29) [TITLE: Компания Anthropic стала самым дорогим ИИ-стартапом, обогнав OpenAI | LEDE: <p>Компания Anthropic в ходе последнего раунда финансирования привлекла 65 миллиардов долларов, а ее оценка достигла ] (ru: Компания Anthropic стала самым дорогим ИИ-стартапом, обогнав OpenAI)
      <p>Компания Anthropic в ходе последнего раунда финансирования привлекла 65 миллиардов долларов, а ее оценка достигла 965 миллиардов долларов.<p>
  - (2026-05-29) [TITLE: Чеченский министр опубликовал видео Белкисы Минцаевой, которая пыталась забрать дочь у бывшего мужа. Теперь она просит «не делать инфоповод» из ее семьи | LEDE: <p>Министр печати Чечни Ахмед Ду] (ru: Чеченский министр опубликовал видео Белкисы Минцаевой, которая пыталась забрать )
      <p>Министр печати Чечни Ахмед Дудаев опубликовал видео Белкисы Минцаевой — матери двоих детей, которая обвинила бывшего мужа в похищении младшей дочери и просила помощи у Следственного комитета.<p>
  - (2026-05-29) [TITLE: Рейтинг Путина продолжает падать. ВЦИОМ изменил методику опросов, но это не помогло | LEDE: <p>Всероссийский центр изучения общественного мнения (ВЦИОМ) зафиксировал снижение рейтинга одобрения] (ru: Рейтинг Путина продолжает падать. ВЦИОМ изменил методику опросов, но это не помо)
      <p>Всероссийский центр изучения общественного мнения (ВЦИОМ) зафиксировал снижение рейтинга одобрения президента РФ на 1,9 процентных пункта по сравнению с предыдущей неделей.<p>
  - (2026-05-29) [TITLE: Reuters: Кремль хочет отправить 100 тысяч проживающих в России армян голосовать против Пашиняна | LEDE: <p>Российские чиновники в последние месяцы обсуждали план отправки на родину проживающих ] (ru: Reuters: Кремль хочет отправить 100 тысяч проживающих в России армян голосовать )
      <p>Российские чиновники в последние месяцы обсуждали план отправки на родину проживающих в России граждан Армении, чтобы они проголосовали на парламентских выборах за конкурентов действующего премьера Никола Пашиняна, пи
  - (2026-05-29) [TITLE: FT: Минфин РФ попросил заморозить расходы бюджета на 2,9 триллиона рублей — по всем статьям, кроме военных | LEDE: <p>Глава Минфина РФ Антон Силуанов попросил сократить расходы всех статьей бюд] (ru: FT: Минфин РФ попросил заморозить расходы бюджета на 2,9 триллиона рублей — по в)
      <p>Глава Минфина РФ Антон Силуанов попросил сократить расходы всех статьей бюджета на 2026 год, кроме военных. Соответствующее письмо, как стало известно Financial Times, Силуанов направил в правительство в феврале.<p>
  - (2026-05-29) [TITLE: Жителя Австрии приговорили к 15 годам за подготовку теракта на концерте Тейлор Свифт | LEDE: <p>21-летний австриец приговорен к 15 годам лишения свободы за подготовку теракта на концерте певицы] (ru: Жителя Австрии приговорили к 15 годам за подготовку теракта на концерте Тейлор С)
      <p>21-летний австриец приговорен к 15 годам лишения свободы за подготовку теракта на концерте певицы Тейлор Свифт в Вене в 2024 году. <p>
  - (2026-05-29) [TITLE: С начала 2026 года на российский рынок не вышел ни один новый иностранный бренд | LEDE: <p>За первые пять месяцев 2026 года на российском рынке не появилось ни одного нового иностранного бренда] (ru: С начала 2026 года на российский рынок не вышел ни один новый иностранный бренд)
      <p>За первые пять месяцев 2026 года на российском рынке не появилось ни одного нового иностранного бренда, пишут «Ведомости» со ссылкой на отчет консалтинговой компании CORE.XP.<p>
  - (2026-05-29) [TITLE: Ракета компании Blue Origin миллиардера Джеффа Безоса взорвалась на стартовой площадке | LEDE: <p>Ракета «Нью Гленн» (New Glenn) компании Blue Origin американского миллиардера Джеффа Безоса взо] (ru: Ракета компании Blue Origin миллиардера Джеффа Безоса взорвалась на стартовой пл)
      <p>Ракета «Нью Гленн» (New Glenn) компании Blue Origin американского миллиардера Джеффа Безоса взорвалась во время испытания двигателей на стартовой площадке на мысе Канаверал во Флориде.<p>

### Ukrainian Internal News (national + local Kyiv) — 61 new of 121 total
  - (2026-05-29) [TITLE: Reuters: Кремль готував схему з перевезенням 100 тисяч виборців для впливу на вибори у Вірменії | LEDE: Російські посадовці обговорювали можливість перевезення до 100 тисяч вірмен, які проживаю] (uk: Reuters: Кремль готував схему з перевезенням 100 тисяч виборців для впливу на ви)
      Російські посадовці обговорювали можливість перевезення до 100 тисяч вірмен, які проживають у РФ, для участі в парламентських виборах у Вірменії та голосування проти чинного прем'єра Нікола Пашиняна.
  - (2026-05-29) [TITLE: Червень прийде з дощами | LEDE: В Україні 30 травня – 1 червня дощі та грози, температура вдень до 24°, детальний прогноз від Укргідрометцентру.] (uk: Червень прийде з дощами)
      В Україні 30 травня – 1 червня дощі та грози, температура вдень до 24°, детальний прогноз від Укргідрометцентру.
  - (2026-05-29) [TITLE: Президент Польщі хоче забрати орден у Зеленського, бо той присвоїв підрозділу ССО "імені Героїв УПА" | LEDE: Польський президент Кароль Навроцький буде домагатися позбавлення президента України] (uk: Президент Польщі хоче забрати орден у Зеленського, бо той присвоїв підрозділу СС)
      Польський президент Кароль Навроцький буде домагатися позбавлення президента України Володимира Зеленського найвищої нагороди Польщі через його рішення присвоїти елітному підрозділу українських ССО імені Героїв УПА.
  - (2026-05-29) [TITLE: Польщу обурило, що елітний підрозділ ССО назвали на честь Героїв УПА | LEDE: У Польщі викликало обурення рішення Володимира Зеленського присвоїти найменування на честь Героїв УПА елітному підро] (uk: Польщу обурило, що елітний підрозділ ССО назвали на честь Героїв УПА)
      У Польщі викликало обурення рішення Володимира Зеленського присвоїти найменування на честь Героїв УПА елітному підрозділу Сил спеціальних операцій.
  - (2026-05-29) [TITLE: ГУР показало вогневий контроль над сухопутним коридором "Крим-Донецьк" | LEDE: Головне управління розвідки Міноборони показало, як оператори підрозділів безпілотних систем департаменту активних] (uk: ГУР показало вогневий контроль над сухопутним коридором "Крим-Донецьк")
      Головне управління розвідки Міноборони показало, як оператори підрозділів безпілотних систем департаменту активних дій ГУР блокують сухопутний коридор "Крим–Донецьк" і знищують техніку російських загарбників у глибокому 
  - (2026-05-29) [TITLE: Свириденко: Законопроєкт про реформу ДБР планують внести до Ради у грудні | LEDE: Прем'єр-міністерка Юлія Свириденко каже, що законопроєкт про реформу Державного бюро розслідувань мають напрацю] (uk: Свириденко: Законопроєкт про реформу ДБР планують внести до Ради у грудні)
      Прем'єр-міністерка Юлія Свириденко каже, що законопроєкт про реформу Державного бюро розслідувань мають напрацювати до кінця року, а внести до Верховної Ради планують у грудні 2026 року.
  - (2026-05-29) [TITLE: Президент Румунії скликав Раду нацбезпеки через влучання дрона у Галаці, в МЗС викликали посла РФ | LEDE: Очільниця МЗС Румунії Оана Цою повідомила в п'ятницю, що викликала посла Російської Фед] (uk: Президент Румунії скликав Раду нацбезпеки через влучання дрона у Галаці, в МЗС в)
      Очільниця МЗС Румунії Оана Цою повідомила в п'ятницю, що викликала посла Російської Федерації, щоб повідомити йому про заходи, яких вживатиме Румунія на дипломатичному рівні після того, як російський безпілотник влучив у
  - (2026-05-29) [TITLE: У Румунії пояснили, чому не збили російський дрон, який врізався в житловий будинок | LEDE: Причиною того, що у румунському місті Галац не збили російський дрон, стали брак часу та обмеження, в] (uk: У Румунії пояснили, чому не збили російський дрон, який врізався в житловий буди)
      Причиною того, що у румунському місті Галац не збили російський дрон, стали брак часу та обмеження, в умовах яких змушена працювати армія країни, заявив представник Міноброни Румунії.

### Ukraine Theater (total-war monitoring) — 190 new of 363 total
  - (2026-05-29) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-28) [FIRMS] thermal anomaly 45.259, 31.671 (FRP 5.68 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 0941Z, FRP 5.68 MW
  - (2026-05-28) [FIRMS] thermal anomaly 47.860, 33.447 (FRP 2.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 0941Z, FRP 2.89 MW
  - (2026-05-28) [FIRMS] thermal anomaly 45.257, 31.677 (FRP 5.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 5.84 MW
  - (2026-05-28) [FIRMS] thermal anomaly 45.257, 31.671 (FRP 5.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 5.84 MW
  - (2026-05-28) [FIRMS] thermal anomaly 44.204, 22.535 (FRP 2.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 2.61 MW
  - (2026-05-28) [FIRMS] thermal anomaly 45.356, 30.904 (FRP 2.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 2.73 MW
  - (2026-05-28) [FIRMS] thermal anomaly 46.333, 31.864 (FRP 2.31 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 2.31 MW

### Paper Trading Scorecard — 40 new of 151 total
  - (2026-05-29) [Polymarket] Will Sadegh Mahsouli be head of state in Iran end of 2026?
      This market will resolve to the individual who de facto holds and exercises the powers of the head of state of the Islamic Republic of Iran on December 31, 2026 at 12:00 PM ET.

For the purposes of this market, “de facto
  - (2026-05-29) [Polymarket] Will David Njoku play for Tampa Bay Buccaneers in 2026-27?
      This market will resolve to the next team David Njoku officially joins by August 31, 2026, 11:59 PM ET.

If David Njoku does not officially join a new team by August 31, 2026, 11:59 PM ET, this market will resolve to “Ot
  - (2026-05-29) [Polymarket] Will Butch Ware win the California Governor Election in 2026?
      This market will resolve to according to the candidate who wins the 2026 California gubernatorial election currently scheduled for November 3, 2026.

If the results of the election are not confirmed by July 31, 2027, thi
  - (2026-05-29) [Polymarket] Will Discord have the highest IPO Market Cap 2026?
      This market will resolve to the company that achieves the highest market capitalization in U.S. dollars based on the official closing price on its first trading day in 2026.

This market will resolve to a company that co
  - (2026-05-29) [Polymarket] Will S&P 500 (SPY) hit (LOW) $710 in May?
      This market will resolve to "Yes" if, at any point during May 2026, any 1-minute candle for S&P 500 (SPY) has a final "Low" price equal to or below the listed price. Otherwise, this market will resolve to "No".

Only pri
  - (2026-05-29) [Polymarket] Will Spencer Pratt finish first in the first round of the 2026 Los Angeles mayoral election?
      The 2026 Los Angeles mayoral election will be held on June 2, 2026, to elect the mayor of Los Angeles, California. If no candidate receives a majority of the vote, a runoff election will be held on November 3, 2026.

Thi
  - (2026-05-29) [Polymarket] Will Google have the best AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is checked
  - (2026-05-29) [Polymarket] Will Paloma Valencia win the 1st round of the 2026 Colombian presidential election?
      Colombia's presidential elections are scheduled for May 31, 2026, and a second round (if required) on June 21, 2026, in case no candidate secures more than 50% of the valid votes in the first round.

This market will res

### U.S. Weather + Severe / Climate Outlooks — 99 new of 102 total
  - (2026-05-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-29) [Severe] Flash Flood Warning: Flash Flood Warning issued May 29 at 5:31AM CDT until May 29 at 8:30AM CDT by NWS Little Rock AR
      FFWLZK

The National Weather Service in Little Rock has issued a

* Flash Flood Warning for...
West Central Perry County in central Arkansas...
Southwestern Pope County in central Arkansas...
Central Yell County in centr
  - (2026-05-29) [Unknown] Hydrologic Outlook: Hydrologic Outlook issued May 29 at 4:25AM MDT by NWS Great Falls MT
      ESFTFX

What: Widespread heavy rainfall Saturday into Monday.

Where: Mostly the western portion of North Central MT.

Timing: The heavier rainfall will begin on Saturday and then
diminish on Monday. Rainfall rates of ar
  - (2026-05-29) [Moderate] Rip Current Statement: Rip Current Statement issued May 29 at 5:18AM CDT until May 30 at 6:00AM CDT by NWS Mobile AL
      * WHAT...Dangerous rip currents.

* WHERE...In Alabama, Mobile Coastal and Baldwin Coastal
Counties. In Florida, Escambia Coastal, Santa Rosa Coastal and
Okaloosa Coastal Counties.

* WHEN...Through late tonight.

* IMPA
  - (2026-05-29) [Moderate] Heat Advisory: Heat Advisory issued May 29 at 4:02AM MDT until May 29 at 6:00PM MDT by NWS Glasgow MT
      * WHAT...Temperatures in the 90s.

* WHERE...Daniels, Dawson, Eastern Roosevelt, Northern Phillips,
Northern Valley, Prairie, Richland, Sheridan, Western Roosevelt,
and Wibaux Counties.

* WHEN...Until 6 PM MDT this even
  - (2026-05-29) [Moderate] Heat Advisory: Heat Advisory issued May 29 at 4:02AM MDT until May 29 at 6:00PM MDT by NWS Glasgow MT
      * WHAT...Temperatures in the mid 90s.

* WHERE...Central and Southeast Phillips, Central and Southern
Valley, Garfield, and McCone Counties.

* WHEN...Until 6 PM MDT this evening.

* IMPACTS...Hot temperatures and high h
  - (2026-05-29) [Moderate] Special Weather Statement: Special Weather Statement issued May 29 at 5:45AM EDT by NWS Charleston SC
      A cold front is expected to push south over the South Carolina
Lowcountry this morning. As the front approaches, fog should
gradually develop across portions of the Lowcountry and southeast
Georgia early this morning. Th
  - (2026-05-29) [Severe] Red Flag Warning: Red Flag Warning issued May 29 at 3:41AM MDT until May 29 at 8:00PM MDT by NWS Albuquerque NM
      ...RED FLAG WARNING REMAINS IN EFFECT FROM NOON TODAY TO 8 PM MDT
THIS EVENING DUE TO STRONG WINDS AND LOW RELATIVE HUMIDITY FOR THE
NORTHWEST PLATEAU, WEST CENTRAL MOUNTAINS, AND WEST CENTRAL BASIN
AND RANGE...

.Strong

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 18 new of 96 total
  - (2026-05-28) [OFAC] Iran-related Designations; Issuance of Russia-related General License and Amended Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1JaWJWcmlkbmQ2NU5oRnlxRkx1blBweGRaWW55dDdfWWk1d2ZONTY5N3FKOEg4UGJOVEZPZmk3czBQT2s1TWpMTjBzTUo2MXpPZGtoMFF3Ul9tRzhJcWg0V3RB?oc=5" target="_blank">Iran-related De
  - (2026-05-28) [OFAC] Designations Removals - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE42SnA2VXlwRlY1bEFUcml3VW0yY3g0MW9qd2dLZC15Yjk5bHZVTlRPRkp1eXBudDZGUWE5X3RSQ0czYmc5ZGNwWFFSWGxwR3dHNjh0ckhkWlFZWWVNUGc?oc=5" target="_blank">Designations Removal
  - (2026-05-28) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFBiSUxCVkxFTVQzeHkybjNQTW5HVERKWjFkMGVrUTQ4UW1uVHlGc2xSZ1ZadlFnWm9FZ0ZaNnZIT1BzbEJjdExFZ2tsYXRiZk54akJkTG1JQXVSMnpQR1AtNEJfbkU?oc=5" target="_blank">OFFICE OF FO
  - (2026-05-29) [USASpending] $48,063,763,681 → LOCKHEED MARTIN CORP: 
      Agency: Department of Energy.  Description: 
  - (2026-05-29) [USASpending] $14,878,345,025 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR
  - (2026-05-29) [USASpending] $7,595,339,605 → MISSION SUPPORT & TEST SERVICES LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003624 TO THE MISSION S
      Agency: Department of Energy.  Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003624 TO THE MISSION SUPPORT AND TEST SERVICES LLC (MSTS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY NATIONAL NUCLEAR SE
  - (2026-05-29) [USASpending] $4,430,784,857 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS.  FIRST STAGE WI
      Agency: National Aeronautics and Space Administration.  Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS.  FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOL
  - (2026-05-29) [USASpending] $3,088,721,030 → LEIDOS, INC.: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STA
      Agency: National Science Foundation.  Description: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STATES ANTARCTIC PROGRAM

### Congressional STOCK Act Trades (House + Senate) — 0 new of 1 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 9 new of 30 total
  - (2026-05-28) [SCOTUS] Fernandez v. United States
  - (2026-05-28) [SCOTUS] Flowers Foods, Inc. v. Brock
  - (2026-05-28) [SCOTUS] Pitchford v. Cain
  - (2026-05-28) [SCOTUS] Rutherford v. United States
  - (2026-05-28) [CA1] Courtemanche v. Noble
  - (2026-05-28) [CA1] USA, ex rel. Solano v. Barton Associates, Inc.
  - (2026-05-28) [CA1] United States v. Johnson
  - (2026-05-28) [CA3] SLT Imports Inc v. SAR Transport Systems Pvt Ltd

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-29) [Xiang Bing] Form 4 (Reporting)
      filed 2026-05-29 10:37 UTC · role: Reporting — Filed: 2026-05-29 AccNo: 0001493152-26-025711 Size: 5 KB
  - (2026-05-29) [FinVolution Group] Form 4 (Issuer)
      filed 2026-05-29 10:37 UTC · role: Issuer — Filed: 2026-05-29 AccNo: 0001493152-26-025711 Size: 5 KB
  - (2026-05-29) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-05-29 10:28 UTC — Filed: 2026-05-29 AccNo: 0001918704-26-014603 Size: 553 KB
  - (2026-05-29) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-05-29 10:28 UTC — Filed: 2026-05-29 AccNo: 0001918704-26-014603 Size: 553 KB
  - (2026-05-29) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-05-29 10:24 UTC — Filed: 2026-05-29 AccNo: 0001918704-26-014602 Size: 747 KB
  - (2026-05-29) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-05-29 10:24 UTC — Filed: 2026-05-29 AccNo: 0001918704-26-014602 Size: 747 KB
  - (2026-05-29) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-29 10:21 UTC — Filed: 2026-05-29 AccNo: 0001213900-26-062410 Size: 61 KB
  - (2026-05-29) [Regencell Bioscience Holdings Ltd] Form 4 (Issuer)
      filed 2026-05-29 10:20 UTC · role: Issuer — Filed: 2026-05-29 AccNo: 0001213900-26-062409 Size: 6 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 6 new of 27 total
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-29) [Malaysia] Russian drone hits Romanian apartment building , says Bucharest
      domain: freemalaysiatoday.com · language: English · tone: 
  - (2026-05-29) [United States] Hantavirus - exposed cruise passengers may return home soon
      domain: wjcl.com · language: English · tone: 
  - (2026-05-29) [United Kingdom] NATO hits out after warplanes scrambled as Russian drone hits Romania
      domain: dailyrecord.co.uk · language: English · tone: 
  - (2026-05-29) [United States] TSXV : OYL Forum Post | 23minus7 - 37012981 | CONGRATS ! 
      domain: stockhouse.com · language: English · tone: 
  - (2026-05-29) [United States] Former AG Pam Bondi to testify before Congress over handling of the Epstein files
      domain: klcc.org · language: English · tone: 
  - (2026-05-29) [India] Assam govt announces  Mission 2 Lakh Govt Job to boost employment in next five years
      domain: aninews.in · language: English · tone: 
  - (2026-05-29) [United Kingdom] Britain heatwave - filled weather future laid bare – from 43c scorchers to flash floods
      domain: dailystar.co.uk · language: English · tone: 
  - (2026-05-29) [United Kingdom] Meta Ramsay : the spy who could have been MI6 first female  C  
      domain: theargus.co.uk · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 22 new of 22 total
  - (2026-05-29) SAMU06 (France)
      icao24: 39c901 · position: (43.7244, 7.2841) · alt: 60m · 24km/h
  - (2026-05-29) GAF102 (Germany)
      icao24: 3ea048 · position: (51.6221, 12.6212) · alt: 563m · 462km/h
  - (2026-05-29) CFC2931 (Canada)
      icao24: c2b585 · position: (38.3205, -7.747) · alt: 4244m · 411km/h
  - (2026-05-29) JAF1PJ (Belgium)
      icao24: 44d1ba · position: (43.9283, 1.1977) · alt: 12192m · 754km/h
  - (2026-05-29) JAF3NE (Belgium)
      on ground · 0km/h
  - (2026-05-29) JAF11G (Belgium)
      icao24: 44d1b3 · position: (45.2697, 18.0729) · alt: 11582m · 767km/h
  - (2026-05-29) GAF600 (Germany)
      icao24: 3f7b3c · position: (52.5399, 13.7511) · alt: 1173m · 442km/h
  - (2026-05-29) RCH242 (United States)
      icao24: ae07f6 · position: (53.2342, 2.2738) · alt: 10363m · 760km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 0 new of 15 total
  (no new items today)

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-05-29) Will the US officially declare war on Venezuela by June 30, 2026?
      yes price: 1% · 24h volume: $1,986,420 · resolves 2025-12-31
  - (2026-05-29) LoL: Dplus KIA vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 100% · 24h volume: $1,576,233 · resolves 2026-05-29
  - (2026-05-29) Roland Garros ATP: Nuno Borges vs Andrey Rublev
      yes price: 28% · 24h volume: $1,527,435 · resolves 2026-06-04
  - (2026-05-29) US x Iran permanent peace deal by June 7, 2026?
      yes price: 20% · 24h volume: $1,354,153 · resolves 2026-06-07
  - (2026-05-29) Will Croatia win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,319,400 · resolves 2026-07-20
  - (2026-05-29) Iran closes its airspace by May 27?
      yes price: 0% · 24h volume: $952,911 · resolves 2026-05-27
  - (2026-05-29) Will the US confirm that aliens exist by May 31?
      yes price: 0% · 24h volume: $912,262 · resolves 2026-05-31
  - (2026-05-29) LoL: JD Gaming vs ThunderTalk Gaming (BO5) - LPL Playoffs
      yes price: 100% · 24h volume: $904,725 · resolves 2026-05-29

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-29) [Marginal Revolution] Are we undermeasuring inflation for lower earners?
      We document a new source of fluctuations in inflation inequality. When the cost of upstream inputs rises, varieties within a product category tend to have similar absolute price increases. However, the same absolute pric
  - (2026-05-29) [Marginal Revolution] How Much Has Shale Gas Saved U.S. Consumers?
      It may seem like a distant memory now, but as of the mid-2000s, U.S. natural gas production had been flat for a decade, and the U.S. was importing liquefied natural gas (LNG), with plans to import much more. Then shale g
  - (2026-05-28) [Marginal Revolution] AI in gdp
      Quality-adjusted AI production in the United States grew at over 2,000 percent per year in 2024 and 2025, driven by three compounding forces: expanding data-center capacity, hardware efficiency gains, and—the largest of 
  - (2026-05-28) [Conversable Economist] Simone Weil on Education and Attention
      I&#8217;ve written a number of times in this space about the &#8220;attention economy&#8221; (for example, here, here, and here). When people consume content on a screen, we are in effect selling our attention. Decisions

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=34, 7d-median=25, 14d-median=25; carrying terms: persons, potential, waters, directive, proposing, temporary, regulatory, required, control, affected, unless, directives
- state_bills: today=323, 7d-median=0, 14d-median=0
- state_news: today=728, 7d-median=722, 14d-median=722
- local_news: today=229, 7d-median=246, 14d-median=246
- foreign_news: today=876, 7d-median=876, 14d-median=876
- chinese_internal: today=281, 7d-median=281, 14d-median=281
- russian_internal: today=898, 7d-median=1021, 14d-median=1021
- ukrainian_internal: today=121, 7d-median=122, 14d-median=122
- ukraine_theater: today=363, 7d-median=365, 14d-median=365
- paper_bets: today=151, 7d-median=141, 14d-median=141
- weather: today=102, 7d-median=112, 14d-median=112
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=96, 7d-median=95, 14d-median=95
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: concepcion, havana, employee, cruises, docks, solutions, garden, morales, transport, royal, mahmoud, smith
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: booker, house, congress, cortez, scott, krishnamoorthi, ossoff, committee, robert, balam, rarig, angels
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: kingdom, language, domain, english, cancer, india, israel
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=22, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=15, 7d-median=16, 14d-median=16; carrying terms: product, overflow, directory, validation, windows, vulnerability, acrobat, premise, vendor, server, buffer, based
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: traffic, agreement, returns, regime, peace, continue, ceasefire, volume, price, hormuz, world, extension
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: production, policy, marginalrevolution, story, https, conversable, class, marginal, economist, revolution, recipients
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] ECB press: Financial stability vulnerabilities remain elevated as geoeconomic shock unfolds
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*