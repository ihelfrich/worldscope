# WORLDSCOPE morning brief — 2026-05-29

## Headline
3673 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 34 new of 34 total
  - (2026-05-29) Regulation for Federal Financial Assistance
      The Office of Management and Budget (OMB) proposes to revise the Guidance for Federal Financial Assistance to improve government- wide policies and requirements related to the management of grants, cooperative agreements
  - (2026-05-29) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Angling Category Retention Limit Adjustment
      NMFS is adjusting the Angling category Atlantic bluefin tuna (BFT) daily retention limit from the default of one school, large school, or small medium BFT to: two BFT per vessel per day/trip measuring 27 inches (68.5 cm)
  - (2026-05-29) Airworthiness Directives; Goodrich Cabin Attendant Seats
      The FAA is adopting a new airworthiness directive (AD) for Goodrich cabin attendant seats installed on Airbus SAS Model A330-200 series, A330-200 Freighter series, A330-300 series, A330-743L, A330- 841, A330-941, A340-20
  - (2026-05-29) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for all The Boeing Company Model 747-100, -100B, -100B SUD, -200B, -200C, - 200F, -300, -400, -400D, -400F, 747SP, and 747SR series airplanes. This AD was prompted b
  - (2026-05-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A330-200, -200 Freighter, -300, -800, and -900 series airplanes. This AD was prompted by the identification of an incorrect shot peening
  - (2026-05-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A318 series airplanes; Model A319-111, -112, - 113, -114, -115, -131, -132, and -133 airplanes; Model A320-211, -212, -214, -216, -231, 
  - (2026-05-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for all Airbus SAS Model A319 series airplanes; Model A320 series airplanes; and Model A321-111, -112, -131, -211, -212, -213, -231, -232, -251N, - 252N, -253N, -271
  - (2026-05-29) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A318-111, -112, and -122 airplanes; Model A319-111, -112, -113, -114, -115, -131, -132, and -133 airplanes; Model A320-211, -212, -214, 

### State Legislative Action — 155 new of 155 total
  - (2026-05-29) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contributions for public school funding; relating to municipal property 
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut
  - (2026-05-29) [Alaska HB 381] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of revenue from the alternative volumetric tax; and providing for an 
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re
  - (2026-05-29) [Alaska HB 24] An Act relating to aggravating factors considered at sentencing.
      An Act relating to aggravating factors considered at sentencing.
  - (2026-05-29) [Alaska SB 200] An Act relating to service areas; relating to municipal assessments of farm or agricultural land; and providing for an effective date.
      An Act relating to service areas; relating to municipal assessments of farm or agricultural land; and providing for an effective date.
  - (2026-05-29) [Alaska SB 24] An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco, a product containing nicotine, or an electronic smoking product; relating to the tobacco use educat
      An Act relating to tobacco, tobacco products, electronic smoking products, nicotine, and products containing nicotine; raising the minimum age to purchase, exchange, or possess tobacco, a product containing nicotine, or 
  - (2026-05-29) [Alaska HB 217] An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.
      An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.
  - (2026-05-29) [Alaska SB 164] An Act eliminating deductions for the remittance of the motor fuel tax, tobacco taxes, and tire fees; relating to discounts on cigarette stamps; and providing for an effective date.
      An Act eliminating deductions for the remittance of the motor fuel tax, tobacco taxes, and tire fees; relating to discounts on cigarette stamps; and providing for an effective date.
  - (2026-05-29) [Alaska SB 272] An Act relating to the electronic health information exchange system; and providing for an effective date.
      An Act relating to the electronic health information exchange system; and providing for an effective date.

### State-Level News — 547 new of 866 total
  - (2026-05-29) [Alabama] Writ of Election Senate Districts 25 & 26
      Download
  - (2026-05-29) [Alabama] Senate Districts 25 and 26 Special Primary Election Proclamation
      Download
  - (2026-05-29) [Alabama] Strong Families Month
      Download
  - (2026-05-29) [Alabama] Governor Ivey Celebrates Another Court Victory in State’s Redistricting Battle, Calls Special Primary Election for Alabama-Drawn State Senate Map
      MONTGOMERY – Governor Kay Ivey on Friday celebrated the 11th Circuit Court of Appeals’ decision to allow for the use of the 2021 Alabama-drawn State Senate map. “Alabama continues winning fair and square in our redistric
  - (2026-05-28) [Alabama] Governor Ivey Encourages Alabama Small Businesses to Pitch Big for America 250
      MONTGOMERY – Governor Kay Ivey on Thursday is encouraging eligible Alabama small businesses and entrepreneurs to submit a pitch for the U.S. Small Business Administration’s (SBA) national “Freedom 250” Patriot Pitch Comp
  - (2026-05-29) [California] Una nueva ley de California prohíbe a las fuerzas del orden interferir en las elecciones estatales
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524_Election-Day-SD_AH_CM_23.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size w
  - (2026-05-29) [California] ‘Sentía que no estaba aprendiendo’: Los estudiantes de colegios comunitarios tienen dificultades con la educación en línea
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-29) [California] Can you even say no when your hospital asks you to sign a waiver?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/071625-Doctor-Paperwork-Tablet_CM_01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-s

### Local News: St. Louis + Atlanta — 229 new of 252 total
  - (2026-05-29) [St. Louis] Longtime St. Charles prom and wedding reception hall demolished for multiyear redevelopment
  - (2026-05-29) [St. Louis] St. Louis leaders hope to avoid escalation over police budget after commission ignores subpoena
  - (2026-05-29) [St. Louis] The legal decisions shaping the future of Missouri elections and local police
  - (2026-05-29) [St. Louis] Man charged with scamming tornado victims seeking home repairs in north St. Louis
  - (2026-05-29) [St. Louis] The story behind the proposed Gateway Arch National Park expansion into Illinois
  - (2026-05-29) [St. Louis] St. Louis nonprofit hopes fund that gave $3,000 gift cards to tornado victims can be replicated
  - (2026-05-29) [St. Louis] A tuneful 'The Tempest' in Forest Park sings a Shakespearean song of rage and redemption
  - (2026-05-29) [St. Louis] Illinois Lt. Gov. candidate Mitchell says he’s ready to step in if Pritzker leaves office

### International News + Multilateral Institutions — 693 new of 905 total
  - (2026-05-29) [Global] 'Poison seller' who sold toxic chemicals online to people across world admits aiding suicides
      Kenneth Law admitted charges relating to Canadian victims - but families say he should also be charged in the UK over 79 deaths in Britain.
  - (2026-05-29) [Global] Nato and EU condemn Russia after drone hits Romanian residential block
      Romania says the Russian drone was likely hit over Ukraine by its air defences and altered its trajectory.
  - (2026-05-29) [Global] 'Controversial' North Korean invasion setting for next Call of Duty game
      Developer Infinity Ward said the game will be "grounded in the military authenticity" the series is known for.
  - (2026-05-29) [Global] Former US attorney general Pam Bondi defends her handling of Epstein files in congressional probe
      The testimony comes about a month after America's top prosecutor was ousted by US President Donald Trump.
  - (2026-05-29) [Global] Eight students arrested in Kenya after suspected deadly school arson attack
      Sixteen pupils died in the fire that ripped through a dormitory while they were asleep.
  - (2026-05-29) [Global] Exploding rocket casts doubts over Nasa's Moon plans
      Explosion of Blue Origin rocket is a setback for the company and for Nasa's Moon plans.
  - (2026-05-29) [Global] US and Iran 'very close' to deal but 'not there yet', Vance says
      US officials earlier told the BBC that the framework of a ceasefire extension deal had been agreed, pending the approval of Trump and Iran's leadership.
  - (2026-05-29) [Global] Ex-head monk of China's 'kung fu temple' jailed for embezzlement
      Shi Yongxin is sentenced to 24 years in prison for embezzlement and bribery.

### Chinese Internal News — 244 new of 284 total
  - (2026-05-29) [TITLE: 神舟二十一号航天员乘组返回任务取得圆满成功 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE13NldjQ1NrR3VYd3kwWWxERjItNzhKUDBhSmc4aVhIbEItTm9nanRncnRkZGw0ZUNzVWx5dm5HQ0VqWjByVmx4S3dZVz] (zh: 神舟二十一号航天员乘组返回任务取得圆满成功 - 人民网-图片频道)
      <a href="https://news.google.com/rss/articles/CBMiaEFVX3lxTE13NldjQ1NrR3VYd3kwWWxERjItNzhKUDBhSmc4aVhIbEItTm9nanRncnRkZGw0ZUNzVWx5dm5HQ0VqWjByVmx4S3dZVzFnWmFFV3d1b3N4d3pFeGtWU2VxQVlfbmZYdTNv?oc=5" target="_blank">神舟二十一号航
  - (2026-05-29) [TITLE: 聚力打造京津冀机器人产业高地 天津市机器人产业技术联盟成立 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBkcW9LcHk0UXdsYlRNLUFwc1B1NUpwemhsVlNpNmdRZjNCbTVIM1BDaFFTXzhDeG5UU1NYR016eDBaeHFBUHU5WUh] (zh: 聚力打造京津冀机器人产业高地 天津市机器人产业技术联盟成立 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBkcW9LcHk0UXdsYlRNLUFwc1B1NUpwemhsVlNpNmdRZjNCbTVIM1BDaFFTXzhDeG5UU1NYR016eDBaeHFBUHU5WUhwT2ZjSE81MUVQYXl2NjdpT1dsNi03QlNKa0RfOENyYkE?oc=5" target="_blank">聚力打造
  - (2026-05-29) [TITLE: 新疆吐鲁番托克逊县发生5.0级地震 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1VNW1xbHRGaVZuTUhQeXpONV9USDZOdXNvZ2h2cjE3dGFDQ2RyeEg4Ujgxc2NoQjBTenVhRURlZWwtaFRLQUNBMkhnZDE5TlQ0bmh] (zh: 新疆吐鲁番托克逊县发生5.0级地震 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE1VNW1xbHRGaVZuTUhQeXpONV9USDZOdXNvZ2h2cjE3dGFDQ2RyeEg4Ujgxc2NoQjBTenVhRURlZWwtaFRLQUNBMkhnZDE5TlQ0bmhkczZFY2x1R01HX0wxOGRUbkFwMVY5cW53VlpB?oc=5" target="_blank"
  - (2026-05-29) [TITLE: 以色列称与联合国秘书长“不再联系”--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE10ZGVkcTR6ZXgwdzF4Vi1sc1ZpcEtDVzItbV9GVTFDdUd4SjBSNUVoRzFZWk1XSFFEYXRlUTRxZ0F2WHdfSjdhNHZVWmMtWWl] (zh: 以色列称与联合国秘书长“不再联系”--国际 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE10ZGVkcTR6ZXgwdzF4Vi1sc1ZpcEtDVzItbV9GVTFDdUd4SjBSNUVoRzFZWk1XSFFEYXRlUTRxZ0F2WHdfSjdhNHZVWmMtWWlsejdhdFlTbERuWEd3bUVrX3drdE9icGJvZmcw?oc=5" target="_blank">以色列
  - (2026-05-29) [TITLE: 中央网信办专项整治恶意炒作涉企信息 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTFBFcjJWdk0xZkRNaG1YY191cEIyVi1DX2xHQWFTSFMwV0NWRllWMlRRamVSeFk4enoyaWJTdG85WEJ3ckVL] (zh: 中央网信办专项整治恶意炒作涉企信息 - politics.people.com.cn)
      <a href="https://news.google.com/rss/articles/CBMickFVX3lxTFBFcjJWdk0xZkRNaG1YY191cEIyVi1DX2xHQWFTSFMwV0NWRllWMlRRamVSeFk4enoyaWJTdG85WEJ3ckVLOFBwM3RCT09BbVBYeXdqLVk4dlhJN3EwOUtvWVdqVHVUQjhMdGo3ai1ob0V6dw?oc=5" target="_
  - (2026-05-29) [TITLE: 四川省成立调查指导组督导稻城亚丁景区摆渡车问题整改 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE02c3FBTE5BMlBLTUhPY2RITGZpSzNsWUpUbGgyUGw4dWJza3pGc25Hd1c5R0p3QkRTU0RkTVdOZ1d2N3QwRXNtRU5ZVlR] (zh: 四川省成立调查指导组督导稻城亚丁景区摆渡车问题整改 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE02c3FBTE5BMlBLTUhPY2RITGZpSzNsWUpUbGgyUGw4dWJza3pGc25Hd1c5R0p3QkRTU0RkTVdOZ1d2N3QwRXNtRU5ZVlRxM243ZHNJSkdyU3FWdTZXeEJHM2FUZ044Q0lFd1RRY3pR?oc=5" target="_blank"
  - (2026-05-29) [TITLE: 以军打击黎南等地130多个真主党目标--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE4wY0tRMjVnMFdRRmNiOUpSSGdDV2QtU2oxbkJUTHJLRkNMcVFEWnV3Rm5PdlNHTk1OSWJxMGJIR3pQbWw0bmFFQVc3ZmlyaU] (zh: 以军打击黎南等地130多个真主党目标--国际 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE4wY0tRMjVnMFdRRmNiOUpSSGdDV2QtU2oxbkJUTHJLRkNMcVFEWnV3Rm5PdlNHTk1OSWJxMGJIR3pQbWw0bmFFQVc3ZmlyaUd5VlBBdFBxVjdaV2FneW1mQTdCVEdSek00dmFv?oc=5" target="_blank">以军打
  - (2026-05-29) [TITLE: 美蓝色起源公司重型运载火箭测试时爆炸--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1KWW4xUXZHU0NVQzZ2MnFoZV8tWE1fbFNzVDNZeElCWEtiR0tVanVoTklaZWhBVktYa2F4MUZaWHV3TWViTnBVZUZUY0d6WF] (zh: 美蓝色起源公司重型运载火箭测试时爆炸--国际 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1KWW4xUXZHU0NVQzZ2MnFoZV8tWE1fbFNzVDNZeElCWEtiR0tVanVoTklaZWhBVktYa2F4MUZaWHV3TWViTnBVZUZUY0d6WFZuUkFzSTQ1NlRocW5abld6VDZPUEVWYkVYWnRV?oc=5" target="_blank">美蓝色

### Russian Internal News (state + in-exile) — 810 new of 1155 total
  - (2026-05-29) [TITLE: Зеленский предупредил, что Россия готовит новый масштабный удар по Украине | LEDE: <p>Украинская разведка получила информацию о том, что Россия готовит новый массированный удар, сообщил президе] (ru: Зеленский предупредил, что Россия готовит новый масштабный удар по Украине)
      <p>Украинская разведка получила информацию о том, что Россия готовит новый массированный удар, сообщил президент Украины Владимир Зеленский в обращении 29 мая.<p>
  - (2026-05-29) [TITLE: В Крыму ограничили продажу топлива после ударов ВСУ | LEDE: <p>Власти аннексированного Крыма объявили, что с 30 мая ограничат продажу бензина АИ-95 — не более 20 литров «в одни руки один раз в ] (ru: В Крыму ограничили продажу топлива после ударов ВСУ)
      <p>Власти аннексированного Крыма объявили, что с 30 мая ограничат продажу бензина АИ-95 — не более 20 литров «в одни руки один раз в сутки».<p>
  - (2026-05-29) [TITLE: Российского военного обвинили в подделке картин и скульптур Эрнста Неизвестного. С обыском пришли в Третьяковскую галерею | LEDE: <p>Следственный комитет России обвинил российского военного Мак] (ru: Российского военного обвинили в подделке картин и скульптур Эрнста Неизвестного.)
      <p>Следственный комитет России обвинил российского военного Максима Кошкарева в том, что он участвовал в подделке картин и скульптур Эрнста Неизвестного.<p>
  - (2026-05-29) [TITLE: В РГГУ открыли вакансию биографа рода Путиных | LEDE: <p>Российский государственный гуманитарный университет (РГГУ) ищет научного сотрудника, который проведет исследование о роде президента РФ ] (ru: В РГГУ открыли вакансию биографа рода Путиных)
      <p>Российский государственный гуманитарный университет (РГГУ) ищет научного сотрудника, который проведет исследование о роде президента РФ Владимира Путина.<p>
  - (2026-05-29) [TITLE: «У России есть средства сровнять с землей всех». Путин съездил в Казахстан — и оттуда пригрозил Армении и вообще всем. А заодно процитировал Геббельса (но на самом деле Гитлера) | LEDE: <p>Межд] (ru: «У России есть средства сровнять с землей всех». Путин съездил в Казахстан — и о)
      <p>Между Россией и Арменией особые отношения. Какие бы решения ни принял Ереван по сближению с Западом, это их не испортит. Но в случае с Евразийским союзом речь идет о чисто экономических субстанциях. Если Армения начне
  - (2026-05-29) [TITLE: По инициативе омбудсмена Львовой-Беловой (ее разыскивает Международный уголовный суд) сняли пропагандистский фильм о том, как украинских детей возят на «интеграционные смены» в российские лагер] (ru: По инициативе омбудсмена Львовой-Беловой (ее разыскивает Международный уголовный)
      <p>В России вышел пропагандистский документальный фильм «СВОи дети». В нем рассказывается об украинских детях, которых возили на «интеграционные смены» в российские оздоровительные лагеря в рамках молодежного проекта «По
  - (2026-05-29) [TITLE: Путин заявил, что дрон, попавший в жилой дом в Румынии, мог быть украинским | LEDE: <p>Президент РФ Владимир Путин допустил, что дрон, который залетел в Румынию в ночь на 29 мая и попал в жилой] (ru: Путин заявил, что дрон, попавший в жилой дом в Румынии, мог быть украинским)
      <p>Президент РФ Владимир Путин допустил, что дрон, который залетел в Румынию в ночь на 29 мая и попал в жилой дом, мог быть украинским.<p>
  - (2026-05-29) [TITLE: Россия, Беларусь, Казахстан и Кыргызстан потребовали от Армении провести референдум — и выбрать между Европейским и Евразийским союзами | LEDE: <p>Власти России, Беларуси, Казахстана и Кыргызст] (ru: Россия, Беларусь, Казахстан и Кыргызстан потребовали от Армении провести референ)
      <p>Власти России, Беларуси, Казахстана и Кыргызстана потребовали от Армении провести референдум и решить вопрос о том, остается ли страна в Евразийском экономическом союзе (ЕАЭС) или продолжает стремиться к вступлению в 

### Ukrainian Internal News (national + local Kyiv) — 84 new of 138 total
  - (2026-05-29) [TITLE: МЗС Румунії закликало НАТО прискорити поставки ППО через інцидент з дроном | LEDE: Міністерка закордонних справ Румунії Оана Цою заявила, що звернеться до НАТО з проханням пришвидшити постачанн] (uk: МЗС Румунії закликало НАТО прискорити поставки ППО через інцидент з дроном)
      Міністерка закордонних справ Румунії Оана Цою заявила, що звернеться до НАТО з проханням пришвидшити постачання засобів ППО на тлі інциденту з дроном, який влучив у багатоповерхівку у румунському місті Галац.
  - (2026-05-29) [TITLE: Генштаб повідомив про 228 бойових атак з початку доби | LEDE: Від початку доби 29 травня на фронті відбулося 228 бойових зіткнень.] (uk: Генштаб повідомив про 228 бойових атак з початку доби)
      Від початку доби 29 травня на фронті відбулося 228 бойових зіткнень.
  - (2026-05-29) [TITLE: Міноборони закликало українців не ігнорувати повітряні тривоги цими вихідними | LEDE: Українців просять дотримуватися безпеки під час сигналів повітряної тривоги, особливо в Києві.] (uk: Міноборони закликало українців не ігнорувати повітряні тривоги цими вихідними)
      Українців просять дотримуватися безпеки під час сигналів повітряної тривоги, особливо в Києві.
  - (2026-05-29) [TITLE: МЗС відповіло на гнів Польщі щодо перейменування підрозділу ССО на честь "Героїв УПА" | LEDE: У Міністерстві закордонних справ України прокоментували різку реакцію польських політиків і посадов] (uk: МЗС відповіло на гнів Польщі щодо перейменування підрозділу ССО на честь "Героїв)
      У Міністерстві закордонних справ України прокоментували різку реакцію польських політиків і посадовців на рішення президента Володимира Зеленського про присвоєння українському військовому підрозділу назви "Героїв УПА".
  - (2026-05-29) [TITLE: Дрон РФ, який влучив у багатоповерхівку в Румунії, переносив щонайменше 30 кг вибухівки | LEDE: Президент Румунії Нікушор Дан заявив, що слідчі оцінили, скільки кілограмів вибухівки переносив р] (uk: Дрон РФ, який влучив у багатоповерхівку в Румунії, переносив щонайменше 30 кг ви)
      Президент Румунії Нікушор Дан заявив, що слідчі оцінили, скільки кілограмів вибухівки переносив російський дрон, який влучив у багатоповерхівку в місті Галац.
  - (2026-05-29) [TITLE: Науседа рішуче засудив атаку російського дрона в Румунії | LEDE: Президент Литви Гітанас Науседа рішуче засудив атаку російського дрона на багатоквартирний будинок у місті Галац на сході Румуні] (uk: Науседа рішуче засудив атаку російського дрона в Румунії)
      Президент Литви Гітанас Науседа рішуче засудив атаку російського дрона на багатоквартирний будинок у місті Галац на сході Румунії.
  - (2026-05-29) [TITLE: Президент Румунії розповів про стан постраждалих внаслідок удару дроном по багатоповерхівці | LEDE: ] (uk: Президент Румунії розповів про стан постраждалих внаслідок удару дроном по багат)
  - (2026-05-29) [TITLE: Локдаун траси до Криму, США кидають Європу, Ядерні погрози Путіна – Кляті питання | LEDE: ] (uk: Локдаун траси до Криму, США кидають Європу, Ядерні погрози Путіна – Кляті питанн)

### Ukraine Theater (total-war monitoring) — 200 new of 367 total
  - (2026-05-29) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-28) [FIRMS] thermal anomaly 45.259, 31.671 (FRP 5.68 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 0941Z, FRP 5.68 MW
  - (2026-05-28) [FIRMS] thermal anomaly 47.860, 33.447 (FRP 2.89 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 0941Z, FRP 2.89 MW
  - (2026-05-28) [FIRMS] thermal anomaly 45.257, 31.677 (FRP 5.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 5.84 MW
  - (2026-05-28) [FIRMS] thermal anomaly 45.257, 31.671 (FRP 5.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 5.84 MW
  - (2026-05-28) [FIRMS] thermal anomaly 44.204, 22.535 (FRP 2.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 2.61 MW
  - (2026-05-28) [FIRMS] thermal anomaly 45.356, 30.904 (FRP 2.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 2.73 MW
  - (2026-05-28) [FIRMS] thermal anomaly 46.333, 31.864 (FRP 2.31 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-28 1119Z, FRP 2.31 MW

### Paper Trading Scorecard — 40 new of 143 total
  - (2026-05-29) [Polymarket] Will Tony Thurmond win the California Governor Election in 2026?
      This market will resolve to according to the candidate who wins the 2026 California gubernatorial election currently scheduled for November 3, 2026.

If the results of the election are not confirmed by July 31, 2027, thi
  - (2026-05-29) [Polymarket] Will the ECB announce a 25 bps decrease at the June 2026 meeting?
      This market will resolve to the amount of basis points the upper bound of the deposit facility rate is changed by versus the level it was prior to the European Central Bank's (ECB) June 2026 meeting.

If the deposit faci
  - (2026-05-29) [Polymarket] Will Butch Ware win the California Governor Election in 2026?
      This market will resolve to according to the candidate who wins the 2026 California gubernatorial election currently scheduled for November 3, 2026.

If the results of the election are not confirmed by July 31, 2027, thi
  - (2026-05-29) [Polymarket] Will Discord have the highest IPO Market Cap 2026?
      This market will resolve to the company that achieves the highest market capitalization in U.S. dollars based on the official closing price on its first trading day in 2026.

This market will resolve to a company that co
  - (2026-05-29) [Polymarket] Will S&P 500 (SPY) hit (LOW) $710 in May?
      This market will resolve to "Yes" if, at any point during May 2026, any 1-minute candle for S&P 500 (SPY) has a final "Low" price equal to or below the listed price. Otherwise, this market will resolve to "No".

Only pri
  - (2026-05-29) [Polymarket] Will Google have the best AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is checked
  - (2026-05-29) [Polymarket] Will Charlie Kirk win the Nobel Peace Prize in 2026?
      This market will resolve according to the winner of the 2026 Nobel Peace Prize, as announced by the Norwegian Nobel Committee.

If multiple listed individuals or entities jointly receive the prize, the market will resolv
  - (2026-05-29) [Kalshi] Russell Wilson: Retirement
      Russell Wilson

### U.S. Weather + Severe / Climate Outlooks — 124 new of 126 total
  - (2026-05-29) [Moderate] Special Weather Statement: Special Weather Statement issued May 29 at 3:11PM CDT by NWS Shreveport LA
      At 311 PM CDT, Doppler radar was tracking a strong thunderstorm 13
miles southwest of Brownsville-Bawcomville, moving east at 30 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IMPAC
  - (2026-05-29) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 29 at 4:09PM EDT until May 30 at 11:00AM EDT by NWS Buffalo NY
      * WHAT...Strong currents and dangerous swimming conditions.

* WHERE...Beaches of Wayne, Northern Cayuga, and Oswego counties.

* WHEN...Through Saturday morning.

* IMPACTS...Strong currents and dangerous swimming condi
  - (2026-05-29) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 29 at 4:09PM EDT until May 30 at 8:00AM EDT by NWS Buffalo NY
      * WHAT...Strong currents and dangerous swimming conditions.

* WHERE...Beaches of Chautauqua county.

* WHEN...Through Saturday morning.

* IMPACTS...Strong currents and dangerous swimming conditions.
  - (2026-05-29) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 29 at 4:09PM EDT until May 29 at 11:00PM EDT by NWS Buffalo NY
      * WHAT...Strong currents and dangerous swimming conditions.

* WHERE...Beaches of Jefferson county.

* WHEN...Until 11 PM EDT this evening.

* IMPACTS...Strong currents and dangerous swimming conditions.
  - (2026-05-29) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 29 at 4:09PM EDT until May 30 at 8:00AM EDT by NWS Buffalo NY
      * WHAT...Strong currents and dangerous swimming conditions.

* WHERE...Beaches of Monroe county.

* WHEN...Through Saturday morning.

* IMPACTS...Strong currents and dangerous swimming conditions.
  - (2026-05-29) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 29 at 4:09PM EDT until May 30 at 3:00AM EDT by NWS Buffalo NY
      * WHAT...Strong currents and dangerous swimming conditions.

* WHERE...Beaches of Orleans county.

* WHEN...Until 3 AM EDT Saturday.

* IMPACTS...Strong currents and dangerous swimming conditions.
  - (2026-05-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-29) [Moderate] Special Weather Statement: Special Weather Statement issued May 29 at 4:05PM EDT by NWS Jacksonville FL
      At 405 PM EDT, Doppler radar was tracking a strong thunderstorm over
Picolata, or 8 miles southeast of Green Cove Springs, moving
southeast at 20 mph.

HAZARD...Wind gusts around 40 mph, excessive cloud-to-ground
lightni

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 0 new of 79 total
  (no new items today)

### Government Action: Sanctions + Procurement + Foreign Agents — 18 new of 97 total
  - (2026-05-28) [OFAC] Iran-related Designations; Issuance of Russia-related General License and Amended Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1JaWJWcmlkbmQ2NU5oRnlxRkx1blBweGRaWW55dDdfWWk1d2ZONTY5N3FKOEg4UGJOVEZPZmk3czBQT2s1TWpMTjBzTUo2MXpPZGtoMFF3Ul9tRzhJcWg0V3RB?oc=5" target="_blank">Iran-related De
  - (2026-05-28) [OFAC] Designations Removals - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE42SnA2VXlwRlY1bEFUcml3VW0yY3g0MW9qd2dLZC15Yjk5bHZVTlRPRkp1eXBudDZGUWE5X3RSQ0czYmc5ZGNwWFFSWGxwR3dHNjh0ckhkWlFZWWVNUGc?oc=5" target="_blank">Designations Removal
  - (2026-05-28) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFBiSUxCVkxFTVQzeHkybjNQTW5HVERKWjFkMGVrUTQ4UW1uVHlGc2xSZ1ZadlFnWm9FZ0ZaNnZIT1BzbEJjdExFZ2tsYXRiZk54akJkTG1JQXVSMnpQR1AtNEJfbkU?oc=5" target="_blank">OFFICE OF FO
  - (2026-05-29) [USASpending] $48,063,763,681 → LOCKHEED MARTIN CORP: 
      Agency: Department of Energy.  Description: 
  - (2026-05-29) [USASpending] $14,878,345,025 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR
  - (2026-05-29) [USASpending] $7,595,339,605 → MISSION SUPPORT & TEST SERVICES LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003624 TO THE MISSION S
      Agency: Department of Energy.  Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003624 TO THE MISSION SUPPORT AND TEST SERVICES LLC (MSTS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY NATIONAL NUCLEAR SE
  - (2026-05-29) [USASpending] $4,430,784,857 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS.  FIRST STAGE WI
      Agency: National Aeronautics and Space Administration.  Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS.  FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOL
  - (2026-05-29) [USASpending] $3,088,721,030 → LEIDOS, INC.: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STA
      Agency: National Science Foundation.  Description: SCIENCE OPERATION AND MAINTENANCE SUPPORT FOR THE UNITED STATES ANTARCTIC PROGRAM

### Congressional STOCK Act Trades (House + Senate) — 64 new of 64 total
  - (2026-05-15) [House] David J. Taylor (R): Purchase PH ($1,001 - $15,000) (excess -3.5% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: PH (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase PH ($1,001 - $15,000) (excess -3.5% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: PH (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase MEDP ($1,001 - $15,000) (excess +5.0% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: MEDP (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclo
  - (2026-05-15) [House] David J. Taylor (R): Purchase MEDP ($1,001 - $15,000) (excess +5.0% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: MEDP (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclo
  - (2026-05-15) [House] David J. Taylor (R): Purchase HD ($1,001 - $15,000) (excess +5.6% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: HD (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase HD ($1,001 - $15,000) (excess +5.6% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: HD (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosu
  - (2026-05-15) [House] David J. Taylor (R): Purchase T ($1,001 - $15,000) (excess +0.7% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: T (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosur
  - (2026-05-15) [House] David J. Taylor (R): Sale AAPL ($1,001 - $15,000) (excess +1.6% vs SPY)
      Member: David J. Taylor (R, house).  BioGuide: T000490.  Asset: AAPL (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-15.  Disclosure date: 2026-05-28.  Excess return vs SPY since disclosure

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 10 new of 30 total
  - (2026-05-28) [SCOTUS] Fernandez v. United States
  - (2026-05-28) [SCOTUS] Flowers Foods, Inc. v. Brock
  - (2026-05-28) [SCOTUS] Pitchford v. Cain
  - (2026-05-28) [SCOTUS] Rutherford v. United States
  - (2026-05-28) [CA1] Courtemanche v. Noble
  - (2026-05-28) [CA1] USA, ex rel. Solano v. Barton Associates, Inc.
  - (2026-05-28) [CA1] United States v. Johnson
  - (2026-05-29) [CA3] Patria Laureano v. Attorney General United States of America

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-29) 40-17F2 - BNY Mellon Investment Funds VI (0001224568) (Subject)
      filed 2026-05-29 20:12 UTC — Filed: 2026-05-29 AccNo: 0001224568-26-000003 Size: 8 KB
  - (2026-05-29) [Marcon Rachel Barthelemy] Form 4 (Reporting)
      filed 2026-05-29 20:12 UTC · role: Reporting — Filed: 2026-05-29 AccNo: 0002066981-26-000002 Size: 4 KB
  - (2026-05-29) [Owens Corning] Form 4 (Issuer)
      filed 2026-05-29 20:12 UTC · role: Issuer — Filed: 2026-05-29 AccNo: 0002066981-26-000002 Size: 4 KB
  - (2026-05-29) [Videtto Emily Cavanagh] Form 4 (Reporting)
      filed 2026-05-29 20:12 UTC · role: Reporting — Filed: 2026-05-29 AccNo: 0000794619-26-000047 Size: 5 KB
  - (2026-05-29) [AMERICAN WOODMARK CORP] Form 4 (Issuer)
      filed 2026-05-29 20:12 UTC · role: Issuer — Filed: 2026-05-29 AccNo: 0000794619-26-000047 Size: 5 KB
  - (2026-05-29) 424B2 - GS Finance Corp. (0001419828) (Filer)
      filed 2026-05-29 20:12 UTC — Filed: 2026-05-29 AccNo: 0001193125-26-248295 Size: 797 KB
  - (2026-05-29) 424B2 - GOLDMAN SACHS GROUP INC (0000886982) (Filer)
      filed 2026-05-29 20:12 UTC — Filed: 2026-05-29 AccNo: 0001193125-26-248295 Size: 797 KB
  - (2026-05-29) [Silvent Karima] Form 4 (Reporting)
      filed 2026-05-29 20:12 UTC · role: Reporting — Filed: 2026-05-29 AccNo: 0001738950-26-000004 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 7 new of 27 total
  - (2026-05-29) [Top] COLLINS, SUSAN M. (REP, Senate ME): $14.93M raised
      cycle 2026 receipts $14.93M · disbursements $6.55M · net $+8.38M
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 16 total
  - (2026-05-29) CVE-2026-0257 · Palo Alto Networks PAN-OS: Palo Alto Networks PAN-OS Authentication Bypass Vulnerability
      vendor: Palo Alto Networks · product: PAN-OS · CISA remediation by 2026-06-01

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-29) Roland Garros ATP: Joao Fonseca vs Novak Djokovic
      yes price: 100% · 24h volume: $5,542,249 · resolves 2026-06-05
  - (2026-05-29) Will Congo DR win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $3,402,834 · resolves 2026-07-20
  - (2026-05-29) Will Donald Trump announce that the United States blockade of the Strait of Hormuz has been lifted by May 31, 2026?
      yes price: 33% · 24h volume: $2,067,273 · resolves 2026-05-31
  - (2026-05-29) Will Uzbekistan win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,871,902 · resolves 2026-07-20
  - (2026-05-29) Will South Africa win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,801,674 · resolves 2026-07-20
  - (2026-05-29) Roland Garros ATP: Karen Khachanov vs Jesper de Jong
      yes price: 0% · 24h volume: $1,629,083 · resolves 2026-06-05
  - (2026-05-29) Will SK Brann win on 2026-05-29?
      yes price: 0% · 24h volume: $1,609,600 · resolves 2026-05-29
  - (2026-05-29) Roland Garros ATP: Casper Ruud vs Tommy Paul
      yes price: 38% · 24h volume: $1,496,425 · resolves 2026-06-05

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-29) [Marginal Revolution] Friday assorted links
      1. Where are the economies of scale in homebuilding? 2. Peter Thiel and Argentina (NYT). 3. Discourse on classical guitar. 4. How many dissertations are AI-written? 5. NYT talks with Macca. 6. New algorithm for ranking V
  - (2026-05-29) [Marginal Revolution] What I have been learning doing New Aesthetics
      Patrick offered his observations here, I will add a few points of my own. I very often think in terms of regions and geographic places.  Currently, artistic movements (of most sorts, not just &#8220;New Aesthetics&#8221;
  - (2026-05-29) [Marginal Revolution] Why are Murders Down in Baltimore?
      In 2015 I wrote Baltimore Arrests are Down and Crime is Way Up and, as I predicted, Baltimore tipped into an high crime equilibrium. After the Freddie Gray riots, arrests declined and crime shot up but crime stayed high 
  - (2026-05-28) [Conversable Economist] Simone Weil on Education and Attention
      I&#8217;ve written a number of times in this space about the &#8220;attention economy&#8221; (for example, here, here, and here). When people consume content on a screen, we are in effect selling our attention. Decisions

### U.S. Political Figures (per-figure anomaly tracking) — 0 new of 613 total
  (no new items today)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=34, 7d-median=25, 14d-median=25; carrying terms: designated, unless, sector, requires, marine, action, order, respect, associated, affected, regulatory, guard
- state_bills: today=155, 7d-median=0, 14d-median=0
- state_news: today=866, 7d-median=722, 14d-median=722
- local_news: today=252, 7d-median=252, 14d-median=252
- foreign_news: today=905, 7d-median=905, 14d-median=905
- chinese_internal: today=284, 7d-median=284, 14d-median=284
- russian_internal: today=1155, 7d-median=1067, 14d-median=1067
- ukrainian_internal: today=138, 7d-median=138, 14d-median=138
- ukraine_theater: today=367, 7d-median=367, 14d-median=367
- paper_bets: today=143, 7d-median=141, 14d-median=141
- weather: today=126, 7d-median=126, 14d-median=126
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=97, 7d-median=95, 14d-median=95
- congressional_trades: today=64, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30; carrying terms: transport, scotus, arocho, khalil, jabar, jaron, docks, morales, raquan, concesionaria, metropolitana, havana
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, issuer, reporting, trust
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ocasio, disbursements, sherrod, congress, friends, committee, lowden, graham, cycle, cooper, lindsey, jonathan
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=0, 14d-median=0
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: reader, defender, langflow, denial, vendor, micro, cross, origin, adobe, product, acrobat, scripting
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: peace, hormuz, permanent, continue, price, ceasefire, extension, volume, agreement, announces, strait, world
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: story, marginalrevolution, class, conversable, marginal, revolution, economist, https, policy, recipients, world, links
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] ECB press: Luis de Guindos: Financial Stability Review - May 2026
- [2026-05-27] ECB press: Financial stability vulnerabilities remain elevated as geoeconomic shock unfolds
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*