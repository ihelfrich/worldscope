# WORLDSCOPE morning brief — 2026-11-25

## Headline
3249 new items across 30 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (837) · Russian Internal News (state + in-exile) (706) · State-Level News (329) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (161) · U.S. Weather + Severe / Climate Outlooks (149) · GDELT GKG — themes / entities / watch areas (134) · World News (by country, top stories) (105) · Ukrainian Internal News (national + local Kyiv) (68) · Court opinions of consequence (federal & state) (52) · IT, InfoSys & cybersecurity news (last 7 days) (46) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 837 new of 1039 total
  - (2026-11-24) [Global] More than 300 Russians killed as Moscow props up Mali’s junta, leaked data reveals
  - (2026-11-25) [Global] All hostages freed after Colombian security forces storm supermarket, says president
  - (2026-11-25) [Global] Colombia’s president arrives at scene of supermarket hostage siege in tourist city
  - (2026-11-24) [Global] Kilmar Ábrego García, man at center of Trump deportation battle, leaves US
  - (2026-11-24) [Global] Life expectancy in Cuba falls for first time since 1950 amid economic crisis
  - (2026-11-25) [Global] China investigates politburo star in Xi Jinping’s latest purge

### Russian Internal News (state + in-exile) — 706 new of 1112 total
  - (2026-11-25) Финансовая стабильность при Путине «блестяще удерживается», а Набиуллина «творит чудеса»: Чубайс выступил с первой публичной лекцией после начала войны | LEDE: Анатолий Чубайс, уехавший из Р] (ru: Фин…
      Анатолий Чубайс, уехавший из России в 2022 году, впервые после начала большой войны выступил с публичной лекцией, обратило внимание издание The Bell.
  - (2026-11-25) Война. 1736-й день. США больше не будут предлагать России деловые сделки в обмен на мир в Украине. Вашингтон вернулся к подходу «земля в обмен на мир» | LEDE: «Медуза» с 24 февраля 2022 года] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-11-25) «Я совершил несколько ужасных ошибок». Глава Nvidia Дженсен Хуанг извинился перед сотрудниками. Он отрицает, что за его возвращением в компанию стоит Трамп | LEDE: Генеральный директор Nvidi] (ru: «Я…
      Генеральный директор Nvidia Дженсен Хуанг извинился перед сотрудниками компании за нарушения кодекса поведения. Об этом он сказал на первой после возвращения в компанию встрече с сотрудниками, сообщает The New York Times…
  - (2026-11-25) Собчак заявила, что удалит с ютуба выпуски с Андреем Григорьевым-Аполлоновым и Игорем Синяком по требованию Роскомнадзора | LEDE: Журналистка Ксения Собчак заявила, что вынуждена удалить с ю] (ru: Соб…
      Журналистка Ксения Собчак заявила, что вынуждена удалить с ютуба несколько выпусков из-за претензий Роскомнадзора.
  - (2026-11-25) Присяжные в США признали Huawei виновной в отмывании денег, краже коммерческих тайн и сотрудничестве с Ираном и Северной Кореей | LEDE: Жюри присяжных в Нью-Йорке признало китайскую компанию] (ru: При…
      Жюри присяжных в Нью-Йорке признало китайскую компанию Huawei виновной по 10 из 12 пунктов обвинения, включая отмывание денег, сговор с целью кражи коммерческой тайны и введение банков в заблуждение относительно своей де…
  - (2026-11-25) Лукашенко предложил Зеленскому вместе полететь в Москву на переговоры с Путиным. «Я ему что, чемодан, что ли?» — ответил Зеленский | LEDE: Александр Лукашенко предложил Владимиру Зеленскому ] (ru: Лук…
      Александр Лукашенко предложил Владимиру Зеленскому вместе прилететь в Москву на переговоры о мире с Владимиром Путиным.

### State-Level News — 329 new of 651 total
  - (2026-11-24) [California] Governor Newsom readies flood-fighting crews and supplies for Thanksgiving week storm and king tides
      Source
  - (2026-11-24) [Alabama] Alabama jobs count hits record as prime-age participation rises
  - (2026-11-24) [Alabama] Firebombed Gadsden mosque invites Alabama House speaker to visit after remarks on Muslim officials
  - (2026-11-24) [Alabama] Ivey urges Alabamians to support local small businesses before the Iron Bowl
  - (2026-11-24) [Alabama] Strong questions FEMA administrator at oversight hearing
  - (2026-11-24) [Alabama] I’ve owned over 35 electric cars. I’ll never go back to gas.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 161 new of 187 total
  - (2026-11-24) [St. Louis] The best indoor play areas for kids in St. Louis
      Whether you’re looking to escape the summer heat, get the wiggles out on a cold winter morning, or simply switch up your usual playdate routine, St. Louis has plenty of indoor destinations for kids of all ages. From spra…
  - (2026-11-24) [St. Louis] A St. Louis Literary Advent Calendar: 26 holiday book and family adventure pairings
      December can be the most wonderful (and busiest) time of the year. The hustle and bustle of the holiday season is often filled with activities, parties, food, and traditions. For my family, the holiday decorations only c…
  - (2026-11-24) [St. Louis] Invented in St. Louis, Pawsibly Yours is like Tinder for finding a rescue dog
      Samantha Dean had worked in academia most of her life, so she certainly wasn’t expecting to start a technology company. “Now I have a nationwide dog adoption app that operates like a dating app,” she says. Dean founded t…
  - (2026-11-24) [St. Louis] Odysseus rides Metro Transit
      “Sing to me of the man, Muse, the man of twists and turns…driven time and again off course…” —Homer, The Odyssey (trans. Robert Fagles) Mascots Ride the MetroLink On a brisk, windy afternoon in November, I found myself a…
  - (2026-11-24) [St. Louis] A homeless St. Louis couple has a home waiting in Maine. They just need to get there
      A couple who has spent the last four and a half years living in a makeshift shelter near the Mississippi River has been offered bus tickets to escape homelessness and get to where a home awaits them: the small town of Bo…
  - (2026-11-24) [St. Louis] Top things to do in St. Louis this weekend: November 27–29
      See Also: Pictures at an Exhibition: A Lyrical Tour @ Powell HallSaint Louis Ballet’s The Nutcracker @ Touhill Performing Arts CenterAllman Betts Family Revival @ Stifel TheatreSt. Louis Blues @ Enterprise Center The Urg…

### U.S. Weather + Severe / Climate Outlooks — 149 new of 151 total
  - (2026-11-25) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-25) [Severe] Winter Storm Warning: Winter Storm Warning issued November 25 at 2:55AM CST until November 26 at 6:00PM CST by NWS Lincoln IL
      * WHAT...Heavy wet snow expected. Total snow accumulations between 3 and 6 inches, with the heaviest amounts southwest of Jacksonville. * WHERE...A portion of west central Illinois. * WHEN...From noon today to 6 PM CST T…
  - (2026-11-25) [Moderate] Winter Weather Advisory: Winter Weather Advisory issued November 25 at 2:55AM CST until November 26 at 6:00PM CST by NWS Lincoln IL
      * WHAT...Snow expected. Total snow accumulations 1 to 3 inches from Canton to Petersburg to Springfield southwest. * WHERE...Portions of central and west central Illinois. * WHEN...From noon today to 6 PM CST Thursday. *…
  - (2026-11-25) [Severe] Special Marine Warning: Special Marine Warning issued November 25 at 3:47AM EST until November 25 at 4:45AM EST by NWS Key West FL
      SMWKEY The National Weather Service in Key West has issued a * Special Marine Warning for... Straits of Florida from Craig Key to west end of Seven Mile Bridge out 60 nm... Straits of Florida from Ocean Reef to Craig Key…
  - (2026-11-25) [Severe] Special Marine Warning: Special Marine Warning issued November 25 at 3:45AM EST until November 25 at 4:45AM EST by NWS Key West FL
      SMWKEY The National Weather Service in Key West has issued a * Special Marine Warning for... Straits of Florida from Ocean Reef to Craig Key 20 to 60 nm out... * Until 445 AM EST. * At 344 AM EST, a strong thunderstorm w…
  - (2026-11-24) [Moderate] Gale Warning: Gale Warning issued November 24 at 11:40PM AKST until November 25 at 5:00AM AKST by NWS Juneau AK
      Southeast Alaska Coastal Waters from Dixon Entrance to Cape Suckling out 100 NM Wind forecasts reflect the predominant speed and direction expected. Seas forecasts represent the average of the highest one-third of the co…

### GDELT GKG — themes / entities / watch areas — 134 new of 134 total
  - (2026-11-25) [Russia oil sanctions perimeter · themes] Drone Strikes Claim Lives in Russia and Ukraine
      almontasaf.net · English · tone -5.69948186528497
  - (2026-11-25) [Russia oil sanctions perimeter · themes] Ukraine Hits Targets in the Baltic and off Libya
      kyivpost.com · English · tone -4.60992907801418
  - (2026-11-25) [Russia oil sanctions perimeter · themes] Ukraine Invasion Day 1,735: Coalition of the Willing
      dailykos.com · English · tone -4.06976744186047
  - (2026-11-25) [Russia oil sanctions perimeter · near] A Russian strike on Ukraine kills 2 and wounds 48 as Kyiv explains its attack in Libya
      texarkanagazette.com · English · tone -6.4334085778781 · 10 other outlets
  - (2026-11-25) [Russia oil sanctions perimeter · near] Trump shelves Russia business deals in Ukraine peace push
      cyprus-mail.com · English · tone -1.56739811912226 · 4 other outlets
  - (2026-11-25) [Russia oil sanctions perimeter · near] Hungary, Ukraine make 'fresh start' as Magyar visit kickstarts trade talks
      bworldonline.com · English · tone 0.710479573712256 · 2 other outlets

### World News (by country, top stories) — 105 new of 105 total
  - (2026-11-25) [Brazil] ValOre Metals Announces Definitive Agreement to Acquire Bemisa Água Azul Mineração S.A., Owner of the Água Azul Gold Project in Pará State, Brazil
      northernnews.ca · English · 6 other outlets ran this story
  - (2026-11-25) [Brazil] Mpox cases are on the rise again in Brazil – just as an antiviral drug fails in trials
      sanfordherald.com · English · 3 other outlets ran this story
  - (2026-11-25) [Brazil] Brazil tax revenue hits record in October
      shafaqna.com · English
  - (2026-11-25) [Brazil] Carmézia Emiliano celebrates Macuxi culture and collective memory in new Sao Paulo exhibition
      artdaily.com · English
  - (2026-11-25) [Brazil] Brazil Stocks Fall 0.43% as Vale Slides | Brazil Market Report, Nov 24
      riotimesonline.com · English
  - (2026-11-25) [Brazil] Why Lula Resists Sending Oil to Cuba Despite Brazilian Left's Pressure
      cubaheadlines.com · English

### Ukrainian Internal News (national + local Kyiv) — 68 new of 129 total
  - (2026-11-25) Міністр закордонних справ Естонії прибув у Київ | LEDE: Міністр закордонних справ Естонії Маргус Тсахкна прибув із візитом в Україну.] (uk: Міністр закордонних справ Естонії прибув у Київ)
      Міністр закордонних справ Естонії Маргус Тсахкна прибув із візитом в Україну.
  - (2026-11-25) Поліція показала наслідки влучання дрона в 16-поверхівку в Києві | LEDE: Правоохоронці показали наслідки атаки безпілотниками росіян 24 листопада на 16-поверхівку у Шевченківському районі Києва] (uk:…
      Правоохоронці показали наслідки атаки безпілотниками росіян 24 листопада на 16-поверхівку у Шевченківському районі Києва.
  - (2026-11-25) Атака на російські кораблі в Лівії: глава МЗС Франції заступився за Україну | LEDE: Міністр закордонних справ Франції Жан-Ноель Барро наголосив, що Україна реалізувала своє "абсолютне право на ] (uk:…
      Міністр закордонних справ Франції Жан-Ноель Барро наголосив, що Україна реалізувала своє "абсолютне право на самооборону", коли атакувала два російські кораблі в лівійських водах.
  - (2026-11-25) ЗМІ: Німеччина планує посилити свої Patriot на 4 млрд євро | LEDE: ] (uk: ЗМІ: Німеччина планує посилити свої Patriot на 4 млрд євро)
  - (2026-11-25) РФ звинуватила Польщу у "русофобії" через ноту протесту після вторгнення російських ракет | LEDE: Посол РФ Георгій Міхно отримав ноту протесту в МЗС Польщі через інцидент 20 листопада 2026 року] (uk:…
      Посол РФ Георгій Міхно отримав ноту протесту в МЗС Польщі через інцидент 20 листопада 2026 року.
  - (2026-11-25) Російські дрони долетіли до Волині: на Ковельщині вирували пожежі, 5 постраждалих | LEDE: Унаслідок атаки дронів по Ковельській громаді на Волині поранено п’ятьох людей, пошкоджені транспорт і ] (uk:…
      Унаслідок атаки дронів по Ковельській громаді на Волині поранено п’ятьох людей, пошкоджені транспорт і цивільна будівля. Пожежі ліквідували.

### Court opinions of consequence (federal & state) — 52 new of 60 total
  - (2026-11-24) U.S. Court of Appeals, 11th Cir.: United States v. Hernan Mojica-Renteria
  - (2026-11-24) U.S. Court of Appeals, 11th Cir.: MedEnvios Healthcare, Inc. v. Secretary, U.S. Department of Health and Human Services
  - (2026-11-24) U.S. Court of Appeals, 3rd Cir.: Emery Barron v. Wetzel
  - (2026-11-24) U.S. Court of Appeals, 1st Cir.: US ex rel. Berkley v. Ocean State, LLC
  - (2026-11-24) U.S. Court of Appeals, 9th Cir.: Los Molinos Mutual Water Company v. Ekdahl
  - (2026-11-24) U.S. Court of Appeals, 9th Cir.: Sunday Red, LLC v. Tigeraire, Inc.

### IT, InfoSys & cybersecurity news (last 7 days) — 46 new of 62 total
  - (2026-11-25) [BleepingComputer] Microsoft confirms authentication issues after November updates
      Microsoft has confirmed that customers may experience authentication issues after installing November security updates that address a high-severity remote code execution vulnerability. [...]
  - (2026-11-25) [BleepingComputer] Hackers reportedly breached CIA intelligence analysis system
      Unknown attackers have reportedly breached an open-source intelligence analysis system at the US Central Intelligence Agency (CIA) [...]
  - (2026-11-25) [The Hacker News] Hackers Compromise 24 Check Point Management Servers in Suspected AI-Driven Attack Campaign
      An unknown threat actor has been using artificial intelligence (AI)-driven offensive tooling in a campaign targeting Check Point Security Management servers, impacting 22 distinct organizations across the world. The intr…
  - (2026-11-25) [The Hacker News] Com-Affiliated Hackers Hijack Cloud Accounts via Vishing for Data Theft and Extortion
      Palo Alto Networks Unit 42 has disclosed that it's tracking and has responded to "numerous waves of vishing attacks" orchestrated by Com-affiliated threat actors since August 2026 that have led to data theft and extortio…
  - (2026-11-25) [The Hacker News] WordPress Blocks Six Backdoored WP Connect Plugins Before Malicious Releases Go Live
      WordPress has removed six WordPress plugins developed by WP Connect after they were backdoored on November 22, 2026, to enable arbitrary code execution on sites that have them installed, following a suspected compromise…
  - (2026-11-25) [The Register] Jury finds Huawei stole US tech, laundered money, and broke sanctions
      Criminal masterminds claimed to work for ‘Weihua’ or to have source code from ‘oscic’ instead of Cisco

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-25) [OrbiMed Capital GP IX LLC] Form 4 (Reporting)
      filed 2026-11-25 02:56 UTC · role: Reporting — Filed: 2026-11-24 AccNo: 0000947871-26-001051 Size: 22 KB
  - (2026-11-25) [OrbiMed Genesis GP LLC] Form 4 (Reporting)
      filed 2026-11-25 02:56 UTC · role: Reporting — Filed: 2026-11-24 AccNo: 0000947871-26-001051 Size: 22 KB
  - (2026-11-25) [Avenzo Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-11-25 02:56 UTC · role: Issuer — Filed: 2026-11-24 AccNo: 0000947871-26-001051 Size: 22 KB
  - (2026-11-25) [ORBIMED ADVISORS LLC] Form 4 (Reporting)
      filed 2026-11-25 02:56 UTC · role: Reporting — Filed: 2026-11-24 AccNo: 0000947871-26-001051 Size: 22 KB
  - (2026-11-25) [Avenzo Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-11-25 02:48 UTC · role: Issuer — Filed: 2026-11-24 AccNo: 0001193125-26-476547 Size: 26 KB
  - (2026-11-25) [George Simeon] Form 4 (Reporting)
      filed 2026-11-25 02:48 UTC · role: Reporting — Filed: 2026-11-24 AccNo: 0001193125-26-476547 Size: 26 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-25) [United States] Fort Hood shooter Nidal Hasan asks court to delay firing-squad execution so he can fight sentence | News, Sports, Jobs
      domain: lahainanews.com · language: English · tone: -6.58207771609833 · 67 other outlets ran this story
  - (2026-11-25) [Australia] How a killer cop's double murder convictions played out
      domain: juneesoutherncross.com.au · language: English · tone: -7.17185385656292 · 52 other outlets ran this story
  - (2026-11-25) [Sweden] Summer vitamin D levels may say more about your health than winter levels, study finds
      domain: euronews.com · language: English · tone: -0.423728813559322 · 48 other outlets ran this story
  - (2026-11-25) [United States] What To Know About The Dolly Parton Tribute In The 2026 Macy's Thanksgiving Day Parade
      domain: iheart.com · language: English · tone: 4.3778801843318 · 42 other outlets ran this story
  - (2026-11-25) [Australia] Beau Lamarre-Condon convicted of murdering Sydney couple
      domain: inquisitr.com · language: English · tone: -7.38255033557047 · 39 other outlets ran this story
  - (2026-11-25) [Australia] How to start investing: Seven ways to build your finances | Great Lakes Advocate
      domain: greatlakesadvocate.com.au · language: English · tone: 0.756143667296786 · 38 other outlets ran this story

### GDACS — global disaster alerts — 32 new of 100 total
  - (2026-11-25) [Green] Earthquake in Taiwan
      Earthquake · Green alert · Taiwan · Magnitude 5.3M, Depth:10km
  - (2026-11-25) [Green] Earthquake in Off E. Coast Of N. Island, N.Z.
      Earthquake · Green alert · Off E. Coast Of N. Island, N.Z. · Magnitude 5.2M, Depth:25.327km
  - (2026-11-25) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 4.7M, Depth:10km
  - (2026-11-25) [Green] Earthquake in Balleny Islands Region
      Earthquake · Green alert · Balleny Islands Region · Magnitude 5.9M, Depth:10km
  - (2026-11-13) [Green] Forest fires in Brazil
      Wildfire · Green alert · Brazil · Green impact for forestfire in 5674 ha
  - (2026-11-21) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 7317 ha

### State Legislative Action — 31 new of 36 total
  - (2026-11-25) [Alaska SB 278] An Act relating to the required local contribution made by a city or borough school district for public school funding; and providing for an effective date.
      An Act relating to the required local contribution made by a city or borough school district for public school funding; and providing for an effective date.
  - (2026-11-25) [Alaska SB 204] An Act relating to substitute teaching; and relating to the qualifications of school board members.
      An Act relating to substitute teaching; and relating to the qualifications of school board members.
  - (2026-11-25) [Alaska HB 176] An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date…
      An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date.
  - (2026-11-25) [Alaska HJR 39] Urging the federal government to waive the new H-1B Visa fees for teachers in the state.
      Urging the federal government to waive the new H-1B Visa fees for teachers in the state.
  - (2026-11-25) [Alaska HB 28] An Act relating to education; relating to reimbursement of school district energy costs; relating to correspondence study program materials; relating to substitute teaching; relating to…
      An Act relating to education; relating to reimbursement of school district energy costs; relating to correspondence study program materials; relating to substitute teaching; relating to the qualifications of school board…
  - (2026-11-25) [Alaska SB 214] An Act making appropriations, including capital appropriations, supplemental appropriations, and reappropriations; making appropriations to capitalize funds; amending appropriations; a…
      An Act making appropriations, including capital appropriations, supplemental appropriations, and reappropriations; making appropriations to capitalize funds; amending appropriations; and providing for an effective date.

### Wikidata leader-roster changes (48h) — 31 new of 53 total
  - (2026-11-25) [Colombia] Abelardo de la Espriella (Q137204778) edited
      /* wbsetclaim-create:2||1 */ [[Property:P214]]: 5099178795824014280008
  - (2026-11-25) [Latvia] Edgars Rinkēvičs (Q3047551) edited
      /* wbsetsitelink-add:1|mnwiki */ Эдгарс Ринкевичс
  - (2026-11-25) [Pakistan] Asif Ali Zardari (Q57373) edited
      /* wbeditentity-statements-multiple-properties-update:0||2 */ source for date of birth, source for place of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])
  - (2026-11-25) [Peru] Keiko Fujimori (Q235137) edited
      /* wbsetsitelink-add:1|mnwiki */ Кэйко Фүжимори
  - (2026-11-25) [Philippines] Bongbong Marcos (Q983324) edited
      /* wbeditentity-update-languages-and-other-short:0||da */ other names, source for date of birth from Lex (Den Store Danske) ([[Wikidata:Requests for permissions/Bot/OKA bot 3|OKA bot task 3]])
  - (2026-11-25) [Mongolia] Khurelsukh Ukhnaa (Q27058418) edited
      /* wbsetsitelink-add:1|afwiki */ Ukhnaagiin Khürelsükh

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 29 new of 29 total
  - (2026-11-25) Protecting the Executive's Privileges and Enhancing Efficiencies in Federal Contracting
  - (2026-11-25) National Adoption Month, 2026
  - (2026-11-25) Establishment of Class E Airspace; Trading Bay Production Airport, Trading Bay, AK
      This action establishes Class E airspace extending upward from 700 feet above the surface at Trading Bay Production Airport, Trading Bay, AK. This action supports the safety and management of instrument flight rules (IFR…
  - (2026-11-25) Airworthiness Directives; The Boeing Company Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for certain The Boeing Company Model 707 airplanes; Model 720 and 720B series airplanes; Model 727C, 727-100, -100C, -200, and -200F series airplanes; and Mode…
  - (2026-11-25) Auction of Flexible-Use Licenses in the Upper C-Band for Next-Generation Wireless Services; Notice and Filing Requirements, Minimum Opening Bids, Upfront Payments, and Other Procedures for Auction 115…
      This document summarizes the procedures, deadlines, upfront payment, and minimum opening bid amounts adopted in the Auction 115 Procedures Public Notice for the Federal Communications Commission's (Commission) upcoming a…
  - (2026-11-25) Safety Zone; Brownsville Ship Channel, Brownsville, TX
      The Coast Guard is establishing a temporary safety zone for navigable waters on the Brownsville Ship Channel. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards ass…

### Paper Trading Scorecard — 18 new of 73 total
  - (2026-11-25) [Polymarket] Timberwolves vs. Thunder
      In the upcoming NBA game between Timberwolves and Thunder, originally scheduled for Wednesday, November 25, 2026 at 7:30 PM ET (as of creation of the first market related to the event): If the Timberwolves win, the marke…
  - (2026-11-25) [Polymarket] Will Ursula von der Leyen visit Ukraine by December 31, 2026?
      This market will resolve to "Yes" if the listed individual visits Ukraine between market creation and December 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". For the purpose of this market, a "visit"…
  - (2026-11-25) [Kalshi] Which Millennium Prize Problem will be solved next?
      Before 2046
  - (2026-11-25) [Kalshi] Fed funds rate at end of 2034
      December 31, 2034
  - (2026-11-25) [Manifold] will my friend say the n word by the end of the week?
  - (2026-11-25) [Manifold] Will GTA6 be recompiled on a PC build before Jensen Huang is out at NVDIA CEO?

### Government & military aircraft airborne (OpenSky) — 17 new of 21 total
  - (2026-11-25) CFC3415 (Canada)
      icao24: c2c377 · position: (57.5457, 10.8267) · alt: 8839m · 858km/h
  - (2026-11-25) GAF628 (Germany)
      icao24: 3f6087 · position: (51.2565, 12.0966) · alt: 4084m · 724km/h
  - (2026-11-25) GAF212 (Germany)
      icao24: 3ea048 · position: (52.8578, 13.6084) · alt: 10050m · 776km/h
  - (2026-11-25) FNY55B3 (France)
      icao24: 39a407 · position: (46.6484, -0.1301) · alt: 4274m · 629km/h
  - (2026-11-25) JAF34G (Belgium)
      icao24: 44d1a6 · position: (34.144, 10.8202) · alt: 2567m · 531km/h
  - (2026-11-25) JAF9LJ (Belgium)
      icao24: 44d1a7 · position: (44.0912, -4.7073) · alt: 10668m · 878km/h

### Chinese Internal News — 16 new of 42 total
  - (2026-11-25) AstraZeneca’s China strategy: fewer sales staff, more investment?
  - (2026-11-25) Chinese private funds retreat from record highs as AI bubble jitters hit Nvidia backers
  - (2026-11-25) BYD apologises for wheel-rim error; Chinese car buyers go electric: 7 EV reads
  - (2026-11-25) BYD eyes a second European plant, enters talks with Ineos over a French assembly
  - (2026-11-25) China Resources dropped from exclusive talks as Kingboard buys distressed tower: sources
  - (2026-11-25) Shein to pay US$100 million to settle US shipping, customer service claims

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-11-24) M 6.4 - Mauritius - Reunion region
      M6.4 · Mauritius - Reunion region · depth 10 km
  - (2026-11-25) M 5.9 - Balleny Islands region
      M5.9 · Balleny Islands region · depth 10 km
  - (2026-11-25) M 5.3 - 83 km ESE of Hengchun, Taiwan
      M5.3 · 83 km ESE of Hengchun, Taiwan · depth 10 km
  - (2026-11-25) M 5.2 - 175 km N of Hicks Bay, New Zealand
      M5.2 · 175 km N of Hicks Bay, New Zealand · depth 25.327 km
  - (2026-11-24) M 5.2 - 93 km WSW of Puerto Madero, Mexico
      M5.2 · 93 km WSW of Puerto Madero, Mexico · depth 35 km
  - (2026-11-24) M 5.0 - 209 km SE of Kokopo, Papua New Guinea
      M5.0 · 209 km SE of Kokopo, Papua New Guinea · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 10 new of 87 total
  - (2026-11-25) [USASpending] $17,956,041,439 → BECHTEL NATIONAL, INC.:
      Agency: Department of Energy. Description:
  - (2026-11-25) [USASpending] $11,315,465,862 → ALLIANCE FOR ENERGY INNOVATION, LLC: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWAB
      Agency: Department of Energy. Description: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWABLE ENERGY LABORATORY
  - (2026-11-25) [USASpending] $4,433,680,297 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WI
      Agency: National Aeronautics and Space Administration. Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOLID…
  - (2026-11-25) [USASpending] $2,844,683,081 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2026-11-25) [USASpending] $2,115,797,977 → BOLLINGER SHIPYARDS LOCKPORT, L.L.C.: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE U
      Agency: Department of Homeland Security. Description: THE UNITED STATES COAST GUARD HAS A REQUIREMENT TO PROCURE UP TO TWENTY-SIX (26) FAST RESPONSE CUTTERS (FRCS) ON A FIRM FIXED PRICE (FFP) BASIS WITH AN ECONOMIC PRICE…
  - (2026-11-25) [USASpending] $1,511,043,583 → HAMILTON SUNDSTRAND SPACE SYSTEMS INTERNATIONAL, INC.: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)
      Agency: National Aeronautics and Space Administration. Description: EXTRAVEHICULAR SPACE OPERATIONS CONTRACT (ESOC)

### Commentary & analysis (last 7 days) — 10 new of 10 total
  - (2026-11-25) [Marginal Revolution] Avoiding disempowerment through protectionism?
      Recently many people are debating whether AI will lead to our disempowerment. One simple example is that we might use AI to pursue or solve various intellectual tasks for us, rather than doing it ourselves. So say there…
  - (2026-11-24) [Adam Tooze] Top Links 1295 Trump’s Nvidia intervention. Copper in chaos. Aron on political ennui. Revolutionary war on the Hudson.
      Great links, images, and reading from Chartbook Newsletter by Adam Tooze
  - (2026-11-24) [Noah Smith] Why the New Right is failing
      To be clear, I’m glad it’s failing.
  - (2026-11-24) [Marginal Revolution] Gambling for Goals
      Young adults in advanced economies have grown more pessimistic about their economic prospects in recent years. At the same time, gambling-like financial activities have proliferated. We link these trends through a Friedm…
  - (2026-11-24) [Marginal Revolution] Tuesday assorted links
      1. On language models writing their own weights. 2. “The Banksy of NBA media”? 3. Astra solves a historical mystery. 4. Some new Indian architecture. And more from Bloomberg. 5. The Icelandic tradition of liberty. 6. “Su…
  - (2026-11-24) [Conversable Economist] The Global Office and the Third Great Unbundling
      All trade can be described as a form of “unbundling”–that is, instead of making everything oneself from scratch, a firm or person instead purchases some goods or services from others. Richard Baldwin describes internatio…

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-11-25) Counter-Strike: Imperial vs FlyQuest (BO3) - PGL Major Singapore Stage 1
      yes price: 50% · 24h volume: $1,235,937 · resolves 2026-11-25
  - (2026-11-25) Counter-Strike: 9z vs DENDELE CS (BO3) - PGL Major Singapore Stage 1
      yes price: 70% · 24h volume: $647,139 · resolves 2026-11-25
  - (2026-11-25) Counter-Strike: Imperial vs FlyQuest - Map 1 Winner
      yes price: 40% · 24h volume: $516,782 · resolves 2026-11-25
  - (2026-11-25) Florianopolis: Juan Manuel La Serna vs Santiago De La Fuente
      yes price: 97% · 24h volume: $356,211 · resolves 2026-12-01
  - (2026-11-25) Ankara: Thomas Faurel vs Nikita Bilozertsev
      yes price: 83% · 24h volume: $282,873 · resolves 2026-12-02
  - (2026-11-25) Will Fenerbahçe SK win on 2026-11-25?
      yes price: 38% · 24h volume: $251,487 · resolves 2026-11-25

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 40 total
  - (2026-11-25) MOVER ▲ Bernard Arnault & family — $119.65B (+$3.86B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-11-25) MOVER ▲ Rob Walton & family — $154.32B (+$2.47B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-11-25) MOVER ▲ Jim Walton & family — $151.08B (+$2.46B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-11-25) MOVER ▲ Alice Walton — $140.37B (+$2.40B since yesterday)
      United States · Fashion & Retail · source: Walmart

### Ukraine Theater (total-war monitoring) — 3 new of 5 total
  - (2026-11-25) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-25) [Liveuamap error] HTTP 503
      primary feed retired; Google News proxy also unreachable
  - (2026-11-25) [Copernicus EMS error] all endpoints 4xx/5xx
      all known activation-list URLs returned non-200

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 16 total
  - (2026-11-24) CVE-2026-132224 · Optimizely Web Experimentation: Optimizely Web Experimentation External Control of Critical State Data Vulnerability
      vendor: Optimizely · product: Web Experimentation · CISA remediation by 2026-11-27
  - (2026-11-24) CVE-2026-131914 · Idunno AntiCsrf: Idunno AntiCsrf Deserialization of Untrusted Data Vulnerability
      vendor: Idunno · product: AntiCsrf · CISA remediation by 2026-11-27
  - (2026-11-24) CVE-2026-132165 · Drupal Core: Drupal Core Remote Code Execution Vulnerability
      vendor: Drupal · product: Core · CISA remediation by 2026-11-27

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-11-24) Influenza A(H5N1) - United States of America
      Between 16 October and 4 November 2026, the United States of America, through its International Health Regulations (IHR) National Focal Point, notified WHO of three laboratory-confirmed human infections with influenza A(…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=17, 14d-median=20; carrying terms: protection, airplanes, published, public, management, airworthiness, provisions, final, provide, certain, action, rulemaking
- state_bills: today=36, 7d-median=68, 14d-median=76; carrying terms: state, relating, health, district, alaska, service, including, providing, public, medical, program, emergency
- state_news: today=651, 7d-median=651, 14d-median=711; carrying terms: nofollow, majority, wednesday, washington, house, demand, congressional, status, error, kansas, program, lawmakers
- local_news: today=187, 7d-median=221, 14d-median=250; carrying terms: house, thanksgiving, people, journal, north, culture, search, democrats, plans, arrested, https, dining
- foreign_news: today=1039, 7d-median=1024, 14d-median=1008; carrying terms: report, defence, house, warning, demand, further, presidential, credit, australian, global, congo, brazil
- chinese_internal: today=42, 7d-median=289, 14d-median=315; carrying terms: nvidia, https, target, chinese, china, global, caixin, world, investors, market, google, huang
- russian_internal: today=1112, 7d-median=960, 14d-median=947; carrying terms: title, https, httperror, telegram, press, error, istories, novayagazeta, politico, anthropic, journal, nvidia
- ukrainian_internal: today=129, 7d-median=129, 14d-median=129; carrying terms: drones, washington, aircraft, hromadske, error, power, negotiating, europe, leaders, emergency, ministry, announced
- ukraine_theater: today=5, 7d-median=277, 14d-median=272; carrying terms: extra, frontline, known, cartography, snapshot, liveuamap, password, terms, maintained, email, accepted, polygon
- paper_bets: today=73, 7d-median=77, 14d-median=77; carrying terms: justice, earthquake, criminal, kylian, credible, goldman, magnitude, offering, henry, refers, unemployment, force
- weather: today=151, 7d-median=125, 14d-median=127; carrying terms: center, atlantic, increasing, magnitude, florida, advisory, washington, especially, angeles, warning, unsecured, winter
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: jtsjol, pcepilfe, effective, supply, payrolls, money, walcl, payems, vixcls, sheet, nonfarm, funds
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, china, russell, rates, range, natural, corporate, close, futures, proxy, large, crypto
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=87, 7d-median=102, 14d-median=100; carrying terms: cyber, committees, burma, islamic, imposed, facilitate, member, services, political, unauthorised, campaign, crimea
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quiverquant, quantitative, https, congresstrading, quiver, client, error, httperror
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: spain, googl, euronext, giancarlo, ambani, hathaway, oracle, microsoft, yiming, madrid, spacex, huang
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, state, martin, blanche, company, court, supreme, charles, justin, trade, international, division
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, holdings, william, brian, capital, james, reeves, poppic, patrick
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: sherrod, cooper, alexandria, raised, cycle, trone, brown, james, ossoff, sayed, krishnamoorthi, talarico
- gdelt_regions: today=105, 7d-median=103, 14d-median=103; carrying terms: english, china, korea, japan, trump, south, turkish, colombia, canada, saudi, brazil, outlets
- gdelt_gkg: today=134, 7d-median=134, 14d-median=125; carrying terms: hezbollah, israel, english, themes, keywords, north, russian, netanyahu, trump, attack, sanctions, indiatimes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: australia, killed, trump, injured, police, outlets, language, crash, story, domain, shooting, english
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=19, 14d-median=19; carrying terms: position, belgium, france, germany, kingdom, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: producing, spain, clades, driving, report, increasing, consecutive, stands, disembarked, septem, numbers, contaminated
- cisa_kev: today=16, 7d-median=19, 14d-median=17; carrying terms: channel, products, using, cisco, multiple, vulnerability, incorrect, product, external, resource, bypass, vendor
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=53, 7d-median=54, 14d-median=54; carrying terms: quickstatements, update, republic, toollabs, edited, wbsetdescription, wbsetsitelink, batch, wbeditentity, wbsetclaim, property, remove
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: earthquake, wildfire, sudan, republic, african, alert, forest, magnitude, impact, islands, green, australia
- usgs_quakes: today=13, 7d-median=13, 14d-median=12; carrying terms: depth, islands, guinea, papua, region, chile, philippines, village
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, december, volume, resolves, donetsk, championship, change, league, interest, meeting, increase, rates
- commentary: today=10, 7d-median=4, 14d-median=6; carrying terms: revolution, https, marginal, economic, marginalrevolution, conversable, world, economist, links, assorted, global, human
- tech_news: today=62, 7d-median=63, 14d-median=63; carrying terms: cyber, report, edition, added, public, cybersecurity, record, attacks, using, daily, access, following
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: boebert, latimer, darrell, amata, stanton, ellzey, speech, jason, goldman, pappas, henry, barrag
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, unavailable, module, consensus, decision, market, converges, claude, sufficient, paper, either, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] ECB press: Frank Elderson: Smart supervision for small banks
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-17] ECB press: Philip R. Lane: The practice and science of monetary policy communication: the ECB experience
- [2026-11-18] ECB press: Boris Vujčić: Financial Stability Review - November 2026
- [2026-11-18] ECB press: Risks from AI valuations, fiscal imbalances and geoeconomic tensions weigh on financial stability outlook
- [2026-11-18] Fed speeches: Barr, Investing in America’s Underserved Communities
- [2026-11-18] Fed press (events + announcements): Minutes of the Federal Open Market Committee, October 27-28, 2026
- [2026-11-19] Fed speeches: Jefferson, Monetary Policy amid Frequent and Complex Shocks
- [2026-11-19] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of First Security Bancorp
- [2026-11-20] ECB press: Christine Lagarde: Acting in time
- [2026-11-20] Fed speeches: Waller, Opening Remarks
- [2026-11-20] Fed press (events + announcements): Federal Reserve Board releases results from survey of senior financial officers at banks about their strategies and practices for managing reserve balances

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*