# WORLDSCOPE morning brief — 2026-09-29

## Headline
3548 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (825) · Russian Internal News (state + in-exile) (649) · Ukraine Theater (total-war monitoring) (370) · State-Level News (364) · World leaders & government officials (324) · Chinese Internal News (243) · Local News: St. Louis + Atlanta (212) · U.S. Weather + Severe / Climate Outlooks (125) · State Legislative Action (60) · Ukrainian Internal News (national + local Kyiv) (58) · IT, InfoSys & cybersecurity news (last 7 days) (47) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 825 new of 1019 total
  - (2026-09-29) [Global] Walkouts, clashes and moments that defined UNGA 2026
      From mass walkouts and heated exchanges to protests, this year’s UNGA produced no shortage of memorable moments.
  - (2026-09-29) [Global] Turkiye arrests president, six members of football refereeing body in probe
      Arrests were made over interference with refereeing procedures, among other accusations, Turkish justice minister says.
  - (2026-09-29) [Global] Iranians stock up on food and medicine as fears of new US fighting grow
      Iran is struggling with shortages as sanctions and blockade strain food and medicine supply chains.
  - (2026-09-29) [Global] Malaysia sends Rohingya back to Myanmar despite safety warnings
      Malaysia sends Rohingya back to Myanmar despite safety warnings
  - (2026-09-29) [Global] Journalist ascends to throne in Uganda kingdom after succession dispute
      Edward Rukidi Kijanangoma succeeds King Oyo Nyimba Kabamba Iguru Rukidi IV, who died last month.
  - (2026-09-29) [Global] Hormuz and Yemen: Iran offers de-escalation at a price others will pay
      Iran is using Hormuz to seek US concessions, relief for the Houthis and greater control over Gulf shipping.

### Russian Internal News (state + in-exile) — 649 new of 960 total
  - (2026-09-29) Совсем скоро знаменитую Шуховскую башню полностью разберут. И заменят на новодел. Рассказываем историю гиперболоида «ослепительного великолепия», который оказался не нужен ее владельцем | LEDE:] (ru:…
      Телебашня на Шаболовке — самая известная конструкция инженера Владимира Шухова. Она была главным источником радио- и телегигнала в СССР, важнейшим инженерным достижением НЭПа — и все еще остается доминантой московского р…
  - (2026-09-29) В Амурской области разбился военный самолет Ту-95. Есть погибшие | LEDE: Военный самолет потерпел крушение возле села Красноярово в Амурской области, сообщили российские телеграм-каналы, бли] (ru: В А…
      Военный самолет потерпел крушение возле села Красноярово в Амурской области, сообщили российские телеграм-каналы, близкие к силовым структурам.
  - (2026-09-29) Депрессию и правда можно лечить электрошоком? | LEDE: Минздрав утвердил стандарт медицинской помощи при рекуррентной депрессии, в котором прописано, с какой частотой врачи должны назначать а] (ru: Деп…
      Минздрав утвердил стандарт медицинской помощи при рекуррентной депрессии, в котором прописано, с какой частотой врачи должны назначать акупунктуру токами крайне высокой частоты, электросудорожную терапию, внутривенное об…
  - (2026-09-29) На лидера «Яблока» Николая Рыбакова составили протокол о мелком хулиганстве. Потому что он написал «За мир» на бюллетене на выборах в Госдуму | LEDE: На лидера партии «Яблоко» Николая Рыбако] (ru: На…
      На лидера партии «Яблоко» Николая Рыбакова составили административный протокол о мелком хулиганстве (часть 1 статьи 20.1 КоАП РФ). Об этом сообщает пресс-служба партии.
  - (2026-09-29) 11-летняя шахматистка из Великобритании стала самым молодым в истории гроссмейстером среди женщин | LEDE: 11-летняя шахматистка из Великобритании Бодхана Савинандан стала самым молодым в ист] (ru: 11-…
      11-летняя шахматистка из Великобритании Бодхана Савинандан стала самым молодым в истории гроссмейстером среди женщин, сообщает «Би-би-си».
  - (2026-09-29) Война. 1679-й день. Папа римский призвал Европу быть готовой «к уступкам в некоторых вопросах» ради мира | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украи] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…

### Ukraine Theater (total-war monitoring) — 370 new of 579 total
  - (2026-09-28) [FIRMS] thermal anomaly 52.846, 29.990 (FRP 3.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-28 2329Z, FRP 3.64 MW
  - (2026-09-28) [FIRMS] thermal anomaly 52.266, 34.533 (FRP 1.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-28 2329Z, FRP 1.03 MW
  - (2026-09-28) [FIRMS] thermal anomaly 51.656, 34.092 (FRP 0.48 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-28 2329Z, FRP 0.48 MW
  - (2026-09-28) [FIRMS] thermal anomaly 51.895, 29.339 (FRP 0.75 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-28 2329Z, FRP 0.75 MW
  - (2026-09-28) [FIRMS] thermal anomaly 51.890, 29.333 (FRP 0.75 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-28 2329Z, FRP 0.75 MW
  - (2026-09-28) [FIRMS] thermal anomaly 51.889, 29.338 (FRP 0.75 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-28 2329Z, FRP 0.75 MW

### State-Level News — 364 new of 529 total
  - (2026-09-28) [Alabama] Governor Ivey Announces Creation of ‘Alabama STEM Council Seal of Approval,’ Calls for Applications
      MONTGOMERY — Governor Kay Ivey on Monday announced the ‘Alabama STEM Council Seal of Approval,’ a new initiative recognizing high-quality STEM programs and events across the state. The initiative is in partnership with t…
  - (2026-09-28) [Alabama] Governor Ivey Announces Finance Director Bill Poole to Depart, Names Doryan Carlton to Lead the Department
      MONTGOMERY – Governor Kay Ivey on Monday announced her Department of Finance Director Bill Poole will depart at the end of the week after 16 years of state service. The governor is also excited to share that Doryan Carlt…
  - (2026-09-29) [California] Governor Newsom honors fallen California Highway Patrol Officer Brian Liles
      Source
  - (2026-09-29) [California] Governor Newsom signs commonsense legislation to make your life easier
      Source
  - (2026-09-28) [California] Governor Newsom signs legislation protecting parents’ rights in youth football
      Source
  - (2026-09-28) [California] Governor Newsom takes action to help lower prices amid Trump’s nationwide gas and diesel price spike
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 243 new of 292 total
  - (2026-09-29) 江苏南通： 喜迎国庆祝福祖国 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9ybTFfUTlIM0NncWZEN1c4cHY4QndZUjkydlJMMWxXcTZQSHdKUTF5dDVnZVpUc1BSYXE2YU5YREVjNmQ1eDhOTEZMVk05VW1hOHUyZ] (zh:…
      江苏南通： 喜迎国庆祝福祖国 人民图片
  - (2026-09-29) 河北秦皇岛： 巧手剪纸迎国庆 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5oRURrNHdnVm5GUEVhZXRiTFFhRkJXcFBGcVZYRTFGejhaT0dBYkktVU1LWU1DZldoWlo3Y2xycDZ3UFdtTHZRV0xYRmRxd2NaMm9iT] (zh:…
      河北秦皇岛： 巧手剪纸迎国庆 人民图片
  - (2026-09-29) 安徽休宁： 云端古村入画来 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE42WVFGbDZHakZIb2dwdDFicHh3Ynh6aHE2LXd2RnV1TUZydzhSRmlQNmxXMjdjVFZpVTdrQk9tZXlhLW1sbmN2aUJqdHcyOFhIQmNhb0] (zh:…
      安徽休宁： 云端古村入画来 人民图片
  - (2026-09-29) 福建连江： 造船企业生产忙 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE9DUWJKTDlYSjk2Uk5yWV9VOTBURzJJdjM1dG9UcWVKc0VCeFU4aGo2NmE1Vm5HLTJTejZqbWVwSnVkbXlxRnYwOFlYZDFHVmNvZUFTN2] (zh:…
      福建连江： 造船企业生产忙 人民图片
  - (2026-09-29) 广西阳朔： 和美乡村 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1GeUJfTlZZZkRfRW43TFNJbC05aDJmNlJyOWJuM0luX08zMzNGSGo0S2t3al9UWklFZFF5dldZVTR1ZGhRQ0xpQzREY040by1nOEtINFUwM] (zh:…
      广西阳朔： 和美乡村 人民图片
  - (2026-09-29) 江苏苏州： 第十五届苏州文博会启幕 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFB4VXYxTzgwZjY4aWtvN0RjM0JJUkJsV1FEYV9ISzhnMk9ld2Q4UDJhZk05YTh2MTluMDhXdUx6WTNnYXdCMFZpOUwyaHJET0FCTn] (zh:…
      江苏苏州： 第十五届苏州文博会启幕 人民图片

### Local News: St. Louis + Atlanta — 212 new of 242 total
  - (2026-09-29) [St. Louis] October gardening tips for St. Louisans
      In this latest edition of This Month in Your Garden, Sue Leahy of Greenscape Gardens shares her to-do list. 1. Get busy planting “First of all, it’s a great time to plant,” says Sue Leahy of Greenscape Gardens in Manches…
  - (2026-09-29) [St. Louis] City dropped the ball on public art effort—but advocates say it’s not too late
      Sixteen years ago, St. Louis aldermen passed an ordinance requiring that 1 percent of budgets for construction projects done by the city be earmarked for public art. But despite tens of millions of dollars in development…
  - (2026-09-29) [St. Louis] The KitchenHub STL is helping local makers become business movers and shakers
      Sheila Brown craved peanut brittle. She was at home in Maplewood several years ago, felt a hankering, and cooked some. She gave a portion to her brother-in-law. He bit off a piece and chewed. “If you start making turtles…
  - (2026-09-29) [St. Louis] Where Art Thou 9/29/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-09-28) [St. Louis] Trial kicks off in lawsuit over St. Louis’ failure to evict sidewalk encampment
      Did the City of St. Louis do enough to deal with a homeless Sudanese couple who for almost four years lived in a makeshift yurt-like structure on a South City sidewalk? That’s the question a jury will have to decide this…
  - (2026-09-28) [St. Louis] Home technology showroom opens in Sunset Hills
      Integration Controls is opening a new showroom this week in Sunset Hills, expanding its offerings in the realm of hidden technology and smart home automation in the St. Louis area. Visitors to the experiential showroom,…

### U.S. Weather + Severe / Climate Outlooks — 125 new of 127 total
  - (2026-09-29) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-29) [Severe] Special Marine Warning: Special Marine Warning issued September 29 at 9:31AM EDT until September 29 at 10:15AM EDT by NWS Miami FL
      SMWMFL The National Weather Service in Miami has issued a * Special Marine Warning for... Biscayne Bay... Coastal waters from Deerfield Beach to Ocean Reef FL out 20 NM... Waters from Deerfield Beach to Ocean Reef FL fro…
  - (2026-09-29) [Severe] Flash Flood Warning: Flash Flood Warning issued September 29 at 7:30AM MDT until September 29 at 10:30AM MDT by NWS El Paso Tx/Santa Teresa NM
      FFWEPZ The National Weather Service in El Paso Tx/Santa Teresa has issued a * Flash Flood Warning for... Central Dona Ana County in south central New Mexico... * Until 1030 AM MDT. * At 730 AM MDT, Doppler radar indicate…
  - (2026-09-29) [Severe] Flood Warning: Flood Warning issued September 29 at 9:28AM EDT by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Astor affecting Lake and Volusia Counties. .The St Johns River at Astor remains within Minor Flood Stage due to tidal effects. Riv…
  - (2026-09-29) [Severe] Flash Flood Warning: Flash Flood Warning issued September 29 at 6:27AM MST until September 29 at 9:45AM MST by NWS Flagstaff AZ
      FFWFGZ The National Weather Service in Flagstaff has extended the * Flash Flood Warning for... The Paria River in... Coconino County in north central Arizona... * Until 945 AM MST /1045 AM MDT/. * At 627 AM MST /727 AM M…
  - (2026-09-29) [Severe] Flash Flood Warning: Flash Flood Warning issued September 29 at 7:16AM MDT until September 29 at 10:15AM MDT by NWS El Paso Tx/Santa Teresa NM
      FFWEPZ The National Weather Service in El Paso Tx/Santa Teresa has issued a * Flash Flood Warning for... Southwestern Sierra County in south central New Mexico... East Central Grant County in southwestern New Mexico... N…

### State Legislative Action — 60 new of 61 total
  - (2026-09-29) [California SB 999] Franchise Tax Board: reporting requirements.
      Existing law requires the Franchise Tax Board, on or before March 1, 2022, and annually on or before March 1 thereafter, to report certain information to the Legislature regarding health coverage penalties paid by househ…
  - (2026-09-29) [California AB 1338] Department of Transportation: transferred property: City of Lynwood.
      Existing law vests the Department of Transportation with full possession and control of all state highways and all property and rights on property acquired for state highway purposes. Various provisions of existing law s…
  - (2026-09-29) [California AB 1592] California Indian Heritage Center support organization.
      Existing law authorizes the Department of Parks and Recreation to enter into a statewide agreement with a park support organization to facilitate the implementation of reforms recommended by the Parks Forward Commission…
  - (2026-09-29) [California AB 739] Common interest developments: managing agent fees.
      Existing law, the Davis-Stirling Common Interest Development Act, governs the formation and operation of common interest developments, and requires a common interest development to be managed by an association, as specif…
  - (2026-09-29) [California SB 342] Contractors: unlicensed work.
      Existing law, the Contractors State License Law, establishes the Contractors State License Board in the Department of Consumer Affairs to license and regulate contractors. Existing law prohibits a person engaging in the…
  - (2026-09-29) [California AB 2219] Veterans.
      Existing law authorizes the board of supervisors of each county to appoint a county veterans service officer to perform duties relating to the administration of benefits to veterans. Existing law authorizes the board to…

### Ukrainian Internal News (national + local Kyiv) — 58 new of 110 total
  - (2026-09-29) Трамп підтримав нову стратегію щодо РФ: послаблення санкцій в обмін на звільнення політв’язнів – ЗМІ | LEDE: Спецпредставник Трампа Джон Коул запропонував новий підхід: звільнення політичних в'] (uk:…
      Спецпредставник Трампа Джон Коул запропонував новий підхід: звільнення політичних в'язнів в обмін на економічне співробітництво з Росією.
  - (2026-09-29) Прем'єр Франції звернувся в прокуратуру через витік у пресу даних про держбюджет-2027 | LEDE: Паризька прокуратура розпочала попереднє розслідування у зв'язку з витоком у пресу інформації про о] (uk:…
      Паризька прокуратура розпочала попереднє розслідування у зв'язку з витоком у пресу інформації про один із напрямків скорочення бюджетних видатків за заявою прем'єр-міністра Себастьєна Лекорню, поданою до правоохоронних о…
  - (2026-09-29) Вимоги ЄС повертаються. Як Україні доведеться змінити відбір до ВККС після рішення "Венеційки" | LEDE: ] (uk: Вимоги ЄС повертаються. Як Україні доведеться змінити відбір до ВККС після рішен)
  - (2026-09-29) У Києві дві балістичні ракети впали біля житлових будинків і не розірвалися, їх знешкодили | LEDE: Вибухотехніки поліції Києва знешкодили бойові частини ракет після російської атаки – поліція. ] (uk:…
      Вибухотехніки поліції Києва знешкодили бойові частини ракет після російської атаки – поліція. Пошкоджено будинки, постраждала одна людина.
  - (2026-09-29) Туск: Нас чекають дуже складні місяці через агресивну позицію Росії | LEDE: Польський прем'єр Дональд Туск заявив, що його країну чекають "дуже складні тижні та місяці" через дедалі агресивніші] (uk:…
      Польський прем'єр Дональд Туск заявив, що його країну чекають "дуже складні тижні та місяці" через дедалі агресивніші дії Росії щодо України.
  - (2026-09-29) Фон дер Ляєн презентувала план зі зміцнення зовнішніх кордонів ЄС | LEDE: Урсула фон дер Ляєн оголосила нову стратегію Єврокомісії для посилення кордонів і співпраці з партнерами на тлі подій у] (uk:…
      Урсула фон дер Ляєн оголосила нову стратегію Єврокомісії для посилення кордонів і співпраці з партнерами на тлі подій у Сеуті.

### IT, InfoSys & cybersecurity news (last 7 days) — 47 new of 58 total
  - (2026-09-29) [BleepingComputer] Vietnamese man charged in $16 million 'pig butchering' crypto scam
      A Vietnamese national was charged with money laundering for his role in a massive "pig butchering" scam, which defrauded a victim out of $16 million worth of cryptocurrency. [...]
  - (2026-09-29) [BleepingComputer] Kiteworks patches critical flaw, brings customer systems online
      American tech company Kiteworks has lifted a precautionary advisory asking customers to shut down systems after patching a critical vulnerability. [...]
  - (2026-09-29) [BleepingComputer] Apple patches CoreGraphics zero-day flaw exploited in attacks
      Apple released security updates to fix a zero-day vulnerability exploited in "extremely sophisticated" targeted attacks on iOS devices. [...]
  - (2026-09-29) [The Hacker News] Dutch Police Arrest 24-Year-Old Amsterdam Man in ShinyHunters Investigation
      Dutch authorities have confirmed that they arrested a 24-year-old man from Amsterdam in connection with the ShinyHunters group. "It is true that this month a 24-year-old man from Amsterdam was arrested in an investigatio…
  - (2026-09-29) [The Hacker News] Official MCP Python SDK Flaw Can Let Malicious Servers Steal OAuth Credentials
      A malicious MCP server could trick an application built on the official MCP Python SDK into handing over the OAuth credentials it uses to log in to a real service, the SDK's maintainers said in a security advisory. Affec…
  - (2026-09-29) [The Hacker News] OpenAI Shelves GPT-6.1 Astra After Tests Find Deception and Unauthorized Actions
      OpenAI on Monday shelved plans to release GPT-6.1 Astra, a next-generation artificial intelligence (AI) model that was planned for an October launch, after it failed internal safety and alignment audits. The development…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-29) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-09-29 13:37 UTC — Filed: 2026-09-29 AccNo: 0001918704-26-029199 Size: 406 KB
  - (2026-09-29) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-09-29 13:37 UTC — Filed: 2026-09-29 AccNo: 0001918704-26-029199 Size: 406 KB
  - (2026-09-29) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-09-29 13:37 UTC — Filed: 2026-09-29 AccNo: 0001918704-26-029198 Size: 1 MB
  - (2026-09-29) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-09-29 13:37 UTC — Filed: 2026-09-29 AccNo: 0001918704-26-029198 Size: 1 MB
  - (2026-09-29) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-09-29 13:36 UTC — Filed: 2026-09-29 AccNo: 0001213900-26-104380 Size: 22 KB
  - (2026-09-29) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-09-29 13:36 UTC — Filed: 2026-09-29 AccNo: 0001213900-26-104380 Size: 22 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-29) [Germany] Equum Medical : Ellenville Regional Hospital Awarded $3 Million to Expand Rural Specialty Access Across New York
      domain: finanznachrichten.de · language: English · tone:
  - (2026-09-29) [Nigeria] Africa : Access to Water and Sanitation in South Africa : a Tale of Insufficiency and Inequality
      domain: allafrica.com · language: English · tone:
  - (2026-09-29) [Canada] 5 subtle symptoms dentists say you should never ignore
      domain: calgarysun.com · language: English · tone:
  - (2026-09-29) [United Kingdom] Saved By The Bell star Dennis Haskins dies aged 75
      domain: eastlondonadvertiser.co.uk · language: English · tone:
  - (2026-09-29) [United States] Treat your feet to the best UGG boots
      domain: mcall.com · language: English · tone:
  - (2026-09-29) [Canada] Brant OPP charge driver , seize 400 pounds of cannabis from vehicle
      domain: simcoereformer.ca · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-29) GAF220 (Germany)
      icao24: 3f62fc · position: (52.832, 13.5851) · alt: 7620m · 745km/h
  - (2026-09-29) PAT440 (United States)
      icao24: adfe54 · position: (38.7188, -79.1842) · alt: 7924m · 460km/h
  - (2026-09-29) GAF390 (Germany)
      icao24: 3f505f · position: (46.7074, 8.0541) · alt: 2087m · 4km/h
  - (2026-09-29) JEDI07 (United States)
      icao24: ae1ea9 · position: (30.4833, -87.9459) · alt: 708m · 401km/h
  - (2026-09-29) SAMU45 (France)
      icao24: 39ca85 · position: (47.8355, 1.9199) · on ground
  - (2026-09-29) FAF7812 (France)
      icao24: 39a858 · position: (45.2509, 1.1058) · alt: 1988m · 299km/h

### Prediction Markets — most-traded (Polymarket) — 19 new of 20 total
  - (2026-09-29) Dota 2: 1win vs Natus Vincere - Game 1 Winner
      yes price: 0% · 24h volume: $1,019,310 · resolves 2026-09-29
  - (2026-09-29) Hangzhou Open: Daniil Medvedev vs Andrey Rublev
      yes price: 100% · 24h volume: $987,517 · resolves 2026-10-06
  - (2026-09-29) Strait of Hormuz traffic returns to normal by September 30?
      yes price: 0% · 24h volume: $566,061 · resolves 2026-10-01
  - (2026-09-29) Valorant: Karmine Corp vs NRG (BO3) - VCT Champions Group D
      yes price: 60% · 24h volume: $555,026 · resolves 2026-09-29
  - (2026-09-29) Dota 2: 1win vs Natus Vincere (BO3) - BLAST Slam Group B
      yes price: 26% · 24h volume: $512,153 · resolves 2026-09-29
  - (2026-09-29) Will Brazil win on 2026-09-29?
      yes price: 100% · 24h volume: $499,935 · resolves 2026-09-29

### Court opinions of consequence (federal & state) — 18 new of 60 total
  - (2026-09-28) U.S. Court of Appeals, 7th Cir.: Brooke Mason v. Cook County, Illinois
  - (2026-09-28) U.S. Court of Appeals, 7th Cir.: Brooke Mason v. Cook County, Illinois
  - (2026-09-28) U.S. Court of Appeals, 11th Cir.: Kandace Edwards v. Randolph County Sheriff
  - (2026-09-28) U.S. Court of Appeals, 9th Cir.: Edwards v. Brown
  - (2026-09-28) U.S. Court of Appeals, 9th Cir.: State of Washington v. Crown Resources Corporation
  - (2026-09-28) U.S. Court of Appeals, 9th Cir.: Diemert v. City of Seattle

### World News (by country, top stories) — 18 new of 18 total
  - (2026-09-29) [China] Momenta partners with DSAT to supply ADAS to Stellantis brands
      just-auto.com · English
  - (2026-09-29) [China] Immediately restore 13+ cr names removed from electoral rolls : Jairam Ramesh reiterates clear demands amid SIR row
      asiabulletin.com · English
  - (2026-09-29) [China] Nissan to lead united kingdom autonomous drive research project
      just-auto.com · English
  - (2026-09-29) [China] Department of Education Organises Four - Day Workshop on Fundamental Remedial Teaching Strategies for Children with Learning Difficulties – Central Tibetan Administration
      tibet.net · English
  - (2026-09-29) [China] Hangzhou Investment Promotion Bureau : Hangzhou Finds a
      asiabulletin.com · English
  - (2026-09-29) [China] Bir Tibetan Settlement Observes Tibetan National Identity Preservation Week – Central Tibetan Administration
      tibet.net · English

### U.S. Federal Action — 17 new of 17 total
  - (2026-09-29) Withdrawal of International Airport Designation of Chalk Seaplane Base
  - (2026-09-29) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain The Boeing Company Model 787-8 and 787-9 airplanes. This AD was prompted by a report of the lack of data to substantiate engine operability when an airpl…
  - (2026-09-29) Medicare Program; Hospital Inpatient Prospective Payment Systems for Acute Care Hospitals (IPPS) and the Long-Term Care Hospital Prospective Payment System and Policy Changes and Fiscal Year (FY) 2027…
      This document corrects technical and typographical errors in the final rule that appeared in the Federal Register on August 4, 2026 titled "Medicare Program; Hospital Inpatient Prospective Payment Systems for Acute Care…
  - (2026-09-29) Safety Zone; Bridge Demolition, Upper Mississippi River, Chester, IL
      The Coast Guard is establishing a temporary safety zone for all navigable waters of the Upper Mississippi River from mile marker 109.5 to mile marker 110.5 near Chester, IL. The safety zone is needed to protect personnel…
  - (2026-09-29) Recodification of Title IX Rules
      The Secretary of Education publishes a final rule to repeal the U.S. Department of Education's (Department) 2024 final rule amending the Title IX regulations and restoring the regulatory text that existed prior to the 20…
  - (2026-09-29) Magnuson-Stevens Act Provisions; Fisheries Off West Coast States; Pacific Coast Groundfish Fishery; 2025-2026 Biennial Specifications and Management Measures; Inseason Adjustments; Correction
      NMFS is taking inseason action to correct its prior omissions in implementing the routine inseason adjustments to management measures in commercial groundfish fisheries published on August 20, 2026. This action revises r…

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-09-29) M 5.6 - southern Mid-Atlantic Ridge
      M5.6 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-09-29) M 5.4 - 99 km SSE of Pangai, Tonga
      M5.4 · 99 km SSE of Pangai, Tonga · depth 10 km
  - (2026-09-29) M 5.3 - 76 km NE of Tadine, New Caledonia
      M5.3 · 76 km NE of Tadine, New Caledonia · depth 10 km
  - (2026-09-29) M 5.0 - 77 km ENE of Tadine, New Caledonia
      M5.0 · 77 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-28) M 4.9 - 2 km SW of Sakai, Japan
      M4.9 · 2 km SW of Sakai, Japan · depth 70.972 km
  - (2026-09-28) M 4.9 - 124 km SE of Pondaguitan, Philippines
      M4.9 · 124 km SE of Pondaguitan, Philippines · depth 78.202 km

### GDELT GKG — themes / entities / watch areas — 14 new of 14 total
  - (2026-09-29) [Russia oil sanctions perimeter · keywords] India may be one of the biggest winners if Iran reopens Hormuz : What happens to crude , petrol and diesel prices ?
      moneycontrol.com · English · tone NA
  - (2026-09-29) [Russia oil sanctions perimeter · keywords] Iran Regime Faces Deepening Oil Export Crisis as New Sales to China Dry Up
      irannewsupdate.com · English · tone NA
  - (2026-09-29) [Russia oil sanctions perimeter · keywords] Arab News | Why Trump rejected Iran Hormuz deal but kept the negotiating channel open
      arabnews.com · English · tone NA
  - (2026-09-29) [Russia oil sanctions perimeter · keywords] Caucasian Knot | Drivers in North Ossetia doubted the usefulness of volunteers in combating queues at gas stations .
      eng.kavkaz-uzel.eu · English · tone NA
  - (2026-09-29) [Russia oil sanctions perimeter · keywords] Russia oil tariff and India leverage gap
      moneycontrol.com · English · tone NA
  - (2026-09-29) [Russia oil sanctions perimeter · keywords] Liberia Widens Lead As World Top Ship Registry
      allafrica.com · English · tone NA

### Government Action: Sanctions + Procurement + Foreign Agents — 13 new of 104 total
  - (2026-09-28) [OFAC] Issuance of Amended Venezuela General Licenses - Office of Foreign Assets Control (.gov)
      Issuance of Amended Venezuela General Licenses Office of Foreign Assets Control (.gov)
  - (2026-09-28) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 48D Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 48D Authorizing the Supply Office of Foreign Assets Control (.gov)
  - (2026-09-24) [OFAC] Publication of Regulatory Amendments; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) - Office of Foreign Asse…
      Publication of Regulatory Amendments; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) Office of Foreign Assets Control (.gov)
  - (2026-09-28) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 46E Authorizing Certain Ac - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 46E Authorizing Certain Ac Office of Foreign Assets Control (.gov)
  - (2026-09-24) [OFAC] BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 505 Sanctions Penalties Regulations - Office of Foreign Assets Control (.gov)
      BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 505 Sanctions Penalties Regulations Office of Foreign Assets Control (.gov)
  - (2026-09-23) [OFAC] Democratic Republic of the Congo-related Designations Removals - Office of Foreign Assets Control (.gov)
      Democratic Republic of the Congo-related Designations Removals Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 8 new of 108 total
  - (2026-09-29) [Manifold] US Average Gas Price Is $4.3800 or more on October 5 2026?
  - (2026-09-29) [Manifold] Will random.org pick 100,000?
  - (2026-09-29) [Manifold] Will a Tesla Roadster hover (all 4 wheels off the ground under its own thrust) at a live demo by October 31, 2026?
  - (2026-09-29) [Manifold] Bitcoin reaches 90k USD at any point before December
  - (2026-09-29) [Manifold] Will the address for math.eg.rego.re receive more than $50 before Oct 1 UTC-12?
  - (2026-09-29) [Manifold] US Average Gas Price Is $4.4200 or more on October 5 2026?

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-29) [Marginal Revolution] Accounting for Cross-Country Income Differences Revisited
      Also known as Why I Do Not Believe in the Housing Theory of Everything: Development accounting is the search for proximate sources of cross-country income differences. This article describes how knowledge in this field h…
  - (2026-09-29) [Marginal Revolution] The Macroeconomic Effect of AI through software engineering
      We measure how artificial intelligence (AI) affects the economy through its impact on software engineering productivity. We use information from financial markets to develop a forward-looking measure that is available in…
  - (2026-09-28) [Marginal Revolution] Man’s best friend?
      When it comes to bear encounters in or near the wild, dogs are the aggressors in 54 percent of incidents, according to a recent study conducted by bear experts at Brigham Young University and other institutions, and publ…
  - (2026-09-28) [Conversable Economist] I Would Like the Value of My Home to Rise, While My Property Taxes Fall
      Many of us are inconsistent in our economic desires. I would like the price of my home to rise, because it increases my wealth, but I would also like the prices of all other homes to fall, so that I could sell my house a…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 1 new of 39 total
  - (2026-09-29) [Crypto error] HTTPError
      403 Client Error: Forbidden for url: https://api.coingecko.com/api/v3/simple/price?ids=bitcoin%2Cethereum%2Ctether%2Cusd-coin%2Cworld-liberty-financial-usd%2Cbinancecoin%2Csolana%2Cripple%2Cdogecoin%2Ccardano&vs_currenci…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-29) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=18, 14d-median=18; carrying terms: proposed, program, final, certain, state, proposes, management, published, provide, directives, issuing, regulatory
- state_bills: today=61, 7d-median=120, 14d-median=105; carrying terms: energy, years, related, provided, water, protection, pilot, appropriate, january, prohibits, program, among
- state_news: today=529, 7d-median=604, 14d-median=604; carrying terms: american, deseret, least, black, democracy, thinking, intelligence, prevent, panel, democrats, speech, cases
- local_news: today=242, 7d-median=227, 14d-median=231; carrying terms: magazine, according, blank, restaurant, police, missing, school, accused, house, following, student, still
- foreign_news: today=1019, 7d-median=1019, 14d-median=1019; carrying terms: related, using, premier, httpsconnectionpool, panel, march, align, society, vnexpress, cases, crime, continues
- chinese_internal: today=292, 7d-median=270, 14d-median=274; carrying terms: cbmib, blank, cbmia, china, global, cbmix, people, cbmidefvx, chinese, cbmibefvx, caixin, cbmiaefvx
- russian_internal: today=960, 7d-median=1011, 14d-median=1042; carrying terms: reuters, istories, novayagazeta, financial, politico, openai, server, found, httperror, russian, gazeta, media
- ukrainian_internal: today=110, 7d-median=129, 14d-median=134; carrying terms: country, energy, years, least, black, cabinet, facility, zelensky, intelligence, update, ukrainian, vladimir
- ukraine_theater: today=579, 7d-median=379, 14d-median=426; carrying terms: unrnqwlirmdydfhlrevebxlsc, command, juogxpvla, luzupcnkpheunxnwdfau, cbmimwfbvv, march, ckxaa, ntuejdulfxr, procurement, cldynmltnwrzrzbvtxjnvlbkcu, cartography, snnftqxbquxntb
- paper_bets: today=108, 7d-median=119, 14d-median=124; carrying terms: manifold, wisconsin, colonize, mamdani, total, humans, pennsylvania, become, nomination, hampshire, florida, labor
- weather: today=127, 7d-median=146, 14d-median=117; carrying terms: message, america, worth, northern, gusts, water, waters, continues, cooler, afdlsx, region, magnitude
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, spread, total, supply, commodities, pcepilfe, energy, personal, funds, jolts, indicator, cpiaucsl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, corporate, close, range, agriculture, credit, rates, commodities, china, large, russell, bitcoin
- markets_global: today=39, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=103, 14d-median=104; carrying terms: involvement, satisfying, threatening, checksum, resolution, recognition, related, chemical, entities, annexation, bissau, trade
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quiverquant, congresstrading, https, client, error, quiver, quantitative, httperror
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: company, supreme, court, appeals, commissioner, trade, state, arizona, international, corporation, colorado, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed, holdings, trust, filer, financial, technology, subject, finance, series
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: house, brown, alexandria, ocasio, james, sherrod, booker, robert, lindsey, cycle, warner, angels
- gdelt_regions: today=18, 7d-median=6, 14d-median=6; carrying terms: english, south, japan
- gdelt_gkg: today=14, 7d-median=25, 14d-median=38; carrying terms: english, trump, sanctions, ukraine, russia, chinese, russian, perimeter, keywords, prices, north, putin
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: domain, language, kingdom, english, trump, india, iheart, state
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, germany, france, kingdom, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: transmitted, country, laboratory, total, centers, genomic, pregnant, surges, challenge, epidemiological, death, years
- cisa_kev: today=18, 7d-median=18, 14d-median=19; carrying terms: authorization, engine, remediation, multiple, cisco, based, traversal, vulnerability, improper, write, injection, bounds
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=16, 7d-median=16, 14d-median=15; carrying terms: indonesia, depth, islands, south, region, japan, russia, tadine, tonga, vanuatu, caledonia, sandwich
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, league, championship, donetsk, champions, shakhtar, september, group, invade, russia
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, class, conversableeconomist, revolution, economist, https, conversable, basic, known, since, marginalrevolution, wealth
- tech_news: today=58, 7d-median=57, 14d-median=57; carrying terms: download, total, years, company, schneier, discovery, daily, using, intelligence, edition, world, according
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: hillary, barrag, agriculture, monica, lindsey, hoyer, daines, stutzman, baird, energy, cleaver, salazar
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, placed, converges, decision, module, sufficient, evidence, paper, claude, markets, either, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-22] ECB press: Philip R. Lane: Interview with Le Temps
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-23] ECB press: Almost ten million people took part in ECB survey on new euro banknotes
- [2026-09-23] Fed speeches: Barr, A Long-Term View on the Costs of Shelter
- [2026-09-23] ECB press: The digitalisation of money, payments and finance
- [2026-09-23] ECB press: Philip R. Lane: The Outlook for the Euro Area Economy
- [2026-09-24] ECB press: Philip R. Lane: The outlook for the euro area economy
- [2026-09-24] ECB press: ECB Executive Board member Isabel Schnabel to resign to take senior role at IMF
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board requests public comment on two proposals related to establishing a regulatory framework for Board-supervised payment stablecoin issuers under the GENIUS Act
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*