# WORLDSCOPE morning brief — 2026-08-27

## Headline
3460 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (752) · Russian Internal News (state + in-exile) (734) · State-Level News (337) · World leaders & government officials (324) · Chinese Internal News (231) · Local News: St. Louis + Atlanta (200) · State Legislative Action (197) · Ukraine Theater (total-war monitoring) (195) · U.S. Weather + Severe / Climate Outlooks (139) · Ukrainian Internal News (national + local Kyiv) (61) · IT, InfoSys & cybersecurity news (last 7 days) (42) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 752 new of 1039 total
  - (2026-08-27) [Global] Game of Drones: Deep strikes into Russia keeping Ukraine 'in this game'
      Mark Owen is pleased to welcome Peter Zalmayev, Director of the Eurasia Democracy Initiative. He argues that Ukraine’s expanding long-range strike campaign has helped Ukraine “stay in this game” by raising the economic,…
  - (2026-08-27) [Global] 🔴 Nepal-Tibet floods live: Nearly 1,500 people missing in devastating landslides
  - (2026-08-27) [Global] Champions League heartbreak: Lyon knocked out in playoffs
      Defeated by Turkish side Fenerbahçe, Lyon will not be competing in Europe’s most prestigious club competition this year. Six years after their last Champions League campaign, Lyon had set their sights on returning to the…
  - (2026-08-27) [Global] Japanese avant-garde artist Yayoi Kusama dies at 97
      Japanese artist Yayoi Kusama died at the age of 97 on August 14 in Tokyo, her company said Thursday. The avant-garde artist known as the “polka dot queen” had channelled her hallucinations and traumas into her work over…
  - (2026-08-27) [Global] UEFA to lift FIFA boycott threat ahead of Champions League draw
      European soccer body UEFA is set to formally withdraw its threat to boycott FIFA competitions after receiving assurances Gianni Infantino’s failed World Cup sell-off plan will not be revived. UEFA’s member federations ar…
  - (2026-08-27) [Global] Man drives car into group of pedestrians in French city of Caen, killing two
      A car ploughed into pedestrians in the French city of Caen late Wednesday, killing two people and injuring 10 others, including seven critically. Police detained a 26-year-old man after he fled the scene, while prosecuto…

### Russian Internal News (state + in-exile) — 734 new of 1159 total
  - (2026-08-27) «Обсудили вопросы, которые находятся в компетенции разведслужб». Нарышкин рассказал о встрече с директором ЦРУ | LEDE: Глава Службы внешней разведки (СВР) Сергей Нарышкин рассказал, что встр] (ru: «Об…
      Глава Службы внешней разведки (СВР) Сергей Нарышкин рассказал, что встретился с директором ЦРУ Джоном Рэтклиффом, который 25 августа приезжал в Москву. По его словам, они «обсудили ряд вопросов, которые находятся в компе…
  - (2026-08-27) «Фонтанка»: в Петербурге взорвали автомобиль, погиб российский военный | LEDE: В Санкт-Петербурге на Колпинском шоссе в автомобиле сработало самодельное взрывное устройство, сообщает «Фонтан] (ru: «Фо…
      В Санкт-Петербурге на Колпинском шоссе в автомобиле сработало самодельное взрывное устройство, сообщает «Фонтанка».
  - (2026-08-27) Кремль: России не нужна военная эскалация, потому что армия и так продвигается вперед | LEDE: Россия дает «жесткий ответ» на удары Украины по российской экономической и торговой инфраструкту] (ru: Кре…
      Россия дает «жесткий ответ» на удары Украины по российской экономической и торговой инфраструктуре, но военная эскалация Москве «просто не нужна». Об этом пресс-секретарь президента России Дмитрий Песков заявил агентству…
  - (2026-08-27) Бывшего «короля госзаказа» заочно приговорили в России к 12 годам колонии по делу о взятке полковнику Захарченко | LEDE: Басманный районный суд Москвы заочно приговорил бывшего совладельца г] (ru: Быв…
      Басманный районный суд Москвы заочно приговорил бывшего совладельца группы компаний «1520» Бориса Ушеровича к 12 годам колонии строгого режима по делу о даче взятки бывшему полковнику МВД Дмитрию Захарченко. Об этом сооб…
  - (2026-08-27) Умерла японская художница Яёи Кусама | LEDE: Японская авангардная художница Яёи Кусама умерла в возрасте 97 лет, сообщается на ее сайте. ] (ru: Умерла японская художница Яёи Кусама)
      Японская авангардная художница Яёи Кусама умерла в возрасте 97 лет, сообщается на ее сайте.
  - (2026-08-27) Forbes опубликовал рейтинг богатейших женщин России. Татьяна Ким осталась лидером, но из-за атак на Wildberries она потеряла два миллиарда долларов | LEDE: Журнал Forbes опубликовал новый ре] (ru: For…
      Журнал Forbes опубликовал новый рейтинг богатейших женщин России. Суммарный капитал участниц списка значительно снизился по сравнению с прошлым годом: в 2025 году он составлял 25,75 миллиарда долларов, в нынешнем — 18,95…

### State-Level News — 337 new of 660 total
  - (2026-08-27) [California] Newsom pushes environmental carve-out for campaign donor’s Santa Monica project
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/021621_Santa-Monica-Pier_GETTY_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-08-26) [California] California sues to block Trump’s mail-in voting rules just days after loss at Supreme Court
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/11082022-Election-Day-RL-CM-15.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-08-26) [California] Equipos federales de lucha contra incendios forestales están sobrecargados. California está interviniendo para ayudar
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/072226_Diablo-Canyon-Fire-Gaps_LV_CM_02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-po…
  - (2026-08-26) [California] Con el tiempo en contra, los legisladores de California rechazan partes clave del plan de Newsom para combatir los incendios forestales
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082426-Eaton-Fire-Survivors-MG-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-08-26) [California] Meta to pay $17 billion — and limit ‘likes’ for teens — in social media settlement with states
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082626-Teen-Phone-Use-IS-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-08-26) [California] Gavin Newsom’s last-minute wildfire plan hits friction in Capitol
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082426-Eaton-Fire-Survivors-MG-CM-02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 231 new of 288 total
  - (2026-08-26) 8.86秒，人形机器人百米竞速再次刷新纪录 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBJTFBEM0xSWkd0THh5TEhiY2h2VU9YTElyZ1F4bzIzM2VCNlpZN3J2QmxRWWdOS1dpc1ZnZk9UZmI4YXVZNHRUc] (zh:…
      8.86秒，人形机器人百米竞速再次刷新纪录 Caixin Global
  - (2026-08-25) 第四届“萌芽”论坛在喀山举行中俄地方合作持续深化_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5qaU9aeGpfblk1VFJnZ0c3OUNCSG80Tmt2SXUyNmtFd2VxNDVQNUQ0NkNPMFBrSzZWZjZGcGFwSGlBZUw3Yj] (zh:…
      第四届“萌芽”论坛在喀山举行中俄地方合作持续深化_特别呈现_手机财新网 财新
  - (2026-08-27) 送别唐师曾：敢言且力行｜纪念 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBSUVJDejkxN2N5R2dadG1uc19CbFJqcXlXdGFzNDI4aGdReGgzZ2FRaVFQNjktTF9uV0ltSDQyS2tjSmpJTmVTT2JFeUpL] (zh:…
      送别唐师曾：敢言且力行｜纪念 Caixin Global
  - (2026-08-27) 今日开盘：沪指报3911.89点 跌幅0.02% - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9MTDZJNFVlQWpPSTNlaEJZd0hCRmZaRm5xWUsxbGZpX0VIOXFJaVRmR19mRlBQVlE4Z2JZNk5zMHFlTGRtZV] (zh:…
      今日开盘：沪指报3911.89点 跌幅0.02% Caixin Global
  - (2026-08-25) 做好中小学、幼儿园学段衔接，教育部发布问答 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1QdThLdDlqZ2NZWldFQ3hlQVB2Y0laVDNCcGNQelB3STVsc1lKUmhsX2RVcEN3bG9pd1dLU19kOXFWVkd0eThkO] (zh:…
      做好中小学、幼儿园学段衔接，教育部发布问答 Caixin Global
  - (2026-08-27) 从易炼红到叶建春 江西八年两任省长落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFAxR2M1VDF4endlWFo3elN4cThQaF93Nm9oUjdHQ29QUldKRlVUOHR2ZVluYVJidG5XNlJqZ0JSb25xQTBiWVZG] (zh:…
      从易炼红到叶建春 江西八年两任省长落马 china.caixin.com

### Local News: St. Louis + Atlanta — 200 new of 236 total
  - (2026-08-27) [St. Louis] Where in the Lou? – 8/27/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-08-26) [St. Louis] Missouri pastor Kenneth Sparks is found guilty on all counts
      After a three-day trial in federal court, a Missouri minister was found guilty on 20 counts related to pandemic loan fraud. Kenneth Sparks, aka Apostle KC Sparks, was indicted in July of 2024 on 33 counts of wire fraud,…
  - (2026-08-26) [St. Louis] The Clydesdale opens August 27 at Ballpark Village
      Ballpark Village is betting that a beloved hometown chef will provide its next culinary chapter: James Beard Award-winning chef Kevin Nashan has partnered with Live! Hospitality & Entertainment to open The Clydesdale (60…
  - (2026-08-26) [St. Louis] Worried about your memory? These St. Louis resources can help protect your brain health
      We all forget why we walked into a room or struggle to recall a name from time to time. But when do those everyday memory lapses become something worth mentioning to a doctor? And just as importantly, what can we do now…
  - (2026-08-26) [St. Louis] Paint Louis returns for a weekend of hip-hop and graffiti on the riverfront
      Every year, across Labor Day weekend, the flood wall along the riverfront takes on a new life. Take a walk along the 2.5-mile stretch that reaches from Chouteau to Arsenal, and you’ll hear the hiss of spray paint as hund…
  - (2026-08-26) [St. Louis] Meet Brian the Balloon Guy, the St. Louis balloon artist taking kids’ parties to the next level
      A balloon dog is one thing. A 6-foot-tall Charizard made from roughly 150 balloons is another. For St. Louis entertainer Brian the Balloon Guy, twisting balloons for kids’ birthday parties has grown into an art form, a s…

### State Legislative Action — 197 new of 229 total
  - (2026-08-27) [Alaska HB 271] An Act relating to the royalty rate for the Kitchen Lights Unit; and providing for an effective date.
      An Act relating to the royalty rate for the Kitchen Lights Unit; and providing for an effective date.
  - (2026-08-27) [Alaska HB 195] An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to th…
      An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to the prescription of opioid overdose dr…
  - (2026-08-26) [Alaska HB 261] An Act relating to education funding; providing for an effective date by amending the effective date of secs. 10, 11, 13, and 15, ch. 5, SLA 2025; and providing for an effective date.
      An Act relating to education funding; providing for an effective date by amending the effective date of secs. 10, 11, 13, and 15, ch. 5, SLA 2025; and providing for an effective date.
  - (2026-08-26) [California SB 661] Airports: financial assistance.
      The State Aeronautics Act establishes the Aeronautics Account in the State Transportation Fund, and continuously appropriates the moneys in the account for expenditure for airport purposes by the Division of Aeronautics…
  - (2026-08-26) [California SB 991] Residential care facilities for the elderly: categorization of citations.
      Existing law, the California Residential Care Facilities for the Elderly Act (act) , requires the State Department of Social Services to license, inspect, and regulate residential care facilities for the elderly, as defi…
  - (2026-08-26) [California AB 2051] Public resources: coastal resources: Coastal Resilience Permitting Working Group.
      (1) The California Coastal Act of 1976 requires any person wishing to perform or undertake any development in the coastal zone, as defined, in addition to obtaining any other permit required by law from any local governm…

### Ukraine Theater (total-war monitoring) — 195 new of 479 total
  - (2026-08-27) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-26) [FIRMS] thermal anomaly 47.259, 34.191 (FRP 11.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-26 0954Z, FRP 11.25 MW
  - (2026-08-26) [FIRMS] thermal anomaly 44.977, 34.069 (FRP 1.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-26 0954Z, FRP 1.35 MW
  - (2026-08-26) [FIRMS] thermal anomaly 45.492, 34.967 (FRP 5.21 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-26 0954Z, FRP 5.21 MW
  - (2026-08-26) [FIRMS] thermal anomaly 46.373, 34.214 (FRP 2.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-26 0954Z, FRP 2.76 MW
  - (2026-08-26) [FIRMS] thermal anomaly 46.589, 34.773 (FRP 23.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-26 0954Z, FRP 23.77 MW

### U.S. Weather + Severe / Climate Outlooks — 139 new of 141 total
  - (2026-08-27) [Moderate] Special Weather Statement: Special Weather Statement issued August 27 at 4:28AM CDT by NWS Amarillo TX
      At 427 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from Mocane to 3 miles west of Elmwood to 3 miles northeast of Perryton. Movement was east at 25 mph. HAZARD...Wind gusts up to 50 mph…
  - (2026-08-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-27) [Severe] Special Marine Warning: Special Marine Warning issued August 27 at 4:26AM CDT until August 27 at 5:30AM CDT by NWS New Orleans LA
      SMWLIX The National Weather Service in New Orleans has issued a * Special Marine Warning for... Lake Pontchartrain... * Until 530 AM CDT. * At 426 AM CDT, a severe thunderstorm was located near The Mid Point Of The Cause…
  - (2026-08-27) [Moderate] Special Weather Statement: Special Weather Statement issued August 27 at 4:23AM CDT by NWS New Orleans LA
      At 423 AM CDT, Doppler radar was tracking strong thunderstorms along a line extending from near Salem to near Maringouin. Movement was east at 35 mph. HAZARD...Winds in excess of 40 mph. SOURCE...Radar indicated. IMPACT.…
  - (2026-08-27) [Moderate] Heat Advisory: Heat Advisory issued August 27 at 4:11AM CDT until August 27 at 8:00PM CDT by NWS Fort Worth TX
      * WHAT...Heat index values up to 109. * WHERE...Portions of North and Central Texas * WHEN...Until 8 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity will increase the risk for heat-related illnesses t…
  - (2026-08-27) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 27 at 2:06AM MST until August 29 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with high temperatures ranging between 104 to 110 degrees and low temperatures 79 to 85 degrees. Major to Extreme HeatRisk today through Saturday. * WHERE...Pinal County, Tohono O'odha…

### Ukrainian Internal News (national + local Kyiv) — 61 new of 119 total
  - (2026-08-27) ГУР і СЗР: Росія готує нову хвилю мобілізації на 600 тисяч людей | LEDE: Росія планує мобілізувати 600 тисяч людей у 2026–2027 роках для війни проти України. Готуються примусові заходи й нове з] (uk:…
      Росія планує мобілізувати 600 тисяч людей у 2026–2027 роках для війни проти України. Готуються примусові заходи й нове законодавство.
  - (2026-08-27) Буданов прокоментував "плівки" з Мудрою: Хай суд розбирається, де хто лунає | LEDE: Голова Офісу президента Кирило Буданов уперше прокоментував інформацію, що його ім'я лунало на записах прослу] (uk:…
      Голова Офісу президента Кирило Буданов уперше прокоментував інформацію, що його ім'я лунало на записах прослуховувань його заступниці Ірини Мудрої, яка фігурує в новій справі антикорупційних органів.
  - (2026-08-27) Командувач литовської армії впевнений, що війська США вже скоро прибудуть до Литви | LEDE: Командувач Збройних сил Литви Раймундас Вайкшнорас переконує, що Сполучені Штати невдовзі замінять аме] (uk:…
      Командувач Збройних сил Литви Раймундас Вайкшнорас переконує, що Сполучені Штати невдовзі замінять американських військових, які завершили ротацію в Литві на початку червня.
  - (2026-08-27) Дрон РФ атакував маршрутку в Херсоні: поранено трьох людей | LEDE: Російський безпілотник поцілив у маршрутний автобус у Херсоні: внаслідок атаки поранення дістали троє людей.] (uk: Дрон РФ атакував м…
      Російський безпілотник поцілив у маршрутний автобус у Херсоні: внаслідок атаки поранення дістали троє людей.
  - (2026-08-27) У Норвегії заявили про важкий стан здоров'я короля, до лікарні прибула його родина | LEDE: Стан здоров'я 89-річного короля Норвегії Гаральда погіршився під час перебування в лікарні.] (uk: У Норвегії…
      Стан здоров'я 89-річного короля Норвегії Гаральда погіршився під час перебування в лікарні.
  - (2026-08-27) Польща просить Єврокомісію оштрафувати Meta на 250 млн євро за шахрайську рекламу | LEDE: Польський уряд звернувся до Європейської комісії з проханням накласти штраф у розмірі 250 мільйонів євр] (uk:…
      Польський уряд звернувся до Європейської комісії з проханням накласти штраф у розмірі 250 мільйонів євро на компанію Meta, звинувативши її у нездатності належним чином боротися з шахрайською рекламою.

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 55 total
  - (2026-08-27) [BleepingComputer] CISA orders feds to patch Citrix NetScaler RCE flaw by Saturday
      CISA has ordered U.S. government agencies to patch their Citrix NetScaler appliances against an actively exploited remote code execution vulnerability by Saturday. [...]
  - (2026-08-27) [BleepingComputer] ATF confirms “major incident” after recent Qilin breach claims
      ATF, the regulatory agency that enforces federal laws governing firearms and explosives in the United States, has confirmed that one of its systems was compromised after breach claims made by the Qilin ransomware gang. […
  - (2026-08-27) [The Hacker News] New GPUThor Rowhammer Defeats ECC on NVIDIA RTX A6000 to Gain Host Root Access
      Academic researchers have disclosed a Rowhammer attack impacting NVIDIA workstation GPUs with GDDR6 memory that defeats error correction codes (ECC), the mitigation NVIDIA recommends against GPU Rowhammer, and enables de…
  - (2026-08-27) [The Hacker News] CISA Adds Six Exploited Flaws to KEV, Including NetScaler, Linux, and SQL Server Bugs
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Wednesday added six flaws to its Known Exploited Vulnerabilities (KEV) catalog, including a high-severity security vulnerability impacting Citrix NetSca…
  - (2026-08-27) [The Register] Check out the width of that Debian display
      Somebody might be aware, but does anyone care?
  - (2026-08-27) [The Register] AI use among UK teachers doubles, but working hours still don't come down
      F- for AI in test of reducing burden of teacher workload

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-27) [Aljomaih Automotive Co.] Form 4 (Reporting)
      filed 2026-08-27 01:59 UTC · role: Reporting — Filed: 2026-08-26 AccNo: 0001878366-26-000026 Size: 6 KB
  - (2026-08-27) [Xos, Inc.] Form 4 (Issuer)
      filed 2026-08-27 01:59 UTC · role: Issuer — Filed: 2026-08-26 AccNo: 0001878366-26-000026 Size: 6 KB
  - (2026-08-27) [Jiang Xiao] Form 4 (Reporting)
      filed 2026-08-27 01:51 UTC · role: Reporting — Filed: 2026-08-26 AccNo: 0001628280-26-059160 Size: 9 KB
  - (2026-08-27) [FARADAY FUTURE INTELLIGENT ELECTRIC INC.] Form 4 (Issuer)
      filed 2026-08-27 01:51 UTC · role: Issuer — Filed: 2026-08-26 AccNo: 0001628280-26-059160 Size: 9 KB
  - (2026-08-27) [Wang Jiawei] Form 4 (Reporting)
      filed 2026-08-27 01:41 UTC · role: Reporting — Filed: 2026-08-26 AccNo: 0001628280-26-059156 Size: 9 KB
  - (2026-08-27) [FARADAY FUTURE INTELLIGENT ELECTRIC INC.] Form 4 (Issuer)
      filed 2026-08-27 01:41 UTC · role: Issuer — Filed: 2026-08-26 AccNo: 0001628280-26-059156 Size: 9 KB

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-08-27) #1 Elon Musk — $862.39B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-08-27) #2 Larry Page — $279.72B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-08-27) #3 Jeff Bezos — $268.10B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-08-27) #4 Sergey Brin — $258.05B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-08-27) #5 Michael Dell — $240.22B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-08-27) #6 Mark Zuckerberg — $197.87B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 28 new of 29 total
  - (2026-08-27) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain The Boeing Company Model 787-8, 787-9, and 787-10 airplanes. This AD was prompted by a Boeing investigation for manufacturing errors and excessive preloa…
  - (2026-08-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-211, -212, -214, -216, -231, -232, and - 233 airplanes; and Model A321-111, -112, -131, -211, -212, -213, -231, and -232 airplanes.…
  - (2026-08-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-25- 06, which applied to all Airbus SAS Model A318 and A320 series airplanes; and Model A319-111, -112, -113, -114, -115, -131, -132, - 133, -151N, -153N, and -171…
  - (2026-08-27) Farmer Bridge Assistance (FBA) Program; Correction
      The Commodity Credit Corporation (CCC) announced the Farmer Bridge Assistance (FBA) Program in a final rule on February 23, 2026. This correction amends the definition of "corn" to add blue and red corn, which are eligib…
  - (2026-08-27) Schedules of Controlled Substances: Placement of Cipepofol in Schedule IV
      On May 29, 2026, the United States Food and Drug Administration (FDA) approved a new drug application for Cypsedo (cipepofol) for induction of general anesthesia in adults undergoing surgery. The Department of Health and…
  - (2026-08-27) Schedules of Controlled Substances: Temporary Placement of 5,6-Dichloro Brorphine, 5,6-Dichloro Desmethylchlorphine, N-Propionitrile Chlorphine, and Spirochlorphine in Schedule I of the Controlled Sub…
      The Drug Enforcement Administration (DEA) issues this temporary order to schedule 1-(1-(1-(4-bromophenyl)ethyl)piperidin-4- yl)-5,6-dichloro-1,3-dihydro-2H-benzo[d]imidazol-2-one (commonly known as 5,6-dichloro brorphine…

### Paper Trading Scorecard — 25 new of 134 total
  - (2026-08-27) [Polymarket] Will SpaceX have between 160-179 launches in 2026?
      This market will resolve according to the number of SpaceX launches between January 1, 2026, 12:00AM ET and December 31, 2026, 11:59PM ET. If the reported total number of SpaceX launches falls exactly between two bracket…
  - (2026-08-27) [Polymarket] Will OpenAI's valuation hit (HIGH) $1.0T by December 31?
      This market will resolve to "Yes" if OpenAI's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or exc…
  - (2026-08-27) [Polymarket] Will the Washington Commanders win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-08-27) [Polymarket] OpenAI announces it has achieved AGI before 2027?
      This market will resolve to "Yes" if OpenAI or an official representative of the company announces that it has created an artificial general intelligence (AGI) by December 31, 2026 ET. Otherwise, this market will resolve…
  - (2026-08-27) [Polymarket] Will Alphabet be the third-largest company in the world by market cap on August 31?
      This market will resolve to the third-largest company in the world by market cap on August 31, 2026, as of market close. The resolution source for this market will be a consensus of credible reporting.
  - (2026-08-27) [Polymarket] LoL: Nongshim Red Force vs BNK FEARX - Game 2 Winner
      This market refers to the LoL Lower bracket semifinal match between Nongshim Red Force and BNK FEARX in the LCK Play-In, initially scheduled for August 27, 2026 at 4:00 AM ET. This market will resolve to "Nongshim Red Fo…

### Government & military aircraft airborne (OpenSky) — 25 new of 27 total
  - (2026-08-27) JAF9XT (Bulgaria)
      icao24: 4520d0 · position: (48.3615, 6.6874) · alt: 5882m · 681km/h
  - (2026-08-27) GAF125 (Germany)
      icao24: 3f62fc · position: (48.3615, 13.5358) · alt: 7002m · 827km/h
  - (2026-08-27) GAF113 (Germany)
      icao24: 3f7588 · position: (51.3516, 13.3278) · alt: 10058m · 783km/h
  - (2026-08-27) PUMA20 (United States)
      icao24: a00001 · position: (40.7029, -3.2907) · alt: 1524m · 233km/h
  - (2026-08-27) JAF63N (Belgium)
      icao24: 44d1a7 · position: (50.9006, 4.4931) · on ground · 46km/h
  - (2026-08-27) JAF1DY (Belgium)
      icao24: 44d1a5 · position: (36.0822, 10.4406) · on ground · 3km/h

### Court opinions of consequence (federal & state) — 22 new of 60 total
  - (2026-08-26) U.S. Court of Appeals, 8th Cir.: United States v. Rodney McIntosh
  - (2026-08-26) U.S. Court of Appeals, 8th Cir.: West Series of Lockton Companies, LLC v. Eric Kaufman
  - (2026-08-26) U.S. Court of Appeals, 6th Cir.: Dennis O'Connor v. Rachael Eubanks
  - (2026-08-26) U.S. Court of Appeals, 7th Cir.: Central States SE & SW Areas Health & Welfare Fund v. Alan McClain
  - (2026-08-26) U.S. Court of Appeals, 1st Cir.: Fellers v. Kelley
  - (2026-08-26) U.S. Court of Appeals, 3rd Cir.: United States v. LaMonica McIver

### Government Action: Sanctions + Procurement + Foreign Agents — 13 new of 108 total
  - (2026-08-26) [OFAC] Counter Terrorism Designations; Issuance of Counter Terrorism General License; Issuance of Amended Russia-related General License - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Issuance of Counter Terrorism General License; Issuance of Amended Russia-related General License Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Global Terrorism Sanctions Regulations 31 CFR. Part 594 GENERAL LICENSE NO. 36 Authorizing the - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Global Terrorism Sanctions Regulations 31 CFR. Part 594 GENERAL LICENSE NO. 36 Authorizing the Office of Foreign Assets Control (.gov)
  - (2026-08-27) [USASpending] $1,680,767,128 → ORACLE HEALTH GOVERNMENT SERVICES, INC.: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
      Agency: Department of Veterans Affairs. Description: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
  - (2026-08-27) [USASpending] $1,066,387,866 → BOOZ ALLEN HAMILTON INC: THE PURPOSE OF THIS EFFORT IS TO ACQUIRE CONTRACTOR SERVICES
      Agency: General Services Administration. Description: THE PURPOSE OF THIS EFFORT IS TO ACQUIRE CONTRACTOR SERVICES TO PROVIDE REAL-TIME, COMPREHENSIVE THREAT ANALYSIS AND ASSESSMENT, TRAINING DEVELOPMENT AND DELIVERY, RE…
  - (2026-08-27) [USASpending] $1,060,163,601 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-08-27) [USASpending] $923,446,339 → HII MISSION TECHNOLOGIES CORP: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED
      Agency: General Services Administration. Description: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED TO ALION SCIENCE AND TECHNOLOGY CORPORATION TO PROVIDE CONTRACTOR SUPPORT TO THE JOINT CAPABILITY EMBEDDE…

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-08-26) M 5.6 - 212 km E of Onagawa Chō, Japan
      M5.6 · 212 km E of Onagawa Chō, Japan · depth 10 km
  - (2026-08-27) M 5.3 - Volcano Islands, Japan region
      M5.3 · Volcano Islands, Japan region · depth 10 km
  - (2026-08-27) M 5.1 - South Atlantic Ocean
      M5.1 · South Atlantic Ocean · depth 10 km
  - (2026-08-26) M 5.0 - 54 km NNW of Ende, Indonesia
      M5.0 · 54 km NNW of Ende, Indonesia · depth 10 km
  - (2026-08-26) M 4.9 - 42 km NE of Ruteng, Indonesia
      M4.9 · 42 km NE of Ruteng, Indonesia · depth 10 km
  - (2026-08-26) M 4.9 - 4 km E of Jordán, Colombia
      M4.9 · 4 km E of Jordán, Colombia · depth 159.913 km

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-27) Counter-Strike: Vitality vs Inner Circle Esports (BO3) - BLAST Open Porto Group B
      yes price: 80% · 24h volume: $1,502,366 · resolves 2026-08-27
  - (2026-08-27) Will Augusto Cury win the 2026 Brazilian presidential election?
      yes price: 2% · 24h volume: $1,263,243 · resolves 2026-10-04
  - (2026-08-27) Counter-Strike: MOUZ vs 9z (BO3) - BLAST Open Porto Group B
      yes price: 64% · 24h volume: $1,237,630 · resolves 2026-08-27
  - (2026-08-27) LoL: Nongshim Red Force vs BNK FEARX - Game 2 Winner
      yes price: 0% · 24h volume: $992,609 · resolves 2026-08-27
  - (2026-08-27) Will FC Barcelona win on 2026-08-27?
      yes price: 80% · 24h volume: $675,065 · resolves 2026-08-27
  - (2026-08-27) LoL: Nongshim Red Force vs BNK FEARX - Game 1 Winner
      yes price: 100% · 24h volume: $628,267 · resolves 2026-08-27

### CISA Known Exploited Vulnerabilities (last 14d) — 6 new of 17 total
  - (2026-08-26) CVE-2021-23758 · Ajax.NET Professional Ajax.NET Professional: Ajax.NET Professional Deserialization of Untrusted Data Vulnerability
      vendor: Ajax.NET Professional · product: Ajax.NET Professional · CISA remediation by 2026-09-09
  - (2026-08-26) CVE-2015-3246 · Red Hat Libuser: Red Hat Libuser Race Condition Vulnerability
      vendor: Red Hat · product: Libuser · CISA remediation by 2026-09-09
  - (2026-08-26) CVE-2015-5287 · Red Hat Automatic Bug Reporting Tool: Red Hat Automatic Bug Reporting Tool Privilege Escalation Vulnerability
      vendor: Red Hat · product: Automatic Bug Reporting Tool · CISA remediation by 2026-09-09
  - (2026-08-26) CVE-2022-0995 · Linux Kernel: Linux Kernel Out-of-Bounds Write Vulnerability
      vendor: Linux · product: Kernel · CISA remediation by 2026-09-09
  - (2026-08-26) CVE-2026-8452 · Citrix NetScaler ADC and NetScaler Gateway: Citrix NetScaler ADC and NetScaler Gateway Improper Restriction of Operations within the Bounds of a Memory Buffer Vulnerability
      vendor: Citrix · product: NetScaler ADC and NetScaler Gateway · CISA remediation by 2026-08-29
  - (2026-08-26) CVE-2019-1068 · Microsoft SQL Server: Microsoft SQL Server Remote Code Execution Vulnerability
      vendor: Microsoft · product: SQL Server · CISA remediation by 2026-08-29

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-27) [Marginal Revolution] Important results on economic mobility
      We use more than 900 million linked employer–employee records covering the entire formal workforce of Brazil to examine when cities provide upward mobility for the initially poor. We find that upward mobility for low-wag…
  - (2026-08-27) [Marginal Revolution] The least bad way to regulate AI?
      That is the topic of my latest Free Press column. Excerpt: The key is to create some basic safeguards, but without stifling broader AI progress. To do so, we must defy the conventional wisdom about public oversight and i…
  - (2026-08-26) [Marginal Revolution] Daddy’s Girl
      Using Danish registry data, we study how managers’ gender attitudes shape gender inequality in the workplace by exploiting the birth of a daughter – as opposed to a son – as a plausibly exogenous shock to male managers’…
  - (2026-08-26) [Conversable Economist] Is US Government Debt Getting Riskier?
      Looking at the benchmark interest rate for 30-year US Treasury debt, long-term interest rates have been rising. Any price change might happen for a number of different reasons: 1) expectations of future inflation are cau…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=19, 14d-median=20; carrying terms: national, establish, proposed, proposes, management, navigable, establishing, within, certain, action, waters, safety
- state_bills: today=229, 7d-median=118, 14d-median=129; carrying terms: violence, child, transfer, specific, request, jurisdiction, entities, emergency, amount, provide, resources, government
- state_news: today=660, 7d-median=597, 14d-median=591; carrying terms: second, content, thursday, client, pressherald, narrow, arkansas, scrutiny, request, challenge, release, beach
- local_news: today=236, 7d-median=238, 14d-median=236; carrying terms: child, falcons, camera, shooting, injured, report, custody, reported, charged, charges, school, court
- foreign_news: today=1039, 7d-median=1023, 14d-median=1004; carrying terms: pledges, several, second, violence, child, specific, arabnews, nameresolutionerror, moves, envoy, request, christmas
- chinese_internal: today=288, 7d-median=284, 14d-median=282; carrying terms: cbmia, cbmiyefvx, cbmixkfvx, title, china, lxtfb, cbmiykfvx, global, cbmibkfvx, google, https, blank
- russian_internal: today=1159, 7d-median=1030, 14d-median=1035; carrying terms: https, client, blank, times, forbidden, httperror, street, media, novayagazeta, europe, gazeta, bloomberg
- ukrainian_internal: today=119, 7d-median=115, 14d-median=110; carrying terms: client, drones, cabinet, vechirniy, hromadske, missiles, forces, according, people, refinery, intelligence, center
- ukraine_theater: today=479, 7d-median=880, 14d-median=916; carrying terms: wltfhszntz, vkhqr, strengthening, ltvyrzfda, lvpcawjcvtq, client, logistics, drones, kwwuxj, mxjlbhrfsjdn, xzvfqnmrlskrit, uwmzuzm
- paper_bets: today=134, 7d-median=133, 14d-median=137; carrying terms: otherwise, control, miles, performing, midterms, johnson, manifold, chair, mbappe, colorado, president, james
- weather: today=141, 7d-median=143, 14d-median=155; carrying terms: swimmers, occurring, odham, tuesday, illnesses, depth, mountains, working, island, extended, moisture, afdlox
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: consumption, vixcls, assets, treasury, growth, commodities, energy, payrolls, sheet, jtsjol, supply, implied
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: credit, treasury, futures, commodities, proxy, russell, nasdaq, china, large, agriculture, crude, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=108, 7d-median=101, 14d-median=96; carrying terms: situation, foreign, systems, daesh, sectoral, content, terrorism, enable, specific, sevastopol, occupation, services
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quantitative, quiverquant, error, httperror, https, congresstrading, quiver, unauthorized
- billionaires: today=30, 7d-median=30, 14d-median=32; carrying terms: london, ellison, yiming, bettencourt, julia, gautam, amazon, zhang, ballmer, technologies, berkshire, steve
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, court, state, supreme, america, company, connecticut, general, center, brown, delaware, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, management, holdings, partners, francisco, automotive, brian, goodrx, research
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, senate, warner, filing, pinkston, alexandria, shawn, ocasio, friends, david, jonathan, booker
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, china, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=33; carrying terms: english, trump, keywords, russian, themes, russia, ukrainian, perimeter, sanctions, spanish, business, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=27, 7d-median=30, 14d-median=30; carrying terms: position, belgium, ground, france, germany, kingdom, canada, bulgaria, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: circulation, divisions, resulting, caused, respiratory, driving, situation, periods, coinci, discontinued, countries, several
- cisa_kev: today=17, 7d-median=12, 14d-median=10; carrying terms: function, command, injection, product, vendor, vulnerability, remediation, microsoft, authentication, missing, project, internet
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=12, 7d-median=17, 14d-median=18; carrying terms: indonesia, depth, ruteng, islands, japan, region, philippines, south, vanuatu, atlantic, solomon
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: shakhtar, interest, league, winner, donetsk, price, volume, august, champions, championship, resolves, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, revolution, economist, conversable, marginal, class, conversableeconomist, impossible, around, because, marginalrevolution, basic
- tech_news: today=55, 7d-median=55, 14d-median=55; carrying terms: systems, models, weekly, microsoft, agents, called, disclosed, going, around, point, according, researchers
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: laurel, mcbath, dexter, harshbarger, scott, norcross, claudia, walberg, shaheen, carbajal, elena, calvert
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, converges, placed, evidence, markets, module, identify, decision, sufficient, placement, market, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*