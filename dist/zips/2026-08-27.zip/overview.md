# WORLDSCOPE morning brief — 2026-08-27

## Headline
3811 new items across 26 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (878) · International News + Multilateral Institutions (803) · State-Level News (447) · World leaders & government officials (324) · Chinese Internal News (246) · State Legislative Action (236) · Local News: St. Louis + Atlanta (225) · U.S. Weather + Severe / Climate Outlooks (144) · Ukraine Theater (total-war monitoring) (86) · Ukrainian Internal News (national + local Kyiv) (77) · IT, InfoSys & cybersecurity news (last 7 days) (49) · Forbes Real-Time Billionaires (top 30 + biggest movers) (40)

## What changed today
### Russian Internal News (state + in-exile) — 878 new of 1284 total
  - (2026-08-27) Associated Press: США столкнулись с дефицитом ракет Patriot в Европе из-за войны с Ираном | LEDE: Армия США испытывает «сверхкритическую» нехватку ракет для систем Patriot в Европе, рассказа] (ru: Ass…
      Армия США испытывает «сверхкритическую» нехватку ракет для систем Patriot в Европе, рассказали Associated Press источники в Пентагоне и НАТО на условиях анонимности. По их словам, дефицит в значительной степени вызван во…
  - (2026-08-27) The Bell, «Верстка» и Борис Гребенщиков стали лауреатами премии имени Анны Политковской | LEDE: В Москве в 14-й раз вручили премию «Камертон» имени погибшей журналистки «Новой газеты» Анны П] (ru: The…
      В Москве в 14-й раз вручили премию «Камертон» имени погибшей журналистки «Новой газеты» Анны Политковской.
  - (2026-08-27) Испанская футболистка Эстер Гонсалес перешла в саудовский клуб. Это возмутило многих ее фанатов. Гонсалес — открытая лесбиянка, а в Саудовской Аравии за однополые отношения могут казнить | LEDE] (ru:…
      Испанская футболистка Эстер Гонсалес — одна из мировых звезд женского футбола. В 2023 году она стала чемпионкой мира вместе со сборной Испании, а в 2025-м — лучшим бомбардиром чемпионата Европы по футболу среди женщин. К…
  - (2026-08-27) Полиция Пензенской области пожаловалась на местных жителей, которые мешают задержаниям. В регионе похищают мужчин и отправляют их на войну | LEDE: Жители Пензенской области «все чаще встают ] (ru: Пол…
      Жители Пензенской области «все чаще встают на защиту правонарушителей» и не дают сотрудникам полиции их задержать, рассказали в местном управлении МВД России. Это происходит на фоне облав, похищений и насильственной отпр…
  - (2026-08-27) Умерла Яеи Кусама — самая успешная художница современности, которая обожала вещи в горошек. И нет, не только потому, что это красиво | LEDE: Сегодня стало известно, что 14 августа в Токио ум] (ru: Уме…
      Сегодня стало известно, что 14 августа в Токио умерла Яеи Кусама — самая коммерчески успешная художница нашего времени. Ей было 97 лет. Работы Кусамы легко узнать по характерному узору в горошек: разные варианты этого па…
  - (2026-08-27) Русскоязычные хакеры обманули ИИ-агента SpaceX и взломали с его помощью семь компаний | LEDE: Русскоязычные хакеры из группировки Aur0ra использовали ИИ-помощника для написания кода Cursor, ] (ru: Рус…
      Русскоязычные хакеры из группировки Aur0ra использовали ИИ-помощника для написания кода Cursor, который недавно купила SpaceX Илона Маска, для взлома семи компаний по всему миру. Об этом сообщает Reuters со ссылкой на от…

### International News + Multilateral Institutions — 803 new of 1048 total
  - (2026-08-27) [Global] UK urged to help free British-Egyptian ‘arrested in Cairo over sister’s activism’
  - (2026-08-26) [Global] South African police arrest two Thai men for allegedly smuggling parrot eggs
  - (2026-08-26) [Global] Mpox is back – and in new countries. How can this outbreak be contained?
  - (2026-08-26) [Global] Moringa lattes and tigernut kebabs: the Ghanaians ‘taking back the power’ of their food
  - (2026-08-27) [Global] Trump signs executive order to rename Lake Ontario as Lake America
  - (2026-08-26) [Global] How to lose Trump’s trade war: test Canada’s resolve with threats to hockey sticks

### State-Level News — 447 new of 750 total
  - (2026-08-27) [Alabama] College Colors Day
      Download
  - (2026-08-27) [Alabama] We Card Awareness Month
      Download
  - (2026-08-27) [California] First Partner Siebel Newsom launches California’s first Social Health Council to strengthen community connection
      Source
  - (2026-08-27) [California] California answers the call: The state has deployed 3,372 personnel since June to support disaster response across the country and abroad
      Source
  - (2026-08-26) [California] Governor Newsom proclaims Farmworker Day
      Source
  - (2026-08-26) [California] Governor Newsom awards $48.5 million to drive economic growth and advance innovation across the state, supporting the creation of 20,000 new jobs
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 246 new of 296 total
  - (2026-08-27) Fosun rebounds after property clean-up with core focus on growth, innovation
  - (2026-08-27) Bond market revolt signals fading confidence in US economic leadership
  - (2026-08-27) Hong Kong expands AI sandbox with projects that include banks, securities and insurance
  - (2026-08-27) Hong Kong retirees’ living costs grow 3 times city’s average on more northbound travel
  - (2026-08-27) Zhipu AI shares jump as viral Ox Alpha model revealed as GLM-5.3-Flash on Chinese chips
  - (2026-08-27) Dovish or Hawkish? Markets await Warsh’s Jackson Hole debut for rate, policy clues

### State Legislative Action — 236 new of 269 total
  - (2026-08-27) [Alaska HB 271] An Act relating to the royalty rate for the Kitchen Lights Unit; and providing for an effective date.
      An Act relating to the royalty rate for the Kitchen Lights Unit; and providing for an effective date.
  - (2026-08-27) [Alaska HB 195] An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to th…
      An Act changing the term 'physician assistant' to 'physician associate'; relating to physician associates; relating to collaborative practice agreements for pharmacists; relating to the prescription of opioid overdose dr…
  - (2026-08-26) [Alaska HB 261] An Act relating to education funding; providing for an effective date by amending the effective date of secs. 10, 11, 13, and 15, ch. 5, SLA 2025; and providing for an effective date.
      An Act relating to education funding; providing for an effective date by amending the effective date of secs. 10, 11, 13, and 15, ch. 5, SLA 2025; and providing for an effective date.
  - (2026-08-27) [California SB 802] Housing finance and development: Sacramento Regional Housing and Homelessness Joint Powers Authority Act.
      (1) Existing law, the Joint Exercise of Powers Act, authorizes 2 or more public agencies, by agreement, to form a joint powers authority to exercise any power common to the contracting parties, as specified. Existing law…
  - (2026-08-27) [California SB 1004] Law enforcement: masks.
      Existing law makes it a crime for a law enforcement officer to wear a facial covering in the performance of their duties, except as specified. Existing law defines law enforcement officer for these purposes as anyone des…
  - (2026-08-27) [California SCR 197] Relative to California Youth Homelessness Outreach, Prevention, and Education (HOPE) Month.
      This measure would proclaim the month of November 2026 as California Youth Homelessness Outreach, Prevention, and Education (HOPE) Month to recognize the need for individuals, schools, communities, businesses, local gove…

### Local News: St. Louis + Atlanta — 225 new of 254 total
  - (2026-08-27) [St. Louis] Sports comedy ‘The Streak’ seeks St. Louis extras for basketball game scenes
      Another film production is taking over St. Louis, and this time there’s an exciting opportunity for local basketball fans and film lovers alike to take part in some of the action. The inspirational sports comedy The Stre…
  - (2026-08-27) [St. Louis] The Mountain Goats head to The Pageant with Candlebox
      Following a sold-out show at Delmar Hall in May, The Mountain Goats were recently announced as the direct support for grunge legends Candlebox for a short run of shows in September, which includes a show at The Pageant o…
  - (2026-08-27) [St. Louis] Top food and drink events in St. Louis
      August 29: Sip ‘N Serve Drag Brunch: No Skip Playlist! August 29: The St. Louis Margarita Festival August 29-30: Festival of Nations September 3: Midnight Margaritas Mixology September 4: The Indomitable Spirit of Americ…
  - (2026-08-27) [St. Louis] How St. Louis can crush the 2028 Olympic marathon trials
      St. Louis rose to the top of the heap of cities bidding for the 2028 U.S. Olympic marathon trials when it was chosen earlier this year. The designation speaks to the region’s ability to put on major sporting events and p…
  - (2026-08-27) [St. Louis] Driver hit in hit-and-run finds herself in city-county tangle
      A rising senior at Washington University was waiting for the light to change at the intersection of Forest Park Parkway and Skinker Boulevard when the car behind her was rear-ended, slamming that car into hers and damagi…
  - (2026-08-27) [St. Louis] ‘Double Lives of Suburban Wives’ treats St. Louis like a freak show
      While society has moved away from the type of freak show that showcases people with unusual physical characteristics, TLC has built a successful business out of putting them on TV instead. From conjoined twins to little…

### U.S. Weather + Severe / Climate Outlooks — 144 new of 145 total
  - (2026-08-27) [Moderate] Special Weather Statement: Special Weather Statement issued August 27 at 1:58PM EDT by NWS Tallahassee FL
      At 158 PM EDT, Doppler radar was tracking a strong thunderstorm 12 miles south of Leary, or 12 miles west of Newton, moving northeast at 5 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty w…
  - (2026-08-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-27) [Extreme] Tornado Warning: Tornado Warning issued August 27 at 1:57PM EDT until August 27 at 2:30PM EDT by NWS Mount Holly NJ
      TORPHI The National Weather Service in Mount Holly NJ has issued a * Tornado Warning for... Central Salem County in southern New Jersey... * Until 230 PM EDT. * At 157 PM EDT, a severe thunderstorm capable of producing a…
  - (2026-08-27) [Severe] Severe Thunderstorm Watch: Severe Thunderstorm Watch issued August 27 at 1:56PM EDT until August 27 at 9:00PM EDT by NWS Albany NY
      THE NATIONAL WEATHER SERVICE HAS ISSUED SEVERE THUNDERSTORM WATCH 631 IN EFFECT UNTIL 9 PM EDT THIS EVENING FOR THE FOLLOWING AREAS IN CONNECTICUT THIS WATCH INCLUDES 1 COUNTY IN NORTHWESTERN CONNECTICUT LITCHFIELD IN MA…
  - (2026-08-27) [Moderate] Special Weather Statement: Special Weather Statement issued August 27 at 1:55PM EDT by NWS Greenville-Spartanburg SC
      At 154 PM EDT, Doppler radar was tracking a strong thunderstorm 13 miles north of Walhalla, or 7 miles north of Oconee State Park, moving east at 10 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar…
  - (2026-08-27) [Severe] Severe Thunderstorm Watch: Severe Thunderstorm Watch issued August 27 at 1:54PM EDT until August 27 at 9:00PM EDT by NWS Binghamton NY
      THE NATIONAL WEATHER SERVICE HAS ISSUED SEVERE THUNDERSTORM WATCH 631 IN EFFECT UNTIL 9 PM EDT THIS EVENING FOR THE FOLLOWING AREAS IN NEW YORK THIS WATCH INCLUDES 16 COUNTIES IN CENTRAL NEW YORK BROOME CHEMUNG CHENANGO…

### Ukraine Theater (total-war monitoring) — 86 new of 233 total
  - (2026-08-27) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2016-07-28) [Liveuamap] Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com - iran.liveuamap.com
      Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com iran.liveuamap.com
  - (2026-08-26) [Liveuamap] Injuries reported in an Israeli drone strike on the Al-Shati refugee camp west of Gaza City - Liveuamap
      Injuries reported in an Israeli drone strike on the Al-Shati refugee camp west of Gaza City &n
  - (2026-08-25) [Liveuamap] More explosions were reported near Zaporizhzhia - Liveuamap
      More explosions were reported near Zaporizhzhia Liveuamap
  - (2026-08-24) [Liveuamap] Explosions were reported at the airfield in Millerovo, Rostov region - Liveuamap
      Explosions were reported at the airfield in Millerovo, Rostov region Liveuamap
  - (2026-08-23) [Liveuamap] Bombing, destruction, and combing operations took place night and dawn in Mansouri, Beit al-Sayyad, and Majdal Zoun. South Governorate, Lebanon - Lebanon news on live map - Liveuamap
      Bombing, destruction, and combing operations took place night and dawn in Mansouri, Beit al-Sayyad, and Majdal Z

### Ukrainian Internal News (national + local Kyiv) — 77 new of 132 total
  - (2026-08-27) "Укрзалізниця" зробила безкоштовними всі платні зали очікування на вокзалах до ранку п'ятниці | LEDE: У зв'язку із затримками потягів, що спричинені російськими обстрілами 27 серпня "Укрзалізни] (uk:…
      У зв'язку із затримками потягів, що спричинені російськими обстрілами 27 серпня "Укрзалізниця" зробила усі платні зали очікування на вокзалах до ранку п'ятниці безкоштовними.
  - (2026-08-27) AP: Європі бракує ракет Patriot, запаси у "надкритичному стані" | LEDE: Американські військові відзначають дефіцит ракет Patriot у Європі через перекидання запасів на Близький Схід.] (uk: AP: Європі б…
      Американські військові відзначають дефіцит ракет Patriot у Європі через перекидання запасів на Близький Схід.
  - (2026-08-27) Румунія підняла винищувачі через ціль над Чорним морем | LEDE: У четвер, 27 серпня, о румунська система радіолокаційного спостереження виявила повітряну ціль за 33 км на північ від українського] (uk:…
      У четвер, 27 серпня, о румунська система радіолокаційного спостереження виявила повітряну ціль за 33 км на північ від українського острова Зміїний.
  - (2026-08-27) Лідери Литви та Естонії не бачать причин переглядати політику щодо Білорусі | LEDE: ] (uk: Лідери Литви та Естонії не бачать причин переглядати політику щодо Білорусі)
  - (2026-08-27) Зеленський у Кишиневі зустрівся з президенткою Молдови | LEDE: ] (uk: Зеленський у Кишиневі зустрівся з президенткою Молдови)
  - (2026-08-27) ПС: Протягом дня РФ скерувала на Україну 140 дронів, більшість із них – на Київ | LEDE: Протягом дня 27 серпня російська армія атакувала Україну близько 140 ударними безпілотниками, з них понад] (uk:…
      Протягом дня 27 серпня російська армія атакувала Україну близько 140 ударними безпілотниками, з них понад 100 – реактивні.

### IT, InfoSys & cybersecurity news (last 7 days) — 49 new of 56 total
  - (2026-08-27) [Krebs on Security] Two Alleged ‘TeamPCP’ Hackers Arrested in Australia
      Authorities in Australia have arrested two men believed to be members of TeamPCP, a prolific cybercrime and data extortion group blamed for perpetrating the longest running spree of software supply chain attacks ever. In…
  - (2026-08-27) [BleepingComputer] PaperCut warns of NG, MF flaw exploited in zero-day attacks
      PaperCut is warning that hackers are actively exploiting a vulnerability in all versions of its PaperCut NG and PaperCut MF print management software in zero-day attacks. [...]
  - (2026-08-27) [BleepingComputer] Manchester Airports Group says hackers stole travelers' data
      The Manchester Airports Group (MAG) disclosed that hackers breached its systems and stole customer data, including Wi-Fi sign-ups from Manchester, Stansted, and East Midlands airports. [...]
  - (2026-08-27) [BleepingComputer] How Threat Research and MDR Help SMBs Build a Defensive Edge
      Threat research gives security teams insight into how attackers operate, while MDR turns that intelligence into faster detection and response. ESET explains how combining threat intelligence, continuous monitoring, and h…
  - (2026-08-27) [BleepingComputer] Android 17 adds ECH support to make web browsing harder to track
      Google is introducing new network security protections in Android 17 to strengthen connection privacy, address cellular vulnerabilities, and protect the privacy of users' home networks. [...]
  - (2026-08-27) [BleepingComputer] Australia arrests alleged TeamPCP hackers behind supply-chain attacks
      Australian authorities have arrested and charged two young men accused of being part of the TeamPCP hacking group linked to a string of far-reaching developer supply chain attacks. [...]

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 40 new of 40 total
  - (2026-08-27) #1 Elon Musk — $869.11B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-08-27) #2 Larry Page — $279.11B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-08-27) #3 Jeff Bezos — $264.60B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-08-27) #4 Sergey Brin — $257.49B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-08-27) #5 Michael Dell — $242.93B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-08-27) #6 Jensen Huang — $197.60B
      United States · Technology · source: Semiconductors · holdings: NVDA-US(NASDAQ), NVDA-US(NASDAQ), NVDA-US(NASDAQ), NVDA-US(NASDAQ)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-08-27 18:01 UTC — Filed: 2026-08-27 AccNo: 0001213900-26-094299 Size: 2 MB
  - (2026-08-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-08-27 18:01 UTC — Filed: 2026-08-27 AccNo: 0001213900-26-094299 Size: 2 MB
  - (2026-08-27) [FLORSHEIM THOMAS W] Form 4 (Reporting)
      filed 2026-08-27 17:57 UTC · role: Reporting — Filed: 2026-08-27 AccNo: 0000900533-26-000004 Size: 21 KB
  - (2026-08-27) [WEYCO GROUP INC] Form 4 (Issuer)
      filed 2026-08-27 17:57 UTC · role: Issuer — Filed: 2026-08-27 AccNo: 0000900533-26-000004 Size: 21 KB
  - (2026-08-27) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-08-27 17:57 UTC — Filed: 2026-08-27 AccNo: 0001918704-26-025109 Size: 1 MB
  - (2026-08-27) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-08-27 17:57 UTC — Filed: 2026-08-27 AccNo: 0001918704-26-025109 Size: 1 MB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-27) [India] Clashes in Spain Ceuta month after mass migrant influx
      domain: thehindu.com · language: English · tone:
  - (2026-08-27) [United States] Eastern Flank Commissioners urge von der Leyen to appoint special coordinator as Russian threat grows
      domain: euronews.com · language: English · tone:
  - (2026-08-27) [United States] Egg yolk peptides protect brain cells from oxidative stress
      domain: news-medical.net · language: English · tone:
  - (2026-08-27) [United States] Alliance releases new film highlighting the critical role of clinical trials
      domain: news-medical.net · language: English · tone:
  - (2026-08-27) [United States] Iran scrambles to sustain trade as US threatens to sanction countries that refuse to break ties
      domain: winchesterstar.com · language: English · tone:
  - (2026-08-27) [United Kingdom] Two killed in domestic violence incident at school near Berlin
      domain: bbc.co.uk · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-08-27) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (48.7343, 2.3821) · on ground · 15km/h
  - (2026-08-27) PAT977 (United States)
      icao24: adfecb · position: (37.2964, -85.6881) · alt: 7620m · 533km/h
  - (2026-08-27) PAT143 (United States)
      icao24: adfe47 · position: (37.4657, -77.3644) · alt: 4229m · 554km/h
  - (2026-08-27) PAT617 (United States)
      icao24: adfe4b · position: (43.9743, -116.951) · alt: 4975m · 545km/h
  - (2026-08-27) PAT281 (United States)
      icao24: adfe8d · position: (36.6897, -87.4707) · alt: 220m · 206km/h
  - (2026-08-27) PAT975 (United States)
      icao24: adfec9 · position: (39.729, -86.292) · alt: 243m · 226km/h

### U.S. Federal Action — 28 new of 29 total
  - (2026-08-27) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain The Boeing Company Model 787-8, 787-9, and 787-10 airplanes. This AD was prompted by a Boeing investigation for manufacturing errors and excessive preloa…
  - (2026-08-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-211, -212, -214, -216, -231, -232, and - 233 airplanes; and Model A321-111, -112, -131, -211, -212, -213, -231, and -232 airplanes.…
  - (2026-08-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-25- 06, which applied to all Airbus SAS Model A318 and A320 series airplanes; and Model A319-111, -112, -113, -114, -115, -131, -132, - 133, -151N, -153N, and -171…
  - (2026-08-27) Farmer Bridge Assistance (FBA) Program; Correction
      The Commodity Credit Corporation (CCC) announced the Farmer Bridge Assistance (FBA) Program in a final rule on February 23, 2026. This correction amends the definition of "corn" to add blue and red corn, which are eligib…
  - (2026-08-27) Schedules of Controlled Substances: Placement of Cipepofol in Schedule IV
      On May 29, 2026, the United States Food and Drug Administration (FDA) approved a new drug application for Cypsedo (cipepofol) for induction of general anesthesia in adults undergoing surgery. The Department of Health and…
  - (2026-08-27) Schedules of Controlled Substances: Temporary Placement of 5,6-Dichloro Brorphine, 5,6-Dichloro Desmethylchlorphine, N-Propionitrile Chlorphine, and Spirochlorphine in Schedule I of the Controlled Sub…
      The Drug Enforcement Administration (DEA) issues this temporary order to schedule 1-(1-(1-(4-bromophenyl)ethyl)piperidin-4- yl)-5,6-dichloro-1,3-dihydro-2H-benzo[d]imidazol-2-one (commonly known as 5,6-dichloro brorphine…

### Paper Trading Scorecard — 28 new of 132 total
  - (2026-08-27) [Polymarket] Will SpaceX have between 160-179 launches in 2026?
      This market will resolve according to the number of SpaceX launches between January 1, 2026, 12:00AM ET and December 31, 2026, 11:59PM ET. If the reported total number of SpaceX launches falls exactly between two bracket…
  - (2026-08-27) [Polymarket] Will the Washington Commanders win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-08-27) [Polymarket] Will Elon Musk post 240-259 tweets from August 21 to August 28, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from August 21 12:00 PM ET to August 28, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts an…
  - (2026-08-27) [Polymarket] Will OpenAI's valuation hit (HIGH) $1.0T by December 31?
      This market will resolve to "Yes" if OpenAI's private market valuation, as measured by the NPM Price reported by Nasdaq Private Market, LLC (NPM) for any date between market creation and December 31, 2026, reaches or exc…
  - (2026-08-27) [Polymarket] Will the Fed increase interest rates by 50+ bps after the October 2026 meeting?
      The FED interest rates are defined in this market by the upper bound of the target federal funds range. The decisions on the target federal funds range are made by the Federal Open Market Committee (FOMC) meetings. This…
  - (2026-08-27) [Manifold] Will my wife get a job offer?

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-08-27) Counter-Strike: Legacy vs FUT Esports (BO3) - BLAST Open Porto Group B
      yes price: 100% · 24h volume: $5,650,802 · resolves 2026-08-27
  - (2026-08-27) Colorado Rockies vs. Washington Nationals
      yes price: 30% · 24h volume: $2,558,043 · resolves 2026-09-03
  - (2026-08-27) Counter-Strike: Team Falcons vs Lynn Vision - Map 1 Winner
      yes price: 100% · 24h volume: $2,539,801 · resolves 2026-08-27
  - (2026-08-27) Will FC Barcelona win on 2026-08-27?
      yes price: 80% · 24h volume: $2,008,714 · resolves 2026-08-27
  - (2026-08-27) Will Augusto Cury win the 2026 Brazilian presidential election?
      yes price: 3% · 24h volume: $1,573,701 · resolves 2026-10-04
  - (2026-08-27) Map Handicap: FAL (-1.5) vs Lynn Vision (+1.5)
      yes price: 85% · 24h volume: $875,454 · resolves 2026-08-27

### Government Action: Sanctions + Procurement + Foreign Agents — 13 new of 108 total
  - (2026-08-26) [OFAC] Counter Terrorism Designations; Issuance of Counter Terrorism General License; Issuance of Amended Russia-related General License - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Issuance of Counter Terrorism General License; Issuance of Amended Russia-related General License Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Global Terrorism Sanctions Regulations 31 CFR. Part 594 GENERAL LICENSE NO. 36 Authorizing the - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Global Terrorism Sanctions Regulations 31 CFR. Part 594 GENERAL LICENSE NO. 36 Authorizing the Office of Foreign Assets Control (.gov)
  - (2026-08-27) [USASpending] $1,680,767,128 → ORACLE HEALTH GOVERNMENT SERVICES, INC.: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
      Agency: Department of Veterans Affairs. Description: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
  - (2026-08-27) [USASpending] $1,066,387,866 → BOOZ ALLEN HAMILTON INC: THE PURPOSE OF THIS EFFORT IS TO ACQUIRE CONTRACTOR SERVICES
      Agency: General Services Administration. Description: THE PURPOSE OF THIS EFFORT IS TO ACQUIRE CONTRACTOR SERVICES TO PROVIDE REAL-TIME, COMPREHENSIVE THREAT ANALYSIS AND ASSESSMENT, TRAINING DEVELOPMENT AND DELIVERY, RE…
  - (2026-08-27) [USASpending] $1,060,163,601 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-08-27) [USASpending] $923,446,339 → HII MISSION TECHNOLOGIES CORP: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED
      Agency: General Services Administration. Description: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED TO ALION SCIENCE AND TECHNOLOGY CORPORATION TO PROVIDE CONTRACTOR SUPPORT TO THE JOINT CAPABILITY EMBEDDE…

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-08-26) M 5.6 - 209 km ESE of Ōfunato, Japan
      M5.6 · 209 km ESE of Ōfunato, Japan · depth 16.05 km
  - (2026-08-27) M 5.3 - 54 km NNE of Labuan Bajo, Indonesia
      M5.3 · 54 km NNE of Labuan Bajo, Indonesia · depth 10 km
  - (2026-08-27) M 5.3 - Volcano Islands, Japan region
      M5.3 · Volcano Islands, Japan region · depth 10 km
  - (2026-08-27) M 5.1 - South Atlantic Ocean
      M5.1 · South Atlantic Ocean · depth 10 km
  - (2026-08-27) M 5.0 - western Xizang
      M5.0 · western Xizang · depth 10 km
  - (2026-08-27) M 4.9 - Indian Ocean Triple Junction
      M4.9 · Indian Ocean Triple Junction · depth 10 km

### CISA Known Exploited Vulnerabilities (last 14d) — 9 new of 20 total
  - (2026-08-27) CVE-2023-49105 · ownCloud ownCloud: ownCloud Improper Authentication Vulnerability
      vendor: ownCloud · product: ownCloud · CISA remediation by 2026-08-30
  - (2026-08-27) CVE-2026-53362 · Linux Kernel: Linux Kernel Unspecified Vulnerability
      vendor: Linux · product: Kernel · CISA remediation by 2026-08-30
  - (2026-08-27) CVE-2026-66384 · JFrog Artifactory: JFrog Artifactory Improper Limitation of a Pathname to a Restricted Directory Vulnerability
      vendor: JFrog · product: Artifactory · CISA remediation by 2026-09-10
  - (2026-08-26) CVE-2021-23758 · Ajax.NET Professional Ajax.NET Professional: Ajax.NET Professional Deserialization of Untrusted Data Vulnerability
      vendor: Ajax.NET Professional · product: Ajax.NET Professional · CISA remediation by 2026-09-09
  - (2026-08-26) CVE-2015-3246 · Red Hat Libuser: Red Hat Libuser Race Condition Vulnerability
      vendor: Red Hat · product: Libuser · CISA remediation by 2026-09-09
  - (2026-08-26) CVE-2015-5287 · Red Hat Automatic Bug Reporting Tool: Red Hat Automatic Bug Reporting Tool Privilege Escalation Vulnerability
      vendor: Red Hat · product: Automatic Bug Reporting Tool · CISA remediation by 2026-09-09

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-08-27) [Marginal Revolution] What should I ask Yiyang Zhuge (诸葛一杨), also known as Zhong Shu (仲树)?
      Yes I will be doing a Conversation with her. She is best known to Western audiences for her interview with Christopher Nolan, but she has numerous other achievements: Yiyang Zhuge is a political theorist, political colum…
  - (2026-08-27) [Marginal Revolution] Thursday assorted links
      1. Data centers in space? Good Anton Leicht essay on the different considerations in the political economy. 2. More whales and Dr. Doolittle stuff. 3. Rohit on the AI hacks. And Peter Wilderford. 4. Is Australia the most…
  - (2026-08-27) [Marginal Revolution] The Antitrust Academy
      The Antitrust Academy is an online platform hosting hundreds of videos comprising a complete course in antitrust law and economics. Teachers include Judge Douglas Ginsburg, Jon Klick, Joshua Wright and others. I am an ad…
  - (2026-08-27) [Conversable Economist] Secular Stagnation and Wealth Inequality: Antecedents and Lessons
      About 10 years ago, the big topics that had economists all atwitter included the “secular stagnation” hypothesis put forward by Lawrence Summers and the rising-inequality hypothesis put forward by Thomas Piketty. Put the…
  - (2026-08-26) [Conversable Economist] Is US Government Debt Getting Riskier?
      Looking at the benchmark interest rate for 30-year US Treasury debt, long-term interest rates have been rising. Any price change might happen for a number of different reasons: 1) expectations of future inflation are cau…

### Court opinions of consequence (federal & state) — 3 new of 5 total
  - (2026-08-21) Arizona Supreme Court: AROJOJOYE v. ALLEN
  - (2026-08-18) Arizona Supreme Court: Williams v. ades/lamont
  - (2026-08-18) Arizona Supreme Court: State of Arizona v. Diondra Sharrelle Howard

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=19, 14d-median=20; carrying terms: establishing, national, establish, public, management, within, action, proposed, proposes, certain, navigable, safety
- state_bills: today=269, 7d-median=118, 14d-median=129; carrying terms: until, financial, general, service, facilities, enforcement, application, corporation, agency, pursuant, establish, commercial
- state_news: today=750, 7d-median=597, 14d-median=585; carrying terms: voting, biggest, stands, spoke, wisconsin, general, wildlife, criminal, service, hampshire, across, customs
- local_news: today=254, 7d-median=254, 14d-median=235; carrying terms: suspect, health, people, charged, opening, games, articles, found, years, being, county, georgia
- foreign_news: today=1048, 7d-median=1023, 14d-median=1002; carrying terms: financial, mobilized, biggest, suspect, cooperati, phone, publications, general, wildlife, publication, aimed, tibet
- chinese_internal: today=296, 7d-median=284, 14d-median=280; carrying terms: cbmiakfvx, cbmibkfvx, cbmix, cbmiaefvx, people, global, cbmixkfvx, articles, lxtfb, title, cbmidefvx, caixin
- russian_internal: today=1284, 7d-median=1030, 14d-median=1030; carrying terms: media, client, times, error, https, telegraph, istories, street, russian, found, reuters, europe
- ukrainian_internal: today=132, 7d-median=115, 14d-median=109; carrying terms: general, intelligence, across, production, kills, putin, zelensky, allies, people, missile, plans, reportedly
- ukraine_theater: today=233, 7d-median=880, 14d-median=887; carrying terms: yljtcul, cwsehumnnpdkxjs, dvllluxkd, archive, cgppz, uwgzduvjcdnxugsxb, qqmxjbuvetfrec, nehzlwjknmtkathan, xfvnnism, general, token, pnzfomdngcw
- paper_bets: today=132, 7d-median=132, 14d-median=135; carrying terms: predictit, seats, goldman, performing, prime, midterm, midterms, resolve, world, wisconsin, humanoid, andrew
- weather: today=145, 7d-median=144, 14d-median=151; carrying terms: hurricane, additional, afdmtr, peachtree, afdokx, afdhgx, until, working, front, afdlwx, extended, increased
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, cpiaucsl, personal, assets, headline, indicator, supply, vixcls, treasury, recession, dcoilwtico, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: china, range, nasdaq, silver, natural, large, crypto, treasury, crude, russell, close, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=101, 14d-median=96; carrying terms: hamas, establishes, usaspending, armed, haitian, tunisia, research, taliban, acronym, union, imposed, proliferation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, unauthorized, quantitative, quiver, client, error, httperror, congresstrading, quiverquant
- billionaires: today=40, 7d-median=30, 14d-median=34; carrying terms: ortega, finance, warren, francoise, family, cryptocurrency, holdings, devasini, huang, sergey, ballmer, technology
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=5, 7d-median=60, 14d-median=60; carrying terms: supreme, court, state, california, allen, arizona, arojojoye
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, financial
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: friends, robert, disbursements, raised, pinkston, elect, krishnamoorthi, senate, brown, cycle, cortez, cooper
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, china, defense
- gdelt_gkg: today=0, 7d-median=25, 14d-median=41; carrying terms: english, trump, keywords, themes, russian, ukrainian, spanish, sanctions, perimeter, russia, chinese, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: domain, english, language, medical, kingdom
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, ground, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: social, welfare, safety, additional, genomic, periods, release, regarding, infect, analysis, temporally, france
- cisa_kev: today=20, 7d-median=12, 14d-median=11; carrying terms: command, vulnerability, remediation, authentication, microsoft, function, product, vendor, injection, missing, project, extensions
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=12, 7d-median=17, 14d-median=19; carrying terms: depth, indonesia, ruteng, islands, japan, region, russia, south, labuan, vanuatu, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: shakhtar, september, winner, interest, rates, league, resolves, champions, august, donetsk, meeting, volume
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, conversable, class, marginal, economist, revolution, impossible, conversableeconomist, around, because, links, assorted
- tech_news: today=56, 7d-median=55, 14d-median=55; carrying terms: critical, government, agency, still, record, across, services, details, around, attacks, computer, patch
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: tulsi, evans, escobar, markwayne, goldman, chicago, sharice, gabbard, sanford, thompson, union, rubio
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, placed, converges, today, identify, paper, evidence, market, unavailable, sufficient, decision, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*