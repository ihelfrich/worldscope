# WORLDSCOPE morning brief — 2026-09-14

## Headline
3013 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (786) · Russian Internal News (state + in-exile) (672) · World leaders & government officials (324) · Chinese Internal News (229) · Ukraine Theater (total-war monitoring) (208) · State-Level News (155) · Local News: St. Louis + Atlanta (151) · U.S. Weather + Severe / Climate Outlooks (122) · Ukrainian Internal News (national + local Kyiv) (59) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 786 new of 950 total
  - (2026-09-14) [Global] Petrol and diesel prices hit highest since 2022
      The cost of filling up a vehicle has rebounded, according to the RAC, as oil prices remain elevated.
  - (2026-09-14) [Global] 'Culture shift' needed in how UK does business, PM urges
      Burnham has said those who take risks should be backed by government, but his government has been criticised for increasing business costs.
  - (2026-09-13) [Global] Rent rises set to speed up in gloomy forecast for tenants
      The cost of renting is expected to rise by 4% or 5% a year by December, says property website Zoopla.
  - (2026-09-14) [Global] Heading off to uni? Here's what to insure against theft
      What should new students consider to keep your belongings safe and covered by insurance?
  - (2026-09-14) [Global] MPs and Lords call for new law to address AI threat to human rights
      Existing laws are not equipped to address the risks to human rights being posed by artificial intelligence, UK politicians say.
  - (2026-09-13) [Global] Carney gambles on the world's biggest investors betting on Canada
      In the midst of a trade war with the US, the prime minister leveraged his connections in global finance to invite some of the world's biggest investors to Canada.

### Russian Internal News (state + in-exile) — 672 new of 892 total
  - (2026-09-14) Глава Международной ассоциации бокса Умар Кремлев потратил сотни тысяч долларов на свадьбу Трампа-младшего на Багамах | LEDE: Часть расходов на свадьбу сына президента США Дональда Трампа-мл] (ru: Гла…
      Часть расходов на свадьбу сына президента США Дональда Трампа-младшего на Багамах оплатил российский бизнесмен и глава Международной ассоциации бокса (IBA) Умар Кремлев. Об этом пишет ProPublica со ссылкой на документы и…
  - (2026-09-14) Польские власти сообщили, что нашли российский беспилотник на территории страны | LEDE: Российский дрон обнаружили в Балтийском море у пляжа в населенном пункте Русиново недалеко от польског] (ru: Пол…
      Российский дрон обнаружили в Балтийском море у пляжа в населенном пункте Русиново недалеко от польского города Ярославец. Об этом сообщил министр обороны Польши Владислав Косиняк-Камыш.
  - (2026-09-14) Сидни Суини снова снялась в рекламе, которая всех возмутила. Ролик с обнаженной актрисой не понравился профессиональным спортсменкам | LEDE: Актриса Сидни Суини снялась в рекламе биржи прогн] (ru: Сид…
      Актриса Сидни Суини снялась в рекламе биржи прогнозов Novig, специализирующейся на ставках на спортивные мероприятия. В рекламе со слоганом «Только спорт», Суини, известная по роли в сериале «Эйфория», появилась обнаженн…
  - (2026-09-14) ФБК и Максим Кац (раньше они конфликтовали) предложили общие рекомендации по голосованию против «Единой России» на думских выборах. «Это был нелегкий поиск компромисса» | LEDE: Политики Юлия] (ru: ФБК…
      Политики Юлия Навальная и Максим Кац одновременно опубликовали заявления, касающиеся совместной стратегии голосования на ближайших выборах в Госдуму (они пройдут в России с 18 по 20 сентября).
  - (2026-09-14) Песков приветствовал призыв Трампа к Украине остановить удары по российским НПЗ. Прекратит ли удары Россия, в Кремле не ответили | LEDE: В Кремле не стали обещать, что прекратят удары по объ] (ru: Пес…
      В Кремле не стали обещать, что прекратят удары по объектам экономической инфраструктуры Украины, если Киев остановит удары по российским НПЗ.
  - (2026-09-14) Латвийская airBaltic подала заявление о защите от кредиторов в США | LEDE: Латвийская авиакомпания airBaltic подала в Нью-Йорке заявление о защите от кредиторов по главе 11 Кодекса США о бан] (ru: Лат…
      Латвийская авиакомпания airBaltic подала в Нью-Йорке заявление о защите от кредиторов по главе 11 Кодекса США о банкротстве. Процедура позволит airBaltic реструктуризировать долг, не прекращая работу.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 229 new of 261 total
  - (2026-09-13) 商品详情 - mall.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE41TGw4T2dTdUE2VXlGMTdtU3ZDVkhoMk1BWS1CdzJwSXhZTlpMT214eGZBNmRkaEI2SFdxVWt1V1o2cWc2X0gzdDQyVW05eU5iRThI] (zh:…
      商品详情 mall.caixin.com
  - (2026-09-13) 维权 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE5fV2dIWUx1ZXJva3BsWmdWTTIzdVVVOHVtU0FtQ3hpVUJQT1RVdjFuS0pTd0Z5a19yTHZSZ3RkcGJjQ201N3NNZXRDWEcyWTZ1T2] (zh:…
      维权 deepview.caixin.com
  - (2026-09-13) 大西洋观察｜攻城掠寨的欧洲极右势力 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1US2NjTzUwcE4wenM2YnVxdkJVc185c0N6VXhWUG9SSUpJS2FmVXdYYkozY2trQmZzalJPVEdybzJybUdfSE9jUFBQbm5hY1pGaFp5] (zh:…
      大西洋观察｜攻城掠寨的欧洲极右势力 财新
  - (2026-09-14) 今日开盘：两市双双低开 沪指跌幅0.54% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9sSFdLR1dYQ1V1RVlyVU11ZUtyNlUzeGRCcXpGaGt6T0ItSkRnQWJoejZMNGFUdEhjRFBKaTdOblZ1cU9FTmpIeWV4Z1VOVlhY] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.54% 财新
  - (2026-09-14) 【霍尔木兹周报】美伊军事博弈升级 两大能源通道同步承压 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFA2ZzRMYktYcF83Mjh3UWQ2d1FsQ05Ra0EwWVpodi1uSjN3OGhyUnBLa00wVl93TmVNYXpqU1hUc0RVRzZ0bTd6UWFkMF] (zh:…
      【霍尔木兹周报】美伊军事博弈升级 两大能源通道同步承压 财新
  - (2026-09-12) 火线评论｜“催捐”为自导自演，流量生意何以屡次重创舆论场 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5sZ3FDbHpPSFZ2VGtjSkdDVjY2MU5NNnkzVVBaV0tITkZIWW5vNTFBUHdqT2syYWUyQ1NZVGd3YzY2M1pHM3lIdk1Mc] (zh:…
      火线评论｜“催捐”为自导自演，流量生意何以屡次重创舆论场 财新

### Ukraine Theater (total-war monitoring) — 208 new of 351 total
  - (2026-09-14) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-13) [FIRMS] thermal anomaly 45.511, 34.959 (FRP 8.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-13 0917Z, FRP 8.41 MW
  - (2026-09-13) [FIRMS] thermal anomaly 45.513, 34.959 (FRP 9.33 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-13 0917Z, FRP 9.33 MW
  - (2026-09-13) [FIRMS] thermal anomaly 46.793, 34.952 (FRP 9.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-13 0917Z, FRP 9.64 MW
  - (2026-09-13) [FIRMS] thermal anomaly 46.769, 34.713 (FRP 10.24 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-13 0917Z, FRP 10.24 MW
  - (2026-09-13) [FIRMS] thermal anomaly 46.775, 34.708 (FRP 10.24 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-13 0917Z, FRP 10.24 MW

### State-Level News — 155 new of 264 total
  - (2026-09-14) [California] Will more Californians vote early because of Trump?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/110525_Election-Counting-Fresno_LV_CM_13.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…
  - (2026-09-14) [California] CalMatters sues UC Berkeley to force university to disclose student-athlete pay data
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/04/032522_UC-BERKELEY_MHN_CM_03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-09-14) [California] More girls are harming themselves. Only some show up in the ER
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/082026-WOC-Mental-Health-MG-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-09-14) [California] Drugs for autoimmune diseases are pricey. This bill could switch patients to a cheaper one
      Nearly 25,000 Californians coul
  - (2026-09-14) [California] California’s vote by mail system works. It’s worth fighting for.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Sac-Ballot-Count_FG_CM_06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-09-13) [Alaska] Suicide Prevention Week 2026
      WHEREAS, protecting the health and wellness of all Alaskans is essential to ensuring a stronger future for our families and communities; and WHEREAS, suicide is the most tragic consequence of mental and emotional illness…

### Local News: St. Louis + Atlanta — 151 new of 193 total
  - (2026-09-14) [St. Louis] An out-of-state firm’s neglect has reshaped a corner of Benton Park—but neighbors are fighting back
      It came to a head over weeds. For some months, neighbors in a pretty patch of Benton Park had been discussing the way the area was changing. All the hallmarks of a beautiful, historic St. Louis neighborhood are there: bi…
  - (2026-09-14) [St. Louis] How the sisters behind Golden Gems built a global retail business from St. Louis
      Ten years ago, two sisters with separate Etsy shops came together to form a single business. They called it Golden Gems after Golden Gem Road, where they’d grown up in Florida, and both Susan Logsdon and Amanda Helman al…
  - (2026-09-14) [St. Louis] Lou’s Clues – 9/14/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-09-14) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-09-14) [St. Louis] Smithsonian National Museum brings its human origins exhibit to Eden Seminary in St. Louis
  - (2026-09-14) [St. Louis] Flock cameras escalate the battle between privacy and safety in St. Louis

### U.S. Weather + Severe / Climate Outlooks — 122 new of 124 total
  - (2026-09-14) [Severe] Flash Flood Warning: Flash Flood Warning issued September 14 at 8:29AM CDT until September 14 at 1:30PM CDT by NWS Kansas City/Pleasant Hill MO
      At 829 AM CDT, Doppler radar indicated thunderstorms producing heavy rain have tracked north and east of the warned area. Between 2 and 4 inches of rain have fallen. Flash flooding is ongoing or expected to begin shortly…
  - (2026-09-14) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-14) [Severe] Flash Flood Warning: Flash Flood Warning issued September 14 at 8:04AM CDT until September 14 at 12:30PM CDT by NWS Kansas City/Pleasant Hill MO
      At 804 AM CDT, Doppler radar indicated between 2 and 5 inches of rain have fallen. The heaviest rain has pushed north and east of the warned area. Additional rainfall amounts up to 0.5 inches are possible. Flash flooding…
  - (2026-09-14) [Severe] Flash Flood Warning: Flash Flood Warning issued September 14 at 7:54AM CDT until September 14 at 11:15AM CDT by NWS Kansas City/Pleasant Hill MO
      At 754 AM CDT, Doppler radar and automated rain gauges indicated between 4 and 7 inches of rain have fallen this morning. Additional rainfall amounts up to 0.5 inches are possible in the warned area. Flash flooding is on…
  - (2026-09-14) [Severe] Flash Flood Warning: Flash Flood Warning issued September 14 at 7:51AM CDT until September 14 at 10:45AM CDT by NWS Kansas City/Pleasant Hill MO
      At 751 AM CDT, Doppler radar indicated thunderstorms will end soon across the warned area. Between 4 and 7 inches of rain have fallen this morning. Flash flooding is ongoing or expected to begin shortly due to runoff fro…
  - (2026-09-14) [Moderate] Wind Advisory: Wind Advisory issued September 14 at 4:04AM AKDT until September 15 at 10:00PM AKDT by NWS Anchorage AK
      * WHAT...South winds 35 to 45 mph with gusts up to 60 mph expected. * WHERE...Kuskokwim Delta. * WHEN...From 10 PM this evening to 10 PM AKDT Tuesday. * IMPACTS...Gusty winds will blow around unsecured objects and power…

### Ukrainian Internal News (national + local Kyiv) — 59 new of 128 total
  - (2026-09-14) Ukraine Sees Exponential Growth in Private Security Firms Providing Anti-Drone Protection
      In November last year Ukraine’s Defense Ministry unveiled a project to allow private businesses to defend their own plants against Russian aerial attacks. Now more than 50 enterprises have obtained permits to use license…
  - (2026-09-14) Russian Drones Just Miss Former CIA Director David Petraeus: a View From a Train Near the Polish Border
      Kyiv Post presents an eyewitness account of the attack on a train at the Polish border that nearly hit former CIA Director David Petraeus and came on the heels of ex-UK Prime Minister Boris Johnson’s departure.
  - (2026-09-14) Ukraine Has Leverage Over Trump Now
      Timothy Ash argues that President Trump cannot blame Ukraine alone for rising energy prices, saying his Iran policy and decision to reduce US support for Kyiv helped push Ukraine toward developing its own long-range stri…
  - (2026-09-14) ‘The Battlefield Has Gone Underground’: Khartiia Commander Reveals Ukraine’s Edge Over Russia
      The commander of Ukraine’s 2nd Khartiia Corps said the battlefield in his sector has shifted underground, where Ukrainian troops are operating more effectively than Russian forces. He also urged Ukraine and its Western p…
  - (2026-09-14) Ukraine Must Attack Russia’s Missile Plants to Win War, MITS Capital CEO Says
      MITS Capital co-founder and CEO Perry Boyle told Kyiv’s Yalta European Strategy Forum that air defense alone cannot save Ukraine and urged partners to back attacks on Russia’s missile-production plants. He also criticize…
  - (2026-09-14) Russian Attack on Pryluky Kills 3, Wounds 7
      Three people were killed and seven injured when Russian forces attacked an agricultural enterprise in central Pryluky, Chernihiv region. At least two explosions were recorded, damaging windows in nearby apartment buildin…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Océanie . Vanuatu : le naufrage dun ferry fait au moins un mort et 30 disparus , un avion français déployé
      ledauphine.com · French · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Własne uprawy , własne przetwórstwo . Rodzina Kuchtów robi wszystko od pola do butelki
      farmer.pl · Polish · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Трамп може опинитися в епіцентрі нових гучних розслідувань з боку демократів
      rbc.ua · Ukrainian · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Comparing Mammoth Energy Services ( NASDAQ : TUSK ) & united states Compression Partners ( NYSE : USAC )
      themarketsdaily.com · English · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Chelmsford charity Sanctus now helps up to 100 people daily | Maldon and Burnham Standard
      maldonandburnhamstandard.co.uk · English · tone NA
  - (2026-09-13) [Russia oil sanctions perimeter · themes] Ce datorie karmică ai în această viață , în funcție de ultima cifră a zilei tale de naștere
      ziarulprofit.ro · Romanian · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-14) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-09-14 13:25 UTC — Filed: 2026-09-14 AccNo: 0001839882-26-045212 Size: 701 KB
  - (2026-09-14) 425 - MiniMed Group, Inc. (0002062583) (Filed by)
      filed 2026-09-14 13:23 UTC — Filed: 2026-09-14 AccNo: 0001628280-26-061714 Size: 22 KB
  - (2026-09-14) 425 - Medtronic plc (0001613103) (Subject)
      filed 2026-09-14 13:23 UTC — Filed: 2026-09-14 AccNo: 0001628280-26-061714 Size: 22 KB
  - (2026-09-14) 424B5 - LANDWIRTSCHAFTLICHE RENTENBANK (0001144797) (Filer)
      filed 2026-09-14 13:22 UTC — Filed: 2026-09-14 AccNo: 0001104659-26-107334 Size: 460 KB
  - (2026-09-14) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-09-14 13:20 UTC — Filed: 2026-09-14 AccNo: 0001918704-26-027354 Size: 1 MB
  - (2026-09-14) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-09-14 13:20 UTC — Filed: 2026-09-14 AccNo: 0001918704-26-027354 Size: 1 MB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-13) [Australia] Out of her league : PM defends mum after Hanson attack
      domain: cessnockadvertiser.com.au · language: English · tone:
  - (2026-09-13) [United States] Comings & Goings : Reds Blossom , Ace Hardware , Arco and ampm
      domain: yumasun.com · language: English · tone:
  - (2026-09-13) [Philippines] How Marcelo del Pilar descendant sees the man behind the hero
      domain: rappler.com · language: English · tone:
  - (2026-09-13) [India] WUC raises alarm over Uyghur repression , Beijings governance model and rights violations in East Turkistan
      domain: news.webindia123.com · language: English · tone:
  - (2026-09-13) [Singapore] China , Russia , India seek economic cooperation at BRICS
      domain: straitstimes.com · language: English · tone:
  - (2026-09-13) [Singapore] Seoul to designate patient - friendly hotels as medical tourism surges
      domain: straitstimes.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-09-14) PAT085 (United States)
      icao24: adfedb · position: (4.7439, -74.6024) · alt: 7078m · 339km/h
  - (2026-09-14) PAT712A (United States)
      icao24: adfee1 · position: (18.5059, -66.5413) · alt: 2994m · 366km/h
  - (2026-09-14) GAF133 (Germany)
      icao24: 3f62fc · position: (49.3972, 12.0636) · alt: 9753m · 624km/h
  - (2026-09-14) JEDI31 (United States)
      icao24: ae1ea6 · position: (30.5436, -88.1333) · alt: 922m · 434km/h
  - (2026-09-14) JEDI18 (United States)
      icao24: ae1ea9 · position: (31.1319, -89.2617) · alt: 1737m · 440km/h
  - (2026-09-14) JEDI29 (United States)
      icao24: ae1eaa · position: (30.359, -88.7333) · alt: 3002m · 445km/h

### Paper Trading Scorecard — 25 new of 128 total
  - (2026-09-14) [Polymarket] Will OpenAI IPO by December 31 2026?
      This market will resolve to "Yes" if OpenAI completes an Initial Public Offering (IPO) by the listed date ET, as confirmed by official company announcements and credible news sources. Otherwise, this market will resolve…
  - (2026-09-14) [Polymarket] Will the price of Bitcoin be above $68,000 on September 14?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-09-14) [Manifold] Will I finish Top 2 in every 2026 Masters League?
  - (2026-09-14) [Manifold] Nvidia closes at $210.00 or higher on Friday 18 September 2026?
  - (2026-09-14) [Manifold] Will Bitcoin be higher than $66,666 at the end of 2026?
  - (2026-09-14) [Manifold] Will Lucy Martinez travel to Thailand before October 31, 2026?

### IT, InfoSys & cybersecurity news (last 7 days) — 24 new of 52 total
  - (2026-09-14) [BleepingComputer] Webinar: How malicious OAuth apps can lead to Google Workspace breaches
      Attackers can combine social engineering with malicious OAuth applications to gain access to Google Workspace data without relying solely on stolen passwords. This webinar examines two attacks to show how these breaches…
  - (2026-09-14) [BleepingComputer] Microsoft: September updates cause RDS failures on Windows Server
      Microsoft has confirmed reports that the September 2026 security updates cause Remote Desktop Services (RDS) failures on Windows Server systems. [...]
  - (2026-09-14) [BleepingComputer] Revolut discloses data breach exposing financial info, passports
      Fintech company Revolut has disclosed a data breach after sharing data from an undisclosed number of customers with a threat actor impersonating a government agency. [...]
  - (2026-09-14) [BleepingComputer] Microsoft: September updates break audio on some Windows PCs
      Microsoft has confirmed that USB audio devices may fail on some Windows systems after installing the KB5124008and KB5124012 September 2026 security updates. [...]
  - (2026-09-14) [BleepingComputer] CISA: Hackers now exploit max severity GitLab flaw in attacks
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) warned that hackers are now exploiting a maximum-severity GitLab vulnerability in attacks. [...]
  - (2026-09-14) [The Hacker News] AI Changed the Exposure Problem. Validation Needs to Change With It.
      There's a lot of noise around AI and cybersecurity right now. What’s actually important is far simpler, if often lost in the hubbub. Vulnerability discovery is getting faster and happening at a much greater scale, while…

### Markets snapshot — 15 new of 21 total
  - (2026-09-14) [FX] DXY proxy (UUP): 28.22 ▲ +0.53%
      close 28.22 · chg +0.15 (+0.53%) · day range 28.18–28.22
  - (2026-09-14) [FX] EUR/USD (FXE): 106.43 ▼ -0.54%
      close 106.43 · chg -0.58 (-0.54%) · day range 106.43–106.45
  - (2026-09-14) [FX] JPY/USD (FXY): 59.20 ▼ -0.80%
      close 59.20 · chg -0.47 (-0.80%) · day range 59.19–59.22
  - (2026-09-14) [Rates] 20+yr Treasury (TLT): 80.84 ▼ -0.04%
      close 80.84 · chg -0.03 (-0.04%) · day range 80.80–80.87
  - (2026-09-14) [Rates] 7-10yr Treasury (IEF): 90.96 ▼ -0.05%
      close 90.96 · chg -0.05 (-0.05%) · day range 90.92–91.03
  - (2026-09-14) [Rates] 1-3yr Treasury (SHY): 81.36 ▼ -0.01%
      close 81.36 · chg -0.01 (-0.01%) · day range 81.34–81.38

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-09-14) LoL: Dplus KIA Challengers vs KT Rolster Challengers (BO5) - LCK Challengers League Playoffs
      yes price: 0% · 24h volume: $997,321 · resolves 2026-09-14
  - (2026-09-14) Will Magdalena Andersson be the next Prime Minister of Sweden?
      yes price: 88% · 24h volume: $723,212 · resolves 2026-09-13
  - (2026-09-14) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 28% · 24h volume: $675,313 · resolves 2027-01-01
  - (2026-09-14) Broncos vs. Chiefs
      yes price: 44% · 24h volume: $615,788 · resolves 2026-09-15
  - (2026-09-14) Will Ulf Kristersson be the next Prime Minister of Sweden?
      yes price: 12% · 24h volume: $576,532 · resolves 2026-09-13
  - (2026-09-14) LoL: Dplus KIA Challengers vs KT Rolster Challengers - Game 4 Winner
      yes price: 100% · 24h volume: $511,060 · resolves 2026-09-14

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-09-14) M 5.6 - 78 km NNE of Tobelo, Indonesia
      M5.6 · 78 km NNE of Tobelo, Indonesia · depth 162.179 km
  - (2026-09-14) M 5.5 - 187 km SSW of Pelabuhanratu, Indonesia
      M5.5 · 187 km SSW of Pelabuhanratu, Indonesia · depth 10 km
  - (2026-09-14) M 5.4 - northern Mid-Atlantic Ridge
      M5.4 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-09-13) M 5.1 - 50 km N of Ruteng, Indonesia
      M5.1 · 50 km N of Ruteng, Indonesia · depth 10 km
  - (2026-09-13) M 4.9 - 86 km SSW of Isangel, Vanuatu
      M4.9 · 86 km SSW of Isangel, Vanuatu · depth 10 km
  - (2026-09-14) M 4.8 - 119 km S of Dampit, Indonesia
      M4.8 · 119 km S of Dampit, Indonesia · depth 33.378 km

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-09-11) Alaska Supreme Court: Matter of Derius L
  - (2026-09-11) U.S. Court of Appeals, 6th Cir.: United States v. Steve Croom, Jr.
  - (2026-09-11) U.S. Court of Appeals, 6th Cir.: United States v. Todd Allen Stafford
  - (2026-09-11) U.S. Court of Appeals, Federal Cir.: Moskowitz Family LLC v. Globus Medical, Inc.
  - (2026-09-10) U.S. Court of Appeals, 6th Cir.: Danyale Tubbs v. Sherry Payton
  - (2026-09-10) U.S. Court of Appeals, 6th Cir.: Hello Farms Licensing MI, LLC v. GR Vending MI, LLC

### World News (by country, top stories) — 6 new of 12 total
  - (2026-09-13) [Japan] How Super Mario Sunshine still delights ( and frustrates ) to this day
      nintendoeverything.com · English
  - (2026-09-13) [Japan] Asian air - con makers prepare for hotter Germany after bumper summer
      asia.nikkei.com · English
  - (2026-09-13) [Japan] Rescuers searching for 140 people from Indonesia passenger ship
      asia.nikkei.com · English
  - (2026-09-13) [Japan] Radiation harm isnt gender - neutral . And no one is talking about it . « nuclear - news
      nuclear-news.net · English
  - (2026-09-13) [Japan] A worthy 9 / 11 remembrance – Walt Zlotow
      nuclear-news.net · English
  - (2026-09-13) [Japan] Satellite images reveal surge in building activity at Iranian nuclear site after Trump bomb threat « nuclear - news
      nuclear-news.net · English

### State Legislative Action — 5 new of 90 total
  - (2026-09-13) [Iowa SJR 10] A joint resolution proposing an amendment to the Constitution of the State of Iowa limiting years of service for members of the general assembly.
      A joint resolution proposing an amendment to the Constitution of the State of Iowa limiting years of service for members of the general assembly.
  - (2026-09-12) [Michigan SB 221] Criminal procedure: mental capacity; outpatient treatment for misdemeanor offenders with mental health issues; provide for. Amends 1974 PA 258 (MCL 330.1001 - 330.2106) by adding sec…
      Criminal procedure: mental capacity; outpatient treatment for misdemeanor offenders with mental health issues; provide for. Amends 1974 PA 258 (MCL 330.1001 - 330.2106) by adding sec. 1021 & ch. 10A. TIE BAR WITH: SB 021…
  - (2026-09-12) [Michigan SB 217] Traffic control: accidents; penalties for moving violation causing physical injury or death to a vulnerable roadway user; enhance. Amends sec. 12e, ch. XVII of 1927 PA 175 (MCL 777.1…
      Traffic control: accidents; penalties for moving violation causing physical injury or death to a vulnerable roadway user; enhance. Amends sec. 12e, ch. XVII of 1927 PA 175 (MCL 777.12e). TIE BAR WITH: SB 0216'25
  - (2026-09-12) [Michigan SB 220] Mental health: other; hospital evaluations for assisted outpatient treatment; expand. Amends secs. 206a & 429 of 1974 PA 258 (MCL 330.1206a & 330.1429).
      Mental health: other; hospital evaluations for assisted outpatient treatment; expand. Amends secs. 206a & 429 of 1974 PA 258 (MCL 330.1206a & 330.1429).
  - (2026-09-12) [Michigan SB 216] Traffic control: accidents; penalties for moving violation causing physical injury or death to a vulnerable roadway user; enhance. Amends secs. 303, 320a, 601c & 653a of 1949 PA 300…
      Traffic control: accidents; penalties for moving violation causing physical injury or death to a vulnerable roadway user; enhance. Amends secs. 303, 320a, 601c & 653a of 1949 PA 300 (MCL 257.303 et seq.); adds secs. 79g…

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-14) [Marginal Revolution] AI, Redistribution, and the Size of the Pie
      Anthropic’s economic team, including Anton Korinek and Chad Jones, have a valuable new paper, Economic Scenarios for Transformative AI. They make their assumptions explicit and provide a scenario explorer that lets you c…
  - (2026-09-14) [Marginal Revolution] Is it the screens? Or education systems?
      The Dark Ages implies television and phones are the main cause of cognitive decline. This fails to explain the patterns in PISA scores. Why did England and Scotland fall so precipitously from 2000 to 2005 whilst America…
  - (2026-09-14) [Marginal Revolution] Does AI assistance enhance or erode expertise?
      From a new NBER working paper: Whether AI assistance builds or erodes professional expertise is unsettled. In a pre-registered three-month randomized controlled trial, we gave 133 practicing patent lawyers at eleven U.S.…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 110 total
  - (2026-09-08) [OFAC] Counter Terrorism Designations; Updates to Iran-related General Licenses - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Updates to Iran-related General Licenses Office of Foreign Assets Control (.gov)

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-14) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=19, 14d-median=18; carrying terms: changes, existing, guard, coast, unless, national, vessels, special, prohibited, final, certain, authorized
- state_bills: today=90, 7d-median=97, 14d-median=88; carrying terms: existing, costs, required, government, prohibits, violation, unless, statewide, issued, include, develop, defined
- state_news: today=264, 7d-median=549, 14d-median=586; carrying terms: marshall, alaska, break, louisiana, reporting, decoding, bring, outbreak, hampshire, focused, former, costs
- local_news: today=193, 7d-median=226, 14d-median=226; carrying terms: charges, former, supreme, woman, missouri, articles, trump, appeared, state, drive, health, shooting
- foreign_news: today=950, 7d-median=993, 14d-median=1006; carrying terms: chinadaily, environment, capital, selected, monetary, aimed, outbreak, follow, ordered, finals, costs, official
- chinese_internal: today=261, 7d-median=284, 14d-median=283; carrying terms: cbmib, articles, lxtfa, caixin, target, china, people, cbmizefvx, cbmibefvx, cbmiykfvx, property, cbmiw
- russian_internal: today=892, 7d-median=1059, 14d-median=1050; carrying terms: raquo, novayagazeta, title, europe, reuters, journal, forbidden, russian, novaya, gazeta, times, telegram
- ukrainian_internal: today=128, 7d-median=135, 14d-median=132; carrying terms: talks, capital, former, reportedly, government, institute, hromadske, trump, drone, political, minister, remain
- ukraine_theater: today=351, 7d-median=416, 14d-median=508; carrying terms: aelnktkjpuutpwmnfr, mrvllwuhrrg, cuxqcnhzrmngsnazc, blenfuamt, ymvzv, cbmzxz, dljjmnzvehrcrlbamm, nvcwd, avrasu, qvpou, zdogd, ujzbsg
- paper_bets: today=128, 7d-median=128, 14d-median=131; carrying terms: colonize, anthropic, pirates, december, theme, democratic, wisconsin, speaker, alaska, break, special, mamdani
- weather: today=124, 7d-median=119, 14d-median=120; carrying terms: evening, excessive, western, moderate, bring, afdfwd, especially, islands, coastal, peachtree, hazardous, degrees
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: growth, unemployment, jtsjol, personal, sheet, indicator, spread, latest, crude, dexchus, commodities, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, range, russell, nasdaq, china, large, equities, corporate, treasury, proxy, bitcoin, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=110, 7d-median=107, 14d-median=106; carrying terms: against, satisfying, violations, lebanon, relation, moldova, acronym, bissau, threatening, federation, guatemala, government
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quantitative, https, quiverquant, httperror, unauthorized, error, client, quiver
- billionaires: today=0, 7d-median=0, 14d-median=15
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, supreme, court, national, blanche, state, center, company, university, opinion, williams, brown
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, holdings, filer, trust, group, subject, tidal, global, finance
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, house, krishnamoorthi, elect, david, ocasio, pinkston, raised, trone, congress, robert, jonathan
- gdelt_regions: today=12, 7d-median=6, 14d-median=6; carrying terms: english, korea, south, center
- gdelt_gkg: today=50, 7d-median=38, 14d-median=38; carrying terms: hezbollah, israel, english, turkish, sanctions, attack, iranian, minister
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: language, domain, india, trump, kingdom, hospital, english, saudi, found, death
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, kingdom, france, ground, germany, canada, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: respiratory, division, reference, operator, december, americas, containing, young, arabia, associated, verified, increasingly
- cisa_kev: today=24, 7d-median=23, 14d-median=21; carrying terms: product, forgery, missing, function, critical, vendor, command, citrix, netscaler, bounds, write, request
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=12, 7d-median=11, 14d-median=11; carrying terms: depth, indonesia, vanuatu, isangel, ruteng, japan, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, september, volume, donetsk, change, shakhtar, league, interest, meeting, rates, resolves, decrease
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, conversable, marginal, economist, https, revolution, conversableeconomist, evidence, government, story, economists, report
- tech_news: today=52, 7d-median=57, 14d-median=56; carrying terms: software, computer, years, government, flaws, agents, technology, become, state, schneier, bleepingcomputer, openai
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: heinrich, loudermilk, young, marcy, laura, verified, mcbath, castor, thompson, tillis, kavanaugh, marshall
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, today, markets, either, unavailable, module, sufficient, evidence, market, decision, identify, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-09] ECB press: Christine Lagarde: The choice facing Europeans
- [2026-09-10] ECB press: Monetary policy decisions
- [2026-09-10] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-11] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy
- [2026-09-12] ECB press: Christine Lagarde: Interview with Ouest-France
- [2026-09-14] ECB press: Isabel Schnabel: Macroeconomic, fiscal and financial stability in a shock-prone world
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*