# WORLDSCOPE morning brief — 2026-10-31

## Headline
3106 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (731) · Russian Internal News (state + in-exile) (597) · State-Level News (325) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (215) · Chinese Internal News (199) · Ukraine Theater (total-war monitoring) (163) · U.S. Weather + Severe / Climate Outlooks (130) · Ukrainian Internal News (national + local Kyiv) (70) · State Legislative Action (67) · GDACS — global disaster alerts (43) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 731 new of 1015 total
  - (2026-10-30) [Global] Canada and EU announce new alliance open to like-minded countries
  - (2026-10-30) [Global] ‘Amateur morons’: Flávio Bolsonaro’s short-lived ‘president-elect’ claim met with mockery
  - (2026-10-30) [Global] How crypto hacking funds isolated North Korea’s nuclear programme
  - (2026-10-31) [Global] Storm warnings for Melbourne, Canberra, Sydney and Brisbane as cold front ‘packs a punch’
  - (2026-10-31) [Global] Albanese looks for reset on world stage as ‘spot fires burn’ domestically and likely interest rate hike looms
  - (2026-10-31) [Global] US cancels G20 ‘family photo’ after Australia, UK and others refuse to appear with Russia

### Russian Internal News (state + in-exile) — 597 new of 990 total
  - (2026-10-31) Один из крупнейших застройщиков РФ — «Самолет» — оказался в кризисе после отмены льготной ипотеки, повышения ставки ЦБ и смерти акционера. Выжить компании может помочь новый влиятельный владеле] (ru:…
      Компания «Самолет» на протяжении нескольких лет считалась одним из самых надежных и динамично развивающихся девелоперов России. Выручка росла на десятки процентов в год, прибыль — в разы, стремительно расширялся и земель…
  - (2026-10-31) Ксении Собчак и Константину Богомолову запретили въезд в Латвию | LEDE: Журналистке Ксении Собчак и ее мужу, режиссеру Константину Богомолову запрещен въезд в Латвию на неопределенный срок.<] (ru: Ксе…
      Журналистке Ксении Собчак и ее мужу, режиссеру Константину Богомолову запрещен въезд в Латвию на неопределенный срок.
  - (2026-10-31) В МИД России обвинили Украину в нарушении режима прекращении огня в Алешках | LEDE: Посол по особым поручениям МИД России Родион Мирошник за сутки до завершения режима прекращения огня в Але] (ru: В М…
      Посол по особым поручениям МИД России Родион Мирошник за сутки до завершения режима прекращения огня в Алешках обвинил Украину в нарушении договоренностей.
  - (2026-10-31) «Каждый говорит: хочется, чтобы так было всегда»: что происходит в Херсоне во время перемирия. Благодаря режиму тишины в соседних Олешках город наконец смог отдохнуть от обстрелов — впервые с 2] (ru:…
      С ноября 2022 года, когда ВСУ освободили Херсон, город живет под непрерывными российскими обстрелами. Линия фронта проходит по руслу Днепра, а Херсон стоит на правом берегу реки. С 27 октября здесь впервые за четыре года…
  - (2026-10-31) У резиденции Трампа в Мар-а-Лаго заметили две системы ПВО. У резиденции Путина их 50 | LEDE: Рядом с резиденцией президента США Дональда Трампа в Мар-а-Лаго во Флориде развернули системы про] (ru: У р…
      Рядом с резиденцией президента США Дональда Трампа в Мар-а-Лаго во Флориде развернули системы противовоздушной обороны Avenger, пишет издание The Telegraph со ссылкой на фотографии Palm Beach Daily News.
  - (2026-10-31) Самолеты с жителями Алешек, которые эвакуируются в Украину, прибыли в Гомель | LEDE: Четыре самолета с жителями города Алешки, которые решили уехать в Украину, приземлились в аэропорту белор] (ru: Сам…
      Четыре самолета с жителями города Алешки, которые решили уехать в Украину, приземлились в аэропорту белорусского Гомеля, сообщил глава фракции «Слуга народа» в Верховной Раде Украины Давид Арахамия.

### State-Level News — 325 new of 757 total
  - (2026-10-31) [Alabama] Governor Kay Ivey Encourages Alabamians to Vote in November 3 General Election
      Governor Ivey encouraged Alabamians to vote in the November 3 General Election. (Governor’s Office, Gina Maiola & Alyssa Turner)
  - (2026-10-30) [Alabama] Alabama DECA Day
      Download
  - (2026-10-30) [Alabama] Governor Ivey Encourages Alabamians to Vote in November 3 General Election
      MONTGOMERY – Governor Kay Ivey on Friday encouraged Alabamians to vote in the November 3 General Election. “Alabama’s future will be shaped by the people we send to Montgomery and Washington, and that decision belongs to…
  - (2026-10-30) [Alabama] Governor Ivey Announces $9.3 Million in Growing Alabama Funding to Improve Industrial Sites Across State
      MONTGOMERY – Governor Kay Ivey on Friday announced five industrial sites across Alabama will soon be improved to better attract quality jobs thanks to more than $9.3 million in new funding. “Through the Growing Alabama p…
  - (2026-10-31) [California] Governor Newsom announces appointments
      Source
  - (2026-10-30) [California] California mobilizes 112 community organizations to take on the overdose crisis and expand access to care
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 215 new of 277 total
  - (2026-10-30) [St. Louis] St. Louis breweries where you can play pinball
      Growing up, Bryan Schubert spent countless hours playing the two pinball machines in his parents’ basement. Years later, as owner and brewer at Millpond Brewing in Millstadt, Illinois, he wanted to bring that experience…
  - (2026-10-30) [St. Louis] Side Project’s acclaimed Beer : Barrel : Time returns November 1
      You don’t have to travel to Belgium, Germany, or some far-flung brewery to find one of the world’s highest-rated beers. You just have to drive to Maplewood. That’s where Side Project Brewing produces Beer : Barrel : Time…
  - (2026-10-30) [St. Louis] 10 art exhibits to catch this month
      Whether you’re interested in taking a journey to the past or exploring contemporary voices, there is plenty to take in this month at the city’s many museums and galleries. Here are a few must-see shows to catch this mont…
  - (2026-10-30) [St. Louis] Why do St. Louis kids tell jokes on Halloween?
      Every Halloween, people new to St. Louis blink in confusion at the tiny people in monster costumes on their doorstep, bombarding them with terrible jokes. On those same nights, St. Louisans who’ve moved elsewhere are app…
  - (2026-10-30) [St. Louis] 31 kid-friendly jokes for trick-or-treating in St. Louis
      St. Louis kids have two main objectives every October 31: find which houses are handing out full-size candy bars, and make the neighbors laugh. Although we can’t help with the former task, we have compiled a list of fami…
  - (2026-10-30) [St. Louis] Saint Louis Zoo’s beloved elephant Raja has left St. Louis after 33 years
      For St. Louis millennials, Raja isn’t just another elephant at the Saint Louis Zoo. He’s practically a childhood friend. Born December 27, 1992, Raja was the first elephant to be born at the zoo and became an instant hom…

### Chinese Internal News — 199 new of 277 total
  - (2026-10-30) 人民日报图文数据库（1946-2026） - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMidkFVX3lxTE1HY21GdFF3VjdWZkZmY3djQ2U2MnBOVDBoTmFJNk1YTmw5ZUlqdV9uWHMxZnBrcWYzdWJ6YmRMUzRybC1kZ3FlazBpdnVBYzd] (zh:…
      人民日报图文数据库（1946-2026） 人民日报
  - (2026-10-31) 陕西青年科学家大会在安康举办 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE91ZmEtM3ctMHdEUjVpXzdsUTBFYkFLYlBIUVMxcUk4NkNVUmtNaVlha2lSUTZCNEppbTN2VTA4WG5zdVhHcE9tdElGaWE3Nld4Z0NldT] (zh:…
      陕西青年科学家大会在安康举办 人民网
  - (2026-10-31) 陕西选手在全国女子拳击冠军赛斩获2金2银3铜 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE4xa3FqZll1cE81R200ODk3X2x2aV9FNkROYnFwbFNtNU9LdUo1TW9LZHhManpwOVczZV9uVDJKdEZVdk9GcVEwbElUdWRLZ1] (zh:…
      陕西选手在全国女子拳击冠军赛斩获2金2银3铜 人民网
  - (2026-10-31) 陕西未来一周冷空气活动频繁 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBQb1FWaFFUaGZZVXhGakYwRHM0SEJMMGk5UjVsOEloT2hlTTZ0S0dOT2ZnVGV3RXo5V3l5YjVLVWY5WTJYYk04VURSY1JsVXRQa1hxVkt] (zh:…
      陕西未来一周冷空气活动频繁 人民网
  - (2026-10-31) 有回音丨充电车位被占、充电桩安装受阻……陕西回应电车充电难题 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFB6ckpScjgta24xQTU4TGhKYWNManpjZVdQWGpoWTlRYVJ2RnNZLVhyd1Q4WjI4Q0FCa01TMHlFdWhKYWxvcXFCd3] (zh:…
      有回音丨充电车位被占、充电桩安装受阻……陕西回应电车充电难题 人民网
  - (2026-10-30) 人民日报图文数据库（1946-2026） - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTE52TmtjT3ZSa1lWamxTeEVrcEcxYkNEbzJuSHVSRWY1cGFvd09jcXlBak5XbnMtMS1wbEtPVngxXzUzSm5UbVRheUhwN0RfUl9] (zh:…
      人民日报图文数据库（1946-2026） 人民日报

### Ukraine Theater (total-war monitoring) — 163 new of 403 total
  - (2026-10-30) [FIRMS] thermal anomaly 49.237, 34.922 (FRP 9.16 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-30 1119Z, FRP 9.16 MW
  - (2026-10-30) [FIRMS] thermal anomaly 49.237, 34.923 (FRP 8.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-30 1119Z, FRP 8.29 MW
  - (2026-10-30) [FIRMS] thermal anomaly 50.162, 34.070 (FRP 4.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-30 1117Z, FRP 4.8 MW
  - (2026-10-30) [FIRMS] thermal anomaly 50.587, 33.384 (FRP 2.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-30 1117Z, FRP 2.28 MW
  - (2026-10-30) [FIRMS] thermal anomaly 51.107, 34.944 (FRP 3.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-30 1117Z, FRP 3.92 MW
  - (2026-10-30) [FIRMS] thermal anomaly 51.143, 34.931 (FRP 5.49 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-30 1117Z, FRP 5.49 MW

### U.S. Weather + Severe / Climate Outlooks — 130 new of 132 total
  - (2026-10-31) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-31) [Moderate] Special Weather Statement: Special Weather Statement issued October 31 at 5:23AM PDT by NWS Pendleton OR
      Patchy dense freezing fog has been observed along the Interstate 90 corridor from the Kittitas Valley to Snoqualmie Pass early this morning. Within freezing fog, visibilities of one-quarter mile or less are expected to p…
  - (2026-10-31) [Severe] Flood Warning: Flood Warning issued October 31 at 5:17AM MST until October 31 at 2:00PM MST by NWS Phoenix AZ
      * WHAT...Flooding caused by excessive rainfall is expected. * WHERE...Maricopa County in south central Arizona... * WHEN...Until 200 PM MST Saturday. * IMPACTS...Flooding of the Salt River below Granite Reef Dam is immin…
  - (2026-10-31) [Severe] Flood Watch: Flood Watch issued October 31 at 5:48AM MDT until November 2 at 11:00AM MST by NWS Pueblo CO
      * WHAT...Flooding caused by excessive rainfall is expected to occur. * WHERE...A portion of south central Colorado, including the following areas, the Eastern San Juan Mountains, and the Upper Rio Grande Valley. * WHEN..…
  - (2026-10-31) [Severe] Flood Watch: Flood Watch issued October 31 at 5:48AM MDT until November 4 at 5:00AM MST by NWS Pueblo CO
      * WHAT...Flooding caused by excessive rainfall will be possible, especially over the western half of San Luis Valley. * WHERE...The western half of the San Luis Valley, including Del Norte, Antonito and Mogote. * WHEN...…
  - (2026-10-31) [Moderate] Gale Warning: Gale Warning issued October 31 at 3:48AM AKDT until November 1 at 4:00AM AKST by NWS Juneau AK
      Southeast Alaska Inside Waters from Dixon Entrance to Skagway Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and…

### Ukrainian Internal News (national + local Kyiv) — 70 new of 134 total
  - (2026-10-31) Avenger Air Defense Missiles Deployed Near Trump’s Mar-a-Lago Resort
      The US Secret Service has deployed two Avenger surface-to-air missile systems on a floating barge near US President Donald Trump’s Mar-a-Lago estate in Florida following warnings of an elevated, dynamic threat environmen…
  - (2026-10-31) Trump Tinkers
      Despite calling himself a great dealmaker, the US president, in his attempt to negotiate a peace deal between Russia and Ukraine, has always made concessions to Moscow with nothing in return. If this is great dealmaking,…
  - (2026-10-31) Drones and Neptune Missiles Strike Kamensky Rocket Fuel Plant
      Ukrainian Defense Forces conducted a complex overnight strike using attack drones and Navy Neptune missile systems against the Kamensky chemical plant in Kamensk-Shakhtinsky, Rostov region, the General Staff announced on…
  - (2026-10-31) Russian Energy Strikes Cut Power to 280,000 Across Ukraine
      Coordinated Russian missile and drone strikes on Oct. 30 damaged combined heat and power plants, four electrical substations, gas distribution hubs, and rail infrastructure across Kyiv, Dnipro, Shostka, and Kharkiv, leav…
  - (2026-10-31) Russian War Casualties Up to 2.1 Million – The Economist
      A study published by The Economist estimates Russian military casualties at between 1.4 million and 2.1 million killed and wounded, with fatalities ranging from 374,000 to 770,000. In comparison, tracking site UALosses r…
  - (2026-10-31) Lavrov Protests Poland’s G20 Role as US Backs Full Membership
      Russian Foreign Minister Sergey Lavrov criticized the US on Friday, Oct. 30, for inviting Poland to participate as a full member in G20 ministerial meetings in Atlanta, claiming the unilateral invitation violated consens…

### State Legislative Action — 67 new of 139 total
  - (2026-10-31) [Alaska HB 69] An Act relating to the base student allocation; and providing for an effective date.
      An Act relating to the base student allocation; and providing for an effective date.
  - (2026-10-31) [Alaska HB 377] An Act relating to public records; relating to managing and preserving audio and video recordings; and relating to fees for the inspection and copying of public records under the Alask…
      An Act relating to public records; relating to managing and preserving audio and video recordings; and relating to fees for the inspection and copying of public records under the Alaska Public Records Act.
  - (2026-10-31) [Alaska HB 96] An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
      An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
  - (2026-10-31) [Alaska HB 314] An Act relating to registered interior designers and interior design; relating to project costs for the construction, enlargement, or improvement of airports; extending the termination…
      An Act relating to registered interior designers and interior design; relating to project costs for the construction, enlargement, or improvement of airports; extending the termination date of the State Board of Registra…
  - (2026-10-31) [Alaska HB 53] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental a…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-10-31) [Alaska HB 14] An Act relating to health care insurance; relating to insurance reimbursement for health care services provided through telehealth; relating to telehealth; relating to workers' compensa…
      An Act relating to health care insurance; relating to insurance reimbursement for health care services provided through telehealth; relating to telehealth; relating to workers' compensation coverage for disability from d…

### GDACS — global disaster alerts — 43 new of 100 total
  - (2026-10-31) [Green] Earthquake in Vanuatu
      Earthquake · Green alert · Vanuatu · Magnitude 5M, Depth:10km
  - (2026-10-31) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 4.9M, Depth:10km
  - (2026-10-31) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 4.9M, Depth:10km
  - (2026-10-31) [Green] Earthquake in Southeast Of Honshu, Japan
      Earthquake · Green alert · Southeast Of Honshu, Japan · Magnitude 4.6M, Depth:10km
  - (2026-10-31) [Green] Earthquake in Central Mid-Atlantic Ridge
      Earthquake · Green alert · Central Mid-Atlantic Ridge · Magnitude 4.5M, Depth:10km
  - (2026-10-29) [Green] Flood in Bhutan
      Flood · Green alert · Bhutan · Magnitude 0

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-31) [HANDLER RICHARD B] Form 4 (Reporting)
      filed 2026-10-31 01:37 UTC · role: Reporting — Filed: 2026-10-30 AccNo: 0001214659-26-013568 Size: 17 KB
  - (2026-10-31) [Jefferies Financial Group Inc.] Form 4 (Issuer)
      filed 2026-10-31 01:37 UTC · role: Issuer — Filed: 2026-10-30 AccNo: 0001214659-26-013568 Size: 17 KB
  - (2026-10-31) [Brophy Michael Burkes] Form 4 (Reporting)
      filed 2026-10-31 01:35 UTC · role: Reporting — Filed: 2026-10-30 AccNo: 0001697362-26-000021 Size: 8 KB
  - (2026-10-31) [Natera, Inc.] Form 4 (Issuer)
      filed 2026-10-31 01:35 UTC · role: Issuer — Filed: 2026-10-30 AccNo: 0001697362-26-000021 Size: 8 KB
  - (2026-10-31) [SenesTech, Inc.] Form 4 (Issuer)
      filed 2026-10-31 01:10 UTC · role: Issuer — Filed: 2026-10-30 AccNo: 0001731122-26-001386 Size: 13 KB
  - (2026-10-31) [GLENBROOK CAPITAL MANAGEMENT] Form 4 (Reporting)
      filed 2026-10-31 01:10 UTC · role: Reporting — Filed: 2026-10-30 AccNo: 0001731122-26-001386 Size: 13 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 38 new of 56 total
  - (2026-10-31) [The Hacker News] Chainalysis Confirms Intrusion Into Internal Tools and Exposure of Customer Identity Data
      American blockchain analysis firm Chainalysis said it was the target of a cybersecurity incident in which an external actor accessed non-sensitive customer data. However, the company noted that the breach did not result…
  - (2026-10-31) [The Hacker News] Attackers Chain Three Ivanti Connect Secure Flaws to Gain Unauthenticated Root Access
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Friday added two security flaws impacting Ivanti Connect Secure (ICS) to its Known Exploited Vulnerabilities (KEV) catalog, following active exploitatio…
  - (2026-10-31) [The Hacker News] A Shared ChatGPT Link Could Run Attacker Code in Your Session and Read Private Chats
      A malicious ChatGPT share link could run an attacker's code in the logged-in session of anyone who opened it, allowing them to read their private conversations, researchers at the security firm Parameter showed. The rese…
  - (2026-10-31) [The Hacker News] Cloudflare Reports 18.2 Million Network-Layer DDoS Attacks in Q3, Up 38%
      Threat actors are launching about 8,226 network-layer distributed denial-of-service (DDoS) attacks per hour, Cloudflare revealed Thursday. The web infrastructure and security company said it autonomously mitigated 18.2 m…
  - (2026-10-31) [The Register] Goth aesthetic gone wild: a user's self-inflicted black screen of non-death in Windows 3.1’s
      Labeled in black on black - controls for a galactic hyper-hearse or ill-advised Windows theme?
  - (2026-10-31) [The Register] Amazon sends chills through its workforce with mixed message memo about AI use
      A lot of software engineers feel bleak about the future of the profession

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 28 new of 60 total
  - (2026-10-30) Supreme Court of Alabama: Energy Alabama v. Alabama Public Service Commission and Alabama Power Company
  - (2026-10-30) Supreme Court of Alabama: In re: Warren Averett Companies, LLC v. BMSS, LLC
  - (2026-10-30) U.S. Court of Appeals, 8th Cir.: Jarell Terry v. Dexter Payne
  - (2026-10-30) U.S. Court of Appeals, 8th Cir.: Stephen Parr v. Union Pacific Railroad Co.
  - (2026-10-30) U.S. Court of Appeals, 10th Cir.: Flux Drive v. Sparks
  - (2026-10-30) U.S. Court of Appeals, 10th Cir.: Cozy Inn, Incorporated v. City of Salina, Kansas

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-10-31) JAF9NV (Bulgaria)
      icao24: 4520aa · position: (36.3501, -8.2053) · alt: 11292m · 843km/h
  - (2026-10-31) SAMU37 (France)
      icao24: 39ca87 · position: (47.6391, 0.8229) · alt: 167m · 127km/h
  - (2026-10-31) CFC4259 (Canada)
      icao24: c2b5b7 · position: (42.7501, 10.0014) · alt: 7315m · 639km/h
  - (2026-10-31) CFC2912 (Canada)
      icao24: c2b585 · position: (52.0689, 17.9413) · alt: 8229m · 595km/h
  - (2026-10-31) JAF8AV (Belgium)
      icao24: 44d1a5 · position: (50.7151, 4.858) · alt: 7673m · 787km/h
  - (2026-10-31) JAF5YV (Belgium)
      icao24: 44d1b3 · position: (41.3281, -5.8845) · alt: 11582m · 756km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 16 new of 105 total
  - (2026-10-26) [OFAC] 41 - Office of Foreign Assets Control (.gov)
      41 Office of Foreign Assets Control (.gov)
  - (2026-10-26) [OFAC] 50. Is there a required format for submitting Annual Reports of Blocked Property to OFAC? - Office of Foreign Assets Control (.gov)
      50. Is there a required format for submitting Annual Reports of Blocked Property to OFAC? Office of Foreign Assets Control (.gov)
  - (2026-10-26) [OFAC] 36 - Office of Foreign Assets Control (.gov)
      36 Office of Foreign Assets Control (.gov)
  - (2026-10-26) [OFAC] 42 - Office of Foreign Assets Control (.gov)
      42 Office of Foreign Assets Control (.gov)
  - (2026-10-31) [USASpending] $42,157,425,910 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-10-31) [USASpending] $34,661,763,245 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS

### U.S. Federal Action — 15 new of 15 total
  - (2026-11-02) Delegation of Authority Under Section 8335 of the National Defense Authorization Act for Fiscal Year 2026
  - (2026-11-02) Adjusting Imports of Robotics, Industrial Machinery, and Their Parts and Components Into the United States
  - (2026-11-02) Unleashing the Power of Unlicensed Ultra-Wideband Devices; Petition of Robert Bosch LLC for Amendment of the Part 15 Subpart F Ultra-Wideband Rules; and Petition of Alliance for Automative Innovation…
      The Federal Communications Commission (Commission or FCC) proposes to update its rules for Ultra-Wideband (UWB) devices to reflect significant technological developments since the rules were first adopted in 2002. UWB te…
  - (2026-11-02) Reducing Barriers to Network Improvements and Service Changes, Accelerating Network Modernization; Correction
      In this document, the Wireline Competition Bureau (Bureau) withdraws all amendatory instructions inadvertently included in the notification published on October 1, 2026, announcing the effective dates of amendments to th…
  - (2026-11-02) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain The Boeing Company Model 787-8, 787-9, and 787-10 airplanes. This AD was prompted by a report that, during production, certain sealant installations with…
  - (2026-11-02) Airworthiness Directives; The Boeing Company Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2023-07- 09, which applied to certain The Boeing Company Model 747-400 and -8 series airplanes. AD 2023-07-09 required inspecting for wear of the transfer pump housing…

### Campaign finance (FEC: top fundraisers + recent filings) — 13 new of 15 total
  - (2026-10-30) [F6] MIKE BELTRAN FOR CONGRESS
      cycle 2026 · filing #2044178
  - (2026-10-30) [F24] MOMSRISING PAC
      cycle 2026 · filing #2044309
  - (2026-10-30) [F6] SALUD CARBAJAL FOR CONGRESS
      cycle 2026 · filing #2044298
  - (2026-10-30) [F6] PEGGY FLANAGAN FOR MINNESOTA
      cycle 2026 · filing #2044481
  - (2026-10-30) [F6] KOZYCKI FOR CONGRESS
      cycle 2026 · filing #2044353
  - (2026-10-30) [F6] LA GENTE FOR GRIJALVA
      cycle 2026 · filing #2044154

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-10-31) Counter-Strike: Nemiga vs FURIA (BO5) - PGL Masters Bucharest Playoffs
      yes price: 32% · 24h volume: $1,783,375 · resolves 2026-10-31
  - (2026-10-31) Will Chelsea FC win on 2026-10-31?
      yes price: 44% · 24h volume: $986,166 · resolves 2026-10-31
  - (2026-10-31) Will Republicans win Iowa and Kansas, and lose Alaska, Maine, Michigan, Ohio, and Texas?
      yes price: 14% · 24h volume: $984,387 · resolves 2026-11-03
  - (2026-10-31) Counter-Strike: Nemiga vs FURIA - Map 2 Winner
      yes price: 0% · 24h volume: $876,546 · resolves 2026-10-31
  - (2026-10-31) Will the Republicans win the Michigan Senate race in 2026?
      yes price: 20% · 24h volume: $757,382 · resolves 2026-11-04
  - (2026-10-31) Will the Democrats win the Michigan Senate race in 2026?
      yes price: 78% · 24h volume: $749,087 · resolves 2026-11-04

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-10-31) M 5.0 - 196 km NW of Port-Olry, Vanuatu
      M5.0 · 196 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-31) M 4.9 - 236 km NW of Port-Olry, Vanuatu
      M4.9 · 236 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-31) M 4.9 - 213 km W of Sola, Vanuatu
      M4.9 · 213 km W of Sola, Vanuatu · depth 10 km
  - (2026-10-31) M 4.8 - 97 km ENE of Port-Olry, Vanuatu
      M4.8 · 97 km ENE of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-30) M 4.7 - 222 km NW of Port-Olry, Vanuatu
      M4.7 · 222 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-31) M 4.6 - Izu Islands, Japan region
      M4.6 · Izu Islands, Japan region · depth 10 km

### Paper Trading Scorecard — 11 new of 67 total
  - (2026-10-31) [Polymarket] Will Ohio enact a data center moratorium by December 31, 2028?
      This market will resolve to "Yes" if the State of Ohio enacts a law or constitutional provision that establishes a statewide moratorium on new data centers between market creation and the specified date, 11:59 PM ET. Oth…
  - (2026-10-31) [Polymarket] Will Anthropic's initial public offering occur in October 2026 (ET)?
      This market will resolve based on the calendar month (ET) in which Anthropic's initial public offering (IPO) occurs. The resolving month will be the calendar month (ET) containing the first day on which Anthropic shares…
  - (2026-10-31) [Manifold] Will Donald Tusk be the Prime Minister of Poland at the end of November 2026?
  - (2026-10-31) [Manifold] Will Daniel J. Sullivan Jr.'s vote total exceed Peltola's winning margin in Alaska's Senate race?
  - (2026-10-31) [Manifold] Will Haley Stevens be a speaker the 2028 RNC?
  - (2026-10-31) [Manifold] Russia to participate in the 2027 IIHF Ice Hockey World Championship

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-31) [Marginal Revolution] The pass-through of retail crime
      This paper shows retailers increase prices in response to organized retail crime. We match store-level crime data to scanner data from the universe of transactions for cannabis retailers in Washington state. Using quasi-…
  - (2026-10-31) [Marginal Revolution] The unintended consequences of academic leniency
      Education is widely recognized as the primary driver of human capital accumulation. However, policies designed to promote educational attainment often overlook students’ endogenous responses. This paper provides empirica…
  - (2026-10-30) [Marginal Revolution] Friday assorted links
      1. Dwarkesh interviews Robert Caro (!). 2. New and pretty brutal results on CTE and football. 3. Interview with Dan Wang. 4. Updated version of the Saez-Zucman audit. Contestable and speculative assumptions are now separ…
  - (2026-10-30) [Conversable Economist] Snapshots of the US Wealth Distribution
      Forbes magazine has just published its annual list of the 400 wealthiest Americans, who this year hold a total of $8 trillion in wealth. It’s a gobsmacking amount of money, but we also live in a world where trillions are…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 18 total
  - (2026-10-30) CVE-2026-118527 · Ivanti Connect Secure: Ivanti Connect Secure Generation of Predictable Numbers or Identifiers Vulnerability
      vendor: Ivanti · product: Connect Secure · CISA remediation by 2026-11-13
  - (2026-10-30) CVE-2026-111357 · Ivanti Connect Secure: Ivanti Connect Secure Missing Authentication for Critical Function Vulnerability
      vendor: Ivanti · product: Connect Secure · CISA remediation by 2026-11-02

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-31) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=15, 14d-median=16; carrying terms: procedures, certain, regulatory, action, final, enforcement, published, national, public, safety, proposing, proposed
- state_bills: today=139, 7d-median=82, 14d-median=109; carrying terms: school, vehicle, facilities, county, provides, alaska, election, insurance, review, motor, legislative, state
- state_news: today=757, 7d-median=724, 14d-median=688; carrying terms: looking, illinois, scaled, pennsylvania, sports, workers, green, figure, still, hundreds, ballots, known
- local_news: today=277, 7d-median=260, 14d-median=241; carrying terms: illinois, still, blank, following, brings, murder, voting, charged, october, missouri, appeared, arrested
- foreign_news: today=1015, 7d-median=1006, 14d-median=1006; carrying terms: province, offers, workers, faced, higher, still, follow, abuse, deadly, hundreds, inclusion, vietnamese
- chinese_internal: today=277, 7d-median=278, 14d-median=277; carrying terms: lxtfa, blank, cbmizkfvx, market, target, cbmiykfvx, https, cbmix, cbmia, google, cbmiy, color
- russian_internal: today=990, 7d-median=991, 14d-median=1010; carrying terms: russian, journal, error, httperror, starlink, gazeta, title, reuters, server, times, media, https
- ukrainian_internal: today=134, 7d-median=130, 14d-median=134; carrying terms: region, damaged, deliveries, starlink, meeting, facilities, sabotage, independent, remarks, month, assessment, diplomatic
- ukraine_theater: today=403, 7d-median=390, 14d-median=397; carrying terms: awqlkxtve, province, damaged, cxvyy, systems, kasta, mnhqm, bomugxvk, ftrutsxzfos, mxfpv, qnjbaxruwmxirvh, zcvbjofk
- paper_bets: today=67, 7d-median=64, 14d-median=65; carrying terms: jpmorgan, office, fuentes, kalshi, mahomes, hypothesis, celsius, state, receiving, manifold, magnitude, season
- weather: today=132, 7d-median=132, 14d-median=134; carrying terms: small, afdhgx, roads, result, river, alert, coast, level, details, early, shore, times
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: recession, dcoilwtico, nonfarm, cpiaucsl, payems, assets, dexuseu, pcepilfe, openings, effective, funds, dexjpus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, treasury, russell, commodities, futures, large, agriculture, proxy, close, range, bitcoin, crypto
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=105, 7d-median=103, 14d-median=104; carrying terms: transnistrian, order, frequently, resolution, office, democratic, region, sectoral, guinea, authorities, yemen, bosnia
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quantitative, client, quiverquant, error, quiver, unauthorized, httperror, congresstrading
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, board, state, court, international, appeals, supreme, trade, services, arkansas, alabama, company
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, reporting, accno, holdings, financial, natera, michael, robert, pharmaceuticals, capital
- fec: today=15, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, congress, adams, johnson
- gdelt_regions: today=0, 7d-median=12, 14d-median=12
- gdelt_gkg: today=0, 7d-median=25, 14d-median=38; carrying terms: english, keywords, israel, attack, sanctions, spanish, hezbollah, netanyahu, elections, themes, russian, chinese
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=30, 14d-median=27; carrying terms: position, belgium, france, kingdom, germany, canada, bulgaria, aabbef
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: update, probable, mortality, clade, traceability, democratic, addition, region, uganda, authorities, person, april
- cisa_kev: today=18, 7d-median=18, 14d-median=17; carrying terms: vendor, injection, vulnerability, external, control, secure, server, product, command, improper, authentication, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: hurricane, typhoon, nigeria, impact, tropical, guinea, papua, green, forestfire, indonesia, wildfire, magnitude
- usgs_quakes: today=12, 7d-median=18, 14d-median=21; carrying terms: depth, vanuatu, philippines, islands, japan, region, russia, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, election, resolves, championship, champions, shakhtar, league, donetsk, presidential, power, senate
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, economist, class, https, marginal, conversable, world, capital, money, human, countries, trump
- tech_news: today=56, 7d-median=56, 14d-median=57; carrying terms: download, computer, vulnerabilities, systems, number, around, https, record, model, compromised, infrastructure, spectrum
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: tiffany, greer, marilyn, lawler, april, golden, figures, ogles, kansas, susie, betty, hillary
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, paper, markets, decision, placement, either, converges, market, consensus, unavailable, identify, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-27] ECB press: October 2026 euro area bank lending survey
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] ECB press: ECB President Lagarde to step down on 7 February 2027
- [2026-10-29] ECB press: Monetary policy decisions
- [2026-10-29] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-10-29] ECB press: Piero Cipollone: Next-day securities settlement, tokenisation and the transformation of Europe’s financial infrastructure
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Results of the ECB Survey of Professional Forecasters for the fourth quarter of 2026
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*