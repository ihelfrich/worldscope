# WORLDSCOPE morning brief — 2026-10-14

## Headline
3207 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (801) · Russian Internal News (state + in-exile) (667) · World leaders & government officials (324) · State-Level News (315) · Chinese Internal News (233) · Local News: St. Louis + Atlanta (207) · U.S. Weather + Severe / Climate Outlooks (146) · Ukraine Theater (total-war monitoring) (82) · GDACS — global disaster alerts (64) · State Legislative Action (60) · Ukrainian Internal News (national + local Kyiv) (57) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 801 new of 1021 total
  - (2026-10-14) [Global] Joni Mitchell becomes US citizen: ‘A journey that began 62 years ago’
  - (2026-10-13) [Global] Intense waves and floods batter California waterfront homes and boardwalks
  - (2026-10-14) [Global] Russia arrests Japanese journalist on allegations of spying
  - (2026-10-14) [Global] Graduate student accused of poisoning colleague and trying to flee to China arrested at LAX
  - (2026-10-14) [Global] Child safety officer incorrectly assessed Elizabeth Struhs as ‘safe’ day after she was admitted to hospital in coma
  - (2026-10-14) [Global] Labor’s bill to cut private health insurance rebate blocked by Greens over pensioner carve-out

### Russian Internal News (state + in-exile) — 667 new of 1123 total
  - (2026-10-14) Открылся предзаказ на «АЗ есмь» — совместную книгу кинокритика Антона Долина и режиссера Андрея Звягинцева. А еще мы сделали футболки по мотивам фильма «Минотавр». Их уже можно купить в нашем «] (ru:…
      Биография Андрея Звягинцева напоминает приключенческий роман — актер родом из Новосибирска, работавший в голодные девяностые дворником и сторожем, самостоятельно осваивает искусство режиссуры, стремительно завоевывает пу…
  - (2026-10-14) В Подмосковье построят крупнейшее в России СИЗО на четыре тысячи мест | LEDE: В Солнечногорском округе Московской области построят крупнейшее СИЗО в России. Аукцион на строительство объявило] (ru: В П…
      В Солнечногорском округе Московской области построят крупнейшее СИЗО в России. Аукцион на строительство объявило региональное управление ФСИН.
  - (2026-10-14) В Украине пятерых российских ученых обвинили в военных преступлениях из-за раскопок в аннексированном Крыму | LEDE: В Украине расследуют уголовные дела в отношении пяти российских археологов] (ru: В У…
      В Украине расследуют уголовные дела в отношении пяти российских археологов из-за раскопок в аннексированном Крыму. Об этом сообщает «Русская служба Би-би-си» со ссылкой прокурорские и судебные документы, оказавшиеся в ра…
  - (2026-10-14) МИД России объявил о введении ответных виз для граждан Черногории | LEDE: Гражданам Черногории нужно будет получать визы для поездок в Россию, заявила «Известиям» представитель МИД РФ Мария ] (ru: МИД…
      Гражданам Черногории нужно будет получать визы для поездок в Россию, заявила «Известиям» представитель МИД РФ Мария Захарова.
  - (2026-10-14) Образ «традиционной жены» — это ловушка, настаивала Сьюзен Таубес в своих романах «Плач по Юлии» и «Развод». К забытой писательнице пришла посмертная слава, в том числе в России | LEDE: В из] (ru: Обр…
      В издательстве «Подписные издания» вышел роман венгерско-американской писательницы Сьюзен Таубес «Плач по Юлии» — вместе с девятью ее рассказами. Все тексты опубликованы на русском впервые — в переводе Юлии Полещук. Одно…
  - (2026-10-14) В Турции остановили вещание оппозиционного Halk TV. Власти ввели на телеканале внешнее управление | LEDE: В Турции остановилось вещание одного из крупнейших оппозиционных телеканалов Halk TV] (ru: В Т…
      В Турции остановилось вещание одного из крупнейших оппозиционных телеканалов Halk TV. Полиция провела обыски в редакции в Стамбуле, каналу назначили внешнего управляющего.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 315 new of 726 total
  - (2026-10-14) [California] Governor Newsom announces appointments 10.13.2026
      Source
  - (2026-10-13) [California] Governor Newsom announces results from California’s first-in-the-nation project to involve Californians in decisions about AI
      Source
  - (2026-10-13) [California] California’s clean-energy grid powers through climate-driven extreme heat, meeting highest demand since 2022
      Source
  - (2026-10-14) [Connecticut] The 169 Problem: Why CT is more expensive than it needs to be
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/10/CT-169-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high" sr…
  - (2026-10-14) [Connecticut] Delayed by investigation, Fazio spent $9.6M over summer challenging Lamont
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/10/FAZIO-FAIR-1009-SG-01-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading=…
  - (2026-10-14) [Connecticut] Jahana Hayes, Chris Shea square off in CT 5th District debate
      <img width="1024" height="578" src="https://ctmirror.org/wp-content/uploads/2026/10/Screenshot-2026-10-13-at-8.09.42-PM-e1791944872758-1024x578.png" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…

### Chinese Internal News — 233 new of 309 total
  - (2026-10-13) Chinese Border City Issues Plague Alert for Travelers From Russia’s Far East - Caixin Global
      Chinese Border City Issues Plague Alert for Travelers From Russia’s Far East Caixin Global
  - (2026-10-13) 袁家军：全面彻底肃清流毒影响、修复净化政治生态 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE9vc3BHYkhHOUkyTVhMS3FZZ1VjSGlGak93eWh3N2VtNVc4LVNhSnc5Z3lqcVYwYzFyRU1wTktiZVRpU2RXM2kwYVBWOERH] (zh:…
      袁家军：全面彻底肃清流毒影响、修复净化政治生态 观察者网
  - (2026-10-14) 美国开始严管“毒品式”保健品 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE12SGN1enJ6dkdlekpVWkhJZ3lqVkVJSGY0eW1pLVFEVVMtZk4xRFdPaW5pSDE1ZUZSMjNMUTgzX1Fnc28xU3ZkX1NVUW9MTlcta1daR] (zh:…
      美国开始严管“毒品式”保健品 观察者网
  - (2026-10-14) 一路丰碑｜血染湘江水，铸就视死如归忠诚 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1ndzVIUlZqUTd6UDRQOUY2SVZKNmcyN1VJVGQ5RVFhN0hzQzU3VllOVnYwVHZwZEJUcjNIeThubjJpa2dYNGRHRVZCcDFvNm1S] (zh:…
      一路丰碑｜血染湘江水，铸就视死如归忠诚 观察者网
  - (2026-10-14) 日本一精神科医生涉嫌肢解妻子被捕，13年前其前妻也离奇死亡 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE05alJjaTFwTDI3T3RwVFFkTC1NWTd3YThOQ1AxSzFrUk5lWkZaX3NiWFA5bnNyN0JpSG50MVJ1cVhxTGkwRHhUT0] (zh:…
      日本一精神科医生涉嫌肢解妻子被捕，13年前其前妻也离奇死亡 观察者网
  - (2026-10-14) 厨师长教你：“软烧鲫鱼”的家常做法，肉质鲜嫩，酸辣入味 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE12OHJuX2RuLTh4M1Nuc2U5clNRMjJqNTFtRTRGUWQ1V3BPakRjZjBtZzdSa1AxQ19EMDhrcHhNcG13Sjg5c0ljcU4zaU] (zh:…
      厨师长教你：“软烧鲫鱼”的家常做法，肉质鲜嫩，酸辣入味 风闻

### Local News: St. Louis + Atlanta — 207 new of 243 total
  - (2026-10-14) [St. Louis] Six Flags Over Georgia roller coaster death sparks debate on US amusement park safety regulations
      A 42-year-old man's death after he was ejected from a roller coaster in Georgia is drawing attention to the safety of amusement park rides.
  - (2026-10-14) [St. Louis] FBI arrests OpenAI employee accused of placing recording device in company conference room
      The FBI has arrested an OpenAI employee for allegedly bugging a corporate conference room. It's unclear what motive investigators suspect.
  - (2026-10-14) [St. Louis] Pope Leo at Rome hospital as he recovers from surgery to remove lung cancer, Vatican says
      Pope Leo XIV spent a tranquil night in Rome's Gemelli hospital following an operation to remove the lower lobe of his right lung and a confirmed cancer diagnosis.
  - (2026-10-14) [St. Louis] Woman accused of killing her husband and 3-year-old son at Pennsylvania resort
      A Pennsylvania woman was charged with killing her husband and toddler son while they were staying at a Great Wolf Lodge resort, officials said.
  - (2026-10-14) [St. Louis] Britney Spears releases 'She'll Never Be Me,' early 2000s collab with Justin Timberlake
      Britney Spears dropped a previously unreleased song written with Justin Timberlake and recorded for her 2001 album.
  - (2026-10-14) [St. Louis] North County church calls for speeding enforcement on dangerous roadway that claimed 2 lives
      Community leaders and grieving loved ones voice urgent safety concerns over a hazardous stretch of road where police have logged dozens of injury crashes.

### U.S. Weather + Severe / Climate Outlooks — 146 new of 150 total
  - (2026-10-14) [Moderate] Gale Warning: Gale Warning issued October 14 at 3:51AM AKDT until October 15 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…
  - (2026-10-14) [Moderate] Gale Warning: Gale Warning issued October 14 at 3:51AM AKDT until October 14 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…
  - (2026-10-14) [Moderate] Gale Warning: Gale Warning issued October 14 at 3:51AM AKDT until October 15 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…
  - (2026-10-14) [Moderate] Gale Warning: Gale Warning issued October 14 at 3:51AM AKDT until October 15 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…
  - (2026-10-14) [Moderate] Gale Warning: Gale Warning issued October 14 at 3:51AM AKDT until October 15 at 5:00AM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…
  - (2026-10-14) [Moderate] Gale Warning: Gale Warning issued October 14 at 3:51AM AKDT until October 14 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for the Northern Gulf of Alaska Coast up to 100 nm out including Kodiak Island and Cook Inlet. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an avera…

### Ukraine Theater (total-war monitoring) — 82 new of 364 total
  - (2026-10-13) [FIRMS] thermal anomaly 52.847, 29.989 (FRP 1.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-13 2350Z, FRP 1.25 MW
  - (2026-10-13) [FIRMS] thermal anomaly 51.891, 29.339 (FRP 1.1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-13 2350Z, FRP 1.1 MW
  - (2026-10-13) [FIRMS] thermal anomaly 50.785, 25.386 (FRP 0.9 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-13 2350Z, FRP 0.9 MW
  - (2026-10-13) [FIRMS] thermal anomaly 50.780, 25.386 (FRP 1.61 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-13 2350Z, FRP 1.61 MW
  - (2026-10-13) [FIRMS] thermal anomaly 49.454, 24.223 (FRP 0.59 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-13 2350Z, FRP 0.59 MW
  - (2026-10-13) [FIRMS] thermal anomaly 49.454, 24.223 (FRP 0.42 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-13 2350Z, FRP 0.42 MW

### GDACS — global disaster alerts — 64 new of 100 total
  - (2026-10-13) [Green] Flood in Libya
      Flood · Green alert · Libya · Magnitude 0
  - (2026-10-14) [Green] Earthquake in Fiji
      Earthquake · Green alert · Fiji · Magnitude 5.9M, Depth:585.07km
  - (2026-10-13) [Green] Tropical Cyclone TRUDY-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 213 km/h)
  - (2026-10-14) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 4.9M, Depth:35km
  - (2026-10-14) [Green] Earthquake in Panama
      Earthquake · Green alert · Panama · Magnitude 4.7M, Depth:10km
  - (2026-10-14) [Green] Earthquake in Chile
      Earthquake · Green alert · Chile · Magnitude 4.9M, Depth:44.914km

### State Legislative Action — 60 new of 64 total
  - (2026-10-14) [Alaska HB 264] An Act making appropriations, including capital appropriations, supplemental appropriations, and reappropriations; making appropriations to capitalize funds; and providing for an effec…
      An Act making appropriations, including capital appropriations, supplemental appropriations, and reappropriations; making appropriations to capitalize funds; and providing for an effective date.
  - (2026-10-14) [Alaska SB 129] An Act establishing a 30-day deadline for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agre…
      An Act establishing a 30-day deadline for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements to nonprofit organizations, m…
  - (2026-10-14) [Alaska HB 263] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-10-14) [Alaska HB 133] An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements t…
      An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements to nonprofit organizations, municipal…
  - (2026-10-14) [California AB 1054] Public employees' retirement: deferred retirement option program: public employee health benefits.
      Existing law, the County Employees Retirement Law of 1937, prescribes retirement benefits for members of specified county and district retirement systems. Existing law establishes the Deferred Retirement Option Program a…
  - (2026-10-14) [California AB 2717] Outdoor advertising displays: arenas: exemptions.
      The Outdoor Advertising Act provides for the regulation by the Department of Transportation of advertising displays, as defined, within view of public highways. The act exempts from most of its provisions an advertising…

### Ukrainian Internal News (national + local Kyiv) — 57 new of 127 total
  - (2026-10-14) Єврокомісарка Кос вважає можливим завершити переговори про вступ Молдови в ЄС у 2028 році | LEDE: ] (uk: Єврокомісарка Кос вважає можливим завершити переговори про вступ Молдови в ЄС у )
  - (2026-10-14) Російський дрон залітав до Румунії, потім його збили в Україні | LEDE: Міноборони Румунії: дрон коротко залетів у румунський простір біля Суліни, після чого був знищений українською протиповітр] (uk:…
      Міноборони Румунії: дрон коротко залетів у румунський простір біля Суліни, після чого був знищений українською протиповітряною обороною.
  - (2026-10-14) Прикидалися жінками на сервісах знайомств: в Україні вперше повідомили про підозру за створення шахрайського кол-центру | LEDE: У Стрию затримали трьох осіб, які створили шахрайський кол-центр ] (uk:…
      У Стрию затримали трьох осіб, які створили шахрайський кол-центр через онлайн-знайомства. Їм загрожує до 15 років ув'язнення за новим законом.
  - (2026-10-14) Поліція показала наслідки ворожої атаки на Рівне: 8 потерпілих, серед них дитина | LEDE: Внаслідок атаки російських окупаційних військ на житловий сектор у Рівному зазнали поранень вісім людей,] (uk:…
      Внаслідок атаки російських окупаційних військ на житловий сектор у Рівному зазнали поранень вісім людей, серед них – дитина.
  - (2026-10-14) Поліція Польщі відпустила чоловіків, яких згодом запідозрили в підпалі Starlink – ЗМІ | LEDE: Польські поліцейські наступного дня після пожежі на станції Starlink перевірили двох громадян Туреч] (uk:…
      Польські поліцейські наступного дня після пожежі на станції Starlink перевірили двох громадян Туреччини, яких згодом запідозрили в підпалі, але не затримали їх.
  - (2026-10-14) Конкурент на шляху до ЄС. Як Україні відкрили кластери та чому доведеться наздоганяти Молдову | LEDE: ] (uk: Конкурент на шляху до ЄС. Як Україні відкрили кластери та чому доведеться наздог)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-14) 497 - VanEck ETF Trust (0001137360) (Filer)
      filed 2026-10-14 11:52 UTC — Filed: 2026-10-14 AccNo: 0001137360-26-000959 Size: 65 KB
  - (2026-10-14) [MORRISON SCOTT C] Form 4 (Reporting)
      filed 2026-10-14 11:24 UTC · role: Reporting — Filed: 2026-10-14 AccNo: 0001205945-26-000004 Size: 7 KB
  - (2026-10-14) [CACI INTERNATIONAL INC /DE/] Form 4 (Issuer)
      filed 2026-10-14 11:24 UTC · role: Issuer — Filed: 2026-10-14 AccNo: 0001205945-26-000004 Size: 7 KB
  - (2026-10-14) [SZEWS CHARLES L] Form 4 (Reporting)
      filed 2026-10-14 11:24 UTC · role: Reporting — Filed: 2026-10-14 AccNo: 0001230604-26-000007 Size: 7 KB
  - (2026-10-14) [CACI INTERNATIONAL INC /DE/] Form 4 (Issuer)
      filed 2026-10-14 11:24 UTC · role: Issuer — Filed: 2026-10-14 AccNo: 0001230604-26-000007 Size: 7 KB
  - (2026-10-14) [McCarthy Ryan D] Form 4 (Reporting)
      filed 2026-10-14 11:24 UTC · role: Reporting — Filed: 2026-10-14 AccNo: 0001895585-26-000003 Size: 7 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 40 new of 58 total
  - (2026-10-14) [BleepingComputer] Hirudo Android malware replaces banking apps to evade security checks
      A new Android malware called Hirudo steals bank account credentials by replacing legitimate banking apps with modified versions that disable security checks. [...]
  - (2026-10-14) [BleepingComputer] Microsoft: Recent Windows updates may trigger Remote Desktop failures
      Microsoft has confirmed that non-admin users may be unable to connect to devices via Remote Desktop after installing recent Windows updates if the "Administrator protection" security feature is enabled. [...]
  - (2026-10-14) [The Hacker News] Researchers Used a Public OpenAI Model to Build a $250,000 Chrome Full-Chain Exploit in Six Days
      A team at security firm XBOW chained three then-unknown Google Chrome bugs into a single attack that runs code on a Windows computer when the user only loads a web page, the company said. Its researchers built the attack…
  - (2026-10-14) [The Hacker News] Hirudo Android Trojan Uses Patched Banking Apps to Bypass Their Built-In Security Checks
      Cybersecurity researchers have disclosed details of a new Android banking trojan called Hirudo that works by replacing legitimate banking apps with purpose-built patched versions designed to bypass security checks from i…
  - (2026-10-14) [The Hacker News] An AI Agent Found a Critical OTP Bypass in Production. The Attack Was the Easy Part.
      The bug was simple: the login let you choose where your sign-in code went. Proving it on a live website was the hard part. TL;DR During an authorized assessment, an AI pentesting agent found a critical authentication byp…
  - (2026-10-14) [The Hacker News] AI-Found Linux Kernel Flaw Gives Local Users Root, and Can Break a Guest Out to the Host
      A flaw in Linux's vhost subsystem lets a local user read and write kernel memory at will and become root across nearly a decade of kernel versions. In one virtualization setup, it lets an untrusted virtual machine write…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 27 new of 28 total
  - (2026-10-14) JAF50T (Bulgaria)
      icao24: 4520ce · position: (41.778, -2.4455) · alt: 11277m · 797km/h
  - (2026-10-14) FAF7811 (France)
      icao24: 39a858 · position: (45.5939, -0.4009) · alt: 388m · 204km/h
  - (2026-10-14) GAF136 (Germany)
      icao24: 3f7588 · position: (41.9854, 14.8315) · alt: 10050m · 855km/h
  - (2026-10-14) GAF901 (Germany)
      icao24: 3ea12c · position: (48.4934, 20.4777) · alt: 11277m · 953km/h
  - (2026-10-14) JAF5HJ (Belgium)
      icao24: 44d1ba · position: (47.7048, 2.0856) · alt: 10668m · 859km/h
  - (2026-10-14) JAF4NW (Belgium)
      icao24: 44d1a6 · position: (50.5028, 5.4397) · alt: 5996m · 716km/h

### Paper Trading Scorecard — 23 new of 79 total
  - (2026-10-14) [Polymarket] Will María Corina Machado enter Venezuela by December 31?
      If María Corina Machado visits Venezuela between market creation and December 31, 2026, 11:59 PM ET, this market will resolve to "Yes". Otherwise, this market will resolve to "No". For the purpose of this market, a "visi…
  - (2026-10-14) [Polymarket] Will Traian Basescu be the next Prime Minister of Romania?
      This market will resolve to the next individual who officially assumes the office of Prime Minister of Romania by December 31, 2027, 11:59 PM ET. To count for resolution, the individual must be formally appointed by the…
  - (2026-10-14) [Manifold] Will the Super Heavy booster explode during Starship Flight 15?
  - (2026-10-14) [Manifold] Fable 5.5 is released before October 16th?
  - (2026-10-14) [Manifold] Katie Zacharia (press secretary) lasts longer than a mooch?
  - (2026-10-14) [Manifold] Will Republicans win a Majority of Toss up house seats in 2026? [Sabato's Crystal Ball]

### U.S. Federal Action — 22 new of 22 total
  - (2026-10-14) Establishment of a Committee of Inquiry To Investigate Allegations of False Statements by Lisa DeNell Cook
  - (2026-10-14) AP1000 Design Certification Renewal
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its regulations to renew the AP1000 design certification and incorporate Revision 20 of the AP1000 design control document. The purpose of this rulemakin…
  - (2026-10-14) AP1000 Design Certification Renewal
      The U.S. Nuclear Regulatory Commission (NRC) is amending its regulations to renew the AP1000 design certification and incorporate Revision 20 of the AP1000 design control document. The purpose of this rulemaking action i…
  - (2026-10-14) Imposition and Collection of Civil Penalties for Certain Immigration-Related Violations
      On June 27, 2025, the Departments issued an interim final rule ("IFR") to streamline assessment of civil penalties under the Immigration and Nationality Act ("INA") for aliens who fail to depart during a voluntary depart…
  - (2026-10-14) Allocation of Assets in Single-Employer Plans; Interest Assumptions for Valuing Benefits
      This final rule amends the Pension Benefit Guaranty Corporation's regulation on Allocation of Assets in Single-Employer Plans to prescribe the spreads component of the interest assumption under the asset allocation regul…
  - (2026-10-14) Airworthiness Directives; Leonardo S.p.a. Helicopters
      The FAA proposes to supersede Airworthiness Directive (AD) 2024-05-06, which applies to all Leonardo S.p.a Model AW169 helicopters. AD 2024-05-06 requires revising the airworthiness limitations section (ALS) of the exist…

### Court opinions of consequence (federal & state) — 17 new of 60 total
  - (2026-10-13) U.S. Court of Appeals, 2nd Cir.: Santos v. Lidl
  - (2026-10-13) U.S. Court of Appeals, 3rd Cir.: Edward Williams v. Attorney General United States of America
  - (2026-10-13) U.S. Court of Appeals, 3rd Cir.: United States v. James Bost
  - (2026-10-13) U.S. Court of International Trade: GameChange Solar Corp. v. United States
  - (2026-10-13) U.S. Court of Appeals, 8th Cir.: Brooklyn Rockett v. Eric Eighmy
  - (2026-10-13) U.S. Court of Appeals, 10th Cir.: Vision Bank v. Avery

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-10-14) LoL: BNK FEARX vs KT Rolster - Game 3 Winner
      yes price: 100% · 24h volume: $1,509,274 · resolves 2026-10-14
  - (2026-10-14) LoL: BNK FEARX vs KT Rolster (BO5) - Demacia Cup Global Invitational Playoffs
      yes price: 87% · 24h volume: $1,294,820 · resolves 2026-10-14
  - (2026-10-14) Shanghai Rolex Masters: Daniil Medvedev vs Stefanos Tsitsipas
      yes price: 100% · 24h volume: $1,288,801 · resolves 2026-10-21
  - (2026-10-14) LoL: BNK FEARX vs KT Rolster - Game 2 Winner
      yes price: 0% · 24h volume: $1,112,350 · resolves 2026-10-14
  - (2026-10-14) LoL: BNK FEARX vs KT Rolster - Game 1 Winner
      yes price: 100% · 24h volume: $1,101,398 · resolves 2026-10-14
  - (2026-10-14) Will Manchester City FC win on 2026-10-14?
      yes price: 48% · 24h volume: $868,638 · resolves 2026-10-14

### USGS earthquakes (M4.5+, past day) — 15 new of 17 total
  - (2026-10-13) M 6.0 - 126 km S of Kokopo, Papua New Guinea
      M6.0 · 126 km S of Kokopo, Papua New Guinea · depth 20.842 km
  - (2026-10-14) M 5.9 - Fiji region
      M5.9 · Fiji region · depth 585.07 km
  - (2026-10-13) M 5.3 - 122 km S of Kokopo, Papua New Guinea
      M5.3 · 122 km S of Kokopo, Papua New Guinea · depth 18.521 km
  - (2026-10-14) M 5.1 - 93 km NNW of Coquimbo, Chile
      M5.1 · 93 km NNW of Coquimbo, Chile · depth 21.947 km
  - (2026-10-13) M 5.1 - 119 km S of Kokopo, Papua New Guinea
      M5.1 · 119 km S of Kokopo, Papua New Guinea · depth 28.4 km
  - (2026-10-14) M 5.0 - 98 km NW of Coquimbo, Chile
      M5.0 · 98 km NW of Coquimbo, Chile · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 107 total
  - (2026-10-13) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Bank of America, N.A. - Office of Foreign Assets Control (.gov)
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Bank of America, N.A. Office of Foreign Assets Control (.gov)
  - (2026-10-13) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Counter Narcotics and Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-10-14) [USASpending] $616,333,357 → CLARK CONSTRUCTION GROUP LLC: IRA: PROVIDE LABOR, MATERIALS, SUPERVISION, AND EQUIPMENT TO
      Agency: General Services Administration. Description: IRA: PROVIDE LABOR, MATERIALS, SUPERVISION, AND EQUIPMENT TO CONSTRUCT THE NEW CISA HQ BUILDING. SERVICES INCLUDE, BUT ARE NOT LIMITED: CIVIL AND SITE WORK CONSISTING…
  - (2026-10-14) [USASpending] $110,613,083 → FIREFLY AEROSPACE INC.: ENHAMCED LANDING AND MONILITY STUDY
      Agency: National Aeronautics and Space Administration. Description: ENHAMCED LANDING AND MONILITY STUDY
  - (2026-10-14) [USASpending] $108,741,465 → SERRATO CORPORATION: NORTH TEXAS AWARD
      Agency: Department of Labor. Description: NORTH TEXAS AWARD
  - (2026-10-14) [USASpending] $99,567,391 → WHITING-TURNER CONTRACTING COMPANY, THE: CONTRACTOR TO PROVIDE BRIDGING DESIGN BUILD SERVICES FOR THE
      Agency: General Services Administration. Description: CONTRACTOR TO PROVIDE BRIDGING DESIGN BUILD SERVICES FOR THE ASHLEY U.S. COURTHOUSE MODERNIZATION AND NEW ANNEX PROJECT IN TOLEDO, OHIO.

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-10-14) [Marginal Revolution] *Plunder: The Last of the War in Europe, 1945*
      By Max Hastings, an excellent book, I benefited from every page. One recurring theme is simply how hard the Germans fought on the way down, and how unusual that behavior was. Here is one interesting passage of many: In W…
  - (2026-10-14) [Marginal Revolution] Well-planned African immigration to America will go fine
      That is the topic of free latest Free Press column, here is one excerpt: The good news is that African immigrants already have done well in the United States. For instance, 46 percent of African immigrants complete a col…
  - (2026-10-13) [Marginal Revolution] Perry Mehrling, RIP
      He and I were in the same Harvard class together, and spent a good deal of time talking economics together. We also were (briefly) bridge partners in a few games. I was a big fan of his book on Fischer Black. I am very s…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 12 total
  - (2026-10-13) CVE-2026-104935 · Ivanti Connect Secure: Ivanti Connect Secure Authentication Bypass by Spoofing Vulnerability
      vendor: Ivanti · product: Connect Secure · CISA remediation by 2026-10-16
  - (2026-10-13) CVE-2026-96951 · Microsoft Windows: Microsoft Windows Command Injection Vulnerability
      vendor: Microsoft · product: Windows · CISA remediation by 2026-10-16

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-14) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=26, 14d-median=26; carrying terms: order, model, proposing, final, public, national, regulatory, proposes, certain, action, period, safety
- state_bills: today=64, 7d-median=64, 14d-median=78; carrying terms: relating, education, alaska, school, providing, state, administration, effective, district, existing, appropriation, program
- state_news: today=726, 7d-median=667, 14d-median=682; carrying terms: economic, business, arkansas, washington, amendment, months, scheduled, residents, pennsylvania, funding, again, legislature
- local_news: today=243, 7d-median=223, 14d-median=224; carrying terms: residents, missouri, metro, arrested, magazine, years, public, struck, across, police, student, million
- foreign_news: today=1021, 7d-median=1018, 14d-median=1018; carrying terms: economic, washington, begins, residents, foreign, funding, seized, better, again, democratic, needs, urged
- chinese_internal: today=309, 7d-median=299, 14d-median=276; carrying terms: cbmib, cbmiaefvx, cbmiw, cbmizefvx, cbmiyefvx, cbmia, investors, cbmiykfvx, https, color, cbmibkfvx, cbmibefvx
- russian_internal: today=1123, 7d-median=1061, 14d-median=1058; carrying terms: politico, reuters, error, httperror, server, financial, forbidden, raquo, russian, laquo, europe, target
- ukrainian_internal: today=127, 7d-median=136, 14d-median=136; carrying terms: previous, washington, military, foreign, httperror, facility, financial, forbidden, ballistic, facilities, drone, warns
- ukraine_theater: today=364, 7d-median=494, 14d-median=532; carrying terms: zabhziqwr, ukziuq, mthpywjdqzlhv, nhvvaxc, loogzjadryzehgsgfsdfhcdghurxdemwyzukzly, mljqttvss, sdxawakc, cuxnyurjy, ckhnagpoq, mapserver, zrqjbptzd, bxfudexfwvfsamtrbc
- paper_bets: today=79, 7d-median=68, 14d-median=120; carrying terms: solved, season, successor, visit, republicans, colonize, december, least, human, mbappe, minister, koivun
- weather: today=150, 7d-median=150, 14d-median=146; carrying terms: bring, isolated, changed, washington, dangerous, weekend, marine, upper, updated, october, pontiac, severe
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: sheet, cpiaucsl, rates, commodities, dexuseu, dcoilwtico, labor, treasury, money, unemployment, jtsjol, unrate
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: yield, proxy, china, rates, commodities, bitcoin, silver, russell, treasury, nasdaq, range, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=107, 7d-median=111, 14d-median=113; carrying terms: guinea, unauthorised, order, compare, economic, recognition, acronym, beirut, greer, restrictive, management, operation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quantitative, error, https, quiverquant, quiver, httperror, client, unauthorized
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: county, corporation, appeals, state, supreme, company, court, warden, james, alabama, board, brown
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, financial, trust, filer, jpmorgan, chase, canada, royal, charles
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: johnson, pinkston, cortez, ossoff, warner, graham, cycle, sherrod, senate, receipts, cooper, trone
- gdelt_regions: today=0, 7d-median=2, 14d-median=2
- gdelt_gkg: today=0, 7d-median=37, 14d-median=37; carrying terms: romanian, themes, english, french, chinese, vietnamese, italian, spanish, perimeter, russian, russia, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=28, 7d-median=30, 14d-median=30; carrying terms: belgium, position, germany, france, kingdom, ground, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: report, hospital, guinea, chikv, generation, autochthonous, kinshasa, traceability, hygiene, continues, previous, separated
- cisa_kev: today=12, 7d-median=13, 14d-median=14; carrying terms: within, injection, bounds, citrix, improper, restriction, manager, buffer, vendor, cisco, encoding, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: panama, cyclone, guinea, china, speed, mexico, maximum, indonesia, hurricane, typhoon, simon, brazil
- usgs_quakes: today=17, 7d-median=21, 14d-median=17; carrying terms: depth, russia, philippines, region, papua, guinea, ridge, atlantic, chile, panama, kokopo, vilyuchinsk
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, champions, league, price, presidential, donetsk, volume, championship, october, shakhtar, brazilian, election
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: economist, revolution, marginal, class, https, conversable, spending, money, spend, public, economic, conve
- tech_news: today=58, 7d-median=60, 14d-median=58; carrying terms: models, computer, theft, group, software, download, engineering, cybersecurity, security, technica, weekly, infrastructure
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: timmons, economic, teresa, addison, white, greer, donalds, nathaniel, sewell, corporation, schiff, cantwell
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, market, decision, either, claude, placement, consensus, paper, unavailable, converges, placed, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-10-07] Fed press (events + announcements): Minutes of the Federal Open Market Committee, September 15-16, 2026
- [2026-10-08] ECB press: Piero Cipollone: Interview with Corriere della Sera
- [2026-10-08] Fed speeches: Waller, The Signaling Value of the Summary of Economic Projections
- [2026-10-08] ECB press: Meeting of 9-10 September 2026
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*