# WORLDSCOPE morning brief — 2026-06-08

## Headline
2783 new items across 24 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (627) · International News + Multilateral Institutions (622) · World leaders & government officials (324) · Chinese Internal News (224) · U.S. Weather + Severe / Climate Outlooks (194) · State-Level News (137) · Local News: St. Louis + Atlanta (127) · Ukraine Theater (total-war monitoring) (116) · State Legislative Action (77) · Ukrainian Internal News (national + local Kyiv) (54) · GDACS — global disaster alerts (45) · USGS earthquakes (M4.5+, past day) (45)

## What changed today
### Russian Internal News (state + in-exile) — 627 new of 831 total
  - (2026-06-08) В Севастополе ввели QR-коды для получения талонов на бензин. Их выдают только в «Максе». Они заканчиваются за секунды | LEDE: В Севастополе на сети заправок ТЭС ввели продажу топлива по QR-к] (ru: В С…
      В Севастополе на сети заправок ТЭС ввели продажу топлива по QR-кодам, объявил вечером 6 июня назначенный Россией губернатор Михаил Развожаев.
  - (2026-06-08) Михаила Ходорковского заочно приговорили к 10 годам колонии по делу о «фейках» про армию | LEDE: Мещанский районный суд Москвы заочно приговорил Михаила Ходорковского к 10 годам колонии по д] (ru: Мих…
      Мещанский районный суд Москвы заочно приговорил Михаила Ходорковского к 10 годам колонии по делу о «фейках» про российскую армию, сообщает «Медиазона». Ходорковскому также запретили в течение пяти лет администрировать са…
  - (2026-06-08) «Нарушения, махинации, беспрецедентное давление. Паралич избирательной системы». Как российская пропаганда рассказывает о выборах в Армении, которые выиграла партия Пашиняна | LEDE: Партия «] (ru: «На…
      Партия «Гражданский договор» премьер-министра Армении Никола Пашиняна одержала победу на парламентских выборах, которые прошли 7 июня. Она набрала 49,82% голосов. В новом составе парламента сторонники Пашиняна получат 61…
  - (2026-06-08) После убийства Хаменеи российские спецслужбы отключили систему наблюдения, созданную для охраны Путина. Израильская разведка смогла подготовить покушение на верховного лидера Ирана, взломав дор] (ru:…
      Российские спецслужбы после убийства верховного лидера Ирана Али Хаменеи на некоторое время отключали специальную систему наблюдения, обеспечивающую безопасность президента РФ Владимира Путина и других высших лиц государ…
  - (2026-06-08) На Филиппинах произошло землетрясение магнитудой 7,8 | LEDE: На острове Минданао на юге Филиппин произошло землетрясение магнитудой 7,8. Первый подземный толчок был зафиксирован в 07:37 по м] (ru: На…
      На острове Минданао на юге Филиппин произошло землетрясение магнитудой 7,8. Первый подземный толчок был зафиксирован в 07:37 по местному времени, за ним последовала серия афтершоков.
  - (2026-06-08) В Латвии впервые сбили залетевший в страну беспилотник | LEDE: Истребители сбили в Латвии беспилотник, залетевший в воздушное пространство страны. ] (ru: В Латвии впервые сбили залетевший в страну бес…
      Истребители сбили в Латвии беспилотник, залетевший в воздушное пространство страны.

### International News + Multilateral Institutions — 622 new of 836 total
  - (2026-06-08) [Global] At least 32 dead after major earthquake strikes southern Philippines
      The magnitude-7.8 quake triggered small tsunami waves in the Philippines, Indonesia and Japan.
  - (2026-06-08) [Global] Rare footage captured of Great White shark in Mediterranean Sea
      A volunteer diver has described shaking as he filmed his encounter with an endangered Great White shark between Tunisia and Sicily.
  - (2026-06-08) [Global] Armenia's pro-West government wins election despite Russian pressure
      Prime Minister Nikol Pashinyan's Civil Contract Party secures nearly 50% of the vote, comfortably beating the other contenders.
  - (2026-06-08) [Global] Knicks' long-awaited NBA run electrifies NYC, with Trump set to attend key game
      The Knicks' stunning winning streak has energised the city as the New York basketball team prepares for the third game of the finals series at its home arena.
  - (2026-06-07) [Global] Zelensky's close European allies set out five conditions for peace talks
      The Ukrainian president's meeting with his staunchest European allies came as US President Donald Trump's focus shifts to the war with Iran.
  - (2026-06-07) [Global] Trump abruptly ends NBC interview after clash over 'rigged election' claim
      During the interview, the president was repeatedly challenged on several points by the show's presenter Kristen Welker.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 224 new of 242 total
  - (2026-06-08) 高考前后五大典型诈骗话术全披露 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBKU0Z3c21wNWpYTXBFSG1DWm5fR283TzJtRmF4TjE5LUNEQ08zTDZXZ2FXVDNhV3ZoN25QMS1NcmJpWE9SaVl3WDhVMnI2Q0I3ZmJPVH] (zh:…
      高考前后五大典型诈骗话术全披露 财新
  - (2026-06-07) 财经早知道｜美股遇挫，AI行情怎么走 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1zQU5oMURmeEhnN296Q1FSOU1TcnJqZHFLa2lGbjlMclJwS0lJNUNJQVNyRHNEa3pyX1RJQ3FsWFNXdTZPRDdnMHo4N05VbExUem8] (zh:…
      财经早知道｜美股遇挫，AI行情怎么走 财新
  - (2026-06-07) 反腐记｜6月首周 黎晓宏、魏小东落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5TcXI1TWJJUDRFR2xXMjhsM19hU212bGYwcFFPUnRNbVBpZjB4Y0hMUGxrTFFidTg3MlltV3Bhc0lJM2d2cHpoZ] (zh:…
      反腐记｜6月首周 黎晓宏、魏小东落马 china.caixin.com
  - (2026-06-07) 5月中国央行“加仓”黄金32万盎司 外储升至3.44万亿美元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5KUUFONFFaWXZaRTBXRmI5NlBxMnBQYk9BZnRzT0x4TV8xSURoYnFrNlYxamZSVllkV296UFpOckZVeE1IaUZMc0N] (zh:…
      5月中国央行“加仓”黄金32万盎司 外储升至3.44万亿美元 财新
  - (2026-06-06) 视线｜NBA总决赛马刺主场两连败 特朗普可能现身尼克斯主场 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1QM3JFNWktTG9OVDczVlB0dHI4MkZPTEU0N0dzUkZ0bWxkSnEwYjI3eUczZ0p6WU9vbkktcm05R0ZaSVE2THczTnJa] (zh:…
      视线｜NBA总决赛马刺主场两连败 特朗普可能现身尼克斯主场 财新
  - (2026-06-07) 2026年全国高考报名人数持续下降 较去年减少45 万人 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9uaUVmNE9RRmxEWHRUMzh1c1VwSFBNWHYxZjFpLVRqTk9RUVZxek11bjlsWVF4TWM4SGVfOG1PZHBhalJEeV9LRnY0d] (zh:…
      2026年全国高考报名人数持续下降 较去年减少45 万人 财新

### U.S. Weather + Severe / Climate Outlooks — 194 new of 196 total
  - (2026-06-08) [Moderate] Special Weather Statement: Special Weather Statement issued June 8 at 6:50AM CDT by NWS Springfield MO
      At 650 AM CDT, Doppler radar was tracking a strong thunderstorm over Highlandville, moving east at 20 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limbs and…
  - (2026-06-08) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-08) [Moderate] Special Weather Statement: Special Weather Statement issued June 8 at 6:47AM CDT by NWS Springfield MO
      At 646 AM CDT, Doppler radar was tracking a strong thunderstorm over southeastern Springfield, moving east at 20 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree…
  - (2026-06-08) [Moderate] Special Weather Statement: Special Weather Statement issued June 8 at 6:47AM CDT by NWS Tulsa OK
      At 646 AM CDT, Doppler radar indicated strong thunderstorms along a line extending from near Gateway to 3 miles south of Pea Ridge to 2 miles northeast of Maysville. Movement was southeast at 30 mph. HAZARD...Wind gusts…
  - (2026-06-08) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 8 at 6:44AM CDT until June 8 at 7:00AM CDT by NWS Tulsa OK
      At 643 AM CDT, a severe thunderstorm was located over Honey Creek State Park, moving southeast at 45 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, siding, and trees. Location…
  - (2026-06-08) [Moderate] Special Weather Statement: Special Weather Statement issued June 8 at 6:42AM CDT by NWS North Platte NE
      At 641 AM CDT/541 AM MDT/, Doppler radar was tracking strong thunderstorms along a line extending from near Roscoe to near Grant. Movement was northeast at 25 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. S…

### State-Level News — 137 new of 227 total
  - (2026-06-08) [Connecticut] CT’s new training rules for homemaker companion workers: What to know
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2021/04/20200822_YK_1187CampbellAveWestHaven_068.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async…
  - (2026-06-08) [Connecticut] Erin Stewart and the sound of trust breaking
      <img width="600" height="450" src="https://ctmirror.org/wp-content/uploads/2026/06/Erin-Stewart.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="https://ctmirror.or…
  - (2026-06-08) [Connecticut] I fought unfair elections in the Middle East. Then I found them in CT
      <img width="915" height="559" src="https://ctmirror.org/wp-content/uploads/2026/06/3rd-district-dem-convention.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="laz…
  - (2026-06-08) [Connecticut] Medically complex children wait a lifetime on a waitlist
      <img width="1024" height="704" src="https://ctmirror.org/wp-content/uploads/2026/05/katie-Beckett-waiver-1024x704.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="…
  - (2026-06-08) [Delaware] New bill would give Delawareans vote on constitutional changes
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/01/IMG_3207-scaled.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=""…
  - (2026-06-08) [Delaware] Get Involved: General Assembly reconvenes, Sussex affordable housing, more
      <img width="1000" height="800" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/06/Get-Involved-Artwork-Template-1000x800-10.png?fit=1000%2C800&ssl=1" class="attachment-rss-image-size size-rss-image-s…

### Local News: St. Louis + Atlanta — 127 new of 179 total
  - (2026-06-08) [St. Louis] 73 Missouri land owners settle with feds over Rock Island Trail easements
      A group of 22 Missouri landowners got checks from the federal government last month—their long-fought compensation for what they alleged was the wrongful taking of their land. In accepting that settlement, they join anot…
  - (2026-06-07) [St. Louis] St. Louis restaurant openings, closings, and coming soons
      The following information is accurate as of an early-June press date. May is a traditionally robust month for restaurant openings in St. Louis, and so it was this year, with 22 openings and only five closings. Two restau…
  - (2026-06-07) [St. Louis] Lou’s Clues – 6/8/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-06-08) [St. Louis] Texas father gunned down while helping his son recover his truck after a carjacking
      Investigators said the stolen truck was equipped with a GPS tracker. After the truck was taken at gunpoint, the owner contacted his father for help.
  - (2026-06-08) [St. Louis] Deadly 5-car crash shuts down westbound I-70 in St. Louis
      Westbound lanes of I-70 were closed for hours after a crash early Monday morning involving several vehicles.
  - (2026-06-08) [St. Louis] North St. Louis shooting leaves man dead
      The victim died at the hospital, and one person was detained pending further investigation, police said.

### Ukraine Theater (total-war monitoring) — 116 new of 318 total
  - (2026-06-08) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-07) [FIRMS] thermal anomaly 46.858, 33.292 (FRP 2.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0952Z, FRP 2.97 MW
  - (2026-06-07) [FIRMS] thermal anomaly 51.704, 34.064 (FRP 4.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0954Z, FRP 4.71 MW
  - (2026-06-07) [FIRMS] thermal anomaly 51.708, 34.062 (FRP 7.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0954Z, FRP 7.93 MW
  - (2026-06-07) [FIRMS] thermal anomaly 51.842, 34.273 (FRP 7.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0954Z, FRP 7.69 MW
  - (2026-06-07) [FIRMS] thermal anomaly 51.854, 34.245 (FRP 3.54 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0954Z, FRP 3.54 MW

### State Legislative Action — 77 new of 126 total
  - (2026-06-07) [California ACR 215] Relative to Hypertension Awareness Month.
      This measure would recognize May 2026 as Hypertension Awareness Month.
  - (2026-06-07) [California SB 1387] State agencies: collection and reporting of demographic data: Jewish identity.
      Existing law declares that it is the policy of the state to afford all persons in public schools, regardless of specified characteristics, including race or ethnicity, equal rights and opportunities in the educational in…
  - (2026-06-07) [California ACR 214] Relative to Juneteenth.
      This measure would recognize June 19, 2026, as Juneteenth and would urge the people of California to join in celebrating Juneteenth as a day to honor and reflect on the significant role that African Americans have played…
  - (2026-06-07) [California SB 1296] Real property: rentals: pet policy.
      Existing law governs the obligations of tenants and landlords. Existing law prohibits a landlord who allows an animal on the premises from advertising or establishing rental policies in a manner that requires a tenant or…
  - (2026-06-07) [California ACR 212] Relative to Dairy Month.
      This measure would proclaim the month of June to be Dairy Month in California.
  - (2026-06-07) [California ACR 217] Relative to California BBQ Month.
      This measure would proclaim the month of June as California BBQ Month, as specified.

### Ukrainian Internal News (national + local Kyiv) — 54 new of 112 total
  - (2026-06-08) Що відбувається на Добропільському виступі – репортаж УП | LEDE: ] (uk: Що відбувається на Добропільському виступі – репортаж УП)
  - (2026-06-08) Росія втрачає Вірменію: як Кремлю не вдалося заблокувати рух Єревана на захід | LEDE: Драматичні парламентські вибори у Вірменії завершилися перемогою чинної партії влади і, відповідно, поразко] (uk:…
      Драматичні парламентські вибори у Вірменії завершилися перемогою чинної партії влади і, відповідно, поразкою Росії. Чи змириться з нею Кремль?
  - (2026-06-08) У Єврокомісії підтвердили, що 21-й пакет санкцій проти РФ буде готовий цього тижня | LEDE: Європейська комісія завершить роботу над новим, 21-м пакетом санкцій Євросоюзу проти Росії цього тижня] (uk:…
      Європейська комісія завершить роботу над новим, 21-м пакетом санкцій Євросоюзу проти Росії цього тижня та передасть його на затвердження у Раду ЄС.
  - (2026-06-08) У вівторок в Україні задощить, опади не вщухнуть до кінця тижня | LEDE: 9 червня в Україні очікуються дощі та грози, місцями тепла погода до +29°C. Наприкінці тижня стане прохолодніше.] (uk: У вівторо…
      9 червня в Україні очікуються дощі та грози, місцями тепла погода до +29°C. Наприкінці тижня стане прохолодніше.
  - (2026-06-08) ССО уразили стратегічний вузол нафтопроводів РФ за 500 км від кордону з Україною | LEDE: Сили спеціальних операцій у серії дронових ударів уразили вузол двох російських магістральних нафтопрово] (uk:…
      Сили спеціальних операцій у серії дронових ударів уразили вузол двох російських магістральних нафтопроводів в Волгоградській області РФ у ніч проти 8 червня.
  - (2026-06-08) Потужний землетрус на Філіппінах забрав життя 19 людей і викликав цунамі | LEDE: У понеділок на півдні Філіппін стався землетрус магнітудою 7,8, в результаті якого загинуло щонайменше 19 осіб, ] (uk:…
      У понеділок на півдні Філіппін стався землетрус магнітудою 7,8, в результаті якого загинуло щонайменше 19 осіб, понад 200 отримали поранення, переважно в пошкоджених будівлях, а на прибережні райони обрушилося цунамі вис…

### GDACS — global disaster alerts — 45 new of 128 total
  - (2026-06-07) [Orange] Earthquake in Philippines
      Earthquake · Orange alert · Philippines · Magnitude 7.8M, Depth:55.193km
  - (2026-06-07) [Orange] Earthquake in Philippines
      Earthquake · Orange alert · Philippines · Magnitude 7.8M, Depth:55.193km
  - (2026-05-28) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-05-28) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-05-28) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-07) [Green] Earthquake in Russia
      Earthquake · Green alert · Russia · Magnitude 5.5M, Depth:10km

### USGS earthquakes (M4.5+, past day) — 45 new of 45 total
  - (2026-06-07) M 7.8 - 26 km SW of Kablalan, Philippines
      M7.8 · 26 km SW of Kablalan, Philippines · depth 55.193 km · PAGER orange
  - (2026-06-08) M 6.5 - 19 km SW of Balangonan, Philippines
      M6.5 · 19 km SW of Balangonan, Philippines · depth 65.57 km
  - (2026-06-07) M 6.0 - 4 km ENE of Pangyan, Philippines
      M6.0 · 4 km ENE of Pangyan, Philippines · depth 35 km
  - (2026-06-07) M 6.0 - 16 km WSW of Balangonan, Philippines
      M6.0 · 16 km WSW of Balangonan, Philippines · depth 81.843 km
  - (2026-06-08) M 5.8 - 11 km SE of Sarangani, Philippines
      M5.8 · 11 km SE of Sarangani, Philippines · depth 52.541 km
  - (2026-06-07) M 5.8 - Easter Island region
      M5.8 · Easter Island region · depth 10 km

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-08) [Tepper Oren] Form 4 (Reporting)
      filed 2026-06-08 11:44 UTC · role: Reporting — Filed: 2026-06-08 AccNo: 0001976408-26-000555 Size: 4 KB
  - (2026-06-08) [Nayax Ltd.] Form 4 (Issuer)
      filed 2026-06-08 11:44 UTC · role: Issuer — Filed: 2026-06-08 AccNo: 0001976408-26-000555 Size: 4 KB
  - (2026-06-08) [Chan Chun Sing] Form 4 (Reporting)
      filed 2026-06-08 11:35 UTC · role: Reporting — Filed: 2026-06-08 AccNo: 0001493152-26-027629 Size: 14 KB
  - (2026-06-08) [Click Holdings Ltd.] Form 4 (Issuer)
      filed 2026-06-08 11:35 UTC · role: Issuer — Filed: 2026-06-08 AccNo: 0001493152-26-027629 Size: 14 KB
  - (2026-06-08) [Manor Sagit] Form 4 (Reporting)
      filed 2026-06-08 11:34 UTC · role: Reporting — Filed: 2026-06-08 AccNo: 0001976408-26-000554 Size: 4 KB
  - (2026-06-08) [Nayax Ltd.] Form 4 (Issuer)
      filed 2026-06-08 11:34 UTC · role: Issuer — Filed: 2026-06-08 AccNo: 0001976408-26-000554 Size: 4 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-08) [Nigeria] Nigeria : NYSC At 53 - Risks in National Service
      domain: allafrica.com · language: English · tone:
  - (2026-06-08) [United Kingdom] Outlander fans raise £10 , 115 for Culloden in honour of actor Sam Heughan
      domain: darlingtonandstocktontimes.co.uk · language: English · tone:
  - (2026-06-08) [United States] Israel and Iran trade fire as ceasefire falters
      domain: koat.com · language: English · tone:
  - (2026-06-08) [United States] Over A Dozen Killed As Magnitude 7 . 8 Quake Hits The Philippines
      domain: newsradio540.iheart.com · language: English · tone:
  - (2026-06-08) [Australia] Grilld chief executive Simon Crowe insists his staff come first
      domain: brisbanetimes.com.au · language: English · tone:
  - (2026-06-08) [United States] Israel and Iran Renew Direct Hostilities
      domain: time.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-06-08) [US tariff & trade dockets · themes] 碰壁的自由 ： TA们在外媒做中国新闻
      wenxuecity.com · Chinese · tone NA
  - (2026-06-08) [US tariff & trade dockets · themes] 台股早盤跌近2千7百點創紀錄 專家 ： 漲多修正 - 財經
      news.cts.com.tw · Chinese · tone NA
  - (2026-06-08) [US tariff & trade dockets · themes] Armenian PM Wins Vote , Cementing Westward Tilt
      themoscowtimes.com · English · tone NA
  - (2026-06-08) [US tariff & trade dockets · themes] 台股黑色星期一 房仲 ： 信用管制措施仍在難掀賣房潮 | 產經
      cna.com.tw · Chinese · tone NA
  - (2026-06-08) [US tariff & trade dockets · themes] Canada deregulation gamble will fall into a future legal trap
      theglobeandmail.com · English · tone NA
  - (2026-06-08) [US tariff & trade dockets · themes] China está pronta para trabalhar com a Coreia do Norte , diz Xi Jinping em visita a Kim Jong - Un
      g1.globo.com · Portuguese · tone NA

### Paper Trading Scorecard — 21 new of 139 total
  - (2026-06-08) [Polymarket] Will the Liberal Democratic Party of Russia (LDPR) win the most seats in the next Russian parliamentary election?
      Parliamentary elections are to be scheduled to be held in Russia in September 2026. This market will resolve according to the political party that wins the greatest number of seats in the next Russian State Duma election…
  - (2026-06-08) [Polymarket] Will Gustavo Petro be the next leader out before 2027?
      This market will resolve according to the first listed individual who ceases to occupy their listed office. An announcement of a resignation/removal, or a scheduled departure from office due to the outcome of an election…
  - (2026-06-08) [Polymarket] Will Lighter reach $10 before 2027?
      This market will immediately resolve to “Yes” if any Lighter 1-minute candle for Lighter (LIT/USDC) between December 30, 2025, 14:25 and December 31, 2026, 23:59 ET has a final “High” price equal to or greater than the p…
  - (2026-06-08) [Polymarket] Will Ethereum reach $2,500 in June?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for ETH/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…
  - (2026-06-08) [Polymarket] Will the Iranian regime survive U.S. military strikes?
      This market will resolve to "Yes" if both of the following conditions are met by June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". 1. The US initiates a military action on Iranian soil, airspace, o…
  - (2026-06-08) [Manifold] Will WWE wrestler Danhausen appear as part of the official celebrations if the New York Knicks win the NBA Championship

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-06-08) Iran closes its airspace by June 8?
      yes price: 100% · 24h volume: $8,244,231 · resolves 2026-06-08
  - (2026-06-08) Will Colombia win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $4,254,976 · resolves 2026-07-20
  - (2026-06-08) Will Keiko Fujimori win the 2026 Peruvian presidential election?
      yes price: 78% · 24h volume: $3,212,521 · resolves 2026-06-07
  - (2026-06-08) US x Iran permanent peace deal by June 15, 2026?
      yes price: 4% · 24h volume: $2,951,922 · resolves 2026-06-15
  - (2026-06-08) Will Roberto Sánchez Palomino win the 2026 Peruvian presidential election?
      yes price: 21% · 24h volume: $2,858,556 · resolves 2026-06-07
  - (2026-06-08) Will Uruguay win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,635,505 · resolves 2026-07-20

### Court opinions of consequence (federal & state) — 6 new of 60 total
  - (2026-06-03) U.S. Court of Appeals, 3rd Cir.: Secretary United States Department of Labor v. Comprehensive Healthcare Management Services LLC
  - (2026-06-03) U.S. Court of Appeals, 7th Cir.: United States v. Maurice Whitesides
  - (2026-06-02) U.S. Supreme Court: Allen v. Milligan
  - (2026-06-02) U.S. Court of Appeals, Federal Cir.: Agi Suretrack LLC v. Farmers Edge Inc.
  - (2026-06-02) Connecticut Supreme Court: Wilmington Savings Fund Society, FSB v. Schulz
  - (2026-06-02) U.S. Court of Appeals, 8th Cir.: Christopher Bonham v. Frank Bisignano

### World News (by country, top stories) — 6 new of 6 total
  - (2026-06-08) [Ukraine] Ukraine receives seventh financing tranche from EU – Svyrydenko
      en.interfax.com.ua · English
  - (2026-06-08) [Ukraine] Ukraine , despite war , fulfills its duties as candidate country for EU membership – Kos
      en.interfax.com.ua · English
  - (2026-06-08) [Ukraine] Russian strike damages IAEA office near Chornobyl – prosecutors
      en.interfax.com.ua · English
  - (2026-06-08) [Ukraine] No timeline for Chornobyl nuclear waste site restart after Russian strikes – IAEA
      en.interfax.com.ua · English
  - (2026-06-08) [Ukraine] Over year we stabilized front , completely eliminated all enemy infiltration areas in zone from Borova to Lyman – 3rd AC
      en.interfax.com.ua · English
  - (2026-06-08) [Ukraine] We must keep European interests in mind - Kallas on E3 - Ukraine statement
      en.interfax.com.ua · English

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-06-08) [Marginal Revolution] Hayekian Literary Criticism
      In economics, Marx is relegated to the history of thought as his ideas were an economic dead end and a political disaster. Yet Marx-influenced literary criticism is a dominant mode of analysis in nearly every English dep…
  - (2026-06-08) [Marginal Revolution] New paper on the iPhone and fertility
      The U.S. general fertility rate has fallen by 22% since 2007, a sustained decline not readily explained by economic conditions, contraceptive use, housing or childcare costs, or other commonly cited factors. We assess th…
  - (2026-06-08) [Marginal Revolution] Might AI hurt corporate profits? (from my email)
      From Clifford Sosin: I loved your talk about AI and wanted to bounce an idea off you. I think AI may be bad for corporate profit margins. A lot of companies make money because their customers can’t be bothered to monitor…

### Government Action: Sanctions + Procurement + Foreign Agents — 2 new of 111 total
  - (2026-06-04) [FARA] Office of Privacy and Civil Liberties | DOJ Privacy Impact Assessments - Department of Justice (.gov)
      Office of Privacy and Civil Liberties | DOJ Privacy Impact Assessments Department of Justice (.gov)
  - (2026-06-08) [USASpending] $619,151,273 → HII MISSION TECHNOLOGIES CORP: THE PURPOSE OF THIS TO IS TO PROVIDE TECHNOLOGY INTEGRATED S
      Agency: General Services Administration. Description: THE PURPOSE OF THIS TO IS TO PROVIDE TECHNOLOGY INTEGRATED SERVICES TO NSIN AND ITS MISSION PARTNERS FOR THE PURPOSE OF COUNTERING AND DETERRING CURRENT AND EMERGING…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-08) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=8, 7d-median=24, 14d-median=28; carrying terms: public, coast, certain, authorized, guard, provide, vessels, address, persons, proposed, captain, safety
- state_bills: today=126, 7d-median=141, 14d-median=141; carrying terms: management, various, arizona, information, administration, impact, among, includes, health, existing, authorizes, person
- state_news: today=227, 7d-median=651, 14d-median=695; carrying terms: nearly, management, increase, received, arizona, administration, columbia, wisconsin, southern, reading, midterm, calling
- local_news: today=179, 7d-median=227, 14d-median=237; carrying terms: soccer, health, morning, dining, target, victim, stlmag, death, police, times, louis, major
- foreign_news: today=836, 7d-median=847, 14d-median=860; carrying terms: opposition, scratched, lived, pagoda, meets, xinhuanet, topical, whittled, nigeria, brings, includes, speech
- chinese_internal: today=242, 7d-median=270, 14d-median=270; carrying terms: target, lxtfb, cbmickfvx, cbmiakfvx, politics, articles, color, cbmiyefvx, cbmibkfvx, lxtfa, caixin, cbmizkfvx
- russian_internal: today=831, 7d-median=1014, 14d-median=1014; carrying terms: gazeta, client, financial, novayagazeta, novaya, roland, title, forbidden, found, reuters, httperror, axios
- ukrainian_internal: today=112, 7d-median=121, 14d-median=122; carrying terms: president, forbidden, ukrinform, httperror, kyivindependent, censor, hromadske, ukraine, found, economic, hmarochos, forum
- ukraine_theater: today=318, 7d-median=318, 14d-median=318; carrying terms: afbvv, contacts, hvymd, jaefjwfjozmzrv, tghtd, vdknldmfwegfhnu, history, kenya, xzvfqnmrlskrit, lonkg, shyzuvztugu, qlhvmtlfwndhsthanjr
- paper_bets: today=139, 7d-median=144, 14d-median=141; carrying terms: hampshire, special, source, arizona, virginia, predictit, wisconsin, midterm, includes, presidential, limits, colorado
- weather: today=196, 7d-median=150, 14d-median=126; carrying terms: indicated, result, sunday, storms, please, flood, urban, runoff, afdbox, afdokx, discussion, morning
- macro: today=21, 7d-median=21, 14d-median=10; carrying terms: labor, unrate, funds, treasury, rates, recession, latest, spread, indicator, unemployment, effective, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, nasdaq, commodities, large, crypto, credit, corporate, agriculture, yield, crude, futures, natural
- markets_global: today=47, 7d-median=65, 14d-median=79; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=111, 14d-median=108; carrying terms: comments, acronym, management, serious, bissau, illegal, counter, cbmiqkfvx, administration, launch, abuses, compare
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, quiver, error, https, client, quiverquant, unauthorized, quantitative, congresstrading
- billionaires: today=36, 7d-median=40, 14d-median=40; carrying terms: larry, alice, microsoft, googl, steve, peterffy, japan, source, retail, infrastructure, tiktok, family
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=30, 14d-median=30
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, collins, robert, court, state, supreme, connecticut, alaska, company, appeals, jonathan, society
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, david, holdings, financial, jpmorgan, chase, filer, trust, subject
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: receipts, booker, graham, ossoff, michael, robert, jonathan, warner, cortez, ocasio, disbursements, senate
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=25, 7d-median=75, 14d-median=12; carrying terms: china, english, themes, chinese, spanish, finance, french, trade, france, spokesperson, house, economic
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: israel, canada, language, english, domain, india, announces, killed, nigeria, death, kingdom, pakistan
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=26; carrying terms: position, ground, belgium, bulgaria, france, kingdom, canada, germany, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: decades, nearly, operator, international, syndrome, response, result, diarrhoea, blood, discharged, challenge, particularly
- cisa_kev: today=10, 7d-median=11, 14d-median=15; carrying terms: overflow, product, vendor, bypass, remediation, vulnerability, authentication, cpanel, privilege, litespeed, daemon, unspecified
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=128, 7d-median=127, 14d-median=127; carrying terms: speed, poland, depth, vietnam, estonia, pakistan, flood, czech, china, angola, serbia, lithuania
- usgs_quakes: today=45, 7d-median=17, 14d-median=17; carrying terms: depth, indonesia, islands, japan, russia, philippines, region
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, world, peace, permanent, turkiye, presidential, meeting, switzerland, mexico, croatia
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: class, revolution, conversable, https, marginal, economist, policy, marginalrevolution, economy, economic, along, economics
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: burlison, darin, schmidt, bryan, jamieson, obernolte, mcmahon, perez, trump, jahana, hakeem, carbajal
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, paper, evidence, module, placement, markets, claude, sufficient, today, market, converges, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline
- [2026-06-06] Fed speeches: Barr, Deregulating in a Financial Boom: What Could Go Wrong?
- [2026-06-08] ECB press: ECB announces main milestones for roll-out of Integrated Reporting Framework

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*