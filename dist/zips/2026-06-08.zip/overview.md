# WORLDSCOPE morning brief — 2026-06-08

## Headline
2477 new items across 24 active section(s) (of 41 tracked).

## Top movers today
International News + Multilateral Institutions (562) · Russian Internal News (state + in-exile) (533) · World leaders & government officials (324) · Chinese Internal News (224) · U.S. Weather + Severe / Climate Outlooks (196) · Ukraine Theater (total-war monitoring) (108) · State-Level News (83) · Local News: St. Louis + Atlanta (75) · Ukrainian Internal News (national + local Kyiv) (46) · GDELT GKG — themes / entities / watch areas (44) · USGS earthquakes (M4.5+, past day) (44) · State Legislative Action (41)

## What changed today
### International News + Multilateral Institutions — 562 new of 800 total
  - (2026-06-08) [Global] Armenia PM Pashinyan's ruling party wins landslide election victory
  - (2026-06-08) [Global] French Open: Zverev defeats Cobolli to win first Grand Slam title
      ⁠Germany's Alexander Zverev has won the French Open final against Flavio Cobolli, and with it his first Grand Slam title.
  - (2026-06-08) [Global] Major quake off Philippines kills at least 19, triggers tsunami warnings
      A powerful 7.8-magnitude earthquake rocked the southern Philippines on Monday, killing at least 19 people, toppling buildings and prompting tsunami warnings across parts of Southeast Asia and the Pacific, as authorities…
  - (2026-06-08) [Global] Israeli army strikes targets in cities throughout western and central Iran
  - (2026-06-08) [Global] Prime Minister Albin Kurti's party wins Kosovo vote but falls short of majority
      Kosovo Prime Minister Albin Kurti's party emerged as the largest force in Sunday's snap election but failed to secure enough support to govern alone, setting the stage for difficult coalition negotiations. The vote, mark…
  - (2026-06-08) [Global] Middle East war live: Israel and Iran trade air strikes, massive blast heard in Tehran
      Israel and Iran traded strikes early Israel on Monday in retaliatory attacks that threatened to drag the Middle East back into a regional war. As the hostilities pursued, a massive blast rocked central Tehran, followed b…

### Russian Internal News (state + in-exile) — 533 new of 742 total
  - (2026-06-08) На Филиппинах произошло землетрясение магнитудой 7,8 | LEDE: На острове Минданао на юге Филиппин произошло землетрясение магнитудой 7,8. Первый подземный толчок был зафиксирован в 07:37 по м] (ru: На…
      На острове Минданао на юге Филиппин произошло землетрясение магнитудой 7,8. Первый подземный толчок был зафиксирован в 07:37 по местному времени, за ним последовала серия афтершоков.
  - (2026-06-08) В Латвии впервые сбили залетевший в страну беспилотник | LEDE: Истребители сбили в Латвии беспилотник, залетевший в воздушное пространство страны. ] (ru: В Латвии впервые сбили залетевший в страну бес…
      Истребители сбили в Латвии беспилотник, залетевший в воздушное пространство страны.
  - (2026-06-08) В США произошла стрельба недалеко от тренировочной базы сборной Англии на чемпионате мира по футболу | LEDE: В городе Канзас-Сити (штат Миссури) произошла стрельба недалеко от базы, где во в] (ru: В С…
      В городе Канзас-Сити (штат Миссури) произошла стрельба недалеко от базы, где во время чемпионата мира по футболу будет тренироваться сборная Англия. Об этом сообщает The Athletic.
  - (2026-06-08) В Новороссийске в результате удара дронов начался пожар на нефтеналивном комплексе | LEDE: Украинские беспилотники в ночь на 8 июня нанесли удар по нефтеналивному комплексу в Новороссийске. ] (ru: В Н…
      Украинские беспилотники в ночь на 8 июня нанесли удар по нефтеналивному комплексу в Новороссийске. На территории комплекса «Шесхарис» в результате атаки дронов начался пожар.
  - (2026-06-08) Зеленский подтвердил, что на встречу с ним в Киев приезжал Абрамович | LEDE: Президент Украины Владимир Зеленский заявил, что российским бизнесменом, который приезжал в Киев на встречу с ним] (ru: Зел…
      Президент Украины Владимир Зеленский заявил, что российским бизнесменом, который приезжал в Киев на встречу с ним, был Роман Абрамович. Об этом он рассказал в интервью Sky News.
  - (2026-06-08) Иран обстрелял север Израиля. ЦАХАЛ ответил ударами по иранским объектам | LEDE: Иран вечером 7 июня выпустил несколько ракет в сторону Израиля. В заявлениях Корпуса стражей исламском револю] (ru: Ира…
      Иран вечером 7 июня выпустил несколько ракет в сторону Израиля. В заявлениях Корпуса стражей исламском революции (КСИР), которое опубликовал Tasnim, говорится, что это стало ответом на удары Израиля по Бейруту.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 224 new of 244 total
  - (2026-06-08) 今天参加高考的话，我能语文及格吗 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5qOGw1VWlVV3ZFc1dOdy1vc2d0MVg0VmxFRnlnSE9zUHZCeXhZYnBKVXB6UUw0YTN6YmYwMUQ0bnN3TzhlRklkVGEyeHlwVjJkUEVBZ] (zh:…
      今天参加高考的话，我能语文及格吗 风闻
  - (2026-06-08) 清华毕业买不起房，读书到底还有什么用？来听听他的回答 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1VZTEyRkJ3Rjh5eVl1YWZJZGRSOE9JampvWnNTQ2gwdlc1VFFBUlpDbE1JOUxxRW1tWDFMSURLTGd2Z1Q0WXhPV0ZfSk1] (zh:…
      清华毕业买不起房，读书到底还有什么用？来听听他的回答 风闻
  - (2026-06-08) 如何正视英国？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE83OURVTkpLZVBNb3FhbXh2dDk1SDdaX09LdmlwVEY5aDVGbXdBTW9VT3BnYmdfRkFNM1JjaXJxUHVJY2xjS3BMR212UWhMTjlxM0ptdElMWE5MW] (zh:…
      如何正视英国？ 观察者
  - (2026-06-08) 习近平抵达平壤开始对朝鲜进行国事访问-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE83N093VHM0dF9VNXZwUWVkZURrUURlT0c4NHpCRmtRR1hjTTIyb0lqaERla2FXcFhzQ3hBNmt4ZzlkclhfTkFzc21QSV80c] (zh:…
      习近平抵达平壤开始对朝鲜进行国事访问-观察者网 观察者
  - (2026-06-08) 强烈推荐！19岁小伙子制作的三战系列视频 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE9MaXhkdW9OTTFhbzd1UUtBNWFDM0RhWkpkNjRlM2FYMmcxN19KQkRfWkRHOUlMZkR2MHNRajI1XzdFRGNoc2VxU0ptOUR0ZWdVc] (zh:…
      强烈推荐！19岁小伙子制作的三战系列视频 风闻
  - (2026-06-08) AI开始接管Junior Analyst的工作了？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5FME5Sa0ZhY181and5TXFoa2ZGVHNpZzdScUdTQmVYaXdnTVNpZEdBYURRaEFsQUs3VWdGMW94WEZXOG9xd3d4cWxmeEJZ] (zh:…
      AI开始接管Junior Analyst的工作了？ 风闻

### U.S. Weather + Severe / Climate Outlooks — 196 new of 198 total
  - (2026-06-08) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-08) [Severe] Flood Warning: Flood Warning issued June 8 at 4:15AM CDT until June 9 at 9:49AM CDT by NWS Huntsville AL
      ...Forecast flooding changed from Moderate to Major severity for the following rivers in Alabama... Flint River at Brownsboro affecting Madison County. * WHAT...Major flooding is occurring and major flooding is forecast.…
  - (2026-06-08) [Extreme] Tornado Warning: Tornado Warning issued June 8 at 4:15AM CDT until June 8 at 5:00AM CDT by NWS Springfield MO
      TORSGF The National Weather Service in Springfield has issued a * Tornado Warning for... Northwestern Newton County in southwestern Missouri... * Until 500 AM CDT. * At 415 AM CDT, a severe thunderstorm capable of produc…
  - (2026-06-08) [Moderate] Gale Watch: Gale Watch issued June 8 at 2:06AM PDT until June 9 at 11:00PM PDT by NWS Seattle WA
      * WHAT...West winds 25 to 30 kt, with gusts up to 40 kt possible. * WHERE...Central U. S. Waters Strait Of Juan De Fuca and East Entrance U. S. Waters Strait Of Juan De Fuca. * WHEN...From Tuesday morning through Tuesday…
  - (2026-06-08) [Severe] Flash Flood Warning: Flash Flood Warning issued June 8 at 4:05AM CDT until June 8 at 8:15AM CDT by NWS Springfield MO
      At 405 AM CDT, Doppler radar indicated thunderstorms producing heavy rain across the warned area. Between 3 and 7 inches of rain have fallen. Flash flooding is ongoing or expected to begin shortly. HAZARD...Life threaten…
  - (2026-06-08) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 8 at 3:00AM MDT until June 8 at 3:30AM MDT by NWS North Platte NE
      At 259 AM MDT, a severe thunderstorm was located near Grant, moving east at 20 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hail damage to vehicles is expected. Expect wind da…

### Ukraine Theater (total-war monitoring) — 108 new of 318 total
  - (2026-06-07) [FIRMS] thermal anomaly 46.858, 33.292 (FRP 2.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0952Z, FRP 2.97 MW
  - (2026-06-07) [FIRMS] thermal anomaly 51.704, 34.064 (FRP 4.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0954Z, FRP 4.71 MW
  - (2026-06-07) [FIRMS] thermal anomaly 51.708, 34.062 (FRP 7.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0954Z, FRP 7.93 MW
  - (2026-06-07) [FIRMS] thermal anomaly 51.842, 34.273 (FRP 7.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0954Z, FRP 7.69 MW
  - (2026-06-07) [FIRMS] thermal anomaly 51.854, 34.245 (FRP 3.54 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 0954Z, FRP 3.54 MW
  - (2026-06-07) [FIRMS] thermal anomaly 44.608, 22.732 (FRP 1.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-07 1132Z, FRP 1.55 MW

### State-Level News — 83 new of 175 total
  - (2026-06-08) [Connecticut] Erin Stewart and the sound of trust breaking
      <img width="600" height="450" src="https://ctmirror.org/wp-content/uploads/2026/06/Erin-Stewart.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="high" srcset…
  - (2026-06-08) [Connecticut] I fought unfair elections in the Middle East. Then I found them in CT
      <img width="915" height="559" src="https://ctmirror.org/wp-content/uploads/2026/06/3rd-district-dem-convention.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" srcset="http…
  - (2026-06-08) [Connecticut] Medically complex children wait a lifetime on a waitlist
      <img width="1024" height="704" src="https://ctmirror.org/wp-content/uploads/2026/05/katie-Beckett-waiver-1024x704.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="…
  - (2026-06-07) [Colorado] Farm animal welfare rules might be rolled back by Congress
      Congress is looking to roll back state animal welfare laws as it wrangles over reauthorization of the federal farm bill. The farm bill, which Congress generally reworks every five years, includes money and federal rules…
  - (2026-06-07) [Arkansas] Arkansas’ LGBTQ+ community needs to be supported, not counter-programmed
      Arkansas Gov. Sarah Huckabee Sanders’ proclamation declaring June “Fidelity Month” appeared innocuous enough at first glance. For most people there’s little to argue with the idea of encouraging residents to “reflect on…
  - (2026-06-08) [Florida] Black midwives are suing Southern states, claiming regulations make it harder to help patients
      Black midwives in the South, a region rife with racial disparities in maternal health access and maternal mortality, are leading lawsuits over state regulations that they say limit their ability to provide care. Women be…

### Local News: St. Louis + Atlanta — 75 new of 139 total
  - (2026-06-07) [St. Louis] St. Louis restaurant openings, closings, and coming soons
      The following information is accurate as of an early-June press date. May is a traditionally robust month for restaurant openings in St. Louis, and so it was this year, with 21 openings and only five closings. Two restau…
  - (2026-06-07) [St. Louis] Lou’s Clues – 6/8/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-06-08) [St. Louis] Basements flooded after water main break leaves trail of damage in University City
      Floodwater rushed into basements after a major water main break, damaging homes and triggering a boil advisory for 12,000 customers in three St. Louis County cities.
  - (2026-06-08) [St. Louis] A million miles of kindness: Ladue School District bus driver retires after 27 years
      Students at Spoede Elementary School gave Carolyn Taylor a hero’s farewell as the beloved bus driver retired after 27 years and more than a million miles.
  - (2026-06-08) [St. Louis] Apple TV becomes fastest streamer to achieve 'studio EGOT' status
      Apple TV has quickly achieved the unofficial "studio EGOT" status after "Schmigadoon!" secured a Tony award Sunday night.
  - (2026-06-08) [St. Louis] Israel says it has struck Iran after taking missile fire
      Israel's recent airstrikes on central and western Iran escalate tensions in the Middle East, following missile fire from Tehran and stalling U.S.-Iran ceasefire talk

### Ukrainian Internal News (national + local Kyiv) — 46 new of 106 total
  - (2026-06-08) ДБР та СБУ затримали бойового медика, який продавав списані безпілотники | LEDE: Військового затримано під час продажу дронів військової частини, оформлених як втрачені. Йому загрожує покарання] (uk:…
      Військового затримано під час продажу дронів військової частини, оформлених як втрачені. Йому загрожує покарання за ч. 4 ст. 410 ККУ.
  - (2026-06-08) У Молдові кажуть, що на територію країни "з великою ймовірністю" залетів український дрон | LEDE: Молдова заявила, що дрон, ймовірно, український, але відповідальність за інцидент несе Росія, я] (uk:…
      Молдова заявила, що дрон, ймовірно, український, але відповідальність за інцидент несе Росія, яка розв'язала війну.
  - (2026-06-08) Каллас: Дискусії про розблокування Угорщиною 6,6 млрд євро за підтримку України тривають | LEDE: ] (uk: Каллас: Дискусії про розблокування Угорщиною 6,6 млрд євро за підтримку України )
  - (2026-06-08) Сили оборони уразили одне найбільших сховищ нафтопродуктів РФ на Кавказі | LEDE: Оператори 1-го окремого центру Сил безпілотних систем у взаємодії із Силами спецоперацій та іншими складовими Си] (uk:…
      Оператори 1-го окремого центру Сил безпілотних систем у взаємодії із Силами спецоперацій та іншими складовими Сил оборони уразили перевалочну нафтобазу "Грушовая" у місті Новоросійськ Краснодарського краю РФ в ніч на 8 ч…
  - (2026-06-08) У травні ЗСУ звільнили майже на 100 кв. км більше, ніж втратили – Сирський | LEDE: Сирський: ЗСУ у травні звільнили майже 100 км², з початку року понад 600 км² української землі.] (uk: У травні ЗСУ зв…
      Сирський: ЗСУ у травні звільнили майже 100 км², з початку року понад 600 км² української землі.
  - (2026-06-08) Винищувачі НАТО збили дрон, що вторгся в повітряний простір Латвії | LEDE: Вранці 8 червня винищувачі союзників Латвії по НАТО збили дрон у повітряному просторі країни.] (uk: Винищувачі НАТО збили дро…
      Вранці 8 червня винищувачі союзників Латвії по НАТО збили дрон у повітряному просторі країни.

### GDELT GKG — themes / entities / watch areas — 44 new of 44 total
  - (2026-06-08) [Russia oil sanctions perimeter · themes] Im not afraid of anything at this age : Elderly jaywalkers risk their lives for convenience
      asiaone.com · English · tone NA
  - (2026-06-08) [Russia oil sanctions perimeter · themes] 愛心醫生教您10種輕鬆防止中暑的方法
      n.yam.com · Chinese · tone NA
  - (2026-06-08) [Russia oil sanctions perimeter · themes] Il prezzo del petrolio torna a salire dopo gli attacchi israeliani contro Iran e Libano
      money.it · Italian · tone NA
  - (2026-06-08) [Russia oil sanctions perimeter · themes] Iran fires ballistic missiles toward Bahrain , Kuwait , tests ceasefire
      sierraleonetimes.com · English · tone NA
  - (2026-06-08) [Russia oil sanctions perimeter · themes] A 7 . 8 magnitude quake in the Philippines kills at least 16
      kuaf.com · English · tone NA
  - (2026-06-08) [Russia oil sanctions perimeter · themes] Профицит госбюджета Азербайджана за 5 месяцев достиг почти 3 млрд манатов
      1news.az · Russian · tone NA

### USGS earthquakes (M4.5+, past day) — 44 new of 44 total
  - (2026-06-07) M 7.8 - 26 km SW of Kablalan, Philippines
      M7.8 · 26 km SW of Kablalan, Philippines · depth 55.193 km · PAGER orange
  - (2026-06-08) M 6.5 - 19 km SW of Balangonan, Philippines
      M6.5 · 19 km SW of Balangonan, Philippines · depth 65.57 km
  - (2026-06-07) M 6.1 - 124 km SE of Severo-Kuril’sk, Russia
      M6.1 · 124 km SE of Severo-Kuril’sk, Russia · depth 35 km
  - (2026-06-07) M 6.0 - 4 km ENE of Pangyan, Philippines
      M6.0 · 4 km ENE of Pangyan, Philippines · depth 35 km
  - (2026-06-07) M 6.0 - 16 km WSW of Balangonan, Philippines
      M6.0 · 16 km WSW of Balangonan, Philippines · depth 81.843 km
  - (2026-06-08) M 5.8 - 11 km SE of Sarangani, Philippines
      M5.8 · 11 km SE of Sarangani, Philippines · depth 52.541 km

### State Legislative Action — 41 new of 90 total
  - (2026-06-07) [California ACR 215] Relative to Hypertension Awareness Month.
      This measure would recognize May 2026 as Hypertension Awareness Month.
  - (2026-06-07) [California SB 1387] State agencies: collection and reporting of demographic data: Jewish identity.
      Existing law declares that it is the policy of the state to afford all persons in public schools, regardless of specified characteristics, including race or ethnicity, equal rights and opportunities in the educational in…
  - (2026-06-07) [California ACR 214] Relative to Juneteenth.
      This measure would recognize June 19, 2026, as Juneteenth and would urge the people of California to join in celebrating Juneteenth as a day to honor and reflect on the significant role that African Americans have played…
  - (2026-06-07) [California SB 1296] Real property: rentals: pet policy.
      Existing law governs the obligations of tenants and landlords. Existing law prohibits a landlord who allows an animal on the premises from advertising or establishing rental policies in a manner that requires a tenant or…
  - (2026-06-07) [California ACR 212] Relative to Dairy Month.
      This measure would proclaim the month of June to be Dairy Month in California.
  - (2026-06-07) [California ACR 217] Relative to California BBQ Month.
      This measure would proclaim the month of June as California BBQ Month, as specified.

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-08) [Singapore] Im not afraid of anything at this age : Elderly jaywalkers risk their lives for convenience
      domain: asiaone.com · language: English · tone:
  - (2026-06-08) [United States] Automatic Pill Dispensing System Market : Enhancing Medication Management
      domain: briefingwire.com · language: English · tone:
  - (2026-06-08) [Nigeria] Atiku Hails Rescue of 360 Borno Captives
      domain: punchng.com · language: English · tone:
  - (2026-06-08) [Ghana] From planting to protecting : The real test of tree for life
      domain: ghanaiantimes.com.gh · language: English · tone:
  - (2026-06-08) [Sierra Leone] Iran fires ballistic missiles toward Bahrain , Kuwait , tests ceasefire
      domain: sierraleonetimes.com · language: English · tone:
  - (2026-06-08) [United States] A 7 . 8 magnitude quake in the Philippines kills at least 16
      domain: kuaf.com · language: English · tone:

### GDACS — global disaster alerts — 39 new of 122 total
  - (2026-06-07) [Orange] Earthquake in Philippines
      Earthquake · Orange alert · Philippines · Magnitude 7.8M, Depth:55.193km
  - (2026-06-07) [Orange] Earthquake in Philippines
      Earthquake · Orange alert · Philippines · Magnitude 7.8M, Depth:55.193km
  - (2026-05-28) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-05-28) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-05-28) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-07) [Green] Earthquake in Russia
      Earthquake · Green alert · Russia · Magnitude 5.5M, Depth:10km

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-06-08) JAF4KN (Bulgaria)
      icao24: 4520ce · position: (47.9097, 2.0203) · alt: 6522m · 722km/h
  - (2026-06-08) SAMU49 (France)
      icao24: 39ca81 · position: (47.3289, -0.1928) · alt: 350m · 227km/h
  - (2026-06-08) PUMA84 (Slovenia)
      icao24: 506e18 · position: (46.1926, 15.1135) · alt: 1493m · 175km/h
  - (2026-06-08) PUMA37 (Slovenia)
      icao24: 506e1d · position: (45.7175, 14.8037) · alt: 1889m · 219km/h
  - (2026-06-08) GAF890 (Germany)
      icao24: 3f97fd · position: (55.2105, -1.5018) · alt: 10355m · 926km/h
  - (2026-06-08) CFC2952 (Canada)
      icao24: c2b585 · position: (48.3576, 17.7493) · alt: 7848m · 464km/h

### Paper Trading Scorecard — 22 new of 140 total
  - (2026-06-08) [Polymarket] Will Julian Alvarez be the top goalscorer at the 2026 FIFA World Cup?
      This market will resolve to the player who scores the most goals through all main tournament rounds of the 2026 FIFA World Cup competition. In the event of a tie, this market will resolve according to the official leader…
  - (2026-06-08) [Polymarket] Will the Liberal Democratic Party of Russia (LDPR) win the most seats in the next Russian parliamentary election?
      Parliamentary elections are to be scheduled to be held in Russia in September 2026. This market will resolve according to the political party that wins the greatest number of seats in the next Russian State Duma election…
  - (2026-06-08) [Polymarket] Will Gustavo Petro be the next leader out before 2027?
      This market will resolve according to the first listed individual who ceases to occupy their listed office. An announcement of a resignation/removal, or a scheduled departure from office due to the outcome of an election…
  - (2026-06-08) [Polymarket] Will the Iranian regime survive U.S. military strikes?
      This market will resolve to "Yes" if both of the following conditions are met by June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". 1. The US initiates a military action on Iranian soil, airspace, o…
  - (2026-06-08) [Polymarket] Will Mohammed bin Salman win the Nobel Peace Prize in 2026?
      This market will resolve according to the winner of the 2026 Nobel Peace Prize, as announced by the Norwegian Nobel Committee. If multiple listed individuals or entities jointly receive the prize, the market will resolve…
  - (2026-06-08) [Polymarket] Will Leo Zacky win the California Governor Election in 2026?
      This market will resolve to according to the candidate who wins the 2026 California gubernatorial election currently scheduled for November 3, 2026. If the results of the election are not confirmed by July 31, 2027, this…

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-06-08) Iran closes its airspace by June 8?
      yes price: 100% · 24h volume: $7,912,816 · resolves 2026-06-08
  - (2026-06-08) Will Colombia win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $3,747,675 · resolves 2026-07-20
  - (2026-06-08) Will Keiko Fujimori win the 2026 Peruvian presidential election?
      yes price: 82% · 24h volume: $3,052,392 · resolves 2026-06-07
  - (2026-06-08) US x Iran permanent peace deal by June 15, 2026?
      yes price: 4% · 24h volume: $2,668,148 · resolves 2026-06-15
  - (2026-06-08) Will Roberto Sánchez Palomino win the 2026 Peruvian presidential election?
      yes price: 18% · 24h volume: $2,630,147 · resolves 2026-06-07
  - (2026-06-08) Israel closes its airspace by June 15?
      yes price: 56% · 24h volume: $2,316,992 · resolves 2026-06-15

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-06-03) U.S. Court of Appeals, 3rd Cir.: Secretary United States Department of Labor v. Comprehensive Healthcare Management Services LLC
  - (2026-06-03) U.S. Court of Appeals, 7th Cir.: United States v. Maurice Whitesides
  - (2026-06-02) U.S. Court of Appeals, 8th Cir.: Christopher Bonham v. Frank Bisignano
  - (2026-06-02) U.S. Court of Appeals, 8th Cir.: United States v. Jayden Debevec
  - (2026-06-02) U.S. Court of Appeals, 8th Cir.: United States v. Terrell Simpson
  - (2026-06-02) U.S. Supreme Court: Allen v. Milligan

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] COMMITTEE TO ELECT SHAWN PINKSTON
      cycle 2014 · filing #948970 · receipts $0.02M
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-06-08) [Marginal Revolution] Might AI hurt corporate profits? (from my email)
      From Clifford Sosin: I loved your talk about AI and wanted to bounce an idea off you. I think AI may be bad for corporate profit margins. A lot of companies make money because their customers can’t be bothered to monitor…
  - (2026-06-07) [Marginal Revolution] Sunday assorted links
      1. The Hyman Rickover corpus. 2. Redux of a 2009 essay by me on poverty and a documentary film. 3. Shruti on AI and copyright law. 4. Will the number of lawyers go up or down? 5. One view on where Somalia stands right no…
  - (2026-06-07) [Marginal Revolution] How High-Skill Immigration Restrictions Eroded Regional Productivity: Evidence from the 2017 BAHA Executive Order
      This paper estimates the regional economic impact of high-skill immigration restrictions by analyzing the 2017 “Buy American, Hire American” (BAHA) policy as a quasi-experimental policy shock. By significantly tightening…

### Government Action: Sanctions + Procurement + Foreign Agents — 2 new of 111 total
  - (2026-06-04) [FARA] Office of Privacy and Civil Liberties | DOJ Privacy Impact Assessments - Department of Justice (.gov)
      Office of Privacy and Civil Liberties | DOJ Privacy Impact Assessments Department of Justice (.gov)
  - (2026-06-08) [USASpending] $619,151,273 → HII MISSION TECHNOLOGIES CORP: THE PURPOSE OF THIS TO IS TO PROVIDE TECHNOLOGY INTEGRATED S
      Agency: General Services Administration. Description: THE PURPOSE OF THIS TO IS TO PROVIDE TECHNOLOGY INTEGRATED SERVICES TO NSIN AND ITS MISSION PARTNERS FOR THE PURPOSE OF COUNTERING AND DETERRING CURRENT AND EMERGING…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 40 total
  - (2026-06-08) MOVER ▼ Larry Page — $300.34B ($-0.17B since yesterday)
      United States · Technology · source: Google
  - (2026-06-08) MOVER ▼ Sergey Brin — $277.01B ($-0.16B since yesterday)
      United States · Technology · source: Google

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-08) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=8, 7d-median=24, 14d-median=28; carrying terms: action, public, personnel, coast, address, safety, vessels, captain, waters, provide, guard, persons
- state_bills: today=90, 7d-median=141, 14d-median=141; carrying terms: statewide, income, impact, criminal, removal, medical, until, rights, provided, procedures, private, collaborative
- state_news: today=175, 7d-median=651, 14d-median=695; carrying terms: sports, improve, nonprofit, thumbnail, plans, statewide, think, error, raising, income, already, losing
- local_news: today=139, 7d-median=227, 14d-median=237; carrying terms: plans, magazine, final, times, weekend, officer, accused, soccer, white, major, local, georgia
- foreign_news: today=800, 7d-median=847, 14d-median=860; carrying terms: reform, plans, anger, ecological, casualties, bureau, portals, usually, search, players, cooperation, impact
- chinese_internal: today=244, 7d-median=270, 14d-median=270; carrying terms: cbmidefvx, cbmix, title, cbmizefvx, cbmickfvx, cbmiw, cbmizkfvx, cbmib, cbmiykfvx, people, lxtfb, politics
- russian_internal: today=742, 7d-median=1014, 14d-median=1014; carrying terms: novayagazeta, found, telegram, centcom, garros, roland, title, error, financial, forbidden, reuters, europe
- ukrainian_internal: today=106, 7d-median=121, 14d-median=122; carrying terms: error, title, vechirniy, independent, ukrinform, found, kyivindependent, babel, censor, hromadske, president, hmarochos
- ukraine_theater: today=318, 7d-median=318, 14d-median=318; carrying terms: nfvgfpt, cvfbvupamep, pbrgd, mzbdlxmzvjvhb, evwxiwgc, procured, eddknkvvutvgdevzywozzfr, armor, zylpod, cuxoqnfnunjotkxec, netymnjfrwphatu, ltjauzzcc
- paper_bets: today=140, 7d-median=144, 14d-median=141; carrying terms: includes, pennsylvania, nomination, manifold, official, country, winner, restricting, season, president, republican, governor
- weather: today=198, 7d-median=150, 14d-median=126; carrying terms: changed, upper, houston, short, afdmtr, twoat, monitoring, damage, until, cause, hazardous, details
- macro: today=21, 7d-median=21, 14d-median=10; carrying terms: rates, spread, unrate, unemployment, recession, labor, treasury, effective, indicator, latest, funds, sheet
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, agriculture, rates, crypto, natural, commodities, proxy, bitcoin, futures, treasury, russell, crude
- markets_global: today=47, 7d-median=65, 14d-median=79; carrying terms: crypto, price
- sanctions_procurement: today=111, 7d-median=111, 14d-median=108; carrying terms: administration, libya, public, cyber, sevastopol, belarus, drilling, region, authorities, economic, counter, weapons
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, quiver, congresstrading, https, client, quiverquant, quantitative, error, unauthorized
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: tokyo, spacex, technology, oracle, francoise, infrastructure, warren, michael, france, retail, tadashi, adani
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=30, 14d-median=30
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, collins, robert, court, company, state, connecticut, alaska, appeals, supreme, jonathan, people
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, issuer, accno, david, holdings, michael, american, scott, finance, steven, thomas
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, raised, robert, angels, graham, joseph, michael, ocasio, alexandria, johnson, lindsey, senate
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=44, 7d-median=75, 14d-median=22; carrying terms: spanish, russian, israel, english, themes, chinese, ukraine, ceasefire, finance, russia, perimeter, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: canada, israel, domain, language, english, india, nigeria, kingdom, woman, death, killed, trump
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=26; carrying terms: ground, position, belgium, bulgaria, kingdom, france, germany, canada, eagle
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: young, border, infant, viral, uganda, jerusalem, majority, pacific, contaminated, toxin, france, arabia
- cisa_kev: today=10, 7d-median=11, 14d-median=15; carrying terms: overflow, vendor, authentication, remediation, vulnerability, bypass, product, console, escalation, cpanel, embedded, privilege
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=122, 7d-median=124, 14d-median=124; carrying terms: cyclone, malaysia, sweden, agricultural, turkmenistan, denmark, alert, tajikistan, estonia, lithuania, madagascar, russia
- usgs_quakes: today=44, 7d-median=17, 14d-median=17; carrying terms: depth, indonesia, islands, japan, russia, region, philippines
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, world, price, volume, peace, permanent, south, korea, turkiye, morocco, meeting, presidential
- commentary: today=5, 7d-median=5, 14d-median=6; carrying terms: conversable, revolution, class, economist, https, marginal, assorted, links, policy, marginalrevolution, economy, economic
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: francisco, administration, jeanne, emanuel, aderholt, jamie, goodlander, curtis, cynthia, chicago, womack, burchett
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, placed, evidence, converges, identify, decision, consensus, either, market, unavailable, sufficient, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI
- [2026-06-03] ECB press: Piero Cipollone: Europe’s money evolves so people’s freedom to pay remains
- [2026-06-04] ECB press: Christine Lagarde: Women and leadership: widening the pipeline
- [2026-06-06] Fed speeches: Barr, Deregulating in a Financial Boom: What Could Go Wrong?
- [2026-06-08] ECB press: ECB announces main milestones for roll-out of Integrated Reporting Framework

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*