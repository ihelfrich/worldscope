# WORLDSCOPE morning brief — 2026-08-05

## Headline
3558 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (762) · Russian Internal News (state + in-exile) (729) · State-Level News (399) · Ukraine Theater (total-war monitoring) (370) · World leaders & government officials (324) · Chinese Internal News (209) · Local News: St. Louis + Atlanta (207) · U.S. Weather + Severe / Climate Outlooks (134) · Ukrainian Internal News (national + local Kyiv) (59) · GDELT GKG — themes / entities / watch areas (50) · IT, InfoSys & cybersecurity news (last 7 days) (44) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 762 new of 1041 total
  - (2026-08-05) [Global] Russian attacks kill 17, exploiting Ukraine’s lack of missile interceptors
      Ukrainian President Volodymyr Zelenskyy says Russian forces used 29 missiles and 115 drones during the assault.
  - (2026-08-05) [Global] Toppled Bangladesh leader Sheikh Hasina to speak today: What we can expect
      Former Bangladeshi prime minister is likely to announce her return from exile in India despite facing the death penalty.
  - (2026-08-05) [Global] Michigan, Missouri, Washington primary elections: Key takeaways
      Recent US primaries have revealed Democratic Party rift between progressives and centrists over US support for Israel.
  - (2026-08-05) [Global] Trump hails progress but warned Iran of ‘hard hit’ if no deal reached
      US President Donald Trump says progress with Iran has been made, but warned Iran of 'hard hit' if no deal reached.
  - (2026-08-05) [Global] Cape Verde’s World Cup hero, social media sensation Vozinha joins Colo-Colo
      Vozinha says he always believed he was a 'big club' player after his move to Colo-Colo in Chile.
  - (2026-08-05) [Global] Inside the Air India Phuket-Delhi flight that dropped 300 feet mid-air
      Seventeen people were injured when an Air India flight from Phuket to Delhi encountered severe turbulence.

### Russian Internal News (state + in-exile) — 729 new of 1134 total
  - (2026-08-05) Война . 1624-й день. Россия атаковала Киевскую область. Под ударами — маркетплейсы и логистические центры. Погибли почти 20 человек. ПВО Украины не смогла сбить ни одну ракету | LEDE: «Медуз] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-08-05) При взрыве в ресторане Balzi Rossi погиб зять главкома ВКС Александра Чайко | LEDE: Даниил Передрий, зять главкома ВКС Александра Чайко, погиб в результате взрыва в итальянском ресторане Bal] (ru: При…
      Даниил Передрий, зять главкома ВКС Александра Чайко, погиб в результате взрыва в итальянском ресторане Balzi Rossi в Москве 1 августа. Его смерть подтверждается утечками из двух государственных баз, пишет «Агентство».
  - (2026-08-05) Бывшего московского муниципального депутата Кетеван Хараидзе приговорили к четырем годам по делу о мошенничестве. Ее освободили от наказания в зале суда | LEDE: Тверской районный суд Москвы ] (ru: Быв…
      Тверской районный суд Москвы приговорил бывшего московского муниципального депутата Кетеван Хараидзе к четырем годам колонии по делу о мошенничестве, сообщает телеграм-канал «Осторожно, новости».
  - (2026-08-05) Bloomberg: в Вене прошла встреча бывших чиновников из Европы и России. Кто представлял Москву, неизвестно | LEDE: Бывшие высокопоставленные чиновники из Великобритании, Франции, Германии и Р] (ru: Blo…
      Бывшие высокопоставленные чиновники из Великобритании, Франции, Германии и России провели в июле встречу в Вене, чтобы изучить возможные условия для мирных переговоров между Москвой и Киевом, пишет Bloomberg со ссылкой н…
  - (2026-08-05) В США сотрудники иммиграционной службы задержали россиянку, запросившую убежище | LEDE: В США сотрудники иммиграционной и таможенной службы (ICE) задержали 59-летнюю россиянку Алевтину Собол] (ru: В С…
      В США сотрудники иммиграционной и таможенной службы (ICE) задержали 59-летнюю россиянку Алевтину Соболеву, уехавшую после начала войны в 2022 году и подавшую прошение об убежище.
  - (2026-08-05) В Киевской области в результате российского удара разрушен крупнейший склад украинского маркетплейса Rozetka | LEDE: В Киевской области в результате российской ракетной атаки разрушен крупне] (ru: В К…
      В Киевской области в результате российской ракетной атаки разрушен крупнейший склад украинского маркетплейса Rozetka, рассказала соосновательница компании Ирина Чечеткина.

### State-Level News — 399 new of 775 total
  - (2026-08-05) [California] Governor Newsom secures federal assistance to support response to Gann Fire in Calaveras County
      Source
  - (2026-08-05) [California] Governor Newsom announces appointments 8.4.2026
      Source
  - (2026-08-04) [California] El Gobernador Newsom invita al presidente Trump a entregar los fondos pendientes para la recuperación por los incendios durante su visita a Los Ángeles
      Source
  - (2026-08-04) [California] Governor Newsom invites President Trump to deliver overdue wildfire recovery funding during Los Angeles visit
      Source
  - (2026-08-04) [California] Governor Newsom announced the deployment of additional firefighting resources and specialized personnel to Washington and Oregon
      Source
  - (2026-08-05) [California] California judge holds Homeland Security in contempt in case over LA immigration sweeps
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/062025-Bell-Immigration-Raid-GETTY-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…

### Ukraine Theater (total-war monitoring) — 370 new of 434 total
  - (2026-08-05) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2026-08-04) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap
  - (2016-04-27) [Liveuamap] Israel-Palestine - Liveuamap
      Israel-Palestine Liveuamap
  - (2016-04-27) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap
  - (2016-05-01) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - iraq.liveuamap.com
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com iraq.liveuamap.com

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 209 new of 281 total
  - (2026-08-04) 被宽屏淘汰的4:3，怎么就成了年轻人的“梦核”？｜热点 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE0tb0NvZlNjZmRJMGYwUXE5dUJYcldkWWEwanZEYXl3R1FmUHJsQ1JmX053Sm9RbEE1S1dveEV5U25LY1lGVkF1RVJ3Ql] (zh:…
      被宽屏淘汰的4:3，怎么就成了年轻人的“梦核”？｜热点 财新
  - (2026-08-04) 瑞银宋宇：政策基调转向加大力度保增长 力度、时点尚待明确 - economy.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBQbU9MOEM3RkVJVGFFUGVBVzhadEF0M25jQk1WbEtCNWZwS0NsdUVRZko3TFJuaGw4WWJ6M005d] (zh:…
      瑞银宋宇：政策基调转向加大力度保增长 力度、时点尚待明确 economy.caixin.com
  - (2026-08-04) 从香港、霍尔木兹到人工智能：毁公器者不若成人之美 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9pU2tya1llV3VNWU53ZDN6aFZONlFBSGZ2LVRzSWtwc3RGREh1dmNoTElvcXZoVXgxb0pXaGN0Tkd1bFJRYnB1ckhEcWtMU] (zh:…
      从香港、霍尔木兹到人工智能：毁公器者不若成人之美 财新
  - (2026-08-04) 如何解读上半年经济数据 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE14S3RlZE9TVGRJWjdKa2pTRWYwaTBQVGd6Nk5CUDFJQWRXRU40NzdPdlIwQXN3MER5NFN5QjBXZUpWdklPT3RxZGVJTzJKblhUTUdkeGx0Yl] (zh:…
      如何解读上半年经济数据 财新
  - (2026-08-04) 美欧经济：从分化到收敛 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9yZ284aTF2SnVNR2ZXdnFkOTRfd3ZXd1JHS2t4Nk1ycjkzbnZaamJTSk1OajRKSVM5Q3N0TDlEV3gzVkxZWlRkTVFrWVlXa184QzZQMkFEdm] (zh:…
      美欧经济：从分化到收敛 财新
  - (2026-08-04) 最值钱的三个字，如何拯救AI产业万亿市值 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE42T2tvNFpvcnhoMDJFVjJfS29DNVgyaUJMR2ZpVm9tcjJ5a3licHo0QjZNSXpNOUsxZVBhZC1yYng3d08weXZvUTF2Rndad1NlZ] (zh:…
      最值钱的三个字，如何拯救AI产业万亿市值 财新

### Local News: St. Louis + Atlanta — 207 new of 239 total
  - (2026-08-05) [St. Louis] Zimmerman wins Democratic primary for St. Louis County executive
      County assessor Jake Zimmerman notched a decisive victory in the Democratic primary for St. Louis County executive yesterday, besting state Senator Brian Williams (D–University City), 46 to 33 percent. State senator Ange…
  - (2026-08-05) [St. Louis] GOP-backed amendments 4 and 5 go down to defeat in Missouri
      Missouri voters rejected two key measures backed by Republican lawmakers on Tuesday’s ballot—one, Amendment 4, that would have made it more difficult for citizens to change the state constitution, and another, Amendment…
  - (2026-08-05) [St. Louis] Bell handily wins Democratic primary, beating back former U.S. Rep. Cori Bush in rematch
      The results were in before U.S. Rep. Wesley Bell’s election night watch party could even get into swing. When the Associated Press called the race for Bell over former Congresswoman Cori Bush around 8 p.m., people were s…
  - (2026-08-04) [St. Louis] Where in Chesterfield 8/5/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-08-04) [St. Louis] ‘Simpsons’ writer Bill Oakley brings regional food dinner to The Blue Duck in Maplewood
      Fans of The Simpsons, curious eaters, and regulars at The Blue Duck (2661 Sutton) will have reason to converge on September 1, when the restaurant hosts a seven-course dinner celebrating America’s regional food tradition…
  - (2026-08-04) [St. Louis] Sur Lie, from the owners of Little Fox, opening next month in Fox Park
      A second concept from Little Fox owners Craig and Mowgli Rivard is slated to open this September in Fox Park. Located directly across the street from Little Fox, Sur Lie (2805 Shenandoah) is a wine-focused bistro and bot…

### U.S. Weather + Severe / Climate Outlooks — 134 new of 146 total
  - (2026-08-05) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-05) [Severe] Fire Weather Watch: Fire Weather Watch issued August 5 at 3:34AM MDT until August 6 at 8:00PM MDT by NWS Glasgow MT
      * AFFECTED AREA...Fire weather zones 120, 122, 134, 135, 136, and 137. * WIND...Northwest at 15 to 25 mph with gusts to 35 mph. * HUMIDITY...As low as 10 percent south of the Missouri River, and as low as 20 percent near…
  - (2026-08-05) [Severe] Red Flag Warning: Red Flag Warning issued August 5 at 3:30AM MDT until August 5 at 8:00PM MDT by NWS Grand Junction CO
      * AFFECTED AREA...In Colorado, Fire Weather Zone 205 Colorado River Headwaters and Fire Weather Zone 293 Gunnison Basin Forecast Area. * TIMING...From 1 PM this afternoon to 8 PM MDT this evening. * WINDS...West 10 to 20…
  - (2026-08-05) [Severe] Flood Watch: Flood Watch issued August 5 at 5:15AM EDT until August 5 at 11:00AM EDT by NWS Baltimore MD/Washington DC
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of DC, including the following , District of Columbia, Maryland, including the following areas, Central and Southeast Mont…
  - (2026-08-05) [Moderate] Heat Advisory: Heat Advisory issued August 5 at 3:22AM CDT until August 5 at 8:00PM CDT by NWS Tulsa OK
      * WHAT...Heat index values up to 106 expected. * WHERE...Portions of northwest and west central Arkansas and east central, northeast, and southeast Oklahoma. * WHEN...From noon today to 8 PM CDT this evening. * IMPACTS..…
  - (2026-08-05) [Severe] Flash Flood Warning: Flash Flood Warning issued August 5 at 3:20AM CDT until August 5 at 6:15AM CDT by NWS Dodge City KS
      FFWDDC The National Weather Service in Dodge City has issued a * Flash Flood Warning for... Southwestern Lane County in west central Kansas... Southern Scott County in west central Kansas... * Until 615 AM CDT. * At 320…

### Ukrainian Internal News (national + local Kyiv) — 59 new of 106 total
  - (2026-08-05) Мерія Вільнюса не прийматиме звернення російською мовою | LEDE: Вільнюська міська рада більше не прийматиме письмові заяви та скарги мешканців російською мовою.] (uk: Мерія Вільнюса не прийматиме звер…
      Вільнюська міська рада більше не прийматиме письмові заяви та скарги мешканців російською мовою.
  - (2026-08-05) Експосадовці з Європи та РФ непублічно зустрілись для обговорення припинення війни в Україні – ЗМІ | LEDE: Колишні чиновники ЄС і РФ таємно обговорили можливі умови мирних переговорів щодо Укра] (uk:…
      Колишні чиновники ЄС і РФ таємно обговорили можливі умови мирних переговорів щодо України у Відні.
  - (2026-08-05) Понад третина українців допускають вибори до повного завершення війни – КМІС | LEDE: 38% українців підтримують проведення виборів до повного завершення війни: 15% вважають, що голосування має в] (uk:…
      38% українців підтримують проведення виборів до повного завершення війни: 15% вважають, що голосування має відбутися ще до припинення бойових дій, а 23% – після припинення вогню та отримання гарантій безпеки, але до укла…
  - (2026-08-05) В Україні з дводенним візитом перебуває очільниця МЗС Латвії | LEDE: Міністерка закордонних справ Латвії Байба Браже перебуває в Україні з дводенним візитом.] (uk: В Україні з дводенним візитом перебу…
      Міністерка закордонних справ Латвії Байба Браже перебуває в Україні з дводенним візитом.
  - (2026-08-05) Зеленський після удару РФ закликав партнерів активніше допомагати з перехоплювачами | LEDE: Президент Володимир Зеленський на тлі масованої російської атаки закликав партнерів активніше допомаг] (uk:…
      Президент Володимир Зеленський на тлі масованої російської атаки закликав партнерів активніше допомагати з ракетами-перехоплювачами до систем ППО.
  - (2026-08-05) Довіра до Зеленського майже не змінилась, незважаючи на протести – КМІС | LEDE: За даними опитування, довіра до президента Володимира Зеленського серед українців на початок серпня, порівняно з ] (uk:…
      За даними опитування, довіра до президента Володимира Зеленського серед українців на початок серпня, порівняно з квітнем, знизилась з 58% до 55%.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-05) [Russia oil sanctions perimeter · themes] The Manufacturers Life Insurance Company Sells 12 , 559 Shares of ITT Inc . $ITT
      dailypolitical.com · English · tone NA
  - (2026-08-05) [Russia oil sanctions perimeter · themes] Gli Houthi rivendicano un attacco contro una petroliera saudita nel nord del Mar Rosso
      zazoom.it · Italian · tone NA
  - (2026-08-05) [Russia oil sanctions perimeter · themes] Borsa güne yükselişle başladı - 5 Ağustos 2026
      sozcu.com.tr · Turkish · tone NA
  - (2026-08-05) [Russia oil sanctions perimeter · themes] Çanakkale Boğazı geçişinde 119 metrelik HAVVA ANAda baca yangını
      haberport.com · Turkish · tone NA
  - (2026-08-05) [Russia oil sanctions perimeter · themes] 习近平经济思想指引中国经济高质量发展行稳致远 - 南海网
      hinews.cn · Chinese · tone NA
  - (2026-08-05) [Russia oil sanctions perimeter · themes] محافظ الغربية يتابع أعمال رصف طريق سنباط حتى كوبري ميت النور
      dostor.org · Arabic · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 57 total
  - (2026-08-05) [The Hacker News] Claude Mythos 5 Tried to Backdoor a Real Open-Source Project in Testing, Then Vouched for Itself
      An agent running Anthropic's Claude Mythos 5 spent 34 hours trying to get a malware dropper merged into a real open-source project during a cyber evaluation by the UK's AI Security Institute. When a bystander publicly wa…
  - (2026-08-05) [The Hacker News] CISA Flags Langflow RCE, Tomcat, and N-central Flaws as Actively Exploited
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA), on August 5, 2026, added three flaws to its Known Exploited Vulnerabilities (KEV) catalog, citing evidence of active exploitation in the wild. The list of…
  - (2026-08-05) [The Hacker News] QuickFox Supply Chain Attack Delivers FDMTP Backdoor via Trojanized Windows Installer
      Cybersecurity researchers have disclosed what has been described as a "long-standing supply chain attack" on QuickFox, a virtual private network (VPN) and network acceleration tool designed for overseas Chinese users. Ac…
  - (2026-08-05) [Schneier on Security] Vulnerabilities in Car Anti-Theft Device
      This is disturbing: …a team of security researchers at UC San Diego, who found that a model of aftermarket car alarm known as the KARR Security System, installed in more than 2 million vehicles across the US by their est…
  - (2026-08-05) [The Register] Double trouble for Microsoft as pre-owned software licenses claims converge
      Tribunal to explore how £270 million reseller case intersects with multibillion-pound class action
  - (2026-08-05) [The Register] New Boeing finally gets going, 15 years after debut
      The 737-7 is the smallest of its type, yet it has the longest range

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-05) [Straub Philip] Form 4 (Reporting)
      filed 2026-08-05 01:55 UTC · role: Reporting — Filed: 2026-08-04 AccNo: 0001193125-26-333541 Size: 4 KB
  - (2026-08-05) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-08-05 01:55 UTC · role: Issuer — Filed: 2026-08-04 AccNo: 0001193125-26-333541 Size: 4 KB
  - (2026-08-05) [KAO MIN H] Form 4 (Reporting)
      filed 2026-08-05 01:55 UTC · role: Reporting — Filed: 2026-08-04 AccNo: 0001193125-26-333540 Size: 5 KB
  - (2026-08-05) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-08-05 01:55 UTC · role: Issuer — Filed: 2026-08-04 AccNo: 0001193125-26-333540 Size: 5 KB
  - (2026-08-05) [van Houte Hans] Form 4 (Reporting)
      filed 2026-08-05 01:41 UTC · role: Reporting — Filed: 2026-08-04 AccNo: 0001817217-26-000012 Size: 7 KB
  - (2026-08-05) [Nurix Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-08-05 01:41 UTC · role: Issuer — Filed: 2026-08-04 AccNo: 0001817217-26-000012 Size: 7 KB

### GDACS — global disaster alerts — 37 new of 265 total
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-08-05) [Green] Eruption Fuego
      Volcano · Green alert · Guatemala
  - (2026-08-05) [Green] Eruption Fuego
      Volcano · Green alert · Guatemala
  - (2026-08-05) [Green] Eruption Fuego
      Volcano · Green alert · Guatemala

### Court opinions of consequence (federal & state) — 32 new of 60 total
  - (2026-08-04) U.S. Court of Appeals, 9th Cir.: Vip Products, LLC v. Jack Daniel's Properties, Inc.
  - (2026-08-04) U.S. Court of Appeals, 9th Cir.: amazon.com Services, LLC v. Perplexity Ai, Inc.
  - (2026-08-04) U.S. Court of Appeals, 9th Cir.: Federal Trade Commission v. Hoskins
  - (2026-08-04) U.S. Court of Appeals, 8th Cir.: EEOC v. Sun Chemical Corporation
  - (2026-08-04) U.S. Court of Appeals, 8th Cir.: FA ND Chev, LLC v. BAPTKO, Inc.
  - (2026-08-04) U.S. Court of Appeals, 8th Cir.: United States v. Lance Brunsting

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 25 new of 30 total
  - (2026-08-05) PUMA52 (Slovenia)
      icao24: 506e1c · position: (46.1039, 14.3952) · alt: 883m · 172km/h
  - (2026-08-05) SAMU06 (France)
      icao24: 39c901 · position: (45.6339, 5.0452) · alt: 464m · 218km/h
  - (2026-08-05) CNA14 (Spain)
      icao24: 34650e · position: (27.9873, -14.7567) · alt: 853m · 225km/h
  - (2026-08-05) JAF1DY (Belgium)
      icao24: 44d1a6 · position: (36.8157, 10.2506) · alt: 5463m · 664km/h
  - (2026-08-05) JAF66L (Belgium)
      icao24: 44d1a5 · position: (51.0123, 4.7698) · alt: 1402m · 385km/h
  - (2026-08-05) JAF9WL (Belgium)
      icao24: 44d1b3 · position: (50.8297, 3.0584) · alt: 3649m · 722km/h

### U.S. Federal Action — 22 new of 22 total
  - (2026-08-05) Continuation of the National Emergency With Respect to the Advancement by Countries of Concern in Sensitive Technologies and Products Critical for the Military, Intelligence, Surveillance, or Cyber-En…
  - (2026-08-05) To Facilitate Positive Adjustment to Competition From Imports of Quartz Surface Products
  - (2026-08-05) Improving Emergency Medical Kit Efficacy and Flexibility in Commercial Airline Operations
      FAA proposes to eliminate the prescriptive list of required items in emergency medical kits and first aid kits and replace it with a performance-based requirement to ensure contents are practical and sufficient to allow…
  - (2026-08-05) Micro-Tracers, Inc.; Response to Objections and Requests for a Public Hearing
      The Food and Drug Administration (FDA or we) received objections and requests for a public hearing submitted by Buchanan Ingersoll & Rooney PC, on behalf of Micro-Tracers, Inc. (Micro-Tracers or objector), on the order g…
  - (2026-08-05) Amendment of United States Area Navigation Route Q-10 and Revocation of Alaska Area Navigation Routes J-804R and J-889R in Alaska
      This action amends United States Area Navigation (RNAV) Route Q-10 and revokes Alaska RNAV Routes J-804R and J-889R in Alaska. These actions are part of a large and comprehensive airway modernization project for the stat…
  - (2026-08-05) Fisheries of the Caribbean, Gulf of America, and South Atlantic; Reef Fish Fishery in the Gulf of America; 2026 Commercial Closure for Greater Amberjack
      NMFS is closing the 2026 commercial fishing season for greater amberjack in the Gulf of America (Gulf). Federal regulations require NMFS to close commercial harvest for greater amberjack if landings reach the commercial…

### USGS earthquakes (M4.5+, past day) — 20 new of 20 total
  - (2026-08-05) M 6.3 - south of the Kermadec Islands
      M6.3 · south of the Kermadec Islands · depth 226.084 km
  - (2026-08-05) M 6.3 - 32 km SW of Sarangani, Philippines
      M6.3 · 32 km SW of Sarangani, Philippines · depth 10 km
  - (2026-08-04) M 5.7 - 127 km NW of Ternate, Indonesia
      M5.7 · 127 km NW of Ternate, Indonesia · depth 35 km
  - (2026-08-05) M 5.2 - Auckland Islands, New Zealand region
      M5.2 · Auckland Islands, New Zealand region · depth 21.906 km
  - (2026-08-05) M 5.2 - 31 km S of Sarangani, Philippines
      M5.2 · 31 km S of Sarangani, Philippines · depth 35 km
  - (2026-08-05) M 5.1 - 46 km SSW of Sarangani, Philippines
      M5.1 · 46 km SSW of Sarangani, Philippines · depth 29.831 km

### Paper Trading Scorecard — 17 new of 133 total
  - (2026-08-05) [Polymarket] SHEIN IPO before 2027?
      This market will resolve to "Yes" if the listed company completes an Initial Public Offering (IPO) by December 31, 2026, 11:59 PM ET, as confirmed by official company announcements or credible news sources. The IPO refer…
  - (2026-08-05) [Manifold] Will a humanoid robot beat a ranked top #10 tennis player by EOY 2027?
  - (2026-08-05) [Manifold] Daily Coinflip
  - (2026-08-05) [Manifold] "Spider-Man: Brand New Day" 2nd Weekend Box Office >= 150M
  - (2026-08-05) [Manifold] "Spider-Man: Brand New Day" 2nd Weekend Box Office >= 130M
  - (2026-08-05) [Manifold] Will Drift0r's medical problem be found before 2027?

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-05) Will Abdul El-Sayed win the 2026 Michigan Democratic Primary?
      yes price: 100% · 24h volume: $1,506,894 · resolves 2026-08-04
  - (2026-08-05) Dota 2: 1win vs BetBoom Team (BO3) - 1win Essence Playoffs
      yes price: 42% · 24h volume: $1,416,975 · resolves 2026-08-05
  - (2026-08-05) LoL: HANJIN BRION vs Nongshim Red Force - Game 1 Winner
      yes price: 100% · 24h volume: $1,250,592 · resolves 2026-08-05
  - (2026-08-05) Will Berhanu Nega be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $935,631 · resolves 2026-06-01
  - (2026-08-05) LoL: HANJIN BRION vs Nongshim Red Force - Game 2 Winner
      yes price: 0% · 24h volume: $833,452 · resolves 2026-08-05
  - (2026-08-05) Will Haley Stevens win the 2026 Michigan Democratic Primary?
      yes price: 0% · 24h volume: $830,854 · resolves 2026-08-04

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-08-05) #27 Masayoshi Son — $72.36B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-08-05) MOVER ▲ Elon Musk — $783.28B (+$57.34B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-05) MOVER ▲ Michael Dell — $252.77B (+$16.04B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-05) MOVER ▼ Jeff Bezos — $283.22B ($-5.82B since yesterday)
      United States · Technology · source: Amazon
  - (2026-08-05) MOVER ▲ Jim Walton & family — $132.37B (+$4.81B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-08-05) MOVER ▲ Larry Ellison — $185.66B (+$4.66B since yesterday)
      United States · Technology · source: Oracle

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 97 total
  - (2026-08-03) [OFAC] Issuance of Amended Venezuela-related General License and Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Issuance of Amended Venezuela-related General License and Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-07-30) [OFAC] Counter Terrorism Designations; Non-Proliferation Designation Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Non-Proliferation Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-08-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Y Authorizing Certain Tra - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Y Authorizing Certain Tra Office of Foreign Assets Control (.gov)
  - (2026-08-05) [USASpending] $1,424,879,474 → ORACLE HEALTH GOVERNMENT SERVICES, INC.: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
      Agency: Department of Veterans Affairs. Description: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
  - (2026-08-05) [USASpending] $1,336,720,376 → THE BOEING COMPANY: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS
      Agency: National Aeronautics and Space Administration. Description: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-05) [South Korea] Lee Kang - in eager for fresh start at Atletico Madrid
      koreaherald.com · English
  - (2026-08-05) [South Korea] New US ambassador meets S . Korea top diplomat flanked by her politician husband
      hani.co.kr · English
  - (2026-08-05) [South Korea] [ Correspondent column ] Korean investigations make even Trump political retribution look mild
      hani.co.kr · English
  - (2026-08-05) [South Korea] Suneung could get essays , absolute grading in AI era
      koreaherald.com · English
  - (2026-08-05) [South Korea] [ Interview ] After 18 months in ICE detention , one man leaves behind a life in the US for a Korea he barely remembers
      hani.co.kr · English
  - (2026-08-05) [South Korea] AI - assisted music now eligible for copyright registration in South Korea
      koreaherald.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 9 total
  - (2026-08-04) CVE-2026-18556 · N-able N-central: N-able N-central Authentication Bypass Using an Alternate Path or Channel Vulnerability
      vendor: N-able · product: N-central · CISA remediation by 2026-08-07
  - (2026-08-04) CVE-2026-34486 · Apache Tomcat: Apache Tomcat Missing Encryption of Sensitive Data Vulnerability
      vendor: Apache · product: Tomcat · CISA remediation by 2026-08-07
  - (2026-08-04) CVE-2026-9198 · IBM Langflow: IBM Langflow Code Injection Vulnerability
      vendor: IBM · product: Langflow · CISA remediation by 2026-08-07

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-08-05) [Marginal Revolution] Is this why China finds it so hard to inflate producer prices?
      This paper investigates why China’s recurrent credit expansions have coincided with persistently weak inflation. We argue that this pattern reflects the country’s production-oriented monetary regime. At the aggregate lev…
  - (2026-08-05) [Marginal Revolution] Victor Niederhoffer, RIP
      In addition to his well-known public roles, he worked very hard to help and befriend me when I was younger. Here are the Google searches for Victor. Less well known about Victor is that he had one of the world’s best col…
  - (2026-08-05) [Marginal Revolution] The Value of Behavioral Policies
      Behavioral interventions have become central to modern public policy, but their empirical promise remains contested because estimated treatment effects often appear small. We argue that a policy response is economically…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: order, rulemaking, published, proposed, proposes, provide, safety, notice, amend, proposing, action, certain
- state_bills: today=0, 7d-median=108, 14d-median=112; carrying terms: among, legal, investigations, activities, owner, management, include, child, orders, subject, protection, reporting
- state_news: today=775, 7d-median=758, 14d-median=493; carrying terms: often, report, exceeded, legal, instead, republished, weather, upcoming, court, water, alone, reported
- local_news: today=239, 7d-median=230, 14d-median=228; carrying terms: vehicle, expected, friday, async, srcset, month, evening, children, killed, content, charges, found
- foreign_news: today=1041, 7d-median=1022, 14d-median=1007; carrying terms: presents, remember, removed, reaches, cross, weather, dipke, survey, figures, hitting, variables, imperial
- chinese_internal: today=281, 7d-median=266, 14d-median=265; carrying terms: global, china, caixin, google, chinese, https, firms, people, record, stock, sales, office
- russian_internal: today=1134, 7d-median=937, 14d-median=916; carrying terms: group, httperror, axios, istories, media, novayagazeta, found, telegram, gazeta, https, novaya, street
- ukrainian_internal: today=106, 7d-median=131, 14d-median=131; carrying terms: babel, economic, causing, minister, independent, injuring, additional, center, forces, httperror, districts, court
- ukraine_theater: today=434, 7d-median=639, 14d-median=627; carrying terms: deepstatemap, liveuamap, error, known, active, polygons, httperror, cartography, maintained, alerts, token, coverage
- paper_bets: today=133, 7d-median=141, 14d-median=134; carrying terms: robot, democratic, election, republicans, nuclear, minister, announcements, season, degrees, kansas, artist, netanyahu
- weather: today=146, 7d-median=173, 14d-median=173; carrying terms: chance, chances, night, twoat, hurricane, dangerously, louis, additional, center, rivers, degrees, messages
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: total, implied, inflation, cpilfesl, sheet, recession, indicator, vixcls, balance, money, latest, consumption
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, proxy, range, natural, credit, bitcoin, agriculture, yield, nasdaq, equities, futures, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=97, 7d-median=104, 14d-median=104; carrying terms: democratic, aeronautics, sovereignty, authorities, order, economic, daesh, crimea, schools, prohibiting, situation, stanford
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, httperror, error, quiverquant, quantitative, congresstrading, client, unauthorized, quiver
- billionaires: today=40, 7d-median=37, 14d-median=37; carrying terms: exchange, finance, ellison, yanai, mexico, zuckerberg, family, tadashi, commodities, bernard, facebook, devasini
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, johnson, california, delaware, supreme, county, appeals, services, blanche, international, thomas, group
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, holdings, robert, therapeutics, william, joshua
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: alexandria, sherrod, house, ossoff, cycle, senate, angels, trone, david, james, brown, pinkston
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, korea
- gdelt_gkg: today=50, 7d-median=25, 14d-median=25; carrying terms: english, hezbollah, israel, trump, netanyahu, spanish, keywords, chinese, themes, russian, israeli, crisis
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=16, 14d-median=16; carrying terms: position, canada, france, belgium, ground, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: recalls, manifestations, democratic, followed, authorities, material, ethiopian, monthly, driving, march, round, report
- cisa_kev: today=9, 7d-median=9, 14d-median=10; carrying terms: injection, deserialization, sharepoint, check, vulnerability, command, microsoft, langflow, improper, vendor, product, management
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=265, 7d-median=265, 14d-median=276; carrying terms: fires, democratic, marino, australia, macedonia, costa, impact, madagascar, green, switzerland, hurricane, serbia
- usgs_quakes: today=20, 7d-median=17, 14d-median=20; carrying terms: depth, region, islands, japan, indonesia, russia, south, kuril, philippines, severo, tonga, kermadec
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, volume, returns, august, ceasefire, strait, normal, hormuz, prime, traffic, interest
- commentary: today=5, 7d-median=5, 14d-median=5; carrying terms: https, having, revolution, conversable, marginal, government, conversableeconomist, economist, class, become, marginalrevolution, toward
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: report, targeted, schneier, using, bleepingcomputer, infrastructure, going, technica, weekday, threat, campaign, vulnerability
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: newhouse, menefee, mario, daines, yakym, craig, speech, teresa, economic, wesley, coons, knott
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, paper, placed, decision, module, identify, converges, unavailable, markets, placement, either, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*