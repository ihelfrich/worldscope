# WORLDSCOPE morning brief — 2026-08-05

## Headline
3611 new items across 29 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (760) · Russian Internal News (state + in-exile) (724) · State-Level News (392) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (291) · Chinese Internal News (208) · Local News: St. Louis + Atlanta (198) · U.S. Weather + Severe / Climate Outlooks (133) · State Legislative Action (116) · Ukrainian Internal News (national + local Kyiv) (56) · GDELT GKG — themes / entities / watch areas (50) · IT, InfoSys & cybersecurity news (last 7 days) (43)

## What changed today
### International News + Multilateral Institutions — 760 new of 1042 total
  - (2026-08-05) [Global] Russian attacks kill 17, exploiting Ukraine’s lack of missile interceptors
      Ukrainian President Volodymyr Zelenskyy says Russian forces used 29 missiles and 115 drones during the assault.
  - (2026-08-05) [Global] Toppled Bangladesh leader Sheikh Hasina to speak today: What we can expect
      Former Bangladeshi prime minister is likely to announce her return from exile in India despite facing the death penalty.
  - (2026-08-05) [Global] Michigan, Missouri, Washington primary elections: Key takeaways
      Recent US primaries have revealed Democratic Party rift between progressives and centrists over US support for Israel.
  - (2026-08-05) [Global] Trump hails progress but warned Iran of ‘hard hit’ if no deal reached
      US President Donald Trump says progress with Iran has been made, but warned Iran of 'hard hit' if no deal reached.
  - (2026-08-05) [Global] Cape Verde’s World Cup hero, social media sensation Vozinha joins Colo-Colo
      Vozinha says he always believed he was a 'big club' player after his move to Colo-Colo in Chile.
  - (2026-08-05) [Global] Inside the Air India Phuket-Delhi flight that dropped 300 feet mid-air
      Seventeen people were injured when an Air India flight from Phuket to Delhi encountered severe turbulence.

### Russian Internal News (state + in-exile) — 724 new of 1130 total
  - (2026-08-05) При взрыве в ресторане Balzi Rossi погиб зять главкома ВКС Александра Чайко | LEDE: Даниил Передрий, зять главкома ВКС Александра Чайко, погиб в результате взрыва в итальянском ресторане Bal] (ru: При…
      Даниил Передрий, зять главкома ВКС Александра Чайко, погиб в результате взрыва в итальянском ресторане Balzi Rossi в Москве 1 августа. Его смерть подтверждается утечками из двух государственных баз, пишет «Агентство».
  - (2026-08-05) Бывшего московского муниципального депутата Кетеван Хараидзе приговорили к четырем годам по делу о мошенничестве. Ее освободили от наказания в зале суда | LEDE: Тверской районный суд Москвы ] (ru: Быв…
      Тверской районный суд Москвы приговорил бывшего московского муниципального депутата Кетеван Хараидзе к четырем годам колонии по делу о мошенничестве, сообщает телеграм-канал «Осторожно, новости».
  - (2026-08-05) Bloomberg: в Вене прошла встреча бывших чиновников из Европы и России. Кто представлял Москву, неизвестно | LEDE: Бывшие высокопоставленные чиновники из Великобритании, Франции, Германии и Р] (ru: Blo…
      Бывшие высокопоставленные чиновники из Великобритании, Франции, Германии и России провели в июле встречу в Вене, чтобы изучить возможные условия для мирных переговоров между Москвой и Киевом, пишет Bloomberg со ссылкой н…
  - (2026-08-05) В США сотрудники иммиграционной службы задержали россиянку, запросившую убежище | LEDE: В США сотрудники иммиграционной и таможенной службы (ICE) задержали 59-летнюю россиянку Алевтину Собол] (ru: В С…
      В США сотрудники иммиграционной и таможенной службы (ICE) задержали 59-летнюю россиянку Алевтину Соболеву, уехавшую после начала войны в 2022 году и подавшую прошение об убежище.
  - (2026-08-05) В Киевской области в результате российского удара разрушен крупнейший склад украинского маркетплейса Rozetka | LEDE: В Киевской области в результате российской ракетной атаки разрушен крупне] (ru: В К…
      В Киевской области в результате российской ракетной атаки разрушен крупнейший склад украинского маркетплейса Rozetka, рассказала соосновательница компании Ирина Чечеткина.
  - (2026-08-05) «Коммерсант»: в центральной России только треть мобильных сессий проходят без ограничений. В приграничных регионах почти 90% подключений идут по «белым спискам» | LEDE: В июле 2026 года в Це] (ru: «Ко…
      В июле 2026 года в Центральном федеральном округе России в среднем только 30,5% пользовательских сессий в мобильных сетях происходили без ограничений, пишет «Коммерсант» со ссылкой на исследование разработчика средств дл…

### State-Level News — 392 new of 768 total
  - (2026-08-05) [California] California judge holds Homeland Security in contempt in case over LA immigration sweeps
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/062025-Bell-Immigration-Raid-GETTY-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-08-04) [California] California Democrats defy Newsom, back billionaire tax
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/022126-Billionaires-Tax-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-08-04) [California] Medi-Cal está cambiando. Esto es lo que debes hacer si te preocupa perder la cobertura
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/020726_Medi-Cal-Doc_JH_CM_72.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-08-04) [California] California estuvo a punto de lograr el acceso universal a la salud. Ahora, millones de personas están perdiendo su cobertura
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/020726_Medi-Cal-Doc_JH_CM_65.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-08-04) [California] LA County says a program meant to help people with serious mental illness is gaining traction
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2023/12/10092023_CARE-Court_AH_10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-08-04) [California] Medi-Cal is changing. Here’s what to do if you’re worried about coverage
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/020726_Medi-Cal-Doc_JH_CM_72.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 291 new of 434 total
  - (2026-08-04) [FIRMS] thermal anomaly 52.806, 32.227 (FRP 0.49 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-04 2358Z, FRP 0.49 MW
  - (2026-08-04) [FIRMS] thermal anomaly 52.367, 33.310 (FRP 0.81 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-04 2358Z, FRP 0.81 MW
  - (2026-08-04) [FIRMS] thermal anomaly 52.342, 33.282 (FRP 0.34 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-04 2358Z, FRP 0.34 MW
  - (2026-08-04) [FIRMS] thermal anomaly 52.189, 34.048 (FRP 0.62 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-04 2358Z, FRP 0.62 MW
  - (2026-08-04) [FIRMS] thermal anomaly 52.301, 32.669 (FRP 0.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-04 2358Z, FRP 0.51 MW
  - (2026-08-04) [FIRMS] thermal anomaly 52.213, 32.308 (FRP 3.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-04 2358Z, FRP 3.41 MW

### Chinese Internal News — 208 new of 282 total
  - (2026-08-04) 责编：任成琦 金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxNdllMTlR4NDhsWUJtSENhNzhCMlByLVpocC1pUm5qbHFuZ3VqUnRWcDVWMlR2Qk43UXRQX0ZocV85MVJhc3dwb] (zh:…
      责编：任成琦 金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-08-05) 责编：任成琦 金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxNV0tnS1JXQk1rb1dRZDFPZkJJbTZtOTBSMG1NS3VWZlhmcHhSSkVJRTktTGE0OFpJMTRxQURZWXBEQ2QtQkxCT] (zh:…
      责编：任成琦 金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-08-04) 责编：任成琦 金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxPamwybHlHdk55STV3VW9qUC1mdklwbmMydlF2TFp5V1dFTUpLUHhUV1RFS2R4WW1pYThYS1h5MXJ6Z1VCTXdBV] (zh:…
      责编：任成琦 金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-08-03) 责编：任成琦 金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxOSktFY2w0ZmlranMtX0pSbHRzcDlzeEhxWnZaZU9kQWFuWXVFYWRuNF9oVHFhQ3RaYjVfdFh3TkJMOC1vTXJRb] (zh:…
      责编：任成琦 金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-08-04) 天津“十五五”交通规划出炉 加快建成国际性综合交通枢纽城市 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9feE1Oa0VzMURseVJoMzd5X0hZck5hN3J0SS1JeUlxQmhHVV9jQ1FGMnJycjdVYWo3YWVGdHZqdHdlcGg0TWw3TzM] (zh:…
      天津“十五五”交通规划出炉 加快建成国际性综合交通枢纽城市 人民网
  - (2026-08-04) 人民日报图文数据库（1946-2026） - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE10T05PeW1kejZSNnFTblB0VGRDdjlGb19kMVNjUUdsUG8xa0NXSGlXNUlOYVdKbUxVV0tiZTNpT3FBQ1NmNVFSRDZSYWRkeDh] (zh:…
      人民日报图文数据库（1946-2026） 人民日报

### Local News: St. Louis + Atlanta — 198 new of 230 total
  - (2026-08-05) [St. Louis] Zimmerman wins Democratic primary for St. Louis County executive
      County assessor Jake Zimmerman notched a decisive victory in the Democratic primary for St. Louis County executive yesterday, besting state Senator Brian Williams (D–University City), 46 to 33 percent. State senator Ange…
  - (2026-08-05) [St. Louis] GOP-backed amendments 4 and 5 go down to defeat in Missouri
      Missouri voters rejected two key measures backed by Republican lawmakers on Tuesday’s ballot—one, Amendment 4, that would have made it more difficult for citizens to change the state constitution, and another, Amendment…
  - (2026-08-05) [St. Louis] Bell handily wins Democratic primary, beating back former U.S. Rep. Cori Bush in rematch
      The results were in before U.S. Rep. Wesley Bell’s election night watch party could even get into swing. When the Associated Press called the race for Bell over former Congresswoman Cori Bush around 8 p.m., people were s…
  - (2026-08-04) [St. Louis] Where in Chesterfield 8/5/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-08-04) [St. Louis] ‘Simpsons’ writer Bill Oakley brings regional food dinner to The Blue Duck in Maplewood
      Fans of The Simpsons, curious eaters, and regulars at The Blue Duck (2661 Sutton) will have reason to converge on September 1, when the restaurant hosts a seven-course dinner celebrating America’s regional food tradition…
  - (2026-08-04) [St. Louis] Sur Lie, from the owners of Little Fox, opening next month in Fox Park
      A second concept from Little Fox owners Craig and Mowgli Rivard is slated to open this September in Fox Park. Located directly across the street from Little Fox, Sur Lie (2805 Shenandoah) is a wine-focused bistro and bot…

### U.S. Weather + Severe / Climate Outlooks — 133 new of 145 total
  - (2026-08-05) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-05) [Severe] Flood Watch: Flood Watch issued August 5 at 5:15AM EDT until August 5 at 11:00AM EDT by NWS Baltimore MD/Washington DC
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of DC, including the following , District of Columbia, Maryland, including the following areas, Central and Southeast Mont…
  - (2026-08-05) [Moderate] Heat Advisory: Heat Advisory issued August 5 at 3:22AM CDT until August 5 at 8:00PM CDT by NWS Tulsa OK
      * WHAT...Heat index values up to 106 expected. * WHERE...Portions of northwest and west central Arkansas and east central, northeast, and southeast Oklahoma. * WHEN...From noon today to 8 PM CDT this evening. * IMPACTS..…
  - (2026-08-05) [Severe] Flash Flood Warning: Flash Flood Warning issued August 5 at 3:20AM CDT until August 5 at 6:15AM CDT by NWS Dodge City KS
      FFWDDC The National Weather Service in Dodge City has issued a * Flash Flood Warning for... Southwestern Lane County in west central Kansas... Southern Scott County in west central Kansas... * Until 615 AM CDT. * At 320…
  - (2026-08-05) [Moderate] Heat Advisory: Heat Advisory issued August 5 at 3:06AM CDT until August 5 at 9:00PM CDT by NWS Amarillo TX
      * WHAT...Temperatures up to 105 expected. * WHERE...Palo Duro Canyon. * WHEN...From 2 PM this afternoon to 9 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity may cause heat illnesses.
  - (2026-08-05) [Moderate] Heat Advisory: Heat Advisory issued August 5 at 12:16AM PDT until August 9 at 8:00AM PDT by NWS Reno NV
      * WHAT...High temperatures of 100 to 106 degrees with overnight lows of 59 to 73 degrees. Widespread Major (level 3 out of 4) HeatRisk across lower valleys. * WHERE...Western Nevada Basin and Range including Pyramid Lake…

### State Legislative Action — 116 new of 126 total
  - (2026-08-05) [Alaska SB 121] An Act relating to settlement of health insurance claims; relating to allowable charges for health care services or supplies; and providing for an effective date.
      An Act relating to settlement of health insurance claims; relating to allowable charges for health care services or supplies; and providing for an effective date.
  - (2026-08-05) [Alaska HB 55] An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
      An Act making appropriations for the operating and capital expenses of the state's integrated comprehensive mental health program; and providing for an effective date.
  - (2026-08-05) [Alaska HB 125] An Act relating to membership of the Board of Fisheries.
      An Act relating to membership of the Board of Fisheries.
  - (2026-08-05) [Alaska HB 53] An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental a…
      An Act making appropriations for the operating and loan program expenses of state government and for certain programs; capitalizing funds; amending appropriations; making supplemental appropriations; and providing for an…
  - (2026-08-05) [Alaska HB 289] An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; an…
      An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; and providing for an effective date.
  - (2026-08-05) [Alaska SB 237] An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Departm…
      An Act relating to the powers of the commissioner of administration with respect to motor vehicles; relating to electronic identification cards; relating to data sharing by the Department of Administration; relating to e…

### Ukrainian Internal News (national + local Kyiv) — 56 new of 103 total
  - (2026-08-05) В Україні з дводенним візитом перебуває очільниця МЗС Латвії | LEDE: Міністерка закордонних справ Латвії Байба Браже перебуває в Україні з дводенним візитом.] (uk: В Україні з дводенним візитом перебу…
      Міністерка закордонних справ Латвії Байба Браже перебуває в Україні з дводенним візитом.
  - (2026-08-05) Зеленський після удару РФ закликав партнерів активніше допомагати з перехоплювачами | LEDE: Президент Володимир Зеленський на тлі масованої російської атаки закликав партнерів активніше допомаг] (uk:…
      Президент Володимир Зеленський на тлі масованої російської атаки закликав партнерів активніше допомагати з ракетами-перехоплювачами до систем ППО.
  - (2026-08-05) Довіра до Зеленського майже не змінилась, незважаючи на протести – КМІС | LEDE: За даними опитування, довіра до президента Володимира Зеленського серед українців на початок серпня, порівняно з ] (uk:…
      За даними опитування, довіра до президента Володимира Зеленського серед українців на початок серпня, порівняно з квітнем, знизилась з 58% до 55%.
  - (2026-08-05) Сибіга після масованого удару по Київщині нагадав про потребу чинити тиск на Росію | LEDE: На тлі нової масованої російської атаки на Київську область очільник МЗС Андрій Сибіга закликав світ п] (uk:…
      На тлі нової масованої російської атаки на Київську область очільник МЗС Андрій Сибіга закликав світ продовжувати чинити тиск на Росію за допомогою санкцій.
  - (2026-08-05) У Румунії на Дунаї затоплять чотири баржі, щоб покращити ситуацію для АЕС | LEDE: У Румунії на Дунаї в районі Чернаводської АЕС затоплять чотири баржі у спробі підвищити рівень води в річці, ві] (uk:…
      У Румунії на Дунаї в районі Чернаводської АЕС затоплять чотири баржі у спробі підвищити рівень води в річці, від чого залежить подальша безпечна робота станції.
  - (2026-08-05) Сили оборони уразили пункти управління, переправу та склад окупантів – Генштаб | LEDE: Українські військові уразили кілька пунктів управління окупантів, військову переправу на Донеччині та скла] (uk:…
      Українські військові уразили кілька пунктів управління окупантів, військову переправу на Донеччині та склад в окупованому Криму.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-05) [Israel-Iran-Hezbollah axis · themes] Letter : Trump ignorance
      reflector.com · English · tone NA
  - (2026-08-05) [Israel-Iran-Hezbollah axis · themes] tayyar . org - مراهقة تفارق الحياة بحادث مروّع
      tayyar.org · Arabic · tone NA
  - (2026-08-05) [Israel-Iran-Hezbollah axis · themes] KNKT Ungkap Tantangan Usut Kebakaran KM Mutiara Sentosa 2 , Bangkai Kapal Masih Dicari
      tribunnews.com · Indonesian · tone NA
  - (2026-08-05) [Israel-Iran-Hezbollah axis · themes] DR Congo Ebola outbreak outstrips response as cases near 3 , 900 - Xinhua
      english.news.cn · English · tone NA
  - (2026-08-05) [Israel-Iran-Hezbollah axis · themes] Po Kinijos sprendimo apriboti lietuvišką lazerių gamintoją – K . Budrio reakcija
      lrytas.lt · Lithuanian · tone NA
  - (2026-08-05) [Israel-Iran-Hezbollah axis · themes] How to keep my dog safe around open water - 9 steps to take
      bicesteradvertiser.net · English · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 57 total
  - (2026-08-05) [The Hacker News] Claude Mythos 5 Tried to Backdoor a Real Open-Source Project in Testing, Then Vouched for Itself
      An agent running Anthropic's Claude Mythos 5 spent 34 hours trying to get a malware dropper merged into a real open-source project during a cyber evaluation by the UK's AI Security Institute. When a bystander publicly wa…
  - (2026-08-05) [The Hacker News] CISA Flags Langflow RCE, Tomcat, and N-central Flaws as Actively Exploited
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA), on August 5, 2026, added three flaws to its Known Exploited Vulnerabilities (KEV) catalog, citing evidence of active exploitation in the wild. The list of…
  - (2026-08-05) [The Hacker News] QuickFox Supply Chain Attack Delivers FDMTP Backdoor via Trojanized Windows Installer
      Cybersecurity researchers have disclosed what has been described as a "long-standing supply chain attack" on QuickFox, a virtual private network (VPN) and network acceleration tool designed for overseas Chinese users. Ac…
  - (2026-08-05) [The Register] Double trouble for Microsoft as pre-owned software licenses claims converge
      Tribunal to explore how £270 million reseller case intersects with multibillion-pound class action
  - (2026-08-05) [The Register] New Boeing finally gets going, 15 years after debut
      The 737-7 is the smallest of its type, yet it has the longest range
  - (2026-08-05) [The Register] Adding an API to networking hardware doesn’t solve management challenges
      This is why cloud-inspired networks win: virtual switches are all consistent

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-05) [Straub Philip] Form 4 (Reporting)
      filed 2026-08-05 01:55 UTC · role: Reporting — Filed: 2026-08-04 AccNo: 0001193125-26-333541 Size: 4 KB
  - (2026-08-05) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-08-05 01:55 UTC · role: Issuer — Filed: 2026-08-04 AccNo: 0001193125-26-333541 Size: 4 KB
  - (2026-08-05) [KAO MIN H] Form 4 (Reporting)
      filed 2026-08-05 01:55 UTC · role: Reporting — Filed: 2026-08-04 AccNo: 0001193125-26-333540 Size: 5 KB
  - (2026-08-05) [GARMIN LTD] Form 4 (Issuer)
      filed 2026-08-05 01:55 UTC · role: Issuer — Filed: 2026-08-04 AccNo: 0001193125-26-333540 Size: 5 KB
  - (2026-08-05) [van Houte Hans] Form 4 (Reporting)
      filed 2026-08-05 01:41 UTC · role: Reporting — Filed: 2026-08-04 AccNo: 0001817217-26-000012 Size: 7 KB
  - (2026-08-05) [Nurix Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-08-05 01:41 UTC · role: Issuer — Filed: 2026-08-04 AccNo: 0001817217-26-000012 Size: 7 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-05) [United Kingdom] Big bank bosses on alert as tax noise gets louder under Burnham
      domain: cityam.com · language: English · tone:
  - (2026-08-05) [India] In 1985 , used tyres from Japan likely carried mosquito eggs to Texas , helping the Asian tiger mosquito spread across the United States | World News
      domain: timesofindia.indiatimes.com · language: English · tone:
  - (2026-08-05) [Australia] Perez Hilton hospitalised after distressing livestream
      domain: dailyliberal.com.au · language: English · tone:
  - (2026-08-05) [United States] Progressive Abdul El - Sayed Wins Michigan Sen Dem Primary
      domain: wiba.iheart.com · language: English · tone:
  - (2026-08-05) [India] Houthis claim ballistic missile strike on Saudi oil tanker Wafaa in northern Red Sea
      domain: aninews.in · language: English · tone:
  - (2026-08-05) [India] ITR filing for F & O traders : Turnover isnt trade value . Experts explain how to calculate it
      domain: livemint.com · language: English · tone:

### GDACS — global disaster alerts — 37 new of 265 total
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-08-05) [Green] Eruption Fuego
      Volcano · Green alert · Guatemala
  - (2026-08-05) [Green] Eruption Fuego
      Volcano · Green alert · Guatemala
  - (2026-08-05) [Green] Eruption Fuego
      Volcano · Green alert · Guatemala

### Court opinions of consequence (federal & state) — 32 new of 60 total
  - (2026-08-04) U.S. Court of Appeals, Federal Cir.: Johnson v. United States
  - (2026-08-04) U.S. Court of Appeals, Federal Cir.: Socket Solutions, LLC v. Import Global, LLC
  - (2026-08-04) U.S. Court of Appeals, 11th Cir.: United States v. Latona Mae Lambert
  - (2026-08-04) U.S. Court of Appeals, 11th Cir.: Estella Curry v. Warden
  - (2026-08-04) U.S. Court of Appeals, 11th Cir.: Jeremias Medrado Pasqual-Andres v. U.S. Attorney General
  - (2026-08-04) U.S. Court of Appeals, 11th Cir.: Joshua Phillips v. City of Hanceville, Alabama

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 26 new of 30 total
  - (2026-08-05) SAMU44 (France)
      icao24: 39ca84 · position: (47.244, -1.9688) · alt: 198m · 221km/h
  - (2026-08-05) CNA22 (Spain)
      icao24: 3475cb · position: (27.7991, -15.7997) · alt: 1432m · 166km/h
  - (2026-08-05) GAF681 (Germany)
      icao24: 3e0f78 · position: (46.7212, 6.2359) · alt: 1318m · 240km/h
  - (2026-08-05) GAF682 (Germany)
      icao24: 3e0f77 · position: (46.7208, 6.2333) · alt: 1318m · 244km/h
  - (2026-08-05) SAMU06 (France)
      icao24: 39c901 · position: (45.2627, 5.5941) · alt: 952m · 220km/h
  - (2026-08-05) JAF63N (Belgium)
      icao24: 44d1ba · position: (50.9037, 4.4849) · on ground · 0km/h

### U.S. Federal Action — 22 new of 22 total
  - (2026-08-05) Continuation of the National Emergency With Respect to the Advancement by Countries of Concern in Sensitive Technologies and Products Critical for the Military, Intelligence, Surveillance, or Cyber-En…
  - (2026-08-05) To Facilitate Positive Adjustment to Competition From Imports of Quartz Surface Products
  - (2026-08-05) Improving Emergency Medical Kit Efficacy and Flexibility in Commercial Airline Operations
      FAA proposes to eliminate the prescriptive list of required items in emergency medical kits and first aid kits and replace it with a performance-based requirement to ensure contents are practical and sufficient to allow…
  - (2026-08-05) Micro-Tracers, Inc.; Response to Objections and Requests for a Public Hearing
      The Food and Drug Administration (FDA or we) received objections and requests for a public hearing submitted by Buchanan Ingersoll & Rooney PC, on behalf of Micro-Tracers, Inc. (Micro-Tracers or objector), on the order g…
  - (2026-08-05) Amendment of United States Area Navigation Route Q-10 and Revocation of Alaska Area Navigation Routes J-804R and J-889R in Alaska
      This action amends United States Area Navigation (RNAV) Route Q-10 and revokes Alaska RNAV Routes J-804R and J-889R in Alaska. These actions are part of a large and comprehensive airway modernization project for the stat…
  - (2026-08-05) Fisheries of the Caribbean, Gulf of America, and South Atlantic; Reef Fish Fishery in the Gulf of America; 2026 Commercial Closure for Greater Amberjack
      NMFS is closing the 2026 commercial fishing season for greater amberjack in the Gulf of America (Gulf). Federal regulations require NMFS to close commercial harvest for greater amberjack if landings reach the commercial…

### USGS earthquakes (M4.5+, past day) — 19 new of 19 total
  - (2026-08-05) M 6.3 - south of the Kermadec Islands
      M6.3 · south of the Kermadec Islands · depth 226.084 km
  - (2026-08-05) M 6.3 - 32 km SW of Sarangani, Philippines
      M6.3 · 32 km SW of Sarangani, Philippines · depth 10 km
  - (2026-08-04) M 5.7 - 127 km NW of Ternate, Indonesia
      M5.7 · 127 km NW of Ternate, Indonesia · depth 35 km
  - (2026-08-05) M 5.2 - Auckland Islands, New Zealand region
      M5.2 · Auckland Islands, New Zealand region · depth 21.906 km
  - (2026-08-05) M 5.2 - 31 km S of Sarangani, Philippines
      M5.2 · 31 km S of Sarangani, Philippines · depth 35 km
  - (2026-08-05) M 5.1 - 46 km SSW of Sarangani, Philippines
      M5.1 · 46 km SSW of Sarangani, Philippines · depth 29.831 km

### Paper Trading Scorecard — 16 new of 133 total
  - (2026-08-05) [Manifold] Will a humanoid robot beat a ranked top #10 tennis player by EOY 2027?
  - (2026-08-05) [Manifold] Daily Coinflip
  - (2026-08-05) [Manifold] "Spider-Man: Brand New Day" 2nd Weekend Box Office >= 150M
  - (2026-08-05) [Manifold] "Spider-Man: Brand New Day" 2nd Weekend Box Office >= 130M
  - (2026-08-05) [Manifold] Will Drift0r's medical problem be found before 2027?
  - (2026-08-05) [Manifold] Free Lottery (black hole in universe)

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-05) Will Abdul El-Sayed win the 2026 Michigan Democratic Primary?
      yes price: 100% · 24h volume: $1,501,894 · resolves 2026-08-04
  - (2026-08-05) Dota 2: 1win vs BetBoom Team (BO3) - 1win Essence Playoffs
      yes price: 49% · 24h volume: $1,398,240 · resolves 2026-08-05
  - (2026-08-05) LoL: HANJIN BRION vs Nongshim Red Force - Game 1 Winner
      yes price: 100% · 24h volume: $1,239,186 · resolves 2026-08-05
  - (2026-08-05) Will Berhanu Nega be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $935,631 · resolves 2026-06-01
  - (2026-08-05) Will Haley Stevens win the 2026 Michigan Democratic Primary?
      yes price: 0% · 24h volume: $811,939 · resolves 2026-08-04
  - (2026-08-05) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 14% · 24h volume: $676,599 · resolves 2027-01-01

### World News (by country, top stories) — 12 new of 12 total
  - (2026-08-05) [Germany] China puts battery storage at center of renewable energy strategy
      finanznachrichten.de · English
  - (2026-08-05) [Germany] India : Heavy monsoon season claims more than 100 lives
      dw.com · English
  - (2026-08-05) [Germany] Santen Pharmaceutical Co ., Ltd .: Santen Joins Inaugural Global Summit for Eye Health as High - Impact Partner
      finanznachrichten.de · English
  - (2026-08-05) [Germany] Korea : Police raid Starbucks offices over Tank Day fiasco
      dw.com · English
  - (2026-08-05) [Germany] Global News : European Life Science Research Association Announces Dual United Nations Qualification
      finanznachrichten.de · English
  - (2026-08-05) [Germany] AI ecosystem circular investment : risk or advantage ?
      dw.com · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-08-05) #27 Masayoshi Son — $72.36B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-08-05) MOVER ▲ Elon Musk — $783.28B (+$57.34B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-05) MOVER ▲ Michael Dell — $252.77B (+$16.04B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-05) MOVER ▼ Jeff Bezos — $283.22B ($-5.82B since yesterday)
      United States · Technology · source: Amazon
  - (2026-08-05) MOVER ▲ Jim Walton & family — $132.37B (+$4.81B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-08-05) MOVER ▲ Larry Ellison — $185.66B (+$4.66B since yesterday)
      United States · Technology · source: Oracle

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 97 total
  - (2026-08-03) [OFAC] Issuance of Amended Venezuela-related General License and Frequently Asked Question - Office of Foreign Assets Control (.gov)
      Issuance of Amended Venezuela-related General License and Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-07-30) [OFAC] Counter Terrorism Designations; Non-Proliferation Designation Update - Office of Foreign Assets Control (.gov)
      Counter Terrorism Designations; Non-Proliferation Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-29) [OFAC] Iran-related Designations - Office of Foreign Assets Control (.gov)
      Iran-related Designations Office of Foreign Assets Control (.gov)
  - (2026-08-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Y Authorizing Certain Tra - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5Y Authorizing Certain Tra Office of Foreign Assets Control (.gov)
  - (2026-08-05) [USASpending] $1,424,879,474 → ORACLE HEALTH GOVERNMENT SERVICES, INC.: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
      Agency: Department of Veterans Affairs. Description: EHRM WAVES K, L, M (VISN 23) AND N, O (VISN 15) DEPLOYMENTS
  - (2026-08-05) [USASpending] $1,336,720,376 → THE BOEING COMPANY: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS
      Agency: National Aeronautics and Space Administration. Description: INTERIM CRYOGENIC PROPULSION STAGE FOR SLS

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 9 total
  - (2026-08-04) CVE-2026-18556 · N-able N-central: N-able N-central Authentication Bypass Using an Alternate Path or Channel Vulnerability
      vendor: N-able · product: N-central · CISA remediation by 2026-08-07
  - (2026-08-04) CVE-2026-34486 · Apache Tomcat: Apache Tomcat Missing Encryption of Sensitive Data Vulnerability
      vendor: Apache · product: Tomcat · CISA remediation by 2026-08-07
  - (2026-08-04) CVE-2026-9198 · IBM Langflow: IBM Langflow Code Injection Vulnerability
      vendor: IBM · product: Langflow · CISA remediation by 2026-08-07

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-08-05) [Marginal Revolution] Is this why China finds it so hard to inflate producer prices?
      This paper investigates why China’s recurrent credit expansions have coincided with persistently weak inflation. We argue that this pattern reflects the country’s production-oriented monetary regime. At the aggregate lev…
  - (2026-08-05) [Marginal Revolution] Victor Niederhoffer, RIP
      In addition to his well-known public roles, he worked very hard to help and befriend me when I was younger. Here are the Google searches for Victor. Less well known about Victor is that he had one of the world’s best col…
  - (2026-08-05) [Marginal Revolution] The Value of Behavioral Policies
      Behavioral interventions have become central to modern public policy, but their empirical promise remains contested because estimated treatment effects often appear small. We argue that a policy response is economically…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: published, rulemaking, provide, requires, order, safety, program, certain, proposed, action, final, standard
- state_bills: today=126, 7d-median=126, 14d-median=117; carrying terms: licenses, projects, legal, access, required, child, subject, requires, activities, housing, responsible, safety
- state_news: today=768, 7d-median=758, 14d-median=493; carrying terms: idaho, issued, flood, front, margin, legal, permit, speaking, release, leaving, alone, money
- local_news: today=230, 7d-median=230, 14d-median=228; carrying terms: georgia, injured, woman, suspect, width, fetchpriority, dining, uploads, people, atlanta, murder, restaurant
- foreign_news: today=1042, 7d-median=1022, 14d-median=1007; carrying terms: plays, wechat, tells, sleeping, tackling, statement, flood, front, alcomsat, margin, legal, strategy
- chinese_internal: today=282, 7d-median=266, 14d-median=265; carrying terms: firms, people, https, chinese, global, google, record, caixin, china, stock, price, sales
- russian_internal: today=1130, 7d-median=937, 14d-median=916; carrying terms: group, found, press, media, istories, error, wildberries, bloomberg, patriot, novayagazeta, forbidden, reuters
- ukrainian_internal: today=103, 7d-median=131, 14d-median=131; carrying terms: prime, attack, injured, reactions, damage, remain, aerial, targeting, warehouse, reach, authorities, ministers
- ukraine_theater: today=434, 7d-median=639, 14d-median=627; carrying terms: firms, unauthorized, deepstatemap, snapshot, error, https, active, frontline, polygons, liveuamap, coverage, cartography
- paper_bets: today=133, 7d-median=141, 14d-median=134; carrying terms: georgia, prime, credible, determined, successor, colonize, decrease, russell, event, anthropic, virginia, state
- weather: today=145, 7d-median=173, 14d-median=173; carrying terms: excessive, white, diego, statement, issued, flood, front, monitoring, effect, index, oxnard, moving
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: supply, labor, dexjpus, assets, crude, vixcls, pcepilfe, unrate, jolts, energy, recession, dexchus
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, yield, crude, rates, agriculture, equities, range, futures, crypto, silver, natural, china
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=97, 7d-median=104, 14d-median=104; carrying terms: prohibiting, occupation, burundi, union, areas, middle, maintenance, transition, energy, leland, central, flight
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quiver, unauthorized, error, quiverquant, https, httperror, quantitative, congresstrading
- billionaires: today=40, 7d-median=37, 14d-median=37; carrying terms: bezos, larry, technologies, canada, zuckerberg, paris, ballmer, japan, alice, exchange, bernard, china
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, services, court, johnson, california, appeals, county, blanche, international, thomas, group, association
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, holdings, therapeutics, robert, joshua, william
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, david, ocasio, ossoff, graham, house, platner, johnson, congress, talarico, sherrod, michael
- gdelt_regions: today=12, 7d-median=6, 14d-median=12; carrying terms: english, china, korea
- gdelt_gkg: today=50, 7d-median=25, 14d-median=25; carrying terms: english, hezbollah, israel, trump, keywords, spanish, netanyahu, israeli, themes, crisis, hormuz, italian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=0; carrying terms: domain, english, language, iheart, russia, territory, years, kingdom, india
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=16, 14d-median=16; carrying terms: position, canada, france, belgium, ground, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: formula, canada, investigations, watery, areas, middle, involved, individual, autochthonous, recherche, published, april
- cisa_kev: today=9, 7d-median=9, 14d-median=10; carrying terms: injection, product, vulnerability, langflow, management, authentication, command, improper, remediation, point, fortinet, deserialization
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=265, 7d-median=265, 14d-median=276; carrying terms: genevieve, orange, depth, canada, alert, hurricane, montenegro, china, flood, tropical, albania, ukraine
- usgs_quakes: today=19, 7d-median=17, 14d-median=19; carrying terms: depth, islands, japan, region, south, russia, indonesia, philippines, severo, kuril, tonga, kermadec
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, volume, ceasefire, hormuz, august, prime, returns, normal, traffic, strait, interest
- commentary: today=5, 7d-median=5, 14d-median=5; carrying terms: class, conversableeconomist, government, marginal, conversable, https, having, revolution, economist, become, marginalrevolution, toward
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: attack, access, review, daily, vulnerability, record, attacks, edition, against, targeted, government, intelligence
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: commission, union, white, welch, chicago, elizabeth, davids, matsui, ruben, pelosi, austin, perry
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, decision, paper, consensus, placed, either, identify, claude, placement, market, converges, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-07-29] ECB press: ECB wage tracker at 2.7% in Q1 2027, indicating stable negotiated wage pressures
- [2026-07-29] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-07-30] ECB press: Digital euro app to incorporate highest accessibility standards
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*