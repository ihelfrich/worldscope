# WORLDSCOPE morning brief — 2026-06-03

## Headline
3208 new items across 29 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (660) · International News + Multilateral Institutions (653) · State-Level News (388) · World leaders & government officials (324) · Chinese Internal News (232) · Local News: St. Louis + Atlanta (197) · Ukraine Theater (total-war monitoring) (123) · State Legislative Action (115) · GDELT GKG — themes / entities / watch areas (75) · U.S. Weather + Severe / Climate Outlooks (70) · Ukrainian Internal News (national + local Kyiv) (64) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 660 new of 1124 total
  - (2026-06-03) «Десятки тысяч погибших — это не абстракция. Это можете быть вы. Вас оставят умирать в грязи». Генсек НАТО предостерег россиян от вербовки на фронт | LEDE: Генеральный секретарь НАТО Марк Рю] (ru: «Де…
      Генеральный секретарь НАТО Марк Рютте обратился к российской молодежи с призывом не поддаваться вербовке на войну. С таким заявлением он выступил во время визита в Киев.
  - (2026-06-03) Патриарх Кирилл отправил в Бразилию митрополита Илариона. Его подозревали в перевозке наркотиков в Чехии | LEDE: Глава Русской православной церкви патриарх Кирилл отправил митрополита Иларио] (ru: Пат…
      Глава Русской православной церкви патриарх Кирилл отправил митрополита Илариона, которого в Чехии заподозрили в перевозке наркотиков, на служение в Аргентинско-Южноамериканскую епархию.
  - (2026-06-03) На ПМЭФ выступили родственницы Путина. Дочь говорила об импортозамещении лекарств, внучатая племянница — о центрах здоровья и рождаемости в РЖД | LEDE: В первый день Петербургского междунаро] (ru: На…
      В первый день Петербургского международного экономического форума на мероприятии выступили две родственницы Владимира Путина: младшая дочь Катерина Тихонова и двоюродная внучатая племянница президента Елена Фисенко.
  - (2026-06-03) В Великобритании протесты и беспорядки из-за убийства 18-летнего Генри Новака. Перед гибелью раненого студента арестовали полицейские, поверив его убийце. Тот заявлял, что сам Новак напал на не] (ru:…
      В Великобритании разгорается скандал вокруг дела об убийстве 18-летнего студента Генри Новака, который погиб в конце 2025 года в Саутгемптоне. Его несколько раз ударил ножом 23-летний Викрам Дигва. 1 июня суд приговорил…
  - (2026-06-03) Удар по Петербургу в день начала ПМЭФ. Z-блогеры — в недоумении, федеральное ТВ — просто молчит. «Илон Маск знал, что на форуме будет его отец, но дроны на „Старлинке“ все равно долетели» | LED] (ru:…
      Украина неслучайно ударила в день старта ПМЭФ. Им плевать, если пострадает кто-то из высоких гостей, а мы боимся бить по Киеву, когда туда приезжают делегации из Европы. Отдельно стоит отметить большое количество видео в…
  - (2026-06-03) Объявлен шорт-лист премии «Большая книга». В него попал роман Маргариты Симоньян (который включили в длинный список задним числом) | LEDE: Литературная премия «Большая книга» опубликовала ко] (ru: Объ…
      Литературная премия «Большая книга» опубликовала короткий список претендентов на награду в 2026 году.

### International News + Multilateral Institutions — 653 new of 898 total
  - (2026-06-03) [Global] What is the St Petersburg forum, Putin’s economic outreach to the world?
      A Ukrainian drone strike targeted energy facilities near St Petersburg hours before the forum began.
  - (2026-06-03) [Global] The Ebola outbreak the world isn’t paying attention to
      A deadly Ebola outbreak in the DRC is spreading across borders, with no approved vaccine or treatment for this strain.
  - (2026-06-03) [Global] Which World Cup 2026 stadiums will host matches in US, Canada and Mexico?
      A quick look at the 16 venues across 16 cities in three countries, which will host the biggest-ever FIFA World Cup.
  - (2026-06-03) [Global] UK minister condemns violent protests against student’s murder
      Henry Nowak's death has spurred right-wing claims ‘two-tier’ policing disadvantages white people
  - (2026-06-03) [Global] Turkiye’s top diplomat, Indonesia’s president discuss $10bn trade goal
      The two discuss a range of sectors, including defence, energy, transportation and the halal food industry.
  - (2026-06-03) [Global] FBI agents fatally shoot alleged hostage-taker in California
      The shooting ends a 12-hour standoff in the city of Bakersfield between suspect and law enforcement.

### State-Level News — 388 new of 824 total
  - (2026-06-02) [Alabama] Flags Lowered Honoring Former State Senator John Emanuel Amari
      Download
  - (2026-06-03) [Connecticut] CT GOP candidate defiant in face of criticism for anti-gay post
      <img width="1024" height="671" src="https://ctmirror.org/wp-content/uploads/2026/06/3D37AC1D-422B-4703-9459-F3E41951067F-1024x671.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=…
  - (2026-06-03) [Connecticut] Here are the 6 things the CT-Puerto Rico Trade Commission will focus on
      <img width="1024" height="732" src="https://ctmirror.org/wp-content/uploads/2026/06/CTPublic_PR-Trade-Commission-1024x732.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-06-03) [Connecticut] CT lawmakers rejected 3-year bachelor’s degrees. But the trend isn’t going away
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/AP24178495361034-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy…
  - (2026-06-03) [Connecticut] More education funds, no funding formula reform
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/05/Shepard-Fisher-4.21.26-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading…
  - (2026-06-03) [Connecticut] When schools lose the people who came back to serve them
      <img width="870" height="572" src="https://ctmirror.org/wp-content/uploads/2026/04/Sand-school.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="https…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 232 new of 290 total
  - (2026-06-03) 从市长到主席边升官边敛财 62岁正省级女高官王莉霞将受审 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE45QnNra2tNWkNrMHVSNTc4WVJSR2dFQk5kemRqcnQycmNZdF80ZzlDbXdMUHJsZ1dhb0VTRkVCdWJ] (zh:…
      从市长到主席边升官边敛财 62岁正省级女高官王莉霞将受审 china.caixin.com
  - (2026-06-02) 老虎证券6月12日起将停止存量用户中国境内开仓加仓 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0tUVVvbGVEWXRrdWFac1RUMVhHeHVIWTZidDVfNDA4dzAwbjBqczlaRGFrYUlpejc3d1BueDlENTNSckFsMThQTE9EczVf] (zh:…
      老虎证券6月12日起将停止存量用户中国境内开仓加仓 财新
  - (2026-06-03) 美国史上最广301调查公布：拟对60个经济体加征10%或12.5%的关税 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9rcEZZVUVwQVFCUVE5M2xoVno2T2gzcXJYVkhwVW9KMml0MDYwb2dFNlpKNm55QUtSZ1dnMmpzLWkwbV9iY] (zh:…
      美国史上最广301调查公布：拟对60个经济体加征10%或12.5%的关税 财新
  - (2026-06-03) 超越美债，黄金成全球官方储备第一大资产 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9mekp5dEl1M3d5X19vNktPcjFvRjh3MnRPTlVaUnF4MFJxVWJRdlBYOUdLNlVRMWN0Zy1zakZoM0FoYlN1emloTThOV3NhWDczY0] (zh:…
      超越美债，黄金成全球官方储备第一大资产 财新
  - (2026-06-02) “耿同学”打假再有战果 《自然》答财新：正评估相关信息 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBfQ0pxMW9nS2d6b0RkLWY1TTlYR1BaOGltMXloRHVpZWlxM3lTaUcxLUd6ckJBMTExSVRWajBUbXBRcVJMQjJYLV9VZj] (zh:…
      “耿同学”打假再有战果 《自然》答财新：正评估相关信息 财新
  - (2026-06-02) 匈牙利新总理欲修法解职总统 试图逼退欧尔班任命的一批高官 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1BckFoR0RobWVQcmd6Qm5RMXp3aXZRZ2NnZDRHU005MVk4WE55N1F3WWpSMkFHYXloRmo3czU0Y2lsd0N2R0ppU19YZ] (zh:…
      匈牙利新总理欲修法解职总统 试图逼退欧尔班任命的一批高官 财新

### Local News: St. Louis + Atlanta — 197 new of 247 total
  - (2026-06-03) [St. Louis] Is the St. Charles Farmers Market the most kid-friendly in the region?
      A change in location may have been all the St. Charles Farmers Market needed to become one of the area’s most family-friendly weekend destinations. This season, the market packed up its produce, parted ways with the City…
  - (2026-06-03) [St. Louis] A house in Wildwood hits the market
      Thoughtful Design Built in 2019, the residence was conceived with an intuitive floor plan, striking details, and carefully considered design elements. Cape Cod-InspiredThis four-bedroom, five-bathroom home is as charming…
  - (2026-06-03) [St. Louis] Police Board’s big raises mean an even bigger increase for St. Louis’ fire department
      On Monday night, the state-appointed Board of Police Commissioners proposed significant pay increases for high-ranking officers: 16 percent for lieutenants, 18 percent for captains, 20 percent for majors, and 22 percent…
  - (2026-06-03) [St. Louis] Broadway star Kate Baldwin helps Opera Theatre of Saint Louis expand its horizons in a glorious show
      One of Broadway’s big stars is in St. Louis this summer, but she’s not at The Muny. Two-time Tony Award nominee Kate Baldwin is starring in The Light in the Piazza as it makes its debut at Opera Theatre of Saint Louis. I…
  - (2026-06-03) [St. Louis] Now is the time to build up the riverfront, civic and business leaders say
      The portion of the Mississippi River that lines St. Louis’ downtown has long felt like an afterthought for the city, but civic and business leaders say the moment now is as good as any to spur riverfront revitalization.…
  - (2026-06-03) [St. Louis] Top things to do in St. Louis this weekend: June 5–7
      Circus Flora | Through June 21 Circus Flora celebrates its 40th anniversary season with Flying High, featuring the Flying Wallendas, the Olate Dogs, a Human Cannonball, and more. See website for details. The Big Top, 340…

### Ukraine Theater (total-war monitoring) — 123 new of 279 total
  - (2026-06-03) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.107 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.87 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.111 (FRP 0.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.51 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.295, 25.110 (FRP 1.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 1.04 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.849, 29.988 (FRP 2.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 2.77 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.701, 31.867 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 0.8 MW

### State Legislative Action — 115 new of 162 total
  - (2026-06-03) [Arizona SB 1235] EMS reciprocity; compact.
      EMS reciprocity; compact.
  - (2026-06-03) [Arizona SB 1497] classical learning; tests; examinations
      classical learning; tests; examinations
  - (2026-06-03) [Arizona SB 1133] candidate financial disclosures; public officers
      candidate financial disclosures; public officers
  - (2026-06-02) [Arizona SB 1184] HOAs; uniformed services division flags
      HOAs; uniformed services division flags
  - (2026-06-02) [Arizona SB 1135] death benefits; burial costs
      death benefits; burial costs
  - (2026-06-02) [Arizona SB 1233] administrative deficiencies; cure period
      administrative deficiencies; cure period

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-06-03) [Taiwan Strait + South China Sea · themes] A Cuba va sempre peggio
      ilpost.it · Italian · tone NA
  - (2026-06-03) [Taiwan Strait + South China Sea · themes] Danneggiata a causa del maltempo la Caverne du Pont Neuf lopera dellartista JR a Parigi
      zazoom.it · Italian · tone NA
  - (2026-06-03) [Taiwan Strait + South China Sea · themes] KLM - medewerker laat 1000 liter kerosine weglekken : Extreem gevaarlijke situatie
      rtl.nl · Dutch · tone NA
  - (2026-06-03) [Taiwan Strait + South China Sea · themes] Worrying time for families after Royal Navy helicopter crashes into field – PM
      times-series.co.uk · English · tone NA
  - (2026-06-03) [Taiwan Strait + South China Sea · themes] Cruise Passenger Hailed As Hero For Jumping Into Water To Save Elderly Man
      1015.iheart.com · English · tone NA
  - (2026-06-03) [Taiwan Strait + South China Sea · themes] Argentina hace historia con el regreso de este mamífero en peligro de extinción : llevan años luchando por su reintroducción
      nacion.com · Spanish · tone NA

### U.S. Weather + Severe / Climate Outlooks — 70 new of 75 total
  - (2026-06-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-03) [Severe] Special Marine Warning: Special Marine Warning issued June 3 at 12:34PM EDT until June 3 at 1:00PM EDT by NWS Key West FL
      SMWKEY The National Weather Service in Key West has issued a * Special Marine Warning for... Hawk Channel and Straits of Florida from Craig Key to west end of Seven Mile Bridge out 20 nm... Bayside and Gulf side from Cra…
  - (2026-06-03) [Severe] Flash Flood Warning: Flash Flood Warning issued June 3 at 11:33AM CDT until June 3 at 2:30PM CDT by NWS Midland/Odessa TX
      FFWMAF The National Weather Service in Midland/Odessa has issued a * Flash Flood Warning for... East Central Culberson County in southwestern Texas... North Central Jeff Davis County in southwestern Texas... Reeves Count…
  - (2026-06-03) [Severe] Flash Flood Warning: Flash Flood Warning issued June 3 at 11:27AM CDT until June 3 at 12:30PM CDT by NWS Midland/Odessa TX
      At 1127 AM CDT /1027 AM MDT/, Doppler radar indicated thunderstorms producing heavy rain across the warned area. Between 0.5 and 1.5 inches of rain have fallen. The expected rainfall rate is 0.5 to 1 inch in 1 hour. Addi…
  - (2026-06-03) [Moderate] Rip Current Statement: Rip Current Statement issued June 3 at 11:26AM CDT until June 7 at 7:00AM CDT by NWS Mobile AL
      * WHAT...For the High Rip Current Risk, dangerous rip currents. For the High Surf Advisory, large breaking waves of 4 to 6 feet expected in the surf zone. * WHERE...In Alabama, Mobile Coastal and Baldwin Coastal Counties…
  - (2026-06-03) [Severe] Red Flag Warning: Red Flag Warning issued June 3 at 10:10AM MDT until June 4 at 7:00PM MDT by NWS Grand Junction CO
      The National Weather Service in Grand Junction has issued a Red Flag Warning for gusty winds, low relative humidity and dry fuels, which is in effect from 1 PM to 7 PM MDT Thursday. * AFFECTED AREA...In Colorado, Fire We…

### Ukrainian Internal News (national + local Kyiv) — 64 new of 130 total
  - (2026-06-03) У Варшаві затримали українця, який зловив легендарного сома у столичному озері | LEDE: ] (uk: У Варшаві затримали українця, який зловив легендарного сома у столичному озері)
  - (2026-06-03) Рубіо: економічні наслідки війни з Іраном менш небезпечні, ніж ядерна зброя Тегерана | LEDE: ] (uk: Рубіо: економічні наслідки війни з Іраном менш небезпечні, ніж ядерна зброя Теге)
  - (2026-06-03) Зеленський: Ми очікуємо на переговорну групу США дуже довго. На жаль, Іран для них – це питання номер один | LEDE: Президент України Володимир Зеленський розчарований тим, що приїзд американськ] (uk:…
      Президент України Володимир Зеленський розчарований тим, що приїзд американської делегації до Києва затягується, але Україна розраховує на цей візит.
  - (2026-06-03) ППО, дрони та 40 тисяч силовиків: ЗМІ дізналися, як Анкара готується до саміту НАТО | LEDE: ] (uk: ППО, дрони та 40 тисяч силовиків: ЗМІ дізналися, як Анкара готується до саміту Н)
  - (2026-06-03) Третій корпус показав "Донбас Арену" та ліквідацію окупантів | LEDE: Третій армійський корпус показав з дрона "Донбас Арену" в тимчасово окупованому Донецьку та ліквідацію росіян на Донеччині т] (uk:…
      Третій армійський корпус показав з дрона "Донбас Арену" в тимчасово окупованому Донецьку та ліквідацію росіян на Донеччині та Луганщині.
  - (2026-06-03) У Києві відбулося засідання Ради Україна-НАТО | LEDE: 3 червня у Києві відбулася зустріч представників України та Північноатлантичного Альянсу у форматі Ради Україна-НАТО, що вперше пройшла в У] (uk:…
      3 червня у Києві відбулася зустріч представників України та Північноатлантичного Альянсу у форматі Ради Україна-НАТО, що вперше пройшла в Україні.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-03) [Puil Kevin] Form 4 (Reporting)
      filed 2026-06-03 16:53 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001104659-26-070015 Size: 13 KB
  - (2026-06-03) [Dakota Gold Corp.] Form 4 (Issuer)
      filed 2026-06-03 16:53 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001104659-26-070015 Size: 13 KB
  - (2026-06-03) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-06-03 16:52 UTC — Filed: 2026-06-03 AccNo: 0001918704-26-015506 Size: 1 MB
  - (2026-06-03) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-06-03 16:52 UTC — Filed: 2026-06-03 AccNo: 0001918704-26-015506 Size: 1 MB
  - (2026-06-03) [Dakota Gold Corp.] Form 4 (Issuer)
      filed 2026-06-03 16:52 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001104659-26-070013 Size: 5 KB
  - (2026-06-03) [O'Rourke Stephen T.] Form 4 (Reporting)
      filed 2026-06-03 16:52 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001104659-26-070013 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-03) [United States] What India , US accomplish together will shape the future , it is
      domain: oklahomacitysun.com · language: English · tone:
  - (2026-06-03) [United States] Thieves are targeting the world copper . This phone company is fighting back
      domain: kzyx.org · language: English · tone:
  - (2026-06-03) [Singapore] CKGSB Opens Applications for Asia Start Program in November 2026 after a Successful May Edition
      domain: singaporestar.com · language: English · tone:
  - (2026-06-03) [India] China PL - 16 Changes the Air Combat Equation ; How India Can Respond
      domain: idrw.org · language: English · tone:
  - (2026-06-03) [Syria] Venezuelas Rodriguez to push energy trade in talks with India
      domain: middleeaststar.com · language: English · tone:
  - (2026-06-03) [United States] Man Charged After Snapchat Encounter in Red Hook
      domain: hudsonvalleycountry.com · language: English · tone:

### U.S. Federal Action — 35 new of 35 total
  - (2026-06-03) Removing Unnecessary and Counterproductive Restrictions on Access to Federal Lands
  - (2026-06-03) Realigning United States Core Childhood Vaccine Recommendations With Best Practices From Peer, Developed Countries
  - (2026-06-03) 1,2-dibromo-3-chloropropane; 1, 3-Butadiene; 13 Carcinogens (4-Nitrobiphenyl, etc.); Acrylonitrile; Asbestos; Benzene; Cadmium; Coke Oven Emissions; Cotton Dust; Ethylene Oxide; Formaldehyde; Inorgani…
      OSHA is scheduling a series of informal public hearings on the above-listed proposed rules. The public hearings will begin on August 19, 2026. All of the proposed rules listed in this notice were published in the Federal…
  - (2026-06-03) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Applications; Change of Sponsor; Change of Sponsor Address; Correction
      The Food and Drug Administration (FDA or we) is amending the final rule that published in the Federal Register of April 16, 2026. That final rule updated regulations to reflect application-related actions for new animal…
  - (2026-06-03) Guidance on Tax-Exempt Refunding Bonds; Hearing
      This document contains proposed regulations that would update certain arbitrage rules and definitions applicable to tax-exempt and other tax-advantaged bonds by clarifying the time and manner for requesting refunds of ov…
  - (2026-06-03) Safety Zone; Fireworks Displays Within the USCG East District (Formerly Fifth Coast Guard District); The Wharf, Washington, DC
      The Coast Guard will enforce a safety zone for a fireworks display at "The Wharf D.C.," in Washington, DC, to provide for the safety of life on navigable waterways during this event. Our regulation for recurring safety z…

### Paper Trading Scorecard — 31 new of 143 total
  - (2026-06-03) [Polymarket] US announces new Iran agreement/ceasefire extension by June 30?
      This market will resolve to “Yes” if the U.S. officially announces an extension of the ceasefire agreement between the U.S. and Iran, defined as a publicly announced commitment to the continued halt of direct military en…
  - (2026-06-03) [Polymarket] SpaceX IPO closing market cap above $4T?
      This market will resolve to “Yes” if the official closing price for SpaceX’s market capitalization on its first trading day is above the value specified in the title. Otherwise, it will resolve to “No”. If no IPO occurs…
  - (2026-06-03) [Polymarket] Will Donald Trump not announce a next United States Attorney General by June 30?
      This market will resolve according to the first individual Donald Trump announces as his pick to be United States Attorney General. An announcement from Donald Trump or the Trump administration stating their intent to no…
  - (2026-06-03) [Polymarket] NATO x Russia military clash by June 30, 2026?
      This market will resolve to "Yes" if there is a military encounter between the military forces of a NATO country and Russia between January 12, and June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".…
  - (2026-06-03) [Polymarket] Predict.fun FDV above $200M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Predict.fun's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-06-03) [Polymarket] Will Jamie Dimon win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…

### GDACS — global disaster alerts — 31 new of 124 total
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-06-03) JAF8LY (Bulgaria)
      icao24: 4520ce · position: (48.7277, 2.3718) · on ground · 2km/h
  - (2026-06-03) PAT251 (United States)
      icao24: adfee0 · position: (32.7328, -102.5833) · alt: 7917m · 450km/h
  - (2026-06-03) NIGER1 (Niger)
      icao24: 062f2e · position: (37.8236, 26.1649) · alt: 11887m · 822km/h
  - (2026-06-03) PAT326 (United States)
      icao24: adfe55 · position: (42.8503, -74.5347) · alt: 7315m · 541km/h
  - (2026-06-03) PAT657 (United States)
      icao24: adfe53 · position: (42.0601, -97.7559) · alt: 7315m · 502km/h
  - (2026-06-03) PAT357 (United States)
      icao24: adfe99 · position: (38.799, -95.6449) · alt: 1706m · 510km/h

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-03) [Japan] We Need To Talk About The Violence In That Wolverine Reveal
      kotaku.com · English
  - (2026-06-03) [Japan] God Of War Will Return To Kratos Eventually After Laufey
      kotaku.com · English
  - (2026-06-03) [Japan] AirPods Pro 3 Deal on Amazon Makes It Feel Like Prime Day Is Already Live , Stock Moves Faster Than Expected
      kotaku.com · English
  - (2026-06-03) [Japan] AT & T will give you a new Motorola Razr flip phone for under $5 / month - how to qualify
      zdnet.com · English
  - (2026-06-03) [Japan] Samsung T7 2TB Portable SSD Drops Again , Looking More Like a Clearance Move Than a Sale on Amazon
      kotaku.com · English
  - (2026-06-03) [Japan] 6 ways I use Spotlight to get more out of my Mac - beyond basic search
      zdnet.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 115 total
  - (2026-06-02) [OFAC] Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question - Office of Foreign Assets Control (.g…
      Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-05-29) [OFAC] 1249 - Office of Foreign Assets Control (.gov)
      1249 Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-06-03) [USASpending] $3,044,069,155 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-06-03) [USASpending] $2,530,079,189 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-06-03) U.S. Court of Appeals, 9th Cir.: Lnu v. Blanche
  - (2026-06-03) U.S. Court of Appeals, 9th Cir.: United States v. Deborba
  - (2026-06-03) Delaware Supreme Court: Camden Foley v. Session Corp.
  - (2026-06-02) U.S. Supreme Court: Allen v. Milligan
  - (2026-06-02) U.S. Court of Appeals, 1st Cir.: United States v. Maldonado
  - (2026-06-02) U.S. Court of Appeals, 7th Cir.: United States v. Thomas Hawkins

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-06-03) M 5.7 - 154 km WSW of Pistol River, Oregon
      M5.7 · 154 km WSW of Pistol River, Oregon · depth 10 km
  - (2026-06-03) M 5.6 - Vanuatu region
      M5.6 · Vanuatu region · depth 10 km
  - (2026-06-03) M 5.1 - 64 km W of Petrolia, CA
      M5.1 · 64 km W of Petrolia, CA · depth 0.150000005960464 km
  - (2026-06-03) M 5.1 - 76 km S of Daroot-Korgon, Kyrgyzstan
      M5.1 · 76 km S of Daroot-Korgon, Kyrgyzstan · depth 10 km
  - (2026-06-03) M 4.9 - Pitcairn Islands region
      M4.9 · Pitcairn Islands region · depth 10 km
  - (2026-06-03) M 4.7 - 142 km SSE of Vilyuchinsk, Russia
      M4.7 · 142 km SSE of Vilyuchinsk, Russia · depth 61.892 km

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-06-03) Will Australia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,056,369 · resolves 2026-07-20
  - (2026-06-03) Roland Garros ATP: Felix Auger-Aliassime vs Flavio Cobolli
      yes price: 36% · 24h volume: $3,759,268 · resolves 2026-06-10
  - (2026-06-03) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,236,405 · resolves 2026-07-20
  - (2026-06-03) Knicks vs. Spurs
      yes price: 36% · 24h volume: $1,666,758 · resolves 2026-06-04
  - (2026-06-03) Will Colombia win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,349,747 · resolves 2026-07-20
  - (2026-06-03) Will the price of Bitcoin be above $66,000 on June 3?
      yes price: 100% · 24h volume: $1,063,087 · resolves 2026-06-03

### Macro indicators — latest values (FRED) — 4 new of 10 total
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-01-01) [Growth] Real GDP (GDPC1)
      latest: 24152.656 as of 2026-01-01
  - (2026-04-01) [Growth] Personal consumption (PCE)
      latest: 21979.4 as of 2026-04-01
  - (2026-05-29) [FX] JPY/USD (DEXJPUS)
      latest: 159.23 as of 2026-05-29

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-03) [Marginal Revolution] Richard Feynman’s formula for the best holiday restaurant
      According to Feynman’s approach, in this context, people should try a different restaurant each night until they find one that exceeds a particular threshold that reflects a desired quality. In Feynman’s equations this t…
  - (2026-06-03) [Marginal Revolution] Sentences to ponder
      In 2019, there were about 150,000 people working in autism therapy. Six years later, there were 654,000—more than the number of people who work in mining and logging, or telecommunications, or at the US Postal Service. T…
  - (2026-06-03) [Marginal Revolution] Consent-based laws and aggregate fertility
      This paper examines how expanding the legal definition of sexual assault affects fertility and sexual behavior, using a panel of European countries. I find that switching to tacit consent-based legislation reduces fertil…
  - (2026-06-02) [Conversable Economist] Does Leniency for First Offenders Pay Off?
      Consider a person who is convicted of a misdemeanor. It is their first offense. Should that person be punished to the full extent of the law, or dealt with more leniently? Depending on one’s prejudices, a theoretical cas…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 40 total
  - (2026-06-03) #29 Jeff Yass — $67.44B
      United States · Finance & Investments · source: Trading, investments
  - (2026-06-03) MOVER ▼ Steve Ballmer — $134.54B ($-0.37B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-06-03) MOVER ▲ Warren Buffett — $140.52B (+$0.23B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-06-03) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: issued, authorized, safety, proposed, personnel, event, within, certain, captain, program, provide, proposing
- state_bills: today=162, 7d-median=155, 14d-median=155; carrying terms: retirement, institutions, traffic, driving, impose, applied, allows, apply, misdemeanor, identified, authorizes, serious
- state_news: today=824, 7d-median=695, 14d-median=708; carrying terms: vaccine, fight, scholarship, budget, bureau, financial, single, kentucky, error, friends, virginians, transgender
- local_news: today=247, 7d-median=247, 14d-median=248; carrying terms: budget, development, local, world, proposal, soccer, large, community, swedish, evening, blank, officer
- foreign_news: today=898, 7d-median=860, 14d-median=864; carrying terms: institutions, civilians, resume, bureau, financial, identified, package, prepares, mianzhu, outbreak, russian, stunt
- chinese_internal: today=290, 7d-median=270, 14d-median=274; carrying terms: cbmizefvx, cbmiykfvx, cbmickfvx, cbmibkfvx, rally, caixin, lxtfa, blank, cbmiw, color, google, cbmia
- russian_internal: today=1124, 7d-median=964, 14d-median=992; carrying terms: spiegel, gazeta, https, politico, financial, europe, title, error, client, reuters, brent, found
- ukrainian_internal: today=130, 7d-median=122, 14d-median=122; carrying terms: injuring, triggered, polish, foreign, civilians, cooperation, armenia, package, error, serious, attack, preparing
- ukraine_theater: today=279, 7d-median=290, 14d-median=299; carrying terms: zdfltdfdfyjjhtknitfnqsmuzngjfyk, tavlzflupendkxekxxdernatvqbxf, beflnly, zyuzqdhbpnu, ofettwjld, anomaly, mhfdys, rmjgqnf, zbklsnflkyvfuz, otemjux, ofbvug, cuxqwwltr
- paper_bets: today=143, 7d-median=143, 14d-median=142; carrying terms: retirement, debut, nomination, earthquake, mamdani, senate, creation, succeed, andrew, visit, signed, resolve
- weather: today=75, 7d-median=107, 14d-median=110; carrying terms: duluth, issued, severe, portion, aviation, storms, prone, caused, shore, remain, francisco, boston
- macro: today=10, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: japan, nikkei, canada, australia, brazil, crypto, nasdaq, kospi, price, sugar, india, natural
- sanctions_procurement: today=115, 7d-median=101, 14d-median=100; carrying terms: leidos, series, flight, description, foreign, https, announce, prohibiting, federation, extra, zimbabwe, beirut
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, https, unauthorized, quiverquant, quantitative, quiver, httperror, error, congresstrading
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: smith, blanche, america, group, castillo, ortiz, veterans, laureano, patria, attorney, general, collins
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, issuer, accno, financial, group, holdings, filer, trust, brian, finance
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cortez, lindsey, graham, brown, robert, ocasio, warner, ossoff, senate, talarico, krishnamoorthi, cycle
- gdelt_regions: today=12, 7d-median=12, 14d-median=12
- gdelt_gkg: today=75, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: language, canada, domain, kingdom, india, english, israel, cancer
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=15, 14d-median=12; carrying terms: ground, position, belgium, bulgaria, canada, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: vendor, service, internet, reader, overwrite, authentication, buffer, denial, based, origin, traversal, premise
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=124, 7d-median=110, 14d-median=110
- usgs_quakes: today=11, 7d-median=10, 14d-median=10
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: peace, permanent, price, resolves, volume, world, bitcoin, garros, ivory, roland, coast, turkiye
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: conversable, https, class, revolution, marginal, economist, marginalrevolution, story, service, paying, people, written
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: biggs, lloyd, mcmahon, casar, anomaly, rosen, weber, acting, padilla, friedman, raskin, wesley
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, markets, placement, module, either, sufficient, identify, decision, converges, consensus, placed, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*