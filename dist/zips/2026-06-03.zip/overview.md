# WORLDSCOPE morning brief — 2026-06-03

## Headline
3020 new items across 27 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (663) · International News + Multilateral Institutions (609) · State-Level News (392) · World leaders & government officials (324) · Chinese Internal News (230) · Local News: St. Louis + Atlanta (197) · Ukraine Theater (total-war monitoring) (154) · U.S. Weather + Severe / Climate Outlooks (69) · Ukrainian Internal News (national + local Kyiv) (64) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40) · U.S. Federal Action (35)

## What changed today
### Russian Internal News (state + in-exile) — 663 new of 1125 total
  - (2026-06-03) «Десятки тысяч погибших — это не абстракция. Это можете быть вы. Вас оставят умирать в грязи». Генсек НАТО предостерег россиян от вербовки на фронт | LEDE: Генеральный секретарь НАТО Марк Рю] (ru: «Де…
      Генеральный секретарь НАТО Марк Рютте обратился к российской молодежи с призывом не поддаваться вербовке на войну. С таким заявлением он выступил во время визита в Киев.
  - (2026-06-03) Патриарх Кирилл отправил в Бразилию митрополита Илариона. Его подозревали в перевозке наркотиков в Чехии | LEDE: Глава Русской православной церкви патриарх Кирилл отправил митрополита Иларио] (ru: Пат…
      Глава Русской православной церкви патриарх Кирилл отправил митрополита Илариона, которого в Чехии заподозрили в перевозке наркотиков, на служение в Аргентинско-Южноамериканскую епархию.
  - (2026-06-03) На ПМЭФ выступили родственницы Путина. Дочь говорила об импортозамещении лекарств, внучатая племянница — о центрах здоровья и рождаемости в РЖД | LEDE: В первый день Петербургского междунаро] (ru: На…
      В первый день Петербургского международного экономического форума на мероприятии выступили две родственницы Владимира Путина: младшая дочь Катерина Тихонова и двоюродная внучатая племянница президента Елена Фисенко.
  - (2026-06-03) В Великобритании протесты и беспорядки из-за убийства 18-летнего Генри Новака. Перед гибелью раненого студента арестовали полицейские, поверив его убийце. Тот заявлял, что сам Новак напал на не] (ru:…
      В Великобритании разгорается скандал вокруг дела об убийстве 18-летнего студента Генри Новака, который погиб в конце 2025 года в Саутгемптоне. Его несколько раз ударил ножом 23-летний Викрам Дигва. 1 июня суд приговорил…
  - (2026-06-03) Удар по Петербургу в день начала ПМЭФ. Z-блогеры — в недоумении, федеральное ТВ — просто молчит. «Илон Маск знал, что на форуме будет его отец, но дроны на „Старлинке“ все равно долетели» | LED] (ru:…
      Украина неслучайно ударила в день старта ПМЭФ. Им плевать, если пострадает кто-то из высоких гостей, а мы боимся бить по Киеву, когда туда приезжают делегации из Европы. Отдельно стоит отметить большое количество видео в…
  - (2026-06-03) Объявлен шорт-лист премии «Большая книга». В него попал роман Маргариты Симоньян (который включили в длинный список задним числом) | LEDE: Литературная премия «Большая книга» опубликовала ко] (ru: Объ…
      Литературная премия «Большая книга» опубликовала короткий список претендентов на награду в 2026 году.

### International News + Multilateral Institutions — 609 new of 855 total
  - (2026-06-03) [Global] 'Both sides are committed' to US-EU trade deal, US Trade Representative Jamieson Greer says
      In an interview with FRANCE 24, US Trade Representative Jamieson Greer insisted that despite fresh US tariffs proposed this Wednesday, "both sides are committed to compliance" with the US-EU trade deal. The top US trade…
  - (2026-06-03) [Global] Months after the regime crackdown, Iranians search for missing protesters
      The deadly crackdown on the December 2025-January 2026 anti-regime protests saw many Iranians killed, tracked or detained. The US-Israel war on Iran has intensified the repression, but it has not stopped families from tr…
  - (2026-06-03) [Global] Japan: Modern-day samurais battle new foe: Climate change
      It is a tradition that dates back a thousand years and has survived wars, earthquakes and even a nuclear disaster. But in recent years, Japan’s Soma Nomaoi samurai festival has found itself under threat from a new enemy:…
  - (2026-06-03) [Global] Director Wim Wenders pulls 1975 film featuring then-teenager Nastassja Kinski in nude scene
      German director Wim Wenders announced Wednesday that he would be pulling his 1975 film “Wrong Move” from circulation due to a scene in which actress Nastassja Kinski, then a teenager, appeared topless.
  - (2026-06-03) [Global] 'US war on Iran not about the Iranian people: Europe can put the issue of human rights on the table'
      Nadia Massih is pleased to welcome Mahmood Amiry-Moghaddam, President of Iran Human Rights and Professor of Neuroscience at University of Oslo. He offers a stark assessment of the Iranian regime's response to recent unre…
  - (2026-06-03) [Global] Iranian Revolutionary Guards claim attacks on Bahrain and Kuwait
      The already fragile ceasefire between Iran and the US has come under strain following a series of attacks from Iran in the Gulf and from the US on Qeshm Island. The Iranian attacks killed one person and injured 63 others…

### State-Level News — 392 new of 827 total
  - (2026-06-02) [Alabama] Flags Lowered Honoring Former State Senator John Emanuel Amari
      Download
  - (2026-06-03) [Connecticut] CT GOP candidate defiant in face of criticism for anti-gay post
      <img width="1024" height="671" src="https://ctmirror.org/wp-content/uploads/2026/06/3D37AC1D-422B-4703-9459-F3E41951067F-1024x671.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=…
  - (2026-06-03) [Connecticut] Here are the 6 things the CT-Puerto Rico Trade Commission will focus on
      <img width="1024" height="732" src="https://ctmirror.org/wp-content/uploads/2026/06/CTPublic_PR-Trade-Commission-1024x732.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-06-03) [Connecticut] CT lawmakers rejected 3-year bachelor’s degrees. But the trend isn’t going away
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/AP24178495361034-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy…
  - (2026-06-03) [Connecticut] More education funds, no funding formula reform
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/05/Shepard-Fisher-4.21.26-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading…
  - (2026-06-03) [Connecticut] When schools lose the people who came back to serve them
      <img width="870" height="572" src="https://ctmirror.org/wp-content/uploads/2026/04/Sand-school.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="https…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 230 new of 289 total
  - (2026-06-02) Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes - Caixin Global
      Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes Caixin Global
  - (2026-06-03) Growth Conversation: Chris Kyme on the local pioneers of the HK advertising industry
  - (2026-06-03) China’s fund managers face new rules to curb risky investment strategies
  - (2026-06-03) Jiangsu 11.5b yuan brokerage merger marks new phase of consolidation
  - (2026-06-03) Tesla’s China sales surge to 2026 high, but rivals crowd the rear-view mirror
  - (2026-06-03) Global oil stockpiles could fall to ‘critical levels’ by summer, IEA warns

### Local News: St. Louis + Atlanta — 197 new of 246 total
  - (2026-06-03) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-06-03) [St. Louis] NIH researchers charged with attempting to smuggle vials of mpox virus into the US
      Both worked at NIH's Rocky Mountain Lab in Montana, where they conducted research involving emerging viral pathogens and how diseases cross from animals to humans.
  - (2026-06-03) [St. Louis] NHL's 'Stanley Pup,' featuring 32 dogs competing, is back for a third year
      The 'Stanley Pup' special will premiere in the United States and Canada on Monday, June 8.
  - (2026-06-03) [St. Louis] Frontier flight diverted after passenger tried to open door, choke off-duty flight attendant, police say
      Passengers, including one who trains in jiu-jitsu, helped restrain the 51-year-old man until the plane landed in Miami.
  - (2026-06-03) [St. Louis] Man charged in deadly shooting in Loretta Hall Park
      Police said that while the victim was lying on the ground, Perry stood over him and shot him again.
  - (2026-06-03) [St. Louis] Who's winning the governor's race in California? Check the latest results
      Track the results from the 2026 California gubernatorial primary election with this interactive map:

### Ukraine Theater (total-war monitoring) — 154 new of 279 total
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.107 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.87 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.111 (FRP 0.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.51 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.295, 25.110 (FRP 1.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 1.04 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.849, 29.988 (FRP 2.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 2.77 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.701, 31.867 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 0.8 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.361, 33.954 (FRP 1.23 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 1.23 MW

### U.S. Weather + Severe / Climate Outlooks — 69 new of 74 total
  - (2026-06-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-03) [Severe] Flash Flood Warning: Flash Flood Warning issued June 3 at 11:33AM CDT until June 3 at 2:30PM CDT by NWS Midland/Odessa TX
      FFWMAF The National Weather Service in Midland/Odessa has issued a * Flash Flood Warning for... East Central Culberson County in southwestern Texas... North Central Jeff Davis County in southwestern Texas... Reeves Count…
  - (2026-06-03) [Severe] Flash Flood Warning: Flash Flood Warning issued June 3 at 11:27AM CDT until June 3 at 12:30PM CDT by NWS Midland/Odessa TX
      At 1127 AM CDT /1027 AM MDT/, Doppler radar indicated thunderstorms producing heavy rain across the warned area. Between 0.5 and 1.5 inches of rain have fallen. The expected rainfall rate is 0.5 to 1 inch in 1 hour. Addi…
  - (2026-06-03) [Moderate] Rip Current Statement: Rip Current Statement issued June 3 at 11:26AM CDT until June 7 at 7:00AM CDT by NWS Mobile AL
      * WHAT...For the High Rip Current Risk, dangerous rip currents. For the High Surf Advisory, large breaking waves of 4 to 6 feet expected in the surf zone. * WHERE...In Alabama, Mobile Coastal and Baldwin Coastal Counties…
  - (2026-06-03) [Severe] Red Flag Warning: Red Flag Warning issued June 3 at 10:10AM MDT until June 4 at 7:00PM MDT by NWS Grand Junction CO
      The National Weather Service in Grand Junction has issued a Red Flag Warning for gusty winds, low relative humidity and dry fuels, which is in effect from 1 PM to 7 PM MDT Thursday. * AFFECTED AREA...In Colorado, Fire We…
  - (2026-06-03) [Unknown] Air Quality Alert: Air Quality Alert issued June 3 at 9:09AM MST by NWS Phoenix AZ
      AQAPSR The Arizona Department of Environmental Quality (ADEQ) has issued an Ozone High Pollution Advisory for the Phoenix Metro Area today. This means that forecast weather conditions combined with existing ozone levels…

### Ukrainian Internal News (national + local Kyiv) — 64 new of 130 total
  - (2026-06-03) Greece Files Protest With Kyiv Over Armed Ukrainian Sea Drone Found Near Lefkada
      Athens on Wednesday submitted an official diplomatic protest to Kyiv over a naval drone found off the Greek island of Lefkada in May. Greek authorities said the explosive-laden vessel posed risks to civilian traffic and…
  - (2026-06-03) ‘Nothing Stops Ukrainian Art’ – Met Opera Chief Peter Gelb
      Peter Gelb, general manager of New York’s Metropolitan Opera, told Kyiv Post about the institution’s support for Ukraine since Russia’s full-scale invasion. He reflected on Ukraine’s resilience, the role of culture in wa…
  - (2026-06-03) Ukraine to Deliver Record 1,500 Motorcycles to Frontline Troops in 2026
      Ukraine’s Defense Procurement Agency on Wednesday signed a contract for 1,500 motorcycles for the Armed Forces, three times last year’s total motorbike buy. The contract was awarded through a competitive tender process t…
  - (2026-06-03) Ukraine Is Doing Better: Notes From the Sidelines of the Black Sea Security Forum 2026
      There were many important discussions at the Black Sea Security Forum 2026 regarding security and Ukraine’s possible future strategies. However, the most important takeaway was optimism. Everyone shared the same assessme…
  - (2026-06-03) WATCH: Ukraine’s Fire Point Tests Missile for Homegrown Anti-Ballistic Shield as Air Defense Shortages Bite
      Ukrainian defense company Fire Point has successfully tested its FP-7.X missile, which will serve as the basis for the planned FREYJA anti-ballistic defense system, providing Kyiv with a lower-cost alternative to Patriot…
  - (2026-06-03) Finland Seizes €3.7 Million in Russian Funds to Compensate Naftogaz
      Finland’s National Enforcement Authority has frozen nearly €4 million belonging to Russia following a compensation claim by Naftogaz. The funds are part of a broader effort to enforce an international arbitration ruling…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Lebanon - Israel Clashes Resume Amid Ceasefire Breach
      athens-times.com · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Iran , US Exchange Attacks Amid Uncertainty In Peace Talks
      middleeaststar.com · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Iran , US Exchange Attacks As Tensions In Gulf Rise
      middleeaststar.com · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Trump confirms call rebuking Netanyahu : I was a little bit perturbed
      wsbt.com · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] The Lebanon escalation : Netanyahu is betting Trump cant stop him
      middleeaststar.com · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Hezbollah launches rockets at Israel , testing U . S .- mediated deal
      yahoo.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-03) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-06-03 17:10 UTC — Filed: 2026-06-03 AccNo: 0001918704-26-015513 Size: 1 MB
  - (2026-06-03) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-06-03 17:10 UTC — Filed: 2026-06-03 AccNo: 0001918704-26-015513 Size: 1 MB
  - (2026-06-03) [Batista de Lima Filho Pedro] Form 4 (Reporting)
      filed 2026-06-03 17:10 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001213900-26-064584 Size: 23 KB
  - (2026-06-03) [AXIA Energia S.A.] Form 4 (Issuer)
      filed 2026-06-03 17:10 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001213900-26-064584 Size: 23 KB
  - (2026-06-03) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-03 17:09 UTC — Filed: 2026-06-03 AccNo: 0001213900-26-064583 Size: 2 MB
  - (2026-06-03) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-03 17:09 UTC — Filed: 2026-06-03 AccNo: 0001213900-26-064583 Size: 2 MB

### U.S. Federal Action — 35 new of 35 total
  - (2026-06-03) Removing Unnecessary and Counterproductive Restrictions on Access to Federal Lands
  - (2026-06-03) Realigning United States Core Childhood Vaccine Recommendations With Best Practices From Peer, Developed Countries
  - (2026-06-03) 1,2-dibromo-3-chloropropane; 1, 3-Butadiene; 13 Carcinogens (4-Nitrobiphenyl, etc.); Acrylonitrile; Asbestos; Benzene; Cadmium; Coke Oven Emissions; Cotton Dust; Ethylene Oxide; Formaldehyde; Inorgani…
      OSHA is scheduling a series of informal public hearings on the above-listed proposed rules. The public hearings will begin on August 19, 2026. All of the proposed rules listed in this notice were published in the Federal…
  - (2026-06-03) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Applications; Change of Sponsor; Change of Sponsor Address; Correction
      The Food and Drug Administration (FDA or we) is amending the final rule that published in the Federal Register of April 16, 2026. That final rule updated regulations to reflect application-related actions for new animal…
  - (2026-06-03) Guidance on Tax-Exempt Refunding Bonds; Hearing
      This document contains proposed regulations that would update certain arbitrage rules and definitions applicable to tax-exempt and other tax-advantaged bonds by clarifying the time and manner for requesting refunds of ov…
  - (2026-06-03) Safety Zone; Fireworks Displays Within the USCG East District (Formerly Fifth Coast Guard District); The Wharf, Washington, DC
      The Coast Guard will enforce a safety zone for a fireworks display at "The Wharf D.C.," in Washington, DC, to provide for the safety of life on navigable waterways during this event. Our regulation for recurring safety z…

### Paper Trading Scorecard — 31 new of 143 total
  - (2026-06-03) [Polymarket] US announces new Iran agreement/ceasefire extension by June 30?
      This market will resolve to “Yes” if the U.S. officially announces an extension of the ceasefire agreement between the U.S. and Iran, defined as a publicly announced commitment to the continued halt of direct military en…
  - (2026-06-03) [Polymarket] SpaceX IPO closing market cap above $4T?
      This market will resolve to “Yes” if the official closing price for SpaceX’s market capitalization on its first trading day is above the value specified in the title. Otherwise, it will resolve to “No”. If no IPO occurs…
  - (2026-06-03) [Polymarket] Will Donald Trump not announce a next United States Attorney General by June 30?
      This market will resolve according to the first individual Donald Trump announces as his pick to be United States Attorney General. An announcement from Donald Trump or the Trump administration stating their intent to no…
  - (2026-06-03) [Polymarket] NATO x Russia military clash by June 30, 2026?
      This market will resolve to "Yes" if there is a military encounter between the military forces of a NATO country and Russia between January 12, and June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".…
  - (2026-06-03) [Polymarket] Predict.fun FDV above $200M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Predict.fun's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-06-03) [Polymarket] Will Bitcoin reach $90,000 in June?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…

### GDACS — global disaster alerts — 31 new of 124 total
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-06-03) PAT251 (United States)
      icao24: adfee0 · position: (32.4113, -103.864) · alt: 7917m · 417km/h
  - (2026-06-03) NIGER1 (Niger)
      icao24: 062f2e · position: (38.5891, 28.7085) · alt: 11887m · 829km/h
  - (2026-06-03) PAT326 (United States)
      icao24: adfe55 · position: (41.5498, -75.4282) · alt: 4777m · 493km/h
  - (2026-06-03) PAT657 (United States)
      icao24: adfe53 · position: (43.2701, -98.4756) · alt: 7315m · 487km/h
  - (2026-06-03) PAT479 (United States)
      icao24: adfe4a · position: (31.2805, -90.2904) · alt: 5128m · 498km/h
  - (2026-06-03) PAT745 (United States)
      icao24: adfe8e · position: (44.8561, -101.6042) · alt: 7315m · 414km/h

### Court opinions of consequence (federal & state) — 12 new of 60 total
  - (2026-06-03) U.S. Court of Appeals, 3rd Cir.: Secretary United States Department of Labor v. Comprehensive Healthcare Management Services LLC
  - (2026-06-03) Delaware Supreme Court: Camden Foley v. Session Corp.
  - (2026-06-03) U.S. Court of Appeals, 9th Cir.: Lnu v. Blanche
  - (2026-06-03) U.S. Court of Appeals, 9th Cir.: United States v. Deborba
  - (2026-06-02) U.S. Supreme Court: Allen v. Milligan
  - (2026-06-02) U.S. Court of Appeals, 1st Cir.: United States v. Maldonado

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-06-03) M 5.7 - 154 km WSW of Pistol River, Oregon
      M5.7 · 154 km WSW of Pistol River, Oregon · depth 10 km
  - (2026-06-03) M 5.6 - Vanuatu region
      M5.6 · Vanuatu region · depth 10 km
  - (2026-06-03) M 5.1 - 64 km W of Petrolia, CA
      M5.1 · 64 km W of Petrolia, CA · depth 0.150000005960464 km
  - (2026-06-03) M 5.1 - 76 km S of Daroot-Korgon, Kyrgyzstan
      M5.1 · 76 km S of Daroot-Korgon, Kyrgyzstan · depth 10 km
  - (2026-06-03) M 4.9 - 58 km NNE of Labuan Bajo, Indonesia
      M4.9 · 58 km NNE of Labuan Bajo, Indonesia · depth 178.883 km
  - (2026-06-03) M 4.9 - Pitcairn Islands region
      M4.9 · Pitcairn Islands region · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 115 total
  - (2026-06-02) [OFAC] Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question - Office of Foreign Assets Control (.g…
      Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-05-29) [OFAC] 1249 - Office of Foreign Assets Control (.gov)
      1249 Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-06-03) [USASpending] $3,044,069,155 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-06-03) [USASpending] $2,530,079,189 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-06-03) Will Australia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,057,943 · resolves 2026-07-20
  - (2026-06-03) Roland Garros ATP: Felix Auger-Aliassime vs Flavio Cobolli
      yes price: 36% · 24h volume: $3,906,452 · resolves 2026-06-10
  - (2026-06-03) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,233,846 · resolves 2026-07-20
  - (2026-06-03) Knicks vs. Spurs
      yes price: 36% · 24h volume: $1,689,172 · resolves 2026-06-04
  - (2026-06-03) Will Colombia win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,348,266 · resolves 2026-07-20
  - (2026-06-03) Will Oh Se-hoon win the 2026 Seoul Mayoral Election
      yes price: 6% · 24h volume: $1,091,066 · resolves 2026-06-03

### Congressional STOCK Act Trades (House + Senate) — 8 new of 49 total
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess +0.6% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess +0.6% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-07) [Senate] Sheldon Whitehouse (D): Sale (Partial) ORCL ($15,001 - $50,000) (excess +21.9% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: ORCL (Stock). Type: Sale (Partial). Amount range: $15,001 - $50,000. Transaction date: 2026-05-07. Disclosure date: 2026-06-02. Excess return vs SPY since…
  - (2026-05-15) [House] Virginia Foxx (R): Purchase ARLP ($1,001 - $15,000) (excess -1.3% vs SPY)
      Member: Virginia Foxx (R, house). BioGuide: F000450. Asset: ARLP (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-06-02. Excess return vs SPY since disclosure: -1.…
  - (2026-05-08) [House] Kevin Hern (R): Exchange DVN ($15,001 - $50,000) (excess -1.6% vs SPY)
      Member: Kevin Hern (R, house). BioGuide: H001082. Asset: DVN (ST). Type: Exchange. Amount range: $15,001 - $50,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY since disclosure: -1.64%…
  - (2026-05-08) [House] Kevin Hern (R): Exchange CTRA ($15,001 - $50,000)
      Member: Kevin Hern (R, house). BioGuide: H001082. Asset: CTRA (ST). Type: Exchange. Amount range: $15,001 - $50,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Description: COTERRA MERGED INTO DEVON.

### Macro indicators — latest values (FRED) — 4 new of 10 total
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-04-01) [Labor] Job openings (JOLTS) (JTSJOL)
      latest: 7618 as of 2026-04-01
  - (2026-05-29) [FX] EUR/USD (DEXUSEU)
      latest: 1.1679 as of 2026-05-29
  - (2026-06-02) [Vol] VIX (S&P 500 implied vol) (VIXCLS)
      latest: 15.77 as of 2026-06-02

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 40 total
  - (2026-06-03) #29 Jeff Yass — $67.44B
      United States · Finance & Investments · source: Trading, investments
  - (2026-06-03) MOVER ▲ Warren Buffett — $141.21B (+$0.69B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway
  - (2026-06-03) MOVER ▲ Rob Walton & family — $136.02B (+$0.34B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-06-03) MOVER ▲ Jim Walton & family — $133.31B (+$0.34B since yesterday)
      United States · Fashion & Retail · source: Walmart

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-03) [Marginal Revolution] Richard Feynman’s formula for the best holiday restaurant
      According to Feynman’s approach, in this context, people should try a different restaurant each night until they find one that exceeds a particular threshold that reflects a desired quality. In Feynman’s equations this t…
  - (2026-06-03) [Marginal Revolution] Sentences to ponder
      In 2019, there were about 150,000 people working in autism therapy. Six years later, there were 654,000—more than the number of people who work in mining and logging, or telecommunications, or at the US Postal Service. T…
  - (2026-06-03) [Marginal Revolution] Consent-based laws and aggregate fertility
      This paper examines how expanding the legal definition of sexual assault affects fertility and sexual behavior, using a panel of European countries. I find that switching to tacit consent-based legislation reduces fertil…
  - (2026-06-02) [Conversable Economist] Does Leniency for First Offenders Pay Off?
      Consider a person who is convicted of a misdemeanor. It is their first offense. Should that person be punished to the full extent of the law, or dealt with more leniently? Depending on one’s prejudices, a theoretical cas…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 19 total
  - (2026-06-03) CVE-2026-45247 · Mirasvit Mirasvit Full Page Cache Warmer: Mirasvit Full Page Cache Warmer Deserialization of Untrusted Data Vulnerability
      vendor: Mirasvit · product: Mirasvit Full Page Cache Warmer · CISA remediation by 2026-06-06

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: coast, action, marine, provide, proposing, event, authorized, service, address, vessels, regulatory, personnel
- state_bills: today=0, 7d-median=155, 14d-median=148
- state_news: today=827, 7d-median=695, 14d-median=708; carrying terms: course, process, livestock, vtdigger, critical, schools, texas, nears, voting, seeking, promises, affordable
- local_news: today=246, 7d-median=246, 14d-median=247; carrying terms: around, prices, security, officials, oxzbxtxk, stars, culture, articles, injured, america, media, crash
- foreign_news: today=855, 7d-median=855, 14d-median=858; carrying terms: defensive, process, critical, schools, shunxin, remarks, authorities, preset, demands, sueddeutsche, seldom, guiyang
- chinese_internal: today=289, 7d-median=270, 14d-median=274; carrying terms: cbmia, cbmiykfvx, articles, cbmidefvx, cbmiakfvx, cbmiyefvx, cbmib, target, lxtfb, caixin, lxtfa, google
- russian_internal: today=1125, 7d-median=964, 14d-median=992; carrying terms: euroclear, reuters, found, garros, press, novaya, title, novayagazeta, china, group, politico, russian
- ukrainian_internal: today=130, 7d-median=122, 14d-median=122; carrying terms: linked, rights, partners, multiple, responsibility, attacks, logistics, independent, casualties, sanctions, future, occupied
- ukraine_theater: today=279, 7d-median=290, 14d-median=299; carrying terms: emfpa, xbhlszujdtm, uahbks, ynvsaje, cfjhzwrjc, snfqz, schools, oxcwhrbzfoa, mtfpn, proven, delegat, lpzxfhsuvcovnmmjvzowzqvnb
- paper_bets: today=143, 7d-median=143, 14d-median=142; carrying terms: another, andrew, access, movie, named, speaker, previousl, season, perform, lifetime, texas, democratic
- weather: today=74, 7d-median=107, 14d-median=110; carrying terms: affecting, scattered, cyclone, midnight, outdoor, currents, afdbox, danger, chance, afdlsx, continue, minor
- macro: today=10, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: india, equity, cotton, sugar, italy, kospi, crypto, index, china, japan, copper, france
- sanctions_procurement: today=115, 7d-median=101, 14d-median=100; carrying terms: laboratory, tunisia, jihad, rights, schools, ukraine, contractor, authorities, democratic, measures, adopted, taliban
- congressional_trades: today=49, 7d-median=40, 14d-median=20; carrying terms: stock, rycey, babin, moore, return, taylor, evans, dwight, auchincloss, package, distribution, senate
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: vasquez, bondi, america, blanche, smith, group, ortiz, veterans, castillo, attorney, laureano, general
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, accno, reporting, financial, holdings, jpmorgan, chase, filer, trust, scott, finance
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: alexandria, cycle, talarico, committee, joshua, ocasio, graham, jonathan, cortez, congress, senate, disbursements
- gdelt_regions: today=12, 7d-median=12, 14d-median=12
- gdelt_gkg: today=50, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=15, 14d-median=12; carrying terms: position, ground, belgium, kingdom, canada, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=19, 7d-median=16, 14d-median=16; carrying terms: directx, overflow, injection, based, traversal, adobe, denial, drupal, internet, product, buffer, windows
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=124, 7d-median=110, 14d-median=110
- usgs_quakes: today=12, 7d-median=10, 14d-median=10
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, peace, world, resolves, permanent, bitcoin, coast, ivory, roland, garros, turkiye
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: class, revolution, marginal, economist, conversable, https, marginalrevolution, story, paying, service, people, screen
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: crank, tammy, aaron, latta, pfluger, darren, elena, hageman, womack, kevin, moran, waller
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, claude, unavailable, identify, markets, placed, module, paper, today, placement, converges, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*