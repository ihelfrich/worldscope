# WORLDSCOPE morning brief — 2026-06-03

## Headline
2874 new items across 28 active section(s) (of 41 tracked).

## Top movers today
International News + Multilateral Institutions (580) · Russian Internal News (state + in-exile) (572) · World leaders & government officials (324) · State-Level News (308) · Chinese Internal News (230) · Local News: St. Louis + Atlanta (177) · GDELT GKG — themes / entities / watch areas (115) · Ukraine Theater (total-war monitoring) (107) · State Legislative Action (76) · U.S. Weather + Severe / Climate Outlooks (71) · Ukrainian Internal News (national + local Kyiv) (52) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 580 new of 866 total
  - (2026-06-03) [Global] US and Iran launch new strikes, as Kuwait says airport hit by Iranian drones
      Kuwait says one person is dead after drones hit civilian buildings including its international airport.
  - (2026-06-03) [Global] Seven killed after drone hits bus in Russia-controlled part of Ukraine
      The bus was travelling between Moscow and Simferopol, in Russian-occupied Crimea, an official says.
  - (2026-06-02) [Global] Putin remains uncompromising on Ukraine, but is public discourse on war changing in Russia?
      Russia is intensifying attacks in Ukraine but more than four years of war are causing concern even among Putin loyalists.
  - (2026-06-03) [Global] Shell pumped oil through Nigeria pipeline for years despite pollution evidence, documents show
      The oil giant says the documents ignore the critical context of the complex operating environment at the time.
  - (2026-06-03) [Global] Trump administration drops $1.8bn 'anti-weaponisation' fund
      Acting Attorney General Todd Blanche's announcement to abandon the fund comes amid pushback from top Republican lawmakers.
  - (2026-06-03) [Global] Foreign nationals among at least 21 killed in Delhi fire
      Many victims were South Asians who had travelled to India for treatment or to accompany relatives.

### Russian Internal News (state + in-exile) — 572 new of 1059 total
  - (2026-06-03) В правительстве Германии увидели «окно для диалога» между Россией и Европой | LEDE: Между Россией и Европой медленно «открывается окно для диалога» о российско-украинской войне, но до начала] (ru: В п…
      Между Россией и Европой медленно «открывается окно для диалога» о российско-украинской войне, но до начала переговоров, вероятно, пройдут месяцы. Об этом, как передает Reuters, заявил на брифинге неназванный представител…
  - (2026-06-03) Марию Пономаренко приговорили почти к двум годам по делу о «нападении на сотрудника колонии». Это третий приговор журналистке за три года | LEDE: Рубцовский городской суд Алтайского края при] (ru: Мар…
      Рубцовский городской суд Алтайского края приговорил журналистку Марию Пономаренко к одному году и 10 месяцам лишения свободы по обвинению «в применении насилия в отношении сотрудника колонии, не опасного для жизни и здор…
  - (2026-06-03) В детском лагере под Нижним Тагилом установили памятник Дзержинскому | LEDE: В поселке Черноисточинск под Нижним Тагилом открыли бюст основателя и первого руководителя ВЧК Феликса Дзержинско] (ru: В д…
      В поселке Черноисточинск под Нижним Тагилом открыли бюст основателя и первого руководителя ВЧК Феликса Дзержинского. Об этом сообщил депутат городской думы Нижнего Тагила от «Единой России» Дмитрий Костенников, который б…
  - (2026-06-03) В праймериз «Единой России» приняли участие 478 участников войны — победил каждый десятый. На самом деле это не простые военные, а опытные политики. «Надо показать президенту новую элиту. И пос] (ru:…
      «Единая Россия» завершила праймериз перед выборами в Государственную Думу. Партия власти и политблок администрации президента (АП) недовыполнили поставленные самим себе KPI в 10% явки от общего количества избирателей в Р…
  - (2026-06-03) Bloomberg: Путин отказался вмешиваться в дело Вадима Мошковича. Бизнесмена обвиняют в мошенничестве, его холдинг «Русагро» национализировали | LEDE: Владимир Путин отказался вмешиваться в де] (ru: Blo…
      Владимир Путин отказался вмешиваться в дело основателя «Русагро», одного из богатейших людей России Вадима Мошковича, пишет Bloomberg.
  - (2026-06-03) Российская разведка обвинила Евросоюз в «выдавливании» РПЦ из Армении | LEDE: Служба внешней разведки (СВР) России утверждает, что Евросоюз поставил перед Арменией условие о «полном разрыве ] (ru: Рос…
      Служба внешней разведки (СВР) России утверждает, что Евросоюз поставил перед Арменией условие о «полном разрыве многовековых религиозно-духовных связей» с Москвой ради евроинтеграции. По мнению разведки, ЕС «агрессивно в…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 308 new of 757 total
  - (2026-06-02) [California] Who’s winning California’s statewide races? Here’s what we know so far
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Chico-Elections_SO_CM_07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-06-02) [California] Resultados electorales de California en directo
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/election_results_featured.png?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-06-02) [California] Hilton y Becerra abren ventaja preliminaria en primarias para gobernador de California
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226-Becerra-Hilton-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-06-02) [California] Shaw, Barrera take commanding lead in state superintendent race
      <img width="1024" height="703" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/092623-Sonja-Shaw-GETTY-CM-01.jpg?fit=1024%2C703&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-06-02) [California] Kim, Allen lead in California insurance watchdog race
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226-JaneKim-02-BL-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="A…
  - (2026-06-02) [California] Will Trump’s waning popularity pull down California Republicans? Tuesday’s election offers a clue
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/062422-State-Capitol-MG-CM-03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### Chinese Internal News — 230 new of 285 total
  - (2026-06-02) Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes - Caixin Global
      Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes Caixin Global
  - (2026-06-03) “俄版达沃斯”开幕前，圣彼得堡遭乌无人机袭击 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9kS2U0dHcwbGNpdnVYakkzN1hSYmdOOVl6WjNCMC0yVW13SDBaN0R1bDM3MW1jX0FHWjY4Y2w1X0hUc0huNmRBVkZRMHE3MW] (zh:…
      “俄版达沃斯”开幕前，圣彼得堡遭乌无人机袭击 观察者
  - (2026-06-03) 左脚踩右脚，硅谷AI融资的钱，最后流到谁手里？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9CS182OF9LMTFhb2o1d3JiNi13UE43bDc0QVFRS2VnR1RtMENram9GUmNzUEx4eURETERCMmxqQXdnZFhEV0VybExLRnBhV] (zh:…
      左脚踩右脚，硅谷AI融资的钱，最后流到谁手里？ 观察者
  - (2026-06-03) 一台3D打印机，为什么让开源社区吵翻了？-科工力量-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTFBpZkhmSDdrMXJVZUhmUmVROUZBR3JRNzZqT1BQYnR1d0U2bU5McXJBcXVoak5OUGQxZE1nNWpsOWd3UG1iQW9sN0] (zh:…
      一台3D打印机，为什么让开源社区吵翻了？-科工力量-观察者网 观察者
  - (2026-06-03) 坏了，这下特朗普都反犹了 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1QV0Ezcy1qRmFyR1lPaHVMN0xkd0JMTmlINGpMVC13eWNGZGdJemlWVEw1U2JWR0ExMmllNlhDN3VDWF8zOTJBaVpCMmZDTkVFQ1dONElsR] (zh:…
      坏了，这下特朗普都反犹了 风闻
  - (2026-06-03) 苏州人不吃蟹黄面，青岛人不吃海肠捞饭 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE9yM2lQU3dsRlFSbVc2R1drYzdTUFBKRGU5S3otMjVRc2RzbHF4cnVHalp1b3VaN25mZWp2QWk4bWhJSTdTVDNyb3lhS1hmcUZnZUF] (zh:…
      苏州人不吃蟹黄面，青岛人不吃海肠捞饭 风闻

### Local News: St. Louis + Atlanta — 177 new of 244 total
  - (2026-06-03) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-06-03) [St. Louis] Hotel workers in Seattle threaten strike ahead of World Cup crowds: 'We're very serious'
      More than 100 Embassy Suites employees will vote whether to authorize a strike. About 750,000 visitors are expected in the city for the 2026 FIFA World Cup games.
  - (2026-06-03) [St. Louis] Meet the 2026 Gerber Baby: Minnesota infant wins nationwide photo search
      The winner's family will receive $50,000, and he’ll appear in Gerber ads and social media campaigns throughout the year.
  - (2026-06-03) [St. Louis] George Santos reported to prosecutors over suspicious Kalshi trades, AP source says
      The prediction marketplace Kalshi detected trades made by Santos ahead of Trump's State of the Union address, a source told AP.
  - (2026-06-03) [St. Louis] Diane Keaton's personal collection hits auction block, including iconic 'Annie Hall' pieces
      A collection of more than 50 lots, titled "Diane Keaton: Architecture of an Icon," will go up for auction on Monday, June 8.
  - (2026-06-03) [St. Louis] Iran and the US trade strikes in the Persian Gulf, further testing the ceasefire
      Talks have dragged on for weeks, and repeated exchanges of strikes in the Gulf region and Israel’s broadening war in Lebanon are further straining the efforts.

### GDELT GKG — themes / entities / watch areas — 115 new of 115 total
  - (2026-06-03) [Russia oil sanctions perimeter · themes] Brasil tem contraste climático nesta quarta - feira com temporais no Norte e Nordeste e tempo seco no Centro - Oeste
      jornaldebrasilia.com.br · Portuguese · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] 4 denizde DENİZKURDU Tatbikatı
      haberler.com · Turkish · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] Rusza rosyjskie Davos . Wcześniej w miasto uderzyły drony Ukrainy
      money.pl · Polish · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] 兴通股份 ( 603209 ): 兴通海运股份有限公司关于子公司投资建造4艘13 , 000载重吨不锈钢化学品船舶的进展公告 - CFi . CN 中财网
      cfi.net.cn · Chinese · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] Τραμπ : Το Ιράν συμφώνησε να μην έχει πυρηνικά όπλα - Ενοχλήθηκα με Νετανιάχου
      tanea.gr · Greek · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] Jens Stoltenberg , Budsjettforhandlinger | Advarsel fra eksperter : Norge bruker for mye oljepenger
      nettavisen.no · Norwegian · tone NA

### Ukraine Theater (total-war monitoring) — 107 new of 276 total
  - (2026-06-03) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.107 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.87 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.111 (FRP 0.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.51 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.295, 25.110 (FRP 1.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 1.04 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.849, 29.988 (FRP 2.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 2.77 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.701, 31.867 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 0.8 MW

### State Legislative Action — 76 new of 158 total
  - (2026-06-03) [Alaska SB 280] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughp…
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re…
  - (2026-06-02) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-06-02) [Alaska SB 9] An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
      An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
  - (2026-06-02) [Alaska HB 14] MED ASSIST;INSURANCE;DISABILITY/WORK COMP
      MED ASSIST;INSURANCE;DISABILITY/WORK COMP
  - (2026-06-03) [Arizona SB 1235] EMS reciprocity; compact.
      EMS reciprocity; compact.
  - (2026-06-03) [Arizona SB 1497] classical learning; tests; examinations
      classical learning; tests; examinations

### U.S. Weather + Severe / Climate Outlooks — 71 new of 77 total
  - (2026-06-03) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued June 3 at 7:51AM EDT until June 3 at 8:00PM EDT by NWS Wakefield VA
      * WHAT...High risk of rip currents expected. * WHERE...Eastern Currituck County. * WHEN...Through this evening. * IMPACTS...Dangerous swimming and surfing conditions. Breaking waves of 4 ft or greater can cause neck and…
  - (2026-06-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-03) [Severe] Flash Flood Warning: Flash Flood Warning issued June 3 at 6:40AM CDT until June 3 at 8:45AM CDT by NWS Midland/Odessa TX
      At 640 AM CDT, Doppler radar indicated thunderstorms producing heavy rain across the warned area. Between 1 and 2 inches of rain have fallen. Additional rainfall amounts up to 1 inch are possible in the warned area. Flas…
  - (2026-06-03) [Moderate] Gale Watch: Gale Watch issued June 3 at 4:20AM PDT until June 5 at 6:00AM PDT by NWS Eureka CA
      * WHAT...For the Small Craft Advisory, northwest winds 20 to 30 kt with gusts up to 40 kt and seas 6 to 9 feet expected. For the Gale Watch, northwest winds 20 to 30 kt with gusts up to 40 kt and seas 7 to 12 feet possib…
  - (2026-06-03) [Moderate] Gale Warning: Gale Warning issued June 3 at 4:20AM PDT until June 5 at 6:00AM PDT by NWS Eureka CA
      * WHAT...For the Gale Warning, north winds 25 to 30 kt with gusts up to 40 kt and seas 8 to 13 feet expected. For the Small Craft Advisory, north winds 20 to 25 kt with gusts up to 35 kt and seas 7 to 10 feet expected. *…
  - (2026-06-03) [Severe] Flash Flood Warning: Flash Flood Warning issued June 3 at 6:19AM CDT until June 3 at 8:15AM CDT by NWS Midland/Odessa TX
      At 619 AM CDT, Doppler radar indicated moderate to heavy rain across the warned area. Between 1 and 2 inches of rain have fallen. Additional rainfall amounts up to half an inch are possible in the warned area. Flash floo…

### Ukrainian Internal News (national + local Kyiv) — 52 new of 118 total
  - (2026-06-03) СБУ: На Харківщині затримали 17-річного студента, якому обіцяли вбити вітчима за шпигунство на користь РФ | LEDE: На Харківщині затримали 17-річного студента професійного коледжу, якого підозрю] (uk:…
      На Харківщині затримали 17-річного студента професійного коледжу, якого підозрюють у передачі представнику РФ даних про місця перебування українських військових на Ізюмському напрямку.
  - (2026-06-03) Трамп заявив, що Іран відмовився від створення ядерної зброї, хоча може й передумати | LEDE: Трамп заявив, що Іран погодився не створювати ядерну зброю, а переговори тривають.] (uk: Трамп заявив, що І…
      Трамп заявив, що Іран погодився не створювати ядерну зброю, а переговори тривають.
  - (2026-06-03) Прем’єр Угорщини вимагає, щоб Орбан взяв відповідальність за рейд проти інкасаторів Ощадбанку | LEDE: Мадяр заявив, що Орбан ініціював рейд проти Ощадбанку для тиску на Україну та має взяти від] (uk:…
      Мадяр заявив, що Орбан ініціював рейд проти Ощадбанку для тиску на Україну та має взяти відповідальність.
  - (2026-06-03) Росіяни вдарили дроном по будинку на Сумщині – убили чоловіка і поранили його матір | LEDE: Одна людина загинула та одна постраждала внаслідок удару російського безпілотника по житловому будинк] (uk:…
      Одна людина загинула та одна постраждала внаслідок удару російського безпілотника по житловому будинку у Сумській області 3 червня.
  - (2026-06-03) "Трансфер до Словаччини через ліс": на Закарпатті викрили незаконну схему | LEDE: Правоохоронці ліквідували на Закарпатті канал незаконного переправлення чоловіків призовного віку через українс] (uk:…
      Правоохоронці ліквідували на Закарпатті канал незаконного переправлення чоловіків призовного віку через українсько-словацький кордон.
  - (2026-06-03) Зеленський обурився, що контракт на постачання "Петріотів" не готовий і пригрозив кадровими висновками | LEDE: Президент Зеленський вимагає пришвидшити контракт по Patriot та дав тиждень на під] (uk:…
      Президент Зеленський вимагає пришвидшити контракт по Patriot та дав тиждень на підготовчі кроки, інакше — кадрові рішення.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-03) 497K - Tidal Trust II (0001924868) (Filer)
      filed 2026-06-03 11:51 UTC — Filed: 2026-06-03 AccNo: 0001999371-26-011927 Size: 152 KB
  - (2026-06-03) [Ge Grace Xin] Form 4 (Reporting)
      filed 2026-06-03 11:51 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001673358-26-000082 Size: 4 KB
  - (2026-06-03) [Yum China Holdings, Inc.] Form 4 (Issuer)
      filed 2026-06-03 11:51 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001673358-26-000082 Size: 4 KB
  - (2026-06-03) [Wei Zhe David] Form 4 (Reporting)
      filed 2026-06-03 11:49 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001673358-26-000081 Size: 4 KB
  - (2026-06-03) [Yum China Holdings, Inc.] Form 4 (Issuer)
      filed 2026-06-03 11:49 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001673358-26-000081 Size: 4 KB
  - (2026-06-03) [Jacobs Bruce N.] Form 4 (Reporting)
      filed 2026-06-03 11:30 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001193125-26-254589 Size: 6 KB

### U.S. Federal Action — 35 new of 35 total
  - (2026-06-03) Removing Unnecessary and Counterproductive Restrictions on Access to Federal Lands
  - (2026-06-03) Realigning United States Core Childhood Vaccine Recommendations With Best Practices From Peer, Developed Countries
  - (2026-06-03) 1,2-dibromo-3-chloropropane; 1, 3-Butadiene; 13 Carcinogens (4-Nitrobiphenyl, etc.); Acrylonitrile; Asbestos; Benzene; Cadmium; Coke Oven Emissions; Cotton Dust; Ethylene Oxide; Formaldehyde; Inorgani…
      OSHA is scheduling a series of informal public hearings on the above-listed proposed rules. The public hearings will begin on August 19, 2026. All of the proposed rules listed in this notice were published in the Federal…
  - (2026-06-03) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Applications; Change of Sponsor; Change of Sponsor Address; Correction
      The Food and Drug Administration (FDA or we) is amending the final rule that published in the Federal Register of April 16, 2026. That final rule updated regulations to reflect application-related actions for new animal…
  - (2026-06-03) Guidance on Tax-Exempt Refunding Bonds; Hearing
      This document contains proposed regulations that would update certain arbitrage rules and definitions applicable to tax-exempt and other tax-advantaged bonds by clarifying the time and manner for requesting refunds of ov…
  - (2026-06-03) Safety Zone; Fireworks Displays Within the USCG East District (Formerly Fifth Coast Guard District); The Wharf, Washington, DC
      The Coast Guard will enforce a safety zone for a fireworks display at "The Wharf D.C.," in Washington, DC, to provide for the safety of life on navigable waterways during this event. Our regulation for recurring safety z…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 29 new of 146 total
  - (2026-06-03) [Polymarket] US announces new Iran agreement/ceasefire extension by June 30?
      This market will resolve to “Yes” if the U.S. officially announces an extension of the ceasefire agreement between the U.S. and Iran, defined as a publicly announced commitment to the continued halt of direct military en…
  - (2026-06-03) [Polymarket] SpaceX IPO closing market cap above $4T?
      This market will resolve to “Yes” if the official closing price for SpaceX’s market capitalization on its first trading day is above the value specified in the title. Otherwise, it will resolve to “No”. If no IPO occurs…
  - (2026-06-03) [Polymarket] Predict.fun FDV above $200M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Predict.fun's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-06-03) [Polymarket] Will Jamie Dimon win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-06-03) [Polymarket] NATO x Russia military clash by June 30, 2026?
      This market will resolve to "Yes" if there is a military encounter between the military forces of a NATO country and Russia between January 12, and June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".…
  - (2026-06-03) [Polymarket] Will Donald Trump not announce a next United States Attorney General by June 30?
      This market will resolve according to the first individual Donald Trump announces as his pick to be United States Attorney General. An announcement from Donald Trump or the Trump administration stating their intent to no…

### GDACS — global disaster alerts — 29 new of 124 total
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-02) [Green] Tropical Cyclone ONE-E-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 102 km/h)
  - (2026-06-02) [Green] Tropical Cyclone ONE-E-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 102 km/h)

### Government & military aircraft airborne (OpenSky) — 28 new of 29 total
  - (2026-06-03) JAF50T (Bulgaria)
      icao24: 4520ce · position: (39.5551, -4.2095) · alt: 11277m · 858km/h
  - (2026-06-03) GAF606 (Germany)
      icao24: 3f6533 · position: (51.8737, 13.2133) · alt: 7658m · 725km/h
  - (2026-06-03) SAMBA50 (Italy)
      icao24: 320055 · position: (41.863, 12.8598) · alt: 632m · 228km/h
  - (2026-06-03) FNY55D5 (France)
      icao24: 39a407 · position: (47.829, -3.2294) · alt: 6728m · 771km/h
  - (2026-06-03) JAF7TJ (Belgium)
      icao24: 44d1ba · position: (50.8571, 3.9246) · alt: 6842m · 800km/h
  - (2026-06-03) JAF35D (Belgium)
      icao24: 44d1a5 · position: (50.6368, 3.9996) · alt: 3733m · 596km/h

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-03) [Japan] Why Im sticking with Firefox as my browser - after years of using Chrome , Edge , and Safari
      zdnet.com · English
  - (2026-06-03) [Japan] Dead touchscreen ? This Android tool lets you extract files from an unresponsive phone
      zdnet.com · English
  - (2026-06-03) [Japan] 8 ways I optimize Zorin OS for peak performance - from a decades - long Linux user
      zdnet.com · English
  - (2026-06-03) [Japan] How AI agents will transform your customer service - despite 3 hurdles
      zdnet.com · English
  - (2026-06-03) [Japan] How to Decipher June Most Popular Emoji
      cnet.com · English
  - (2026-06-03) [Japan] Thaksin granted royal pardon , regains freedom
      asia.nikkei.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 114 total
  - (2026-06-02) [OFAC] Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question - Office of Foreign Assets Control (.g…
      Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-05-29) [OFAC] 1249 - Office of Foreign Assets Control (.gov)
      1249 Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-06-03) [USASpending] $3,044,069,155 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-06-03) [USASpending] $2,530,079,189 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-06-03) Roland Garros WTA: Anna Kalinskaya vs Maja Chwalinska
      yes price: 0% · 24h volume: $2,258,008 · resolves 2026-06-09
  - (2026-06-03) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,010,533 · resolves 2026-07-20
  - (2026-06-03) Knicks vs. Spurs
      yes price: 36% · 24h volume: $1,150,709 · resolves 2026-06-04
  - (2026-06-03) Will USA win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $927,309 · resolves 2026-07-20
  - (2026-06-03) LoL: EDward Gaming vs Bilibili Gaming (BO5) - LPL Playoffs
      yes price: 0% · 24h volume: $914,432 · resolves 2026-06-03
  - (2026-06-03) Will Czechia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $863,537 · resolves 2026-07-20

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. James
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. Squire
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. Duran-Gonzalez
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: Von Derhaar v. Watson
  - (2026-06-02) U.S. Supreme Court: Allen v. Milligan
  - (2026-06-02) U.S. Court of Appeals, 1st Cir.: United States v. Maldonado

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 40 total
  - (2026-06-03) #29 Jeff Yass — $67.44B
      United States · Finance & Investments · source: Trading, investments
  - (2026-06-03) #30 Germán Larrea Mota Velasco & family — $66.88B
      Mexico · Metals & Mining · source: Mining · holdings: GMXT-MX(MEXICO), GMEXICOB-MX(MEXICO), SCCO-US(NYSE)
  - (2026-06-03) MOVER ▲ Amancio Ortega — $141.18B (+$4.51B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-06-03) MOVER ▼ Masayoshi Son — $96.90B ($-3.49B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-06-03) MOVER ▼ Bernard Arnault & family — $146.43B ($-1.40B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-06-03) MOVER ▼ Gautam Adani — $87.09B ($-1.33B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### USGS earthquakes (M4.5+, past day) — 7 new of 8 total
  - (2026-06-03) M 5.7 - 154 km WSW of Pistol River, Oregon
      M5.7 · 154 km WSW of Pistol River, Oregon · depth 10 km
  - (2026-06-03) M 5.6 - Vanuatu region
      M5.6 · Vanuatu region · depth 10 km
  - (2026-06-03) M 5.1 - 76 km S of Daroot-Korgon, Kyrgyzstan
      M5.1 · 76 km S of Daroot-Korgon, Kyrgyzstan · depth 10 km
  - (2026-06-03) M 4.9 - Pitcairn Islands region
      M4.9 · Pitcairn Islands region · depth 10 km
  - (2026-06-03) M 4.6 - 77 km SE of Ozernovskiy, Russia
      M4.6 · 77 km SE of Ozernovskiy, Russia · depth 62.18 km
  - (2026-06-03) M 4.6 - 6 km NW of El Cortezo, Panama
      M4.6 · 6 km NW of El Cortezo, Panama · depth 10 km

### Macro indicators — latest values (FRED) — 5 new of 8 total
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-04-01) [Inflation] CPI Core (ex food & energy, SA) (CPILFESL)
      latest: 335.423 as of 2026-04-01
  - (2026-04-01) [Labor] Job openings (JOLTS) (JTSJOL)
      latest: 7618 as of 2026-04-01
  - (2026-01-01) [Growth] Real GDP (GDPC1)
      latest: 24152.656 as of 2026-01-01
  - (2026-05-29) [FX] JPY/USD (DEXJPUS)
      latest: 159.23 as of 2026-05-29

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-06-03) [Marginal Revolution] Sentences to ponder
      In 2019, there were about 150,000 people working in autism therapy. Six years later, there were 654,000—more than the number of people who work in mining and logging, or telecommunications, or at the US Postal Service. T…
  - (2026-06-03) [Marginal Revolution] Consent-based laws and aggregate fertility
      This paper examines how expanding the legal definition of sexual assault affects fertility and sexual behavior, using a panel of European countries. I find that switching to tacit consent-based legislation reduces fertil…
  - (2026-06-02) [Marginal Revolution] Big if true
      Several important questions — such as the possibility of debt-rollover without primary surpluses — turn on whether the present value of the aggregate endowment is finite, i.e., whether the economic growth rate under the…
  - (2026-06-02) [Conversable Economist] Does Leniency for First Offenders Pay Off?
      Consider a person who is convicted of a misdemeanor. It is their first offense. Should that person be punished to the full extent of the law, or dealt with more leniently? Depending on one’s prejudices, a theoretical cas…

### Congressional STOCK Act Trades (House + Senate) — 3 new of 44 total
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess +0.6% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess +0.6% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-07) [Senate] Sheldon Whitehouse (D): Sale (Partial) ORCL ($15,001 - $50,000) (excess +21.9% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: ORCL (Stock). Type: Sale (Partial). Amount range: $15,001 - $50,000. Transaction date: 2026-05-07. Disclosure date: 2026-06-02. Excess return vs SPY since…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: within, provide, needed, proposed, event, waters, marine, program, regulatory, issued, enforcement, proposing
- state_bills: today=158, 7d-median=155, 14d-median=155; carrying terms: injury, requesting, equity, motor, value, teachers, constitution, provided, additionally, physicians, materials, within
- state_news: today=757, 7d-median=695, 14d-median=708; carrying terms: graduates, history, persist, closed, jeffrey, srcset, announced, forward, dakota, virginians, extraordinary, continued
- local_news: today=244, 7d-median=246, 14d-median=247; carrying terms: history, murder, color, dsbhzzzxgyckrzuy, multiple, everything, station, series, soccer, among, cbmiqwfbvv, washington
- foreign_news: today=866, 7d-median=860, 14d-median=863; carrying terms: judges, injury, graduates, history, speed, packing, httpsconnectionpool, square, wuhan, announced, remember, forward
- chinese_internal: today=285, 7d-median=270, 14d-median=274; carrying terms: cbmix, color, cbmickfvx, cbmibkfvx, articles, google, caixin, lxtfa, cbmia, rally, people, lxtfb
- russian_internal: today=1059, 7d-median=964, 14d-median=992; carrying terms: euroclear, novaya, client, error, international, httperror, financial, bloomberg, associated, gazeta, press, brent
- ukrainian_internal: today=118, 7d-median=122, 14d-median=122; carrying terms: commander, production, nearly, institute, polish, latest, httperror, invasion, contracts, regions, missiles, costs
- ukraine_theater: today=276, 7d-median=290, 14d-median=299; carrying terms: lwnln, lxzrd, history, production, bthyelg, kxntfkuvj, dxvgzhtegxv, bhyztq, uzdtnngzzwu, demining, announced, ntrhym
- paper_bets: today=146, 7d-median=143, 14d-median=142; carrying terms: speaker, speed, whether, control, michigan, individual, achieve, following, scheduled, successor, israel, candle
- weather: today=77, 7d-median=107, 14d-median=110; carrying terms: boston, moving, counties, objects, florida, result, forestry, weekend, below, formation, holly, beach
- macro: today=8, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: price, canada, crypto, kospi, equity, merval, shanghai, index, brazil, italy, china, natural
- sanctions_procurement: today=114, 7d-median=101, 14d-median=100; carrying terms: prohibited, cbmiqkfvx, ruaulkefbwvuxpz, institute, space, square, engineering, human, taliban, ztwgwxqzvywvd, embargo, transnistrian
- congressional_trades: today=44, 7d-median=40, 14d-median=20; carrying terms: souhy, bernardo, package, purchase, stock, dwight, moreno, senate, auchincloss, excess, david, compensation
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: blanche, smith, bondi, vasquez, group, veterans, ortiz, castillo, gregory, collins, buckley, garcia
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, david, financial, holdings, group, chase, jpmorgan, filer, trust
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: joshua, filing, joseph, congress, graham, senate, booker, angels, raised, house, disbursements, michael
- gdelt_regions: today=12, 7d-median=12, 14d-median=12
- gdelt_gkg: today=115, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=29, 7d-median=15, 14d-median=12; carrying terms: ground, position, belgium, bulgaria, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: buffer, directory, defender, following, overflow, product, vendor, denial, microsoft, bypass, adobe, injection
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=124, 7d-median=110, 14d-median=110
- usgs_quakes: today=8, 7d-median=8, 14d-median=8
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, world, volume, peace, permanent, resolves, bitcoin, ivory, coast, garros, roland, turkiye
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, economist, https, marginal, class, conversable, policy, story, marginalrevolution, interview, analysis, required
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: topic, coney, boston, dingell, roberts, crawford, rochester, perry, norman, darin, maria, harris
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, placement, claude, consensus, markets, converges, either, module, placed, decision, market, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*