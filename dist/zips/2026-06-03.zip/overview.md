# WORLDSCOPE morning brief — 2026-06-03

## Headline
3193 new items across 29 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (704) · International News + Multilateral Institutions (632) · State-Level News (385) · World leaders & government officials (324) · Chinese Internal News (231) · Local News: St. Louis + Atlanta (208) · Ukraine Theater (total-war monitoring) (122) · State Legislative Action (76) · GDELT GKG — themes / entities / watch areas (75) · U.S. Weather + Severe / Climate Outlooks (68) · Ukrainian Internal News (national + local Kyiv) (64) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 704 new of 1169 total
  - (2026-06-03) Патриарх Кирилл отправил в Бразилию митрополита Илариона. Его подозревали в перевозке наркотиков в Чехии | LEDE: Глава Русской православной церкви патриарх Кирилл отправил митрополита Иларио] (ru: Пат…
      Глава Русской православной церкви патриарх Кирилл отправил митрополита Илариона, которого в Чехии заподозрили в перевозке наркотиков, на служение в Аргентинско-Южноамериканскую епархию.
  - (2026-06-03) На ПМЭФ выступили родственницы Путина. Дочь говорила об импортозамещении лекарств, внучатая племянница — о центрах здоровья и рождаемости в РЖД | LEDE: В первый день Петербургского междунаро] (ru: На…
      В первый день Петербургского международного экономического форума на мероприятии выступили две родственницы Владимира Путина: младшая дочь Катерина Тихонова и двоюродная внучатая племянница президента Елена Фисенко.
  - (2026-06-03) В Великобритании протесты и беспорядки из-за убийства 18-летнего Генри Новака. Перед гибелью раненого студента арестовали полицейские, поверив его убийце. Тот заявлял, что сам Новак напал на не] (ru:…
      В Великобритании разгорается скандал вокруг дела об убийстве 18-летнего студента Генри Новака, который погиб в конце 2025 года в Саутгемптоне. Его несколько раз ударил ножом 23-летний Викрам Дигва. 1 июня суд приговорил…
  - (2026-06-03) Удар по Петербургу в день начала ПМЭФ. Z-блогеры — в недоумении, федеральное ТВ — просто молчит. «Илон Маск знал, что на форуме будет его отец, но дроны на „Старлинке“ все равно долетели» | LED] (ru:…
      Украина неслучайно ударила в день старта ПМЭФ. Им плевать, если пострадает кто-то из высоких гостей, а мы боимся бить по Киеву, когда туда приезжают делегации из Европы. Отдельно стоит отметить большое количество видео в…
  - (2026-06-03) Объявлен шорт-лист премии «Большая книга». В него попал роман Маргариты Симоньян (который включили в длинный список задним числом) | LEDE: Литературная премия «Большая книга» опубликовала ко] (ru: Объ…
      Литературная премия «Большая книга» опубликовала короткий список претендентов на награду в 2026 году.
  - (2026-06-03) «Закулисье реальности» — хоррор, в котором источником ужаса становится мебель. Режиссеру Кейну Парсонсу всего 20 лет, но его фильм уже стал прокатным хитом | LEDE: В мировой прокат вышел фил] (ru: «За…
      В мировой прокат вышел фильм «Закулисье реальности» («Backrooms») Кейна Парсонса — 20-летнего ютьюбера, который обратился в своей работе к интернет-легендам. В частности, он изучает явление «лиминальных пространств» — не…

### International News + Multilateral Institutions — 632 new of 878 total
  - (2026-06-03) [Global] Kidnappings, threats and ‘protection fees’: how can Mexico confront rise in deadly extortion?
  - (2026-06-02) [Global] Trump administration proposes 25% tariffs on Brazil despite US trade surplus
  - (2026-06-02) [Global] Cricket Canada suspended over allegations of gang-linked corruption
  - (2026-06-03) [Global] Diphtheria outbreak: residents of remote NT community say health clinic has no hand sanitiser
  - (2026-06-03) [Global] NSW motorists who use medicinal cannabis may soon be able to drive without fear of major penalty
  - (2026-06-03) [Global] Anti-abortion activists are trying to limit access in NSW – and they are just getting started

### State-Level News — 385 new of 821 total
  - (2026-06-02) [Alabama] Flags Lowered Honoring Former State Senator John Emanuel Amari
      Download
  - (2026-06-03) [Alaska] Dutch Harbor Remembrance Day 2026
      WHEREAS, on June 3, 1942, six months after the attack on Pearl Harbor, World War II arrived in Alaska when Dutch Harbor on Amaknak Island was bombed by Japanese – the first aerial attack by an enemy on the continental Un…
  - (2026-06-03) [California] Governor Newsom announces judicial appointments 6.2.2026
      Source
  - (2026-06-02) [California] Trump is still trying to rob victims to pay criminals for their political support
      Source
  - (2026-06-01) [California] Governor Newsom issues legislative update 6.1.26
  - (2026-06-03) [California] ¿Quiénes van ganando en las elecciones estatales de California? Esto es lo que sabemos hasta ahora
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Chico-Elections_SO_CM_07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 231 new of 290 total
  - (2026-06-02) Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes - Caixin Global
      Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes Caixin Global
  - (2026-06-03) 从市长到主席边升官边敛财 62岁正省级女高官王莉霞将受审 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE45QnNra2tNWkNrMHVSNTc4WVJSR2dFQk5kemRqcnQycmNZdF80ZzlDbXdMUHJsZ1dhb0VTRkVCdWJ] (zh:…
      从市长到主席边升官边敛财 62岁正省级女高官王莉霞将受审 china.caixin.com
  - (2026-06-02) 老虎证券6月12日起将停止存量用户中国境内开仓加仓 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0tUVVvbGVEWXRrdWFac1RUMVhHeHVIWTZidDVfNDA4dzAwbjBqczlaRGFrYUlpejc3d1BueDlENTNSckFsMThQTE9EczVf] (zh:…
      老虎证券6月12日起将停止存量用户中国境内开仓加仓 财新
  - (2026-06-03) 美国史上最广301调查公布：拟对60个经济体加征10%或12.5%的关税 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9rcEZZVUVwQVFCUVE5M2xoVno2T2gzcXJYVkhwVW9KMml0MDYwb2dFNlpKNm55QUtSZ1dnMmpzLWkwbV9iY] (zh:…
      美国史上最广301调查公布：拟对60个经济体加征10%或12.5%的关税 财新
  - (2026-06-03) 超越美债，黄金成全球官方储备第一大资产 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9mekp5dEl1M3d5X19vNktPcjFvRjh3MnRPTlVaUnF4MFJxVWJRdlBYOUdLNlVRMWN0Zy1zakZoM0FoYlN1emloTThOV3NhWDczY0] (zh:…
      超越美债，黄金成全球官方储备第一大资产 财新
  - (2026-06-02) “耿同学”打假再有战果 《自然》答财新：正评估相关信息 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBfQ0pxMW9nS2d6b0RkLWY1TTlYR1BaOGltMXloRHVpZWlxM3lTaUcxLUd6ckJBMTExSVRWajBUbXBRcVJMQjJYLV9VZj] (zh:…
      “耿同学”打假再有战果 《自然》答财新：正评估相关信息 财新

### Local News: St. Louis + Atlanta — 208 new of 259 total
  - (2026-06-03) [St. Louis] Is the St. Charles Farmers Market the most kid-friendly in the region?
      A change in location may have been all the St. Charles Farmers Market needed to become one of the area’s most family-friendly weekend destinations. This season, the market packed up its produce, parted ways with the City…
  - (2026-06-03) [St. Louis] A house in Wildwood hits the market
      Thoughtful Design Built in 2019, the residence was conceived with an intuitive floor plan, striking details, and carefully considered design elements. Cape Cod-InspiredThis four-bedroom, five-bathroom home is as charming…
  - (2026-06-03) [St. Louis] Police Board’s big raises mean an even bigger increase for St. Louis’ fire department
      On Monday night, the state-appointed Board of Police Commissioners proposed significant pay increases for high-ranking officers: 16 percent for lieutenants, 18 percent for captains, 20 percent for majors, and 22 percent…
  - (2026-06-03) [St. Louis] Broadway star Kate Baldwin helps Opera Theatre of Saint Louis expand its horizons in a glorious show
      One of Broadway’s big stars is in St. Louis this summer, but she’s not at The Muny. Two-time Tony Award nominee Kate Baldwin is starring in The Light in the Piazza as it makes its debut at Opera Theatre of Saint Louis. I…
  - (2026-06-03) [St. Louis] Now is the time to build up the riverfront, civic and business leaders say
      The portion of the Mississippi River that lines St. Louis’ downtown has long felt like an afterthought for the city, but civic and business leaders say the moment now is as good as any to spur riverfront revitalization.…
  - (2026-06-03) [St. Louis] Busch Family Brewing & Distilling in Defiance to remain closed for 2026 season
      After two seasons of brewing beer, bronco busting at monthly Saturday night rodeos, pouring its signature Bridlespur Bourbon, and drawing crowds for country-themed parties and events, Busch Family Brewing & Distilling (4…

### Ukraine Theater (total-war monitoring) — 122 new of 279 total
  - (2026-06-03) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.107 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.87 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.111 (FRP 0.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.51 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.295, 25.110 (FRP 1.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 1.04 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.849, 29.988 (FRP 2.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 2.77 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.701, 31.867 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 0.8 MW

### State Legislative Action — 76 new of 158 total
  - (2026-06-03) [Alaska SB 280] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughp…
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re…
  - (2026-06-02) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-06-02) [Alaska SB 9] An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
      An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
  - (2026-06-02) [Alaska HB 14] MED ASSIST;INSURANCE;DISABILITY/WORK COMP
      MED ASSIST;INSURANCE;DISABILITY/WORK COMP
  - (2026-06-03) [Arizona SB 1235] EMS reciprocity; compact.
      EMS reciprocity; compact.
  - (2026-06-03) [Arizona SB 1497] classical learning; tests; examinations
      classical learning; tests; examinations

### GDELT GKG — themes / entities / watch areas — 75 new of 75 total
  - (2026-06-03) [Russia oil sanctions perimeter · keywords] Dozens of Azerbaijan Companies Manage Russian Shadow Fleet Tankers
      occrp.org · English · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · keywords] Joint training of NATO Special Operations Forces - Radio Romania International
      rri.ro · English · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · keywords] Hungary Ends Two - Year Block on Ukraine Arms Payouts
      kyivpost.com · English · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · keywords] Russia Ships Most Oil Since 2022 as Drones Strike Refineries
      finance.yahoo.com · English · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · keywords] Story of Russian ruble : Fueled from abroad , drained from within
      dailysabah.com · English · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · keywords] Putin humiliated as £120m warship deployed in English Channel blown up by Ukraine | World | News
      express.co.uk · English · tone NA

### U.S. Weather + Severe / Climate Outlooks — 68 new of 73 total
  - (2026-06-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-03) [Severe] Red Flag Warning: Red Flag Warning issued June 3 at 10:10AM MDT until June 4 at 7:00PM MDT by NWS Grand Junction CO
      The National Weather Service in Grand Junction has issued a Red Flag Warning for gusty winds, low relative humidity and dry fuels, which is in effect from 1 PM to 7 PM MDT Thursday. * AFFECTED AREA...In Colorado, Fire We…
  - (2026-06-03) [Unknown] Air Quality Alert: Air Quality Alert issued June 3 at 9:09AM MST by NWS Phoenix AZ
      AQAPSR The Arizona Department of Environmental Quality (ADEQ) has issued an Ozone High Pollution Advisory for the Phoenix Metro Area today. This means that forecast weather conditions combined with existing ozone levels…
  - (2026-06-03) [Moderate] Special Weather Statement: Special Weather Statement issued June 3 at 10:57AM CDT by NWS Duluth MN
      Dry conditions and breezy winds will lead to near critical fire weather conditions today. Southerly winds of 10 to 20 mph with gusts of 20 to 25 mph are forecast for today. Minimum relative humidity values of 20 to 30 pe…
  - (2026-06-03) [Moderate] Gale Warning: Gale Warning issued June 3 at 8:40AM PDT until June 5 at 6:00AM PDT by NWS Eureka CA
      * WHAT...For the Gale Warning, north winds 25 to 30 kt with gusts up to 40 kt and seas 8 to 13 feet expected. For the Small Craft Advisory, north winds 20 to 25 kt with gusts up to 35 kt and seas 7 to 10 feet expected. *…
  - (2026-06-03) [Moderate] Gale Warning: Gale Warning issued June 3 at 8:40AM PDT until June 5 at 6:00AM PDT by NWS Eureka CA
      * WHAT...For the Gale Warning, northwest winds 20 to 30 kt with gusts up to 40 kt and seas 7 to 12 feet expected. For the Small Craft Advisory, northwest winds 20 to 30 kt with gusts up to 40 kt and seas 6 to 9 feet expe…

### Ukrainian Internal News (national + local Kyiv) — 64 new of 130 total
  - (2026-06-03) У Києві відбулося засідання Ради Україна-НАТО | LEDE: 3 червня у Києві відбулася зустріч представників України та Північноатлантичного Альянсу у форматі Ради Україна-НАТО, що вперше пройшла в У] (uk:…
      3 червня у Києві відбулася зустріч представників України та Північноатлантичного Альянсу у форматі Ради Україна-НАТО, що вперше пройшла в Україні.
  - (2026-06-03) Трамп підтвердив, що вилаяв Нетаньягу під час телефонної розмови | LEDE: ] (uk: Трамп підтвердив, що вилаяв Нетаньягу під час телефонної розмови)
  - (2026-06-03) Зеленський і Рютте відреагували на проблему дронів ЗСУ, що залітають у простір НАТО | LEDE: Україна надасть державам НАТО, де знаходили українські дрони, допомогу у захисті їхнього повітряного ] (uk:…
      Україна надасть державам НАТО, де знаходили українські дрони, допомогу у захисті їхнього повітряного простору.
  - (2026-06-03) Макрон прийняв Мадяра і заявив про підготовку стратегічного партнерства з Угорщиною | LEDE: ] (uk: Макрон прийняв Мадяра і заявив про підготовку стратегічного партнерства з Угорщи)
  - (2026-06-03) Ворог атакував Краматорськ: троє вбитих, четверо поранених мирних жителів | LEDE: Троє людей загинули, а четверо дістали поранення внаслідок ворожого удару по Краматорську Донецької області.] (uk: Вор…
      Троє людей загинули, а четверо дістали поранення внаслідок ворожого удару по Краматорську Донецької області.
  - (2026-06-03) Зеленський: Я готовий до прямих перемовин з Путіним, щоб завершити цю війну | LEDE: Президент України Володимир Зеленський повідомив, що готовий провести прямі перемовини з правителем РФ Володи] (uk:…
      Президент України Володимир Зеленський повідомив, що готовий провести прямі перемовини з правителем РФ Володимиром Путіним, щоби завершити цю війну.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-03) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-06-03 16:22 UTC — Filed: 2026-06-03 AccNo: 0001839882-26-027669 Size: 481 KB
  - (2026-06-03) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-06-03 16:22 UTC — Filed: 2026-06-03 AccNo: 0001918704-26-015503 Size: 545 KB
  - (2026-06-03) [Ginn Kirk Edwards] Form 4 (Reporting)
      filed 2026-06-03 16:20 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001193125-26-254987 Size: 4 KB
  - (2026-06-03) [Atlas Energy Solutions Inc.] Form 4 (Issuer)
      filed 2026-06-03 16:20 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001193125-26-254987 Size: 4 KB
  - (2026-06-03) [GRASSI LOUIS C] Form 4 (Reporting)
      filed 2026-06-03 16:19 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001004702-26-000085 Size: 5 KB
  - (2026-06-03) [OCEANFIRST FINANCIAL CORP] Form 4 (Issuer)
      filed 2026-06-03 16:19 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001004702-26-000085 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-03) [United States] Jonah Goldberg : Trump is stuck between two realities . Neither serves the American people
      domain: morningjournal.com · language: English · tone:
  - (2026-06-03) [United States] FBI personnel have fatally shot a man holding hostages in Bakersfield , California , police say
      domain: 13wmaz.com · language: English · tone:
  - (2026-06-03) [United States] Redding Chico Eureka
      domain: krcrtv.com · language: English · tone:
  - (2026-06-03) [United States] Temple Beth Emet starts Holocaust Survivor Day celebration early in Cooper City
      domain: local10.com · language: English · tone:
  - (2026-06-03) [United States] Cruise Passenger Hailed As Hero For Jumping Into Water To Save Elderly Man
      domain: magic1079.iheart.com · language: English · tone:
  - (2026-06-03) [United States] A mystery beetle is devouring North Carolina precious blueberries
      domain: popsci.com · language: English · tone:

### U.S. Federal Action — 35 new of 35 total
  - (2026-06-03) Removing Unnecessary and Counterproductive Restrictions on Access to Federal Lands
  - (2026-06-03) Realigning United States Core Childhood Vaccine Recommendations With Best Practices From Peer, Developed Countries
  - (2026-06-03) 1,2-dibromo-3-chloropropane; 1, 3-Butadiene; 13 Carcinogens (4-Nitrobiphenyl, etc.); Acrylonitrile; Asbestos; Benzene; Cadmium; Coke Oven Emissions; Cotton Dust; Ethylene Oxide; Formaldehyde; Inorgani…
      OSHA is scheduling a series of informal public hearings on the above-listed proposed rules. The public hearings will begin on August 19, 2026. All of the proposed rules listed in this notice were published in the Federal…
  - (2026-06-03) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Applications; Change of Sponsor; Change of Sponsor Address; Correction
      The Food and Drug Administration (FDA or we) is amending the final rule that published in the Federal Register of April 16, 2026. That final rule updated regulations to reflect application-related actions for new animal…
  - (2026-06-03) Guidance on Tax-Exempt Refunding Bonds; Hearing
      This document contains proposed regulations that would update certain arbitrage rules and definitions applicable to tax-exempt and other tax-advantaged bonds by clarifying the time and manner for requesting refunds of ov…
  - (2026-06-03) Safety Zone; Fireworks Displays Within the USCG East District (Formerly Fifth Coast Guard District); The Wharf, Washington, DC
      The Coast Guard will enforce a safety zone for a fireworks display at "The Wharf D.C.," in Washington, DC, to provide for the safety of life on navigable waterways during this event. Our regulation for recurring safety z…

### Paper Trading Scorecard — 32 new of 144 total
  - (2026-06-03) [Polymarket] US announces new Iran agreement/ceasefire extension by June 30?
      This market will resolve to “Yes” if the U.S. officially announces an extension of the ceasefire agreement between the U.S. and Iran, defined as a publicly announced commitment to the continued halt of direct military en…
  - (2026-06-03) [Polymarket] SpaceX IPO closing market cap above $4T?
      This market will resolve to “Yes” if the official closing price for SpaceX’s market capitalization on its first trading day is above the value specified in the title. Otherwise, it will resolve to “No”. If no IPO occurs…
  - (2026-06-03) [Polymarket] Will Donald Trump not announce a next United States Attorney General by June 30?
      This market will resolve according to the first individual Donald Trump announces as his pick to be United States Attorney General. An announcement from Donald Trump or the Trump administration stating their intent to no…
  - (2026-06-03) [Polymarket] Will President Trump attend the NBA Finals?
      The 2026 NBA Finals are scheduled for June 3, 2026 through June 19, 2026. This market will resolve to "Yes" if Donald Trump attends the 2026 NBA Finals. Otherwise, this market will resolve to "No". If the event is cancel…
  - (2026-06-03) [Polymarket] Predict.fun FDV above $200M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Predict.fun's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-06-03) [Polymarket] NATO x Russia military clash by June 30, 2026?
      This market will resolve to "Yes" if there is a military encounter between the military forces of a NATO country and Russia between January 12, and June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-06-03) JAF8LY (Bulgaria)
      icao24: 4520ce · position: (48.2765, 1.6061) · alt: 4206m · 639km/h
  - (2026-06-03) GAF635 (Germany)
      icao24: 3f6533 · position: (52.4643, 9.7948) · alt: 449m · 237km/h
  - (2026-06-03) PAT375 (United States)
      icao24: adfecb · position: (37.8649, -85.5737) · alt: 2019m · 393km/h
  - (2026-06-03) PAT251 (United States)
      icao24: adfee0 · position: (33.4357, -100.3963) · alt: 7917m · 472km/h
  - (2026-06-03) NIGER1 (Niger)
      icao24: 062f2e · position: (36.0526, 22.0104) · alt: 11887m · 855km/h
  - (2026-06-03) PAT657 (United States)
      icao24: adfe53 · position: (40.1083, -96.2139) · alt: 7315m · 480km/h

### Court opinions of consequence (federal & state) — 18 new of 60 total
  - (2026-06-02) U.S. Supreme Court: Allen v. Milligan
  - (2026-06-02) Hawaii Supreme Court: In re: Barjaktarovic
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. James
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. Squire
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. Duran-Gonzalez
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: Von Derhaar v. Watson

### World News (by country, top stories) — 18 new of 18 total
  - (2026-06-03) [South Korea] Yoo Byung Jae company BLACKPAPER cites Misunderstanding in internship posting , plans to remove controversial job advertisement
      allkpop.com · English
  - (2026-06-03) [South Korea] Jang Geun Suk reveals he had a crush on Ha Ji Won , I even confessed my feelings to her
      allkpop.com · English
  - (2026-06-03) [South Korea] BTS Jin joins celebrities encouraging voter participation on election day
      allkpop.com · English
  - (2026-06-03) [South Korea] At polling stations , voters look beyond local pledges
      koreaherald.com · English
  - (2026-06-03) [South Korea] Democratic candidates lead major mayoral contests , exit poll shows
      koreaherald.com · English
  - (2026-06-03) [South Korea] June election victory to buoy Lee administration
      koreaherald.com · English

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 114 total
  - (2026-06-02) [OFAC] Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question - Office of Foreign Assets Control (.g…
      Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-05-29) [OFAC] 1249 - Office of Foreign Assets Control (.gov)
      1249 Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-06-03) [USASpending] $3,044,069,155 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-06-03) [USASpending] $2,530,079,189 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-06-03) M 5.7 - 154 km WSW of Pistol River, Oregon
      M5.7 · 154 km WSW of Pistol River, Oregon · depth 10 km
  - (2026-06-03) M 5.6 - Vanuatu region
      M5.6 · Vanuatu region · depth 10 km
  - (2026-06-03) M 5.1 - 76 km S of Daroot-Korgon, Kyrgyzstan
      M5.1 · 76 km S of Daroot-Korgon, Kyrgyzstan · depth 10 km
  - (2026-06-03) M 5.1 - 64 km W of Petrolia, CA
      M5.08 · 64 km W of Petrolia, CA · depth 0.150000005960464 km
  - (2026-06-03) M 4.9 - Pitcairn Islands region
      M4.9 · Pitcairn Islands region · depth 10 km
  - (2026-06-03) M 4.7 - 142 km SSE of Vilyuchinsk, Russia
      M4.7 · 142 km SSE of Vilyuchinsk, Russia · depth 61.892 km

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-06-03) Will Australia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,043,150 · resolves 2026-07-20
  - (2026-06-03) Roland Garros ATP: Felix Auger-Aliassime vs Flavio Cobolli
      yes price: 54% · 24h volume: $3,487,835 · resolves 2026-06-10
  - (2026-06-03) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,212,299 · resolves 2026-07-20
  - (2026-06-03) Knicks vs. Spurs
      yes price: 36% · 24h volume: $1,640,374 · resolves 2026-06-04
  - (2026-06-03) Will Colombia win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,347,464 · resolves 2026-07-20
  - (2026-06-03) Counter-Strike: Liquid vs MIBR (BO1) - IEM Cologne Major Stage 1
      yes price: 0% · 24h volume: $1,055,963 · resolves 2026-06-03

### Congressional STOCK Act Trades (House + Senate) — 8 new of 49 total
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess +0.6% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess +0.6% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-07) [Senate] Sheldon Whitehouse (D): Sale (Partial) ORCL ($15,001 - $50,000) (excess +21.9% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: ORCL (Stock). Type: Sale (Partial). Amount range: $15,001 - $50,000. Transaction date: 2026-05-07. Disclosure date: 2026-06-02. Excess return vs SPY since…
  - (2026-05-15) [House] Virginia Foxx (R): Purchase ARLP ($1,001 - $15,000) (excess -1.3% vs SPY)
      Member: Virginia Foxx (R, house). BioGuide: F000450. Asset: ARLP (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-06-02. Excess return vs SPY since disclosure: -1.…
  - (2026-05-08) [House] Kevin Hern (R): Exchange DVN ($15,001 - $50,000) (excess -1.6% vs SPY)
      Member: Kevin Hern (R, house). BioGuide: H001082. Asset: DVN (ST). Type: Exchange. Amount range: $15,001 - $50,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY since disclosure: -1.64%…
  - (2026-05-08) [House] Kevin Hern (R): Exchange CTRA ($15,001 - $50,000)
      Member: Kevin Hern (R, house). BioGuide: H001082. Asset: CTRA (ST). Type: Exchange. Amount range: $15,001 - $50,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Description: COTERRA MERGED INTO DEVON.

### GDACS — global disaster alerts — 5 new of 98 total
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)

### Macro indicators — latest values (FRED) — 4 new of 8 total
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-04-01) [Labor] Job openings (JOLTS) (JTSJOL)
      latest: 7618 as of 2026-04-01
  - (2026-01-01) [Growth] Real GDP (GDPC1)
      latest: 24152.656 as of 2026-01-01
  - (2026-05-29) [FX] JPY/USD (DEXJPUS)
      latest: 159.23 as of 2026-05-29

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-03) [Marginal Revolution] Richard Feynman’s formula for the best holiday restaurant
      According to Feynman’s approach, in this context, people should try a different restaurant each night until they find one that exceeds a particular threshold that reflects a desired quality. In Feynman’s equations this t…
  - (2026-06-03) [Marginal Revolution] Sentences to ponder
      In 2019, there were about 150,000 people working in autism therapy. Six years later, there were 654,000—more than the number of people who work in mining and logging, or telecommunications, or at the US Postal Service. T…
  - (2026-06-03) [Marginal Revolution] Consent-based laws and aggregate fertility
      This paper examines how expanding the legal definition of sexual assault affects fertility and sexual behavior, using a panel of European countries. I find that switching to tacit consent-based legislation reduces fertil…
  - (2026-06-02) [Conversable Economist] Does Leniency for First Offenders Pay Off?
      Consider a person who is convicted of a misdemeanor. It is their first offense. Should that person be punished to the full extent of the law, or dealt with more leniently? Depending on one’s prejudices, a theoretical cas…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 40 total
  - (2026-06-03) #29 Jeff Yass — $67.44B
      United States · Finance & Investments · source: Trading, investments
  - (2026-06-03) MOVER ▼ Amancio Ortega — $138.66B ($-0.91B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-06-03) MOVER ▼ Bernard Arnault & family — $144.05B ($-0.52B since yesterday)
      France · Fashion & Retail · source: LVMH

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: marine, certain, address, authorized, needed, event, service, guard, captain, issued, waters, action
- state_bills: today=158, 7d-median=155, 14d-median=155; carrying terms: taxation, effective, children, available, local, conservation, duties, apply, authority, obtaining, injury, specified
- state_news: today=821, 7d-median=695, 14d-median=708; carrying terms: really, effort, described, wildfires, children, surges, scrutiny, friday, spotlightdelaware, george, landmark, source
- local_news: today=259, 7d-median=248, 14d-median=248; carrying terms: friday, local, crash, service, evening, everything, school, prices, suspect, lxtfbmqu, being, security
- foreign_news: today=878, 7d-median=860, 14d-median=864; carrying terms: effort, recommendation, upholding, children, stance, mainland, swissinfo, exposing, source, local, raided, boxing
- chinese_internal: today=290, 7d-median=270, 14d-median=274; carrying terms: lxtfa, target, title, cbmizkfvx, cbmickfvx, cbmix, articles, cbmib, color, https, blank, rally
- russian_internal: today=1169, 7d-median=964, 14d-median=992; carrying terms: forbidden, gazeta, bloomberg, istories, international, press, europe, client, novayagazeta, group, russian, reuters
- ukrainian_internal: today=130, 7d-median=122, 14d-median=122; carrying terms: equipment, children, linked, refineries, woman, integration, armed, military, missiles, europe, latest, despite
- ukraine_theater: today=279, 7d-median=290, 14d-median=299; carrying terms: hymdhnbllhddlkrm, children, cbmiwkfvx, ekvqylj, plwwzxelr, dhmfh, source, xwszk, cuxoc, cbmingfbvv, local, hwdwxnbtbxcjb
- paper_bets: today=144, 7d-median=143, 14d-median=142; carrying terms: sachs, company, according, romania, source, winner, arizona, final, climate, supervolcano, world, party
- weather: today=73, 7d-median=107, 14d-median=110; carrying terms: marine, coastal, advisory, minor, afdmtr, friday, afdlox, morning, remains, depth, miami, afdfwd
- macro: today=8, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: price, germany, japan, commodity, australia, shanghai, index, nikkei, cotton, equity, crude, crypto
- sanctions_procurement: today=114, 7d-median=101, 14d-median=100; carrying terms: aeronautics, company, congo, mediterranean, cyber, destruction, violations, prohibiting, proliferation, cdexqrddleknpcjdwzfb, transnistria, armed
- congressional_trades: today=49, 7d-median=40, 14d-median=20; carrying terms: house, purchase, range, moreno, auchincloss, dwight, distribution, member, bernardo, compensation, transaction, senate
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: bondi, blanche, vasquez, smith, employee, group, ortiz, veterans, castillo, attorney, robert, gregory
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, financial, group, filer, jpmorgan, chase, michael, finance, subject
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: house, joseph, brown, filing, raised, warner, lindsey, senate, ossoff, joshua, angels, krishnamoorthi
- gdelt_regions: today=18, 7d-median=18, 14d-median=18
- gdelt_gkg: today=75, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: english, domain, language, kingdom, canada, india
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=15, 14d-median=12; carrying terms: position, ground, bulgaria, belgium, germany, kingdom, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: bypass, trend, windows, overwrite, following, vulnerability, microsoft, origin, injection, defender, adobe, remediation
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=98, 7d-median=97, 14d-median=97
- usgs_quakes: today=11, 7d-median=10, 14d-median=10
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, permanent, peace, world, volume, bitcoin, roland, ivory, coast, garros, morocco
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: economist, class, marginal, https, revolution, conversable, story, marginalrevolution, paying, service, people, screen
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: lummis, mcconnell, banks, tracey, moylan, pelosi, sessions, hudson, sanford, carol, perry, loudermilk
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, sufficient, either, today, claude, converges, identify, paper, consensus, placement, evidence, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*