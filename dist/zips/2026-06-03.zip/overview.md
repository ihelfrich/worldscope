# WORLDSCOPE morning brief — 2026-06-03

## Headline
2986 new items across 26 active section(s) (of 41 tracked).

## Top movers today
International News + Multilateral Institutions (646) · Russian Internal News (state + in-exile) (606) · State-Level News (454) · World leaders & government officials (324) · Chinese Internal News (234) · Local News: St. Louis + Atlanta (219) · Ukraine Theater (total-war monitoring) (126) · U.S. Weather + Severe / Climate Outlooks (93) · SEC Form 4 insider transactions (recent) (40) · U.S. Federal Action (35) · Paper Trading Scorecard (33) · Ukrainian Internal News (national + local Kyiv) (31)

## What changed today
### International News + Multilateral Institutions — 646 new of 886 total
  - (2026-06-03) [Global] Israeli strikes near Tyre hospital put youngest patient at risk
      Jabal Aamel Hospital in Tyre was heavily damaged after an Israeli strike levelled nearby buildings, leaving key medical
  - (2026-06-03) [Global] Dalai Lama receives Grammy award for spoken-word album
      Tibetan spiritual leader Tenzin Gyatso received his first Grammy award for his spoken-word album.
  - (2026-06-03) [Global] Gunfire erupts in Mogadishu before protests against Somali president’s rule
      Ex-Somali PM Khaire accuses government forces of attacking him before planned antigovernment protests in Mogadishu.
  - (2026-06-03) [Global] Iran faces a new energy imbalance, but its options are limited
      Iran’s government weighs limited energy control options in a strained economy, with the war impacting production.
  - (2026-06-03) [Global] Israeli attacks kill nine in Lebanon, reach Beirut outskirts
      The attacks test a US-mediated deal to curb Israel-Hezbollah attacks, and new Israel-Lebanon talks in Washington.
  - (2026-06-03) [Global] Lula says Brazil cannot ‘accept treatment’ after new US tariffs proposed
      Brazil's president says he was surprised by the proposed 25 percent tariffs, which came amid signs relations improving.

### Russian Internal News (state + in-exile) — 606 new of 1052 total
  - (2026-06-03) Эльвира Набиуллина пропала из числа спикеров ПМЭФ | LEDE: Глава Банка России Эльвира Набиуллина исчезла из списка спикеров в программе Петербургского международного экономическго форума. Об ] (ru: Эль…
      Глава Банка России Эльвира Набиуллина исчезла из списка спикеров в программе Петербургского международного экономическго форума. Об этом пишет РБК со ссылкой на источники, близкие к Центробанку.
  - (2026-06-03) Мессенджер «Макс» исчез из App Store | LEDE: Российский национальный мессенджер «Макс» пропал из App Store. Приложение больше нельзя найти через поиск, а переход по прямой ссылке на его стра] (ru: Мес…
      Российский национальный мессенджер «Макс» пропал из App Store. Приложение больше нельзя найти через поиск, а переход по прямой ссылке на его страницу выдает ошибку.
  - (2026-06-03) «Прилеты уже обыденность. Можно не париться». Пока гости ПМЭФ знакомятся с «достижениями» российской экономики, петербуржцы наблюдают за черным дымом над городом после атаки ВСУ. Репортаж «Бере] (ru:…
      Утром 3 июня Украина нанесла массированный удар дронами по Санкт-Петербургу и Ленинградской области, в результате несколько человек пострадали (точное число власти так и не назвали), был поражен нефтяной терминал и объек…
  - (2026-06-03) Сразу две россиянки вышли в полуфинал «Роллан Гаррос». Это случилось впервые за 17 лет | LEDE: Российские теннисистки Мирра Андреева и Диана Шнайдер вышли в полуфинал Открытого чемпионата Фр] (ru: Сра…
      Российские теннисистки Мирра Андреева и Диана Шнайдер вышли в полуфинал Открытого чемпионата Франции по теннису.
  - (2026-06-03) Советник Сечина (он же бывший раскрытый шпион) заявил на ПМЭФ, что Россия будет воевать следующие «пару десятилетий» | LEDE: Россия будет находиться в следующие «пару десятилетий» в состояни] (ru: Сов…
      Россия будет находиться в следующие «пару десятилетий» в состоянии войны, а в стране появятся два «воюющих» поколения, заявил Андрей Безруков, политолог и советник главы «Роснефти» Игоря Сечина.
  - (2026-06-03) «Десятки тысяч погибших — это не абстракция. Это можете быть вы. Вас оставят умирать в грязи». Генсек НАТО предостерег россиян от вербовки на фронт | LEDE: Генеральный секретарь НАТО Марк Рю] (ru: «Де…
      Генеральный секретарь НАТО Марк Рютте обратился к российской молодежи с призывом не поддаваться вербовке на войну. С таким заявлением он выступил во время визита в Киев.

### State-Level News — 454 new of 888 total
  - (2026-06-02) [Alabama] Flags Lowered Honoring Former State Senator John Emanuel Amari
      Download
  - (2026-06-03) [Colorado] What vacant ambassador posts means for Colorado
      Across the Western Hemisphere today, more than a dozen U.S. ambassador posts are either vacant or awaiting Senate confirmation. At the same time, instability across the region is growing. In Haiti, a worsening security a…
  - (2026-06-03) [Colorado] US Senate panel pans DHS plan to stop customs processing at blue-city airports
      WASHINGTON — Homeland Security Secretary Markwayne Mullin appeared before the U.S. Senate Appropriations Homeland Security panel Tuesday and defended his threats to cripple international air travel into some cities led b…
  - (2026-06-03) [Colorado] Fifty for 150: World’s first recreational marijuana sales begin in Colorado in 2014
      Colorado became a tourist destination for cannabis users in 2014, when the first legal recreational marijuana sales in the world began in the state. Legalization in Colorado marked the beginning of what would become a na…
  - (2026-06-03) [Colorado] Rising costs of fuel, other goods squeeze already strained abortion funds
      The increasing costs of fuel for cars and airplanes are adding extra strain to abortion funds that help people pay to travel for care in other states, leaders of several funds said this week. Abortion funds can help when…
  - (2026-06-03) [Colorado] Colorado’s 3 Republican candidates for governor square off in first full debate
      Colorado Springs ministry leader Victor Marx faced his two rivals for the Colorado Republican Party’s nomination for governor in a debate for the first time on Tuesday night, and quickly found himself the target of sting…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 234 new of 291 total
  - (2026-06-03) 从市长到主席边升官边敛财 62岁正省级女高官王莉霞将受审 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE45QnNra2tNWkNrMHVSNTc4WVJSR2dFQk5kemRqcnQycmNZdF80ZzlDbXdMUHJsZ1dhb0VTRkVCdWJ] (zh:…
      从市长到主席边升官边敛财 62岁正省级女高官王莉霞将受审 china.caixin.com
  - (2026-06-02) 老虎证券6月12日起将停止存量用户中国境内开仓加仓 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0tUVVvbGVEWXRrdWFac1RUMVhHeHVIWTZidDVfNDA4dzAwbjBqczlaRGFrYUlpejc3d1BueDlENTNSckFsMThQTE9EczVf] (zh:…
      老虎证券6月12日起将停止存量用户中国境内开仓加仓 财新
  - (2026-06-03) 超越美债，黄金成全球官方储备第一大资产 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9mekp5dEl1M3d5X19vNktPcjFvRjh3MnRPTlVaUnF4MFJxVWJRdlBYOUdLNlVRMWN0Zy1zakZoM0FoYlN1emloTThOV3NhWDczY0] (zh:…
      超越美债，黄金成全球官方储备第一大资产 财新
  - (2026-06-02) “耿同学”打假再有战果 《自然》答财新：正评估相关信息 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBfQ0pxMW9nS2d6b0RkLWY1TTlYR1BaOGltMXloRHVpZWlxM3lTaUcxLUd6ckJBMTExSVRWajBUbXBRcVJMQjJYLV9VZj] (zh:…
      “耿同学”打假再有战果 《自然》答财新：正评估相关信息 财新
  - (2026-06-02) 匈牙利新总理欲修法解职总统 试图逼退欧尔班任命的一批高官 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1BckFoR0RobWVQcmd6Qm5RMXp3aXZRZ2NnZDRHU005MVk4WE55N1F3WWpSMkFHYXloRmo3czU0Y2lsd0N2R0ppU19YZ] (zh:…
      匈牙利新总理欲修法解职总统 试图逼退欧尔班任命的一批高官 财新
  - (2026-06-03) 2026年以来补税上市公司同比增加 主要因不符合税收优惠条件等 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE55cnM4c3NtaEZJNUZiM2JMWjFGRUVnOXNUNXRzR3hfQVd1S0wyRHQ1QWN0SEpOQ3lmUHdza3FVRTBEYzk4M01nSX] (zh:…
      2026年以来补税上市公司同比增加 主要因不符合税收优惠条件等 财新

### Local News: St. Louis + Atlanta — 219 new of 266 total
  - (2026-06-03) [St. Louis] Dohmo ice cream
      The Grit blended ice cream at Dohmo in Olivette
  - (2026-06-03) [St. Louis] Royal Palm chicken
      The chicken taouk plate at Royal Palm Mediterranean Cuisine in Fairview Heights
  - (2026-06-03) [St. Louis] Royal Palm chicken (copy)
  - (2026-06-03) [St. Louis] Dohmo ice cream (copy)
  - (2026-06-03) [St. Louis] Trump sons
      Eric Trump, left, Donald Trump Jr. at the Nasdaq Market in New York last August celebrate the closing of a deal under which blockchain company Alt5 Sigma raised hundreds of millions of dollars to buy World Liberty Financ…
  - (2026-06-03) [St. Louis] Moms set for U.S. Open at Riviera, with one nearly 7 months pregnant
      Madelene Sagstrom rested her left hand on her belly as she readied to hit a bunker shot in the practice area at Riviera Country Club.

### Ukraine Theater (total-war monitoring) — 126 new of 279 total
  - (2026-06-03) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.107 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.87 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.111 (FRP 0.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.51 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.295, 25.110 (FRP 1.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 1.04 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.849, 29.988 (FRP 2.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 2.77 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.701, 31.867 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 0.8 MW

### U.S. Weather + Severe / Climate Outlooks — 93 new of 97 total
  - (2026-06-03) [Moderate] Special Weather Statement: Special Weather Statement issued June 3 at 4:12PM EDT by NWS Key West FL
      At 412 PM EDT, Doppler radar was tracking a strong thunderstorm near Jewfish Creek Bridge, moving east at 10 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree lim…
  - (2026-06-03) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 3 at 2:09PM MDT until June 3 at 3:00PM MDT by NWS El Paso Tx/Santa Teresa NM
      SVREPZ The National Weather Service in El Paso has issued a * Severe Thunderstorm Warning for... North central Otero County in south central New Mexico... * Until 300 PM MDT. * At 208 PM MDT, a severe thunderstorm was lo…
  - (2026-06-03) [Moderate] Special Weather Statement: Special Weather Statement issued June 3 at 3:09PM CDT by NWS Amarillo TX
      At 309 PM CDT, Doppler radar was tracking a strong thunderstorm 9 miles east of Beaver, moving northwest at 25 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated. IMPACT...Gusty winds coul…
  - (2026-06-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-03) [Moderate] Special Weather Statement: Special Weather Statement issued June 3 at 3:08PM CDT by NWS Hastings NE
      At 308 PM CDT, Doppler radar was tracking strong thunderstorms along a line extending from near Giltner to near Inland to near Ayr. Movement was northeast at 25 mph. HAZARD...Wind gusts up to 50 mph and penny size hail.…
  - (2026-06-03) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued June 3 at 3:07PM CDT until June 3 at 3:45PM CDT by NWS Amarillo TX
      At 306 PM CDT, a severe thunderstorm was located 6 miles south of Balko, or 13 miles northeast of Perryton, moving north at 25 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Minor damage to roofs, si…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-03) [CHAPMAN ROBERT M] Form 4 (Reporting)
      filed 2026-06-03 20:17 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001180400-26-000002 Size: 5 KB
  - (2026-06-03) [COUSINS PROPERTIES INC] Form 4 (Issuer)
      filed 2026-06-03 20:17 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001180400-26-000002 Size: 5 KB
  - (2026-06-03) [Yates Lloyd M] Form 4 (Reporting)
      filed 2026-06-03 20:17 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0000062709-26-000158 Size: 5 KB
  - (2026-06-03) [MARSH & MCLENNAN COMPANIES, INC.] Form 4 (Issuer)
      filed 2026-06-03 20:17 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0000062709-26-000158 Size: 5 KB
  - (2026-06-03) [Duffy Sean P.] Form 4 (Reporting)
      filed 2026-06-03 20:17 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001610717-26-000180 Size: 5 KB
  - (2026-06-03) [Omada Health, Inc.] Form 4 (Issuer)
      filed 2026-06-03 20:17 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001610717-26-000180 Size: 5 KB

### U.S. Federal Action — 35 new of 35 total
  - (2026-06-03) Removing Unnecessary and Counterproductive Restrictions on Access to Federal Lands
  - (2026-06-03) Realigning United States Core Childhood Vaccine Recommendations With Best Practices From Peer, Developed Countries
  - (2026-06-03) 1,2-dibromo-3-chloropropane; 1, 3-Butadiene; 13 Carcinogens (4-Nitrobiphenyl, etc.); Acrylonitrile; Asbestos; Benzene; Cadmium; Coke Oven Emissions; Cotton Dust; Ethylene Oxide; Formaldehyde; Inorgani…
      OSHA is scheduling a series of informal public hearings on the above-listed proposed rules. The public hearings will begin on August 19, 2026. All of the proposed rules listed in this notice were published in the Federal…
  - (2026-06-03) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Applications; Change of Sponsor; Change of Sponsor Address; Correction
      The Food and Drug Administration (FDA or we) is amending the final rule that published in the Federal Register of April 16, 2026. That final rule updated regulations to reflect application-related actions for new animal…
  - (2026-06-03) Guidance on Tax-Exempt Refunding Bonds; Hearing
      This document contains proposed regulations that would update certain arbitrage rules and definitions applicable to tax-exempt and other tax-advantaged bonds by clarifying the time and manner for requesting refunds of ov…
  - (2026-06-03) Safety Zone; Fireworks Displays Within the USCG East District (Formerly Fifth Coast Guard District); The Wharf, Washington, DC
      The Coast Guard will enforce a safety zone for a fireworks display at "The Wharf D.C.," in Washington, DC, to provide for the safety of life on navigable waterways during this event. Our regulation for recurring safety z…

### Paper Trading Scorecard — 33 new of 144 total
  - (2026-06-03) [Polymarket] Will Donald Trump not announce a next United States Attorney General by June 30?
      This market will resolve according to the first individual Donald Trump announces as his pick to be United States Attorney General. An announcement from Donald Trump or the Trump administration stating their intent to no…
  - (2026-06-03) [Polymarket] Will Kim Sang-wook win the 2026 Ulsan mayoral election?
      The Ulsan mayoral election is scheduled to take place on June 3, 2026. This market will resolve according to the candidate who wins this election. Interim, temporary, or caretaker mayors will not count. If the result of…
  - (2026-06-03) [Polymarket] NATO x Russia military clash by June 30, 2026?
      This market will resolve to "Yes" if there is a military encounter between the military forces of a NATO country and Russia between January 12, and June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".…
  - (2026-06-03) [Polymarket] Will Jamie Dimon win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…
  - (2026-06-03) [Polymarket] Predict.fun FDV above $200M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Predict.fun's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-06-03) [Polymarket] Will Mexico win on 2026-06-11?
      In the upcoming game, scheduled for June 11, 2026 If Mexico wins, this market will resolve to "Yes". Otherwise, this market will resolve to "No". If the game is postponed, this market will remain open until the game has…

### Ukrainian Internal News (national + local Kyiv) — 31 new of 39 total
  - (2026-06-03) У Херсоні внаслідок російських атак 2 людей загинули та 9 постраждали | LEDE: Російські війська атакували багатоповерхівку у Херсоні: 2 людей загинули, 9 постраждали.] (uk: У Херсоні внаслідок російсь…
      Російські війська атакували багатоповерхівку у Херсоні: 2 людей загинули, 9 постраждали.
  - (2026-06-03) Генштаб: 215 боїв відбулось на фронті з початку доби | LEDE: Від початку доби 3 червня на фронті відбулось 215 бойових зіткнень.] (uk: Генштаб: 215 боїв відбулось на фронті з початку доби)
      Від початку доби 3 червня на фронті відбулось 215 бойових зіткнень.
  - (2026-06-03) Трамп візьме участь у саміті НАТО у Туреччині – держсекретар США | LEDE: ] (uk: Трамп візьме участь у саміті НАТО у Туреччині – держсекретар США)
  - (2026-06-03) Рубіо заявив про "хороші перспективи" домовленостей щодо Гренландії | LEDE: ] (uk: Рубіо заявив про "хороші перспективи" домовленостей щодо Гренландії)
  - (2026-06-03) Верховний Суд став на бік журналістів у справі за позовом покійного Портнова | LEDE: Верховний Суд скасував зобов’язання hromadske видалити розслідування про Портнова.] (uk: Верховний Суд став на бік…
      Верховний Суд скасував зобов’язання hromadske видалити розслідування про Портнова.
  - (2026-06-03) Мадяр заявив, що Україна та Угорщина досягли домовленостей в питаннях нацменшин | LEDE: Прем'єр-міністр Угорщини Петер Мадяр заявив, що його країна досягла "всеосяжної угоди" з Україною щодо уг] (uk:…
      Прем'єр-міністр Угорщини Петер Мадяр заявив, що його країна досягла "всеосяжної угоди" з Україною щодо угорської нацменшини.

### GDACS — global disaster alerts — 31 new of 124 total
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-06-03) M 5.7 - 154 km WSW of Pistol River, Oregon
      M5.7 · 154 km WSW of Pistol River, Oregon · depth 10 km
  - (2026-06-03) M 5.6 - Vanuatu region
      M5.6 · Vanuatu region · depth 10 km
  - (2026-06-03) M 5.2 - 202 km SSE of Vilyuchinsk, Russia
      M5.2 · 202 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-06-03) M 5.2 - 39 km NE of San Fernando, Peru
      M5.2 · 39 km NE of San Fernando, Peru · depth 139.126 km
  - (2026-06-03) M 5.1 - 62 km W of Petrolia, CA
      M5.1 · 62 km W of Petrolia, CA · depth 10 km
  - (2026-06-03) M 5.1 - 76 km S of Daroot-Korgon, Kyrgyzstan
      M5.1 · 76 km S of Daroot-Korgon, Kyrgyzstan · depth 10 km

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-06-03) U.S. Court of Appeals, 3rd Cir.: Secretary United States Department of Labor v. Comprehensive Healthcare Management Services LLC
  - (2026-06-03) U.S. Court of Appeals, 9th Cir.: Lnu v. Blanche
  - (2026-06-03) U.S. Court of Appeals, 9th Cir.: United States v. Deborba
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. James
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. Squire
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. Duran-Gonzalez

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-06-03) Will Australia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,043,343 · resolves 2026-07-20
  - (2026-06-03) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,163,402 · resolves 2026-07-20
  - (2026-06-03) Will Ghana win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,145,283 · resolves 2026-07-20
  - (2026-06-03) Knicks vs. Spurs
      yes price: 36% · 24h volume: $2,078,940 · resolves 2026-06-04
  - (2026-06-03) Will Oh Se-hoon win the 2026 Seoul Mayoral Election
      yes price: 66% · 24h volume: $1,916,924 · resolves 2026-06-03
  - (2026-06-03) Roland Garros ATP: Matteo Berrettini vs Matteo Arnaldi
      yes price: 22% · 24h volume: $1,359,466 · resolves 2026-06-10

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 115 total
  - (2026-06-02) [OFAC] Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question - Office of Foreign Assets Control (.g…
      Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-05-29) [OFAC] 1249 - Office of Foreign Assets Control (.gov)
      1249 Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-06-03) [USASpending] $3,044,069,155 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-06-03) [USASpending] $2,530,079,189 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)

### Congressional STOCK Act Trades (House + Senate) — 8 new of 49 total
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess -2.4% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess -2.4% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-07) [Senate] Sheldon Whitehouse (D): Sale (Partial) ORCL ($15,001 - $50,000) (excess +15.9% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: ORCL (Stock). Type: Sale (Partial). Amount range: $15,001 - $50,000. Transaction date: 2026-05-07. Disclosure date: 2026-06-02. Excess return vs SPY since…
  - (2026-05-15) [House] Virginia Foxx (R): Purchase ARLP ($1,001 - $15,000) (excess -0.6% vs SPY)
      Member: Virginia Foxx (R, house). BioGuide: F000450. Asset: ARLP (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-06-02. Excess return vs SPY since disclosure: -0.…
  - (2026-05-08) [House] Kevin Hern (R): Exchange DVN ($15,001 - $50,000) (excess -0.3% vs SPY)
      Member: Kevin Hern (R, house). BioGuide: H001082. Asset: DVN (ST). Type: Exchange. Amount range: $15,001 - $50,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY since disclosure: -0.28%…
  - (2026-05-08) [House] Kevin Hern (R): Exchange CTRA ($15,001 - $50,000)
      Member: Kevin Hern (R, house). BioGuide: H001082. Asset: CTRA (ST). Type: Exchange. Amount range: $15,001 - $50,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Description: COTERRA MERGED INTO DEVON.

### World News (by country, top stories) — 6 new of 6 total
  - (2026-06-03) [Japan] Tomb Raider : Legacy of Atlantis reveals AI usage disclaimer [ update : official statement ]
      nintendoeverything.com · English
  - (2026-06-03) [Japan] Ubisoft all but rules out a Rayman 1 remake , says it near impossible to do
      nintendoeverything.com · English
  - (2026-06-03) [Japan] Demeo x Dungeons & Dragons : Battlemarked coming to Nintendo Switch 2
      nintendoeverything.com · English
  - (2026-06-03) [Japan] LEGO Batman : Legacy of the Dark Knight reveals Nintendo Switch 2 release date , new trailer
      nintendoeverything.com · English
  - (2026-06-03) [Japan] Clothing rental services in U . S . promise sustainable alternative to fast fashion
      japantoday.com · English
  - (2026-06-03) [Japan] Takaichi office starts new social media account over press access concerns
      japantoday.com · English

### Macro indicators — latest values (FRED) — 5 new of 10 total
  - (2026-06-01) [Rates] 10-Year Treasury (DGS10)
      latest: 4.47 as of 2026-06-01
  - (2026-06-02) [Rates] 30-Year Treasury (DGS30)
      latest: 4.97 as of 2026-06-02
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-04-01) [Inflation] CPI Core (ex food & energy, SA) (CPILFESL)
      latest: 335.423 as of 2026-04-01
  - (2026-04-01) [Inflation] Core PCE (PCEPILFE)
      latest: 129.63 as of 2026-04-01

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-03) [Marginal Revolution] Wednesday assorted links
      1. One hundred greatest bird names of all time. 2. The method for counting 52,019 puffins. 3. Luggage-tag switching scheme involves flights from Canada to countries where drug smuggling can carry death penalty. Yet a thi…
  - (2026-06-03) [Marginal Revolution] Richard Feynman’s formula for the best holiday restaurant
      According to Feynman’s approach, in this context, people should try a different restaurant each night until they find one that exceeds a particular threshold that reflects a desired quality. In Feynman’s equations this t…
  - (2026-06-03) [Marginal Revolution] Sentences to ponder
      In 2019, there were about 150,000 people working in autism therapy. Six years later, there were 654,000—more than the number of people who work in mining and logging, or telecommunications, or at the US Postal Service. T…
  - (2026-06-02) [Conversable Economist] Does Leniency for First Offenders Pay Off?
      Consider a person who is convicted of a misdemeanor. It is their first offense. Should that person be punished to the full extent of the law, or dealt with more leniently? Depending on one’s prejudices, a theoretical cas…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 40 total
  - (2026-06-03) #29 Jeff Yass — $67.44B
      United States · Finance & Investments · source: Trading, investments
  - (2026-06-03) MOVER ▼ Warren Buffett — $140.86B ($-0.79B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 19 total
  - (2026-06-03) CVE-2026-45247 · Mirasvit Mirasvit Full Page Cache Warmer: Mirasvit Full Page Cache Warmer Deserialization of Untrusted Data Vulnerability
      vendor: Mirasvit · product: Mirasvit Full Page Cache Warmer · CISA remediation by 2026-06-06

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: program, guard, marine, address, specifically, certain, authorized, personnel, safety, persons, events, proposed
- state_bills: today=0, 7d-median=155, 14d-median=148
- state_news: today=888, 7d-median=695, 14d-median=708; carrying terms: mackinac, court, workforce, voter, mountain, advance, opposition, washington, police, sports, turnout, capitol
- local_news: today=266, 7d-median=248, 14d-median=248; carrying terms: court, washington, vehicle, police, america, cbminafbvv, cbmipgfbvv, suspect, final, board, accused, today
- foreign_news: today=886, 7d-median=860, 14d-median=864; carrying terms: innovative, court, eight, grand, questions, zhenhua, opposition, condemns, washington, nature, vehicle, selected
- chinese_internal: today=291, 7d-median=270, 14d-median=274; carrying terms: cbmiakfvx, politics, title, lxtfb, cbmibkfvx, cbmia, lxtfa, rally, cbmiyefvx, cbmizkfvx, cbmizefvx, cbmix
- russian_internal: today=1052, 7d-median=964, 14d-median=992; carrying terms: https, roland, china, tasnim, error, euroclear, brent, reuters, found, international, group, europe
- ukrainian_internal: today=39, 7d-median=122, 14d-median=122; carrying terms: https, economic, babel, httperror, vechirniy, client, forbidden, error, ukraine, censor, title, hmarochos
- ukraine_theater: today=279, 7d-median=290, 14d-median=299; carrying terms: myoff, qzqwniuk, cuxpr, cbmigwfbvv, njvwz, thhqrkcwaeozsvpbb, america, sfddbhdiu, uahbks, bpamvqdutnoeo, error, snzab
- paper_bets: today=144, 7d-median=143, 14d-median=142; carrying terms: supervolcano, achieved, washington, earthquake, trained, country, levels, nomination, total, previousl, colorado, rippling
- weather: today=97, 7d-median=107, 14d-median=110; carrying terms: potential, angeles, locations, washington, western, central, ongoing, levels, until, galveston, america, hazards
- macro: today=10, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: index, cotton, natural, france, nikkei, copper, australia, nasdaq, silver, shanghai, india, italy
- sanctions_procurement: today=115, 7d-median=101, 14d-median=100; carrying terms: programs, february, annexation, belarus, court, ahroshhwt, program, weapons, daesh, entity, central, latinscript
- congressional_trades: today=49, 7d-median=40, 14d-median=20; carrying terms: david, moreno, googl, souhy, babin, acquired, asset, wtshf, range, taylor, stanton, auchincloss
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: america, blanche, vasquez, bondi, group, veterans, castillo, ortiz, general, laureano, patria, attorney
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, holdings, group, trust, brian, american, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, brown, cycle, joseph, ocasio, james, cooper, johnson, lindsey, graham, joshua, alexandria
- gdelt_regions: today=6, 7d-median=12, 14d-median=12
- gdelt_gkg: today=125, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=15, 14d-median=12; carrying terms: ground, position, belgium, canada, kingdom, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=19, 7d-median=16, 14d-median=16; carrying terms: overwrite, defender, directx, internet, microsoft, vendor, directory, buffer, bypass, windows, service, premise
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=124, 7d-median=110, 14d-median=110
- usgs_quakes: today=17, 7d-median=13, 14d-median=13
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, resolves, price, world, peace, volume, bitcoin, roland, garros, ivory, coast, turkiye
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: https, economist, class, revolution, conversable, marginal, assorted, links, marginalrevolution, story, paying, people
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: ogles, pablo, zeldin, charles, court, trading, lance, rosen, courtney, cuellar, abraham, allen
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: identify, converges, evidence, placement, either, unavailable, markets, decision, placed, sufficient, consensus, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence
- [2026-06-02] Fed press (events + announcements): Agencies remove additional references to reputation risk
- [2026-06-03] ECB press: Frank Elderson: Strengthening operational resilience for the age of AI

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*