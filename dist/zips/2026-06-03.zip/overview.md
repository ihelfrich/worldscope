# WORLDSCOPE morning brief — 2026-06-03

## Headline
3116 new items across 27 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (649) · International News + Multilateral Institutions (606) · State-Level News (378) · World leaders & government officials (324) · Chinese Internal News (231) · Local News: St. Louis + Atlanta (195) · State Legislative Action (159) · Ukraine Theater (total-war monitoring) (128) · U.S. Weather + Severe / Climate Outlooks (67) · Ukrainian Internal News (national + local Kyiv) (63) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 649 new of 1116 total
  - (2026-06-03) Патриарх Кирилл отправил в Бразилию митрополита Илариона. Его подозревали в перевозке наркотиков в Чехии | LEDE: Глава Русской православной церкви патриарх Кирилл отправил митрополита Иларио] (ru: Пат…
      Глава Русской православной церкви патриарх Кирилл отправил митрополита Илариона, которого в Чехии заподозрили в перевозке наркотиков, на служение в Аргентинско-Южноамериканскую епархию.
  - (2026-06-03) На ПМЭФ выступили родственницы Путина. Дочь говорила об импортозамещении лекарств, внучатая племянница — о центрах здоровья и рождаемости в РЖД | LEDE: В первый день Петербургского междунаро] (ru: На…
      В первый день Петербургского международного экономического форума на мероприятии выступили две родственницы Владимира Путина: младшая дочь Катерина Тихонова и двоюродная внучатая племянница президента Елена Фисенко.
  - (2026-06-03) В Великобритании протесты и беспорядки из-за убийства 18-летнего Генри Новака. Перед гибелью раненого студента арестовали полицейские, поверив его убийце. Тот заявлял, что сам Новак напал на не] (ru:…
      В Великобритании разгорается скандал вокруг дела об убийстве 18-летнего студента Генри Новака, который погиб в конце 2025 года в Саутгемптоне. Его несколько раз ударил ножом 23-летний Викрам Дигва. 1 июня суд приговорил…
  - (2026-06-03) Удар по Петербургу в день начала ПМЭФ. Z-блогеры — в недоумении, федеральное ТВ — просто молчит. «Илон Маск знал, что на форуме будет его отец, но дроны на „Старлинке“ все равно долетели» | LED] (ru:…
      Украина неслучайно ударила в день старта ПМЭФ. Им плевать, если пострадает кто-то из высоких гостей, а мы боимся бить по Киеву, когда туда приезжают делегации из Европы. Отдельно стоит отметить большое количество видео в…
  - (2026-06-03) Объявлен шорт-лист премии «Большая книга». В него попал роман Маргариты Симоньян (который включили в длинный список задним числом) | LEDE: Литературная премия «Большая книга» опубликовала ко] (ru: Объ…
      Литературная премия «Большая книга» опубликовала короткий список претендентов на награду в 2026 году.
  - (2026-06-03) «Закулисье реальности» — хоррор, в котором источником ужаса становится мебель. Режиссеру Кейну Парсонсу всего 20 лет, но его фильм уже стал прокатным хитом | LEDE: В мировой прокат вышел фил] (ru: «За…
      В мировой прокат вышел фильм «Закулисье реальности» («Backrooms») Кейна Парсонса — 20-летнего ютьюбера, который обратился в своей работе к интернет-легендам. В частности, он изучает явление «лиминальных пространств» — не…

### International News + Multilateral Institutions — 606 new of 855 total
  - (2026-06-03) [Global] Kidnappings, threats and ‘protection fees’: how can Mexico confront rise in deadly extortion?
  - (2026-06-02) [Global] Trump administration proposes 25% tariffs on Brazil despite US trade surplus
  - (2026-06-02) [Global] Cricket Canada suspended over allegations of gang-linked corruption
  - (2026-06-03) [Global] Diphtheria outbreak: residents of remote NT community say health clinic has no hand sanitiser
  - (2026-06-03) [Global] NSW motorists who use medicinal cannabis may soon be able to drive without fear of major penalty
  - (2026-06-03) [Global] Anti-abortion activists are trying to limit access in NSW – and they are just getting started

### State-Level News — 378 new of 816 total
  - (2026-06-03) [California] Governor Newsom announces judicial appointments 6.2.2026
      Source
  - (2026-06-02) [California] Trump is still trying to rob victims to pay criminals for their political support
      Source
  - (2026-06-01) [California] Governor Newsom issues legislative update 6.1.26
  - (2026-06-02) [Alabama] Flags Lowered Honoring Former State Senator John Emanuel Amari
      Download
  - (2026-06-03) [California] ¿Quiénes van ganando en las elecciones estatales de California? Esto es lo que sabemos hasta ahora
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226_Chico-Elections_SO_CM_07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-06-03) [California] Cinco cosas que debes saber sobre las elecciones de California
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/060226-Xavier-Becerra-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 231 new of 289 total
  - (2026-06-02) Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes - Caixin Global
      Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes Caixin Global
  - (2026-06-02) 开业即巅峰，合作却短命！全球最大室内雪场“闪电分手”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8yU3o2c0FLaXNNMmRpSVkySWJtYTNhelJfb21VWjNhSE0zZ2ZPWTRaUWF4V241WVlUVGl4bWYwOEtEdHYtQ1ZVL] (zh:…
      开业即巅峰，合作却短命！全球最大室内雪场“闪电分手”-观察者网 观察者
  - (2026-06-03) 玩“山姆托举”梗宝妈账号被禁言30天，取消商业变现功能 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE0yQ3l6cWloSUx1Wm8xMURfdmI4ZVl2WFh5LVM0ZkZJRUhnX1lGMklzXy1nR0g4UEtqdUVRRnlZQ3VwbkZDWm9HN01Hc] (zh:…
      玩“山姆托举”梗宝妈账号被禁言30天，取消商业变现功能 观察者
  - (2026-06-03) 科工力量：一台3D打印机，为什么让开源社区吵翻了？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTFBpZkhmSDdrMXJVZUhmUmVROUZBR3JRNzZqT1BQYnR1d0U2bU5McXJBcXVoak5OUGQxZE1nNWpsOWd3UG1iQW9sN0kyckt] (zh:…
      科工力量：一台3D打印机，为什么让开源社区吵翻了？ 观察者
  - (2026-06-03) 傅首尔自称2年瘦了38斤，调整饮食和规律运动，这变化也太大了吧？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1mWDA0VnlQXzBtSUFzdTEzeHVHUVFHank4LUN6X2JvVVlkRXZCYzhZZjU1QTl2T0NrVl9JZTF2cFJQZndCWlJxd] (zh:…
      傅首尔自称2年瘦了38斤，调整饮食和规律运动，这变化也太大了吧？ 风闻
  - (2026-06-03) 坏了，这下特朗普都反犹了 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1QV0Ezcy1qRmFyR1lPaHVMN0xkd0JMTmlINGpMVC13eWNGZGdJemlWVEw1U2JWR0ExMmllNlhDN3VDWF8zOTJBaVpCMmZDTkVFQ1dONElsR] (zh:…
      坏了，这下特朗普都反犹了 风闻

### Local News: St. Louis + Atlanta — 195 new of 246 total
  - (2026-06-03) [St. Louis] Is the St. Charles Farmers Market the most kid-friendly in the region?
      A change in location may have been all the St. Charles Farmers Market needed to become one of the area’s most family-friendly weekend destinations. This season, the market packed up its produce, parted ways with the City…
  - (2026-06-03) [St. Louis] A house in Wildwood hits the market
      Thoughtful Design Built in 2019, the residence was conceived with an intuitive floor plan, striking details, and carefully considered design elements. Cape Cod-InspiredThis four-bedroom, five-bathroom home is as charming…
  - (2026-06-03) [St. Louis] Police Board’s big raises mean an even bigger increase for St. Louis’ fire department
      On Monday night, the state-appointed Board of Police Commissioners proposed significant pay increases for high-ranking officers: 16 percent for lieutenants, 18 percent for captains, 20 percent for majors, and 22 percent…
  - (2026-06-03) [St. Louis] Broadway star Kate Baldwin helps Opera Theatre of Saint Louis expand its horizons in a glorious show
      One of Broadway’s big stars is in St. Louis this summer, but she’s not at The Muny. Two-time Tony Award nominee Kate Baldwin is starring in The Light in the Piazza as it makes its debut at Opera Theatre of Saint Louis. I…
  - (2026-06-03) [St. Louis] Now is the time to build up the riverfront, civic and business leaders say
      The portion of the Mississippi River that lines St. Louis’ downtown has long felt like an afterthought for the city, but civic and business leaders say the moment now is as good as any to spur riverfront revitalization.…
  - (2026-06-03) [St. Louis] Busch Family Brewing & Distilling in Defiance to remain closed for 2026 season
      After two seasons of brewing beer, bronco busting at monthly Saturday night rodeos, pouring its signature Bridlespur Bourbon, and drawing crowds for country-themed parties and events, Busch Family Brewing & Distilling (4…

### State Legislative Action — 159 new of 241 total
  - (2026-06-03) [Alaska SB 280] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughp…
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re…
  - (2026-06-02) [Alaska HB 298] An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
      An Act relating to the Legislative Ethics Act; relating to legislative subpoenas; relating to the jurisdiction of the office of the ombudsman; and providing for an effective date.
  - (2026-06-02) [Alaska SB 9] An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
      An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
  - (2026-06-02) [Alaska HB 14] MED ASSIST;INSURANCE;DISABILITY/WORK COMP
      MED ASSIST;INSURANCE;DISABILITY/WORK COMP
  - (2026-06-03) [Arizona SB 1235] EMS reciprocity; compact.
      EMS reciprocity; compact.
  - (2026-06-03) [Arizona SB 1497] classical learning; tests; examinations
      classical learning; tests; examinations

### Ukraine Theater (total-war monitoring) — 128 new of 279 total
  - (2026-06-03) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.107 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.87 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.111 (FRP 0.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.51 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.295, 25.110 (FRP 1.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 1.04 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.849, 29.988 (FRP 2.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 2.77 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.701, 31.867 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 0.8 MW

### U.S. Weather + Severe / Climate Outlooks — 67 new of 72 total
  - (2026-06-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-03) [Moderate] Gale Warning: Gale Warning issued June 3 at 8:40AM PDT until June 5 at 6:00AM PDT by NWS Eureka CA
      * WHAT...For the Gale Warning, north winds 25 to 30 kt with gusts up to 40 kt and seas 8 to 13 feet expected. For the Small Craft Advisory, north winds 20 to 25 kt with gusts up to 35 kt and seas 7 to 10 feet expected. *…
  - (2026-06-03) [Moderate] Gale Warning: Gale Warning issued June 3 at 8:40AM PDT until June 5 at 6:00AM PDT by NWS Eureka CA
      * WHAT...For the Gale Warning, northwest winds 20 to 30 kt with gusts up to 40 kt and seas 7 to 12 feet expected. For the Small Craft Advisory, northwest winds 20 to 30 kt with gusts up to 40 kt and seas 6 to 9 feet expe…
  - (2026-06-03) [Moderate] Gale Warning: Gale Warning issued June 3 at 8:32AM PDT until June 4 at 9:00AM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 15 to 25 kt with gusts up to 40 kt expected. * WHERE...Coastal Waters from Point Pinos to Point Piedras Blancas California out to 10 NM. * WHEN...Until 9 AM PDT Thursday. * IMPACTS...Strong winds…
  - (2026-06-03) [Moderate] Gale Warning: Gale Warning issued June 3 at 8:32AM PDT until June 5 at 3:00AM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 25 to 35 kt with gusts up to 40 kt and seas 9 to 14 ft expected. * WHERE...Waters from Point Reyes to Pigeon Point 10-60 NM. * WHEN...Until 3 AM PDT Friday. * IMPACTS...Strong winds will cause ha…
  - (2026-06-03) [Moderate] Gale Warning: Gale Warning issued June 3 at 8:32AM PDT until June 4 at 3:00AM PDT by NWS San Francisco CA
      * WHAT...Northwest winds 15 to 25 kt with gusts up to 35 kt expected. * WHERE...Coastal Waters from Point Reyes to Pigeon Point California out to 10 NM. * WHEN...Until 3 AM PDT Thursday. * IMPACTS...Strong winds will cau…

### Ukrainian Internal News (national + local Kyiv) — 63 new of 129 total
  - (2026-06-03) Зеленський: Я готовий до прямих перемовин з Путіним, щоб завершити цю війну | LEDE: Президент України Володимир Зеленський повідомив, що готовий провести прямі перемовини з правителем РФ Володи] (uk:…
      Президент України Володимир Зеленський повідомив, що готовий провести прямі перемовини з правителем РФ Володимиром Путіним, щоби завершити цю війну.
  - (2026-06-03) Рютте натякнув, що в обстрілі Петербурга у дні форуму Путіна в НАТО не бачать проблем | LEDE: У НАТО не бачать проблем в обстрілі Україною Санкт-Петербурга у день, коли там стартує Петербурзьки] (uk:…
      У НАТО не бачать проблем в обстрілі Україною Санкт-Петербурга у день, коли там стартує Петербурзький міжнародний економічний форум (ПМЕФ) – ключова міжнародна подія праителя РФ Володимира Путіна.
  - (2026-06-03) Країну захищають не інтерпретації. Країну захищає результат | LEDE: Аналітика щодо закупівель Міноборони, ролі журналістів і результатів для оборони України під час війни.] (uk: Країну захищають не ін…
      Аналітика щодо закупівель Міноборони, ролі журналістів і результатів для оборони України під час війни.
  - (2026-06-03) Зеленський на зустрічі із Рютте: "Україна в НАТО потрібна самому Альянсу і навіть росіянам" | LEDE: Генеральний секретар НАТО Марк Рютте та президент України Володимир Зеленський у Києві заявил] (uk:…
      Генеральний секретар НАТО Марк Рютте та президент України Володимир Зеленський у Києві заявили, що жодна зі сторін не відмовляється від потреби вступу України в Альянс.
  - (2026-06-03) Зеленський: Ми домовилися про швидке постачання Patriot і ракет до них | LEDE: Президент України Володимир Зеленський розкрив деталі домовленості зі США та партнерами про постачання нових систе] (uk:…
      Президент України Володимир Зеленський розкрив деталі домовленості зі США та партнерами про постачання нових систем Patriot, на які зараз терміново шукають гроші.
  - (2026-06-03) Генсек НАТО звернувся до молодих росіян: Ви помрете у багнюці в Україні | LEDE: Марк Рютте заявив про рекордні втрати РФ на війні та звернувся до російської молоді під час візиту до України.] (uk: Ген…
      Марк Рютте заявив про рекордні втрати РФ на війні та звернувся до російської молоді під час візиту до України.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Iran has agreed not to have a nuke , Trump says as he reveals hell probably meet the new Ayatollah
      lbc.co.uk · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Trump Confirms Details of Heated Call with Netanyahu
      wjdx.iheart.com · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Iran and the US trade strikes in the Persian Gulf , further testing the ceasefire
      wkms.org · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Donald Trump confirms he called Benjamin Netanyahu crazy amid Iran peace talks
      brentwoodlive.co.uk · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Trump admits cursing out Netanyahu over Lebanon war
      punchng.com · English · tone NA
  - (2026-06-03) [Israel-Iran-Hezbollah axis · keywords] Trump says he called Netanyahu crazy , Israel stalling Iran peace talks
      citizensvoice.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-03) [Charlotte's Web Holdings, Inc.] Form 4 (Issuer)
      filed 2026-06-03 15:53 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0001750155-26-000086 Size: 5 KB
  - (2026-06-03) [Usifer Maureen K] Form 4 (Reporting)
      filed 2026-06-03 15:53 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0001750155-26-000086 Size: 5 KB
  - (2026-06-03) [Thermon Group Holdings, Inc.] Form 4 (Issuer)
      filed 2026-06-03 15:52 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0000905148-26-002795 Size: 10 KB
  - (2026-06-03) [Schott Jan L] Form 4 (Reporting)
      filed 2026-06-03 15:52 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0000905148-26-002795 Size: 10 KB
  - (2026-06-03) 497 - ADVANCED SERIES TRUST (0000814679) (Filer)
      filed 2026-06-03 15:52 UTC — Filed: 2026-06-03 AccNo: 0000814679-26-000080 Size: 6 KB
  - (2026-06-03) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-03 15:52 UTC — Filed: 2026-06-03 AccNo: 0001213900-26-064542 Size: 2 MB

### U.S. Federal Action — 35 new of 35 total
  - (2026-06-03) Removing Unnecessary and Counterproductive Restrictions on Access to Federal Lands
  - (2026-06-03) Realigning United States Core Childhood Vaccine Recommendations With Best Practices From Peer, Developed Countries
  - (2026-06-03) 1,2-dibromo-3-chloropropane; 1, 3-Butadiene; 13 Carcinogens (4-Nitrobiphenyl, etc.); Acrylonitrile; Asbestos; Benzene; Cadmium; Coke Oven Emissions; Cotton Dust; Ethylene Oxide; Formaldehyde; Inorgani…
      OSHA is scheduling a series of informal public hearings on the above-listed proposed rules. The public hearings will begin on August 19, 2026. All of the proposed rules listed in this notice were published in the Federal…
  - (2026-06-03) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Applications; Change of Sponsor; Change of Sponsor Address; Correction
      The Food and Drug Administration (FDA or we) is amending the final rule that published in the Federal Register of April 16, 2026. That final rule updated regulations to reflect application-related actions for new animal…
  - (2026-06-03) Guidance on Tax-Exempt Refunding Bonds; Hearing
      This document contains proposed regulations that would update certain arbitrage rules and definitions applicable to tax-exempt and other tax-advantaged bonds by clarifying the time and manner for requesting refunds of ov…
  - (2026-06-03) Safety Zone; Fireworks Displays Within the USCG East District (Formerly Fifth Coast Guard District); The Wharf, Washington, DC
      The Coast Guard will enforce a safety zone for a fireworks display at "The Wharf D.C.," in Washington, DC, to provide for the safety of life on navigable waterways during this event. Our regulation for recurring safety z…

### Paper Trading Scorecard — 32 new of 145 total
  - (2026-06-03) [Polymarket] Will Bitcoin reach $72,500 in June?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…
  - (2026-06-03) [Polymarket] SpaceX IPO closing market cap above $4T?
      This market will resolve to “Yes” if the official closing price for SpaceX’s market capitalization on its first trading day is above the value specified in the title. Otherwise, it will resolve to “No”. If no IPO occurs…
  - (2026-06-03) [Polymarket] US announces new Iran agreement/ceasefire extension by June 30?
      This market will resolve to “Yes” if the U.S. officially announces an extension of the ceasefire agreement between the U.S. and Iran, defined as a publicly announced commitment to the continued halt of direct military en…
  - (2026-06-03) [Polymarket] Will the price of Bitcoin be above $76,000 on June 4?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-06-03) [Polymarket] Will Donald Trump not announce a next United States Attorney General by June 30?
      This market will resolve according to the first individual Donald Trump announces as his pick to be United States Attorney General. An announcement from Donald Trump or the Trump administration stating their intent to no…
  - (2026-06-03) [Polymarket] Predict.fun FDV above $200M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Predict.fun's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-06-03) JAF8LY (Bulgaria)
      icao24: 4520ce · position: (45.5837, -1.8866) · alt: 10972m · 840km/h
  - (2026-06-03) GAF635 (Germany)
      icao24: 3f6533 · position: (50.8696, 7.155) · on ground · 98km/h
  - (2026-06-03) PAT251 (United States)
      icao24: adfee0 · position: (33.5106, -97.9651) · alt: 7917m · 488km/h
  - (2026-06-03) NIGER1 (Niger)
      icao24: 062f2e · position: (35.477, 17.5242) · alt: 11887m · 866km/h
  - (2026-06-03) PAT657 (United States)
      icao24: adfe53 · position: (38.4615, -94.6172) · alt: 7315m · 475km/h
  - (2026-06-03) PAT283 (United States)
      icao24: adfe92 · position: (39.7597, -112.353) · alt: 6629m · 517km/h

### GDACS — global disaster alerts — 29 new of 122 total
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-02) [Green] Tropical Cyclone ONE-E-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 102 km/h)
  - (2026-06-02) [Green] Tropical Cyclone ONE-E-26
      Tropical Cyclone · Green alert · · Tropical Depression (maximum wind speed of 102 km/h)

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-06-03) Delaware Supreme Court: Camden Foley v. Session Corp.
  - (2026-06-02) U.S. Supreme Court: Allen v. Milligan
  - (2026-06-02) U.S. Court of Appeals, 7th Cir.: United States v. Thomas Hawkins
  - (2026-06-02) U.S. Court of Appeals, 1st Cir.: United States v. Maldonado
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. James
  - (2026-06-02) U.S. Court of Appeals, 5th Cir.: United States v. Squire

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 115 total
  - (2026-06-02) [OFAC] Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question - Office of Foreign Assets Control (.g…
      Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-05-29) [OFAC] 1249 - Office of Foreign Assets Control (.gov)
      1249 Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-06-03) [USASpending] $3,044,069,155 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-06-03) [USASpending] $2,530,079,189 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-06-03) M 5.7 - 154 km WSW of Pistol River, Oregon
      M5.7 · 154 km WSW of Pistol River, Oregon · depth 10 km
  - (2026-06-03) M 5.6 - Vanuatu region
      M5.6 · Vanuatu region · depth 10 km
  - (2026-06-03) M 5.1 - 76 km S of Daroot-Korgon, Kyrgyzstan
      M5.1 · 76 km S of Daroot-Korgon, Kyrgyzstan · depth 10 km
  - (2026-06-03) M 5.1 - 64 km W of Petrolia, CA
      M5.08 · 64 km W of Petrolia, CA · depth 0.150000005960464 km
  - (2026-06-03) M 4.9 - Pitcairn Islands region
      M4.9 · Pitcairn Islands region · depth 10 km
  - (2026-06-03) M 4.7 - 142 km SSE of Vilyuchinsk, Russia
      M4.7 · 142 km SSE of Vilyuchinsk, Russia · depth 61.892 km

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-06-03) Will Australia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $9,972,620 · resolves 2026-07-20
  - (2026-06-03) Roland Garros ATP: Felix Auger-Aliassime vs Flavio Cobolli
      yes price: 56% · 24h volume: $3,229,463 · resolves 2026-06-10
  - (2026-06-03) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,131,446 · resolves 2026-07-20
  - (2026-06-03) Knicks vs. Spurs
      yes price: 36% · 24h volume: $1,618,481 · resolves 2026-06-04
  - (2026-06-03) Counter-Strike: Liquid vs MIBR (BO1) - IEM Cologne Major Stage 1
      yes price: 0% · 24h volume: $1,050,098 · resolves 2026-06-03
  - (2026-06-03) Counter-Strike: THUNDER dOWNUNDER vs BIG (BO1) - IEM Cologne Major Stage 1
      yes price: 0% · 24h volume: $1,040,644 · resolves 2026-06-03

### Congressional STOCK Act Trades (House + Senate) — 8 new of 49 total
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess +0.6% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-08) [Senate] Sheldon Whitehouse (D): Sale (Partial) NVDA ($100,001 - $250,000) (excess +0.6% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: NVDA (Stock). Type: Sale (Partial). Amount range: $100,001 - $250,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY sin…
  - (2026-05-07) [Senate] Sheldon Whitehouse (D): Sale (Partial) ORCL ($15,001 - $50,000) (excess +21.9% vs SPY)
      Member: Sheldon Whitehouse (D, senate). BioGuide: W000802. Asset: ORCL (Stock). Type: Sale (Partial). Amount range: $15,001 - $50,000. Transaction date: 2026-05-07. Disclosure date: 2026-06-02. Excess return vs SPY since…
  - (2026-05-15) [House] Virginia Foxx (R): Purchase ARLP ($1,001 - $15,000) (excess -1.3% vs SPY)
      Member: Virginia Foxx (R, house). BioGuide: F000450. Asset: ARLP (ST). Type: Purchase. Amount range: $1,001 - $15,000. Transaction date: 2026-05-15. Disclosure date: 2026-06-02. Excess return vs SPY since disclosure: -1.…
  - (2026-05-08) [House] Kevin Hern (R): Exchange DVN ($15,001 - $50,000) (excess -1.6% vs SPY)
      Member: Kevin Hern (R, house). BioGuide: H001082. Asset: DVN (ST). Type: Exchange. Amount range: $15,001 - $50,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Excess return vs SPY since disclosure: -1.64%…
  - (2026-05-08) [House] Kevin Hern (R): Exchange CTRA ($15,001 - $50,000)
      Member: Kevin Hern (R, house). BioGuide: H001082. Asset: CTRA (ST). Type: Exchange. Amount range: $15,001 - $50,000. Transaction date: 2026-05-08. Disclosure date: 2026-06-02. Description: COTERRA MERGED INTO DEVON.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 40 total
  - (2026-06-03) #29 Jeff Yass — $67.44B
      United States · Finance & Investments · source: Trading, investments
  - (2026-06-03) MOVER ▼ Steve Ballmer — $134.82B ($-3.79B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-06-03) MOVER ▲ Rob Walton & family — $135.33B (+$2.92B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-06-03) MOVER ▲ Jim Walton & family — $132.63B (+$2.92B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-06-03) MOVER ▲ Alice Walton — $123.68B (+$2.85B since yesterday)
      United States · Fashion & Retail · source: Walmart

### Macro indicators — latest values (FRED) — 4 new of 8 total
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-04-01) [Inflation] CPI Core (ex food & energy, SA) (CPILFESL)
      latest: 335.423 as of 2026-04-01
  - (2026-04-01) [Inflation] Core PCE (PCEPILFE)
      latest: 129.63 as of 2026-04-01
  - (2026-05-29) [FX] EUR/USD (DEXUSEU)
      latest: 1.1679 as of 2026-05-29

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-03) [Marginal Revolution] Sentences to ponder
      In 2019, there were about 150,000 people working in autism therapy. Six years later, there were 654,000—more than the number of people who work in mining and logging, or telecommunications, or at the US Postal Service. T…
  - (2026-06-03) [Marginal Revolution] Consent-based laws and aggregate fertility
      This paper examines how expanding the legal definition of sexual assault affects fertility and sexual behavior, using a panel of European countries. I find that switching to tacit consent-based legislation reduces fertil…
  - (2026-06-02) [Marginal Revolution] Big if true
      Several important questions — such as the possibility of debt-rollover without primary surpluses — turn on whether the present value of the aggregate endowment is finite, i.e., whether the economic growth rate under the…
  - (2026-06-02) [Conversable Economist] Does Leniency for First Offenders Pay Off?
      Consider a person who is convicted of a misdemeanor. It is their first offense. Should that person be punished to the full extent of the law, or dealt with more leniently? Depending on one’s prejudices, a theoretical cas…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: issued, personnel, certain, enforcement, proposed, service, guard, program, coast, captain, safety, marine
- state_bills: today=241, 7d-median=155, 14d-median=155; carrying terms: employee, including, grant, services, related, various, whose, claims, prohibits, retirement, death, budget
- state_news: today=816, 7d-median=695, 14d-median=708; carrying terms: friends, services, httperror, storm, research, handful, really, birmingham, found, choose, agency, involving
- local_news: today=246, 7d-median=246, 14d-median=247; carrying terms: found, history, among, injured, office, large, ballot, culture, according, shooting, years, local
- foreign_news: today=855, 7d-median=855, 14d-median=858; carrying terms: services, httperror, research, trading, align, highway, autopsy, satellite, applauded, moscow, alarm, algeria
- chinese_internal: today=289, 7d-median=270, 14d-median=274; carrying terms: cbmiyefvx, cbmia, cbmibkfvx, cbmixkfvx, cbmiykfvx, cbmiaefvx, china, color, cbmiw, google, property, cbmiakfvx
- russian_internal: today=1116, 7d-median=964, 14d-median=992; carrying terms: press, centcom, httperror, associated, telegram, financial, spiegel, istories, found, tasnim, client, bloomberg
- ukrainian_internal: today=129, 7d-median=122, 14d-median=122; carrying terms: including, focused, httperror, claims, volodymyr, moscow, armed, found, hromadske, civilian, injured, missiles
- ukraine_theater: today=279, 7d-median=290, 14d-median=299; carrying terms: hqemhvczfovgtbdg, nvhzyky, vdknldmfwegfhnu, httperror, various, rmjgqnf, manama, jtdfjkbejyshqznlz, arabia, aulsdndnuwy, nmekdymwzfwxywzlj, algeria
- paper_bets: today=145, 7d-median=143, 14d-median=142; carrying terms: district, candidate, binance, another, nuclear, retirement, prime, seats, succeed, signed, kalshi, miami
- weather: today=72, 7d-median=107, 14d-median=110; carrying terms: flooding, including, around, streams, river, pattern, drier, create, potential, weekend, please, mount
- macro: today=8, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: china, kospi, france, cotton, sugar, crude, commodity, natural, australia, mexico, crypto, copper
- sanctions_procurement: today=115, 7d-median=101, 14d-median=100; carrying terms: serious, usmca, flight, services, related, hybrid, respect, claims, ruaulkefbwvuxpz, authorities, river, armed
- congressional_trades: today=49, 7d-median=40, 14d-median=20; carrying terms: amount, transaction, description, since, rycey, bernardo, executive, brian, souhy, stock, house, david
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: smith, bondi, america, vasquez, blanche, fernandez, group, veterans, castillo, kenneth, attorney, patria
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, david, financial, group, holdings, filer, chase, jpmorgan, trust
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: lindsey, krishnamoorthi, committee, house, disbursements, james, ossoff, johnson, cycle, alexandria, receipts, congress
- gdelt_regions: today=12, 7d-median=12, 14d-median=12
- gdelt_gkg: today=50, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=15, 14d-median=12; carrying terms: ground, position, belgium, bulgaria, germany, kingdom, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: validation, service, authentication, directx, reader, acrobat, denial, vendor, langflow, trend, premise, drupal
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=122, 7d-median=109, 14d-median=109
- usgs_quakes: today=11, 7d-median=10, 14d-median=10
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, volume, resolves, price, world, peace, bitcoin, roland, coast, ivory, garros, turkiye
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: conversable, class, marginal, https, revolution, economist, story, marginalrevolution, service, people, questions, paying
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: pelosi, williams, ogles, lloyd, alsobrooks, aguilar, crank, maxwell, clarence, services, diana, moody
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, identify, market, consensus, placement, either, today, sufficient, unavailable, evidence, converges, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*