# WORLDSCOPE morning brief — 2026-06-03

## Headline
3106 new items across 27 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (717) · International News + Multilateral Institutions (611) · State-Level News (393) · World leaders & government officials (324) · Chinese Internal News (236) · Local News: St. Louis + Atlanta (199) · Ukraine Theater (total-war monitoring) (126) · GDELT GKG — themes / entities / watch areas (125) · U.S. Weather + Severe / Climate Outlooks (71) · Ukrainian Internal News (national + local Kyiv) (64) · SEC Form 4 insider transactions (recent) (40) · U.S. Federal Action (35)

## What changed today
### Russian Internal News (state + in-exile) — 717 new of 1176 total
  - (2026-06-03) Сразу две россиянки вышли в полуфинал «Роллан Гаррос». Это случилось впервые за 17 лет | LEDE: Российские теннисистки Мирра Андреева и Диана Шнайдер вышли в полуфинал Открытого чемпионата Фр] (ru: Сра…
      Российские теннисистки Мирра Андреева и Диана Шнайдер вышли в полуфинал Открытого чемпионата Франции по теннису.
  - (2026-06-03) Советник Сечина (он же бывший раскрытый шпион) заявил на ПМЭФ, что Россия будет воевать следующие «пару десятилетий» | LEDE: Россия будет находиться в следующие «пару десятилетий» в состояни] (ru: Сов…
      Россия будет находиться в следующие «пару десятилетий» в состоянии войны, а в стране появятся два «воюющих» поколения, заявил Андрей Безруков, политолог и советник главы «Роснефти» Игоря Сечина.
  - (2026-06-03) «Десятки тысяч погибших — это не абстракция. Это можете быть вы. Вас оставят умирать в грязи». Генсек НАТО предостерег россиян от вербовки на фронт | LEDE: Генеральный секретарь НАТО Марк Рю] (ru: «Де…
      Генеральный секретарь НАТО Марк Рютте обратился к российской молодежи с призывом не поддаваться вербовке на войну. С таким заявлением он выступил во время визита в Киев.
  - (2026-06-03) Патриарх Кирилл отправил в Бразилию митрополита Илариона. Его подозревали в перевозке наркотиков в Чехии | LEDE: Глава Русской православной церкви патриарх Кирилл отправил митрополита Иларио] (ru: Пат…
      Глава Русской православной церкви патриарх Кирилл отправил митрополита Илариона, которого в Чехии заподозрили в перевозке наркотиков, на служение в Аргентинско-Южноамериканскую епархию.
  - (2026-06-03) На ПМЭФ выступили родственницы Путина. Дочь говорила об импортозамещении лекарств, внучатая племянница — о центрах здоровья и рождаемости в РЖД | LEDE: В первый день Петербургского междунаро] (ru: На…
      В первый день Петербургского международного экономического форума на мероприятии выступили две родственницы Владимира Путина: младшая дочь Катерина Тихонова и двоюродная внучатая племянница президента Елена Фисенко.
  - (2026-06-03) В Великобритании протесты и беспорядки из-за убийства 18-летнего Генри Новака. Перед гибелью раненого студента арестовали полицейские, поверив его убийце. Тот заявлял, что сам Новак напал на не] (ru:…
      В Великобритании разгорается скандал вокруг дела об убийстве 18-летнего студента Генри Новака, который погиб в конце 2025 года в Саутгемптоне. Его несколько раз ударил ножом 23-летний Викрам Дигва. 1 июня суд приговорил…

### International News + Multilateral Institutions — 611 new of 856 total
  - (2026-06-03) [Global] Kidnappings, threats and ‘protection fees’: how can Mexico confront rise in deadly extortion?
  - (2026-06-02) [Global] Trump administration proposes 25% tariffs on Brazil despite US trade surplus
  - (2026-06-02) [Global] Cricket Canada suspended over allegations of gang-linked corruption
  - (2026-06-03) [Global] Diphtheria outbreak: residents of remote NT community say health clinic has no hand sanitiser
  - (2026-06-03) [Global] NSW motorists who use medicinal cannabis may soon be able to drive without fear of major penalty
  - (2026-06-03) [Global] Anti-abortion activists are trying to limit access in NSW – and they are just getting started

### State-Level News — 393 new of 828 total
  - (2026-06-02) [Alabama] Flags Lowered Honoring Former State Senator John Emanuel Amari
      Download
  - (2026-06-03) [Connecticut] CT GOP candidate defiant in face of criticism for anti-gay post
      <img width="1024" height="671" src="https://ctmirror.org/wp-content/uploads/2026/06/3D37AC1D-422B-4703-9459-F3E41951067F-1024x671.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=…
  - (2026-06-03) [Connecticut] Here are the 6 things the CT-Puerto Rico Trade Commission will focus on
      <img width="1024" height="732" src="https://ctmirror.org/wp-content/uploads/2026/06/CTPublic_PR-Trade-Commission-1024x732.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-06-03) [Connecticut] CT lawmakers rejected 3-year bachelor’s degrees. But the trend isn’t going away
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/AP24178495361034-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy…
  - (2026-06-03) [Connecticut] More education funds, no funding formula reform
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/05/Shepard-Fisher-4.21.26-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading…
  - (2026-06-03) [Connecticut] When schools lose the people who came back to serve them
      <img width="870" height="572" src="https://ctmirror.org/wp-content/uploads/2026/04/Sand-school.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="https…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 236 new of 294 total
  - (2026-06-02) Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes - Caixin Global
      Analysis: China’s Local Fiscal Recovery Hides Scramble to Plug Budget Holes Caixin Global
  - (2026-06-03) 从市长到主席边升官边敛财 62岁正省级女高官王莉霞将受审 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE45QnNra2tNWkNrMHVSNTc4WVJSR2dFQk5kemRqcnQycmNZdF80ZzlDbXdMUHJsZ1dhb0VTRkVCdWJ] (zh:…
      从市长到主席边升官边敛财 62岁正省级女高官王莉霞将受审 china.caixin.com
  - (2026-06-02) 老虎证券6月12日起将停止存量用户中国境内开仓加仓 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0tUVVvbGVEWXRrdWFac1RUMVhHeHVIWTZidDVfNDA4dzAwbjBqczlaRGFrYUlpejc3d1BueDlENTNSckFsMThQTE9EczVf] (zh:…
      老虎证券6月12日起将停止存量用户中国境内开仓加仓 财新
  - (2026-06-03) 超越美债，黄金成全球官方储备第一大资产 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9mekp5dEl1M3d5X19vNktPcjFvRjh3MnRPTlVaUnF4MFJxVWJRdlBYOUdLNlVRMWN0Zy1zakZoM0FoYlN1emloTThOV3NhWDczY0] (zh:…
      超越美债，黄金成全球官方储备第一大资产 财新
  - (2026-06-02) “耿同学”打假再有战果 《自然》答财新：正评估相关信息 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBfQ0pxMW9nS2d6b0RkLWY1TTlYR1BaOGltMXloRHVpZWlxM3lTaUcxLUd6ckJBMTExSVRWajBUbXBRcVJMQjJYLV9VZj] (zh:…
      “耿同学”打假再有战果 《自然》答财新：正评估相关信息 财新
  - (2026-06-02) 匈牙利新总理欲修法解职总统 试图逼退欧尔班任命的一批高官 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1BckFoR0RobWVQcmd6Qm5RMXp3aXZRZ2NnZDRHU005MVk4WE55N1F3WWpSMkFHYXloRmo3czU0Y2lsd0N2R0ppU19YZ] (zh:…
      匈牙利新总理欲修法解职总统 试图逼退欧尔班任命的一批高官 财新

### Local News: St. Louis + Atlanta — 199 new of 247 total
  - (2026-06-03) [St. Louis] Honey Bee Tea owners to open Honey Coffee & Matcha in Brentwood
      Since opening Honey Bee Tea in 2022, owners Hai Tang and Moon Duong have capitalized on the popularity of boba tea, expanding to five locations across the St. Louis metro area. Now, the husband-and-wife team is poised to…
  - (2026-06-03) [St. Louis] Police Board agrees to pause action on double-digit raises—but only for two weeks
      Mayor Cara Spencer won a rare—and minor—consession from the rest of the Board of Police Commissioners this morning when they voted to postpone a vote on double-digit raises for command staff. Those proposed raises were a…
  - (2026-06-03) [St. Louis] Is the St. Charles Farmers Market the most kid-friendly in the region?
      A change in location may have been all the St. Charles Farmers Market needed to become one of the area’s most family-friendly weekend destinations. This season, the market packed up its produce, parted ways with the City…
  - (2026-06-03) [St. Louis] A house in Wildwood hits the market
      Thoughtful Design Built in 2019, the residence was conceived with an intuitive floor plan, striking details, and carefully considered design elements. Cape Cod-InspiredThis four-bedroom, five-bathroom home is as charming…
  - (2026-06-03) [St. Louis] Police Board’s big raises mean an even bigger increase for St. Louis’ fire department
      On Monday night, the state-appointed Board of Police Commissioners proposed significant pay increases for high-ranking officers: 16 percent for lieutenants, 18 percent for captains, 20 percent for majors, and 22 percent…
  - (2026-06-03) [St. Louis] Broadway star Kate Baldwin helps Opera Theatre of Saint Louis expand its horizons in a glorious show
      One of Broadway’s big stars is in St. Louis this summer, but she’s not at The Muny. Two-time Tony Award nominee Kate Baldwin is starring in The Light in the Piazza as it makes its debut at Opera Theatre of Saint Louis. I…

### Ukraine Theater (total-war monitoring) — 126 new of 279 total
  - (2026-06-03) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.107 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.87 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.292, 25.111 (FRP 0.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 0.51 MW
  - (2026-06-02) [FIRMS] thermal anomaly 45.295, 25.110 (FRP 1.04 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2341Z, FRP 1.04 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.849, 29.988 (FRP 2.77 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 2.77 MW
  - (2026-06-02) [FIRMS] thermal anomaly 52.701, 31.867 (FRP 0.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-02 2339Z, FRP 0.8 MW

### GDELT GKG — themes / entities / watch areas — 125 new of 125 total
  - (2026-06-03) [Russia oil sanctions perimeter · themes] Godståg har spårat ur i Göteborg
      aftonbladet.se · Swedish · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] Trump abre la puerta a reunirse con el líder supremo iraní Mojtaba Jameneí
      diario1.com · Spanish · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] Stižu snimke iranske osvete , Arapi bijesni . Rubio : Rat je gotov , mi smo pobijedili
      index.hr · Croatian · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] कुवैत एयरपोर्ट पर हमले में भारतीय की मौत , विदेश मंत्रालय ने ईरान को सुना डाला
      livehindustan.com · Hindi · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] ESTADOS UNIDOS | Marco Rubio niega que el objetivo de la guerra con Irán fuera forzar un cambio de régimen
      lacronicabadajoz.com · Spanish · tone NA
  - (2026-06-03) [Russia oil sanctions perimeter · themes] Cruise Passenger Hailed As Hero For Jumping Into Water To Save Elderly Man
      star941fm.iheart.com · English · tone NA

### U.S. Weather + Severe / Climate Outlooks — 71 new of 76 total
  - (2026-06-03) [Severe] Flash Flood Warning: Flash Flood Warning issued June 3 at 12:21PM CDT until June 3 at 12:30PM CDT by NWS Midland/Odessa TX
      The heavy rain has ended. Please continue to heed remaining road closures. A Flood Watch remains in effect until 100 AM CDT /1200 AM MDT/ Thursday for portions of southeast New Mexico and Texas.
  - (2026-06-03) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-03) [Severe] Flood Watch: Flood Watch issued June 3 at 11:17AM MDT until June 4 at 12:00AM MDT by NWS Midland/Odessa TX
      * WHAT...Flash looding caused by excessive rainfall is possible. * WHERE...Portions of southeast New Mexico, including the following areas, Central Lea, Eddy County Plains, Guadalupe Mountains of Eddy County, Northern Le…
  - (2026-06-03) [Severe] Flash Flood Warning: Flash Flood Warning issued June 3 at 11:33AM CDT until June 3 at 2:30PM CDT by NWS Midland/Odessa TX
      FFWMAF The National Weather Service in Midland/Odessa has issued a * Flash Flood Warning for... East Central Culberson County in southwestern Texas... North Central Jeff Davis County in southwestern Texas... Reeves Count…
  - (2026-06-03) [Moderate] Rip Current Statement: Rip Current Statement issued June 3 at 11:26AM CDT until June 7 at 7:00AM CDT by NWS Mobile AL
      * WHAT...For the High Rip Current Risk, dangerous rip currents. For the High Surf Advisory, large breaking waves of 4 to 6 feet expected in the surf zone. * WHERE...In Alabama, Mobile Coastal and Baldwin Coastal Counties…
  - (2026-06-03) [Severe] Red Flag Warning: Red Flag Warning issued June 3 at 10:10AM MDT until June 4 at 7:00PM MDT by NWS Grand Junction CO
      The National Weather Service in Grand Junction has issued a Red Flag Warning for gusty winds, low relative humidity and dry fuels, which is in effect from 1 PM to 7 PM MDT Thursday. * AFFECTED AREA...In Colorado, Fire We…

### Ukrainian Internal News (national + local Kyiv) — 64 new of 130 total
  - (2026-06-03) Greece Files Protest With Kyiv Over Armed Ukrainian Sea Drone Found Near Lefkada
      Athens on Wednesday submitted an official diplomatic protest to Kyiv over a naval drone found off the Greek island of Lefkada in May. Greek authorities said the explosive-laden vessel posed risks to civilian traffic and…
  - (2026-06-03) ‘Nothing Stops Ukrainian Art’ – Met Opera Chief Peter Gelb
      Peter Gelb, general manager of New York’s Metropolitan Opera, told Kyiv Post about the institution’s support for Ukraine since Russia’s full-scale invasion. He reflected on Ukraine’s resilience, the role of culture in wa…
  - (2026-06-03) Ukraine to Deliver Record 1,500 Motorcycles to Frontline Troops in 2026
      Ukraine’s Defense Procurement Agency on Wednesday signed a contract for 1,500 motorcycles for the Armed Forces, three times last year’s total motorbike buy. The contract was awarded through a competitive tender process t…
  - (2026-06-03) Ukraine Is Doing Better: Notes From the Sidelines of the Black Sea Security Forum 2026
      There were many important discussions at the Black Sea Security Forum 2026 regarding security and Ukraine’s possible future strategies. However, the most important takeaway was optimism. Everyone shared the same assessme…
  - (2026-06-03) WATCH: Ukraine’s Fire Point Tests Missile for Homegrown Anti-Ballistic Shield as Air Defense Shortages Bite
      Ukrainian defense company Fire Point has successfully tested its FP-7.X missile, which will serve as the basis for the planned FREYJA anti-ballistic defense system, providing Kyiv with a lower-cost alternative to Patriot…
  - (2026-06-03) Finland Seizes €3.7 Million in Russian Funds to Compensate Naftogaz
      Finland’s National Enforcement Authority has frozen nearly €4 million belonging to Russia following a compensation claim by Naftogaz. The funds are part of a broader effort to enforce an international arbitration ruling…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-03) [PERRY DEXTER V] Form 4 (Reporting)
      filed 2026-06-03 17:24 UTC · role: Reporting — Filed: 2026-06-03 AccNo: 0000811589-26-000081 Size: 4 KB
  - (2026-06-03) [FIRST BANCORP /NC/] Form 4 (Issuer)
      filed 2026-06-03 17:24 UTC · role: Issuer — Filed: 2026-06-03 AccNo: 0000811589-26-000081 Size: 4 KB
  - (2026-06-03) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-03 17:23 UTC — Filed: 2026-06-03 AccNo: 0001213900-26-064592 Size: 2 MB
  - (2026-06-03) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-03 17:23 UTC — Filed: 2026-06-03 AccNo: 0001213900-26-064592 Size: 2 MB
  - (2026-06-03) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-06-03 17:23 UTC — Filed: 2026-06-03 AccNo: 0001918704-26-015517 Size: 562 KB
  - (2026-06-03) 424B3 - Prosper Funding LLC (0001542574) (Filer)
      filed 2026-06-03 17:22 UTC — Filed: 2026-06-03 AccNo: 0001542574-26-000283 Size: 77 KB

### U.S. Federal Action — 35 new of 35 total
  - (2026-06-03) Removing Unnecessary and Counterproductive Restrictions on Access to Federal Lands
  - (2026-06-03) Realigning United States Core Childhood Vaccine Recommendations With Best Practices From Peer, Developed Countries
  - (2026-06-03) 1,2-dibromo-3-chloropropane; 1, 3-Butadiene; 13 Carcinogens (4-Nitrobiphenyl, etc.); Acrylonitrile; Asbestos; Benzene; Cadmium; Coke Oven Emissions; Cotton Dust; Ethylene Oxide; Formaldehyde; Inorgani…
      OSHA is scheduling a series of informal public hearings on the above-listed proposed rules. The public hearings will begin on August 19, 2026. All of the proposed rules listed in this notice were published in the Federal…
  - (2026-06-03) New Animal Drugs; Approval of New Animal Drug Applications; Withdrawal of Approval of New Animal Drug Applications; Change of Sponsor; Change of Sponsor Address; Correction
      The Food and Drug Administration (FDA or we) is amending the final rule that published in the Federal Register of April 16, 2026. That final rule updated regulations to reflect application-related actions for new animal…
  - (2026-06-03) Guidance on Tax-Exempt Refunding Bonds; Hearing
      This document contains proposed regulations that would update certain arbitrage rules and definitions applicable to tax-exempt and other tax-advantaged bonds by clarifying the time and manner for requesting refunds of ov…
  - (2026-06-03) Safety Zone; Fireworks Displays Within the USCG East District (Formerly Fifth Coast Guard District); The Wharf, Washington, DC
      The Coast Guard will enforce a safety zone for a fireworks display at "The Wharf D.C.," in Washington, DC, to provide for the safety of life on navigable waterways during this event. Our regulation for recurring safety z…

### GDACS — global disaster alerts — 31 new of 124 total
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in Vanuatu Islands Region
      Earthquake · Green alert · Vanuatu Islands Region · Magnitude 5.6M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-03) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.7M, Depth:10km
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)
  - (2026-06-02) [Green] Tropical Cyclone AMANDA-26
      Tropical Cyclone · Green alert · · Tropical Storm (maximum wind speed of 102 km/h)

### Paper Trading Scorecard — 30 new of 142 total
  - (2026-06-03) [Polymarket] SpaceX IPO closing market cap above $4T?
      This market will resolve to “Yes” if the official closing price for SpaceX’s market capitalization on its first trading day is above the value specified in the title. Otherwise, it will resolve to “No”. If no IPO occurs…
  - (2026-06-03) [Polymarket] Will Donald Trump publicly insult Tucker Carlson by June 30, 2026?
      This market will resolve to "Yes" if Donald Trump makes any public statement in which he insults, mocks, or attacks the listed individual personally or professionally in a clearly negative manner between market creation…
  - (2026-06-03) [Polymarket] Will Donald Trump not announce a next United States Attorney General by June 30?
      This market will resolve according to the first individual Donald Trump announces as his pick to be United States Attorney General. An announcement from Donald Trump or the Trump administration stating their intent to no…
  - (2026-06-03) [Polymarket] NATO x Russia military clash by June 30, 2026?
      This market will resolve to "Yes" if there is a military encounter between the military forces of a NATO country and Russia between January 12, and June 30, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".…
  - (2026-06-03) [Polymarket] Predict.fun FDV above $200M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Predict.fun's governance token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The toke…
  - (2026-06-03) [Polymarket] Will Jamie Dimon win the 2028 US Presidential Election?
      The 2028 US Presidential Election is scheduled to take place on November 7, 2028. This market will resolve to the person who wins the 2028 US Presidential Election. The resolution source for this market is the Associated…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-06-03) Delaware Supreme Court: Camden Foley v. Session Corp.
  - (2026-06-03) U.S. Court of Appeals, 3rd Cir.: Secretary United States Department of Labor v. Comprehensive Healthcare Management Services LLC
  - (2026-06-03) U.S. Court of Appeals, 9th Cir.: Lnu v. Blanche
  - (2026-06-03) U.S. Court of Appeals, 9th Cir.: United States v. Deborba
  - (2026-06-02) U.S. Supreme Court: Allen v. Milligan
  - (2026-06-02) U.S. Court of Appeals, 7th Cir.: United States v. Thomas Hawkins

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-03) [South Korea] Voter turnout comes to second - highest for local election at 61 %
      koreaherald.com · English
  - (2026-06-03) [South Korea] Yoo Byung Jae company BLACKPAPER cites Misunderstanding in internship posting , plans to remove controversial job advertisement
      allkpop.com · English
  - (2026-06-03) [South Korea] Jang Geun Suk reveals he had a crush on Ha Ji Won , I even confessed my feelings to her
      allkpop.com · English
  - (2026-06-03) [South Korea] BTS Jin joins celebrities encouraging voter participation on election day
      allkpop.com · English
  - (2026-06-03) [South Korea] At polling stations , voters look beyond local pledges
      koreaherald.com · English
  - (2026-06-03) [South Korea] Democratic candidates lead major mayoral contests , exit poll shows
      koreaherald.com · English

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-06-03) M 5.7 - 154 km WSW of Pistol River, Oregon
      M5.7 · 154 km WSW of Pistol River, Oregon · depth 10 km
  - (2026-06-03) M 5.6 - Vanuatu region
      M5.6 · Vanuatu region · depth 10 km
  - (2026-06-03) M 5.1 - 64 km W of Petrolia, CA
      M5.1 · 64 km W of Petrolia, CA · depth 0.150000005960464 km
  - (2026-06-03) M 5.1 - 76 km S of Daroot-Korgon, Kyrgyzstan
      M5.1 · 76 km S of Daroot-Korgon, Kyrgyzstan · depth 10 km
  - (2026-06-03) M 4.9 - 58 km NNE of Labuan Bajo, Indonesia
      M4.9 · 58 km NNE of Labuan Bajo, Indonesia · depth 178.883 km
  - (2026-06-03) M 4.9 - Pitcairn Islands region
      M4.9 · Pitcairn Islands region · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 115 total
  - (2026-06-02) [OFAC] Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question - Office of Foreign Assets Control (.g…
      Counter Terrorism and Iran-related Designations; Democratic Republic of the Congo-related Designations; Issuance of Iran-related Frequently Asked Question Office of Foreign Assets Control (.gov)
  - (2026-05-29) [OFAC] 1249 - Office of Foreign Assets Control (.gov)
      1249 Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-06-02) [OFAC] 1257 - Office of Foreign Assets Control (.gov)
      1257 Office of Foreign Assets Control (.gov)
  - (2026-06-03) [USASpending] $3,044,069,155 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-06-03) [USASpending] $2,530,079,189 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-06-03) Will Australia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $10,099,855 · resolves 2026-07-20
  - (2026-06-03) Roland Garros ATP: Felix Auger-Aliassime vs Flavio Cobolli
      yes price: 10% · 24h volume: $4,078,515 · resolves 2026-06-10
  - (2026-06-03) Will Ecuador win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $2,258,731 · resolves 2026-07-20
  - (2026-06-03) Knicks vs. Spurs
      yes price: 36% · 24h volume: $1,708,405 · resolves 2026-06-04
  - (2026-06-03) Will Colombia win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,372,494 · resolves 2026-07-20
  - (2026-06-03) Will Oh Se-hoon win the 2026 Seoul Mayoral Election
      yes price: 5% · 24h volume: $1,087,824 · resolves 2026-06-03

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 4 new of 5 total
  - (2026-06-03) [Marginal Revolution] Richard Feynman’s formula for the best holiday restaurant
      According to Feynman’s approach, in this context, people should try a different restaurant each night until they find one that exceeds a particular threshold that reflects a desired quality. In Feynman’s equations this t…
  - (2026-06-03) [Marginal Revolution] Sentences to ponder
      In 2019, there were about 150,000 people working in autism therapy. Six years later, there were 654,000—more than the number of people who work in mining and logging, or telecommunications, or at the US Postal Service. T…
  - (2026-06-03) [Marginal Revolution] Consent-based laws and aggregate fertility
      This paper examines how expanding the legal definition of sexual assault affects fertility and sexual behavior, using a panel of European countries. I find that switching to tacit consent-based legislation reduces fertil…
  - (2026-06-02) [Conversable Economist] Does Leniency for First Offenders Pay Off?
      Consider a person who is convicted of a misdemeanor. It is their first offense. Should that person be punished to the full extent of the law, or dealt with more leniently? Depending on one’s prejudices, a theoretical cas…

### Macro indicators — latest values (FRED) — 2 new of 10 total
  - (2026-04-01) [Inflation] CPI (headline, SA) (CPIAUCSL)
      latest: 332.407 as of 2026-04-01
  - (2026-04-01) [Growth] Personal consumption (PCE)
      latest: 21979.4 as of 2026-04-01

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 40 total
  - (2026-06-03) #29 Jeff Yass — $67.44B
      United States · Finance & Investments · source: Trading, investments
  - (2026-06-03) MOVER ▲ Warren Buffett — $141.66B (+$0.45B since yesterday)
      United States · Finance & Investments · source: Berkshire Hathaway

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-06-03) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 19 total
  - (2026-06-03) CVE-2026-45247 · Mirasvit Mirasvit Full Page Cache Warmer: Mirasvit Full Page Cache Warmer Deserialization of Untrusted Data Vulnerability
      vendor: Mirasvit · product: Mirasvit Full Page Cache Warmer · CISA remediation by 2026-06-06

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-03) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=35, 7d-median=30, 14d-median=30; carrying terms: safety, events, captain, service, certain, proposing, address, persons, personnel, program, within, action
- state_bills: today=0, 7d-median=155, 14d-median=148
- state_news: today=828, 7d-median=695, 14d-median=708; carrying terms: attorneys, birmingham, became, received, highly, agency, access, issues, holds, america, looks, working
- local_news: today=247, 7d-median=247, 14d-median=248; carrying terms: america, onlyfans, trump, evening, content, things, atlantamagazine, since, known, suspect, google, public
- foreign_news: today=856, 7d-median=856, 14d-median=858; carrying terms: scaling, playground, kunming, exchanges, became, africa, nanking, foundation, received, vollansky, agency, access
- chinese_internal: today=294, 7d-median=270, 14d-median=274; carrying terms: google, https, title, caixin, cbmiyefvx, color, cbmia, blank, cbmickfvx, cbmibkfvx, cbmixkfvx, rally
- russian_internal: today=1176, 7d-median=964, 14d-median=992; carrying terms: axios, times, russian, error, reuters, roland, found, novaya, forbidden, media, china, centcom
- ukrainian_internal: today=130, 7d-median=122, 14d-median=122; carrying terms: multiple, ballistic, refineries, urges, territory, invasion, sites, escalation, across, security, shadow, trump
- ukraine_theater: today=279, 7d-median=290, 14d-median=299; carrying terms: cuxpawe, rmjgqnf, slpztfjnmgplu, cuxnnklrsk, maintenance, aaxvzr, utkvn, lznlfuqkmzegpta, gwrevwoffxbtuzamdqyxdb, mtjfntvvwdfqnzflzzg, meptrwrsaf, uxsudorgvdbdlieekzrhczqvzvskw
- paper_bets: today=142, 7d-median=142, 14d-median=142; carrying terms: celsius, andrew, arizona, fuentes, creation, jpmorgan, officially, training, chase, primary, safety, population
- weather: today=76, 7d-median=107, 14d-median=110; carrying terms: continues, swimmers, hazard, today, formation, possible, deeper, streams, afdffc, atlantic, return, miami
- macro: today=10, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: india, cotton, germany, mexico, copper, equity, italy, kospi, shanghai, crypto, merval, index
- sanctions_procurement: today=115, 7d-median=101, 14d-median=100; carrying terms: respect, usaspending, maintenance, groups, boeing, transnistria, comments, resolutions, events, agency, annexation, criminal
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, error, quiverquant, quantitative, congresstrading, unauthorized, client, https, httperror
- billionaires: today=40, 7d-median=40, 14d-median=40
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: blanche, america, smith, group, ortiz, veterans, castillo, patria, general, attorney, laureano, gregory
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, financial, group, jpmorgan, chase, filer, trust, management, finance
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: krishnamoorthi, raised, brown, sherrod, lindsey, receipts, james, joseph, michael, warner, booker, ossoff
- gdelt_regions: today=12, 7d-median=12, 14d-median=12
- gdelt_gkg: today=125, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=15, 14d-median=12; carrying terms: position, ground, belgium, kingdom, germany, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=19, 7d-median=16, 14d-median=16; carrying terms: drupal, injection, denial, product, overflow, defender, bypass, directx, microsoft, authentication, service, premise
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=124, 7d-median=110, 14d-median=110
- usgs_quakes: today=12, 7d-median=10, 14d-median=10
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, resolves, peace, price, world, volume, bitcoin, roland, garros, ivory, coast, turkiye
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: https, conversable, revolution, economist, class, marginal, marginalrevolution, story, people, paying, service, screen
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: zinke, valadao, schmidt, marsha, dingell, delia, joyce, frost, kaptur, jefferson, grijalva, debbie
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, sufficient, paper, decision, identify, today, market, module, consensus, markets, converges, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks
- [2026-06-01] ECB press: ECB Consumer Expectations Survey results – April 2026
- [2026-06-02] ECB press: International role of the euro increased moderately in 2025
- [2026-06-02] ECB press: Boris Vujčić: A European perspective on currency and convergence

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*