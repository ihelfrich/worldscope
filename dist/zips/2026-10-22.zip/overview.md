# WORLDSCOPE morning brief — 2026-10-22

## Headline
3840 new items across 27 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (1082) · International News + Multilateral Institutions (846) · State-Level News (384) · World leaders & government officials (324) · Chinese Internal News (221) · Local News: St. Louis + Atlanta (212) · Ukraine Theater (total-war monitoring) (163) · U.S. Weather + Severe / Climate Outlooks (145) · Ukrainian Internal News (national + local Kyiv) (69) · State Legislative Action (68) · IT, InfoSys & cybersecurity news (last 7 days) (46) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 1082 new of 1164 total
  - (2026-10-22) В Кировской области отправили в отставку мэра Сосновки Никиту Горелова. Он получил пост по программе для «ветеранов СВО», но затем начал критиковать коррупцию | LEDE: В Кировской области отп] (ru: В К…
      В Кировской области отправили в отставку мэра города Сосновка Никиту Горелова — выпускника президентской кадровой программы «Время героев» для участников войны с Украиной. Об этом он сообщил в своем телеграм-канале.
  - (2026-10-22) Политолог Александр Кынев рассказал, что не может нормально передвигаться «с учетом полученных травм» при задержании. Суд все равно оставил его в СИЗО | LEDE: Мосгорсуд отказался отпустить и] (ru: Пол…
      Мосгорсуд отказался отпустить из СИЗО политолога Александра Кынева, обвиняемого по делу о покушении на сбыт наркотиков, сообщила «Медиазона».
  - (2026-10-22) Россия и Украина обменялись телами погибших военнослужащих | LEDE: Россия и Украина провели очередной обмен телами погибших военнослужащих, сообщают РБК и БелТА. ] (ru: Россия и Украина обменялись тел…
      Россия и Украина провели очередной обмен телами погибших военнослужащих, сообщают РБК и БелТА.
  - (2026-10-22) Большой стрим по случаю дня рождения «Медузы» уже сегодня! Гости: Екатерина Шульман, Антон Долин, Илья Колмановский, Анна Монгайт, Александр Плющев — и, конечно, создатели «Медузы». Вы тоже при] (ru:…
      «Медузе» 12 лет. Мы запустились в 2014 году, который из нынешнего времени кажется важным и переломным. Сегодня — в четверг, 22 октября, в 17:30 по московскому времени — мы проведем большой стрим, где будем вспоминать, ка…
  - (2026-10-22) «Что за хрень, Стив?» Американские конгрессмены возмущены тем, что Уиткофф назвал Путина «гуманистом». Оправдывать своего переговорщика пришлось Трампу и Вэнсу. Цепочка заявлений | LEDE: Спе] (ru: «Чт…
      Спецпосланник президента США Стив Уиткофф 21 октября побывал в Санкт-Петербурге и провел с президентом РФ Владимиром Путиным переговоры о завершении войны. В начале встречи Путин объявил, что освободил гражданина США Сти…
  - (2026-10-22) Трамп обвинил в провале российского наступления на Киев «глупого генерала», который завел танки в грязь. Так ли все было? И что это за генерал? Отвечает «Русская служба Би-би-си» | LEDE: Пре] (ru: Тра…
      Президент США неоднократно обещал завершить российско-украинскую войну в течение 24 часов, но мирные переговоры до сих пор существенно не продвинулись. Так же регулярно Дональд Трамп высказывается про первые дни полномас…

### International News + Multilateral Institutions — 846 new of 1049 total
  - (2026-10-22) [Global] Barclays cutting 5,000 jobs as it increases reliance on AI
      The bank says it is using more AI leading to a 5% reduction in its workforce.
  - (2026-10-21) [Global] The 'trillion pound' oil fund the government believes Britain could have built
      For the first time, the Treasury calculates how much the UK could have raised by investing North Sea proceeds.
  - (2026-10-22) [Global] Is an 'AI war' complicating your job search?
      How fair are AI recruitment tools that help decide our future, and what happens when we click "apply"?
  - (2026-10-21) [Global] Websites taken down worldwide as critical cyber-security update issued
      The vulnerabilities with PHP, a programming language widely used across the internet, have been described as the most significant ever found by AI.
  - (2026-10-22) [Global] What is PHP and why did it spark a global cyber-security scramble?
      AI uncovered long-hidden programming flaws, triggering a rare global cyber-security response.
  - (2026-10-22) [Global] No order, no seat: Starbucks China rolls out new store policy
      Starbucks says it is improving customers' in-store experience as it competes with homegrown rivals.

### State-Level News — 384 new of 758 total
  - (2026-10-22) [Alaska] Lights On Afterschool Day 2026
      WHEREAS, the health, safety, and education of Alaska’s children are fundamental to the happiness, success, and well-being of Alaska’s families and communities; and WHEREAS, when offered an array of opportunities tailored…
  - (2026-10-21) [California] Governor Newsom proclaims Disability Employment Awareness Month
      Source
  - (2026-10-21) [California] Governor Newsom announces new staff-led initiative at Corcoran to support rehabilitation and reentry
      Source
  - (2026-10-21) [California] Governor Newsom slams Trump’s disaster retreat as California prepares for dangerous El Niño storms
      Source
  - (2026-10-21) [Alabama] Thank Alabama Teachers Month
      Download
  - (2026-10-21) [Alabama] Careers in Construction Month
      Download

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 221 new of 273 total
  - (2026-10-22) 【商圈】太子集团群魔录：陈志、胡小伟以及整个电诈网络 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE5Tdkw3eU54cGVWLTBMNTY5MEM1SEF3WXlBVzhZMV9FX29YS3hUYklvZks3UWlwQ0NhN3hUaEMyNWNvSTRXYWkxN05OU] (zh:…
      【商圈】太子集团群魔录：陈志、胡小伟以及整个电诈网络 财新数据
  - (2026-10-22) 电气化时代的能源独立与大宗商品获取保障 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9UQ2xlaHIyNzNkVThuSzJIR3FUZ05iTWROaHdiS3NaX2pQWlNtN3dqTnNxRHg4ckc5U0poVFJhSGRTWmM5aHdMQXRtVDJPMWhQTn] (zh:…
      电气化时代的能源独立与大宗商品获取保障 财新
  - (2026-10-22) 美国见闻：AI的钱从哪里来，电从哪里来 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBxamUybi1STmVuRWJUcDNiYjdJYXpzdnlzV3hjV0N0Y1l5RFFvdWluRTNzRDFTVW4zenh2Yi1MZDM1UExSQlZaS3RubmsyclEyUE] (zh:…
      美国见闻：AI的钱从哪里来，电从哪里来 财新
  - (2026-10-22) 广西国营某农场将政府告上法庭，钦州市市长出庭应诉 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBMcTJ1VzZnZkVSY3NneGlEUGFyeVgxazNyU25RWnNlNWJIaVo0MDlJQXJ6eEE0dTBQMDFGTDhQMlh2am5ScTY0R3JzS01TR] (zh:…
      广西国营某农场将政府告上法庭，钦州市市长出庭应诉 财新
  - (2026-10-22) 今日开盘：沪指报3714.48点 涨幅0.04% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5KLWF5akFIMjAyMmxRUVBoZzVONWNrYXN3cWR4UTM3VXBzalRhM1hKaC1WMk1sWk5pXzhWOHkxNDlmLVRBbHlreFNldldNM] (zh:…
      今日开盘：沪指报3714.48点 涨幅0.04% 财新
  - (2026-10-22) MiniMax港股破发 市场为何重估AI模型公司？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5hTDB3T2FHRnZITC0xR3RxMGFQU29fd1RyVzFOWk1sM2NBYndaWmphOXljTDZaZkFjeG9VbDcxZlhCdnpqMTFQUmE3VHYz] (zh:…
      MiniMax港股破发 市场为何重估AI模型公司？ 财新

### Local News: St. Louis + Atlanta — 212 new of 252 total
  - (2026-10-22) [St. Louis] Incident at City Hall provided an education for St. Louis City Youth Council
      Criminal defense attorney Talmage Newton IV found himself on Wednesday night in a tug-of-war over his briefcase with a man who was likely homeless and almost certainly on drugs. In the process, Newton gave a lesson on th…
  - (2026-10-22) [St. Louis] Barnes & Noble will open in Creve Coeur in November
      Two years after Barnes & Noble launched a store inside the Saint Louis Galleria, the bookstore chain is ready to do it again: It plans to open a 25,000-square-foot store in what was once an Office Depot in Creve Coeur. T…
  - (2026-10-22) [St. Louis] Where in the Lou 10/22/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…
  - (2026-10-22) [St. Louis] Gioia’s Deli to open in Arnold in early December
      The St. Louis metro area’s southern suburbs are about to get more delicious: Gioia’s Deli is expanding to Jefferson County, with a slated opening of early December. The restaurant will take over a former Goodcents Subs s…
  - (2026-10-21) [St. Louis] Ben Poremba to open Esca Vino Spuntino, an Italian-inspired wine bar and bottle shop in the Delmar Maker District
      For five years, Ben Poremba and his wine director/right-hand-person, Luciano Racca, have been talking about opening a wine bar and bottle shop. The idea was to transport diners to the sort of enotecas and bodegas you’d f…
  - (2026-10-21) [St. Louis] Former Alton Steel property would become a data center under TerraWatt plan
      Nearly nine months after Alton Steel Inc. revealed it would cease operations for good, the company is moving forward with a proposal to sell the 381-acre industrial property in the Metro East to a developer eager to turn…

### Ukraine Theater (total-war monitoring) — 163 new of 474 total
  - (2026-10-22) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-21) [FIRMS] thermal anomaly 52.708, 34.448 (FRP 9.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-21 0907Z, FRP 9.55 MW
  - (2026-10-21) [FIRMS] thermal anomaly 52.585, 34.005 (FRP 5.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-21 0907Z, FRP 5.97 MW
  - (2026-10-21) [FIRMS] thermal anomaly 52.708, 34.448 (FRP 8.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-21 0907Z, FRP 8.53 MW
  - (2026-10-21) [FIRMS] thermal anomaly 52.703, 34.211 (FRP 7.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-21 0907Z, FRP 7.97 MW
  - (2026-10-21) [FIRMS] thermal anomaly 52.771, 34.162 (FRP 5.51 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-21 0907Z, FRP 5.51 MW

### U.S. Weather + Severe / Climate Outlooks — 145 new of 146 total
  - (2026-10-22) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued October 22 at 4:50AM MST until October 22 at 5:00AM MST by NWS Flagstaff AZ
      At 450 AM MST, a severe thunderstorm was located near Vernon, or 15 miles east of Show Low, moving northeast at 40 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hail damage to…
  - (2026-10-22) [Moderate] Special Weather Statement: Special Weather Statement issued October 22 at 5:48AM MDT by NWS Salt Lake City UT
      At 548 AM MDT, Doppler radar was tracking a strong thunderstorm 5 miles south of Panguitch, or 35 miles east of Cedar City, moving north at 40 mph. HAZARD...Half inch size hail. SOURCE...Radar indicated. IMPACT...Minor d…
  - (2026-10-22) [Moderate] Gale Warning: Gale Warning issued October 22 at 3:46AM AKDT until October 23 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-10-22) [Moderate] Gale Warning: Gale Warning issued October 22 at 3:46AM AKDT until October 23 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-10-22) [Moderate] Gale Warning: Gale Warning issued October 22 at 3:46AM AKDT until October 23 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-10-22) [Moderate] Gale Warning: Gale Warning issued October 22 at 3:46AM AKDT until October 23 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…

### Ukrainian Internal News (national + local Kyiv) — 69 new of 138 total
  - (2026-10-22) Politico: Більше 50% американців вважають, що Трамп заслуговує на імпічмент | LEDE: 54% американців вважають, що президент США Дональд Трамп вчинив правопорушення, які є підставою для імпічмент] (uk:…
      54% американців вважають, що президент США Дональд Трамп вчинив правопорушення, які є підставою для імпічменту, як показало нове опитування громадської думки.
  - (2026-10-22) Премію Сахарова цього року отримав Міжнародний кримінальний суд | LEDE: Європарламент присудив цьогорічну премію Сахарова за свободу думки Міжнародному кримінальному суду та його посадовцям.] (uk: Пре…
      Європарламент присудив цьогорічну премію Сахарова за свободу думки Міжнародному кримінальному суду та його посадовцям.
  - (2026-10-22) На пошкодженій атакою РФ станції метро "Чернігівська" 23 жовтня відкриють один із вестибюлів | LEDE: 23 жовтня на станції київського метро "Чернігівська", пошкодженій під час російської атаки 1] (uk:…
      23 жовтня на станції київського метро "Чернігівська", пошкодженій під час російської атаки 19 жовтня, відкриють для пасажирів вестибюль № 1 – вихід у напрямку станції "Дарниця".
  - (2026-10-22) Тепло і майже без опадів – погода в Україні на 23-25 жовтня | LEDE: Найближчими днями в Україні очікується тепла погода, 23 жовтня прогнозують невеликі дощі, надалі – переважно без опадів.] (uk: Тепло…
      Найближчими днями в Україні очікується тепла погода, 23 жовтня прогнозують невеликі дощі, надалі – переважно без опадів.
  - (2026-10-22) В Україну повернули тіла 252 загиблих, які, за твердженням РФ, є українськими військовими | LEDE: В Україну повернули тіла 252 загиблих, за твердженням російської сторони, вони належать українс] (uk:…
      В Україну повернули тіла 252 загиблих, за твердженням російської сторони, вони належать українським військовослужбовцям.
  - (2026-10-22) Зеленський: Трамп може допомогти завершити війну, але треба змінити риторику щодо Путіна | LEDE: Президент Володимир Зеленський вважає, що президент США Дональд Трамп може допомогти завершити р] (uk:…
      Президент Володимир Зеленський вважає, що президент США Дональд Трамп може допомогти завершити російську війну проти України, якщо змінить свою риторику щодо глави Кремля Володимира Путіна.

### State Legislative Action — 68 new of 156 total
  - (2026-10-21) [Alabama SB 24] Restoration of Voting Rights; Pardons and Paroles Board required to post application for individuals seeking restoration; board required to notify individuals and Secretary of State wh…
      Elections, Voting, & Campaigns
  - (2026-10-21) [Alabama SB 197] Food trucks and other mobile food vendors; require one health inspection and fire inspection to apply statewide
      Health
  - (2026-10-21) [Alabama SB 22] Boards and commissions; appointment of members revised
      Legislature
  - (2026-10-21) [Alabama SB 134] Taxation; tobacco interstate warehouser permits required, penalties imposed for violations
      Taxation & Revenue
  - (2026-10-21) [Alabama SB 85] Veterinary medicine; veterinarian-client-patient relationship further specified; scope of practice inside and outside veterinarian-client-patient relationship further defined
      Animals
  - (2026-10-21) [Alabama SB 173] Crimes and offenses; violation of domestic violence protection order, jurisdiction amended
      Crimes & Offenses

### IT, InfoSys & cybersecurity news (last 7 days) — 46 new of 57 total
  - (2026-10-22) [BleepingComputer] GitLab warns of new max severity code execution vulnerability
      GitLab has released security patches for a maximum-severity Regular Expression Compiler flaw that can let remote attackers run arbitrary code on vulnerable servers. [...]
  - (2026-10-22) [BleepingComputer] Authorities disrupt nearly 11,000 cybercrime networks in Africa
      Law enforcement agencies have disrupted nearly 11,000 cybercriminal networks and arrested more than 1,400 people in Operation Serengeti III, which targeted business email compromise, ransomware, and online scams. [...]
  - (2026-10-22) [The Hacker News] Railway Says Intruder May Have Accessed Customer Secrets, Urges Credential Rotation
      Platform-as-a-Service (PaaS) provider Railway on Wednesday disclosed "anomalous activity" related to systems that store customer environment variables. Upon further investigation, the company found that an unauthorized t…
  - (2026-10-22) [The Hacker News] OpenCode Flaw Lets Malicious MCP Servers Execute Code During Sign-In on Windows and WSL
      A flaw in the OpenCode AI coding agent allowed a malicious or hijacked MCP server to run code on a developer's Windows or WSL machine when the developer signed in. OpenCode connects to MCP (Model Context Protocol) server…
  - (2026-10-22) [The Hacker News] LiteLLM Suspects GitHub Token Leak in AI Gateway Logs Behind Malicious Package Release
      LiteLLM on Wednesday disclosed that threat actors compromised "multiple independent security controls" to push a malicious version of the Python package containing a credential stealer and a backdoor. On October 21, 2026…
  - (2026-10-22) [The Hacker News] Node.js Brotli Decoder Bug Could Allow Remote Code Execution in All Supported Versions
      Node.js released security updates on October 21 for its three supported release lines, 22.x, 24.x and 26.x, fixing 10 flaws. The most serious is a bug in the Brotli decompression code that Node.js bundles, which the proj…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-22) 497K - ALLSPRING EXCHANGE-TRADED FUNDS TRUST (0001611331) (Filer)
      filed 2026-10-22 11:16 UTC — Filed: 2026-10-22 AccNo: 0001611331-26-000032 Size: 77 KB
  - (2026-10-22) 485BPOS - ALLSPRING EXCHANGE-TRADED FUNDS TRUST (0001611331) (Filer)
      filed 2026-10-22 11:07 UTC — Filed: 2026-10-22 AccNo: 0001611331-26-000030 Size: 3 MB
  - (2026-10-22) 485BPOS - ALLSPRING EXCHANGE-TRADED FUNDS TRUST (0001611331) (Filer)
      filed 2026-10-22 11:07 UTC — Filed: 2026-10-22 AccNo: 0001611331-26-000030 Size: 3 MB
  - (2026-10-22) 424B3 - Blackstone Real Estate Income Trust, Inc. (0001662972) (Filer)
      filed 2026-10-22 10:45 UTC — Filed: 2026-10-22 AccNo: 0001662972-26-000154 Size: 127 KB
  - (2026-10-22) 425 - Churchill Capital Corp XI (0002074973) (Subject)
      filed 2026-10-22 10:30 UTC — Filed: 2026-10-22 AccNo: 0001213900-26-111470 Size: 28 KB
  - (2026-10-22) 485BXT - GraniteShares ETF Trust (0001689873) (Filer)
      filed 2026-10-22 10:19 UTC — Filed: 2026-10-22 AccNo: 0001493152-26-048007 Size: 40 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-10-22) [United States] LA HBCU Xavier University To Open Medical School
      domain: 960weli.iheart.com · language: English · tone:
  - (2026-10-22) [China] Russia signals new talks next month with Ukraine
      domain: taiwansun.com · language: English · tone:
  - (2026-10-22) [United States] Ukraine hits Russian data centers and experts say it sets back AI research
      domain: wsbradio.com · language: English · tone:
  - (2026-10-22) [United Kingdom] Badenoch says police seen as ghost service after devastating failure | Dumbarton and Vale of Leven Reporter
      domain: dumbartonreporter.co.uk · language: English · tone:
  - (2026-10-22) [United States] Can a dream help you solve a problem ? Here how to try tonight
      domain: wbaa.org · language: English · tone:
  - (2026-10-22) [United States] HSBC Initiates Coverage on Public Service Enterprise Group ( NYSE : PEG )
      domain: tickerreport.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-22) JAF9XT (Bulgaria)
      icao24: 4520ce · position: (36.7924, -4.3871) · alt: 11277m · 841km/h
  - (2026-10-22) JAF95J (Bulgaria)
      icao24: 4520aa · position: (40.8364, -6.8202) · alt: 11277m · 828km/h
  - (2026-10-22) JAF097P (Bulgaria)
      icao24: 452179 · position: (42.4109, 15.7133) · alt: 11887m · 739km/h
  - (2026-10-22) SAMU37 (France)
      icao24: 39ca87 · position: (47.3594, 0.7604) · alt: 304m · 199km/h
  - (2026-10-22) GAF433 (Germany)
      icao24: 3f7588 · position: (52.4415, 9.7961) · alt: 480m · 341km/h
  - (2026-10-22) SAMU691 (France)
      icao24: 39c994 · position: (45.7254, 4.9417) · alt: 129m · 52km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-10-22) [Russia oil sanctions perimeter · keywords] Elon Musk SpaceX - Tesla merger math doesnt add up
      fortune.com · English · tone NA
  - (2026-10-22) [Russia oil sanctions perimeter · keywords] BOK pauses rate hikes , but signals more may come
      koreaherald.com · English · tone NA
  - (2026-10-22) [Russia oil sanctions perimeter · keywords] Weekly Sanctions Update : October 13 , 2026
      mondaq.com · English · tone NA
  - (2026-10-22) [Russia oil sanctions perimeter · keywords] US sanctions law firm accused of helping Iran evade oil sanctions
      middle-east-online.com · English · tone NA
  - (2026-10-22) [Russia oil sanctions perimeter · keywords] Links to an Iranian Oil Network . The United States Sanctions Seven Ships Along with a Panamanian Firm and its Partners .
      newsroompanama.com · English · tone NA
  - (2026-10-22) [Russia oil sanctions perimeter · keywords] U . S . Treasury Sanctions Shipping Law Firm for Alleged Shadow Fleet Services
      maritime-executive.com · English · tone NA

### USGS earthquakes (M4.5+, past day) — 21 new of 21 total
  - (2026-10-21) M 5.3 - Reykjanes Ridge
      M5.3 · Reykjanes Ridge · depth 10 km
  - (2026-10-21) M 5.1 - south of Africa
      M5.1 · south of Africa · depth 10 km
  - (2026-10-21) M 5.0 - Reykjanes Ridge
      M5.0 · Reykjanes Ridge · depth 10 km
  - (2026-10-21) M 5.0 - Reykjanes Ridge
      M5.0 · Reykjanes Ridge · depth 10 km
  - (2026-10-21) M 5.0 - 198 km WNW of Port-Olry, Vanuatu
      M5.0 · 198 km WNW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-21) M 5.0 - 194 km WNW of Port-Olry, Vanuatu
      M5.0 · 194 km WNW of Port-Olry, Vanuatu · depth 10 km

### Court opinions of consequence (federal & state) — 20 new of 60 total
  - (2026-10-21) U.S. Court of Appeals, 1st Cir.: Dworman v. PHH Mortgage Services
  - (2026-10-21) U.S. Court of Appeals, 5th Cir.: Knife Rights v. Blanche
  - (2026-10-21) U.S. Court of Appeals, 5th Cir.: Quality Proc Svc v. Whitney Oil
  - (2026-10-21) U.S. Court of Appeals, 5th Cir.: Garcia v. United States
  - (2026-10-21) U.S. Court of Appeals, 8th Cir.: United States v. Cory Baker
  - (2026-10-21) Delaware Supreme Court: Thomas M. Sands v. Homestar Remodeling, LLC

### Paper Trading Scorecard — 18 new of 70 total
  - (2026-10-22) [Manifold] The final battle in Quroe's favorite animal market will be Sulfur cave molly vs Common bed bug.
  - (2026-10-22) [Manifold] Will the Democrats win the 2026 New Mexico Senate Election by 10% or more?
  - (2026-10-22) [Manifold] If Jon Ossoff is reelected, will he serve a full 6 year term?
  - (2026-10-22) [Manifold] If Abdul El-Sayed is elected, will he serve a full 6 year term?
  - (2026-10-22) [Manifold] If James Talarico is elected, will he serve a full 6 year term?
  - (2026-10-22) [Manifold] Will the Democrats hold 53 or more Senate seats in the next Congress?

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 110 total
  - (2026-10-21) [OFAC] Iran-related Designations; Belarus and North Korea Designations Removals; Issuance of Iran-related and Russia-related General Licenses and Amended Frequently Asked Questions - Office of Foreign…
      Iran-related Designations; Belarus and North Korea Designations Removals; Issuance of Iran-related and Russia-related General Licenses and Amended Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-10-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE GG Authorizing - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE GG Authorizing Office of Foreign Assets Control (.gov)
  - (2026-10-21) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE HH Authorizing - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE HH Authorizing Office of Foreign Assets Control (.gov)
  - (2026-10-22) [USASpending] $15,578,682,243 → LOCKHEED MARTIN CORP: TAS::80 0124::TAS DESIGN, DEVELOPMENT, TEST&EVALUATION OF PR
      Agency: National Aeronautics and Space Administration. Description: TAS::80 0124::TAS DESIGN, DEVELOPMENT, TEST&EVALUATION OF PROJECT ORION
  - (2026-10-22) [USASpending] $1,869,227,775 → HANFORD TANK WASTE OPERATIONS & CLOSURE, LLC: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITI
      Agency: Department of Energy. Description: THE AWARD CONTINUES PERFORMANCE OF INTEGRATED TANK DISPOSITION CONTRACT VIA THE IMPLEMENTATION TASK ORDER, TO-02.
  - (2026-10-22) [USASpending] $1,780,030,031 → NORTHROP GRUMMAN SYSTEMS CORPORATION: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUI
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF NEXTSTEP NRA AWARD. THIS NEXTSTEP CONTRACT BUILDS UPON THE SUCCESS OF COMMERCIAL ORBITAL TRANSPORTATION SERVICES SPACE ACT AGREEMENT DEVELO…

### U.S. Federal Action — 14 new of 16 total
  - (2026-10-22) Advancing Women's Health To Improve Outcomes in All Phases of Life
  - (2026-10-22) Safety Zone; Brownsville Ship Channel, Brownsville, TX
      The Coast Guard is establishing a temporary safety zone for navigable waters on the Brownsville Ship Channel. The safety zone is needed to protect personnel, vessels, and the marine environment from potential hazards ass…
  - (2026-10-22) Virginia: Approval of State Coal Combustion Residuals Permit Program
      The Environmental Protection Agency (EPA or the Agency) is approving Virginia's coal combustion residuals (CCR) permit program under the Resource Conservation and Recovery Act (RCRA). After reviewing the CCR permit progr…
  - (2026-10-22) Utah Underground Injection Control Program; Class VI Primacy
      The U.S. Environmental Protection Agency (EPA or Agency) has received a complete Underground Injection Control (UIC) program revision application from the State of Utah, requesting primary enforcement responsibility (pri…
  - (2026-10-22) Drawbridge Operation Regulation; Manitowoc River, Manitowoc, WI
      The Coast Guard is proposing to alter the operating schedule that governs the Eighth Street Bridge, mile 0.29 and the Tenth Street Bridge, mile 0.43, over the Manitowoc River, in the town of Manitowoc, Wisconsin. The Cit…
  - (2026-10-22) Fisheries Off West Coast States; Modification of the West Coast Salmon Fisheries; Inseason Action #1-#11
      NMFS announces eleven inseason actions for 2026-2027 ocean salmon fisheries. These inseason actions modified the commercial salmon fisheries in the area from United States/Canada border to Cape Falcon, OR.

### World News (by country, top stories) — 12 new of 12 total
  - (2026-10-22) [Japan] Cyberpunk 2077 PS5 Update 2 . 5 Live Now , Get the Patch Notes Here
      pushsquare.com · English
  - (2026-10-22) [Japan] Tesla Plans To Start Selling Cybercabs By The End Of The Year
      engadget.com · English
  - (2026-10-22) [Japan] The Morning Show - KNCE Radio
      truetaosradio.com · English
  - (2026-10-22) [Japan] New GASA Research : 71 % of Adults Surveyed Across 13 Asian Markets Encountered Scams , with Estimated Losses of US$136 . 5 Billion
      japanherald.com · English
  - (2026-10-22) [Japan] Panda homeland takes a new path amid changing times
      japanherald.com · English
  - (2026-10-22) [Japan] 20 - year title drought ends for China women gymnastics team
      japanherald.com · English

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-10-22) US x Iran ceasefire continues through October 22?
      yes price: 96% · 24h volume: $944,907 · resolves 2026-10-23
  - (2026-10-22) Will the Fed increase interest rates by 50+ bps after the October 2026 meeting?
      yes price: 0% · 24h volume: $904,086 · resolves 2026-10-29
  - (2026-10-22) Will Tim Scott win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $886,094 · resolves 2028-11-08
  - (2026-10-22) Israel x Iran ceasefire continues through October 21?
      yes price: 99% · 24h volume: $493,187 · resolves 2026-10-22
  - (2026-10-22) US x Iran ceasefire continues through October 31?
      yes price: 74% · 24h volume: $459,241 · resolves 2026-10-31
  - (2026-10-22) Dota 2: Team Spirit vs LEGION - Game 1 Winner
      yes price: 100% · 24h volume: $391,464 · resolves 2026-10-22

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-22) [Marginal Revolution] Modern Principles of Economics!
      If you are teaching economics Modern Principles is the book to use! Great and original writing, over one hundred videos, iClicker, Achieve and lots of additional support. Contact Mike Krotine to get an examination copy.…
  - (2026-10-22) [Marginal Revolution] A simple point about the intertemporal regulation of AI
      At some point AI will be more regulated than it is today. Furthermore, I believe that most parts of the American economy, once they are regulated, end up overregulated. Thus it is likely that the AI sector will, at some…
  - (2026-10-22) [Marginal Revolution] Do mass shootings in universities lead to permanent effects?
      Using a stacked difference-in-differences design covering shootings between 1990 and 2025, I compare cohorts at affected universities before and after the shooting with cohorts at matched control universities. I find no…
  - (2026-10-21) [Conversable Economist] A Supply-Shock Era?
      Economists and policy-makers know, in a broad sense, how to respond to a negative shock to aggregate demand in an economy, like the financial meltdown leading to the Great Recession of 2007-09. The financial crisis shrin…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-09-25) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo
      Since the last Disease Outbreak News was published on 11 September 2026, the Bundibugyo virus outbreak in the Democratic Republic of the Congo has expanded further, with two additional health zones affected. These includ…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-22) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=16, 7d-median=16, 14d-median=26; carrying terms: protection, proposing, action, regulatory, proposed, enforcement, final, certain, agency, document, public, safety
- state_bills: today=156, 7d-median=118, 14d-median=109; carrying terms: school, district, alaska, providing, administration, state, education, relating, contracts, construction, california, amending
- state_news: today=758, 7d-median=688, 14d-median=688; carrying terms: urges, virginia, signs, others, election, friday, place, newsletter, democratic, farmers, polling, attorney
- local_news: today=252, 7d-median=238, 14d-median=233; carrying terms: woman, being, against, jackson, accused, missouri, missing, injured, journal, arrested, people, stlmag
- foreign_news: today=1049, 7d-median=1011, 14d-median=1018; carrying terms: urges, others, election, built, ready, place, trial, farmers, allow, march, woman, palestinian
- chinese_internal: today=273, 7d-median=278, 14d-median=292; carrying terms: cbmia, title, cbmiw, china, cbmixkfvx, market, cbmiyefvx, cbmickfvx, cbmizkfvx, cbmiykfvx, cbmibkfvx, lxtfa
- russian_internal: today=1164, 7d-median=1019, 14d-median=1029; carrying terms: europe, novayagazeta, client, httperror, street, istories, forbidden, title, politico, laquo, https, server
- ukrainian_internal: today=138, 7d-median=134, 14d-median=136; carrying terms: urges, economic, despite, update, missile, agreement, cabinet, facility, diesel, energy, sanctions, announced
- ukraine_theater: today=474, 7d-median=413, 14d-median=425; carrying terms: rsnjrtzdisthjqzvcse, mjrozw, cbmiv, zgzjadrozenmtjnewepvte, tawsycvbhvhvwrlr, ready, vsael, lxbthbvmvtv, ntounjuwc, clvwz, twxlmeudyr, kwmnzy
- paper_bets: today=70, 7d-median=69, 14d-median=69; carrying terms: netanyahu, achieved, leaders, visit, erupt, general, mamdani, magnitude, succeed, become, lifetime, chair
- weather: today=146, 7d-median=138, 14d-median=142; carrying terms: ruskin, afdmtr, worth, counties, detroit, magnitude, baltimore, friday, southwest, areas, peachtree, francisco
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: effective, labor, spread, total, money, walcl, dexuseu, inflation, assets, latest, pcepilfe, nonfarm
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, nasdaq, china, large, russell, silver, proxy, futures, rates, crude, crypto, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=110, 7d-median=105, 14d-median=108; carrying terms: actions, economic, drilling, solutions, updates, program, areas, contract, democratic, transition, measures, sectoral
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, quiverquant, error, congresstrading, httperror, quantitative, https, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: board, state, court, appeals, supreme, trade, international, mullin, delaware, blanche, warden, center
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, holdings, trust, filer, estate, funds, subject, income
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, brown, ocasio, sherrod, committee, elect, johnson, disbursements, congress, warner, robert, krishnamoorthi
- gdelt_regions: today=12, 7d-median=10, 14d-median=8; carrying terms: english, china, japan, japanherald
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, russia, perimeter, sanctions, israel, greek, trump, china, keywords, south, diesel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=0; carrying terms: domain, english, kingdom, india, killed, australia, language, china, daily, hindustantimes, south, question
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=23, 14d-median=28; carrying terms: position, belgium, ground, france, germany, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: recombinant, adult, complete, incubation, african, across, blood, brings, producing, neurological, update, contaminated
- cisa_kev: today=20, 7d-median=15, 14d-median=14; carrying terms: product, cisco, vendor, traversal, remediation, injection, vulnerability, improper, apache, fortinet, command, struts
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=100, 14d-median=100; carrying terms: impact, green, australia, depth, indonesia, magnitude, fires, wildfire, typhoon, speed, cyclone, papua
- usgs_quakes: today=21, 7d-median=20, 14d-median=20; carrying terms: depth, indonesia, russia, south, papua, vanuatu, region, guinea, islands, ridge, alaska, kokopo
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, donetsk, presidential, champions, shakhtar, price, league, championship, october, brazilian, election
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, conversable, revolution, marginal, class, economist, marginalrevolution, spending, conversableeconomist, years, government, world
- tech_news: today=57, 7d-median=58, 14d-median=58; carrying terms: intelligence, updates, software, download, people, technica, security, krebs, weekly, infrastructure, engineering, schneier
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: ritchie, lance, murphy, britt, scalise, economic, intelligence, virginia, melanie, banks, veasey, lutnick
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, consensus, unavailable, module, sufficient, placement, decision, placed, paper, either, markets, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-13] ECB press: Philip R. Lane: The AI opportunity for Europe
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-17] ECB press: Christine Lagarde: IMFC Statement
- [2026-10-19] ECB press: Frank Elderson: From climate and nature risks to economic resilience and competitiveness
- [2026-10-20] ECB press: Frank Elderson: Interview with Die Presse
- [2026-10-21] ECB press: Philip R. Lane: Euro liquidity lines and the international monetary system
- [2026-10-21] ECB press: Piero Cipollone: Pontes and Appia: unlocking opportunities for banks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*