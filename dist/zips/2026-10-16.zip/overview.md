# WORLDSCOPE morning brief — 2026-10-16

## Headline
3429 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (810) · Russian Internal News (state + in-exile) (725) · State-Level News (389) · World leaders & government officials (324) · Chinese Internal News (238) · Local News: St. Louis + Atlanta (210) · U.S. Weather + Severe / Climate Outlooks (140) · State Legislative Action (114) · Ukraine Theater (total-war monitoring) (92) · Ukrainian Internal News (national + local Kyiv) (61) · IT, InfoSys & cybersecurity news (last 7 days) (45) · GDACS — global disaster alerts (41)

## What changed today
### International News + Multilateral Institutions — 810 new of 1036 total
  - (2026-10-16) [Global] Children aged 5, 8 and 11 killed in US school shooting before suspect shot by bystander
      A teacher was also killed in the attack at the Silver Rail Elementary School in the city of Bend, Oregon, police say.
  - (2026-10-16) [Global] 'It's really hard to believe' - How Oregon primary school shooting unfolded
      Three children aged 5, 8 and 11 and a teacher were killed after a 16-year-old suspect opened fire in the city of Bend, local police say.
  - (2026-10-16) [Global] Ship attack reports near Hormuz reach record high as oil exports slow
      BBC Verify analysis of data from a UK maritime agency shows 12 vessels were struck in a week.
  - (2026-10-16) [Global] Zelensky rallies EU support as Trump says Ukraine leader 'more difficult to deal with than Putin'
      The US president launches a new wave of blistering criticism at Volodymyr Zelensky ahead of a meeting of EU leaders in Brussels.
  - (2026-10-16) [Global] China tells Israel to stop 'forced establishment' of West Bank settlements
      Chinese Foreign Minister Wang Yi spoke to Israeli President Isaac Herzog on the sidelines of a conference.
  - (2026-10-16) [Global] Dad fined after son, 2, died in Cyprus hotel fall
      Joshua Foster "lost control" of his son while showing him the view of a water park from a window.

### Russian Internal News (state + in-exile) — 725 new of 1132 total
  - (2026-10-16) Врач рассказал, почему симптомы деменции могут обостриться осенью | LEDE: ] (ru: Врач рассказал, почему симптомы деменции могут обостриться осенью)
  - (2026-10-16) Премьер Латвии назвал неожиданную причину поддержки Украины | LEDE: ] (ru: Премьер Латвии назвал неожиданную причину поддержки Украины)
  - (2026-10-16) В ЕС будут задействовать все ресурсы для давления на США, заявила Захарова | LEDE: ] (ru: В ЕС будут задействовать все ресурсы для давления на США, заявила Захарова)
  - (2026-10-16) В МИД назвали энергетическое сотрудничество с Южным Кавказом перспективным | LEDE: ] (ru: В МИД назвали энергетическое сотрудничество с Южным Кавказом перспективным)
  - (2026-10-16) В Иране прокомментировали возможные удары США по энергообъектам страны | LEDE: ] (ru: В Иране прокомментировали возможные удары США по энергообъектам страны)
  - (2026-10-16) "Росатом" обсуждает поставку плавучих АЭС в другие страны, заявил Лихачев | LEDE: ] (ru: "Росатом" обсуждает поставку плавучих АЭС в другие страны, заявил Лихачев)

### State-Level News — 389 new of 812 total
  - (2026-10-15) [California] California files its 100th lawsuit against Trump, this time over ICE at courthouses
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/010625-Limon-Senate-Pro-Tem-MG-CM-18.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-10-15) [California] Trump sues California over allegations of noncitizens registering to vote
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/060226-Dean-Logan-GETTY-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-10-15) [California] This landmark California brewery was slated for closure: Instead it’s returning to its roots
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/093026_Prohibition-Brewing_AH_CM_25.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-10-15) [California] Información para los pacientes: Estos son los mejores consejos sobre cómo optar por no compartir tus datos
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/101326-OPT-OUT-SIDEBAR-GH-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-10-15) [California] MyChart y un importante hospital me dijeron que podía optar por no compartir mis datos de salud. Pero no me lo pusieron fácil
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/101326-OPT-OUT-GH-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="Illu…
  - (2026-10-15) [California] Gavin Newsom’s 24/7 social media machine
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/051425-MayBudgetRevise-FG-CM-09.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 238 new of 296 total
  - (2026-10-15) - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTFB6Y0w5Z3RLaVRyYm82aU1iaVN1OGdHc2JSWTZkNm9hUVRRTWNUOFRTcGhlUHhvdElvNG5XTjB2WkxjQW96NGJjbDZ3VjNPVG9NdGhodUl6UmtRdkxB?oc=5"] (zh:…
      财新
  - (2026-10-15) 国产芯片公司算苗科技一年融资近20亿元 预计第一代产品2027 年量产 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE1xQVd6ZE1DeFZWbklRb3RRR1dhajN3dUpMSHJScTBTZF9PcE9JQnUtb0wtc3hEQ19IcFJORDZRNzFRQ3NENk] (zh:…
      国产芯片公司算苗科技一年融资近20亿元 预计第一代产品2027 年量产 财新
  - (2026-10-16) 今日开盘：两市双双高开 沪指涨幅0.44% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE10T3ozcVZjSVdIQ2lWTlRtZmszU01fbGYzTkhYM1JWa0lUazAxeC1WcU04eGdFZVpvYWpwSnZuUVFySmdCUExqM1RVTGJTNTFL] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.44% 财新
  - (2026-10-16) 婴幼儿纸尿裤甲酰胺问题调查核实情况公布后，山东省卫健委通报 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9JVXNZY25QMkVQQkRKbE4yVjFzMnEwbTRmZVJsWkFEQlRCQ3h3V1RVSXFUZ3RoYm40VjJkZG56c1dCQThDbG91WXU2] (zh:…
      婴幼儿纸尿裤甲酰胺问题调查核实情况公布后，山东省卫健委通报 财新
  - (2026-10-16) 【交易簿】蓝天格锐比特币赃款只退本金 中英司法差异让受害者无缘巨额增值 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE91SzlDOXZ0ekpiX2hEemEyNVE4NGNHX2p3QzQyYkxwRV9TQ0xmWkhQT24xanF4RXZpTXJtLXdrT1ZZWXFI] (zh:…
      【交易簿】蓝天格锐比特币赃款只退本金 中英司法差异让受害者无缘巨额增值 财新数据
  - (2026-10-15) 财经早知道｜“市值王”长鑫科技“退位” 工商银行重回A股市值第一 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE83RXlNc2NIUlVwellmMkpWcm5Iem1qQ0FSMmItd2cwQnpzM3p4dzBOekpfRHRhNUhucWdqVWdhQUZKMUU1b0VGS] (zh:…
      财经早知道｜“市值王”长鑫科技“退位” 工商银行重回A股市值第一 财新

### Local News: St. Louis + Atlanta — 210 new of 247 total
  - (2026-10-16) [St. Louis] What’s True in the Lou? – 10/16/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-10-16) [St. Louis] Compton Hill Water Tower gets big fundraising push—before it’s too late
      For decades, the reward for climbing the Compton Hill Water Tower’s 198 steps was one of the best views in St. Louis. Standing at a high point near the corner of Grand and Russell, the 179-foot Romanesque tower offered v…
  - (2026-10-16) [St. Louis] Ask George: Is it OK for restaurant staffers to hang out at the bar after their shifts?
      The answer is an unemphatic yes, provided there are clear boundaries. After a shift spent taking care of other people, there’s nothing inherently wrong with sitting down and letting someone take care of you. A drink and…
  - (2026-10-15) [St. Louis] Sew much fun: The Fashion Class is coming to Ladue
      St. Louis knows a thing or two about fashion. After all, the city is credited with giving the world the first cocktail dress. But as sewing skills stopped being passed down at home and home economics classes disappeared…
  - (2026-10-15) [St. Louis] Tora Asian House now open in Clayton
      Tora Asian House (16 N. Central) in Clayton opened October 2. The new restaurant features Pan-Asian cuisine, with a focus on homemade noodles, entrées, bubble tea, and more from local restaurateurs with decades of indust…
  - (2026-10-15) [St. Louis] New Mapleplay Café in Maplewood combines indoor play, climbing, and coffee for families
      As a mom of four, Olivia Walton knows the challenge of finding an indoor play space that keeps everyone happy. What works for a toddler isn’t always exciting for an elementary schooler, and what keeps the big kids entert…

### U.S. Weather + Severe / Climate Outlooks — 140 new of 142 total
  - (2026-10-16) [Moderate] Special Weather Statement: Special Weather Statement issued October 16 at 3:26AM AKDT by NWS Juneau AK
      A series of fronts is bringing multiple rounds of moderate to heavy rainfall across the Alaska Panhandle as of early Friday morning. This second round of heavy rain has brought around 2 to 3 inches of rainfall to the are…
  - (2026-10-16) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-16) [Moderate] Special Weather Statement: Special Weather Statement issued October 16 at 7:22AM EDT by NWS Columbia SC
      Areas of fog have begun to develop over the eastern Midlands and lower CSRA this morning. Fog may become locally dense at times, reducing visibilities on roadways.
  - (2026-10-16) [Severe] Freeze Watch: Freeze Watch issued October 16 at 6:22AM CDT until October 17 at 9:00AM CDT by NWS Amarillo TX
      * WHAT...Sub-freezing temperatures as low as 28 possible. * WHERE...Portions of the Panhandle of Oklahoma and the Panhandle of Texas. * WHEN...From late tonight through Saturday morning. * IMPACTS...Frost and freeze cond…
  - (2026-10-16) [Moderate] Special Weather Statement: Special Weather Statement issued October 16 at 7:19AM EDT by NWS Cleveland OH
      At 719 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from near Cleveland Heights to North Royalton to Medina. Movement was northeast at 60 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...…
  - (2026-10-16) [Moderate] Gale Watch: Gale Watch issued October 16 at 7:17AM EDT until October 20 at 9:00AM EDT by NWS Charleston SC
      * WHAT...North winds 25 to 35 kt with gusts up to 45 kt and seas 10 to 15 ft possible. * WHERE...Waters from South Santee River SC to Edisto Beach SC extending from 20 to 60 NM and Waters from Edisto Beach SC to Savannah…

### State Legislative Action — 114 new of 118 total
  - (2026-10-16) [Alaska HB 13] An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobi…
      An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobile intensive care paramedic service…
  - (2026-10-16) [Alaska SB 207] An Act relating to the removal of unlawful occupants from residential real property; relating to the crimes of trespass, forgery, and deceptive business practices; and amending Rules 8…
      An Act relating to the removal of unlawful occupants from residential real property; relating to the crimes of trespass, forgery, and deceptive business practices; and amending Rules 82 and 85(a), Alaska Rules of Civil P…
  - (2026-10-16) [Alaska HB 126] An Act relating to the reinstatement of Native village corporations; relating to proxy solicitations to shareholders of corporations organized under state law under the Alaska Native C…
      An Act relating to the reinstatement of Native village corporations; relating to proxy solicitations to shareholders of corporations organized under state law under the Alaska Native Claims Settlement Act; and providing…
  - (2026-10-16) [Alaska SB 239] An Act relating to commercial motor vehicle licensing examinations; relating to the registration and titling of legally imported motor vehicles; relating to proof of financial responsi…
      An Act relating to commercial motor vehicle licensing examinations; relating to the registration and titling of legally imported motor vehicles; relating to proof of financial responsibility for suspension for nonpayment…
  - (2026-10-16) [Alaska SB 200] An Act relating to service areas; relating to municipal assessments of farm or agricultural land; and providing for an effective date.
      An Act relating to service areas; relating to municipal assessments of farm or agricultural land; and providing for an effective date.
  - (2026-10-16) [Alaska HB 1] An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.
      An Act relating to specie as legal tender in the state; and relating to borough and city sales and use taxes on specie.

### Ukraine Theater (total-war monitoring) — 92 new of 393 total
  - (2026-10-15) [FIRMS] thermal anomaly 52.223, 32.518 (FRP 7.73 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-15 0920Z, FRP 7.73 MW
  - (2026-10-15) [FIRMS] thermal anomaly 52.226, 32.523 (FRP 5.68 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-15 0920Z, FRP 5.68 MW
  - (2026-10-15) [FIRMS] thermal anomaly 52.224, 32.516 (FRP 4.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-15 0920Z, FRP 4.01 MW
  - (2026-10-15) [FIRMS] thermal anomaly 45.356, 30.904 (FRP 2.69 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-15 1058Z, FRP 2.69 MW
  - (2026-10-15) [FIRMS] thermal anomaly 44.305, 23.058 (FRP 11.59 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-15 1058Z, FRP 11.59 MW
  - (2026-10-15) [FIRMS] thermal anomaly 46.495, 31.758 (FRP 2.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-15 1058Z, FRP 2.7 MW

### Ukrainian Internal News (national + local Kyiv) — 61 new of 128 total
  - (2026-10-16) Сікорський нагадав Трампу, що українці отримують поранення від бомб і ракет Путіна | LEDE: Глава МЗС Польщі Радослав Сікорський відреагував на заяву президента США Дональда Трампа, який поклав ] (uk:…
      Глава МЗС Польщі Радослав Сікорський відреагував на заяву президента США Дональда Трампа, який поклав відповідальність за поранення і смерті українців у війні на президента України Володимира Зеленського.
  - (2026-10-16) Зеленський провів першу зустріч з Мадяром, яка пройшла тет-а-тет | LEDE: Президент Володимир Зеленський провів першу офіційну зустріч з прем'єром Угорщини Петером Мадяром.] (uk: Зеленський провів перш…
      Президент Володимир Зеленський провів першу офіційну зустріч з прем'єром Угорщини Петером Мадяром.
  - (2026-10-16) НАБУ і САП завершили слідство у справі Стефанішиної щодо незаконного збагачення | LEDE: Антикорупційні органи завершили слідство у справі щодо колишньої віцепрем'єрки – міністерки юстиції Ольги] (uk:…
      Антикорупційні органи завершили слідство у справі щодо колишньої віцепрем'єрки – міністерки юстиції Ольги Стефанішиної щодо незаконного збагачення на 13,9 млн грн та недостовірного декларування.
  - (2026-10-16) Лідерка німецьких ультраправих: Підтримувати Україну марно, вона вже програла | LEDE: Аліс Вайдель, співлідерка АдН, закликає Німеччину тиснути на Зеленського та повторювати політику Дональда Т] (uk:…
      Аліс Вайдель, співлідерка АдН, закликає Німеччину тиснути на Зеленського та повторювати політику Дональда Трампа щодо РФ.
  - (2026-10-16) Каллас: ЄС намагається переконати США, що тиснути треба на Росію | LEDE: Кая Каллас повідомила, що Європа прагне переконати США у необхідності тиску на Кремль та обговорює використання замороже] (uk:…
      Кая Каллас повідомила, що Європа прагне переконати США у необхідності тиску на Кремль та обговорює використання заморожених активів РФ на користь України.
  - (2026-10-16) В Україні дощитиме всі вихідні, але буде тепло | LEDE: Синоптики прогнозують дощі, туман і пориви вітру 17–19 жовтня. Температура вночі 5–14°, вдень до 21°. Деталі від Укргідрометцентру.] (uk: В Украї…
      Синоптики прогнозують дощі, туман і пориви вітру 17–19 жовтня. Температура вночі 5–14°, вдень до 21°. Деталі від Укргідрометцентру.

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 59 total
  - (2026-10-16) [BleepingComputer] Microsoft: October Windows update may break Smart App Control
      Microsoft says some users may have trouble turning on Smart App Control after installing this month's KB5127648 Windows 11 security update. [...]
  - (2026-10-16) [BleepingComputer] BAE Systems cyberattack disrupts US federal court operations
      The Administrative Office of the US Courts says a cyberattack on government contractor BAE Systems has taken down the notice system used by federal bankruptcy courts. [...]
  - (2026-10-16) [BleepingComputer] BeyondTrust patches zero-day exploited in attacks since August
      BeyondTrust warned customers on Thursday to patch a critical flaw in its Remote Support (RS) that has been exploited in zero-day attacks since late August. [...]
  - (2026-10-16) [The Hacker News] China-Linked Hackers Exploited BeyondTrust Zero-Day to Take Over Remote Support Servers
      The China-nexus cyber espionage group tracked as Armory Castle (previously UNC5221 or Warp Panda) exploited a newly disclosed security flaw in BeyondTrust Remote Support (formerly Bomgar) as a zero-day in late August 202…
  - (2026-10-16) [The Hacker News] CERT-In Warns AI Agents Accessed Sensitive Data at Indian Organizations During Testing
      AI agents being tested online reached the live systems of Indian organizations and read business records, including personal data and confidential material, CERT-In said in an advisory on October 15. The agents went beyo…
  - (2026-10-16) [The Hacker News] PEERSTITCH Malware Deployed via FortiOS Flaw Bypasses Checks on Tagged VPN Sessions
      A suspected advanced threat actor has been observed exploiting a security flaw in Fortinet FortiOS to deliver a previously unreported memory-resident ARM64 malware known as PEERSTITCH. The attack involves the exploitatio…

### GDACS — global disaster alerts — 41 new of 100 total
  - (2026-10-16) [Green] Earthquake in Philippines
      Earthquake · Green alert · Philippines · Magnitude 4.9M, Depth:73.712km
  - (2026-10-16) [Green] Earthquake in Southern East Pacific Rise
      Earthquake · Green alert · Southern East Pacific Rise · Magnitude 4.8M, Depth:10km
  - (2026-10-16) [Green] Tropical Cyclone ONE-26
      Tropical Cyclone · Green alert · Cook Islands, French Polynesia · Tropical Storm (maximum wind speed of 120 km/h)
  - (2026-10-16) [Green] Earthquake in México
      Earthquake · Green alert · México · Magnitude 4.7M, Depth:10km
  - (2026-10-16) [Green] Earthquake in Russia
      Earthquake · Green alert · Russia · Magnitude 6.9M, Depth:143.176km
  - (2026-10-04) [Green] Forest fires in Papua New Guinea
      Wildfire · Green alert · Papua New Guinea · Green impact for forestfire in 15144 ha

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-16) 497 - Eaton Vance Municipals Trust II (0000914529) (Filer)
      filed 2026-10-16 11:26 UTC — Filed: 2026-10-16 AccNo: 0001133228-26-013323 Size: 86 KB
  - (2026-10-16) 497 - Eaton Vance Investment Trust (0000779991) (Filer)
      filed 2026-10-16 11:26 UTC — Filed: 2026-10-16 AccNo: 0001133228-26-013323 Size: 86 KB
  - (2026-10-16) 497 - Eaton Vance Municipals Trust (0000778365) (Filer)
      filed 2026-10-16 11:26 UTC — Filed: 2026-10-16 AccNo: 0001133228-26-013323 Size: 86 KB
  - (2026-10-16) 425 - Morgan Stanley ETF Trust (0001676326) (Filed by)
      filed 2026-10-16 11:23 UTC — Filed: 2026-10-16 AccNo: 0001133228-26-013322 Size: 81 KB
  - (2026-10-16) 425 - Eaton Vance Municipals Trust II (0000914529) (Subject)
      filed 2026-10-16 11:23 UTC — Filed: 2026-10-16 AccNo: 0001133228-26-013322 Size: 81 KB
  - (2026-10-16) 497 - ALLSPRING FUNDS TRUST (0001081400) (Filer)
      filed 2026-10-16 11:21 UTC — Filed: 2026-10-16 AccNo: 0001081400-26-000506 Size: 53 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-16) JAF50T (Bulgaria)
      icao24: 4520ce · position: (46.5455, 1.2838) · alt: 10668m · 805km/h
  - (2026-10-16) JAF5GA (Bulgaria)
      icao24: 4520aa · position: (38.336, -3.5381) · alt: 11269m · 828km/h
  - (2026-10-16) SAMU45 (France)
      icao24: 39ca85 · position: (47.8351, 1.9194) · alt: 114m · 77km/h
  - (2026-10-16) SAMU37 (France)
      icao24: 39ca87 · position: (47.4328, 0.8753) · alt: 190m · 220km/h
  - (2026-10-16) PAT277 (United States)
      icao24: adfdd0 · position: (30.1962, -82.0814) · alt: 3802m · 435km/h
  - (2026-10-16) GAF141 (Germany)
      icao24: 3f717c · position: (42.5725, 13.2712) · alt: 9410m · 686km/h

### Court opinions of consequence (federal & state) — 27 new of 60 total
  - (2026-10-15) U.S. Court of Appeals, 6th Cir.: Paula Bailey v. Mich. Dep't of Corr.
  - (2026-10-15) U.S. Court of Appeals, 7th Cir.: Eric D. Holmes v. Ron Neal
  - (2026-10-15) U.S. Court of Appeals, 7th Cir.: Eric D. Holmes v. Ron Neal
  - (2026-10-15) Arkansas Supreme Court: Andrew Ross, Jr. v. Dexter Payne, Director, Arkansas Division of Correction
  - (2026-10-15) Arkansas Supreme Court: Andrew Ross, Jr. v. State of Arkansas
  - (2026-10-15) Arkansas Supreme Court: Dung Thai Tran v. Dexter Payne, Director, Arkansas Division of Correction

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-10-16) [Russia oil sanctions perimeter · themes] Russia strikes nine Ukrainian regions as strain grows between Zelensky and Trump
      newsandstar.co.uk · English · tone NA
  - (2026-10-16) [Russia oil sanctions perimeter · themes] Guerre en Ukraine : Volodymyr Zelensky défie Donald Trump , lUE renouvelle son soutien à lUkraine
      touteleurope.eu · French · tone NA
  - (2026-10-16) [Russia oil sanctions perimeter · themes] Дефіцит пального для суден - як удари по НПЗ Росії підняли світові ціни
      24tv.ua · Ukrainian · tone NA
  - (2026-10-16) [Russia oil sanctions perimeter · themes] Trump se znovu pustil do Zelenského . Lépe se mu prý jedná s Putinem , obnovení útoků na ruské rafinerie označil za ostudu
      zahranicni.hn.cz · Czech · tone NA
  - (2026-10-16) [Russia oil sanctions perimeter · themes] Лидеры ЕС решили сохранить военную помощь Киеву без участия США | MigNews - Новости Израиля и Мира на русском языке
      mignews.com · Russian · tone NA
  - (2026-10-16) [Russia oil sanctions perimeter · themes] PVCFC ( DCM ) thúc đẩy xúc tiến thương mại tại Đông Nam Á
      tinnhanhchungkhoan.vn · Vietnamese · tone NA

### Paper Trading Scorecard — 22 new of 88 total
  - (2026-10-16) [Polymarket] GTA VI released by November 30?
      This market will resolve to "Yes" if it Grand Theft Auto VI is officially released in the US by the listed date, 11:59 PM ET. Otherwise, this market will resolve to "No". For the purposes of this market, "release" refers…
  - (2026-10-16) [Polymarket] Will SpaceX have the highest IPO Market Cap 2026?
      This market will resolve to the company that achieves the highest market capitalization in U.S. dollars based on the official closing price on its first trading day in 2026. This market will resolve to a company that com…
  - (2026-10-16) [Manifold] Will Barcelona will the match Barcelona VS Real Betis ?
  - (2026-10-16) [Manifold] Will Paris win the match Barcelona VS Paris?
  - (2026-10-16) [Manifold] Anthropic Releases at Least 2 more Fable models before 2027?
  - (2026-10-16) [Manifold] Will Ilhan Omar lose her US citizenship by the end of 2027?

### Government Action: Sanctions + Procurement + Foreign Agents — 17 new of 108 total
  - (2026-10-15) [OFAC] Iran-related Designations; Cuba Designation; Issuance of New and Amended General Licenses and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Cuba Designation; Issuance of New and Amended General Licenses and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-10-15) [OFAC] 1276 - Office of Foreign Assets Control (.gov)
      1276 Office of Foreign Assets Control (.gov)
  - (2026-10-15) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL (a) Except as provided in paragraph (b) of this general license, all transactions prohibited by - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL (a) Except as provided in paragraph (b) of this general license, all transactions prohibited by Office of Foreign Assets Control (.gov)
  - (2026-10-16) [USASpending] $1,414,827,399 → THE JOHNS HOPKINS UNIVERSITY APPLIED PHYSICS LABORATORY LLC: DRAGONFLY EXTENDED PHASE B MISSION UNDER 80MSFC20D0004 AEROS
      Agency: National Aeronautics and Space Administration. Description: DRAGONFLY EXTENDED PHASE B MISSION UNDER 80MSFC20D0004 AEROSPACE RESEARCH, DEVELOPMENT AND ENGINEERING SUPPORT (ARDES) II.
  - (2026-10-16) [USASpending] $1,057,002,179 → KBR WYLE SERVICES, LLC: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT
      Agency: National Aeronautics and Space Administration. Description: IGF::CT::IGFMSOC FPDS-NG MISSION SYSTEMS OPERATIONS CONTRACT (MSOC)
  - (2026-10-16) [USASpending] $724,718,527 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…

### U.S. Federal Action — 16 new of 16 total
  - (2026-10-16) Non-Applicability of Section 357(c) to Consolidated Groups
      This document contains final regulations clarifying that, in the case of certain transfers between members of a consolidated group, a transferee's assumption of certain liabilities will not reduce the transferor's basis…
  - (2026-10-16) Safety Zone; Cumberland River, Hendersonville, TN
      The Coast Guard is proposing to establish a temporary safety zone for navigable waters on the Cumberland River from mile marker 221.7 to 222. The safety zone is needed to protect personnel, vessels, and the marine enviro…
  - (2026-10-16) Fisheries of the Exclusive Economic Zone Off Alaska; Reallocation of Atka Mackerel in the Bering Sea and Aleutian Islands Management Area
      NMFS is reallocating the projected unused amount of the 2026 Atka mackerel incidental catch allowance (ICA) for the Bering Sea subarea and Eastern Aleutian district (BS/EAI) to the Amendment 80 cooperative allocation for…
  - (2026-10-16) Denali National Park and Preserve; Vehicle Use
      The National Park Service (NPS) amends special regulations for Denali National Park and Preserve to conform the regulations regarding the number of vehicles that can travel on the restricted section of the Denali Park Ro…
  - (2026-10-16) Fishery Management Plans of St. Croix and St. Thomas and St. John; Spiny Lobster Management Measures
      NMFS proposes regulations to implement Framework Action 4 under both the St. Croix Fishery Management Plan (FMP) and the St. Thomas and St. John FMP, as prepared by the Caribbean Fishery Management Council (Council). The…
  - (2026-10-16) Establishment of United States Area Navigation Route T-550 and Revocation of Very High Frequency Omnidirectional Range Federal Airway V-320
      This action revokes Very High Frequency (VHF) Omnidirectional Range (VOR) Federal Airway V-320 in Alaska due to navigational signal limits causing portions of this route to be unusable. There are two routes with the iden…

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-10-16) Will the Fed decrease interest rates by 50+ bps after the October 2026 meeting?
      yes price: 0% · 24h volume: $1,081,385 · resolves 2026-10-29
  - (2026-10-16) Shanghai Rolex Masters: Daniil Medvedev vs Tommy Paul
      yes price: 64% · 24h volume: $779,067 · resolves 2026-10-23
  - (2026-10-16) Counter-Strike: NIP vs Liquid (BO3) - Stake Pulse Beat III Playoffs
      yes price: 100% · 24h volume: $701,663 · resolves 2026-10-16
  - (2026-10-16) 2026 Balance of Power: Other
      yes price: 0% · 24h volume: $375,944 · resolves 2026-11-04
  - (2026-10-16) Valorant: 100 Thieves vs G2 Esports (BO3) - VCT Champions Playoffs
      yes price: 38% · 24h volume: $297,111 · resolves 2026-10-16
  - (2026-10-16) Will the U.S. invade Iran before 2027?
      yes price: 16% · 24h volume: $264,504 · resolves 2027-01-01

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-10-16) M 6.9 - 76 km NE of Ozernovskiy, Russia
      M6.9 · 76 km NE of Ozernovskiy, Russia · depth 135 km
  - (2026-10-15) M 5.2 - 107 km NNE of Hihifo, Tonga
      M5.2 · 107 km NNE of Hihifo, Tonga · depth 10 km
  - (2026-10-15) M 5.2 - 157 km W of Sola, Vanuatu
      M5.2 · 157 km W of Sola, Vanuatu · depth 10 km
  - (2026-10-16) M 4.9 - 31 km ENE of Kinablangan, Philippines
      M4.9 · 31 km ENE of Kinablangan, Philippines · depth 73.712 km
  - (2026-10-15) M 4.9 - 198 km SSE of Vilyuchinsk, Russia
      M4.9 · 198 km SSE of Vilyuchinsk, Russia · depth 10 km
  - (2026-10-16) M 4.8 - southern East Pacific Rise
      M4.8 · southern East Pacific Rise · depth 10 km

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - (2026-10-16) [Top] PELTOLA, MARY (DEM, Senate AK): $32.62M raised
      cycle 2026 receipts $32.62M · disbursements $29.46M · net $+3.16M
  - (2026-10-16) [Top] COLLINS, SUSAN M. (REP, Senate ME): $24.13M raised
      cycle 2026 receipts $24.13M · disbursements $20.04M · net $+4.09M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-16) [Marginal Revolution] India has more Restrictive Labor Law than Germany
      In Premature Imitation and India’s Flailing State, Shruti Rajagopalan and I discuss how India has essentially all of the laws of a developed country but at much lower state capacity–this mismatch creates what we call pre…
  - (2026-10-16) [Marginal Revolution] On Bergman’s *Persona*
      I first saw Ingmar Bergman’s Persona, his stone-cold classic of 1965, as a teenager, and God knows how many times I have seen it since. It has the greatest opening sequence in cinema: a percussive, rapid-fire montage tha…
  - (2026-10-16) [Marginal Revolution] I guest host the NYT podcast and interview Dwarkesh
      Here is the audio, video, and transcript. Excerpt: Cowen: Unreleased models — why are they important? Patel: As in the ones that are internal to the companies? Cowen: Well, many companies have unreleased models. Maybe it…
  - (2026-10-15) [Conversable Economist] The Incoherence of the Trump Tariff Announcements
      Sometimes you see a figure that makes you uncertain whether to laugh or cry, so you do a little of both. The Global Linkages Lab at Brown University–specifically, Şebnem Kalemli-Özcan, Can Soylu, and Muhammed A. Yildirim…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 15 total
  - (2026-10-15) CVE-2026-21589 · Atlassian Multiple Products: Atlassian Multiple Products Files or Directories Accessible to External Parties Vulnerability
      vendor: Atlassian · product: Multiple Products · CISA remediation by 2026-10-18

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-16) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=16, 7d-median=26, 14d-median=26; carrying terms: require, proposed, public, proposes, regulatory, safety, proposing, action, final, certain, period, national
- state_bills: today=118, 7d-median=73, 14d-median=78; carrying terms: effective, state, relating, education, providing, powers, school, administration, district, alaska, contracts, service
- state_news: today=812, 7d-median=667, 14d-median=682; carrying terms: being, advantage, medicaid, azgovernor, pressherald, decide, roger, facing, public, https, susan, missouri
- local_news: today=247, 7d-median=235, 14d-median=229; carrying terms: being, public, https, missouri, atlanta, state, charged, google, person, following, across, health
- foreign_news: today=1036, 7d-median=1018, 14d-median=1018; carrying terms: being, worst, talks, paris, killing, vessel, thailand, controlled, began, gandhi, forbidden, videos
- chinese_internal: today=296, 7d-median=299, 14d-median=288; carrying terms: https, cbmickfvx, cbmigwfbvv, google, title, cbmibkfvx, target, cbmizkfvx, cbmiakfvx, cbmiw, cbmizefvx, cbmibefvx
- russian_internal: today=1132, 7d-median=1061, 14d-median=1068; carrying terms: laquo, found, server, istories, europe, telegram, https, gazeta, raquo, forbidden, error, reuters
- ukrainian_internal: today=128, 7d-median=130, 14d-median=134; carrying terms: moscow, drone, previous, former, talks, pressure, ahead, europe, killing, latest, https, strikes
- ukraine_theater: today=393, 7d-median=409, 14d-median=504; carrying terms: sources, cuxnzghps, arcgis, rlnus, yxjtlwhfazlmbzrbwfe, nlrmdepyvju, ttbssnh, cwrdbxaxnnmq, relations, mnevlt, awhmvnfhotdjtjhdvw, jcsmizdy
- paper_bets: today=88, 7d-median=68, 14d-median=99; carrying terms: experience, yards, kalshi, humans, leaders, koivun, succeed, named, least, manifold, become, solved
- weather: today=142, 7d-median=142, 14d-median=142; carrying terms: miami, flooding, counties, afddtx, continues, visibility, short, northern, pressure, strong, norton, impacts
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, spread, labor, dexjpus, personal, nonfarm, latest, consumption, openings, dexuseu, unrate, sheet
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, natural, nasdaq, range, large, commodities, china, crypto, treasury, equities, credit, corporate
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=108, 14d-median=111; carrying terms: member, destabilisation, armed, mexico, schools, syria, space, middle, actions, maintenance, republic, somalia
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, error, quantitative, quiver, quiverquant, congresstrading, httperror, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, appeals, state, corporation, company, james, board, international, county, alabama, division
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, reporting, accno, financial, trust, robert, filer, jpmorgan, chase, finance, funds
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, trone, ossoff, disbursements, robert, ocasio, congress, angels, brown, raised, filing, james
- gdelt_regions: today=0, 7d-median=1, 14d-median=1
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, themes, italian, french, chinese, vietnamese, russia, sanctions, russian, perimeter, ukrainian, greek
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=28, 14d-median=30; carrying terms: position, belgium, kingdom, germany, france, ground, canada, bulgaria, netherlands, eagle, aabbef
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: geographic, member, border, linked, further, process, declaration, recent, february, third, being, addition
- cisa_kev: today=15, 7d-median=13, 14d-median=14; carrying terms: improper, vendor, buffer, zammad, citrix, remediation, product, memory, management, fixation, privilege, netscaler
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: guinea, forest, china, typhoon, fires, maximum, panama, flood, forestfire, tropical, cyclone, green
- usgs_quakes: today=11, 7d-median=21, 14d-median=17; carrying terms: depth, russia, philippines, panama, tonga, alaska, vilyuchinsk, vanuatu, southern
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, championship, presidential, shakhtar, volume, donetsk, champions, league, resolves, october, election, house
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, https, conversable, class, revolution, economist, money, public, remember, social, track, conve
- tech_news: today=59, 7d-median=59, 14d-median=58; carrying terms: agents, https, bleepingcomputer, theft, edition, newsletter, infrastructure, campaign, years, intelligence, download, microsoft
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: austin, norma, ciscomani, shaheen, gimenez, pramila, darren, kimberlyn, johnny, rivet, finstad, valerie
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, identify, either, placement, converges, evidence, decision, consensus, market, placed, paper, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Ontario Bancorporation, Inc.
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces it will extend, until November 4, the comment period on its proposal to modernize Regulation O
- [2026-10-02] Fed press (events + announcements): Federal Reserve Board announces approval of application by Fleur Capital Corporation
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-10-07] Fed press (events + announcements): Minutes of the Federal Open Market Committee, September 15-16, 2026
- [2026-10-08] ECB press: Piero Cipollone: Interview with Corriere della Sera
- [2026-10-08] Fed speeches: Waller, The Signaling Value of the Summary of Economic Projections
- [2026-10-08] ECB press: Meeting of 9-10 September 2026
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-13] ECB press: Philip R. Lane: The AI opportunity for Europe
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*