# WORLDSCOPE morning brief — 2026-11-16

## Headline
2771 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (732) · Russian Internal News (state + in-exile) (567) · World leaders & government officials (324) · Chinese Internal News (245) · U.S. Weather + Severe / Climate Outlooks (128) · GDELT GKG — themes / entities / watch areas (123) · World News (by country, top stories) (97) · Local News: St. Louis + Atlanta (96) · Ukraine Theater (total-war monitoring) (81) · State-Level News (74) · Ukrainian Internal News (national + local Kyiv) (56) · GDACS — global disaster alerts (43)

## What changed today
### International News + Multilateral Institutions — 732 new of 900 total
  - (2026-11-16) [Global] ‘The blood of these brothers cries out’: Pope Leo demands justice for people killed protecting the Amazon
  - (2026-11-16) [Global] Canada could work with Chinese automakers if US trade talks fail, says Carney
  - (2026-11-16) [Global] Megaspeed, the company linked to the downfall of Nvidia boss, says it’s a ‘legitimate and lawful business’
  - (2026-11-15) [Global] 160 questions, only one wrong: top scorer in South Korea tax exam admits AI cheating
  - (2026-11-16) [Global] MP Helen Haines’s first words since leaving hospital after alleged attack led to double amputation
  - (2026-11-16) [Global] Coles investigates cyber-attack and apologises to customers

### Russian Internal News (state + in-exile) — 567 new of 719 total
  - (2026-11-16) В школьных учебниках вырезали строфу про няню и кружку из стихотворения Пушкина | LEDE: В учебнике «Литературное чтение» для третьего класса стихотворение Александра Пушкина «Зимний вечер» н] (ru: В ш…
      В учебнике «Литературное чтение» для третьего класса стихотворение Александра Пушкина «Зимний вечер» напечатали без строфы, в которой поэт предлагает няне «выпить с горя». Об этом сообщила «Фонтанка».
  - (2026-11-16) В Молдове назвали федерализацию страны «идеей, которую достали из нафталина». Такое требование якобы выдвинула Россия на переговорах по Украине | LEDE: Спикер парламента Молдовы Игорь Гросу ] (ru: В М…
      Спикер парламента Молдовы Игорь Гросу заявил, что европейский курс страны закреплен в Конституции, а идеи, которые продвигает Россия, «достали из нафталина».
  - (2026-11-16) ВСУ атаковали Крымский мост. Движение по нему закрыто | LEDE: Глава аннексированного Крыма Сергей Аксенов заявил, что украинские военные атаковали мост, связывающий полуостров с Россией. ] (ru: ВСУ ат…
      Глава аннексированного Крыма Сергей Аксенов заявил, что украинские военные атаковали мост, связывающий полуостров с Россией.
  - (2026-11-16) FT: встреча лидеров Китая, США и России пройдет без заранее согласованной повестки | LEDE: Трехсторонняя встреча Дональда Трампа, Владимира Путина и Си Цзиньпина на полях саммита АТЭС в Кита] (ru: FT:…
      Трехсторонняя встреча Дональда Трампа, Владимира Путина и Си Цзиньпина на полях саммита АТЭС в Китае будет проходить без заранее согласованной повестки, пишет Financial Times. Издание отмечает, что это «необычный шаг», т…
  - (2026-11-16) Памятник Солженицыну решили оставить в центре Владивостока. Месяц назад его убирали с набережной, но через сутки вернули обратно | LEDE: Памятник писателю Александру Солженицыну больше не пл] (ru: Пам…
      Памятник писателю Александру Солженицыну больше не планируют переносить из центра Владивостока, сообщили РИА Новости в мэрии города.
  - (2026-11-16) Украина атаковала Ростовскую область и Краснодарский край. В Азове загорелась нефтебаза | LEDE: В городе Азов в результате атаки украинских дронов начались пожары на четырех производственных] (ru: Укр…
      В городе Азов в результате атаки украинских дронов начались пожары на четырех производственных объектах, сообщил губернатор Ростовской области Юрий Слюсарь.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 245 new of 270 total
  - (2026-11-16) China’s Fixed-Asset Investment Decline Deepens - Caixin Global
      China’s Fixed-Asset Investment Decline Deepens Caixin Global
  - (2026-11-16) CX Daily: Shadowy Agencies Prey on China’s Graduates Amid Tough Job Market - Caixin Global
      CX Daily: Shadowy Agencies Prey on China’s Graduates Amid Tough Job Market Caixin Global
  - (2026-11-16) Nissan Turns China Into Export Hub as Sales There Slump - Caixin Global
      Nissan Turns China Into Export Hub as Sales There Slump Caixin Global
  - (2026-11-16) China’s Industrial Output Growth Slows - Caixin Global
      China’s Industrial Output Growth Slows Caixin Global
  - (2026-11-16) China’s Retail Sales Growth Slows to 0.4%, Missing Forecasts - Caixin Global
      China’s Retail Sales Growth Slows to 0.4%, Missing Forecasts Caixin Global
  - (2026-11-15) Cover Story: The Promise and Risks of China’s AI Infrastructure Rush - Caixin Global
      Cover Story: The Promise and Risks of China’s AI Infrastructure Rush Caixin Global

### U.S. Weather + Severe / Climate Outlooks — 128 new of 130 total
  - (2026-11-16) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-15) [Moderate] Coastal Flood Watch: Coastal Flood Watch issued November 15 at 10:06PM AKST until November 19 at 1:00PM AKST by NWS Fairbanks AK
      * WHAT...Water levels of 3 to 5 feet above the normal high tide possible, with highest water level rises expected around Hooper Bay. Southeast winds could gust as high as 55 mph. * WHERE...Yukon Delta Coast, primarily Ho…
  - (2026-11-15) [Severe] High Wind Watch: High Wind Watch issued November 15 at 9:59PM AKST until November 19 at 3:00PM AKST by NWS Fairbanks AK
      * WHAT...South winds 30 to 50 mph with gusts up to 70 mph possible. * WHERE...Eastern Alaska Range North of Trims Camp and Windy Pass. * WHEN...From late Tuesday night through Thursday afternoon. * IMPACTS...Winds this s…
  - (2026-11-16) [Moderate] Rip Current Statement: Rip Current Statement issued November 16 at 1:59AM EST until November 20 at 1:00AM EST by NWS Tallahassee FL
      * WHAT...Dangerous rip currents. * WHERE...Franklin County Beaches. * WHEN...Through late Thursday night. * IMPACTS...Rip currents can sweep even the best swimmers away from shore into deeper water.
  - (2026-11-15) [Severe] Winter Storm Watch: Winter Storm Watch issued November 15 at 9:54PM AKST until November 19 at 3:00PM AKST by NWS Fairbanks AK
      * WHAT...Blizzard conditions possible. Total snow accumulations of 5 to 10 inches possible. Southeast winds could gust as high as 70 mph. * WHERE...St Lawrence Island. * WHEN...From Tuesday afternoon through Thursday aft…
  - (2026-11-15) [Severe] Winter Storm Watch: Winter Storm Watch issued November 15 at 9:54PM AKST until November 20 at 3:00PM AKST by NWS Fairbanks AK
      * WHAT...Snow and gusty winds possible. Total snow accumulations of 1 to 4 inches, with locally higher totals around 4 to 8 inches for the Southern Seward Peninsula Coast possible. Southeast winds could gust as high as 5…

### GDELT GKG — themes / entities / watch areas — 123 new of 123 total
  - (2026-11-16) [Russia oil sanctions perimeter · themes] Zelenskiy says Starshield restrictions threaten Ukraine's energy defences ahead of winter
      asiaone.com · English · tone -6.12460401267159 · 4 other outlets
  - (2026-11-16) [Russia oil sanctions perimeter · themes] Three ships struck by drones in Black Sea near Romanian shipping canal, PM says
      japantoday.com · English · tone -4.28954423592493
  - (2026-11-16) [Russia oil sanctions perimeter · keywords] Can a US-Approved Sale Clean a Shadow Fleet Tanker?
      maritime-executive.com · English · tone -0.817438692098093
  - (2026-11-16) [Russia oil sanctions perimeter · near] Prince Harry salutes wounded Ukrainian veterans as 'role models' on surprise Ukraine visit
      asiaone.com · English · tone -1.51898734177215 · 148 other outlets
  - (2026-11-16) [Russia oil sanctions perimeter · near] Zelenskyy says Starshield restrictions threaten Ukraine's energy defenses ahead of winter
      wwaytv3.com · English · tone -6.47249190938511 · 9 other outlets
  - (2026-11-16) [Russia oil sanctions perimeter · near] Zelensky: U.S. Asked if Ukraine Would Quit Donbas for NATO
      hngn.com · English · tone -2.6246719160105 · 2 other outlets

### World News (by country, top stories) — 97 new of 97 total
  - (2026-11-16) [Brazil] Brazil Coach, Captain See Red Against Japan
      thetidenewsonline.com · English
  - (2026-11-16) [Brazil] Brazil's Ceara declares drought emergency in 65 municipalities
      bignewsnetwork.com · English
  - (2026-11-16) [Brazil] Brazil expands Asian trade ties as Lula seeks to reduce dependence on US market
      slguardian.org · English
  - (2026-11-16) [Brazil] Brazilian media make strong claims against Chelsea in Estevao player ratings
      theprideoflondon.com · English
  - (2026-11-16) [Brazil] China Wants to Expand Open AI in BRICS: What Could Brazil Gain? – BRICS Information Sharing & Exchanging Platform
      brics-info.org · English
  - (2026-11-16) [Canada] Carney says Canada could turn to Chinese automakers if Trump trade talks fail
      hurriyetdailynews.com · English · 14 other outlets ran this story

### Local News: St. Louis + Atlanta — 96 new of 202 total
  - (2026-11-15) [St. Louis] Recipe: Sweet potato casserole with candied pecans
      Many years ago, I worked at Ruth’s Chris Steakhouse and immediately fell in love with their sweet potato casserole. It was a regular menu item—some people ordered it as a side, while others topped it with vanilla ice cre…
  - (2026-11-16) [St. Louis] St. Louis police fatally shoot man after alleged carjacking attempt in Dutchtown
      Police said a 42-year-old man pointed a BB pistol at a driver and refused repeated orders to drop it. The driver escaped unharmed.
  - (2026-11-16) [St. Louis] Isaac, a cat missing since the Brooklyn building collapse, has been reunited with his young owner
      A cat missing since last week’s deadly Brooklyn building collapse has been found alive and reunited with his young owner.
  - (2026-11-16) [St. Louis] Michael John Roberts, 'BoJack Horseman' animator, has died
      Michael John Roberts, the Canadian animator known best for his work on Netflix's "BoJack Horseman," has died.
  - (2026-11-16) [St. Louis] Missing 8-year-old dies after being found in St. Francois County lake
      A community member found the child on Sunday in Lac Carmel in St. Francois County. Rescuers performed CPR, and medics pronounced the child dead at 4:37 p.m.
  - (2026-11-15) [St. Louis] TSA finds live snakes in California traveler's luggage
      TSA said the luggage had a pillowcase filled with two of what they called "nope ropes," also known as snakes.

### Ukraine Theater (total-war monitoring) — 81 new of 266 total
  - (2026-11-16) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-15) [Liveuamap] Houthi forces… – Lahij Governorate, Yemen - Liveuamap
      Houthi forces… – Lahij Governorate, Yemen Liveuamap
  - (2026-11-14) [Liveuamap] Hackers who breached German… – Berlin, Berlin - Liveuamap
      Hackers who breached German… – Berlin, Berlin Liveuamap
  - (2026-11-13) [Liveuamap] 2 people killed in Zolota Balka of Kherson region as result of Russian drone strike – Kherson Oblast, Ukraine - Liveuamap
      2 people killed in Zolota Balka of Kherson region as result of Russian drone strike – Kherson Oblast, Ukraine <font c
  - (2016-04-29) [Liveuamap] Yemen live map: Houthis and Red Sea today | Liveuamap - Liveuamap
      Yemen live map: Houthis and Red Sea today | Liveuamap Liveuamap
  - (2026-11-12) [Liveuamap] Houthi forces… – Lahij Governorate, Yemen - Liveuamap
      Houthi forces… – Lahij Governorate, Yemen Liveuamap

### State-Level News — 74 new of 180 total
  - (2026-11-16) [California] Governor Newsom, Acting Governor Limón lower flags as Dolores Huerta is laid to rest
      Source
  - (2026-11-16) [Connecticut] CT voters gave us a mandate. Let’s meet the moment.
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/11/POST-ELECTION-1104-SG-07-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetch…
  - (2026-11-16) [Connecticut] New Haven’s short-term rental ban will hurt renters it’s meant to help
      <img width="842" height="559" src="https://ctmirror.org/wp-content/uploads/2026/11/nh-rent-debate.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="ht…
  - (2026-11-16) [Connecticut] CT’s gun laws work. Washington is coming for them anyway.
      <img width="734" height="373" src="https://ctmirror.org/wp-content/uploads/2026/11/JH-gun-chart.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="http…
  - (2026-11-15) [Connecticut] For veterans, joining the workforce can be tough. This group wants to help.
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/09/Unturning-Steel-0903-SG-07-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loa…
  - (2026-11-15) [Connecticut] The Holland Tunnel’s centennial year
      <img width="960" height="635" src="https://ctmirror.org/wp-content/uploads/2026/11/Holland-Tunnel.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="ht…

### Ukrainian Internal News (national + local Kyiv) — 56 new of 106 total
  - (2026-11-16) Молдова підтвердила заборону на виїзд "лідера" Придністров'я, який прибув до країни | LEDE: Вадиму Красносельському, самопроголошеному лідеру Придністров'я, після візиту до Путіна заборонено за] (uk:…
      Вадиму Красносельському, самопроголошеному лідеру Придністров'я, після візиту до Путіна заборонено залишати Молдову до 2028 року.
  - (2026-11-16) Шведські центристи вирішили формувати уряд з соціал-демократами | LEDE: ] (uk: Шведські центристи вирішили формувати уряд з соціал-демократами)
  - (2026-11-16) Двоє у владі. Як Буданов і Арахамія ділять вплив у владі Зеленського | LEDE: ] (uk: Двоє у владі. Як Буданов і Арахамія ділять вплив у владі Зеленського)
  - (2026-11-16) Росіяни знову атакували Дніпро: загинула людина, ще троє поранені, палали автівки | LEDE: Зранку 16 листопада росіяни завдали нового удару по Дніпру: загинула одна людина, ще троє дістали поран] (uk:…
      Зранку 16 листопада росіяни завдали нового удару по Дніпру: загинула одна людина, ще троє дістали поранень.
  - (2026-11-16) Окупанти заявили про удар по Кримському мосту: розгорнули оперативний штаб | LEDE: За заявою Сергія Аксьонова, через удар по Кримському мосту обмежено рух транспорту. У Керчі працюють служби та] (uk:…
      За заявою Сергія Аксьонова, через удар по Кримському мосту обмежено рух транспорту. У Керчі працюють служби та розгорнуто оперативний штаб.
  - (2026-11-16) Росіяни вдарили по об'єктах енергетики на Черкащині: частина людей – без електрики | LEDE: Внаслідок атаки російських окупаційних військ у Черкаській області знеструмлено частину споживачів.] (uk: Рос…
      Внаслідок атаки російських окупаційних військ у Черкаській області знеструмлено частину споживачів.

### GDACS — global disaster alerts — 43 new of 100 total
  - (2026-11-16) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 5.4M, Depth:273.644km
  - (2026-11-08) [Green] Flood in Argentina
      Flood · Green alert · Argentina · Magnitude 0
  - (2026-11-09) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 6011 ha
  - (2026-11-01) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 48082 ha
  - (2026-11-15) [Green] Earthquake in Russia
      Earthquake · Green alert · Russia · Magnitude 4.8M, Depth:10km
  - (2026-11-15) [Green] Earthquake in Afghanistan
      Earthquake · Green alert · Afghanistan · Magnitude 4.9M, Depth:191.363km

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-15) [United States] Dan Walters: With California's insurance crisis at an impasse, it might be time for a different approach – Daily Democrat
      domain: dailydemocrat.com · language: English · tone: -6.61417322834646 · 91 other outlets ran this story
  - (2026-11-16) Tanker's steering failed before New Orleans cruise ship crash – NBC 6 South Florida
      domain: nbcmiami.com · language: English · tone: -2.66990291262136 · 70 other outlets ran this story
  - (2026-11-16) [Pakistan] Who makes Sydney Sweeney's American Eagle jeans — and under what conditions?
      domain: wfsu.org · language: English · tone: -1.6827783745077 · 58 other outlets ran this story
  - (2026-11-16) [Australia] Police charge 14-year-old boy after alleged stolen car crash leaves teen girl in critical condition
      domain: abc.net.au · language: English · tone: -8.53658536585366 · 45 other outlets ran this story
  - (2026-11-16) [Bahrain] Iran targets US military base in Bahrain with drone attack - The Ghanaian Chronicle
      domain: thechronicle.com.gh · language: English · tone: -5.55555555555556 · 41 other outlets ran this story
  - (2026-11-16) [United States] Family hopes to create memorial for 6-year-old killed in Pacific Beach hit-and-run – NBC 7 San Diego
      domain: nbcsandiego.com · language: English · tone: -0.199203187250997 · 36 other outlets ran this story

### Wikidata leader-roster changes (48h) — 35 new of 64 total
  - (2026-11-16) [Samoa] Tuilaʻepa Saʻilele Malielegaoi (Q57723) edited
      /* clientsitelink-remove:1||cewiki */ Туилаэпа-Аионо-Саилеле-Малиелегаои
  - (2026-11-15) [Azerbaijan] Ilham Aliyev (Q57371) edited
      /* wbeditentity-statements-single-property-update:1||2 */ [[Property:P166]]
  - (2026-11-15) [Austria] Alexander Van der Bellen (Q78869) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/69064|batch #69064]]
  - (2026-11-15) [Comoros] Azali Assoumani (Q515602) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/69349|batch #69349]]: add P1810 to P396
  - (2026-11-15) [Cuba] Miguel Díaz-Canel (Q1932603) edited — position held
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/69349|batch #69349]]: add P1810 to P396
  - (2026-11-15) [Czech Republic] Petr Pavel (Q2080040) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/69064|batch #69064]]

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 22 new of 24 total
  - (2026-11-16) JAF4PT (Belgium)
      icao24: 44b438 · position: (39.3274, 2.2749) · alt: 11277m · 849km/h
  - (2026-11-16) NCR672 (United States)
      icao24: a95c2f · position: (61.1769, -149.9888) · on ground
  - (2026-11-16) NCR868 (United States)
      icao24: aa3086 · position: (32.1769, 34.5207) · alt: 2727m · 493km/h
  - (2026-11-16) AF2 (Australia)
      icao24: 7c00d0 · position: (-12.3942, 130.9234) · alt: 396m · 242km/h
  - (2026-11-16) FNY5277 (France)
      icao24: 3b9b18 · position: (46.7395, -1.8571) · alt: 8229m · 893km/h
  - (2026-11-16) JAF8WN (Belgium)
      icao24: 449683 · position: (42.5774, 20.3974) · alt: 5021m · 766km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 16 new of 63 total
  - (2026-11-16) [The Register] Techie rigged off-spec fan near flammable liquid and an exposed motherboard, then left it to run for days
      Nobody died, money got made, and the maintenance crew didn’t care
  - (2026-11-16) [The Register] Microsoft’s Azure Linux dons Fedora to dress itself up for mainstream workloads
      Version 4.0 of Redmond’s cloudy OS is free to use in its cloud. Repeat. Free to use
  - (2026-11-16) [The Register] Amazon loses first batch of broadband satellites launched on custom rocket
      United Launch Alliance’s Vulcan LEO didn’t reach orbit
  - (2026-11-16) [TechCrunch] Helsing backer Plural raises $1.1B to fund Europe’s next moonshots
      Operator-led VC firm Plural has raised €1 billion in new capital ($1.1 billion), joining a growing cohort of larger European funds that also includes Mundi Ventures’ Kembara and EQT-managed Scaleup Europe Fund.
  - (2026-11-16) [TechCrunch] Apple launches new app to study how people use AI for health
      Apple's new app for a study will answer everyday medical questions
  - (2026-11-15) [BleepingComputer] FBI warns ARTEX AI hacking tool is powering global cyberattacks
      The FBI is warning that hackers are using an AI-powered penetration testing framework called ARTEX to automate cyberattacks against organizations worldwide, including a recent ConnectWise supply-chain breach that comprom…

### Paper Trading Scorecard — 15 new of 74 total
  - (2026-11-16) [Polymarket] Will Z.ai have the best AI model at the end of November 2026?
      This market will resolve according to the company which owns the model which has the highest arena rank based on the arena.ai Text Arena (Overall) when the table under the "Leaderboard" tab is checked on November 30, 202…
  - (2026-11-16) [Polymarket] Will BYD be removed from Chinese Military Companies list by June 30, 2027?
      This market will resolve to "Yes" if the specified company is fully removed from the list entitled “Entities Identified as Chinese Military Companies Operating in the United States in Accordance with Section 1260H of the…
  - (2026-11-16) [Manifold] Will this Vincent van Gogh painting sell for >$200 million?
  - (2026-11-16) [Manifold] Will Jensen Huang return to NVIDIA CEO before November 30, 2026?
  - (2026-11-16) [Manifold] Do you think gta 6 will be buggy on release day?
  - (2026-11-16) [Manifold] What fraction of the participants of justwrite.club will win?

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-14) [F99] (unknown)
      cycle 2026 · filing #2047750
  - (2026-11-14) [F99] (unknown)
      cycle 2026 · filing #2047702
  - (2026-11-14) [F2] MONTANEZ BERRIOS (DMB), DELIRIS
      cycle 2026 · filing #2047724
  - (2026-11-14) [F99] (unknown)
      cycle 2026 · filing #2047741
  - (2026-11-14) [F99] (unknown)
      cycle 2026 · filing #2047747
  - (2026-11-14) [F99] (unknown)
      cycle 2026 · filing #2047754

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-11-16) Will Kristi Noem win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $1,148,546 · resolves 2028-11-08
  - (2026-11-16) Will there be no new be CEO of NVIDIA by December 31, 2028?
      yes price: 16% · 24h volume: $768,875 · resolves 2029-01-01
  - (2026-11-16) Will Jensen Huang rejoin NVIDIA by November 30, 2026?
      yes price: 7% · 24h volume: $378,463 · resolves 2026-12-01
  - (2026-11-16) Sydney: Omar Jasika vs Alex Bolt
      yes price: 100% · 24h volume: $334,295 · resolves 2026-11-23
  - (2026-11-16) Will Jamie Dimon win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $296,034 · resolves 2028-11-08
  - (2026-11-16) Will Jesus Christ return before 2027?
      yes price: 1% · 24h volume: $195,482 · resolves 2027-01-01

### USGS earthquakes (M4.5+, past day) — 9 new of 9 total
  - (2026-11-15) M 5.5 - 9 km E of Union, Philippines
      M5.5 · 9 km E of Union, Philippines · depth 9.971 km
  - (2026-11-16) M 5.4 - 20 km NW of Anamizu, Japan
      M5.4 · 20 km NW of Anamizu, Japan · depth 273.644 km
  - (2026-11-15) M 5.1 - 169 km NW of Gorontalo, Indonesia
      M5.1 · 169 km NW of Gorontalo, Indonesia · depth 487.384 km
  - (2026-11-15) M 5.0 - 256 km SSE of Ambon, Indonesia
      M5.0 · 256 km SSE of Ambon, Indonesia · depth 305.989 km
  - (2026-11-15) M 5.0 - 74 km N of Pārūn, Afghanistan
      M5.0 · 74 km N of Pārūn, Afghanistan · depth 100.728 km
  - (2026-11-15) M 4.9 - 44 km S of Jurm, Afghanistan
      M4.9 · 44 km S of Jurm, Afghanistan · depth 191.363 km

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-11-16) [Marginal Revolution] A scenario for rogue AIs?
      From Adam Kaufman: I think it’s pretty likely that in 6 months there will be rogue AIs running around on the internet, appropriating whatever compute they can hack into or pay for (with stolen money or by renting out the…
  - (2026-11-15) [Marginal Revolution] Sunday assorted links
      1. His office. 2. The South African bi-oceanic railway. 3. Ethnic politics and class politics. 4. AI-generated preview is going viral, what is the chance they make the movie now? I will pay to see it. Is this a new metho…
  - (2026-11-15) [Marginal Revolution] Tyler Cowen’s strongest musical recommendations, 2003–2026
      From the Archive, written by ChatGPT: The clearest standouts are Loveless, Brazil Classics 1, Solo Monk, and the Louvin Brothers’ Tragic Songs of Life. Bach receives the strongest sustained endorsement across the years.…

### State Legislative Action — 2 new of 73 total
  - (2026-11-15) [Vermont H 575] An act relating to survivor and disability benefits for emergency personnel
      An act relating to survivor and disability benefits for emergency personnel
  - (2026-11-14) [Virginia SB 857] Public education; enrollment of certain children placed in foster care, assessment reqs., guidance.
      Public education; enrollment of certain children placed in foster care; assessment requirements; guidance. Provides that if a child placed in foster care transfers from one school division to another, the receiving schoo…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 2 new of 34 total
  - (2026-11-16) MOVER ▲ Zhong Shanshan — $66.22B (+$1.28B since yesterday)
      China · Food & Beverage · source: Beverages, pharmaceuticals
  - (2026-11-16) MOVER ▲ Tadashi Yanai & family — $70.74B (+$1.20B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-16) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=21, 14d-median=25; carrying terms: reflect, provide, final, regulatory, proposed, action, applicable, airworthiness, safety, directives, certain, airplanes
- state_bills: today=73, 7d-median=97, 14d-median=90; carrying terms: medical, emergency, reporting, health, protection, authority, approval, insurance, providing, program, relating, vehicle
- state_news: today=180, 7d-median=717, 14d-median=675; carrying terms: obituary, httperror, toomanyredirects, republican, against, caucus, letters, decision, representing, district, effort, leader
- local_news: today=202, 7d-median=266, 14d-median=256; carrying terms: football, google, business, killed, house, early, south, death, atlanta, police, cbmigwfbvv, president
- foreign_news: today=900, 7d-median=997, 14d-median=992; carrying terms: field, region, block, labour, thenationalnews, follow, suspected, football, massive, iranian, district, threatens
- chinese_internal: today=270, 7d-median=321, 14d-median=321; carrying terms: google, cbmickfvx, lxtfb, cbmix, cbmizefvx, cbmiy, global, cbmizkfvx, lxtfa, cbmic, cbmiakfvx, market
- russian_internal: today=719, 7d-median=1012, 14d-median=938; carrying terms: laquo, httperror, https, client, bloomberg, error, telegram, axios, reuters, server, politico, europe
- ukrainian_internal: today=106, 7d-median=132, 14d-median=134; carrying terms: httperror, region, against, struck, foreign, operation, killed, ukrainian, vladimir, house, international, concerns
- ukraine_theater: today=266, 7d-median=271, 14d-median=271; carrying terms: region, tfmnvgvty, jjvgnycxjibzdf, benfcnbfawndznpkvevcngdeyklvtmvboecxrmvsnznvdvdkz, ddnsrzniverxc, xfturhrs, lxtfbqd, cbmiv, cbmiaefvx, bvlfctc, interim, google
- paper_bets: today=74, 7d-median=74, 14d-median=71; carrying terms: problem, russell, receiving, yards, speed, funds, openai, world, colonize, fusion, zohran, anthropic
- weather: today=130, 7d-median=130, 14d-median=130; carrying terms: hurricane, region, forecast, capsize, light, message, pontiac, afdfwd, waters, afdhgx, around, discussion
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: vixcls, money, growth, dexjpus, payems, spread, recession, nonfarm, funds, personal, latest, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: futures, russell, close, yield, silver, bitcoin, crude, credit, equities, large, corporate, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=100, 7d-median=100, 14d-median=99; carrying terms: aeronautics, entity, maintenance, btdyc, comments, hybrid, mtjwwxz, activities, google, description, provide, blank
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quantitative, httperror, https, unauthorized, client, error, quiver, congresstrading
- billionaires: today=34, 7d-median=34, 14d-median=0; carrying terms: oracle, brokerage, jensen, ellison, bloomberg, buffett, michael, spain, tiktok, carlos, yanai, finance
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60; carrying terms: court, supreme, international, state, connecticut, delaware, appeals, blanche, florida, company, thomas, trade
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, filed, issuer, holdings, michael, isaac, brian, partners, investment, centuri, william
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: disbursements, receipts, ossoff, peltola, cooper, cycle, talarico, james, jackson, jonathan, warner, robert
- gdelt_regions: today=97, 7d-median=97, 14d-median=12; carrying terms: english, europe, trump, south, korea, japan, daily, korean, nvidia, million, german, turkey
- gdelt_gkg: today=123, 7d-median=115, 14d-median=26; carrying terms: english, russian, sanctions, keywords, themes, trump, russia, perimeter, chinese, hezbollah, israel, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=0; carrying terms: language, australia, killed, murder, trump, domain, police, shooting, english, suspect, injured, ukraine
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=24, 7d-median=22, 14d-median=26; carrying terms: position, france, belgium, germany, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: addition, consuming, sometimes, response, bangladesh, increasingly, adult, region, occupational, expanded, driving, kenya
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: critical, authentication, value, product, google, cisco, missing, vulnerability, return, remediation, vendor, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=64, 7d-median=54, 14d-median=0; carrying terms: languages, places, guinea, people, bulgaria, batch, wikidatacleanup, republic, bissau, import, short, democratic
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: australia, wildfire, earthquake, fires, sudan, impact, botswana, green, magnitude, south, forest, depth
- usgs_quakes: today=9, 7d-median=12, 14d-median=11; carrying terms: depth, japan, indonesia, philippines, russia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, volume, presidential, israel, ceasefire, champions, championship, league, november, continues, donetsk
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, revolution, marginal, conversable, class, economist, since, conversableeconomist, world, economic, working, around
- tech_news: today=63, 7d-median=63, 14d-median=61; carrying terms: critical, daily, access, three, investigation, computer, schneier, spectrum, computerweekly, found, remote, review
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: scalise, incumbent, mentions, weber, vasquez, housing, friedman, barrasso, riley, wilson, michael, duyne
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, module, identify, converges, placed, claude, either, market, today, decision, evidence, consensus

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*