# WORLDSCOPE morning brief — 2026-09-08

## Headline
2910 new items across 23 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (772) · Russian Internal News (state + in-exile) (703) · World leaders & government officials (324) · Chinese Internal News (236) · Ukraine Theater (total-war monitoring) (214) · State-Level News (152) · U.S. Weather + Severe / Climate Outlooks (118) · Local News: St. Louis + Atlanta (98) · Ukrainian Internal News (national + local Kyiv) (69) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (33) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 772 new of 995 total
  - (2026-09-08) [Global] Canada braces for prolonged trade war as counter-tariffs on US take effect
      The tariffs will apply to $20bn worth of American products, jeopardising the stability of the world's largest bilateral trading relationship.
  - (2026-09-08) [Global] At least two people dead after Russian strikes on Kyiv
      Air raid alerts and sounds of explosions rang out in Ukraine's capital as Russian forces launched drone strikes early on Tuesday.
  - (2026-09-08) [Global] Investigation after female staff at Eiffel Tower replaced by men for religious visit
      The move saw outraged staff walk off the job on Monday, closing the French landmark for a day.
  - (2026-09-08) [Global] Highest paid world leader to get salary increase of $1 million
      Singapore's prime minister Lawrence Wong will see his annual pay rise to 3.6 million Singapore dollars ($2.8m; £2.1m).
  - (2026-09-08) [Global] Argentina targets oil company operating in Falklands
      The move comes days after President Javier Milei stepped up Argentina's claims of sovereignty over the Falklands.
  - (2026-09-08) [Global] Five killed in Miami plane crash were in two vehicles on ground, investigators say
      Investigators described the scene as "utter devastation" after a Boeing 767-300 overshot the runway at Miami airport.

### Russian Internal News (state + in-exile) — 703 new of 1015 total
  - (2026-09-08) Умер первый председатель Банка России Георгий Матюхин — единственный, чья подпись появлялась на российских банкнотах | LEDE: Первый председатель Банка России Георгий Матюхин умер на 92-м год] (ru: Уме…
      Первый председатель Банка России Георгий Матюхин умер на 92-м году жизни, сообщила пресс-служба регулятора.
  - (2026-09-08) Венеция-2026. «Возможная любовь» звезды корейского кино Ли Чхан Дона. Драма, в которой паразитами на этот раз точно оказываются богачи | LEDE: На Венецианском кинофестивале прошла премьера ф] (ru: Вен…
      На Венецианском кинофестивале прошла премьера фильма «Возможная любовь» (Ganeunghan sarang) Ли Чхан Дона — звезды корейского кино, автора «Пылающего» и «Поэзии». Будто в ответ главному хиту корейского кинематографа после…
  - (2026-09-08) Российский дрон повредил здание канала «Мы — Украина» в Киеве, когда он показывал в прямом эфире телемарафон | LEDE: Один из дронов, которыми российские войска атаковали Киев 8 сентября, пов] (ru: Рос…
      Один из дронов, которыми российские войска атаковали Киев 8 сентября, повредил здание телеканала «Мы — Украина».
  - (2026-09-08) Правительство РФ разрешило выдавать сотрудникам почты антидроновые ружья | LEDE: Правительство РФ включило средства для борьбы с беспилотниками в список служебных средств для работников почт] (ru: Пра…
      Правительство РФ включило средства для борьбы с беспилотниками в список служебных средств для работников почты. Соответствующее постановление подписал премьер-министр Михаил Мишустин.
  - (2026-09-08) В Москве сносят Электрозавод. Фасады обещают «сохранить» — но нет гарантий, что их не заменят новоделом. «Медуза» показывает, что сейчас происходит на территории исторического завода | LEDE: <p] (ru:…
      На территории Электрозавода — одного из самых выразительных образцов промышленной архитектуры в Москве — снесли часть построек. До 2025 года у Электрозавода был временный охранный статус, он считался выявленным объектом…
  - (2026-09-08) Венгрия высылает десять российских дипломатов | LEDE: Венгрия потребовала от десяти российских дипломатов покинуть страну. Об этом объявила министр иностранных дел страны Анита Орбан. ] (ru: Венгрия в…
      Венгрия потребовала от десяти российских дипломатов покинуть страну. Об этом объявила министр иностранных дел страны Анита Орбан.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 236 new of 280 total
  - (2026-09-07) CATL Sees New-Energy Big Rigs Making Up Half of China’s Truck Sales by 2028 - Caixin Global
      CATL Sees New-Energy Big Rigs Making Up Half of China’s Truck Sales by 2028 Caixin Global
  - (2026-09-08) Analysis: Stricter Rules, State Capital Are Rewiring China’s Venture Ecosystem - Caixin Global
      Analysis: Stricter Rules, State Capital Are Rewiring China’s Venture Ecosystem Caixin Global
  - (2026-09-07) Commentary: Zombie Automakers Are Fueling China’s Export Chaos - Caixin Global
      Commentary: Zombie Automakers Are Fueling China’s Export Chaos Caixin Global
  - (2026-09-07) 尚睿闻（Raymond Sagayam）： 亚洲崛起，重塑全球市场核心趋势_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFA0RThjN0pzQ2VtcS1PZV9uUWZfTzZFLVN3TDd2d3ZXajQ5X2RzZng3bktPSFlLX0hXVXkyM] (zh:…
      尚睿闻（Raymond Sagayam）： 亚洲崛起，重塑全球市场核心趋势_特别呈现_手机财新网 财新
  - (2026-09-07) 财新闻｜商家隐瞒关键信息致消费者错失购车补贴 法院判了 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE90NzRkNEJpMU8xSDJPWVc1QXNxem1xbFJYN09jUFdaOGhYbFBYanhvSTVJdi1aZDVJTG5rZmtfc2N6c] (zh:…
      财新闻｜商家隐瞒关键信息致消费者错失购车补贴 法院判了 mini.caixin.com
  - (2026-09-07) 看到那眼神与身影，你无法掉头而去｜亲历 - mini.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9GQ2tQOVpidDVzRE9CdkdfWUxEVTBTRVY1ZjUtanl6bFR0UGpjYjJDSzg0R0t0SXdaUUdIX1ltUEdDYnZDY1RRX] (zh:…
      看到那眼神与身影，你无法掉头而去｜亲历 mini.caixin.com

### Ukraine Theater (total-war monitoring) — 214 new of 416 total
  - (2026-09-08) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-07) [Liveuamap] A drone struck a refugee camp belonging to an Iranian Kurdish opposition group in Sulaymaniyah in Iraq&039;s Kurdistan Region, at about 4:40 a.m. on Monday, Kurdistan-based website Rudaw r…
      A drone struck a refugee camp belonging to an Iranian Kurdish opposition group in Sulaymaniyah in Iraq&039;s Kurdistan Regi
  - (2026-08-09) [Liveuamap] Houthis targeted the Heijah Al-Abd road linking the governorates of Taiz and Aden with a ballistic missile. - Liveuamap
      Houthis targeted the Heijah Al-Abd road linking the governorates of Taiz and Aden with a ballistic missile. &n
  - (2026-09-07) [Liveuamap] At Sloviansk direction clashes yesterday near Ozerne and Kryva Luka, also towards Ray-Oleksandrivka, - General Staff of Armed Forces of Ukraine reports Donetsk Oblast, Ukraine - Ukraine In…
      At Sloviansk direction clashes yesterday near Ozerne and Kryva Luka, also towards Ray-Oleksandrivka, - General Staff of Armed F
  - (2026-09-01) [Liveuamap] The death toll has risen to 5 following an explosion at an ammunition depot in Binnish, in the Idlib countryside of northwestern Syria. - Liveuamap
      The death toll has risen to 5 following an explosion at an ammunition depot in Binnish, in the Idlib countryside of north
  - (2026-09-08) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap

### State-Level News — 152 new of 325 total
  - (2026-09-07) [California] Happy Labor Day! California is the #1 for state for workers, #1 economy in the nation
      Source
  - (2026-09-07) [California] Governor Newsom proclaims Labor Day
      Source
  - (2026-09-08) [Connecticut] CT towns are installing license plate reading cameras on school buses
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/09/SCHOOL-BUS-CAMERAS-0902-SG-07-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-09-08) [Connecticut] Help preserve the Preserve in Old Saybrook
      <img width="1024" height="505" src="https://ctmirror.org/wp-content/uploads/2026/09/Pequot-Swamp-pond-in-fall-1024x505.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" load…
  - (2026-09-08) [Delaware] Employee backlash grows at UD as return-to-office policy advances
      <img width="1024" height="768" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/09/IMG_8728-scaled.jpeg?fit=1024%2C768&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=""…
  - (2026-09-08) [Delaware] Delaware districts may miss out on state money for new schools
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/02/delmar-hallway-edited.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…

### U.S. Weather + Severe / Climate Outlooks — 118 new of 120 total
  - (2026-09-08) [Moderate] Gale Warning: Gale Warning issued September 8 at 3:50AM AKDT until September 9 at 1:00AM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, south winds 20 to 30 kt with gusts up to 40 kt. For the Gale Warning, south winds 25 to 35 kt with gusts up to 50 kt expected. For the second Small Craft Advisory, south winds…
  - (2026-09-08) [Moderate] Gale Warning: Gale Warning issued September 8 at 3:48AM AKDT until September 9 at 5:00AM AKDT by NWS Juneau AK
      Southeast Alaska Inside Waters from Dixon Entrance to Skagway Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and…
  - (2026-09-08) [Moderate] Gale Warning: Gale Warning issued September 8 at 3:45AM AKDT until September 9 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-08) [Moderate] Gale Warning: Gale Warning issued September 8 at 3:45AM AKDT until September 9 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-08) [Moderate] Gale Warning: Gale Warning issued September 8 at 3:45AM AKDT until September 9 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-08) [Moderate] Gale Warning: Gale Warning issued September 8 at 3:45AM AKDT until September 9 at 5:00PM AKDT by NWS Anchorage AK
      Offshore Waters Forecast for the Bering Sea Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent an average of the highest one-third of the combined wind wave and swell height. .TO…

### Local News: St. Louis + Atlanta — 98 new of 130 total
  - (2026-09-08) [St. Louis] City Foundry developer suggests entertainment may be the best use for The Armory
      Steve Smith wants to get a conversation started about whether The Armory should be converted into office space or kept as an entertainment venue. And the CEO of New + Found says that can’t just be theoretical: Part of de…
  - (2026-09-08) [St. Louis] UMSL lists chancellor’s home for sale, ending a 51-year tradition
      Live like a chancellor for the price of a tenured professor—that’s how real estate agent Brian Elsesser is pitching the four-bed, four-bathroom, 3,300-square-foot home that just hit the market in Bellerive Acres. The hou…
  - (2026-09-07) [St. Louis] St. Louis restaurant openings, closings, and coming soons
      The following information is accurate as of an early-September press date. The month began with a rare double whammy—and then some—on August 1: Baileys’ Chocolate Bar and Baileys’ Range both closed, Salt + Smoke shuttere…
  - (2026-09-07) [St. Louis] Lou’s Clues – 9/07/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-09-07) [St. Louis] Top family-friendly events this week in St. Louis
      Toddler Tunes | Beginning September 8The Magic House is adding a new Tuesday-morning program just for toddlers and their grown-ups. Little ones can sing, dance, play instruments, explore rhythm, and enjoy interactive sto…
  - (2026-09-08) [St. Louis] Cinema St. Louis limits the use of AI in festival films

### Ukrainian Internal News (national + local Kyiv) — 69 new of 132 total
  - (2026-09-08) Прем’єрка Ісландії відреагувала на мапу Трампа, де країна позначена прапором США | LEDE: Кріструн Фростадоттір вважає публікацію Дональда Трампа з мапою, на якій американський прапор охоплює ін] (uk:…
      Кріструн Фростадоттір вважає публікацію Дональда Трампа з мапою, на якій американський прапор охоплює інші країни, образливою для ісландців, канадців та гренландців.
  - (2026-09-08) Зеленський заявив, що, крім Кравченка, також зустрічався з керівниками НАБУ і САП | LEDE: Президент Зеленський 7 вересня провів зустрічі з очільниками Національного антикорупційного бюро, Спеці] (uk:…
      Президент Зеленський 7 вересня провів зустрічі з очільниками Національного антикорупційного бюро, Спеціалізованої антикорупційної прокуратури та генпрокурором Русланом Кравченком. Говорили про кадрові питання
  - (2026-09-08) Сервіс "ухиляння" повного циклу: на Львівщині викрили організовану злочинну групу | LEDE: На Львівщині правоохоронці викрили злочинне угруповання, учасники якого, допомагали чоловікам призовног] (uk:…
      На Львівщині правоохоронці викрили злочинне угруповання, учасники якого, допомагали чоловікам призовного віку оформити фіктивні медичні документи про стан здоров'я.
  - (2026-09-08) У ексзаступника глави Львівського ОТЦК хочуть конфіскувати автівки й будинок на понад 7,4 млн | LEDE: Спеціалізована антикорупційна прокуратура вимагає визнати необґрунтованими активи колишньог] (uk:…
      Спеціалізована антикорупційна прокуратура вимагає визнати необґрунтованими активи колишнього заступника начальника Львівського обласного ТЦК та СП.
  - (2026-09-08) Росія пригрозила Угорщині "жорсткою відповіддю" за вигнання російських дипломатів | LEDE: МЗС РФ пообіцяло відреагувати на висилку 10 російських дипломатів з Будапешта. Орбан заявила: це не впл] (uk:…
      МЗС РФ пообіцяло відреагувати на висилку 10 російських дипломатів з Будапешта. Орбан заявила: це не вплине на дипвідносини. Подробиці конфлікту.
  - (2026-09-08) У Кремлі заявили, що перемога РФ у війні проти України вже близько | LEDE: Дмитро Пєсков стверджує, що російська армія близька до перемоги у війні з Україною. Кремль висловив умови для завершен] (uk:…
      Дмитро Пєсков стверджує, що російська армія близька до перемоги у війні з Україною. Кремль висловив умови для завершення конфлікту.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-08) 424B2 - MP Agregador, S. de R.L. de C.V. (0001876711) (Filer)
      filed 2026-09-08 11:55 UTC — Filed: 2026-09-08 AccNo: 0001140361-26-035849 Size: 874 KB
  - (2026-09-08) 424B2 - Mercado Livre Brasil Ltda. (0001833442) (Filer)
      filed 2026-09-08 11:55 UTC — Filed: 2026-09-08 AccNo: 0001140361-26-035849 Size: 874 KB
  - (2026-09-08) 424B2 - MercadoLibre Colombia Ltda. (0001833425) (Filer)
      filed 2026-09-08 11:55 UTC — Filed: 2026-09-08 AccNo: 0001140361-26-035849 Size: 874 KB
  - (2026-09-08) 424B2 - MercadoLibre S.R.L. (0001833424) (Filer)
      filed 2026-09-08 11:55 UTC — Filed: 2026-09-08 AccNo: 0001140361-26-035849 Size: 874 KB
  - (2026-09-08) 424B2 - DeRemate.com of Mexico, S. de R.L. de C.V. (0001833420) (Filer)
      filed 2026-09-08 11:55 UTC — Filed: 2026-09-08 AccNo: 0001140361-26-035849 Size: 874 KB
  - (2026-09-08) 424B2 - MercadoLibre Chile Ltda. (0001833418) (Filer)
      filed 2026-09-08 11:55 UTC — Filed: 2026-09-08 AccNo: 0001140361-26-035849 Size: 874 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 33 new of 56 total
  - (2026-09-08) [BleepingComputer] Hackers build AI frameworks for widescale credential theft
      Threat actors are increasingly switching from AI-powered coding assistants to multi-agent frameworks that automate every stage of an attack. [...]
  - (2026-09-08) [BleepingComputer] Microsoft: Windows Server 2025 changes causing app crashes
      Microsoft warned customers last week that they may experience application crashes on some Windows Server 2025 due to recent memory management changes. [...]
  - (2026-09-08) [BleepingComputer] 220 million traveler records exposed in Vietnam-linked APIS leak
      Exclusive: An exposed Advance Passenger Information System (APIS) database held 220 million passenger and crew records containing names, passport numbers, dates of birth, nationalities, and flight details spanning 2017 t…
  - (2026-09-08) [The Hacker News] FreeIPA Flaw Chain Lets Anonymous Clients Create Reusable Administrator Credentials
      A flaw in FreeIPA lets a client that has never logged in create a Kerberos identity of its own choosing in the directory and end up in the administrators group, Red Hat says. FreeIPA is the system that determines who may…
  - (2026-09-08) [The Hacker News] Adobe Patches Magento Zero-Day Exploited to Deploy Rust Backdoor and PHP Web Shell
      Adobe on Monday released security patches to address a maximum-severity flaw impacting Adobe Commerce and Magento Open Source that has come under active exploitation in the wild. The vulnerability, now tracked as CVE-202…
  - (2026-09-08) [The Hacker News] BengalSEO Poisons Bing Search Results to Deliver MayaBot and Tech Support Scams
      Cybersecurity researchers have disclosed details of a sprawling search engine optimization (SEO) poisoning campaign that paves the way for malware deployment and tech support scams. The campaign, discovered by the DFIR R…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-09-08) JAF4KN (Bulgaria)
      icao24: 4520ce · position: (33.8969, -6.5682) · alt: 7269m · 783km/h
  - (2026-09-08) JAF5GA (Bulgaria)
      icao24: 4520aa · position: (33.0325, -7.4795) · alt: 5356m · 693km/h
  - (2026-09-08) INDIA2 (India)
      icao24: 8002fb · position: (19.0891, 72.8919) · alt: 121m · 253km/h
  - (2026-09-08) SAMU71 (France)
      icao24: 398c4e · position: (46.1876, 4.8321) · alt: 609m · 226km/h
  - (2026-09-08) PAT011 (United States)
      icao24: adfe4d · position: (38.3182, -85.925) · alt: 4076m · 333km/h
  - (2026-09-08) JAF59L (Belgium)
      icao24: 44d1ba · position: (47.5379, 1.9768) · alt: 11887m · 758km/h

### Paper Trading Scorecard — 20 new of 131 total
  - (2026-09-08) [Polymarket] Will the Fed Pause–Pause–Cut in the next three decisions (Jun–Jul–Sep)?
      The FED interest rates are defined in this market by the upper bound of the target federal funds rate. The decisions on the target federal funds rate are made by the Federal Open Market Committee (FOMC) meetings. This ma…
  - (2026-09-08) [Manifold] Will Speaker Mike Johnson send the House members home early before midterms?
  - (2026-09-08) [Manifold] US Average Gas Price Is $4.100 or more on September 14 2026?
  - (2026-09-08) [Manifold] Daily Coinflip
  - (2026-09-08) [Manifold] Did OpenAI just solve navier stokes??
  - (2026-09-08) [Manifold] Will California elect a Republican governor in 2026?

### Government Action: Sanctions + Procurement + Foreign Agents — 20 new of 103 total
  - (2026-09-04) [OFAC] Iran-related Designations; Issuance of Iran-related General License - ofac.treasury.gov
      Iran-related Designations; Issuance of Iran-related General License ofac.treasury.gov
  - (2026-09-03) [OFAC] Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License - ofac.treasury.gov
      Cuba Designations; Russia-related Designation Removal; Issuance of Amended Cuba General License ofac.treasury.gov
  - (2026-09-02) [OFAC] Reminder to file the 2026 Annual Report of Blocked Property; Issuance of Amended Venezuela-related General Licenses and Frequently Asked Question - ofac.treasury.gov
      Reminder to file the 2026 Annual Report of Blocked Property; Issuance of Amended Venezuela-related General Licenses and Frequently Asked Question ofac.treasury.gov
  - (2026-09-04) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se - ofac.treasury.gov
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 13902 of January 10, 2020 (“Imposing Sanctions With Respect to Additional Se ofac.treasury.gov
  - (2026-09-03) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in - ofac.treasury.gov
      OFFICE OF FOREIGN ASSETS CONTROL Executive Order 14404 of May 1, 2026 Imposing Sanctions on Those Responsible for Repression in ofac.treasury.gov
  - (2026-09-02) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54C Authorizing the Supply - ofac.treasury.gov
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54C Authorizing the Supply ofac.treasury.gov

### World News (by country, top stories) — 12 new of 12 total
  - (2026-09-08) [China] Should children literature cultivate competition or compassion ?-- Beijing Review
      bjreview.com.cn · English
  - (2026-09-08) [China] China - Laos Peace Train - 2026 joint exercise opens in Vientiane
      en.people.cn · English
  - (2026-09-08) [China] China imposes provisional anti - dumping measures on Japanese dichlorosilane
      en.people.cn · English
  - (2026-09-08) [China] Women in NW China Xinjiang stitch brighter future at local workshop
      en.people.cn · English
  - (2026-09-08) [China] Clued - in | From China Shock to China Squeeze : China threat narrative falls apart
      en.people.cn · English
  - (2026-09-08) [China] Interview with Dame Dr . Adaora Umeoji , OON , Group Managing Director and Chief Executive Officer , Zenith Bank
      internationalbanker.com · English

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-09-08) Genoa: Thiago Seyboth Wild vs Francesco Ferrari
      yes price: 54% · 24h volume: $1,382,773 · resolves 2026-09-15
  - (2026-09-08) LoL: Invictus Gaming vs LGD Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $1,365,682 · resolves 2026-09-08
  - (2026-09-08) LoL: Invictus Gaming vs LGD Gaming - Game 3 Winner
      yes price: 100% · 24h volume: $1,058,427 · resolves 2026-09-08
  - (2026-09-08) LoL: Invictus Gaming vs LGD Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $858,815 · resolves 2026-09-08
  - (2026-09-08) Will Glenn Youngkin win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $580,671 · resolves 2028-11-07
  - (2026-09-08) Will BV Borussia 09 Dortmund win on 2026-09-08?
      yes price: 54% · 24h volume: $379,177 · resolves 2026-09-08

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 9 new of 39 total
  - (2026-09-08) MOVER ▲ Masayoshi Son — $79.31B (+$3.82B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-09-08) MOVER ▲ Rob Walton & family — $131.58B (+$2.45B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-09-08) MOVER ▼ Mukesh Ambani — $89.33B ($-0.95B since yesterday)
      India · Diversified · source: Diversified
  - (2026-09-08) MOVER ▼ Amancio Ortega — $146.06B ($-0.86B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-09-08) MOVER ▲ Gautam Adani — $82.32B (+$0.82B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-09-08) MOVER ▲ Francoise Bettencourt Meyers & family — $96.48B (+$0.47B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### USGS earthquakes (M4.5+, past day) — 8 new of 8 total
  - (2026-09-08) M 5.3 - 51 km NNE of Ruteng, Indonesia
      M5.3 · 51 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-09-08) M 5.1 - South Sandwich Islands region
      M5.1 · South Sandwich Islands region · depth 128.647 km
  - (2026-09-08) M 5.1 - 92 km ESE of Isangel, Vanuatu
      M5.1 · 92 km ESE of Isangel, Vanuatu · depth 10 km
  - (2026-09-08) M 4.7 - 43 km NW of Aroa, Venezuela
      M4.7 · 43 km NW of Aroa, Venezuela · depth 10 km
  - (2026-09-08) M 4.6 - 1 km NNW of Katochí, Greece
      M4.6 · 1 km NNW of Katochí, Greece · depth 10 km
  - (2026-09-08) M 4.6 - 176 km SSE of Vilyuchinsk, Russia
      M4.6 · 176 km SSE of Vilyuchinsk, Russia · depth 24.871 km

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-09-08) [Marginal Revolution] No Doing, No Learning
      A regulation that raises gasoline prices makes people angry but when regulation prevents an industry from ever existing, most people never learn what they lost. Consider nuclear power. Overnight construction costs for ea…
  - (2026-09-08) [Marginal Revolution] Ed Elson and Scott Galloway interview me on AI
      The post Ed Elson and Scott Galloway interview me on AI appeared first on Marginal REVOLUTION.
  - (2026-09-08) [Marginal Revolution] Will new transportation technologies increase urban density?
      Will 21st century transportation innovations work against urban density, as the car did in the 20th century, or promote urban centralization, as the railroad did in the 19th century? Reducing the cost of commuting always…
  - (2026-09-07) [Conversable Economist] The Latent Benefits of Work
      Each year, the White House Council of Economic Advisers publishes the Economic Report of the President. The CEA is led by politically appointed academics, and thus you need to take it as given that the annual report will…
  - (2026-09-07) [Conversable Economist] Marge Piercy on Why Work Matters
      I sometimes struggle, when teaching about unemployment, to explain just why work matters. It’s straightforward enough to note that elevated unemployment leads to loss of economic output, lower tax payments, and greater n…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Court opinions of consequence (federal & state) — 1 new of 60 total
  - (2026-09-04) Hawaii Supreme Court: Souza v. Nago, filed 4:35pm 09/04/2026. Souza v. Nago

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-08) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=11, 7d-median=11, 14d-median=18; carrying terms: associated, applicable, final, unless, commission, changes, safety, national, certain, proposed, service, issuing
- state_bills: today=0, 7d-median=75, 14d-median=79
- state_news: today=325, 7d-median=623, 14d-median=636; carrying terms: recently, second, children, calls, attachment, though, crime, trump, governor, january, service, wednesday
- local_news: today=130, 7d-median=234, 14d-median=236; carrying terms: stlmag, trump, court, against, https, games, shooting, culture, national, district, family, weekend
- foreign_news: today=995, 7d-median=1085, 14d-median=1048; carrying terms: second, cannot, failed, promoted, worry, province, potential, trump, accuses, massive, governor, service
- chinese_internal: today=280, 7d-median=280, 14d-median=286; carrying terms: cbmizkfvx, cbmib, cbmickfvx, cbmidefvx, cbmibkfvx, cbmix, color, google, cbmibefvx, cbmixkfvx, lxtfa, https
- russian_internal: today=1015, 7d-median=1042, 14d-median=1058; carrying terms: street, politico, group, istories, axios, media, europe, novaya, times, error, found, telegram
- ukrainian_internal: today=132, 7d-median=130, 14d-median=128; carrying terms: ahead, trump, general, service, residential, launched, overnight, resilience, against, damage, moscow, invasion
- ukraine_theater: today=416, 7d-median=570, 14d-median=493; carrying terms: interactive, zxnpsen, disabled, cuxpzvvmvhz, xujlrdmv, nevepptkn, vugxoyuzqrfzpcnjsd, dquzjlznvoeln, rktnbzi, jaefjwfjozmzrv, service, odzwyu
- paper_bets: today=131, 7d-median=131, 14d-median=132; carrying terms: election, drought, senate, johnny, artist, seats, colorado, decrease, rippling, leaders, jinping, goldman
- weather: today=120, 7d-median=120, 14d-median=126; carrying terms: afdlox, showers, angeles, southwest, portions, rainfall, along, short, combined, swell, service, wednesday
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, indicator, vixcls, payrolls, cpilfesl, supply, pcepilfe, implied, growth, unrate, openings, dcoilwtico
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, treasury, equities, agriculture, crypto, crude, close, credit, commodities, corporate, natural, proxy
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=103, 7d-median=104, 14d-median=107; carrying terms: schools, detect, syria, myanmar, cbmixkfvx, energy, checksum, office, articles, union, destruction, battelle
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, congresstrading, unauthorized, quiver, error, quantitative, https, quiverquant, client
- billionaires: today=39, 7d-median=30, 14d-median=30; carrying terms: walton, oracle, india, spacex, jensen, exchange, tesla, mukesh, larrea, ellison, family, china
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, supreme, court, appeals, connecticut, energy, insurance, blanche, company, county, group, williams
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, holdings, america, group, filer, trust, technologies, thomas, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ossoff, senate, congress, filing, cortez, talarico, krishnamoorthi, cooper, sherrod, ocasio, house, david
- gdelt_regions: today=12, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, kingdom, ground, bulgaria, germany, spain
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: months, symptoms, second, cluster, resulting, regio, broader, travel, cvdpv, associated, raise, circulation
- cisa_kev: today=20, 7d-median=21, 14d-median=20; carrying terms: improper, critical, authentication, missing, microsoft, remediation, function, command, gitea, request, forgery, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=8, 7d-median=12, 14d-median=12; carrying terms: depth, islands, indonesia, south, region, chile, russia, ruteng, vanuatu, sandwich, isangel
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, champions, decrease, interest, resolves, price, championship, meeting, league, change, donetsk, september
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, class, marginal, https, conversable, economist, current, recent, government, conversableeconomist, number, people
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: hackers, according, critical, artificial, record, target, intelligence, noopener, https, companies, agents, cybersecurity
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: gillibrand, robin, castor, ellzey, morrison, keith, balderson, bresnahan, neguse, mannion, babin, chicago
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, either, paper, converges, identify, unavailable, claude, today, module, evidence, decision, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*