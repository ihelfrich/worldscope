# WORLDSCOPE morning brief — 2026-11-10

## Headline
3348 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (818) · Russian Internal News (state + in-exile) (699) · State-Level News (377) · World leaders & government officials (324) · Chinese Internal News (240) · Local News: St. Louis + Atlanta (223) · U.S. Weather + Severe / Climate Outlooks (143) · State Legislative Action (97) · Ukrainian Internal News (national + local Kyiv) (76) · Ukraine Theater (total-war monitoring) (70) · IT, InfoSys & cybersecurity news (last 7 days) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 818 new of 1013 total
  - (2026-11-10) [Global] US and rest of world must follow China’s lead on green energy, says John Kerry
  - (2026-11-10) [Global] Victorian Labor’s ‘unforgivable’ preferences decision risks Liberal-One Nation government, Greens warn
  - (2026-11-10) [Global] David Jones’s finances were reviewed and restructuring flagged months before it fell into administration
  - (2026-11-10) [Global] Australia to introduce mandatory reporting after OpenAI hack to combat artificial intelligence ‘going rogue’
  - (2026-11-10) [Global] Beau Lamarre-Condon admits entering Jesse Baird’s house when he wasn’t home and eating Easter egg, murder trial hears
  - (2026-11-10) [Global] Mortgage holders’ confidence crashes to lowest level since 1994 as year that ‘feels like a recession’ looms

### Russian Internal News (state + in-exile) — 699 new of 1014 total
  - (2026-11-10) В Польше задержали двух украинцев, подозреваемых в шпионаже и диверсиях в пользу России | LEDE: В Польше арестовали двух граждан Украины в возрасте 24 и 25 лет, которых подозревают в шпионаж] (ru: В П…
      В Польше арестовали двух граждан Украины в возрасте 24 и 25 лет, которых подозревают в шпионаже и диверсиях по заданию российских спецслужб. Об этом сообщил министр-координатор польских спецслужб Томаш Шемоняк.
  - (2026-11-10) Адвокату Марии Бонцлер запросили 15 лет колонии по делу о госизмене | LEDE: Прокуратура потребовала приговорить адвоката из Калининграда Марию Бонцлер к 15 годам лишения свободы. Об этом соо] (ru: Адв…
      Прокуратура потребовала приговорить адвоката из Калининграда Марию Бонцлер к 15 годам лишения свободы. Об этом сообщил проект «Слово защите» со ссылкой на адвоката Илью Сидорова, который навестил Бонцлер в СИЗО.
  - (2026-11-10) Знаете теорию, что все мультфильмы Pixar связаны? То же самое придумал режиссер Дмитрий Черняков для опер Сергея Рахманинова. Его новый спектакль в Цюрихе — это неожиданная биография пушкинског] (ru:…
      В Цюрихском оперном театре вышел спектакль Дмитрия Чернякова «Рахманинов. Три оперы». «Алеко», «Скупой рыцарь» и «Франческа да Римини» не задумывались композитором как трилогия, Черняков и дирижер Джанандреа Нозеда объед…
  - (2026-11-10) На последних выборах в США проиграл не только Трамп и республиканцы. От победы демократов может сильно пострадать кое-кто еще. Кое-кто искусственный…. Рассказываем, как демократы хотят затормоз] (ru:…
      После победы Демократической партии на промежуточных выборах в США политика американских властей в отношении искусственного интеллекта может измениться. С момента возвращения Дональда Трампа в Белый дом в 2024-м сотрудни…
  - (2026-11-10) Skims — бренд белья от Ким Кардашьян — выпустил адвент-календарь за 148 долларов. Его уже назвали «худшим адвент-календарем всех времен». Внутри оказались резинки для волос и брелоки; компания ] (ru:…
      Skims — популярный бренд нижнего белья, одежды и аксессуаров от Ким Кардашьян — снял с продажи свой рождественский адвент-календарь и предложил вернуть за него деньги. Причиной стали массовые жалобы на содержимое календа…
  - (2026-11-10) На переговоры в Абу-Даби приехал офицер ФСБ Дмитрий Минаев. Украина обвиняла его в попытке покушения на Кирилла Буданова (он тоже участвует в переговорах) | LEDE: Российская делегация на тре] (ru: На…
      Российская делегация на трехсторонних переговорах в Абу-Даби представлена пятью членами делегации и шестью экспертами. Четверо из них, как обратило внимание «Агентство», участвуют в таких переговорах впервые.

### State-Level News — 377 new of 560 total
  - (2026-11-09) [Alabama] Governor Ivey Announces Award of Contract to Replace Gilbert’s Ferry SR-77 Bridge in Etowah County
      MONTGOMERY – Governor Kay Ivey on Monday announced the Alabama Department of Transportation (ALDOT) has awarded a contract to replace the Gilbert’s Ferry Bridge on SR-77 over the Coosa River in Etowah County. “For almost…
  - (2026-11-09) [Alabama] From Last to Leading: Governor Ivey Celebrates a Decade That Connected Alabama
      MONTGOMERY – Governor Kay Ivey on Monday at the State Capitol joined legislative leaders, Alabama Department of Economic and Community Affairs (ADECA) Director Kenneth Boswell and the internet service providers and utili…
  - (2026-11-09) [California] NEARLY 12,000 PEOPLE REACHED: Governor Newsom thanks county-level teams and state partners at CARE Act convening
      Source
  - (2026-11-10) [California] CA pension funds were hedging Nvidia even before the affair
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/091526_Dreamforce-2026_AHK_CM_05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-11-10) [California] Race for LA’s new county executive post officially begins. It could be a historic battle
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/08/100323-Lindsey-Horvath-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-11-10) [California] California Muslims gained a moment of hope and belonging after midterm election
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/090923-DayOfDignity-KC-CM-05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 240 new of 321 total
  - (2026-11-09) Who Is Alice Huang, the Former Megaspeed Executive Linked to Nvidia’s CEO? - Caixin Global
      Who Is Alice Huang, the Former Megaspeed Executive Linked to Nvidia’s CEO? Caixin Global
  - (2026-11-10) China Opens Onshore Forex Market to Overseas Yuan Clearing Banks - Caixin Global
      China Opens Onshore Forex Market to Overseas Yuan Clearing Banks Caixin Global
  - (2026-11-09) China’s Factory-Gate Inflation Hits Highest in More Than Four Years - Caixin Global
      China’s Factory-Gate Inflation Hits Highest in More Than Four Years Caixin Global
  - (2026-11-09) China Policy Tool Seen Lifting October Social Financing - Caixin Global
      China Policy Tool Seen Lifting October Social Financing Caixin Global
  - (2026-11-09) Taiyuan Investigates Deadly Fire at Mixed-Use High-Rise - Caixin Global
      Taiyuan Investigates Deadly Fire at Mixed-Use High-Rise Caixin Global
  - (2026-11-10) Ex-Security Chief of Jiangxi Province Indicted over 19-Year Bribery Scheme - Caixin Global
      Ex-Security Chief of Jiangxi Province Indicted over 19-Year Bribery Scheme Caixin Global

### Local News: St. Louis + Atlanta — 223 new of 252 total
  - (2026-11-10) [St. Louis] Budweiser celebrates 150 years with holiday cans, collectibles and Clydesdales
      Budweiser is wrapping up its 150th anniversary year with a holiday collection that brings together some familiar favorites: the Clydesdales, commemorative steins, and a healthy dose of St. Louis nostalgia. Launching toda…
  - (2026-11-10) [St. Louis] Judge dismisses the Woke Ginger’s suit against Food Outreach
      The Woke Ginger has hit a major roadblock in his bid to sue a former employer. Justin Kralemann, a St. Louisan who opines on politics on Instagram and TikTok, set off a firestorm when he sued his former employer, St. Lou…
  - (2026-11-10) [St. Louis] Clayco’s Bob Clark doesn’t see doom and gloom for data centers in Democratic victory
      Bob Clark is feeling optimistic. The Clayco founder, St. Louis County resident, and current face of American data center construction—he was on the cover of Forbes last month, making his pitch—is a lifelong Democrat, and…
  - (2026-11-10) [St. Louis] In ‘Settling,’ SLU prof tells the stories of the ‘women who sued the news’
      It was not so terribly long ago that women who wanted to write for Newsweek were told that they had to be researchers, not writers—gathering material that their male colleagues could then publish under their bylines. Or…
  - (2026-11-10) [St. Louis] Cat burglar who broke into South City homes has a long history
      Portly and disheveled, Robert Lee Brown doesn’t look like the sort of guy who would be light on his feet, but apparently he is. Last month, he broke into five homes in South City in the middle of night as the homeowners…
  - (2026-11-10) [St. Louis] Where Art Thou – 11/10/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…

### U.S. Weather + Severe / Climate Outlooks — 143 new of 146 total
  - (2026-11-10) [Moderate] Wind Advisory: Wind Advisory issued November 10 at 5:56AM AKST until November 10 at 12:00PM AKST by NWS Anchorage AK
      * WHAT...East to southeast winds 20 to 30 mph with gusts up to 65 mph expected. * WHERE...Anchorage and Eagle River Hillsides. * WHEN...Until noon AKST today. * IMPACTS...Travel could be difficult, especially high profil…
  - (2026-11-10) [Moderate] Wind Advisory: Wind Advisory issued November 10 at 5:56AM AKST until November 10 at 12:00PM AKST by NWS Anchorage AK
      * WHAT...East to winds 25 to 40 mph with gusts between 55 and 70 mph expected. * WHERE...Whittier, Portage Valley, and East Turnagain Arm. * WHEN...Until noon AKST today. * IMPACTS...Travel could be difficult, especially…
  - (2026-11-10) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-10) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 10 at 7:53AM MST until November 10 at 8:00AM MST by NWS Albuquerque NM
      Fog has diminished and is not expected to return. Therefore, the Fog Advisory will be allowed to expire.
  - (2026-11-10) [Moderate] Gale Warning: Gale Warning issued November 10 at 5:48AM AKST until November 10 at 6:00AM AKST by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, east winds 25 to 35 kt with gusts up to 40 kt and seas 21 to 26 ft expected. For the Gale Warning, southeast winds 25 to 35 kt with gusts up to 50 kt and seas 13 to 18 ft expe…
  - (2026-11-10) [Moderate] Gale Warning: Gale Warning issued November 10 at 5:48AM AKST until November 10 at 6:00PM AKST by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, east winds 20 to 30 kt with gusts up to 40 kt and seas 15 to 20 ft. For the Gale Warning, southeast winds 30 to 40 kt with gusts up to 50 kt and seas 13 to 18 ft expected. For…

### State Legislative Action — 97 new of 97 total
  - (2026-11-10) [Alaska SB 206] An Act relating to reports of harassment, intimidation, or bullying in schools; relating to parental notification of incidents of harassment, intimidation, or bullying involving studen…
      An Act relating to reports of harassment, intimidation, or bullying in schools; relating to parental notification of incidents of harassment, intimidation, or bullying involving students and threats of suicide by student…
  - (2026-11-10) [Alaska HB 70] An Act relating to emergency medical services for operational canines; relating to the powers, duties, and liability of emergency medical technicians and mobile intensive care paramedic…
      An Act relating to emergency medical services for operational canines; relating to the powers, duties, and liability of emergency medical technicians and mobile intensive care paramedics; relating to the practice of vete…
  - (2026-11-10) [Alaska HB 182] An Act relating to live music and entertainment at breweries, wineries, and distilleries.
      An Act relating to live music and entertainment at breweries, wineries, and distilleries.
  - (2026-11-10) [Alaska HB 158] An Act relating to professional licensing; relating to temporary licenses for certain professions; and providing for an effective date.
      An Act relating to professional licensing; relating to temporary licenses for certain professions; and providing for an effective date.
  - (2026-11-10) [Alaska HJR 21] Encouraging the United States Congress to designate 2025 as the Year of the Soldier.
      Encouraging the United States Congress to designate 2025 as the Year of the Soldier.
  - (2026-11-10) [Alaska HB 149] An Act relating to pharmacy benefits managers; relating to third-party administrators; and providing for an effective date.
      An Act relating to pharmacy benefits managers; relating to third-party administrators; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 76 new of 139 total
  - (2026-11-10) Генерал СБУ Дука написав лист із СІЗО: Контакти зі злочинцями не роблять співучасником | LEDE: Сергій Дука закликає оцінювати його дії за доказами та просить парламент заслухати справу між прав] (uk:…
      Сергій Дука закликає оцінювати його дії за доказами та просить парламент заслухати справу між правоохоронними органами.
  - (2026-11-10) Понад 70% американців хочуть, щоб новий Конгрес припинив війну з Іраном – опитування | LEDE: Більшість американців виступає за те, щоб новообраний Конгресу припинив війну з Іраном і скасував ім] (uk:…
      Більшість американців виступає за те, щоб новообраний Конгресу припинив війну з Іраном і скасував імпортні мита, запроваджені президентом Дональдом Трампом.
  - (2026-11-10) За генерала СБУ Дуку внесли 44 млн грн застави від 1113 платників | LEDE: 10 листопада за генерал-майора СБУ Сергія Дуку, підозрюваного у справі "Карфаген", внесли 44 мільйони гривень з визначе] (uk:…
      10 листопада за генерал-майора СБУ Сергія Дуку, підозрюваного у справі "Карфаген", внесли 44 мільйони гривень з визначених судом 65 мільйонів.
  - (2026-11-10) Рік на підготовку: що зміни до Метанового регламенту ЄС означають для України і як їх використати | LEDE: ] (uk: Рік на підготовку: що зміни до Метанового регламенту ЄС означають для України і )
  - (2026-11-10) Перезапуск відносин: Сибіга зустрінеться з главою МЗС Південної Кореї в Парижі | LEDE: Міністр закордонних справ України Андрій Сибіга проведе особисту зустріч із міністром закордонних справ Ре] (uk:…
      Міністр закордонних справ України Андрій Сибіга проведе особисту зустріч із міністром закордонних справ Республіки Корея Чо Хьоном у Парижі, щоб нормалізувати відносини та відновити двосторонній діалог.
  - (2026-11-10) Рух ЧЕСНО: Безкоштовний проїзд у Києві – президентський популізм усупереч Конституції | LEDE: ] (uk: Рух ЧЕСНО: Безкоштовний проїзд у Києві – президентський популізм усупереч Консти)

### Ukraine Theater (total-war monitoring) — 70 new of 273 total
  - (2026-11-10) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-08) [Liveuamap] Explosions were reported in Kremenchuk, Poltava region – Kremenchuk, Poltavs&039;ka oblast - Liveuamap
      Explosions were reported in Kremenchuk, Poltava region – Kremenchuk, Poltavs&039;ka oblast <font color="#6f6f6f"
  - (2014-11-14) [Liveuamap] Ukraine war live map: front line and news today | Liveuamap - Liveuamap
      Ukraine war live map: front line and news today | Liveuamap Liveuamap
  - (2026-11-09) [Liveuamap] The IAEA has been informed that an employee of the Zaporizhzhia Nuclear Power Plant (ZNPP) was killed in a drone attack today. Separately, an employee of the nearby Zaporizhzhia Thermal Po…
      The IAEA has been informed that an employee of the Zaporizhzhia Nuclear Power Plant (ZNPP) was killed in a drone attack today. Se
  - (2026-11-10) [Liveuamap] Sahel live map: Mali, Burkina, Niger today | Liveuamap - Liveuamap
      Sahel live map: Mali, Burkina, Niger today | Liveuamap Liveuamap
  - (2016-04-27) [Liveuamap] Belarus news live map today | Liveuamap - Liveuamap
      Belarus news live map today | Liveuamap Liveuamap

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 60 total
  - (2026-11-10) [BleepingComputer] SAP patches ICM2SHELL and PROXYGATE maximum severity flaws
      SAP patched 35 vulnerabilities in its November 2026 security updates, including four maximum-severity issues affecting its NetWeaver, Web Dispatcher, and Gateway software. [...]
  - (2026-11-10) [BleepingComputer] Hackers now exploit critical Barracuda ESG flaws to gain root access
      Cybersecurity company Barracuda Networks warned that attackers have begun exploiting two recently patched Email Security Gateway (ESG) vulnerabilities that let them run commands with root privileges. [...]
  - (2026-11-10) [BleepingComputer] Turla hackers use new Cereal malware to spy on govt Exchange servers
      The Russian state-backed threat group Turla has been using a new malicious toolset called 'Cereal' to intercept emails on Microsoft Exchange servers at government organizations. [...]
  - (2026-11-10) [BleepingComputer] Google patches eighth Chrome zero-day exploited in attacks this year
      Google has released emergency security updates to patch a new Chrome vulnerability exploited in zero-day attacks, the eighth such flaw since the start of the year. [...]
  - (2026-11-10) [BleepingComputer] Fireworks AI discloses new breach after cloud provider hack
      AI infrastructure startup Fireworks has disclosed a new security breach in which attackers accessed its development machines after breaching a third-party cloud provider. [...]
  - (2026-11-10) [The Hacker News] Binance Warns of iOS Sandbox Escape That Could Expose Crypto Wallet Keys, No Fix Confirmed
      An iOS sandbox escape published on GitHub lets an app read other apps' files on iPhones running iOS 26 and 27. That puts seed phrases, private keys, and login credentials at risk of exposure to malicious apps, Binance wa…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-10) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-11-10 14:55 UTC — Filed: 2026-11-10 AccNo: 0001918704-26-035138 Size: 1 MB
  - (2026-11-10) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-11-10 14:55 UTC — Filed: 2026-11-10 AccNo: 0001918704-26-035138 Size: 1 MB
  - (2026-11-10) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-11-10 14:54 UTC — Filed: 2026-11-10 AccNo: 0001918704-26-035137 Size: 678 KB
  - (2026-11-10) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-11-10 14:54 UTC — Filed: 2026-11-10 AccNo: 0001918704-26-035137 Size: 678 KB
  - (2026-11-10) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-11-10 14:53 UTC — Filed: 2026-11-10 AccNo: 0001918704-26-035136 Size: 953 KB
  - (2026-11-10) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-11-10 14:53 UTC — Filed: 2026-11-10 AccNo: 0001918704-26-035136 Size: 953 KB

### GDACS — global disaster alerts — 39 new of 100 total
  - (2026-11-10) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5M, Depth:35km
  - (2026-11-10) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 4.58M, Depth:20.8199996948242km
  - (2026-11-10) [Green] Earthquake in Northern Mid-Atlantic Ridge
      Earthquake · Green alert · Northern Mid-Atlantic Ridge · Magnitude 4.8M, Depth:10km
  - (2026-11-10) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 4.7M, Depth:10km
  - (2026-11-10) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 4.9M, Depth:35km
  - (2026-11-10) [Green] Earthquake in Solomon Islands
      Earthquake · Green alert · Solomon Islands · Magnitude 4.6M, Depth:10km

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 27 new of 30 total
  - (2026-11-10) PAT594 (United States)
      icao24: adfede · position: (30.5188, -82.8727) · alt: 5478m · 439km/h
  - (2026-11-10) PAT972 (United States)
      icao24: adfe4a · position: (34.9381, -100.4438) · alt: 7315m · 545km/h
  - (2026-11-10) JEDI21 (United States)
      icao24: ae1eab · position: (30.2919, -87.7554) · alt: 1036m · 509km/h
  - (2026-11-10) JEDI21 (United States)
      icao24: ae1eaa · position: (30.2976, -87.5771) · alt: 1028m · 497km/h
  - (2026-11-10) JEDI66 (United States)
      icao24: ae1ead · position: (30.5904, -87.2489) · alt: 1569m · 414km/h
  - (2026-11-10) SAMU45 (France)
      icao24: 39ca86 · position: (47.8354, 1.9199) · on ground

### U.S. Federal Action — 19 new of 19 total
  - (2026-11-10) Imposition of Special Measure Prohibiting the Transmittal of Funds Involving MEXC Global
      FinCEN is issuing notice of an order, pursuant to section 9714(a) of the Combating Russian Money Laundering Act (Pub. L. 116- 283), as amended by section 6106(b) of the National Defense Authorization Act for Fiscal Year…
  - (2026-11-10) Inspection Programs for Single-Engine Turbine-Powered Airplanes and Unmanned Aircraft; and Miscellaneous Maintenance-Related Updates
      The final rule updates the maintenance inspection requirements for single-engine turbine-powered airplanes and unmanned aircraft. Aircraft owners and operators now have more inspection program options to choose from and…
  - (2026-11-10) Special Conditions: Gulfstream Aerospace Corporation, Model GVII-G400 Airplane; Flight Envelope Protection: Takeoff Stall Protection
      These special conditions are issued for the Gulfstream Aerospace Corporation (Gulfstream) Model GVII-G400 airplane. This airplane will have a novel or unusual design feature when compared to the state of technology envis…
  - (2026-11-10) Modification to Work Requirements for Able-Bodied Adults
      The proposed rule would codify USDA's regulatory implementation of provisions of the One Big Beautiful Bill Act of 2025 (OBBB) changing the three-month time limit for certain participants subject to work requirements in…
  - (2026-11-10) Supplemental Nutrition Assistance Program: Reforming Categorical Eligibility
      Under section 5(a) of the Food and Nutrition Act of 2008, households in which each member receives benefits under a State program funded by Temporary Assistance for Needy Families (TANF) are categorically eligible for th…
  - (2026-11-10) Airworthiness Directives; Leonardo S.p.a. Helicopters
      The FAA proposes to supersede Airworthiness Directive (AD) 2024-05-07, which applies to all Leonardo S.p.a. Model AW189 helicopters. AD 2024-05-07 requires revising the airworthiness limitations section (ALS) of the exis…

### Paper Trading Scorecard — 16 new of 71 total
  - (2026-11-10) [Polymarket] Next Israeli government formed by November 30, 2026?
      This market will resolve to "Yes" if a new Government of Israel is officially sworn in by the specified date, 11:59 PM ET. Otherwise, this market will resolve to “No.” To qualify, a newly formed government, headed by a P…
  - (2026-11-10) [Manifold] Will Pangram be able to keep up with general image generation methods?
  - (2026-11-10) [Manifold] Will investors find a second mistress involving Jensen Huang before dec 31, 2026
  - (2026-11-10) [Manifold] Free lottery (Hartle 1983)
  - (2026-11-10) [Manifold] Fable 5.5 released before the end of November?
  - (2026-11-10) [Manifold] Will the WTI Crude Oil Spot Price be above $89 on November 16, 2026?

### Campaign finance (FEC: top fundraisers + recent filings) — 13 new of 27 total
  - (2026-11-09) [F1] WE STAND WITH DAN SUPER PAC
      cycle 2026 · filing #2046856
  - (2026-11-09) [F3] MICHAEL FARRELL FOR UTAH
      cycle 2026 · filing #2046802 · receipts $0.00M
  - (2026-11-09) [F2] SMITH, D. ADAM
      cycle 2026 · filing #2046858
  - (2026-11-09) [F3X] WE STAND WITH DAN SUPER PAC
      cycle 2026 · filing #2046861 · receipts $0.05M
  - (2026-11-09) [F1] BUILDING RELATIONSHIPS IN DIVERSE GEOGRAPHIC ENVIRONMENTS PAC (BRIDGE
      cycle 2026 · filing #2046870
  - (2026-11-09) [F1] MOOR FOR SENATE
      cycle 2026 · filing #2046829

### USGS earthquakes (M4.5+, past day) — 13 new of 14 total
  - (2026-11-10) M 5.4 - Pulau Pulau Tanimbar, Indonesia
      M5.4 · Pulau Pulau Tanimbar, Indonesia · depth 10 km
  - (2026-11-10) M 5.2 - 19 km WSW of Lata, Solomon Islands
      M5.2 · 19 km WSW of Lata, Solomon Islands · depth 10 km
  - (2026-11-10) M 5.0 - 58 km NE of Fef, Indonesia
      M5.0 · 58 km NE of Fef, Indonesia · depth 35 km
  - (2026-11-10) M 4.9 - 78 km ESE of Hitachi, Japan
      M4.9 · 78 km ESE of Hitachi, Japan · depth 35 km
  - (2026-11-10) M 4.9 - north of Franz Josef Land
      M4.9 · north of Franz Josef Land · depth 10 km
  - (2026-11-09) M 4.9 - south of the Fiji Islands
      M4.9 · south of the Fiji Islands · depth 175.527 km

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-11-10) Will the Fed increase interest rates by 25 bps after the December 2026 meeting?
      yes price: 84% · 24h volume: $1,435,196 · resolves 2026-12-09
  - (2026-11-10) Will the Fed increase interest rates by 50+ bps after the December 2026 meeting?
      yes price: 13% · 24h volume: $1,160,202 · resolves 2026-12-09
  - (2026-11-10) Will Shawn Fain win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $805,047 · resolves 2028-11-07
  - (2026-11-10) BNP Paribas Nordic Open: Lorenzo Sonego vs Quentin Halys
      yes price: 100% · 24h volume: $653,664 · resolves 2026-11-17
  - (2026-11-10) Will the Fed decrease interest rates by 25 bps after the December 2026 meeting?
      yes price: 0% · 24h volume: $555,906 · resolves 2026-12-09
  - (2026-11-10) Will David Lisnard win the 2027 French presidential election?
      yes price: 12% · 24h volume: $432,937 · resolves 2027-04-19

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 99 total
  - (2026-11-09) [OFAC] Iran Designation Update - Office of Foreign Assets Control (.gov)
      Iran Designation Update Office of Foreign Assets Control (.gov)
  - (2026-11-10) [USASpending] $342,820,034 → GENERAL DYNAMICS INFORMATION TECHNOLOGY, INC.: OPERATE AND MAINTAIN THE OBIM INFRASTRUCTURE COMPONENTS AND
      Agency: Department of Homeland Security. Description: OPERATE AND MAINTAIN THE OBIM INFRASTRUCTURE COMPONENTS AND ASSOCIATED APPLICATIONS AND OTHER FUNCTIONALITY OF THE PRODUCTION AND NON-PRODUCTION ENVIRONMENTS AND ASSO…
  - (2026-11-10) [USASpending] $310,786,905 → MIRACLE SYSTEMS LLC: CISA PROGRAM MANAGEMENT SUPPORT SERVICES PMSS AWARD
      Agency: General Services Administration. Description: CISA PROGRAM MANAGEMENT SUPPORT SERVICES PMSS AWARD
  - (2026-11-10) [USASpending] $260,040,542 → ASRC FEDERAL FACILITIES LOGISTICS LLC: THE PURPOSE OF THIS CONTRACT IS TO ACQUIRE REPAIRS, OPERATIO
      Agency: National Aeronautics and Space Administration. Description: THE PURPOSE OF THIS CONTRACT IS TO ACQUIRE REPAIRS, OPERATIONS & MAINTENANCE, AND ENGINEERING (ROME) AND RELATED SERVICES FOR THE GODDARD SPACE FLIGHT C…
  - (2026-11-10) [USASpending] $243,482,962 → AMENTUM SERVICES, INC.: INDOPACIFIC COMMAND TECHNOLOGY EXPERIMENTATION ANALYSIS AND
      Agency: General Services Administration. Description: INDOPACIFIC COMMAND TECHNOLOGY EXPERIMENTATION ANALYSIS AND MANAGEMENT SERVICES (ITEAMS) BASE AWARD.
  - (2026-11-10) [USASpending] $242,599,760 → ITILITY, L.L.C: THE PURPOSE OF THIS IS TO AWARD THE TASK ORDER TO ITILITY, L
      Agency: General Services Administration. Description: THE PURPOSE OF THIS IS TO AWARD THE TASK ORDER TO ITILITY, LLC.

### World News (by country, top stories) — 6 new of 6 total
  - (2026-11-10) [Japan] Takaichi Seeks Intl AI Cooperation at France - Hosted Meeting
      nippon.com · English
  - (2026-11-10) [Japan] Japan to Call for Limiting Kid Exposure to Social Media
      nippon.com · English
  - (2026-11-10) [Japan] COP31 Starts in Turkey amid Growing Climate Impacts
      nippon.com · English
  - (2026-11-10) [Japan] Super Mario Party Jamboree 2 . 4 . 0 update out now , patch notes - GameShare using GameChat and more
      nintendoeverything.com · English
  - (2026-11-10) [Japan] Nagoya Station for Maglev Line to Be Completed in 2033 or Later
      nippon.com · English
  - (2026-11-10) [Japan] Just Dance : Decades of Hits - Game
      nintendoworldreport.com · English

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 15 total
  - (2026-11-09) CVE-2026-102895 · GPUStack GPUStack: GPUStack Improper Authentication Vulnerability
      vendor: GPUStack · product: GPUStack · CISA remediation by 2026-11-12
  - (2026-11-09) CVE-2026-123158 · OpenBSD OpenSSH: OpenBSD OpenSSH Unexpected Status Code or Return Value Vulnerability
      vendor: OpenBSD · product: OpenSSH · CISA remediation by 2026-11-12
  - (2026-11-09) CVE-2026-116779 · SignalWire FreeSwitch: SignalWire FreeSwitch Code Injection Vulnerability
      vendor: SignalWire · product: FreeSwitch · CISA remediation by 2026-11-12
  - (2026-11-09) CVE-2026-123218 · IBM Aspera Faspex: IBM Aspera Faspex Incorrect Authorization Vulnerability
      vendor: IBM · product: Aspera Faspex · CISA remediation by 2026-11-12

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-10) [Marginal Revolution] Checking the AI audit of Saez and Zucman’s research.
      From SaneCite: We checked the anonymous AI audit of Emmanuel Saez and Gabriel Zucman’s research that Marginal Revolution featured on 28 Oct: all 147 problems it calls serious enough to change a headline number, against t…
  - (2026-11-10) [Marginal Revolution] *Godzilla: Minus Zero* (no spoilers)
      This is a morally serious movie (really). And Ghidorah stars! The whole thing is about twenty minutes too long, but mostly very good. And like many in the Godzilla series, it offers extended and instructive commentary on…
  - (2026-11-10) [Marginal Revolution] *Unbeatable: The Brutally Honest Case for Free Markets*
      That is the new and forthcoming book from Bryan Caplan, University of Chicago Press. Excerpt: Real-world free markets deliver one broad benefit that flies under the radar of economic theory: They shield humanity from its…
  - (2026-11-09) [Conversable Economist] How Currencies Have Come and Gone: 1850-2026
      Around the world, 568 currencies have been issued since 1850, but 405 of them have been discontinued. Iñaki Aldasoro, Jon Frost, Rudraksh Kansal and Catherine Schenk tell the story in “Gaining (and losing) currency: a gl…

### GDELT GKG — themes / entities / watch areas — 1 new of 1 total
  - (2026-11-10) [Russia oil sanctions perimeter · keywords] Russian oil dominance faces sudden collapse : rising shipping expenses pushed Indian buyers away
      english.pravda.ru · English · tone NA

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-10) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=25, 14d-median=18; carrying terms: regulatory, service, certain, action, safety, commission, final, agency, proposes, document, proposed, necessary
- state_bills: today=97, 7d-median=90, 14d-median=97; carrying terms: emergency, providing, production, vehicle, relating, establishing, enforcement, access, insurance, authority, review, health
- state_news: today=560, 7d-median=675, 14d-median=675; carrying terms: house, meeting, ballots, politics, toomanyredirects, leads, management, women, votes, dollars, gubernatorial, investigate
- local_news: today=252, 7d-median=252, 14d-median=256; carrying terms: house, years, being, stlmag, crash, night, midterm, shooting, times, early, person, articles
- foreign_news: today=1013, 7d-median=1013, 14d-median=1006; carrying terms: israeli, petrol, arabia, brief, ministers, disease, handling, rates, risks, using, means, claim
- chinese_internal: today=321, 7d-median=334, 14d-median=304; carrying terms: global, growth, cbmic, caixin, cbmiykfvx, articles, google, cbmidefvx, lxtfa, market, title, https
- russian_internal: today=1014, 7d-median=946, 14d-median=951; carrying terms: found, times, httperror, reuters, media, journal, europe, laquo, telegram, street, https, russian
- ukrainian_internal: today=139, 7d-median=139, 14d-median=134; carrying terms: meeting, ministers, poland, takeaways, alongside, ukrinform, international, years, strike, kremlin, launched, ministry
- ukraine_theater: today=273, 7d-median=269, 14d-median=328; carrying terms: tfmnvgvty, wbudhn, mapserver, liveuamap, kcjjlbvjpttfvdffqde, retlwqwvstlc, bkcldpswlpsdkytda, cuxqm, seupimxdjtjdfbl, oblast, byuryufr, ytewlu
- paper_bets: today=71, 7d-median=67, 14d-median=67; carrying terms: celsius, kalshi, receiving, become, industrial, problems, evans, openai, world, minister, humans, human
- weather: today=146, 7d-median=130, 14d-median=132; carrying terms: moderate, twoat, areas, southwest, friday, offshore, afdhgx, impacts, direction, magnitude, updated, damage
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexchus, commodities, total, supply, vixcls, assets, nonfarm, balance, spread, indicator, payrolls, personal
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, large, agriculture, range, commodities, equities, crude, bitcoin, natural, silver, nasdaq, rates
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=99, 14d-median=99; carrying terms: operations, democratic, compare, management, blank, target, congo, issuance, including, amended, ujgxrwtvbs, energy
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, https, httperror, client, unauthorized, congresstrading, quiver, error, quantitative
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed, financial, filer, holdings, trust, chase, jpmorgan, scotia, global
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, house, ossoff, disbursements, brown, james, senate, krishnamoorthi, ocasio, sayed, cortez
- gdelt_regions: today=6, 7d-median=0, 14d-median=0
- gdelt_gkg: today=1, 7d-median=25, 14d-median=25; carrying terms: english, sanctions, russia, perimeter, russian, keywords
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: france, kingdom, position, belgium, germany, canada, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: symptoms, increases, tested, aboard, periods, individual, activity, bordering, history, areas, months, occupational
- cisa_kev: today=15, 7d-median=13, 14d-median=17; carrying terms: remediation, authentication, product, vulnerability, secure, vendor, edition, software, dangerous, unchecked, cisco, value
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: tropical, nigeria, fires, depth, cyclone, green, forestfire, forest, sudan, botswana, alert, maximum
- usgs_quakes: today=14, 7d-median=11, 14d-median=15; carrying terms: depth, islands, japan, indonesia, vanuatu, south, ridge, indian, atlantic, alaska
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, volume, presidential, election, democratic, donetsk, shakhtar, champions, october, championship, league
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, revolution, class, conversable, https, marginal, world, marginalrevolution, published, promised, economic, since
- tech_news: today=60, 7d-median=61, 14d-median=60; carrying terms: going, friday, world, access, weekly, vulnerability, service, newsletter, group, devices, brought, computer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: house, amodei, kavanaugh, warnock, victoria, securities, mcdowell, harshbarger, stacey, steny, mccormick, barrett
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, consensus, claude, placement, module, placed, either, unavailable, converges, decision, evidence, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*