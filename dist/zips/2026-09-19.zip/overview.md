# WORLDSCOPE morning brief — 2026-09-19

## Headline
3136 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (742) · Russian Internal News (state + in-exile) (626) · World leaders & government officials (324) · State-Level News (305) · Ukraine Theater (total-war monitoring) (235) · Chinese Internal News (205) · Local News: St. Louis + Atlanta (197) · U.S. Weather + Severe / Climate Outlooks (112) · State Legislative Action (79) · Ukrainian Internal News (national + local Kyiv) (70) · SEC Form 4 insider transactions (recent) (40) · Government Action: Sanctions + Procurement + Foreign Agents (37)

## What changed today
### International News + Multilateral Institutions — 742 new of 1045 total
  - (2026-09-19) [Global] US and Denmark reach deal over Greenland after Trump annexation threats
      Trump says the agreement will give the US "permanent control over security, and all other needs, in Greenland", though specifics have not been confirmed by Danish officials.
  - (2026-09-19) [Global] Trump says he is banning CNN and Politico from White House
      The US president has had a tense and fiery relationship with the US media throughout his political career.
  - (2026-09-19) [Global] Google's Gemini AI hacked three companies in security test
      The AI model accessed the internet and guessed credentials to three websites, a Google official told the BBC.
  - (2026-09-18) [Global] Trump signs sweeping Russia sanctions bill
      The bill is named after the late Senator Lindsey Graham, a staunch advocate of aid for Ukraine.
  - (2026-09-18) [Global] Grim discoveries of murdered women spark fear in South Africa
      Dineo Motapane is one of nine recent victims whose deaths have left a nation traumatised over the level of violence against women.
  - (2026-09-19) [Global] Deadly shark attack prompts rare kill order in Western Australia
      Police boats and helicopters are patrolling Perth's beaches as authorities continue their search for the swimmer's body, and the shark that attacked him.

### Russian Internal News (state + in-exile) — 626 new of 1067 total
  - (2026-09-19) Война. 1669-й день. Трамп подписал закон об «адских» санкциях против России. Но как они будут применяться (и будут ли), пока никто не знает | LEDE: «Медуза» с 24 февраля 2022 года в прямом э] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-19) Странно, что с этими новостями мы все давно не поседели. Хотя подождите, а от стресса такое правда может произойти? И бывает ли так, что седина — это не просто возрастное, а симптом? | LEDE: <p] (ru:…
      Нет, ничего. Просто мы подумали, что ни разу не рассказывали вам о седине. А там есть что рассказать!
  - (2026-09-19) Единственный аэропорт Люксембурга прерывал работу из-за «несанкционированных беспилотников» | LEDE: Международный аэропорт Люксембурга (единственный в стране) вечером в пятницу, 18 сентября,] (ru: Еди…
      Международный аэропорт Люксембурга (единственный в стране) вечером в пятницу, 18 сентября, приостановил работу на несколько часов из-за обнаружения «несанкционированных беспилотных аппаратов». Об этом сообщается на сайте…
  - (2026-09-19) Илья Яшин отменил поездку в Ереван, где собирался прийти на избирательный участок. Он рассказал, что его предупредили о «физической угрозе» в Армении | LEDE: Политик Илья Яшин сообщил, что о] (ru: Иль…
      Политик Илья Яшин сообщил, что отказался от поездки в Ереван из-за того, что его предупредили о «рисках», связанных с посещением Армении.
  - (2026-09-19) В России продолжаются выборы. Наблюдателей не пускают на участки, медведи мешают избирателям, явка уже 30%. Материал обновляется | LEDE: . ] (ru: В России продолжаются выборы. Наблюдателей не пускают…
      .
  - (2026-09-19) Госдеп США одобрил продажу Украине средств ПВО на 2,7 миллиарда долларов | LEDE: Госдепартамент США одобрил возможную продажу Украине средств противовоздушной обороны на 2,68 миллиарда долла] (ru: Гос…
      Госдепартамент США одобрил возможную продажу Украине средств противовоздушной обороны на 2,68 миллиарда долларов, говорится в сообщении ведомства. Соглашение предусматривает закупку средств модернизации ПВО и сопутствующ…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 305 new of 683 total
  - (2026-09-18) [Alaska] Flags to be Flown at Half-Staff in Honor of Former Representative Cheri Davis
      Governor Dunleavy has ordered that Alaska and United States flags fly at half-staff between sunrise and sunset on Tuesday, September 22, 2026, in honor of former legislator Cheri Davis.
  - (2026-09-18) [Alaska] Prisoners of War and Missing in Action Recognition Day 2026
      WHEREAS, throughout American history, generations of military servicemen and women have embodied patriotism by sacrificing their own personal safety and wellbeing to protect our country, our people, our freedom, and the…
  - (2026-09-19) [California] Governor Newsom issues legislative update 9.18.26
      Source
  - (2026-09-19) [California] Governor Newsom announces appointments 9.18.2026
      Source
  - (2026-09-18) [California] Governor Newsom announces Judicial Appointments 9.18.2026
      Source
  - (2026-09-18) [California] Governor Newsom proclaims California POW/MIA Recognition Day
      Source

### Ukraine Theater (total-war monitoring) — 235 new of 417 total
  - (2026-09-19) [DeepStateMap] frontline snapshot, 527 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-18) [FIRMS] thermal anomaly 46.530, 34.065 (FRP 14.6 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-18 0924Z, FRP 14.6 MW
  - (2026-09-18) [FIRMS] thermal anomaly 46.531, 34.064 (FRP 14.14 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-18 0924Z, FRP 14.14 MW
  - (2026-09-18) [FIRMS] thermal anomaly 46.901, 34.918 (FRP 4.76 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-18 0924Z, FRP 4.76 MW
  - (2026-09-18) [FIRMS] thermal anomaly 46.678, 34.079 (FRP 17.81 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-18 0924Z, FRP 17.81 MW
  - (2026-09-18) [FIRMS] thermal anomaly 46.679, 34.078 (FRP 15.35 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-18 0924Z, FRP 15.35 MW

### Chinese Internal News — 205 new of 271 total
  - (2026-09-18) China’s Youth Unemployment Hits Record High - Caixin Global
      China’s Youth Unemployment Hits Record High Caixin Global
  - (2026-09-18) 财新闻｜HYROX失禁选手发文道歉 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1zYkVkcTlFRHNNUGJWZGRPbUFVRFZjNENKNU42a1hnSlJ1bEtJNXVOa0ZCZFlfVENSRHBSWXNERllvamk3THRVRzV1dGFjOW5JYjFK] (zh:…
      财新闻｜HYROX失禁选手发文道歉 财新
  - (2026-09-19) 薛暮桥与1943货币斗争 | 纪念 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9mNGE1bGNzTWpSLXNEQWFUNk9XeFAtVTlXUGFTWWpva1FXZWdYTnlqTTJJMDJNeHc4WFc1OGV4eGF1VFowZmljNm1yNndtNGRhY28w] (zh:…
      薛暮桥与1943货币斗争 | 纪念 财新
  - (2026-09-18) 财新周刊目录 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE8zMURmM3NCRkFnby1pMG02Y2JzS3hRQ2RhQzF6UFZSWG9ZZUhSYUxxMExzZXA2RWF6eWota2RUNjRBZTBiTTBMRURLYTFiaV] (zh:…
      财新周刊目录 database.caixin.com
  - (2026-09-19) “玩玩就会”的三不像，匹克球怎么就流行起来的？｜体坛 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9HZ3BHRnFWS0JtQ2N6Y29vREd5UE1ORWlQQ2lyOVhsd2dTUTdldXg4cWg0ZE8wb2N4WXpVLUwzU2NQVHg1MTY2ZW1jUHV] (zh:…
      “玩玩就会”的三不像，匹克球怎么就流行起来的？｜体坛 财新
  - (2026-09-19) 人事观察｜五省份党委副书记到位 乌鲁木齐书记王琳再履新 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBpWWJ6TlhsV0xhTGtnZVJWVk90QkNMZ3FnX1FLdDBkdXFpWEk2ZjZ1Tm5tMzVpYkdCbU9BLWhBeU9f] (zh:…
      人事观察｜五省份党委副书记到位 乌鲁木齐书记王琳再履新 china.caixin.com

### Local News: St. Louis + Atlanta — 197 new of 251 total
  - (2026-09-19) [St. Louis] Thai restaurant in the Grove to close after 7 years as owner shifts focus to grocery business
      Chao Baan will close Sunday after seven years as owner Shayn Prapaisilp shifts his focus to the family's growing grocery business.
  - (2026-09-19) [St. Louis] Ed Sheeran is set to return to stage for 1st time since Macklemore was cut and other acts withdrew
      It remains to be seen how Ed Sheeran will handle the performance at Philadelphia’s Lincoln Financial Field given the departure of his opening acts.
  - (2026-09-19) [St. Louis] William Shatner, 95, takes the stage this weekend with his metal band
      Shatner plans to debut the new band at the independent music festival Riot Fest.
  - (2026-09-19) [St. Louis] St. Louis weekend events draw thousands despite late-summer heat
      As crowds flock to the Great Forest Park Balloon Race and Saint Louis Art Fair, organizers and doctors urge attendees to stay cool and hydrated.
  - (2026-09-19) [St. Louis] Infectious disease expert breaks down first Measles case in St. Louis in 20 years
      Following news of St. Louis's first Measles case in two decades, Dr. Jennifer Layden gives insight into the fight against the infectious disease.
  - (2026-09-19) [St. Louis] Aviation company says it completed fully autonomous flight across the U.S.
      Joby Aviation said an aircraft equipped with autonomy technology flew from California to North Carolina's Outer Banks.

### U.S. Weather + Severe / Climate Outlooks — 112 new of 114 total
  - (2026-09-19) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-19) [Moderate] Gale Warning: Gale Warning issued September 19 at 3:41AM AKDT until September 20 at 5:00PM AKDT by NWS Juneau AK
      Southeast Alaska Coastal Waters from Dixon Entrance to Cape Suckling out 100 NM Wind forecasts reflect the predominant speed and direction expected. Seas forecasts represent the average of the highest one-third of the co…
  - (2026-09-19) [Moderate] Gale Warning: Gale Warning issued September 19 at 3:41AM AKDT until September 20 at 5:00PM AKDT by NWS Juneau AK
      Southeast Alaska Coastal Waters from Dixon Entrance to Cape Suckling out 100 NM Wind forecasts reflect the predominant speed and direction expected. Seas forecasts represent the average of the highest one-third of the co…
  - (2026-09-19) [Moderate] Gale Warning: Gale Warning issued September 19 at 3:41AM AKDT until September 20 at 5:00PM AKDT by NWS Juneau AK
      Southeast Alaska Coastal Waters from Dixon Entrance to Cape Suckling out 100 NM Wind forecasts reflect the predominant speed and direction expected. Seas forecasts represent the average of the highest one-third of the co…
  - (2026-09-19) [Moderate] Gale Warning: Gale Warning issued September 19 at 3:41AM AKDT until September 20 at 5:00PM AKDT by NWS Juneau AK
      Southeast Alaska Coastal Waters from Dixon Entrance to Cape Suckling out 100 NM Wind forecasts reflect the predominant speed and direction expected. Seas forecasts represent the average of the highest one-third of the co…
  - (2026-09-19) [Moderate] Gale Warning: Gale Warning issued September 19 at 3:41AM AKDT until September 20 at 5:00PM AKDT by NWS Juneau AK
      Southeast Alaska Coastal Waters from Dixon Entrance to Cape Suckling out 100 NM Wind forecasts reflect the predominant speed and direction expected. Seas forecasts represent the average of the highest one-third of the co…

### State Legislative Action — 79 new of 105 total
  - (2026-09-19) [Alaska SJR 25] Supporting efforts to modernize and improve the United States-Mexico-Canada Agreement; and supporting simplified border crossings and free trade with Canada and Mexico.
      Supporting efforts to modernize and improve the United States-Mexico-Canada Agreement; and supporting simplified border crossings and free trade with Canada and Mexico.
  - (2026-09-18) [Alaska SB 87] An Act disapproving the recommendations of the State Officers Compensation Commission; and providing for an effective date.
      An Act disapproving the recommendations of the State Officers Compensation Commission; and providing for an effective date.
  - (2026-09-18) [Alaska HB 221] An Act establishing the first Friday of every October as Alaska Arts and Culture Day; and providing for an effective date.
      An Act establishing the first Friday of every October as Alaska Arts and Culture Day; and providing for an effective date.
  - (2026-09-18) [Alaska SB 47] An Act relating to Chugach State Park; and providing for an effective date.
      An Act relating to Chugach State Park; and providing for an effective date.
  - (2026-09-18) [Alaska HJR 13] Urging the President of the United States to expand evacuation efforts for applicants with approved Special Immigrant Visas, including resumption of evacuation flights organized by the…
      Urging the President of the United States to expand evacuation efforts for applicants with approved Special Immigrant Visas, including resumption of evacuation flights organized by the Coordinator for Afghan Relocation E…
  - (2026-09-18) [Alaska SCR 27] Suspending Rules 24(c), 35, 41(b), and 42(e), Uniform Rules of the Alaska State Legislature, concerning House Bill No. 173, relating to occupational therapist licensure; relating to oc…
      Suspending Rules 24(c), 35, 41(b), and 42(e), Uniform Rules of the Alaska State Legislature, concerning House Bill No. 173, relating to occupational therapist licensure; relating to occupational therapy assistant licensu…

### Ukrainian Internal News (national + local Kyiv) — 70 new of 138 total
  - (2026-09-19) Зеленський показав новий дрон-перехоплювач реактивних "Шахедів" | LEDE: Президент Володимир Зеленський повідомив, що військова контррозвідка СБУ створила новий дрон-перехоплювач для боротьби з ] (uk:…
      Президент Володимир Зеленський повідомив, що військова контррозвідка СБУ створила новий дрон-перехоплювач для боротьби з реактивними "Шахедами" і вже успішно застосувала його.
  - (2026-09-19) Повітряний простір Молдови порушили кілька дронів | LEDE: ] (uk: Повітряний простір Молдови порушили кілька дронів)
  - (2026-09-19) Генштаб: Сили оборони уразили пункти управління БпЛА, полігон і склад росіян | LEDE: 18 вересня та в ніч на 19 вересня Сили оборони України уразили вісім пунктів управління російськими безпілот] (uk:…
      18 вересня та в ніч на 19 вересня Сили оборони України уразили вісім пунктів управління російськими безпілотниками на окупованих територіях Донецької та Запорізької областей, а також полігон і склад боєприпасів.
  - (2026-09-19) Польські винищувачі піднялись в небо через удари РФ по Україні | LEDE: ] (uk: Польські винищувачі піднялись в небо через удари РФ по Україні)
  - (2026-09-19) Лимонад, доміно і радянська форма: як окупанти проводять "вибори" на Херсонщині | LEDE: На окупованих територіях Херсонської області РФ влаштувала псевдовибори до Державної думи зі стилізованим] (uk:…
      На окупованих територіях Херсонської області РФ влаштувала псевдовибори до Державної думи зі стилізованими дільницями та подарунками виборцям.
  - (2026-09-19) ЗМІ: США попереджають союзників про затримки з постачанням ракет | LEDE: США інформували союзників про затримки з постачанням ракет Patriot, Tomahawk, Typhon через вичерпання власних запасів пі] (uk:…
      США інформували союзників про затримки з постачанням ракет Patriot, Tomahawk, Typhon через вичерпання власних запасів під час війни з Іраном.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-19) [Definium Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-09-19 01:55 UTC · role: Issuer — Filed: 2026-09-18 AccNo: 0001193125-26-395892 Size: 6 KB
  - (2026-09-19) [Vallone Carol A] Form 4 (Reporting)
      filed 2026-09-19 01:55 UTC · role: Reporting — Filed: 2026-09-18 AccNo: 0001193125-26-395892 Size: 6 KB
  - (2026-09-19) [Definium Therapeutics, Inc.] Form 4 (Issuer)
      filed 2026-09-19 01:55 UTC · role: Issuer — Filed: 2026-09-18 AccNo: 0001193125-26-395893 Size: 6 KB
  - (2026-09-19) [Krebs Andreas] Form 4 (Reporting)
      filed 2026-09-19 01:55 UTC · role: Reporting — Filed: 2026-09-18 AccNo: 0001193125-26-395893 Size: 6 KB
  - (2026-09-19) [Dillione Janet] Form 4 (Reporting)
      filed 2026-09-19 01:36 UTC · role: Reporting — Filed: 2026-09-18 AccNo: 0001213900-26-101594 Size: 7 KB
  - (2026-09-19) [CorMedix Inc.] Form 4 (Issuer)
      filed 2026-09-19 01:36 UTC · role: Issuer — Filed: 2026-09-18 AccNo: 0001213900-26-101594 Size: 7 KB

### Government Action: Sanctions + Procurement + Foreign Agents — 37 new of 105 total
  - (2026-09-18) [OFAC] Expiration of Emergency With Respect to the Situation in Ethiopia; Ethiopia-related Designations Removals; Issuance of Amended Russia-related General License and Associated Frequently Asked Que…
      Expiration of Emergency With Respect to the Situation in Ethiopia; Ethiopia-related Designations Removals; Issuance of Amended Russia-related General License and Associated Frequently Asked Questions Office of Foreign As…
  - (2026-09-18) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-09-14) [OFAC] 1245 - Office of Foreign Assets Control (.gov)
      1245 Office of Foreign Assets Control (.gov)
  - (2026-09-18) [OFAC] Russian Harmful Foreign Activities Sanctions - Office of Foreign Assets Control (.gov)
      Russian Harmful Foreign Activities Sanctions Office of Foreign Assets Control (.gov)
  - (2026-09-19) [OFAC] Sanctions Programs Atlas - Office of Foreign Assets Control (.gov)
      Sanctions Programs Atlas Office of Foreign Assets Control (.gov)
  - (2026-09-19) [USASpending] $30,883,321,453 → BATTELLE MEMORIAL INSTITUTE: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST
      Agency: Department of Energy. Description: BATTELLE MEMORIAL INSTITUTE/PACIFIC NORTHWEST LABORATORY OPERATING AND MANAGING CONTRACT

### IT, InfoSys & cybersecurity news (last 7 days) — 32 new of 52 total
  - (2026-09-19) [BleepingComputer] Calling viral AI actress Tilly Norwood? Agree to a face scan first
      AI actress Tilly Norwood went viral after glitching into Chinese on Piers Morgan Uncensored last night. Her "Talking Tilly" video call service face-scans every caller for an 18+ age check, senses callers' moods during ca…
  - (2026-09-19) [The Hacker News] Claude Opus 5 Helped Researchers Take Over OpenAI Staff Accounts via Chained Flaws
      Three researchers at the security firm Hacktron used Anthropic's Claude Opus 5 to chain two flaws and take over the ChatGPT and Codex accounts of several OpenAI employees, then reach an internal OpenAI code repository. T…
  - (2026-09-19) [The Hacker News] SolarWinds Patches ARM Hard-Coded Key Flaw Enabling Unauthenticated RCE
      SolarWinds has released security updates to address a high-severity flaw in Access Rights Manager (ARM) that, if successfully exploited, could lead to an unauthenticated remote code execution vulnerability. The vulnerabi…
  - (2026-09-19) [The Hacker News] Critical Pre-Auth RCE in Orkes Conductor Workflow Platform Exploited in the Wild
      A critical vulnerability impacting Orkes Conductor is being actively exploited in the wild, according to Fortinet. The vulnerability in question is CVE-2026-58138 (CVSS v3.1 score: 9.8/CVSS v4 score: 9.3), which relates…
  - (2026-09-19) [The Hacker News] Google Gemini Broke Into Real Company Systems After Security Test Domain Mix-Up
      Google's Gemini model has become the latest artificial intelligence (AI) system to access the internet and break into other companies during a cybersecurity evaluation. The development was first reported by The Wall Stre…
  - (2026-09-19) [The Hacker News] CrowdSec Says TanStack npm Attack Led to Copy of 170 Private GitHub Repositories
      An attacker copied about 170 of CrowdSec's private GitHub repositories on May 22 using the account of an employee who had just left, CrowdSec said on September 18. The French security company had kept his GitHub access o…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 25 new of 60 total
  - (2026-09-18) Arizona Supreme Court: Abraham v. Arizona Board of Regents
  - (2026-09-18) U.S. Court of Appeals, 8th Cir.: Kelli Florek v. Creighton University
  - (2026-09-18) U.S. Court of Appeals, 8th Cir.: Morgan Fitch v. BNSF Railway Company
  - (2026-09-18) U.S. Court of Appeals, 8th Cir.: United States v. Jeremy Phillips
  - (2026-09-18) U.S. Court of Appeals, 1st Cir.: Berkey International, LLC v. U.S. Environmental Protection Agency
  - (2026-09-18) U.S. Court of Appeals, 1st Cir.: D.V.D. v. U.S. Department of Homeland Security

### Government & military aircraft airborne (OpenSky) — 20 new of 21 total
  - (2026-09-19) PAT080 (United States)
      icao24: adfeda · position: (42.5613, -73.8629) · alt: 3253m · 468km/h
  - (2026-09-19) JAF95J (Bulgaria)
      icao24: 4520aa · position: (44.5516, -4.2823) · alt: 11277m · 850km/h
  - (2026-09-19) GAF788 (Germany)
      icao24: 3f59f3 · position: (46.0095, -9.8547) · alt: 11590m · 821km/h
  - (2026-09-19) JAF55M (Belgium)
      icao24: 44d1ba · position: (48.5075, 2.3609) · alt: 10668m · 861km/h
  - (2026-09-19) JAF42N (Belgium)
      icao24: 44d1a6 · position: (49.8863, 6.1711) · alt: 10690m · 935km/h
  - (2026-09-19) JAF74C (Belgium)
      icao24: 44d1b3 · position: (48.746, 8.4667) · alt: 11582m · 773km/h

### Prediction Markets — most-traded (Polymarket) — 18 new of 20 total
  - (2026-09-19) LoL: Invictus Gaming vs JD Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $2,426,187 · resolves 2026-09-19
  - (2026-09-19) LoL: Invictus Gaming vs JD Gaming - Game 3 Winner
      yes price: 0% · 24h volume: $1,851,713 · resolves 2026-09-19
  - (2026-09-19) LoL: Invictus Gaming vs JD Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $1,350,490 · resolves 2026-09-19
  - (2026-09-19) LoL: Invictus Gaming vs JD Gaming (BO5) - LPL Regional Finals Playoffs
      yes price: 76% · 24h volume: $1,343,565 · resolves 2026-09-19
  - (2026-09-19) Will FC Barcelona win on 2026-09-19?
      yes price: 78% · 24h volume: $1,173,814 · resolves 2026-09-19
  - (2026-09-19) Will Tottenham Hotspur FC win on 2026-09-19?
      yes price: 50% · 24h volume: $640,990 · resolves 2026-09-19

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-09-18) M 5.5 - Kermadec Islands region
      M5.5 · Kermadec Islands region · depth 94.054 km
  - (2026-09-19) M 5.2 - 210 km WNW of Abepura, Indonesia
      M5.2 · 210 km WNW of Abepura, Indonesia · depth 10 km
  - (2026-09-18) M 5.2 - 28 km NE of Villa Presidente Frei, Chile
      M5.2 · 28 km NE of Villa Presidente Frei, Chile · depth 100.009 km
  - (2026-09-18) M 5.2 - 189 km SSW of Pelabuhanratu, Indonesia
      M5.2 · 189 km SSW of Pelabuhanratu, Indonesia · depth 10 km
  - (2026-09-19) M 5.0 - South Sandwich Islands region
      M5.0 · South Sandwich Islands region · depth 77.621 km
  - (2026-09-19) M 4.9 - 117 km NW of Barranca, Peru
      M4.9 · 117 km NW of Barranca, Peru · depth 10 km

### Paper Trading Scorecard — 13 new of 124 total
  - (2026-09-19) [Manifold] Will İmisli FK defeat Sabah FK ?
  - (2026-09-19) [Manifold] Strait or canal subject to UNCLOS transit passage rights closed by end 2030?
  - (2026-09-19) [Manifold] China has nuclear-powered carrier in service by end 2040?
  - (2026-09-19) [Manifold] Will Democrats win back the house in 2026 midterms?
  - (2026-09-19) [Manifold] Will Democratic candidate Sherrod Brown win Mahoning County in the OH-SEN election?
  - (2026-09-19) [Manifold] Will my roommate talk while sleeping in the next month?

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 21 total
  - (2026-09-18) CVE-2025-39964 · Linux Kernel: Linux Kernel Race Condition Vulnerability
      vendor: Linux · product: Kernel · CISA remediation by 2026-09-21
  - (2026-09-18) CVE-2026-53266 · Linux Kernel: Linux Kernel Out-of-Bounds Write Vulnerability
      vendor: Linux · product: Kernel · CISA remediation by 2026-09-21
  - (2026-09-18) CVE-2025-39682 · Linux Kernel: Linux Kernel Improper Check for Unusual or Exceptional Conditions Vulnerability
      vendor: Linux · product: Kernel · CISA remediation by 2026-09-21

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=18, 14d-median=18; carrying terms: navigable, final, certain, management, proposing, proposes, program, proposed, establishing, action, issuing, document
- state_bills: today=105, 7d-median=79, 14d-median=82; carrying terms: january, protection, account, effective, energy, provide, advisory, certification, licensure, until, safety, county
- state_news: today=683, 7d-median=683, 14d-median=623; carrying terms: louisiana, billion, centers, shared, around, content, protection, hawaii, unions, recent, provide, world
- local_news: today=251, 7d-median=236, 14d-median=231; carrying terms: around, school, articles, following, blank, residents, former, google, metro, trump, https, downtown
- foreign_news: today=1045, 7d-median=1045, 14d-median=1005; carrying terms: yemen, around, content, committee, businessnews, production, questions, generation, iranian, congo, christmas, urged
- chinese_internal: today=271, 7d-median=282, 14d-median=282; carrying terms: people, articles, lxtfa, blank, lxtfb, cbmiykfvx, google, https, color, cbmiakfvx, cbmix, target
- russian_internal: today=1067, 7d-median=1067, 14d-median=1059; carrying terms: guardian, europe, novayagazeta, title, openai, error, blank, bloomberg, found, group, telegram, httperror
- ukrainian_internal: today=138, 7d-median=137, 14d-median=136; carrying terms: military, billion, hmarochos, reportedly, battlefield, energy, world, injuring, kravchenko, defense, kyivindependent, people
- ukraine_theater: today=417, 7d-median=417, 14d-median=417; carrying terms: beskrestnov, rvzzr, klwrysnfib, yemen, afbmmxnlew, steps, fwdbnuufbnhprrhvomms, cxvyy, ddlnd, production, cbmiyefvx, zosjnyatnxduxmd
- paper_bets: today=124, 7d-median=126, 14d-median=128; carrying terms: wisconsin, drought, chuck, nuclear, chair, successor, netanyahu, supreme, republicans, sachs, jackson, minister
- weather: today=114, 7d-median=114, 14d-median=107; carrying terms: currents, central, houston, afdffc, louis, around, discussion, combined, friday, messages, ruskin, pontiac
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: walcl, pcepilfe, commodities, indicator, dexjpus, jtsjol, money, cpiaucsl, personal, cpilfesl, openings, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, large, close, china, russell, equities, nasdaq, silver, crude, agriculture, credit, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=105, 7d-median=108, 14d-median=105; carrying terms: military, haitian, central, yemen, content, asked, detect, bombing, daesh, provide, human, council
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, error, client, quiver, congresstrading, unauthorized, quiverquant, https, quantitative
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, supreme, court, appeals, company, international, blanche, connecticut, trade, robert, university, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, accno, reporting, holdings, therapeutics, robert, andrew, technologies, definium
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, cooper, brown, disbursements, filing, graham, elect, robert, warner, senate, committee, james
- gdelt_regions: today=0, 7d-median=0, 14d-median=6
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, minister, sanctions, iranian, attack, turkish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=30, 14d-median=30; carrying terms: kingdom, belgium, position, germany, ground, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: dicale, index, january, fatal, seasonal, central, regarding, centers, poverty, individuals, mechanical, tshopo
- cisa_kev: today=21, 7d-median=23, 14d-median=21; carrying terms: citrix, artifactory, vendor, google, write, improper, critical, function, bounds, product, netscaler, chromium
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=17, 7d-median=13, 14d-median=11; carrying terms: depth, islands, indonesia, vanuatu, region, japan, colombia, south, ruteng, mexico, kermadec, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: championship, volume, meeting, resolves, donetsk, change, shakhtar, rates, price, league, champions, interest
- commentary: today=0, 7d-median=6, 14d-median=6; carrying terms: economist, revolution, class, https, marginal, evidence, conversable, conversableeconomist, story, recent, explain, price
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: world, speed, according, artificial, cybersecurity, weekly, spectrum, openai, technica, record, target, companies
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: duyne, debbie, cantwell, crane, brecheen, delauro, janice, ogles, katherine, attorney, trading, yakym
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, paper, converges, today, either, identify, market, consensus, placed, placement, markets, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy
- [2026-09-12] ECB press: Christine Lagarde: Interview with Ouest-France
- [2026-09-14] ECB press: Isabel Schnabel: Macroeconomic, fiscal and financial stability in a shock-prone world
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI
- [2026-09-16] ECB press: ECB wage tracker at 2.7% in H1 2027, pointing to a modest uptick in negotiated wage growth
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] ECB press: Boris Vujčić: Interview with Reuters
- [2026-09-18] ECB press: ECB Consumer Expectations Survey results – August 2026
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*