# WORLDSCOPE morning brief — 2026-08-25

## Headline
3671 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (783) · Russian Internal News (state + in-exile) (736) · Ukraine Theater (total-war monitoring) (508) · State-Level News (369) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (222) · Chinese Internal News (221) · U.S. Weather + Severe / Climate Outlooks (139) · Ukrainian Internal News (national + local Kyiv) (54) · GDELT GKG — themes / entities / watch areas (50) · IT, InfoSys & cybersecurity news (last 7 days) (45) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 783 new of 1002 total
  - (2026-08-25) [Global] Iran says it is 'fully prepared' to counter widened US economic sanctions
      The US calls its latest sanctions on Iran an "economic D-Day", but Tehran says it has a plan to address them.
  - (2026-08-25) [Global] Burnham refuses to rule out tax rises in autumn Budget
      Experts have warned that he and Chancellor John Healey will have little room to manoeuvre in their first Budget.
  - (2026-08-24) [Global] New 10p coin enters circulation - will you spot one?
      The coin has been designed to feature King Charles III and a Scottish grouse close to extinction.
  - (2026-08-25) [Global] How Canada could hit back to hurt the US economy - and Trump
      What leverage does Canada, which sells about 70% of its goods to the US, actually have in this spiralling trade dispute?
  - (2026-08-24) [Global] 'What you see is what you pay' - why some US restaurants are banning tips
      Tips are central to US dining culture but some eateries think that they are unfair.
  - (2026-08-25) [Global] US-Canada trade war escalates as Trump threatens tariff hike on vehicles
      Mark Carney accused Trump of wanting to "destroy" Canada's auto industry, and said he would only resume trade talks if the US comes with the "right attitude".

### Russian Internal News (state + in-exile) — 736 new of 992 total
  - (2026-08-25) На Амурском газохимическом комплексе произошел пожар. По данным телеграм-каналов, есть погибший и десятки пострадавших | LEDE: В Амурской области на строительной площадке готовящегося к запу] (ru: На…
      В Амурской области на строительной площадке готовящегося к запуску Амурского газохимического комплекса (АГХК) произошел пожар. Об этом сообщила пресс-служба предприятия.
  - (2026-08-25) Во Внуково прилетел военно-транспортный самолет ВВС США. Кого он привез, неизвестно | LEDE: Утром 25 августа в московском аэропорту Внуково приземлился военно-транспортный самолет Военно-воз] (ru: Во…
      Утром 25 августа в московском аэропорту Внуково приземлился военно-транспортный самолет Военно-воздушных сил США Boeing C-17 Globemaster III с бортовым номером RCH4555, следует из данных сервиса Flightradar24.
  - (2026-08-25) В московском метро начали рекламировать «альтернативную службу» без отправки на фронт. Но подписывать нужно обычный контракт | LEDE: В Москве около станций метро начали рекламировать альтерн] (ru: В м…
      В Москве около станций метро начали рекламировать альтернативную гражданскую службу. Об этом сообщает издание «Вот Так» со ссылкой на читательницу, которая заметила такие стенды.
  - (2026-08-25) Бывшую замглавы офиса президента Украины Ирину Мудрую отправили под стражу по делу о коррупции | LEDE: Высший антикоррупционный суд Украины назначил бывшей замглавы офиса президента Украины ] (ru: Быв…
      Высший антикоррупционный суд Украины назначил бывшей замглавы офиса президента Украины содержание под стражей на 60 дней с возможностью внесения залога в размере 20 миллионов гривен (около 380 тысяч евро). Об этом сообща…
  - (2026-08-25) В России арестован еще один глава компании по производству дронов — гендиректор центра «ТулаДрон» Евгений Григорьев | LEDE: В Туле задержан генеральный директор научно-производственного цент] (ru: В Р…
      В Туле задержан генеральный директор научно-производственного центра беспилотных авиационных систем «ТулаДрон» Евгений Григорьев, сообщило местное издание Myslo со ссылкой на источники.
  - (2026-08-25) США собираются отозвать около 200 тысяч виз у иностранцев, которые приехали по ним в страну и попросили убежище | LEDE: В ближайшие недели Госдепартамент США объявит об аннулировании виз B1 ] (ru: США…
      В ближайшие недели Госдепартамент США объявит об аннулировании виз B1 и B2, владельцы которых запросили убежище в стране. Об этом пишет агентство Associated Press, ознакомившееся с документами ведомства.

### Ukraine Theater (total-war monitoring) — 508 new of 880 total
  - (2026-08-25) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-24) [FIRMS] thermal anomaly 46.714, 33.066 (FRP 20.68 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-24 1032Z, FRP 20.68 MW
  - (2026-08-24) [FIRMS] thermal anomaly 44.531, 34.137 (FRP 15.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-24 1032Z, FRP 15.86 MW
  - (2026-08-24) [FIRMS] thermal anomaly 44.530, 34.132 (FRP 15.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-24 1032Z, FRP 15.86 MW
  - (2026-08-24) [FIRMS] thermal anomaly 44.550, 33.713 (FRP 3.48 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-24 1032Z, FRP 3.48 MW
  - (2026-08-24) [FIRMS] thermal anomaly 46.269, 34.815 (FRP 3.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-24 1032Z, FRP 3.18 MW

### State-Level News — 369 new of 471 total
  - (2026-08-24) [Alabama] Governor Ivey Announces First Grants in Major New Rural Healthcare Program Totaling More than $144 Million
      MONTGOMERY – Governor Kay Ivey on Monday announced the awarding of 138 grants worth a total of more than $144 million to healthcare providers and institutions throughout the state as part of the Alabama Rural Health Tran…
  - (2026-08-25) [California] Governor Newsom signs legislation 8.24.2026
      Source
  - (2026-08-25) [California] Governor Newsom announces judicial appointments 8.24.26
  - (2026-08-24) [California] Governor Newsom announces intent for California to sue Trump administration over latest attack on voting; new legislation introduced to defend democracy
      Source
  - (2026-08-24) [California] FACTS NOT ON FOX NEWS: California attracts more startup investment than 49 states combined
      Source
  - (2026-08-24) [Colorado] Colorado Sen. Cathy Kipp submits first complaint under state’s deepfake disclosure law
      The Colorado secretary of state’s office will investigate whether a video from a libertarian think tank generated with artificial intelligence violates a state law against undisclosed deepfake videos of candidates. Sen.…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 222 new of 238 total
  - (2026-08-25) [St. Louis] Where Art Thou? – 8/25/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-24) [St. Louis] 5 creative packed-lunch ideas that go beyond the usual sandwich
      If you’ve ever stressed out in the morning over what to pack for lunch—only to find yourself trashing most of the uneaten contents later that afternoon, then this one’s for you. Butler’s Pantry chef Samantha Piller share…
  - (2026-08-24) [St. Louis] 5 quick, easy breakfast ideas for busy school mornings
      Every weekday morning during the school year involves pretty much the same things: oversleeping, running behind, and lots of yelling. What they rarely involve is a healthy breakfast. Like most harried families, I count i…
  - (2026-08-24) [St. Louis] Missouri AG asks the court to force Cori Bush’s Politivist Power to turn over records
      The Missouri Attorney General is demanding answers from Politivist Power, an organization founded by former Congresswoman Cori Bush. Politivist was formed as a 501(c)(4), a tax-exempt social welfare organization that, un…
  - (2026-08-24) [St. Louis] Top glamping destinations in the Midwest and beyond
      Big Cedar Lodge | Ridgedale, Missouri Camp Long Creek, an extension of Big Cedar Lodge, is located near the banks of Table Rock Lake. Guests can choose from luxury tents, shepherd huts, or cabins. The tents have wood flo…
  - (2026-08-24) [St. Louis] What makes Pulaski County one of Missouri’s best weekend escapes
      Two and a half hours is all it takes to trade city traffic for spring-fed rivers, glowing Route 66 signs, scenic backroads, and a weekend packed with discoveries. Pulaski County has quietly become one of Missouri’s most…

### Chinese Internal News — 221 new of 279 total
  - (2026-08-24) China’s Fiscal Revenue Surges as State Spending Stagnates - Caixin Global
      China’s Fiscal Revenue Surges as State Spending Stagnates Caixin Global
  - (2026-08-24) Cover Story: China Tech Firms Drive AI Data Center Boom in Southeast Asia - Caixin Global
      Cover Story: China Tech Firms Drive AI Data Center Boom in Southeast Asia Caixin Global
  - (2026-08-24) China’s Draft Outbound Investment Rules Target Individuals, Tighten Oversight - Caixin Global
      China’s Draft Outbound Investment Rules Target Individuals, Tighten Oversight Caixin Global
  - (2026-08-23) 财新闻｜旗下奶粉被控致病，美国雅培：将赔偿6.7亿美元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9QOVViZUUyZlhIRWhtN3g2aUZ2TzZqMEJTVWViM3hwQl9DaHBXTGhxYTVqVHI4RVFYN2lPdGtUR3RKWnM2b1JGeG5BaE] (zh:…
      财新闻｜旗下奶粉被控致病，美国雅培：将赔偿6.7亿美元 财新
  - (2026-08-25) 最新财新周刊｜AI大调仓 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5qREJQNjI2VEt2MGpaTlZDd3VUN09DbDZ0OENnRVhFOHQ0eVRxOGpJUTFQajhXcjJlMVE1QTQ0MDVOTVJvUTd6dTlMek5IWUVuVlJ4QWlJZ] (zh:…
      最新财新周刊｜AI大调仓 财新
  - (2026-08-24) 财经早知道｜国管公积金新政 首套房最高可贷款340万元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBHbHdRTnBCQlNQeFNQdWhWRlBhNGpUakpGSWpwNER2VHdTYXE2cnJJNDNpdFR0bTNqRDFFUFJWQU80eEpRbVhrSzZOWX] (zh:…
      财经早知道｜国管公积金新政 首套房最高可贷款340万元 财新

### U.S. Weather + Severe / Climate Outlooks — 139 new of 143 total
  - (2026-08-25) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-25) [Moderate] Special Weather Statement: Special Weather Statement issued August 25 at 4:36AM CDT by NWS Grand Forks ND
      At 435 AM CDT, Doppler radar was tracking a strong thunderstorm over northern Lower Red Lake, or 37 miles north of Bemidji, moving northeast at 45 mph. HAZARD...Wind gusts up to 40 mph and penny size hail. SOURCE...Radar…
  - (2026-08-25) [Moderate] Special Weather Statement: Special Weather Statement issued August 25 at 4:17AM CDT by NWS North Platte NE
      At 417 AM CDT, Doppler radar was tracking a strong thunderstorm near Tryon, moving southeast at 40 mph. HAZARD...Wind gusts up to 50 mph and penny size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock dow…
  - (2026-08-25) [Unknown] Air Quality Alert: Air Quality Alert issued August 25 at 4:00AM CDT by NWS Memphis TN
      AQAMEG The Shelby County Health Department has issued a Code Orange Ozone Forecast effective for Shelby County Tennessee, Crittenden County Arkansas, and DeSoto County Mississippi, including the city of Memphis for today…
  - (2026-08-25) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued August 25 at 4:57AM EDT until August 25 at 9:00AM EDT by NWS Newport/Morehead City NC
      * WHAT...Visibility one quarter mile or less in dense fog. * WHERE...Inland Onslow County. * WHEN...Until 9 AM EDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-08-25) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 25 at 1:51AM MST until August 29 at 8:00PM MST by NWS Tucson AZ
      * WHAT...Dangerously hot conditions with high temperatures ranging between 103 to 111 degrees and low temperatures 79 to 85 degrees. Major HeatRisk is expected today and then widespread Major to Extreme HeatRisk Wednesda…

### Ukrainian Internal News (national + local Kyiv) — 54 new of 107 total
  - (2026-08-25) У Єврокомісії знають про операцію "Форест Гамп" і нагадують про "нульову терпимість до корупції" | LEDE: ] (uk: У Єврокомісії знають про операцію "Форест Гамп" і нагадують про "нульову терпимі)
  - (2026-08-25) Марина Стародубська: 8 неочевидних кроскультурних фактів про Україну | LEDE: ] (uk: Марина Стародубська: 8 неочевидних кроскультурних фактів про Україну)
  - (2026-08-25) Вісім неочевидних кроскультурних фактів про Україну | LEDE: Вісім цікавих кроскультурних фактів про суспільні зміни, очікування та реальність в Україні за 35 років.] (uk: Вісім неочевидних кроскультур…
      Вісім цікавих кроскультурних фактів про суспільні зміни, очікування та реальність в Україні за 35 років.
  - (2026-08-25) Сили оборони уразили Афіпський НПЗ та Астраханський ГПЗ, які забезпечують армію РФ | LEDE: ЗСУ уразили Афіпський НПЗ і Астраханський газозавод, які забезпечують армію РФ, підтверджено пожежу.] (uk: Си…
      ЗСУ уразили Афіпський НПЗ і Астраханський газозавод, які забезпечують армію РФ, підтверджено пожежу.
  - (2026-08-25) Росіяни 8 разів атакували Краматорськ авіабомбами: 11 поранених, серед них немовля | LEDE: Росіяни завдали авіаудару по Краматорську: відомо про жертв і поранених, пошкоджено житло та торгові о] (uk:…
      Росіяни завдали авіаудару по Краматорську: відомо про жертв і поранених, пошкоджено житло та торгові об'єкти.
  - (2026-08-25) Storm Shadow для України: Кремль пригрозив Британії "напіввіськовими діями" проти її збройних заводів | LEDE: Радник Кремля попередив про можливі атаки на британські заводи після передачі Украї] (uk:…
      Радник Кремля попередив про можливі атаки на британські заводи після передачі Україні технологій Storm Shadow.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-25) [Russia oil sanctions perimeter · themes] 롯데GRS , 엔제리너스 인도네시아 진출 … 5년간 10개점
      newspim.com · Korean · tone NA
  - (2026-08-25) [Russia oil sanctions perimeter · themes] 高雄連日豪雨 國民黨行動中常會高雄場暫緩舉行 | 政治
      cna.com.tw · Chinese · tone NA
  - (2026-08-25) [Russia oil sanctions perimeter · themes] Zam sonrası pompa etiketleri zirvede : İstanbul , Ankara ve İzmirde benzin litre fiyatı ne kadar oldu ?
      anlatilaninotesi.com.tr · Turkish · tone NA
  - (2026-08-25) [Russia oil sanctions perimeter · themes] 突破具身智能物理死角 ： IJCAI 2026 具身智能泛化与控制突破
      163.com · Chinese · tone NA
  - (2026-08-25) [Russia oil sanctions perimeter · themes] LIVE TEXT / O importantă rafinărie de petrol din sudul Rusiei ar fi fost lovită în urma unui atac ucrainean . Război în Ucraina , ziua 1644
      news.yam.md · Romanian · tone NA
  - (2026-08-25) [Russia oil sanctions perimeter · themes] Российское командование торгует топливом , отправляя оккупантов на штурмы пешком – данные Атеша
      war.obozrevatel.com · Russian · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 55 total
  - (2026-08-25) [The Hacker News] Attackers Target miniOrange SAML Flaws That Can Grant WordPress Admin Access
      Bad actors are attempting to exploit two severe unauthenticated authentication bypasses in the Xecurify miniOrange SAML 2.0 Single Sign On plugin that make it possible for an attacker to sign in as any WordPress user, in…
  - (2026-08-25) [The Hacker News] Actively Exploited Oracle WebLogic Flaw Lets Unauthenticated Attackers Access Critical Data
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Monday added a maximum-severity security flaw impacting Oracle HTTP Server and Oracle WebLogic Server to its Known Exploited Vulnerabilities (KEV) catal…
  - (2026-08-25) [The Register] Crooks push Mac malware through fake OpenAI Codex ads
      Sponsored search results lead developers straight into a ClickFix malware trap
  - (2026-08-25) [The Register] HMRC dangles £500M carrot for National Insurance system revamp
      Taxman wants to drag creaky NPS into agile era
  - (2026-08-25) [The Register] What is virtualization modernization?
      SPONSORED EXPLAINER: Why you should take a long-term approach to rethinking your virtualization portfolio
  - (2026-08-25) [The Register] Australia’s record industry won’t chart tunes recorded in the key of AI
      This is basically a riff on ‘You wouldn’t steal a car’ and means only the human league can have a hit

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-25) [Kapoor Rohit (RK2)] Form 4 (Reporting)
      filed 2026-08-25 01:58 UTC · role: Reporting — Filed: 2026-08-24 AccNo: 0001419945-26-000064 Size: 6 KB
  - (2026-08-25) [TEEKAY TANKERS LTD.] Form 4 (Issuer)
      filed 2026-08-25 01:58 UTC · role: Issuer — Filed: 2026-08-24 AccNo: 0001419945-26-000064 Size: 6 KB
  - (2026-08-25) [Seidelin Mikkel] Form 4 (Reporting)
      filed 2026-08-25 01:53 UTC · role: Reporting — Filed: 2026-08-24 AccNo: 0001419945-26-000062 Size: 6 KB
  - (2026-08-25) [TEEKAY TANKERS LTD.] Form 4 (Issuer)
      filed 2026-08-25 01:53 UTC · role: Issuer — Filed: 2026-08-24 AccNo: 0001419945-26-000062 Size: 6 KB
  - (2026-08-25) [Speers Brody] Form 4 (Reporting)
      filed 2026-08-25 01:46 UTC · role: Reporting — Filed: 2026-08-24 AccNo: 0001419945-26-000061 Size: 6 KB
  - (2026-08-25) [TEEKAY TANKERS LTD.] Form 4 (Issuer)
      filed 2026-08-25 01:46 UTC · role: Issuer — Filed: 2026-08-24 AccNo: 0001419945-26-000061 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### State Legislative Action — 25 new of 30 total
  - (2026-08-25) [Alaska HB 280] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and tele…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and telecommunications service providers; an…
  - (2026-08-25) [Alaska HB 289] An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; an…
      An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; and providing for an effective date.
  - (2026-08-25) [Alaska HB 283] An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and provid…
      An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and providing for an effective date.
  - (2026-08-24) [Alaska SB 9] An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
      An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
  - (2026-08-24) [Alaska SB 63] An Act relating to the Local Boundary Commission; and providing for an effective date.
      An Act relating to the Local Boundary Commission; and providing for an effective date.
  - (2026-08-24) [Alaska SB 158] An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
      An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.

### Government & military aircraft airborne (OpenSky) — 25 new of 30 total
  - (2026-08-25) JAF94H (Bulgaria)
      icao24: 4520aa · position: (45.5727, 0.6764) · alt: 11887m · 731km/h
  - (2026-08-25) SAMU45 (France)
      icao24: 39ca85 · position: (48.6865, 2.1263) · alt: 480m · 222km/h
  - (2026-08-25) PUMA56 (Slovenia)
      icao24: 506e19 · position: (45.8898, 15.4493) · alt: 944m · 190km/h
  - (2026-08-25) PUMA26 (Slovenia)
      icao24: 506e1c · position: (45.9192, 15.516) · alt: 579m · 155km/h
  - (2026-08-25) GAF412 (Germany)
      icao24: 3ea1cc · position: (51.9792, 9.3681) · alt: 1485m · 529km/h
  - (2026-08-25) SAMU691 (France)
      icao24: 39c994 · position: (45.7835, 3.8345) · alt: 1371m · 237km/h

### Court opinions of consequence (federal & state) — 20 new of 60 total
  - (2026-08-24) U.S. Court of Appeals, 3rd Cir.: Jane Parkin v. Avis Rent a Car System LLC
  - (2026-08-24) U.S. Court of Appeals, 3rd Cir.: Roger Salvatora v. XTO Energy Inc
  - (2026-08-24) U.S. Court of Appeals, 1st Cir.: Pereira Alves v. Blanche
  - (2026-08-24) U.S. Court of Appeals, 1st Cir.: United States v. Reynoso
  - (2026-08-24) Delaware Supreme Court: Robert E. Vanella, on behalf of The Delaware Call v. Christina Duran, in her official capacity as FOIA Coordinator for the Delaware Department of Safe
  - (2026-08-24) Delaware Supreme Court: FON Holdings, LLC v. Brian Jones

### Paper Trading Scorecard — 17 new of 123 total
  - (2026-08-25) [Polymarket] Clarity Act (H.R.3633) signed into law in 2026?
      This market will resolve to "Yes" if the Digital Asset Market Clarity Act of 2025 (H.R.3633) is passed by both chambers of the U.S. Congress and signed into law by December 31, 2026, 11:59 PM ET. Otherwise, this market w…
  - (2026-08-25) [Polymarket] Will Bitcoin dip to $62,500 in August?
      This market will resolve to "Yes" if any Binance 1 minute candle for BTC/USDT from the creation of this market through 11:59 PM ET on the last day of the month specified in the title has a final Low price equal to or low…
  - (2026-08-25) [Manifold] Daily Coinflip
  - (2026-08-25) [Manifold] Nick Walker Wins 2026 Mr. Olympia?
  - (2026-08-25) [Manifold] Natalie Harp births President Donald J. Trump's child by EOY 2028?
  - (2026-08-25) [Manifold] Strait of Hormuz traffic returns to normal by April 30th 2027? [Polymarket]

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-08-24) M 6.0 - 215 km NNE of Lospalos, Timor Leste
      M6.0 · 215 km NNE of Lospalos, Timor Leste · depth 10 km
  - (2026-08-25) M 5.5 - 108 km NE of Hengchun, Taiwan
      M5.5 · 108 km NE of Hengchun, Taiwan · depth 14.608 km
  - (2026-08-24) M 5.5 - 207 km SSE of Amahai, Indonesia
      M5.5 · 207 km SSE of Amahai, Indonesia · depth 10 km
  - (2026-08-25) M 5.0 - 31 km S of Nemuro, Japan
      M5.0 · 31 km S of Nemuro, Japan · depth 96.855 km
  - (2026-08-24) M 5.0 - 209 km NNE of Lospalos, Timor Leste
      M5.0 · 209 km NNE of Lospalos, Timor Leste · depth 9.947 km
  - (2026-08-24) M 5.0 - southern Mid-Atlantic Ridge
      M5.0 · southern Mid-Atlantic Ridge · depth 10 km

### U.S. Federal Action — 16 new of 19 total
  - (2026-08-25) Continuation of the Exercise of Certain Authorities Under the Trading With the Enemy Act
  - (2026-08-25) The National Space Transportation Policy
  - (2026-08-25) Establishment of Four Customs-Enforcement Areas
      This document sets forth the Commissioner of U.S. Customs and Border Protection's (CBP) declaration establishing four Customs- Enforcement Areas (CEA) in the near shore waters of South Florida, Central/Southern Californi…
  - (2026-08-25) Final Waiver and Extension of the Project Period With Funding-Elementary and Secondary Education Act of 1965, as Amended, Title VI, Part B, Native Hawaiian Education
      The Secretary waives the requirements in the Education Department General Administrative Regulations (EDGAR) that generally prohibit project period extensions involving the obligation of additional Federal funds. The fin…
  - (2026-08-25) Amendment of Restricted Areas R-2505, R-2524, R-2508, and R-2515 in California
      This action amends multiple coordinates used to describe restricted areas R-2505, R-2524, R-2508, and R-2515 in California. The amendments are administrative in nature and do not expand any outer boundaries, altitudes, t…
  - (2026-08-25) Reduction in Force Appeals; Correction
      The Office of Personnel Management (OPM) published a final rule in the Federal Register on August 3, 2026, concerning reduction in force appeals. That document contained typographical and citation errors in the regulator…

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 105 total
  - (2026-08-24) [OFAC] Removal of Syria's designation as a State Sponsor of Terrorism and Associated Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Removal of Syria's designation as a State Sponsor of Terrorism and Associated Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-08-24) [OFAC] DETERMINATION PURSUANT TO SECTION 1(a)(i) OF EXECUTIVE ORDER 13902 Aviation, Digital Asset, Gold, Shipping, and Technology Sect - Office of Foreign Assets Control (.gov)
      DETERMINATION PURSUANT TO SECTION 1(a)(i) OF EXECUTIVE ORDER 13902 Aviation, Digital Asset, Gold, Shipping, and Technology Sect Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions | Office of Fore…
      Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions | Office of Foreign Assets Control Office o…
  - (2026-08-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Suspension of Certain Iranian Transactions and Sanctions Regulations General Licenses On August - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Suspension of Certain Iranian Transactions and Sanctions Regulations General Licenses On August Office of Foreign Assets Control (.gov)
  - (2026-08-24) [OFAC] Strait of Hormuz Toll Payments Alert Update - Office of Foreign Assets Control (.gov)
      Strait of Hormuz Toll Payments Alert Update Office of Foreign Assets Control (.gov)
  - (2026-08-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE BB Authorizing - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE BB Authorizing Office of Foreign Assets Control (.gov)

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-08-25) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 0% · 24h volume: $908,793 · resolves 2026-09-16
  - (2026-08-25) Will John Thune win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $469,630 · resolves 2028-11-07
  - (2026-08-25) Will Donald Trump publicly insult someone on August 23, 2026?
      yes price: 6% · 24h volume: $385,092 · resolves 2026-08-24
  - (2026-08-25) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 34% · 24h volume: $372,476 · resolves 2026-09-16
  - (2026-08-25) Will the Iranian regime fall before 2027?
      yes price: 8% · 24h volume: $358,191 · resolves 2026-12-31
  - (2026-08-25) LoL: Kiwoom DRX Challengers vs BNK FearX Youth (BO5) - LCK Challengers League Play-In
      yes price: 36% · 24h volume: $285,387 · resolves 2026-08-25

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-25) [Marginal Revolution] Do Minimum Wages Help Worker in Poor and Low-Income Families?
      We provide the first direct estimates of the effects of minimum wages on low-wage workers in families at different points of the distribution of income-to-needs, using data from the Survey of Income and Program Participa…
  - (2026-08-25) [Marginal Revolution] That was then, this is now
      In 1914 Yitzhak Ben-Zvi and David Ben-Gurion, the president and prime minister of Israel after 1948 respectively, were in the Ottoman capital studying law at Istanbul University. They had studied Ottoman Turkish and emba…
  - (2026-08-24) [Marginal Revolution] Common sense in charge
      …children are increasingly seen as interfering with the freedom of parents; views on whether mothers of young children should work have become markedly more progressive and account for a substantially larger share of the…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-08-24) CVE-2026-21962 · Oracle HTTP Server and Oracle Weblogic Server Proxy Plug-in: Oracle HTTP Server and Oracle Weblogic Server Proxy Plug-in Improper Access Control Vulnerability
      vendor: Oracle · product: HTTP Server and Oracle Weblogic Server Proxy Plug-in · CISA remediation by 2026-08-27

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=14, 14d-median=19; carrying terms: national, proposes, establish, proposed, action, certain, navigable, service, specifically, management, coast, establishing
- state_bills: today=30, 7d-median=134, 14d-median=129; carrying terms: funds, years, agency, offense, community, violence, consumer, purposes, income, provides, permits, property
- state_news: today=471, 7d-median=597, 14d-median=585; carrying terms: sites, beach, trump, budget, costs, comes, services, presidential, story, narrow, polls, async
- local_news: today=238, 7d-median=238, 14d-median=229; carrying terms: color, trump, center, killed, family, being, georgia, charged, state, taken, arrested, court
- foreign_news: today=1002, 7d-median=1002, 14d-median=1002; carrying terms: explained, began, gross, lives, outlets, pledges, halts, known, yunnan, engines, shifts, legislate
- chinese_internal: today=279, 7d-median=284, 14d-median=279; carrying terms: color, lxtfb, global, cbmiykfvx, politics, cbmiyefvx, caixin, chinese, target, cbmib, cbmibkfvx, lxtfa
- russian_internal: today=992, 7d-median=1030, 14d-median=1030; carrying terms: forbidden, telegram, novaya, found, error, media, journal, https, httperror, gazeta, client, novayagazeta
- ukrainian_internal: today=107, 7d-median=114, 14d-median=109; carrying terms: update, hromadske, across, comes, launched, energy, intelligence, center, support, facility, europe, patriot
- ukraine_theater: today=880, 7d-median=880, 14d-median=1025; carrying terms: procurement, sujvrdnf, aytvmbmfoalmynwfxafk, klwrysnfib, procured, cjzyt, hkmlrfmgfwdw, disabled, zvsdrfovjpy, cuxoa, ektxwhblafvut, jvowd
- paper_bets: today=123, 7d-median=131, 14d-median=139; carrying terms: chair, funds, georgia, lifetime, degrees, mexico, alaska, levels, johnny, texas, nominal, fuentes
- weather: today=143, 7d-median=145, 14d-median=166; carrying terms: deeper, francisco, cooler, thunderstorm, include, impact, disregard, widespread, scattered, memphis, thunderstorms, morning
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: money, payrolls, funds, indicator, effective, assets, balance, jolts, cpilfesl, unrate, implied, openings
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, range, nasdaq, bitcoin, proxy, crude, large, yield, natural, corporate, futures, close
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=105, 7d-median=100, 14d-median=96; carrying terms: hamas, niger, assets, resolution, agency, snapshot, color, aggression, entity, alliance, destabilising, misappropriation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quantitative, error, congresstrading, quiver, quiverquant, httperror, unauthorized, client
- billionaires: today=30, 7d-median=34, 14d-median=34; carrying terms: finance, gmexicob, telecom, julia, gautam, larrea, semiconductors, alice, ballmer, peterffy, tiktok, india
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, state, court, supreme, company, center, james, connecticut, trust, america, general, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, reporting, filed, vincent
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, shawn, ossoff, trone, filing, booker, cycle, ocasio, cooper, robert, receipts, platner
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan, defense, china
- gdelt_gkg: today=50, 7d-median=25, 14d-median=41; carrying terms: english, trump, keywords, themes, russian, russia, sanctions, ukrainian, perimeter, china, chinese, business
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, france, ground, germany, kingdom, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: ventilation, niger, round, developments, sites, release, march, years, disembarked, regarding, conflict, average
- cisa_kev: today=13, 7d-median=12, 14d-median=10; carrying terms: driver, injection, secure, ancillary, security, windows, cisco, command, authentication, defense, metabase, adaptive
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=315, 14d-median=315
- usgs_quakes: today=17, 7d-median=19, 14d-median=19; carrying terms: indonesia, depth, ruteng, islands, japan, philippines, region, tonga, atlantic, papua, ridge, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, resolves, interest, shakhtar, championship, price, august, champions, volume, donetsk, winner, september
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, https, conversable, marginal, class, economist, conversableeconomist, wrote, impossible, around, point, interesting
- tech_news: today=55, 7d-median=55, 14d-median=56; carrying terms: release, newsletter, download, spectrum, known, technica, across, services, called, schneier, record, microsoft
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: justice, emily, francisco, maxwell, sotomayor, gilbert, chris, rashida, houchin, graves, alsobrooks, kaine
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, paper, sufficient, claude, market, consensus, markets, either, today, placement, identify, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*