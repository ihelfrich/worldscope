# WORLDSCOPE morning brief — 2026-08-25

## Headline
3059 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (766) · Russian Internal News (state + in-exile) (696) · State-Level News (343) · World leaders & government officials (324) · Chinese Internal News (216) · Local News: St. Louis + Atlanta (212) · U.S. Weather + Severe / Climate Outlooks (139) · Ukraine Theater (total-war monitoring) (68) · Ukrainian Internal News (national + local Kyiv) (49) · IT, InfoSys & cybersecurity news (last 7 days) (42) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 766 new of 998 total
  - (2026-08-24) [Global] Prince Harry quits board of wildlife charity after rangers’ human rights abuses
  - (2026-08-24) [Global] Video shows hundreds held captive after Nigeria mosque kidnapping
  - (2026-08-24) [Global] Children make up half of mpox cases in Guinea-Bissau as epidemic spreads
  - (2026-08-25) [Global] Colombia’s new president Abelardo de la Espriella announces immigration crackdown
  - (2026-08-24) [Global] US strikes a vessel in the eastern Pacific, killing 2 people in first attack in months
  - (2026-08-24) [Global] Trump announces new 50% tariff on Canadian cars, trucks and steel

### Russian Internal News (state + in-exile) — 696 new of 952 total
  - (2026-08-25) В России арестован еще один глава компании по производству дронов — гендиректор центра «ТулаДрон» Евгений Григорьев | LEDE: В Туле задержан генеральный директор научно-производственного цент] (ru: В Р…
      В Туле задержан генеральный директор научно-производственного центра беспилотных авиационных систем «ТулаДрон» Евгений Григорьев, сообщило местное издание Myslo со ссылкой на источники.
  - (2026-08-25) США собираются отозвать около 200 тысяч виз у иностранцев, которые приехали по ним в страну и попросили убежище | LEDE: В ближайшие недели Госдепартамент США объявит об аннулировании виз B1 ] (ru: США…
      В ближайшие недели Госдепартамент США объявит об аннулировании виз B1 и B2, владельцы которых запросили убежище в стране. Об этом пишет агентство Associated Press, ознакомившееся с документами ведомства.
  - (2026-08-25) Ozon объявил о мерах поддержки продавцов на фоне атак дронов. Среди них — отмена постоплаты и бесплатная перевозка товаров на другие склады | LEDE: Маркетплейс Ozon, склады которого начали а] (ru: Ozo…
      Маркетплейс Ozon, склады которого начали атаковать украинские беспилотники, объявил о мерах поддержки продавцов.
  - (2026-08-25) Бензина АИ-95 нет на почти 80% российских заправок | LEDE: Бензин АИ-95, по состоянию на 24 августа, был лишь на 22% российских АЗС, пишет «Инфотэк», ссылаясь на данные сервиса «Бензонавт».<] (ru: Бен…
      Бензин АИ-95, по состоянию на 24 августа, был лишь на 22% российских АЗС, пишет «Инфотэк», ссылаясь на данные сервиса «Бензонавт».
  - (2026-08-25) Кремль назвал «информационными утками» сообщения о новой мобилизации в России | LEDE: Украинские власти своими заявлениями о возможной мобилизации в России пытаются «идеологически раскачиват] (ru: Кре…
      Украинские власти своими заявлениями о возможной мобилизации в России пытаются «идеологически раскачивать ситуацию у нас в стране». Об этом заявил пресс-секретарь президента РФ Дмитрий Песков в комментарии RTVI.
  - (2026-08-25) Задержан бывший президент Армении Роберт Кочарян | LEDE: Сотрудники правоохранительных органов Армении утром 25 августа задержали и доставили в Антикоррупционный комитет бывшего президента р] (ru: Зад…
      Сотрудники правоохранительных органов Армении утром 25 августа задержали и доставили в Антикоррупционный комитет бывшего президента республики Роберта Кочаряна.

### State-Level News — 343 new of 452 total
  - (2026-08-24) [Alabama] Governor Ivey Announces First Grants in Major New Rural Healthcare Program Totaling More than $144 Million
      MONTGOMERY – Governor Kay Ivey on Monday announced the awarding of 138 grants worth a total of more than $144 million to healthcare providers and institutions throughout the state as part of the Alabama Rural Health Tran…
  - (2026-08-25) [California] Governor Newsom signs legislation 8.24.2026
      Source
  - (2026-08-25) [California] Governor Newsom announces judicial appointments 8.24.26
  - (2026-08-24) [California] Governor Newsom announces intent for California to sue Trump administration over latest attack on voting; new legislation introduced to defend democracy
      Source
  - (2026-08-24) [California] FACTS NOT ON FOX NEWS: California attracts more startup investment than 49 states combined
      Source
  - (2026-08-24) [Arizona] Supreme Court lifts block on Trump’s mail-in ballot order, for now
      WASHINGTON — With just over two months until the November midterms, the U.S. Supreme Court gave way Monday for President Donald Trump to have a hand in regulating mail-in ballots nationwide, a voting method he has falsel…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 216 new of 276 total
  - (2026-08-24) China’s Fiscal Revenue Surges as State Spending Stagnates - Caixin Global
      China’s Fiscal Revenue Surges as State Spending Stagnates Caixin Global
  - (2026-08-24) Cover Story: China Tech Firms Drive AI Data Center Boom in Southeast Asia - Caixin Global
      Cover Story: China Tech Firms Drive AI Data Center Boom in Southeast Asia Caixin Global
  - (2026-08-24) China’s Draft Outbound Investment Rules Target Individuals, Tighten Oversight - Caixin Global
      China’s Draft Outbound Investment Rules Target Individuals, Tighten Oversight Caixin Global
  - (2026-08-25) 轻信“网友”，赴泰旅游被绑架！中国女留学生跳车脱险 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE85RDNZeE9Pd0Nkd3dPVmg0bG9KNjBRQ1U5MFpXYm5EZmNuVmtDSllPbmMyVVY4LXZmNlUxM01vZ0ZjUlVReFotQ1Qta0l] (zh:…
      轻信“网友”，赴泰旅游被绑架！中国女留学生跳车脱险 观察者
  - (2026-08-25) 老人重摔倒地掙扎多次无法起身，邻居视而不见还悠闲吃雪糕，如何看待邻居行为？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFB5dXZsUEFjd3Fxc2gxSmFEekthalV6M3U0LUk1ZjJaVmYzUlo0dUJrVC1ndDFnU09JSnNWYmRlTzdNMVdh] (zh:…
      老人重摔倒地掙扎多次无法起身，邻居视而不见还悠闲吃雪糕，如何看待邻居行为？ 风闻
  - (2026-08-24) 目击者称老板娘救人时还摔了一跤，其儿子说“到此为止”，这事真的不需要答案了？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE52REJkVG5FaGh0RDBNM1FnRUVfNVZfd29rc0JOSFNIODVLcFptVHJ3dkNLM3E2d3JSTkNsOGU5Vk94ZEV] (zh:…
      目击者称老板娘救人时还摔了一跤，其儿子说“到此为止”，这事真的不需要答案了？ 风闻

### Local News: St. Louis + Atlanta — 212 new of 228 total
  - (2026-08-25) [St. Louis] Where Art Thou? – 8/25/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-08-24) [St. Louis] 5 creative packed-lunch ideas that go beyond the usual sandwich
      If you’ve ever stressed out in the morning over what to pack for lunch—only to find yourself trashing most of the uneaten contents later that afternoon, then this one’s for you. Butler’s Pantry chef Samantha Piller share…
  - (2026-08-24) [St. Louis] 5 quick, easy breakfast ideas for busy school mornings
      Every weekday morning during the school year involves pretty much the same things: oversleeping, running behind, and lots of yelling. What they rarely involve is a healthy breakfast. Like most harried families, I count i…
  - (2026-08-24) [St. Louis] Missouri AG asks the court to force Cori Bush’s Politivist Power to turn over records
      The Missouri Attorney General is demanding answers from Politivist Power, an organization founded by former Congresswoman Cori Bush. Politivist was formed as a 501(c)(4), a tax-exempt social welfare organization that, un…
  - (2026-08-24) [St. Louis] Top glamping destinations in the Midwest and beyond
      Big Cedar Lodge | Ridgedale, Missouri Camp Long Creek, an extension of Big Cedar Lodge, is located near the banks of Table Rock Lake. Guests can choose from luxury tents, shepherd huts, or cabins. The tents have wood flo…
  - (2026-08-24) [St. Louis] What makes Pulaski County one of Missouri’s best weekend escapes
      Two and a half hours is all it takes to trade city traffic for spring-fed rivers, glowing Route 66 signs, scenic backroads, and a weekend packed with discoveries. Pulaski County has quietly become one of Missouri’s most…

### U.S. Weather + Severe / Climate Outlooks — 139 new of 143 total
  - (2026-08-25) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-25) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 25 at 2:32AM CDT until August 25 at 3:15AM CDT by NWS Aberdeen SD
      SVRABR The National Weather Service in Aberdeen has issued a * Severe Thunderstorm Warning for... Southern Clark County in northeastern South Dakota... Southwestern Hamlin County in northeastern South Dakota... * Until 3…
  - (2026-08-25) [Moderate] Heat Advisory: Heat Advisory issued August 25 at 12:02AM PDT until August 25 at 10:00AM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...For the Heat Advisory, temperatures up to 98. For the Extreme Heat Warning, dangerously hot conditions with temperatures up to 112 expected. * WHERE...A portion of southwest California. * WHEN...For the Heat Adv…
  - (2026-08-25) [Moderate] Heat Advisory: Heat Advisory issued August 25 at 12:02AM PDT until August 25 at 10:00AM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...For the Heat Advisory, temperatures up to 95. For the Extreme Heat Warning, dangerously hot conditions with temperatures up to 102 expected. * WHERE...Catalina and Santa Barbara Islands, Los Angeles County Beach…
  - (2026-08-25) [Moderate] Heat Advisory: Heat Advisory issued August 25 at 12:02AM PDT until August 28 at 8:00PM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Temperatures up to 108 expected. * WHERE...San Luis Obispo County Interior Valleys, San Luis Obispo County Mountains, Santa Lucia Mountains, and Southern Salinas Valley. * WHEN...From 10 AM this morning to 8 PM…
  - (2026-08-25) [Severe] Extreme Heat Warning: Extreme Heat Warning issued August 25 at 12:02AM PDT until August 28 at 8:00PM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...For the Heat Advisory, temperatures up to 101. For the Extreme Heat Warning, dangerously hot conditions with temperatures up to 105 expected. * WHERE...Cuyama Valley. * WHEN...For the Heat Advisory, until 10 AM…

### Ukraine Theater (total-war monitoring) — 68 new of 233 total
  - (2026-08-25) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-24) [Liveuamap] The United Kingdom has approved the transfer of Storm Shadow technology to Ukraine for its own production. British Prime Minister Burnham announced this during a meeting of the Coalition o…
      The United Kingdom has approved the transfer of Storm Shadow technology to Ukraine for its own production. British Prime Minister Bu
  - (2016-07-28) [Liveuamap] Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com - Liveuamap
      Iran news on live map in English - War in Iran - Conflict in the Gulf- iran.liveuamap.com Liveuamap
  - (2016-04-27) [Liveuamap] Israel-Palestine - Liveuamap
      Israel-Palestine Liveuamap
  - (2016-05-01) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - iraq.liveuamap.com
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com iraq.liveuamap.com
  - (2026-08-24) [Liveuamap] Israeli forces arrest 11 citizens during raids and incursions into a number of West Bank cities at dawn today. - Liveuamap
      Israeli forces arrest 11 citizens during raids and incursions into a number of West Bank cities at d

### Ukrainian Internal News (national + local Kyiv) — 49 new of 102 total
  - (2026-08-25) Зеленський опулікував привітання Трампа з Днем Незалежності | LEDE: Президент Володимир Зеленський показав текст привітання з Днем Незалежності України, який він отримав від американського ліде] (uk:…
      Президент Володимир Зеленський показав текст привітання з Днем Незалежності України, який він отримав від американського лідера Дональда Трампа.
  - (2026-08-25) Нема в Брюсселі - нема взагалі: чому робота в Комітеті регіонів ЄС важлива для українських громад | LEDE: ] (uk: Нема в Брюсселі - нема взагалі: чому робота в Комітеті регіонів ЄС важлива для у)
  - (2026-08-25) "Став футболістом не заради Ferrari". Неймовірна історія найкращого гравця чемпіонату світу Родрі | LEDE: ] (uk: "Став футболістом не заради Ferrari". Неймовірна історія найкращого гравця чемпі)
  - (2026-08-25) Ексзаступницю голови ОП Мудру взяли під варту із заставою у 20 мільйонів | LEDE: Вищий антикорупційний суд обрав колишній заступниці керівника Офісу президента Ірині Мудрій запобіжний захід у в] (uk:…
      Вищий антикорупційний суд обрав колишній заступниці керівника Офісу президента Ірині Мудрій запобіжний захід у вигляді тримання під вартою з можливістю внесення 20 мільйонів гривень застави.
  - (2026-08-25) У Румунії підіймали винищувачі через повітряну ціль поблизу кордону | LEDE: ] (uk: У Румунії підіймали винищувачі через повітряну ціль поблизу кордону)
  - (2026-08-25) У Вірменії затримали експрезидента Кочаряна та його старшого сина у справі про корупцію | LEDE: Вірменська поліція затримала Роберта Кочаряна і його сина Седрака в рамках корупційного розслідув] (uk:…
      Вірменська поліція затримала Роберта Кочаряна і його сина Седрака в рамках корупційного розслідування.

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 55 total
  - (2026-08-25) [The Hacker News] Actively Exploited Oracle WebLogic Flaw Lets Unauthenticated Attackers Access Critical Data
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) on Monday added a maximum-severity security flaw impacting Oracle HTTP Server and Oracle WebLogic Server to its Known Exploited Vulnerabilities (KEV) catal…
  - (2026-08-25) [The Register] SpaceX claims it will put a Vera Rubin NVL72 rack-scale system into orbit next year
      And fly ‘significant scale’ in 2028 – a claim that isn’t entirely bonkers, but needs a solid grain of salt
  - (2026-08-25) [The Register] IBM announces chip that natively executes Arm and Z instructions concurrently
      Cunning plan to expand the amount of software that runs on mainframes is also an admission ISVs are focusing their energies elsewhere
  - (2026-08-25) [The Register] Microsoft AI watermarks in Paint and Photos are linked to user IDs, researcher finds
      Privacy? Not if you use hosted AI services
  - (2026-08-25) [TechCrunch] India’s Airbound bags $37M to take on trucks with rocket-like drones
      Airbound's ultra-lightweight approach to drone delivery has attracted backing from Greenoaks, DoorDash, and Silicon Valley investor Lachy Groom.
  - (2026-08-25) [TechCrunch] Situational Awareness, star AI hedge fund that nearly imploded, now being probed by the SEC
      The AI hedge fund went from "the talk of Wall Street" to "subject of federal subpoenas" faster than you can say "diversify your portfolio."

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-25) [Kapoor Rohit (RK2)] Form 4 (Reporting)
      filed 2026-08-25 01:58 UTC · role: Reporting — Filed: 2026-08-24 AccNo: 0001419945-26-000064 Size: 6 KB
  - (2026-08-25) [TEEKAY TANKERS LTD.] Form 4 (Issuer)
      filed 2026-08-25 01:58 UTC · role: Issuer — Filed: 2026-08-24 AccNo: 0001419945-26-000064 Size: 6 KB
  - (2026-08-25) [Seidelin Mikkel] Form 4 (Reporting)
      filed 2026-08-25 01:53 UTC · role: Reporting — Filed: 2026-08-24 AccNo: 0001419945-26-000062 Size: 6 KB
  - (2026-08-25) [TEEKAY TANKERS LTD.] Form 4 (Issuer)
      filed 2026-08-25 01:53 UTC · role: Issuer — Filed: 2026-08-24 AccNo: 0001419945-26-000062 Size: 6 KB
  - (2026-08-25) [Speers Brody] Form 4 (Reporting)
      filed 2026-08-25 01:46 UTC · role: Reporting — Filed: 2026-08-24 AccNo: 0001419945-26-000061 Size: 6 KB
  - (2026-08-25) [TEEKAY TANKERS LTD.] Form 4 (Issuer)
      filed 2026-08-25 01:46 UTC · role: Issuer — Filed: 2026-08-24 AccNo: 0001419945-26-000061 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 23 new of 60 total
  - (2026-08-24) U.S. Court of Appeals, 1st Cir.: Pereira Alves v. Blanche
  - (2026-08-24) U.S. Court of Appeals, 1st Cir.: United States v. Reynoso
  - (2026-08-24) U.S. Court of Appeals, 3rd Cir.: Jane Parkin v. Avis Rent a Car System LLC
  - (2026-08-24) U.S. Court of Appeals, 3rd Cir.: Roger Salvatora v. XTO Energy Inc
  - (2026-08-24) U.S. Court of Appeals, 9th Cir.: Kinnucan v. National Security Agency
  - (2026-08-24) U.S. Court of Appeals, 9th Cir.: United States v. Aguilera

### Government & military aircraft airborne (OpenSky) — 21 new of 21 total
  - (2026-08-25) JAF5PW (Bulgaria)
      icao24: 4520d0 · position: (47.2634, 0.9384) · alt: 7871m · 724km/h
  - (2026-08-25) JAF76T (Bulgaria)
      icao24: 4520aa · position: (47.8282, 1.2748) · alt: 5044m · 693km/h
  - (2026-08-25) SAMU05 (France)
      icao24: 39ca81 · position: (44.4539, 6.0157) · alt: 777m · 226km/h
  - (2026-08-25) GAF412 (Germany)
      icao24: 3ea1cc · position: (51.743, 9.6336) · alt: 6362m · 610km/h
  - (2026-08-25) GAF681 (Germany)
      icao24: 3e0f77 · position: (44.5303, 10.8617) · alt: 304m · 215km/h
  - (2026-08-25) GAF744 (Germany)
      icao24: 3f59f3 · position: (53.1046, 13.7478) · alt: 11285m · 900km/h

### Paper Trading Scorecard — 18 new of 126 total
  - (2026-08-25) [Polymarket] Clarity Act (H.R.3633) signed into law in 2026?
      This market will resolve to "Yes" if the Digital Asset Market Clarity Act of 2025 (H.R.3633) is passed by both chambers of the U.S. Congress and signed into law by December 31, 2026, 11:59 PM ET. Otherwise, this market w…
  - (2026-08-25) [Polymarket] Will the price of Bitcoin be above $76,000 on August 25?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-08-25) [Polymarket] Will Bitcoin dip to $62,500 in August?
      This market will resolve to "Yes" if any Binance 1 minute candle for BTC/USDT from the creation of this market through 11:59 PM ET on the last day of the month specified in the title has a final Low price equal to or low…
  - (2026-08-25) [Manifold] Daily Coinflip
  - (2026-08-25) [Manifold] Nick Walker Wins 2026 Mr. Olympia?
  - (2026-08-25) [Manifold] Natalie Harp births President Donald J. Trump's child by EOY 2028?

### U.S. Federal Action — 16 new of 19 total
  - (2026-08-25) Continuation of the Exercise of Certain Authorities Under the Trading With the Enemy Act
  - (2026-08-25) The National Space Transportation Policy
  - (2026-08-25) Establishment of Four Customs-Enforcement Areas
      This document sets forth the Commissioner of U.S. Customs and Border Protection's (CBP) declaration establishing four Customs- Enforcement Areas (CEA) in the near shore waters of South Florida, Central/Southern Californi…
  - (2026-08-25) Final Waiver and Extension of the Project Period With Funding-Elementary and Secondary Education Act of 1965, as Amended, Title VI, Part B, Native Hawaiian Education
      The Secretary waives the requirements in the Education Department General Administrative Regulations (EDGAR) that generally prohibit project period extensions involving the obligation of additional Federal funds. The fin…
  - (2026-08-25) Amendment of Restricted Areas R-2505, R-2524, R-2508, and R-2515 in California
      This action amends multiple coordinates used to describe restricted areas R-2505, R-2524, R-2508, and R-2515 in California. The amendments are administrative in nature and do not expand any outer boundaries, altitudes, t…
  - (2026-08-25) Reduction in Force Appeals; Correction
      The Office of Personnel Management (OPM) published a final rule in the Federal Register on August 3, 2026, concerning reduction in force appeals. That document contained typographical and citation errors in the regulator…

### USGS earthquakes (M4.5+, past day) — 16 new of 16 total
  - (2026-08-24) M 6.0 - 215 km NNE of Lospalos, Timor Leste
      M6.0 · 215 km NNE of Lospalos, Timor Leste · depth 10 km
  - (2026-08-25) M 5.5 - 108 km NE of Hengchun, Taiwan
      M5.5 · 108 km NE of Hengchun, Taiwan · depth 14.608 km
  - (2026-08-24) M 5.5 - 207 km SSE of Amahai, Indonesia
      M5.5 · 207 km SSE of Amahai, Indonesia · depth 10 km
  - (2026-08-24) M 5.0 - 209 km NNE of Lospalos, Timor Leste
      M5.0 · 209 km NNE of Lospalos, Timor Leste · depth 9.947 km
  - (2026-08-24) M 5.0 - southern Mid-Atlantic Ridge
      M5.0 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-08-25) M 4.9 - 4 km NNE of Jalālābād, Afghanistan
      M4.9 · 4 km NNE of Jalālābād, Afghanistan · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 12 new of 105 total
  - (2026-08-24) [OFAC] Removal of Syria's designation as a State Sponsor of Terrorism and Associated Sanctions List Updates - Office of Foreign Assets Control (.gov)
      Removal of Syria's designation as a State Sponsor of Terrorism and Associated Sanctions List Updates Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions | Office of Fore…
      Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions | Office of Foreign Assets Control Office o…
  - (2026-08-24) [OFAC] DETERMINATION PURSUANT TO SECTION 1(a)(i) OF EXECUTIVE ORDER 13902 Aviation, Digital Asset, Gold, Shipping, and Technology Sect - Office of Foreign Assets Control (.gov)
      DETERMINATION PURSUANT TO SECTION 1(a)(i) OF EXECUTIVE ORDER 13902 Aviation, Digital Asset, Gold, Shipping, and Technology Sect Office of Foreign Assets Control (.gov)
  - (2026-08-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Suspension of Certain Iranian Transactions and Sanctions Regulations General Licenses On August - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Suspension of Certain Iranian Transactions and Sanctions Regulations General Licenses On August Office of Foreign Assets Control (.gov)
  - (2026-08-24) [OFAC] Strait of Hormuz Toll Payments Alert Update - Office of Foreign Assets Control (.gov)
      Strait of Hormuz Toll Payments Alert Update Office of Foreign Assets Control (.gov)
  - (2026-08-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE BB Authorizing - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Iranian Transactions and Sanctions Regulations 31 CFR part 560 GENERAL LICENSE BB Authorizing Office of Foreign Assets Control (.gov)

### State Legislative Action — 11 new of 16 total
  - (2026-08-25) [Alaska HB 280] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and tele…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state, including the apportionment of income of broadcasters, financial institutions, and telecommunications service providers; an…
  - (2026-08-25) [Alaska HB 289] An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; an…
      An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; and providing for an effective date.
  - (2026-08-25) [Alaska HB 283] An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and provid…
      An Act making supplemental appropriations; making appropriations under art. IX, sec. 17(c), Constitution of the State of Alaska, from the constitutional budget reserve fund; and providing for an effective date.
  - (2026-08-24) [Alaska SB 9] An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
      An Act relating to the surrender of infants; relating to civil history; and providing for an effective date.
  - (2026-08-24) [Alaska SB 63] An Act relating to the Local Boundary Commission; and providing for an effective date.
      An Act relating to the Local Boundary Commission; and providing for an effective date.
  - (2026-08-24) [Alaska SB 158] An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.
      An Act relating to administrative areas for regulation of certain commercial set net entry permits; and providing for an effective date.

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-25) Will the Fed decrease interest rates by 50+ bps after the September 2026 meeting?
      yes price: 0% · 24h volume: $867,203 · resolves 2026-09-16
  - (2026-08-25) Will John Thune win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $469,547 · resolves 2028-11-07
  - (2026-08-25) Will Donald Trump publicly insult someone on August 23, 2026?
      yes price: 6% · 24h volume: $373,171 · resolves 2026-08-24
  - (2026-08-25) Will the Fed increase interest rates by 25 bps after the September 2026 meeting?
      yes price: 34% · 24h volume: $370,504 · resolves 2026-09-16
  - (2026-08-25) Will the Iranian regime fall before 2027?
      yes price: 8% · 24h volume: $361,886 · resolves 2026-12-31
  - (2026-08-25) Strait of Hormuz traffic returns to normal by August 31?
      yes price: 0% · 24h volume: $332,259 · resolves 2026-09-01

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-25) [Marginal Revolution] Do Minimum Wages Help Worker in Poor and Low-Income Families?
      We provide the first direct estimates of the effects of minimum wages on low-wage workers in families at different points of the distribution of income-to-needs, using data from the Survey of Income and Program Participa…
  - (2026-08-25) [Marginal Revolution] That was then, this is now
      In 1914 Yitzhak Ben-Zvi and David Ben-Gurion, the president and prime minister of Israel after 1948 respectively, were in the Ottoman capital studying law at Istanbul University. They had studied Ottoman Turkish and emba…
  - (2026-08-24) [Marginal Revolution] Common sense in charge
      …children are increasingly seen as interfering with the freedom of parents; views on whether mothers of young children should work have become markedly more progressive and account for a substantially larger share of the…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-08-24) CVE-2026-21962 · Oracle HTTP Server and Oracle Weblogic Server Proxy Plug-in: Oracle HTTP Server and Oracle Weblogic Server Proxy Plug-in Improper Access Control Vulnerability
      vendor: Oracle · product: HTTP Server and Oracle Weblogic Server Proxy Plug-in · CISA remediation by 2026-08-27

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=19, 7d-median=14, 14d-median=20; carrying terms: establish, proposes, certain, proposed, national, action, establishing, specifically, management, within, model, airworthiness
- state_bills: today=16, 7d-median=134, 14d-median=129; carrying terms: purposes, order, provided, within, every, health, licensure, relating, public, provides, violence, provisions
- state_news: today=452, 7d-median=597, 14d-median=591; carrying terms: company, black, safety, president, policy, montana, narrow, green, office, second, large, around
- local_news: today=228, 7d-median=235, 14d-median=228; carrying terms: people, alert, georgia, county, taken, students, court, august, officers, metro, camera, injured
- foreign_news: today=998, 7d-median=998, 14d-median=1002; carrying terms: almost, economy, speed, company, backs, yongning, staying, black, overseas, recital, changsha, index
- chinese_internal: today=276, 7d-median=284, 14d-median=274; carrying terms: people, cbmib, market, cbmiykfvx, chinese, cbmiakfvx, cbmiw, lxtfb, cbmibefvx, cbmiaefvx, cbmizefvx, caixin
- russian_internal: today=952, 7d-median=1030, 14d-median=1035; carrying terms: httperror, forbidden, novaya, times, wildberries, client, russian, novayagazeta, blank, media, found, https
- ukrainian_internal: today=102, 7d-median=114, 14d-median=112; carrying terms: years, httperror, black, ukraine, president, censor, increasingly, kyivindependent, energy, least, people, efforts
- ukraine_theater: today=233, 7d-median=834, 14d-median=985; carrying terms: tavlzflupendkxekxxdernatvqbxf, bvewqwsej, kzlgxundkagftsm, wdjoaznrndlxdtq, ektxwhblafvut, xzvlutntmejfshzxvv, ogridf, tlldbhpfuhfidtvmrg, dvllluxkd, technical, zrces, fpejviewphy
- paper_bets: today=126, 7d-median=131, 14d-median=137; carrying terms: prime, succeed, kansas, speed, alaska, become, colonize, humans, headline, president, pirates, house
- weather: today=143, 7d-median=145, 14d-median=172; carrying terms: portion, flooding, especially, synopsis, changed, watch, evening, index, streams, expected, depth, humidity
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: consumption, implied, cpilfesl, funds, nonfarm, personal, crude, unemployment, effective, pcepilfe, supply, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, nasdaq, equities, credit, russell, corporate, proxy, natural, treasury, silver, agriculture, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=105, 7d-median=100, 14d-median=96; carrying terms: portal, satisfying, response, measures, company, cyber, against, occupation, ukraine, development, laboratory, imposed
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, congresstrading, client, https, unauthorized, quiver, error, quantitative, quiverquant
- billionaires: today=0, 7d-median=34, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: company, supreme, court, state, appeals, connecticut, center, general, america, james, trust, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, accno, filed, vincent
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, sherrod, trone, raised, talarico, committee, ossoff, senate, booker, cortez, johnson, pinkston
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, korea, south, koreaherald
- gdelt_gkg: today=0, 7d-median=25, 14d-median=37; carrying terms: english, trump, hezbollah, keywords, israel, greek, business, israeli, travel, military, strikes, attacks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=27, 14d-median=30; carrying terms: belgium, position, ground, france, germany, kingdom, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: years, presented, activity, outbreak, passengers, response, september, inconclusive, toxin, vaccine, cvdpv, travel
- cisa_kev: today=13, 7d-median=12, 14d-median=10; carrying terms: authentication, vendor, metabase, inspection, product, injection, security, firewall, winsock, secure, command, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=315, 14d-median=315
- usgs_quakes: today=16, 7d-median=19, 14d-median=18; carrying terms: depth, indonesia, ruteng, japan, islands, philippines, region, tonga, ridge, guinea, papua, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, september, volume, league, championship, donetsk, august, champions, interest, shakhtar, rates, meeting
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, class, https, economist, revolution, marginal, conversableeconomist, impossible, wrote, around, because, point
- tech_news: today=55, 7d-median=55, 14d-median=56; carrying terms: development, schneier, attacks, companies, computerweekly, around, engineering, https, release, hackers, spectrum, bleepingcomputer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: byron, obernolte, justice, kansas, turner, mcconnell, sorensen, christopher, balart, staff, sheehy, guest
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, converges, consensus, identify, placed, evidence, placement, today, claude, either, market, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*