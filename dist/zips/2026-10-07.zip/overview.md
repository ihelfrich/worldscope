# WORLDSCOPE morning brief — 2026-10-07

## Headline
3806 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (829) · Russian Internal News (state + in-exile) (750) · Ukraine Theater (total-war monitoring) (542) · State-Level News (354) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (194) · Chinese Internal News (179) · U.S. Weather + Severe / Climate Outlooks (140) · State Legislative Action (106) · Ukrainian Internal News (national + local Kyiv) (70) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (43)

## What changed today
### International News + Multilateral Institutions — 829 new of 1034 total
  - (2026-10-07) [India] ‘She is 4 months pregnant’: Families search for loved ones after Delhi’s Seemapuri building collapse
  - (2026-10-07) [India] Delhi building collapse LIVE: 1 dead, 8 injured, resident says her sister called from under debris
  - (2026-10-07) [India] Two cheetahs from Kuno released in MP’s Veerangana Durgavati Tiger Reserve
  - (2026-10-07) [India] CJI Surya Kant set to attend NLSIU convocation weeks after row over proposed presence: Report
  - (2026-10-07) [India] ‘Op Dolphin’s Nose’ in 2019 and now ‘Op Firewall’: How India is busting Pakistani spy rings
  - (2026-10-07) [India] ‘Not conducive’: Centre opposes Balwant Rajoana’s death commutation plea in Supreme Court

### Russian Internal News (state + in-exile) — 750 new of 1229 total
  - (2026-10-07) Евросоюз согласовал самое масштабное расширение санкционного списка против России | LEDE: Послы стран Евросоюза договорились включить более 1500 физических и юридических лиц в санкционный сп] (ru: Евр…
      Послы стран Евросоюза договорились включить более 1500 физических и юридических лиц в санкционный список против России, сообщает Euronews.
  - (2026-10-07) Возможную вспышку чумы в России обсуждают по всему миру, а Трамп даже собрался позвонить по этому поводу Путину. Неужели все так серьезно? Объясняем коротко, почему повода для паники нет | LEDE] (ru:…
      Возможная вспышка чумы в РФ все чаще попадает в заголовки мировых СМИ и в поле зрения властей крупнейших стран. Президент США Дональд Трамп заявил, что собирается созвониться с Владимиром Путиным, чтобы получить от него…
  - (2026-10-07) Новосибирский Академгородок — одно из самых протестных мест в России. На избирательных участках там проигрывает Владимир Путин, а побеждают «Яблоко» и «Новые люди». Репортаж «7×7» | LEDE: На] (ru: Нов…
      На трех избирательных участках новосибирского Академгородка в 2026 году победил кандидат в Госдуму от «Яблока» Дмитрий Шабанов, а «Единая Россия» не заняла первого места по партийным спискам. Во время президентских выбор…
  - (2026-10-07) 7 октября. Три года. Жители Израиля рассказывают «Медузе», как эта террористическая атака — самая страшная в истории страны — изменила их самих и мир вокруг | LEDE: Нападение ХАМАС 7 октября] (ru: 7 о…
      Нападение ХАМАС 7 октября 2023 года — одно из самых страшных событий в новейшей истории мира. Накануне третьей годовщины «Медуза» поговорила с жителями Израиля, где эта террористическая атака коснулась каждого. Восемь че…
  - (2026-10-07) Российский суд оштрафовал Бориса Гребенщикова на 15 тысяч рублей за интервью «Медузе» | LEDE: Хорошевский районный суд Москвы выписал музыканту Борису Гребенщикову штраф 15 тысяч рублей по а] (ru: Рос…
      Хорошевский районный суд Москвы выписал музыканту Борису Гребенщикову штраф 15 тысяч рублей по административному протоколу об «участии в деятельности нежелательной организации» (статья 20.33 КоАП). Поводом для протокола,…
  - (2026-10-07) Bloomberg: Россия — после встречи Путина и Трампа — решила нарастить расходы на войну | LEDE: В конце 2025 года Владимир Путин распорядился резко увеличить расходы на войну с Украиной, пишет] (ru: Blo…
      В конце 2025 года Владимир Путин распорядился резко увеличить расходы на войну с Украиной, пишет Bloomberg. По словам источников, триггером послужила его встреча с президентом США Дональдом Трампом на Аляске в августе 20…

### Ukraine Theater (total-war monitoring) — 542 new of 735 total
  - (2026-10-07) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-06) [FIRMS] thermal anomaly 44.914, 22.499 (FRP 2.05 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-06 0041Z, FRP 2.05 MW
  - (2026-10-06) [FIRMS] thermal anomaly 44.914, 22.494 (FRP 2.05 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-06 0041Z, FRP 2.05 MW
  - (2026-10-06) [FIRMS] thermal anomaly 44.910, 22.503 (FRP 2.62 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-06 0041Z, FRP 2.62 MW
  - (2026-10-06) [FIRMS] thermal anomaly 44.913, 22.484 (FRP 0.6 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-06 0041Z, FRP 0.6 MW
  - (2026-10-06) [FIRMS] thermal anomaly 44.912, 22.489 (FRP 1.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-06 0041Z, FRP 1.15 MW

### State-Level News — 354 new of 732 total
  - (2026-10-06) [Alabama] Flags Lowered Honoring Former State Representative Bobby Mac Junkins
      Download
  - (2026-10-06) [California] California reminds voters to check their mailboxes and return their ballot ASAP!
      Source
  - (2026-10-06) [California] Governor Gavin Newsom statement on Donald Trump’s disgusting and disqualifying comments
      Source
  - (2026-10-07) [California] Toward a people-centered agenda
      <img width="1024" height="576" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/LEDE_civic-engagement-agenda-scaled.png?fit=1024%2C576&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-10-07) [California] Why you’re voting on how medical clinics spend their money
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/062625-Medical-Clinic-AP-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-10-07) [California] Why are out-of-state billionaires funding a California voter ID measure?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/092926-Winklevoss-and-Uihlein-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 194 new of 242 total
  - (2026-10-07) [St. Louis] Can you put appliqués on walls? A St. Louis textiles expert weighs in
      During a recent visit to the KDR Designer Showroom in St. Louis, I picked up a catalog of Samuel & Sons’ fall 2026 collection. The luxury passementerie company, which sells decorative trims such as tassels, cords and fri…
  - (2026-10-07) [St. Louis] Some St. Louisans are quietly preparing for the next big disaster—and smaller ones, too
      There’s a group of around 20 people who, this fall, will spread out around St. Louis with more know-how in applying tourniquets, providing first aid, and taking action in the wake of immediate trauma. When the next storm…
  - (2026-10-07) [St. Louis] Libertarians blast Republican calls to drop out in tight Missouri House races
      Libertarians in several key races for the Missouri House say they’ve heard from Republican leaders suggesting they should drop out. That could indicate that the GOP is worried that November’s elections will be tight. It…
  - (2026-10-07) [St. Louis] FUFU n’ Sauce owner Adjo Honsou is serving a market she never envisioned
      When Adjo Honsou decided to take a leap and open a FUFU n’ Sauce restaurant last June, she was sure the people who came to know the brand as a food truck would follow. But the dynamic purveyor of West African culture and…
  - (2026-10-07) [St. Louis] Top things to do in St. Louis this weekend: October 9–11
      See Also:Best of Missouri Market @ Missouri Botanical GardenHistoric Shaw Art FairSteve Martin and Martin Short @ Fox TheatreLittle Big Town @ Stifel TheatreLittle River Band @ The FactoryBig Head Todd & The Monsters @ T…
  - (2026-10-06) [St. Louis] St. Louis CITY SC is one result away from MLS history
      Last Wednesday, St. Louis CITY SC beat Red Bull New York 3-0 to extend the club’s unbeaten run to 19 matches across all competitions. CITY is now on the verge of Major League Soccer history. As CITY manager Yoann Damet s…

### Chinese Internal News — 179 new of 253 total
  - (2026-10-06) 知名科普博主洪广玉被刑拘 曾参与大连樱桃种植户维权活动 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBFUDVvaVV4YUV4UkFtblBYODZBWmIzVDE1dTJpYTk2WHNLMWI1aHUyc1c4QWhRVkZJZF9HMlZzX01SZW8ybVk3MUJxZV] (zh:…
      知名科普博主洪广玉被刑拘 曾参与大连樱桃种植户维权活动 财新
  - (2026-10-06) 比利时裔美国粒子物理学家获诺贝尔物理学奖 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFB6YjdER0VaRVpBNTFQTkFlMzI1WkZQMzFLYURicTllYTVwQTY0U1A4VW5HNHNFQ2piWXRJNzFZNVFuREVhaC15My1MS21lRTNVb] (zh:…
      比利时裔美国粒子物理学家获诺贝尔物理学奖 财新
  - (2026-10-05) 缅北果敢电诈家族覆灭详情公布 “佤联军”副总司令鲍军峰在昆明落网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBsTm40RkI4RkxKdDZPRUZKNXRZbEJFZUExQWhEUHJKRUpPYXMxM3c3N1lMUEx3cHBjZzhRd0Y4UUJMYzdoV1Fnb] (zh:…
      缅北果敢电诈家族覆灭详情公布 “佤联军”副总司令鲍军峰在昆明落网 财新
  - (2026-10-06) 系统性发展电诈金主 果敢白家从兴起到末路 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBwbHVYblR5YzJIVkZoNUV5R1RXeC13SkhzVDlXeFl0VERfa0VMQndTQ1p6aHRfUG8xSkpVR28xd2RYejZwYWZIQ2JmbHl4VWlzT] (zh:…
      系统性发展电诈金主 果敢白家从兴起到末路 财新
  - (2026-10-05) 大西洋观察｜法律与秩序：新时代的选战话术 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBEZzFWb3N5ZXlCNlc0N0hoZ2lReFlWQUZyaE1QajljZGFHNHdXVDFjV2FRRXFjb1pwYUczem54bkI1SzlMajNGcEV5eDA3NnpCc] (zh:…
      大西洋观察｜法律与秩序：新时代的选战话术 财新
  - (2026-10-07) 【商圈】放弃大模型 克里希纳能否带领IBM完成大象转身？ - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE05OWI5NjVoUDFEdkRUQ0Y0Vjd5UXQySjYxYjVrM0s2U3JnYV9HLXhyRTI4THR2LTZNYnNHRFNnZ0xUeXhRZXFsS2x] (zh:…
      【商圈】放弃大模型 克里希纳能否带领IBM完成大象转身？ 财新数据

### U.S. Weather + Severe / Climate Outlooks — 140 new of 141 total
  - (2026-10-07) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-07) [Severe] High Wind Warning: High Wind Warning issued October 7 at 5:23AM AKDT until October 8 at 4:00AM AKDT by NWS Anchorage AK
      * WHAT...South winds 40 to 60 mph with gusts up to 80 mph. Strongest winds will be in Adak. * WHERE...Atka and Adak. * WHEN...From 5 PM this afternoon to 4 AM AKDT Thursday. * IMPACTS...High winds may move loose debris,…
  - (2026-10-07) [Severe] High Wind Warning: High Wind Warning issued October 7 at 5:23AM AKDT until October 8 at 4:00AM AKDT by NWS Anchorage AK
      * WHAT...Southeasterly winds 40 to 50 mph with gust up to 75 mph in the morning. Then, winds shift westerly, increasing to 50 to 60 mph with gusts up to 75 mph. * WHERE...Shemya. * WHEN...From 1 PM this afternoon to 4 AM…
  - (2026-10-07) [Moderate] Wind Advisory: Wind Advisory issued October 7 at 5:23AM AKDT until October 9 at 1:00AM AKDT by NWS Anchorage AK
      * WHAT...Southeasterly winds 30 to 40 mph with gusts up to 55 mph expected. * WHERE...Kuskokwim Delta Coast and Nunivak Island. * WHEN...From 8 AM Thursday to 1 AM AKDT Friday. * IMPACTS...Gusty winds will blow around un…
  - (2026-10-07) [Moderate] Wind Advisory: Wind Advisory issued October 7 at 5:23AM AKDT until October 8 at 1:00PM AKDT by NWS Anchorage AK
      * WHAT...South winds 35 to 45 mph with gusts up to 55 mph expected in Unalaska. * WHERE...Unalaska and Dutch Harbor. * WHEN...From 5 AM to 1 PM AKDT Thursday. * IMPACTS...Gusty winds will blow around unsecured objects an…
  - (2026-10-07) [Severe] High Wind Watch: High Wind Watch issued October 7 at 5:23AM AKDT until October 8 at 10:00AM AKDT by NWS Anchorage AK
      * WHAT...South winds 40 to 50 mph with gusts up to 75 mph possible. * WHERE...Pribilof Islands. * WHEN...From late tonight through Thursday morning. * IMPACTS...High winds could move loose debris, damage property, and ca…

### State Legislative Action — 106 new of 157 total
  - (2026-10-07) [Alaska SB 204] An Act relating to substitute teaching; and relating to the qualifications of school board members.
      An Act relating to substitute teaching; and relating to the qualifications of school board members.
  - (2026-10-07) [Alaska SB 287] An Act establishing the Joint Legislative Alaska Native Languages Academic Task Force.
      An Act establishing the Joint Legislative Alaska Native Languages Academic Task Force.
  - (2026-10-07) [Alaska SB 289] An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating…
      An Act relating to elections; relating to voters; relating to voting; relating to voter registration; relating to election administration; relating to campaign contributions; relating to write-in candidates for President…
  - (2026-10-06) [Alaska SB 41] An Act relating to mental health education.
      An Act relating to mental health education.
  - (2026-10-06) [Alaska SB 130] An Act relating to the fisheries product development tax credit; providing for an effective date by amending the effective date of sec. 2, ch. 31, SLA 2022; and providing for an effect…
      An Act relating to the fisheries product development tax credit; providing for an effective date by amending the effective date of sec. 2, ch. 31, SLA 2022; and providing for an effective date.
  - (2026-10-06) [Alaska HB 284] An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs…
      An Act relating to the Multistate Tax Compact; relating to apportionment of income to the state; establishing a state sales and use tax; relating to taxes levied by cities and boroughs; relating to the corporate income t…

### Ukrainian Internal News (national + local Kyiv) — 70 new of 137 total
  - (2026-10-07) ЗМІ: Детективи НАБУ прийшли з обшуком до департаменту містобудування Миколаївської ОВА | LEDE: Кореспондентка місцевого видання "МикВісті" повідомила, що 7 жовтня детективи НАБУ проводять обшук] (uk:…
      Кореспондентка місцевого видання "МикВісті" повідомила, що 7 жовтня детективи НАБУ проводять обшук у Департаменті містобудування, архітектури, капітального будівництва та супроводження проєктів розвитку Миколаївської ОВА…
  - (2026-10-07) Угорщина повідомила ЄС про намір надавати захист військовозобов'язаним з України | LEDE: Угорщина повідомила Європейській комісії про те, що вона не виконуватиме директиву ЄС про тимчасовий зах] (uk:…
      Угорщина повідомила Європейській комісії про те, що вона не виконуватиме директиву ЄС про тимчасовий захист у частині заборони надання захисту особам, які мають невиконаний військовий обовʼязок перед Україною.
  - (2026-10-07) Причина не лише в біженцях. Чому зростає напруга у відносинах поляків та українців | LEDE: ] (uk: Причина не лише в біженцях. Чому зростає напруга у відносинах поляків та українц)
  - (2026-10-07) Лише 9% поляків хочуть швидкого вступу України до ЄС. Що сталося з "братерством" за чотири роки | LEDE: У 2026 році відносини Польщі та України ускладнилися. Причини: біженці, суперечки через Є] (uk:…
      У 2026 році відносини Польщі та України ускладнилися. Причини: біженці, суперечки через ЄС, історичні питання, зростання випадків нападів на українців.
  - (2026-10-07) В Ердогана розповіли про його розмову з Путіним щодо безпеки судноплавства в Чорному морі | LEDE: Президент Туреччини Реджеп Ердоган під час телефонної розмови з лідером РФ Володимиром Путіним ] (uk:…
      Президент Туреччини Реджеп Ердоган під час телефонної розмови з лідером РФ Володимиром Путіним наголосив на важливості зусиль для безпеки судноплавства в Чорному морі та заявив про готовність сприяти прямим контактам між…
  - (2026-10-07) В Азербайджані заперечили зв’язок зі справою ексглави німецької розвідки | LEDE: Рада з питань ЗМІ та телерадіомовлення Азербайджану заперечила повідомлення про те, що колишній керівник німецьк] (uk:…
      Рада з питань ЗМІ та телерадіомовлення Азербайджану заперечила повідомлення про те, що колишній керівник німецької розвідки Август Ганнінг міг передавати секретні документи азербайджанському агенту.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-10-07) U.S. Court of Appeals, 2nd Cir.: Skolarus v. Bloomberg, L.P.
  - (2026-10-06) U.S. Court of Appeals, 3rd Cir.: United States v. Charles Summers
  - (2026-10-06) U.S. Court of Appeals, 10th Cir.: United States v. Wahhaj (Siraj Ibn)
  - (2026-10-06) U.S. Court of Appeals, 9th Cir.: Roe v. Petersen
  - (2026-10-06) U.S. Court of Appeals, 5th Cir.: In Re: Jamaal Howard
  - (2026-10-06) U.S. Court of Appeals, 5th Cir.: Parish of Cameron v. Devon Energy

### IT, InfoSys & cybersecurity news (last 7 days) — 43 new of 59 total
  - (2026-10-07) [Krebs on Security] ShinyHunters Extorted Boeing Spin-off Prior to Arrests
      A teenager from Amman, Jordan suspected of leading the prolific data theft and extortion group ShinyHunters has been detained and is reportedly cooperating with the FBI to identify other members of the hacking gang. Kreb…
  - (2026-10-07) [BleepingComputer] Ransomware has a new target. Is your backup ready?
      Ransomware groups are increasingly targeting backup infrastructure to eliminate recovery options and increase pressure on victims to pay. Kaseya explains why organizations need isolated, immutable, and regularly tested b…
  - (2026-10-07) [BleepingComputer] Hackers exploit critical Atlassian flaw after public PoC release
      A critical vulnerability (CVE-2026-21589) affecting multiple Atlassian product families, including Jira, Confluence, and Bitbucket, is being exploited in attacks that do not require authentication. [...]
  - (2026-10-07) [BleepingComputer] SonicWall warns of max severity SSRF flaw in SMA1000 gateways
      SonicWall has released hotfixes to address a maximum-severity server-side request forgery (SSRF) flaw in SMA1000 series appliances. [...]
  - (2026-10-07) [BleepingComputer] Musician sent to prison for $10 million streaming fraud using AI bots
      A North Carolina musician was sentenced to 18 months in prison for collecting more than $10 million in royalties from Spotify, Apple Music, Amazon Music, and YouTube Music in a massive streaming royalty fraud scheme. [..…
  - (2026-10-07) [BleepingComputer] Advantest confirms personal information stolen in ransomware attack
      Advantest Corporation is notifying affected individuals that a ransomware attack earlier this year exposed their personally identifiable data. [...]

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-07) [Star Bulk Carriers Corp.] Form 4 (Issuer)
      filed 2026-10-07 14:08 UTC · role: Issuer — Filed: 2026-10-07 AccNo: 0001333848-26-000005 Size: 5 KB
  - (2026-10-07) [Erhardt Koert] Form 4 (Reporting)
      filed 2026-10-07 14:08 UTC · role: Reporting — Filed: 2026-10-07 AccNo: 0001333848-26-000005 Size: 5 KB
  - (2026-10-07) 485BXT - Kurv ETF Trust (0001782952) (Filer)
      filed 2026-10-07 14:07 UTC — Filed: 2026-10-07 AccNo: 0001999371-26-022296 Size: 30 KB
  - (2026-10-07) 485BXT - Kurv ETF Trust (0001782952) (Filer)
      filed 2026-10-07 14:07 UTC — Filed: 2026-10-07 AccNo: 0001999371-26-022296 Size: 30 KB
  - (2026-10-07) 485BPOS - Nationwide VL Separate Account-G (0001313581) (Filer)
      filed 2026-10-07 14:06 UTC — Filed: 2026-10-07 AccNo: 0001193125-26-416318 Size: 1 MB
  - (2026-10-07) 485BPOS - Nationwide VL Separate Account-G (0001313581) (Filer)
      filed 2026-10-07 14:06 UTC — Filed: 2026-10-07 AccNo: 0001193125-26-416318 Size: 1 MB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 29 new of 130 total
  - (2026-10-07) [Polymarket] Will OpenAI’s market cap be $1.5T or greater at market close on IPO day by December 31, 2027?
      This market will resolve based on OpenAI's market capitalization at the closing price on its first day of trading. If no IPO occurs by December 31, 2027, 11:59 PM ET, the market will resolve to "No IPO by December 31, 20…
  - (2026-10-07) [Manifold] OpenAI's proof of zero free region of Riemann zeta for Re(s)>7/8 shown to be flawed before 2027?
  - (2026-10-07) [Manifold] Will 30-year treasury yields go above 6% before 2027?
  - (2026-10-07) [Manifold] Daily Coinflip
  - (2026-10-07) [Manifold] Will there be a "Gentle Singularity"?
  - (2026-10-07) [Manifold] Will John Fetterman endorse a Republican before election day?

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-10-07) PAT455 (United States)
      icao24: adfeda · position: (42.7163, -74.1799) · alt: 3009m · 347km/h
  - (2026-10-07) CFC3370 (Canada)
      icao24: c2b37d · position: (32.2957, -79.9246) · alt: 6065m · 779km/h
  - (2026-10-07) PAT942 (United States)
      icao24: adfe53 · position: (43.2993, -94.6872) · alt: 7315m · 515km/h
  - (2026-10-07) PAT011 (United States)
      icao24: adfe94 · position: (33.8025, -118.2276) · alt: 1844m · 444km/h
  - (2026-10-07) PAT748 (United States)
      icao24: adfe8d · position: (36.0729, -83.8792) · alt: 1432m · 410km/h
  - (2026-10-07) CFC3701 (Canada)
      icao24: c2c1f1 · position: (47.3355, -82.5331) · alt: 10972m · 756km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-10-06) [Taiwan Strait + South China Sea · themes] Editorial : As election nears , Healey suddenly peddling natural gas – Lowell Sun
      lowellsun.com · English · tone NA
  - (2026-10-06) [Taiwan Strait + South China Sea · themes] Drony uderzyły w 2 statki na Morzu Czarnym . Bułgaria informuje o ataku
      bankier.pl · Polish · tone NA
  - (2026-10-06) [Taiwan Strait + South China Sea · themes] Hà Tĩnh thông tin liên quan hiện tượng cá chết rải rác trên vùng biển
      baophapluat.vn · Vietnamese · tone NA
  - (2026-10-06) [Taiwan Strait + South China Sea · themes] Saudi - backed Yemen forces intensify strike against Houthis - News Today
      newstodaynet.com · English · tone NA
  - (2026-10-06) [Taiwan Strait + South China Sea · themes] One WhatsApp message can summon help : Odisha Ama Rasta goes live - Pragativadi I Latest Odisha News in English I Breaking News
      pragativadi.com · English · tone NA
  - (2026-10-06) [Taiwan Strait + South China Sea · themes] Guerre en Ukraine . Attaque de drones près de Moscou , marins et civils tués … Le point sur la nuit
      toulon.maville.com · French · tone NA

### USGS earthquakes (M4.5+, past day) — 18 new of 18 total
  - (2026-10-06) M 5.9 - 264 km SSW of Severo-Kuril’sk, Russia
      M5.9 · 264 km SSW of Severo-Kuril’sk, Russia · depth 26.047 km
  - (2026-10-06) M 5.5 - 92 km NNW of Aleneva, Alaska
      M5.5 · 92 km NNW of Aleneva, Alaska · depth 87.6 km
  - (2026-10-06) M 5.1 - 34 km NNW of Bāgeshwar, India
      M5.1 · 34 km NNW of Bāgeshwar, India · depth 10 km
  - (2026-10-07) M 4.9 - 80 km SW of El Arenal, Mexico
      M4.9 · 80 km SW of El Arenal, Mexico · depth 61.654 km
  - (2026-10-07) M 4.9 - South Sandwich Islands region
      M4.9 · South Sandwich Islands region · depth 10 km
  - (2026-10-06) M 4.9 - 189 km SW of Abepura, Indonesia
      M4.9 · 189 km SW of Abepura, Indonesia · depth 80.203 km

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 111 total
  - (2026-10-01) [OFAC] 831 - Office of Foreign Assets Control (.gov)
      831 Office of Foreign Assets Control (.gov)
  - (2026-10-07) [USASpending] $1,657,305,176 → IDAHO ENVIRONMENTAL COALITION LLC: THE PURPOSE OF THIS ACTION IS TO AWARD THE ICP TEN YEAR PLAN
      Agency: Department of Energy. Description: THE PURPOSE OF THIS ACTION IS TO AWARD THE ICP TEN YEAR PLAN HYBRID TASK ORDER UNDER SINGLE AWARD MASTER IDIQ CONTRACT 89303321DEM000061. CLIN 05 S1W D&D IS INCLUDED WITH AUTHOR…
  - (2026-10-07) [USASpending] $1,570,962,676 → AT&T ENTERPRISES, LLC: ENTERPRISE DATA NETWORK SERVICES CARRIER B
      Agency: Department of Veterans Affairs. Description: ENTERPRISE DATA NETWORK SERVICES CARRIER B
  - (2026-10-07) [USASpending] $1,505,648,979 → ACCENTURE FEDERAL SERVICES LLC: IGF::CL::IGF - TIVOD SUPPORTS THE ORIGINATION, DISBURSEMENT,
      Agency: Department of Education. Description: IGF::CL::IGF - TIVOD SUPPORTS THE ORIGINATION, DISBURSEMENT, AND REPORTING OF TITLE IV FEDERAL STUDENT AID PROGRAMS, INCLUDING - BUT NOT LIMITED TO - DIRECT LOANS, PELL GRANT…
  - (2026-10-07) [USASpending] $1,291,222,928 → BOOZ ALLEN HAMILTON INC: TASK ORDER AWARD
      Agency: General Services Administration. Description: TASK ORDER AWARD
  - (2026-10-07) [USASpending] $1,031,809,186 → LEIDOS, INC.: THE PURPOSE OF THIS TO IS TO PROVIDE RESEARCH, DESIGN, DEVEL
      Agency: General Services Administration. Description: THE PURPOSE OF THIS TO IS TO PROVIDE RESEARCH, DESIGN, DEVELOPMENT, INTEGRATION, T&E, INITIAL FIELDING AND OPERATION, LOGISTICS, MAINTENANCE, SUSTAINMENT, AND TRAININ…

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-10-07) Will Raphael Warnock win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $886,150 · resolves 2028-11-08
  - (2026-10-07) Counter-Strike: FURIA vs 9z (BO3) - ESL Pro League Group Stage
      yes price: 100% · 24h volume: $746,746 · resolves 2026-10-07
  - (2026-10-07) Shanghai Rolex Masters: Arthur Fery vs Marin Cilic
      yes price: 100% · 24h volume: $584,749 · resolves 2026-10-14
  - (2026-10-07) Will Elon Musk post <40 tweets from October 5 to October 7, 2026?
      yes price: 0% · 24h volume: $584,584 · resolves 2026-10-07
  - (2026-10-07) Counter-Strike: PARIVISION vs Natus Vincere (BO3) - ESL Pro League Group Stage
      yes price: 34% · 24h volume: $444,176 · resolves 2026-10-07
  - (2026-10-07) Will François Asselineau win the 2027 French presidential election?
      yes price: 0% · 24h volume: $358,189 · resolves 2027-04-19

### U.S. Federal Action — 11 new of 21 total
  - (2026-10-07) National Manufacturing Day, 2026
  - (2026-10-07) Approval and Promulgation of State Air Quality Plans for Designated Facilities and Pollutants; West Virginia; Negative Declarations for Existing Large Municipal Waste Combustors and Other Solid Waste…
      The Environmental Protection Agency (EPA) is proposing to approve the negative declarations submitted by the West Virginia Department of Environmental Protection (WVDEP) on July 13, 2026. The negative declarations submit…
  - (2026-10-07) Drawbridge Operation Regulation; Bay St. Louis, Bay St. Louis, MS; Back Bay of Biloxi, Biloxi, MS; Pascagoula River, Pascagoula, MS; Three Mile Creek, Mobile, AL; Chickasaw Creek, Saraland, AL.
      The Coast Guard proposes to change the operating procedures governing the five CSX Transportation drawbridges across Bay St. Louis, Bay St. Louis, MS; Back Bay of Biloxi, Biloxi, MS; Pascagoula River, Pascagoula, MS; Thr…
  - (2026-10-07) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is revising a notice of proposed rulemaking (NPRM) to supersede Airworthiness Directive (AD) 2014-16-22 and AD 2017-25-13, which apply to certain Airbus SAS Model A330-200, A330-200 Freighter, A330-300, A340-200,…
  - (2026-10-07) Privacy Act of 1974; Implementation
      In the Notice section of today's Federal Register, the Office of the Pardon Attorney (PARDON), a component within the United States Department of Justice (DOJ or Department), has published a notice of a new system of rec…
  - (2026-10-07) Statements of General Policy or Interpretation Not Directly Related to Regulations; Withdrawal of Proposed Rule
      The Department of Labor (Department) is withdrawing its notice of proposed rulemaking (NPRM) published on July 2, 2025 (90 FR 28985), which proposed to remove parts located in Title 29, Chapter V, Subchapter B of the Cod…

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-07) [Marginal Revolution] Against Laissez-Faire Democracy
      In a new paper, Brennan and Freiman argue persuasively that: the arguments against laissez-faire capitalism apply in a rather straight way against laissez-faire democracy. This should be a rather startling result, consid…
  - (2026-10-07) [Marginal Revolution] Texas-Canada Fact of the Day
      Texas produces more than Canada with three quarters of the population. Rough numbers for 2025: Texas Canada Texas / Canada Population 31.7 million 41.7 million 0.76 GDP, nominal (US$) $2.9 trillion $2.3 trillion 1.27 GDP…
  - (2026-10-07) [Marginal Revolution] Why most stereotypes are negative
      Stereotypes are a foundational construct in psychological science, often defined as beliefs concerning characteristic group attributes. We present a cognitive-ecological theory of social perception that predicts and expl…
  - (2026-10-06) [Conversable Economist] The Challenge of US Rural Development
      The first challenge of discussing US rural areas is to define them. I remember once reading a poetic definition that a rural area is a place where the shape of the land matters. But the US Census takes a different approa…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-07) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=26, 14d-median=21; carrying terms: proposed, within, certain, procedures, final, rulemaking, program, action, state, regulatory, information, issued
- state_bills: today=157, 7d-median=108, 14d-median=111; carrying terms: public, development, legislature, service, contracts, based, defined, subject, committee, county, enforcement, adopt
- state_news: today=732, 7d-median=698, 14d-median=698; carrying terms: million, different, allow, another, development, available, reports, service, based, president, along, start
- local_news: today=242, 7d-median=225, 14d-median=227; carrying terms: million, blank, county, atlantamagazine, being, games, articles, color, major, target, dining, state
- foreign_news: today=1034, 7d-median=1012, 14d-median=1018; carrying terms: union, another, elpais, reports, service, cooperation, president, strategy, start, intelligence, fears, money
- chinese_internal: today=253, 7d-median=253, 14d-median=265; carrying terms: cbmizefvx, blank, cbmib, china, cbmibefvx, cbmidefvx, articles, investors, color, cbmia, target, cbmickfvx
- russian_internal: today=1229, 7d-median=1054, 14d-median=1049; carrying terms: forbidden, openai, axios, client, error, title, telegram, blank, russian, novayagazeta, politico, httperror
- ukrainian_internal: today=137, 7d-median=133, 14d-median=131; carrying terms: million, plans, vechirniy, reports, forces, president, poland, intelligence, capital, building, including, potential
- ukraine_theater: today=735, 7d-median=564, 14d-median=514; carrying terms: eldcqi, yldzq, zvpinmxzb, holodomor, zxpqcwt, cbmiu, alrvszbr, methodius, uenazzngsjd, lxtfbwsdzsovrqz, maintenance, service
- paper_bets: today=130, 7d-median=123, 14d-median=122; carrying terms: court, romania, colonize, achieved, party, industrial, growth, leaders, netanyahu, problem, fusion, majors
- weather: today=141, 7d-median=141, 14d-median=144; carrying terms: unknown, beaches, vessels, around, average, saturday, flooding, morning, night, afdilx, short, north
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: balance, assets, dcoilwtico, cpilfesl, money, sheet, dexjpus, treasury, dexchus, dexuseu, unrate, total
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: futures, china, yield, proxy, credit, large, agriculture, corporate, crude, treasury, nasdaq, range
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=111, 7d-median=121, 14d-median=111; carrying terms: union, illegal, guatemala, entities, square, public, cbmizefvx, african, against, effects, sevastopol, development
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quiver, unauthorized, quiverquant, congresstrading, quantitative, https, httperror, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, union, supreme, corporation, appeals, mason, national, company, state, international, connecticut, phillips
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, filer, holdings, financial, trust, finance, america, jpmorgan, chase
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cortez, michael, ossoff, cycle, talarico, ocasio, james, sherrod, alexandria, trone, receipts, brown
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=25, 7d-median=49, 14d-median=50; carrying terms: english, russian, ukraine, china, themes, taiwan, vietnamese, romanian, french, south, death, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: english, kingdom, india, language, philippines, domain, court, israel, finanznachrichten, germany, ahead, election
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, canada, germany, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: mortality, sustained, confirmed, social, unknown, death, person, different, known, kinshasa, inconclusive, recombination
- cisa_kev: today=13, 7d-median=17, 14d-median=18; carrying terms: input, vendor, traversal, cisco, buffer, incorrect, multiple, products, write, product, vulnerability, authorization
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=18, 7d-median=14, 14d-median=16; carrying terms: depth, indonesia, islands, region, south, japan, russia, caledonia, tadine, china, zealand, sandwich
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: shakhtar, league, volume, champions, price, resolves, championship, donetsk, october, group, rates, strike
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, economist, conversableeconomist, revolution, marginal, conversable, https, basic, taxes, income, property, spending
- tech_news: today=59, 7d-median=57, 14d-median=57; carrying terms: download, intelligence, techcrunch, using, infrastructure, surveillance, weekly, attacks, technology, openai, spectrum, users
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: harshbarger, white, desaulnier, william, hillary, whitesides, ciscomani, daines, chicago, bryan, union, laurel
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, module, evidence, markets, converges, paper, sufficient, consensus, placement, unavailable, placed, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-29] Fed speeches: Bowman, Opening Remarks
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-30] Fed speeches: Cook, The Dual Mandate in Rural America
- [2026-10-01] Fed speeches: Waller, The Data Version of Godzilla versus Kong: FRED Takes on AI
- [2026-10-01] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-10-01] Fed speeches: Jefferson, The U.S. Economy and Monetary Policy
- [2026-10-01] Fed speeches: Bowman, Modernizing Financial Regulation: Initial Observations from eSLR
- [2026-10-02] ECB press: Boris Vujčić: Resilience, integration and competitiveness: building the future of European banking
- [2026-10-02] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-05] ECB press: Philip R. Lane: Diagnostic Challenges for ECB Monetary Policy
- [2026-10-06] ECB press: Philip R. Lane: Interview with Ansa
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*