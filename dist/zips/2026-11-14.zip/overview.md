# WORLDSCOPE morning brief — 2026-11-14

## Headline
3585 new items across 31 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (775) · Russian Internal News (state + in-exile) (599) · State-Level News (369) · World leaders & government officials (324) · Chinese Internal News (253) · Local News: St. Louis + Atlanta (231) · U.S. Weather + Severe / Climate Outlooks (137) · GDELT GKG — themes / entities / watch areas (118) · Ukraine Theater (total-war monitoring) (101) · World News (by country, top stories) (101) · GDACS — global disaster alerts (83) · State Legislative Action (77)

## What changed today
### International News + Multilateral Institutions — 775 new of 977 total
  - (2026-11-14) [Global] The ANC’s implosion was decades in the making
      Zuma squandered Mbeki’s gains, while Ramaphosa’s dithering turned the ANC’s promised renewal into a fight for survival.
  - (2026-11-14) [Global] Southeast Asian leaders to meet as Trump visit highlights trade disruption
      ASEAN summit comes as US president embarks on Asia trip that will see him meet China's Xi.
  - (2026-11-14) [Global] Ukraine is running out of options, and Russia knows it
      The Abu Dhabi talks reveal Moscow’s growing leverage over Ukraine and a shifting Western approach to peace.
  - (2026-11-14) [Global] Salah breaks Egypt scoring record, Tunisia lose to Libya in AFCON qualifier
      Salah scored twice to take his international tally to 70 ​and surpass former captain Hossam Hassan’s record.
  - (2026-11-14) [Global] Philippine court orders arrest of jailed, US-wanted celebrity preacher
      Palace denies timing of warrant is linked to Trump’s visit to Manila next week.
  - (2026-11-14) [Global] Siege fuels disease fears in Yemen’s Taiz
      Health officials warn that falling numbers of recorded infections may conceal a worsening disease crisis in Taiz.

### Russian Internal News (state + in-exile) — 599 new of 938 total
  - (2026-11-14) Путин помиловал блогера Лерчек | LEDE: Президент России Владимир Путин подписал указ о помиловании блогера Валерии Чекалиной (Лерчек). ] (ru: Путин помиловал блогера Лерчек)
      Президент России Владимир Путин подписал указ о помиловании блогера Валерии Чекалиной (Лерчек).
  - (2026-11-14) Белый дом объявил, что встреча Трампа, Путина и Си пройдет 19 ноября в Китае. Они обсудят ядерное оружие, но не войну в Украине | LEDE: Встреча Дональда Трампа с Владимиром Путиным и Си Цзин] (ru: Бел…
      Встреча Дональда Трампа с Владимиром Путиным и Си Цзиньпином состоится на следующей неделе на полях саммита АТЭС в Китае, сообщили в Белом доме. Это будет первая в истории трехсторонняя встреча лидеров США, России и Кита…
  - (2026-11-14) «Раньше врачи прививали себе чуму. Я привила себе тюрьму». Мария Бонцлер защищала фигурантов политических дел — а теперь сама получила 12 лет колонии за «госизмену». «Гласная» рассказывает удив] (ru:…
      12 ноября суд в Калининграде приговорил 66-летнюю Марию Бонцлер к 12 годам колонии. Адвоката признали виновной в «госизмене». Карьера Бонцлер началась еще в 1990-х — тогда она защищала права срочников, отправленных на Пе…
  - (2026-11-14) В США отменили общенациональный запрет на вылеты из аэропортов. Самолеты по всей стране простояли четыре часа | LEDE: Федеральное управление гражданской авиации США (FAA) отменило общенацион] (ru: В С…
      Федеральное управление гражданской авиации США (FAA) отменило общенациональный запрет на вылеты самолетов из всех аэропортов страны.
  - (2026-11-14) В США приостановили вылеты самолетов из всех аэропортов | LEDE: Федеральное управление гражданской авиации США (FAA) ввело общенациональный запрет на вылеты самолетов во всех аэропортах, соо] (ru: В С…
      Федеральное управление гражданской авиации США (FAA) ввело общенациональный запрет на вылеты самолетов во всех аэропортах, сообщает Axios со ссылкой на заявление ведомства.
  - (2026-11-13) В Третьяковской галерее отменили показ фильма о подростках на Китай-городе | LEDE: В Третьяковской галерее отменили показ документального фильма «Мы не знакомимся», в котором рассказывается ] (ru: В Т…
      В Третьяковской галерее отменили показ документального фильма «Мы не знакомимся», в котором рассказывается о подростках-«нефорах», собирающихся в районе Китай-города в Москве. Об этом рассказал кинокритик Кирилл Артамоно…

### State-Level News — 369 new of 729 total
  - (2026-11-13) [Alabama] Global Health Equity Week
      Download
  - (2026-11-13) [Alabama] Family Caregivers Month
      Download
  - (2026-11-13) [Alabama] National Adoption Month
      Download
  - (2026-11-13) [Alabama] Family Caregivers Month
      Download
  - (2026-11-13) [Alabama] Gifted Education Month
      Download
  - (2026-11-13) [Alabama] National Rural Health Day
      Download

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 253 new of 319 total
  - (2026-11-13) 宁德时代月内连签两家eVTOL 企业电池厂商加速布局低空领域 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXEFVX3lxTE5VUUs2YU1uc2E0YjM1aFI5eHdQWER6NFVTX1drQ1RHd2FSQlB6TDRoS0JGR21WaHQxdTdveDlYR0Yyem9JX3JuUHF] (zh:…
      宁德时代月内连签两家eVTOL 企业电池厂商加速布局低空领域 财新
  - (2026-11-14) 【CCI快报】：中国大宗商品指数周跌0.49% 液化石油气领跌4.60% - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE8yT29YUnBwME5yMm1MNDFudHRNU2NUdTBzTUpsRkpiNnF5R013dk9WZFFPOEpMamRsbk5qU0VGQm9hX2p] (zh:…
      【CCI快报】：中国大宗商品指数周跌0.49% 液化石油气领跌4.60% 财新数据
  - (2026-11-14) 【周刊提前读】一类肿瘤疫苗取得突破 mRNA赛道重获重视 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE54Mm4wQ3MxMVIwd0k2YVE0QkprUmZ5c1VJRUdxY0ZtZW45NFBYVzl2STF3cDdSOXo0X2FJLUNOS2pILXQwQ25IU2c] (zh:…
      【周刊提前读】一类肿瘤疫苗取得突破 mRNA赛道重获重视 财新数据
  - (2026-11-14) 【周刊提前读】各路资金涌向算力中心 “新时代地产投资”有何风险？ - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1iLXVidk9sVXh1eFFLWEF4V1lBQnUwUmNLd09RMjFoUFpGV1B4OVdTNXhyNVRVN1NpVk1VQXFtcUtaYWVQaVd] (zh:…
      【周刊提前读】各路资金涌向算力中心 “新时代地产投资”有何风险？ 财新数据
  - (2026-11-14) 【周刊提前读】油气市场结构剧变 地缘溢价持续 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1uLUhER0h4MjgySGpTUmZTVDV3Sm1oNFk0UDJic0RzTTRkQUpVMVFRRDdZRUhhbkN1TGhQNlV2QjNHLW9aUnREWnVGQzF1c] (zh:…
      【周刊提前读】油气市场结构剧变 地缘溢价持续 财新数据
  - (2026-11-14) 【周刊提前读】电单车非法改装屡禁不止 治理须回应骑手需求实际 - 财新数据 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE1IZ3dkWWhFc1dwWHMzcGR2T09IdzVDYnBwaF9JSUk3MkNKYnBteWVudFAtWVpzSTM3MGxHWmQ1MVNtWTRFYzhXR] (zh:…
      【周刊提前读】电单车非法改装屡禁不止 治理须回应骑手需求实际 财新数据

### Local News: St. Louis + Atlanta — 231 new of 275 total
  - (2026-11-14) [St. Louis] Flyover Comedy Festival schedule shifts amid FAA nationwide ground stop
      In a twist that only a comedian might come up with, nothing is flying over flyover country this evening. According to multiple sources, flights in the United States are grounded until further notice “due to extraordinary…
  - (2026-11-13) [St. Louis] Top holiday markets in St. Louis for the design enthusiast
      Shopping season is officially underway, and St. Louis is getting into the spirit with a plethora of large and small vendor markets and community events across the city and county. Peruse the offerings below and find a pe…
  - (2026-11-13) [St. Louis] St. Louis mom creates custom dolls that reflect kids of all abilities
      When Rose Watson’s niece turned 4, Watson knew exactly what to give her: a doll that looked just like her cousin Lavender, complete with a feeding tube, tracheostomy tube, and ventilator. The little girl had always been…
  - (2026-11-13) [St. Louis] Santa, live reindeer, and holiday fun are coming to Cottle Village for one day only
      Twinkling lights, live reindeer, a visit from Santa, and hot chocolate (with the option of something stronger for the grown-ups). It sounds like a scene from a Christmas movie, but it’s all part of Christmas on the Farms…
  - (2026-11-13) [St. Louis] Where to order Thanksgiving dinner in St. Louis
      Let’s talk turkey—and sides and desserts. We’ve compiled a list of options for dine-in or carryout. Editor’s note: The following options are noted in three categories: DINE IN, PICK UP, and DINE IN or PICK UP. If any wor…
  - (2026-11-13) [St. Louis] Ask George: Where can a family of 10 go for a holiday dinner in St. Louis?
      The question of “a nice place to go with a party of eight to 10” comes up frequently and even more so during the holidays. I started a top-of-mind list that’s by no means all-inclusive. If you know of a place (private or…

### U.S. Weather + Severe / Climate Outlooks — 137 new of 139 total
  - (2026-11-14) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-14) [Severe] Special Marine Warning: Special Marine Warning issued November 14 at 2:01AM EST until November 14 at 3:00AM EST by NWS Newport/Morehead City NC
      SMWMHX The National Weather Service in Newport has issued a * Special Marine Warning for... Waters from Cape Lookout to Surf City NC from 20 to 60 NM... * Until 300 AM EST. * At 200 AM EST, a severe thunderstorm capable…
  - (2026-11-13) [Moderate] Wind Advisory: Wind Advisory issued November 13 at 10:58PM PST until November 14 at 6:00PM PST by NWS Medford OR
      * WHAT...Southeast winds 15 to 25 mph with gusts up to 40 mph expected. * WHERE...The Rogue Valley in Jackson County, from the southern and eastern portion of Medford to Ashland, including Phoenix, Talent and portions of…
  - (2026-11-13) [Moderate] Wind Advisory: Wind Advisory issued November 13 at 10:58PM PST until November 15 at 1:00PM PST by NWS Medford OR
      * WHAT...South winds 25 to 35 mph with gusts up to 55 mph expected. * WHERE...Most of the Shasta Valley in central Siskiyou County. This includes portions of Interstate 5 as well as the communities of Weed, Gazelle, Gren…
  - (2026-11-14) [Severe] Freeze Warning: Freeze Warning issued November 14 at 1:43AM EST until November 15 at 9:00AM EST by NWS Wilmington NC
      * WHAT...Sub-freezing temperatures as low as 28 expected. Widespread frost is also expected. * WHERE...In North Carolina, Bladen, Columbus, Inland Brunswick, and Inland Pender Counties. In South Carolina, Central Horry,…
  - (2026-11-14) [Severe] Freeze Warning: Freeze Warning issued November 14 at 1:43AM EST until November 15 at 9:00AM EST by NWS Wilmington NC
      * WHAT...For the Frost Advisory, temperatures as low as 36 will result in frost formation. For the Freeze Warning, sub-freezing temperatures as low as 28 and widespread frost expected. * WHERE...In North Carolina, Robeso…

### GDELT GKG — themes / entities / watch areas — 118 new of 118 total
  - (2026-11-14) [Russia oil sanctions perimeter · near] France, Germany, Italy, Poland, UK to represent Europe in Ukraine peace talks alongside EU institutions
      timesofoman.com · English · tone 1.70603674540682 · 24 other outlets
  - (2026-11-14) [Russia oil sanctions perimeter · near] Starshield speed limits return in Ukraine as senators demand answers
      krtv.com · English · tone -5.41176470588235 · 11 other outlets
  - (2026-11-14) [Russia oil sanctions perimeter · near] Ukraine expects largest-ever prisoner exchange with Russia since war, involving over 1,000 from each side: Zelenskyy
      aninews.in · English · tone -0.583657587548638 · 6 other outlets
  - (2026-11-14) [Russia oil sanctions perimeter · near] Trump to Meet Putin and Xi in China for Talks on Nuclear Weapons and Iran
      slguardian.org · English · tone -1.4336917562724 · 6 other outlets
  - (2026-11-14) [Russia oil sanctions perimeter · near] Car Bomb Severely Injures Exiled Pro-Kremlin Ukrainian Official In Moscow
      zerohedge.com · English · tone -7.32600732600732 · 1 other outlets
  - (2026-11-14) [Russia oil sanctions perimeter · near] Ukraine launches mass drone attack as winter pressure on power systems deepens
      paktribune.com · English · tone -5.41237113402062 · 1 other outlets

### Ukraine Theater (total-war monitoring) — 101 new of 271 total
  - (2026-11-14) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-12) [Liveuamap] A car carrying a Russian serviceman exploded… - Liveuamap
      A car carrying a Russian serviceman exploded… Liveuamap
  - (2026-11-10) [Liveuamap] A US Army soldier has been arrested in Gloucestershire, UK, on suspicion of offenses under Sections 1 and 3 of the National Security Act 2023, as part of a Russia-related investigation by…
      A US Army soldier has been arrested in Gloucestershire, UK, on suspicion of offenses under Sections 1 and 3 of the National Secu
  - (2026-11-12) [Liveuamap] Drones attack at the Volgograd oil refinery – Volgograd Oblast, Russia - Liveuamap
      Drones attack at the Volgograd oil refinery – Volgograd Oblast, Russia Liveuamap
  - (2026-11-12) [Liveuamap] Yemeni government forces report clashes with Houthi forces in Al-Jawf, Marib, and White - Liveuamap
      Yemeni government forces report clashes with Houthi forces in Al-Jawf, Marib, and White <font color="#
  - (2026-11-10) [Liveuamap] An Israeli civilian illegally crossed the border into Lebanon a short while ago, near the Rosh Hanikra Crossing, the military says. The military says the man was located by United Nations…
      An Israeli civilian illegally crossed the border into Lebanon a short while ago, near the Rosh Hanikra Cr

### World News (by country, top stories) — 101 new of 101 total
  - (2026-11-14) [Brazil] Brazil demands explanation from Israel over teenager's death in custody
      bignewsnetwork.com · English · 1 other outlets ran this story
  - (2026-11-14) [Brazil] Letter from Brazil: How 'Lula's army' beat the social-media algorithms to pull off a startling win
      scroll.in · English
  - (2026-11-14) [Brazil] São Paulo Plan, Saturday 14 Nov: Free Pinacoteca Entry
      riotimesonline.com · English
  - (2026-11-14) [Brazil] Brazil investigates strife between Israeli tourists and pro-Palestine residents
      the-messenger.com · English
  - (2026-11-14) [Brazil] 17 Paraguayan Workers Among 21 Rescued from Forced Labor in Brazil Cigarette Factories
      latintimes.com · English
  - (2026-11-13) [Brazil] USDA raises Brazil soybean oil exports, cuts regional stocks | Hellenic Shipping News Worldwide
      hellenicshippingnews.com · English

### GDACS — global disaster alerts — 83 new of 100 total
  - (2026-11-14) [Green] Earthquake in West Chile Rise
      Earthquake · Green alert · West Chile Rise · Magnitude 4.8M, Depth:10km
  - (2026-11-14) [Green] Earthquake in Western Indian-Antarctic Ridge
      Earthquake · Green alert · Western Indian-Antarctic Ridge · Magnitude 4.5M, Depth:10km
  - (2026-11-14) [Green] Earthquake in Argentina
      Earthquake · Green alert · Argentina · Magnitude 4.7M, Depth:216.092km
  - (2026-11-14) [Green] Earthquake in Off W Coast Of Northern Sumatera
      Earthquake · Green alert · Off W Coast Of Northern Sumatera · Magnitude 5.2M, Depth:10km
  - (2026-11-14) [Green] Earthquake in Fiji
      Earthquake · Green alert · Fiji · Magnitude 4.5M, Depth:587.447km
  - (2026-11-11) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 5805 ha

### State Legislative Action — 77 new of 78 total
  - (2026-11-13) [California AB 1815] Factory-built housing: building standards and local requirements.
      Existing law, the California Building Standards Law, establishes the California Building Standards Commission within the Government Operations Agency. Existing law requires the commission to approve and adopt building st…
  - (2026-11-13) [California AB 605] Employment: refineries: task force.
      Existing law establishes an accidental release prevention program for the state. Under that law, stationary sources subject to the accidental release prevention program may be required to prepare and submit a risk manage…
  - (2026-11-13) [California AB 282] Elections: seizure of election materials.
      Under existing law, a county elections official is required to prepare a certified statement of the results of an election and submit it to the county board of supervisors within 30 days of the election. This bill would…
  - (2026-11-13) [California AB 2179] Workplace violence: restraining orders.
      Existing law authorizes any employer or authorized bargaining representative, as specified, whose employee has suffered unlawful violence or a credible threat of violence that can reasonably be construed to be carried ou…
  - (2026-11-13) [California SB 1368] Speech-language pathologists, audiologists, and hearing aid dispensers.
      Existing law, the Speech-Language Pathologists and Audiologists and Hearing Aid Dispensers Licensure Act, until January 1, 2027, establishes the Speech-Language Pathology and Audiology and Hearing Aid Dispensers Board wi…
  - (2026-11-13) [California AB 2575] Health care services: artificial intelligence.
      Existing law charges the Labor Commissioner with enforcement of various labor laws, including investigation of employee complaints. This bill would declare it is the policy of the state that a worker providing direct pat…

### Ukrainian Internal News (national + local Kyiv) — 74 new of 129 total
  - (2026-11-14) Конкуренція між містами. Як привабити людей в умовах обмежених ресурсів | LEDE: Українські міста змагаються за молодих мешканців, створюючи нові можливості попри демографічну кризу, безпекові т] (uk:…
      Українські міста змагаються за молодих мешканців, створюючи нові можливості попри демографічну кризу, безпекові та економічні виклики.
  - (2026-11-14) Російські обстріли трьох областей: троє загиблих, семеро поранених | LEDE: Російські обстріли Херсонської, Дніпропетровської та Донецької областей призвели до жертв і руйнувань інфраструктури.] (uk: Р…
      Російські обстріли Херсонської, Дніпропетровської та Донецької областей призвели до жертв і руйнувань інфраструктури.
  - (2026-11-14) На перемовинах у Абу-Дабі Росія вимагала від НАТО відійти до кордонів 97 року – NYT | LEDE: Москва під час перемовин у Абу-Дабі наполягає на відведенні сил НАТО до меж 1997 року. Деталі й позиц] (uk:…
      Москва під час перемовин у Абу-Дабі наполягає на відведенні сил НАТО до меж 1997 року. Деталі й позиція США – у документі, який отримала The New York Times.
  - (2026-11-14) За ніч ППО знешкодила 81 російську ціль, є влучання на 8 локаціях | LEDE: Уночі 14 листопада Росія випустила 96 дронів по Україні, ППО знешкодила більшість, зокрема Shahed і Гербера. Зафіксован] (uk:…
      Уночі 14 листопада Росія випустила 96 дронів по Україні, ППО знешкодила більшість, зокрема Shahed і Гербера. Зафіксовані влучання на 8 локаціях.
  - (2026-11-14) У Запоріжжі повністю перекрили рух транспорту греблею ДніпроГЕС | LEDE: 14 листопада через рішення ОВА у Запоріжжі обмежили рух транспорту греблею Дніпровської ГЕС. Об'їзд можливий через інші м] (uk:…
      14 листопада через рішення ОВА у Запоріжжі обмежили рух транспорту греблею Дніпровської ГЕС. Об'їзд можливий через інші мости.
  - (2026-11-14) Новий Конгрес США: головне про 8 демократів, які можуть вирішувати долю допомоги Україні | LEDE: ] (uk: Новий Конгрес США: головне про 8 демократів, які можуть вирішувати долю допомоги)

### IT, InfoSys & cybersecurity news (last 7 days) — 47 new of 63 total
  - (2026-11-14) [Ars Technica] Starship flight 15 powers to orbit—setting up a possible catch on Saturday
      One way or another, the company will get some more data on Saturday.
  - (2026-11-13) [BleepingComputer] Trezor confirms crypto-stealing implants in three wallets, releases fix
      Cryptocurrency hardware wallet maker Trezor has confirmed that three Safe 5 devices sold by Southeast Asian reseller CryptoBilis contained malicious hardware implants designed to steal wallet recovery phrases and send th…
  - (2026-11-13) [BleepingComputer] German military drone operations disrupted by cyberattack
      German defense technology company Quantum Systems confirmed that it detected an incident in late October that was part of an active cyberattack by "hostile actors." [...]
  - (2026-11-13) [BleepingComputer] Check Point gateways hacked via PHP2Shell to deploy VMware ESXi wiper
      Vulnerable Check Point Security Gateway instances have been targeted in PHP2Shell attacks that deployed data-wiping malware on VMware ESXi hosts. [...]
  - (2026-11-13) [BleepingComputer] How one AI agent exposed five critical enterprise security gaps
      An AI agent built to automate invoice processing could be manipulated into changing vendor bank details through a malicious email, without triggering traditional security alerts. Token Security examines five critical AI…
  - (2026-11-13) [BleepingComputer] Microsoft says November security updates cause printing issues
      Microsoft warned customers earlier this week that the November 2026 security updates may break printing for documents with complex formatting. [...]

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-14) [Kieser Brian Joseph] Form 4 (Reporting)
      filed 2026-11-14 02:59 UTC · role: Reporting — Filed: 2026-11-13 AccNo: 0001493152-26-051920 Size: 28 KB
  - (2026-11-14) [NEXGEL, INC.] Form 4 (Issuer)
      filed 2026-11-14 02:59 UTC · role: Issuer — Filed: 2026-11-13 AccNo: 0001493152-26-051920 Size: 28 KB
  - (2026-11-14) [Ciardiello Steven] Form 4 (Reporting)
      filed 2026-11-14 02:58 UTC · role: Reporting — Filed: 2026-11-13 AccNo: 0001493152-26-051919 Size: 13 KB
  - (2026-11-14) [NEXGEL, INC.] Form 4 (Issuer)
      filed 2026-11-14 02:58 UTC · role: Issuer — Filed: 2026-11-13 AccNo: 0001493152-26-051919 Size: 13 KB
  - (2026-11-14) [Blackman Ian Howard] Form 4 (Reporting)
      filed 2026-11-14 02:58 UTC · role: Reporting — Filed: 2026-11-13 AccNo: 0001493152-26-051918 Size: 13 KB
  - (2026-11-14) [NEXGEL, INC.] Form 4 (Issuer)
      filed 2026-11-14 02:58 UTC · role: Issuer — Filed: 2026-11-13 AccNo: 0001493152-26-051918 Size: 13 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-14) [United States] FAA Lifts Nationwide Ground Stop After Communications Outage Disrupts Flights at JFK, LaGuardia and Long Island Airports
      domain: longisland.com · language: English · tone: -6.12244897959184 · 292 other outlets ran this story
  - (2026-11-14) [United States] All passengers and crew on New Orleans cruise ship survive crash with tanker on Mississippi River
      domain: santafenewmexican.com · language: English · tone: -2.96296296296296 · 194 other outlets ran this story
  - (2026-11-13) [United States] FAA orders all flights in U.S. grounded for 'reasons of safety'; communication issue impacting air traffic control centers | News, Sports, Jobs - Lawrence Journal-World: news, informat…
      domain: ljworld.com · language: English · tone: -2.68817204301075 · 120 other outlets ran this story
  - (2026-11-14) [China] Trump plans Iran war talks with Xi and Putin, AFP reports
      domain: inquisitr.com · language: English · tone: -0.420168067226891 · 102 other outlets ran this story
  - (2026-11-14) [United States] Flights Across the U.S. Resume After Major Disruption Lasting Over Four Hours
      domain: cubaheadlines.com · language: English · tone: -7.38993710691824 · 93 other outlets ran this story
  - (2026-11-14) [United States] FAA grounds planes across US airports, including Bay Area, amid 'communication issues'
      domain: ktvu.com · language: English · tone: -1.74927113702624 · 74 other outlets ran this story

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Wikidata leader-roster changes (48h) — 25 new of 54 total
  - (2026-11-14) [Central African Republic] Faustin-Archange Touadéra (Q57758) edited
      /* wbeditentity-update-languages-short:0||hi */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/67776|batch #67776]]
  - (2026-11-14) [Canada] Mark Carney (Q192533) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/65842|batch #65842]]: Import places from GND
  - (2026-11-14) [Samoa] Tuilaʻepa Saʻilele Malielegaoi (Q57723) edited
      /* wbeditentity-update-languages-short:0||hi */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/67776|batch #67776]]
  - (2026-11-14) [People's Republic of China] Li Qiang (Q4414390) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/65842|batch #65842]]: Import places from GND
  - (2026-11-13) [Brazil] Luiz Inácio Lula da Silva (Q37181) edited
      /* wbmergeitems-from:0||Q142140358 */
  - (2026-11-13) [Cameroon] Paul Biya (Q57272) edited
      /* wbsetsitelink-add:1|rwwiki */ Paul Biya

### Court opinions of consequence (federal & state) — 24 new of 60 total
  - (2026-11-13) U.S. Court of Appeals, 10th Cir.: United States v. Martin
  - (2026-11-13) U.S. Court of Appeals, 5th Cir.: Jackson v. Ventavia Research Group
  - (2026-11-13) U.S. Court of Appeals, 7th Cir.: Alton Antrim v. Jared Hoy
  - (2026-11-13) U.S. Court of Appeals, 7th Cir.: Alton Antrim v. Jared Hoy
  - (2026-11-13) U.S. Court of Appeals, Federal Cir.: Faerber v. United States
  - (2026-11-13) U.S. Court of Appeals, Federal Cir.: Green v. MSPB

### USGS earthquakes (M4.5+, past day) — 23 new of 23 total
  - (2026-11-13) M 5.8 - 79 km WSW of Changuillo, Peru
      M5.8 · 79 km WSW of Changuillo, Peru · depth 10 km
  - (2026-11-14) M 5.2 - off the west coast of northern Sumatra
      M5.2 · off the west coast of northern Sumatra · depth 10 km
  - (2026-11-13) M 5.2 - 79 km NE of Kuqa, China
      M5.2 · 79 km NE of Kuqa, China · depth 10 km
  - (2026-11-13) M 5.2 - West Chile Rise
      M5.2 · West Chile Rise · depth 10 km
  - (2026-11-13) M 5.1 - 153 km NW of Kavieng, Papua New Guinea
      M5.1 · 153 km NW of Kavieng, Papua New Guinea · depth 10 km
  - (2026-11-13) M 5.1 - South Sandwich Islands region
      M5.1 · South Sandwich Islands region · depth 63.81 km

### Government Action: Sanctions + Procurement + Foreign Agents — 22 new of 100 total
  - (2026-11-13) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Counter Narcotics and Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-11-13) [OFAC] Federal Register/Vol. 91, No. 218/Friday, November 13, 2026/Rules and Regulations - Office of Foreign Assets Control (.gov)
      Federal Register/Vol. 91, No. 218/Friday, November 13, 2026/Rules and Regulations Office of Foreign Assets Control (.gov)
  - (2026-11-13) [OFAC] Federal Register/Vol. 91, No. 218/Friday, November 13, 2026/Rules and Regulations - Office of Foreign Assets Control (.gov)
      Federal Register/Vol. 91, No. 218/Friday, November 13, 2026/Rules and Regulations Office of Foreign Assets Control (.gov)
  - (2026-11-14) [USASpending] $17,956,041,439 → BECHTEL NATIONAL, INC.:
      Agency: Department of Energy. Description:
  - (2026-11-14) [USASpending] $1,135,248,775 → RAUMA MARINE CONSTRUCTIONS OY: PURCHASE OF TWO ARCTIC SECURITY CUTTERS FOR THE USCG
      Agency: Department of Homeland Security. Description: PURCHASE OF TWO ARCTIC SECURITY CUTTERS FOR THE USCG
  - (2026-11-14) [USASpending] $892,722,487 → MAXIMUS FEDERAL SERVICES, INC.: DEBT MANAGEMENT AND COLLECTIONS SYSTEM (DMCS) IGF::CT::IGF
      Agency: Department of Education. Description: DEBT MANAGEMENT AND COLLECTIONS SYSTEM (DMCS) IGF::CT::IGF

### U.S. Federal Action — 20 new of 20 total
  - (2026-11-13) Presidential Determination Pursuant to Section 1245(d)(4)(B) and (C) of the National Defense Authorization Act for Fiscal Year 2012
  - (2026-11-13) Airworthiness Directives; The Boeing Company Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for certain The Boeing Company Model 787-8 airplanes. This proposed AD was prompted by a report that certain wing skin outer mold line (OML) penetrating fasten…
  - (2026-11-13) Publication of Iran-Related Web General Licenses EE and FF
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is publishing two Iran-related general licenses (GLs): GLs EE and FF, which were made available on OFAC's website at the time of issuance.
  - (2026-11-13) Publication of Russian Harmful Foreign Activities Sanctions Regulations Web General Licenses 55F and 115D
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is publishing two general licenses (GLs) issued pursuant to the Russian Harmful Foreign Activities Sanctions Regulations: GLs 55F and 115D, each of…
  - (2026-11-13) Publication of a Cuba Sanctions Regulations Web General License
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is publishing a general license (GL) issued in the Cuba Sanctions program: GL 1. This GL was previously made available on OFAC's website.
  - (2026-11-13) Amendment of Class C Airspace; Laughlin Air Force Base, Del Rio, TX
      This action makes administrative amendments to the Laughlin AFB, TX, Class C airspace legal description. Specifically, the action updates the geographic coordinates of the airport reference point (ARP) to match the FAA's…

### Paper Trading Scorecard — 19 new of 75 total
  - (2026-11-14) [Polymarket] Will Russia capture all of Chasiv Yar by December 31?
      This market will resolve to “Yes” if, according to the ISW map, Russia captures the entirety of Chasiv Yar, Donetsk Oblast, (48.589446° N, 37.831430° E) between market creation and the specified date, 11:59 PM ET. Chasiv…
  - (2026-11-14) [Manifold] Will Jensen Huang testify before a committee of the US Congress by EoY, 2026?
  - (2026-11-14) [Manifold] Will it be revealed this year that the aircraft grounding was due to a cyberattack?
  - (2026-11-14) [Manifold] Will I be able to fly to SFO on Sunday evening?
  - (2026-11-14) [Manifold] Will another Windows "blue screen of death" outage happen again before December 2027? 5 million computers
  - (2026-11-14) [Manifold] Are the Microsoft outage and FAA ground stop meaningfully related?

### Campaign finance (FEC: top fundraisers + recent filings) — 14 new of 27 total
  - (2026-11-12) [F3X] PLUMBERS & PIPEFITTERS LOCAL UNION NO. 295 PAC
      cycle 2026 · filing #2047309 · receipts $0.00M
  - (2026-11-12) [F3X] MENDOCINO COUNTY DEMOCRATIC PARTY
      cycle 2026 · filing #2047356 · receipts $0.00M
  - (2026-11-12) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2047430
  - (2026-11-12) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2047271
  - (2026-11-12) [F99] LUCETE LEADERSHIP FUND
      cycle 2026 · filing #2047382
  - (2026-11-12) [F99] CORY STEELE FOR PRESIDENT
      cycle 2026 · filing #2047280

### Government & military aircraft airborne (OpenSky) — 11 new of 12 total
  - (2026-11-14) JAF63D (Belgium)
      icao24: 44b438 · position: (48.3771, 1.1369) · alt: 10058m · 806km/h
  - (2026-11-14) RCH221 (United States)
      icao24: ae10b7 · position: (40.7802, 24.5002) · alt: 9441m · 873km/h
  - (2026-11-14) JAF1VB (Belgium)
      icao24: 449681 · position: (45.0061, -0.1403) · alt: 11887m · 746km/h
  - (2026-11-14) JAF5BJ (Belgium)
      icao24: 44d1a7 · position: (41.37, 0.1472) · alt: 11887m · 766km/h
  - (2026-11-14) JAF34G (Belgium)
      icao24: 44d1a5 · position: (42.3497, 9.9909) · alt: 11887m · 844km/h
  - (2026-11-14) JAF5PN (Belgium)
      icao24: 44d1b3 · position: (43.1146, 0.7176) · alt: 11277m · 767km/h

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-11-14) MOVER ▼ Michael Dell — $208.45B ($-10.72B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-11-14) MOVER ▼ Elon Musk — $887.16B ($-7.11B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-11-14) MOVER ▲ Mark Zuckerberg — $220.42B (+$6.12B since yesterday)
      United States · Technology · source: Facebook
  - (2026-11-14) MOVER ▼ Jensen Huang — $141.90B ($-2.84B since yesterday)
      United States · Technology · source: Nvidia
  - (2026-11-14) MOVER ▼ Larry Page — $244.53B ($-2.25B since yesterday)
      United States · Technology · source: Google
  - (2026-11-14) MOVER ▼ Larry Ellison — $165.51B ($-2.14B since yesterday)
      United States · Technology · source: Oracle

### Prediction Markets — most-traded (Polymarket) — 10 new of 20 total
  - (2026-11-14) Counter-Strike: Spirit vs MOUZ (BO3) - BLAST Rivals Playoffs
      yes price: 46% · 24h volume: $679,489 · resolves 2026-11-14
  - (2026-11-14) Counter-Strike: FURIA vs Team Falcons (BO3) - BLAST Rivals Playoffs
      yes price: 52% · 24h volume: $547,283 · resolves 2026-11-14
  - (2026-11-14) Will Marjorie Taylor Greene win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $530,773 · resolves 2028-11-07
  - (2026-11-14) Will Shawn Fain win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $468,438 · resolves 2028-11-07
  - (2026-11-14) Will Rob Sand win the 2028 Democratic presidential nomination?
      yes price: 0% · 24h volume: $400,955 · resolves 2028-11-07
  - (2026-11-14) LoL: Bilibili Gaming vs Gen.G (BO5) - Worlds Playoffs
      yes price: 38% · 24h volume: $387,777 · resolves 2026-11-15

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-14) [Marginal Revolution] People like their jobs, even British people
      This paper investigates the role of work in providing meaning, purpose, community, and other non-monetary benefits. Using an original cross-national survey of 8,234 working-age adults across the UK, US, Denmark, and Indi…
  - (2026-11-14) [Marginal Revolution] The Power and Roots of Aspirations
      Aspirations have become a common theme in empirical economics studies but there is no unified understanding of the range of outcomes they influence, the factors that shape them, and how to measure them. We survey this gr…
  - (2026-11-13) [Marginal Revolution] Are we witnessing an intelligence explosion?
      From Luis Garicano and Alex Imas: Hence AI capabilities improved 1.91 times faster after October 2025, but R&D spending grew 6.19 times and the technical workforce 3.10 times. So measured capability gains per dollar fell…
  - (2026-11-13) [Conversable Economist] Visions of the EU in 2050
      The Centre for Economic Policy Research (the one in London, not the one in Washington, DC, as you can see from the spelling of Centre) has a new initiative called “Europe 2050: Geometries of peace, power, and prosperity”…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 15 total
  - (2026-11-13) CVE-2026-114713 · UnrealIRCd UnrealIRCd: UnrealIRCd Improper Neutralization of Delimiters Vulnerability
      vendor: UnrealIRCd · product: UnrealIRCd · CISA remediation by 2026-11-16
  - (2026-11-13) CVE-2026-123039 · Check Point Multiple Products: Check Point Multiple Products Incorrect Permission Assignment for Critical Resource Vulnerability
      vendor: Check Point · product: Multiple Products · CISA remediation by 2026-11-16

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-11-13) Middle East respiratory syndrome (MERS) – Qatar
      On 29 October 2026, the National International Health Regulations (IHR) Focal Point of the State of Qatar notified the World Health Organization (WHO) of two laboratory-confirmed cases of Middle East respiratory syndrome…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-14) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=26, 14d-median=25; carrying terms: existing, agency, regulatory, reflect, airworthiness, changes, published, proposes, directives, proposed, airplanes, model
- state_bills: today=78, 7d-median=78, 14d-median=97; carrying terms: income, providing, reporting, insurance, medical, authority, vehicle, emergency, relating, health, approval, program
- state_news: today=729, 7d-median=717, 14d-median=717; carrying terms: width, black, historic, amendment, whether, async, social, votes, attention, possible, short, policy
- local_news: today=275, 7d-median=266, 14d-median=265; carrying terms: family, class, culture, south, trump, falcons, election, woman, shooting, illinois, winning, families
- foreign_news: today=977, 7d-median=997, 14d-median=997; carrying terms: qatar, historic, default, async, senior, possible, webfeedsfeaturedvisual, short, policy, family, economic, announcement
- chinese_internal: today=319, 7d-median=321, 14d-median=321; carrying terms: cbmiyefvx, global, google, cbmizkfvx, cbmizefvx, articles, cbmickfvx, cbmidefvx, cbmib, caixin, cbmixkfvx, cbmiakfvx
- russian_internal: today=938, 7d-median=1012, 14d-median=946; carrying terms: https, gazeta, russian, journal, novayagazeta, media, novaya, istories, bloomberg, raquo, group, forbidden
- ukrainian_internal: today=129, 7d-median=134, 14d-median=134; carrying terms: black, security, kyivindependent, further, ministry, strikes, vladimir, pressure, injured, country, attack, europe
- ukraine_theater: today=271, 7d-median=271, 14d-median=271; carrying terms: jjbux, pechersk, zozmr, irhixawzvqnd, mqnotrm, ncdvz, ycwltsthnt, hpqwz, dqrjhiuvu, cbmiyefvx, assets, ujgzqmriy
- paper_bets: today=75, 7d-median=75, 14d-median=69; carrying terms: jinping, december, inflation, allen, secretary, resolved, celsius, visit, world, leader, mahomes, russell
- weather: today=139, 7d-median=139, 14d-median=132; carrying terms: miami, cyclones, boston, friday, detroit, afdbox, vessels, discussion, possible, result, short, oxnard
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: payrolls, crude, unemployment, dexchus, balance, unrate, treasury, openings, cpiaucsl, inflation, implied, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: silver, bitcoin, russell, crude, crypto, treasury, equities, china, rates, close, commodities, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=100, 7d-median=99, 14d-median=99; carrying terms: homeland, content, maintenance, portal, checksum, security, detect, representative, jjmudpzw, mtjwwxz, assets, related
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, error, quiver, congresstrading, client, quiverquant, unauthorized, httperror, quantitative
- billionaires: today=40, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, international, supreme, court, florida, connecticut, appeals, company, blanche, arkansas, trade, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed, holdings, michael, joseph
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, booker, warner, ocasio, sayed, talarico, alexandria, robert, raised, cortez, ossoff
- gdelt_regions: today=101, 7d-median=11, 14d-median=8; carrying terms: english, korea, south, europe, trump, japan
- gdelt_gkg: today=118, 7d-median=25, 14d-median=25; carrying terms: english, russian, sanctions, themes, russia, trump, perimeter, chinese, keywords, israel, french, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=0; carrying terms: killed, domain, trump, english, india, press, murder, suspect, shooting, police, control, language
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=12, 7d-median=22, 14d-median=26; carrying terms: position, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: irkutsk, locations, december, broader, traceability, identification, fever, poultry, notification, beginning, ranging, netherlands
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: value, critical, authentication, remediation, vulnerability, missing, vendor, product, return, cisco, google, improper
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=54, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: botswana, sudan, magnitude, south, fires, alert, impact, forest, green, forestfire, japan, australia
- usgs_quakes: today=23, 7d-median=15, 14d-median=12; carrying terms: depth, japan, islands, region, ridge, south, indian, guinea, papua, philippines, sandwich, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: presidential, volume, price, resolves, election, league, shakhtar, championship, champions, donetsk, israel, democratic
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, revolution, https, class, marginal, economist, world, conversableeconomist, since, working, economic, total
- tech_news: today=63, 7d-median=63, 14d-median=61; carrying terms: spectrum, record, infrastructure, friday, vulnerability, security, blogging, products, authentication, target, investigation, daily
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: sanford, sanders, meeks, harriet, fedorchak, foster, loeffler, hudson, boston, counsel, allen, reserved
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, today, either, sufficient, paper, placement, evidence, unavailable, identify, consensus, module, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy
- [2026-11-05] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Allegiant United Holdings, LLC, Nano Financial Holdings, Inc., and Nano Banc
- [2026-11-06] ECB press: ECB publishes consolidated banking data for end-June 2026
- [2026-11-07] ECB press: Christine Lagarde: Interview with Yomiuri Shimbun
- [2026-11-09] Fed press (events + announcements): Federal Reserve Board announces approval of two applications by Mutual Federal Bancorp, MHC, and MFB Bancorp, Inc.
- [2026-11-10] Fed speeches: Waller, The Economic Outlook and Some Thoughts on Labor Market Dynamism
- [2026-11-10] ECB press: Piero Cipollone: Cash and the digital euro: two sides of the same coin
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-10] Fed speeches: Bowman, The U.S. Economy and Considerations for Monetary Policy
- [2026-11-12] Fed speeches: Barr, American Inequality and the Future of AI
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*