# WORLDSCOPE morning brief — 2026-09-30

## Headline
3540 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (805) · Russian Internal News (state + in-exile) (612) · State-Level News (415) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (320) · Chinese Internal News (235) · Local News: St. Louis + Atlanta (205) · U.S. Weather + Severe / Climate Outlooks (142) · State Legislative Action (70) · Ukrainian Internal News (national + local Kyiv) (70) · GDELT GKG — themes / entities / watch areas (63) · IT, InfoSys & cybersecurity news (last 7 days) (41)

## What changed today
### International News + Multilateral Institutions — 805 new of 1018 total
  - (2026-09-30) [Global] Burundi agrees to receive ‘third-country’ migrant deportees from US
  - (2026-09-30) [Global] Top Trump figures push to direct human rights funding to rightwing causes
  - (2026-09-30) [Global] AI tool that copied actor’s ‘lustrous’ voice violated his rights, Tokyo court rules
  - (2026-09-30) [Global] South Korea calls for apology from North Korea after mine injures three soldiers
  - (2026-09-30) [Global] Malaysia begins Myanmar repatriations despite warnings from UN and rights groups
  - (2026-09-30) [Global] Double beds, aircon and big-screen TVs: Indonesia suspends officials over luxury prison cells

### Russian Internal News (state + in-exile) — 612 new of 1022 total
  - (2026-09-30) Война. 1680-й день. Каждый час воздушной тревоги стоит Украине 45 миллионов долларов. Киев вынужден менять систему оповещения, чтобы сократить убытки | LEDE: «Медуза» с 24 февраля 2022 года ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-30) Лидер «Яблока» потребовал от МВД проверить информацию о пытках политолога Александра Кынева | LEDE: Председатель партии «Яблоко» Николай Рыбаков направил обращение главе МВД Владимиру Колоко] (ru: Лид…
      Председатель партии «Яблоко» Николай Рыбаков направил обращение главе МВД Владимиру Колокольцеву с требованием срочно проверить информацию о применении насилия к политологу Александру Кыневу, находящемуся в СИЗО.
  - (2026-09-30) Футбольный клуб «Манчестер Сити» обвинили в беспрецедентном нарушении финансовых правил. Теперь ему грозят потеря денег, очков и даже титулов | LEDE: Футбольный клуб «Манчестер Сити — один и] (ru: Фут…
      Футбольный клуб «Манчестер Сити — один из лидеров Английской премьер-лиги — признали виновным в систематическом нарушении финансовых правил. Расследование, начатое еще в декабре 2018 года, продлилось более четырех лет. В…
  - (2026-09-30) Невероятно! Ученые нашли и описали новый вид динозавра — с четырьмя крыльями! Находка может поменять представление об эволюции полета | LEDE: Палеонтологи описали новый вид мелких динозавров] (ru: Нев…
      Палеонтологи описали новый вид мелких динозавров, результаты исследования опубликованы в журнале Nature. Новый вид динозавров назвали Norellraptor barsboldi — в честь американского палеонтолога Марка Аллена Норелла и его…
  - (2026-09-30) Reuters: McDonaldʼs определяет «готовность клиентов платить» с помощью ИИ и вынуждает франчайзи повышать цены | LEDE: McDonaldʼs активно использует ИИ, чтобы оценивать «готовность клиентов п] (ru: Reu…
      McDonaldʼs активно использует ИИ, чтобы оценивать «готовность клиентов платить» и повышать прибыль головной компании, выяснило Reuters, изучив внутреннюю систему ценообразования сети. В США цены на одни и те же позиции м…
  - (2026-09-30) Война за Фолкленды закончилась почти полвека назад — но Аргентина и Британия то и дело вновь затевают спор об островах. Так Фолкленды — они чьи? За кого жители самого архипелага? И возможна ли ] (ru:…
      В сентябре 2026 года спор Аргентины и Великобритании вокруг Фолклендских островов вновь обострился. Президент Аргентины Хавьер Милей объявил о санкциях против компаний, участвующих в разработке нефтяного месторождения Se…

### State-Level News — 415 new of 824 total
  - (2026-09-30) [California] Why CA’s poverty rate is second only to Louisiana
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/10/102524_Unhoused-Voting_FG_CM_28.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-09-30) [California] California high-speed rail fails to accomplish most of its legislative goals for 2026
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/091225-High-Speed-Rail-LV-CM-09.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-09-30) [California] LA can make the Olympics cleaner and greener than the World Cup
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/011326-LA-Olympics-2028-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-09-30) [California] California’s hallmark economic sectors are confronting threats to their survival
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/073025-Tablas-Creek-Vineyard-LV-CM-32.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-09-30) [California] Abortion pills to be offered at California community college health centers under new law
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/032624-Mifepristone-Abortion-Rights-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-…
  - (2026-09-30) [California] A new California law will prohibit sales of disposable vapes. Here’s why
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/062519-SF-Vape-GETTY-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="A…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 320 new of 662 total
  - (2026-09-29) [FIRMS] thermal anomaly 45.822, 22.178 (FRP 1.34 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-29 1238Z, FRP 1.34 MW
  - (2026-09-29) [FIRMS] thermal anomaly 46.833, 23.357 (FRP 8.13 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-29 1240Z, FRP 8.13 MW
  - (2026-09-29) [FIRMS] thermal anomaly 47.627, 23.397 (FRP 4.91 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-29 1240Z, FRP 4.91 MW
  - (2026-09-29) [FIRMS] thermal anomaly 48.500, 22.768 (FRP 3.74 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-29 1240Z, FRP 3.74 MW
  - (2026-09-29) [FIRMS] thermal anomaly 48.497, 22.766 (FRP 4.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-29 1240Z, FRP 4.92 MW
  - (2026-09-29) [FIRMS] thermal anomaly 49.416, 34.411 (FRP 1.06 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-29 2312Z, FRP 1.06 MW

### Chinese Internal News — 235 new of 302 total
  - (2026-09-29) China’s Central Bank Cuts Policy Lending Rate in Targeted Growth Push - Caixin Global
      China’s Central Bank Cuts Policy Lending Rate in Targeted Growth Push Caixin Global
  - (2026-09-29) Southeast Asia Can Be More to China Than Just a Buyer, Malaysian Official Says - Caixin Global
      Southeast Asia Can Be More to China Than Just a Buyer, Malaysian Official Says Caixin Global
  - (2026-09-30) 习近平等党和国家领导人出席烈士纪念日向人民英雄敬献花篮仪式 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE01V01xbGRTLUpyMU5WMmFsNlFldnJCWTA5RW83THg5MUp6VXl4UjM4QTdfazhrSmJOMExoWHhYTFdadmU4bl] (zh:…
      习近平等党和国家领导人出席烈士纪念日向人民英雄敬献花篮仪式 人民网-图片频道
  - (2026-09-30) 上海：中国第16次北冰洋考察成果丰硕 “双龙” 凯旋 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE54UlhQVTQ2Y1BaSEFGQWpXVjZRWU5jWDMyM1ZWUzFGTmxBRWVOaEVETGRLOHNPS2MweGRra3VuNHZ2RGVUUFRRM3JEc] (zh:…
      上海：中国第16次北冰洋考察成果丰硕 “双龙” 凯旋 人民图片
  - (2026-09-30) 山东高密： 自主游戏乐享童年 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTFBRaUNyUjQ3SkYzRDRPc1dPeEdieDhxX1lKalZPY0FINEw0UnlzLWxUOHBXOVNoeWxLTXZKUmhpd3Q2TURObk0xeUV5SXpKRDJEb1NoQ] (zh:…
      山东高密： 自主游戏乐享童年 人民图片
  - (2026-09-30) 2026中国（天津）国际汽车展览会在津启幕 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1lbnRTMXRoMnMxYi1EeFUza0lUSWF4Wjc5TThOMlRVLWRBOHRnUHdYekx5endjRWlsN2FRcko4MW4yOXJxWTRJclZIUENkbTh] (zh:…
      2026中国（天津）国际汽车展览会在津启幕 人民网

### Local News: St. Louis + Atlanta — 205 new of 247 total
  - (2026-09-30) [St. Louis] Plan to crack down on smoke shops gains support from St. Louis aldermen
      A bill moving through St. Louis City Hall would make it a lot harder to open a smoke shop in the city. The bill’s sponsor, Alderman Tom Oldenburg, says that smoke shops currently face few hurdles to opening and, once in…
  - (2026-09-30) [St. Louis] Blues enter new television era with Blue Note+
      With several new faces and the fifth-youngest opening night roster in the NHL, the St. Louis Blues will look quite different when they take the ice in Dallas on Friday. So will the way fans watch them this season. For ye…
  - (2026-09-30) [St. Louis] Where in Chesterfield 9/30/2026
      Let’s see how well you know Chesterfield. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess…
  - (2026-09-29) [St. Louis] Ameren intends to use natural gas to power the local grid amid ‘unprecedented’ growth in demand
      Ameren Missouri is doubling down on using more gas-fired power plants to meet the sharp demand for electricity it foresees coming to the local grid. That’s according to the electric utility’s 2026 Integrated Resource Pla…
  - (2026-09-29) [St. Louis] Chuck E. Cheese Adventure World is coming to Chesterfield
      Chuck E. Cheese is trading arcade tokens for climbing structures, slides, and ball pits with a new destination headed to Chesterfield. The company announced this week that Chuck E. Cheese Adventure World, its new indoor…
  - (2026-09-29) [St. Louis] Film screenings to catch this month
      The spookiest season is upon us once again, and as the temperatures are finally cooling down, it’s time to settle in with some Halloween movie favorites and more at theaters all around St. Louis. The Hi-Pointe has plenty…

### U.S. Weather + Severe / Climate Outlooks — 142 new of 144 total
  - (2026-09-30) [Severe] Flood Warning: Flood Warning issued September 30 at 9:14AM EDT by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Astor affecting Volusia and Lake Counties. .The St Johns River at Astor remains within Minor Flood Stage due to tidal effects. Riv…
  - (2026-09-30) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-30) [Severe] Special Marine Warning: Special Marine Warning issued September 30 at 9:12AM EDT until September 30 at 9:30AM EDT by NWS Key West FL
      For the following areas... Hawk Channel and Straits of Florida from west end of Seven Mile Bridge to Halfmoon Shoal out 20 nm... Gulf of America from west end of Seven Mile Bridge to Halfmoon Shoal out to 5 fathoms... At…
  - (2026-09-30) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 30 at 8:08AM CDT until September 30 at 11:00AM CDT by NWS La Crosse WI
      * WHAT...Visibility 1/4 mile or less in dense fog. * WHERE...In Iowa, Floyd, Mitchell, Chickasaw, Fayette, Howard, and Winneshiek Counties. In Minnesota, Fillmore County. * WHEN...Until 11 AM CDT this morning. * IMPACTS.…
  - (2026-09-30) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 30 at 8:52AM EDT until September 30 at 10:00AM EDT by NWS Charleston SC
      * WHAT...Visibility less than one mile in dense fog. * WHERE...A portion of southeast Georgia. * WHEN...Until 10 AM EDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-09-30) [Moderate] Gale Warning: Gale Warning issued September 30 at 5:51AM PDT until October 1 at 9:00AM PDT by NWS Eureka CA
      * WHAT...North winds 20 to 30 kt with gusts up to 35 kt and seas 10 to 12 feet. * WHERE...Waters from Cape Mendocino to Pt. Arena CA from 10 to 60 nm. * WHEN...Until 9 AM PDT Thursday. * IMPACTS...Strong winds will cause…

### State Legislative Action — 70 new of 75 total
  - (2026-09-30) [Alaska HB 303] An Act relating to the registration and titling of legally imported motor vehicles; and providing for an effective date.
      An Act relating to the registration and titling of legally imported motor vehicles; and providing for an effective date.
  - (2026-09-30) [Alaska HB 157] An Act relating to the effect of a decree of adoption or termination of parental rights on the legal relationship between a person and the person's siblings; and providing for an effec…
      An Act relating to the effect of a decree of adoption or termination of parental rights on the legal relationship between a person and the person's siblings; and providing for an effective date.
  - (2026-09-30) [Alaska HB 188] An Act establishing the welcoming Alaska office; establishing the welcoming Alaska center; establishing the Welcoming Alaska Advisory Committee; repealing the office of citizenship ass…
      An Act establishing the welcoming Alaska office; establishing the welcoming Alaska center; establishing the Welcoming Alaska Advisory Committee; repealing the office of citizenship assistance; and providing for an effect…
  - (2026-09-30) [Alaska HB 377] An Act relating to public records; relating to managing and preserving audio and video recordings; and relating to fees for the inspection and copying of public records under the Alask…
      An Act relating to public records; relating to managing and preserving audio and video recordings; and relating to fees for the inspection and copying of public records under the Alaska Public Records Act.
  - (2026-09-30) [Alaska HB 376] An Act relating to early intervention services for certain children; relating to optional services under the medical assistance program; and providing for an effective date.
      An Act relating to early intervention services for certain children; relating to optional services under the medical assistance program; and providing for an effective date.
  - (2026-09-30) [Alaska HB 272] An Act relating to insurance coverage for prosthetic and orthotic devices; relating to medical assistance for prosthetic and orthotic devices; and providing for an effective date.
      An Act relating to insurance coverage for prosthetic and orthotic devices; relating to medical assistance for prosthetic and orthotic devices; and providing for an effective date.

### Ukrainian Internal News (national + local Kyiv) — 70 new of 131 total
  - (2026-09-30) Кількість комерційних рейсів у ЄС зросла попри високі ціни на авіапаливо | LEDE: Кількість комерційних рейсів у ЄС зростала кожного літнього місяця порівняно з минулим роком, незважаючи на те, ] (uk:…
      Кількість комерційних рейсів у ЄС зростала кожного літнього місяця порівняно з минулим роком, незважаючи на те, що бойові дії на Близькому Сході призвели до здорожчання авіаційного палива.
  - (2026-09-30) Росія офіційно пригрозила НАТО ядерною зброєю через Калінінградську область – ЗМІ | LEDE: Москва попередила НАТО про готовність застосувати ядерну зброю за спроби ізоляції Калінінградської обла] (uk:…
      Москва попередила НАТО про готовність застосувати ядерну зброю за спроби ізоляції Калінінградської області. Альянс відповів, що не становить загрози РФ.
  - (2026-09-30) Допомога Україні перед зимою та російська блокада Чорного моря стануть темами саміту ЄС | LEDE: Лідери ЄС на саміті 15–16 жовтня закличуть посилити підтримку України перед зимою та обговорять н] (uk:…
      Лідери ЄС на саміті 15–16 жовтня закличуть посилити підтримку України перед зимою та обговорять наслідки російського блокування чорноморських експортних шляхів.
  - (2026-09-30) ЄС продовжить на 2 роки місію в Середземномор’ї для боротьби з "тіньовим флотом" РФ – ЗМІ | LEDE: ЄС розширює повноваження місії EUNavfor Med Irini для протидії російському «тіньовому флоту» та] (uk:…
      ЄС розширює повноваження місії EUNavfor Med Irini для протидії російському «тіньовому флоту» та захисту інфраструктури в Середземному морі.
  - (2026-09-30) Якщо Росія нападе: як готуються литовці і чому в українських біженців – дежавю | LEDE: ] (uk: Якщо Росія нападе: як готуються литовці і чому в українських біженців – дежавю)
  - (2026-09-30) План евакуації, тривожні валізи та спокій. Як Литва живе під загрозою російської агресії | LEDE: "Сирени лунатимуть по всій Литві – перевірка системи"] (uk: План евакуації, тривожні валізи та спокій.…
      "Сирени лунатимуть по всій Литві – перевірка системи"

### GDELT GKG — themes / entities / watch areas — 63 new of 63 total
  - (2026-09-30) [Russia oil sanctions perimeter · themes] Kenya : Govt to Deploy Assets , Infrastructure Fund for Sh2 . 2tn Lamu Refinery Investment - Ruto
      allafrica.com · English · tone NA
  - (2026-09-30) [Russia oil sanctions perimeter · themes] Летчик объяснил , откуда один из пилотов самолета Flydubai взял нож – Москва 24 , 30 . 09 . 2026
      m24.ru · Russian · tone NA
  - (2026-09-30) [Russia oil sanctions perimeter · themes] La Defensa Pública no puede sostenerse a costa de sus trabajadores :: El Diario de La Pampa
      eldiariodelapampa.com.ar · Spanish · tone NA
  - (2026-09-30) [Russia oil sanctions perimeter · themes] EE . UU refuerza bloqueo a Cuba ; impone nuevas restricciones – Radio Santa Fe 1070 a . m . Noticias de Colombia
      radiosantafe.com · Spanish · tone NA
  - (2026-09-30) [Russia oil sanctions perimeter · themes] Dax aktuell : Inflation steigt – Dax dreht ins Minus
      handelsblatt.com · German · tone NA
  - (2026-09-30) [Russia oil sanctions perimeter · themes] Wetterwende bringt Regen und Gewitter nach Deutschland
      fnp.de · German · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 41 new of 58 total
  - (2026-09-30) [BleepingComputer] TeamViewer urges users to patch severe flaws “as soon as possible”
      Remote access software company TeamViewer warned customers on Tuesday to immediately patch a set of high-severity vulnerabilities affecting its client and host software. [...]
  - (2026-09-30) [BleepingComputer] Bitget hacked via zero-day in third-party security products
      Cryptocurrency exchange Bitget revealed today that attackers who stole $387.5 million last week breached its systems after exploiting a zero-day flaw in third-party security products. [...]
  - (2026-09-30) [BleepingComputer] Microsoft is rolling out Linux container support to WSL
      Microsoft is taking Windows Subsystem for Linux beyond just running Linux distributions, as WSL Containers is now generally available. [...]
  - (2026-09-30) [The Hacker News] Know Your Enemy: Browser-Based Attack Techniques in 2026
      Given that the browser is where business apps are accessed and used, it makes sense that attacks are happening there too. Most breaches today begin in a browser session. Often, they never leave it, with the entire attack…
  - (2026-09-30) [The Hacker News] AI Coding Agents Exposed 13,000 Internal Images, Including Billing Records, on GitHub
      AI coding agents asked to share screenshots of code changes for review have put internal company images in public GitHub repositories, security company Glow said. Its researchers found more than 13,000 internal images fr…
  - (2026-09-30) [The Hacker News] US-Focused CSuite Phishing Steals Microsoft 365 Sessions and Deploys RMM Tools for Remote Access
      ANY.RUN researchers traced a US-focused CSuite phishing campaign across 351 sandbox analyses, with 51% of submissions coming from the United States. Technology, manufacturing, government, and consulting organizations sho…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-30) 497 - Natixis Funds Trust IV (0001095726) (Filer)
      filed 2026-09-30 13:14 UTC — Filed: 2026-09-30 AccNo: 0001133228-26-012981 Size: 6 KB
  - (2026-09-30) 424B5 - Digimarc Corp (0002119322) (Filer)
      filed 2026-09-30 13:14 UTC — Filed: 2026-09-30 AccNo: 0001437749-26-031539 Size: 155 KB
  - (2026-09-30) 497 - BNY MELLON MIDCAP INDEX FUND, INC. (0000875732) (Filer)
      filed 2026-09-30 13:13 UTC — Filed: 2026-09-30 AccNo: 0000030146-26-000442 Size: 8 KB
  - (2026-09-30) 497 - BNY MELLON INDEX FUNDS, INC. (0000857114) (Filer)
      filed 2026-09-30 13:13 UTC — Filed: 2026-09-30 AccNo: 0000030146-26-000442 Size: 8 KB
  - (2026-09-30) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-09-30 13:12 UTC — Filed: 2026-09-30 AccNo: 0001918704-26-029630 Size: 523 KB
  - (2026-09-30) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-09-30 13:12 UTC — Filed: 2026-09-30 AccNo: 0001918704-26-029630 Size: 523 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-09-30) RCH703 (United States)
      icao24: adfdb7 · position: (50.5144, 10.4987) · alt: 5516m · 537km/h
  - (2026-09-30) RCH705 (United States)
      icao24: adfdb6 · position: (50.1623, 13.3566) · alt: 4206m · 431km/h
  - (2026-09-30) PAT322 (United States)
      icao24: adfe51 · position: (40.2236, -78.8973) · alt: 7315m · 474km/h
  - (2026-09-30) AF2 (United States)
      icao24: adfeb8 · position: (35.9221, -79.6834) · alt: 10370m · 998km/h
  - (2026-09-30) JEDI52 (United States)
      icao24: ae1eab · position: (31.06, -87.7081) · alt: 1638m · 468km/h
  - (2026-09-30) RCH5010 (United States)
      icao24: adfdbe · position: (38.6752, 12.2438) · alt: 5821m · 579km/h

### U.S. Federal Action — 24 new of 24 total
  - (2026-09-30) Gold Star Mother's and Family's Day, 2026
  - (2026-09-30) Medical Devices; Gastroenterology-Urology Devices; Classification of the Flushing and Storage Solution for Vascular Autografts at Room Temperature
      The Food and Drug Administration (FDA) is classifying the flushing and storage solution for vascular autografts at room temperature into class II (special controls). The special controls that apply to the device type are…
  - (2026-09-30) Medicare Program; FY 2027 Hospice Wage Index and Payment Rate Update and Hospice Quality Reporting Program Requirements; Correction
      This document corrects technical errors in the final rule that appeared in the August 3, 2026 Federal Register titled "Medicare Program; FY 2027 Hospice Wage Index and Payment Rate Update and Hospice Quality Reporting Pr…
  - (2026-09-30) Television Broadcasting Services Norwell, Massachusetts
      This document amends the Table of TV Allotments (table) of the Federal Communications Commission's (Commission) rules by substituting channel 10 for channel 36 at Norwell, Massachusetts in response to a Petition for Rule…
  - (2026-09-30) Regulation D: Reserve Requirements of Depository Institutions
      The Board of Governors of the Federal Reserve System ("Board") has adopted final amendments to its Regulation D to revise the rate of interest paid on balances ("IORB") maintained at Federal Reserve Banks by or on behalf…
  - (2026-09-30) Regulation A: Extensions of Credit by Federal Reserve Banks
      The Board of Governors of the Federal Reserve System ("Board") has adopted final amendments to its Regulation A to reflect the Board's approval of an increase in the rate for primary credit at each Federal Reserve Bank.…

### Paper Trading Scorecard — 18 new of 125 total
  - (2026-09-30) [Manifold] Daily Coinflip
  - (2026-09-30) [Manifold] Will I find someone from Manifold Markets to do flat viewings for me in London?
  - (2026-09-30) [Manifold] Will AI technology and infrastructure and AI itself become extinct before 2100?
  - (2026-09-30) [Manifold] Will Iran’s parliament hold a vote on initiating withdrawal from the Nuclear Non-Proliferation Treaty (NPT) before 2027?
  - (2026-09-30) [Manifold] Does Claude Opus 5.5 make egregious errors?
  - (2026-09-30) [Manifold] Azerbaijan defeat Liechtenstein ?

### Government Action: Sanctions + Procurement + Foreign Agents — 18 new of 114 total
  - (2026-09-29) [OFAC] Counter Narcotics, Counter Terrorism, Iran-related, and Non-Proliferation Designations - Office of Foreign Assets Control (.gov)
      Counter Narcotics, Counter Terrorism, Iran-related, and Non-Proliferation Designations Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] Publication of Regulatory Amendments; Publication of Cuba Sanctions Regulations; Issuance of New and Amended Cuba-related Frequently Asked Questions; Publication of Cuba-related OFAC Alert - Of…
      Publication of Regulatory Amendments; Publication of Cuba Sanctions Regulations; Issuance of New and Amended Cuba-related Frequently Asked Questions; Publication of Cuba-related OFAC Alert Office of Foreign Assets Contro…
  - (2026-09-29) [OFAC] BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 515 Cuban Assets Control Regulat - Office of Foreign Assets Control (.gov)
      BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 515 Cuban Assets Control Regulat Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] OFAC Alert Expanded Sanctions Against Cuba - Office of Foreign Assets Control (.gov)
      OFAC Alert Expanded Sanctions Against Cuba Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] 765. May persons subject to U.S. jurisdiction open an office in Cuba? - Office of Foreign Assets Control (.gov)
      765. May persons subject to U.S. jurisdiction open an office in Cuba? Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] Los Mayos Narco-Corruption in Baja California - Office of Foreign Assets Control (.gov)
      Los Mayos Narco-Corruption in Baja California Office of Foreign Assets Control (.gov)

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-09-30) M 5.6 - 74 km S of Yonakuni, Japan
      M5.6 · 74 km S of Yonakuni, Japan · depth 10.792 km
  - (2026-09-30) M 5.4 - Balleny Islands region
      M5.4 · Balleny Islands region · depth 10 km
  - (2026-09-30) M 5.2 - Balleny Islands region
      M5.2 · Balleny Islands region · depth 10 km
  - (2026-09-30) M 5.1 - 121 km S of Kokopo, Papua New Guinea
      M5.1 · 121 km S of Kokopo, Papua New Guinea · depth 28.026 km
  - (2026-09-30) M 5.0 - 27 km N of Kupang, Indonesia
      M5.0 · 27 km N of Kupang, Indonesia · depth 19.368 km
  - (2026-09-30) M 5.0 - 83 km NE of Tadine, New Caledonia
      M5.0 · 83 km NE of Tadine, New Caledonia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-09-30) China Open: Nuno Borges vs Novak Djokovic
      yes price: 0% · 24h volume: $1,511,112 · resolves 2026-10-07
  - (2026-09-30) Dota 2: BetBoom Team vs OG (BO3) - BLAST Slam Group C
      yes price: 30% · 24h volume: $1,178,408 · resolves 2026-09-30
  - (2026-09-30) Will there be no change in Fed interest rates after the October 2026 meeting?
      yes price: 66% · 24h volume: $973,466 · resolves 2026-10-29
  - (2026-09-30) Will the Fed increase interest rates by 25 bps after the October 2026 meeting?
      yes price: 34% · 24h volume: $818,479 · resolves 2026-10-29
  - (2026-09-30) Will Benjamin Netanyahu be the next Prime Minister of Israel?
      yes price: 34% · 24h volume: $755,772 · resolves 2026-10-28
  - (2026-09-30) LoL: T1 Academy vs Galions - Game 2 Winner
      yes price: 100% · 24h volume: $517,179 · resolves 2026-09-30

### World News (by country, top stories) — 12 new of 12 total
  - (2026-09-30) [China] Ford participates in Michigan LIFT to boost US automotive supply chains
      just-auto.com · English
  - (2026-09-30) [China] Highway Roop acquires fellow Indian automotive parts manufacturer
      just-auto.com · English
  - (2026-09-30) [China] South Africa Poised to Become Key Player in Global Rare Earth Supply Chain by 2034 【 SMM Analysis 】
      news.metal.com · English
  - (2026-09-30) [China] Why Mars has stopped referring to the human in the loop
      warc.com · English
  - (2026-09-30) [China] Tibetan Associations Across North America Observe Tibetan National Identity Preservation Week – Central Tibetan Administration
      tibet.net · English
  - (2026-09-30) [China] Google Pixel 11a CAD - based renders leak showing more of the same
      gsmarena.com · English

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-09-29) U.S. Court of Appeals, 10th Cir.: Phillips v. Boilermaker-Blacksmith National Pension Trust
  - (2026-09-29) U.S. Court of Appeals, D.C. Cir.: Solon Phillips v. WCP Fund I LLC
  - (2026-09-29) U.S. Court of Appeals, 11th Cir.: Bruce Henry v. Sheriff of Tuscaloosa County, Alabama
  - (2026-09-29) U.S. Court of Appeals, 1st Cir.: President and Fellows of Harvard College v. Harvard Graduate Students Union - UAW, Local 5118
  - (2026-09-29) U.S. Court of Appeals, 9th Cir.: San Carlos Apache Tribe v. United States Forest Service
  - (2026-09-29) U.S. Court of Appeals, 9th Cir.: Kane v. Pacap Aviation Finance, LLC

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 9 new of 47 total
  - (2026-09-30) [crypto] BTC: $85,398.0000 (24h: +1.26%)
      price=$85398 mcap=$1,716,510,626,545 vol24=$32,756,770,046 chg24=1.2577017744384706%
  - (2026-09-30) [crypto] ETH: $2,732.7900 (24h: -0.02%)
      price=$2732.79 mcap=$333,729,969,211 vol24=$13,981,660,576 chg24=-0.02169808734878913%
  - (2026-09-30) [crypto] USDT: $0.9997 (24h: -0.01%)
      price=$0.999655 mcap=$183,805,698,140 vol24=$61,760,542,523 chg24=-0.014204047965926577%
  - (2026-09-30) [crypto] USDC: $0.9998 (24h: -0.01%)
      price=$0.999817 mcap=$74,304,712,224 vol24=$16,825,837,578 chg24=-0.011434903149315211%
  - (2026-09-30) [crypto] BNB: $777.0900 (24h: +1.54%)
      price=$777.09 mcap=$103,499,489,786 vol24=$938,412,923 chg24=1.5378461534093961%
  - (2026-09-30) [crypto] SOL: $122.3600 (24h: +1.24%)
      price=$122.36 mcap=$71,932,156,643 vol24=$4,043,431,208 chg24=1.238583307238995%

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-30) [Marginal Revolution] Trump Administration Limits Predatory Lending in Education
      The New Republic writes “President Trump is banning students majoring in degrees that don’t make enough money from taking out college loans.” Yes, but do note that no student is banned from any major and the lending rule…
  - (2026-09-30) [Marginal Revolution] *Shade*
      The author is Sam Bloch, and the subtitle is The Promise of a Forgotten Natural Resource. An interesting book on a neglected topic, here is one excerpt: Shade is not part of L.A.’s modern identity. In the 1930s, the city…
  - (2026-09-30) [Marginal Revolution] Don’t let AI make you dumber
      That is the topic of my latest Free Press column, here is one excerpt: I do not think the skeptics would put it this way, but as I read Conti, I find he has a pretty bleak fundamental view of humanity. Are we all really…
  - (2026-09-29) [Conversable Economist] Interview with Ariel Pakes: The Inner Workings of Product Markets
      Jeff Horwich serves as interlocutor in “Interview with Ariel Pakes: To understand the broader economy, unlock the inner workings of product markets” (Federal Reserve Bank of Minneapolis, September 25, 2026). Pakes is an…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### EPSS — highest exploit-probability CVEs — 3 new of 40 total
  - (2026-09-29) CVE-2024-7593: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-09-29) CVE-2024-3400: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-09-29) CVE-2025-53770: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 19 total
  - (2026-09-29) CVE-2026-86950 · Apple Multiple Products: Apple Multiple Products Out-of-Bounds Write Vulnerability
      vendor: Apple · product: Multiple Products · CISA remediation by 2026-10-02

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-30) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=18, 14d-median=18; carrying terms: proposed, final, state, program, certain, provisions, model, national, action, published, issuing, management
- state_bills: today=75, 7d-median=120, 14d-median=105; carrying terms: unless, provisions, require, vests, duties, within, california, regulates, entity, public, license, members
- state_news: today=824, 7d-median=604, 14d-median=683; carrying terms: azgovernor, calls, outside, illinois, recovery, schools, voted, families, public, exceeded, voice, least
- local_news: today=247, 7d-median=231, 14d-median=231; carrying terms: louis, accused, public, tuesday, atlantamagazine, following, crash, death, suspect, people, georgia, against
- foreign_news: today=1018, 7d-median=1018, 14d-median=1019; carrying terms: orders, finance, battle, schools, families, product, exceeded, least, charges, rising, nuclear, leaders
- chinese_internal: today=302, 7d-median=270, 14d-median=274; carrying terms: cbmiykfvx, firms, people, cbmizkfvx, google, cbmibkfvx, cbmigwfbvv, caixin, cbmiakfvx, lxtfb, cbmia, cbmixkfvx
- russian_internal: today=1022, 7d-median=1011, 14d-median=1029; carrying terms: journal, found, russian, media, httperror, laquo, title, europe, novaya, street, novayagazeta, politico
- ukrainian_internal: today=131, 7d-median=129, 14d-median=134; carrying terms: censor, sanctions, stronger, missiles, polish, hybrid, powered, study, title, attacked, military, least
- ukraine_theater: today=662, 7d-median=379, 14d-median=427; carrying terms: ekvqylj, cuxocetzn, cnvichb, klwrysnfib, thpet, suvzbc, zeqyzhzzcmm, nddfrhzwtqdjvom, deepstatemap, hsfjblthjmk, vsodv, zunnjsbu
- paper_bets: today=125, 7d-median=120, 14d-median=124; carrying terms: arizona, jinping, kalshi, colonize, washington, house, december, johnson, become, mexico, zohran, hampshire
- weather: today=144, 7d-median=144, 14d-median=121; carrying terms: louis, short, portions, pontiac, degrees, illinois, northeast, caribbean, montgomery, moderate, tampa, statement
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dcoilwtico, walcl, inflation, cpilfesl, recession, headline, openings, personal, indicator, unemployment, labor, pcepilfe
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, bitcoin, large, agriculture, natural, nasdaq, silver, yield, corporate, credit, treasury, china
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=114, 7d-median=103, 14d-median=104; carrying terms: situation, sevastopol, sanctions, resolutions, events, recognition, legislation, hybrid, violations, crimea, threatening, combat
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, quiverquant, quiver, httperror, error, congresstrading, quantitative, client, https
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, appeals, commissioner, court, arizona, delaware, state, international, connecticut, corporation, trade, association
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed, holdings, filer, trust, financial, technology, investment, subject, finance
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: sherrod, warner, cooper, house, johnson, booker, cortez, cycle, james, talarico, receipts, david
- gdelt_regions: today=12, 7d-median=6, 14d-median=6; carrying terms: english, south, japan
- gdelt_gkg: today=63, 7d-median=52, 14d-median=50; carrying terms: english, sanctions, trump, russian, perimeter, russia, themes, chinese, spanish, german, serbian, south
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, germany, canada, samuidf
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: caused, illness, situation, december, cvdpv, result, critically, ethiopia, alerted, resulting, increases, seasonal
- cisa_kev: today=19, 7d-median=18, 14d-median=19; carrying terms: bounds, products, write, google, improper, vulnerability, engine, authorization, cisco, overflow, product, traversal
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=17, 7d-median=17, 14d-median=15; carrying terms: indonesia, depth, islands, colombia, south, region, japan, tonga, guinea, tadine, sandwich, chile
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, donetsk, champions, shakhtar, championship, league, september, meeting, interest, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, economist, https, class, revolution, conversableeconomist, basic, marginal, wealth, marginalrevolution, economics, think
- tech_news: today=58, 7d-median=57, 14d-median=57; carrying terms: hacker, intelligence, critical, going, openai, bleepingcomputer, newsletter, infrastructure, edition, technica, techcrunch, according
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: tenney, valadao, harrigan, louis, relations, rogers, adviser, banks, franklin, carlos, spartz, bessent
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, module, consensus, sufficient, evidence, converges, markets, identify, market, unavailable, placement, decision

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-23] ECB press: Almost ten million people took part in ECB survey on new euro banknotes
- [2026-09-23] Fed speeches: Barr, A Long-Term View on the Costs of Shelter
- [2026-09-23] ECB press: The digitalisation of money, payments and finance
- [2026-09-23] ECB press: Philip R. Lane: The Outlook for the Euro Area Economy
- [2026-09-24] ECB press: Philip R. Lane: The outlook for the euro area economy
- [2026-09-24] ECB press: ECB Executive Board member Isabel Schnabel to resign to take senior role at IMF
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board requests public comment on two proposals related to establishing a regulatory framework for Board-supervised payment stablecoin issuers under the GENIUS Act
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.
- [2026-09-28] ECB press: Christine Lagarde: Hearing of the Committee on Economic and Monetary Affairs of the European Parliament
- [2026-09-28] Fed speeches: Cook, An Update on AI and the Economy
- [2026-09-29] ECB press: ECB amends monetary policy implementation guidelines as part of regular review

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*