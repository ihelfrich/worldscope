# WORLDSCOPE morning brief — 2026-08-24

## Headline
3430 new items across 24 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (881) · International News + Multilateral Institutions (713) · Russian Internal News (state + in-exile) (633) · World leaders & government officials (324) · Chinese Internal News (214) · U.S. Weather + Severe / Climate Outlooks (149) · Local News: St. Louis + Atlanta (135) · State-Level News (92) · Ukrainian Internal News (national + local Kyiv) (49) · Forbes Real-Time Billionaires (top 30 + biggest movers) (34) · Sanctions & Designations (recent) (30) · Government & military aircraft airborne (OpenSky) (29)

## What changed today
### Ukraine Theater (total-war monitoring) — 881 new of 1165 total
  - (2026-08-23) [FIRMS] thermal anomaly 50.486, 34.943 (FRP 6.14 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-23 0911Z, FRP 6.14 MW
  - (2026-08-23) [FIRMS] thermal anomaly 50.488, 34.951 (FRP 9.27 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-23 0911Z, FRP 9.27 MW
  - (2026-08-23) [FIRMS] thermal anomaly 50.485, 34.944 (FRP 7.82 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-23 0911Z, FRP 7.82 MW
  - (2026-08-23) [FIRMS] thermal anomaly 51.285, 34.198 (FRP 11.01 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-23 0911Z, FRP 11.01 MW
  - (2026-08-23) [FIRMS] thermal anomaly 51.285, 34.198 (FRP 10.82 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-23 0911Z, FRP 10.82 MW
  - (2026-08-23) [FIRMS] thermal anomaly 51.473, 34.249 (FRP 7.16 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-23 0911Z, FRP 7.16 MW

### International News + Multilateral Institutions — 713 new of 948 total
  - (2026-08-23) [Global] Landslide at waste mound in Guinea capital kills 30, government says
  - (2026-08-23) [Global] ‘No more!!!’: Trump lashes out after US-Canada talks devolve into trade war
  - (2026-08-23) [Global] The lesson from Canada’s collapsed trade talks with the US: negotiation may be futile
  - (2026-08-24) [Global] Fast-fashion giant Shein sets cut-price $27bn valuation for Hong Kong IPO
  - (2026-08-24) [Global] New Zealand to consider banning children under 16 from social media
  - (2026-08-24) [Global] Hanson-Young says men should ‘call out’ boys’ club culture – as it happened

### Russian Internal News (state + in-exile) — 633 new of 815 total
  - (2026-08-24) «Это избавит нас от дилеммы: выходить или нет». Пашинян заявил, что «будет рад», если ОДКБ исключит Армению | LEDE: Премьер-министр Армении Никол Пашинян заявил, что «будет очень рад», если ] (ru: «Эт…
      Премьер-министр Армении Никол Пашинян заявил, что «будет очень рад», если страну исключат из ОДКБ.
  - (2026-08-24) «В большой войне не будет победителей, и сама Россия не способна победить». Залужный написал еще одну колонку — теперь для украинского NV | LEDE: Пока в Кремле считают, что распада СССР не д] (ru: «В…
      Пока в Кремле считают, что распада СССР не должно было произойти, российская стратегия будет исключать любые компромиссы. Но это ошибка и для руководства России: одержимость идеей исправления истории привела к большой во…
  - (2026-08-24) Умер хореограф Дмитрий «Тадж» Баймурадов. Его недавно обвинили в сексуализированном насилии | LEDE: Умер хореограф и танцор Дмитрий «Тадж» Баймурадов, сообщил в инстаграме его брат Сулейман ] (ru: Уме…
      Умер хореограф и танцор Дмитрий «Тадж» Баймурадов, сообщил в инстаграме его брат Сулейман Баймурадов. «Вы хотели мяса? Получайте! Брат мой сделал последний выход», — написал он.
  - (2026-08-24) Акции Ozon на Мосбирже упали более чем на 28% после ударов дронов Украины по складам маркетплейса | LEDE: Котировки акций Ozon после открытия основной торговой сессии на Мосбирже снизились н] (ru: Акц…
      Котировки акций Ozon после открытия основной торговой сессии на Мосбирже снизились на 12,7%, до отметки в 2600 рублей. Индекс Мосбиржи в начале торгов опустился до 2092 пунктов, что на 2% ниже уровня закрытия предыдущей…
  - (2026-08-24) The Economist: в закрытом опросе на тему президентских выборов в Украине бывший министр обороны Михаил Федоров занял третье место. На втором — Залужный | LEDE: В неопубликованном опросе на т] (ru: The…
      В неопубликованном опросе на тему гипотетических президентских выборов в Украине третье место занял бывший министр обороны Михаил Федоров с 16% голосов, пишет журнал The Economist, ознакомившийся с результатами.
  - (2026-08-24) Минфин предложил поддержать Wildberries отсрочкой от уплаты налогов и приостановкой проверок до конца года | LEDE: Министерство финансов РФ внесло в правительство меры поддержки для группы R] (ru: Мин…
      Министерство финансов РФ внесло в правительство меры поддержки для группы RWB (Объединенная компания Wildberries & Russ) и продавцов, потерявших товары в результате атак украинских беспилотников.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 214 new of 245 total
  - (2026-08-24) AIM-424“恶意”超远程空对空导弹浮出水面 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFAzQk1tUVBEcjE1dlJiLWNJdVVpTlZITHQ0S2V3WUk0d1NoZGVZVnVPenB6Qlp5UXpDalpFallpUnkwVkxyY3BwWV9sc19MLX] (zh:…
      AIM-424“恶意”超远程空对空导弹浮出水面 风闻
  - (2026-08-23) 英媒爆料：史无前例！伊朗黑客成功瘫痪英国发电厂 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9DVGZQbFpwZzZLNzNkdkhRcXhXdFBxSFk4azdhTEY4NWNkaXRfTG1MSXpZbXhSTXNjUGJwc3lWZTgtNWgtRkpOZ1pZR1FVS] (zh:…
      英媒爆料：史无前例！伊朗黑客成功瘫痪英国发电厂 观察者
  - (2026-08-23) 老人进店休息离世，店家帮扶遭索赔10万，派出所两次协商后赔1.9万元 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE90NGlHbHlSS2RWWFVsMFk2U1JQOXpGTHg2NXZrMm1NMU15bmdtYmRSMi1lX2FyWHdXRkludDI3NW9uX1FLLT] (zh:…
      老人进店休息离世，店家帮扶遭索赔10万，派出所两次协商后赔1.9万元 观察者
  - (2026-08-22) “白菜收购环节蘸甲醛保鲜”，张家口通报：情况属实 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE9sdTJnVTJhZk5adXRNeExMck5wdEpvcUd5TXpBUUx5RGpyTmJaX01BVTh2WXZxOXFtekFUZWNKNUNxZUczd0tYeUZMQmhx] (zh:…
      “白菜收购环节蘸甲醛保鲜”，张家口通报：情况属实 观察者
  - (2026-08-23) 泽连斯基遭遇逼宫，最新回应 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBHdkRCQkhSeGRldlA2U0tjS21wNWozdXZyWUFHWnVGdVpyRTJCMGhGRUUxNUxjcjUxRGRzUndMZFh6U3BzaXJZbGdHZGZ0c0VGNi10VEx] (zh:…
      泽连斯基遭遇逼宫，最新回应 观察者
  - (2026-08-24) 七成民众说不，美官员急喊：不能让中国赢 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1aT0hzRnhBR3plX01zUmI3b2xDdU9yWlRkcXdzYV84cXJEZ0RZekotR1hJdnBLTlZPSHh6d2haNC1BbTJYandTa3BCeHZTYWx6N] (zh:…
      七成民众说不，美官员急喊：不能让中国赢 观察者

### U.S. Weather + Severe / Climate Outlooks — 149 new of 151 total
  - (2026-08-24) [Moderate] Special Weather Statement: Special Weather Statement issued August 24 at 4:20AM CDT by NWS Little Rock AR
      At 419 AM CDT, Doppler radar was tracking a strong thunderstorm 8 miles southwest of Piercetown, or 9 miles south of Jasper, moving southeast at 30 mph. HAZARD...Winds in excess of 40 mph and half inch hail. SOURCE...Rad…
  - (2026-08-24) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 24 at 5:18AM EDT until August 24 at 5:45AM EDT by NWS Raleigh NC
      At 518 AM EDT, severe thunderstorms were located along a line extending from near Hoffman to 9 miles west of Raeford to near Wakulla, moving northeast at 25 mph. HAZARD...60 mph wind gusts and nickel size hail. SOURCE...…
  - (2026-08-24) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-24) [Severe] Special Marine Warning: Special Marine Warning issued August 24 at 5:13AM EDT until August 24 at 5:30AM EDT by NWS Newport/Morehead City NC
      For the following areas... Waters from Ocracoke Inlet to Cape Lookout NC from 20 to 60 NM... At 512 AM EDT, a severe thunderstorm capable of producing waterspouts was located 24 nm east of Atlas Tanker, moving east at 15…
  - (2026-08-24) [Moderate] Special Weather Statement: Special Weather Statement issued August 24 at 4:12AM CDT by NWS Little Rock AR
      At 412 AM CDT, Doppler radar was tracking a strong thunderstorm near Eula, or 14 miles southeast of Jasper, moving southeast at 30 mph. HAZARD...Winds in excess of 40 mph and half inch hail. SOURCE...Radar indicated. IMP…
  - (2026-08-24) [Moderate] Special Weather Statement: Special Weather Statement issued August 24 at 5:09AM EDT by NWS Wilmington NC
      At 508 AM EDT, Doppler radar was tracking strong thunderstorms along a line extending from Hoffman to near Maxton. Movement was northeast at 20 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar indi…

### Local News: St. Louis + Atlanta — 135 new of 194 total
  - (2026-08-24) [St. Louis] The 40th anniversary of ‘Harp Attack!’ shines a light on St. Louis’ rich harmonica history
  - (2026-08-24) [St. Louis] Sean Grayson, former cop convicted of killing Sonya Massey, dies
  - (2026-08-24) [St. Louis] Lou’s Clues – 8/24/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-08-24) [St. Louis] See the Aug. 24, 1926, front page: Valentino burial to be in America, funeral Monday
      Headlines from the Aug. 24, 1926, front page include: Bank employee's books found to be $16,000 short
  - (2026-08-24) [St. Louis] New laws go into effect Friday
      Plus: Kirkwood took millions from its electric utility, treated it like 'slush fund' before crash
  - (2026-08-24) [St. Louis] 'I LEARNED FROM A GREAT TEACHER'
      School nurse Erin Rimkus, left, talks with April Maldonado, center, and her son Christian Maldonado before an all-district gathering of teachers Tuesday, Aug. 18, 2026, at Kirkwood High School. Christian is a new teacher…

### State-Level News — 92 new of 189 total
  - (2026-08-23) [Arkansas] Arkansas led the way on vaccinations. It shouldn’t follow Trump backward in time.
      Anger and policy aren’t always good combinations. Betty Bumpers, however, proved that there’s an exception to that rule. The former first lady of Arkansas was dismayed when her husband, Gov. Dale Bumpers, took office and…
  - (2026-08-23) [Arkansas] East Texas sits on a goldmine of lithium. Questions loom about regulation.
      TEXARKANA — When Scott Norton became president of the TexAmericas Center, he hoped the industrial park would attract employers that would bring much-needed jobs to North East Texas. Little did he know the industrial cent…
  - (2026-08-23) [Arkansas] Why truckers always seem to be on the phone while they drive on the highway
      This story was originally published by CalMatters. Sign up for their newsletters. The calls started rolling in nonstop to Fresno trucker Gurinderjit Singh as he prepared for an out-of-state delivery earlier this summer.…
  - (2026-08-24) [Florida] For two years, Florida Juvenile Justice department ducked records request
      Nearly two years since the Department of Juvenile Justice received a records request from the Florida Phoenix, it remains unfulfilled. Despite fulfilling a nearly identical request in 2024 within three months, the depart…
  - (2026-08-23) [Florida] Uthmeier’s found another windmill to tilt at
      Florida Attorney General James Uthmeier is a busy, busy bee, darting from human trafficking prosecutions to going after shoplifting gangs to trying to outlaw drag queen Christmas shows to accusing Microsoft of anti-Chris…
  - (2026-08-24) [Connecticut] A legacy behind the heels: My 38 years with Nancy Wyman
      <img width="1024" height="881" src="https://ctmirror.org/wp-content/uploads/2015/11/Malloy-Wyman-after-budget-talks-e1510855846209.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding=…

### Ukrainian Internal News (national + local Kyiv) — 49 new of 109 total
  - (2026-08-24) Сибіга після зустрічі з очільницею МЗС Швеції: Gripen готуються захищати небо України | LEDE: Міністр закордонних справ Андрій Сибіга провів переговори з главою МЗС Швеції Марією Мальмер Стенер] (uk:…
      Міністр закордонних справ Андрій Сибіга провів переговори з главою МЗС Швеції Марією Мальмер Стенергард, яка прибула до Києва 24 серпня.
  - (2026-08-24) Фундамент української незалежності | LEDE: Україна святкує 35 років незалежності: сильна армія, активне суспільство та успіхи у боротьбі з корупцією.] (uk: Фундамент української незалежності)
      Україна святкує 35 років незалежності: сильна армія, активне суспільство та успіхи у боротьбі з корупцією.
  - (2026-08-24) Лукашенко привітав українців із Днем Незалежності: побажав "здоров'я і миру" | LEDE: Самопроголошений президент Білорусі Олександр Лукашенко привітав український народ із тридцять п'ятою річниц] (uk:…
      Самопроголошений президент Білорусі Олександр Лукашенко привітав український народ із тридцять п'ятою річницею Дня Незалежності, не згадавши, що його режим уже 5 років підтримує війну Росії проти України.
  - (2026-08-24) Король Британії у День Незалежності висловив захоплення стійкістю українців | LEDE: ] (uk: Король Британії у День Незалежності висловив захоплення стійкістю українців)
  - (2026-08-24) Свято-Успенська Святогірська лавра заявила про напад на братію: є загиблий і поранені | LEDE: У Святогірській лаврі група невідомих напала на братію: один монах загинув, ще двоє людей поранені ] (uk:…
      У Святогірській лаврі група невідомих напала на братію: один монах загинув, ще двоє людей поранені – лавра
  - (2026-08-24) ЗМІ: Уряд Канади очікує довготривалої торгової війни зі США | LEDE: ] (uk: ЗМІ: Уряд Канади очікує довготривалої торгової війни зі США)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 34 new of 34 total
  - (2026-08-24) #1 Elon Musk — $856.89B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-08-24) #2 Larry Page — $281.86B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-08-24) #3 Jeff Bezos — $266.64B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-08-24) #4 Sergey Brin — $260.01B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-08-24) #5 Michael Dell — $236.19B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-08-24) #6 Larry Ellison — $189.02B
      United States · Technology · source: Oracle · holdings: ORCL-US(NYSE), ORCL-US(NYSE), PSKY-US(NASDAQ), SPCX-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-24) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (47.862, 1.8648) · alt: 8694m · 786km/h
  - (2026-08-24) RFF07 (Portugal)
      icao24: 496ca7 · position: (37.013, -7.966) · on ground · 11km/h
  - (2026-08-24) CFC2983 (Canada)
      icao24: c2b55d · position: (54.068, -3.2378) · alt: 7620m · 557km/h
  - (2026-08-24) GAF788 (Germany)
      icao24: 3f59f3 · position: (49.821, 12.3037) · alt: 8229m · 985km/h
  - (2026-08-24) JAF66L (Belgium)
      icao24: 44d1ba · position: (50.1721, 2.9449) · alt: 7155m · 762km/h
  - (2026-08-24) JAF1YV (Belgium)
      icao24: 44d1a7 · position: (39.0022, 22.8636) · alt: 11582m · 824km/h

### Paper Trading Scorecard — 25 new of 140 total
  - (2026-08-24) [Polymarket] Will a 1+ Year Enrichment Moratorium be in a US-Iran deal in 2026?
      This market resolves to “Yes” if a written diplomatic instrument between the United States and Iran that creates a moratorium on all enrichment of uranium for Iran for a period of at least one year has been mutually sign…
  - (2026-08-24) [Polymarket] Will the Communist Party of the Russian Federation (KPRF) win the second-most seats in the next Russian parliamentary election?
      Parliamentary elections are scheduled to be held in Russia in September 2026. This market will resolve according to the political party that wins the second greatest number of seats in the next Russian State Duma electio…
  - (2026-08-24) [Polymarket] Will Alexander Vindman be the Democratic nominee for Senate in Florida?
      This market will resolve according to the winner of the Democratic Primary for United States Senator from Florida. If no 2026 Florida Democratic Senate Primary takes place, this market will resolve to "Other". The resolu…
  - (2026-08-24) [Manifold] Will any of Levent Alpöge’s mathematical results with Claude be proven flawed by the end of the year?
  - (2026-08-24) [Manifold] Will my company make a sale today?
  - (2026-08-24) [Manifold] Daily Coinflip

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-24) [Israel-Iran-Hezbollah axis · keywords] US envoy Barrack clarifies remarks on Iran and Hezbollah
      naharnet.com · English · tone NA
  - (2026-08-24) [Israel-Iran-Hezbollah axis · keywords] Greek involvement in Cyprus - Erdogan equips the Occupied Territories for major conflict with Israel
      bankingnews.gr · English · tone NA
  - (2026-08-24) [Israel-Iran-Hezbollah axis · keywords] UN expert urges peacekeepers in Palestinian territories as settler attacks surge
      arabherald.com · English · tone NA
  - (2026-08-24) [Israel-Iran-Hezbollah axis · keywords] Deadline Detroit | Michigan AG Dana Nessel Asks : Is There Room In Democratic Party For People Who Believe in Israel Right to Exist ?
      deadlinedetroit.com · English · tone NA
  - (2026-08-24) [Israel-Iran-Hezbollah axis · keywords] Uganda and Burundi military officials visit Israel to discuss Gaza troop deployment
      krmg.com · English · tone NA
  - (2026-08-24) [Israel-Iran-Hezbollah axis · keywords] Jeffries - Kushner meeting : Democrats prepare deeper collaboration with Trump White House after election
      wsws.org · English · tone NA

### USGS earthquakes (M4.5+, past day) — 19 new of 19 total
  - (2026-08-23) M 6.0 - 33 km SSW of Honchō, Japan
      M6.0 · 33 km SSW of Honchō, Japan · depth 42.867 km
  - (2026-08-23) M 5.3 - 120 km W of Lata, Solomon Islands
      M5.3 · 120 km W of Lata, Solomon Islands · depth 10 km
  - (2026-08-23) M 5.3 - southern Mid-Atlantic Ridge
      M5.3 · southern Mid-Atlantic Ridge · depth 10 km
  - (2026-08-23) M 5.2 - 61 km NE of Ruteng, Indonesia
      M5.2 · 61 km NE of Ruteng, Indonesia · depth 10 km
  - (2026-08-23) M 5.0 - 228 km ESE of Attu Station, Alaska
      M5.0 · 228 km ESE of Attu Station, Alaska · depth 13.186 km
  - (2026-08-24) M 4.9 - 10 km NNW of Cot, Costa Rica
      M4.9 · 10 km NNW of Cot, Costa Rica · depth 10 km

### IT, InfoSys & cybersecurity news (last 7 days) — 19 new of 55 total
  - (2026-08-24) [The Hacker News] UAT-10147 Uses AI to Scale Server Attacks, Deploys SPECTRE With EDR Bypass and Linux Rootkit
      Cybersecurity researchers have disclosed details of a Chinese-speaking cybercrime group dubbed UAT-10147 that's targeting Windows and Linux web servers globally across the education, media, technology, and gaming sectors…
  - (2026-08-24) [Cybersecurity Dive] Salesforce gave every org the same free scanner. Attackers already know what it misses.
      A defense every attacker can rehearse against isn't a defense. It's a false sense of security.
  - (2026-08-24) [The Register] Canonical backs quest to translate mountains of C into safe Rust with AI
      Bungs banknotes at Bristol boffins to find out if mature code survives the machine
  - (2026-08-24) [The Register] Software should work, and talking about it needn't be boring
      Bingeing the boxed set of binary bafflement
  - (2026-08-24) [The Register] China calls off ambitious ice-hunting moonshot a day before flight
      Chang'e 7 didn’t meet unspecified ‘launch requirements’
  - (2026-08-24) [The Register] Batch file automated a clean-up job, then fouled itself by deleting the wrong directory
      It survived testing and the boss signed off, so who was really to blame?

### Prediction Markets — most-traded (Polymarket) — 18 new of 20 total
  - (2026-08-24) Clarity Act (H.R.3633) signed into law in 2026?
      yes price: 16% · 24h volume: $1,318,137 · resolves 2027-01-01
  - (2026-08-24) Will Málaga CF win on 2026-08-24?
      yes price: 40% · 24h volume: $501,759 · resolves 2026-08-24
  - (2026-08-24) LoL: DN SOOPers Challengers vs Kiwoom DRX Challengers (BO5) - LCK Challengers League Play-In
      yes price: 100% · 24h volume: $434,744 · resolves 2026-08-24
  - (2026-08-24) LoL: DN SOOPers Challengers vs Kiwoom DRX Challengers - Game 3 Winner
      yes price: 0% · 24h volume: $369,135 · resolves 2026-08-24
  - (2026-08-24) Will Chelsea FC win on 2026-08-24?
      yes price: 52% · 24h volume: $362,243 · resolves 2026-08-24
  - (2026-08-24) Will there be no change in Fed interest rates after the September 2026 meeting?
      yes price: 68% · 24h volume: $338,372 · resolves 2026-09-16

### World News (by country, top stories) — 12 new of 12 total
  - (2026-08-24) [Japan] Dark Horse Preview : Concrete : Stars Over Sand # 3
      fandompost.com · English
  - (2026-08-24) [Japan] The vast impacts of a dry Danube
      nuclear-news.net · English
  - (2026-08-24) [Japan] DOE Again Denies Access to Defense Nuclear Facilities Safety Board ( DNFSB ) at Nuclear Weapons Facilities ; Contact Your Elected Officials
      nuclear-news.net · English
  - (2026-08-24) [Japan] Dark Horse Preview : Concrete : Grendel : Devil Crucible – Sedition # 2
      fandompost.com · English
  - (2026-08-24) [Japan] Dark Horse Preview : Hidden Springs # 4
      fandompost.com · English
  - (2026-08-24) [Japan] Dark Horse Preview : Hidden Springs # 4
      fandompost.com · English

### Court opinions of consequence (federal & state) — 11 new of 60 total
  - (2026-08-20) U.S. Court of Appeals, 11th Cir.: Delta Air Lines, Inc. v. U.S. Department of Transportation
  - (2026-08-20) U.S. Court of Appeals, 11th Cir.: Annette Kingsolver v. U.S. Attorney General
  - (2026-08-20) U.S. Court of Appeals, 2nd Cir.: Juca v. Banks
  - (2026-08-20) Delaware Supreme Court: Holloman v. State
  - (2026-08-20) Delaware Supreme Court: Project Labrador Holdco, LLC v. Bakkt Opco Holdings, LLC
  - (2026-08-20) D.C. Court of Appeals: Burton as Trustee of the EB Trust v. Chase Point Unit Owners Ass'n

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 101 total
  - (2026-08-21) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-08-24) [USASpending] $41,316,801,718 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-08-24) [USASpending] $34,404,438,770 → CONSOLIDATED NUCLEAR SECURITY, LLC: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 N
      Agency: Department of Energy. Description: IGF::CL,CT::IGF MANAGEMENT AND OPERATING CONTRACT FOR Y-12 NATIONAL SECURITY COMPLEX, PANTEX PLANT, WITH AN OPTION FOR SAVANNAH RIVER TRITIUM OPERATIONS
  - (2026-08-24) [USASpending] $10,518,464,548 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration. Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF…
  - (2026-08-24) [USASpending] $4,426,530,857 → NORTHROP GRUMMAN SYSTEMS CORPORATION: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WI
      Agency: National Aeronautics and Space Administration. Description: FIRST DDT AND E, ARES I-X, AND FLIGHT TESTS. FIRST STAGE WILL BE A FIVE SEGMENT, SOLID ROCKET BOOSTER DERIVED FROM THE SPACE SHUTTLE PROGRAM (SSP) SOLID…
  - (2026-08-24) [USASpending] $3,205,729,526 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…

### State Legislative Action — 5 new of 62 total
  - (2026-08-23) [California AB 1651] State Bar of California: artificial intelligence.
      Existing law, the State Bar Act, provides for the licensure and regulation of attorneys by the State Bar of California (State Bar) , a public corporation governed by a board of trustees. Existing law authorizes the State…
  - (2026-08-23) [California AB 2624] Privacy for immigration support services providers.
      Existing law authorizes designated health care services providers, employees, volunteers, and patients, and individuals who face threats of violence or violence or harassment from the public because of their affiliation…
  - (2026-08-23) [California SB 1126] Local agencies: financial postings.
      Existing law requires, within 7 months after the close of each fiscal year or within the time prescribed by the Controller, whichever is later, the officer of each local agency, as defined, who has charge of the financia…
  - (2026-08-23) [California AB 2789] Mediation: child custody and visitation.
      Existing law requires the court, for purposes of deciding custody, to determine the best interests of the child based on certain factors, including the nature and amount of contact with both parents and, consistent with…
  - (2026-08-23) [California SB 1133] Pupil instruction: preventative health instruction.
      Existing law requires the adopted courses of study for grades 1 to 6, inclusive, and 7 to 12, inclusive, to offer instruction and courses in certain areas of study, including, among others, physical education, with empha…

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-08-24) [Marginal Revolution] I DJ for Rick Rubin about music and patriotism
      MUSIC EPISODE: “You think you understand patriotism, you have your hands around it–it’s the simple thing, but it turns out it’s not. And maybe, music and the history of music shows us all that better than mere discourse…
  - (2026-08-23) [Marginal Revolution] Sunday assorted links
      1. “Underestimating something that has an AI “accent” by reflexively dismissing it as slop rhymes curiously with underestimating someone because they have a funny accent in your native language (and it isn’t one of the a…
  - (2026-08-23) [Marginal Revolution] Democracy and Caeserism
      In my 2015 post discussing Joseph Heath’s excellent book Enlightenment 2.0, I had this to say: One of the reasons that I oppose the extension of democratic politics into every aspect of modern life is precisely that in t…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-24) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=14, 7d-median=14, 14d-median=20; carrying terms: proposes, action, certain, proposing, national, establish, proposed, public, within, airworthiness, establishing, specifically
- state_bills: today=62, 7d-median=134, 14d-median=129; carrying terms: obtain, including, comprehensive, social, agencies, others, natural, commission, director, grant, office, violence
- state_news: today=189, 7d-median=597, 14d-median=597; carrying terms: found, because, current, construction, commonwealthbeacon, often, prison, hospital, access, amendment, schools, colorado
- local_news: today=194, 7d-median=235, 14d-median=229; carrying terms: found, suspect, county, inside, following, charges, murder, court, people, police, google, opening
- foreign_news: today=948, 7d-median=978, 14d-median=1007; carrying terms: independent, rsshub, battle, threats, suspect, single, adult, promote, match, explained, reaffirms, hospital
- chinese_internal: today=245, 7d-median=284, 14d-median=271; carrying terms: global, cbmix, cbmiakfvx, lxtfa, china, caixin, people, google, market, cbmibefvx, cbmizkfvx, articles
- russian_internal: today=815, 7d-median=1030, 14d-median=1040; carrying terms: httperror, found, politico, europe, forbidden, wildberries, media, street, title, client, russian, novaya
- ukrainian_internal: today=109, 7d-median=114, 14d-median=114; carrying terms: independent, found, study, expected, increasingly, remains, continue, strikes, refinery, visit, intelligence, foreign
- ukraine_theater: today=1165, 7d-median=887, 14d-median=1025; carrying terms: mettnejutzdoymt, nffer, nvcwd, lrgjwvwfovwvbugjrnw, cuxpyzkwwmxjrddbtzfeqm, governorate, ktvtjtvxnubhztegpcajfjn, cbmiigfbvv, vtrwjvrkdoywluvndwbu, cuxoa, aexvnnjaewvhcxrbnjq, cbmiyafbvv
- paper_bets: today=140, 7d-median=135, 14d-median=139; carrying terms: goldman, human, fuentes, supervolcano, miami, levels, kalshi, chase, primary, industrial, jinping, approve
- weather: today=151, 7d-median=151, 14d-median=177; carrying terms: wednesday, continues, including, cooling, effect, impact, fulton, current, miami, normal, currents, overnight
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unrate, growth, dexjpus, vixcls, dcoilwtico, consumption, openings, jolts, crude, energy, dexuseu, cpilfesl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, large, silver, agriculture, commodities, equities, bitcoin, close, treasury, china, range, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=101, 7d-median=96, 14d-median=96; carrying terms: legislation, laboratory, systems, illegal, human, respect, relation, abuses, armed, military, bissau, effects
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, client, unauthorized, error, quiver, quiverquant, congresstrading, https, quantitative
- billionaires: today=34, 7d-median=34, 14d-median=34; carrying terms: berkshire, francoise, trading, googl, india, exchange, madrid, china, infrastructure, telecom, bloomberg, adani
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, state, appeals, supreme, company, connecticut, international, trust, general, america, center, trade
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, management, holdings, partners, michael, technology, vincent, gigacloud, xiang
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, robert, receipts, shawn, sherrod, house, alexandria, ocasio, warner, michael, cortez, graham
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: japan, english, korea, south, koreaherald
- gdelt_gkg: today=25, 7d-median=25, 14d-median=37; carrying terms: english, trump, greek, israel, hezbollah, keywords, business, israeli, travel, military, hamas, attacks
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, france, germany, kingdom, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: laboratory, acute, found, continues, infant, fatal, travel, years, human, including, investigations, majority
- cisa_kev: today=12, 7d-median=12, 14d-median=10; carrying terms: ancillary, injection, cisco, firewall, adaptive, vendor, vulnerability, windows, microsoft, winsock, authentication, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=315, 14d-median=315
- usgs_quakes: today=19, 7d-median=19, 14d-median=19; carrying terms: depth, indonesia, ruteng, japan, islands, region, philippines, south, tonga, chile, sandwich, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: league, resolves, interest, shakhtar, rates, price, winner, august, donetsk, september, champions, volume
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, class, marginal, https, conversable, economist, conversableeconomist, impossible, links, wrote, assorted, because
- tech_news: today=55, 7d-median=55, 14d-median=56; carrying terms: systems, schneier, including, edition, digital, publicly, released, models, problems, researchers, computer, weekly
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: trading, jodey, pocan, tulsi, rivas, goldman, jahana, trahan, schmitt, spartz, boebert, jason
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, identify, sufficient, market, placed, either, converges, consensus, evidence, module, placement, paper

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*