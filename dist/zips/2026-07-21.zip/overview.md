# WORLDSCOPE morning brief — 2026-07-21

## Headline
2280 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (533) · Russian Internal News (state + in-exile) (415) · World leaders & government officials (324) · Chinese Internal News (205) · Ukraine Theater (total-war monitoring) (163) · State Legislative Action (158) · U.S. Weather + Severe / Climate Outlooks (158) · State-Level News (64) · Local News: St. Louis + Atlanta (53) · SEC Form 4 insider transactions (recent) (40) · Ukrainian Internal News (national + local Kyiv) (33) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 533 new of 993 total
  - (2026-07-21) [Global] Trump slaps 50% tariffs on Canada and Carney vows to 'intensify' trade talks
      The duties mark a major escalation in trade tensions between the North American neighbours.
  - (2026-07-21) [Global] 'Anti-ICE' Army veteran set fire outside Manhattan federal building, say officials
      Andrew Arrabaca, 43, was armed with two axes, a machete, three knives and fireworks, says the FBI.
  - (2026-07-21) [Global] At least 27 dead and 83 missing after passenger ferry capsizes off Guyana
      An investigation into the tragedy has been launched, the island's prime minister says, adding he hopes more will be found alive.
  - (2026-07-20) [Global] Paramount and Warner Bros mega merger paused by judge
      US court temporarily stops Paramount and Warner Bros merging after 12 states launched legal action.
  - (2026-07-21) [India] No decision to increase ethanol blending with petrol beyond 20%: Petroleum MoS
  - (2026-07-21) [India] Don't allow sand quarries in river beds: PMK leader Anbumani Ramadoss

### Russian Internal News (state + in-exile) — 415 new of 886 total
  - (2026-07-21) Федеральный суд в США приостановил слияние Paramount и Warner Bros. | LEDE: Судья окружного суда в Окленде (штат Калифорния) Арасели Мартинес-Ольгин на две недели приостановила покупку Warne] (ru: Фед…
      Судья окружного суда в Окленде (штат Калифорния) Арасели Мартинес-Ольгин на две недели приостановила покупку Warner Bros. с компанией Paramount. Стоимость сделки оценивается в 110 миллиардов долларов.
  - (2026-07-21) Аэропорт Внуково купит у Шереметьево часть Домодедово | LEDE: Московский аэропорт Внуково выкупит у Шереметьево 25% компании, которая контролирует группу «Домодедово». Сумма сделки, по данны] (ru: Аэр…
      Московский аэропорт Внуково выкупит у Шереметьево 25% компании, которая контролирует группу «Домодедово». Сумма сделки, по данным РБК, составит 16,5 миллиарда рублей.
  - (2026-07-21) ФСБ обвинила жителя Тюмени в подготовке теракта на одном из предприятий Урала. При задержании его убили | LEDE: Сотрудники ФСБ убили при задержании жителя Тюмени, которого спецслужба обвинил] (ru: ФСБ…
      Сотрудники ФСБ убили при задержании жителя Тюмени, которого спецслужба обвинила в подготовке теракта на «одном из ключевых предприятий Уральского федерального округа». Сообщение Центра общественных связей (ЦОС) ФСБ распр…
  - (2026-07-21) «Коммерсант»: российские НПЗ возобновляют продажу бензина на бирже. Объем торгов резко сократился из-за топливного кризиса | LEDE: Российские нефтеперерабатывающие заводы постепенно возвраща] (ru: «Ко…
      Российские нефтеперерабатывающие заводы постепенно возвращаются к продажам топлива на Петербургской бирже. Такой вывод, пишет «Коммерсант» , можно сделать из обзора аналитического агентства Platts, с которым ознакомилось…
  - (2026-07-21) Тайвань впервые замедлит мобильный интернет во время учений по гражданской обороне | LEDE: Власти Тайваня впервые замедлят скорость мобильного интернета во время ежегодных учений по гражданс] (ru: Тай…
      Власти Тайваня впервые замедлят скорость мобильного интернета во время ежегодных учений по гражданской обороне, которые пройдут в августе. Таким образом они хотят проверить, как граждане будут коммуницировать в случае чр…
  - (2026-07-21) Президент Никарагуа Даниэль Ортега объявил, что в его стране больше не будет выборов | LEDE: Даниэль Ортега, занимающий пост президента Никарагуа с 2007 года, объявил, что в стране больше ни] (ru: Пре…
      Даниэль Ортега, занимающий пост президента Никарагуа с 2007 года, объявил, что в стране больше никогда не будут проводить выборы, сообщает Reuters. Такая мера, заявил он, необходима, чтобы оппозиция не пришла к власти.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 205 new of 283 total
  - (2026-07-19) 世界杯决赛西阿大战，数据一网打尽 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBEclpKYzlpcFlUOXJKZk1jMzBwNDRBeE5fZWt4QnlrYTJyaE1ORnBTY0NaQnB3aUtSZzNmQUlkU040aUQ5ZEM0NWRhdXFOUnl5QWNxZ] (zh:…
      世界杯决赛西阿大战，数据一网打尽 财新
  - (2026-07-21) 国泰海通人工智能投融资论坛成功举行_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBKbkQ5V0hoQnlBTExlaXRzVXhhd3EteTlhMUZNckMwVEF4R1RjX256ZU8xT0l6bEMxa1Vqc0ZMQmpON2pSMlhqUVBoX] (zh:…
      国泰海通人工智能投融资论坛成功举行_特别呈现_手机财新网 财新
  - (2026-07-21) 今日开盘：两市双双高开 沪指涨幅0.42% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1RQmNmQnhWVmxRWlh3SWZxSl9YOXJVaDBrMGRUcjZKOFo5NjFzYk5udjhMb3FfN3VWeEJsMXBOZ243V1dMdmVZMHVNR01KbU9l] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.42% 财新
  - (2026-07-21) 年近古稀的我，居然也混入了Hyrox2026世锦赛！｜亲历 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBibDE4ZUFzank3TVVGM0JWd1o3emNsQ01kUXlqQVMweXlIUVVmd2dTYmpnelp5NmNSdzdmb3RsVzB6ME1aQVlBczFx] (zh:…
      年近古稀的我，居然也混入了Hyrox2026世锦赛！｜亲历 财新
  - (2026-07-21) 智能体挑战个人信息保护 各方热议法律边界 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE1YeEozblNYenYyYmNjLUxLT0FoR2J5clRpbzllbnFlOWpCQVR0dUh2ZkFLZWFZX0FFbHkyQ0h1TkFES3FhWkp] (zh:…
      智能体挑战个人信息保护 各方热议法律边界 china.caixin.com
  - (2026-07-21) 特稿｜LV诉茉莉奶白侵权 纹样商标化边界何在？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9wbl8tU1d5TTVfYzVkS1FIaUlGcU1KOHQ4SXhXeHdzeHdiTFo4TEdpVGN5RlNybDY3amEwQ1BSS0RiT1NxT3dKTjVyVU9zUU] (zh:…
      特稿｜LV诉茉莉奶白侵权 纹样商标化边界何在？ 财新

### Ukraine Theater (total-war monitoring) — 163 new of 625 total
  - (2026-07-20) [Liveuamap] Drones raid in Domodedovo, Moscow region - Liveuamap
      Drones raid in Domodedovo, Moscow region Liveuamap
  - (2026-07-21) [Liveuamap] Israeli forces entered the village of al-Samdaniyah al-Sharqiyah in Syria&039;s Quneitra province with five military vehicles, set up a temporary checkpoint, and searched civilians. They a…
      Israeli forces entered the village of al-Samdaniyah al-Sharqiyah in Syria&039;s Quneitra province with five milit
  - (2026-07-21) [Liveuamap] Airstrike with glide bomb reported in the central part of Sloviansk - Liveuamap
      Airstrike with glide bomb reported in the central part of Sloviansk Liveuamap
  - (2026-07-18) [Liveuamap] The US State Department: We advise Americans to reconsider travel to the Middle East. - iran.liveuamap.com
      The US State Department: We advise Americans to reconsider travel to the Middle East.
  - (2026-07-19) [Liveuamap] Explosion in Zaporizhzhia reported 0, Ukraine - Ukraine Interactive map - Ukraine Latest news on live map - Liveuamap
      Explosion in Zaporizhzhia reported 0, Ukraine - Ukraine Interactive map - Ukraine Latest news on live map Li
  - (2026-07-19) [Liveuamap] An elite residential complex in central Moscow is on fire, trapping around nine people, including children, inside. - Liveuamap
      An elite residential complex in central Moscow is on fire, trapping around nine people, including children, inside.

### State Legislative Action — 158 new of 217 total
  - (2026-07-21) [Colorado HB 1176] Modify Fourth-Year Innovation Pilot Program
      Under the fourth-year innovation pilot program (program), each year the general assembly appropriates an amount to the department of education (department) for the department to distribute to local education providers fr…
  - (2026-07-21) [Colorado HB 1045] Disabilities Housing Protections
      The act specifies relevant factors for assessing reasonable accommodations related to assistance animals that may be necessary for an individual with a disability to have an equal opportunity to use and enjoy housing und…
  - (2026-07-21) [District of Columbia B 26-0747] Schedule of Fines Rulemaking Approval and Authority Emergency Act of 2026
      Schedule of Fines Rulemaking Approval and Authority Emergency Act of 2026
  - (2026-07-21) [District of Columbia B 26-0732] Prearrest Diversion Task Force Recommendations Emergency Amendment Act of 2026
      Prearrest Diversion Task Force Recommendations Emergency Amendment Act of 2026
  - (2026-07-21) [District of Columbia B 26-0719] Letter Contract and Modification Nos. M001, M002, M003, M004 and M005 to Contract No. CW120680 with Vector Fleet Management, LLC Approval and Payment Authorization Eme…
      Letter Contract and Modification Nos. M001, M002, M003, M004 and M005 to Contract No. CW120680 with Vector Fleet Management, LLC Approval and Payment Authorization Emergency Act of 2026
  - (2026-07-21) [District of Columbia B 26-0759] Medical Cannabis Licensing and Unlicensed Establishment Enforcement Clarification Emergency Amendment Act of 2026
      Medical Cannabis Licensing and Unlicensed Establishment Enforcement Clarification Emergency Amendment Act of 2026

### U.S. Weather + Severe / Climate Outlooks — 158 new of 174 total
  - (2026-07-21) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-21) [Moderate] Tropical Cyclone Local Statement: Tropical Cyclone Local Statement issued July 21 at 4:21AM CDT by NWS Mobile AL
      HLSMOB This product covers portions of southwest Alabama...northwest Florida...south central Alabama...and inland southeast Mississippi. **TROPICAL STORM BERTHA WILL BRING COASTAL AND OFFSHORE IMPACTS LATER TODAY THROUGH…
  - (2026-07-21) [Moderate] Special Weather Statement: Special Weather Statement issued July 21 at 1:18AM AKDT by NWS Fairbanks AK
      At 118 AM AKDT, Doppler radar was tracking a cluster of strong thunderstorms 56 miles north of Cleary Summit, or 59 miles northwest of Twelvemile Summit, moving northwest at 25 mph. HAZARD...Pea size hail. SOURCE...Radar…
  - (2026-07-21) [Moderate] Special Weather Statement: Special Weather Statement issued July 21 at 3:17AM MDT by NWS Salt Lake City UT
      At 317 AM MDT, Doppler radar was tracking strong thunderstorms along a line extending from 11 miles east of Fillmore to 11 miles west of Marysvale. Movement was west at 25 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...…
  - (2026-07-21) [Severe] Flood Watch: Flood Watch issued July 21 at 5:16AM EDT until July 22 at 2:00AM EDT by NWS Charleston WV
      * WHAT...Flash flooding caused by excessive rainfall continues to be possible. * WHERE...Portions of northeast Kentucky, including the following counties, Boyd, Carter, Greenup and Lawrence, southeast Ohio, including the…
  - (2026-07-21) [Severe] Tropical Storm Watch: Tropical Storm Watch issued July 21 at 4:10AM CDT by NWS Mobile AL
      * WHAT...Southwest winds 20 to 30 kt with gusts up to 35 kt and seas 8 to 13 ft. Highest winds will be located over the open Gulf waters. * WHERE...Pensacola Bay System, Western Choctawhatchee Bay, Eastern Choctawhatchee…

### State-Level News — 64 new of 478 total
  - (2026-07-21) [California] Governor Newsom announces appointments 7.20.26
      Source
  - (2026-07-21) [Connecticut] It’s a bird! It’s a plane! It’s a very expensive collision!
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/BIRD-STRIKES-071526-JL-013-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fet…
  - (2026-07-21) [Connecticut] CT ratepayers pay the price when utility bullying goes unchecked
      <img width="545" height="300" src="https://ctmirror.org/wp-content/uploads/2026/07/Electric-bill.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="htt…
  - (2026-07-21) [Connecticut] State land ownership doesn’t equal stewardship
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/BATTERSON-PARK-0630-JL-004-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loa…
  - (2026-07-21) [Connecticut] CT’s pre-K endowment diverts pension dollars
      <img width="907" height="372" src="https://ctmirror.org/wp-content/uploads/2026/06/Reason-report-graphic.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" src…
  - (2026-07-20) [Hawaii] DLNR News Release – PROGRESS OF PUʻUHONUA O WAIʻANAE POW MOVE TO MAUKA FARM VILLAGE July 20, 2026
      STATE OF HAWAIʻI KA MOKU ʻĀINA O HAWAIʻI JOSH GREEN, M.D. GOVERNOR KE KIAʻĀINA DEPARTMENT OF LAND AND NATURAL RESOURCES KA ‘OIHANA KUMUWAIWAI ‘ĀINA RYAN K.P. KANAKA‘OLE […]

### Local News: St. Louis + Atlanta — 53 new of 198 total
  - (2026-07-21) [St. Louis] Where Art Thou? – 7/21/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-07-21) [St. Louis] Genre-bending songs from St. Louis artists you need to hear
  - (2026-07-20) [St. Louis] AI-generated political ad in St. Charles County raises deepfake questions ahead of primary election - First Alert 4
      <a href="https://news.google.com/rss/articles/CBMizAFBVV95cUxPcGdqdXdqaG05S3VUb28xNGRUZmFHTFh1TGRXQjh3U2tyOVAzOU9WeUdKX1ZFQk5jRXV5bHFqTGM0aVF6Tmh4WlhsOTAwMmZMVG5lblFwSEtWM2J6ZTZhdWo2ZnV6WlNaTmpQZEg1Wm1XYTRST09OX0l4dmItdz…
  - (2026-07-19) [St. Louis] ‘Go touch some grass’: Nolan Wells’ mom says she’s receiving hate mail after the death of her son - First Alert 4
      <a href="https://news.google.com/rss/articles/CBMiwwFBVV95cUxNamE5ZlJtc1hubkdvVkFaWVZIS1lHNVM4bzIwYlBNcUJlUjdVOUNZb3lzcVhWN3dKR1NPMFlkbXdrOEZ6VHlUTEwwZGtmamhMWjBEbTNkUDJHRkIybE5YWUFqa29FVno2OGhRNHVuTEdlUXJTWVlJWXNyMzhyY2…
  - (2026-07-20) [Atlanta] Brent Key: No better place for combo of athletics, academics than Georgia Tech - AJC.com
      Brent Key: No better place for combo of athletics, academics than Georgia Tech AJC.com
  - (2026-07-20) [Atlanta] Opinion: Poorest Georgia communities are paying the price for illicit vapes - AJC.com
      Opinion: Poorest Georgia communities are paying the price for illicit vapes AJC.com

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-21) [Lally Robert B] Form 4 (Reporting)
      filed 2026-07-21 01:47 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0002126940-26-000004 Size: 7 KB
  - (2026-07-21) [ImageneBio, Inc.] Form 4 (Issuer)
      filed 2026-07-21 01:47 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0002126940-26-000004 Size: 7 KB
  - (2026-07-21) [Tomasello Vickie] Form 4 (Reporting)
      filed 2026-07-21 01:36 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0001493225-26-000088 Size: 8 KB
  - (2026-07-21) [Northfield Bancorp, Inc.] Form 4 (Issuer)
      filed 2026-07-21 01:36 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0001493225-26-000088 Size: 8 KB
  - (2026-07-21) [Patafio Frank P.] Form 4 (Reporting)
      filed 2026-07-21 01:36 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0001493225-26-000087 Size: 7 KB
  - (2026-07-21) [Northfield Bancorp, Inc.] Form 4 (Issuer)
      filed 2026-07-21 01:36 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0001493225-26-000087 Size: 7 KB

### Ukrainian Internal News (national + local Kyiv) — 33 new of 98 total
  - (2026-07-21) Литовська армія посилить охорону СПГ-термінала через загрозу провокацій з боку РФ | LEDE: Армія Литви найближчим часом посилить охорону термінала скрапленого природного газу (СПГ) у Клайпеді – ] (uk:…
      Армія Литви найближчим часом посилить охорону термінала скрапленого природного газу (СПГ) у Клайпеді – таке рішення прийняли на тлі попереджень про можливі провокації з боку Росії у країнах Балтії.
  - (2026-07-21) Двоє людей постраждали внаслідок російської атаки на Одесу | LEDE: 21 липня російські загарбники атакували Одесу, внаслідок чого пошкоджений житловий будинок і 17-річний хлопець і 23-річна дівч] (uk:…
      21 липня російські загарбники атакували Одесу, внаслідок чого пошкоджений житловий будинок і 17-річний хлопець і 23-річна дівчина.
  - (2026-07-21) Окупанти вдарили КАБами по житлових кварталах Запоріжжя: є загиблий і поранений | LEDE: Внаслідок удару російських військ керованими авіабомбами по житлових кварталах Запоріжжя одна людина заги] (uk:…
      Внаслідок удару російських військ керованими авіабомбами по житлових кварталах Запоріжжя одна людина загинула, ще одна поранена.
  - (2026-07-21) За останні кілька тижнів конфлікту з Іраном майже 100 військових США були пораненні | LEDE: З 7 липня майже 100 американських військовослужбовців отримали поранення різного ступеня тяжкості у м] (uk:…
      З 7 липня майже 100 американських військовослужбовців отримали поранення різного ступеня тяжкості у межах конфлікту з Іраном, розповіли у Пентагоні.
  - (2026-07-21) Радник президента Литви: Ентузіазм ЄС щодо санкцій проти Росії слабшає | LEDE: Старший радник президента Литви Дейвідас Матульоніс попередив, що всередині ЄС слабшає ентузіазм стосовно впровадж] (uk:…
      Старший радник президента Литви Дейвідас Матульоніс попередив, що всередині ЄС слабшає ентузіазм стосовно впровадження нових санкцій проти Росії.
  - (2026-07-21) Міністр юстиції Японії прибув до Києва | LEDE: Лід: Міністр юстиції Японії Мітані Хідехіро перебуває з візитом у Києві, де покладе квіти до Стіни пам’яті полеглих захисників України.] (uk: Міністр юст…
      Лід: Міністр юстиції Японії Мітані Хідехіро перебуває з візитом у Києві, де покладе квіти до Стіни пам’яті полеглих захисників України.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 21 new of 23 total
  - (2026-07-21) Order Sunsetting Certain Large Trader Reporting Requirements for Physical Commodity Swaps
      The Commodity Futures Trading Commission ("CFTC" or the "Commission") is issuing this Order pursuant to Sec. 20.9 of its regulations, the sunset provision of the Commission's large trader reporting rules for physical com…
  - (2026-07-21) Patient Protection and Affordable Care Act, HHS Notice of Benefit and Payment Parameters for 2027; and Basic Health Program; Correction
      This document corrects typographical errors in the final rule that appeared in the May 20, 2026, Federal Register titled "Patient Protection and Affordable Care Act, HHS Notice of Benefit and Payment Parameters for 2027;…
  - (2026-07-21) General Technical, Organizational, Conforming, and Correcting Amendments to the Federal Motor Carrier Safety Regulations
      FMCSA amends its regulations by making technical corrections throughout the Federal Motor Carrier Safety Regulations (FMCSR). The Agency makes minor changes to correct inadvertent errors and omissions, remove or update o…
  - (2026-07-21) USCIS Immigration Fees and Related Procedures Required by H.R.1 Reconciliation Bill; Correction
      This document corrects the interim final rule (IFR) that published in the Federal Register on April 29, 2026. The IFR codified certain immigration fees and other provisions required by the One Big Beautiful Bill Act (H.R…
  - (2026-07-21) Fisheries of the Northeastern United States; Summer Flounder Fishery; Quota Transfer From North Carolina to Massachusetts
      NMFS announces that the State of North Carolina is transferring a portion of its 2026 commercial summer flounder quota to the Commonwealth of Massachusetts. This adjustment to the 2026 fishing year quota is necessary to…
  - (2026-07-21) Magnuson-Stevens Act Provisions; Fisheries Off West Coast States; Pacific Coast Groundfish Fishery; Pacific Coast Groundfish Fishery Management Plan; Amendment 38; 2027-28 Biennial Specifications and…
      NMFS announces that the Pacific Fishery Management Council (Council) submitted amendment 38 to the Pacific Coast Groundfish Fishery Management Plan (Groundfish FMP) to the Secretary of Commerce for review. If approved, a…

### World News (by country, top stories) — 18 new of 18 total
  - (2026-07-21) [China] Move and win roundup : Week of July 20 , 2026
      campaignasia.com · English
  - (2026-07-21) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-21) [China] Tina Talk | One Germany , Three Clocks ( Part 2 )
      autonews.gasgoo.com · English
  - (2026-07-21) [China] 10歲就學會獨立 林熙蕾憶童年往事
      singtaousa.com · English
  - (2026-07-21) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-07-21) [China] 南海仁愛礁局勢 ： 中方基於人道主義准許菲方轉運傷員
      singtaousa.com · English

### Paper Trading Scorecard — 14 new of 145 total
  - (2026-07-21) [Polymarket] Will Lamine Yamal win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-07-21) [Polymarket] Will Trump meet with Benjamin Netanyahu in July 2026?
      This market will resolve to "Yes" if the listed individual meets with Donald Trump between July 1 and July 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". A meeting is defined as any encounter where b…
  - (2026-07-21) [Polymarket] Will Bitcoin reach $75,000 in July?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for BTC/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final High price equ…
  - (2026-07-21) [Polymarket] Iran invades Kuwait by July 31?
      This market will resolve to "Yes" if Iranian military forces enter Kuwait by the listed date, 11:59 PM ET in a military operation that establishes control over any portion of Kuwait territory. Otherwise, this market will…
  - (2026-07-21) [Polymarket] Hamad bin Isa Al Khalifa out as leader of Bahrain by December 31, 2026?
      This market will resolve to "Yes" if the King of Bahrain, Hamad bin Isa Al Khalifa, ceases to be the de facto leader of Bahrain at any point between market creation and December 31, 2026, 11:59 PM ET. Otherwise, this mar…
  - (2026-07-21) [Kalshi] Kylian Mbappe Total FIFA World Cup Career Goals
      Kylian Mbappe

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 57 total
  - (2026-07-21) [BleepingComputer] Microsoft shares manual fix for WSUS sync delays and timeouts
      Microsoft has shared manual mitigations to help IT administrators fix Windows Server Update Services (WSUS) servers affected by a known issue that causes Windows Update scans to fail or time out. [...]
  - (2026-07-21) [BleepingComputer] Windows LegacyHive zero-day flaw gets free, unofficial patches
      Free unofficial patches are available for a recently disclosed Windows zero-day flaw that allows attackers to escalate privileges on up-to-date Windows systems. [...]
  - (2026-07-21) [The Hacker News] WordPress wp2shell Exploitation Grows as Public Exploit Fuels Mass Scanning
      Attackers have begun to exploit two critical vulnerabilities in WordPress that, when combined together, enable unauthenticated remote code execution (RCE) and complete compromise of vulnerable websites. The two security…
  - (2026-07-21) [The Hacker News] New ENCFORGE Ransomware Targets AI Model Files in Langflow RCE Attack
      Researchers at Sysdig have linked a second attack on the same Langflow server to JADEPUFFER, the AI-agent-driven operator it first documented earlier this month. The same operator has now been spotted deploying ENCFORGE,…
  - (2026-07-21) [The Hacker News] Critical ServiceNow AI Platform Flaw Exploited for Unauthenticated Code Execution
      Threat actors are now exploiting a recently disclosed critical security flaw impacting ServiceNow AI Platform, according to Defused Cyber. In a post shared on X, the threat intelligence firm said it's observing in-the-wi…
  - (2026-07-21) [The Register] Some Mullvad VPN customers tunnel for exit after co-founder donates millions to populist party
      SEK 5M gift supplied 72 percent of Örebropartiet's annual income, but company insists it was strictly personal

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-07-21) Will Gretchen Whitmer win the 2028 US Presidential Election?
      yes price: 1% · 24h volume: $1,442,891 · resolves 2028-11-07
  - (2026-07-21) LoL: BNK FEARX vs Dplus KIA (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $1,241,746 · resolves 2026-07-21
  - (2026-07-21) LoL: Gen.G vs T1 (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $1,186,457 · resolves 2026-07-21
  - (2026-07-21) LoL: Gen.G vs Hanwha Life Esports (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $725,716 · resolves 2026-07-21
  - (2026-07-21) Will Gretchen Whitmer win the 2028 Democratic presidential nomination?
      yes price: 2% · 24h volume: $650,411 · resolves 2028-11-07
  - (2026-07-21) LoL: KT Rolster vs Dplus KIA (BO1) - KeSPA Cup Group Stage
      yes price: 96% · 24h volume: $456,533 · resolves 2026-07-21

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 38 total
  - (2026-07-21) MOVER ▲ Masayoshi Son — $67.52B (+$3.54B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-21) MOVER ▲ Tadashi Yanai & family — $67.53B (+$1.46B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-21) MOVER ▼ Mukesh Ambani — $88.44B ($-1.11B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-21) MOVER ▼ Bernard Arnault & family — $148.11B ($-0.95B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-21) MOVER ▲ Amancio Ortega — $136.84B (+$0.59B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-21) MOVER ▲ Gautam Adani — $90.26B (+$0.54B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### GDACS — global disaster alerts — 7 new of 186 total
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-20) [Green] Earthquake in Pacific-Antarctic Ridge
      Earthquake · Green alert · Pacific-Antarctic Ridge · Magnitude 5.5M, Depth:10km
  - (2026-07-20) [Green] Earthquake in Pacific-Antarctic Ridge
      Earthquake · Green alert · Pacific-Antarctic Ridge · Magnitude 5.5M, Depth:10km
  - (2026-07-20) [Green] Earthquake in Northern Mid-Atlantic Ridge
      Earthquake · Green alert · Northern Mid-Atlantic Ridge · Magnitude 5.6M, Depth:10km

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, D.C. Cir.: Heritage Foundation v. DOJ
  - (2026-07-20) U.S. Court of Appeals, 9th Cir.: Garcia Demetrio v. Blanche
  - (2026-07-17) U.S. Court of Appeals, 9th Cir.: United States v. Holcomb
  - (2026-07-16) Supreme Court of California: Maniago v. Desert Cardiology Consultants' Medical Group
  - (2026-07-16) D.C. Court of Appeals: Brooks v. Mitsubishi Electric & Electronics US, Inc.

### USGS earthquakes (M4.5+, past day) — 5 new of 17 total
  - (2026-07-21) M 5.2 - northern Mid-Atlantic Ridge
      M5.2 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-07-21) M 5.0 - Mid-Indian Ridge
      M5.0 · Mid-Indian Ridge · depth 10 km
  - (2026-07-20) M 5.0 - 141 km SSW of Gataivai, Samoa
      M5.0 · 141 km SSW of Gataivai, Samoa · depth 10 km
  - (2026-07-21) M 4.6 - 84 km SW of Puerto Madero, Mexico
      M4.6 · 84 km SW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-21) M 4.6 - south of the Fiji Islands
      M4.6 · south of the Fiji Islands · depth 204.561 km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-21) [Marginal Revolution] The economic effects of GLP-1s
      We estimate the causal impacts of GLP-1 treatment on labor market outcomes using linked Danish administrative data and a matched stacked difference-in-differences design. We compare patients who initiate GLP-1 treatment…
  - (2026-07-21) [Marginal Revolution] Is America ruled by an oligarchy?
      Any time you hear claims about American government, a sanity-inducing response is to ask whether they also are true of state and local governments. Here is an excerpt from my latest piece at The Free Press: First, in peo…

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 116 total
  - (2026-07-21) [BIS Entity List] page checksum 47a6bf4796c4
      Page content hash: 47a6bf4796c4. Compare with prior day's hash to detect updates.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-21) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=23, 7d-median=20, 14d-median=20; carrying terms: center, national, commission, approved, guard, regulatory, period, authorized, proposing, based, persons, local
- state_bills: today=217, 7d-median=124, 14d-median=124; carrying terms: privacy, approved, committee, whether, school, companies, retention, board, infrastructure, supervision, secretary, based
- state_news: today=478, 7d-median=472, 14d-median=472; carrying terms: throughout, lawyer, official, approved, breaks, whether, remarks, school, companies, right, region, infrastructure
- local_news: today=198, 7d-median=216, 14d-median=216; carrying terms: breaks, school, google, wanted, another, suspect, night, async, start, concerns, vehicle, attack
- foreign_news: today=993, 7d-median=1022, 14d-median=1022; carrying terms: lawyer, official, congo, breaks, improve, whether, arabnews, remarks, delays, tensions, school, hanoi
- chinese_internal: today=283, 7d-median=280, 14d-median=280; carrying terms: google, blank, politics, cbmicefvx, articles, cbmix, cbmiyefvx, cbmiakfvx, cbmiy, lxtfb, cbmib, target
- russian_internal: today=886, 7d-median=882, 14d-median=882; carrying terms: forbidden, title, laquo, istories, telegram, error, financial, europe, gazeta, media, journal, research
- ukrainian_internal: today=98, 7d-median=126, 14d-median=126; carrying terms: vladimir, campaign, others, backed, earlier, trump, region, invasion, infrastructure, another, secretary, greater
- ukraine_theater: today=625, 7d-median=512, 14d-median=512; carrying terms: nwnfrlwrhdg, qnhzrzu, kekrysy, approved, btqttgjzuvntlulnwkpkofdda, edzscg, school, companies, resistance, region, yuxmwluta, google
- paper_bets: today=145, 7d-median=144, 14d-median=144; carrying terms: goals, artist, receives, celsius, emirates, official, california, humanoid, predictit, rippling, polymarket, republicans
- weather: today=174, 7d-median=170, 14d-median=170; carrying terms: louis, currents, effect, caused, corridor, humid, prolonged, norton, region, mount, period, greater
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexuseu, treasury, payems, effective, spread, vixcls, payrolls, cpilfesl, total, headline, rates, inflation
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, treasury, russell, large, silver, credit, crypto, equities, range, futures, rates, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=116, 7d-median=116, 14d-median=116; carrying terms: mediterranean, facilitate, federation, california, congo, campaign, company, jjmudpzw, illegal, launch, trump, docket
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, https, httperror, error, client, quiver, quantitative, unauthorized, congresstrading
- billionaires: today=38, 7d-median=33, 14d-median=33; carrying terms: tiktok, semiconductors, warren, italy, berkshire, ortega, tokyo, brokerage, buffett, japan, china, telecom
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, district, california, children, trucks, company, school, america, delaware, general, truck, appeals
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, issuer, accno, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: appretices, trone, disbursements, graham, filing, action, cooper, committee, journeymen, senate, local, alexandria
- gdelt_regions: today=18, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=0, 7d-median=45, 14d-median=45; carrying terms: english, israel, trump, perimeter, russian, sanctions, hezbollah, chinese, russia
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=20, 14d-median=20
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=20, 14d-median=20
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: kingdom, evolve, national, infant, death, geographical, mediterranean, geographic, official, process, substantial, congo
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: authentication, vendor, cisco, server, deserialization, product, remediation, improper, traversal, forgery, microsoft, sharepoint
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=186, 7d-median=156, 14d-median=156; carrying terms: green, orange, italy, congo, austria, poland, belarus, minor, drought, ecuador, vietnam, maximum
- usgs_quakes: today=17, 7d-median=18, 14d-median=18; carrying terms: depth, south, madero, mexico, kermadec, ridge, puerto, islands, indonesia, tobelo, tonga, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, meeting, rates, interest, volume, ethiopia, minister, price, prime, mekonnen, demeke, presidential
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, economist, revolution, marginal, conversable, https, disclosure, caught, question, caleb, nelson, heidi
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: hacker, vulnerabilities, company, companies, google, infrastructure, updates, based, activities, weekday, safety, malware
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: louis, shelley, blanche, blunt, pelosi, harold, graves, daniel, wesley, gottheimer, subramanyam, steny
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, placement, module, paper, identify, sufficient, unavailable, converges, markets, consensus, either, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*