# WORLDSCOPE morning brief — 2026-07-21

## Headline
3416 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (766) · Russian Internal News (state + in-exile) (696) · State-Level News (383) · World leaders & government officials (324) · Chinese Internal News (232) · Ukraine Theater (total-war monitoring) (210) · Local News: St. Louis + Atlanta (196) · U.S. Weather + Severe / Climate Outlooks (167) · State Legislative Action (71) · Ukrainian Internal News (national + local Kyiv) (61) · GDELT GKG — themes / entities / watch areas (46) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 766 new of 1037 total
  - (2026-07-21) [Global] Lebanese army deploys in ‘pilot zones’ under US-backed plan
      The Lebanese army has begun deploying in three southern towns as part of a US-backed framework agreement with Israel.
  - (2026-07-21) [Global] Trump administration attacks US left, alleging Cuba ties: Key takeaways
      US report says the beleaguered government in Havana is the 'connective tissue' of a global 'anti-American coalition'.
  - (2026-07-21) [Global] Moldova chooses new prime minister as it pushes for EU membership
      Political newcomer Vasile Tofan inherits Moldova's push to join the European Union by 2030.
  - (2026-07-21) [Global] Zelenskyy replaces Ukraine military chief after protests
      Replaced military chief Syrskii clashed with former Defence Minister Fedorov, whose removal last week led to protests.
  - (2026-07-21) [Global] Drone shows scorched landscape after Spain wildfire
      A drone has revealed what remains of this forest after a wildfire burned through over 30,000 hectares of it.
  - (2026-07-21) [Global] US defence chief Hegseth puts Iran war cost at $37.5bn so far
      Latest cost comes as Hegseth and Joint Chiefs Chairman Caine seek a $1.5 trillion budget, including $70bn for Iran war.

### Russian Internal News (state + in-exile) — 696 new of 982 total
  - (2026-07-21) Александра Сырского уволили с поста главнокомандующего ВСУ | LEDE: Президент Украины Владимир Зеленский отправил в отставку главнокомандующего ВСУ Александра Сырского. ] (ru: Александра Сырского уволи…
      Президент Украины Владимир Зеленский отправил в отставку главнокомандующего ВСУ Александра Сырского.
  - (2026-07-21) Правительство определило очередность поставок топлива. У обычных заправок — самый низкий приоритет | LEDE: Российское правительство рекомендовало направлять топливо в первую очередь государс] (ru: Пра…
      Российское правительство рекомендовало направлять топливо в первую очередь государственным заказчикам и на муниципальные нужды. Такое решение, пишет «Коммерсант», было принято по итогам совещания с участием вице-премьера…
  - (2026-07-21) Росгвардия будет заранее готовиться к мобилизации и военному положению | LEDE: Росгвардия планирует изменить правила ведения гражданской обороны. Теперь в них будут упоминаться военное полож] (ru: Рос…
      Росгвардия планирует изменить правила ведения гражданской обороны. Теперь в них будут упоминаться военное положение и мобилизация. На это обратило внимание «Агентство».
  - (2026-07-21) «Ты не дома! Ты у нас дома! Так что заткни пасть». В Грузии один из гостей свадьбы напал на девушку «за русскую речь». Теперь эту историю обсуждает весь интернет, а в Тбилиси прошел марш в подд] (ru:…
      Вот уже несколько дней русскоязычный интернет обсуждает нападение на туристку в отеле в Грузии. 19 июля гость свадьбы, которая проходила в гостинице, зашел в номер девушки и разбил ей нос. Подруги пострадавшей утверждают…
  - (2026-07-21) В сети спорят, можно ли считать удары по Wildberries (в России) или по «Новой почте» (в Украине) военным преступлением. Что об этом говорит международное право? | LEDE: В ночь на 18 июля укр] (ru: В с…
      В ночь на 18 июля украинские беспилотники ударили по складским комплексам Wildberries в Электростали (Подмосковье) и Котовске (Тамбовская область). Погибли восемь человек, десятки пострадали; ущерб продавцам предваритель…
  - (2026-07-21) На VK Fest во время выступления Доры появился аниматор в виде Человека-паука — ранее сталкер в таком же костюме залез к ней домой. Фестиваль извинился | LEDE: Организаторы VK Fest извинились] (ru: На…
      Организаторы VK Fest извинились перед певицей Дорой за появление аниматора в костюме Человека-паука во время ее выступления. Ранее сталкер в таком же костюме проник в квартиру исполнительницы.

### State-Level News — 383 new of 747 total
  - (2026-07-21) [Alabama] Probation and Parole Officers’ Week
      Download
  - (2026-07-21) [California] La Casa Blanca admite usar palabras clave para cancelar importantes subvenciones de investigación californianas
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/050625_CSU-San-Marcos_AH_CM_54.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-07-21) [California] Presidente de Cal State, en el centro de una demanda por discriminación de 12 millones de dólares, opta a un puesto de transición
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/04/042224-Inland-Empire-JAH-10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-07-21) [California] Where Gavin Newsom is tougher on public employees than Greg Abbott
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526_RTO-State-Workers_MG_CM_08.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-21) [California] Why California’s AI transparency law for state government use was destined to fail
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526-RTO-State-Workers-MG-24-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-21) [California] Cal State president at center of $12M discrimination suit is up for transition job
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/04/042224-Inland-Empire-JAH-10.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 232 new of 303 total
  - (2026-07-19) 世界杯决赛西阿大战，数据一网打尽 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBEclpKYzlpcFlUOXJKZk1jMzBwNDRBeE5fZWt4QnlrYTJyaE1ORnBTY0NaQnB3aUtSZzNmQUlkU040aUQ5ZEM0NWRhdXFOUnl5QWNxZ] (zh:…
      世界杯决赛西阿大战，数据一网打尽 财新
  - (2026-07-21) 国泰海通人工智能投融资论坛成功举行_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBKbkQ5V0hoQnlBTExlaXRzVXhhd3EteTlhMUZNckMwVEF4R1RjX256ZU8xT0l6bEMxa1Vqc0ZMQmpON2pSMlhqUVBoX] (zh:…
      国泰海通人工智能投融资论坛成功举行_特别呈现_手机财新网 财新
  - (2026-07-21) 今日开盘：两市双双高开 沪指涨幅0.42% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1RQmNmQnhWVmxRWlh3SWZxSl9YOXJVaDBrMGRUcjZKOFo5NjFzYk5udjhMb3FfN3VWeEJsMXBOZ243V1dMdmVZMHVNR01KbU9l] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.42% 财新
  - (2026-07-21) 年近古稀的我，居然也混入了Hyrox2026世锦赛！｜亲历 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBibDE4ZUFzank3TVVGM0JWd1o3emNsQ01kUXlqQVMweXlIUVVmd2dTYmpnelp5NmNSdzdmb3RsVzB6ME1aQVlBczFx] (zh:…
      年近古稀的我，居然也混入了Hyrox2026世锦赛！｜亲历 财新
  - (2026-07-21) 权力与荣耀：足球的更多可能｜荐书 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5ZaUJFc1dkeXdwVmtMZEkwVTVoNnhBZlVQODc0R2lMcktIU2VkZFdsQzZrZW1ubTctTE14b19oNG9oOXhaOEI5cnBXdU1OcC1UOUJKX] (zh:…
      权力与荣耀：足球的更多可能｜荐书 财新
  - (2026-07-21) 智能体挑战个人信息保护 各方热议法律边界 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE1YeEozblNYenYyYmNjLUxLT0FoR2J5clRpbzllbnFlOWpCQVR0dUh2ZkFLZWFZX0FFbHkyQ0h1TkFES3FhWkp] (zh:…
      智能体挑战个人信息保护 各方热议法律边界 china.caixin.com

### Ukraine Theater (total-war monitoring) — 210 new of 636 total
  - (2026-07-21) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-21) [Liveuamap] President Zelensky: Mykhailo Drapaty will replace Oleksandr Syrsky as the new Commander-in-Chief of the Armed Forces of Ukraine Kyiv, Kyiv city - Ukraine Interactive map - Ukraine Latest n…
      President Zelensky: Mykhailo Drapaty will replace Oleksandr Syrsky as the new Commander-in-Chief of the Armed Forces of Ukraine
  - (2026-07-21) [Liveuamap] Israeli forces entered the village of al-Samdaniyah al-Sharqiyah in Syria&039;s Quneitra province with five military vehicles, set up a temporary checkpoint, and searched civilians. They a…
      Israeli forces entered the village of al-Samdaniyah al-Sharqiyah in Syria&039;s Quneitra province with five milit
  - (2026-07-21) [Liveuamap] An Israeli official: Military action must be taken at Jabal al-Fas in Iran. Giv&039;atayim, Tel Aviv District - iran.liveuamap.com
      An Israeli official: Military action must be taken at Jabal al-Fas in Iran. Giv&039;atayim, Tel Aviv District &nbs
  - (2026-07-20) [Liveuamap] A civilian vehicle was targeted near "Najd Roundabout" in Al-Zahra city, in the central Gaza Strip. - Liveuamap
      A civilian vehicle was targeted near "Najd Roundabout" in Al-Zahra city, in the central Gaza
  - (2026-07-21) [Liveuamap] Drone targets Ali Al Salem Air Base in Kuwait Al Jahra Governorate, Kuwait - iran.liveuamap.com
      Drone targets Ali Al Salem Air Base in Kuwait Al Jahra Governorate, Kuwait iran.liveuam

### Local News: St. Louis + Atlanta — 196 new of 227 total
  - (2026-07-21) [St. Louis] Venezuela confirms 3 people have died of hantavirus infections, with 2 more deaths suspected
      Venezuelan officials stressed there has been no evidence of human-to-human transmission and no risk to the general community.
  - (2026-07-21) [St. Louis] She spent 25 years knowing exactly who represents her in Congress. Missouri's new map changed the answer while she wasn't looking
      New district lines moved 60,000 St. Louis County voters. A retired federal worker found out when her ballot didn't match the government's own website
  - (2026-07-21) [St. Louis] Illinois health officials approve new $231M hospital in Cahokia Heights
      The new hospital reportedly has 108 beds and is designed to expand health services for patients in Southern Illinois and the Metro East.
  - (2026-07-21) [St. Louis] Family says woman was shot while sitting on living room couch after gunfire tore through north St. Louis home
      The victim's family says seven people were inside the home when bullets shattered the living room windows. Police are still searching for the shooter.
  - (2026-07-21) [St. Louis] 2 married couples from Honduras were among 5 adults who drowned in an Ohio river
      One of the couples had two young children who were also at the Scioto River on Sunday.
  - (2026-07-21) [St. Louis] Missouri voter guide: Here's what's on your 2026 primary election ballot
      Read the 5 On Your Side Voter Guide for details on all the hot election races across Missouri.

### U.S. Weather + Severe / Climate Outlooks — 167 new of 171 total
  - (2026-07-21) [Severe] Special Marine Warning: Special Marine Warning issued July 21 at 7:50PM EDT until July 21 at 8:15PM EDT by NWS Mount Holly NJ
      For the following areas... Coastal waters from Great Egg Inlet to Cape May NJ out 20 NM... Coastal waters from Little Egg Inlet to Great Egg Inlet NJ out 20 NM... Coastal waters from Manasquan Inlet to Little Egg Inlet N…
  - (2026-07-21) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 21 at 7:50PM EDT until July 21 at 8:00PM EDT by NWS Baltimore MD/Washington DC
      At 749 PM EDT, severe thunderstorms were located along a line extending from near Berryville to 6 miles southeast of Millwood Pike to near Front Royal, moving east at 45 mph. HAZARD...60 mph wind gusts. SOURCE...Radar in…
  - (2026-07-21) [Moderate] Special Weather Statement: Special Weather Statement issued July 21 at 5:49PM MDT by NWS Salt Lake City UT
      At 549 PM MDT, Doppler radar was tracking a strong thunderstorm over Summit Park, or 8 miles northwest of Park City, moving north at 10 mph. HAZARD...Wind gusts up to 50 mph and pea size hail. SOURCE...Radar indicated. I…
  - (2026-07-21) [Extreme] Tornado Warning: Tornado Warning issued July 21 at 7:49PM EDT until July 21 at 8:15PM EDT by NWS Baltimore MD/Washington DC
      TORLWX The National Weather Service in Sterling Virginia has issued a * Tornado Warning for... Northeastern Shenandoah County in northwestern Virginia... * Until 815 PM EDT. * At 749 PM EDT, a severe thunderstorm capable…
  - (2026-07-21) [Moderate] Special Weather Statement: Special Weather Statement issued July 21 at 6:49PM CDT by NWS New Orleans LA
      At 649 PM CDT, Doppler radar was tracking a cluster of strong thunderstorms capable of producing funnel clouds along a line extending from near Norco to near Montegut. Movement was south at 30 mph. HAZARD...Funnel clouds…
  - (2026-07-21) [Severe] Severe Thunderstorm Watch: Severe Thunderstorm Watch issued July 21 at 7:49PM EDT until July 21 at 10:00PM EDT by NWS Jackson KY
      SEVERE THUNDERSTORM WATCH 508 REMAINS VALID UNTIL 10 PM EDT THIS EVENING FOR THE FOLLOWING AREAS IN KENTUCKY THIS WATCH INCLUDES 15 COUNTIES IN EAST CENTRAL KENTUCKY ESTILL POWELL IN NORTHEAST KENTUCKY JOHNSON IN SOUTH C…

### State Legislative Action — 71 new of 115 total
  - (2026-07-21) [Alabama SB 107] Alabama Board of Funeral Services; board authorized to impose administrative fee on funeral establishments for each funeral arranged; initial application, renewal, branch registration…
      Occupational Licensing Boards
  - (2026-07-21) [Arizona HB 2946] municipalities; counties; development fees
      municipalities; counties; development fees
  - (2026-07-21) [California SB 711] Taxation: federal conformity.
      Under the Personal Income Tax Law and the Corporation Tax Law, various provisions of the federal Internal Revenue Code, as enacted as of a specified date, are referenced in various sections of the Revenue and Taxation Co…
  - (2026-07-21) [California SB 709] Self-service storage facilities: rental agreement disclosures.
      Existing law, the California Self-Service Storage Facility Act, establishes procedures governing the operation of self-service storage facilities, including specifying remedies for facility owners when occupants are deli…
  - (2026-07-21) [California AB 1768] Transactions and use taxes: Counties of Contra Costa and Los Angeles.
      Existing law authorizes various local governmental entities, subject to certain limitations and approval requirements, to levy a transactions and use tax for general or specific purposes, in accordance with the procedure…
  - (2026-07-21) [California ACR 226] Relative to Black Girl Joy Day.
      This measure would designate August 10, 2026, and August 10 of each subsequent year thereafter, as Black Girl Joy Day and encourage all Californians to join in celebrating Black Girl Joy Day.

### Ukrainian Internal News (national + local Kyiv) — 61 new of 121 total
  - (2026-07-22) Окупований Крим опинився під ударом дронів: частина півострова залишилась без світла | LEDE: У ніч на 22 липня дрони атакували Крим: вибухи, пожежі, зникло світло в Алушті та Ялті.] (uk: Окупований Кр…
      У ніч на 22 липня дрони атакували Крим: вибухи, пожежі, зникло світло в Алушті та Ялті.
  - (2026-07-22) Трамп доручив скасувати угоди про нерозголошення даних щодо НЛО | LEDE: Трамп скасував NDA для ексдержслужбовців, щоб розкрити нову інформацію про UAP. Дані можуть публікувати після перевірки.] (uk: Т…
      Трамп скасував NDA для ексдержслужбовців, щоб розкрити нову інформацію про UAP. Дані можуть публікувати після перевірки.
  - (2026-07-22) Парламент Франції ухвалив заборону на соцмережі для дітей до 15 років | LEDE: Закон набуде чинності у вересні: французьким дітям до 15 років заборонять соціальні мережі.] (uk: Парламент Франції ухвали…
      Закон набуде чинності у вересні: французьким дітям до 15 років заборонять соціальні мережі.
  - (2026-07-21) Зеленський пропонував Федорову різні посади не в Міноборони. Той відмовився — джерела | LEDE: Президент Володимир Зеленський пропонував Михайлу Федорову різні варіанти роботи у владі, зокрема п] (uk:…
      Президент Володимир Зеленський пропонував Михайлу Федорову різні варіанти роботи у владі, зокрема перейти на позицію віцепрем'єра з технологічного розвитку, але Федоров проти, бо не розуміє, за що його звільнили з МОУ.
  - (2026-07-21) Федоров подякував Сирському за історичні битви та привітав призначення Драпатого головкомом ЗСУ | LEDE: Ексміністр оборони Михайло Федоров, проти відставки якого в України 6 днів були мітинги, ] (uk:…
      Ексміністр оборони Михайло Федоров, проти відставки якого в України 6 днів були мітинги, подякував генералу Олександру Сирському за історичні битви та привітав призначення Михайла Драпатого на посаду головнокомандувача З…
  - (2026-07-21) Драпатий про своє призначення головнокомандувачем ЗСУ: Працюватиму з повагою до людей | LEDE: Михайло Драпатий, якого президент України Володимир Зеленський 21 липня призначив новим головнокома] (uk:…
      Михайло Драпатий, якого президент України Володимир Зеленський 21 липня призначив новим головнокомандувачем ЗСУ, заявив, що працюватиме з повагою до людей, які захищають Україну.

### GDELT GKG — themes / entities / watch areas — 46 new of 46 total
  - (2026-07-21) [Russia oil sanctions perimeter · themes] Inspection Finds Zebra Mussels on Boat Crossing into Manitoba
      chrisd.ca · English · tone NA
  - (2026-07-21) [Russia oil sanctions perimeter · themes] BC Hydro to triple size of its public EV charging network by 2035
      ominecaexpress.com · English · tone NA
  - (2026-07-21) [Russia oil sanctions perimeter · themes] Zelensky sacks Ukraine military chief following widespread protests - LocalNews8 . com
      localnews8.com · English · tone NA
  - (2026-07-21) [Russia oil sanctions perimeter · themes] Dow Jones jumps 386 points as global stocks take off
      newjerseytelegraph.com · English · tone NA
  - (2026-07-21) [Russia oil sanctions perimeter · themes] 유안타 카카오뱅크 , 개인사업자 대출 확대 기대 … 수신 성장도 지속
      etoday.co.kr · Korean · tone NA
  - (2026-07-21) [Russia oil sanctions perimeter · themes] Vice Adm . Marc Miguez Assumes Command of U . S . 3rd Fleet – Seapower Magazine
      seapowermagazine.org · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-21) [Butterfly Network, Inc.] Form 4 (Issuer)
      filed 2026-07-21 23:52 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0001104659-26-085497 Size: 16 KB
  - (2026-07-21) [ROTHBERG JONATHAN M] Form 4 (Reporting)
      filed 2026-07-21 23:52 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0001104659-26-085497 Size: 16 KB
  - (2026-07-21) [MacDonald Ryan S] Form 4 (Reporting)
      filed 2026-07-21 23:44 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0001398344-26-012443 Size: 6 KB
  - (2026-07-21) [Bluerock Private Real Estate Fund] Form 4 (Issuer)
      filed 2026-07-21 23:44 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0001398344-26-012443 Size: 6 KB
  - (2026-07-21) [Boundless Bio, Inc.] Form 4 (Issuer)
      filed 2026-07-21 23:38 UTC · role: Issuer — Filed: 2026-07-21 AccNo: 0001178579-26-000017 Size: 10 KB
  - (2026-07-21) [TANG CAPITAL MANAGEMENT LLC] Form 4 (Reporting)
      filed 2026-07-21 23:38 UTC · role: Reporting — Filed: 2026-07-21 AccNo: 0001178579-26-000017 Size: 10 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 56 total
  - (2026-07-21) [BleepingComputer] Police dismantle Kratos phishing platform, arrest developer
      Authorities in Germany and the U.S. dismantled the central infrastructure of Kratos, a phishing-as-a-service (PhaaS) platform with global reach, and its developer was arrested in Indonesia. [...]
  - (2026-07-21) [BleepingComputer] FakeGit campaign uses 7,600 GitHub repos to push SmartLoader malware
      A large-scale operation dubbed 'FakeGit' is pushing SmartLoader and StealC malware through 7,600 malicious GitHub repositories that accumulated more than 14 million downloads. [...]
  - (2026-07-21) [BleepingComputer] Critical SharePoint RCE flaw exploited to steal machine keys
      Hackers are actively exploiting the critical CVE-2026-50522 vulnerability in Microsoft SharePoint to steal machine keys and maintain access even after affected servers are patched. [...]
  - (2026-07-21) [BleepingComputer] Anubis ransomware claims Coca-Cola Fairlife attack, threatens data leak
      The Anubis ransomware gang has claimed responsibility for the cyberattack on Coca-Cola's Fairlife dairy subsidiary, threatening to publish allegedly stolen corporate data unless the company pays a ransom. [...]
  - (2026-07-21) [BleepingComputer] Critical wp2shell WordPress flaws exploited to install webshells
      Hackers are exploiting the "wp2shell" critical vulnerability suite (CVE-2026-63030 and CVE-2026-60137) affecting WordPress Core to deploy persistent webshells and install malicious plugins on affected servers. [...]
  - (2026-07-21) [The Hacker News] Apple Fixes Hide My Email Bug That Exposed Real Addresses in Mail Logs
      Apple has moved to address a security flaw in its Hide My Email service that enabled users' real email addresses to be unmasked, effectively undermining the feature's privacy guarantees. 404 Media reported Tuesday that a…

### Court opinions of consequence (federal & state) — 32 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, 6th Cir.: Am. Ass'n of Nurse Anesthesiology v. Robert Kennedy, Jr.
  - (2026-07-21) U.S. Court of Appeals, 6th Cir.: Melvin Steger v. Steven Willis
  - (2026-07-21) U.S. Court of Appeals, 8th Cir.: Faith Elsharkawy v. Chisago Lakes Board of Education
  - (2026-07-21) U.S. Court of Appeals, 8th Cir.: United States v. Ronald Mason
  - (2026-07-21) U.S. Court of Appeals, 7th Cir.: United States v. Katrail Bridges
  - (2026-07-21) U.S. Court of Appeals, 7th Cir.: Alyssa Schukar v. Kenosha County

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 25 new of 144 total
  - (2026-07-21) [Polymarket] Will Silver (XAGUSD) hit (LOW) $54 in July?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of July 2026, any 1-minute candle for Silver (XAGUSD) has a final "High" or "Low" price equal to or beyond (above for…
  - (2026-07-21) [Polymarket] Will Nigel Farage win the Clacton by-election?
      A by-election for the United Kingdom parliamentary constituency of Clacton is expected to be held soon following the announced resignation of incumbent Nigel Farage. This market will resolve according to the candidate wh…
  - (2026-07-21) [Polymarket] Will Elon Musk post 100-119 tweets from July 17 to July 24, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 17 12:00 PM ET to July 24, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-21) [Polymarket] Will LeBron James play for the Dallas Mavericks in 2026-27?
      This market will resolve to the next team LeBron James officially joins by October 31, 2026, 11:59 PM ET. If LeBron James does not officially join a new team by October 31, 2026, 11:59 PM ET, this market will resolve to…
  - (2026-07-21) [Polymarket] Will Dune: Messiah have the best domestic opening weekend in 2026?
      This market will resolve according to the title of the movie which grosses more domestically on its opening weekend than any other movie in 2026. The “Weekend Box Office Performance” table on the page for the relevant mo…
  - (2026-07-21) [Kalshi] Kylian Mbappe Total FIFA World Cup Career Goals
      Kylian Mbappe

### U.S. Federal Action — 21 new of 23 total
  - (2026-07-21) Order Sunsetting Certain Large Trader Reporting Requirements for Physical Commodity Swaps
      The Commodity Futures Trading Commission ("CFTC" or the "Commission") is issuing this Order pursuant to Sec. 20.9 of its regulations, the sunset provision of the Commission's large trader reporting rules for physical com…
  - (2026-07-21) Patient Protection and Affordable Care Act, HHS Notice of Benefit and Payment Parameters for 2027; and Basic Health Program; Correction
      This document corrects typographical errors in the final rule that appeared in the May 20, 2026, Federal Register titled "Patient Protection and Affordable Care Act, HHS Notice of Benefit and Payment Parameters for 2027;…
  - (2026-07-21) General Technical, Organizational, Conforming, and Correcting Amendments to the Federal Motor Carrier Safety Regulations
      FMCSA amends its regulations by making technical corrections throughout the Federal Motor Carrier Safety Regulations (FMCSR). The Agency makes minor changes to correct inadvertent errors and omissions, remove or update o…
  - (2026-07-21) USCIS Immigration Fees and Related Procedures Required by H.R.1 Reconciliation Bill; Correction
      This document corrects the interim final rule (IFR) that published in the Federal Register on April 29, 2026. The IFR codified certain immigration fees and other provisions required by the One Big Beautiful Bill Act (H.R…
  - (2026-07-21) Fisheries of the Northeastern United States; Summer Flounder Fishery; Quota Transfer From North Carolina to Massachusetts
      NMFS announces that the State of North Carolina is transferring a portion of its 2026 commercial summer flounder quota to the Commonwealth of Massachusetts. This adjustment to the 2026 fishing year quota is necessary to…
  - (2026-07-21) Magnuson-Stevens Act Provisions; Fisheries Off West Coast States; Pacific Coast Groundfish Fishery; Pacific Coast Groundfish Fishery Management Plan; Amendment 38; 2027-28 Biennial Specifications and…
      NMFS announces that the Pacific Fishery Management Council (Council) submitted amendment 38 to the Pacific Coast Groundfish Fishery Management Plan (Groundfish FMP) to the Secretary of Commerce for review. If approved, a…

### USGS earthquakes (M4.5+, past day) — 17 new of 17 total
  - (2026-07-21) M 5.6 - Kermadec Islands region
      M5.6 · Kermadec Islands region · depth 10 km
  - (2026-07-21) M 5.3 - 132 km ENE of Santa Cruz das Flores, Portugal
      M5.3 · 132 km ENE of Santa Cruz das Flores, Portugal · depth 6.736 km
  - (2026-07-21) M 5.2 - northern Mid-Atlantic Ridge
      M5.2 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-07-21) M 5.1 - 7 km WNW of Kalbay, Philippines
      M5.1 · 7 km WNW of Kalbay, Philippines · depth 68.769 km
  - (2026-07-21) M 5.0 - 58 km SSW of Merizo Village, Guam
      M5.0 · 58 km SSW of Merizo Village, Guam · depth 12.164 km
  - (2026-07-21) M 5.0 - Mid-Indian Ridge
      M5.0 · Mid-Indian Ridge · depth 10 km

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-21) [Japan] Wireless Plans - CNET
      cnet.com · English
  - (2026-07-21) [Japan] Were Asking All the Wrong Questions About AI Companionship
      cnet.com · English
  - (2026-07-21) [Japan] Deezer Is Cracking Down on Fake Music and Fake Streams
      cnet.com · English
  - (2026-07-21) [Japan] US envoy Sergio Gor to join Secretary Marco Rubio for 2nd Ministerial Quad meeting in Philippines
      japanherald.com · English
  - (2026-07-21) [Japan] Nvidia and Wistron to build Blackwell AI servers in Texas
      asia.nikkei.com · English
  - (2026-07-21) [Japan] SpaceX eyes multibillion - dollar Pentagon AI computing deal
      japanherald.com · English

### GDACS — global disaster alerts — 12 new of 196 total
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-17) [Green] Flood in Japan
      Flood · Green alert · Japan · Magnitude 0
  - (2026-07-17) [Green] Flood in Japan
      Flood · Green alert · Japan · Magnitude 0
  - (2026-07-17) [Green] Flood in Japan
      Flood · Green alert · Japan · Magnitude 0

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-07-21) Will Gretchen Whitmer win the 2028 US Presidential Election?
      yes price: 1% · 24h volume: $1,445,473 · resolves 2028-11-07
  - (2026-07-21) Los Angeles Dodgers vs. Philadelphia Phillies
      yes price: 48% · 24h volume: $1,409,036 · resolves 2026-07-28
  - (2026-07-21) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,004,538 · resolves 2026-06-01
  - (2026-07-21) Will Gretchen Whitmer win the 2028 Democratic presidential nomination?
      yes price: 2% · 24h volume: $656,071 · resolves 2028-11-07
  - (2026-07-21) Baltimore Orioles vs. Boston Red Sox
      yes price: 44% · 24h volume: $609,990 · resolves 2026-07-28
  - (2026-07-21) Cincinnati Reds vs. Seattle Mariners
      yes price: 48% · 24h volume: $530,522 · resolves 2026-07-29

### Government & military aircraft airborne (OpenSky) — 9 new of 9 total
  - (2026-07-21) SAMU44 (France)
      icao24: 39ca84 · position: (47.3939, -0.8432) · alt: 388m · 267km/h
  - (2026-07-21) KAF3211 (Kuwait)
      icao24: 706216 · position: (39.3677, 15.9724) · alt: 10058m · 890km/h
  - (2026-07-21) JAF45T (Belgium)
      icao24: 44d1a6 · position: (50.41, 3.5021) · alt: 6903m · 707km/h
  - (2026-07-21) JAF1DE (Belgium)
      icao24: 44d2ab · position: (47.0322, 19.497) · alt: 12192m · 772km/h
  - (2026-07-21) NCR801 (United States)
      icao24: a8bf91 · position: (22.4431, 121.7967) · alt: 12192m · 920km/h
  - (2026-07-21) AF23 (China)
      icao24: 7b1001 · position: (22.3084, 113.9273) · on ground · 27km/h

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 20 total
  - (2026-07-21) CVE-2026-60137 · WordPress Core: WordPress Core SQL Injection Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-08-04
  - (2026-07-21) CVE-2026-63030 · WordPress Core: WordPress Core Interpretation Conflict Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-07-24
  - (2026-07-21) CVE-2026-0770 · Langflow Langflow: Langflow Inclusion of Functionality from Untrusted Control Sphere Vulnerability
      vendor: Langflow · product: Langflow · CISA remediation by 2026-07-24
  - (2026-07-21) CVE-2021-27137 · DD-WRT DD-WRT: DD-WRT Stack-Based Buffer Overflow Vulnerability
      vendor: DD-WRT · product: DD-WRT · CISA remediation by 2026-07-24

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 40 total
  - (2026-07-21) MOVER ▲ Jensen Huang — $179.17B (+$3.41B since yesterday)
      United States · Technology · source: Semiconductors
  - (2026-07-21) MOVER ▲ Thomas Peterffy — $108.22B (+$2.98B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-07-21) MOVER ▼ Bernard Arnault & family — $146.32B ($-2.14B since yesterday)
      France · Fashion & Retail · source: LVMH

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-21) [Marginal Revolution] Tuesday assorted links
      1. White on Hutt’s macro. 2. Are LLMs obsessed with Japan? 3. Princeton University art museum gets landmark gift of Haitian paintings. 4. “Sight unseen” — the revenge of asymmetric information. But was it a good buy? 5.…
  - (2026-07-21) [Marginal Revolution] The Odyssey
      Worth seeing, and I enjoyed it — but a few observations I haven’t seen elsewhere. For all the praise of IMAX and 70mm’s supposed clarity, several scenes are out of focus on the actor. Pulling focus is harder with a large…
  - (2026-07-21) [Marginal Revolution] The economic effects of GLP-1s
      We estimate the causal impacts of GLP-1 treatment on labor market outcomes using linked Danish administrative data and a matched stacked difference-in-differences design. We compare patients who initiate GLP-1 treatment…

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 117 total
  - (2026-07-21) [BIS Entity List] page checksum 47a6bf4796c4
      Page content hash: 47a6bf4796c4. Compare with prior day's hash to detect updates.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-22) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=0, 7d-median=20, 14d-median=20; carrying terms: local, regulatory, personnel, aleutian, proposing, commodity, event, exclusive, available, persons, safety, modifying
- state_bills: today=0, 7d-median=115, 14d-median=115; carrying terms: covered, adopt, enforcement, appropriate, employees, population, measure, personnel, minimum, procedures, according, purposes
- state_news: today=0, 7d-median=711, 14d-median=711; carrying terms: standard, redirects, corporate, pillen, analysts, employees, incidents, measure, tested, citizenship, efforts, black
- local_news: today=0, 7d-median=227, 14d-median=227; carrying terms: downtown, farms, community, group, async, hours, heritage, staying, hospitalized, target, think, involved
- foreign_news: today=0, 7d-median=1024, 14d-median=1024; carrying terms: worst, clear, centre, catch, technologies, population, aggression, black, expanding, began, investigating, announces
- chinese_internal: today=0, 7d-median=299, 14d-median=299; carrying terms: cbmix, cbmidkfvx, target, global, blank, mainland, viral, cbmiyefvx, cbmickfvx, cbmiy, cbmicefvx, capital
- russian_internal: today=0, 7d-median=878, 14d-median=878; carrying terms: waico, europe, gazeta, bloomberg, found, raquo, telegram, russian, laquo, title, financial, netflix
- ukrainian_internal: today=0, 7d-median=128, 14d-median=128; carrying terms: censor, civilians, yevhen, aggression, personnel, risks, components, resigned, value, senior, black, troops
- ukraine_theater: today=0, 7d-median=636, 14d-median=636; carrying terms: zbwxyx, djzjh, wvzlmzudkbwlyum, yzegwnghcrjrtntdvoejrcfe, technologies, nddfrhzwtqdjvom, incidents, lrgjwvwfovwvbugjrnw, frequently, zzhxufu, components, cqkxuyjhhsdbtchpzsm
- paper_bets: today=0, 7d-median=144, 14d-median=144; carrying terms: carlos, winner, majors, nomination, point, formally, qualify, standard, brazil, succeed, payable, mayfield
- weather: today=0, 7d-median=171, 14d-median=171; carrying terms: impacts, denver, runoff, mountains, angeles, cause, interior, amounts, moderate, lying, conditions, moisture
- macro: today=0, 7d-median=21, 14d-median=21; carrying terms: jtsjol, payrolls, payems, personal, spread, latest, cpiaucsl, money, supply, recession, sheet, treasury
- markets: today=0, 7d-median=21, 14d-median=21; carrying terms: yield, credit, proxy, futures, commodities, large, corporate, crypto, agriculture, equities, nasdaq, china
- markets_global: today=0, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=0, 7d-median=117, 14d-median=117; carrying terms: palestinian, lpzee, resolutions, stanford, authorities, square, technologies, ylexvnp, industrial, nvownfbfe, control, independence
- congressional_trades: today=0, 7d-median=1, 14d-median=1; carrying terms: congresstrading, error, unauthorized, httperror, quiver, quantitative, quiverquant, https, client
- billionaires: today=0, 7d-median=34, 14d-median=34; carrying terms: carlos, peterffy, tesla, larry, london, holdings, bernard, technologies, tadashi, nasdaq, tiktok, japan
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=0, 7d-median=60, 14d-median=60; carrying terms: services, local, limited, blanche, denby, abbey, attorney, keathley, rifle, community, crisp, metro
- form4: today=0, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer
- fec: today=0, 7d-median=27, 14d-median=27; carrying terms: cooper, elect, sherrod, jonathan, david, shawn, james, disbursements, johnson, michael, receipts, booker
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=0, 7d-median=46, 14d-median=46; carrying terms: chinese, hezbollah, english, israel, russian, sanctions, perimeter, arabic, spanish, trump, russia, senate
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=9, 14d-median=9
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=0, 7d-median=40, 14d-median=40; carrying terms: contact, point, poultry, authorities, arabia, local, probable, mauritania, haemorrhage, appropriate, several, recent
- cisa_kev: today=0, 7d-median=16, 14d-median=16; carrying terms: vendor, builder, services, sonicwall, authentication, joomlack, traversal, dangerous, product, remediation, control, deserialization
- epss: today=0, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=160, 14d-median=160; carrying terms: panama, speed, depth, bulgaria, north, brazil, montenegro, guinea, storm, flood, drought, liechtenstein
- usgs_quakes: today=0, 7d-median=20, 14d-median=20; carrying terms: south, depth, islands, puerto, madero, kermadec, mexico, atlantic, ridge, indonesia
- forecasts: today=0, 7d-median=20, 14d-median=20; carrying terms: prime, demeke, volume, ethiopia, interest, resolves, price, minister, rates, meeting, mekonnen, change
- commentary: today=0, 7d-median=6, 14d-median=6; carrying terms: caught, budget, heidi, editor, wroblewski, pushback, answering, perhaps, interview, disclosure, assorted, schrag
- tech_news: today=0, 7d-median=56, 14d-median=56; carrying terms: covered, regulate, control, safety, number, delil, reckless, measures, wordpress, intelligence, cache, server
- political_figures: today=0, 7d-median=613, 14d-median=613; carrying terms: richard, carlos, welch, wicker, messmer, lawler, biggs, catherine, magaziner, rollins, burgess, enforcement
- paper_bet_placement: today=0, 7d-median=1, 14d-median=1; carrying terms: paper, today, either, converges, placed, decision, consensus, sufficient, identify, unavailable, market, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-17] ECB press: Piero Cipollone: The cooperative spirit at the heart of the digital euro
- [2026-07-20] ECB press: Survey on the Access to Finance of Enterprises: lending conditions tightened

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*