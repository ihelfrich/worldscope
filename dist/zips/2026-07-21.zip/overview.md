# WORLDSCOPE morning brief — 2026-07-21

## Headline
2317 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (537) · Russian Internal News (state + in-exile) (428) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (242) · Chinese Internal News (206) · U.S. Weather + Severe / Climate Outlooks (160) · State-Level News (68) · Local News: St. Louis + Atlanta (55) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Ukrainian Internal News (national + local Kyiv) (33) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 537 new of 972 total
  - (2026-07-21) [Global] Philippine Foreign Secretary says ASEAN must work together
      Philippine Foreign Secretary says ASEAN must work together
  - (2026-07-21) [Global] Philippine Foreign Secretary says ASEAN must work together
      Philippine Foreign Secretary says ASEAN must work together
  - (2026-07-21) [Global] Hormuz tankers on fire, as US, Iran continue attacks: What’s the latest?
      The White House told Al Jazeera that the US would continue its attacks unless Trump decides otherwise.
  - (2026-07-21) [Global] Mamdani says he takes Netanyahu’s ICC arrest warrant ‘seriously’
      Mamdani says he takes Netanyahu’s ICC arrest warrant ‘seriously’
  - (2026-07-21) [Global] Farage, Reform in ‘trouble’, as UK braces for crypto influence in politics
      Farage's crisis after revelations of substantial crypto donations prompts broader political questions over donor clout.
  - (2026-07-21) [Global] Israeli forces open fire on children in Syrian village
      Israeli forces open fire on children in Syrian village

### Russian Internal News (state + in-exile) — 428 new of 889 total
  - (2026-07-21) Федеральный суд в США приостановил слияние Paramount и Warner Bros. | LEDE: Судья окружного суда в Окленде (штат Калифорния) Арасели Мартинес-Ольгин на две недели приостановила покупку Warne] (ru: Фед…
      Судья окружного суда в Окленде (штат Калифорния) Арасели Мартинес-Ольгин на две недели приостановила покупку Warner Bros. компанией Paramount. Стоимость сделки оценивается в 110 миллиардов долларов.
  - (2026-07-21) Аэропорт Внуково купит у Шереметьево часть Домодедово | LEDE: Московский аэропорт Внуково выкупит у Шереметьево 25% компании, которая контролирует группу «Домодедово». Сумма сделки, по данны] (ru: Аэр…
      Московский аэропорт Внуково выкупит у Шереметьево 25% компании, которая контролирует группу «Домодедово». Сумма сделки, по данным РБК, составит 16,5 миллиарда рублей.
  - (2026-07-21) ФСБ обвинила жителя Тюмени в подготовке теракта на одном из предприятий Урала. При задержании его убили | LEDE: Сотрудники ФСБ убили при задержании жителя Тюмени, которого спецслужба обвинил] (ru: ФСБ…
      Сотрудники ФСБ убили при задержании жителя Тюмени, которого спецслужба обвинила в подготовке теракта на «одном из ключевых предприятий Уральского федерального округа». Сообщение Центра общественных связей (ЦОС) ФСБ распр…
  - (2026-07-21) «Коммерсант»: российские НПЗ возобновляют продажу бензина на бирже. Объем торгов резко сократился из-за топливного кризиса | LEDE: Российские нефтеперерабатывающие заводы постепенно возвраща] (ru: «Ко…
      Российские нефтеперерабатывающие заводы постепенно возвращаются к продажам топлива на Петербургской бирже. Такой вывод, пишет «Коммерсант» , можно сделать из обзора аналитического агентства Platts, с которым ознакомилось…
  - (2026-07-21) Тайвань впервые замедлит мобильный интернет во время учений по гражданской обороне | LEDE: Власти Тайваня впервые замедлят скорость мобильного интернета во время ежегодных учений по гражданс] (ru: Тай…
      Власти Тайваня впервые замедлят скорость мобильного интернета во время ежегодных учений по гражданской обороне, которые пройдут в августе. Таким образом они хотят проверить, как граждане будут коммуницировать в случае чр…
  - (2026-07-21) Президент Никарагуа Даниэль Ортега объявил, что в его стране больше не будет выборов | LEDE: Даниэль Ортега, занимающий пост президента Никарагуа с 2007 года, объявил, что в стране больше ни] (ru: Пре…
      Даниэль Ортега, занимающий пост президента Никарагуа с 2007 года, объявил, что в стране больше никогда не будут проводить выборы, сообщает Reuters. Такая мера, заявил он, необходима, чтобы оппозиция не пришла к власти.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 242 new of 695 total
  - (2026-07-21) [DeepStateMap] frontline snapshot, 523 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-20) [Liveuamap] Drones raid in Domodedovo, Moscow region - Liveuamap
      Drones raid in Domodedovo, Moscow region Liveuamap
  - (2026-07-21) [Liveuamap] Israeli forces entered the village of al-Samdaniyah al-Sharqiyah in Syria&039;s Quneitra province with five military vehicles, set up a temporary checkpoint, and searched civilians. They a…
      Israeli forces entered the village of al-Samdaniyah al-Sharqiyah in Syria&039;s Quneitra province with five milit
  - (2026-07-21) [Liveuamap] Airstrike with glide bomb reported in the central part of Sloviansk - Liveuamap
      Airstrike with glide bomb reported in the central part of Sloviansk Liveuamap
  - (2026-07-19) [Liveuamap] Explosion in Zaporizhzhia reported 0, Ukraine - Ukraine Interactive map - Ukraine Latest news on live map - Liveuamap
      Explosion in Zaporizhzhia reported 0, Ukraine - Ukraine Interactive map - Ukraine Latest news on live map Li
  - (2026-07-18) [Liveuamap] Drone strike reported at the infrastructure in Kryvyi Rih, there are injuries - Liveuamap
      Drone strike reported at the infrastructure in Kryvyi Rih, there are injuries Liveuamap

### Chinese Internal News — 206 new of 283 total
  - (2026-07-20) China Deploys ‘National Team’ in Multi-Pronged Stock Market Rescue - Caixin Global
      China Deploys ‘National Team’ in Multi-Pronged Stock Market Rescue Caixin Global
  - (2026-07-20) 第三十五届“哈洽会”数字经济展区亮点纷呈 - 黑龙江人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE9GTGwwdENfQmx6YUYwYlBGOXFlZXQ1RXJoRG5NODN4NGVFUTVUbVpoYmx0dExVYUJJWnNUQzhjc1c5a0lXYzEtY3JIVmZkT] (zh:…
      第三十五届“哈洽会”数字经济展区亮点纷呈 黑龙江人民网
  - (2026-07-19) 国别频道 - 黑龙江人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE14cVFqWkJ6dm9JekZQRlpKcEtyOVRsY1VDVEh1VkszUjFnU3RNQjVFWVNUQTQwWm1QS3g0czBjYk1tdmdNUHdqakFyV1NuZi1iWWFYWXcyWlpoU] (zh:…
      国别频道 黑龙江人民网
  - (2026-07-21) 30万点赞！“大手牵小手”，定格暑期实践最暖瞬间 - 人民网－湖北频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9nVDFHd3ltNHg4OFh3ZW5PaVotMGpmNjE1LWR6aGk0R0JoNUs1djM2UmVacXhpRW9aQ293dFJYelR4V2dUM1RsQ25] (zh:…
      30万点赞！“大手牵小手”，定格暑期实践最暖瞬间 人民网－湖北频道
  - (2026-07-21) 人民锐评：保研辅导岂能沦为“收割焦虑”的生意？ - 人民网教育 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBldXRwbW92RGxJb0pxMm41NFVzN1RxcDFzSGgtbm04NjlyMWhUV2hPV0lrV1JVa2hYOHNIRjU1T2FUY2hzY1dGc3I2LVh] (zh:…
      人民锐评：保研辅导岂能沦为“收割焦虑”的生意？ 人民网教育
  - (2026-07-21) 人民直击｜这样的保研辅导是助力还是陷阱？ - 人民网教育 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE1TS2F1S29QMjhoQ1IxbUlydkF1TmlNbE9kOVBkbUNCSmpqYjJZN0x5LTVzQW1VOEdNa1VTSERCVlkzaGJHekRKZUoxWmE1S1] (zh:…
      人民直击｜这样的保研辅导是助力还是陷阱？ 人民网教育

### U.S. Weather + Severe / Climate Outlooks — 160 new of 175 total
  - (2026-07-21) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-21) [Moderate] Special Weather Statement: Special Weather Statement issued July 21 at 5:35AM EDT by NWS Northern Indiana
      At 535 AM EDT, Doppler radar was tracking a cluster of strong thunderstorms over Bluffton, moving east at 40 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated. IMPACT...Gusty winds could…
  - (2026-07-21) [Moderate] Special Weather Statement: Special Weather Statement issued July 21 at 1:31AM AKDT by NWS Fairbanks AK
      At 131 AM AKDT, Doppler radar was tracking a cluster of strong thunderstorms 36 miles southeast of Seven Mile, or 46 miles north of Murphy Dome, moving northwest at 40 mph. HAZARD...Pea size hail. SOURCE...Radar indicate…
  - (2026-07-21) [Moderate] Tropical Cyclone Local Statement: Tropical Cyclone Local Statement issued July 21 at 4:21AM CDT by NWS Mobile AL
      HLSMOB This product covers portions of southwest Alabama...northwest Florida...south central Alabama...and inland southeast Mississippi. **TROPICAL STORM BERTHA WILL BRING COASTAL AND OFFSHORE IMPACTS LATER TODAY THROUGH…
  - (2026-07-21) [Moderate] Special Weather Statement: Special Weather Statement issued July 21 at 1:18AM AKDT by NWS Fairbanks AK
      At 118 AM AKDT, Doppler radar was tracking a cluster of strong thunderstorms 56 miles north of Cleary Summit, or 59 miles northwest of Twelvemile Summit, moving northwest at 25 mph. HAZARD...Pea size hail. SOURCE...Radar…
  - (2026-07-21) [Moderate] Special Weather Statement: Special Weather Statement issued July 21 at 3:17AM MDT by NWS Salt Lake City UT
      At 317 AM MDT, Doppler radar was tracking strong thunderstorms along a line extending from 11 miles east of Fillmore to 11 miles west of Marysvale. Movement was west at 25 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...…

### State-Level News — 68 new of 482 total
  - (2026-07-21) [Arizona] School voucher advocates sue to keep ESA reform measure off the November ballot
      The Goldwater Institute, is attempting to convince a court to block the “Protect Education, Accountability Now Act” from the November ballot by disqualifying tens of thousands of voter signatures supporting it. The citiz…
  - (2026-07-21) [Connecticut] It’s a bird! It’s a plane! It’s a very expensive collision!
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/BIRD-STRIKES-071526-JL-013-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fet…
  - (2026-07-21) [Connecticut] CT ratepayers pay the price when utility bullying goes unchecked
      <img width="545" height="300" src="https://ctmirror.org/wp-content/uploads/2026/07/Electric-bill.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="htt…
  - (2026-07-21) [Connecticut] State land ownership doesn’t equal stewardship
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/BATTERSON-PARK-0630-JL-004-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loa…
  - (2026-07-21) [Connecticut] CT’s pre-K endowment diverts pension dollars
      <img width="907" height="372" src="https://ctmirror.org/wp-content/uploads/2026/06/Reason-report-graphic.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" src…
  - (2026-07-21) [California] Governor Newsom announces appointments 7.20.26
      Source

### Local News: St. Louis + Atlanta — 55 new of 198 total
  - (2026-07-21) [St. Louis] Tanglefoot Dance Hall offers country dancing 6 days a week
      After opening in May with dancing and lessons, the Festus venue is now also serving food and drinks as a bar and grill.
  - (2026-07-21) [St. Louis] Winning Powerball numbers for Monday, July 20, 2026: Did anyone win the jackpot?
      Check your numbers! Did you win the $544 million Powerball jackpot?
  - (2026-07-21) [St. Louis] 'Sticks out for Zach': Hockey community mourns 18-year-old killed on I-64
      Zachary Pruss, a recent high school graduate, is being mourned by the St. Charles County hockey community following a fatal crash on I-64.
  - (2026-07-21) [St. Louis] 'We sold out': Local farms see spike in lettuce sales as Missouri cyclosporiasis outbreak grows
      Some St. Louis-area growers say customers are asking more questions about where their lettuce comes from after Missouri reported 216 cases of the parasite.
  - (2026-07-21) [St. Louis] Tropical Storm Bertha forms on track approaching US Gulf Coast
      The slow-moving storm has been drifting erratically but is expected to stay near or along the northern Gulf Coast this week.
  - (2026-07-21) [St. Louis] Ladue City Council rejects controversial Rock Hill Quarries Landfill development proposal
      After hours of debate and public comment, council members cited traffic and flooding concerns in unanimously denying the proposed redevelopment.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-21) [Lally Robert B] Form 4 (Reporting)
      filed 2026-07-21 01:47 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0002126940-26-000004 Size: 7 KB
  - (2026-07-21) [ImageneBio, Inc.] Form 4 (Issuer)
      filed 2026-07-21 01:47 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0002126940-26-000004 Size: 7 KB
  - (2026-07-21) [Tomasello Vickie] Form 4 (Reporting)
      filed 2026-07-21 01:36 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0001493225-26-000088 Size: 8 KB
  - (2026-07-21) [Northfield Bancorp, Inc.] Form 4 (Issuer)
      filed 2026-07-21 01:36 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0001493225-26-000088 Size: 8 KB
  - (2026-07-21) [Patafio Frank P.] Form 4 (Reporting)
      filed 2026-07-21 01:36 UTC · role: Reporting — Filed: 2026-07-20 AccNo: 0001493225-26-000087 Size: 7 KB
  - (2026-07-21) [Northfield Bancorp, Inc.] Form 4 (Issuer)
      filed 2026-07-21 01:36 UTC · role: Issuer — Filed: 2026-07-20 AccNo: 0001493225-26-000087 Size: 7 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-21) [Malaysia] Cops probing whether online groups influenced Banting school stabbing
      domain: freemalaysiatoday.com · language: English · tone:
  - (2026-07-21) [United States] Preliminary Hearing For D4vd Starts Today | News Radio 690 KTSM
      domain: ktsmradio.iheart.com · language: English · tone:
  - (2026-07-21) [India] Automation Expo 2026 Brings 700+ Exhibitors as Industry Leaders Back India Biggest Automation Show
      domain: newsx.com · language: English · tone:
  - (2026-07-21) [Ireland] Alzheimer blood test could identify risk up to 10 years before symptoms start
      domain: irishdentist.ie · language: English · tone:
  - (2026-07-21) [United Kingdom] Coffee Heart Disease Warning : Why Your Daily Brew Could Help or Harm Your Heart
      domain: ibtimes.co.uk · language: English · tone:
  - (2026-07-21) [India] PM Modi Announces Ex Gratia After Sikkim Tunnel Collapse
      domain: deccanchronicle.com · language: English · tone:

### Ukrainian Internal News (national + local Kyiv) — 33 new of 98 total
  - (2026-07-21) Парламент Франції готується ухвалити заборону на соцмережі для дітей до 15 років | LEDE: Французькі законодавці у вівторок мають схвалити законопроєкт, який забороняє доступ до соціальних мереж] (uk:…
      Французькі законодавці у вівторок мають схвалити законопроєкт, який забороняє доступ до соціальних мереж дітям віком до 15 років, завдяки чому Франція стане лідером серед країн ЄС, що вживають подібних заходів.
  - (2026-07-21) Литовська армія посилить охорону СПГ-термінала через загрозу провокацій з боку РФ | LEDE: Армія Литви найближчим часом посилить охорону термінала скрапленого природного газу (СПГ) у Клайпеді – ] (uk:…
      Армія Литви найближчим часом посилить охорону термінала скрапленого природного газу (СПГ) у Клайпеді – таке рішення прийняли на тлі попереджень про можливі провокації з боку Росії у країнах Балтії.
  - (2026-07-21) Двоє людей постраждали внаслідок російської атаки на Одесу | LEDE: 21 липня російські війська атакували Одесу: поранені 17-річний хлопець і 23-річна дівчина, пошкоджені будинки.] (uk: Двоє людей постр…
      21 липня російські війська атакували Одесу: поранені 17-річний хлопець і 23-річна дівчина, пошкоджені будинки.
  - (2026-07-21) Окупанти вдарили КАБами по житлових кварталах Запоріжжя: є загиблий, двоє поранені | LEDE: 21 липня росіяни атакували Запоріжжя авіабомбами: одна людина загинула, одна поранена, пошкоджені буді] (uk:…
      21 липня росіяни атакували Запоріжжя авіабомбами: одна людина загинула, одна поранена, пошкоджені будівлі.
  - (2026-07-21) За останні кілька тижнів конфлікту з Іраном майже 100 військових США були пораненні | LEDE: З 7 липня майже 100 американських військовослужбовців отримали поранення різного ступеня тяжкості у м] (uk:…
      З 7 липня майже 100 американських військовослужбовців отримали поранення різного ступеня тяжкості у межах конфлікту з Іраном, розповіли у Пентагоні.
  - (2026-07-21) Радник президента Литви: Ентузіазм ЄС щодо санкцій проти Росії слабшає | LEDE: Старший радник президента Литви Дейвідас Матульоніс попередив, що всередині ЄС слабшає ентузіазм стосовно впровадж] (uk:…
      Старший радник президента Литви Дейвідас Матульоніс попередив, що всередині ЄС слабшає ентузіазм стосовно впровадження нових санкцій проти Росії.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 30 new of 30 total
  - (2026-07-21) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (47.717, 1.9874) · alt: 7330m · 852km/h
  - (2026-07-21) JAF94H (Bulgaria)
      icao24: 4520aa · position: (48.4529, 0.4372) · alt: 7924m · 877km/h
  - (2026-07-21) GAF175 (Germany)
      icao24: 3f7588 · position: (34.8051, 23.7889) · alt: 9136m · 731km/h
  - (2026-07-21) PUMA52 (Slovenia)
      icao24: 506e18 · position: (45.9129, 15.5207) · alt: 487m · 177km/h
  - (2026-07-21) SAMU691 (France)
      icao24: 39c994 · position: (45.7478, 4.9026) · on ground · 0km/h
  - (2026-07-21) JAF3NE (Belgium)
      icao24: 44d1ba · position: (47.9549, 0.8598) · alt: 10363m · 780km/h

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-21) [Israel-Iran-Hezbollah axis · themes] Razorne poplave u Avganistanu : Najmanje 20 mrtvih , 100 nestalih
      nezavisne.com · Serbian · tone NA
  - (2026-07-21) [Israel-Iran-Hezbollah axis · themes] Vzpoura v centru Prahy . Vyškrtnutý Dvořák z ODS údajně spřádá plán pomsty
      novinky.cz · Czech · tone NA
  - (2026-07-21) [Israel-Iran-Hezbollah axis · themes] У побережья Румынии поразили танкер , направлявшийся в Украину
      korrespondent.net · Russian · tone NA
  - (2026-07-21) [Israel-Iran-Hezbollah axis · themes] Rumah Mewah di Medan Meledak , Tim SAR Kerahkan 400 Personel Cari Korban Tertimbun
      batam.tribunnews.com · Indonesian · tone NA
  - (2026-07-21) [Israel-Iran-Hezbollah axis · themes] Preliminary Hearing For D4vd Starts Today | News Radio 690 KTSM
      ktsmradio.iheart.com · English · tone NA
  - (2026-07-21) [Israel-Iran-Hezbollah axis · themes] Cleopatra : Ratu Terakhir Mesir yang Berjuang di Tengah Bayang - Bayang Romawi
      kompas.com · Indonesian · tone NA

### U.S. Federal Action — 21 new of 23 total
  - (2026-07-21) Order Sunsetting Certain Large Trader Reporting Requirements for Physical Commodity Swaps
      The Commodity Futures Trading Commission ("CFTC" or the "Commission") is issuing this Order pursuant to Sec. 20.9 of its regulations, the sunset provision of the Commission's large trader reporting rules for physical com…
  - (2026-07-21) Patient Protection and Affordable Care Act, HHS Notice of Benefit and Payment Parameters for 2027; and Basic Health Program; Correction
      This document corrects typographical errors in the final rule that appeared in the May 20, 2026, Federal Register titled "Patient Protection and Affordable Care Act, HHS Notice of Benefit and Payment Parameters for 2027;…
  - (2026-07-21) General Technical, Organizational, Conforming, and Correcting Amendments to the Federal Motor Carrier Safety Regulations
      FMCSA amends its regulations by making technical corrections throughout the Federal Motor Carrier Safety Regulations (FMCSR). The Agency makes minor changes to correct inadvertent errors and omissions, remove or update o…
  - (2026-07-21) USCIS Immigration Fees and Related Procedures Required by H.R.1 Reconciliation Bill; Correction
      This document corrects the interim final rule (IFR) that published in the Federal Register on April 29, 2026. The IFR codified certain immigration fees and other provisions required by the One Big Beautiful Bill Act (H.R…
  - (2026-07-21) Fisheries of the Northeastern United States; Summer Flounder Fishery; Quota Transfer From North Carolina to Massachusetts
      NMFS announces that the State of North Carolina is transferring a portion of its 2026 commercial summer flounder quota to the Commonwealth of Massachusetts. This adjustment to the 2026 fishing year quota is necessary to…
  - (2026-07-21) Magnuson-Stevens Act Provisions; Fisheries Off West Coast States; Pacific Coast Groundfish Fishery; Pacific Coast Groundfish Fishery Management Plan; Amendment 38; 2027-28 Biennial Specifications and…
      NMFS announces that the Pacific Fishery Management Council (Council) submitted amendment 38 to the Pacific Coast Groundfish Fishery Management Plan (Groundfish FMP) to the Secretary of Commerce for review. If approved, a…

### Paper Trading Scorecard — 12 new of 143 total
  - (2026-07-21) [Polymarket] Will Trump meet with Benjamin Netanyahu in July 2026?
      This market will resolve to "Yes" if the listed individual meets with Donald Trump between July 1 and July 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No". A meeting is defined as any encounter where b…
  - (2026-07-21) [Polymarket] Iran invades Kuwait by July 31?
      This market will resolve to "Yes" if Iranian military forces enter Kuwait by the listed date, 11:59 PM ET in a military operation that establishes control over any portion of Kuwait territory. Otherwise, this market will…
  - (2026-07-21) [Polymarket] Hamad bin Isa Al Khalifa out as leader of Bahrain by December 31, 2026?
      This market will resolve to "Yes" if the King of Bahrain, Hamad bin Isa Al Khalifa, ceases to be the de facto leader of Bahrain at any point between market creation and December 31, 2026, 11:59 PM ET. Otherwise, this mar…
  - (2026-07-21) [Kalshi] Kylian Mbappe Total FIFA World Cup Career Goals
      Kylian Mbappe
  - (2026-07-21) [Manifold] Will Anthropic allow me to have a daily or weekly usage credit limit in 2026?
  - (2026-07-21) [Manifold] Will @tooawful on telegram be found dead before sept?

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-21) [China] Ping An Unveils Innovative AI Solutions in Healthcare , Insurance and Payments at WAIC 2026
      asiabulletin.com · English
  - (2026-07-21) [China] China permits injured personnel transfer from illegally grounded Philippine vessel at Renai Jiao
      en.people.cn · English
  - (2026-07-21) [China] Update : China permits injured personnel transfer from illegally
      asiabulletin.com · English
  - (2026-07-21) [China] Sakshi Chaudhary to represent India at Commonwealth Games 51 Kgs women boxing category
      asiabulletin.com · English
  - (2026-07-21) [China] Vessels conduct towing and salvage training - People Daily Online
      en.people.cn · English
  - (2026-07-21) [China] Zoomlion Expands European Service Network with Professional Training and 4 - Hour On - Site Support
      asiabulletin.com · English

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 57 total
  - (2026-07-21) [BleepingComputer] Microsoft shares manual fix for WSUS sync delays and timeouts
      Microsoft has shared manual mitigations to help IT administrators fix Windows Server Update Services (WSUS) servers affected by a known issue that causes Windows Update scans to fail or time out. [...]
  - (2026-07-21) [BleepingComputer] Windows LegacyHive zero-day flaw gets free, unofficial patches
      Free unofficial patches are available for a recently disclosed Windows zero-day flaw that allows attackers to escalate privileges on up-to-date Windows systems. [...]
  - (2026-07-21) [The Hacker News] WordPress wp2shell Exploitation Grows as Public Exploit Fuels Mass Scanning
      Attackers have begun to exploit two critical vulnerabilities in WordPress that, when combined together, enable unauthenticated remote code execution (RCE) and complete compromise of vulnerable websites. The two security…
  - (2026-07-21) [The Hacker News] New ENCFORGE Ransomware Targets AI Model Files in Langflow RCE Attack
      Researchers at Sysdig have linked a second attack on the same Langflow server to JADEPUFFER, the AI-agent-driven operator it first documented earlier this month. The same operator has now been spotted deploying ENCFORGE,…
  - (2026-07-21) [The Hacker News] Critical ServiceNow AI Platform Flaw Exploited for Unauthenticated Code Execution
      Threat actors are now exploiting a recently disclosed critical security flaw impacting ServiceNow AI Platform, according to Defused Cyber. In a post shared on X, the threat intelligence firm said it's observing in-the-wi…
  - (2026-07-21) [The Register] Some Mullvad VPN customers tunnel for exit after co-founder donates millions to populist party
      SEK 5M gift supplied 72 percent of Örebropartiet's annual income, but company insists it was strictly personal

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-07-21) Will Gretchen Whitmer win the 2028 US Presidential Election?
      yes price: 1% · 24h volume: $1,442,891 · resolves 2028-11-07
  - (2026-07-21) LoL: BNK FEARX vs Dplus KIA (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $1,249,999 · resolves 2026-07-21
  - (2026-07-21) LoL: Gen.G vs T1 (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $1,187,004 · resolves 2026-07-21
  - (2026-07-21) LoL: Gen.G vs Hanwha Life Esports (BO1) - KeSPA Cup Group Stage
      yes price: 0% · 24h volume: $726,204 · resolves 2026-07-21
  - (2026-07-21) Will Gretchen Whitmer win the 2028 Democratic presidential nomination?
      yes price: 2% · 24h volume: $650,411 · resolves 2028-11-07
  - (2026-07-21) LoL: KT Rolster vs Dplus KIA (BO1) - KeSPA Cup Group Stage
      yes price: 100% · 24h volume: $584,364 · resolves 2026-07-21

### Court opinions of consequence (federal & state) — 8 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, D.C. Cir.: Heritage Foundation v. DOJ
  - (2026-07-20) U.S. Court of Appeals, 9th Cir.: Garcia Demetrio v. Blanche
  - (2026-07-17) U.S. Court of Appeals, 9th Cir.: United States v. Holcomb
  - (2026-07-16) U.S. Court of Appeals, 8th Cir.: Joshua Glasscock v. Sig Sauer, Inc.
  - (2026-07-16) Supreme Court of California: Maniago v. Desert Cardiology Consultants' Medical Group
  - (2026-07-16) U.S. Court of Appeals, 6th Cir.: United States v. Samuel Arellio Hernandez

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 38 total
  - (2026-07-21) MOVER ▲ Masayoshi Son — $67.52B (+$3.54B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-21) MOVER ▲ Tadashi Yanai & family — $67.53B (+$1.46B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-21) MOVER ▼ Mukesh Ambani — $88.44B ($-1.10B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-21) MOVER ▲ Amancio Ortega — $136.97B (+$0.72B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-21) MOVER ▼ Bernard Arnault & family — $148.46B ($-0.60B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-21) MOVER ▲ Gautam Adani — $90.19B (+$0.47B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### GDACS — global disaster alerts — 7 new of 186 total
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-19) [Green] Flood in Afghanistan
      Flood · Green alert · Afghanistan · Magnitude 0
  - (2026-07-20) [Green] Earthquake in Pacific-Antarctic Ridge
      Earthquake · Green alert · Pacific-Antarctic Ridge · Magnitude 5.5M, Depth:10km
  - (2026-07-20) [Green] Earthquake in Pacific-Antarctic Ridge
      Earthquake · Green alert · Pacific-Antarctic Ridge · Magnitude 5.5M, Depth:10km
  - (2026-07-20) [Green] Earthquake in Northern Mid-Atlantic Ridge
      Earthquake · Green alert · Northern Mid-Atlantic Ridge · Magnitude 5.6M, Depth:10km

### USGS earthquakes (M4.5+, past day) — 5 new of 15 total
  - (2026-07-21) M 5.2 - northern Mid-Atlantic Ridge
      M5.2 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-07-21) M 5.0 - Mid-Indian Ridge
      M5.0 · Mid-Indian Ridge · depth 10 km
  - (2026-07-20) M 5.0 - 141 km SSW of Gataivai, Samoa
      M5.0 · 141 km SSW of Gataivai, Samoa · depth 10 km
  - (2026-07-21) M 4.6 - 84 km SW of Puerto Madero, Mexico
      M4.6 · 84 km SW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-21) M 4.6 - south of the Fiji Islands
      M4.6 · south of the Fiji Islands · depth 204.561 km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-21) [Marginal Revolution] The economic effects of GLP-1s
      We estimate the causal impacts of GLP-1 treatment on labor market outcomes using linked Danish administrative data and a matched stacked difference-in-differences design. We compare patients who initiate GLP-1 treatment…
  - (2026-07-21) [Marginal Revolution] Is America ruled by an oligarchy?
      Any time you hear claims about American government, a sanity-inducing response is to ask whether they also are true of state and local governments. Here is an excerpt from my latest piece at The Free Press: First, in peo…

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 115 total
  - (2026-07-21) [BIS Entity List] page checksum 47a6bf4796c4
      Page content hash: 47a6bf4796c4. Compare with prior day's hash to detect updates.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-21) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=23, 7d-median=20, 14d-median=20; carrying terms: local, reporting, wildlife, personnel, navigable, allow, commission, species, remove, fishery, revised, published
- state_bills: today=0, 7d-median=100, 14d-median=100
- state_news: today=482, 7d-median=474, 14d-median=474; carrying terms: nevada, grand, alleged, communities, president, announcement, single, bottom, saying, experts, custody, allow
- local_news: today=198, 7d-median=216, 14d-median=216; carrying terms: major, woman, experts, overnight, voters, charges, sentenced, schools, saportareport, sheriff, music, loading
- foreign_news: today=972, 7d-median=1022, 14d-median=1022; carrying terms: crimes, grand, xinhua, alleged, warned, president, communities, announcement, forum, protests, winner, rsshub
- chinese_internal: today=283, 7d-median=280, 14d-median=280; carrying terms: articles, cbmiyefvx, caixin, lxtfa, cbmia, cbmiy, people, cbmizkfvx, blank, cbmiykfvx, politics, cbmib
- russian_internal: today=889, 7d-median=884, 14d-median=884; carrying terms: error, media, insider, bloomberg, https, apple, times, raquo, httperror, russian, gazeta, telegram
- ukrainian_internal: today=98, 7d-median=126, 14d-median=126; carrying terms: kremlin, major, president, claimed, announcement, called, government, hromadske, though, people, recorded, others
- ukraine_theater: today=695, 7d-median=523, 14d-median=523; carrying terms: rgzenmnsre, syria, wlotalcytmlrmxq, rzbhlqqkrytlvgr, president, ficgrvovfusgxkvgt, lwotd, cuxnrxlwogjjuhdjau, mqklfrtryq, ziewntoetzqtjkctziaxdpmlzfduhonwjrstfnbtjuoefusjrcanddotdibwjcohutegtmbuvhdgfmnmj, zuclnxymn, ktvtjtvxnubhztegpcajfjn
- paper_bets: today=143, 7d-median=143, 14d-median=143; carrying terms: trillionaire, approve, india, goals, president, comes, announcement, succeed, government, human, majors, supervolcano
- weather: today=175, 7d-median=171, 14d-median=171; carrying terms: grand, north, prone, prolonged, overnight, reaching, flood, coastal, hazards, holly, oxnard, drainage
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: growth, unrate, total, dexuseu, recession, headline, jolts, crude, balance, walcl, energy, indicator
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, equities, proxy, treasury, rates, silver, china, russell, corporate, credit, futures, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=115, 7d-median=116, 14d-median=116; carrying terms: syria, niger, relationship, landing, president, government, engineering, transactions, protests, chemical, satisfying, bosnia
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quantitative, httperror, quiverquant, https, unauthorized, congresstrading, quiver, client
- billionaires: today=38, 7d-median=33, 14d-median=33; carrying terms: france, buffett, india, family, steve, bloomberg, bezos, technologies, infrastructure, meyers, cryptocurrency, euronext
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: school, william, limited, appeals, daimler, north, international, company, trucks, supreme, association, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: local, cortez, ocasio, committee, jonathan, disbursements, elect, senate, cooper, sherrod, lowden, david
- gdelt_regions: today=12, 7d-median=12, 14d-median=12; carrying terms: english, japan
- gdelt_gkg: today=25, 7d-median=35, 14d-median=35; carrying terms: english, russian, hezbollah, israel, chinese, themes, arabic
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: trump, takes, language, domain, killed, crash, australia, kingdom, english
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: local, india, posing, niger, routine, reporting, elements, region, observed, months, global, cases
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: remediation, injection, vulnerability, request, product, bypass, sharepoint, microsoft, access, server, traversal, cisco
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=186, 7d-median=156, 14d-median=156; carrying terms: france, philippines, indonesia, romania, kenya, hungary, ukraine, alert, green, republic, vietnam, cambodia
- usgs_quakes: today=15, 7d-median=18, 14d-median=18; carrying terms: depth, south, indonesia, puerto, mexico, madero, ridge, islands, kermadec, tonga, atlantic
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, price, ethiopia, interest, rates, prime, volume, meeting, resolves, mekonnen, demeke, change
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, marginal, conversable, class, revolution, economist, working, often, heidi, things, jaeger, mokyr
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: algorithm, major, career, researchers, months, government, engineering, cyberattack, single, arbitrary, people, users
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: hinson, william, mcclintock, yakym, nicole, lalota, daniel, grace, president, score, cleveland, ramirez
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, sufficient, consensus, decision, today, market, module, placed, markets, either, paper, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-07] Fed speeches: Bowman, Opening Remarks on Sound Practices for Artificial Intelligence
- [2026-07-07] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to amend its requirements for banks to maintain anti-money laundering programs
- [2026-07-08] Fed press (events + announcements): Minutes of the Federal Open Market Committee, June 16-17, 2026
- [2026-07-09] ECB press: Meeting of 10-11 June 2026
- [2026-07-09] Fed press (events + announcements): Federal Reserve Board issues enforcement action with TS Banking Group, Inc. and TS Contrarian Bancshares, Inc.
- [2026-07-09] Fed press (events + announcements): Federal Reserve announces the leadership and objectives of its task forces to advance the conduct of monetary policy
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-13] ECB press: Isabel Schnabel: How to foster growth and resilience in Europe
- [2026-07-13] ECB press: Piero Cipollone: Interview with Jornal de Negocios
- [2026-07-14] ECB press: ECB selects 36 payment service providers to join digital euro pilot
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] ECB press: Piero Cipollone: Interview with Ouest-France
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*