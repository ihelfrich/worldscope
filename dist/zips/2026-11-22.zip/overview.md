# WORLDSCOPE morning brief — 2026-11-22

## Headline
2589 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (646) · Russian Internal News (state + in-exile) (478) · World leaders & government officials (324) · Chinese Internal News (199) · U.S. Weather + Severe / Climate Outlooks (123) · Local News: St. Louis + Atlanta (118) · GDELT GKG — themes / entities / watch areas (104) · World News (by country, top stories) (98) · State-Level News (89) · Ukraine Theater (total-war monitoring) (71) · State Legislative Action (50) · Ukrainian Internal News (national + local Kyiv) (50)

## What changed today
### International News + Multilateral Institutions — 646 new of 961 total
  - (2026-11-22) [Global] New draft deal aims to avert collapse of talks at COP31 climate summit
      The UN COP31 meeting in Turkey enters a second day of overtime as countries struggle to reach an agreement.
  - (2026-11-21) [Global] Zelensky says Crimean Bridge strikes 'fair response' as he meets UK's Streeting
      Ukraine's president says Kyiv acted after 109 separate Russian aerial attacks on bridges in Ukraine.
  - (2026-11-21) [Global] Russia-bound ship attacked in Gulf of Finland
      Finnish defence forces say that Ukraine was likely behind the drone attack on the vessel.
  - (2026-11-22) [Global] Mexican drug lord on FBI's 10 most wanted list arrested in shoot-out
      Fausto Isidro "Chapo Idisro" Meza Flores, who is accused of drug trafficking and torture, is detained after gun fight with authorities.
  - (2026-11-22) [Global] FBI reportedly investigating apparent hack of its criminal database
      The National Crime Information Center database is used by federal and local law enforcement to share information.
  - (2026-11-22) [Global] Dozens missing after fire at Indonesian factory
      At least three people were killed and four injured in a fire at a confectionary factory over the weekend.

### Russian Internal News (state + in-exile) — 478 new of 780 total
  - (2026-11-22) «Они хотят сожрать друг друга». «Аль-Каеда» и «Исламское государство» ведут тайную войну в Африке. Ее исход повлияет на миллионы человек | LEDE: Между террористическими группировками и «Аль-] (ru: «Он…
      Между террористическими группировками и «Аль-Каеда» и «Исламское государство» на протяжении трех месяцев идут ожесточенные бои в регионе Сахель в Западной Африке. Хотя организации враждуют уже несколько лет, нынешнее про…
  - (2026-11-22) В Калининградской области впервые сработали сирены воздушной тревоги. Губернатор заявил о «подозрительном объекте со стороны Литвы» | LEDE: Вечером 21 ноября в Калининградской области прозву] (ru: В К…
      Вечером 21 ноября в Калининградской области прозвучали сирены воздушной тревоги. По данным СМИ, это произошло впервые с начала полномасштабной войны.
  - (2026-11-22) Познакомьтесь с новым владельцем сервиса Miro, придуманного в Перми. Это компания Bending Spoons. Она скупает приложения, увольняет команды и повышает цены (чтобы скупать еще больше приложений)] (ru:…
      В конце октября Miro — сервис для совместной работы, созданный российским разработчиками и взлетевший во время пандемии, — получил нового владельца. Им стала итальянская технологическая компания Bending Spoons, которая с…
  - (2026-11-21) Дания призвала страны ЕС прекратить выдачу туристических виз россиянам | LEDE: Дания предложила странам Евросоюза ввести дополнительные ограничения на въезд россиян в Шенгенскую зону. Ноту с] (ru: Дан…
      Дания предложила странам Евросоюза ввести дополнительные ограничения на въезд россиян в Шенгенскую зону. Ноту с таким требованием Копенгаген разослал правительствам стран ЕС, рассказали Reuters два дипломата.
  - (2026-11-21) Зеленский предложил эвакуировать жителей 15 населенных пунктов по примеру Алешек | LEDE: Киев передал США предложение организовать гуманитарную миссию по эвакуации жителей из 15 населенных п] (ru: Зел…
      Киев передал США предложение организовать гуманитарную миссию по эвакуации жителей из 15 населенных пунктов Херсонской и Запорожской областей, сообщил журналистам президент Украины Владимир Зеленский.
  - (2026-11-21) Жерара Депардье и Мишеля Уэльбека обвинили в изнасиловании актрисы во время съемок фильма «Спа». Новые обвинения в адрес актера появились за неделю до суда по другому делу о сексуализированном ] (ru:…
      Французские актер Жерар Депардье и писатель Мишель Уэльбек стали фигурантами досудебного расследования по делу о сексуализированном насилии, сообщили местные издания (1,2,3), ссылаясь на источники. По данным СМИ, Депардь…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 199 new of 271 total
  - (2026-11-21) 回购潮的“偏题”：员工激励式回购不是给股东的礼物 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9wNzcxZUtPQnV2ZmVaVWtuTDRHMkFJeFZadkJpcnFaWjhRLW9xMGVqa0dZZmIyN3ladUh1a1drOE5panQ2VkFtcmRnZmZZW] (zh:…
      回购潮的“偏题”：员工激励式回购不是给股东的礼物 财新
  - (2026-11-21) 大西洋观察｜联合国气候大会的无奈与现实 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBaTVBiWGxEdVB2d2VOUmg1ZGJPMWZua094cXZXcmNsY2s3WnhGV0daU1FHLU1pUXduelgtUHJDWEgzZ01DcENrdzdFc2NFNHU5Tk] (zh:…
      大西洋观察｜联合国气候大会的无奈与现实 财新
  - (2026-11-22) 财新观察｜亚太回答时代课题 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFB0Tko3M3dFWmhPVkttUng3QXJIX0ZNNnZZbWdoNEx3M2VCLWMxbVluaFd2WGhWZlpWNjkzV2RkTlkxajFLSTQ5Z3JmM3gycWd4UWhoUExB] (zh:…
      财新观察｜亚太回答时代课题 财新
  - (2026-11-22) 中石油集团副总经理谢军被查 长期任职西南油气田 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE0yZEdmemdxQW5Xd0dwLW9wbkk2MUhEczJkcjRHMklHeEtFemJtS3N0T19TbGdNNnQzSmRjaWN0QkU3ME55cFAyRkt0UDlhaV] (zh:…
      中石油集团副总经理谢军被查 长期任职西南油气田 财新
  - (2026-11-22) 《可能的爱》：不可凝视，不可贪恋｜影视 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9EU0ZkRGx2RVRuOFpQUlZNdHQwNWg1cnFMSHRvSDRvcUFwdjVCc0g2ZFM1UmJSd0Y0bWNpbnluT2hGdml6SXVCZElKWFp2MkFaZ2] (zh:…
      《可能的爱》：不可凝视，不可贪恋｜影视 财新
  - (2026-11-21) 最新财新周刊｜APEC的深圳时间 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9RcmE2SmJQcE84X0VMN3Z1Q0NGaXBQNjkyYkoxT2lUcWJqZGtJTWptbDNnQnlTVXEwNk80bjJKOFdXakVQN0wwSlhmVGRoUmVIVEZDX] (zh:…
      最新财新周刊｜APEC的深圳时间 财新

### U.S. Weather + Severe / Climate Outlooks — 123 new of 125 total
  - (2026-11-22) [Moderate] Special Weather Statement: Special Weather Statement issued November 22 at 1:28AM CST by NWS Norman OK
      At 128 AM CST, trained weather spotters reported a strong thunderstorm 9 miles east of Hinton, moving northeast at 30 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Trained weather spotters reported a 50 mph wind gust i…
  - (2026-11-22) [Moderate] Special Weather Statement: Special Weather Statement issued November 22 at 2:27AM EST by NWS Charleston SC
      Areas of fog will continue to develop across portions of Southeast Georgia this morning. The fog could become locally dense at time with visibilities dropping to 1/4 mile or less. The nature of the fog is such that visib…
  - (2026-11-22) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-22) [Moderate] Special Weather Statement: Special Weather Statement issued November 22 at 1:19AM CST by NWS Norman OK
      At 119 AM CST, Doppler radar was tracking strong thunderstorms along a line extending from 3 miles west of Norge to 6 miles east of Rush Springs to near Marlow. Movement was northeast at 35 mph. HAZARD...Wind gusts up to…
  - (2026-11-22) [Moderate] Special Weather Statement: Special Weather Statement issued November 22 at 1:14AM CST by NWS Norman OK
      At 114 AM CST, Doppler radar was tracking a strong thunderstorm near Lake Chickasha, moving northeast at 50 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated. IMPACT...Gusty winds could k…
  - (2026-11-21) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued November 21 at 10:12PM AKST until November 22 at 9:00AM AKST by NWS Juneau AK
      * WHAT...Visibility 1/4 mile in dense fog. * WHERE...City and Borough of Sitka. * WHEN...Until 9 AM AKST Sunday. * IMPACTS...Low visibility could make travel conditions hazardous.

### Local News: St. Louis + Atlanta — 118 new of 210 total
  - (2026-11-21) [St. Louis] Celebrate the holiday season with festive events and performances
      As Thanksgiving approaches, the holiday season starts in earnest among St. Louis’ cultural institutions, theater companies, and venues. Mark your calendars for some free holiday celebrations or splurge on tickets for the…
  - (2026-11-21) [St. Louis] Kirkwood’s first Festival of Trees is underway at KPAC
      The lobby is all aglow at the Kirkwood Performing Arts Center (210 E. Monroe), where Kirkwood’s first-ever Festival of Trees has taken over. On view from November 21–December 4, the festive display includes wreath and tr…
  - (2026-11-21) [St. Louis] Vitale’s Deli in Glendale will close December 19
      For 11 years, Mike Vitale’s lunch counter across from Glendale City Hall has been a neighborhood fixture. Now Vitale is ready to retire. He says Vitale’s Deli (425 N. Sappington Road) will close Saturday, December 19. He…
  - (2026-11-22) [St. Louis] President Trump vows to work with Democrats to cap credit card interest rates at 10%
      President Donald Trump said Saturday that he would work with the incoming Democratic Congress to cap credit card interest rates.
  - (2026-11-22) [St. Louis] Video shows masked ICE agents detaining 2 passengers at Seattle airport
      Masked U.S. immigration officers have detained two people on a jet bridge at Seattle-Tacoma International Airport as passengers were boarding.
  - (2026-11-22) [St. Louis] Cat escapes kennel on Delta flight taking off for Florida
      A flight from Boston to Tampa was briefly delayed Friday when a cat escaped its kennel while the aircraft was taxiing before takeoff, according to Delta Air Lines.

### GDELT GKG — themes / entities / watch areas — 104 new of 104 total
  - (2026-11-22) [Russia oil sanctions perimeter · near] Ukraine's shortage of window installers threatens to leave families exposed this winter
      wgauradio.com · English · tone -4.20819490586933 · 7 other outlets
  - (2026-11-22) [Russia oil sanctions perimeter · near] Poland Russian drone activity
      politicaldog101.com · English · tone -4.76190476190476 · 1 other outlets
  - (2026-11-22) [Russia oil sanctions perimeter · near] "Clearest security guarantee for Ukraine is NATO membership": Zelenskyy seeks long-lasting solutions
      batonrougepost.com · English · tone -0.214592274678111 · 1 other outlets
  - (2026-11-22) [Russia oil sanctions perimeter · near] Incoming HPSCI Chairman Jim Himes Sends Threat Letter to DNI Clayton Surrounding Elon Musk's Starlink
      theconservativetreehouse.com · English · tone -0.539568345323741 · 1 other outlets
  - (2026-11-22) [Russia oil sanctions perimeter · near] Cumbrian aid team sends 26 pallets of sanitiser to Ukraine
      nwemail.co.uk · English · tone 7.21153846153846
  - (2026-11-22) [Russia oil sanctions perimeter · near] Letters to the Editor: Nov. 21, 2026
      pentictonherald.ca · English · tone -2.67260579064588

### World News (by country, top stories) — 98 new of 98 total
  - (2026-11-22) [Brazil] Town in southern Brazil left reeling by supercell storm
      spokesman.com · English · 6 other outlets ran this story
  - (2026-11-21) [Brazil] Brazil ex-President Jair Bolsonaro taken to ICU
      whbl.com · English · 3 other outlets ran this story
  - (2026-11-22) [Brazil] Flamengo claims ninth Brazilian Serie A title
      ianslive.in · English · 1 other outlets ran this story
  - (2026-11-22) [Brazil] São Paulo Sunday Guide: Museums on Paulista, 22 Nov
      riotimesonline.com · English
  - (2026-11-22) [Brazil] IAE Could Expand Engine Production if India Selects Brazil's C-390
      idrw.org · English
  - (2026-11-22) [Canada] Canada joins NATO Innovation Fund as 25th participating ally
      russiaherald.com · English · 8 other outlets ran this story

### State-Level News — 89 new of 429 total
  - (2026-11-21) [California] Thousands of mixed-status California families to lose housing under Trump HUD rule
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/112026-Housing-File-LA-PU-CM-04.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-11-21) [Alaska] Adoption Day 2026
      WHEREAS, Alaska’s children are our future, and all children deserve to experience the security and love of a stable home; and WHEREAS, in Alaska, as of October 2026 more than 2300 children are living in out-of-home care,…
  - (2026-11-22) [Florida] Midterm wins, near-misses could signal political change in the Deep South
      The midterms are over but Tennessee state Rep. Justin Pearson is back on the road, visiting churches and community centers across the congressional district he narrowly lost. He wants to thank voters who supported him. A…
  - (2026-11-21) [Arkansas] Military veterans to feds: no data centers on public lands
      Add military veterans to the growing force demanding a data center reckoning. A national coalition called Veterans for Public Lands is calling on federal powers to immediately pause data center development on public land…
  - (2026-11-21) [Arkansas] Veterans Day US House vote on contentious bill incenses vets
      WASHINGTON — Many military veterans are opposing a U.S. House-passed proposal to revamp retirement and disability benefits, saying it threatens future veterans’ compensation. The House passed two bills last week that add…
  - (2026-11-21) [Arkansas] A Thanksgiving treat in the offing: Lower gas prices
      WASHINGTON — $3.62 a gallon. That’s the predicted national average price of regular gasoline on Thanksgiving Day, according to GasBuddy, which tracks prices at the pump. That would continue the steady glide path down tha…

### Ukraine Theater (total-war monitoring) — 71 new of 273 total
  - (2026-11-22) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-21) [Liveuamap] Pro-government armed forces, including the… - Liveuamap
      Pro-government armed forces, including the… Liveuamap
  - (2026-11-19) [Liveuamap] Zelenskyy met with Macron… – Berlin, Berlin - Liveuamap
      Zelenskyy met with Macron… – Berlin, Berlin Liveuamap
  - (2026-11-18) [Liveuamap] At Pokrovsk direction… – Donetsk Oblast, Ukraine - Liveuamap
      At Pokrovsk direction… – Donetsk Oblast, Ukraine Liveuamap
  - (2026-11-18) [Liveuamap] Fire at the Ilysky refinery as result of drones strikes – Ilskiy, Krasnodar - Liveuamap
      Fire at the Ilysky refinery as result of drones strikes – Ilskiy, Krasnodar Liveuamap<
  - (2026-11-17) [Liveuamap] Russian Deputy Foreign… – Moskva, Moscow - Liveuamap
      Russian Deputy Foreign… – Moskva, Moscow Liveuamap

### State Legislative Action — 50 new of 68 total
  - (2026-11-21) [District of Columbia B 26-0480] Ensuring Access and Supporting Engagement (EASE) for DOC residents Act of 2025
      Ensuring Access and Supporting Engagement (EASE) for DOC residents Act of 2025
  - (2026-11-21) [District of Columbia B 26-0702] First Responders Facilities Modernization Act of 2026
      First Responders Facilities Modernization Act of 2026
  - (2026-11-21) [District of Columbia B 26-0757] Illegal Occupancy Enforcement Amendment Act of 2026
      Illegal Occupancy Enforcement Amendment Act of 2026
  - (2026-11-21) [District of Columbia B 26-0026] Theatrical Wrestling Regulation Amendment Act of 2025
      Theatrical Wrestling Regulation Amendment Act of 2025
  - (2026-11-21) [District of Columbia B 26-0753] Health and Human Service Programs and Benefits Eligibility and Delivery Data-Sharing Clarifications Amendment Act of 2026
      Health and Human Service Programs and Benefits Eligibility and Delivery Data-Sharing Clarifications Amendment Act of 2026
  - (2026-11-21) [District of Columbia B 26-0844] Nationals Park Financing Act of 2026
      Nationals Park Financing Act of 2026

### Ukrainian Internal News (national + local Kyiv) — 50 new of 120 total
  - (2026-11-22) НАТО збереться у Брюсселі через російські ракети у Польщі | LEDE: У штаб-квартирі НАТО обговорять порушення повітряного простору Польщі російськими ракетами та заходи для посилення захисту схід] (uk:…
      У штаб-квартирі НАТО обговорять порушення повітряного простору Польщі російськими ракетами та заходи для посилення захисту східного кордону.
  - (2026-11-22) У Хорватії тисячі людей протестували через смерть у психіатричній лікарні | LEDE: ] (uk: У Хорватії тисячі людей протестували через смерть у психіатричній лікарні)
  - (2026-11-22) Російські обстріли Донеччини та Херсонщини: 11 поранених | LEDE: Внаслідок атак РФ по Донецькій та Херсонській областях 21 листопада постраждали 11 осіб. Зруйновані житлові будинки, об'єкти соц] (uk:…
      Внаслідок атак РФ по Донецькій та Херсонській областях 21 листопада постраждали 11 осіб. Зруйновані житлові будинки, об'єкти соцсфери, газопровід.
  - (2026-11-22) Новий в.о. президента Сербії пропустить саміт ЄС-Західні Балкани | LEDE: ] (uk: Новий в.о. президента Сербії пропустить саміт ЄС-Західні Балкани)
  - (2026-11-22) Росія атакувала Україну 186 дронами: влучання зафіксували на 18 локаціях | LEDE: У ніч на 22 листопада російські війська атакували Україну 186 безпілотниками, з яких 72 були реактивними. Протип] (uk:…
      У ніч на 22 листопада російські війська атакували Україну 186 безпілотниками, з яких 72 були реактивними. Протиповітряна оборона збила або подавила 161 ворожий дрон.
  - (2026-11-22) Під завалами зруйнованої росіянами 5-поверхівки на Київщині можуть бути люди – ДСНС | LEDE: Рятувальники повідомили, що на Київщині шукають людей під завалами зруйнованого росіянами будинку.] (uk: Під…
      Рятувальники повідомили, що на Київщині шукають людей під завалами зруйнованого росіянами будинку.

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-11-22) [Australia] Fred Nile dies aged 92: why a Greens rival paid tribute | The Northern Daily Leader
      domain: northerndailyleader.com.au · language: English · tone: -0.853485064011379 · 114 other outlets ran this story
  - (2026-11-22) [United Kingdom] RAF's next jet 'perhaps last crewed fighter', says Air Chief Marshal
      domain: newsshopper.co.uk · language: English · tone: -0.647249190938512 · 79 other outlets ran this story
  - (2026-11-22) [Australia] Man found dead on Tasmanian island linked to shooting of officer | The Examiner
      domain: examiner.com.au · language: English · tone: -3.72250423011844 · 46 other outlets ran this story
  - (2026-11-22) [Mexico] Mexican forces capture FBI's most‑wanted cartel leader El Chapo Isidro in Sinaloa
      domain: kenya-today.com · language: English · tone: -6.42570281124498 · 42 other outlets ran this story
  - (2026-11-22) [Australia] Trio arrested, man killed in spate of city stabbings
      domain: batemansbaypost.com.au · language: English · tone: -7.46812386156649 · 39 other outlets ran this story
  - (2026-11-22) [Mexico] Evil Elon Musk Being Blamed for a Dead Turtle and Dolphin in Mexico
      domain: twitchy.com · language: English · tone: -6.22317596566524 · 33 other outlets ran this story

### GDACS — global disaster alerts — 32 new of 100 total
  - (2026-11-22) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.9M, Depth:5.573km
  - (2026-11-22) [Green] Earthquake in Peru
      Earthquake · Green alert · Peru · Magnitude 5M, Depth:108.134km
  - (2026-11-21) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.6M, Depth:31.078km
  - (2026-11-21) [Green] Earthquake in Argentina
      Earthquake · Green alert · Argentina · Magnitude 4.9M, Depth:209.784km
  - (2026-11-21) [Green] Earthquake in Japan
      Earthquake · Green alert · Japan · Magnitude 4.6M, Depth:65.465km
  - (2026-11-21) [Green] Earthquake in Panama
      Earthquake · Green alert · Panama · Magnitude 4.5M, Depth:10km

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 20 new of 60 total
  - (2026-11-24) Connecticut Supreme Court: State v. Sharpley
  - (2026-11-20) U.S. Court of Appeals, 7th Cir.: Juana Elizalde Castillo v. Todd W. Blanche
  - (2026-11-20) U.S. Court of Appeals, 7th Cir.: Christopher Rodgers v. Ron Neal
  - (2026-11-19) U.S. Court of Appeals, 7th Cir.: Tower Crossing Condominium Association v. Affiliated FM Insurance Company
  - (2026-11-19) U.S. Court of Appeals, 7th Cir.: United States v. Adel Daoud
  - (2026-11-19) U.S. Court of Appeals, 7th Cir.: United States v. Adel Daoud

### IT, InfoSys & cybersecurity news (last 7 days) — 19 new of 63 total
  - (2026-11-22) [The Hacker News] OpenRouter Drops 3 Providers After Researchers Catch Months of Prompt Theft at AI Hosting Firms
      Attackers stole data from inside three AI inference providers for months, and none of the three knew until researchers told them, the industrial cybersecurity company Dragos said this week. Some of the stolen requests we…
  - (2026-11-22) [The Hacker News] Researchers Demonstrate Ghostscript Sandbox-Escape RCE via Crafted File Uploads in Popular Apps
      A now-patched flaw in Ghostscript allows a crafted file to escape the program's security sandbox and run commands on the server that processes it. Ghostscript is the interpreter that many Linux servers use to convert upl…
  - (2026-11-21) [BleepingComputer] Rackspace Spot breach let hackers access customer Kubernetes secrets
      Rackspace warned customers that hackers breached its Rackspace Spot cloud platform using compromised credentials, allowing them to deploy unauthorized workloads and access Kubernetes secrets in customer clusters. [...]
  - (2026-11-21) [BleepingComputer] Microsoft Entra Connect Health flaw exploited to steal tenant data
      Microsoft is warning organizations that it suffered a data breach after attackers exploited a vulnerability in its Entra Connect Health service to gain unauthorized access to administrator email addresses and tenant conf…
  - (2026-11-21) [BleepingComputer] BADBOX botnet returns with record-breaking 40 billion daily ad requests
      The BADBOX malware found in a broad range of generic Android TV boxes has returned to large-scale ad-fraud operations following last year's disruptions. [...]
  - (2026-11-21) [BleepingComputer] FBI reportedly hacked again, this time targeting nationwide police database
      FBI systems have reportedly been breached for the second time in two months, this time targeting the agency's National Crime Information Center (NCIC), which is used to share information between local, state, and federal…

### Paper Trading Scorecard — 17 new of 71 total
  - (2026-11-22) [Polymarket] US announces end of Iranian blockade by December 15, 2026?
      On July 13, 2026, Trump announced the United States would reinstate its naval blockade of Iran, targeting Iranian ships and customers. This market will resolve to “Yes” if the United States government, or an authorized r…
  - (2026-11-22) [Polymarket] Will Lovable be acquired before 2027?
      This market will resolve to “Yes” if credible reporting confirms that any entity enters into an agreement to acquire the listed company by December 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to “No”. Merg…
  - (2026-11-22) [Manifold] Will Donald Trump comment on the Riemann hypothesis?
  - (2026-11-22) [Manifold] OpenAI IPOs in 2027 AND has a market cap of 1trillion or more at market close on IPO day?
  - (2026-11-22) [Manifold] Daily Coinflip
  - (2026-11-22) [Manifold] OpenAI IPOs on or before June 11 2027?

### Government & military aircraft airborne (OpenSky) — 17 new of 17 total
  - (2026-11-22) INDIA1 (India)
      icao24: 800440 · position: (28.5701, 77.1093) · alt: 167m · 251km/h
  - (2026-11-22) GAF146 (Germany)
      icao24: 3e8b02 · position: (45.5899, 0.4496) · alt: 9441m · 685km/h
  - (2026-11-22) NCR791 (United States)
      icao24: ab4ec6 · position: (34.0113, -98.7701) · alt: 11887m · 1003km/h
  - (2026-11-22) GAF739 (Germany)
      icao24: 3f59f3 · position: (52.2842, 13.2673) · alt: 2743m · 558km/h
  - (2026-11-22) JAF7LH (Belgium)
      icao24: 44d1a6 · position: (40.3897, -7.2393) · alt: 11887m · 747km/h
  - (2026-11-22) JAF1VB (Belgium)
      icao24: 44d1a7 · position: (36.7415, -4.3432) · alt: 2727m · 591km/h

### Wikidata leader-roster changes (48h) — 15 new of 42 total
  - (2026-11-22) [Jordan] Abdullah II of Jordan (Q57464) edited
      /* wbsetlabel-add:1|bn */ দ্বিতীয় আবদুল্লাহ, জর্ডানের রাজা, Bot: Adding Bengali label and aliases based on existing sitelinks.
  - (2026-11-22) [New Zealand] Christopher Luxon (Q74370310) edited
      /* wbcreateclaim-create:1| */ [[Property:P227]]: 131135607X, #temporary_batch_1795307474486
  - (2026-11-22) [Montenegro] Milojko Spajić (Q101225458) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73584|batch #73584]]: Import P106 from GND
  - (2026-11-21) [Belarus] Alexander Lukashenka (Q2866) edited
      /* wbsetaliases-remove:2|ru */ Президент Республики Белаурсь, Президент Беларуси
  - (2026-11-21) [Cape Verde] José Maria Neves (Q57649) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/73581|batch #73581]]: Import P106 from GND
  - (2026-11-21) [Germany] Frank-Walter Steinmeier (Q76658) edited
      /* wbeditentity-update:0| */ QuickStatements 3.0 [[:toollabs:qs-dev/batch/75027|batch #75027]]: redundant data added by Pinky_sl

### Campaign finance (FEC: top fundraisers + recent filings) — 13 new of 27 total
  - (2026-11-20) [F2] SCANLON, MARY GAY
      cycle 2026 · filing #2048741
  - (2026-11-20) [F3X] NY REPUBLICAN FEDERAL CAMPAIGN COMMITTEE
      cycle 2026 · filing #2048771 · receipts $0.42M
  - (2026-11-20) [F3X] TOWER LOAN PAC
      cycle 2026 · filing #2048766
  - (2026-11-20) [F1] GAI CONSULTANTS, INC. - POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #2048760
  - (2026-11-20) [F24] PEOPLE'S ACTION POWER
      cycle 2026 · filing #2048810
  - (2026-11-20) [F1] THE SCOTTS MIRACLE-GRO CO STEWARDSHIP PAC
      cycle 2026 · filing #2048719

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-11-22) Oklahoma State vs. Arizona State
      yes price: 100% · 24h volume: $2,409,025 · resolves 2026-11-22
  - (2026-11-22) Will FC Barcelona win on 2026-11-22?
      yes price: 84% · 24h volume: $585,012 · resolves 2026-11-22
  - (2026-11-22) Will Josh Hawley win the 2028 Republican presidential nomination?
      yes price: 2% · 24h volume: $379,089 · resolves 2028-11-08
  - (2026-11-22) Will the U.S. invade Iran before 2027?
      yes price: 6% · 24h volume: $273,835 · resolves 2027-01-01
  - (2026-11-22) Will "Mo Bamba" by Sheck Wes be on the radio in GTA VI at launch?
      yes price: 93% · 24h volume: $264,659 · resolves 2026-12-04
  - (2026-11-22) Spread: Villarreal CF (-1.5)
      yes price: 1% · 24h volume: $180,392 · resolves 2026-11-22

### USGS earthquakes (M4.5+, past day) — 10 new of 10 total
  - (2026-11-21) M 6.8 - 105 km NE of Lospalos, Timor Leste
      M6.8 · 105 km NE of Lospalos, Timor Leste · depth 132.055 km
  - (2026-11-21) M 5.9 - 238 km SW of Yanglong, China
      M5.9 · 238 km SW of Yanglong, China · depth 10 km · PAGER yellow
  - (2026-11-21) M 5.2 - 112 km SSE of Tateyama, Japan
      M5.2 · 112 km SSE of Tateyama, Japan · depth 10 km
  - (2026-11-22) M 5.0 - 15 km NNE of Carhuamayo, Peru
      M5.0 · 15 km NNE of Carhuamayo, Peru · depth 108.134 km
  - (2026-11-22) M 4.9 - 246 km ESE of Sarangani, Philippines
      M4.9 · 246 km ESE of Sarangani, Philippines · depth 5.573 km
  - (2026-11-21) M 4.9 - 88 km WNW of El Aguilar, Argentina
      M4.9 · 88 km WNW of El Aguilar, Argentina · depth 209.784 km

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 102 total
  - (2026-11-21) [OFAC] Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMi-gJBVV95cUxQdHZLb0JLOEptMm8wbTFBYTVJLUJDSTRoUTl3dGxraTJ5c0lYWGdsY2RCUk5sQWlnNE40YjZwdmg2eEtqbUowU2JZd0JTVWR6Q1JjTWhlMVRyZ1hXVklwUVJwdkJCQUk3V3hZaC1ybjl2VV9iUjFwc01hZWVVX0…
  - (2026-11-22) [USASpending] $22,674,757,233 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration. Description: INTERNATIONAL SPACE STATION
  - (2026-11-22) [USASpending] $3,229,285,063 → SPACE EXPLORATION TECHNOLOGIES CORP.: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST
      Agency: National Aeronautics and Space Administration. Description: WORK REQUIRED FOR THE DESIGN, DEVELOPMENT, MANUFACTURE, TEST, LAUNCH, DEMONSTRATION, AND ENGINEERING SUPPORT OF THE HUMAN LANDING SYSTEM (HLS) INTEGRATE…
  - (2026-11-22) [USASpending] $1,225,912,520 → MAGELLAN FEDERAL, INC.: MILITARY AND FAMILY LIFE COUNSELING. REQUIREMENT FOR WORLDWI
      Agency: General Services Administration. Description: MILITARY AND FAMILY LIFE COUNSELING. REQUIREMENT FOR WORLDWIDE NON MEDICAL CONFIDENTIAL COUNSELING SERVICES.
  - (2026-11-22) [USASpending] $983,105,739 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-11-22) [USASpending] $817,361,024 → SYNCOM SPACE SERVICES LLC: IGF::OT::IGF SYNERGY-ACHIEVING CONSOLIDATED OPERATIONS AND M
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF SYNERGY-ACHIEVING CONSOLIDATED OPERATIONS AND MAINTENANCE, COST PLUS INCENTIVE FEE - INDEFINITE DELIVERY INDEFINITE QUANTITY

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 34 total
  - (2026-11-22) MOVER ▲ Mukesh Ambani — $96.10B (+$0.64B since yesterday)
      India · Diversified · source: Diversified
  - (2026-11-22) MOVER ▲ Gautam Adani — $85.95B (+$0.57B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-11-22) MOVER ▲ Tadashi Yanai & family — $70.12B (+$0.47B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-11-22) MOVER ▼ Carlos Slim Helu & family — $122.88B ($-0.08B since yesterday)
      Mexico · Telecom · source: Telecom

### Commentary & analysis (last 7 days) — 3 new of 3 total
  - (2026-11-22) [Marginal Revolution] Will AI Growth Reach the Developing World?
      Here is the abstract from a new NBER paper by Daniel Björkegren, David Lagakos & Mitchell VanVuren: This paper explores how economic growth driven by AI will impact the developing world. Our analysis is based on a growth…
  - (2026-11-21) [Marginal Revolution] Saturday assorted links
      1. Many federal agencies are hiring economists. 2. Theodore Zeldin, RIP. 3. Henry Oliver on Paradise Lost. 4. Quantum computing even weirder than you think? (NYT) And an article bullish on quantum computing (NYT). 5. Goo…
  - (2026-11-21) [Marginal Revolution] A simple observation
      The Riemann proof seems like a true surprise. Yet on the same day Anthropic shares fell about ten percent. In other words, the market feels that “capabilities” do not necessarily translate into significant social and eco…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-22) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=17, 7d-median=17, 14d-median=21; carrying terms: directives, certain, published, update, airplanes, provide, airworthiness, applicable, safety, standards, national, proposed
- state_bills: today=68, 7d-median=73, 14d-median=76; carrying terms: state, relating, public, health, local, business, including, practice, insurance, general, authority, development
- state_news: today=429, 7d-median=711, 14d-median=711; carrying terms: years, house, wyofile, according, history, latest, university, table, economic, court, members, voted
- local_news: today=210, 7d-median=250, 14d-median=252; carrying terms: years, house, found, court, weekend, woman, thanksgiving, school, https, families, authorities, residents
- foreign_news: today=961, 7d-median=1012, 14d-median=997; carrying terms: market, vnecdn, timesofisrael, attempt, years, flags, others, according, price, styles, zeitung, river
- chinese_internal: today=271, 7d-median=315, 14d-median=319; carrying terms: market, cbmiakfvx, https, cbmib, cbmic, cbmixkfvx, cbmiykfvx, lxtfb, cbmibkfvx, articles, cbmigwfbvv, cbmiyefvx
- russian_internal: today=780, 7d-median=947, 14d-median=947; carrying terms: istories, forbidden, gazeta, axios, found, street, server, journal, starlink, error, client, europe
- ukrainian_internal: today=120, 7d-median=127, 14d-median=132; carrying terms: years, dnipro, according, latest, found, targeting, court, country, error, odesa, zelensky, ceasefire
- ukraine_theater: today=273, 7d-median=277, 14d-median=272; carrying terms: hrzjv, cbmitwfbvv, years, lnynjon, lbujuoelnsnc, rlbznvhjylzha, memorandum, cuxnd, lwgwrlrpwtn, uljsytlcsef, facility, jvjctwtvftffkynffc
- paper_bets: today=71, 7d-median=77, 14d-median=75; carrying terms: market, solved, drought, earthquake, december, state, supervolcano, labor, erupt, prize, human, visit
- weather: today=125, 7d-median=127, 14d-median=130; carrying terms: north, today, waves, above, counties, afdsew, areas, monitoring, river, afdphi, northern, portions
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: jolts, supply, funds, indicator, openings, cpilfesl, labor, dexuseu, sheet, personal, rates, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, yield, china, close, crypto, futures, russell, silver, range, rates, corporate, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=102, 7d-median=100, 14d-median=100; carrying terms: satisfying, moldova, activities, annexation, areas, systems, tiananmen, integrity, description, economic, weapons, campaign
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, congresstrading, client, quiver, quiverquant, https, httperror, error, quantitative
- billionaires: today=34, 7d-median=40, 14d-median=34; carrying terms: telecom, japan, arnault, yiming, france, zhong, technology, carlos, adani, source, berkshire, microsoft
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, appeals, people, martin, court, supreme, blanche, company, miller, charles, colorado, insurance
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, holdings, william, management, capital, technologies, brian, james, scott
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, sherrod, raised, cycle, abdul, alexandria, cooper, filing, booker, david, sayed, krishnamoorthi
- gdelt_regions: today=98, 7d-median=103, 14d-median=100; carrying terms: english, trump, korea, japan, south, germany, turkey, minister, china, german, italian, indiatimes
- gdelt_gkg: today=104, 7d-median=132, 14d-median=118; carrying terms: english, keywords, russian, israel, hezbollah, sanctions, trump, netanyahu, years, north, russia, security
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: trump, english, australia, murder, killed, police, domain, shooting, language, crash, injured, county
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=17, 7d-median=19, 14d-median=22; carrying terms: position, belgium, germany, kingdom, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: genetic, formula, disembarked, britain, avian, mosquitoes, december, state, north, cameroon, cases, faster
- cisa_kev: today=21, 7d-median=18, 14d-median=15; carrying terms: missing, multiple, vulnerability, vendor, critical, cisco, remediation, value, authentication, check, improper, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=42, 7d-median=46, 14d-median=46; carrying terms: quickstatements, wbsetdescription, wbsetsitelink, edited, update, toollabs, property, wbeditentity, republic, wbsetclaim, congo, batch
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: impact, earthquake, republic, sudan, depth, forestfire, magnitude, central, australia, indonesia, forest, alert
- usgs_quakes: today=10, 7d-median=12, 14d-median=14; carrying terms: depth, indonesia, japan, philippines, china, argentina
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, price, volume, december, donetsk, presidential, championship, league, champions, shakhtar, november, change
- commentary: today=3, 7d-median=5, 14d-median=6; carrying terms: revolution, marginal, https, economic, marginalrevolution, links, world, growth, assorted, policy, paper, think
- tech_news: today=63, 7d-median=63, 14d-median=63; carrying terms: years, today, computer, according, systems, techcrunch, security, technica, technology, target, hackers, https
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: kansas, markey, janelle, emilia, yvette, labor, quigley, sykes, eugene, house, watson, securities
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: market, markets, placed, placement, sufficient, either, today, consensus, paper, converges, identify, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-11-10] ECB press: Philip R. Lane: The science and practice of monetary policy communication: the ECB experience
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of United Community Bank
- [2026-11-12] Fed press (events + announcements): Federal Reserve announces revised tentative schedule of Federal Open Market Committee meetings in 2027
- [2026-11-12] Fed press (events + announcements): Federal Reserve Board announces pricing, effective January 1, 2027, for payment services the Federal Reserve Banks provide to banks and credit unions, and changes to streamline and adjust their check services
- [2026-11-13] ECB press: Isabel Schnabel: Made in Europe
- [2026-11-13] Fed press (events + announcements): Agencies extend comment period for proposed third-party risk management guidance
- [2026-11-14] Fed speeches: Jefferson, New Technology, Old Questions: Productivity Puzzles  and the Macroeconomy
- [2026-11-16] ECB press: Boris Vujčić: Risks and resilience in the euro area financial system
- [2026-11-16] Fed speeches: Barr, Some Potential Financial Stability Implications of Artificial Intelligence
- [2026-11-16] ECB press: Frank Elderson: Smart supervision for small banks
- [2026-11-16] Fed speeches: Warsh, Opening Remarks
- [2026-11-17] Fed speeches: Waller, Considerations at the Intersection of Payments and Tokenized Markets
- [2026-11-17] ECB press: Philip R. Lane: The practice and science of monetary policy communication: the ECB experience
- [2026-11-18] ECB press: Boris Vujčić: Financial Stability Review - November 2026
- [2026-11-18] ECB press: Risks from AI valuations, fiscal imbalances and geoeconomic tensions weigh on financial stability outlook
- [2026-11-18] Fed speeches: Barr, Investing in America’s Underserved Communities
- [2026-11-18] Fed press (events + announcements): Minutes of the Federal Open Market Committee, October 27-28, 2026
- [2026-11-19] Fed speeches: Jefferson, Monetary Policy amid Frequent and Complex Shocks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*