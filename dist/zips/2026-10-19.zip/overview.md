# WORLDSCOPE morning brief — 2026-10-19

## Headline
2980 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (799) · Russian Internal News (state + in-exile) (694) · World leaders & government officials (324) · Chinese Internal News (240) · State-Level News (166) · Local News: St. Louis + Atlanta (132) · U.S. Weather + Severe / Climate Outlooks (126) · Ukraine Theater (total-war monitoring) (100) · Ukrainian Internal News (national + local Kyiv) (66) · GDACS — global disaster alerts (60) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 799 new of 957 total
  - (2026-10-19) [Global] Third Ebola case in Kenya highlights US failures amid Trump cuts to key services
  - (2026-10-19) [Global] Hurricane Trudy menaces Mexico’s Pacific coast and Greece hit by deadly floods
  - (2026-10-19) [Global] ‘This is not poker’: Alberta goes to polls in referendum that has exposed divisions, not least among separatists
  - (2026-10-18) [Global] Four people killed in ‘violent, fast-moving’ fire at Canadian military base
  - (2026-10-19) [Global] China’s economy grows faster than forecast after AI boom boosts exports
  - (2026-10-19) [Global] Three deaths from float crushes raise safety concerns over Japanese festivals

### Russian Internal News (state + in-exile) — 694 new of 886 total
  - (2026-10-19) Россия активно бьет по заводам и мостам в Украине — выдержит ли украинская экономика? Анализ Carnegie Politika | LEDE: Украина наносит заметные удары по России: сперва по Wildberries и НПЗ, ] (ru: Рос…
      Украина наносит заметные удары по России: сперва по Wildberries и НПЗ, затем — по дата-центрам. Кроме того, вчера была самая масштабная за время войны атака ВСУ на Санкт-Петербург. Россия действует не менее опасно. Ее уд…
  - (2026-10-19) Уполномоченный Верховной рады по правам человека: Россия и Украина обсуждают эвакуацию жителей Алешек | LEDE: Уполномоченный Верховной рады по правам человека Дмитрий Лубинец сообщил, что Ро] (ru: Упо…
      Уполномоченный Верховной рады по правам человека Дмитрий Лубинец сообщил, что Россия и Украина «приступили к согласованию последних деталей» эвакуации жителей города Алешки (украинское название — Олешки) в оккупированной…
  - (2026-10-19) Z-блогер Татьяна Монтян получила полтора года колонии — из-за слов об «охраноте», которую надо «мочить безо всякого сожаления» | LEDE: Ворошиловский межрайонный суд в аннексированном Донецке] (ru: Z-б…
      Ворошиловский межрайонный суд в аннексированном Донецке приговорил военного блогера и колумнистку RT Татьяну Монтян к полутора годам колонии по делу о призывах к «экстремизму», пишет «Медиазона».
  - (2026-10-19) Война. 1699-й день. Трамп: Зеленский не хочет завершать войну. Зеленский: Трамп хочет, чтобы Украина поддалась и капитулировала | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-19) Сын Евгения Пригожина сохранил и расширил бизнес ЧВК Вагнера в Центральноафриканской Республике. Торговля золотом, оружием и наркотиками приносит его семье более 400 миллионов долларов в год, у] (ru:…
      После гибели Евгения Пригожина российские власти взяли под контроль ЧВК Вагнера и создали «Африканский корпус» Минобороны, под контроль которого должны были перейти наемники ЧВК в африканском регионе. Однако, как пишет T…
  - (2026-10-19) В Париже закрылся Лувр (прямо в годовщину его ограбления). Вход в музей заблокировали протестующие студенты | LEDE: Администрация Лувра объявила, что из-за студенческих протестов музей закры] (ru: В П…
      Администрация Лувра объявила, что из-за студенческих протестов музей закрыт.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 240 new of 270 total
  - (2026-10-19) 硬科技早报|首个全国产十万卡集群亮相；9部门称加快推进科技兴商 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1xaHpLRnBQem5hS3FZc3lNdFl0bDZDRTRJSzZoMjQwVUswd0M3eGJYRVJUVndCRlJ5dkJIaXpEUThVVWxaeHFp] (zh:…
      硬科技早报|首个全国产十万卡集群亮相；9部门称加快推进科技兴商 观察者网
  - (2026-10-19) 触发对日本的“敌国条款” ， 需要联合国的共识吗？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFA3REMzUGVuTVUyWktBblNEb1ZEcFQxMU1PR25HSlFoQ3NPOVNiY3JlY3FNS3lVZzBSVDlsU0NITE1xN0Y4SXI3azBtWm1Z] (zh:…
      触发对日本的“敌国条款” ， 需要联合国的共识吗？ 风闻
  - (2026-10-19) 这么粗浅的道理也配拿诺奖？ - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE90Qk9WR1ZYTnBFaWR3aUpjZ0dHa0pOZU9KYkx0LVFBd3Z4UV9CWkhyNm56U1FLYzZMWE81Ry1oMWpfZmtld2t6UmVmSmpXUnVvMU5NMT] (zh:…
      这么粗浅的道理也配拿诺奖？ 观察者网
  - (2026-10-18) 一路丰碑｜铁索寒光里，迸发一往无前勇气 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1WVTVmQW1RNmRvTjFNaHVqNElLYmdpUFpFOHdCckF5Zi1RZFhZVFJ2OGpvT0VmODFNTXZzUTlTRVBRd0tVQjlEaUhHdWRFTl8z] (zh:…
      一路丰碑｜铁索寒光里，迸发一往无前勇气 观察者网
  - (2026-10-19) 泽连斯基：特朗普正逼迫乌克兰投降 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTFA3OGMzMjZDWEN6UUYxTHJvNnlWclc2LWFkZjhGdHpLSnlmWTVnMW5rUk5GZFZDeGNDdW0zTDVleHYyeGNwY1k2VHhRdURpRFpDQWV] (zh:…
      泽连斯基：特朗普正逼迫乌克兰投降 观察者网
  - (2026-10-19) 估值40亿美元冲刺美股上市，非洲支付宝靠借贷跨过盈亏线 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5SMlBISDRWNzNpSWdXSjhIZnpXV1F1eExpdmJobHd3aXpUSDVMZEU3T2FyalBfQ2tKM3pxUEsxMGwtMXdCaUhqY2pO] (zh:…
      估值40亿美元冲刺美股上市，非洲支付宝靠借贷跨过盈亏线 观察者网

### State-Level News — 166 new of 315 total
  - (2026-10-19) [California] Don’t judge California voters for this election question
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/06/040324-CA-Supreme-Court-CASC-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-10-19) [California] ‘Put them down with gas’: Abuse and retaliation inside a California women’s prison
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/10/CCWF_BL_KQED_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="The back…
  - (2026-10-19) [California] CARE Court can profoundly change lives, and California’s justice system, if given the chance
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/12/120125_CARECourt_FM_38.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="Si…
  - (2026-10-19) [Delaware] Delaware immigrant parents face uncertainty amid ongoing deportations
      <img width="1024" height="683" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/10/50044960247_9bfe5be886_o-scaled-1.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-p…
  - (2026-10-19) [Delaware] Get Involved: Hospital costs, Harrington data center ban, solar in Sussex, more
      <img width="1000" height="800" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/10/1-3.png?fit=1000%2C800&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="as…
  - (2026-10-19) [Delaware] Dayesla Ixtli uses a living canvas to revive, reinterpret mythic women
      <img width="1024" height="682" src="https://i0.wp.com/spotlightdelaware.org/wp-content/uploads/2026/10/Monarch-2.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decodi…

### Local News: St. Louis + Atlanta — 132 new of 194 total
  - (2026-10-19) [St. Louis] Lou’s Clues – 10/19/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-10-19) [St. Louis] How Missouri could hold corporate landlords accountable
      Big news is coming today for two out-of-state landlords with significant St. Louis holdings. Troubled Benton Park property Senate Square is up for auction on the courthouse steps. Today is also the deadline St. Louis Cou…
  - (2026-10-19) [St. Louis] Two St. Louis entrepreneurs bought a countertop business—and found another one in the process
      In the depths of the pandemic Audrey and Ryan Brown remember feeling the weight of a future that seemed like it was only becoming more uncertain. Like many families, the couple was worried about whether opportunities wou…
  - (2026-10-19) [St. Louis] More than 1.5M pounds of meat and poultry recalled due to 'possible temperature abuse'
      Kayem Foods Inc. has recalled more than 1.5 million pounds of ready-to-eat meat and poultry products. Here's what consumers should look for.
  - (2026-10-19) [St. Louis] Amelia Earhart expedition crew finds 'no conclusive evidence' during search for plane wreckage
      A group searching for Amelia Earhart's plane said what was originally thought to be plane wreckage on a remote island was likely a collection of large trees.
  - (2026-10-19) [St. Louis] Air Force identifies service member who fell to his death rappelling at college football game
      The man who fell while rappelling from the roof of the San Antonio Alamodome during a pregame ceremony has been identified as a career Air Force instructor.

### U.S. Weather + Severe / Climate Outlooks — 126 new of 128 total
  - (2026-10-19) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-19) [Moderate] Gale Warning: Gale Warning issued October 19 at 9:11AM EDT until October 20 at 11:00AM EDT by NWS Baltimore MD/Washington DC
      * WHAT...For the Small Craft Advisory, north winds 15 to 20 kt with gusts up to 30 kt. For the Gale Warning, north winds 15 to 25 kt with gusts up to 35 kt and waves 2 to 4 ft expected. * WHERE...Chesapeake Bay from Drum…
  - (2026-10-19) [Moderate] Wind Advisory: Wind Advisory issued October 19 at 5:03AM AKDT until October 19 at 10:00PM AKDT by NWS Fairbanks AK
      * WHAT...South winds 30 to 45 mph with gusts up to 65 mph. * WHERE...Eastern Alaska Range North of Trims Camp. * WHEN...Until 10 PM AKDT this evening. * IMPACTS...Gusty winds could blow around unsecured objects and make…
  - (2026-10-19) [Moderate] Gale Warning: Gale Warning issued October 19 at 4:22AM AKDT until October 20 at 7:00PM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, southeast winds 25 to 35 kt with gusts up to 45 kt and seas 12 to 17 ft expected. For the Gale Warning, south winds 25 to 35 kt with gusts up to 45 kt and seas 15 to 20 ft exp…
  - (2026-10-19) [Moderate] Gale Warning: Gale Warning issued October 19 at 4:22AM AKDT until October 20 at 10:00PM AKDT by NWS Juneau AK
      * WHAT...For the Gale Warning, southeast winds 35 to 45 kt with gusts up to 55 kt and seas 20 to 25 ft expected. For the Small Craft Advisory, south winds 15 to 25 kt and seas 18 to 23 ft expected. * WHERE...Icy Cape to…
  - (2026-10-19) [Moderate] Gale Warning: Gale Warning issued October 19 at 4:22AM AKDT until October 20 at 7:00PM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, southeast winds 25 to 35 kt with gusts up to 40 kt and seas 7 to 12 ft expected. For the Gale Warning, southeast winds 25 to 35 kt with gusts up to 40 kt and seas 9 to 14 ft e…

### Ukraine Theater (total-war monitoring) — 100 new of 413 total
  - (2026-10-19) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-10-18) [FIRMS] thermal anomaly 44.201, 22.977 (FRP 9.13 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-18 1142Z, FRP 9.13 MW
  - (2026-10-18) [FIRMS] thermal anomaly 44.204, 22.971 (FRP 4.96 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-18 1142Z, FRP 4.96 MW
  - (2026-10-18) [FIRMS] thermal anomaly 44.240, 22.799 (FRP 5.6 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-18 1142Z, FRP 5.6 MW
  - (2026-10-18) [FIRMS] thermal anomaly 44.240, 22.794 (FRP 10.06 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-18 1142Z, FRP 10.06 MW
  - (2026-10-18) [FIRMS] thermal anomaly 44.243, 22.793 (FRP 10.06 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-18 1142Z, FRP 10.06 MW

### Ukrainian Internal News (national + local Kyiv) — 66 new of 136 total
  - (2026-10-19) Комендантська година майже по всій Донеччині триватиме 19 годин на добу – ОВА | LEDE: З 1 листопада на всій території Донеччини, окрім Олександрівської та Черкаської громад, діятиме довга комен] (uk:…
      З 1 листопада на всій території Донеччини, окрім Олександрівської та Черкаської громад, діятиме довга комендантська година: з 16:00 до 11:00.
  - (2026-10-19) Сили оборони уразили російську РЛС на Брянщині та склади боєприпасів на Донеччині | LEDE: Сили оборони України 18 жовтня та в ніч на 19 жовтня уразили радіолокаційну станцію в Брянській області] (uk:…
      Сили оборони України 18 жовтня та в ніч на 19 жовтня уразили радіолокаційну станцію в Брянській області Росії, а також склади, позиції та місця зосередження російських військових на окупованих територіях України.
  - (2026-10-19) Корецький про перегляд бронювання: Генштаб потребує військових, а кількість відстрочок зростає | LEDE: Прем'єр-міністр Сергій Корецький пояснив намір уряду переглянути правила бронювання потреб] (uk:…
      Прем'єр-міністр Сергій Корецький пояснив намір уряду переглянути правила бронювання потребою Генштабу у військових та стрімким зростанням кількості бронювань і відстрочок від мобілізації.
  - (2026-10-19) Єврокомісія: До кінця 2026 Україна може отримати 30 млрд євро за умови реформ | LEDE: До кінця поточного року Київ може отримати від Європейського Союзу близько 30 млрд євро, якщо продовжить зд] (uk:…
      До кінця поточного року Київ може отримати від Європейського Союзу близько 30 млрд євро, якщо продовжить здійснювати відповідні реформи.
  - (2026-10-19) Росія вдарила по Кривому Рогу: двоє загиблих, семеро поранених | LEDE: Російські війська атакували промислове підприємство в Покровському районі Кривого Рогу, внаслідок чого загинули двоє чолов] (uk:…
      Російські війська атакували промислове підприємство в Покровському районі Кривого Рогу, внаслідок чого загинули двоє чоловіків, ще семеро людей дістали поранення, серед них – 15-річний хлопець.
  - (2026-10-19) КМВА: Час відновлення роботи станції метро "Чернігівська" наразі невідомий | LEDE: Фахівці оцінюють ступінь пошкоджень станції столичного метро "Чернігівська" внаслідок російської атаки 19 жовт] (uk:…
      Фахівці оцінюють ступінь пошкоджень станції столичного метро "Чернігівська" внаслідок російської атаки 19 жовтня; прогнозувати відновлення роботи наразі неможливо.

### GDACS — global disaster alerts — 60 new of 100 total
  - (2026-10-19) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.8M, Depth:10km
  - (2026-10-19) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 4.8M, Depth:10km
  - (2026-10-19) [Green] Earthquake in China
      Earthquake · Green alert · China · Magnitude 5M, Depth:10km
  - (2026-10-19) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 5.4M, Depth:10km
  - (2026-10-19) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.7M, Depth:10km
  - (2026-10-19) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 4.9M, Depth:10km

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-19) 424B3 - HSBC USA INC /MD/ (0000083246) (Filer)
      filed 2026-10-19 13:16 UTC — Filed: 2026-10-19 AccNo: 0001104659-26-116759 Size: 1 MB
  - (2026-10-19) [Snyder Mark S] Form 4 (Reporting)
      filed 2026-10-19 13:16 UTC · role: Reporting — Filed: 2026-10-19 AccNo: 0000108985-26-000089 Size: 4 KB
  - (2026-10-19) [YORK WATER CO] Form 4 (Issuer)
      filed 2026-10-19 13:16 UTC · role: Issuer — Filed: 2026-10-19 AccNo: 0000108985-26-000089 Size: 4 KB
  - (2026-10-19) 497 - HARTFORD MUTUAL FUNDS, INC (0001006415) (Filer)
      filed 2026-10-19 13:15 UTC — Filed: 2026-10-19 AccNo: 0001193125-26-424749 Size: 62 KB
  - (2026-10-19) 497 - HARTFORD MUTUAL FUNDS II, INC (0000049905) (Filer)
      filed 2026-10-19 13:15 UTC — Filed: 2026-10-19 AccNo: 0001193125-26-424749 Size: 62 KB
  - (2026-10-19) 497 - HARTFORD MUTUAL FUNDS, INC (0001006415) (Filer)
      filed 2026-10-19 13:14 UTC — Filed: 2026-10-19 AccNo: 0001193125-26-424748 Size: 19 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-10-19) [Syria] Maritime organization chief looks forward to deepening cooperation with China
      domain: middleeaststar.com · language: English · tone:
  - (2026-10-19) [United States] Rubio says there was no US pause in intelligence sharing with Ukraine - Dominican Republic Post – Caribbean News , Business , Travel & Culture
      domain: dominicanrepublicpost.com · language: English · tone:
  - (2026-10-19) [Australia] A pregnant mom let her 5 - year - old stay outside to collect goose feathers – and was placed on the child abuse and neglect registry
      domain: theconversation.com · language: English · tone:
  - (2026-10-19) [United States] Single fatal crash destroys vehicle on S . Union Road - WHIO TV 7 and WHIO Radio
      domain: whio.com · language: English · tone:
  - (2026-10-19) [United States] Daedalus : Greece unveils new supercomputer as it eyes role in Europe AI race
      domain: euronews.com · language: English · tone:
  - (2026-10-19) [United States] In the news today : four soldiers killed , Alberta referendum , AI privacy fears
      domain: lethbridgeherald.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 31 new of 58 total
  - (2026-10-19) [BleepingComputer] Microsoft fixes classic Outlook bug that hid Copilot buttons
      Microsoft has fixed a known issue that removed the Copilot Chat and Copilot buttons in the classic Outlook desktop mail client for some Windows users. [...]
  - (2026-10-19) [BleepingComputer] Microsoft: October Windows Server updates break Exchange sign-in, mail flow
      Microsoft has confirmed that this month's Windows Server security updates are causing OWA sign-in and mail delivery issues on some Exchange Server systems. [...]
  - (2026-10-19) [The Hacker News] Fake Web3 Accelerator Uses npm Packages to Spread Malware and Hijack AI Agent Traffic
      A fake Web3 accelerator has been observed pushing information stealers and backdoors to Windows and macOS systems using malicious npm packages under the pretext of offering free artificial intelligence (AI) credits for A…
  - (2026-10-19) [The Hacker News] Unpatched Broadcom Wi-Fi Flaw Lets Attackers in Range Run Code as Root on Routers
      A flaw in Broadcom's Wi-Fi setup software lets an attacker within radio range run code as root on Broadcom-based routers, without the network password or any pairing step, security researcher Quentin Kaiser disclosed on…
  - (2026-10-19) [The Hacker News] OpenCode Console Breach May Have Exposed OpenAI, Anthropic, and Google API Keys
      An intruder reached a legacy system at OpenCode on the night of October 16 and may have exposed the third-party AI provider keys that users had saved in OpenCode Console, the company said. Console is OpenCode's optional…
  - (2026-10-19) [The Record] Hackers steal customer data from major Russian hosting provider FirstVDS
      Hackers have stolen passwords, access credentials and other sensitive data belonging to customers of Russian hosting provider FirstVDS after exploiting a vulnerability in software used to manage its servers.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-10-19) JAF4KN (Bulgaria)
      icao24: 4520ce · position: (34.5951, -7.7663) · alt: 9182m · 823km/h
  - (2026-10-19) JEDI66 (United States)
      icao24: ae1eac · position: (30.2246, -88.5138) · alt: 1653m · 374km/h
  - (2026-10-19) PAT200 (United States)
      icao24: adfdd1 · position: (36.5851, -76.7721) · alt: 7924m · 468km/h
  - (2026-10-19) SAMU691 (France)
      icao24: 39c994 · position: (45.7079, 4.7997) · alt: 381m · 130km/h
  - (2026-10-19) PAT04 (United States)
      icao24: ae51a9 · position: (39.2531, -77.1662) · alt: 601m · 207km/h
  - (2026-10-19) KAF3207 (Kuwait)
      icao24: 706216 · position: (50.9278, -0.2687) · alt: 9448m · 718km/h

### USGS earthquakes (M4.5+, past day) — 25 new of 25 total
  - (2026-10-19) M 6.0 - 186 km NW of Port-Olry, Vanuatu
      M6.0 · 186 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-19) M 5.4 - 196 km NW of Port-Olry, Vanuatu
      M5.4 · 196 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-19) M 5.4 - 184 km WNW of Port-Olry, Vanuatu
      M5.4 · 184 km WNW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-19) M 5.3 - 188 km NW of Port-Olry, Vanuatu
      M5.3 · 188 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-19) M 5.2 - 211 km WNW of Port-Olry, Vanuatu
      M5.2 · 211 km WNW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-18) M 5.2 - 71 km ESE of ‘Ohonua, Tonga
      M5.2 · 71 km ESE of ‘Ohonua, Tonga · depth 10 km

### Court opinions of consequence (federal & state) — 18 new of 60 total
  - (2026-10-16) Alaska Supreme Court: King v. Carty
  - (2026-10-14) U.S. Court of Appeals, 3rd Cir.: Sofiqul Islam v. Attorney General United States of America
  - (2026-10-14) U.S. Court of Appeals, 7th Cir.: United States v. Andre Neal-Ford
  - (2026-10-14) U.S. Court of Appeals, 7th Cir.: United States v. Andre Neal-Ford
  - (2026-10-14) U.S. Court of Appeals, 7th Cir.: United States v. Eugene Haywood
  - (2026-10-14) U.S. Court of Appeals, 7th Cir.: United States v. Eugene Haywood

### World News (by country, top stories) — 18 new of 18 total
  - (2026-10-19) [Japan] Google Gemini 4 Agents Just Beat Minecraft With No Human Intervention
      engadget.com · English
  - (2026-10-19) [Japan] Even Realities G2 Review : Smart Glasses , Stupid Controls
      engadget.com · English
  - (2026-10-19) [Japan] Samson Studio Liquid Swords Has Gone Bankrupt
      gamingbolt.com · English
  - (2026-10-19) [Japan] Fatal Fury City Of The Wolves Ver 3 . 3 . 2 Tokyo Revengers And Switch 2
      gamerheadlines.com · English
  - (2026-10-19) [Japan] It Was So All Over The Place - Ex - Capcom Manager Discusses Resident Evil 7 Tumultuous Development
      nintendolife.com · English
  - (2026-10-19) [Japan] From smart sensors to AI robots , technology transforming China elderly care
      japanherald.com · English

### Paper Trading Scorecard — 15 new of 66 total
  - (2026-10-19) [Manifold] Will Mike Johnson be Speaker of the House following the Midterms?
  - (2026-10-19) [Manifold] Daily Coinflip
  - (2026-10-19) [Manifold] Will 0xDe89112492A292c194D2501b2721D4Bc6cED2A75 RECEIVE more than 100.00 USDC Base by October 25th 11:59 pm UTC
  - (2026-10-19) [Manifold] Will Charles III remain the king for all of 2027?
  - (2026-10-19) [Manifold] Will Donald Trump make an endorsement or comment on the NZ election before polls close?
  - (2026-10-19) [Manifold] Will a major-party U.S. presidential candidate deploy an AI clone to talk to voters before the 2028 election?

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-10-19) Will the Fed decrease interest rates by 50+ bps after the October 2026 meeting?
      yes price: 0% · 24h volume: $1,284,307 · resolves 2026-10-29
  - (2026-10-19) Will the Fed decrease interest rates by 25 bps after the October 2026 meeting?
      yes price: 0% · 24h volume: $835,633 · resolves 2026-10-29
  - (2026-10-19) Will the Fed increase interest rates by 25 bps after the October 2026 meeting?
      yes price: 14% · 24h volume: $722,143 · resolves 2026-10-29
  - (2026-10-19) Will there be no change in Fed interest rates after the October 2026 meeting?
      yes price: 86% · 24h volume: $716,660 · resolves 2026-10-29
  - (2026-10-19) European Open: Yannick Hanfmann vs Martin Damm
      yes price: 0% · 24h volume: $499,451 · resolves 2026-10-26
  - (2026-10-19) Japan Women's Open: Katie Boulter vs Himeno Sakatsume
      yes price: 94% · 24h volume: $366,104 · resolves 2026-10-26

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 104 total
  - (2026-10-19) [USASpending] $2,753,683,081 → THE BOEING COMPANY: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CO
      Agency: National Aeronautics and Space Administration. Description: SPACE LAUNCH SYSTEM (SLS) STAGES PRODUCTION AND EVOLUTION CONTRACT (SPEC)
  - (2026-10-19) [USASpending] $2,012,496,050 → AMENTUM TECHNOLOGY, INC.: ENGINEERING SERVICES AND SCIENCE CAPABILITY AUGMENTATION (ES
      Agency: National Aeronautics and Space Administration. Description: ENGINEERING SERVICES AND SCIENCE CAPABILITY AUGMENTATION (ESSCA)
  - (2026-10-19) [USASpending] $1,426,694,597 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SOFTWARE LIFE CYCLE DEVELOPMENT
      Agency: General Services Administration. Description: SOFTWARE LIFE CYCLE DEVELOPMENT
  - (2026-10-19) [USASpending] $580,415,713 → BLUESTAQ LLC: AIR FORCE RESEARCH LABORATORY (AFRL)/AIR FORCE SPACE AND MIS
      Agency: General Services Administration. Description: AIR FORCE RESEARCH LABORATORY (AFRL)/AIR FORCE SPACE AND MISSILE SYSTEMS CENTER (SMC), HAS A NEED TO EXPAND THE ADVANCED COMMAND AND CONTROL ENTERPRISE SYSTEMS AND SO…
  - (2026-10-19) [USASpending] $469,907,907 → DAVIS CONSTRUCTORS & ENGINEERS, INC.: DESIGN-BUILD MODERNIZATION AND EXPANSION OF THE ALCAN LAND P
      Agency: General Services Administration. Description: DESIGN-BUILD MODERNIZATION AND EXPANSION OF THE ALCAN LAND PORT OF ENTRY NEAR TOK, ALASKA, INCLUDING DEMOLITION, NEW INSPECTION FACILITIES, ADMINISTRATION BUILDINGS,…
  - (2026-10-19) [USASpending] $371,699,226 → KRATOS S2, INC: COSMIC AES SBIR III CONTRACT 47QFCA20C0019. THIS CONTRACT IS
      Agency: General Services Administration. Description: COSMIC AES SBIR III CONTRACT 47QFCA20C0019. THIS CONTRACT IS FOR OTHER FUNCTIONS.

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-19) [Marginal Revolution] No, DataCenters are Not Crowding-Out Other Investments
      Based on charts like the one at right, Paul Krugman and many others are arguing that: Massive spending on data centers is crowding out investment in everything else in the economy. Not so fast. Can you see one immediate…
  - (2026-10-19) [Marginal Revolution] What I’ve been reading
      David Stuart, The Four Heavens: A New History of the Ancient Maya. The best book about the ancient Maya that I know of, and also a book about how we keep on discovering more about them. “The model I advocate for here rej…
  - (2026-10-18) [Marginal Revolution] *You Can See Everything* (no spoilers)
      An excellent and also original movie, you all should see it. There are different interpretations, but I read it as a story between two autistic people, and the bond they have but also the great difficulties they have in…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-19) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=33, 7d-median=33, 14d-median=26; carrying terms: require, national, proposed, agency, period, action, public, proposing, safety, final, regulatory, proposes
- state_bills: today=109, 7d-median=118, 14d-median=114; carrying terms: administration, effective, alaska, state, powers, district, relating, providing, education, school, include, training
- state_news: today=315, 7d-median=688, 14d-median=678; carrying terms: urges, protections, missouri, editor, hundreds, person, found, assistance, nearly, deseret, water, become
- local_news: today=194, 7d-median=235, 14d-median=234; carrying terms: missouri, person, found, record, georgia, following, google, according, across, arrested, million, closed
- foreign_news: today=957, 7d-median=1018, 14d-median=1018; carrying terms: urges, hundreds, person, found, training, nearly, leader, dates, water, record, credit, fears
- chinese_internal: today=270, 7d-median=296, 14d-median=288; carrying terms: lxtfb, cbmibkfvx, investors, lxtfa, cbmiykfvx, blank, cbmizkfvx, cbmib, cbmiy, target, color, cbmix
- russian_internal: today=886, 7d-median=1029, 14d-median=1068; carrying terms: found, media, russian, europe, telegram, financial, title, gazeta, https, novayagazeta, error, novaya
- ukrainian_internal: today=136, 7d-median=130, 14d-median=135; carrying terms: powered, campaign, found, regions, nearly, russian, criticized, attack, urged, western, minister, russia
- ukraine_theater: today=413, 7d-median=393, 14d-median=411; carrying terms: rmvbbugzbzbqmk, sculpture, training, llxlqtutjdgxqvvbbwkrwylfvszexc, smjdbmvucxhnvxjrr, xnfbdr, sdxawakc, accreditation, aefylwxlq, lxtfbavunals, record, cuxpn
- paper_bets: today=66, 7d-median=69, 14d-median=74; carrying terms: fuentes, lifetime, successor, majors, kalshi, experience, break, participation, colonize, earthquake, supervolcano, chase
- weather: today=128, 7d-median=142, 14d-median=142; carrying terms: moderate, roads, impacts, pontiac, thursday, damage, average, october, level, southern, temperatures, national
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: effective, walcl, balance, spread, labor, nonfarm, commodities, payems, dexuseu, unrate, recession, payrolls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, large, equities, commodities, credit, futures, close, agriculture, natural, china, bitcoin, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=107, 14d-median=110; carrying terms: destabilising, transnistrian, territorial, content, laboratory, campaign, misappropriation, republic, enable, member, assets, resolutions
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, quiverquant, quantitative, congresstrading, httperror, https, quiver, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, supreme, board, appeals, corporation, court, mullin, alabama, county, trade, international, james
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, filed, issuer, trust, holdings, filer, matthew, funds, thomas, joseph
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, receipts, trone, booker, pinkston, cycle, committee, michael, robert, senate, alexandria, ocasio
- gdelt_regions: today=18, 7d-median=4, 14d-median=4; carrying terms: english
- gdelt_gkg: today=0, 7d-median=25, 14d-median=25; carrying terms: english, israel, hezbollah, strait
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: india, killed, language, domain, china, kingdom, english, damage, protest, canada, gandhi, against
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=28, 14d-median=30; carrying terms: belgium, position, france, kingdom, germany, ground, bulgaria, canada, netherlands, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: district, largest, ethiopian, disease, monkeypox, probable, fifth, include, province, epizootics, history, intensifying
- cisa_kev: today=14, 7d-median=15, 14d-median=14; carrying terms: product, cisco, traversal, vendor, remediation, vulnerability, injection, improper, fortinet, products, multiple, proftpd
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: brazil, fires, hurricane, depth, australia, forestfire, alert, tropical, forest, magnitude, typhoon, earthquake
- usgs_quakes: today=25, 7d-median=17, 14d-median=18; carrying terms: depth, indonesia, region, panama, papua, guinea, tonga, vanuatu, ridge, ruteng, grande, kokopo
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: presidential, volume, championship, october, shakhtar, champions, league, donetsk, price, resolves, playoffs, election
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, class, revolution, marginal, conversable, https, remember, track, conversableeconomist, spending, years, marginalrevolution
- tech_news: today=58, 7d-median=58, 14d-median=58; carrying terms: campaign, media, ireland, people, weekday, record, going, ransomware, engineering, weekly, systems, security
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: craig, stacey, composite, mccollum, massie, deposit, hassan, lutnick, trading, schultz, gilbert, ernst
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: evidence, converges, claude, paper, module, market, identify, sufficient, decision, today, markets, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-10-07] Fed press (events + announcements): Minutes of the Federal Open Market Committee, September 15-16, 2026
- [2026-10-08] ECB press: Piero Cipollone: Interview with Corriere della Sera
- [2026-10-08] Fed speeches: Waller, The Signaling Value of the Summary of Economic Projections
- [2026-10-08] ECB press: Meeting of 9-10 September 2026
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-13] ECB press: Philip R. Lane: The AI opportunity for Europe
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-17] ECB press: Christine Lagarde: IMFC Statement
- [2026-10-19] ECB press: Frank Elderson: From climate and nature risks to economic resilience and competitiveness

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*