# WORLDSCOPE morning brief — 2026-06-02

## Headline
2783 new items across 22 active section(s) (of 37 tracked).

## Top movers today
International News + Multilateral Institutions (575) · Russian Internal News (state + in-exile) (558) · World leaders & government officials (324) · State-Level News (292) · Chinese Internal News (228) · State Legislative Action (223) · Local News: St. Louis + Atlanta (168) · Ukraine Theater (total-war monitoring) (103) · U.S. Weather + Severe / Climate Outlooks (87) · Ukrainian Internal News (national + local Kyiv) (53) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 575 new of 850 total
  - (2026-06-02) [Global] Ukraine rescuers pull dead from rubble after Russian strikes kill 18 people
      An eight-year-old boy and a woman killed in a strike on an apartment block are among the dead, officials say.
  - (2026-06-02) [Global] Clashes continue in Lebanon despite Israel and Hezbollah accepting US partial ceasefire plan
      A cessation of hostilities between Israel and Hezbollah is seen as crucial to the peace process with Iran.
  - (2026-06-02) [Global] Two people shot dead amid Kenya protests against US Ebola quarantine centre plan
      The US plan has sparked public anger and led to demonstrations near the site of the proposed treatment facility.
  - (2026-06-02) [Global] Why Myanmar president's India visit is being closely watched
      Myanmar is seeking to broaden diplomatic engagement after years of international criticism and isolation.
  - (2026-06-02) [Global] Denmark's Mette Frederiksen to form government after months of negotiations
      The leader of Denmark's Social Democratic Party is forming a centre-left coalition minority government, giving her a third term as prime minister.
  - (2026-06-02) [Global] Sabrina Carpenter gets restraining order against man who showed up at her home
      The singer reported a series of "deeply alarming" incidents at her house to Los Angeles police.

### Russian Internal News (state + in-exile) — 558 new of 890 total
  - (2026-06-02) Россиян начали вербовать на войну с помощью вакансий «в тылу СВО» в Беларуси и Китае. Такие объявления появились на «Авито» | LEDE: На российском сайте «Авито» появились объявления, в которы] (ru: Рос…
      На российском сайте «Авито» появились объявления, в которых предлагают заключить контракт на службу в «тылу СВО» в Беларуси и Китае. На эти вакансии обратило внимание издание «Верстка».
  - (2026-06-02) Россия запустила по Украине сотни дронов и десятки ракет. В Киеве и Днепре погибли 17 человек, около 100 ранены. Фотографии | LEDE: Российская армия в ночь на 2 июня нанесла массированный уд] (ru: Рос…
      Российская армия в ночь на 2 июня нанесла массированный удар ракетами и дронами по Украине. В Киеве повреждены многоэтажные жилые дома. По последним данным, погибли шесть человек, более 60 получили ранения. В Днепре в ре…
  - (2026-06-02) Журналиста «Новой газеты» Олега Ролдугина отпустили под домашний арест | LEDE: Тверской районный суд Москвы отпустил обозревателя «Новой газеты» Олега Ролдугина из СИЗО и перевел его под дом] (ru: Жур…
      Тверской районный суд Москвы отпустил обозревателя «Новой газеты» Олега Ролдугина из СИЗО и перевел его под домашний арест по делу о незаконном использовании персональных данных.
  - (2026-06-02) Зампреда Духовного управления мусульман России оштрафовали из-за картины о битве на Калке | LEDE: Мировой судья в Москве оштрафовал первого зампредседателя Духовного управления мусульман Рос] (ru: Зам…
      Мировой судья в Москве оштрафовал первого зампредседателя Духовного управления мусульман России (ДУМ) Дамира Мухетдинова на 150 тысяч рублей по статье об осквернении религиозных предметов (часть 2 статьи 5.26 КоАП), сооб…
  - (2026-06-02) Боевая машина «Терминатор» теперь называется «Спиридон». Так звали деда Путина | LEDE: «Уралвагонзавод» сообщил, что переименовал боевую машину поддержки танков «Терминатор», дав ей новое на] (ru: Бое…
      «Уралвагонзавод» сообщил, что переименовал боевую машину поддержки танков «Терминатор», дав ей новое название — «Спиридон».
  - (2026-06-02) Вучич заявил, что Сербия не планирует вводить визы для россиян | LEDE: Президент Сербии Александр Вучич заявил, что вводить визы для россиян не планируется. ] (ru: Вучич заявил, что Сербия не планируе…
      Президент Сербии Александр Вучич заявил, что вводить визы для россиян не планируется.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 292 new of 504 total
  - (2026-06-01) [California] Prediction marketplace Kalshi gives Becerra high odds of winning. They also bet on his campaign
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/041426_Governors-Forum-Sacramento_MG_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp…
  - (2026-06-01) [California] Un tanque de productos químicos estuvo a punto de explotar. ¿Acaso los reguladores de California no detectaron las señales de alerta?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052226-Garden-Grove-Leak-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-06-02) [Connecticut] Ned Lamont’s and Josh Elliott’s campaigns are turning up the heat
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/06/E1F0175E-C0F6-487C-BB64-2C40CD67083C-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="…
  - (2026-06-02) [Connecticut] That wasn’t a trend. It was representation
      <img width="982" height="528" src="https://ctmirror.org/wp-content/uploads/2026/06/Glast-party-graf.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="…
  - (2026-06-02) [Connecticut] CT could fall victim to the hyperscale datacenter monster
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/05/AP-data-center.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcset="h…
  - (2026-06-01) [Connecticut] Hartford asks judge to block subpoenas for police misconduct records
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/06/CTPublic-HartfordPolice-1024x683.webp" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loadi…

### Chinese Internal News — 228 new of 265 total
  - (2026-06-01) Cover Story: How AI Took Over China’s Micro-Drama Industry in 90 Days - Caixin Global
      Cover Story: How AI Took Over China’s Micro-Drama Industry in 90 Days Caixin Global
  - (2026-06-01) China Manufacturing Activity Flatlines as New Export Orders Fall - Caixin Global
      China Manufacturing Activity Flatlines as New Export Orders Fall Caixin Global
  - (2026-06-02) 小泉进次郎：大家都说“日本真是世界典范啊” - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBmTmV0ZXZiMHIySjBNT3kyUWNsWTBCR0Q4TEVra183WHZULU13eHBES1FMQ2xfd2dPc1dzVkZtUG12aFAyVVNZY1JFZGZKdXpD] (zh:…
      小泉进次郎：大家都说“日本真是世界典范啊” 风闻
  - (2026-06-02) 程序员必将消亡，程序员失业是必然！ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5rbWNDQ3hNR2J3V181aVZtc1B2a2FudjlwRm5qYTkyN3l6SFA0czZrYzVqckNqUm5PbGYwYmtoNy1PMEZaWWhnaWRUX2ZfMUhEc1dD] (zh:…
      程序员必将消亡，程序员失业是必然！ 风闻
  - (2026-06-01) “一车安全带全是P上去的”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFA4bnpzRnFPYXRqM0RaSGNadjFKbDVTN19ScjdMTnYyNTBkOGxkbHpuSnhJbkVjN3dEWmJlVzMwT0JneVRheHFkaG5hT3YxZU9xek] (zh:…
      “一车安全带全是P上去的”-观察者网 观察者
  - (2026-06-01) “一车明星安全带全是P的”，公安部交管局发声-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1oLUF1VlpPN0k2RGVYTjEwZmNXcGN5T1RfRDdsamxwUldJUkdVX3IySlhzakVPZk45dE5CODVzV3lWSV9kUHNSYTkzd] (zh:…
      “一车明星安全带全是P的”，公安部交管局发声-观察者网 观察者

### State Legislative Action — 223 new of 234 total
  - (2026-06-02) [Alaska SB 143] An Act relating to ethics and budget training for school board members; relating to the terms of office of municipal school board members; relating to the size of the city council in s…
      An Act relating to ethics and budget training for school board members; relating to the terms of office of municipal school board members; relating to the size of the city council in second class cities; and providing fo…
  - (2026-06-02) [Alaska HB 13] An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobi…
      An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobile intensive care paramedic service…
  - (2026-06-02) [Alaska HB 36] An Act relating to treatment foster homes; relating to the placement of foster children in hospitals and residential psychiatric treatment centers for psychiatric care; relating to the…
      An Act relating to treatment foster homes; relating to the placement of foster children in hospitals and residential psychiatric treatment centers for psychiatric care; relating to the duties of the Department of Family…
  - (2026-06-02) [Alaska HB 96] An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
      An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
  - (2026-06-02) [Alaska HB 52] An Act relating to the rights of minors undergoing evaluation or inpatient treatment at psychiatric hospitals; relating to the use of seclusion or restraint of minors at psychiatric hos…
      An Act relating to the rights of minors undergoing evaluation or inpatient treatment at psychiatric hospitals; relating to the use of seclusion or restraint of minors at psychiatric hospitals; relating to a report publis…
  - (2026-06-02) [Alaska HB 93] An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.
      An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.

### Local News: St. Louis + Atlanta — 168 new of 217 total
  - (2026-06-02) [St. Louis] Shooting north of downtown leaves man critically injured
      Police said the victim was in critical, unstable condition and that homicide detectives were requested.
  - (2026-06-02) [St. Louis] Man shot, killed Monday night in Columbus Square
      Police said the man died at the hospital after being shot on Carr Street.
  - (2026-06-02) [St. Louis] Secretary of State Marco Rubio to testify before Congress for first time since Iran war began
      Secretary of State Marco Rubio is set to face a litany of questions about the Trump administration’s fragile and stalling diplomatic efforts around the world.
  - (2026-06-02) [St. Louis] Judge keeps Missouri plan to replace income tax with expanded sales taxes on Aug. 4 ballot
      Opponents quickly appealed the ruling, which leaves lawmakers’ description of Amendment 5 intact as a June 9 ballot deadline approaches.
  - (2026-06-02) [St. Louis] Woman killed, man injured in Alton shooting
      Police said the people involved knew each other, and investigators don't believe there is any active threat to the public.
  - (2026-06-02) [St. Louis] South Carolina jury finds store owner not guilty of murder in killing of Black teen
      Chikei Rick Chow maintained his innocence after shooting Cyrus Carmack-Belton in the back after chasing him from his store in 2023.

### Ukraine Theater (total-war monitoring) — 103 new of 272 total
  - (2026-06-02) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-01) [FIRMS] thermal anomaly 52.282, 33.034 (FRP 1.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-01 0018Z, FRP 1.56 MW
  - (2026-06-01) [FIRMS] thermal anomaly 51.847, 34.280 (FRP 0.45 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-01 0018Z, FRP 0.45 MW
  - (2026-06-01) [FIRMS] thermal anomaly 51.756, 33.792 (FRP 0.82 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-01 0018Z, FRP 0.82 MW
  - (2026-06-01) [FIRMS] thermal anomaly 51.837, 32.009 (FRP 0.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-01 0018Z, FRP 0.95 MW
  - (2026-06-01) [FIRMS] thermal anomaly 51.336, 34.379 (FRP 0.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-01 0018Z, FRP 0.72 MW

### U.S. Weather + Severe / Climate Outlooks — 87 new of 90 total
  - (2026-06-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 5:46AM CDT by NWS Jackson MS
      At 545 AM CDT, Doppler radar was tracking a strong thunderstorm over Sweatman, or 12 miles northeast of Winona, moving southeast at 15 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds…
  - (2026-06-02) [Moderate] Gale Watch: Gale Watch issued June 2 at 3:44AM PDT until June 5 at 6:00AM PDT by NWS Eureka CA
      * WHAT...For the Small Craft Advisory, north winds 15 to 20 kt with gusts up to 25 kt and seas 6 to 9 feet. For the Gale Watch, north winds 25 to 30 kt with gusts up to 40 kt and seas 8 to 13 feet possible. * WHERE...Wat…
  - (2026-06-02) [Moderate] Heat Advisory: Heat Advisory issued June 2 at 2:27AM AKDT until June 2 at 8:00PM AKDT by NWS Juneau AK
      * WHAT...Temperatures 80 to 85 expected in areas away from the inner channels and outer coast. * WHERE...City of Hyder, Ketchikan Gateway Borough, and Prince of Wales Island. * WHEN...From 10 AM this morning to 8 PM AKDT…
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 6:07AM EDT by NWS Morristown TN
      Patch dense fog, primarily in the Sequatchie river valley, areas near the East Tennessee mountains, and also the valley locations in our western North Carolina counties, will affect the area through mid morning. When dri…
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 5:02AM CDT by NWS Grand Forks ND
      Relative humidity values will drop to the 20 to 25 percent along with southeast winds 10 to 15 mph across portions of north- central Minnesota. Near critical fire weather conditions are expected for the afternoon hours.…

### Ukrainian Internal News (national + local Kyiv) — 53 new of 110 total
  - (2026-06-02) Десять мільйонів грн щомісяця на сексуальній експлуатації жінок: судитимуть 9 учасників схеми | LEDE: Перед судом постануть 9 учасників злочинної організації, які налагодили масштабну схему сек] (uk:…
      Перед судом постануть 9 учасників злочинної організації, які налагодили масштабну схему сексуальної експлуатації жінок.
  - (2026-06-02) Юрій Чебан: Ми дуже хочемо повернути на світову арену нашу байдарку-четвірку | LEDE: ] (uk: Юрій Чебан: Ми дуже хочемо повернути на світову арену нашу байдарку-четвірку)
  - (2026-06-02) Повітряні сили: За травень ППО знищила 111 ракет, з них 12 балістичних | LEDE: Протягом травня 2026 року протиповітряною обороною Cил оборони знищено понад 57000 повітряних цілей.] (uk: Повітряні сили…
      Протягом травня 2026 року протиповітряною обороною Cил оборони знищено понад 57000 повітряних цілей.
  - (2026-06-02) Дощі, грози і до +27° – погода на 3-5 червня | LEDE: В Україні до кінця тижня збережеться тепла та дощова погода. Місцями – грози і значні опади] (uk: Дощі, грози і до +27° – погода на 3-5 червня)
      В Україні до кінця тижня збережеться тепла та дощова погода. Місцями – грози і значні опади
  - (2026-06-02) Росіяни від ранку атакують Харків дронами: поранені троє людей | LEDE: Армія РФ від ранку 2 червня атакує Харків ударними безпілотниками, внаслідок ударів у двох районах міста поранення дістали] (uk:…
      Армія РФ від ранку 2 червня атакує Харків ударними безпілотниками, внаслідок ударів у двох районах міста поранення дістали 51-річний та 30-річний чоловіки та жінка 50 років.
  - (2026-06-02) У Путіна пообіцяли закінчити війну за добу, якщо Україна віддасть "російські регіони" | LEDE: Пєсков заявив, що РФ завершить війну за добу, якщо ЗСУ здадуть українські регіони, які окупанти вва] (uk:…
      Пєсков заявив, що РФ завершить війну за добу, якщо ЗСУ здадуть українські регіони, які окупанти вважають російськими.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-02) 497 - Corgi ETF Trust I (0002078265) (Filer)
      filed 2026-06-02 11:14 UTC — Filed: 2026-06-02 AccNo: 0002078265-26-000202 Size: 15 KB
  - (2026-06-02) 424B3 - Phoenix Energy One, LLC (0001818643) (Filer)
      filed 2026-06-02 11:12 UTC — Filed: 2026-06-02 AccNo: 0001193125-26-252493 Size: 2 MB
  - (2026-06-02) [Itagaki Yasushi] Form 4 (Reporting)
      filed 2026-06-02 11:11 UTC · role: Reporting — Filed: 2026-06-02 AccNo: 0001193125-26-252492 Size: 6 KB
  - (2026-06-02) [MITSUBISHI UFJ FINANCIAL GROUP INC] Form 4 (Issuer)
      filed 2026-06-02 11:11 UTC · role: Issuer — Filed: 2026-06-02 AccNo: 0001193125-26-252492 Size: 6 KB
  - (2026-06-02) [Potts Charles Edward] Form 4 (Reporting)
      filed 2026-06-02 11:11 UTC · role: Reporting — Filed: 2026-06-02 AccNo: 0002000358-26-000012 Size: 5 KB
  - (2026-06-02) [T Stamp Inc] Form 4 (Issuer)
      filed 2026-06-02 11:11 UTC · role: Issuer — Filed: 2026-06-02 AccNo: 0002000358-26-000012 Size: 5 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Paper Trading Scorecard — 26 new of 140 total
  - (2026-06-02) [Polymarket] Will Gideon Sa’ar be the next Prime Minister of Israel?
      Legislative elections are schedule to be held in Israel on October 27, 2026. This market will resolve to the next individual who is officially appointed and sworn in as Prime Minister of Israel following the 2026 parliam…
  - (2026-06-02) [Polymarket] Will Crude Oil reach a new all-time high by September 30?
      This market will resolve to "Yes" if, on any trading day after market creation, the official daily high price published by the CME Group for the Active Month (front month) of CME Crude Oil (CL) futures is greater than $1…
  - (2026-06-02) [Polymarket] Will the price of Bitcoin be above $66,000 on June 3?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-06-02) [Polymarket] Will SHEIN have the highest IPO Market Cap 2026?
      This market will resolve to the company that achieves the highest market capitalization in U.S. dollars based on the official closing price on its first trading day in 2026. This market will resolve to a company that com…
  - (2026-06-02) [Polymarket] Counter-Strike: BetBoom Team vs Gaimin Gladiators (BO1) - IEM Cologne Major Stage 1
      This market refers to the Counter-Strike Round 1 match between BetBoom Team and Gaimin Gladiators in the IEM Cologne Major Stage 1, initially scheduled for June 2 at 8:00AM ET. This market will resolve to "BetBoom Team"…
  - (2026-06-02) [Polymarket] US x Iran permanent peace deal by June 7, 2026?
      This market will resolve to “Yes” if Iran and the United states agree to a permanent peace deal by the specified date, 11:59 PM ET. Otherwise, this market will resolve to “No”. A permanent peace deal refers to any agreem…

### Government & military aircraft airborne (OpenSky) — 24 new of 26 total
  - (2026-06-02) JAF94H (Bulgaria)
      icao24: 4520aa · position: (40.5438, -2.7993) · alt: 10668m · 924km/h
  - (2026-06-02) SAMU06 (France)
      icao24: 39c901 · position: (None, None) · on ground
  - (2026-06-02) CFC2948 (Canada)
      icao24: c2b55d · position: (49.9487, 21.7847) · alt: 3970m · 389km/h
  - (2026-06-02) KAF3209 (Kuwait)
      icao24: 706217 · position: (35.2753, 22.5229) · alt: 10668m · 832km/h
  - (2026-06-02) FAF9162 (France)
      icao24: 3b771c · position: (60.1435, 12.808) · alt: 7924m · 565km/h
  - (2026-06-02) JAF9CK (Belgium)
      icao24: 44d1ba · position: (41.1794, 4.3958) · alt: 12192m · 759km/h

### Court opinions of consequence (federal & state) — 16 new of 60 total
  - (2026-06-01) U.S. Court of Appeals, D.C. Cir.: Nicolas Talbott v. United States
  - (2026-06-01) U.S. Court of Appeals, 11th Cir.: Donald Smith v. Sonya Slott
  - (2026-06-01) U.S. Court of Appeals, 5th Cir.: Bravo v. Dallas ISD
  - (2026-06-01) U.S. Court of Appeals, 5th Cir.: United States v. Filline
  - (2026-06-01) U.S. Court of Appeals, 3rd Cir.: United States v. Richardson Dangleben, Jr.
  - (2026-06-01) Supreme Court of California: People v. Bankston

### U.S. Federal Action — 12 new of 15 total
  - (2026-06-02) Federal Employees Health Benefits Program: Verification Requirements for Family Member Coverage
      The FEHB Protection Act of 2025 (FPA) requires OPM to issue regulations and implement a process to verify: The veracity of any qualifying life event (QLE) through which a health benefits plan enrollee seeks to add a memb…
  - (2026-06-02) Fisheries Off West Coast States; the Highly Migratory Species Fishery; Pacific Loggerhead Conservation Area Closure
      NMFS is prohibiting fishing with large-mesh drift gillnet (DGN) gear (>=14 inches mesh) off the coast of southern California east of 120[deg] W meridian from June 1, 2026, through August 31, 2026. This prohibition is bas…
  - (2026-06-02) Fisheries of the South Atlantic; 2026 Recreational Accountability Measure and Closure for Snowy Grouper in the South Atlantic
      NMFS implements an accountability measure (AM) and closure for the recreational harvest of snowy grouper in South Atlantic Federal waters. NMFS reduces the length of the snowy grouper 2026 recreational fishing season to…
  - (2026-06-02) Notice of Vacatur Regarding Certain Provisions of the 2024 Nondiscrimination in Health Programs and Activities Final Rule
      This is to inform the public that, on October 22, 2025, the United States District Court for the Southern District of Mississippi issued an order in Tennessee v. Kennedy, No. 1:24-cv-161-LG-BWR (S.D. Miss. Oct. 22, 2025)…
  - (2026-06-02) New Mailing Standards for Domestic Mailing Services Products
      On April 9, 2026, the Postal Service (USPS) filed a notice of mailing services price adjustments with the Postal Regulatory Commission (PRC), effective July 12, 2026. This final rule contains the revisions to Mailing Sta…
  - (2026-06-02) Payment Limitation and Payment Eligibility
      This rule revises the payment limitation and payment eligibility regulations to conform with provisions of the One Big Beautiful Bill Act (OBBBA). This rule also makes additional changes to those regulations to improve p…

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-06-02) Roland Garros ATP: Rafael Jodar vs Alexander Zverev
      yes price: 20% · 24h volume: $2,994,373 · resolves 2026-06-09
  - (2026-06-02) US x Iran permanent peace deal by June 15, 2026?
      yes price: 14% · 24h volume: $1,719,129 · resolves 2026-06-15
  - (2026-06-02) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,106,723 · resolves 2026-07-20
  - (2026-06-02) Will Saudi Arabia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,067,598 · resolves 2026-07-20
  - (2026-06-02) Roland Garros WTA: Elina Svitolina vs Marta Kostyuk
      yes price: 34% · 24h volume: $998,012 · resolves 2026-06-09
  - (2026-06-02) Will Norway win the 2026 FIFA World Cup?
      yes price: 3% · 24h volume: $971,940 · resolves 2026-07-20

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 108 total
  - (2026-06-01) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control, and FTI Consulting, Inc. - Office of Foreign Assets Control (.gov)
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control, and FTI Consulting, Inc. Office of Foreign Assets Control (.gov)
  - (2026-06-01) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-06-01) [OFAC] Introduction to the Office of Foreign Assets Control - Office of Foreign Assets Control (.gov)
      Introduction to the Office of Foreign Assets Control Office of Foreign Assets Control (.gov)
  - (2026-06-02) [UN Sanctions] page checksum 1bd12e7cb6e6
      Active UN Security Council sanctions committees page snapshot

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-06-02) [Marginal Revolution] The US Exports Intelligence
      Most Americans work in the service sector so it’s not surprising that most export-related jobs are in the service sector (The U.S. exports about $2.2 trillion of goods and $1.2 trillion of services, but services are more…
  - (2026-06-02) [Marginal Revolution] *The Republic of Love*
      The author is Martha C. Nussbaum, and the subtitle is Opera & Political Freedom. Martha decided she did not wish to do a podcast after all, so since I put some real prep time in I thought I would offer some thoughts on t…
  - (2026-06-01) [Marginal Revolution] The chimera of universal coverage in a large, diverse country
      Our findings suggest that policies intended to subsidize health insurance of higher income groups, for example, the enhanced premium subsidies, are far less efficient than policies intended to further expand public insur…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 16 total
  - (2026-06-01) CVE-2024-21182 · Oracle WebLogic Server: Oracle WebLogic Server Unspecified Vulnerability
      vendor: Oracle · product: WebLogic Server · CISA remediation by 2026-06-04

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=30, 14d-median=30; carrying terms: guard, requires, persons, needed, within, amendment, program, proposing, action, provide, captain, proposed
- state_bills: today=234, 7d-median=155, 14d-median=155; carrying terms: being, employer, notice, sharing, impact, things, conditions, assessment, currently, related, relating, house
- state_news: today=504, 7d-median=695, 14d-median=695; carrying terms: being, flgov, moving, charged, bills, notice, keeps, total, caught, graduation, yellow, subscribe
- local_news: today=217, 7d-median=246, 14d-median=246; carrying terms: being, charged, museum, remains, sharing, house, tornado, magazine, story, shooting, national, vehicle
- foreign_news: today=850, 7d-median=860, 14d-median=860; carrying terms: being, risks, dream, notice, total, trips, integration, stunt, defensive, currently, related, probe
- chinese_internal: today=265, 7d-median=269, 14d-median=269; carrying terms: cbmibefvx, china, title, cbmiakfvx, cbmidefvx, articles, google, https, cbmiykfvx, cbmib, cbmix, politics
- russian_internal: today=890, 7d-median=916, 14d-median=916; carrying terms: company, telegram, group, axios, httperror, reuters, china, https, times, international, novaya, istories
- ukrainian_internal: today=110, 7d-median=122, 14d-median=122; carrying terms: russia, risks, total, remains, integration, conditions, assessment, commander, prime, civilian, measures, leaders
- ukraine_theater: today=272, 7d-median=308, 14d-median=308; carrying terms: wlnpmuh, tddtbezsm, cbmilafbvv, vwlbvv, tnvinuzjb, mnzdte, nywlbet, total, pfave, vlnuvhznq, xuhrncw, thhqrkcwaeozsvpbb
- paper_bets: today=140, 7d-median=141, 14d-median=141; carrying terms: company, holliday, earthquake, country, democratic, kalshi, kansas, andrew, presidential, total, mamdani, romania
- weather: today=90, 7d-median=112, 14d-median=112; carrying terms: morning, moving, notice, begin, detroit, impact, remains, conditions, holly, monday, afdokx, messages
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: coffee, nikkei, canada, crypto, commodity, crude, merval, copper, kospi, natural, china, france
- sanctions_procurement: today=108, 7d-median=100, 14d-median=100; carrying terms: company, zimbabwe, ukraine, russia, democratic, zklpexj, ztwgwxqzvywvd, protecting, daesh, operations, related, xtgxrdudrnejwemltsu
- congressional_trades: today=40, 7d-median=1, 14d-median=1
- billionaires: today=0, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: america, bondi, vasquez, transport, smith, employee, blanche, group, fernandez, castillo, veterans, kenneth
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, accno, issuer, financial, group, filer, trust
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cooper, angels, receipts, friends, warner, cycle, ossoff, graham, joshua, krishnamoorthi, alexandria, disbursements
- gdelt_regions: today=0, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=26, 7d-median=0, 14d-median=8; carrying terms: position, ground, belgium, bulgaria, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: directory, authentication, product, following, reader, vendor, bypass, overwrite, defender, adobe, service, traversal
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, peace, price, world, volume, permanent, bitcoin, coast, garros, ivory, roland, turkiye
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, story, policy, class, economist, marginal, conversable, revolution, recipients, marginalrevolution, company, professor
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: kevin, stephanie, turner, barrett, friedman, aderholt, norcross, levin, elfreth, houchin, ruben, stauber
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: sufficient, claude, decision, evidence, paper, consensus, today, placement, module, converges, identify, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Christine Lagarde: When It Matters Most: Upholding Independence in Challenging Times
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*