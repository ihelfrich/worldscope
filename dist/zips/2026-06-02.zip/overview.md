# WORLDSCOPE morning brief — 2026-06-02

## Headline
3283 new items across 32 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (648) · International News + Multilateral Institutions (619) · State-Level News (358) · World leaders & government officials (324) · Chinese Internal News (233) · Local News: St. Louis + Atlanta (206) · State Legislative Action (143) · Ukraine Theater (total-war monitoring) (135) · GDACS — global disaster alerts (96) · U.S. Weather + Severe / Climate Outlooks (78) · Ukrainian Internal News (national + local Kyiv) (63) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 648 new of 952 total
  - (2026-06-02) Трамп назначил директором разведки главу федерального ипотечного агентства Билла Пулте. В разведке у него нет никакого опыта | LEDE: Глава Федерального агентства жилищного финансирования (FH] (ru: Тра…
      Глава Федерального агентства жилищного финансирования (FHFA) США Билл Пулте будет исполнять обязанности директора Национальной разведки, сообщил президент страны Дональд Трамп.
  - (2026-06-02) В Польше вернулся на трассу автобус № 666 в город Хель. Шутки про Highway to Hel, конечно же, тоже вернулись. Три года назад номер «адского» маршрута поменяли из-за жалоб верующих | LEDE: В ] (ru: В П…
      В Польше перезапустили автобусный маршрут № 666 в курортный город Хель, расположенный на одноименном полуострове на побережье Балтийского моря. Новым оператором маршрута станет немецкая транспортная компания Flixbus, кот…
  - (2026-06-02) Офицер флота годами подделывал и продавал скульптуры Эрнста Неизвестного. Их обнаружили только на выставке в Третьяковке | LEDE: Эрнст Неизвестный — самый знаменитый советский скульптор втор] (ru: Офи…
      Эрнст Неизвестный — самый знаменитый советский скульптор второй половины XX века. Он создавал экспрессивные, полные символизма скульптуры, иногда — на грани абстракции. Карьера Неизвестного началась в эпоху оттепели, ког…
  - (2026-06-02) Мизулина написала донос на Собчак. Она пожаловалась на «пропаганду ЛГБТ» в интервью бьюти-блогера Игоря Синяка | LEDE: Глава Лиги безопасного интернета Екатерина Мизулина написала донос в МВ] (ru: Миз…
      Глава Лиги безопасного интернета Екатерина Мизулина написала донос в МВД на Ксению Собчак. Поводом для доноса стало интервью бьюти-блогера Игоря Синяка, вышедшее на ютьюб-канале «Осторожно, Собчак» 1 июня.
  - (2026-06-02) В СМИ много новостей о том, что Сербия хочет отменить безвизовый режим с Россией. Стоит ли беспокоиться, если я уже живу в стране? А если собираюсь туда переехать? Разбираем риски вступления Се] (ru:…
      «В Сербии обсуждают отказ от безвиза с Россией до конца 2026 года» — новости с такими заголовками появились во многих русскоязычных медиа 1 июня. Все началось с публикаций «Известий»: издание дважды за несколько дней пис…
  - (2026-06-02) Россия продолжает запрещать импорт из Армении — теперь это яблоки, баклажаны и сухофрукты. Пашинян пообещал субсидии пострадавшим экспортерам | LEDE: Россельхознадзор с 3 июня 2026 года запр] (ru: Рос…
      Россельхознадзор с 3 июня 2026 года запретил ввоз из Армении картофеля, баклажанов, семечковых культур (яблоки, груши, айва) и сухофруктов.

### International News + Multilateral Institutions — 619 new of 837 total
  - (2026-06-02) [Global] Thomas Pesquet set to return to space in 2027
      French astronaut Thomas Pesquet is set to return to space with fellow spaceman Arnaud Prost in 2027. It comes as part of an agreement between the French government and American space company Vast announced at Choose Fran…
  - (2026-06-02) [Global] Celine Dion announces new Paris dates to meet demand
      If you tried and failed to get tickets to see Celine Dion in Paris this fall, all is not lost. Due to what the concert organiser called “exceptional demand,” the singer has added ten new dates in May of 2027. This will b…
  - (2026-06-02) [Global] Israel conducts deadly attacks on southern Lebanon after Trump promises de-escalation
      Israel ​kept up strikes on southern Lebanon on Tuesday, killing eight people, including children, as it pressed its campaign against Hezbollah a day after President Donald Trump asked Prime Minister Benjamin Netanyahu no…
  - (2026-06-02) [Global] Russia 'bogged down' in Ukraine, suffering net territorial losses for first the time since 2023
      Angela Diffley is pleased to welcome Peter Zalmayev, director of the Eurasia Democracy Initiative. He offers a forceful assessment of the evolving dynamics of Russia's war against Ukraine. Rejecting narratives of Russian…
  - (2026-06-02) [Global] The lucrative market behind viral fake news
      Public debate is increasingly disrupted by viral misinformation circulating on social media. Behind this sensationalist content regularly lie actors driven by pure profit. To truly understand the spread of online misinfo…
  - (2026-06-02) [Global] French President visits national team ahead of World cup
      French President Emmanuel Macron and First Lady Brigitte Macron visited the country's national football team ahead of their departure for the World Cup. France are one of the favourites going into the competition. This w…

### State-Level News — 358 new of 550 total
  - (2026-06-02) [California] Will Trump’s waning popularity pull down California Republicans? Today’s election offers a clue
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/062422-State-Capitol-MG-CM-03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-06-02) [California] California House races could decide the majority in Congress. Who will survive the primary?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/04/031524-US-Capitol-REUTERS-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-06-02) [California] Today we vote. Then, we wait 🗳️
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/110524_Sacramento-General-Election_MG_CM_28.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size w…
  - (2026-06-02) [California] Live California election results
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/election_results_featured.png?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…
  - (2026-06-02) [California] Top Democrats compete in wide-open primary for lieutenant governor
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2023/07/030822-Newsom-State-of-State-MG-CM-014.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-06-02) [California] From Vallejo to Riverside, VotingMatters brought CalMatters’ primary voter guide to life
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/052026_SF-VotingMatters_MO_CM_50.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 233 new of 268 total
  - (2026-06-01) Cover Story: How AI Took Over China’s Micro-Drama Industry in 90 Days - Caixin Global
      Cover Story: How AI Took Over China’s Micro-Drama Industry in 90 Days Caixin Global
  - (2026-06-01) China Manufacturing Activity Flatlines as New Export Orders Fall - Caixin Global
      China Manufacturing Activity Flatlines as New Export Orders Fall Caixin Global
  - (2026-06-02) China’s Tiger Brokers reports strong results, with no mention of trading crackdown
  - (2026-06-02) US$1b windfall: how Meituan’s bets on AI, robotics outshine quarterly loss
  - (2026-06-02) CK Asset resumes sales at 21 Borrett Road after waiting out luxury-property slump
  - (2026-06-02) The big scoop: lemon tea chain Ningji to revamp Haagen-Dazs’ struggling China business

### Local News: St. Louis + Atlanta — 206 new of 243 total
  - (2026-06-02) [St. Louis] Horse stabbings at Las Vegas equestrian competition shocks the community
      A teenage girl is facing multiple charges for allegedly stabbing three horses during an equestrian event in Las Vegas.
  - (2026-06-02) [St. Louis] Sabrina Carpenter gets restraining order against alleged stalker who tried to break into her house, reports say
      In a declaration submitted to the court, Carpenter reportedly said she has experienced "severe and ongoing emotional distress" because of the stalking.
  - (2026-06-02) [St. Louis] 'Twins Peaks: The Return' actor Owain Rhys Davies dies at 44
      ​The 44-year-old actor starred in "Twin Peaks: The Return" as Agent Wilson.
  - (2026-06-02) [St. Louis] Carnival data breach: Nearly 6 million impacted by social engineering attack
      A social engineering attack is a scam method "bad actors" use to trick people into giving them sensitive information or access.
  - (2026-06-02) [St. Louis] Windows repeatedly smashed at Steve's Hot Dogs; police are searching for the suspect
      Anyone with information was asked to call CrimeStoppers at 866-371-TIPS (8477).
  - (2026-06-02) [St. Louis] Woman missing out of Jefferson County
      Branham is diagnosed with bipolar schizophrenia and is without her medication, the sheriff's office said.

### State Legislative Action — 143 new of 153 total
  - (2026-06-02) [Alaska SB 143] An Act relating to ethics and budget training for school board members; relating to the terms of office of municipal school board members; relating to the size of the city council in s…
      An Act relating to ethics and budget training for school board members; relating to the terms of office of municipal school board members; relating to the size of the city council in second class cities; and providing fo…
  - (2026-06-02) [Alaska HB 13] An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobi…
      An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobile intensive care paramedic service…
  - (2026-06-02) [Alaska HB 36] An Act relating to treatment foster homes; relating to the placement of foster children in hospitals and residential psychiatric treatment centers for psychiatric care; relating to the…
      An Act relating to treatment foster homes; relating to the placement of foster children in hospitals and residential psychiatric treatment centers for psychiatric care; relating to the duties of the Department of Family…
  - (2026-06-02) [Alaska HB 96] An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
      An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
  - (2026-06-02) [Alaska HB 52] An Act relating to the rights of minors undergoing evaluation or inpatient treatment at psychiatric hospitals; relating to the use of seclusion or restraint of minors at psychiatric hos…
      An Act relating to the rights of minors undergoing evaluation or inpatient treatment at psychiatric hospitals; relating to the use of seclusion or restraint of minors at psychiatric hospitals; relating to a report publis…
  - (2026-06-02) [Alaska HB 93] An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.
      An Act changing the residency requirements for hunting, trapping, and sport fishing privileges; and providing for an effective date.

### Ukraine Theater (total-war monitoring) — 135 new of 271 total
  - (2026-06-02) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-02) [Liveuamap] Overnight Russia launched 8 3M22 Tsyrkon missiles, 33 Iskander-M ballistic missiles, 27 cruise missiles Kh-101, 5 cruise missiles Kaliber and 656 drones of different types, - Ukrainian Air…
      Overnight Russia launched 8 3M22 Tsyrkon missiles, 33 Iskander-M ballistic missiles, 27 cruise missiles Kh-101, 5 cruise missile
  - (2026-06-01) [Liveuamap] Zelensky instructed to try to end this war as soon as possible, preferably before winter, - Budanov - Liveuamap
      Zelensky instructed to try to end this war as soon as possible, preferably before winter, - Budanov <font color=
  - (2026-06-02) [Liveuamap] Lebanon's official Six killed in Israeli airstrikes on the towns of Breqa, Toul, Harouf, and Shoukin in southern Lebanon. - Liveuamap
      Lebanon's official Six killed in Israeli airstrikes on the towns of Breqa, Toul, Harouf, and Shoukin in souther
  - (2026-06-02) [Liveuamap] Netanyahu: The regime in Iran will eventually fall. Jerusalem, Jerusalem District - iran.liveuamap.com
      Netanyahu: The regime in Iran will eventually fall. Jerusalem, Jerusalem District
  - (2026-06-02) [Liveuamap] Israeli Defense Minister: The Lebanese government and all relevant parties have been informed that an attack on Israeli settlements will be met with an attack on the southern suburbs of Be…
      Israeli Defense Minister: The Lebanese government and all relevant parties have been informed that an attack on Isra

### GDACS — global disaster alerts — 96 new of 96 total
  - (2025-11-21) [Orange] Drought in Madagascar
      Drought · Orange alert · Madagascar · Medium impact for agricultural drought in 311371 km2
  - (2025-11-21) [Orange] Drought in Madagascar
      Drought · Orange alert · Madagascar · Medium impact for agricultural drought in 311371 km2
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-29) [Green] Flood in Germany
      Flood · Green alert · Germany · Magnitude 0

### U.S. Weather + Severe / Climate Outlooks — 78 new of 81 total
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 10:43AM CDT by NWS Little Rock AR
      At 1043 AM CDT, Doppler radar was tracking a strong thunderstorm near Morgan Springs, or 17 miles west of Waldron, moving south at 20 mph. HAZARD...Winds in excess of 40 mph. SOURCE...Radar indicated. IMPACT...Gusty wind…
  - (2026-06-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-02) [Moderate] Gale Watch: Gale Watch issued June 2 at 8:37AM PDT until June 5 at 6:00AM PDT by NWS Eureka CA
      * WHAT...For the Small Craft Advisory, northwest winds 15 to 20 kt with gusts up to 25 kt and seas 7 to 9 feet. For the Gale Watch, north winds 25 to 30 kt with gusts up to 40 kt and seas 8 to 13 feet possible. * WHERE..…
  - (2026-06-02) [Severe] Flood Warning: Flood Warning issued June 2 at 10:36AM CDT until June 8 at 7:00AM CDT by NWS Little Rock AR
      ...The Flood Warning continues for the following rivers in Arkansas... Cache River Near Patterson affecting Jackson and Woodruff Counties. For the Cache River...including Patterson...Minor flooding is forecast. * WHAT...…
  - (2026-06-02) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued June 2 at 11:33AM EDT until June 2 at 8:00PM EDT by NWS Newport/Morehead City NC
      * WHAT...Dangerous rip currents and strong longshore currents in the surf zone. * WHERE...Ocracoke Island and Core Banks beaches. * WHEN...Through this evening. * IMPACTS...Rip currents can sweep even the best swimmers a…
  - (2026-06-02) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued June 2 at 11:33AM EDT until June 2 at 8:00PM EDT by NWS Newport/Morehead City NC
      * WHAT...Dangerous rip currents, large breaking waves expected, and strong longshore currents in the surf zone. * WHERE...The beaches north of Hatteras Inlet. * WHEN...Through this evening. * IMPACTS...Rip currents can s…

### Ukrainian Internal News (national + local Kyiv) — 63 new of 119 total
  - (2026-06-02) ЗМІ: ЄС готується відкрити перший переговорний кластер з Україною і Молдовою 15 червня | LEDE: ЄС 15 червня може офіційно відкрити перший кластер у переговорах про вступ України та Молдови – пі] (uk:…
      ЄС 15 червня може офіційно відкрити перший кластер у переговорах про вступ України та Молдови – після того як Угорщина дала зрозуміти, що відмовиться від своєї давньої опозиції щодо заявки України.
  - (2026-06-02) Розвідка дізналась, куди Росія планує бити далі: українське ракетобудівництво | LEDE: За даними розвідки, Росія визначила як пріоритет для наступних атак по Україні компанії, які ефективно розр] (uk:…
      За даними розвідки, Росія визначила як пріоритет для наступних атак по Україні компанії, які ефективно розробляють різні типи ракетних технологій.
  - (2026-06-02) "Росія нас тестує". Пояснення з Румунії, чому удар дрона був навмисним і які будуть наслідки | LEDE: ] (uk: "Росія нас тестує". Пояснення з Румунії, чому удар дрона був навмисним і які буд)
  - (2026-06-02) У Дніпрі завершили пошуково-рятувальну операцію: нічна атака РФ забрала життя 16 людей, 42 поранено | LEDE: У Дніпрі завершили пошуково-рятувальну операцію у житловому кварталі, по якому уночі ] (uk:…
      У Дніпрі завершили пошуково-рятувальну операцію у житловому кварталі, по якому уночі поцілили російські ракети.
  - (2026-06-02) Мадяр повторив, що готовий зустрітися із Зеленським на початку наступного тижня | LEDE: Прем'єр Угорщини Петер Мадяр готовий зустрітися з президентом України Володимиром Зеленським на початку н] (uk:…
      Прем'єр Угорщини Петер Мадяр готовий зустрітися з президентом України Володимиром Зеленським на початку наступного тижня, якщо вдасться досягти згоди щодо питання основних прав угорської меншини.
  - (2026-06-02) У липні в ЄС вирішуватимуть, чи продовжувати тимчасовий захист для українських біженців | LEDE: Європейський Союз планує прийняти рішення щодо статусу українських біженців після березня 2027 ро] (uk:…
      Європейський Союз планує прийняти рішення щодо статусу українських біженців після березня 2027 року, у липні 2026 року; якщо ж це не вдасться – то в вересні.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-02) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-06-02 15:46 UTC — Filed: 2026-06-02 AccNo: 0001918704-26-015144 Size: 617 KB
  - (2026-06-02) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-06-02 15:45 UTC — Filed: 2026-06-02 AccNo: 0001918704-26-015143 Size: 109 KB
  - (2026-06-02) [Lelah Noam] Form 4 (Reporting)
      filed 2026-06-02 15:45 UTC · role: Reporting — Filed: 2026-06-02 AccNo: 0001976408-26-000536 Size: 4 KB
  - (2026-06-02) [Allot Ltd.] Form 4 (Issuer)
      filed 2026-06-02 15:45 UTC · role: Issuer — Filed: 2026-06-02 AccNo: 0001976408-26-000536 Size: 4 KB
  - (2026-06-02) 424B2 - Morgan Stanley Finance LLC (0001666268) (Filer)
      filed 2026-06-02 15:45 UTC — Filed: 2026-06-02 AccNo: 0001839882-26-027292 Size: 484 KB
  - (2026-06-02) 424B2 - MORGAN STANLEY (0000895421) (Filer)
      filed 2026-06-02 15:45 UTC — Filed: 2026-06-02 AccNo: 0001839882-26-027292 Size: 484 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-02) [United States] Pete Vasquez Named Chief of U . S . Border Patrol – Tickle The Wire
      domain: ticklethewire.com · language: English · tone:
  - (2026-06-02) [United States] Doctors checked Biden just after Trump debate as Jill Biden feared he had a stroke
      domain: kmuw.org · language: English · tone:
  - (2026-06-02) [United States] E - scooter rider hit , killed after crash with street sweeper
      domain: wgal.com · language: English · tone:
  - (2026-06-02) [Israel] Taiwanese military display Robot patrol dogs for future service
      domain: jpost.com · language: English · tone:
  - (2026-06-02) [India] Conspiracy director calls late star Val Kilmer worst human being Ive ever known in deleted posts
      domain: livemint.com · language: English · tone:
  - (2026-06-02) [India] Manipal Tata Medical College Marks a Historic Milestone with Its First Graduation Ceremony
      domain: indiagazette.com · language: English · tone:

### WHO Disease Outbreak News — 40 new of 40 total
  - (2026-05-29) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo and Uganda continues to evolve rapidly, with increasing case numbers, geographic spread, and ongoing cross-border transmission. As of 27…
  - (2026-05-28) Hantavirus outbreak linked to cruise ship travel, Multi-locations
      This is the fourth Disease Outbreak News report on the Andes hantavirus outbreak linked to cruise ship travel, following the notification to the World Health Organization (WHO) on 2 May 2026 of severe respiratory illness…
  - (2026-05-22) Ebola disease caused by Bundibugyo virus – Democratic Republic of the Congo
      On 15 May 2026, the Ministry of Public Health, Hygiene and Social Welfare, Democratic Republic of the Congo (DRC), and the Ministry of Health of Uganda declared an outbreak of Ebola Disease following the confirmation of…
  - (2026-05-17) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      On 5 May 2026, the World Health Organization (WHO) was alerted of a high-mortality outbreak of unknown illness in Mongbwalu Health Zone, Ituri Province, Democratic Republic of the Congo (DRC), including deaths among heal…
  - (2026-05-13) Hantavirus cluster linked to cruise ship travel, Multi-country
      This is the third Disease Outbreak News report on the hantavirus cluster, following the notification to the World Health Organization (WHO) on 2 May 2026 of severe respiratory illness cases aboard MV Hondius, a cruise sh…
  - (2026-05-08) Hantavirus cluster linked to cruise ship travel, Multi-country
      On 2 May 2026, a cluster of passengers with severe respiratory illness aboard a cruise ship was reported to the World Health Organization (WHO). At that time, according to the ship operator, 147 passengers and crew were…

### EPSS — highest exploit-probability CVEs — 40 new of 40 total
  - (2026-06-02) CVE-2023-23752: 95% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2017-8917: 95% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2018-7600: 94% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2021-22986: 94% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2018-1000861: 94% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2017-1000353: 94% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000

### Paper Trading Scorecard — 32 new of 142 total
  - (2026-06-02) [Polymarket] Will Gideon Sa’ar be the next Prime Minister of Israel?
      Legislative elections are schedule to be held in Israel on October 27, 2026. This market will resolve to the next individual who is officially appointed and sworn in as Prime Minister of Israel following the 2026 parliam…
  - (2026-06-02) [Polymarket] Will the price of Bitcoin be above $78,000 on June 3?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-06-02) [Polymarket] Will Crude Oil (CL) hit (HIGH) $120 by end of June?
      This market will resolve to "Yes" if, on any trading day, the official CME settlement price for the Active Month (front month) of Crude Oil (CL) futures is equal to or above the listed price between market creation and t…
  - (2026-06-02) [Polymarket] Croatia vs. Belgium: O/U 2.5
      In the upcoming FIFA International Friendlies game between Croatia and Belgium, scheduled for June 2 at 12:00 PM ET: This market will resolve to "Over" if Croatia and Belgium combine to score 3 or more goals in this game…
  - (2026-06-02) [Polymarket] Will Bitcoin reach $110,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "High" price equal to or gr…
  - (2026-06-02) [Polymarket] Will SHEIN have the highest IPO Market Cap 2026?
      This market will resolve to the company that achieves the highest market capitalization in U.S. dollars based on the official closing price on its first trading day in 2026. This market will resolve to a company that com…

### Court opinions of consequence (federal & state) — 31 new of 60 total
  - (2026-06-02) Supreme Court of Georgia: Almond v. State
  - (2026-06-02) Supreme Court of Georgia: Anderson v. State
  - (2026-06-02) Supreme Court of Georgia: Burden v. State
  - (2026-06-02) Supreme Court of Georgia: Clark v. State
  - (2026-06-01) U.S. Court of Appeals, 3rd Cir.: United States v. Richardson Dangleben, Jr.
  - (2026-06-01) U.S. Court of Appeals, 1st Cir.: United States v. Pilson

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-06-02) JAF8GH (Bulgaria)
      icao24: 4520ce · position: (50.5644, 2.9989) · alt: 1158m · 261km/h
  - (2026-06-02) PAT26 (United States)
      icao24: ae74ac · position: (39.3073, -76.7638) · alt: 205m · 205km/h
  - (2026-06-02) PAT319 (United States)
      icao24: adfede · position: (36.1278, -85.1796) · alt: 5478m · 433km/h
  - (2026-06-02) JAF49Y (Bulgaria)
      icao24: 4520aa · position: (41.4531, -3.4725) · alt: 10972m · 787km/h
  - (2026-06-02) CFC3742 (Canada)
      icao24: c2b369 · position: (43.9647, -76.0811) · alt: 10363m · 873km/h
  - (2026-06-02) PAT758 (United States)
      icao24: adfe4a · position: (26.5798, -79.9454) · alt: 899m · 371km/h

### Markets snapshot — 21 new of 21 total
  - (2026-06-02) [US equities] S&P 500 (SPY): 759.68 ▲ +0.15%
      close 759.68 · chg +1.14 (+0.15%) · day range 756.75–760.40
  - (2026-06-02) [US equities] Nasdaq 100 (QQQ): 745.16 ▲ +0.33%
      close 745.16 · chg +2.42 (+0.33%) · day range 739.23–745.59
  - (2026-06-02) [US equities] Russell 2000 (IWM): 291.07 ▲ +0.72%
      close 291.07 · chg +2.09 (+0.72%) · day range 288.40–291.87
  - (2026-06-02) [Intl equities] MSCI EAFE (EFA): 105.09 ▲ +0.62%
      close 105.09 · chg +0.65 (+0.62%) · day range 104.53–105.16
  - (2026-06-02) [EM equities] MSCI EM (EEM): 70.80 ▲ +1.03%
      close 70.80 · chg +0.72 (+1.03%) · day range 70.06–70.86
  - (2026-06-02) [China equities] China large-cap (FXI): 36.58 ▲ +3.51%
      close 36.58 · chg +1.24 (+3.51%) · day range 36.26–36.63

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-06-02) Roland Garros ATP: Rafael Jodar vs Alexander Zverev
      yes price: 0% · 24h volume: $7,780,758 · resolves 2026-06-09
  - (2026-06-02) LoL: ThunderTalk Gaming vs LGD Gaming (BO5) - LPL Playoffs
      yes price: 0% · 24h volume: $2,178,648 · resolves 2026-06-02
  - (2026-06-02) US x Iran permanent peace deal by June 15, 2026?
      yes price: 14% · 24h volume: $1,646,333 · resolves 2026-06-15
  - (2026-06-02) Counter-Strike: BIG vs Liquid (BO1) - IEM Cologne Major Stage 1
      yes price: 0% · 24h volume: $1,018,732 · resolves 2026-06-02
  - (2026-06-02) Will Norway win the 2026 FIFA World Cup?
      yes price: 3% · 24h volume: $942,534 · resolves 2026-07-20
  - (2026-06-02) Counter-Strike: GamerLegion vs NRG (BO1) - IEM Cologne Major Stage 1
      yes price: 100% · 24h volume: $922,938 · resolves 2026-06-02

### U.S. Federal Action — 12 new of 15 total
  - (2026-06-02) Federal Employees Health Benefits Program: Verification Requirements for Family Member Coverage
      The FEHB Protection Act of 2025 (FPA) requires OPM to issue regulations and implement a process to verify: The veracity of any qualifying life event (QLE) through which a health benefits plan enrollee seeks to add a memb…
  - (2026-06-02) Fisheries Off West Coast States; the Highly Migratory Species Fishery; Pacific Loggerhead Conservation Area Closure
      NMFS is prohibiting fishing with large-mesh drift gillnet (DGN) gear (>=14 inches mesh) off the coast of southern California east of 120[deg] W meridian from June 1, 2026, through August 31, 2026. This prohibition is bas…
  - (2026-06-02) Fisheries of the South Atlantic; 2026 Recreational Accountability Measure and Closure for Snowy Grouper in the South Atlantic
      NMFS implements an accountability measure (AM) and closure for the recreational harvest of snowy grouper in South Atlantic Federal waters. NMFS reduces the length of the snowy grouper 2026 recreational fishing season to…
  - (2026-06-02) Notice of Vacatur Regarding Certain Provisions of the 2024 Nondiscrimination in Health Programs and Activities Final Rule
      This is to inform the public that, on October 22, 2025, the United States District Court for the Southern District of Mississippi issued an order in Tennessee v. Kennedy, No. 1:24-cv-161-LG-BWR (S.D. Miss. Oct. 22, 2025)…
  - (2026-06-02) New Mailing Standards for Domestic Mailing Services Products
      On April 9, 2026, the Postal Service (USPS) filed a notice of mailing services price adjustments with the Postal Regulatory Commission (PRC), effective July 12, 2026. This final rule contains the revisions to Mailing Sta…
  - (2026-06-02) Payment Limitation and Payment Eligibility
      This rule revises the payment limitation and payment eligibility regulations to conform with provisions of the One Big Beautiful Bill Act (OBBBA). This rule also makes additional changes to those regulations to improve p…

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-02) [China] Gold firms , silver jumps as oil slips on Iran talks - Kitco AM Report
      kitco.com · English
  - (2026-06-02) [China] How in - flight ads benefit from captive audiences
      emarketer.com · English
  - (2026-06-02) [China] Euro zone inflation jump reinforces case for June rate hike
      kitco.com · English
  - (2026-06-02) [China] IMF flags central bank independence gaps across Middle East , Central Asia
      kitco.com · English
  - (2026-06-02) [China] 【 大美广东 】 Traditional Dragon Boat Arrives in Downtown Foshan传统龙船从河涌 游 入佛山市中心
      ysln.ycwb.com · English
  - (2026-06-02) [China] 【 大美广东 】 Explore Intangible Cultural Heritage with Dear You : Emotions in Light and Shadow大美岭南
      ysln.ycwb.com · English

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-06-02) #29 Robin Zeng — $67.87B
      Hong Kong · Energy · source: Batteries · holdings: 300750-CN(SHENZHEN)
  - (2026-06-02) MOVER ▲ Michael Dell — $258.87B (+$57.48B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-06-02) MOVER ▲ Larry Ellison — $292.27B (+$52.67B since yesterday)
      United States · Technology · source: Oracle
  - (2026-06-02) MOVER ▼ Larry Page — $301.14B ($-10.35B since yesterday)
      United States · Technology · source: Google
  - (2026-06-02) MOVER ▲ Masayoshi Son — $100.39B (+$10.11B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-06-02) MOVER ▼ Sergey Brin — $277.74B ($-9.51B since yesterday)
      United States · Technology · source: Google

### USGS earthquakes (M4.5+, past day) — 10 new of 10 total
  - (2026-06-01) M 6.2 - 22 km WSW of Scarcelli, Italy
      M6.2 · 22 km WSW of Scarcelli, Italy · depth 243 km
  - (2026-06-01) M 5.4 - 207 km WNW of Abepura, Indonesia
      M5.4 · 207 km WNW of Abepura, Indonesia · depth 29.55 km
  - (2026-06-02) M 4.9 - 278 km WNW of Houma, Tonga
      M4.9 · 278 km WNW of Houma, Tonga · depth 543.651 km
  - (2026-06-02) M 4.7 - 48 km E of Farkhār, Afghanistan
      M4.7 · 48 km E of Farkhār, Afghanistan · depth 200.185 km
  - (2026-06-02) M 4.6 - 232 km E of Levuka, Fiji
      M4.6 · 232 km E of Levuka, Fiji · depth 617.751 km
  - (2026-06-02) M 4.6 - northern Mid-Atlantic Ridge
      M4.6 · northern Mid-Atlantic Ridge · depth 10 km

### Macro indicators — latest values (FRED) — 6 new of 6 total
  - (2026-05-29) [Rates] Fed Funds Effective Rate (DFF)
      latest: 3.62 as of 2026-05-29
  - (2026-05-29) [Rates] 2-Year Treasury (DGS2)
      latest: 3.98 as of 2026-05-29
  - (2026-04-01) [Inflation] CPI Core (ex food & energy, SA) (CPILFESL)
      latest: 335.423 as of 2026-04-01
  - (2026-04-01) [Inflation] Core PCE (PCEPILFE)
      latest: 129.63 as of 2026-04-01
  - (2026-05-27) [Money] Fed balance sheet (total assets) (WALCL)
      latest: 6704383 as of 2026-05-27
  - (2026-04-01) [Money] M2 money supply (M2SL)
      latest: 22804.5 as of 2026-04-01

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 108 total
  - (2026-06-01) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control, and FTI Consulting, Inc. - Office of Foreign Assets Control (.gov)
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control, and FTI Consulting, Inc. Office of Foreign Assets Control (.gov)
  - (2026-06-01) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-06-01) [OFAC] Introduction to the Office of Foreign Assets Control - Office of Foreign Assets Control (.gov)
      Introduction to the Office of Foreign Assets Control Office of Foreign Assets Control (.gov)
  - (2026-06-02) [UN Sanctions] page checksum 1bd12e7cb6e6
      Active UN Security Council sanctions committees page snapshot

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-06-02) [Marginal Revolution] Tuesday assorted links
      1. Chaucerian John Fleming has passed away. 2. Can we agree to disagree? 3. The viral Wemby video. 4. New dark output from AI? 5. Should Florida eliminate property taxes for most residents? 6. Observations on quantum com…
  - (2026-06-02) [Marginal Revolution] The US Exports Intelligence
      Most Americans work in the service sector so it’s not surprising that most export-related jobs are in the service sector (The U.S. exports about $2.2 trillion of goods and $1.2 trillion of services, but services are more…
  - (2026-06-02) [Marginal Revolution] *The Republic of Love*
      The author is Martha C. Nussbaum, and the subtitle is Opera & Political Freedom. Martha decided she did not wish to do a podcast after all, so since I put some real prep time in I thought I would offer some thoughts on t…

### Congressional STOCK Act Trades (House + Senate) — 1 new of 41 total
  - (2026-05-28) [House] Christian D. Menefee (D): Sale PINS ($15,001 - $50,000) (excess -0.5% vs SPY)
      Member: Christian D. Menefee (D, house). BioGuide: M001245. Asset: PINS (ST). Type: Sale. Amount range: $15,001 - $50,000. Transaction date: 2026-05-28. Disclosure date: 2026-06-01. Excess return vs SPY since disclosure:…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 16 total
  - (2026-06-01) CVE-2024-21182 · Oracle WebLogic Server: Oracle WebLogic Server Unspecified Vulnerability
      vendor: Oracle · product: WebLogic Server · CISA remediation by 2026-06-04

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=30, 14d-median=30; carrying terms: regulatory, requires, authorized, program, event, marine, order, coast, personnel, specifically, certain, safety
- state_bills: today=153, 7d-median=153, 14d-median=153; carrying terms: recognize, funding, hotline, unlawful, requires, approve, homeowners, governs, policies, private, violence, completion
- state_news: today=550, 7d-median=695, 14d-median=695; carrying terms: funding, companies, requires, increases, needs, navigate, granted, raising, hawaii, dropped, policies, legal
- local_news: today=243, 7d-median=246, 14d-median=246; carrying terms: accused, swedish, woman, uxpqoxc, vzwxachbzy, arrested, dsbhzzzxgyckrzuy, across, cbmixkfvx, missing, larger, coming
- foreign_news: today=837, 7d-median=860, 14d-median=860; carrying terms: middle, alleged, accused, companies, conflict, needs, dropped, opposing, legal, private, counterpart, garrison
- chinese_internal: today=268, 7d-median=269, 14d-median=269; carrying terms: cbmixkfvx, cbmiykfvx, lxtfb, cbmibkfvx, rally, target, cbmiyefvx, cbmib, https, google, cbmickfvx, cbmidefvx
- russian_internal: today=952, 7d-median=952, 14d-median=952; carrying terms: press, associated, axios, reuters, international, istories, group, roland, journal, politico, disney, tasnim
- ukrainian_internal: today=119, 7d-median=122, 14d-median=122; carrying terms: alleged, conflict, diplomatic, armed, woman, eastern, focused, wounded, struck, network, triggered, poland
- ukraine_theater: today=271, 7d-median=308, 14d-median=308; carrying terms: middle, wvzjuagpwodn, companies, conflict, volunteers, uvkhwlvfkutdhbkx, needs, uzfgmvzkdxuxme, jxamxtzg, requests, fplxg, dpuuhis
- paper_bets: today=142, 7d-median=141, 14d-median=141; carrying terms: largest, officially, manifold, approve, otherwise, predictit, erupt, verve, market, final, succeed, pennsylvania
- weather: today=81, 7d-median=112, 14d-median=112; carrying terms: normal, monitoring, coastal, friday, louis, especially, tampa, ocean, depth, until, rivers, pontiac
- macro: today=6, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: price, australia, index, equity, coffee, china, sugar, nikkei, brazil, kospi, japan, france
- sanctions_procurement: today=108, 7d-median=100, 14d-median=100; carrying terms: middle, authorities, space, zhang, active, boeing, armed, launch, eastern, contract, unauthorised, legislation
- congressional_trades: today=41, 7d-median=1, 14d-median=1
- billionaires: today=40, 7d-median=35, 14d-median=35
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: bondi, blanche, transport, america, vasquez, smith, group, fernandez, ortiz, castillo, flowers, foods
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, issuer, reporting, accno, financial, group, filer, chase, jpmorgan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cortez, warner, senate, receipts, joshua, filing, congress, cooper, booker, sherrod, graham, alexandria
- gdelt_regions: today=12, 7d-median=46, 14d-median=46
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: nigeria, kingdom, india, israel, english, language, domain
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=0, 14d-median=8; carrying terms: position, kingdom, bulgaria, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: following, denial, traversal, explorer, microsoft, service, based, directory, premise, bypass, adobe, trend
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=96, 7d-median=96, 14d-median=96
- usgs_quakes: today=10, 7d-median=10, 14d-median=10
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: world, permanent, price, peace, volume, resolves, bitcoin, ivory, scotland, coast, garros, roland
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: marginal, class, conversable, revolution, https, economist, policy, links, marginalrevolution, assorted, people, monetary
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: aguilar, schmidt, janice, davis, jahana, zinke, rivas, comptroller, samuel, becca, fischer, derrick
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, identify, placed, module, decision, sufficient, placement, paper, evidence, unavailable, market, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*