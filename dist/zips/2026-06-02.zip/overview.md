# WORLDSCOPE morning brief — 2026-06-02

## Headline
3320 new items across 31 active section(s) (of 41 tracked).

## Top movers today
Russian Internal News (state + in-exile) (663) · International News + Multilateral Institutions (633) · State-Level News (384) · World leaders & government officials (324) · Chinese Internal News (235) · Local News: St. Louis + Atlanta (219) · State Legislative Action (145) · Ukraine Theater (total-war monitoring) (116) · GDACS — global disaster alerts (96) · U.S. Weather + Severe / Climate Outlooks (87) · Ukrainian Internal News (national + local Kyiv) (66) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Russian Internal News (state + in-exile) — 663 new of 964 total
  - (2026-06-02) На заправках в Белгородской и Курской областях начали ограничивать продажу бензина | LEDE: В нескольких округах Белгородской области на заправках «Роснефти» перестали наливать бензин АИ-92 в] (ru: На…
      В нескольких округах Белгородской области на заправках «Роснефти» перестали наливать бензин АИ-92 в канистры. Об этом изданию «Пепел» сообщили жители Корочанского, Алексеевского, Яковлевского и других округов.
  - (2026-06-02) «М.Видео» выпустила ИИ-рекламу, в которой Пригожин катапультируется с самолета. Но не тот Пригожин, о котором можно было подумать | LEDE: Сеть магазинов бытовой техники и электроники «М.Виде] (ru: «М.…
      Сеть магазинов бытовой техники и электроники «М.Видео» выпустила рекламу распродажи White Friday. Лицами акции стали продюсер Иосиф Пригожин и его жена, певица Валерия, которые «приглашают покупателей отправиться в полет…
  - (2026-06-02) Украинская армия за пару недель превратила трассу на Крым в дорогу смерти — все благодаря новым «умным» дронам. БПЛА делают опасной зону даже в 100 километрах от линии фронта. Чем ответят ВС РФ] (ru:…
      В Крыму — топливный кризис. Все из-за новой волны атак ВСУ на бензовозы и другие грузовые автомобили, снабжающие аннексированный полуостров по трассе Р-280 «Новороссия». Еще пару месяцев назад эта дорога считалась относи…
  - (2026-06-02) В Беларуси обыски у студентов Европейского гуманитарного университета (он объявлен «экстремистским»). Им угрожают репрессиями, если они не отчислятся | LEDE: В Беларуси проходят обыски и доп] (ru: В Б…
      В Беларуси проходят обыски и допросы в рамках уголовного дела о сотрудничестве с Европейским гуманитарным университетом (ЕГУ), сообщила правозащитная организация «Вясна».
  - (2026-06-02) Трамп назначил директором разведки главу федерального ипотечного агентства Билла Пулте. В разведке у него нет никакого опыта | LEDE: Глава Федерального агентства жилищного финансирования (FH] (ru: Тра…
      Глава Федерального агентства жилищного финансирования (FHFA) США Билл Пулте будет исполнять обязанности директора Национальной разведки, сообщил президент страны Дональд Трамп.
  - (2026-06-02) В Польше вернулся на трассу автобус № 666 в город Хель. Шутки про Highway to Hel, конечно же, тоже вернулись. Три года назад номер «адского» маршрута поменяли из-за жалоб верующих | LEDE: В ] (ru: В П…
      В Польше перезапустили автобусный маршрут № 666 в курортный город Хель, расположенный на одноименном полуострове на побережье Балтийского моря. Новым оператором маршрута станет немецкая транспортная компания Flixbus, кот…

### International News + Multilateral Institutions — 633 new of 844 total
  - (2026-06-02) [Global] Trump signs order allowing AI companies to give government access to models before release
      President Donald Trump on Tuesday signed an executive order to enable leading AI developers to voluntarily ​submit their most capable models for government cybersecurity tests before releasing them to the public. The ord…
  - (2026-06-02) [Global] Fifteen years on, the Dupont de Ligonnès case still haunts France
      For more than 15 years, the fate of Xavier Dupont de Ligonnès has remained one of France’s biggest mysteries. The 50-year-old is suspected of having murdered his entire family and burying them in concrete under their hom…
  - (2026-06-02) [Global] 1994 Tutsi Genocide: 'French government has never fully come to terms with its involvement'
      Annette Young is pleased to welcome Phil Clark, Professor of International Politics at SOAS University of London. He specialises in conflict and post-conflict issues. As French President Emmanuel Macron and Rwandan Presi…
  - (2026-06-02) [Global] US, Iran: Washington keeps 'chasing the perfect war'
      No lessons learned:The Quincy Institute's Adam Weinstein tells #F24Debate Washington keeps chasing the fantasy of a 'quick and easy' war abroad ➡️https://f24.my/BxciRead the full article⤵️https://quincyinst.org/2026/05/0…
  - (2026-06-02) [Global] REPLAY: Rubio faces Senate grilling over Trump's foreign policy
      Secretary of State Marco Rubio told lawmakers Tuesday in his first public testimony since the Iran war began that the Iranians have agreed to negotiate on nuclear points that they had not been willing to address in the p…
  - (2026-06-02) [Global] Macron, Kagame inaugurate Paris memorial honouring victims of the Rwandan genocide
      Rwanda's President Paul Kagame is in Paris with President Emmanuel Macron for the inauguration of a new memorial site dedicated to the victims of the 1994 Genocide against the Tutsis. More than one million Tutsis were ki…

### State-Level News — 384 new of 576 total
  - (2026-06-02) [California] Las votaciones en California terminan el martes. ¿Los resultados? No los esperes pronto
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/110524-Election-Fresno_LV_CM_09.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-06-02) [California] California celebra las primarias para gobernador más inciertas de los últimos años
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426-May-Budget-Revise-MG-CM-07.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-06-02) [California] California elige a su próximo comisionado de seguros en medio de crisis por incendios forestales
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/010925_Eaton-Fire_AP_CM_01-1.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…
  - (2026-06-02) [California] ¿Quién dirigirá las escuelas de California? Los votantes eligen al próximo superintendente estatal
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/111925-School-PowerShutoff-KG-CM-05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-06-02) [California] Who will lead California schools? Voters choose next state superintendent
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/111925-School-PowerShutoff-KG-CM-05.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-06-02) [California] California chooses its next insurance watchdog amid wildfire crisis
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/010925_Eaton-Fire_AP_CM_01-1.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 235 new of 270 total
  - (2026-06-02) “我儿子5岁就能来山姆”，宝妈含泪道歉：只是跟风玩梗，没有崇洋媚外-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5VcHNfM19ZaldpejE5UlBRYkJNUU1aWENFS3dPZ2oxbFlOakZneU5fbXVCWVh5cE5QUDQ0WTQ5N2plRF] (zh:…
      “我儿子5岁就能来山姆”，宝妈含泪道歉：只是跟风玩梗，没有崇洋媚外-观察者网 观察者
  - (2026-06-02) 小泉进次郎：大家都说“日本真是世界典范啊” - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFBmTmV0ZXZiMHIySjBNT3kyUWNsWTBCR0Q4TEVra183WHZULU13eHBES1FMQ2xfd2dPc1dzVkZtUG12aFAyVVNZY1JFZGZKdXpD] (zh:…
      小泉进次郎：大家都说“日本真是世界典范啊” 风闻
  - (2026-06-02) Agentic AI时代，网络到底应该长什么样？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBZbkpraktfLTM5VWNhbFJqel95VDk4ZzVTeWpxXy1XWWljQmZuM08tNHJPM01EazdIWXd4QnVpcHl5WWNDOVlFWkRLRDVWZ] (zh:…
      Agentic AI时代，网络到底应该长什么样？ 风闻
  - (2026-06-01) “一车安全带全是P上去的”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFA4bnpzRnFPYXRqM0RaSGNadjFKbDVTN19ScjdMTnYyNTBkOGxkbHpuSnhJbkVjN3dEWmJlVzMwT0JneVRheHFkaG5hT3YxZU9xek] (zh:…
      “一车安全带全是P上去的”-观察者网 观察者
  - (2026-06-02) 礼赞社科大师｜王蘧常：不求一时誉，当期千载知 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5fWDBrRkh4OEVfSGRIVDVKczFiUENGNzNXTHNXUjFMM2xqZVg3bXJQZGFvYm1KSUpqMUR1dmh3ekhSVS1Va1Rrc3V2dUJkMl] (zh:…
      礼赞社科大师｜王蘧常：不求一时誉，当期千载知 观察者
  - (2026-06-02) 网暴救灾村干部“戴金耳环” ，相关网民被处罚-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE05dFV2TnhRSkdzb0JlWEc2dFpPZlNSX1FyTGxtdkVLQnRESTAxTklRbGlhclpPNGd5dmVWeWZjU29iOG44eVM5M1MwU] (zh:…
      网暴救灾村干部“戴金耳环” ，相关网民被处罚-观察者网 观察者

### Local News: St. Louis + Atlanta — 219 new of 249 total
  - (2026-06-02) [St. Louis] Ben & Jerry's reveals fate of Stephen Colbert ice cream
      Stephen Colbert's late-night reign may have come with an expiration date, but a Ben & Jerry's pint created in his image will live on forever.
  - (2026-06-02) [St. Louis] 2020010_N18.jpg
  - (2026-06-02) [St. Louis] 2020010_N19.jpg
  - (2026-06-02) [St. Louis] 2020010_N30.jpg
  - (2026-06-02) [St. Louis] 2020010_N18.jpg
  - (2026-06-02) [St. Louis] 2020010_N19.jpg

### State Legislative Action — 145 new of 155 total
  - (2026-06-02) [Alaska HB 176] An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date…
      An Act relating to notice of new fees and fee increases from the University of Alaska; relating to billing statements from the University of Alaska; and providing for an effective date.
  - (2026-06-02) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…
  - (2026-06-02) [Alaska SB 130] An Act relating to the fisheries product development tax credit; providing for an effective date by amending the effective date of sec. 2, ch. 31, SLA 2022; and providing for an effect…
      An Act relating to the fisheries product development tax credit; providing for an effective date by amending the effective date of sec. 2, ch. 31, SLA 2022; and providing for an effective date.
  - (2026-06-02) [Alaska SB 143] An Act relating to ethics and budget training for school board members; relating to the terms of office of municipal school board members; relating to the size of the city council in s…
      An Act relating to ethics and budget training for school board members; relating to the terms of office of municipal school board members; relating to the size of the city council in second class cities; and providing fo…
  - (2026-06-02) [Alaska HB 13] An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobi…
      An Act relating to optional municipal property tax exemptions for real property owned and occupied by volunteer certified or licensed providers of fire fighting, emergency medical, mobile intensive care paramedic service…
  - (2026-06-02) [Alaska HB 36] An Act relating to treatment foster homes; relating to the placement of foster children in hospitals and residential psychiatric treatment centers for psychiatric care; relating to the…
      An Act relating to treatment foster homes; relating to the placement of foster children in hospitals and residential psychiatric treatment centers for psychiatric care; relating to the duties of the Department of Family…

### Ukraine Theater (total-war monitoring) — 116 new of 271 total
  - (2026-06-02) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-02) [Liveuamap] Overnight Russia launched 8 3M22 Tsyrkon missiles, 33 Iskander-M ballistic missiles, 27 cruise missiles Kh-101, 5 cruise missiles Kaliber and 656 drones of different types, - Ukrainian Air…
      Overnight Russia launched 8 3M22 Tsyrkon missiles, 33 Iskander-M ballistic missiles, 27 cruise missiles Kh-101, 5 cruise missile
  - (2026-06-02) [Liveuamap] Lebanon's official Six killed in Israeli airstrikes on the towns of Breqa, Toul, Harouf, and Shoukin in southern Lebanon. - Liveuamap
      Lebanon's official Six killed in Israeli airstrikes on the towns of Breqa, Toul, Harouf, and Shoukin in souther
  - (2026-06-02) [Liveuamap] Netanyahu: The regime in Iran will eventually fall. Jerusalem, Jerusalem District - iran.liveuamap.com
      Netanyahu: The regime in Iran will eventually fall. Jerusalem, Jerusalem District
  - (2026-06-02) [Liveuamap] Two dead and 14 wounded in the toll from the raids on Burj al-Shamali - Liveuamap
      Two dead and 14 wounded in the toll from the raids on Burj al-Shamali Liveu
  - (2026-06-02) [Liveuamap] Israeli Defense Minister: The Lebanese government and all relevant parties have been informed that an attack on Israeli settlements will be met with an attack on the southern suburbs of Be…
      Israeli Defense Minister: The Lebanese government and all relevant parties have been informed that an attack on Isra

### GDACS — global disaster alerts — 96 new of 96 total
  - (2025-11-21) [Orange] Drought in Madagascar
      Drought · Orange alert · Madagascar · Medium impact for agricultural drought in 311371 km2
  - (2025-11-21) [Orange] Drought in Madagascar
      Drought · Orange alert · Madagascar · Medium impact for agricultural drought in 311371 km2
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-19) [Green] Flood in United States
      Flood · Green alert · United States · Magnitude 0
  - (2026-05-29) [Green] Flood in Germany
      Flood · Green alert · Germany · Magnitude 0

### U.S. Weather + Severe / Climate Outlooks — 87 new of 89 total
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 12:50PM CDT by NWS Shreveport LA
      At 1250 PM CDT, Doppler radar was tracking a line of strong thunderstorms extending from 13 miles northeast of Blevins to over Ashdown, or extending from 15 miles north of Prescott to over Ashdown, moving southeast at 20…
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 11:49AM MDT by NWS Albuquerque NM
      At 1149 AM MDT, Doppler radar was tracking a strong thunderstorm 7 miles southwest of Conchas Lake State Park, or 30 miles west of Tucumcari, moving west at 5 mph. HAZARD...Wind gusts of 50 to 55 mph and nickel size hail…
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 11:49AM MDT by NWS El Paso Tx/Santa Teresa NM
      At 1149 AM MDT, Doppler radar was tracking a strong thunderstorm over Silver Lake, moving north at 10 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock…
  - (2026-06-02) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 12:46PM CDT by NWS Fort Worth TX
      At 1246 PM CDT, Doppler radar was tracking a strong thunderstorm near Itasca and another near Covington, moving southwest at 5 mph. HAZARD...Winds in excess of 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could…
  - (2026-06-02) [Moderate] Special Weather Statement: Special Weather Statement issued June 2 at 12:45PM CDT by NWS Shreveport LA
      At 1245 PM CDT, Doppler radar was tracking a strong thunderstorm over Village, or 11 miles east of Magnolia, moving south at 10 mph. HAZARD...Wind gusts up to 50 mph and penny size hail. SOURCE...Radar indicated. IMPACT.…

### Ukrainian Internal News (national + local Kyiv) — 66 new of 122 total
  - (2026-06-02) Зеленський: Ми знаємо від розвідки, що масований удар може бути і цієї ночі | LEDE: Президент України Володимир Зеленський попередив, що росіяни можуть вчинити новий масований удар.] (uk: Зеленський:…
      Президент України Володимир Зеленський попередив, що росіяни можуть вчинити новий масований удар.
  - (2026-06-02) ЗМІ: Угорщина припинить блокувати відшкодування країнам ЄС коштів за поставки зброї Україні | LEDE: Новий угорський уряд скасував вето на часткове відшкодування країнам ЄС вартості зброї, яку в] (uk:…
      Новий угорський уряд скасував вето на часткове відшкодування країнам ЄС вартості зброї, яку вони надсилають Україні.
  - (2026-06-02) Прем'єр Латвії доручить знайти рішення щодо припинення торгівлі з Росією | LEDE: ] (uk: Прем'єр Латвії доручить знайти рішення щодо припинення торгівлі з Росією)
  - (2026-06-02) У Києві підсвітили Монумент Незалежності кольорами прапора Італії | LEDE: ] (uk: У Києві підсвітили Монумент Незалежності кольорами прапора Італії)
  - (2026-06-02) До 90 зросла кількість постраждалих внаслідок масованої російської атаки по Києву | LEDE: Кількість постраждалих внаслідок російської атаки на Київ уночі 2 червня зросла до 90.] (uk: До 90 зросла кіль…
      Кількість постраждалих внаслідок російської атаки на Київ уночі 2 червня зросла до 90.
  - (2026-06-02) Опитування: бельгійці дедалі критичніше ставляться до США | LEDE: ] (uk: Опитування: бельгійці дедалі критичніше ставляться до США)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-02) 424B2 - Morgan Stanley Finance LLC (0001666268) (Filer)
      filed 2026-06-02 17:51 UTC — Filed: 2026-06-02 AccNo: 0001839882-26-027346 Size: 637 KB
  - (2026-06-02) 424B2 - MORGAN STANLEY (0000895421) (Filer)
      filed 2026-06-02 17:51 UTC — Filed: 2026-06-02 AccNo: 0001839882-26-027346 Size: 637 KB
  - (2026-06-02) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-02 17:51 UTC — Filed: 2026-06-02 AccNo: 0001213900-26-064056 Size: 3 MB
  - (2026-06-02) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-02 17:51 UTC — Filed: 2026-06-02 AccNo: 0001213900-26-064056 Size: 3 MB
  - (2026-06-02) 424B2 - Morgan Stanley Finance LLC (0001666268) (Filer)
      filed 2026-06-02 17:51 UTC — Filed: 2026-06-02 AccNo: 0001839882-26-027345 Size: 548 KB
  - (2026-06-02) 424B2 - MORGAN STANLEY (0000895421) (Filer)
      filed 2026-06-02 17:51 UTC — Filed: 2026-06-02 AccNo: 0001839882-26-027345 Size: 548 KB

### WHO Disease Outbreak News — 40 new of 40 total
  - (2026-05-29) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo and Uganda continues to evolve rapidly, with increasing case numbers, geographic spread, and ongoing cross-border transmission. As of 27…
  - (2026-05-28) Hantavirus outbreak linked to cruise ship travel, Multi-locations
      This is the fourth Disease Outbreak News report on the Andes hantavirus outbreak linked to cruise ship travel, following the notification to the World Health Organization (WHO) on 2 May 2026 of severe respiratory illness…
  - (2026-05-22) Ebola disease caused by Bundibugyo virus – Democratic Republic of the Congo
      On 15 May 2026, the Ministry of Public Health, Hygiene and Social Welfare, Democratic Republic of the Congo (DRC), and the Ministry of Health of Uganda declared an outbreak of Ebola Disease following the confirmation of…
  - (2026-05-17) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      On 5 May 2026, the World Health Organization (WHO) was alerted of a high-mortality outbreak of unknown illness in Mongbwalu Health Zone, Ituri Province, Democratic Republic of the Congo (DRC), including deaths among heal…
  - (2026-05-13) Hantavirus cluster linked to cruise ship travel, Multi-country
      This is the third Disease Outbreak News report on the hantavirus cluster, following the notification to the World Health Organization (WHO) on 2 May 2026 of severe respiratory illness cases aboard MV Hondius, a cruise sh…
  - (2026-05-08) Hantavirus cluster linked to cruise ship travel, Multi-country
      On 2 May 2026, a cluster of passengers with severe respiratory illness aboard a cruise ship was reported to the World Health Organization (WHO). At that time, according to the ship operator, 147 passengers and crew were…

### EPSS — highest exploit-probability CVEs — 40 new of 40 total
  - (2026-06-02) CVE-2023-23752: 95% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2017-8917: 95% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2018-7600: 94% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2021-22986: 94% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2018-1000861: 94% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000
  - (2026-06-02) CVE-2017-1000353: 94% exploit probability (p100.0)
      EPSS 0.945 · percentile 1.000

### Paper Trading Scorecard — 38 new of 148 total
  - (2026-06-02) [Polymarket] Will Gideon Sa’ar be the next Prime Minister of Israel?
      Legislative elections are schedule to be held in Israel on October 27, 2026. This market will resolve to the next individual who is officially appointed and sworn in as Prime Minister of Israel following the 2026 parliam…
  - (2026-06-02) [Polymarket] T20 Scotland Tri-Series, Women: Scotland vs Bangladesh
      This market refers to the cricket match between Scotland and Bangladesh scheduled for June 2 2026 in T20 Scotland Tri-Series, Women. This market resolves according to the finalized match result as published by https://ww…
  - (2026-06-02) [Polymarket] Will Bitcoin reach $110,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "High" price equal to or gr…
  - (2026-06-02) [Polymarket] Will Marta Kostyuk win the 2026 Women’s French Open?
      The 2026 French Open is scheduled for May 18 - June 7, 2026. This market will resolve to the player that wins the 2026 French Open Women’s Singles Tournament. If at any point it becomes impossible for a listed player to…
  - (2026-06-02) [Polymarket] Will SHEIN have the highest IPO Market Cap 2026?
      This market will resolve to the company that achieves the highest market capitalization in U.S. dollars based on the official closing price on its first trading day in 2026. This market will resolve to a company that com…
  - (2026-06-02) [Polymarket] Will France win Group I in the 2026 FIFA World Cup?
      This market will resolve according to the team that wins Group I in the 2026 FIFA World Cup group stage, scheduled for June 11-27, 2026. If multiple teams tie as group winners, this market will resolve according to the o…

### Court opinions of consequence (federal & state) — 33 new of 60 total
  - (2026-06-02) U.S. Court of Appeals, 9th Cir.: United States v. $1,106,775 in US Currency
  - (2026-06-02) Supreme Court of Georgia: Almond v. State
  - (2026-06-02) Supreme Court of Georgia: Anderson v. State
  - (2026-06-02) Supreme Court of Georgia: Burden v. State
  - (2026-06-02) Supreme Court of Georgia: Clark v. State
  - (2026-06-02) U.S. Court of Appeals, Federal Cir.: Agi Suretrack LLC v. Farmers Edge Inc.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-06-02) JAF8GH (Bulgaria)
      icao24: 4520ce · position: (36.1331, -4.9065) · alt: 11277m · 885km/h
  - (2026-06-02) PAT217 (United States)
      icao24: adfeda · position: (36.7549, -78.9705) · alt: 6598m · 497km/h
  - (2026-06-02) CFC3418 (Canada)
      icao24: c2c363 · position: (44.168, -75.9238) · alt: 6172m · 663km/h
  - (2026-06-02) PAT758 (United States)
      icao24: adfe4a · position: (27.9331, -81.4383) · alt: 7924m · 441km/h
  - (2026-06-02) PAT473 (United States)
      icao24: adfe92 · position: (34.4241, -119.6579) · alt: 4008m · 382km/h
  - (2026-06-02) PAT211 (United States)
      icao24: adfe8d · position: (37.3423, -84.1525) · alt: 8229m · 564km/h

### Markets snapshot — 21 new of 21 total
  - (2026-06-02) [US equities] S&P 500 (SPY): 759.28 ▲ +0.10%
      close 759.28 · chg +0.74 (+0.10%) · day range 756.75–760.40
  - (2026-06-02) [US equities] Nasdaq 100 (QQQ): 744.58 ▲ +0.25%
      close 744.58 · chg +1.84 (+0.25%) · day range 739.23–746.23
  - (2026-06-02) [US equities] Russell 2000 (IWM): 290.93 ▲ +0.67%
      close 290.93 · chg +1.95 (+0.67%) · day range 288.40–291.87
  - (2026-06-02) [Intl equities] MSCI EAFE (EFA): 104.73 ▲ +0.28%
      close 104.73 · chg +0.29 (+0.28%) · day range 104.53–105.16
  - (2026-06-02) [EM equities] MSCI EM (EEM): 70.49 ▲ +0.58%
      close 70.49 · chg +0.41 (+0.58%) · day range 70.06–70.86
  - (2026-06-02) [China equities] China large-cap (FXI): 36.38 ▲ +2.94%
      close 36.38 · chg +1.04 (+2.94%) · day range 36.26–36.63

### U.S. Federal Action — 12 new of 15 total
  - (2026-06-02) Federal Employees Health Benefits Program: Verification Requirements for Family Member Coverage
      The FEHB Protection Act of 2025 (FPA) requires OPM to issue regulations and implement a process to verify: The veracity of any qualifying life event (QLE) through which a health benefits plan enrollee seeks to add a memb…
  - (2026-06-02) Fisheries Off West Coast States; the Highly Migratory Species Fishery; Pacific Loggerhead Conservation Area Closure
      NMFS is prohibiting fishing with large-mesh drift gillnet (DGN) gear (>=14 inches mesh) off the coast of southern California east of 120[deg] W meridian from June 1, 2026, through August 31, 2026. This prohibition is bas…
  - (2026-06-02) Fisheries of the South Atlantic; 2026 Recreational Accountability Measure and Closure for Snowy Grouper in the South Atlantic
      NMFS implements an accountability measure (AM) and closure for the recreational harvest of snowy grouper in South Atlantic Federal waters. NMFS reduces the length of the snowy grouper 2026 recreational fishing season to…
  - (2026-06-02) Notice of Vacatur Regarding Certain Provisions of the 2024 Nondiscrimination in Health Programs and Activities Final Rule
      This is to inform the public that, on October 22, 2025, the United States District Court for the Southern District of Mississippi issued an order in Tennessee v. Kennedy, No. 1:24-cv-161-LG-BWR (S.D. Miss. Oct. 22, 2025)…
  - (2026-06-02) New Mailing Standards for Domestic Mailing Services Products
      On April 9, 2026, the Postal Service (USPS) filed a notice of mailing services price adjustments with the Postal Regulatory Commission (PRC), effective July 12, 2026. This final rule contains the revisions to Mailing Sta…
  - (2026-06-02) Payment Limitation and Payment Eligibility
      This rule revises the payment limitation and payment eligibility regulations to conform with provisions of the One Big Beautiful Bill Act (OBBBA). This rule also makes additional changes to those regulations to improve p…

### World News (by country, top stories) — 12 new of 12 total
  - (2026-06-02) [Japan] Silo Season 3 Trailer Promises Chaos And Time Jumps
      engadget.com · English
  - (2026-06-02) [Japan] Here what we want ( and need ) to see at Sony biggest State of Play in years
      destructoid.com · English
  - (2026-06-02) [Japan] Star Fox hands - on gameplay : Switch 2 takes flight with nostalgia trip for a new generation
      destructoid.com · English
  - (2026-06-02) [Japan] Newest wave of LEGO Pokémon sets are smaller and mercifully more affordable than launch lineup
      destructoid.com · English
  - (2026-06-02) [Japan] Google Home Speaker May Finally Launch in June 2026
      explosion.com · English
  - (2026-06-02) [Japan] 4 Essential Dental Habits to Stay on Top of
      explosion.com · English

### Prediction Markets — most-traded (Polymarket) — 12 new of 20 total
  - (2026-06-02) Roland Garros ATP: Rafael Jodar vs Alexander Zverev
      yes price: 0% · 24h volume: $7,832,132 · resolves 2026-06-09
  - (2026-06-02) US x Iran permanent peace deal by June 15, 2026?
      yes price: 14% · 24h volume: $2,441,620 · resolves 2026-06-15
  - (2026-06-02) Will Brazil win the 2026 FIFA World Cup?
      yes price: 8% · 24h volume: $1,210,682 · resolves 2026-07-20
  - (2026-06-02) Will Tunisia win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $1,094,328 · resolves 2026-07-20
  - (2026-06-02) Will England win the 2026 FIFA World Cup?
      yes price: 11% · 24h volume: $1,003,147 · resolves 2026-07-20
  - (2026-06-02) Will Portugal win the 2026 FIFA World Cup?
      yes price: 10% · 24h volume: $922,455 · resolves 2026-07-20

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-06-02) #29 Robin Zeng — $67.87B
      Hong Kong · Energy · source: Batteries · holdings: 300750-CN(SHENZHEN)
  - (2026-06-02) MOVER ▲ Larry Ellison — $295.42B (+$3.15B since yesterday)
      United States · Technology · source: Oracle
  - (2026-06-02) MOVER ▼ Michael Dell — $255.78B ($-3.09B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-06-02) MOVER ▼ Jeff Bezos — $266.00B ($-2.48B since yesterday)
      United States · Technology · source: Amazon
  - (2026-06-02) MOVER ▼ Larry Page — $299.10B ($-2.04B since yesterday)
      United States · Technology · source: Google
  - (2026-06-02) MOVER ▼ Jensen Huang — $193.09B ($-1.97B since yesterday)
      United States · Technology · source: Semiconductors

### Macro indicators — latest values (FRED) — 10 new of 10 total
  - (2026-05-29) [Rates] Fed Funds Effective Rate (DFF)
      latest: 3.62 as of 2026-05-29
  - (2026-05-29) [Rates] 2-Year Treasury (DGS2)
      latest: 3.98 as of 2026-05-29
  - (2026-06-01) [Rates] SOFR (SOFR)
      latest: 3.65 as of 2026-06-01
  - (2026-06-01) [Rates] 10y–2y Spread (recession indicator) (T10Y2Y)
      latest: 0.42 as of 2026-06-01
  - (2026-04-01) [Labor] Unemployment rate (UNRATE)
      latest: 4.3 as of 2026-04-01
  - (2026-04-01) [Labor] Nonfarm payrolls (PAYEMS)
      latest: 158736 as of 2026-04-01

### USGS earthquakes (M4.5+, past day) — 9 new of 9 total
  - (2026-06-01) M 6.2 - 22 km WSW of Scarcelli, Italy
      M6.2 · 22 km WSW of Scarcelli, Italy · depth 243 km
  - (2026-06-01) M 5.4 - 207 km WNW of Abepura, Indonesia
      M5.4 · 207 km WNW of Abepura, Indonesia · depth 29.55 km
  - (2026-06-02) M 4.9 - 278 km WNW of Houma, Tonga
      M4.9 · 278 km WNW of Houma, Tonga · depth 543.651 km
  - (2026-06-02) M 4.7 - 48 km E of Farkhār, Afghanistan
      M4.7 · 48 km E of Farkhār, Afghanistan · depth 200.185 km
  - (2026-06-02) M 4.6 - 232 km E of Levuka, Fiji
      M4.6 · 232 km E of Levuka, Fiji · depth 617.751 km
  - (2026-06-02) M 4.6 - northern Mid-Atlantic Ridge
      M4.6 · northern Mid-Atlantic Ridge · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 108 total
  - (2026-06-01) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control, and FTI Consulting, Inc. - Office of Foreign Assets Control (.gov)
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control, and FTI Consulting, Inc. Office of Foreign Assets Control (.gov)
  - (2026-06-01) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-06-01) [OFAC] Introduction to the Office of Foreign Assets Control - Office of Foreign Assets Control (.gov)
      Introduction to the Office of Foreign Assets Control Office of Foreign Assets Control (.gov)
  - (2026-06-02) [UN Sanctions] page checksum 1bd12e7cb6e6
      Active UN Security Council sanctions committees page snapshot

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 18 total
  - (2026-06-02) CVE-2022-0492 · Linux Kernel: Linux Kernel Improper Authentication Vulnerability
      vendor: Linux · product: Kernel · CISA remediation by 2026-06-05
  - (2026-06-02) CVE-2025-48595 · Android Framework: Android Framework Integer Overflow Vulnerability
      vendor: Android · product: Framework · CISA remediation by 2026-06-05
  - (2026-06-01) CVE-2024-21182 · Oracle WebLogic Server: Oracle WebLogic Server Unspecified Vulnerability
      vendor: Oracle · product: WebLogic Server · CISA remediation by 2026-06-04

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-06-02) [Marginal Revolution] Tuesday assorted links
      1. Chaucerian John Fleming has passed away. 2. Can we agree to disagree? 3. The viral Wemby video. 4. New dark output from AI? 5. Should Florida eliminate property taxes for most residents? 6. Observations on quantum com…
  - (2026-06-02) [Marginal Revolution] The US Exports Intelligence
      Most Americans work in the service sector so it’s not surprising that most export-related jobs are in the service sector (The U.S. exports about $2.2 trillion of goods and $1.2 trillion of services, but services are more…
  - (2026-06-02) [Marginal Revolution] *The Republic of Love*
      The author is Martha C. Nussbaum, and the subtitle is Opera & Political Freedom. Martha decided she did not wish to do a podcast after all, so since I put some real prep time in I thought I would offer some thoughts on t…

### Congressional STOCK Act Trades (House + Senate) — 1 new of 41 total
  - (2026-05-28) [House] Christian D. Menefee (D): Sale PINS ($15,001 - $50,000) (excess -0.5% vs SPY)
      Member: Christian D. Menefee (D, house). BioGuide: M001245. Asset: PINS (ST). Type: Sale. Amount range: $15,001 - $50,000. Transaction date: 2026-05-28. Disclosure date: 2026-06-01. Excess return vs SPY since disclosure:…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-02) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=30, 14d-median=30; carrying terms: program, enforcement, safety, order, authorized, captain, marine, needed, provide, public, vessels, guard
- state_bills: today=155, 7d-median=155, 14d-median=155; carrying terms: ballot, licenses, owner, funding, investment, administrator, existing, legislative, practice, district, calculation, awareness
- state_news: today=576, 7d-median=695, 14d-median=695; carrying terms: ballot, press, protests, claim, judge, hours, kansans, behind, warning, competing, practice, immigrant
- local_news: today=249, 7d-median=248, 14d-median=248; carrying terms: ballot, owner, judge, behind, culture, sunday, month, story, fatal, project, magazine, things
- foreign_news: today=844, 7d-median=860, 14d-median=860; carrying terms: press, claim, guideline, western, nameresolutionerror, remember, hours, nansha, route, phone, quarterly, procuratorate
- chinese_internal: today=270, 7d-median=270, 14d-median=270; carrying terms: cbmizefvx, politics, title, lxtfb, color, cbmixkfvx, people, target, cbmiyefvx, cbmiaefvx, cbmibkfvx, caixin
- russian_internal: today=964, 7d-median=964, 14d-median=964; carrying terms: press, novayagazeta, street, brent, error, associated, politico, international, client, group, journal, roland
- ukrainian_internal: today=122, 7d-median=122, 14d-median=122; carrying terms: citing, western, rhetoric, hours, hmarochos, warning, drone, warnings, babel, censor, allies, pushing
- ukraine_theater: today=271, 7d-median=308, 14d-median=308; carrying terms: press, protests, eetgs, afblsl, xutxv, netymnjfrwphatu, hours, znedfsv, judkdnz, middle, vdituxnwc, efdputjnvw
- paper_bets: today=148, 7d-median=141, 14d-median=141; carrying terms: chair, holliday, pirates, global, limits, state, nomination, chase, models, visit, following, goals
- weather: today=89, 7d-median=112, 14d-median=112; carrying terms: winds, western, america, strong, highs, deeper, hours, forestry, indicated, warning, impact, following
- macro: today=10, 7d-median=0, 14d-median=0
- markets: today=21, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79; carrying terms: lumber, sugar, china, germany, kospi, australia, japan, close, canada, cotton, india, brazil
- sanctions_procurement: today=108, 7d-median=100, 14d-median=100; carrying terms: protests, uuhzmzg, operation, middle, usmca, bissau, serious, zimbabwe, beirut, snapshot, imposed, stability
- congressional_trades: today=41, 7d-median=1, 14d-median=1
- billionaires: today=40, 7d-median=35, 14d-median=35
- people: today=0, 7d-median=324, 14d-median=324
- sanctions: today=0, 7d-median=16, 14d-median=16
- courtlistener: today=60, 7d-median=30, 14d-median=30; carrying terms: america, vasquez, blanche, smith, bondi, group, fernandez, veterans, ortiz, castillo, flowers, foods
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, issuer, reporting, financial, david, group, holdings, chase, filer, jpmorgan, michael
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, committee, raised, senate, cortez, lindsey, michael, booker, joseph, johnson, joshua, ocasio
- gdelt_regions: today=12, 7d-median=46, 14d-median=46
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=0, 14d-median=8; carrying terms: ground, position, bulgaria, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=18, 7d-median=16, 14d-median=16; carrying terms: overwrite, traversal, micro, vulnerability, overflow, buffer, denial, service, bypass, product, error, remediation
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=96, 7d-median=96, 14d-median=96
- usgs_quakes: today=9, 7d-median=9, 14d-median=9
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: permanent, peace, resolves, world, price, volume, bitcoin, garros, ivory, coast, scotland, roland
- commentary: today=5, 7d-median=6, 14d-median=6; carrying terms: marginal, economist, policy, class, conversable, https, revolution, assorted, links, marginalrevolution, subtitled, central
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: clyburn, press, jeanne, administrator, fleischmann, reserved, marsha, angus, thune, strong, hickenlooper, haridopolos
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, markets, either, paper, consensus, evidence, decision, today, module, identify, claude, placed

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026
- [2026-05-27] Fed speeches: Cook, The Opportunities and Risks AI Presents for the Economy and Financial System
- [2026-05-28] Fed speeches: Jefferson, Global Economic Developments and the U.S. Economy
- [2026-05-28] ECB press: Piero Cipollone: Money in the digital age
- [2026-05-28] ECB press: Meeting of 29-30 April 2026
- [2026-05-28] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Atlantic Union Bank and former employee of Frost Bank
- [2026-05-29] ECB press: ECB appoints three Directors General
- [2026-05-29] Fed speeches: Bowman, A Framework for Practical Monetary Policy Decision Making
- [2026-05-31] ECB press: Luis de Guindos: Interview with Expansión
- [2026-06-01] ECB press: Isabel Schnabel: From money market funds to stablecoins: lessons for central banks
- [2026-06-01] Fed speeches: Powell, Acceptance Remarks

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*