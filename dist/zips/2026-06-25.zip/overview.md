# WORLDSCOPE morning brief — 2026-06-25

## Headline
3705 new items across 29 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (805) · Russian Internal News (state + in-exile) (701) · State-Level News (397) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (298) · Chinese Internal News (236) · Local News: St. Louis + Atlanta (190) · U.S. Weather + Severe / Climate Outlooks (171) · State Legislative Action (121) · Ukrainian Internal News (national + local Kyiv) (65) · Court opinions of consequence (federal & state) (53) · IT, InfoSys & cybersecurity news (last 7 days) (46)

## What changed today
### International News + Multilateral Institutions — 805 new of 1065 total
  - (2026-06-25) [Global] Reeves backs Burnham to become next prime minister
      The chancellor throws her support behind the MP for Makerfield despite reports he could demote her if he becomes PM.
  - (2026-06-25) [Global] Oil price falls to levels not seen since before Iran war
      Energy prices have been on a wild ride since Iran responded to US and Israeli attacks by effectively closing the Strait of Hormuz.
  - (2026-06-25) [Global] I've spent 30 years in recruitment - this is how to get a job
      The recruitment agency boss shares his tips on getting noticed in a tougher jobs market.
  - (2026-06-25) [Global] Price cuts on family summer days out come into force
      The government is reducing VAT from 20% to 5% on attractions and kids' meals as schools begin to break-up.
  - (2026-06-25) [Global] Anthropic accuses Chinese rival Alibaba of illicitly extracting AI capabilities
      The firm alleged that Alibaba used fraudulent accounts to access data from its Claude AI model.
  - (2026-06-24) [Global] The legal fight to get equal pay for Germany's disabled workers
      A test case is seeking the minimum wage for 300,000 disabled people who currently get paid less.

### Russian Internal News (state + in-exile) — 701 new of 1087 total
  - (2026-06-25) Минюст РФ собирается лишить «иноагентов» права совершать безвозмездные сделки с недвижимостью и авторскими правами | LEDE: Россиянам, которых Минюст объявил «иностранными агентами», грозит д] (ru: Мин…
      Россиянам, которых Минюст объявил «иностранными агентами», грозит дальнейшее поражение в правах, пишет The Bell.
  - (2026-06-25) Война. 1583-й день. «У Зеленского дела идут неплохо. Он мужественный человек», — говорит Трамп. В Москве это вызывает «растущее раздражение» | LEDE: «Медуза» с 24 февраля 2022 года в прямом ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-06-25) Из App Store удалили VK, «Одноклассники» и Mail.ru | LEDE: Из App Store пропали несколько приложений холдинга VK, сообщает РБК 25 июня. В частности, недоступны «Дзен», VK Video, VK Мессендже] (ru: Из…
      Из App Store пропали несколько приложений холдинга VK, сообщает РБК 25 июня. В частности, недоступны «Дзен», VK Video, VK Мессенджер, VK Music, VK Знакомства.
  - (2026-06-25) В Уфе пожар в районе НПЗ. На Урале объявлена угроза атаки беспилотников | LEDE: Беспилотники Украины атаковали нефтеперерабатывающий завод в Уфе, сообщили украинские телеграм-каналы Exilenov] (ru: В У…
      Беспилотники Украины атаковали нефтеперерабатывающий завод в Уфе, сообщили украинские телеграм-каналы Exilenova+ и Supernova+, опубликовавшие несколько фото и видео с места события.
  - (2026-06-25) Жителей Москвы предупредили об отключении мобильного интернета | LEDE: Операторы мобильной связи начали присылать жителям Москвы предупреждения о том, что в городе возможно отключение интерн] (ru: Жит…
      Операторы мобильной связи начали присылать жителям Москвы предупреждения о том, что в городе возможно отключение интернета.
  - (2026-06-25) В Венесуэле за одну минуту произошли два сильных землетрясения. Разрушены жилые дома. Десятки человек погибли. Как это выглядит | LEDE: Два землетрясения магнитудой 7,2 и 7,5 произошли в Вен] (ru: В В…
      Два землетрясения магнитудой 7,2 и 7,5 произошли в Венесуэле с разницей в 38 секунд вечером 24 июня. По оценке Геологической службы США, оба землетрясения произошли в 160 километрах к западу от Каракаса, столицы страны.…

### State-Level News — 397 new of 752 total
  - (2026-06-24) [Alabama] PTSD Awareness Month
      Download
  - (2026-06-24) [Alabama] National Law Enforcement Week
      Download
  - (2026-06-24) [Alabama] Alzheimer’s & Brain Awareness Month
      Download
  - (2026-06-24) [Alabama] Amateur Radio Week
      Download
  - (2026-06-24) [Alabama] American Village
      Download
  - (2026-06-24) [Alabama] World Elder Abuse Awareness Day
      Download

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 298 new of 482 total
  - (2026-06-25) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-06-24) [FIRMS] thermal anomaly 46.474, 34.037 (FRP 15.27 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-24 0934Z, FRP 15.27 MW
  - (2026-06-24) [FIRMS] thermal anomaly 46.883, 33.732 (FRP 9.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-24 0934Z, FRP 9.02 MW
  - (2026-06-24) [FIRMS] thermal anomaly 46.881, 33.725 (FRP 9.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-24 0934Z, FRP 9.02 MW
  - (2026-06-24) [FIRMS] thermal anomaly 46.879, 33.719 (FRP 7.32 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-24 0934Z, FRP 7.32 MW
  - (2026-06-24) [FIRMS] thermal anomaly 46.887, 33.722 (FRP 9.02 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-06-24 0934Z, FRP 9.02 MW

### Chinese Internal News — 236 new of 316 total
  - (2026-06-25) 2026中国海岛（洞头）摄影嘉年华启幕，“旅拍中国”洞头分赛区同步发布 - 人民网-图片频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFA0b3h5akMwQjM1NnlzRnJTSF9LZnNlQ3plWlJZZXo5LVhyajBJZHJEaGgtRU1YRUZqUTVVa1VRbHFl] (zh:…
      2026中国海岛（洞头）摄影嘉年华启幕，“旅拍中国”洞头分赛区同步发布 人民网-图片频道
  - (2026-06-25) 河南周口创新打造"1334"校园餐管理示范范式 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFB4SklpYXBMWDdvVWc5dGRQdXhDQWp1YTF6RUx4UmtsM1BMVWhtaHZIOEV6UldEQXZMdjQtMnhMSE05YmRkN284RmJTdTh] (zh:…
      河南周口创新打造"1334"校园餐管理示范范式 人民网健康
  - (2026-06-25) 柬埔寨人民党主席、参议院主席洪森抵京访华--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibEFVX3lxTE1KTlNuQzhEUjg0algtMktSTGFZeGRXZlFmNXB4LVp3UkZJWmRnM2FBWXdJNHRqcThQTl9qOXVKdFBaaW5GMHlianR4ejhx] (zh:…
      柬埔寨人民党主席、参议院主席洪森抵京访华--国际 人民网
  - (2026-06-25) 习语丨“牢牢守住18亿亩耕地红线” - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTFBKRXJsdGNqNlFTR0FaaDBGaFVDZ1U0T0Q1dHdtd3dWVmppVG10cWc5ZG4tWEUwQmo4WVVLMWI3ck5mQ1dW] (zh:…
      习语丨“牢牢守住18亿亩耕地红线” politics.people.com.cn
  - (2026-06-24) 监测显示委内瑞拉一分钟内发生两次7级以上强震--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTFBDS3Y1bHJqZGRRTVBVS3QtNGVQN2x4WVFyajczamg2TDlkZG1rUExGR3BoQmFwdVdydFdybjAwTmxxcHRSTTZ2MXJXeV] (zh:…
      监测显示委内瑞拉一分钟内发生两次7级以上强震--国际 人民网
  - (2026-06-25) 近镜头｜总书记手中这把麦粒凝聚同心奋斗 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTE9nWnlYWERkbGppZ3Y4YXpnRW5SdHdxVVFfZXMzU1loTmZkdHVOcVo2WFI4VEt0NlZLRlIwYzhtYUF2SH] (zh:…
      近镜头｜总书记手中这把麦粒凝聚同心奋斗 politics.people.com.cn

### Local News: St. Louis + Atlanta — 190 new of 222 total
  - (2026-06-24) [St. Louis] Grant’s Farm’s new Nature Exploration Area teaches kids about the wild world in their own backyard
      At Grant’s Farm, visitors can travel past bison, feed goats, and meet animals from around the world. Now, the attraction is encouraging families to slow down and discover something a little closer to home. A new Nature E…
  - (2026-06-24) [St. Louis] Where in Clayton? – 6/25/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-06-24) [St. Louis] Blues at the Arch brings the soul of America to the Gateway Arch
      Music lovers can head to the Gateway Arch as the Blues at the Arch festival returns August 14–16. On the original site of the historic Old Rock House, the festival will pay homage to the rich blues history of St. Louis.…
  - (2026-06-24) [St. Louis] A home in Frontenac hits the market
      Island-EleganceNestled in one of St. Louis’ most coveted neighborhoods, this four-bedroom, Dutch Colonial calls to mind the architecture of Nantucket homes. Manicured landscaping surrounds the property, with an expansive…
  - (2026-06-24) [St. Louis] Tariffs hit firework shows, leading to higher costs and cancellations
      Towns across America have been preparing for years to celebrate July 4 in a big way since it falls on the 250th anniversary of America’s founding. But costly tariffs that the Trump administration slapped on Chinese-made…
  - (2026-06-24) [St. Louis] Atomic Eats turns Atomic by Jamo into a full-service destination
      The Grove will soon have a new late-night dining option, courtesy of two big players in the St. Louis food and entertainment scene. Atomic Eats (4140 Manchester), a fast-casual restaurant, will open inside Atomic by Jamo…

### U.S. Weather + Severe / Climate Outlooks — 171 new of 173 total
  - (2026-06-25) [Moderate] Special Weather Statement: Special Weather Statement issued June 25 at 5:11AM CDT by NWS Lincoln IL
      At 511 AM CDT, Doppler radar was tracking a strong thunderstorm near Hutsonville, or 12 miles north of Robinson, moving southeast at 30 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated.…
  - (2026-06-25) [Severe] Flood Warning: Flood Warning issued June 25 at 5:09AM CDT until June 25 at 3:30PM CDT by NWS Goodland KS
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Portions of northwest Kansas, including the following county, Decatur and southwest Nebraska, including the following county, Red Willow. * WHEN...Until…
  - (2026-06-25) [Moderate] Special Weather Statement: Special Weather Statement issued June 25 at 6:07AM EDT by NWS Indianapolis IN
      At 607 AM EDT, Doppler radar was tracking a strong thunderstorm 9 miles south of Marshall, moving southeast at 30 mph. HAZARD...Winds in excess of 40 mph and half inch hail. SOURCE...Radar indicated. IMPACT...Gusty winds…
  - (2026-06-25) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-06-25) [Moderate] Special Weather Statement: Special Weather Statement issued June 25 at 5:05AM CDT by NWS Goodland KS
      At 505 AM CDT, Doppler radar was tracking a strong thunderstorm 8 miles southwest of Russell Springs, or 20 miles northwest of Scott State Lake, moving northeast at 30 mph. HAZARD...Wind gusts of 50 to 55 mph and penny s…
  - (2026-06-25) [Moderate] Special Weather Statement: Special Weather Statement issued June 25 at 5:01AM CDT by NWS Lincoln IL
      At 501 AM CDT, Doppler radar was tracking a strong thunderstorm 8 miles northwest of Hutsonville, or 12 miles north of Robinson, moving southeast at 30 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...R…

### State Legislative Action — 121 new of 153 total
  - (2026-06-25) [Alaska HB 304] An Act relating to the duties of the commissioner of fish and game; establishing the sport fishing angler access account; establishing the sport fishing angler access surcharge; and pr…
      An Act relating to the duties of the commissioner of fish and game; establishing the sport fishing angler access account; establishing the sport fishing angler access surcharge; and providing for an effective date.
  - (2026-06-24) [Alaska HB 303] An Act relating to the registration and titling of legally imported motor vehicles; and providing for an effective date.
      An Act relating to the registration and titling of legally imported motor vehicles; and providing for an effective date.
  - (2026-06-24) [Alaska HB 217] An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.
      An Act relating to commercial motor vehicle licensing examinations; regulating autonomous vehicles; and providing for an effective date.
  - (2026-06-25) [Arizona SB 1015] gender transition procedures; provider liability
      gender transition procedures; provider liability
  - (2026-06-25) [Arizona SB 1012] concealed weapons; notice; repeal
      concealed weapons; notice; repeal
  - (2026-06-25) [Arizona SB 1040] voter registration rolls; internet access
      voter registration rolls; internet access

### Ukrainian Internal News (national + local Kyiv) — 65 new of 124 total
  - (2026-06-25) Генштаб: ЗСУ вночі уразили автомобільний і залізничні мости на окупованій території та РЛС у Криму | LEDE: Українські сили знищили мости, склади і нафтобазу, що забезпечували війська РФ на окуп] (uk:…
      Українські сили знищили мости, склади і нафтобазу, що забезпечували війська РФ на окупованих територіях.
  - (2026-06-25) Зеленський підтвердив удари по нафтобазі і 2 НПЗ в Уфі, що за 1500 км від фронту | LEDE: ЗСУ та СБУ атакували нафтобазу у Краснодарському краї РФ і два НПЗ в Башкортостані, що за 1500 км від фр] (uk:…
      ЗСУ та СБУ атакували нафтобазу у Краснодарському краї РФ і два НПЗ в Башкортостані, що за 1500 км від фронту, заявив Зеленський.
  - (2026-06-25) Фон дер Ляєн у Гданську оголосила про виділення Україні першого траншу з 90-мільярдного кредиту | LEDE: ЄС виділив Україні 3,2 млрд євро та анонсував фінансування виробництва дронів у рамках пр] (uk:…
      ЄС виділив Україні 3,2 млрд євро та анонсував фінансування виробництва дронів у рамках програми на 90 млрд євро.
  - (2026-06-25) "Зеленський припустився помилки. Не можна віддавати відносини з Польщею в руки радикалів" | LEDE: ] (uk: "Зеленський припустився помилки. Не можна віддавати відносини з Польщею в руки р)
  - (2026-06-25) Опитування: Майже 60% поляків не підтримують вступ України до ЄС | LEDE: За результатами опитування, 59,7% поляків не підтримують вступ України до Європейського Союзу. Водночас 35,4% респондент] (uk:…
      За результатами опитування, 59,7% поляків не підтримують вступ України до Європейського Союзу. Водночас 35,4% респондентів висловилися за членство України в блоці, найвищий рівень підтримки зафіксували серед виборців уря…
  - (2026-06-25) У ДПСУ відповіли Білорусі: У прикордонні небезпечно, Україна не випускатиме людей у чужі ліси | LEDE: Держприкордонслужба не погодиться на пропозицію Білорусі пропускати українців у білоруські ] (uk:…
      Держприкордонслужба не погодиться на пропозицію Білорусі пропускати українців у білоруські ліси для збору ягід чи грибів, бо це не небезпечно.

### Court opinions of consequence (federal & state) — 53 new of 60 total
  - (2026-06-30) Connecticut Supreme Court: Hilton v. Commissioner of Correction
  - (2026-06-24) U.S. Court of Appeals, 7th Cir.: Michael Jezior v. City of Chicago
  - (2026-06-24) U.S. Court of Appeals, 7th Cir.: Russia Brown v. CTA
  - (2026-06-24) U.S. Court of Appeals, 7th Cir.: Robert Hossfeld v. Allstate Insurance Company
  - (2026-06-24) U.S. Court of Appeals, 7th Cir.: Robert Hossfeld v. Allstate Insurance Company
  - (2026-06-24) U.S. Court of Appeals, 11th Cir.: Edward Braggs v. Commissioner, Alabama Department of Corrections

### IT, InfoSys & cybersecurity news (last 7 days) — 46 new of 57 total
  - (2026-06-25) [The Hacker News] New Mistic Backdoor Linked to KongTuke in ClickFix and ModeloRAT Campaigns
      A new, stealthy backdoor named Mistic has been deployed as part of suspected financially motivated attacks aimed at multiple organizations spanning insurance, education, IT, and professional services sectors since April…
  - (2026-06-25) [The Hacker News] Cisco Catalyst SD-WAN Zero-Day CVE-2026-20245 Exploited to Gain Root Access
      An unknown threat actor exploited a recently disclosed high-severity security flaw impacting Cisco Catalyst SD-WAN as a zero-day at least two months before it was publicly disclosed, according to new findings from Google…
  - (2026-06-25) [The Register] IBM stacks up a sub-nanometer chip future
      Big Blue shows off process node it claims can scale down to 1 Angstrom
  - (2026-06-25) [The Register] Digital ID brain trust will meet behind closed doors as minister ducks cost questions
      Minutes will not be published, and MPs still have no answer on the group's budget or how its members were chosen
  - (2026-06-25) [The Register] Salyut 5 at 50: The Soviet space station that sickened one crew and nearly drowned another
      The last inhabited Almaz outpost was short-lived, secretive, and remarkably accident-prone
  - (2026-06-25) [The Register] The CPU's growing role in agentic AI infrastructure
      PARTNER CONTENT: As agentic AI systems scale across cloud and datacenter environments, CPUs remain the control plane coordinating performance and efficiency.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-06-25) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-25 10:11 UTC — Filed: 2026-06-25 AccNo: 0001918704-26-017637 Size: 957 KB
  - (2026-06-25) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-25 10:11 UTC — Filed: 2026-06-25 AccNo: 0001918704-26-017637 Size: 957 KB
  - (2026-06-25) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-25 10:09 UTC — Filed: 2026-06-25 AccNo: 0001918704-26-017636 Size: 927 KB
  - (2026-06-25) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-25 10:09 UTC — Filed: 2026-06-25 AccNo: 0001918704-26-017636 Size: 927 KB
  - (2026-06-25) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-06-25 10:08 UTC — Filed: 2026-06-25 AccNo: 0001918704-26-017635 Size: 583 KB
  - (2026-06-25) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-06-25 10:08 UTC — Filed: 2026-06-25 AccNo: 0001918704-26-017635 Size: 583 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-06-25) [Israel] EU antisemitism czar warns against circumcision ban - Christians for Israel International
      domain: whyisrael.org · language: English · tone:
  - (2026-06-25) [United States] Senator behind SB 1 campus reform says all is well 1 year in , not all agree
      domain: daytondailynews.com · language: English · tone:
  - (2026-06-25) [Germany] HiTHIUM and Turbo Energy deploy AI - driven energy infrastructure platform across 15 industrial facilities in Europe
      domain: finanznachrichten.de · language: English · tone:
  - (2026-06-25) [United States] Pentagon Reverses Flu Shot Decision After TX Outbreak
      domain: wiba.iheart.com · language: English · tone:
  - (2026-06-25) [United Kingdom] Law & Order : Criminal Intent
      domain: tvguide.co.uk · language: English · tone:
  - (2026-06-25) [Canada] In the news today : Canada to face South Africa , calls to ban SKS , breastfeeding rates
      domain: panow.com · language: English · tone:

### U.S. Federal Action — 36 new of 37 total
  - (2026-06-25) Ushering in the Next Frontier of Quantum Innovation
  - (2026-06-25) Securing the Nation Against Advanced Cryptographic Attacks
  - (2026-06-25) Update of Procedures for Implementing the National Environmental Policy Act and Assessing the Environmental Effects Abroad of EPA Actions
      The United States Environmental Protection Agency (EPA or Agency) is proposing amendments to its procedures for implementing the requirements of the National Environmental Policy Act of 1969 (NEPA). This proposed rule wo…
  - (2026-06-25) Rescinding the Equity Assistance Center Program Regulations
      The Secretary of Education proposes to rescind the Equity Assistance Center Program regulations. The Department proposes to rescind these regulations to provide the Department greater flexibility in carrying out the stat…
  - (2026-06-25) Prohibition on the Use of Reputation Risk
      On October 21, 2025, the Board issued its Notice of Proposed Rulemaking to codify the elimination of reputation risk from its supervisory framework. This change aligns with Executive Order 14331, "Guaranteeing Fair Banki…
  - (2026-06-25) Sterigenics U.S., LLC; Filing of Food Additive Petition
      The Food and Drug Administration (FDA or we) is announcing that we have filed a food additive petition, submitted by Sterigenics U.S., LLC, proposing that we amend our food additive regulations to provide for the safe us…

### Paper Trading Scorecard — 32 new of 139 total
  - (2026-06-25) [Polymarket] Will USA win the 2026 FIFA World Cup?
      This market will resolve according to the national team that wins the 2026 FIFA World Cup. If at any point it becomes impossible for this team to win the FIFA World Cup based on the rules of FIFA (e.g., they are eliminat…
  - (2026-06-25) [Polymarket] Will Russia test a nuclear weapon by September 30 2026?
      This market will resolve to "Yes" if Russia conducts a nuclear test by the listed date (ET). Otherwise, this market will resolve to "No". A nuclear test is defined as the intentional non-combat detonation of a device by…
  - (2026-06-25) [Polymarket] Will Magdalena Andersson be the next Prime Minister of Sweden?
      Parliamentary elections are scheduled to be held in Sweden on September 13, 2026. This market will resolve to the next individual who is officially appointed and assumes office as Prime Minister of Sweden following the n…
  - (2026-06-25) [Polymarket] Will Alibaba have the best AI model at the end of July 2026?
      This market will resolve according to the company which owns the model which has the highest arena rank based off the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is chec…
  - (2026-06-25) [Polymarket] Will Satoshi's identity be revealed by June 30?
      This market will resolve to 'Yes' if the identity of Satoshi Nakamoto, the pseudonymous creator or creators of Bitcoin, is definitively proven between market creation and the listed date, 11:59 PM ET. Otherwise, this mar…
  - (2026-06-25) [Polymarket] Will Philadelphia Phillies win the 2026 NL East title?
      This market will resolve according to the team that wins the 2026 MLB National League East division. In the event of a tie, this market will resolve according to the official winner as determined by MLB rules. If multipl…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-06-25) [Israel-Iran-Hezbollah axis · themes] Preço do barril de Brent cai para os 72 dólares e toca níveis pré - guerra
      rtp.pt · Portuguese · tone NA
  - (2026-06-25) [Israel-Iran-Hezbollah axis · themes] Ban pecah : Pencuri kabel jadi dalang pam banjir lumpuh
      kosmo.com.my · Malay · tone NA
  - (2026-06-25) [Israel-Iran-Hezbollah axis · themes] युवाओं से माफी मांगें और इस्तीफा दें , छात्रों को आतंकवादी कहने के आरोप पर राहुल गांधी का शिक्षा मंत्री पर हमला - rahul gandhi targets education minister demandin…
      navbharattimes.indiatimes.com · Hindi · tone NA
  - (2026-06-25) [Israel-Iran-Hezbollah axis · themes] Страны Персидского залива не понимают , как будут развиваться отношения с США
      interfax.ru · Russian · tone NA
  - (2026-06-25) [Israel-Iran-Hezbollah axis · themes] Continue interruzioni idriche , ultimatum del Comune ad Acqualatina
      latinatoday.it · Italian · tone NA
  - (2026-06-25) [Israel-Iran-Hezbollah axis · themes] Tenor KPR Subsidi 40 Tahun Dinilai Permudah Anak Muda Sulsel Miliki Rumah
      makassar.tribunnews.com · Indonesian · tone NA

### Government & military aircraft airborne (OpenSky) — 25 new of 30 total
  - (2026-06-25) JAF9XT (Bulgaria)
      icao24: 4520ce · position: (45.3983, 5.8887) · alt: 10668m · 853km/h
  - (2026-06-25) CFC3166 (Canada)
      icao24: c2b373 · position: (52.4561, 9.6048) · alt: 10020m · 837km/h
  - (2026-06-25) SAMU44 (France)
      icao24: 39ca84 · position: (47.2093, -1.5547) · on ground · 2km/h
  - (2026-06-25) CFC2953 (Canada)
      icao24: c2b585 · position: (50.0719, 14.1467) · alt: 7315m · 568km/h
  - (2026-06-25) JAF12M (Belgium)
      icao24: 44d1ba · position: (32.4009, -14.4309) · alt: 10972m · 913km/h
  - (2026-06-25) JAF3NE (Belgium)
      icao24: 44d1a6 · position: (50.9063, 4.4966) · on ground · 9km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 106 total
  - (2026-06-24) [OFAC] Russia-related Designations Removals - Office of Foreign Assets Control (.gov)
      Russia-related Designations Removals Office of Foreign Assets Control (.gov)
  - (2026-06-25) [USASpending] $3,122,899,691 → JEFFERSON SCIENCE ASSOCIATES, LLC: TAS::89 0222::TAS MANAGEMENT AND OPERATION OF THE THOMAS JEF
      Agency: Department of Energy. Description: TAS::89 0222::TAS MANAGEMENT AND OPERATION OF THE THOMAS JEFFERSON NATIONAL ACCELERATOR FACILITY.
  - (2026-06-25) [USASpending] $1,470,526,588 → CALIFORNIA INSTITUTE OF TECHNOLOGY: DEEP SPACE NETWORK (DSN) THE CONTRACT IS THE SPONSORING AGR
      Agency: National Aeronautics and Space Administration. Description: DEEP SPACE NETWORK (DSN) THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION (NASA) AND THE CALIFORNIA IN…
  - (2026-06-25) [USASpending] $818,965,672 → CALIFORNIA INSTITUTE OF TECHNOLOGY: PSYCHE: JOURNEY TO A METAL WORLD THE CONTRACT IS THE SPONSO
      Agency: National Aeronautics and Space Administration. Description: PSYCHE: JOURNEY TO A METAL WORLD THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION (NASA) AND THE CALIF…
  - (2026-06-25) [USASpending] $801,618,105 → THE GEO GROUP, INC.: DETENTION SERVICES - SAN DIEGO
      Agency: Department of Justice. Description: DETENTION SERVICES - SAN DIEGO
  - (2026-06-25) [USASpending] $599,989,351 → NORIDIAN HEALTHCARE SOLUTIONS, LLC: A/B MAC JURISDICTION E
      Agency: Department of Health and Human Services. Description: A/B MAC JURISDICTION E

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-06-24) M 7.5 - 28 km SE of Yumare, Venezuela
      M7.5 · 28 km SE of Yumare, Venezuela · depth 10 km · PAGER red
  - (2026-06-24) M 7.2 - 23 km SE of Yumare, Venezuela
      M7.2 · 23 km SE of Yumare, Venezuela · depth 20.294 km · PAGER red
  - (2026-06-24) M 6.9 - 30 km ENE of Kuji, Japan
      M6.9 · 30 km ENE of Kuji, Japan · depth 50.923 km
  - (2026-06-24) M 5.6 - 11 km N of Redwood Valley, CA
      M5.59 · 11 km N of Redwood Valley, CA · depth 8.85 km · PAGER yellow
  - (2026-06-25) M 5.4 - 58 km E of Kokopo, Papua New Guinea
      M5.4 · 58 km E of Kokopo, Papua New Guinea · depth 52.51 km
  - (2026-06-25) M 5.1 - 152 km N of Caluula, Somalia
      M5.1 · 152 km N of Caluula, Somalia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-06-25) Will South Korea win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $9,359,290 · resolves 2026-07-20
  - (2026-06-25) Will Bosnia-Herzegovina win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $8,452,820 · resolves 2026-07-20
  - (2026-06-25) Will Canada win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $7,104,138 · resolves 2026-07-20
  - (2026-06-25) Will Germany win on 2026-06-25?
      yes price: 64% · 24h volume: $5,660,838 · resolves 2026-06-25
  - (2026-06-25) Will South Africa win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $5,054,273 · resolves 2026-07-20
  - (2026-06-25) Will Mexico win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $4,699,979 · resolves 2026-07-20

### GDACS — global disaster alerts — 11 new of 133 total
  - (2026-06-24) [Red] Earthquake in Venezuela
      Earthquake · Red alert · Venezuela · Magnitude 7.5M, Depth:10km
  - (2026-06-24) [Red] Earthquake in Venezuela
      Earthquake · Red alert · Venezuela · Magnitude 7.5M, Depth:10km
  - (2026-06-06) [Green] Flood in China
      Flood · Green alert · China · Magnitude 0
  - (2026-06-06) [Green] Flood in China
      Flood · Green alert · China · Magnitude 0
  - (2026-06-06) [Green] Flood in China
      Flood · Green alert · China · Magnitude 0
  - (2026-06-24) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.57M, Depth:8.06999969482422km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 40 total
  - (2026-06-25) MOVER ▲ Masayoshi Son — $82.77B (+$5.56B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-06-25) MOVER ▲ Michael Dell — $236.34B (+$2.20B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-06-25) MOVER ▼ Steve Ballmer — $119.44B ($-2.14B since yesterday)
      United States · Technology · source: Microsoft
  - (2026-06-25) MOVER ▲ Tadashi Yanai & family — $70.42B (+$1.92B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-06-25) MOVER ▼ Mark Zuckerberg — $191.61B ($-1.54B since yesterday)
      United States · Technology · source: Facebook
  - (2026-06-25) MOVER ▲ Amancio Ortega — $141.11B (+$1.31B since yesterday)
      Spain · Fashion & Retail · source: Zara

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### Commentary & analysis (last 7 days) — 3 new of 5 total
  - (2026-06-25) [Marginal Revolution] I am told James Mill is buried there also
      St. Mary’s Abbot’s Church in Kensington. The post I am told James Mill is buried there also appeared first on Marginal REVOLUTION.
  - (2026-06-25) [Marginal Revolution] Translated from the Chinese
      I think this is the Cursor moment for academia. The Stanford REAP team has made their move, http://CoPaper.AI is mass-terminating the manual labor of traditional empirical papers. Link: https://copaper.ai/landing If usin…
  - (2026-06-24) [Marginal Revolution] What should the UAP Scientific Advisory Board do?
      There are more and more frauds, charlatans, and lunatics entering this area of inquiry. It is important to stay disciplined on data-driven questions, most importantly to what extent are released (and unreleased) videos b…

### Congressional STOCK Act Trades (House + Senate) — 2 new of 70 total
  - (2026-05-29) [House] Nancy Pelosi (D): Purchase INTC ($1,000,001 - $5,000,000) (excess +17.6% vs SPY)
      Member: Nancy Pelosi (D, house). BioGuide: P000197. Asset: INTC (OP). Type: Purchase. Amount range: $1,000,001 - $5,000,000. Transaction date: 2026-05-29. Disclosure date: 2026-06-23. Excess return vs SPY since disclosur…
  - (2026-05-29) [House] Nancy Pelosi (D): Purchase UBER ($500,001 - $1,000,000) (excess +7.7% vs SPY)
      Member: Nancy Pelosi (D, house). BioGuide: P000197. Asset: UBER (OP). Type: Purchase. Amount range: $500,001 - $1,000,000. Transaction date: 2026-05-29. Disclosure date: 2026-06-23. Excess return vs SPY since disclosure:…

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-06-24) Yellow fever - Global
      Yellow fever is a viral disease found in areas of Africa and the Americas, spread by infected mosquitoes. Following an increase of cases in the Americas in 2025, transmission activity remained into 2026. From 1 January t…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-06-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=37, 7d-median=25, 14d-median=25; carrying terms: captain, program, personnel, hazards, potential, proposes, comment, establishing, requirement, office, unless, public
- state_bills: today=153, 7d-median=152, 14d-median=152; carrying terms: preservation, facilities, functions, complaints, elected, program, among, imposes, appointed, administered, person, conduct
- state_news: today=752, 7d-median=580, 14d-median=580; carrying terms: served, facilities, resource, university, robert, emissions, elected, complaints, towers, never, single, appointments
- local_news: today=222, 7d-median=222, 14d-median=222; carrying terms: celebrate, cancer, involved, million, crews, breaks, cbmiogfbvv, brings, releases, person, investigation, carolina
- foreign_news: today=1065, 7d-median=1050, 14d-median=1050; carrying terms: facilities, staying, sweeping, block, powder, menghai, flames, espriella, university, parliament, explained, route
- chinese_internal: today=316, 7d-median=298, 14d-median=298; carrying terms: cbmizkfvx, surge, lxtfa, listing, supplier, people, cbmiyefvx, politics, lxtfb, security, apple, caixin
- russian_internal: today=1087, 7d-median=980, 14d-median=980; carrying terms: raquo, index, novayagazeta, machine, social, axios, title, error, figaro, client, rusprofile, group
- ukrainian_internal: today=124, 7d-median=116, 14d-median=116; carrying terms: facilities, risks, route, latvian, never, operators, poland, program, tensions, among, listed, nawrocki
- ukraine_theater: today=482, 7d-median=586, 14d-median=586; carrying terms: nominal, qutaqthyrxvyazjnckjwqq, qyynnfcmzzotlid, uquqtwdr, jjdulknenemdgwoxzyx, wxehdrevdxaffma, uzvzt, dennbvhsmxbxbgrdsu, czeee, aaxvzr, aznlrnnib, jmuhf
- paper_bets: today=139, 7d-median=139, 14d-median=139; carrying terms: presidential, verve, retirement, number, florida, title, jpmorgan, gross, reaches, trading, resolve, formal
- weather: today=173, 7d-median=174, 14d-median=174; carrying terms: effect, parishes, knock, quality, paradise, fulton, concentrations, swell, brazos, creek, flood, noble
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: payems, personal, vixcls, funds, dexchus, latest, labor, unemployment, inflation, indicator, openings, unrate
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: agriculture, large, equities, rates, russell, close, range, crude, bitcoin, natural, commodities, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=106, 7d-median=103, 14d-median=103; carrying terms: bombing, systems, hdlvjofnrtzc, launch, vgxnrflrs, number, color, application, single, herzegovina, mxlwxprlrotgk, docket
- congressional_trades: today=70, 7d-median=68, 14d-median=68; carrying terms: april, latta, restricted, disclosure, walberg, matthew, banks, robert, mcguire, description, cisneros, delaney
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: sergey, julia, buffett, ellison, technologies, tesla, infrastructure, michael, gcarsoa, bernard, masayoshi, carlos
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: university, medical, mccarthy, blanche, supreme, court, corporation, revisions, hernandez
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, accno, holdings, reporting, issuer
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, cortez, cooper, krishnamoorthi, groom, congress, michael, robert, graham, appretices, plumbing, shawn
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, russian, spanish, trump, themes
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: fatality, kerala, genomic, seven, borne, arachidonic, summarizes, municipality, involved, geographical, reaching, index
- cisa_kev: today=10, 7d-median=10, 14d-median=10; carrying terms: critical, widget, peopletools, product, remediation, enterprise, ransomware, sentry, symlink, content, traversal, peoplesoft
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=133, 7d-median=119, 14d-median=119; carrying terms: tropical, sweden, alert, angola, impact, austria, madagascar, poland, mekkhala, forest, fires, flood
- usgs_quakes: today=14, 7d-median=15, 14d-median=15; carrying terms: depth, guinea, tobelo, islands, papua, indonesia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, verde, resolves, croatia, argentina, world, volume
- commentary: today=5, 7d-median=5, 14d-median=5; carrying terms: revolution, going, population, conversableeconomist, classified, economist, years, middle, https, upper, faster, barely
- tech_news: today=57, 7d-median=54, 14d-median=54; carrying terms: fraud, block, millions, credentials, launch, alert, single, nationals, mythos, affected, proxy, million
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: martin, advisers, biggs, gonzalez, michael, jeffries, mcmahon, cramer, robert, mcclintock, labor, edward
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: unavailable, claude, today, identify, placement, consensus, decision, module, sufficient, either, evidence, markets

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-11] Fed press (events + announcements): Federal Reserve Board announces final rule that establishes data standards for certain information collections
- [2026-06-17] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-06-17] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the June 16-17 FOMC meeting
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board requests comment on proposal to require certain payment stablecoin issuers to maintain an effective customer identification program
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Manufacturers and Traders Trust Company
- [2026-06-18] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-19] ECB press: Frank Elderson: Fireside chat
- [2026-06-22] Fed press (events + announcements): Federal Reserve notes with deep sadness the passing of Alan Greenspan
- [2026-06-22] Fed speeches: Waller, Welcoming Remarks on the International Role of the U.S. Dollar
- [2026-06-22] ECB press: Christine Lagarde: Hearing of the Committee on Economic and Monetary Affairs of the European Parliament
- [2026-06-23] ECB press: Philip R. Lane: Introductory remarks
- [2026-06-23] ECB press: Boris Vujčić: Outlook for the euro area economy and monetary policy
- [2026-06-24] ECB press: Iceland joins TIPS for instant payments
- [2026-06-24] ECB press: ECB reports on progress towards euro adoption
- [2026-06-24] Fed speeches: Cook, Welcome Remarks
- [2026-06-24] Fed press (events + announcements): Federal Reserve Board's annual bank stress test confirms that large banks are well positioned to weather a severe recession and able to continue to lend to households and businesses
- [2026-06-25] ECB press: Isabel Schnabel: Interview with Die Zeit
- [2026-06-25] ECB press: ECB to integrate non-financial credit claim portfolios into general collateral framework, phasing out temporary measures

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*