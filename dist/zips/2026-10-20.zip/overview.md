# WORLDSCOPE morning brief — 2026-10-20

## Headline
3189 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (807) · Russian Internal News (state + in-exile) (702) · World leaders & government officials (324) · State-Level News (311) · Chinese Internal News (239) · Local News: St. Louis + Atlanta (187) · U.S. Weather + Severe / Climate Outlooks (134) · Ukraine Theater (total-war monitoring) (87) · Ukrainian Internal News (national + local Kyiv) (60) · GDACS — global disaster alerts (49) · State Legislative Action (44) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 807 new of 1011 total
  - (2026-10-20) [India] Dussehra 2026: Traffic curbs in Dwarka, security tightened in Delhi-NCR and more
  - (2026-10-20) [India] Rubio says U.S. to discuss refining Venezuelan crude with Reliance, adds India made ‘substantial progress’ in diversifying energy supplies
  - (2026-10-20) [India] CJP’s Abhijeet Dipke thanks Delhi Ramlila organisers for 'free publicity' over cockroach effigy
  - (2026-10-20) [India] Man killed as car crashes into Krishna water pipeline near Nagole Metro Station; supply restored after five-hour repair
  - (2026-10-20) [India] It is state-sponsored terrorism: Mamata Banerjee over extension of custody of 2 CJP leaders
  - (2026-10-20) [India] Haryana’s BPS Government Medical College becomes first Indian college to win international innovation prize

### Russian Internal News (state + in-exile) — 702 new of 1019 total
  - (2026-10-20) Западные таблоиды написали, что Ким Чен Ын в коме. КНДР ответила публикацией его фотографий с семьей на выставке одежды | LEDE: В западных таблоидах распространились слухи, что лидер КНДР Ки] (ru: Зап…
      В западных таблоидах распространились слухи, что лидер КНДР Ким Чен Ын находится в коме. В ответ на это власти Северной Кореи опубликовали его новые фотографии.
  - (2026-10-20) Задержан подозреваемый в поджоге ратуши Лиможа. Это радикальный левый активист, который уже попадал в поле зрения полиции | LEDE: Во Франции задержали подозреваемого в поджоге ратуши Лиможа ] (ru: Зад…
      Во Франции задержали подозреваемого в поджоге ратуши Лиможа во время протестов, сообщает FranceInfo.
  - (2026-10-20) Не успели мы оглянуться, а пролетело кошмарно много времени . Вот как менялась главная страница «Медузы» за последние 12 лет (смотрим и плачем!) | LEDE: Да, ребята, мы обновили дизайн главно] (ru: Не…
      Да, ребята, мы обновили дизайн главной страницы «Медузы» — впервые за много-много-много-много лет. Нам и самим ужасно интересно вспомнить, как менялась «Медуза» с 2014-го, — поэтому мы решили собрать этот таймлайн. Тут м…
  - (2026-10-20) Южная Корея вслед за отзывом посла сократит штат посольства в Киеве. Сеул все еще ждет от Украины «конструктивных шагов» после скандала с пленными из КНДР | LEDE: Южная Корея отзовет часть д] (ru: Южн…
      Южная Корея отзовет часть дипломатического персонала из Украины на фоне скандала о передаче Сеулу северокорейских военнопленных, сообщает «Ренхап».
  - (2026-10-20) Москва уже не та. В последние годы в столице закрылись многие легендарные места . Коротко вспоминаем самые известные — от клуба Powerhouse до «Рюмочной в Зюзино» | LEDE: Первые клубы и незав] (ru: Мос…
      Первые клубы и независимые заведения, открывшиеся в постсоветской Москве, в большинстве своем проработали меньше 15 лет. Но те из них, кому удалось дожить до 2020-х, обрели культовый статус — именно с «Пропагандой», «Сай…
  - (2026-10-20) Российского рэпера Navai выпустили из СИЗО и выдворили из Казахстана. Дело о контрабанде наркотиков прекращено | LEDE: Российского рэпера Navai (настоящее имя Наваи Бакиров) отпустили из СИЗ] (ru: Рос…
      Российского рэпера Navai (настоящее имя Наваи Бакиров) отпустили из СИЗО в Казахстане. Уголовное дело о контрабанде наркотиков, фигурантом которого был рэпер, прекращено с учетом его «деятельного раскаяния», сообщили ТАС…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 311 new of 502 total
  - (2026-10-19) [California] Governor Newsom announces new tool to make it easier to access and find a state job
      Source
  - (2026-10-19) [California] Governor Newsom announces historic new ocean protections as Trump pushes offshore drilling
      Source
  - (2026-10-19) [California] Governor Newsom spotlights California’s steel comeback: first new mill in 50 years brings jobs, investment, and cleaner industry
      <a href="https://www.gov.ca.gov/2026/10/19/governor-newsom-spotlights-californias-steel-comeback-first-new-mill-in-50-years-brings-jobs-investment-and-cle
  - (2026-10-19) [Alabama] Governor Ivey Highlights Statewide School Choice Opportunities as Alabama’s Specialty Schools Open Admission
      MONTGOMERY – Governor Kay Ivey on Monday announced that all four of Alabama’s specialty public high schools have opened their admissions portals for the 2027-28 academic year and encouraged Alabama families to explore th…
  - (2026-10-20) [Colorado] Denver to close Robert F. Smith STEAM Academy, a tiny HBCU-style high school, after 6 years
      This story was originally published by Chalkbeat. Sign up for their newsletters at ckbe.at/newsletters. The vision for Robert F. Smith STEAM Academy was to provide as many as 500 Denver students with an education modeled…
  - (2026-10-20) [Colorado] Bear killings skyrocket as garbage, bird feeders draw them into conflict
      Bears are having a very bad year. Across much of the United States, a warm winter and persistent drought have decimated the natural foods that black and brown bears rely on. With nearly every station at the buffet in sho…

### Chinese Internal News — 239 new of 278 total
  - (2026-10-18) 全球首创3公里超导材料27年量产 上海造太阳稳了 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5uUkJjMHV4UHlKbTg1WFJ2VmZUUEtQa1pWTHRUVGx5TEZsejNIYVo2dEY0NUx5ZlVESS1KemlRRW9Ya1B3UXdLUWpnRGN] (zh:…
      全球首创3公里超导材料27年量产 上海造太阳稳了 观察者网
  - (2026-10-20) 格力技校开学，董明珠定规矩：不许谈恋爱，校内不准开宰学生的超市 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFAzczN6RFU0VEw1MlRtUDlVRmdMWjVZYUlMRDE3SklVMnRUdUJGWDhBdFRtRjJnTEQyb0o3SkNTZFp3d0FGaThM] (zh:…
      格力技校开学，董明珠定规矩：不许谈恋爱，校内不准开宰学生的超市 观察者网
  - (2026-10-20) 独女车祸离世，八旬父母十年后再获赔7.6万余元生活费，网友称赔少了，你怎么看？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE91QXJiSEdIY0s2T0ZvNGI0cHZNQUZYOFl5di1WbU1MMmFzako0aUhQLWkxb2xWYlBadWpnNzhsMEJ6OF] (zh:…
      独女车祸离世，八旬父母十年后再获赔7.6万余元生活费，网友称赔少了，你怎么看？ 风闻
  - (2026-10-20) 境外违规调研、高管不配合检查：明星研究所“研究天团”被监管约谈 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1nZEZoa3lGMWJoT1FTckd3OVNvTC1vTHVraFNmYVZFVFFpNi16SWhNVV9ZUnNWV2hwVVJiajAxVG9HRElRYjdq] (zh:…
      境外违规调研、高管不配合检查：明星研究所“研究天团”被监管约谈 观察者网
  - (2026-10-20) 被歪曲的琉球叙事，正在酝酿区域新乱源 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1RNXIwWXhNeHpTZU52OGlWeEJZQ0xyWnVoZUhMN3JlZms1ZTRKSXJiUWcyY1JRWi1HMkpvZGhKVElMMGF0VkEyWS1yWW5pbGlJM] (zh:…
      被歪曲的琉球叙事，正在酝酿区域新乱源 观察者网
  - (2026-10-20) 哪场战争因打赢才撤出？吹捧膜拜该有度。 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFB6MXhmeG16UndjUmhXRWtIQ2NmQXpTZHVnd1NkNjVWZkh4ZlNrMkVtQWtFWUVQa1FxTGtueDFVRlJfcVA3ZS03QmZBRDRXbm5TQU] (zh:…
      哪场战争因打赢才撤出？吹捧膜拜该有度。 风闻

### Local News: St. Louis + Atlanta — 187 new of 217 total
  - (2026-10-20) [St. Louis] Affton man faces criminal charges for pointing a gun at St. Louis County worker
      A neighborhood dispute that turned ugly on a quiet street in Affton led to a Public Works employee being threatened with a gun last week. William O. Luton, 56, is in St. Louis County Jail after allegedly threatening the…
  - (2026-10-20) [St. Louis] Dennis Hancock thinks St. Louis County voters are ready for change
      Dennis Hancock knows he’s the underdog. St. Louis County hasn’t elected a Republican county executive since Gene McNary, last elected in 1986. Hancock is also at a serious cash disadvantage; his Democratic rival, Jake Zi…
  - (2026-10-20) [St. Louis] Where Art Thou 10/20/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-10-20) [St. Louis] Judge blocks auction of Senate Square—for now
      The troubled Senate Square complex in Benton Park will have to wait a little longer before it’s auctioned off. On Monday, a trio of interested buyers, all based in the St. Louis area, arrived to news that the auction had…
  - (2026-10-20) [St. Louis] ‘Mapping Missouri’ revisits the format that made ‘Mapping St. Louis’ a sensation
      Andrew W. Hahn’s new book, Mapping Missouri, is a sequel to Mapping St. Louis, which he wrote for Reedy Press and debuted two years ago. The first book told the history of the Gateway City in 40 maps. In this new book, H…
  - (2026-10-19) [St. Louis] How to make Mess Hall chef John Messbarger’s hearty, beer-infused chili
      At Mess Hall, the UK-style pub food counter at 2nd Shift Brewing (1601 Sublette), chef John Messbarger has developed a following for his hearty comfort fare. Chili is one of his most popular offerings, especially as the…

### U.S. Weather + Severe / Climate Outlooks — 134 new of 138 total
  - (2026-10-20) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-20) [Moderate] Gale Warning: Gale Warning issued October 20 at 3:30AM AKDT until October 21 at 5:00AM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-10-20) [Moderate] Gale Warning: Gale Warning issued October 20 at 3:30AM AKDT until October 20 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-10-20) [Moderate] Special Weather Statement: Special Weather Statement issued October 20 at 3:18AM AKDT by NWS Juneau AK
      A strong storm system is moving into the northern half of the Alaska Panhandle and the northeast Gulf Coast this morning and will continue through today. Total rain accumulation are expected to be between 1.5-3.5 inches,…
  - (2026-10-20) [Severe] High Wind Warning: High Wind Warning issued October 20 at 3:11AM AKDT until October 20 at 10:00PM AKDT by NWS Juneau AK
      * WHAT...For the High Wind Warning, south winds 30 to 40 mph with gusts up to 65 mph. For the Wind Advisory, south winds 20 to 30 mph with gusts up to 50 mph expected. * WHERE...Municipality of Skagway. * WHEN...For the…
  - (2026-10-20) [Moderate] Wind Advisory: Wind Advisory issued October 20 at 3:11AM AKDT until October 21 at 10:00AM AKDT by NWS Juneau AK
      * WHAT...For the High Wind Warning, south winds 30 to 40 mph with gusts up to 65 mph. For the Wind Advisory, south winds 20 to 30 mph with gusts up to 50 mph expected. * WHERE...Municipality of Skagway. * WHEN...For the…

### Ukraine Theater (total-war monitoring) — 87 new of 425 total
  - (2026-10-19) [FIRMS] thermal anomaly 44.003, 23.158 (FRP 4.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-19 1121Z, FRP 4.78 MW
  - (2026-10-19) [FIRMS] thermal anomaly 44.244, 23.386 (FRP 2.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-19 1121Z, FRP 2.86 MW
  - (2026-10-19) [FIRMS] thermal anomaly 44.248, 23.385 (FRP 2.86 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-19 1121Z, FRP 2.86 MW
  - (2026-10-19) [FIRMS] thermal anomaly 44.498, 24.693 (FRP 3.42 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-19 1121Z, FRP 3.42 MW
  - (2026-10-19) [FIRMS] thermal anomaly 44.251, 22.793 (FRP 1.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-19 1121Z, FRP 1.84 MW
  - (2026-10-19) [FIRMS] thermal anomaly 44.250, 22.788 (FRP 1.84 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-19 1121Z, FRP 1.84 MW

### Ukrainian Internal News (national + local Kyiv) — 60 new of 129 total
  - (2026-10-20) Зеленський прибув до Норвегії | LEDE: ] (uk: Зеленський прибув до Норвегії)
  - (2026-10-20) Окупанти вдарили по торговельному центрі на Рівненщині: троє поранених | LEDE: Троє людей отримали поранення в результаті російської атаки на торговельний центр на Рівненщині.] (uk: Окупанти вдарили п…
      Троє людей отримали поранення в результаті російської атаки на торговельний центр на Рівненщині.
  - (2026-10-20) Отримайте можливості річної підписки на УП з оплатою частинами в monobank | LEDE: З 16 вересня клієнти monobank можуть оформити оплату частинами на річну підписку на "Українську правду". Підпис] (uk:…
      З 16 вересня клієнти monobank можуть оформити оплату частинами на річну підписку на "Українську правду". Підписка дає необмежений доступ до матеріалів УП: сайт без комерційної реклами в пакеті "Стандарт" або доступ до вс…
  - (2026-10-20) У Києві уламки дрона РФ впали на дах медзакладу: працюють екстрені служби | LEDE: Уламки російського безпілотника впали на будівлю медичного закладу в Солом'янському районі Києва.] (uk: У Києві уламки…
      Уламки російського безпілотника впали на будівлю медичного закладу в Солом'янському районі Києва.
  - (2026-10-20) На переговори в Осло від ЄС і НАТО прибудуть представники команд фон дер Ляєн і Рютте – ЄП | LEDE: На зустрічі в Осло ЄС представлятиме Бйорн Зайберт, НАТО – Лоренц Маєр-Міннеманн. Присутні пре] (uk:…
      На зустрічі в Осло ЄС представлятиме Бйорн Зайберт, НАТО – Лоренц Маєр-Міннеманн. Присутні представники США, Британії, Франції та інших країн.
  - (2026-10-20) ЗМІ: На переговорах в Норвегії будуть представники Трампа і Зеленський, а потім Віткофф вилетить у Москву | LEDE: На переговорах в Осло у вівторок, що пройдуть за участю президента Володимира З] (uk:…
      На переговорах в Осло у вівторок, що пройдуть за участю президента Володимира Зеленського, спецпредставників президента США Дональда Трампа і лідерів Норвегії та Фінляндії, будуть також присутні представники Британії, Фр…

### GDACS — global disaster alerts — 49 new of 88 total
  - (2026-10-20) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5M, Depth:35km
  - (2026-10-20) [Green] Earthquake in Wallis and Futuna
      Earthquake · Green alert · Wallis and Futuna · Magnitude 4.5M, Depth:417.492km
  - (2026-10-20) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 4.9M, Depth:10km
  - (2026-10-20) [Green] Earthquake in Mariana Islands
      Earthquake · Green alert · Mariana Islands · Magnitude 4.9M, Depth:250.025km
  - (2026-10-20) [Green] Earthquake in China
      Earthquake · Green alert · China · Magnitude 5.1M, Depth:10km
  - (2026-10-20) [Green] Earthquake in Vanuatu Islands
      Earthquake · Green alert · Vanuatu Islands · Magnitude 5.2M, Depth:10km

### State Legislative Action — 44 new of 44 total
  - (2026-10-20) [Alaska SB 210] An Act relating to the recognition of Indigenous cultures in public education.
      An Act relating to the recognition of Indigenous cultures in public education.
  - (2026-10-20) [California SB 580] Attorney General: immigration enforcement policies.
      Existing law requires the Attorney General to develop model policies limiting assistance with immigration enforcement to the fullest extent possible consistent with federal and state law at public schools, public librari…
  - (2026-10-20) [California SB 1187] Open meetings.
      Existing law, the Ralph M. Brown Act, requires, with specified exceptions, that all meetings of a legislative body, as defined, of a local agency be open and public and that all persons be permitted to attend and partici…
  - (2026-10-20) [California SB 881] Income taxation: credits: voluntary contributions: food bank donations.
      (1) The Personal Income Tax Law and the Corporation Tax Law allow various credits against the taxes imposed by those laws, including, for taxable years beginning on or after January 1, 2017, and before January 1, 2027, a…
  - (2026-10-20) [California SB 578] California Workplace Outreach Program.
      Existing law establishes the Department of Industrial Relations within the Labor and Workforce Development Agency to, among other things, foster, promote, and develop the welfare of wage earners, to improve their working…
  - (2026-10-20) [California SB 518] Descendants of enslaved persons: reparations.
      Former law, Chapter 319 of the Statutes of 2020, until July 1, 2023, established a task force to, among other things, identify, compile, and synthesize the relevant corpus of evidentiary documentation of the institution…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-20) 424B3 - Cubebio Co., Ltd (0002058594) (Filer)
      filed 2026-10-20 11:16 UTC — Filed: 2026-10-20 AccNo: 0001829126-26-011327 Size: 9 MB
  - (2026-10-20) 424B3 - CubeBio Holdings Ltd (0002058261) (Filer)
      filed 2026-10-20 11:16 UTC — Filed: 2026-10-20 AccNo: 0001829126-26-011327 Size: 9 MB
  - (2026-10-20) [Li Jeffrey K] Form 4 (Reporting)
      filed 2026-10-20 11:05 UTC · role: Reporting — Filed: 2026-10-20 AccNo: 0001781319-26-000004 Size: 5 KB
  - (2026-10-20) [Keysight Technologies, Inc.] Form 4 (Issuer)
      filed 2026-10-20 11:05 UTC · role: Issuer — Filed: 2026-10-20 AccNo: 0001781319-26-000004 Size: 5 KB
  - (2026-10-20) [JUSKIE JO ANN] Form 4 (Reporting)
      filed 2026-10-20 11:05 UTC · role: Reporting — Filed: 2026-10-20 AccNo: 0002069480-26-000006 Size: 4 KB
  - (2026-10-20) [Keysight Technologies, Inc.] Form 4 (Issuer)
      filed 2026-10-20 11:05 UTC · role: Issuer — Filed: 2026-10-20 AccNo: 0002069480-26-000006 Size: 4 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 54 total
  - (2026-10-20) [BleepingComputer] OVHcloud CLI releases backdoored on GitHub to steal developer secrets
      French cloud and hosting provider OVHcloud is warning users that attackers compromised its open-source command-line interface (CLI) tool to distribute information-stealing malware. [...]
  - (2026-10-20) [BleepingComputer] Ahold Delhaize: Cyberattack affects services across US and Europe
      Ahold Delhaize, one of the world's largest food retail chains, confirmed that last week's cyberattack disrupted services at stores across Europe and the United States. [...]
  - (2026-10-20) [BleepingComputer] Revolut outage disrupts online banking operations worldwide
      Fintech company Revolut is working to resolve a massive outage that disrupted most of its services worldwide earlier today. [...]
  - (2026-10-20) [The Hacker News] Hackers Hijack Five OVHcloud CLI Releases to Distribute Secret-Stealing Malware
      An attacker used a contributor's GitHub account to replace the download archives on five existing releases of OVHcloud's command-line tool on Monday, October 19. The account had been hijacked, and the new files were a bu…
  - (2026-10-20) [The Hacker News] ClickFix Attackers Exploit Siemens Software Center Flaw to Deploy Remote Access Trojan
      Siemens has addressed a DLL sideloading vulnerability impacting Siemens Software Center that it said has been exploited in ClickFix attacks. The high-severity vulnerability, tracked as CVE-2026-110936 (CVSS v4 score: 8.4…
  - (2026-10-20) [The Hacker News] Ex-OpenAI Engineer Detained in Spy Device Case as Saudi Royal Contacts Emerge
      A U.S. court on Monday granted the U.S. government's request to detain a former OpenAI engineer accused of planting a recording device in an executive conference room at the company's San Francisco office to allegedly st…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-10-20) [Taiwan Strait + South China Sea · themes] Ponte San Vito a Ragusa , il Pd denuncia : Lavori appena conclusi e marciapiedi già dissestati . Il Comune controlla ?
      corrierediragusa.it · Italian · tone NA
  - (2026-10-20) [Taiwan Strait + South China Sea · themes] Łódź : W powietrze wysadzono trzy potężne kominy . Runęły jeden po drugim
      rp.pl · Polish · tone NA
  - (2026-10-20) [Taiwan Strait + South China Sea · themes] В Каспийском море перевернулась лодка , пропали два человека :: Новости дня / ВЗГЛЯД
      vz.ru · Russian · tone NA
  - (2026-10-20) [Taiwan Strait + South China Sea · themes] कुशीनगर में भीषण सड़क हादसा : नवरात्रि मेले से लौट रहे दोस्तों की कार पेड़ से टकराई , 4 की मौत , 3 घायल
      navbharattimes.indiatimes.com · Hindi · tone NA
  - (2026-10-20) [Taiwan Strait + South China Sea · themes] Ukraine - Krieg im Liveticker : +++ 12 : 54 Rubio räumt mögliche Verzögerung bei Raketenlieferung an Ukraine ein +++
      n-tv.de · German · tone NA
  - (2026-10-20) [Taiwan Strait + South China Sea · themes] Arizona woman 3 - year wait for an intestine shows the US organ transplant system complexity
      bozemandailychronicle.com · English · tone NA

### Court opinions of consequence (federal & state) — 24 new of 60 total
  - (2026-10-19) U.S. Court of Appeals, Federal Cir.: Google LLC v. Valtrus Innovations Ltd.
  - (2026-10-19) D.C. Court of Appeals: Amended Judgment: Allen v. Whitehead
  - (2026-10-19) U.S. Court of Appeals, 8th Cir.: Charlie Foster v. United States
  - (2026-10-19) U.S. Court of Appeals, 8th Cir.: United States v. Roberto Orellana
  - (2026-10-19) U.S. Court of Appeals, 9th Cir.: United States v. Anderson
  - (2026-10-19) U.S. Court of Appeals, 3rd Cir.: Holy Trinity Ukrainian Catholic Church v. Township of Collier

### Government & military aircraft airborne (OpenSky) — 22 new of 23 total
  - (2026-10-20) JAF94H (Bulgaria)
      icao24: 4520aa · position: (36.4946, -8.1436) · alt: 11285m · 892km/h
  - (2026-10-20) PAT351 (United States)
      icao24: adfec9 · position: (29.6326, -97.926) · alt: 5021m · 362km/h
  - (2026-10-20) GAF133 (Germany)
      icao24: 3f7588 · position: (43.088, 14.3178) · alt: 10355m · 718km/h
  - (2026-10-20) CFC85 (Canada)
      icao24: c2b5c1 · position: (45.0767, -77.2816) · alt: 6667m · 452km/h
  - (2026-10-20) GAF020 (Germany)
      icao24: 3f717c · position: (52.5076, 9.4453) · alt: 571m · 385km/h
  - (2026-10-20) FNY55C4 (France)
      icao24: 39a408 · position: (48.31, -4.0192) · alt: 4114m · 551km/h

### USGS earthquakes (M4.5+, past day) — 21 new of 23 total
  - (2026-10-20) M 6.3 - 197 km NW of Port-Olry, Vanuatu
      M6.3 · 197 km NW of Port-Olry, Vanuatu · depth 16 km · TSUNAMI
  - (2026-10-19) M 5.7 - 203 km WNW of Port-Olry, Vanuatu
      M5.7 · 203 km WNW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-19) M 5.7 - 198 km NW of Port-Olry, Vanuatu
      M5.7 · 198 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-19) M 5.3 - 116 km WNW of Höfn, Iceland
      M5.3 · 116 km WNW of Höfn, Iceland · depth 10 km
  - (2026-10-20) M 5.2 - 206 km NW of Port-Olry, Vanuatu
      M5.2 · 206 km NW of Port-Olry, Vanuatu · depth 10 km
  - (2026-10-20) M 5.1 - 263 km WSW of Yanglong, China
      M5.1 · 263 km WSW of Yanglong, China · depth 10 km

### Paper Trading Scorecard — 15 new of 71 total
  - (2026-10-20) [Polymarket] IAEA visits Isfahan, Fordow, or Natanz nuclear site by October 31?
      This market will resolve to "Yes" if one or more International Atomic Energy Agency (IAEA) officials physically visit the Isfahan Nuclear Technology Center, Fordow Fuel Enrichment Plant, or Natanz Nuclear Facility in Ira…
  - (2026-10-20) [Manifold] Onion futures unbanned before 2028?
  - (2026-10-20) [Manifold] Will Hakeem Jeffries be the Majority or Minority Leader in the House after the Midterms?
  - (2026-10-20) [Manifold] Elon Musk actually gifts a SpaceX share to every American child in 2027?
  - (2026-10-20) [Manifold] Will Calvin Wang show up to 21W.023 on time?
  - (2026-10-20) [Manifold] Will Elon Musk give one of his SpaceX shares to every kid in America next year?

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-10-20) Will FC Barcelona win on 2026-10-20?
      yes price: 40% · 24h volume: $878,905 · resolves 2026-10-20
  - (2026-10-20) US x Iran ceasefire continues through October 22?
      yes price: 93% · 24h volume: $832,119 · resolves 2026-10-23
  - (2026-10-20) Will SSC Napoli win on 2026-10-20?
      yes price: 56% · 24h volume: $323,102 · resolves 2026-10-20
  - (2026-10-20) 2026 Balance of Power: R Senate, D House
      yes price: 28% · 24h volume: $294,038 · resolves 2026-11-04
  - (2026-10-20) Will Kylian Mbappé win the 2026 Ballon d'Or?
      yes price: 5% · 24h volume: $276,404 · resolves 2027-01-01
  - (2026-10-20) European Open: Mariano Navone vs Juan Manuel Cerundolo
      yes price: 100% · 24h volume: $267,525 · resolves 2026-10-26

### U.S. Federal Action — 7 new of 15 total
  - (2026-10-20) Interval Fund Modernization; Expansion of Multiple Share Class to Registered Closed-End Management Investment Companies and Business Development Companies
  - (2026-10-20) Civil Penalties Inflation Adjustments; Annual Adjustments
      This rule provides for annual adjustments to the level of civil monetary penalties contained in Bureau of Indian Affairs (Bureau) regulations to account for inflation under the Federal Civil Penalties Inflation Adjustmen…
  - (2026-10-20) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the General Category October Through November Fishery for 2026
      NMFS closes the General category fishery for Atlantic bluefin tuna (BFT) for the remainder of the October through November time period. The General category may only retain, possess, or land large medium and giant (i.e.,…
  - (2026-10-20) Authorizations for Certain Activities at Liquefied Natural Gas Plants
      The Federal Energy Regulatory Commission proposes to revise its regulations to establish procedures for authorizing activities at liquefied natural gas plants without case-specific authorization orders under sections 3 o…
  - (2026-10-20) Minimum Maturation Temperature for Beef and Ovine Meat From Regions Affected With Foot-and-Mouth Disease
      We are proposing to amend the regulations regarding the minimum maturation temperature for fresh (chilled or frozen) boneless beef and ovine meat from certain listed regions or countries affected with foot-and-mouth dise…
  - (2026-10-20) Airspace Designations; Incorporation by Reference Amendment of FAA Order JO 7400.11M
      This action administratively corrects identified final rules published by FAA in the Federal Register between May and September 2026 so that certain published airspace designation amendments are transferred to the most-c…

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 109 total
  - (2026-10-19) [OFAC] Protecting American Intellectual Property Act of 2022 (PAIPA) Designations; Issuance of Associated General Licenses - Office of Foreign Assets Control (.gov)
      Protecting American Intellectual Property Act of 2022 (PAIPA) Designations; Issuance of Associated General Licenses Office of Foreign Assets Control (.gov)
  - (2026-10-19) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Protecting American Intellectual Property Act of 2022 50 U.S.C. 1709 GENERAL LICENSE NO. 1 Tra - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Protecting American Intellectual Property Act of 2022 50 U.S.C. 1709 GENERAL LICENSE NO. 1 Tra Office of Foreign Assets Control (.gov)
  - (2026-10-20) [USASpending] $276,567,932 → CACI, INC. - FEDERAL: NASA CONSOLIDATED APPLICATION AND PLATFORM SERVICES (NCAPS)
      Agency: National Aeronautics and Space Administration. Description: NASA CONSOLIDATED APPLICATION AND PLATFORM SERVICES (NCAPS)
  - (2026-10-19) [USTR] docket for public comments - USTR portal - United States Trade Representative (.gov)
      docket for public comments - USTR portal United States Trade Representative (.gov)

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-10-20) [Marginal Revolution] The net fiscal impact of immigration should include gains from trade
      Immigration affects natives through both labor markets and public budgets, yet these channels are usually studied separately. We combine them in a general-equilibrium model with search-and-matching frictions, skill-speci…
  - (2026-10-20) [Marginal Revolution] On Brazilian food
      Every now and then I will write a piece on food for Works in Progress. Here is my piece on eating in Brazil: Brazil, like most large nations, also offers multiple cuisines. For instance you can go to Minas Gerais for por…
  - (2026-10-19) [Marginal Revolution] The California billionaire tax is very likely a net revenue loser
      This paper examines the revenue and migration impact of the 2026 California Billionaire Tax Act, a one-time 5 percent tax on the worldwide net worth of individuals exceeding $1 billion. Using data from the Forbes Billion…
  - (2026-10-19) [Conversable Economist] Medicaid’s Expanding Enrollment
      The Medicaid program spends close to $1 trillion annually, with about 65% of that coming fom the federal government and the rest from state governnments. This is almost, but not quite, one-in-five dollars of total US hea…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-20) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=15, 7d-median=33, 14d-median=26; carrying terms: national, proposed, final, period, proposing, proposes, certain, protection, regulatory, require, enforcement, agency
- state_bills: today=44, 7d-median=118, 14d-median=92; carrying terms: state, relating, powers, administration, district, providing, education, alaska, school, order, program, contracts
- state_news: today=502, 7d-median=688, 14d-median=678; carrying terms: policy, voter, approved, today, later, north, white, please, recently, rhode, economy, state
- local_news: today=217, 7d-median=235, 14d-median=228; carrying terms: child, against, north, accused, state, https, taking, headlines, officials, around, missouri, color
- foreign_news: today=1011, 7d-median=1011, 14d-median=1018; carrying terms: policy, network, suspends, caught, north, fighting, confirmed, accused, state, candidates, banque, using
- chinese_internal: today=278, 7d-median=282, 14d-median=288; carrying terms: cbmibkfvx, cbmic, cbmickfvx, cbmixkfvx, cbmix, cbmizkfvx, cbmiykfvx, blank, lxtfa, cbmigwfbvv, cbmibefvx, market
- russian_internal: today=1019, 7d-median=1022, 14d-median=1045; carrying terms: street, telegram, bloomberg, politico, times, server, https, russian, novayagazeta, httperror, forbidden, reuters
- ukrainian_internal: today=129, 7d-median=130, 14d-median=135; carrying terms: bombs, against, volodymyr, possible, institute, systems, state, criticized, plans, kremlin, https, strike
- ukraine_theater: today=425, 7d-median=398, 14d-median=419; carrying terms: cuxon, owhksjjmqlu, tulrd, cuxqtlbqcvplrjlvotlnnlfrdvu, qwhxu, ruvpzw, dsxhxlxm, tnzinmltu, hydropark, vnmztr, hqzlhtek, hkmlrfmgfwdw
- paper_bets: today=71, 7d-median=71, 14d-median=70; carrying terms: degrees, leaders, evans, drought, anthropic, celsius, jackson, minister, millennium, zohran, least, allen
- weather: today=138, 7d-median=142, 14d-median=142; carrying terms: depth, oxnard, angeles, today, across, afdfwd, afdilx, changed, north, possible, please, vessels
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: inflation, recession, effective, energy, latest, jtsjol, jolts, payrolls, cpiaucsl, commodities, payems, total
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: treasury, russell, crypto, china, equities, close, silver, crude, corporate, bitcoin, credit, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=109, 7d-median=107, 14d-median=108; carrying terms: rkiye, burundi, lebanon, against, order, middle, republic, laboratory, systems, state, cyber, description
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, error, httperror, quantitative, quiver, congresstrading, https, client, unauthorized
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: board, state, court, appeals, supreme, corporation, mullin, alabama, company, county, international, trade
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, trust, holdings, financial, filer, chase, jpmorgan, finance, group
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, shawn, house, sherrod, pinkston, senate, angels, ossoff, disbursements, cycle, trone, raised
- gdelt_regions: today=0, 7d-median=4, 14d-median=4; carrying terms: english
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, themes, italian, chinese, russian, spanish, vietnamese, china, strait, taiwan, hindi, ukrainian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=23, 7d-median=28, 14d-median=29; carrying terms: belgium, position, france, ground, kingdom, germany, bulgaria, canada
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: autochthonous, district, addition, since, update, traceability, containing, travel, activities, member, valley, organs
- cisa_kev: today=14, 7d-median=15, 14d-median=14; carrying terms: traversal, product, injection, remediation, cisco, vendor, vulnerability, improper, fortinet, control, multiple, storage
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=88, 7d-median=100, 14d-median=100; carrying terms: earthquake, depth, australia, hurricane, forest, guinea, magnitude, papua, wildfire, cyclone, indonesia, speed
- usgs_quakes: today=23, 7d-median=17, 14d-median=19; carrying terms: depth, indonesia, region, south, philippines, islands, tonga, guinea, vanuatu, papua, alaska, ruteng
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, championship, champions, donetsk, presidential, shakhtar, league, october, volume, election, brazilian
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, class, revolution, https, marginal, conversable, track, marginalrevolution, spending, conversableeconomist, years, government
- tech_news: today=54, 7d-median=58, 14d-median=58; carrying terms: people, today, across, systems, download, weekly, behind, https, artificial, newsletter, infrastructure, engineering
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: rogers, buchanan, evans, pallone, roger, blake, elissa, angus, lutnick, lynch, sheldon, marsha
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, market, either, identify, module, placement, placed, decision, converges, evidence, unavailable, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-10-07] Fed press (events + announcements): Minutes of the Federal Open Market Committee, September 15-16, 2026
- [2026-10-08] ECB press: Piero Cipollone: Interview with Corriere della Sera
- [2026-10-08] Fed speeches: Waller, The Signaling Value of the Summary of Economic Projections
- [2026-10-08] ECB press: Meeting of 9-10 September 2026
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-13] ECB press: Philip R. Lane: The AI opportunity for Europe
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-17] ECB press: Christine Lagarde: IMFC Statement
- [2026-10-19] ECB press: Frank Elderson: From climate and nature risks to economic resilience and competitiveness
- [2026-10-20] ECB press: Frank Elderson: Interview with Die Presse

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*