# WORLDSCOPE morning brief — 2026-08-13

## Headline
3999 new items across 25 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (767) · International News + Multilateral Institutions (764) · Russian Internal News (state + in-exile) (738) · State-Level News (354) · World leaders & government officials (324) · Chinese Internal News (220) · Local News: St. Louis + Atlanta (208) · U.S. Weather + Severe / Climate Outlooks (205) · GDELT GKG — themes / entities / watch areas (72) · Ukrainian Internal News (national + local Kyiv) (59) · IT, InfoSys & cybersecurity news (last 7 days) (42) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### Ukraine Theater (total-war monitoring) — 767 new of 1025 total
  - (2026-08-13) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-12) [FIRMS] thermal anomaly 46.581, 34.988 (FRP 2.88 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-12 0915Z, FRP 2.88 MW
  - (2026-08-12) [FIRMS] thermal anomaly 46.612, 34.898 (FRP 6.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-12 0915Z, FRP 6.18 MW
  - (2026-08-12) [FIRMS] thermal anomaly 46.618, 34.899 (FRP 7.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-12 0915Z, FRP 7.56 MW
  - (2026-08-12) [FIRMS] thermal anomaly 47.933, 32.721 (FRP 4.23 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-12 0917Z, FRP 4.23 MW
  - (2026-08-12) [FIRMS] thermal anomaly 48.759, 31.934 (FRP 3.24 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-12 0917Z, FRP 3.24 MW

### International News + Multilateral Institutions — 764 new of 1034 total
  - (2026-08-13) [Global] Zambia elections haunted by ghost of incumbent president’s arch-rival
  - (2026-08-12) [Global] At least 44 dead after overcrowded ferry capsizes on Lake Kariba in Zimbabwe
  - (2026-08-12) [Global] Halting the march of the African armyworm: a natural cure offers hope to farmers
  - (2026-08-12) [Global] Former Mexican governor charged in case of 43 students who vanished in 2014
  - (2026-08-12) [Global] Canadian airline WestJet agrees to settle flight attendants’ sexual harassment class action
  - (2026-08-13) [Global] Former Catholic bishop accused of hosting alcohol-fuelled parties to sexually abuse Aboriginal men found guilty

### Russian Internal News (state + in-exile) — 738 new of 1149 total
  - (2026-08-13) Россия и Украина обменялись телами погибших военных | LEDE: Россия и Украина провели обмен телами погибших военных, сообщил РБК депутат Госдумы, представитель парламентской координационной г] (ru: Рос…
      Россия и Украина провели обмен телами погибших военных, сообщил РБК депутат Госдумы, представитель парламентской координационной группы по вопросам «СВО» Шамсаил Саралиев.
  - (2026-08-13) В Севастополе в результате взрыва бомбы погиб местный житель. Телеграм-каналы пишут, что погибший — офицер ВМФ России | LEDE: В аннексированном Севастополе в результате взрыва погиб местный ] (ru: В С…
      В аннексированном Севастополе в результате взрыва погиб местный житель, сообщают близкие к силовикам телеграм-каналы Mash и «База».
  - (2026-08-13) На Трампа подали в суд из-за платного доступа к его постам | LEDE: Издание The Intercept и некоммерческая организация Freedom of the Press Foundation подали в суд на президента США Дональда ] (ru: На…
      Издание The Intercept и некоммерческая организация Freedom of the Press Foundation подали в суд на президента США Дональда Трампа. Они требуют заблокировать платный сервис Truth API, который дает ранний доступ к публикац…
  - (2026-08-13) В России резко вырос спрос на китайские ИИ-модели. Они дешевле и их проще оплатить | LEDE: Клиенты основных российских облачных платформ для бизнеса увеличили использование китайских больших] (ru: В Р…
      Клиенты основных российских облачных платформ для бизнеса увеличили использование китайских больших языковых моделей в 2026 году, пишет «Коммерсант» со ссылкой на участников рынка.
  - (2026-08-13) ВСУ больше не будут сообщать о количестве запущенных и сбитых российских баллистических ракет | LEDE: Военное руководство Украины приняло решение не сообщать в утренних сводках информацию о ] (ru: ВСУ…
      Военное руководство Украины приняло решение не сообщать в утренних сводках информацию о количестве запущенных и уничтоженных российских баллистических ракет. Об этом рассказал представитель Воздушных сил ВСУ Юрий Игнат.
  - (2026-08-13) Жители России смогут покупать места на кладбищах через «Госуслуги» | LEDE: На российском портале «Госуслуги» запустят сервис для поиска и покупки мест на кладбищах. На проект выделят 295,5 м] (ru: Жит…
      На российском портале «Госуслуги» запустят сервис для поиска и покупки мест на кладбищах. На проект выделят 295,5 миллиона рублей, пишет «Коммерсант», который ознакомился с документами Минцифры.

### State-Level News — 354 new of 681 total
  - (2026-08-12) [California] Governor Newsom and First Partner Siebel Newsom announce California State Parks’ FREE Fourth Grade Pass Now Available for 2026/27 School Year
      Source
  - (2026-08-12) [California] California’s latest efficiency wins include access to life-saving heat tools, smarter and faster hiring efforts, and simplified business tax filing
      Source
  - (2026-08-12) [Alaska] Governor Dunleavy Introduces Compromise AK LNG Tax Legislation
      Today Governor Mike Dunleavy transmitted to the Legislature a compromise bill establishing the tax and oversight framework for the Alaska LNG project which can clear the way for the project to begin securing financing. T…
  - (2026-08-12) [Alabama] Governor Ivey Announces Die Casting Company ‘2A USA’ to Make $32 Million Investment to Expand Auburn Facility
      MONTGOMERY — Governor Kay Ivey on Wednesday announced that Italian aluminum die casting company 2A USA is again expanding its Auburn manufacturing facility with a $32 million investment. The Tier I automotive industry su…
  - (2026-08-12) [California] Corte Suprema de California dictamina que municipalidades no pueden añadir obstáculos a devoluciones de impuestos
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/040126_Marathon-Refinery_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-08-12) [California] CA gig workers clear new milestone in push for union
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/09/040825_Gig-Workers-Rally_LB3_CM_08.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 220 new of 270 total
  - (2026-08-12) 富途老虎期权内幕交易案锁定45人 共获利1.55亿美元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5JZm94ZnV4SHVYVjIxa25nR0JDeHdXMzNCaGxsS1VfenZsRkdMbW9CZ0hlTEVYWjNHaXRrbW1WbHFuMnNTaHZRS3NacD] (zh:…
      富途老虎期权内幕交易案锁定45人 共获利1.55亿美元 财新
  - (2026-08-13) 今日开盘：两市双双高开 沪指涨幅0.27% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8tb0poWVdDLWlJRmdWNXFSTlFJa1lYNTZGR0R6VUhGVzN2UUlFQmZLUi1YX1RuUzBRcjcwUVlITkctZkpTb29FaUZULTI0S3hW] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.27% 财新
  - (2026-08-12) 财经早知道｜央行最新动作，及时谋划出台务实管用的增量政策 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5XZVlxbWFZQnF4dEtDcjhKOVkzMElic2pqVTRmWUdXcG9Td1llcmROTGZvdUdPYzRLSzJJV0oybHo1WFlTRDlqSmdBd] (zh:…
      财经早知道｜央行最新动作，及时谋划出台务实管用的增量政策 财新
  - (2026-08-13) 朱镕基，中国走向世界的形象代言人｜纪念 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5mOWs3LThMbkdJQ1Ntc0NFSmxVaHpCUndaT1BkampBY1BCNmlBUWFSZjNDSFI2a1RUM01JSjZablo3bGVyeThwYzc5bVFpQS02Wm] (zh:…
      朱镕基，中国走向世界的形象代言人｜纪念 财新
  - (2026-08-13) 南苏丹暴发独立以来最严重霍乱疫情 已致1700余人死亡 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5YQmp3M2tmOGE1WGJNQjR5OEkwMTluNHp0QnRnQi1fU2ZKcXkwUmhtaFd1djhLNG9sU2RZZlFUcG5qeW1ieTBRNTZkcH] (zh:…
      南苏丹暴发独立以来最严重霍乱疫情 已致1700余人死亡 财新
  - (2026-08-13) 荣耀发万元“机器人手机” IPO动作密集 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9OUkNJSGM0Rjlkc3lEdEJmSXFpYjZOSVFnRnlrMk84d2NNZFVkYWhWT3JTZlJhel9hMXVsUDE5TjZGTEtBYjU3dTlOUDNUaHQ3V] (zh:…
      荣耀发万元“机器人手机” IPO动作密集 财新

### Local News: St. Louis + Atlanta — 208 new of 229 total
  - (2026-08-12) [St. Louis] Van Hoesen House of Cheesecakes opens first storefront in Rock Hill
      The Rock Hill dining landscape just got a lot sweeter, thanks to a wildly popular local cheesecake brand. Van Hoesen House of Cheesecakes, a two-year-old business known for its elevated cheesecakes, is set to softly open…
  - (2026-08-12) [St. Louis] Midtown taxing district heads to the Board of Aldermen, despite skepticism from TIF commissioners
      Backers of a proposed taxing district covering parts of the Covenant Blu-Grand Center and Midtown neighborhoods weathered skepticism about their plan during a meeting of the St. Louis Tax Increment Financing Commission W…
  - (2026-08-12) [St. Louis] St. Louis bands come together to support earthquake relief in Venezuela
      Since June 24, Venezuela has been dealing with the aftermath of two devastating earthquakes that caused thousands of deaths, with even more people displaced from their homes and in need of support. In response, the St. L…
  - (2026-08-12) [St. Louis] A-List Editors’ Choice Awards 2026: Wellness, Beauty & Lifestyle
      WELLNESS BEST NEW SERIES FOR RUNNERS GO! St. Louis Summer Series GO! St. Louis is proving race season doesn’t end with the marathon. This year its new summer lineup included trail relays, family-friendly fun runs, and re…
  - (2026-08-12) [St. Louis] A-List Editors’ Choice Awards 2026: Food, Drink & Nightlife
      HAUTE HERBIVORE Bougie Bites Plant-based comfort foods like the Blue Oyster St. Paul sandwich, Birria Cartel tacos, and Bougie AF burger get their dynamic personality from owner Latoya Elnora Thompson and her culinary te…
  - (2026-08-12) [St. Louis] A-List Editors’ Choice Awards 2026: Arts, Culture & Entertainment
      SPECIALTY BOOK CLUB Shakespeare Festival Reads If you long for the welcoming embrace of high-school English class as an adult, the Shakespeare Festival Reads book club may be for you. This collab between Left Bank Books…

### U.S. Weather + Severe / Climate Outlooks — 205 new of 206 total
  - (2026-08-13) [Severe] Special Marine Warning: Special Marine Warning issued August 13 at 5:33AM EDT until August 13 at 6:30AM EDT by NWS Upton NY
      SMWOKX The National Weather Service in Upton NY has issued a * Special Marine Warning for... Central Long Island Sound... * Until 630 AM EDT. * At 533 AM EDT, a severe thunderstorm was located near Central Long Island So…
  - (2026-08-13) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 13 at 4:29AM CDT until August 13 at 5:15AM CDT by NWS Des Moines IA
      SVRDMX The National Weather Service in Des Moines has issued a * Severe Thunderstorm Warning for... Southern Crawford County in west central Iowa... * Until 515 AM CDT. * At 429 AM CDT, a severe thunderstorm was located…
  - (2026-08-13) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-13) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 13 at 4:27AM CDT until August 13 at 5:15AM CDT by NWS Omaha/Valley NE
      SVROAX The National Weather Service in Omaha has issued a * Severe Thunderstorm Warning for... Southeastern Monona County in west central Iowa... Northeastern Harrison County in southwestern Iowa... Shelby County in sout…
  - (2026-08-13) [Moderate] Special Weather Statement: Special Weather Statement issued August 13 at 4:25AM CDT by NWS Green Bay WI
      Patchy dense fog, with visibility less than one-half mile at times, is occurring over east-central Wisconsin, including portions of the Fox Valley to the lakeshore. The fog should diminish over much of the area after day…
  - (2026-08-13) [Severe] Flash Flood Watch: Flash Flood Watch issued August 13 at 3:20AM MDT until August 13 at 9:00PM MDT by NWS Pueblo CO
      * WHAT...Flash flooding and debris flows caused by excessive rainfall continue to be possible over the Aspen Acres burn scar. * WHERE...The Aspen Acres Burn Scar. * WHEN...From noon MDT today through this evening. * IMPA…

### GDELT GKG — themes / entities / watch areas — 72 new of 72 total
  - (2026-08-13) [Russia oil sanctions perimeter · keywords] Ukraine hits major Russian naval base | The Arkansas Democrat - Gazette
      arkansasonline.com · English · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · keywords] Russian strike sparks fire at Ukraine port ; Zelenskyy seeks interceptors - Dominican Republic Post – Caribbean News , Business , Travel & Culture
      dominicanrepublicpost.com · English · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · keywords] An overnight Ukrainian blitz damages Russia Black Sea naval stronghold , Zelenskyy says | News , Sports , Jobs
      lahainanews.com · English · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · keywords] ADAPTIVE INDOMITABLE UKRAINE Reversal of Ru Occupation in the Southeast Continues . 745 Sq Km & 26 Villages Liberated Since January
      dailykos.com · English · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · keywords] Black Sea : Drone war escalates , hitting global wheat exports | Queensland Country Life
      queenslandcountrylife.com.au · English · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · keywords] Oil eases as weaker demand outlook counters Mideast supply concerns
      arabnews.com · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 59 new of 115 total
  - (2026-08-13) У МЗС допускають можливість зустрічі українських посадовців із Лукашенком | LEDE: У МЗС України заявили про можливість переговорів із Лукашенком, якщо це допоможе зберегти життя чи вплинути на ] (uk:…
      У МЗС України заявили про можливість переговорів із Лукашенком, якщо це допоможе зберегти життя чи вплинути на перебіг війни.
  - (2026-08-13) РосЗМІ: В окупованому Севастополі підірвали чоловіка | LEDE: У Севастополі стався вибух в урні, загинув чоловік. Можливо причетна жінка з рюкзаком.] (uk: РосЗМІ: В окупованому Севастополі підірвали чо…
      У Севастополі стався вибух в урні, загинув чоловік. Можливо причетна жінка з рюкзаком.
  - (2026-08-13) Справа Стефанішиної: Апеляційна палата ВАКС призначила розгляд скарги на заставу у 6 млн грн | LEDE: 19 серпня суд розгляне апеляцію Ольги Стефанішиної щодо застави у справі про незаконне збага] (uk:…
      19 серпня суд розгляне апеляцію Ольги Стефанішиної щодо застави у справі про незаконне збагачення.
  - (2026-08-13) Польща близька до ухвалення рішення щодо передачі ракет Patriot для України | LEDE: Рішення про можливу передачу Україні ракет Patriot Польща ухвалить у найближчі дні.] (uk: Польща близька до ухваленн…
      Рішення про можливу передачу Україні ракет Patriot Польща ухвалить у найближчі дні.
  - (2026-08-13) П'ятеро людей постраждали внаслідок ранкової атаки БпЛА на село в Харківській області | LEDE: 13 серпня російські безпілотники атакували Вербівку на Харківщині: 5 поранених, руйнування.] (uk: П'ятеро…
      13 серпня російські безпілотники атакували Вербівку на Харківщині: 5 поранених, руйнування.
  - (2026-08-13) Російські "хвости" та кримінал: як влада Чехії обирає суперника Павелу на виборах президента | LEDE: Чи зможе правляча чеська коаліція на чолі із Андреєм Бабішем знайти кандидата, здатного на н] (uk:…
      Чи зможе правляча чеська коаліція на чолі із Андреєм Бабішем знайти кандидата, здатного на наступних президентських виборах перемогти чинного главу держави Петра Павела?

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 58 total
  - (2026-08-13) [The Hacker News] Attackers Exploit SharePoint Authentication Bypass After Public PoC Release
      Threat actors have begun to exploit a newly disclosed Microsoft SharePoint vulnerability following the release of a proof-of-concept (PoC) code. The vulnerability in question is CVE-2026-55040 (CVSS score: 9.1), which re…
  - (2026-08-13) [The Register] Everything is better with pickles... except Windows
      Operating system indigestion pops up over chicken sandwich ad
  - (2026-08-13) [The Register] Passwords stored in public Google Doc then showed up in search results
      Developer spotted hostname and credential string lurking in autocomplete
  - (2026-08-13) [The Register] Cisco thinks Mythos means instant death for unsupported networking kit
      CEO says buyers are moving fast and shuffling budgets to replace old boxen
  - (2026-08-13) [The Register] Tencent says it could make instant profits on $53B hardware splurge by renting it for AI workloads
      Plans to build models instead because it thinks selling tokens will prove more lucrative in the long term
  - (2026-08-13) [The Register] Chinese Loongson processors have leaky caches, researchers find
      Attackers could extract data, even working from inside a guest VM

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-13) [Farajallah Awny Samaan Botros] Form 4 (Reporting)
      filed 2026-08-13 01:54 UTC · role: Reporting — Filed: 2026-08-12 AccNo: 0001493152-26-037515 Size: 5 KB
  - (2026-08-13) [TAKEDA PHARMACEUTICAL CO LTD] Form 4 (Issuer)
      filed 2026-08-13 01:54 UTC · role: Issuer — Filed: 2026-08-12 AccNo: 0001493152-26-037515 Size: 5 KB
  - (2026-08-13) [Ibrahim Ramy Riad Ahmed] Form 4 (Reporting)
      filed 2026-08-13 01:53 UTC · role: Reporting — Filed: 2026-08-12 AccNo: 0001493152-26-037514 Size: 5 KB
  - (2026-08-13) [TAKEDA PHARMACEUTICAL CO LTD] Form 4 (Issuer)
      filed 2026-08-13 01:53 UTC · role: Issuer — Filed: 2026-08-12 AccNo: 0001493152-26-037514 Size: 5 KB
  - (2026-08-13) [Pacheco Rhonda Janice] Form 4 (Reporting)
      filed 2026-08-13 01:53 UTC · role: Reporting — Filed: 2026-08-12 AccNo: 0001493152-26-037513 Size: 5 KB
  - (2026-08-13) [TAKEDA PHARMACEUTICAL CO LTD] Form 4 (Issuer)
      filed 2026-08-13 01:53 UTC · role: Issuer — Filed: 2026-08-12 AccNo: 0001493152-26-037513 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-13) [Nigeria] Osun : Police arrest 10 over Modakeke violence , polytechnic invasion
      domain: dailypost.ng · language: English · tone:
  - (2026-08-13) [] 5 new podcasts to listen to this week
      domain: the-independent.com · language: English · tone:
  - (2026-08-13) [United Kingdom] Amber heat warning in force as parts of England face more extreme temperatures
      domain: theboltonnews.co.uk · language: English · tone:
  - (2026-08-13) [United States] Surgeon Sews Patient Organs Together , Man Dresses as Grim Reaper to Scare | NOW 105 . 7
      domain: radionow1057.iheart.com · language: English · tone:
  - (2026-08-13) [Australia] Marine Rescue NSW records second busiest July on record
      domain: mysailing.com.au · language: English · tone:
  - (2026-08-13) [United Kingdom] DWP confirms full list of benefits exempt from new driving licence cancellations
      domain: birminghammail.co.uk · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 28 new of 60 total
  - (2026-08-12) U.S. Court of Appeals, 8th Cir.: Shamrock Hills, LLC v. State of Iowa
  - (2026-08-12) U.S. Court of Appeals, 8th Cir.: United States v. Amir Mulamba
  - (2026-08-12) U.S. Court of Appeals, 8th Cir.: United States v. Xavier Murry
  - (2026-08-12) U.S. Court of Appeals, 10th Cir.: Friends of Animals v. FWS
  - (2026-08-12) U.S. Court of Appeals, 10th Cir.: United States v. Reed
  - (2026-08-12) U.S. Court of Appeals, 10th Cir.: Walden v. The City of Duncan, Oklahoma

### Paper Trading Scorecard — 24 new of 126 total
  - (2026-08-13) [Polymarket] Will Gold (XAUUSD) hit (HIGH) $4,700 in August?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of August 2026, any 1-minute candle for Gold (XAUUSD) has a final "High" or "Low" price equal to or beyond (above for…
  - (2026-08-13) [Polymarket] Will Russia capture all of Kupiansk by December 31?
      This market will resolve to “Yes” if, according to the ISW map, Russia captures the entirety of Kupiansk by December 31, 2026, at 11:59 PM ET. Kupiansk will be considered captured if the entirety of the municipality is s…
  - (2026-08-13) [Polymarket] Will Crude Oil reach a new all-time high by September 30?
      This market will resolve to "Yes" if, on any trading day after market creation, the official daily high price published by the CME Group for the Active Month (front month) of CME Crude Oil (CL) futures is greater than $1…
  - (2026-08-13) [Polymarket] Spain accuses Morocco of facilitating Ceuta migrant wave by August 31?
      This market will resolve to "Yes" if the Spanish government explicitly claims that Moroccan authorities deliberately caused or facilitated the influx of migrants that occurred in the Spanish territory of Ceuta on July 30…
  - (2026-08-13) [Manifold] Will Democrats win the 2026 Wisconsin Gubernatorial election by 5.00% or more?
  - (2026-08-13) [Manifold] Will the existence of a non-MF group be proved this month?

### Government & military aircraft airborne (OpenSky) — 22 new of 25 total
  - (2026-08-13) SAMU37 (France)
      icao24: 39ca87 · position: (47.4103, 0.9324) · alt: 243m · 217km/h
  - (2026-08-13) PUMA22 (Slovenia)
      icao24: 506e1c · position: (45.8066, 14.6643) · alt: 1402m · 169km/h
  - (2026-08-13) GAF851 (Germany)
      icao24: 3f97fd · position: (47.0969, 16.0989) · alt: 9753m · 841km/h
  - (2026-08-13) CNA26 (Spain)
      icao24: 3475ca · position: (None, None) · on ground · 121km/h
  - (2026-08-13) JAF8WT (Belgium)
      icao24: 44d1ba · position: (50.9211, 4.6199) · alt: 350m · 317km/h
  - (2026-08-13) JAF99Y (Belgium)
      icao24: 44d1a6 · position: (46.2761, -1.918) · alt: 11582m · 865km/h

### U.S. Federal Action — 18 new of 18 total
  - (2026-08-13) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A330-243, A330-243F, A330-341, A330-342, A330- 343, A330-841, and A330-941 airplanes; and Model A340-211, A340-212, A340-213, A340-311…
  - (2026-08-13) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A318 series airplanes; Model A319 series airplanes; Model A320 series airplanes; and Model A321-111, -112, -131, -211, -212, -213, -23…
  - (2026-08-13) Air Plan Approval; Commonwealth of Virginia; Transfer of Authority and Requests for Certain Public Hearings on Air Permits
      The Environmental Protection Agency (EPA) is proposing to approve a state implementation plan (SIP) revision request submitted by Virginia Department of Environmental Quality (VADEQ) on behalf of the Commonwealth of Virg…
  - (2026-08-13) Establishment of Class E Airspace; Havana, IL
      This action corrects a notice of proposed rulemaking (NPRM) that the FAA published in the Federal Register on August 10, 2026, proposing to establish Class E airspace at Havana, IL. Subsequent to publication, it was disc…
  - (2026-08-13) Fisheries Off West Coast States; Modification of the West Coast Salmon Fisheries; Inseason Action #23-#24
      NMFS announces two inseason actions for the 2026 portion of the 2025-2026 ocean salmon fisheries. These inseason actions modified the commercial and recreational salmon fisheries in the area from Cape Falcon, Oregon to t…
  - (2026-08-13) Air Plan Approval; Missouri; Clean Data Determination for the 2015 8-Hour Ozone Standard for the Missouri Portion of the St. Louis Nonattainment Area
      The Environmental Protection Agency (EPA) is determining under the Clean Air Act (CAA) that the Missouri portion of the St. Louis, MO- IL bi-state nonattainment area has achieved clean data for the 2015 8- hour ozone Nat…

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-08-13) Dota 2: Team Spirit vs Xtreme Gaming (BO3) - The International Group Stage
      yes price: 76% · 24h volume: $1,463,222 · resolves 2026-08-13
  - (2026-08-13) Dota 2: Team Spirit vs Xtreme Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $1,234,761 · resolves 2026-08-13
  - (2026-08-13) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,100,188 · resolves 2026-06-01
  - (2026-08-13) LoL: Weibo Gaming vs Ninjas in Pyjamas (BO3) - LPL Group Nirvana
      yes price: 12% · 24h volume: $873,156 · resolves 2026-08-13
  - (2026-08-13) LoL: Weibo Gaming vs Ninjas in Pyjamas - Game 2 Winner
      yes price: 100% · 24h volume: $811,577 · resolves 2026-08-13
  - (2026-08-13) LoL: Kiwoom DRX vs BNK FEARX - Game 1 Winner
      yes price: 100% · 24h volume: $726,576 · resolves 2026-08-13

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 99 total
  - (2026-08-12) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Rice Lake Weighing Systems, Inc. - Office of Foreign Assets Control (.gov)
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Rice Lake Weighing Systems, Inc. Office of Foreign Assets Control (.gov)
  - (2026-08-12) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-08-13) [USASpending] $4,464,785,978 → FLUOR-BWXT PORTSMOUTH LLC: PORTSMOUTH GASEOUS DIFFUSION PLANT DECONTAMINATION AND DECOM
      Agency: Department of Energy. Description: PORTSMOUTH GASEOUS DIFFUSION PLANT DECONTAMINATION AND DECOMMISSIONING PROJECT
  - (2026-08-13) [USASpending] $2,188,408,942 → THE TRUSTEES OF PRINCETON UNIVERSITY: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE P
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE PRINCETON PLASMA PHYSICS LABORATORY (PPPL)
  - (2026-08-13) [USASpending] $1,432,695,359 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SOFTWARE LIFE CYCLE DEVELOPMENT
      Agency: General Services Administration. Description: SOFTWARE LIFE CYCLE DEVELOPMENT
  - (2026-08-13) [USASpending] $926,859,869 → HII MISSION TECHNOLOGIES CORP: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED
      Agency: General Services Administration. Description: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED TO ALION SCIENCE AND TECHNOLOGY CORPORATION TO PROVIDE CONTRACTOR SUPPORT TO THE JOINT CAPABILITY EMBEDDE…

### USGS earthquakes (M4.5+, past day) — 10 new of 10 total
  - (2026-08-12) M 6.0 - South Sandwich Islands region
      M6.0 · South Sandwich Islands region · depth 10 km
  - (2026-08-13) M 5.5 - 69 km SSW of Chirilagua, El Salvador
      M5.5 · 69 km SSW of Chirilagua, El Salvador · depth 56.794 km
  - (2026-08-13) M 5.1 - 59 km NNW of Barishal, Pakistan
      M5.1 · 59 km NNW of Barishal, Pakistan · depth 58.893 km
  - (2026-08-12) M 5.1 - 226 km E of Levuka, Fiji
      M5.1 · 226 km E of Levuka, Fiji · depth 570.792 km
  - (2026-08-13) M 4.7 - Greenland Sea
      M4.7 · Greenland Sea · depth 10 km
  - (2026-08-12) M 4.7 - 31 km E of Basco, Philippines
      M4.7 · 31 km E of Basco, Philippines · depth 10 km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-13) [Marginal Revolution] My very interesting Conversation with Daron Acemoglu
      Here is the audio, video, and transcript. Here is the episode summary: Daron Acemoglu returns for his second appearance with a new book, What Happened to Liberal Democracy?, which Tyler reads as an attempt to redefine an…
  - (2026-08-12) [Marginal Revolution] Mistakes in financial economics
      I feel like this is almost deliberately missing the point. My median expectation is that AI boosts the economy enormously, so shorting things would be a terrible idea. But non-trivial tail risk is that it kills everyone.…
  - (2026-08-12) [Marginal Revolution] Wednesday assorted links
      1. The cheese collateral in Italian banks is melting. 2. Denmark fact of the day: “…half of Denmark’s growth has been due to essentially one company” 3. “Foreign travel now makes up 1.4% of the US consumer spending budge…
  - (2026-08-12) [Conversable Economist] Did the Sewing Machine Reduce the Workload for Women?
      Is new technology that replaces a worker a good thing? We have a tendency, it seems to me, to believe that most previous inventions turned out to have overall net social benefits, but to be worried that all future invent…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 36 total
  - (2026-08-13) #30 Masayoshi Son — $66.92B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-08-13) MOVER ▲ Amancio Ortega — $148.02B (+$0.81B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-08-13) MOVER ▲ Carlos Slim Helu & family — $121.52B (+$0.05B since yesterday)
      Mexico · Telecom · source: Telecom

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-13) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=20, 14d-median=20; carrying terms: action, proposes, service, august, remove, proposed, standards, certain, procedures, program, commission, special
- state_bills: today=0, 7d-median=108, 14d-median=108; carrying terms: vehicle, businesses, operating, sufficient, prohibits, ordinances, environmental, various, governor, quality, relating, native
- state_news: today=681, 7d-median=681, 14d-median=586; carrying terms: opinion, saturday, attachment, hands, lawsuit, forbidden, montana, might, illustration, legislature, hospitals, according
- local_news: today=229, 7d-median=230, 14d-median=230; carrying terms: saturday, attachment, weekend, incident, according, cbmipgfbvv, president, killed, local, charges, police, color
- foreign_news: today=1034, 7d-median=1011, 14d-median=1006; carrying terms: vehicle, weight, leads, scheduled, targets, innovative, wuhan, zhengcai, bodies, parts, forbidden, vnexpress
- chinese_internal: today=270, 7d-median=261, 14d-median=264; carrying terms: cbmib, cbmiykfvx, cbmixkfvx, cbmia, https, color, cbmizefvx, cbmicefvx, cbmiaefvx, lxtfa, global, cbmizkfvx
- russian_internal: today=1149, 7d-median=1063, 14d-median=1032; carrying terms: bloomberg, title, patriot, forbidden, https, gazeta, journal, russian, found, times, novaya, telegram
- ukrainian_internal: today=115, 7d-median=107, 14d-median=111; carrying terms: chief, three, intelligence, billion, weapons, targets, overnight, people, injured, forbidden, sanctions, across
- ukraine_theater: today=1025, 7d-median=780, 14d-median=778; carrying terms: ewprovzpx, uhplq, nthtendvq, zwdja, april, dxlauvjtu, exhnznffove, wklwy, rsehczd, yxzkmkv, ujzbsg, zqujn
- paper_bets: today=126, 7d-median=129, 14d-median=135; carrying terms: majors, netanyahu, chase, speed, texas, otherwise, election, governor, arizona, theme, succeed, playoff
- weather: today=206, 7d-median=182, 14d-median=176; carrying terms: statement, idaho, overnight, afdlsx, tropical, aviation, weekend, memphis, douglas, across, stroke, ruskin
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: labor, vixcls, cpiaucsl, effective, jolts, dexchus, rates, supply, payems, payrolls, implied, headline
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, treasury, range, silver, rates, crude, large, bitcoin, crypto, russell, corporate, futures
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=99, 14d-median=99; carrying terms: belarus, middle, aeronautics, rights, tiananmen, zimbabwe, unauthorised, award, destruction, google, claims, hybrid
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, unauthorized, https, congresstrading, quiver, quantitative, error, httperror, client
- billionaires: today=36, 7d-median=34, 14d-median=35; carrying terms: oracle, ambani, ellison, walmart, exchange, bloomberg, source, carlos, diversified, microsoft, france, london
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: johnson, supreme, delaware, county, appeals, court, association, connecticut, state, blanche, management, corporation
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, michael, holdings
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, cycle, senate, receipts, lindsey, robert, michael, warner, david, elect, ocasio, disbursements
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea, japan
- gdelt_gkg: today=72, 7d-median=37, 14d-median=42; carrying terms: english, russian, themes, trump, chinese, israel, hezbollah, russia, strait, arabic, sanctions, german
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=25, 7d-median=26, 14d-median=26; carrying terms: position, france, belgium, ground, germany, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: isolates, resulting, onboard, paralytic, middle, rates, exchange, discontinued, environmental, valley, internationally, three
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: sensitive, firewall, remediation, vendor, authentication, cisco, product, secure, deserialization, langflow, command, vulnerability
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=236; carrying terms: flood, nicaragua, alert, bosnia, belarus, north, philippines, fires, belize, hungary, france, magnitude
- usgs_quakes: today=10, 7d-median=13, 14d-median=14; carrying terms: depth, russia, indonesia, islands, philippines, kuril, japan, severo, region, south
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: august, winner, normal, hormuz, traffic, strait, resolves, price, september, volume, returns, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, revolution, https, marginal, conversable, economist, conversableeconomist, current, marginalrevolution, growth, future, conversableecon
- tech_news: today=58, 7d-median=56, 14d-median=56; carrying terms: weekly, krebs, intelligence, companies, people, vulnerability, across, water, against, cloud, because, attacks
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: hickenlooper, abraham, haridopolos, jimmy, sorensen, babin, torres, hinds, chief, durbin, carlos, april
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, paper, evidence, sufficient, module, today, markets, unavailable, market, placed, converges, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*