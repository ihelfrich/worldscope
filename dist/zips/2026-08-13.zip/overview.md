# WORLDSCOPE morning brief — 2026-08-13

## Headline
3882 new items across 24 active section(s) (of 42 tracked).

## Top movers today
Ukraine Theater (total-war monitoring) (770) · International News + Multilateral Institutions (752) · Russian Internal News (state + in-exile) (710) · State-Level News (337) · World leaders & government officials (324) · Local News: St. Louis + Atlanta (222) · Chinese Internal News (207) · U.S. Weather + Severe / Climate Outlooks (200) · Ukrainian Internal News (national + local Kyiv) (59) · GDELT GKG — themes / entities / watch areas (50) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (38)

## What changed today
### Ukraine Theater (total-war monitoring) — 770 new of 1024 total
  - (2026-08-13) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-12) [Liveuamap] The Air Assault Forces of the Armed Forces of Ukraine, assault units, and other involved units liberated 26 settlements in the Dnipropetrovsk, Donetsk, and Zaporizhzhia regions along the O…
      The Air Assault Forces of the Armed Forces of Ukraine, assault units, and other involved units liberated 26 settlements in the Dn
  - (2026-08-12) [Liveuamap] At Kramatorsk direction clashes yesterday near Yurkivka, - General Staff of Armed Forces of Ukraine reports - Liveuamap
      At Kramatorsk direction clashes yesterday near Yurkivka, - General Staff of Armed Forces of Ukraine reports <font
  - (2026-08-11) [Liveuamap] The U.S. has approved the sale of 5,250 ⁠interceptors to Bahrain, Kuwait, Qatar, and the United Arab Emirates for replenishment, - Reuters Washington, District of Columbia - Liveuamap
      The U.S. has approved the sale of 5,250 ⁠interceptors to Bahrain, Kuwait, Qatar, and the United Arab Emirates for re
  - (2026-08-12) [Liveuamap] Fires broke out and plumes of smoke rose from the positions of Iranian Kurdish opposition groups in Erbil province, northern Iraq. Erbil Governorate, Iraq - Iraq news map in English - News…
      Fires broke out and plumes of smoke rose from the positions of Iranian Kurdish opposition groups in Erbil province, north
  - (2026-08-11) [Liveuamap] Russia launched Tsyrkon missiles, Iskander-M/KN-23 ballistic missiles and 120 strike drones overnight, - Ukrainian Air Force Kyiv, Kyiv city - Ukraine Interactive map - Ukraine Latest news…
      Russia launched Tsyrkon missiles, Iskander-M/KN-23 ballistic missiles and 120 strike drones overnight, - Ukrainian Air Force Kyi

### International News + Multilateral Institutions — 752 new of 1031 total
  - (2026-08-13) [Global] Zambia elections haunted by ghost of incumbent president’s arch-rival
  - (2026-08-12) [Global] At least 44 dead after overcrowded ferry capsizes on Lake Kariba in Zimbabwe
  - (2026-08-12) [Global] Halting the march of the African armyworm: a natural cure offers hope to farmers
  - (2026-08-12) [Global] Former Mexican governor charged in case of 43 students who vanished in 2014
  - (2026-08-12) [Global] Canadian airline WestJet agrees to settle flight attendants’ sexual harassment class action
  - (2026-08-13) [Global] Reformers associate may have ‘boasted’ or ‘lied’ about a $15,000 commitment from Angus Taylor, Icac hears

### Russian Internal News (state + in-exile) — 710 new of 1122 total
  - (2026-08-13) На Трампа подали в суд из-за платного доступа к его постам | LEDE: Издание The Intercept и некоммерческая организация Freedom of the Press Foundation подали в суд на президента США Дональда ] (ru: На…
      Издание The Intercept и некоммерческая организация Freedom of the Press Foundation подали в суд на президента США Дональда Трампа. Они требуют заблокировать платный сервис Truth API, который дает ранний доступ к публикац…
  - (2026-08-13) В России резко вырос спрос на китайские ИИ-модели. Они дешевле и их проще оплатить | LEDE: Клиенты основных российских облачных платформ для бизнеса увеличили использование китайских больших] (ru: В Р…
      Клиенты основных российских облачных платформ для бизнеса увеличили использование китайских больших языковых моделей в 2026 году, пишет «Коммерсант» со ссылкой на участников рынка.
  - (2026-08-13) ВСУ больше не будут сообщать о количестве запущенных и сбитых российских баллистических ракет | LEDE: Военное руководство Украины приняло решение не сообщать в утренних сводках информацию о ] (ru: ВСУ…
      Военное руководство Украины приняло решение не сообщать в утренних сводках информацию о количестве запущенных и уничтоженных российских баллистических ракет. Об этом рассказал представитель Воздушных сил ВСУ Юрий Игнат.
  - (2026-08-13) Жители России смогут покупать места на кладбищах через «Госуслуги» | LEDE: На российском портале «Госуслуги» запустят сервис для поиска и покупки мест на кладбищах. На проект выделят 295,5 м] (ru: Жит…
      На российском портале «Госуслуги» запустят сервис для поиска и покупки мест на кладбищах. На проект выделят 295,5 миллиона рублей, пишет «Коммерсант», который ознакомился с документами Минцифры.
  - (2026-08-13) Зеленский: если США продадут Украине 5% своих ракет-перехватчиков, мы переживем зиму. А если 10% — мы уничтожим все российские баллистические ракеты | LEDE: Президент Украины Владимир Зеленс] (ru: Зел…
      Президент Украины Владимир Зеленский в интервью CNN заявил, что в этом году Украина получила в два с половиной раза меньше ракет-перехватичков, чем у нее было в 2025 году. При этом Россия ежемесячно запускает в два раза…
  - (2026-08-13) Украина атаковала Башкортостан. Телеграм-каналы сообщают о пожаре на НПЗ и складе Wildberries | LEDE: Украина нанесла удар дронами по Башкортостану. Глава региона Радий Хабиров сообщил, что ] (ru: Укр…
      Украина нанесла удар дронами по Башкортостану. Глава региона Радий Хабиров сообщил, что «обломки беспилотника» упали в одной из промзон города Салават. Там начался пожар. О погибших и пострадавших пока не сообщается.

### State-Level News — 337 new of 664 total
  - (2026-08-12) [Alabama] Governor Ivey Announces Die Casting Company ‘2A USA’ to Make $32 Million Investment to Expand Auburn Facility
      MONTGOMERY — Governor Kay Ivey on Wednesday announced that Italian aluminum die casting company 2A USA is again expanding its Auburn manufacturing facility with a $32 million investment. The Tier I automotive industry su…
  - (2026-08-12) [California] Governor Newsom and First Partner Siebel Newsom announce California State Parks’ FREE Fourth Grade Pass Now Available for 2026/27 School Year
      Source
  - (2026-08-12) [California] California’s latest efficiency wins include access to life-saving heat tools, smarter and faster hiring efforts, and simplified business tax filing
      Source
  - (2026-08-12) [Alaska] Governor Dunleavy Introduces Compromise AK LNG Tax Legislation
      Today Governor Mike Dunleavy transmitted to the Legislature a compromise bill establishing the tax and oversight framework for the Alaska LNG project which can clear the way for the project to begin securing financing. T…
  - (2026-08-12) [California] Corte Suprema de California dictamina que municipalidades no pueden añadir obstáculos a devoluciones de impuestos
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/040126_Marathon-Refinery_AP_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-08-12) [California] CA gig workers clear new milestone in push for union
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/09/040825_Gig-Workers-Rally_LB3_CM_08.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Local News: St. Louis + Atlanta — 222 new of 239 total
  - (2026-08-12) [St. Louis] Van Hoesen House of Cheesecakes opens first storefront in Rock Hill
      The Rock Hill dining landscape just got a lot sweeter, thanks to a wildly popular local cheesecake brand. Van Hoesen House of Cheesecakes, a two-year-old business known for its elevated cheesecakes, is set to softly open…
  - (2026-08-12) [St. Louis] Midtown taxing district heads to the Board of Aldermen, despite skepticism from TIF commissioners
      Backers of a proposed taxing district covering parts of the Covenant Blu-Grand Center and Midtown neighborhoods weathered skepticism about their plan during a meeting of the St. Louis Tax Increment Financing Commission W…
  - (2026-08-12) [St. Louis] St. Louis bands come together to support earthquake relief in Venezuela
      Since June 24, Venezuela has been dealing with the aftermath of two devastating earthquakes that caused thousands of deaths, with even more people displaced from their homes and in need of support. In response, the St. L…
  - (2026-08-12) [St. Louis] A-List Editors’ Choice Awards 2026: Wellness, Beauty & Lifestyle
      WELLNESS BEST NEW SERIES FOR RUNNERS GO! St. Louis Summer Series GO! St. Louis is proving race season doesn’t end with the marathon. This year its new summer lineup included trail relays, family-friendly fun runs, and re…
  - (2026-08-12) [St. Louis] A-List Editors’ Choice Awards 2026: Food, Drink & Nightlife
      HAUTE HERBIVORE Bougie Bites Plant-based comfort foods like the Blue Oyster St. Paul sandwich, Birria Cartel tacos, and Bougie AF burger get their dynamic personality from owner Latoya Elnora Thompson and her culinary te…
  - (2026-08-12) [St. Louis] A-List Editors’ Choice Awards 2026: Arts, Culture & Entertainment
      SPECIALTY BOOK CLUB Shakespeare Festival Reads If you long for the welcoming embrace of high-school English class as an adult, the Shakespeare Festival Reads book club may be for you. This collab between Left Bank Books…

### Chinese Internal News — 207 new of 261 total
  - (2026-08-12) 富途老虎期权内幕交易案锁定45人 共获利1.55亿美元 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5JZm94ZnV4SHVYVjIxa25nR0JDeHdXMzNCaGxsS1VfenZsRkdMbW9CZ0hlTEVYWjNHaXRrbW1WbHFuMnNTaHZRS3NacD] (zh:…
      富途老虎期权内幕交易案锁定45人 共获利1.55亿美元 财新
  - (2026-08-13) 今日开盘：两市双双高开 沪指涨幅0.27% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8tb0poWVdDLWlJRmdWNXFSTlFJa1lYNTZGR0R6VUhGVzN2UUlFQmZLUi1YX1RuUzBRcjcwUVlITkctZkpTb29FaUZULTI0S3hW] (zh:…
      今日开盘：两市双双高开 沪指涨幅0.27% 财新
  - (2026-08-12) 财经早知道｜央行最新动作，及时谋划出台务实管用的增量政策 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5XZVlxbWFZQnF4dEtDcjhKOVkzMElic2pqVTRmWUdXcG9Td1llcmROTGZvdUdPYzRLSzJJV0oybHo1WFlTRDlqSmdBd] (zh:…
      财经早知道｜央行最新动作，及时谋划出台务实管用的增量政策 财新
  - (2026-08-13) 朱镕基，中国走向世界的形象代言人｜纪念 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5mOWs3LThMbkdJQ1Ntc0NFSmxVaHpCUndaT1BkampBY1BCNmlBUWFSZjNDSFI2a1RUM01JSjZablo3bGVyeThwYzc5bVFpQS02Wm] (zh:…
      朱镕基，中国走向世界的形象代言人｜纪念 财新
  - (2026-08-13) 荣耀发万元“机器人手机” IPO动作密集 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9OUkNJSGM0Rjlkc3lEdEJmSXFpYjZOSVFnRnlrMk84d2NNZFVkYWhWT3JTZlJhel9hMXVsUDE5TjZGTEtBYjU3dTlOUDNUaHQ3V] (zh:…
      荣耀发万元“机器人手机” IPO动作密集 财新
  - (2026-08-13) 火线评论｜外籍人才扎堆回流香港 缘何韩国精英最吃香？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBzYTdYZDJZZEQzWm5mdFo4SmgxcTREYVJydU1VODlncTA5SDFwazgwcFhKT0hvVmt0SWxLRTI0VWN2Y3Uwc0VSMUFSOHh] (zh:…
      火线评论｜外籍人才扎堆回流香港 缘何韩国精英最吃香？ 财新

### U.S. Weather + Severe / Climate Outlooks — 200 new of 201 total
  - (2026-08-13) [Severe] Flood Watch: Flood Watch issued August 13 at 2:18AM MDT until August 13 at 10:00PM MDT by NWS Denver CO
      * WHAT...Flash flooding caused by excessive rainfall is possible. * WHERE...Portions of east central and northeast Colorado, including the following areas, in east central Colorado, North and Northeast Elbert County Belo…
  - (2026-08-13) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-13) [Severe] Flood Warning: Flood Warning issued August 13 at 4:15AM EDT until August 14 at 7:32AM EDT by NWS Wilmington OH
      ...The Flood Warning is extended for the following rivers... Whitewater River at Brookville. * WHAT...Minor flooding is forecast. * WHERE...Whitewater River at Brookville. * WHEN...From this afternoon to Friday morning.…
  - (2026-08-13) [Extreme] Tornado Warning: Tornado Warning issued August 13 at 3:14AM CDT until August 13 at 3:30AM CDT by NWS Omaha/Valley NE
      At 314 AM CDT, a severe thunderstorm capable of producing a tornado was located over Howells, or 17 miles southwest of West Point, moving east at 45 mph. HAZARD...Tornado. SOURCE...Radar indicated rotation. IMPACT...Flyi…
  - (2026-08-13) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 13 at 3:09AM CDT until August 13 at 4:00AM CDT by NWS Omaha/Valley NE
      SVROAX The National Weather Service in Omaha has issued a * Severe Thunderstorm Warning for... Southeastern Madison County in northeastern Nebraska... Southwestern Burt County in east central Nebraska... Southern Cuming…
  - (2026-08-13) [Moderate] Special Weather Statement: Special Weather Statement issued August 13 at 4:07AM EDT by NWS Northern Indiana
      Areas of fog, dense in some spots, will continue in portions of northern Indiana and southern Lower Michigan with visibilities at or below 1/2 mile at times. Drivers are urged to slow down and do not use high beam headli…

### Ukrainian Internal News (national + local Kyiv) — 59 new of 115 total
  - (2026-08-13) Польща близька до прийняття рішення щодо передачі ракет Patriot для України | LEDE: Заступниця міністра оборони Польщі Магдалена Собковяк-Чарнецька повідомила, що її країна розглядає можливість] (uk:…
      Заступниця міністра оборони Польщі Магдалена Собковяк-Чарнецька повідомила, що її країна розглядає можливість передачі Україні чергової партії ракет Patriot. Це питання буде вирішено протягом найближчих днів.
  - (2026-08-13) П'ятеро людей постраждали внаслідок ранкової атаки БпЛА на село в Харківській області | LEDE: 13 серпня російські безпілотники атакували Вербівку на Харківщині: 5 поранених, руйнування.] (uk: П'ятеро…
      13 серпня російські безпілотники атакували Вербівку на Харківщині: 5 поранених, руйнування.
  - (2026-08-13) Російські "хвости" та кримінал: як влада Чехії обирає суперника Павелу на виборах президента | LEDE: Чи зможе правляча чеська коаліція на чолі із Андреєм Бабішем знайти кандидата, здатного на н] (uk:…
      Чи зможе правляча чеська коаліція на чолі із Андреєм Бабішем знайти кандидата, здатного на наступних президентських виборах перемогти чинного главу держави Петра Павела?
  - (2026-08-13) У Румунії через обміління Дунаю зупиняють другий енергоблок Чернаводської АЕС | LEDE: Чернаводська АЕС тимчасово зупинила другий енергоблок через падіння рівня води в Дунаї.] (uk: У Румунії через обмі…
      Чернаводська АЕС тимчасово зупинила другий енергоблок через падіння рівня води в Дунаї.
  - (2026-08-13) На Одещині "Шахед" атакував пасажирський потяг: загинули машиніст і його помічник | LEDE: Удар "Шахеда" по пасажирському поїзду на Одещині: загинула локомотивна бригада, пасажирів евакуйовано] (uk: На…
      Удар "Шахеда" по пасажирському поїзду на Одещині: загинула локомотивна бригада, пасажирів евакуйовано
  - (2026-08-13) ЗМІ дізналися, чому Трампа таємно пересадили на інший літак дорогою з Анкари | LEDE: Трампа евакуювали на інший літак після саміту НАТО в Анкарі через ймовірну спробу збити його борт із ПЗРК — ] (uk:…
      Трампа евакуювали на інший літак після саміту НАТО в Анкарі через ймовірну спробу збити його борт із ПЗРК — повідомляє CNN.

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-13) [Russia oil sanctions perimeter · themes] US – Iran standoff deepens : Strait of Hormuz disruption , oil spill in Oman and flight updates UAE residents need today ( Aug . 13 , 2026 )
      gulfnews.com · English · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · themes] Colombian President invokes
      bignewsnetwork.com · English · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · themes] Imbarcazione scuffiata a circa 300 metri dalla costa di Ortona : quattro persone messe in salvo
      chietitoday.it · Italian · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · themes] Adana Kozanda Sel ve Dolu Sonrası Mısır Hasadı Başladı
      mersinhaber.com · Turkish · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · themes] Venezuela : Dont Blame the Victim
      venezuelastar.com · English · tone NA
  - (2026-08-13) [Russia oil sanctions perimeter · themes] أسعار الذهب ترتفع إلى أعلى مستوى منذ شهرين
      24.ae · Arabic · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-13) [Farajallah Awny Samaan Botros] Form 4 (Reporting)
      filed 2026-08-13 01:54 UTC · role: Reporting — Filed: 2026-08-12 AccNo: 0001493152-26-037515 Size: 5 KB
  - (2026-08-13) [TAKEDA PHARMACEUTICAL CO LTD] Form 4 (Issuer)
      filed 2026-08-13 01:54 UTC · role: Issuer — Filed: 2026-08-12 AccNo: 0001493152-26-037515 Size: 5 KB
  - (2026-08-13) [Ibrahim Ramy Riad Ahmed] Form 4 (Reporting)
      filed 2026-08-13 01:53 UTC · role: Reporting — Filed: 2026-08-12 AccNo: 0001493152-26-037514 Size: 5 KB
  - (2026-08-13) [TAKEDA PHARMACEUTICAL CO LTD] Form 4 (Issuer)
      filed 2026-08-13 01:53 UTC · role: Issuer — Filed: 2026-08-12 AccNo: 0001493152-26-037514 Size: 5 KB
  - (2026-08-13) [Pacheco Rhonda Janice] Form 4 (Reporting)
      filed 2026-08-13 01:53 UTC · role: Reporting — Filed: 2026-08-12 AccNo: 0001493152-26-037513 Size: 5 KB
  - (2026-08-13) [TAKEDA PHARMACEUTICAL CO LTD] Form 4 (Issuer)
      filed 2026-08-13 01:53 UTC · role: Issuer — Filed: 2026-08-12 AccNo: 0001493152-26-037513 Size: 5 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 38 new of 58 total
  - (2026-08-13) [The Hacker News] Attackers Exploit SharePoint Authentication Bypass After Public PoC Release
      Threat actors have begun to exploit a newly disclosed Microsoft SharePoint vulnerability following the release of a proof-of-concept (PoC) code. The vulnerability in question is CVE-2026-55040 (CVSS score: 9.1), which re…
  - (2026-08-13) [The Register] Passwords stored in public Google Doc then showed up in search results
      Developer spotted hostname and credential string lurking in autocomplete
  - (2026-08-13) [The Register] Cisco thinks Mythos means instant death for unsupported networking kit
      CEO says buyers are moving fast and shuffling budgets to replace old boxen
  - (2026-08-13) [The Register] Tencent says it could make instant profits on $53bn hardware splurge by renting it for AI workloads
      Plans to build models instead because it thinks selling tokens will prove more lucrative in the long term
  - (2026-08-13) [The Register] Chinese Loongson processors have leaky caches, researchers find
      Attackers could extract data, even working from inside a guest VM
  - (2026-08-13) [The Register] OpenAI ad service can bill customers for up to one day after they pause campaigns
      ChatGPT Ads, I wish I knew how to quit you

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 28 new of 60 total
  - (2026-08-12) Arizona Supreme Court: Mario Rodriguez-Ramirez v. State of Arizona
  - (2026-08-12) U.S. Court of Appeals, 10th Cir.: Friends of Animals v. FWS
  - (2026-08-12) U.S. Court of Appeals, 10th Cir.: United States v. Reed
  - (2026-08-12) U.S. Court of Appeals, 10th Cir.: Walden v. The City of Duncan, Oklahoma
  - (2026-08-12) Delaware Supreme Court: Porter v. State
  - (2026-08-12) U.S. Court of Appeals, 11th Cir.: Center for Biological Diversity v. U.S. Environmental Protection Agency

### Government & military aircraft airborne (OpenSky) — 27 new of 30 total
  - (2026-08-13) JAF1TA (Bulgaria)
      icao24: 4520d0 · position: (48.9979, 6.2708) · alt: 243m · 271km/h
  - (2026-08-13) JAF56C (Bulgaria)
      icao24: 4520aa · position: (47.5016, 0.7507) · alt: 9753m · 849km/h
  - (2026-08-13) JEDI27 (France)
      icao24: 39a858 · position: (46.1022, -0.1006) · alt: 1219m · 286km/h
  - (2026-08-13) PUMA42 (Slovenia)
      icao24: 506e18 · position: (46.2148, 15.2934) · alt: 1463m · 192km/h
  - (2026-08-13) PUMA20 (Slovenia)
      icao24: 506e1d · position: (45.8725, 15.4618) · alt: 1310m · 174km/h
  - (2026-08-13) PUMA22 (Slovenia)
      icao24: 506e1c · position: (45.6039, 15.0434) · alt: 1402m · 167km/h

### Paper Trading Scorecard — 21 new of 124 total
  - (2026-08-13) [Polymarket] Will Gold (XAUUSD) hit (HIGH) $4,700 in August?
      This market will resolve to "Yes" if, at any point after market creation and during a trading session of August 2026, any 1-minute candle for Gold (XAUUSD) has a final "High" or "Low" price equal to or beyond (above for…
  - (2026-08-13) [Polymarket] Will Crude Oil reach a new all-time high by September 30?
      This market will resolve to "Yes" if, on any trading day after market creation, the official daily high price published by the CME Group for the Active Month (front month) of CME Crude Oil (CL) futures is greater than $1…
  - (2026-08-13) [Polymarket] Spain accuses Morocco of facilitating Ceuta migrant wave by August 31?
      This market will resolve to "Yes" if the Spanish government explicitly claims that Moroccan authorities deliberately caused or facilitated the influx of migrants that occurred in the Spanish territory of Ceuta on July 30…
  - (2026-08-13) [Polymarket] Israel closes its airspace by August 31?
      This market will resolve to “Yes” if Israel initiates a major closure of its airspace by the specified date, 11:59 PM ET. Otherwise, this market will resolve to “No”. A “major closure” is defined as a broad closure, canc…
  - (2026-08-13) [Manifold] Will the existence of a non-MF group be proved this month?
  - (2026-08-13) [Manifold] Is Val going to attend The Strotes wedding?

### U.S. Federal Action — 18 new of 18 total
  - (2026-08-13) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A330-243, A330-243F, A330-341, A330-342, A330- 343, A330-841, and A330-941 airplanes; and Model A340-211, A340-212, A340-213, A340-311…
  - (2026-08-13) Airworthiness Directives; Airbus SAS Airplanes
      The FAA proposes to adopt a new airworthiness directive (AD) for all Airbus SAS Model A318 series airplanes; Model A319 series airplanes; Model A320 series airplanes; and Model A321-111, -112, -131, -211, -212, -213, -23…
  - (2026-08-13) Air Plan Approval; Commonwealth of Virginia; Transfer of Authority and Requests for Certain Public Hearings on Air Permits
      The Environmental Protection Agency (EPA) is proposing to approve a state implementation plan (SIP) revision request submitted by Virginia Department of Environmental Quality (VADEQ) on behalf of the Commonwealth of Virg…
  - (2026-08-13) Establishment of Class E Airspace; Havana, IL
      This action corrects a notice of proposed rulemaking (NPRM) that the FAA published in the Federal Register on August 10, 2026, proposing to establish Class E airspace at Havana, IL. Subsequent to publication, it was disc…
  - (2026-08-13) Fisheries Off West Coast States; Modification of the West Coast Salmon Fisheries; Inseason Action #23-#24
      NMFS announces two inseason actions for the 2026 portion of the 2025-2026 ocean salmon fisheries. These inseason actions modified the commercial and recreational salmon fisheries in the area from Cape Falcon, Oregon to t…
  - (2026-08-13) Air Plan Approval; Missouri; Clean Data Determination for the 2015 8-Hour Ozone Standard for the Missouri Portion of the St. Louis Nonattainment Area
      The Environmental Protection Agency (EPA) is determining under the Clean Air Act (CAA) that the Missouri portion of the St. Louis, MO- IL bi-state nonattainment area has achieved clean data for the 2015 8- hour ozone Nat…

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 99 total
  - (2026-08-12) [OFAC] Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Rice Lake Weighing Systems, Inc. - Office of Foreign Assets Control (.gov)
      Settlement Agreement between the U.S. Department of the Treasury's Office of Foreign Assets Control and Rice Lake Weighing Systems, Inc. Office of Foreign Assets Control (.gov)
  - (2026-08-12) [OFAC] DEPARTMENT OF THE TREASURY - Office of Foreign Assets Control (.gov)
      DEPARTMENT OF THE TREASURY Office of Foreign Assets Control (.gov)
  - (2026-08-13) [USASpending] $4,464,785,978 → FLUOR-BWXT PORTSMOUTH LLC: PORTSMOUTH GASEOUS DIFFUSION PLANT DECONTAMINATION AND DECOM
      Agency: Department of Energy. Description: PORTSMOUTH GASEOUS DIFFUSION PLANT DECONTAMINATION AND DECOMMISSIONING PROJECT
  - (2026-08-13) [USASpending] $2,188,408,942 → THE TRUSTEES OF PRINCETON UNIVERSITY: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE P
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE PRINCETON PLASMA PHYSICS LABORATORY (PPPL)
  - (2026-08-13) [USASpending] $1,432,695,359 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: SOFTWARE LIFE CYCLE DEVELOPMENT
      Agency: General Services Administration. Description: SOFTWARE LIFE CYCLE DEVELOPMENT
  - (2026-08-13) [USASpending] $926,859,869 → HII MISSION TECHNOLOGIES CORP: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED
      Agency: General Services Administration. Description: IGF::OT::IGF TASK ORDER (TO) 47QFCA18F0067 IS HEREBY AWARDED TO ALION SCIENCE AND TECHNOLOGY CORPORATION TO PROVIDE CONTRACTOR SUPPORT TO THE JOINT CAPABILITY EMBEDDE…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-08-13) #30 Masayoshi Son — $66.92B
      Japan · Finance & Investments · source: Telecom, Investments · holdings: 9984-JP(TOKYO)
  - (2026-08-13) MOVER ▲ Elon Musk — $889.87B (+$63.70B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-13) MOVER ▲ Michael Dell — $257.45B (+$12.80B since yesterday)
      United States · Technology · source: Dell Technologies
  - (2026-08-13) MOVER ▲ Larry Ellison — $194.77B (+$8.49B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-13) MOVER ▼ Mark Zuckerberg — $198.79B ($-6.87B since yesterday)
      United States · Technology · source: Facebook
  - (2026-08-13) MOVER ▲ Jensen Huang — $193.46B (+$5.61B since yesterday)
      United States · Technology · source: Semiconductors

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-08-13) Dota 2: Team Liquid vs Vici Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $1,596,846 · resolves 2026-08-13
  - (2026-08-13) Dota 2: Team Falcons vs LGD Gaming (BO3) - The International Group Stage
      yes price: 100% · 24h volume: $1,392,300 · resolves 2026-08-13
  - (2026-08-13) Dota 2: Team Spirit vs Xtreme Gaming (BO3) - The International Group Stage
      yes price: 70% · 24h volume: $1,075,353 · resolves 2026-08-13
  - (2026-08-13) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 1% · 24h volume: $978,502 · resolves 2026-06-01
  - (2026-08-13) Dota 2: Team Spirit vs Xtreme Gaming - Game 1 Winner
      yes price: 72% · 24h volume: $828,637 · resolves 2026-08-13
  - (2026-08-13) LoL: Weibo Gaming vs Ninjas in Pyjamas - Game 1 Winner
      yes price: 0% · 24h volume: $657,188 · resolves 2026-08-13

### USGS earthquakes (M4.5+, past day) — 9 new of 9 total
  - (2026-08-12) M 6.0 - South Sandwich Islands region
      M6.0 · South Sandwich Islands region · depth 10 km
  - (2026-08-13) M 5.5 - 69 km SSW of Chirilagua, El Salvador
      M5.5 · 69 km SSW of Chirilagua, El Salvador · depth 56.794 km
  - (2026-08-13) M 5.1 - 59 km NNW of Barishal, Pakistan
      M5.1 · 59 km NNW of Barishal, Pakistan · depth 58.893 km
  - (2026-08-12) M 5.1 - 226 km E of Levuka, Fiji
      M5.1 · 226 km E of Levuka, Fiji · depth 570.792 km
  - (2026-08-13) M 4.7 - Greenland Sea
      M4.7 · Greenland Sea · depth 10 km
  - (2026-08-12) M 4.7 - 31 km E of Basco, Philippines
      M4.7 · 31 km E of Basco, Philippines · depth 10 km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-13) [Marginal Revolution] My very interesting Conversation with Daron Acemoglu
      Here is the audio, video, and transcript. Here is the episode summary: Daron Acemoglu returns for his second appearance with a new book, What Happened to Liberal Democracy?, which Tyler reads as an attempt to redefine an…
  - (2026-08-12) [Marginal Revolution] Mistakes in financial economics
      I feel like this is almost deliberately missing the point. My median expectation is that AI boosts the economy enormously, so shorting things would be a terrible idea. But non-trivial tail risk is that it kills everyone.…
  - (2026-08-12) [Marginal Revolution] Wednesday assorted links
      1. The cheese collateral in Italian banks is melting. 2. Denmark fact of the day: “…half of Denmark’s growth has been due to essentially one company” 3. “Foreign travel now makes up 1.4% of the US consumer spending budge…
  - (2026-08-12) [Conversable Economist] Did the Sewing Machine Reduce the Workload for Women?
      Is new technology that replaces a worker a good thing? We have a tendency, it seems to me, to believe that most previous inventions turned out to have overall net social benefits, but to be worried that all future invent…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-13) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=20, 14d-median=20; carrying terms: special, certain, provide, final, proposed, standards, program, service, airspace, procedures, remove, proposing
- state_bills: today=0, 7d-median=108, 14d-median=107; carrying terms: materials, administration, financial, others, agency, things, professional, services, certain, provide, general, existing
- state_news: today=664, 7d-median=664, 14d-median=664; carrying terms: security, rising, latest, according, things, holding, indiana, following, thursday, jersey, natural, sunday
- local_news: today=239, 7d-median=239, 14d-median=239; carrying terms: according, following, crash, mother, attachment, plans, weekend, https, public, killed, charged, articles
- foreign_news: today=1031, 7d-median=1011, 14d-median=1011; carrying terms: security, rising, latest, developing, female, applied, started, zhenhua, dreamed, viral, container, chinadaily
- chinese_internal: today=261, 7d-median=261, 14d-median=261; carrying terms: cbmickfvx, cbmiakfvx, cbmixkfvx, https, lxtfa, cbmiw, articles, global, google, blank, target, cbmiaefvx
- russian_internal: today=1122, 7d-median=1063, 14d-median=1009; carrying terms: bloomberg, street, europe, russian, forbidden, journal, found, media, https, patriot, error, gazeta
- ukrainian_internal: today=115, 7d-median=107, 14d-median=115; carrying terms: combat, logistics, campaign, security, others, latest, europe, following, political, staff, general, company
- ukraine_theater: today=1024, 7d-median=780, 14d-median=780; carrying terms: ektxwhblafvut, xkvzrrrtdoq, latest, wtvrazjz, zkywukptvuvnm, developing, female, dfelrloxbfy, jqamsyoepen, dovelxcxvuakftmtjqohrfde, wudinu, brrgxpaw
- paper_bets: today=124, 7d-median=129, 14d-median=133; carrying terms: humans, industrial, virginia, mbappe, earthquake, world, republicans, inflation, openai, arizona, verve, jinping
- weather: today=201, 7d-median=182, 14d-median=176; carrying terms: valley, below, following, severe, thursday, flooding, produce, continue, shower, falls, afdffc, mountains
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexjpus, assets, growth, vixcls, rates, dcoilwtico, cpiaucsl, sheet, total, dexuseu, latest, pcepilfe
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, crude, rates, silver, bitcoin, corporate, commodities, range, credit, large, russell, crypto
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=99, 7d-median=99, 14d-median=99; carrying terms: administration, jihad, combat, facilitate, linear, measures, technology, security, campaign, agency, bombing, aggression
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, httperror, client, quiver, quantitative, error, congresstrading, https, quiverquant
- billionaires: today=40, 7d-median=34, 14d-median=34; carrying terms: nasdaq, source, bernard, trading, googl, india, gautam, bloomberg, mukesh, warren, technology, alice
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, johnson, supreme, appeals, county, delaware, association, blanche, company, corporation, state, connecticut
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, filed, reporting, issuer, michael, holdings
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ocasio, lindsey, michael, house, johnson, cortez, filing, cooper, raised, elect, krishnamoorthi, talarico
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, korea, japan
- gdelt_gkg: today=50, 7d-median=37, 14d-median=48; carrying terms: english, spanish, russian, themes, hormuz, chinese, trump, russia, strait, turkish, italian, keywords
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=26; carrying terms: position, france, belgium, ground, germany, slovenia, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: contamination, rapidly, province, genomic, arachidonic, accordance, social, humans, carrying, occur, complete, current
- cisa_kev: today=9, 7d-median=9, 14d-median=9; carrying terms: secure, remediation, untrusted, product, vulnerability, deserialization, authentication, vendor, cisco, command, injection, firewall
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=251, 14d-median=236; carrying terms: albania, hurricane, drought, herzegovina, bosnia, thailand, islands, liechtenstein, belize, forest, earthquake, depth
- usgs_quakes: today=9, 7d-median=13, 14d-median=14; carrying terms: depth, islands, philippines, indonesia, japan, region, south, honmachi
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: winner, price, august, resolves, volume, september, hormuz, traffic, strait, returns, normal, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, revolution, https, class, conversable, marginal, conversableeconomist, current, marginalrevolution, growth, future, conversableecon
- tech_news: today=58, 7d-median=56, 14d-median=56; carrying terms: campaign, security, world, adoption, infrastructure, cyber, https, newsletter, researchers, people, spectrum, techcrunch
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: administration, shelley, counsel, vince, cassidy, gillibrand, moore, virginia, meuser, security, administrator, krishnamoorthi
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, placement, placed, market, claude, identify, evidence, paper, consensus, either, today, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of First Interstate Bank
- [2026-07-30] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Iuka Bancshares, Inc. and The Iuka State Bank
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize its rule governing the extension of credit to bank "insiders"—bank executives, board members and major shareholders who could potentially influence a bank's lending decisions
- [2026-07-31] Fed press (events + announcements): Federal Reserve Board requests comment on a proposal to modernize rules for mutual banking organizations
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Coastal Bend Bancshares, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by FS Bancorp, Inc.
- [2026-08-04] Fed press (events + announcements): Federal Reserve Board announces approval of the application by Banco Santander, S.A. and Santander Holdings USA, Inc.
- [2026-08-05] Fed speeches: Cook, Outlook for the U.S. and Alaskan Economies
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*