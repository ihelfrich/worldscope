# WORLDSCOPE morning brief — 2026-09-15

## Headline
3367 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (799) · Russian Internal News (state + in-exile) (728) · State-Level News (379) · World leaders & government officials (324) · Chinese Internal News (243) · Local News: St. Louis + Atlanta (215) · Ukraine Theater (total-war monitoring) (178) · U.S. Weather + Severe / Climate Outlooks (104) · State Legislative Action (75) · Ukrainian Internal News (national + local Kyiv) (67) · IT, InfoSys & cybersecurity news (last 7 days) (47) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 799 new of 981 total
  - (2026-09-15) [Global] State pension likely to top £13,000 a year as UK wage growth slows to 3.9%
      The rise has reignited the debate about the state pension's long-term affordability and generational fairness.
  - (2026-09-15) [Global] Trump says AI safety fears a 'hoax' as he rejects calls for greater safeguards
      The US president's comments come after Anthropic co-founder Jack Clark told the BBC an AI "kill switch" may need to be mandatory.
  - (2026-09-14) [Global] I got paid $5,000 to move to a place I'd never heard of
      Relocation schemes offer support for people who want to swap big cities for a cheaper, quieter life.
  - (2026-09-15) [Global] AI 'kill switch' may need to be mandatory, Anthropic co-founder tells BBC
      US President Donald Trump dismisses calls to slow the development of AI, saying that claims of it "taking over the World" are a "HOAX".
  - (2026-09-14) [Global] Pubs in England and Wales to allow digital ID apps to prove age
      New rules introduced on Tuesday mean establishments will be able to accept digital ID apps alongside physical documents.
  - (2026-09-15) [Global] AI regulation faces political deadlock as calls grow for Congress to act
      With Trump opposed and Congress divided, new safety legislation on AI is unlikely to pass anytime soon despite mounting pressure.

### Russian Internal News (state + in-exile) — 728 new of 1042 total
  - (2026-09-15) LVMH рискует выбыть из топ-10 крупнейших компаний Европы. Ее капитализация ниже, чем у LʼOréal | LEDE: LVMH близка к тому, чтобы потерять статус самой дорогой компании Франции и впервые с 20] (ru: LVM…
      LVMH близка к тому, чтобы потерять статус самой дорогой компании Франции и впервые с 2017 года выбыть из десятки крупнейших европейских компаний по капитализации, пишет Bloomberg.
  - (2026-09-15) Война . 1665-й день. Трамп: Россия и Украина согласились не наносить удары по энергетике друг друга. Украина: атакует Сызранский НПЗ. Россия: наносит удар по АЗС в Киеве | LEDE: «Медуза» с 2] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-15) Хоккеист Александр Овечкин (лучший снайпер НХЛ) снялся в агитационном ролике «Единой России». Как выяснила «Медуза», спортсмена рассматривали как одного из потенциальных лидеров списка ЕР на вы] (ru:…
      Хоккеист Александр Овечкин снялся в предвыборном ролике «Единой России». Незадолго до выборов в Госдуму, которые пройдут 18-20 сентября, партия выпустила такие телевизионные ролики для пятерки лидеров своего федерального…
  - (2026-09-15) Историка русской кухни Павла Сюткина приговорили к шести годам колонии из-за антивоенного высказывания | LEDE: Зюзинский суд Москвы приговорил 61-летнего писателя и историка русской кухни Па] (ru: Ист…
      Зюзинский суд Москвы приговорил 61-летнего писателя и историка русской кухни Павла Сюткина к шести годам колонии общего режима по делу о распространении «фейков» об армии, сообщает «Медиазона».
  - (2026-09-15) В Нидерландах остановили движение поездов. Оператор предполагает диверсию | LEDE: В Нидерландах произошел масштабный сбой на железной дороге: в значительной части страны нарушено движение по] (ru: В Н…
      В Нидерландах произошел масштабный сбой на железной дороге: в значительной части страны нарушено движение поездов. Оператор железнодорожной инфраструктуры ProRail предполагает, что речь может идти о диверсии, сообщает NO…
  - (2026-09-15) В Кремле назвали энергетическое перемирие «очень хорошей идеей». Но, по словам Пескова, «мировых проблем оно не решит» | LEDE: Российские власти считают предложенное президентом США энергети] (ru: В К…
      Российские власти считают предложенное президентом США энергетическое перемирие — взаимный отказ РФ и Украины от ударов по объектам энергетической инфраструктуры — «очень хорошей идеей». Однако, заявил журналистам пресс-…

### State-Level News — 379 new of 540 total
  - (2026-09-14) [Alabama] Adult Education & Family Literacy Week,
      Download
  - (2026-09-14) [Alabama] Month of Prayer
      Download
  - (2026-09-14) [Alabama] Governor Ivey Approves Alabama’s First Workforce Pell Program at Lawson State Community College
      MONTGOMERY – Governor Kay Ivey on Monday announced that Lawson State Community College’s Lineworker Training Program has become the first program in Alabama to receive state approval through the Workforce Pell process, m…
  - (2026-09-14) [Alabama] November 2026 General Election Proposed Amendments to the Constitution of Alabama 2022 – Statewide
      Download
  - (2026-09-14) [Alaska] Governor Dunleavy Proclaims September 14-18 Alaska Clean Energy Week
      Alaska Governor Mike Dunleavy has proclaimed September 14-18, 2026, as “Alaska Clean Energy Week,” recognizing Alaska’s vast energy resources and the state’s continued leadership in developing reliable and sustainable en…
  - (2026-09-14) [Alaska] Alaska Clean Energy Week 2026
      WHEREAS, Alaska is filled with more sustainable energy potential than nearly any place on earth and has produced this energy under the highest environmental standards for decades. That potential includes generation from…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 243 new of 282 total
  - (2026-09-14) Sarah de Lagarde：AI赋能人类未来，问责由谁承担？_特别呈现_手机财新网 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBDNW9qcjFBSkd4aGwzWlRkeHZmTzAxdlN4S3ktMG0xenN3eUZHRGs3b2p3US12TUZZRENCUnR1a] (zh:…
      Sarah de Lagarde：AI赋能人类未来，问责由谁承担？_特别呈现_手机财新网 财新
  - (2026-09-13) 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE41TGw4T2dTdUE2VXlGMTdtU3ZDVkhoMk1BWS1CdzJwSXhZTlpMT214eGZBNmRkaEI2SFdxVWt1V1o2cWc2X0gzdDQyVW05eU5iRThIZjI2WDRQVDd] (zh:…
      商品详情 财新商城
  - (2026-09-13) 经常账户顺差 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE12cjNkeXc3QWtvUzFrUEFXSk9iam5oVlVpcEstckk5UGZoMjU4TVMyRk1iM1ExdEJDN1o1THgwS29XS2RELXlsQ3JFQkpkUn] (zh:…
      经常账户顺差 deepview.caixin.com
  - (2026-09-15) 图集｜大量韩国民众持续集会 反对向霍尔木兹海峡派兵 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE03WWxUbmZOWjAyTXB6TGxRS2x1dktlV0Q2NTd5VUZybDBfWTJRV250Rmd5ZlkzRU1aRGJraXR2ckRmNk5mRFVyZ0lGdDhY] (zh:…
      图集｜大量韩国民众持续集会 反对向霍尔木兹海峡派兵 财新
  - (2026-09-15) 今日开盘：两市双双低开 沪指跌幅0.14% - 财新网 (Caixin) | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBob25DaFRLOTJ0T005czJDYUNZdjAzbmhrQkpwLXQtN1R5Nm1GMF9DUXJaNGE3enpKNlJTdHI0VkZRZXV4WDQ1QX] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.14% 财新网 (Caixin)
  - (2026-09-15) 火线评论｜别让欠款成为压垮中小企业的稻草 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9JRFY2S1Z3X2I1TGg1ZDdLNTRvczRSekdJdUN2NmVqV2k1ZWVYN05VNDYybFhFU3YzLXlRU0J5TVd5cUFtanNqWXdmbWlrbmpyb] (zh:…
      火线评论｜别让欠款成为压垮中小企业的稻草 财新

### Local News: St. Louis + Atlanta — 215 new of 236 total
  - (2026-09-15) [St. Louis] Mayor touts progress at City Justice Center, resists calls for new jail
      The City Justice Center smells better since commissioner Nate Hayward took over nearly a year ago, Mayor Cara Spencer says. On top of that, there have been some cosmetic changes, like a fresh coat of paint and flower bed…
  - (2026-09-15) [St. Louis] FluidIQ looks to revolutionize medical ventilation with a small, disposable plastic device
      A company with ties to the St. Louis region is looking to revolutionize the way people are ventilated in medical settings with a brand new device that’s vastly cheaper and lighter than the options that exist today. For t…
  - (2026-09-15) [St. Louis] Where Art Thou 9/15/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-09-14) [St. Louis] Jill Stein demands jury trial in St. Louis assault case—rejecting deal from prosecutors
      St. Louis will be seeing more of perennial third party presidential candidate Dr. Jill Stein in the coming months. The Green Party politician requested in court today that her misdemeanor assault and trespass case go to…
  - (2026-09-14) [St. Louis] Grab your lederhosen and dirndl, and head to Hermann’s Oktoberfest
      While the St. Louis metro area hosts a variety of Oktoberfest celebrations, Hermann, Missouri—just 67 miles west—celebrates its rich German heritage with its own popular rendition. Settled in the mid-1800s by the Deutsch…
  - (2026-09-14) [St. Louis] Photos: 2026 A-List Awards Celebration
      On September 9, 2026, A-List honorees gathered at 4 Hands Brewing Co. to celebrate their achievements. Attendees enjoyed Hi-Pointe Drive-In sliders and fries, Gioia’s Deli hot salami sandwiches, Pop & Sons Dirty Beverage…

### Ukraine Theater (total-war monitoring) — 178 new of 309 total
  - (2026-09-15) [DeepStateMap] frontline snapshot, 527 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-14) [FIRMS] thermal anomaly 44.077, 23.311 (FRP 4.83 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-14 1038Z, FRP 4.83 MW
  - (2026-09-14) [FIRMS] thermal anomaly 44.077, 23.312 (FRP 4.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-14 1038Z, FRP 4.92 MW
  - (2026-09-14) [FIRMS] thermal anomaly 44.064, 23.185 (FRP 5 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-14 1038Z, FRP 5 MW
  - (2026-09-14) [FIRMS] thermal anomaly 44.067, 23.178 (FRP 5 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-14 1038Z, FRP 5 MW
  - (2026-09-14) [FIRMS] thermal anomaly 44.110, 23.185 (FRP 32.95 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-14 1038Z, FRP 32.95 MW

### U.S. Weather + Severe / Climate Outlooks — 104 new of 106 total
  - (2026-09-15) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-15) [Moderate] Heat Advisory: Heat Advisory issued September 15 at 7:12AM CDT until September 15 at 7:00PM CDT by NWS Houston/Galveston TX
      * WHAT...Heat index values up to 110. * WHERE...Portions of south central and southeast Texas. * WHEN...Until 7 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity may cause heat illnesses.
  - (2026-09-15) [Moderate] Gale Warning: Gale Warning issued September 15 at 4:08AM AKDT until September 16 at 4:00PM AKDT by NWS Juneau AK
      * WHAT...For the first Small Craft Advisory, south winds 20 to 30 kt with gusts up to 40 kt expected. For the Gale Warning, south winds 25 to 35 kt with gusts up to 45 kt expected. For the second Small Craft Advisory, so…
  - (2026-09-15) [Moderate] Gale Warning: Gale Warning issued September 15 at 4:05AM AKDT until September 16 at 5:00PM AKDT by NWS Juneau AK
      Southeast Alaska Inside Waters from Dixon Entrance to Skagway Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent the average of the highest one-third of the combined windwave and…
  - (2026-09-15) [Moderate] Gale Warning: Gale Warning issued September 15 at 7:03AM CDT until September 15 at 4:00PM CDT by NWS Duluth MN
      * WHAT...West winds 20 to 30 kt with gusts up to 40 kt and waves 6 to 9 ft. * WHERE...Grand Portage to Grand Marais MN. * WHEN...Until 4 PM CDT this afternoon. * IMPACTS...Strong winds will cause hazardous waves which co…
  - (2026-09-15) [Moderate] Gale Warning: Gale Warning issued September 15 at 7:03AM CDT until September 15 at 4:00PM CDT by NWS Duluth MN
      * WHAT...West winds 20 to 30 kt with gusts up to 40 kt and waves 4 to 7 ft. * WHERE...Port Wing to Sand Island WI, Sand Island to Bayfield WI, Oak Point to Saxon Harbor WI and Outer Apostle Islands Beyond 5 NM from Mainl…

### State Legislative Action — 75 new of 76 total
  - (2026-09-15) [Alaska HB 20] An Act relating to fees for paper documents; relating to unfair trade practices; and providing for an effective date.
      An Act relating to fees for paper documents; relating to unfair trade practices; and providing for an effective date.
  - (2026-09-15) [Alaska HB 210] An Act relating to workers' compensation coverage for disability from diseases for certain firefighters; relating to occupational disability benefits and medical benefits available und…
      An Act relating to workers' compensation coverage for disability from diseases for certain firefighters; relating to occupational disability benefits and medical benefits available under the public employees' retirement…
  - (2026-09-15) [Alaska HB 175] An Act relating to the term of the chair of the Regulatory Commission of Alaska; and relating to the qualifications of members of the Regulatory Commission of Alaska.
      An Act relating to the term of the chair of the Regulatory Commission of Alaska; and relating to the qualifications of members of the Regulatory Commission of Alaska.
  - (2026-09-15) [Alaska SB 79] An Act relating to wage payments; and providing for an effective date.
      An Act relating to wage payments; and providing for an effective date.
  - (2026-09-15) [Alaska HB 184] An Act relating to financing by the Alaska Industrial Development and Export Authority for workforce housing development projects; relating to a mandatory exemption from municipal prop…
      An Act relating to financing by the Alaska Industrial Development and Export Authority for workforce housing development projects; relating to a mandatory exemption from municipal property taxes for certain assets of the…
  - (2026-09-15) [Alaska HB 197] An Act relating to the practice of dental hygiene; establishing an executive administrator position for the Board of Dental Examiners; and relating to the ownership of dental offices a…
      An Act relating to the practice of dental hygiene; establishing an executive administrator position for the Board of Dental Examiners; and relating to the ownership of dental offices and clinics.

### Ukrainian Internal News (national + local Kyiv) — 67 new of 134 total
  - (2026-09-15) Глава МЗС Угорщини подала скаргу в прокуратуру щодо дорогих перельотів Сійярто | LEDE: Міністерка закордонних справ Угорщини Аніта Орбан подала кримінальну скаргу на свого попередника Петера Сі] (uk:…
      Міністерка закордонних справ Угорщини Аніта Орбан подала кримінальну скаргу на свого попередника Петера Сійярто та його команду за те, що вони протягом останніх чотирьох років регулярно користувалися до
  - (2026-09-15) Лавров не сумнівається, що РФ поверне заморожені в ЄС активи | LEDE: Сергій Лавров повідомив, що Росія прагне добитися повернення резервів, арештованих у ЄС. Єврокомісія обговорює можливу конфі] (uk:…
      Сергій Лавров повідомив, що Росія прагне добитися повернення резервів, арештованих у ЄС. Єврокомісія обговорює можливу конфіскацію цих активів.
  - (2026-09-15) З Румунії екстрадували й арештували ексмера Рахова – він уже вийшов під заставу | LEDE: Віктора Медвідя, ексмера Рахова, підозрюють у розтраті майна. Прокуратура оскаржує розмір застави. Йому з] (uk:…
      Віктора Медвідя, ексмера Рахова, підозрюють у розтраті майна. Прокуратура оскаржує розмір застави. Йому загрожує до 8 років ув'язнення.
  - (2026-09-15) Фінляндія схвалила пакет допомоги Україні на 290 млн євро | LEDE: 34-й пакет оборонної допомоги від Фінляндії включає оснащення, якого Україна терміново потребує. Заява президента Александра Ст] (uk:…
      34-й пакет оборонної допомоги від Фінляндії включає оснащення, якого Україна терміново потребує. Заява президента Александра Стубба.
  - (2026-09-15) Україна висловила солідарність з Данією після інциденту з російським фрегатом | LEDE: Міністр закордонних справ України Андрій Сибіга висловив солідарність з Данією на тлі інциденту між фрегато] (uk:…
      Міністр закордонних справ України Андрій Сибіга висловив солідарність з Данією на тлі інциденту між фрегатом РФ і данським гелікоптером.
  - (2026-09-15) ВАКС зняв з Єрмака електронний браслет, бо той "загрожує його життю і здоров’ю" | LEDE: Вищий антикорупційний суд продовжив строк дії процесуальних обов'язків, покладених на колишнього керівник] (uk:…
      Вищий антикорупційний суд продовжив строк дії процесуальних обов'язків, покладених на колишнього керівника Офісу президента Андрія Єрмака, підозрюваного у легалізації майна, отриманого злочинним шляхом, водночас звільнив…

### IT, InfoSys & cybersecurity news (last 7 days) — 47 new of 57 total
  - (2026-09-15) [BleepingComputer] CISA: Critical VMware RCE flaw now exploited by ransomware gangs
      The U.S. Cybersecurity and Infrastructure Security Agency (CISA) warned security teams that ransomware gangs have now joined ongoing attacks exploiting a critical VMware vCenter vulnerability patched in July. [...]
  - (2026-09-15) [BleepingComputer] Suspected Black Axe gang leaders face cybercrime charges in the US
      Five alleged leaders of the Black Axe cybercrime syndicate, known for its involvement in global-scale cyber-enabled financial fraud, have been extradited to the United States to face wire fraud and money laundering charg…
  - (2026-09-15) [BleepingComputer] Microsoft confirms KB5002914 Excel update breaks copy and paste
      Microsoft has confirmed that copy and paste may silently fail for some Excel users after installing the September 2026 KB5002914 security update. [...]
  - (2026-09-15) [BleepingComputer] Cisco patches Secure Email Gateway zero-day exploited in attacks
      Cisco warned customers to patch a critical Secure Email Gateway zero-day security flaw that threat actors have been exploiting in attacks. [...]
  - (2026-09-15) [The Hacker News] Human Attacker Exploits Marimo RCE, Reaches SSH Bastion in Eight Seconds
      With artificial intelligence (AI) shrinking the window between vulnerability discovery and exploitation and lowering the barrier to entry for bad actors, new findings from Sysdig show that skilled human operators can mov…
  - (2026-09-15) [The Hacker News] Attack Chains, Not Just Attack Surfaces: Why Testing Individual Techniques Misses the Point
      Introduction Security teams have gotten pretty good at testing against what can hurt them. Can this EDR agent catch this payload? Will my organization fail the phishing simulation? Does this SIEM rule fire on this partic…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-15) 424B3 - LB PHARMACEUTICALS INC (0001691082) (Filer)
      filed 2026-09-15 12:22 UTC — Filed: 2026-09-15 AccNo: 0001193125-26-391384 Size: 39 KB
  - (2026-09-15) 497J - Tidal Trust II (0001924868) (Filer)
      filed 2026-09-15 12:15 UTC — Filed: 2026-09-15 AccNo: 0001999371-26-020517 Size: 6 KB
  - (2026-09-15) 424B5 - Xylem Inc. (0001524472) (Filer)
      filed 2026-09-15 12:14 UTC — Filed: 2026-09-15 AccNo: 0001193125-26-391375 Size: 593 KB
  - (2026-09-15) [Weber Mary Rose] Form 4 (Reporting)
      filed 2026-09-15 12:11 UTC · role: Reporting — Filed: 2026-09-15 AccNo: 0002127850-26-000002 Size: 5 KB
  - (2026-09-15) [Lincoln International, Inc.] Form 4 (Issuer)
      filed 2026-09-15 12:11 UTC · role: Issuer — Filed: 2026-09-15 AccNo: 0002127850-26-000002 Size: 5 KB
  - (2026-09-15) [Marvin Kristin Marie] Form 4 (Reporting)
      filed 2026-09-15 12:09 UTC · role: Reporting — Filed: 2026-09-15 AccNo: 0002114339-26-000002 Size: 5 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-09-15) JAF9BV (Bulgaria)
      icao24: 4520ce · position: (35.2163, -6.555) · alt: 9540m · 858km/h
  - (2026-09-15) GAF623 (Germany)
      icao24: 3f6533 · position: (53.0357, 9.8952) · alt: 6918m · 827km/h
  - (2026-09-15) FAF7812 (France)
      icao24: 39a858 · position: (43.017, 12.0695) · alt: 3352m · 289km/h
  - (2026-09-15) PUMA87 (Slovenia)
      icao24: 506e19 · position: (45.9031, 15.5441) · alt: 487m · 174km/h
  - (2026-09-15) PUMA72 (Slovenia)
      icao24: 506e1d · position: (45.9348, 15.6201) · alt: 548m · 32km/h
  - (2026-09-15) PUMA68 (Slovenia)
      icao24: 506e1c · position: (45.9158, 15.534) · alt: 487m · 156km/h

### Paper Trading Scorecard — 27 new of 137 total
  - (2026-09-15) [Manifold] Will the Clay Mathematics Institute formally recognize OpenAI's Navier-Stokes solution as correct before 2029?
  - (2026-09-15) [Manifold] Nvidia closes at $213.00 or higher on Tuesday 15 September 2026?
  - (2026-09-15) [Manifold] Will 0x876611867717dE6b6dff30da5CeF9feB620eE1ea REACH more than 100.00 USDC Base by September 21th 11:59 pm UTC
  - (2026-09-15) [Manifold] Is Mike Rogers a COWARD? (Michigan senate)
  - (2026-09-15) [Manifold] Brazil 2026 Election: Will the U.S. impose new Global Magnitsky sanctions on a Brazilian before the elections?
  - (2026-09-15) [Manifold] Will the California legislature override any gubernatorial veto by the end of 2027

### Court opinions of consequence (federal & state) — 21 new of 60 total
  - (2026-09-14) Arizona Supreme Court: Tyler Strang v. malay/hernandez
  - (2026-09-14) U.S. Court of Appeals, Federal Cir.: Ncs Multistage Inc. v. Nine Energy Service, Inc.
  - (2026-09-14) U.S. Court of Appeals, Federal Cir.: Texasldpc Inc. v. Broadcom Inc.
  - (2026-09-14) U.S. Court of Appeals, 6th Cir.: United States v. Chance York
  - (2026-09-14) U.S. Court of Appeals, 7th Cir.: American Academy of Pediatrics v. James Uthmeier
  - (2026-09-14) U.S. Court of Appeals, 7th Cir.: American Academy of Pediatrics v. James Uthmeier

### U.S. Federal Action — 16 new of 16 total
  - (2026-09-15) Patriot Day 2026, the 25th Anniversary of the September 11 Terrorist Attacks
  - (2026-09-15) Federal Employees Health Benefits Program: Optimizing FEHB Plan Offerings
      This request for information (RFI) seeks public input on how to optimize health benefits plan options offered in the Federal Employees Health Benefits (FEHB) Program, which includes the Postal Service Health Benefits (PS…
  - (2026-09-15) Promoting Employee Accountability
      OPM is reopening the public comment period for additional comments on OPM data and a new report published by a nongovernmental organization. OPM is releasing current data that is relevant to the proposed rule published o…
  - (2026-09-15) Airworthiness Directives; MD Helicopters, LLC Helicopters
      The FAA is superseding Airworthiness Directive (AD) 2024-23- 06, which applied to certain MD Helicopters, LLC Model 369, 369A, 369D, 369E, 369F, 369FF, 369H, 369HE, 369HM, 369HS, 500N, and 600N helicopters. AD 2024-23-06…
  - (2026-09-15) Pacific Halibut Fisheries of the West Coast; Inseason Action for the 2026 Area 2A Pacific Halibut Directed Commercial Fishery
      NMFS announces an inseason action for the 2026 Pacific halibut non-Tribal directed commercial fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds a fishing period, Septem…
  - (2026-09-15) Amendment of Class D and Class E Airspace Over Hyannis, MA
      This action updates the airport name for Cape Cod Gateway Airport in the Falmouth, MA Class E5 airspace legal description. This action also updates verbiage in the Hyannis, MA Class D airspace legal description to comply…

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 109 total
  - (2026-09-14) [OFAC] Iran-related Designation; Issuance of Amended Venezuela-related General License and Frequently Asked Question - ofac.treasury.gov
      Iran-related Designation; Issuance of Amended Venezuela-related General License and Frequently Asked Question ofac.treasury.gov
  - (2026-09-14) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 52C Authorizing Certain Tr - ofac.treasury.gov
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 52C Authorizing Certain Tr ofac.treasury.gov
  - (2026-09-10) [OFAC] Iran-related and Counter Terrorism Designations; Licensing Policy Update under Operation Economic Outcast; Settlement Agreement between OFAC and an Individual - ofac.treasury.gov
      Iran-related and Counter Terrorism Designations; Licensing Policy Update under Operation Economic Outcast; Settlement Agreement between OFAC and an Individual ofac.treasury.gov
  - (2026-09-09) [OFAC] Transnational Criminal Organizations Designations; Counter Terrorism Designation; Issuance of New and Amended Frequently Asked Questions - ofac.treasury.gov
      Transnational Criminal Organizations Designations; Counter Terrorism Designation; Issuance of New and Amended Frequently Asked Questions ofac.treasury.gov
  - (2026-09-10) [OFAC] IRANIAN TRANSACTIONS AND SANCTIONS REGULATIONS STATEMENT OF LICENSING POLICY ON IRAN-RELATED REQUESTS Consistent with current U. - ofac.treasury.gov
      IRANIAN TRANSACTIONS AND SANCTIONS REGULATIONS STATEMENT OF LICENSING POLICY ON IRAN-RELATED REQUESTS Consistent with current U. ofac.treasury.gov
  - (2026-09-08) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Suspension of Certain Iranian Transactions and Sanctions Regulations General Licenses Updated: - ofac.treasury.gov
      OFFICE OF FOREIGN ASSETS CONTROL Suspension of Certain Iranian Transactions and Sanctions Regulations General Licenses Updated: ofac.treasury.gov

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-09-14) M 5.3 - off the coast of Michoacan, Mexico
      M5.3 · off the coast of Michoacan, Mexico · depth 10 km
  - (2026-09-14) M 5.2 - 135 km SE of Gizo, Solomon Islands
      M5.2 · 135 km SE of Gizo, Solomon Islands · depth 10 km
  - (2026-09-14) M 5.0 - 69 km NW of Lae, Papua New Guinea
      M5.0 · 69 km NW of Lae, Papua New Guinea · depth 119.787 km
  - (2026-09-14) M 4.9 - 69 km SSW of Patea, New Zealand
      M4.9 · 69 km SSW of Patea, New Zealand · depth 97.616 km
  - (2026-09-14) M 4.9 - 28 km WSW of Sipí, Colombia
      M4.9 · 28 km WSW of Sipí, Colombia · depth 48.051 km
  - (2026-09-14) M 4.9 - 20 km SSW of Sipí, Colombia
      M4.9 · 20 km SSW of Sipí, Colombia · depth 59.835 km

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-09-15) Will Deportivo Alavés win on 2026-09-15?
      yes price: 57% · 24h volume: $498,888 · resolves 2026-09-15
  - (2026-09-15) Biella: Pavel Lagutin vs Enrico Dalla Valle
      yes price: 100% · 24h volume: $486,367 · resolves 2026-09-22
  - (2026-09-15) Will the US confirm that aliens exist by September 30?
      yes price: 0% · 24h volume: $452,568 · resolves 2026-10-01
  - (2026-09-15) Counter-Strike: Brute vs G2 Ares (BO3) - NODWIN Clutch Series Group Stage
      yes price: 100% · 24h volume: $412,068 · resolves 2026-09-15
  - (2026-09-15) US x Iran Effective Ceasefire by September 4?
      yes price: 98% · 24h volume: $411,612 · resolves 2026-09-04
  - (2026-09-15) Valencia: Alicia Herrero Linana vs Lucia Cortez Llorca
      yes price: 68% · 24h volume: $366,857 · resolves 2026-09-21

### Commentary & analysis (last 7 days) — 3 new of 4 total
  - (2026-09-15) [Marginal Revolution] The striking thing is how late the market moved
      Here’s the S&P 500 (daily close) with the key COVID and policy events marked; the numbered key is below the chart. Event key: Dec 31 – China reports the Wuhan pneumonia cluster to the WHO Jan 21 – First confirmed US case…
  - (2026-09-15) [Marginal Revolution] Those new service sector jobs
      Horwitz is in the business of playing a version of mom for local college students. Concierge companies offering student support have existed for decades. But in recent years, a new crop of upstarts — such as Horwitz’s co…
  - (2026-09-15) [Marginal Revolution] Did the ACA reduce mortality?
      Many of us brought up related points at the time, but basically we were booed off the reservation: While recent research has provided evidence that the Medicaid expansions of the Affordable Care Act (ACA) reduced mortali…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 23 total
  - (2026-09-14) CVE-2026-76461 · Cisco Secure Email Gateway: Cisco Secure Email Gateway SQL Injection Vulnerability
      vendor: Cisco · product: Secure Email Gateway · CISA remediation by 2026-09-17

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-15) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=16, 7d-median=19, 14d-median=17; carrying terms: proposed, navigable, unless, final, proposes, prohibited, safety, guard, certain, vessels, commission, coast
- state_bills: today=76, 7d-median=97, 14d-median=88; carrying terms: instead, services, residential, administered, provides, within, child, projects, subject, provide, education, regulates
- state_news: today=540, 7d-median=549, 14d-median=586; carrying terms: challenging, families, released, thousands, projects, class, morning, provide, spent, proposed, financial, trees
- local_news: today=236, 7d-median=227, 14d-median=230; carrying terms: atlantamagazine, season, class, google, national, charged, health, north, state, weekend, appeared, https
- foreign_news: today=981, 7d-median=986, 14d-median=1004; carrying terms: palestinians, europe, goods, northern, chinadaily, italia, panel, boxing, canadian, morning, trial, spent
- chinese_internal: today=282, 7d-median=284, 14d-median=282; carrying terms: title, people, cbmixkfvx, cbmia, target, cbmib, cbmiykfvx, cbmiakfvx, cbmibkfvx, cbmizkfvx, lxtfb, cbmiw
- russian_internal: today=1042, 7d-median=1059, 14d-median=1050; carrying terms: media, novaya, reuters, europe, raquo, client, forbidden, found, politico, bloomberg, error, title
- ukrainian_internal: today=134, 7d-median=135, 14d-median=133; carrying terms: operations, residential, ukraine, europe, faces, censor, attacked, reports, reportedly, million, military, sanctions
- ukraine_theater: today=309, 7d-median=351, 14d-median=451; carrying terms: hnefr, ukraine, hoaerxuu, cbmimwfbvv, points, vlpia, strglxvoveg, rqqxnnnvvsef, suvzbc, cuxqqxpqsnjnwe, adviser, yxzjefhxeuowodv
- paper_bets: today=137, 7d-median=128, 14d-median=131; carrying terms: decrease, succeed, seats, robot, mbappe, general, primary, kalshi, human, leader, johnny, playoff
- weather: today=106, 7d-median=106, 14d-median=112; carrying terms: limbs, moving, index, rivers, depth, afdsew, northern, september, conditions, combined, isolated, louis
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexuseu, recession, supply, cpiaucsl, headline, pcepilfe, latest, consumption, money, unrate, labor, cpilfesl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, nasdaq, large, close, equities, china, range, agriculture, yield, commodities, natural, crypto
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=109, 7d-median=108, 14d-median=107; carrying terms: security, serious, controlled, services, qaida, operations, ukraine, annexation, moldova, chemical, guatemala, space
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: client, quantitative, httperror, unauthorized, quiverquant, congresstrading, error, quiver, https
- billionaires: today=0, 7d-median=0, 14d-median=15
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, appeals, national, supreme, court, company, university, robert, opinion, brown, rivera, williams
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, filed, reporting, accno, trust, filer, group, subject, tidal, brian, global, robert
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, ossoff, krishnamoorthi, graham, receipts, michael, elect, pinkston, platner, disbursements, sherrod, james
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=0, 7d-median=38, 14d-median=38; carrying terms: hezbollah, israel, english, sanctions, turkish, attack, iranian, minister
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, germany, ground, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: ituri, evolve, noted, ventilatory, previously, parganas, resulting, cereulide, press, districts, additi, history
- cisa_kev: today=23, 7d-median=23, 14d-median=22; carrying terms: artifactory, function, microsoft, critical, buffer, vulnerability, netscaler, write, authentication, citrix, injection, bounds
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=13, 7d-median=11, 14d-median=12; carrying terms: depth, islands, indonesia, mexico, papua, zealand, guinea
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: decrease, interest, championship, champions, change, meeting, league, rates, price, september, donetsk, resolves
- commentary: today=4, 7d-median=6, 14d-median=6; carrying terms: conversableeconomist, class, marginal, conversable, revolution, economist, https, evidence, story, recent, explain, price
- tech_news: today=57, 7d-median=57, 14d-median=56; carrying terms: security, rsquo, inbox, review, openai, weekly, million, research, spectrum, researchers, newsletter, state
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: wittman, feenstra, victoria, raphael, christian, suhas, advisers, debbie, ernst, hinson, quigley, danny
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, sufficient, unavailable, consensus, today, evidence, decision, market, placed, module, identify, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.
- [2026-09-10] ECB press: Monetary policy decisions
- [2026-09-10] ECB press: Christine Lagarde, Boris Vujčić: Monetary policy statement (with Q&A)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-11] ECB press: Philip R. Lane: Outlook for the euro area economy
- [2026-09-12] ECB press: Christine Lagarde: Europe seen from Normandy
- [2026-09-12] ECB press: Christine Lagarde: Interview with Ouest-France
- [2026-09-14] ECB press: Isabel Schnabel: Macroeconomic, fiscal and financial stability in a shock-prone world
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*