# WORLDSCOPE morning brief — 2026-09-06

## Headline
2906 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (653) · Ukraine Theater (total-war monitoring) (623) · Russian Internal News (state + in-exile) (548) · World leaders & government officials (324) · Chinese Internal News (208) · Local News: St. Louis + Atlanta (119) · State-Level News (99) · U.S. Weather + Severe / Climate Outlooks (90) · Ukrainian Internal News (national + local Kyiv) (56) · Conflict & unrest (GDELT, last 48h) (40) · Sanctions & Designations (recent) (30) · GDELT GKG — themes / entities / watch areas (25)

## What changed today
### International News + Multilateral Institutions — 653 new of 1005 total
  - (2026-09-06) [Global] India news: Rahul Gandhi backs student protests in Maharashtra
      Opposition Rahul Gandhi has said that students are "tormented" by the ruling Bharatiya Janata Party. The Congress politician has demanded immediate action into the demands of Maharashtra student protesters. DW has more.
  - (2026-09-06) [Global] Germany, Kosovo unite against ticks carrying deadly virus
      Germany has high-security labs while Kosovo has Hyalomma ticks and experience with the deadly Crimean-Congo hemorrhagic fever. Working together, German and Kosovar scientists are fighting the disease and its vectors.
  - (2026-09-06) [Global] Germany plans anti-drone shield after Leipzig attack: report
      Several German cities will receive rapidly deployable units capable of defending against drone strikes on critical infrastructure, Bild am Sonntag newspaper reported.
  - (2026-09-06) [Global] How climate change and food insecurity could fuel future conflicts
      Climate change, conflict, and trade tensions are putting pressure on the global food system. New research suggests the biggest risk is not food shortages, but whether societies can peacefully adapt to change.
  - (2026-09-06) [Global] Indonesia: Flights canceled as Anak Krakatau volcano erupts
      The spread of ash after the volcanic eruption of Anak Krakatau has impacted thousands of passengers, as flights were canceled at Jakarta's international airport.
  - (2026-09-06) [Global] Saxony-Anhalt: Far-right AfD eyes power in German state vote
      Although the eastern state accounts for less than 3% of the nationwide electorate, the election outcome could serve as a bellwether about the far-right AfD's prospects in the rest of the country. DW has the latest.

### Ukraine Theater (total-war monitoring) — 623 new of 798 total
  - (2026-09-06) [DeepStateMap] frontline snapshot, 526 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-05) [FIRMS] thermal anomaly 51.077, 34.781 (FRP 0.99 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-05 0020Z, FRP 0.99 MW
  - (2026-09-05) [FIRMS] thermal anomaly 50.229, 33.402 (FRP 1.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-05 0020Z, FRP 1.18 MW
  - (2026-09-05) [FIRMS] thermal anomaly 48.531, 34.647 (FRP 1.44 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-05 0022Z, FRP 1.44 MW
  - (2026-09-05) [FIRMS] thermal anomaly 48.533, 34.619 (FRP 3.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-05 0022Z, FRP 3.78 MW
  - (2026-09-05) [FIRMS] thermal anomaly 48.529, 34.618 (FRP 3.78 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-05 0022Z, FRP 3.78 MW

### Russian Internal News (state + in-exile) — 548 new of 845 total
  - (2026-09-06) Bild: Германия после диверсии в аэропорту Лейпцига развернет «киберкупол» и разрешит критическим предприятиям «активно противодействовать» дронам | LEDE: Германия на фоне инцидента в аэропор] (ru: Bil…
      Германия на фоне инцидента в аэропорту Лейпцига ужесточит подход к борьбе с российскими диверсиями и создаст «щит безопасности», сообщил федеральный министр внутренних дел Александер Добриндт.
  - (2026-09-06) Стив Уиткофф и Джаред Кушнер приехали в Киев. Это их первый визит в Украину | LEDE: Посланники президента США Стив Уиткофф и Джаред Кушнер прибыли в Киев, сообщают источники Kyiv Independent] (ru: Сти…
      Посланники президента США Стив Уиткофф и Джаред Кушнер прибыли в Киев, сообщают источники Kyiv Independent, а также источники «РБК-Украина».
  - (2026-09-06) «Дикая лошадь под номером девять» Мартина Макдоны: экзистенциальная трагикомедия об агентах ЦРУ на острове Пасхи. Антон Долин — о роли Джона Малковича, каких не было в его карьере | LEDE: На] (ru: «Ди…
      На Венецианском кинофестивале прошла премьера новой картины знаменитого ирландского драматурга и режиссера Мартина Макдоны «Дикая лошадь под номером девять». Это кровавая черная комедия, которая к финалу окончательно пер…
  - (2026-09-06) «Мэйдэй» — дурацкий добрый боевик об американском летчике (Райан Рейнольдс) и бывшем кагэбэшнике (Кеннет Брана), которые вместе убегают от красноармейцев. Если вы ценитель клюквы из 1980-х, он ] (ru:…
      На Apple TV вышел фильм о дружбе сбитого летчика ВМС США и бывшего кагэбэшника, которые пытаются выбраться из СССР 1987 года. Шекспировский актер Кеннет Брана вновь — не в первый раз за карьеру — играет советского гражда…
  - (2026-09-06) Немецкий Isar Aerospace вывел на околоземную орбиту пять спутников. Это первый коммерческий орбитальный запуск с территории континентальной Европы | LEDE: Немецкий аэрокосмический стартап Is] (ru: Нем…
      Немецкий аэрокосмический стартап Isar Aerospace запустил ракету-носитель Spectrum, которая вывела на низкую околоземную орбиту пять спутников.
  - (2026-09-06) Визит посланников Трампа в Кремль, похоже, не приблизил мир: Путин по-прежнему готов прекратить войну «только на своих условиях». Рассказываем главное о поездке Уиткоффа и Кушнера в Москву | LE] (ru:…
      Стив Уиткофф и Джаред Кушнер должны были привезти в Москву новое предложение Дональда Трампа о прекращении войны. И многие элементы их вчерашнего визита в Кремль указывали на серьезность намерений Вашингтона возродить пе…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 208 new of 264 total
  - (2026-09-06) 商品详情 - 财新商城 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1zazMwbHpRcksxT3p4WkpmQWZDRFY5QnhSRnBBWWdlOFk3RFJRbi1ZenZPOW1RY1dMYUhvVnpBUGNFM0xwSlZUSlAzQ2tHZHFod3NjcWdlbGlmN2R] (zh:…
      商品详情 财新商城
  - (2026-09-05) 私募股权投资 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE8zTVZQbHJ2Rm9QbTJTWjRzbmV3aVFCX2hHUk12YjBmNnRPZ2xFOGlwMGh6OTdvYXVEVDc5RjlDTkUxS0ZJSEVSTHlaMW9acl] (zh:…
      私募股权投资 deepview.caixin.com
  - (2026-09-06) 《欢迎来龙餐馆》原型讲述：巴格达淘金路｜故事 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9BRks3VmpfcFp3NS1zR2FNS3lsME9rb0hHWDJBYnJnMDFfcGlISVZvOWFuNG0teEYxeWRucENQRjMxNFE3WGtJSWRxWm9xYWp] (zh:…
      《欢迎来龙餐馆》原型讲述：巴格达淘金路｜故事 财新
  - (2026-09-05) 财新闻｜特斯拉推出无人驾驶“赛博出租车” - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1zRGt4ZlE0M0NVNFJqVEJsYnhmdlpBd1h3dFpPaWQxN1BoWUtZV3dXRlBGa2tFV1NBaUNWRDBtZV9lTlo0V1E1R01BZVZhaUR0b] (zh:…
      财新闻｜特斯拉推出无人驾驶“赛博出租车” 财新
  - (2026-09-05) “新教育学堂”歧路 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiT0FVX3lxTFBSd1E0Vm9zRUZYZXZ6dVcwd2NMNHhjSFBHVUFvd0pTcUhGa0dqbEVicHdscFotbFMtWEEzeHdJUHFmeVVqTzBmaUtBYXkzbjQ?oc=5" targ] (zh:…
      “新教育学堂”歧路 财新周刊
  - (2026-09-06) 火线评论｜“内卷外溢”病根在国内 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1nRTFTLXNIdWlsUHRxTldvRVk0NjdoZUVMQTRQb19PdXFWUE05eW9fZ0p5QnBwMGNVVDBVOWxmRWlOaXVfUVhIU2lNdl84THBpMExzS] (zh:…
      火线评论｜“内卷外溢”病根在国内 财新

### Local News: St. Louis + Atlanta — 119 new of 208 total
  - (2026-09-06) [St. Louis] A 'crisis' in Missouri elections? Supreme Court puts the blame on one state official
      The unanimous decision from Missouri's high court made clear who was to blame for the chaos: Secretary of State Denny Hoskins.
  - (2026-09-06) [St. Louis] Messenger: St. Louis woman sends ‘thank you’ notes to judges amid rising threats
      New report says threats to federal judges are rising every year as Trump administration heaps scorn upon them.
  - (2026-09-06) [St. Louis] Worthy: Blues captaincy a big step for Robert Thomas’ legacy in St. Louis
      It feels like a potentially transformative moment for the Blues, who have named Robert Thomas as captain and introduced assistant captains Philip Broberg, Dylan Holloway, Jake Neighbours and Colton Parayko.
  - (2026-09-06) [St. Louis] Principia field hockey looks to make a name for itself for first time in 26 years
      “I’m just so grateful that we have this opportunity," Principia field hockey player Hazel Stewart said.
  - (2026-09-06) [St. Louis] From no-no to uh-oh: Cardinals lefty Matthew Liberatore seeks ways to stop snowball rallies
      DENVER — In his ongoing attempt to minimize the single innings that mushroom on him, Cardinals starter Matthew Liberatore has changed his approach, changed how he mixes pitches, changed a handful of different ways he att…
  - (2026-09-06) [St. Louis] David Hoffmann: Local news can bring communities together
      Hello, I’m David Hoffmann. Like many of you, I’ve been thinking a lot about our country, our communities and how we find our way back to one another.

### State-Level News — 99 new of 408 total
  - (2026-09-05) [California] California could be first in the nation to create smoke-damage standards
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/080226-Renters-and-Insurance-AD-CM-01.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post…
  - (2026-09-05) [Alaska] Alaska Lt. Gov. Dahlstrom reverses herself, puts Treg Taylor back in governor’s race
      Late Friday night, Alaska Lt. Gov. Nancy Dahlstrom said she will reverse a decision she made Monday and will certify former attorney general Treg Taylor as a final-four candidate in Alaska’s race for governor. Dahlstrom,…
  - (2026-09-06) [Arkansas] Election experts see few legal options for Trump to meddle with polling places
      WASHINGTON — President Donald Trump said earlier this year he’d “do anything necessary to make sure we have honest elections” this fall, declining to rule out sending the National Guard or federal law enforcement officer…
  - (2026-09-06) [Arkansas] Press freedom shouldn’t be a casualty in Arkansas’ data center wars
      There’s no such thing as a slam dunk court case, but the constitutional argument against prior restraint comes close. For nearly a century, the U.S. Supreme Court has ruled against efforts to prevent news outlets from pu…
  - (2026-09-06) [Arkansas] Labor unions are growing, but where depends on state politics
      Labor union membership continues to climb in the United States, though the increase remains sharply divided by the politics of individual states. Last year, the nation added more than 411,000 union members — the largest…
  - (2026-09-06) [Connecticut] Volunteer fire departments are shrinking. For some, it’s a call to action
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/08/011_firefighter_JL_0817-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchp…

### U.S. Weather + Severe / Climate Outlooks — 90 new of 92 total
  - (2026-09-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-06) [Moderate] Special Weather Statement: Special Weather Statement issued September 6 at 7:26AM EDT by NWS Morristown TN
      At 725 AM EDT, Doppler radar was tracking a strong thunderstorm over Abingdon, moving southeast at 20 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock do…
  - (2026-09-06) [Moderate] Special Weather Statement: Special Weather Statement issued September 6 at 7:17AM EDT by NWS Raleigh NC
      Areas of fog may be locally dense through 9 AM. Visibility may vary over short distances and decrease to one quarter to one half mile in some areas. Motorists should slow down, allow extra following distance, and be aler…
  - (2026-09-06) [Moderate] Special Weather Statement: Special Weather Statement issued September 6 at 6:02AM CDT by NWS Chicago IL
      Areas of dense fog will reduce visibilities to locally down to one quarter mile or less early this morning from portions of the northwest suburbs of Chicago west into portions of north central Illinois. Fog will quickly…
  - (2026-09-06) [Severe] Special Marine Warning: Special Marine Warning issued September 6 at 5:57AM CDT until September 6 at 7:00AM CDT by NWS New Orleans LA
      SMWLIX The National Weather Service in New Orleans has issued a * Special Marine Warning for... Coastal Waters from Port Fourchon LA to Lower Atchafalaya River LA out 20 nm... Coastal waters from the Southwest Pass of th…
  - (2026-09-06) [Moderate] Special Weather Statement: Special Weather Statement issued September 6 at 6:44AM EDT by NWS Morristown TN
      At 643 AM EDT, Doppler radar was tracking a cluster of strong thunderstorms over Lebanon, moving southeast at 20 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty winds cou…

### Ukrainian Internal News (national + local Kyiv) — 56 new of 130 total
  - (2026-09-06) Зеленський зустрів Віткоффа та Кушнера, почались перемовини | LEDE: Джаред Кушнер і Стів Віткофф відвідали Україну та провели перемовини з Володимиром Зеленським щодо врегулювання війни. Очікую] (uk:…
      Джаред Кушнер і Стів Віткофф відвідали Україну та провели перемовини з Володимиром Зеленським щодо врегулювання війни. Очікуються нові кроки.
  - (2026-09-06) Віткофф та Кушнер вперше прибули до України | LEDE: Посланці президента США Дональда Трампа Стів Віткофф і Джаред Кушнер прибули до України у неділю.] (uk: Віткофф та Кушнер вперше прибули до України)
      Посланці президента США Дональда Трампа Стів Віткофф і Джаред Кушнер прибули до України у неділю.
  - (2026-09-06) Кравченко після обшуків НАБУ наказав перевірити працівників ОГП на поліграфі | LEDE: Генеральний прокурор Руслан Кравченко заперечив причетність до можливого "кришування" незаконних кол-центрів] (uk:…
      Генеральний прокурор Руслан Кравченко заперечив причетність до можливого "кришування" незаконних кол-центрів і доручив провести перевірки в Офісі генпрокурора, а працівників підрозділів, пов'язаних із такими справами, пе…
  - (2026-09-06) "Мир потрібен": Зеленський зустрівся зі своїми переговорниками перед приїздом американців | LEDE: Президент Володимир Зеленський обговорив підготовку до переговорів зі Стівом Віткоффом та Джаре] (uk:…
      Президент Володимир Зеленський обговорив підготовку до переговорів зі Стівом Віткоффом та Джаредом Кушнером у Києві 6 вересня.
  - (2026-09-06) Від бутербродів на кордоні до антиукраїнських коментарів: що сталося з польською солідарністю | LEDE: ] (uk: Від бутербродів на кордоні до антиукраїнських коментарів: що сталося з польською)
  - (2026-09-06) Міноборони РФ заявило про атаку понад 250 українських безпілотників | LEDE: Міністерство оборони Росії заявило, що в ніч на 6 вересня російська ППО нібито перехопила та знищила 258 українських ] (uk:…
      Міністерство оборони Росії заявило, що в ніч на 6 вересня російська ППО нібито перехопила та знищила 258 українських безпілотників.

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-06) [United States] Child Critically Ill With Brain - Eating Amoeba After Swimming In The Kinneret
      domain: theyeshivaworld.com · language: English · tone:
  - (2026-09-06) [India] War against drugs : Modi govt has prepared roadmap to make India drug - free by 2029 , says Amit Shah
      domain: economictimes.indiatimes.com · language: English · tone:
  - (2026-09-06) [Australia] Firies battle blazes as spring temperatures soar
      domain: easternriverinachronicle.com.au · language: English · tone:
  - (2026-09-06) [India] Samastha anti - women stance is a century - old : Does it still hold sway in Kerala ?
      domain: thenewsminute.com · language: English · tone:
  - (2026-09-06) [United States] This Quentin Tarantino Western Has His Only Good Guy
      domain: collider.com · language: English · tone:
  - (2026-09-06) [United Kingdom] Operation Market Garden in focus at Staffordshire Regiment Museum event
      domain: lichfieldlive.co.uk · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-09-06) [Israel-Iran-Hezbollah axis · keywords] Israel kills 4 , including 2 girls , in fresh S . Lebanon truce violation
      dailysabah.com · English · tone NA
  - (2026-09-06) [Israel-Iran-Hezbollah axis · keywords] Lebanon says 4 dead in strikes that Israel calls response to Hezbollah drones
      standardmedia.co.ke · English · tone NA
  - (2026-09-06) [Israel-Iran-Hezbollah axis · keywords] Miriam Margolyes : Im not a rock star , Im a little old lady
      rte.ie · English · tone NA
  - (2026-09-06) [Israel-Iran-Hezbollah axis · keywords] RT speaks to husband of Lebanese bride killed in Israeli airstrike
      greekherald.com · English · tone NA
  - (2026-09-06) [Israel-Iran-Hezbollah axis · keywords] ARE ISRAEL AND THE US ON THE SAME PAGE WHEN IT COMES TO THE IRANIAN NUCLEAR THREAT ?
      isracast.com · English · tone NA
  - (2026-09-06) [Israel-Iran-Hezbollah axis · keywords] October 7th blessings ? Muslim Brotherhood - linked cleric celebrates Mamdani rise
      israelnationalnews.com · English · tone NA

### Government & military aircraft airborne (OpenSky) — 18 new of 19 total
  - (2026-09-06) JAF50T (Bulgaria)
      icao24: 4520ce · position: (40.8563, -3.0566) · alt: 11269m · 769km/h
  - (2026-09-06) JAF94H (Bulgaria)
      icao24: 4520aa · position: (39.6496, -4.1281) · alt: 11277m · 801km/h
  - (2026-09-06) CFC2986 (Canada)
      icao24: c2b55d · position: (52.2082, -0.7038) · alt: 358m · 314km/h
  - (2026-09-06) GAFZA (United Kingdom)
      icao24: 4013e1 · position: (52.2279, -1.5447) · alt: 579m · 94km/h
  - (2026-09-06) JAF29J (Belgium)
      icao24: 44d1ba · position: (50.4626, 6.0468) · alt: 6263m · 735km/h
  - (2026-09-06) JAF6BX (Belgium)
      icao24: 44d1b3 · position: (42.2089, 21.3192) · alt: 10363m · 799km/h

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-09-06) LoL: T1 vs Dplus KIA - Game 2 Winner
      yes price: 0% · 24h volume: $1,972,188 · resolves 2026-09-06
  - (2026-09-06) LoL: T1 vs Dplus KIA - Game 3 Winner
      yes price: 100% · 24h volume: $1,826,768 · resolves 2026-09-06
  - (2026-09-06) LoL: T1 vs Dplus KIA (BO5) - LCK Playoffs
      yes price: 66% · 24h volume: $1,651,518 · resolves 2026-09-06
  - (2026-09-06) Will Manchester United FC win on 2026-09-06?
      yes price: 48% · 24h volume: $1,320,727 · resolves 2026-09-06
  - (2026-09-06) LoL: Invictus Gaming vs Team WE - Game 4 Winner
      yes price: 100% · 24h volume: $1,059,108 · resolves 2026-09-06
  - (2026-09-06) LoL: Invictus Gaming vs Team WE (BO5) - LPL Playoffs
      yes price: 100% · 24h volume: $1,020,312 · resolves 2026-09-06

### USGS earthquakes (M4.5+, past day) — 15 new of 15 total
  - (2026-09-06) M 5.6 - 93 km SE of Kirakira, Solomon Islands
      M5.6 · 93 km SE of Kirakira, Solomon Islands · depth 38.543 km
  - (2026-09-05) M 5.6 - 96 km ESE of Isangel, Vanuatu
      M5.6 · 96 km ESE of Isangel, Vanuatu · depth 10 km
  - (2026-09-05) M 5.5 - 157 km E of Kokopo, Papua New Guinea
      M5.5 · 157 km E of Kokopo, Papua New Guinea · depth 114.364 km
  - (2026-09-06) M 5.3 - 108 km SW of Puerto Madero, Mexico
      M5.3 · 108 km SW of Puerto Madero, Mexico · depth 10 km
  - (2026-09-06) M 5.2 - southern East Pacific Rise
      M5.2 · southern East Pacific Rise · depth 10 km
  - (2026-09-05) M 5.2 - 77 km SSW of Sibolga, Indonesia
      M5.2 · 77 km SSW of Sibolga, Indonesia · depth 91.853 km

### IT, InfoSys & cybersecurity news (last 7 days) — 15 new of 56 total
  - (2026-09-06) [The Hacker News] Attackers Hijack MikroTik Routers Through Internet-Exposed SSH Without Authentication
      Attackers are exploiting MikroTik routers with their Secure Shell (SSH) remote-access service, which is reachable from the internet, to gain full administrative control without authentication, according to CERT Polska's…
  - (2026-09-06) [The Hacker News] Four REVSTEALER-Linked Modules Disable Windows Update and Defender to Run a Crypto Miner
      Elastic Security Labs has documented four previously unreported programs associated with REVSTEALER, an emerging Windows information stealer, that remain on an infected machine after the stealer deletes itself. One of th…
  - (2026-09-06) [The Register] Time lords prepare to kick leap seconds into the next millennium
      Risk of an unprecedented negative adjustment prompts plan to let UTC drift by as much as an hour
  - (2026-09-06) [The Register] US troops can still be tracked by purchased location data, and Congress wants to know why
      DoD controls on mobile ad identifiers haven't stopped military location data turning up for sale
  - (2026-09-05) [BleepingComputer] Over 5,400 hacked sites serve ClickFix payloads stored on the blockchain
      A massive cybercriminal operation is leveraging thousands of compromised small-business websites to deliver ClickFix payloads stored in smart contracts on the BNB Smart Chain (BSC). [...]
  - (2026-09-05) [The Hacker News] Unpatched Magento and Adobe Commerce Zero-Day Exploited to Backdoor Online Stores
      Attackers are exploiting a new unpatched vulnerability in Magento Open Source and Adobe Commerce that lets them run malicious code on an online store's server without logging in, Dutch e-commerce security company Sansec…

### Paper Trading Scorecard — 12 new of 131 total
  - (2026-09-06) [Polymarket] Will Tottenham win the 2026-27 English Premier League (EPL) Championship?
      This market will resolve according to the team that wins the 2026-27 English Premier League (EPL) Championship. If at any point it becomes impossible for a listed team to win the 2026-27 English Premier League (EPL) Cham…
  - (2026-09-06) [Manifold] Daily Coinflip
  - (2026-09-06) [Manifold] Will a new Smash Bros game be announced in the Nintendo Direct on 9/8?
  - (2026-09-06) [Manifold] Will the price of ICP hit $5 by Oct1
  - (2026-09-06) [Manifold] Will I laugh a genuine laugh this month (September)?
  - (2026-09-06) [Manifold] Will Anthropic announce having solved Navier Stokes but actually not have?

### Court opinions of consequence (federal & state) — 5 new of 60 total
  - (2026-09-04) U.S. Court of Appeals, 4th Cir.: United States v. Richard Rund
  - (2026-09-02) U.S. Court of Appeals, 9th Cir.: Construction Laborers Pension Trust of Greater St. Louis v. Funko Inc
  - (2026-09-02) U.S. Court of Appeals, 9th Cir.: United States v. Younes Nasri
  - (2026-09-02) U.S. Court of Appeals, 9th Cir.: Urias-Gaxiola v. Blanche
  - (2026-09-02) U.S. Court of International Trade: Zoetis Servs. LLC v. United States

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F7] TEXAS FARM BUREAU
      cycle 2016 · filing #1081726
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-06) [Marginal Revolution] *Why Not Bolivia?*
      The author is Calvin Korponai, and the subtitle is From Macchu Picchu into Bolivia in search of the Garden of Eden. Bolivia is a fantastic country to visit, more original than most people are expecting, and this is the b…
  - (2026-09-05) [Marginal Revolution] Short Videos, Big Self-Control Problems
      I study how short-form design amplifies self-control problems in digital media. Short units repeatedly renew temptation that lasts longer than each unit, turning local temptation into sustained overconsumption. Using mic…
  - (2026-09-05) [Marginal Revolution] Saturday assorted links
      1. Joaquin Rodrigo’s Toccata. Rodrigo by the way was blind, 2. China word of the day. 3. “People Keep Sneaking Into New York City Sewers. No One Knows Why.” (NYT) 4. Yiyang Zhuge has postponed her recording session with…

### Government Action: Sanctions + Procurement + Foreign Agents — 2 new of 104 total
  - (2026-09-05) [OFAC] Recent Actions - Office of Foreign Assets Control (.gov)
      Recent Actions Office of Foreign Assets Control (.gov)
  - (2026-09-06) [USASpending] $10,517,828,993 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration. Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=11, 7d-median=18, 14d-median=19; carrying terms: unless, safety, certain, national, proposed, action, specifically, service, associated, existing, applicable, special
- state_bills: today=75, 7d-median=78, 14d-median=79; carrying terms: court, include, safety, services, effective, certain, develop, provide, recommendations, resources, request, applicant
- state_news: today=408, 7d-median=623, 14d-median=636; carrying terms: toward, continues, dcist, indiana, legislative, tennessee, november, money, jones, safety, ruled, since
- local_news: today=208, 7d-median=234, 14d-median=238; carrying terms: court, georgia, stlmag, center, police, former, student, srcset, dining, investigation, officers, blank
- foreign_news: today=1005, 7d-median=1096, 14d-median=1044; carrying terms: middle, author, statement, bachelor, congress, address, mutual, applauded, money, streets, include, times
- chinese_internal: today=264, 7d-median=282, 14d-median=286; carrying terms: cbmibkfvx, blank, articles, title, cbmia, google, cbmibefvx, cbmib, https, cbmixkfvx, cbmickfvx, cbmiakfvx
- russian_internal: today=845, 7d-median=1042, 14d-median=1058; carrying terms: laquo, gazeta, europe, httperror, journal, title, axios, truth, istories, street, times, russian
- ukrainian_internal: today=130, 7d-median=128, 14d-median=124; carrying terms: europe, called, peace, infrastructure, intelligence, assessment, facilities, former, reportedly, tensions, critical, government
- ukraine_theater: today=798, 7d-median=735, 14d-median=674; carrying terms: etvveus, cbmiigjbvv, viirs, cbmif, zjzxj, lzsje, zlsfrhyk, vhvobe, simplifies, interactive, demining, tnrrrg
- paper_bets: today=131, 7d-median=132, 14d-median=132; carrying terms: caribbean, michigan, performing, funds, industrial, experience, senate, andrew, world, schumer, mamdani, source
- weather: today=92, 7d-median=145, 14d-median=138; carrying terms: please, flash, statement, continues, details, afddtx, humidity, heavy, front, moderate, afdlox, angeles
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: nonfarm, unemployment, commodities, dexjpus, cpilfesl, sheet, money, indicator, crude, pcepilfe, assets, recession
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, range, bitcoin, yield, commodities, corporate, china, proxy, futures, crypto, close, equities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=106, 14d-median=107; carrying terms: middle, operation, myanmar, guatemala, entities, active, chemical, terrorism, snapshot, military, taliban, syria
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, unauthorized, https, error, client, httperror, quiver, quantitative, quiverquant
- billionaires: today=0, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, appeals, connecticut, company, county, blanche, energy, board, insurance, health
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, holdings, brian, technologies, therapeutics, america, robert, george
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, brown, elect, sherrod, lindsey, senate, cycle, alexandria, platner, receipts, robert, raised
- gdelt_regions: today=0, 7d-median=9, 14d-median=9; carrying terms: japan, english
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, hezbollah, keywords, strikes, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: india, kingdom, language, hospital, response, canada, against, english, domain, trump
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=30, 14d-median=30; carrying terms: position, belgium, bulgaria, kingdom, canada, germany
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: middle, analyzed, identification, early, derived, tested, ministry, clades, including, senegal, woman, dhaka
- cisa_kev: today=21, 7d-median=21, 14d-median=20; carrying terms: authentication, product, server, remediation, improper, function, vendor, microsoft, vulnerability, missing, request, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=15, 7d-median=12, 14d-median=14; carrying terms: depth, islands, indonesia, japan, region, chile, alaska, guinea, vanuatu, papua, southern, nikolski
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: champions, shakhtar, league, volume, resolves, decrease, championship, price, change, donetsk, interest, september
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, revolution, marginal, conversable, economist, https, economy, current, recent, conversableeconomist, sustained, marginalrevolution
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: computerweekly, world, intelligence, industry, company, technology, going, hackers, schneier, attack, cyber, critical
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: donalds, haridopolos, biggs, mcconnell, ilhan, bernard, owens, franklin, graves, pablo, bessent, lankford
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, markets, claude, sufficient, consensus, placement, either, converges, identify, evidence, paper, today

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain
- [2026-09-01] Fed speeches: Barr, Unlocking Opportunities for Workers and Entrepreneurs with a Criminal Record
- [2026-09-01] ECB press: Boris Vujčić: Listening to households: expectations, behaviour and monetary policy
- [2026-09-03] Fed speeches: Waller, The Economic Outlook and Some Comments on My Policy Communication
- [2026-09-04] ECB press: Philip R. Lane: Diversity at the European Central Bank
- [2026-09-04] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with United Texas Bank, Quontic Bank Acquisition Corp., and Quontic Bank Holdings Corp.

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*