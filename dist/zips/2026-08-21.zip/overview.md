# WORLDSCOPE morning brief — 2026-08-21

## Headline
3174 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (750) · Russian Internal News (state + in-exile) (630) · World leaders & government officials (324) · State-Level News (320) · Chinese Internal News (235) · Local News: St. Louis + Atlanta (201) · U.S. Weather + Severe / Climate Outlooks (180) · Ukraine Theater (total-war monitoring) (81) · State Legislative Action (68) · Ukrainian Internal News (national + local Kyiv) (62) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 750 new of 1007 total
  - (2026-08-21) [Global] UK borrows more than expected in July as Healey prepares for first Budget
      Chancellor John Healey said the government is 'committed to meeting our fiscal rules'
  - (2026-08-20) [Global] Stifling heat and broken toilets: TUI River Cruise passengers tell of their holiday hell
      Holidaymakers tell the BBC they paid for luxury breaks but faulty air conditioning left them in sweltering heat.
  - (2026-08-20) [Global] Millenials have found it hard to buy homes – but things may be turning a corner
      Twenty-somethings are much less likely to own a home than previous generations. But data suggests things may be improving.
  - (2026-08-21) [Global] Panama Canal to cut number of ships passing through due to El Niño
      The crucial waterway's operator says low rainfall caused by the ocean pattern had led to the decision.
  - (2026-08-21) [Global] Why the US economy is ringing alarm bells
      The US hit a debt milestone this week, but just how worried should we be about the world's largest economy?
  - (2026-08-20) [Global] How landscape gardening is being electrified
      The switch to quieter electric equipment is not going as fast as some would like.

### Russian Internal News (state + in-exile) — 630 new of 1032 total
  - (2026-08-21) Российские войска освободили населенный пункт Зеленое в ДНР | LEDE: ] (ru: Российские войска освободили населенный пункт Зеленое в ДНР)
  - (2026-08-21) Захарова прокомментировала санкции Киева против создателей "Маши и Медведя" | LEDE: ] (ru: Захарова прокомментировала санкции Киева против создателей "Маши и Медведя")
  - (2026-08-21) Евросоюз провалил посредничество по урегулированию в Косово, заявил МИД | LEDE: ] (ru: Евросоюз провалил посредничество по урегулированию в Косово, заявил МИД)
  - (2026-08-21) Омбудсмен предложила увеличить срок добровольного погашения долга | LEDE: ] (ru: Омбудсмен предложила увеличить срок добровольного погашения долга)
  - (2026-08-21) На асфальтном заводе в Подмосковье потушили открытый огонь | LEDE: ] (ru: На асфальтном заводе в Подмосковье потушили открытый огонь)
  - (2026-08-21) СМИ: Буданов* фигурирует в деле экс-замглавы офиса Зеленского | LEDE: ] (ru: СМИ: Буданов* фигурирует в деле экс-замглавы офиса Зеленского)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 320 new of 595 total
  - (2026-08-21) [California] Governor Newsom signs legislation 8.20.2026
      Source
  - (2026-08-20) [California] Governor Newsom awards $11.3 million to 13 prohousing communities to build more affordable housing
      Source
  - (2026-08-20) [California] California sends FREE life-saving asthma inhalers to ALL schools
      Source
  - (2026-08-20) [Alabama] Governor Ivey Announces More Than $52 Million in GoMESA Funded Projects for 2026
      MONTGOMERY – Governor Kay Ivey on Thursday announced more than $52 million for 21 projects in Coastal Alabama supported by funds from the Gulf of Mexico Energy Security Act of 2006 (GoMESA). These projects focus on envir…
  - (2026-08-21) [California] AI led to mistakes in Nevada County criminal cases. Should the DA be sanctioned?
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082026-Nevada-County-Court-CM-01-scaled.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-po…
  - (2026-08-21) [California] Lawmakers gut major DUI reform through ‘hostile amendments’
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/081825-RedistrictingPress-MG-CM-15.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### Chinese Internal News — 235 new of 295 total
  - (2026-08-20) 全球存储：海力士一纸回购， 为什么值一成市值 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE96QXlIY2pxM1NfV0tYMC1GclA2V213NmVIVEt0MGdIYmpMYzlMR3BmbXNYamV6YklfUFdXWTVlT1JiTFFEUVR2ZnFDc05walp] (zh:…
      全球存储：海力士一纸回购， 为什么值一成市值 财新
  - (2026-08-20) 2026世界机器人大会开幕 参展企业同比增长36% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1ubnJ5dmluSW5oeDFwS0lDd1h4RV9pOVFlZjMzN0NSWThrbzY0VFhaNzE0TUNxbTVPSmFGOHhPOF92TjFzaTY5NE1JdF81] (zh:…
      2026世界机器人大会开幕 参展企业同比增长36% 财新
  - (2026-08-20) 2056台机器人同台竞技世界人形机器人运动会开赛在即 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE56TVNfeXoxUmJGYkY5UTMyX19fV2U2Vmw4Z0oxLWV6MzlpOU53eFhhTVdrdUtKYVFCNVd1OEdaU1hYc0U0bVFFWE9nNlN] (zh:…
      2056台机器人同台竞技世界人形机器人运动会开赛在即 财新
  - (2026-08-21) 今日开盘：两市双双低开 沪指跌幅0.32% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8zSTFEMGNUYW1qLVpsUXluNGhVd0txY3p1NFVkTGJGbEt5VjlZRHFWZlRjWk90SDlETERZX05lVktyTE1lb2gxbDBLRjd0REIz] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.32% 财新
  - (2026-08-20) 财经早知道｜上海出台“沪八条”，首套房商贷首付最低15% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5XT3dqQk5VdlBKUVRVSHdPSW83OW1Bc0ZZTUotQmRPZlNSY0R3RjNGcmRFbzlpcm83SV9JQk9GVUpxUjNtcHJMV2RQb] (zh:…
      财经早知道｜上海出台“沪八条”，首套房商贷首付最低15% 财新
  - (2026-08-21) 吴伟出任中投公司副董事长、总经理 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9SeHAxZ1RzUG5zQkctaWJCUXRQanFLRHk4aFpDcDQ0ZEc0NEFRcV9VSk1aZGVHNUZQaExUQ2liaWp6ZWdPSlU1RjlKMEpzSG9wSThtd] (zh:…
      吴伟出任中投公司副董事长、总经理 财新

### Local News: St. Louis + Atlanta — 201 new of 235 total
  - (2026-08-21) [St. Louis] See the Aug. 21, 1926, front page: Boy robber, 14, shot when he resists arrest
      Headlines from the August xx, 1926, front page include: Admits killing wife in quarrel over pair of socks
  - (2026-08-21) [St. Louis] Meet the Missourian playing against the Savannah Bananas this weekend
      Plus: STL ain't bad. Just ask this TikTok influencer.
  - (2026-08-21) [St. Louis] Wagganer, Stanley
      Wagganer, Stanley
  - (2026-08-21) [St. Louis] Wagganer, Stanley
      Stanley Robert Wagganer, age 69, passed away peacefully on Sunday, August 16, 2026, at Evelyn's House in Creve Coeur, Missouri. He had lived with MS for many years and had more recently faced cancer.
  - (2026-08-21) [St. Louis] Movie review: 'Mutiny' fails to make waves in sea of Statham action flicks
      The latest Jason Statham joint, “Mutiny,” isn’t playing coy with its references. The film, directed by Jean-François Richet, written by Lindsay Michel and J.P. Davis, is “'Die Hard' on a container ship,” and a new poster…
  - (2026-08-21) [St. Louis] How Playing A Quick Puzzle Can Improve Your Workday
      A quick puzzle can be a simple way to reset, refocus, and recharge during the workday.

### U.S. Weather + Severe / Climate Outlooks — 180 new of 182 total
  - (2026-08-21) [Moderate] Heat Advisory: Heat Advisory issued August 21 at 2:22AM PDT until August 21 at 10:00PM PDT by NWS Spokane WA
      * WHAT...High temperatures ranging from the mid 90s to just over 100 degrees resulting in Major HeatRisk. * WHERE...Much of the Inland Northwest. * WHEN...From 11 AM this morning to 10 PM PDT this evening. * IMPACTS...Ho…
  - (2026-08-21) [Moderate] Special Weather Statement: Special Weather Statement issued August 21 at 4:21AM CDT by NWS Birmingham AL
      At 421 AM CDT, Doppler radar was tracking a strong thunderstorm over Tamola, or 12 miles northwest of York, moving southeast at 15 mph. HAZARD...Wind gusts up to 50 mph. SOURCE...Radar indicated. IMPACT...Gusty winds cou…
  - (2026-08-21) [Moderate] Special Weather Statement: Special Weather Statement issued August 21 at 5:18AM EDT by NWS Morristown TN
      At 518 AM EDT, Doppler radar was tracking a strong thunderstorm over Morristown, moving northeast at 30 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limbs an…
  - (2026-08-21) [Moderate] Special Weather Statement: Special Weather Statement issued August 21 at 5:18AM EDT by NWS Greenville-Spartanburg SC
      At 518 AM EDT, Doppler radar was tracking a strong thunderstorm 8 miles west of Pickens, or near Keowee Toxaway State Park, moving northeast at 20 mph. HAZARD...Wind gusts up to 40 mph and half inch hail. SOURCE...Radar…
  - (2026-08-21) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-21) [Moderate] Special Weather Statement: Special Weather Statement issued August 21 at 4:15AM CDT by NWS Birmingham AL
      At 415 AM CDT, Doppler radar was tracking a strong thunderstorm over Pell City, moving east at 25 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree limbs and blow…

### Ukraine Theater (total-war monitoring) — 81 new of 234 total
  - (2026-08-21) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-21) [Liveuamap] Russia struck a border crossing on the Ukrainian-Moldovan border - Liveuamap
      Russia struck a border crossing on the Ukrainian-Moldovan border Liveuamap
  - (2026-08-20) [Liveuamap] Restrictions imposed at the airports of Moscow region - Liveuamap
      Restrictions imposed at the airports of Moscow region Liveuamap
  - (2026-08-20) [Liveuamap] Zelensky signed a decree imposing new sanctions on Russia’s military-industrial complex and collaborators. The relevant documents were published on the President’s website Kyiv, Kyiv city…
      Zelensky signed a decree imposing new sanctions on Russia’s military-industrial complex and collaborators. The relevant documen
  - (2026-08-19) [Liveuamap] The Verkhovna Rada appointed Yevheniy Khmara as the Minister of Defense of Ukraine. The decision was supported by 312 MPs Kyiv, Kyiv city - Ukraine Interactive map - Ukraine Latest news on…
      The Verkhovna Rada appointed Yevheniy Khmara as the Minister of Defense of Ukraine. The decision was supported by 312 MPs Kyiv, Kyiv
  - (2026-08-21) [Liveuamap] Two raids in the vicinity of Doha Kafr Rumman Nabatieh,Nabatiyeh Governorate - Lebanon news on live map - Liveuamap
      Two raids in the vicinity of Doha Kafr Rumman Nabatieh,Nabatiyeh Governorate - Lebanon news on live map &nb

### State Legislative Action — 68 new of 81 total
  - (2026-08-20) [California SB 1187] Open meetings.
      Existing law, the Ralph M. Brown Act, requires, with specified exceptions, that all meetings of a legislative body, as defined, of a local agency be open and public and that all persons be permitted to attend and partici…
  - (2026-08-20) [California AB 1830] Ignition interlock devices.
      (1) Existing law makes it unlawful for a person who is under the influence of any alcoholic beverage, has 0.08 or 0.04 percent or more, by weight, of alcohol in their blood, as specified, is addicted to the use of any dr…
  - (2026-08-20) [California AB 801] Nondiscrimination.
      Existing law establishes the Department of Financial Protection and Innovation under the direction of the Commissioner of Financial Protection and Innovation. Existing law makes the department responsible for administeri…
  - (2026-08-20) [California AB 1806] Department of Justice.
      Existing law requires law enforcement agencies to report to the Department of Justice, as specified, any incident in which a peace officer is involved in a shooting or use of force that results in death or serious bodily…
  - (2026-08-20) [California AB 2233] Behavioral health treatment plans.
      Existing law, the Knox-Keene Health Care Service Plan Act of 1975, provides for the licensure and regulation of health care service plans by the Department of Managed Health Care, and makes a willful violation of the act…
  - (2026-08-20) [California SB 526] Health facilities: clinics.
      Existing law requires the State Department of Public Health to license and regulate clinics, as defined. A violation of these provisions is a crime. Existing law requires any person, firm, association, partnership, or co…

### Ukrainian Internal News (national + local Kyiv) — 62 new of 119 total
  - (2026-08-21) Керівник підрозділу детективів НАБУ: Застава не має ставати кешбеком від вкрадених активів | LEDE: ] (uk: Керівник підрозділу детективів НАБУ: Застава не має ставати кешбеком від вкраден)
  - (2026-08-21) З-під завалів торговельного центру в Краматорську дістали тіло жінки | LEDE: Кількість жертв російського удару про торговельному центру в Краматорську на Донеччині зросла до двох: з-під завалів] (uk:…
      Кількість жертв російського удару про торговельному центру в Краматорську на Донеччині зросла до двох: з-під завалів деблокували тіло жінки.
  - (2026-08-21) Застава має залишатися дієвим запобіжним заходом, а не кешбеком від вкрадених активів | LEDE: Як підозрювані у справах НАБУ і САП виходять на волю завдяки заставам та схемам їх внесення.] (uk: Застава…
      Як підозрювані у справах НАБУ і САП виходять на волю завдяки заставам та схемам їх внесення.
  - (2026-08-21) Лідери держав з "коаліція охочих" зберуться на засідання 24 серпня | LEDE: Засідання "коаліції охочих" щодо подальшої підтримки України, у якому візьмуть участь лідери держав-членів, відбудетьс] (uk:…
      Засідання "коаліції охочих" щодо подальшої підтримки України, у якому візьмуть участь лідери держав-членів, відбудеться 24 серпня.
  - (2026-08-21) Сили оборони уразили НПЗ та військовий аеродром у Росії | LEDE: В ніч на 21 серпня Сили оборони уразили нафтопереробний завод у російській Пермі та військовий аеродром "Маринівка" у Волгоградсь] (uk:…
      В ніч на 21 серпня Сили оборони уразили нафтопереробний завод у російській Пермі та військовий аеродром "Маринівка" у Волгоградській області РФ.
  - (2026-08-21) Драпатий анонсував візит Військового комітету НАТО в Україну у жовтні | LEDE: Головнокомандувач ЗСУ Михайло Драпатий заявив, що у Військовий комітет НАТО відвідає Україну у жовтні цього року.] (uk: Др…
      Головнокомандувач ЗСУ Михайло Драпатий заявив, що у Військовий комітет НАТО відвідає Україну у жовтні цього року.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-21) [Chuang Shun-Chih] Form 4 (Reporting)
      filed 2026-08-21 01:58 UTC · role: Reporting — Filed: 2026-08-20 AccNo: 0001683168-26-006638 Size: 7 KB
  - (2026-08-21) [NOCERA, INC.] Form 4 (Issuer)
      filed 2026-08-21 01:58 UTC · role: Issuer — Filed: 2026-08-20 AccNo: 0001683168-26-006638 Size: 7 KB
  - (2026-08-21) [Huidor Mark Antonio] Form 4 (Reporting)
      filed 2026-08-21 01:45 UTC · role: Reporting — Filed: 2026-08-20 AccNo: 0001193125-26-359706 Size: 11 KB
  - (2026-08-21) [Cineverse Corp.] Form 4 (Issuer)
      filed 2026-08-21 01:45 UTC · role: Issuer — Filed: 2026-08-20 AccNo: 0001193125-26-359706 Size: 11 KB
  - (2026-08-21) [Repass Wolfe] Form 4 (Reporting)
      filed 2026-08-21 01:30 UTC · role: Reporting — Filed: 2026-08-20 AccNo: 0001193125-26-359693 Size: 6 KB
  - (2026-08-21) [Fold Holdings, Inc.] Form 4 (Issuer)
      filed 2026-08-21 01:30 UTC · role: Issuer — Filed: 2026-08-20 AccNo: 0001193125-26-359693 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-21) [United States] Doctor urges vigilance as hotter weather looms after heat - related deaths in Kern County
      domain: bakersfieldnow.com · language: English · tone:
  - (2026-08-21) [United States] Diversify Advisory Services LLC Invests $808 , 000 in Regeneron Pharmaceuticals , Inc . $REGN
      domain: themarketsdaily.com · language: English · tone:
  - (2026-08-21) [India] Frankfinn Institute of Air Hostess Training Receives Three Prestigious Awards at THSC Connect 2026 in New Delhi
      domain: business-standard.com · language: English · tone:
  - (2026-08-21) [Australia] Slain grocer safety fear revealed as teen cleared
      domain: narrominenewsonline.com.au · language: English · tone:
  - (2026-08-21) [Pakistan] Pakistan : Jailed ex - PM Imran Khan shifted to Islamabad hospital following Supreme Court directive
      domain: southeastasiapost.com · language: English · tone:
  - (2026-08-21) [India] What did Lindsay Clancy Apple Watch data reveal ? Here all prosecutors presented in court amid trial
      domain: hindustantimes.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 40 new of 56 total
  - (2026-08-21) [The Hacker News] GitLab CVE-2026-19478 Comes Under Active Exploitation Within Days of Disclosure
      A newly disclosed security flaw in GitLab has come under active exploitation within days of public disclosure, according to watchTowr. The vulnerability in question is CVE-2026-19478 (CVSS score: 9.4), a case of code inj…
  - (2026-08-21) [The Hacker News] Microsoft Entra ID Flaw (CVSS 10.0) Exploited in Wild, Allows Remote Code Execution
      Microsoft on Thursday warned of a maximum-severity security flaw in Entra ID that it said has been exploited in the wild, but noted that no customer action is required. The vulnerability, tracked as CVE-2026-69836 (CVSS…
  - (2026-08-21) [The Register] Wi-Fi 7's WPA3 protections come with a compatibility catch
      CableLabs wants hardware makers to embrace a workaround that keeps legacy kit connected
  - (2026-08-21) [The Register] Debian is 33, Haiku is 25, and neither is standing still
      One remains a pillar of Linux, while the other keeps the BeOS dream alive
  - (2026-08-21) [The Register] EE invites mobile users to live life in the 5G Fast Lane – for a price
      Network slicing offers a prioritized experience for those prepared to pay for a premium monthly plan
  - (2026-08-21) [The Register] Developer given Mission:Impossible - fixing rubbish code that could crash a city - simply chose not to accept it
      After imagining explosions, blackouts, and daring escapes, this techie decided the best thing to do was just not doing the job

### Court opinions of consequence (federal & state) — 31 new of 60 total
  - (2026-08-25) Connecticut Supreme Court: Lasa Extract, LLC v. Zoning Board of Appeals
  - (2026-08-20) D.C. Court of Appeals: Burton as Trustee of the EB Trust v. Chase Point Unit Owners Ass'n
  - (2026-08-20) D.C. Court of Appeals: Edwards & Jones v. Wilmington Savings Fund Society, FSB
  - (2026-08-20) D.C. Court of Appeals: In re Turkel
  - (2026-08-20) D.C. Court of Appeals: Peoples v. CIH Properties
  - (2026-08-20) U.S. Court of International Trade: Inspired Ventures, LLC v. United States

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 22 new of 22 total
  - (2026-08-21) Regulation Crypto Assets
      The Securities and Exchange Commission ("Commission") is proposing new rules to create a tailored offering regime for certain investment contracts involving crypto assets. The proposed offering regime is intended to faci…
  - (2026-08-21) Request for Comment on the Listing of Compute Derivatives Contracts
      The Commodity Futures Trading Commission ("CFTC" or "Commission") is seeking public responses to this Request for Comment to better inform its understanding and oversight of derivatives markets in compute.
  - (2026-08-21) Income Taxes
  - (2026-08-21) Fisheries of the Northeastern United States; Mackerel, Squid, and Butterfish; 2026 Illex Squid Quota Harvested
      NMFS is closing the directed Illex squid fishery in Federal waters based on a projection that 96 percent of the 2026 domestic annual harvest (DAH) will be harvested. This closure is effective 0001 hour (hr) local time on…
  - (2026-08-21) Inflation Adjustment for EOIR OBBBA Fees; Fiscal Year 2027
      The Department of Justice ("Department") is making inflationary adjustments to immigration-related fees for filings with the Executive Office for Immigration Review ("EOIR") as required by the One Big Beautiful Bill Act…
  - (2026-08-21) Environmental Protection Regulations for Domestic Licensing and Related Regulatory Functions

### USGS earthquakes (M4.5+, past day) — 19 new of 19 total
  - (2026-08-20) M 6.7 - 31 km NW of Aniso, Peru
      M6.7 · 31 km NW of Aniso, Peru · depth 99 km
  - (2026-08-20) M 5.6 - 67 km NNW of Ende, Indonesia
      M5.6 · 67 km NNW of Ende, Indonesia · depth 10 km
  - (2026-08-20) M 5.2 - 270 km SSE of Dunhuang, China
      M5.2 · 270 km SSE of Dunhuang, China · depth 10 km
  - (2026-08-21) M 5.1 - south of Tonga
      M5.1 · south of Tonga · depth 10 km
  - (2026-08-20) M 5.1 - 183 km SE of Kokopo, Papua New Guinea
      M5.1 · 183 km SE of Kokopo, Papua New Guinea · depth 35 km
  - (2026-08-20) M 5.0 - Pacific-Antarctic Ridge
      M5.0 · Pacific-Antarctic Ridge · depth 10 km

### Paper Trading Scorecard — 18 new of 139 total
  - (2026-08-21) [Polymarket] US-Iran Final Nuclear Deal by October 31, 2026?
      On June 14, 2026, the United States and Iran announced a written diplomatic agreement, including a 60-day extendable period in which both countries committed to negotiate toward a “final deal” regarding Iran’s nuclear pr…
  - (2026-08-21) [Manifold] Will the silver spot price be above $75 USD on September 1st?
  - (2026-08-21) [Manifold] Will Romania invoke NATO Article 4 over a Black Sea drone incident before September 1, 2026?
  - (2026-08-21) [Manifold] Will North Korea launch another ballistic missile before September 1, 2026?
  - (2026-08-21) [Manifold] Will the 30-year US Treasury par yield reach 5.25% before October 1, 2026?
  - (2026-08-21) [Manifold] Will US gross federal debt reach $41 trillion before 2027?

### World News (by country, top stories) — 18 new of 18 total
  - (2026-08-21) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-08-21) [China] China , Switzerland complete FTA upgrade negotiations
      china.org.cn · English
  - (2026-08-21) [China] Ex - Deloitte IT manager jailed for 22 months over HK$1 . 2 million laptop theft
      scmp.com · English
  - (2026-08-21) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-08-21) [China] Russian Foreign Ministry urges Japan to fully recognize WWII outcomes , stop whitewashing wartime aggression
      china.org.cn · English
  - (2026-08-21) [China] 7th Forum on China - Africa Media Cooperation held in Beijing
      china.org.cn · English

### Government & military aircraft airborne (OpenSky) — 16 new of 19 total
  - (2026-08-21) SAMU37 (France)
      icao24: 39ca87 · position: (47.4776, 1.1055) · alt: 457m · 235km/h
  - (2026-08-21) GAF213 (Germany)
      icao24: 3f727c · position: (40.33, -3.3905) · alt: 1493m · 367km/h
  - (2026-08-21) GAF757 (Germany)
      icao24: 3f59f3 · position: (57.6678, 9.2758) · alt: 11582m · 896km/h
  - (2026-08-21) JAF3NE (Belgium)
      icao24: 44d1a5 · position: (43.9865, -1.3753) · alt: 10363m · 845km/h
  - (2026-08-21) JAF97T (Belgium)
      icao24: 44d1a2 · position: (46.8487, 14.7364) · alt: 11582m · 852km/h
  - (2026-08-21) NCR9729 (United States)
      icao24: a9c52e · position: (18.3371, -66.9956) · alt: 12192m · 879km/h

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-08-21) Dota 2: Team Liquid vs Team Falcons (BO3) - The International Playoffs
      yes price: 42% · 24h volume: $2,873,016 · resolves 2026-08-21
  - (2026-08-21) Dota 2: Team Spirit vs TEAM VISION (BO3) - The International Playoffs
      yes price: 36% · 24h volume: $2,252,159 · resolves 2026-08-21
  - (2026-08-21) NATO x Russia military clash by August 31, 2026?
      yes price: 6% · 24h volume: $1,104,008 · resolves 2026-08-31
  - (2026-08-21) LoL: EDward Gaming vs ThunderTalk Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $1,032,476 · resolves 2026-08-21
  - (2026-08-21) LoL: HANJIN BRION vs BNK FEARX - Game 1 Winner
      yes price: 0% · 24h volume: $947,820 · resolves 2026-08-21
  - (2026-08-21) LoL: EDward Gaming vs ThunderTalk Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $673,552 · resolves 2026-08-21

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 96 total
  - (2026-08-20) [OFAC] Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions - Office of Fore…
      Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] Ecuadorian Maritime Cocaine Trafficking Network - Office of Foreign Assets Control (.gov)
      Ecuadorian Maritime Cocaine Trafficking Network Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] 1265 - Office of Foreign Assets Control (.gov)
      1265 Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-08-15) [FARA] Trial Attorney, GS-0905-14/15 - Department of Justice (.gov)
      Trial Attorney, GS-0905-14/15 Department of Justice (.gov)
  - (2026-08-21) [USASpending] $27,583,176,865 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 38 total
  - (2026-08-21) #30 Dieter Schwarz — $64.14B
      Germany · Fashion & Retail · source: Retail
  - (2026-08-21) MOVER ▼ Francoise Bettencourt Meyers & family — $95.52B ($-0.28B since yesterday)
      France · Fashion & Retail · source: L'Oréal
  - (2026-08-21) MOVER ▼ Rob Walton & family — $125.92B ($-0.22B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-08-21) MOVER ▼ Jim Walton & family — $125.19B ($-0.22B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-08-21) MOVER ▼ Alice Walton — $115.09B ($-0.22B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-08-21) MOVER ▲ Gautam Adani — $82.40B (+$0.21B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-21) [Marginal Revolution] Rick Rubin podcasts with me
      Two hours, thirty-four minutes, Rick and I recorded this session not too long ago in Tuscany. It was everything Rick wanted to ask. Self-recommending of course, and there is more to come. The post Rick Rubin podcasts wit…
  - (2026-08-21) [Marginal Revolution] Green shoots for the UK?
      Early signs of tech-driven improvements in productivity growth could herald a sustained strengthening in the UK’s economic outlook, analysts have said, in a turnaround after years of underperformance. Private sector prod…
  - (2026-08-21) [Marginal Revolution] More evidence on the effects of recent tariffs
      Trump is giving economists something to write papers about: U.S. tariff rates in 2025 rose to levels not seen since the Great Depression, yet imports increased. To account for the missing trade collapse, we develop an op…
  - (2026-08-20) [Conversable Economist] Data Center Spending in US
      The good folks at “Our World in Data” have been putting together a data series which shows monthly spending on the “on-site work to build data centers each month, including materials and construction labor. It excludes t…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 12 total
  - (2026-08-20) CVE-2026-72530 · TrueConf Server: TrueConf Server Code Injection Vulnerability
      vendor: TrueConf · product: Server · CISA remediation by 2026-09-03
  - (2026-08-20) CVE-2026-72529 · TrueConf Server: TrueConf Server Missing Authentication for Critical Function Vulnerability
      vendor: TrueConf · product: Server · CISA remediation by 2026-08-23

### EPSS — highest exploit-probability CVEs — 1 new of 40 total
  - (2026-08-20) CVE-2012-1823: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-21) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: proposing, proposes, certain, proposed, provide, establish, final, national, state, action, program, coast
- state_bills: today=81, 7d-median=129, 14d-median=108; carrying terms: required, relating, authorizes, purposes, development, consultation, related, ensure, based, government, violation, business
- state_news: today=595, 7d-median=585, 14d-median=585; carrying terms: created, required, possible, political, court, washington, whether, legal, start, charges, seeks, economic
- local_news: today=235, 7d-median=216, 14d-median=229; carrying terms: blank, gives, charges, involving, missouri, articles, school, killed, three, local, georgia, shooting
- foreign_news: today=1007, 7d-median=978, 14d-median=980; carrying terms: strait, coast, court, wooden, thousands, migrant, legal, bureau, start, seeks, yongning, related
- chinese_internal: today=295, 7d-median=280, 14d-median=270; carrying terms: blank, articles, cbmidefvx, lxtfb, china, cbmiw, color, cbmia, people, google, cbmizkfvx, cbmib
- russian_internal: today=1032, 7d-median=1032, 14d-median=1032; carrying terms: blank, politico, journal, error, istories, found, reuters, street, media, httperror, title, world
- ukrainian_internal: today=119, 7d-median=107, 14d-median=107; carrying terms: political, washington, cabinet, energy, western, https, government, president, territory, prime, increasingly, strikes
- ukraine_theater: today=234, 7d-median=887, 14d-median=887; carrying terms: blank, nlgxsxlrz, wxpgazfdthvkzw, restoring, rdmhbrxdhdf, movemen, zdmztgzjmffjszfxukladvfvq, uefpa, dwhmzvhcvjg, lcmrbrlnucep, oxcwhrbzfoa, eodjka
- paper_bets: today=139, 7d-median=141, 14d-median=139; carrying terms: nominee, georgia, headline, jackson, chase, midterms, leaders, mbappe, rippling, polymarket, court, washington
- weather: today=182, 7d-median=177, 14d-median=177; carrying terms: develop, coast, possible, washington, boston, degrees, lower, humidity, western, afdlsx, areas, related
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: money, dexuseu, total, nonfarm, headline, balance, openings, cpilfesl, implied, indicator, commodities, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, equities, china, close, credit, natural, treasury, agriculture, nasdaq, silver, rates, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=96, 7d-median=93, 14d-median=96; carrying terms: concerning, blank, libya, latinscript, mufswgh, russia, against, niger, aeronautics, acronym, middle, political
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, client, httperror, quiverquant, congresstrading, quiver, https, error, unauthorized
- billionaires: today=38, 7d-median=34, 14d-median=34; carrying terms: arnault, brokerage, jensen, family, hathaway, bettencourt, giancarlo, adani, facebook, france, india, diversified
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, group, appeals, supreme, international, state, company, blanche, trust, connecticut, trade, america
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, capital, holdings, michael, group, william
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, booker, jonathan, krishnamoorthi, platner, raised, ossoff, filing, pinkston, graham, johnson, cooper
- gdelt_regions: today=18, 7d-median=12, 14d-median=9; carrying terms: english, japan, korea, south
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, themes, russian, spanish, trump, strait, german, china, greek, south, arabic, italian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: india, kingdom, domain, military, nigeria, english, language, australia
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=29, 14d-median=30; carrying terms: position, belgium, ground, france, kingdom, germany, netherlands, spain
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: local, toxin, beginning, developments, resurgence, challenge, division, onboard, india, epidemiological, safety, source
- cisa_kev: today=12, 7d-median=9, 14d-median=9; carrying terms: firewall, authentication, command, loadmaster, remediation, secure, injection, vulnerability, product, progress, vendor, cisco
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=277, 14d-median=277; carrying terms: herzegovina, costa, orange, congo, green, croatia, france, fires, flood, brazil, russia, albania
- usgs_quakes: today=19, 7d-median=21, 14d-median=18; carrying terms: depth, indonesia, islands, ruteng, japan, south, papua, guinea, levuka, tonga, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: september, august, resolves, donetsk, league, shakhtar, volume, champions, winner, interest, meeting, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, marginal, economist, class, revolution, conversable, marginalrevolution, seems, social, wrote, growth, great
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: computer, weekday, google, review, https, government, already, models, attackers, researchers, bleepingcomputer, online
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: credit, bonamici, whitehouse, mciver, andrea, marco, balderson, krishnamoorthi, guthrie, susie, tammy, warnock
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, sufficient, consensus, unavailable, today, paper, converges, evidence, claude, market, markets, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*