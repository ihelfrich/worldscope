# WORLDSCOPE morning brief — 2026-08-21

## Headline
4486 new items across 28 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (860) · International News + Multilateral Institutions (830) · Ukraine Theater (total-war monitoring) (708) · State-Level News (460) · World leaders & government officials (324) · Chinese Internal News (255) · Local News: St. Louis + Atlanta (240) · U.S. Weather + Severe / Climate Outlooks (214) · State Legislative Action (90) · Ukrainian Internal News (national + local Kyiv) (81) · Court opinions of consequence (federal & state) (60) · GDELT GKG — themes / entities / watch areas (50)

## What changed today
### Russian Internal News (state + in-exile) — 860 new of 1245 total
  - (2026-08-21) В Геленджике полностью закончился бензин | LEDE: По состоянию на утро 21 августа бензин продавала лишь одна заправка в Геленджике — АЗС «Лукойла» в селе Архипово-Осиповка. На остальных запра] (ru: В Г…
      По состоянию на утро 21 августа бензин продавала лишь одна заправка в Геленджике — АЗС «Лукойла» в селе Архипово-Осиповка. На остальных заправках было доступно только дизельное топливо, сообщила городская администрация.
  - (2026-08-21) Кандидата в Госдуму от КПРФ Николая Бондаренко оштрафовали на 1000 рублей из-за фото Навального. Теперь Бондаренко не сможет участвовать в выборах | LEDE: Суд в Саратове оштрафовал депутата ] (ru: Кан…
      Суд в Саратове оштрафовал депутата областной думы от партии КПРФ Николая Бондаренко на тысячу рублей по административной статье о демонстрации экстремистской символики. Об этом сообщил проект «Слово защите».
  - (2026-08-21) «Родина» снова пытается снять «Яблоко» с выборов — на этот раз в Псковской области. Это регион Льва Шлосберга, получившего 11 лет за антивоенную позицию | LEDE: Партия «Родина» подала иск в ] (ru: «Ро…
      Партия «Родина» подала иск в Псковский областной суд с требованием снять список партии «Яблоко» с выборов в региональное законодательное собрание. Об этом сообщила пресс-служба «Яблока».
  - (2026-08-21) Умер Йован Савович — создатель Dirty и «Лепры». Фотожабы и мемы, придуманные пользователями этих сайтов, во многом сформировали Рунет до эпохи соцсетей | LEDE: Веб-дизайнер и IT-предпринимат] (ru: Уме…
      Веб-дизайнер и IT-предприниматель Йован Савович умер в возрасте 43 лет после продолжительной болезни. По словам его близких, у него был рассеянный склероз. Савович известен в первую очередь как создатель «Лепрозория» и п…
  - (2026-08-21) Россия ударила по крупнейшему торговому центру Кривого Рога — а через полчаса ударила снова, когда там шла спасательная операция . 15 человек погибли, 130 ранены | LEDE: Российская армия ата] (ru: Рос…
      Российская армия атаковала крупнейший торговый центр Кривого Рога, заявил председатель совета обороны города Александр Вилкул. Судя по видео, опубликованным в соцсетях, речь идет о торговом центре «Солнечная галерея». По…
  - (2026-08-21) Основатель Blackwater создал компанию, которая будет предлагать услуги ПВО по подписке | LEDE: Основатель компании Blackwater Эрик Принс создал компанию Vectus, которая будет предоставлять у] (ru: Осн…
      Основатель компании Blackwater Эрик Принс создал компанию Vectus, которая будет предоставлять услуги противовоздушной обороны по системе подписки. Об этом пишет Axios.

### International News + Multilateral Institutions — 830 new of 1059 total
  - (2026-08-20) [Global] US deports 20 people to Liberia, the first of 1,200 migrants under Trump deal
  - (2026-08-21) [Global] JD Vance reportedly mocks Carney for trying to ‘out-tough’ Trump on trade
  - (2026-08-21) [Global] Strangers in their own land: Mexicans deported from Trump’s America find refuge in ‘Little LA’
  - (2026-08-21) [Global] Tiananmen Square vigil organisers in Hong Kong found guilty of ‘inciting subversion’
  - (2026-08-21) [Global] Weather tracker: Extreme rain deluges Japan and South Korea
  - (2026-08-21) [Global] Russia’s missile tests around disputed islands anger Japan

### Ukraine Theater (total-war monitoring) — 708 new of 945 total
  - (2026-08-21) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-20) [FIRMS] thermal anomaly 44.053, 25.323 (FRP 11.42 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1147Z, FRP 11.42 MW
  - (2026-08-20) [FIRMS] thermal anomaly 44.057, 25.322 (FRP 17.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1147Z, FRP 17.29 MW
  - (2026-08-20) [FIRMS] thermal anomaly 44.065, 23.549 (FRP 13.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1149Z, FRP 13.41 MW
  - (2026-08-20) [FIRMS] thermal anomaly 44.069, 23.548 (FRP 9.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1149Z, FRP 9.92 MW
  - (2026-08-20) [FIRMS] thermal anomaly 44.003, 22.113 (FRP 5.36 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1149Z, FRP 5.36 MW

### State-Level News — 460 new of 722 total
  - (2026-08-21) [California] Governor Newsom issues statement on federal Colorado River plan
      Source
  - (2026-08-21) [California] Governor Newsom signs legislation 8.20.2026
      Source
  - (2026-08-20) [California] Governor Newsom awards $11.3 million to 13 prohousing communities to build more affordable housing
      Source
  - (2026-08-20) [California] California sends FREE life-saving asthma inhalers to ALL schools
      Source
  - (2026-08-21) [California] Legisladores usan ‘enmiendas hostiles’ para desmantelar reformas a leyes contra manejo bajo la influencia del alcohol
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/081825-RedistrictingPress-MG-CM-15.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-08-21) [California] In California’s biggest cities, Turner’s Outdoorsman is a top source of crime guns
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/071222_GunFile_LV_CM_005.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 255 new of 305 total
  - (2026-08-21) 肯尼迪号“复古”：恢复雷达照射器-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTE81LU96b3ZaQjVxWVZ2ajFTTm02Z3dNdThjUzd5ellUS0tSNW1XSGg3Wm0tbTVSclRISlo2RDkxaDRYQ18tOVZNVkJJSEd4dEJ] (zh:…
      肯尼迪号“复古”：恢复雷达照射器-观察者网 观察者
  - (2026-08-20) A8女生想找A8.3男生，男生却想找23岁的——90后婚恋死循环怎么破？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE8wUV9DWklfRDVPVnppaE5WWnJqSFExS2h1S09LUkVaaGlaZGhOYXhiOHdzemZQSWx3SFIwdkltVXYxLVQt] (zh:…
      A8女生想找A8.3男生，男生却想找23岁的——90后婚恋死循环怎么破？ 观察者
  - (2026-08-21) 中铁成都局回应“旅客买票占座放零食”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBsZDlUQ2ZvOUlUUWV6eW9tdUxIUHhpRGFpWEhjWWgxZHdUbGJwdlN5dzVHSVBDS1RvRFJrRHl1NGc4UGg4ZTlEaVJJd3IxY] (zh:…
      中铁成都局回应“旅客买票占座放零食”-观察者网 观察者
  - (2026-08-20) “借死不借生”？房东赶走孕妇租客，还列了一溜儿要求… - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1udkZ2eFZtdFZTOXk3QUUzVV8wNG9FbzZVODJ0SV84SG9fdHc1RlA3TzNrT2dyOFg0WlJYUElMNDdtcGxDVC14V0U3V1] (zh:…
      “借死不借生”？房东赶走孕妇租客，还列了一溜儿要求… 观察者
  - (2026-08-21) 科拉松·瓦尔迪兹·法布罗斯-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiVEFVX3lxTE1zb01fU3hTMGQ2clRRN3JvamlTYVdNcVZnLVdsRG9sejcxOGtmRUJPYmcwQzJIdkNxMVdpLVNmXzQ2NnlwN19KSExzdjc2OFFpaT] (zh:…
      科拉松·瓦尔迪兹·法布罗斯-观察者网 观察者
  - (2026-08-21) 应急机械拉手存在安全隐患，多品牌集中召回超427万辆车 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5VUzM2SU1xUVVsQjRxRVJVSDBCeVVPU1VkaE9LZUhUQmVpYXYxNmhvZkw2TnJINkFZRGJRVnV0eVJYbDh4QTU0UnphW] (zh:…
      应急机械拉手存在安全隐患，多品牌集中召回超427万辆车 观察者

### Local News: St. Louis + Atlanta — 240 new of 263 total
  - (2026-08-21) [St. Louis] Is it OK to ask a restaurant where its lettuce comes from?
      Do you think it’s inappropriate or insulting to ask a restaurant where it sources its lettuce? —Laura R., St. Louis This question is especially timely, given yesterday’s CDC’s update that the number of cyclospora cases h…
  - (2026-08-21) [St. Louis] Where to find the best oysters in St. Louis
      St. Louis may be hundreds of miles from the nearest ocean, but oysters have long been a staple on local menus. From neighborhood taverns to seafood spots, happy hours, and local grocers, there’s no shortage of places to…
  - (2026-08-21) [St. Louis] GroveFest will not take place this year
      GroveFest, the street festival that for two decades has taken place in St. Louis’ popular nightlife district in October, won’t be happening this year. A representative from the organization Park Central Development, the…
  - (2026-08-21) [St. Louis] Defamation suit targets attorney Al Watkins, ex-wife
      A St. Louis attorney is being sued by the executive chairman of a billion dollar critical minerals company after the attorney allegedly urged his ex-wife to make a “defamatory and outrageous” call to the executive’s Idah…
  - (2026-08-21) [St. Louis] What’s True in the Lou? – 8/21/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-08-20) [St. Louis] Stanley Browne launches Cellar & Table, a new wine and hospitality venture in St. Louis
      Hospitality veteran and certified sommelier Stanley Browne has launched a new wine and hospitality consulting business. Cellar & Table will offer a range of services, including hospitality consulting, wine experiences an…

### U.S. Weather + Severe / Climate Outlooks — 214 new of 216 total
  - (2026-08-21) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 21 at 3:11PM CDT until August 21 at 3:45PM CDT by NWS La Crosse WI
      At 310 PM CDT, a severe thunderstorm was located near Bloomington, or 8 miles northwest of Lancaster, moving southeast at 15 mph. HAZARD...60 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...Hail…
  - (2026-08-21) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 21 at 3:11PM CDT until August 23 at 10:00PM CDT by NWS Chicago IL
      * WHAT...High wave action and dangerous currents expected at Lake Michigan beaches. Waves 3 to 6 feet expected. * WHERE...Porter County. * WHEN...From Saturday morning through Sunday evening. * IMPACTS...Swimming conditi…
  - (2026-08-21) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 21 at 4:11PM EDT until August 21 at 4:15PM EDT by NWS Tallahassee FL
      The storms which prompted the warning have weakened below severe limits, and no longer pose an immediate threat to life or property. Therefore, the warning will be allowed to expire. However, gusty winds are still possib…
  - (2026-08-21) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 21 at 3:11PM CDT until August 21 at 3:30PM CDT by NWS New Orleans LA
      At 311 PM CDT, a severe thunderstorm was located near Lyman, or near Long Beach, moving west at 15 mph. HAZARD...60 mph wind gusts and penny size hail. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, siding, a…
  - (2026-08-21) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 21 at 4:11PM EDT until August 21 at 4:15PM EDT by NWS Wilmington NC
      The storm which prompted the warning has weakened below severe limits, and no longer poses an immediate threat to life or property. Therefore, the warning will be allowed to expire. A Severe Thunderstorm Watch remains in…
  - (2026-08-21) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 21 at 4:11PM EDT until August 21 at 4:30PM EDT by NWS Greenville-Spartanburg SC
      At 411 PM EDT, a severe thunderstorm was located 6 miles southeast of Uptown Charlotte, or near Southpark Mall, moving east at 15 mph. HAZARD...70 mph wind gusts and quarter size hail. SOURCE...Radar indicated. IMPACT...…

### State Legislative Action — 90 new of 118 total
  - (2026-08-21) [Alaska SB 191] An Act approving the transfer of land owned by the Alaska Railroad Corporation to the City of Whittier; and providing for an effective date.
      An Act approving the transfer of land owned by the Alaska Railroad Corporation to the City of Whittier; and providing for an effective date.
  - (2026-08-21) [Alaska HB 237] An Act relating to mathematics education; relating to the duties of the Department of Education and Early Development; and relating to the duties of school districts.
      An Act relating to mathematics education; relating to the duties of the Department of Education and Early Development; and relating to the duties of school districts.
  - (2026-08-21) [Alaska HJR 39] Urging the federal government to waive the new H-1B Visa fees for teachers in the state.
      Urging the federal government to waive the new H-1B Visa fees for teachers in the state.
  - (2026-08-21) [Alaska SCR 17] Recognizing the 50th anniversary of the state's regional educational attendance areas; and celebrating the enduring contributions of the state's regional educational attendance areas t…
      Recognizing the 50th anniversary of the state's regional educational attendance areas; and celebrating the enduring contributions of the state's regional educational attendance areas to public education, local leadership…
  - (2026-08-21) [Alaska HB 387] An Act establishing the Joint Legislative Alaska Native Languages Academic Task Force.
      An Act establishing the Joint Legislative Alaska Native Languages Academic Task Force.
  - (2026-08-21) [Alaska SB 20] An Act relating to cardiopulmonary resuscitation education in public schools; and relating to the duties of the Department of Education and Early Development.
      An Act relating to cardiopulmonary resuscitation education in public schools; and relating to the duties of the Department of Education and Early Development.

### Ukrainian Internal News (national + local Kyiv) — 81 new of 136 total
  - (2026-08-21) Від початку доби на фронті відбулось 172 бойових зіткнення – Генштаб | LEDE: Від початку доби 21 серпня на фронті відбулось 172 бойових зіткнення, з них 23 – на Покровському напрямку.] (uk: Від початк…
      Від початку доби 21 серпня на фронті відбулось 172 бойових зіткнення, з них 23 – на Покровському напрямку.
  - (2026-08-21) Зеленський призначив 16 антикорсуддів для розблокування коштів від ЄС | LEDE: Президент Володимир Зеленський призначив 11 суддів Вищого антикорупційного суду та 5 суддів Апеляційної палати цьог] (uk:…
      Президент Володимир Зеленський призначив 11 суддів Вищого антикорупційного суду та 5 суддів Апеляційної палати цього суду, що є кроком, необхідним для отримання від 250 до 300 млн євро від ЄС за програмою Ukraine Facilit…
  - (2026-08-21) Сибіга анонсував нові пакети допомоги від партнерів 24 серпня | LEDE: ] (uk: Сибіга анонсував нові пакети допомоги від партнерів 24 серпня)
  - (2026-08-21) Сибіга розповів про роботу з партнерами над "антибалістичними санкціями" проти РФ | LEDE: ] (uk: Сибіга розповів про роботу з партнерами над "антибалістичними санкціями" проти Р)
  - (2026-08-21) Операція "Форест Гамп": ВАКС обрав запобіжний захід ще одному учаснику схеми | LEDE: Вищий антикорупційний суд застосував запобіжний захід до учасника корупційної схеми генерального директора з] (uk:…
      Вищий антикорупційний суд застосував запобіжний захід до учасника корупційної схеми генерального директора з правових питань Офісу Президента.
  - (2026-08-21) В Єлисейському палаці розповіли, що обговорюватиме "коаліція охочих" | LEDE: ] (uk: В Єлисейському палаці розповіли, що обговорюватиме "коаліція охочих")

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-08-25) Connecticut Supreme Court: Lasa Extract, LLC v. Zoning Board of Appeals
  - (2026-08-25) Connecticut Supreme Court: State v. Toste
  - (2026-08-21) Supreme Court of Alabama: Dalton D. Banks v. Darla Lashay Persall; Dean Smith; Fuller, Willingham & Carter, LLC; Melvin Hasting; and Thomas Drake II
  - (2026-08-21) Supreme Court of Alabama: I. Ripon Britton, Jr., and Gregory H. Hawley v. Yashiba Glenn Blanchard, in her official capacity as Jefferson County Judge of Probate
  - (2026-08-21) Supreme Court of Alabama: In re: Grady L. Floyd, Jr., Gabrielle Floyd, and Charlie Floyd, Jr. v. Escambia County Community Hospital, Inc.
  - (2026-08-21) Supreme Court of Alabama: Ivy Fund Manager, LLC, d/b/a OC Ventures; Ivy Midtown GP, LLC; and NDG Student Living, LLC, d/b/a Varsity Campus v. CDH Real Estate Investment Management Company, Ltd.; Cook…

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-08-21) [Russia oil sanctions perimeter · themes] Sp 29 Colle del Cadibona sotto pressione : tra traffico pesante , pericoli e il nodo irrisolto della logistica
      ivg.it · Italian · tone NA
  - (2026-08-21) [Russia oil sanctions perimeter · themes] Russian strike kills at least 15 at shopping centre in Zelensky home city
      barryanddistrictnews.co.uk · English · tone NA
  - (2026-08-21) [Russia oil sanctions perimeter · themes] The True Crime Cruise Sets Sail Again Aboard Virgin Voyages
      hot983.iheart.com · English · tone NA
  - (2026-08-21) [Russia oil sanctions perimeter · themes] انقطاع الكهرباء لليوم التاسع على مئات الآلاف بولاية إنديانا بسبب العاصفة
      elwatannews.com · Arabic · tone NA
  - (2026-08-21) [Russia oil sanctions perimeter · themes] Lampedusa , 68 migranti sbarcano sugli scogli tra i bagnanti
      tg24.sky.it · Italian · tone NA
  - (2026-08-21) [Russia oil sanctions perimeter · themes] Messina , ordigno bellico sulla spiaggia di Torre Faro : area interdetta a Capo Peloro
      strettoweb.com · Italian · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 49 new of 54 total
  - (2026-08-21) [BleepingComputer] New SynkLoader malware pushed in Microsoft Teams phishing campaign
      A previously unknown malware family dubbed SynkLoader is being distributed in Microsoft Teams phishing campaigns to steal credentials via a fake lock screen. [...]
  - (2026-08-21) [BleepingComputer] Hundreds of leaked AWS keys give full control over corporate accounts
      More than 9,300 Amazon Web Services (AWS) access keys publicly exposed between August 2022 and August 2026 are still active and valid. [...]
  - (2026-08-21) [BleepingComputer] Microsoft blames Windows gaming issues on RGB lighting devices
      Microsoft says ongoing issues causing games to crash or fail to launch after installing the August 2026 Windows updates may be caused by peripherals with RGB lighting. [...]
  - (2026-08-21) [BleepingComputer] Is Online Privacy Possible? How Digital Identities Can Help
      Using the same email, phone number, payment method, and other identifiers makes it easier for data brokers and attackers to profile your activity. Anonyome Labs explains how separate digital personas can reduce correlati…
  - (2026-08-21) [BleepingComputer] Microsoft rolls out Classic Outlook theme for New Outlook users
      Microsoft has started rolling out a Classic Outlook theme for users of Outlook on the web and the New Outlook for Windows. [...]
  - (2026-08-21) [The Hacker News] Microsoft Defender's Own Driver Can Be Weaponized to Delete Security Software at Boot
      Check Point Research has disclosed a technique that uses Microsoft Defender's own legitimately signed boot-time remediation driver to perform arbitrary kernel-level file and registry operations on Windows systems ranging…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-21) [Owlet, Inc.] Form 4 (Issuer)
      filed 2026-08-21 20:11 UTC · role: Issuer — Filed: 2026-08-21 AccNo: 0001213555-26-000004 Size: 324 KB
  - (2026-08-21) [BURKE ZANE M] Form 4 (Reporting)
      filed 2026-08-21 20:11 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0001213555-26-000004 Size: 324 KB
  - (2026-08-21) [Medpace Holdings, Inc.] Form 4 (Issuer)
      filed 2026-08-21 20:11 UTC · role: Issuer — Filed: 2026-08-21 AccNo: 0000892251-26-000123 Size: 16 KB
  - (2026-08-21) [DAVENPORT FRED B JR] Form 4 (Reporting)
      filed 2026-08-21 20:11 UTC · role: Reporting — Filed: 2026-08-21 AccNo: 0000892251-26-000123 Size: 16 KB
  - (2026-08-21) 424B2 - BANK OF MONTREAL /CAN/ (0000927971) (Filer)
      filed 2026-08-21 20:11 UTC — Filed: 2026-08-21 AccNo: 0001839882-26-041083 Size: 388 KB
  - (2026-08-21) 424B2 - GS Finance Corp. (0001419828) (Filer)
      filed 2026-08-21 20:11 UTC — Filed: 2026-08-21 AccNo: 0001193125-26-361108 Size: 849 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-08-21) [United States] Andrew and Tristan Tate referred to counterterrorism police over Russia trip
      domain: miaminewtimes.com · language: English · tone:
  - (2026-08-21) [Australia] Labor puts the bite on rivals with free dental pitch
      domain: crookwellgazette.com.au · language: English · tone:
  - (2026-08-21) [United States] 50 Cent , 702 & More Pop Out For Donell Jones & Joe Verzuz Battle
      domain: 1035thebeat.iheart.com · language: English · tone:
  - (2026-08-21) [United States] Heart Condition Forces Olympian Into Retirement
      domain: 720thevoice.iheart.com · language: English · tone:
  - (2026-08-21) [United States] WI Food Maker Faces Safety Fines for 2 Fatal Incidents
      domain: isssource.com · language: English · tone:
  - (2026-08-21) [Australia] Bush Summit : Regional Australia top concerns laid bare
      domain: geelongadvertiser.com.au · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-08-21) JAF4KN (Bulgaria)
      icao24: 4520d0 · position: (40.3149, -3.5746) · alt: 11277m · 795km/h
  - (2026-08-21) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (39.2771, -0.912) · alt: 11285m · 776km/h
  - (2026-08-21) PAT121 (United States)
      icao24: adfe49 · position: (39.7105, -89.5691) · alt: 922m · 362km/h
  - (2026-08-21) CFC0547 (Canada)
      icao24: c02045 · position: (47.4939, -98.6153) · alt: 4853m · 368km/h
  - (2026-08-21) PAT123 (United States)
      icao24: adfec0 · position: (33.5883, -80.8284) · alt: 6088m · 469km/h
  - (2026-08-21) PAT700 (United Republic of Tanzania)
      icao24: 080010 · position: (42.203, -120.4318) · alt: 10972m · 829km/h

### USGS earthquakes (M4.5+, past day) — 27 new of 27 total
  - (2026-08-21) M 5.7 - 194 km SW of Labuan, Indonesia
      M5.7 · 194 km SW of Labuan, Indonesia · depth 10 km
  - (2026-08-21) M 5.4 - South Sandwich Islands region
      M5.4 · South Sandwich Islands region · depth 158.986 km
  - (2026-08-21) M 5.4 - 148 km SSE of Tateyama, Japan
      M5.4 · 148 km SSE of Tateyama, Japan · depth 61.666 km
  - (2026-08-21) M 5.2 - 19 km W of Jabonga, Philippines
      M5.2 · 19 km W of Jabonga, Philippines · depth 10 km
  - (2026-08-21) M 5.1 - 1 km N of Alegria, Philippines
      M5.1 · 1 km N of Alegria, Philippines · depth 10 km
  - (2026-08-21) M 5.1 - south of Tonga
      M5.1 · south of Tonga · depth 10 km

### U.S. Federal Action — 22 new of 22 total
  - (2026-08-21) Regulation Crypto Assets
      The Securities and Exchange Commission ("Commission") is proposing new rules to create a tailored offering regime for certain investment contracts involving crypto assets. The proposed offering regime is intended to faci…
  - (2026-08-21) Request for Comment on the Listing of Compute Derivatives Contracts
      The Commodity Futures Trading Commission ("CFTC" or "Commission") is seeking public responses to this Request for Comment to better inform its understanding and oversight of derivatives markets in compute.
  - (2026-08-21) Income Taxes
  - (2026-08-21) Fisheries of the Northeastern United States; Mackerel, Squid, and Butterfish; 2026 Illex Squid Quota Harvested
      NMFS is closing the directed Illex squid fishery in Federal waters based on a projection that 96 percent of the 2026 domestic annual harvest (DAH) will be harvested. This closure is effective 0001 hour (hr) local time on…
  - (2026-08-21) Inflation Adjustment for EOIR OBBBA Fees; Fiscal Year 2027
      The Department of Justice ("Department") is making inflationary adjustments to immigration-related fees for filings with the Executive Office for Immigration Review ("EOIR") as required by the One Big Beautiful Bill Act…
  - (2026-08-21) Environmental Protection Regulations for Domestic Licensing and Related Regulatory Functions

### Paper Trading Scorecard — 22 new of 135 total
  - (2026-08-21) [Polymarket] US-Iran Final Nuclear Deal by October 31, 2026?
      On June 14, 2026, the United States and Iran announced a written diplomatic agreement, including a 60-day extendable period in which both countries committed to negotiate toward a “final deal” regarding Iran’s nuclear pr…
  - (2026-08-21) [Manifold] Daily Coinflip
  - (2026-08-21) [Manifold] Will I have 2500 Traders by September 8, 2026? (9/8/26) Today Manifold Markets says I have 2186. Today is my 90th day.
  - (2026-08-21) [Manifold] WPlace Colors vs Void: Which side will win?
  - (2026-08-21) [Manifold] Do you like 78% odds?
  - (2026-08-21) [Manifold] Will the silver spot price be above $75 USD on September 1st?

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-08-21) Cincinnati Open: Sara Bejlek vs Madison Keys
      yes price: 100% · 24h volume: $2,011,850 · resolves 2026-08-28
  - (2026-08-21) Will Arsenal FC win on 2026-08-21?
      yes price: 100% · 24h volume: $1,794,707 · resolves 2026-08-21
  - (2026-08-21) Cincinnati Open: Taylor Fritz vs Brandon Nakashima
      yes price: 68% · 24h volume: $1,622,966 · resolves 2026-08-28
  - (2026-08-21) Will the Fed increase interest rates by 50+ bps after the September 2026 meeting?
      yes price: 0% · 24h volume: $1,367,536 · resolves 2026-09-16
  - (2026-08-21) Will Coventry City FC win on 2026-08-21?
      yes price: 0% · 24h volume: $1,080,875 · resolves 2026-08-21
  - (2026-08-21) Will Real Betis Balompié win on 2026-08-21?
      yes price: 36% · 24h volume: $718,684 · resolves 2026-08-21

### Government Action: Sanctions + Procurement + Foreign Agents — 15 new of 96 total
  - (2026-08-20) [OFAC] Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions - Office of Fore…
      Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] 1265 - Office of Foreign Assets Control (.gov)
      1265 Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] Ecuadorian Maritime Cocaine Trafficking Network - Office of Foreign Assets Control (.gov)
      Ecuadorian Maritime Cocaine Trafficking Network Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-08-15) [FARA] Trial Attorney, GS-0905-14/15 - Department of Justice (.gov)
      Trial Attorney, GS-0905-14/15 Department of Justice (.gov)
  - (2026-08-21) [USASpending] $27,583,176,865 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-08-21) #30 Dieter Schwarz — $64.53B
      Germany · Fashion & Retail · source: Retail
  - (2026-08-21) MOVER ▲ Elon Musk — $857.12B (+$22.44B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-21) MOVER ▲ Larry Ellison — $189.57B (+$6.00B since yesterday)
      United States · Technology · source: Oracle
  - (2026-08-21) MOVER ▲ Thomas Peterffy — $108.78B (+$4.65B since yesterday)
      United States · Finance & Investments · source: Discount brokerage
  - (2026-08-21) MOVER ▲ Germán Larrea Mota Velasco & family — $72.99B (+$3.88B since yesterday)
      Mexico · Metals & Mining · source: Mining
  - (2026-08-21) MOVER ▲ Larry Page — $281.60B (+$2.76B since yesterday)
      United States · Technology · source: Google

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-08-21) [Marginal Revolution] This brew, at least, is from Ashburn, Virginia
      The post This brew, at least, is from Ashburn, Virginia appeared first on Marginal REVOLUTION.
  - (2026-08-21) [Marginal Revolution] Friday assorted links
      1. Profile of Julian Gough and his evolutionary cosmology. And the Substack version. 2. New Spanish-language edition of Bioy Casares on Borges coming out. The older edition was, among other things, too heavy to lug aroun…
  - (2026-08-21) [Marginal Revolution] Breaking Ground: Can Refund Bonuses Solve the Holdout Problem?
      My latest paper (with Cason and Zubrickas) has just been published by the Journal of Urban Economics. We show that refund bonuses can indeed improve the holdout problem. Abstract: The holdout problem presents a pervasive…
  - (2026-08-21) [Conversable Economist] Even Sand Isn’t Infinite
      The number of grains of sand on a beach is a classic example of an “infinite” number, in the sense that it would be impossible to count. But sand itself isn’t infinite. Demand for sand is way up, around the world, becaus…
  - (2026-08-20) [Conversable Economist] Data Center Spending in US
      The good folks at “Our World in Data” have been putting together a data series which shows monthly spending on the “on-site work to build data centers each month, including materials and construction labor. It excludes t…

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### CISA Known Exploited Vulnerabilities (last 14d) — 3 new of 13 total
  - (2026-08-21) CVE-2026-73570 · Synacor Zimbra Collaboration Suite (ZCS): Zimbra Collaboration Suite (ZCS) OS Command Injection Vulnerability
      vendor: Synacor · product: Zimbra Collaboration Suite (ZCS) · CISA remediation by 2026-08-24
  - (2026-08-20) CVE-2026-72530 · TrueConf Server: TrueConf Server Code Injection Vulnerability
      vendor: TrueConf · product: Server · CISA remediation by 2026-09-03
  - (2026-08-20) CVE-2026-72529 · TrueConf Server: TrueConf Server Missing Authentication for Critical Function Vulnerability
      vendor: TrueConf · product: Server · CISA remediation by 2026-08-23

### EPSS — highest exploit-probability CVEs — 1 new of 40 total
  - (2026-08-21) CVE-2012-1823: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-21) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=22, 7d-median=20, 14d-median=20; carrying terms: program, proposes, certain, national, proposing, proposed, action, state, provide, establish, final, specifically
- state_bills: today=118, 7d-median=129, 14d-median=124; carrying terms: unless, every, payment, based, others, management, violation, project, required, specified, makes, transfer
- state_news: today=722, 7d-median=585, 14d-median=585; carrying terms: tribune, every, others, management, dcist, energy, seeking, center, saying, initiative, lawsuit, nominee
- local_news: today=263, 7d-median=216, 14d-median=229; carrying terms: injured, center, officers, arrested, driver, charles, reported, weekend, officer, local, following, national
- foreign_news: today=1059, 7d-median=978, 14d-median=980; carrying terms: suffered, guizhou, topics, unprecedented, harbin, quality, management, energy, rescue, seeking, ongoing, officers
- chinese_internal: today=305, 7d-median=280, 14d-median=270; carrying terms: cbmiw, chinese, people, politics, cbmiakfvx, cbmibefvx, blank, color, cbmizefvx, cbmixkfvx, global, target
- russian_internal: today=1245, 7d-median=1040, 14d-median=1040; carrying terms: bloomberg, wildberries, blank, reuters, novaya, journal, europe, laquo, novayagazeta, times, street, politico
- ukrainian_internal: today=136, 7d-median=107, 14d-median=107; carrying terms: kyivindependent, injured, energy, infrastructure, prime, putin, donald, security, moscow, defense, russian, ukrinform
- ukraine_theater: today=945, 7d-median=945, 14d-median=945; carrying terms: mzexhm, drzfaexfrmfljodl, obwptvxldx, yaemttujuahzxadr, cuxnaeuytmzqmelqz, aircraft, pwwnqxmjf, cvpnzvfybeptm, wlotalcytmlrmxq, prnzbc, cbmimgfbvv, etvveus
- paper_bets: today=135, 7d-median=141, 14d-median=137; carrying terms: alaska, president, midterms, openai, miles, succeed, miami, growth, sachs, johnny, total, lifetime
- weather: today=216, 7d-median=177, 14d-median=177; carrying terms: scattered, miami, oregon, pendleton, severe, flash, northeast, below, center, ongoing, creek, memphis
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: personal, rates, latest, vixcls, dexuseu, indicator, dexjpus, dexchus, payems, effective, money, openings
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: china, treasury, close, large, rates, commodities, agriculture, yield, nasdaq, bitcoin, natural, range
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=96, 7d-median=93, 14d-median=96; carrying terms: drilling, systems, xskfisuh, relation, transactions, portal, blank, measures, services, related, chemical, controlled
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, client, error, unauthorized, https, httperror, quiver, quiverquant, quantitative
- billionaires: today=40, 7d-median=34, 14d-median=34; carrying terms: diversified, bloomberg, carlos, thomas, finance, buffett, technologies, trading, brokerage, larry, technology, warren
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: appeals, supreme, court, international, company, state, trade, trust, connecticut, delaware, alabama, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, holdings, group
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, booker, senate, alexandria, angels, cycle, house, krishnamoorthi, elect, jonathan, talarico, receipts
- gdelt_regions: today=18, 7d-median=12, 14d-median=9; carrying terms: japan, english, korea, south
- gdelt_gkg: today=50, 7d-median=41, 14d-median=25; carrying terms: english, themes, russian, russia, german, hezbollah, israel, sanctions, perimeter, china, greek, ukrainian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: hormuz, accused, language, domain, australia, english, kingdom
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, france, kingdom, germany, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: passengers, following, bulape, timor, marburg, monkeypox, globally, brands, ministry, investigations, declaration, nipah
- cisa_kev: today=13, 7d-median=9, 14d-median=9; carrying terms: loadmaster, vulnerability, command, secure, vendor, remediation, injection, authentication, product, progress, cisco, firewall
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=277, 14d-median=277; carrying terms: panama, hurricane, fires, flood, nicaragua, drought, north, serbia, myanmar, republic, romania, orange
- usgs_quakes: today=27, 7d-median=24, 14d-median=18; carrying terms: indonesia, depth, islands, russia, region, philippines, ruteng, japan, kuril, south, banda, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: rates, price, volume, champions, championship, meeting, resolves, winner, september, shakhtar, league, donetsk
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, economist, revolution, marginal, class, https, conversableeconomist, marginalrevolution, impossible, future, links, assorted
- tech_news: today=54, 7d-median=56, 14d-median=56; carrying terms: infrastructure, vulnerability, government, technology, record, known, security, attacks, computer, including, weekday, cybersecurity
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: bradley, kustoff, becca, thomas, ronny, jason, bergman, risch, flood, greer, ricketts, houchin
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, unavailable, markets, claude, sufficient, paper, converges, decision, market, placed, identify, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*