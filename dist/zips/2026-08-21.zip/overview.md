# WORLDSCOPE morning brief — 2026-08-21

## Headline
3456 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (752) · Russian Internal News (state + in-exile) (702) · Ukraine Theater (total-war monitoring) (380) · World leaders & government officials (324) · State-Level News (292) · Chinese Internal News (229) · Local News: St. Louis + Atlanta (199) · U.S. Weather + Severe / Climate Outlooks (180) · State Legislative Action (67) · Ukrainian Internal News (national + local Kyiv) (57) · SEC Form 4 insider transactions (recent) (40) · IT, InfoSys & cybersecurity news (last 7 days) (39)

## What changed today
### International News + Multilateral Institutions — 752 new of 1029 total
  - (2026-08-20) [Global] US deports 20 people to Liberia, the first of 1,200 migrants under Trump deal
  - (2026-08-21) [Global] Russia’s missile tests around disputed islands anger Japan
  - (2026-08-21) [Global] Tiananmen Square vigil organisers found guilty in Hong Kong of ‘inciting subversion’
  - (2026-08-20) [Global] Founder of China’s Evergrande jailed for life after pleading guilty to fraud
  - (2026-08-20) [Global] North Korea fires 10 missiles day after Trump curtails South Korea joint drills
  - (2026-08-21) [Global] Australia news live: Hiker Lily Hooper remembered as someone ‘everyone liked’; testing under way after dozens of little penguins found dead

### Russian Internal News (state + in-exile) — 702 new of 1115 total
  - (2026-08-21) «Коммерсант»: российские издательства сократили тиражи из-за украинских атак на склады Wildberries (там хранятся их книги) | LEDE: Некоторые российские издательства остановили печать новых к] (ru: «Ко…
      Некоторые российские издательства остановили печать новых книг и начали сокращать тиражи после атак украинских беспилотников на склады Wildberries, рассказали «Коммерсанту» два собеседника в крупных сетях.
  - (2026-08-21) VK подала иск против Apple в московский суд — из-за удаления ее приложений из App Store | LEDE: Компания VK подала иск против Apple в Арбитражный суд Москвы, сообщает «Интерфакс». ] (ru: VK подала иск…
      Компания VK подала иск против Apple в Арбитражный суд Москвы, сообщает «Интерфакс».
  - (2026-08-21) ФСБ задержала иностранца. По версии спецслужбы, он запустил дрон на московском вокзале, чтобы подготовить теракт | LEDE: В Мурманской области задержали иностранца, которого подозревают в под] (ru: ФСБ…
      В Мурманской области задержали иностранца, которого подозревают в подготовке теракта в Москве по указанию украинских спецслужб, заявили в ФСБ.
  - (2026-08-21) На фигуранта «дела канских подростков» Никиту Уварова завели еще одно уголовное дело | LEDE: Против 21-летнего жителя города Канска возбуждено уголовное дело «о вовлечении в деятельность экс] (ru: На…
      Против 21-летнего жителя города Канска возбуждено уголовное дело «о вовлечении в деятельность экстремистской организации», сообщили в Следственном комитете по Красноярскому краю.
  - (2026-08-21) Мобилизация в России «не планируется и не ожидается», заявил поспред РФ при ООН Василий Небензя | LEDE: Постоянный представитель РФ при ООН Василий Небензя заявил, что мобилизация в России н] (ru: Моб…
      Постоянный представитель РФ при ООН Василий Небензя заявил, что мобилизация в России не планируется.
  - (2026-08-21) Украинские беспилотники атаковали Пермь | LEDE: В Перми утром 21 августа была объявлена беспилотная опасность, включены сирены, жители города сообщали о взрывах. Городской аэропорт не приним] (ru: Укр…
      В Перми утром 21 августа была объявлена беспилотная опасность, включены сирены, жители города сообщали о взрывах. Городской аэропорт не принимал и не отправлял рейсы.

### Ukraine Theater (total-war monitoring) — 380 new of 631 total
  - (2026-08-21) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-08-20) [FIRMS] thermal anomaly 44.053, 25.323 (FRP 11.42 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1147Z, FRP 11.42 MW
  - (2026-08-20) [FIRMS] thermal anomaly 44.057, 25.322 (FRP 17.29 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1147Z, FRP 17.29 MW
  - (2026-08-20) [FIRMS] thermal anomaly 44.065, 23.549 (FRP 13.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1149Z, FRP 13.41 MW
  - (2026-08-20) [FIRMS] thermal anomaly 44.069, 23.548 (FRP 9.92 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1149Z, FRP 9.92 MW
  - (2026-08-20) [FIRMS] thermal anomaly 44.003, 22.113 (FRP 5.36 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-20 1149Z, FRP 5.36 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 292 new of 571 total
  - (2026-08-20) [Alabama] Governor Ivey Announces More Than $52 Million in GoMESA Funded Projects for 2026
      MONTGOMERY – Governor Kay Ivey on Thursday announced more than $52 million for 21 projects in Coastal Alabama supported by funds from the Gulf of Mexico Energy Security Act of 2006 (GoMESA). These projects focus on envir…
  - (2026-08-21) [California] Governor Newsom signs legislation 8.20.2026
      Source
  - (2026-08-20) [California] Governor Newsom awards $11.3 million to 13 prohousing communities to build more affordable housing
      Source
  - (2026-08-20) [California] California sends FREE life-saving asthma inhalers to ALL schools
      Source
  - (2026-08-21) [California] AI led to mistakes in Nevada County criminal cases. Should the DA be sanctioned?
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/082026-Nevada-County-Court-CM-01-scaled.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-po…
  - (2026-08-21) [California] Lawmakers gut major DUI reform through ‘hostile amendments’
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/08/081825-RedistrictingPress-MG-CM-15.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### Chinese Internal News — 229 new of 296 total
  - (2026-08-20) China Sentences Evergrande Founder Hui Ka Yan to Life in Prison for Massive Fraud - Caixin Global
      China Sentences Evergrande Founder Hui Ka Yan to Life in Prison for Massive Fraud Caixin Global
  - (2026-08-20) 责编：王 平 金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxOdHpneGNncW03UEN3eVlKSmFXdmlmVnkxbUlSRW9VVHdCc1VGbkdwQ1FJZTU4MmRpd0pwMkZ5cmZYRzgtYWU0Z] (zh:…
      责编：王 平 金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-08-21) 讽刺与幽默 2026年08月21日 星期五 - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMic0FVX3lxTE1jTk9HSjhJcXJnU2FUT19BU0xnamR1UmZHY1psQXlLcktuWUhTWlZ5c3FRRmdMNjJMdGxXRFJYZlZhSGU0ZkNqYXo0bUdXcH] (zh:…
      讽刺与幽默 2026年08月21日 星期五 人民日报
  - (2026-08-21) 江苏省省管领导干部任职前公示 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE1qd080NEhIb3Z5M0cxNGNwZEhzbjBLTDRydW9OTnNPRlB3Vkxnc0kweXV4YWU2S2owSHBEeE9UTTdPV2swaGdmMy16LXFvTDByNFJwdk] (zh:…
      江苏省省管领导干部任职前公示 人民网
  - (2026-08-20) 江苏交通水利等一批重大项目迎来重要建设节点 - 人民网－江苏频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBkUGxSaGdLU1lMRWEtRnlIRVdwcTVwckQ3RmM4ZHZBRVRBb2QyeWxYUjNmRlY4UzNaVjRxMWFJNzBQTDV2YWkyZlN6b0] (zh:…
      江苏交通水利等一批重大项目迎来重要建设节点 人民网－江苏频道
  - (2026-08-21) “出口中国”活动走进埃塞 - 共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFB6OG5RMTRMeFF1TUd3amQ2TTZfRHRZMTBKU0J1QXI4RWJWYUZybFEtemxta3FHMGNaSDNXMlZLRThoS1FIdWQ3MVQwdVpvX1lYbjBoY] (zh:…
      “出口中国”活动走进埃塞 共产党新闻网

### Local News: St. Louis + Atlanta — 199 new of 234 total
  - (2026-08-21) [St. Louis] What’s True in the Lou? – 8/21/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-08-20) [St. Louis] Stanley Browne launches Cellar & Table, a new wine and hospitality venture in St. Louis
      Hospitality veteran and certified sommelier Stanley Browne has launched a new wine and hospitality consulting business. Cellar & Table will offer a range of services, including hospitality consulting, wine experiences an…
  - (2026-08-20) [St. Louis] Demand for food aid swells in St. Louis—and then swells more
      Little brains need food. Research suggests that nourished kiddos do better in school. One study from 2019 even found that exposure to food-stamp benefits increased the lifetime earnings of needy kids by up to 7 percent o…
  - (2026-08-20) [St. Louis] Clayton pushes back on wall around Napoli patio
      One of Clayton’s most popular restaurants wants to give diners on its prominent downtown patio more separation from the comings and goings on the street. But Clayton officials don’t want that protection to wall off one o…
  - (2026-08-20) [St. Louis] Fate of Missouri congressional redistricting top of mind at governor’s annual ham breakfast
  - (2026-08-20) [St. Louis] Flock cameras are bagged up after employee abused system, St. Charles County Police say

### U.S. Weather + Severe / Climate Outlooks — 180 new of 185 total
  - (2026-08-21) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-21) [Moderate] Special Weather Statement: Special Weather Statement issued August 21 at 2:33AM CDT by NWS La Crosse WI
      At 232 AM CDT, Doppler radar was tracking a strong thunderstorm near Stacyville, or 15 miles north of Osage, moving east at 35 mph. HAZARD...Wind gusts up to 50 mph and pea size hail. SOURCE...Radar indicated. IMPACT...G…
  - (2026-08-21) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued August 21 at 3:31AM EDT until August 21 at 10:00PM EDT by NWS Marquette MI
      * WHAT...Dangerous swimming conditions are due to high wave action and strong rip currents. * WHERE...Southern Schoolcraft County. * WHEN...Through this evening. * IMPACTS...High wave action and dangerous currents will l…
  - (2026-08-21) [Moderate] Special Weather Statement: Special Weather Statement issued August 21 at 2:27AM CDT by NWS Norman OK
      At 225 AM CDT, Doppler radar was tracking a strong thunderstorm near Lamar, moving south at 30 mph. HAZARD...Wind gusts of 40 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down tree li…
  - (2026-08-21) [Moderate] Special Weather Statement: Special Weather Statement issued August 21 at 3:22AM EDT by NWS Peachtree City GA
      At 322 AM EDT, a strong thunderstorm was over Mount Bethel, or near Marietta, moving east at 10 mph. HAZARD...Up to 40 mph wind, frequent cloud to ground lightning and heavy rain. SOURCE...Radar indicated. IMPACT...Expec…
  - (2026-08-21) [Moderate] Special Weather Statement: Special Weather Statement issued August 21 at 2:22AM CDT by NWS Tulsa OK
      At 222 AM CDT, Doppler radar indicated a strong thunderstorm over Hanna, moving south at 20 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock down smal…

### State Legislative Action — 67 new of 139 total
  - (2026-08-21) [Alaska HB 216] An Act approving the transfer of land owned by the Alaska Railroad Corporation to the City of Whittier; and providing for an effective date.
      An Act approving the transfer of land owned by the Alaska Railroad Corporation to the City of Whittier; and providing for an effective date.
  - (2026-08-21) [Alaska HB 286] An Act relating to an optional municipal tax exemption for the homes of volunteer firefighters and volunteer providers of emergency medical services or mobile intensive care paramedic…
      An Act relating to an optional municipal tax exemption for the homes of volunteer firefighters and volunteer providers of emergency medical services or mobile intensive care paramedic services; and providing for an effec…
  - (2026-08-21) [Alaska HB 282] An Act relating to municipal regulation of automated traffic safety cameras.
      An Act relating to municipal regulation of automated traffic safety cameras.
  - (2026-08-20) [Alaska HB 289] An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; an…
      An Act making appropriations, including supplemental appropriations, capital appropriations, reappropriations, and other appropriations; amending appropriations; capitalizing funds; and providing for an effective date.
  - (2026-08-20) [Alaska HB 239] An Act relating to crime and criminal procedure; relating to civil claims by victims of sexual abuse of a minor; relating to homicide; relating to assault; relating to sexual assault;…
      An Act relating to crime and criminal procedure; relating to civil claims by victims of sexual abuse of a minor; relating to homicide; relating to assault; relating to sexual assault; relating to stalking; relating to se…
  - (2026-08-20) [Alaska HB 133] An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements t…
      An Act establishing deadlines for the payment of contracts under the State Procurement Code; establishing deadlines for the payment of grants, contracts, and reimbursement agreements to nonprofit organizations, municipal…

### Ukrainian Internal News (national + local Kyiv) — 57 new of 115 total
  - (2026-08-21) Окупанти атакували FPV-дронами цивільних на Запоріжжі: 4 поранених | LEDE: У Запорізькому районі четверо людей поранені внаслідок ударів російських FPV-дронів. Постраждалим надають меддопомогу.] (uk:…
      У Запорізькому районі четверо людей поранені внаслідок ударів російських FPV-дронів. Постраждалим надають меддопомогу.
  - (2026-08-21) Білорусь вирішила закрити своє посольство у Фінляндії | LEDE: ] (uk: Білорусь вирішила закрити своє посольство у Фінляндії)
  - (2026-08-21) У Німеччині розглядають закриття "Русского дома" у Берліні після інциденту з дроном в Лейпцигу – ЗМІ | LEDE: Уряд Німеччини обговорює можливе закриття "Русского дома" після інциденту з дроном у] (uk:…
      Уряд Німеччини обговорює можливе закриття "Русского дома" після інциденту з дроном у Лейпцигу.
  - (2026-08-21) Українське суспільство випередило державу: як війна перетворила країну на "мурмурацію" | LEDE: ] (uk: Українське суспільство випередило державу: як війна перетворила країну на "мурму)
  - (2026-08-21) Підпис ціною 250 млн євро. Президент гальмує кошти для України, але проблема не лише у ньому | LEDE: На кону – орієнтовно 250 млн євро. Але президент тягне з рішенням вже понад місяць, і немає ] (uk:…
      На кону – орієнтовно 250 млн євро. Але президент тягне з рішенням вже понад місяць, і немає певності, чи не буде зірваний крайній термін...
  - (2026-08-21) Суспільство, яке переросло свою державу | LEDE: Як змінились суспільство й держава за 12 років війни. Мурмурація, самоорганізація, розрив швидкостей.] (uk: Суспільство, яке переросло свою державу)
      Як змінились суспільство й держава за 12 років війни. Мурмурація, самоорганізація, розрив швидкостей.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-21) [Chuang Shun-Chih] Form 4 (Reporting)
      filed 2026-08-21 01:58 UTC · role: Reporting — Filed: 2026-08-20 AccNo: 0001683168-26-006638 Size: 7 KB
  - (2026-08-21) [NOCERA, INC.] Form 4 (Issuer)
      filed 2026-08-21 01:58 UTC · role: Issuer — Filed: 2026-08-20 AccNo: 0001683168-26-006638 Size: 7 KB
  - (2026-08-21) [Huidor Mark Antonio] Form 4 (Reporting)
      filed 2026-08-21 01:45 UTC · role: Reporting — Filed: 2026-08-20 AccNo: 0001193125-26-359706 Size: 11 KB
  - (2026-08-21) [Cineverse Corp.] Form 4 (Issuer)
      filed 2026-08-21 01:45 UTC · role: Issuer — Filed: 2026-08-20 AccNo: 0001193125-26-359706 Size: 11 KB
  - (2026-08-21) [Repass Wolfe] Form 4 (Reporting)
      filed 2026-08-21 01:30 UTC · role: Reporting — Filed: 2026-08-20 AccNo: 0001193125-26-359693 Size: 6 KB
  - (2026-08-21) [Fold Holdings, Inc.] Form 4 (Issuer)
      filed 2026-08-21 01:30 UTC · role: Issuer — Filed: 2026-08-20 AccNo: 0001193125-26-359693 Size: 6 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 39 new of 56 total
  - (2026-08-21) [The Hacker News] Microsoft Entra ID Flaw (CVSS 10.0) Exploited in Wild, Allows Remote Code Execution
      Microsoft on Thursday warned of a maximum-severity security flaw in Entra ID that it said has been exploited in the wild, but noted that no customer action is required. The vulnerability, tracked as CVE-2026-69836 (CVSS…
  - (2026-08-21) [The Register] EE invites mobile users to live life in the 5G Fast Lane – for a price
      Network slicing offers a prioritized experience for those prepared to pay for a premium monthly plan
  - (2026-08-21) [The Register] Developer given Mission:Impossible - fixing rubbish code that could crash a city - simply chose not to accept it
      After imagining explosions, blackouts, and daring escapes, this techie decided the best thing to do was just not doing the job
  - (2026-08-21) [The Register] Cisco bug severity warning reads like Olympic gymnastics scores: 10, 10, 9.9, 9.6, and 7.5.
      Secure Workload Software has five nasty flaws and even SaaS users have updates to install
  - (2026-08-21) [The Register] Alibaba Cloud plans to use fewer Western chips, to boost its already huge AI margins
      Cloudy AI is Chinese giant’s ‘most certain’ path to growth as e-commerce slows
  - (2026-08-21) [The Register] Supermicro fired staff after probe into $2.5 billion GPUs-to-China smuggling operation
      Policies and code of conduct breached

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Court opinions of consequence (federal & state) — 29 new of 60 total
  - (2026-08-25) Connecticut Supreme Court: Lasa Extract, LLC v. Zoning Board of Appeals
  - (2026-08-20) Delaware Supreme Court: Project Labrador Holdco, LLC v. Bakkt Opco Holdings, LLC
  - (2026-08-20) U.S. Court of Appeals, D.C. Cir.: Adsync Technologies, Inc. v. FAA (PUBLIC REISSUED)
  - (2026-08-20) U.S. Court of Appeals, 10th Cir.: United States v. Kahn
  - (2026-08-20) U.S. Court of International Trade: Inspired Ventures, LLC v. United States
  - (2026-08-20) U.S. Court of Appeals, Federal Cir.: Gordon v. Collins

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-08-21) [Taiwan Strait + South China Sea · themes] AP News in Brief at 12 : 04 a . m . EDT
      hngnews.com · English · tone NA
  - (2026-08-21) [Taiwan Strait + South China Sea · themes] Storms and possible tornadoes pummel the Northeast US , flooding roads and damaging beaches
      hngnews.com · English · tone NA
  - (2026-08-21) [Taiwan Strait + South China Sea · themes] Al menos 46 fallecidos y 16 desaparecidos tras volcar una embarcación en Nigeria
      24horas.cl · Spanish · tone NA
  - (2026-08-21) [Taiwan Strait + South China Sea · themes] ماذا يحدث لجسمك عند تناول التين ؟
      masrawy.com · Arabic · tone NA
  - (2026-08-21) [Taiwan Strait + South China Sea · themes] Schwerer E - Scooter - Unfall in Frankfurt ➤ Hessen am Morgen : Die Nachrichten im Ticker vom 21 . 08 . 2026
      hessenschau.de · German · tone NA
  - (2026-08-21) [Taiwan Strait + South China Sea · themes] Древни поверия оживяват на 21 август - Общество Новини Стандарт
      standartnews.com · Bulgarian · tone NA

### Government & military aircraft airborne (OpenSky) — 20 new of 21 total
  - (2026-08-21) JAF76T (Bulgaria)
      icao24: 4520aa · position: (44.3081, -3.981) · alt: 10980m · 884km/h
  - (2026-08-21) JEDI27 (France)
      icao24: 39a842 · position: (46.0364, -0.0352) · alt: 1348m · 249km/h
  - (2026-08-21) GAF213 (Germany)
      icao24: 3f727c · position: (49.0474, 3.2447) · alt: 10050m · 579km/h
  - (2026-08-21) JAF7HW (Belgium)
      icao24: 44d1ba · position: (31.2147, -15.3525) · alt: 11277m · 840km/h
  - (2026-08-21) JAF2HN (Belgium)
      icao24: 44d1a6 · position: (36.9254, 24.7918) · alt: 11277m · 713km/h
  - (2026-08-21) JAF4AB (Belgium)
      icao24: 44d1a7 · position: (36.5475, 27.6119) · alt: 4747m · 699km/h

### USGS earthquakes (M4.5+, past day) — 18 new of 21 total
  - (2026-08-20) M 6.7 - 31 km NW of Aniso, Peru
      M6.7 · 31 km NW of Aniso, Peru · depth 99 km
  - (2026-08-20) M 5.6 - 67 km NNW of Ende, Indonesia
      M5.6 · 67 km NNW of Ende, Indonesia · depth 10 km
  - (2026-08-20) M 5.3 - 48 km NNE of Ruteng, Indonesia
      M5.3 · 48 km NNE of Ruteng, Indonesia · depth 10 km
  - (2026-08-20) M 5.2 - 270 km SSE of Dunhuang, China
      M5.2 · 270 km SSE of Dunhuang, China · depth 10 km
  - (2026-08-20) M 5.1 - 183 km SE of Kokopo, Papua New Guinea
      M5.1 · 183 km SE of Kokopo, Papua New Guinea · depth 35 km
  - (2026-08-20) M 5.0 - Pacific-Antarctic Ridge
      M5.0 · Pacific-Antarctic Ridge · depth 10 km

### Paper Trading Scorecard — 15 new of 137 total
  - (2026-08-21) [Polymarket] US-Iran Final Nuclear Deal by October 31, 2026?
      On June 14, 2026, the United States and Iran announced a written diplomatic agreement, including a 60-day extendable period in which both countries committed to negotiate toward a “final deal” regarding Iran’s nuclear pr…
  - (2026-08-21) [Manifold] Will the silver spot price be above $75 USD on September 1st?
  - (2026-08-21) [Manifold] Will North Korea launch another ballistic missile before September 1, 2026?
  - (2026-08-21) [Manifold] tung tung tung sahur dies by the end of the month
  - (2026-08-21) [Manifold] Will the WTI Crude Oil Spot Price be above $86.50 on August 27, 2026?
  - (2026-08-21) [Manifold] Will Donald Trump mention the Deltarune References that the Department of War has made?

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-08-21) Dota 2: Team Liquid vs Team Falcons - Game 1 Winner
      yes price: 0% · 24h volume: $3,066,591 · resolves 2026-08-21
  - (2026-08-21) Dota 2: Team Spirit vs TEAM VISION (BO3) - The International Playoffs
      yes price: 36% · 24h volume: $1,933,404 · resolves 2026-08-21
  - (2026-08-21) Dota 2: Team Liquid vs Team Falcons (BO3) - The International Playoffs
      yes price: 28% · 24h volume: $1,141,674 · resolves 2026-08-21
  - (2026-08-21) NATO x Russia military clash by August 31, 2026?
      yes price: 4% · 24h volume: $1,090,988 · resolves 2026-08-31
  - (2026-08-21) LoL: EDward Gaming vs ThunderTalk Gaming - Game 1 Winner
      yes price: 18% · 24h volume: $438,551 · resolves 2026-08-21
  - (2026-08-21) Will Brentford win the 2026-27 English Premier League (EPL) Championship?
      yes price: 0% · 24h volume: $369,773 · resolves 2027-05-30

### Government Action: Sanctions + Procurement + Foreign Agents — 14 new of 96 total
  - (2026-08-20) [OFAC] Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions - Office of Fore…
      Counter Narcotics, Counter Terrorism, Cuba-related, and Iran-related Designations; Issuance of Russia-related General License; Issuance of Associated Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] 1265 - Office of Foreign Assets Control (.gov)
      1265 Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-08-20) [OFAC] Ecuadorian Maritime Cocaine Trafficking Network - Office of Foreign Assets Control (.gov)
      Ecuadorian Maritime Cocaine Trafficking Network Office of Foreign Assets Control (.gov)
  - (2026-08-15) [FARA] Trial Attorney, GS-0905-14/15 - Department of Justice (.gov)
      Trial Attorney, GS-0905-14/15 Department of Justice (.gov)
  - (2026-08-21) [USASpending] $27,583,176,865 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 11 new of 40 total
  - (2026-08-21) #30 Dieter Schwarz — $64.14B
      Germany · Fashion & Retail · source: Retail
  - (2026-08-21) MOVER ▼ Elon Musk — $834.68B ($-31.28B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-08-21) MOVER ▼ Rob Walton & family — $126.15B ($-9.45B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-08-21) MOVER ▼ Jim Walton & family — $125.41B ($-9.43B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-08-21) MOVER ▼ Alice Walton — $115.31B ($-9.21B since yesterday)
      United States · Fashion & Retail · source: Walmart
  - (2026-08-21) MOVER ▼ Jeff Bezos — $267.95B ($-5.06B since yesterday)
      United States · Technology · source: Amazon

### World News (by country, top stories) — 6 new of 6 total
  - (2026-08-21) [China] न्यूज़ फोकस --- 21 - 08 - 2026
      hindi.cri.cn · English
  - (2026-08-21) [China] 12조4천억 위안 ! 데이터로 보는 중국의 지속적인 민생 투자 확대
      korean.cri.cn · English
  - (2026-08-21) [China] Dow Jones Top Company Headlines at 1 AM ET : SpaceX Is Racking Up Wins in Washington | Layoffs ...
      morningstar.com · English
  - (2026-08-21) [China] 美国纪实 ： 晒晒我学生的宿舍 ， 他们提交的真实图片 ， 充满生活气息 | www . wenxuecity . com
      wenxuecity.com · English
  - (2026-08-21) [China] 带状疱疹的诊断及其后遗症的针灸治疗 | www . wenxuecity . com
      wenxuecity.com · English
  - (2026-08-21) [China] 超越SpaceX ！ 史上最大IPO ， 或要来了 | www . wenxuecity . com
      wenxuecity.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #718895
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-21) [Marginal Revolution] Rick Rubin podcasts with me
      Two hours, thirty-four minutes, Rick and I recorded this session not too long ago in Tuscany. It was everything Rick wanted to ask. Self-recommending of course, and there is more to come. The post Rick Rubin podcasts wit…
  - (2026-08-21) [Marginal Revolution] Green shoots for the UK?
      Early signs of tech-driven improvements in productivity growth could herald a sustained strengthening in the UK’s economic outlook, analysts have said, in a turnaround after years of underperformance. Private sector prod…
  - (2026-08-21) [Marginal Revolution] More evidence on the effects of recent tariffs
      Trump is giving economists something to write papers about: U.S. tariff rates in 2025 rose to levels not seen since the Great Depression, yet imports increased. To account for the missing trade collapse, we develop an op…
  - (2026-08-20) [Conversable Economist] Data Center Spending in US
      The good folks at “Our World in Data” have been putting together a data series which shows monthly spending on the “on-site work to build data centers each month, including materials and construction labor. It excludes t…

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 12 total
  - (2026-08-20) CVE-2026-72530 · TrueConf Server: TrueConf Server Code Injection Vulnerability
      vendor: TrueConf · product: Server · CISA remediation by 2026-09-03
  - (2026-08-20) CVE-2026-72529 · TrueConf Server: TrueConf Server Missing Authentication for Critical Function Vulnerability
      vendor: TrueConf · product: Server · CISA remediation by 2026-08-23

### EPSS — highest exploit-probability CVEs — 1 new of 40 total
  - (2026-08-20) CVE-2012-1823: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-21) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=20, 14d-median=20; carrying terms: action, proposing, final, establish, certain, program, provide, state, proposed, national, proposes, service
- state_bills: today=139, 7d-median=137, 14d-median=129; carrying terms: agency, employees, person, provided, agencies, providing, payment, private, general, vehicle, others, purposes
- state_news: today=571, 7d-median=571, 14d-median=571; carrying terms: approved, students, officer, effort, number, loading, republicans, climate, reporting, ctmirror, falls, seven
- local_news: today=234, 7d-median=216, 14d-median=229; carrying terms: taken, another, officer, missouri, inside, faces, concerns, atlanta, found, health, color, state
- foreign_news: today=1029, 7d-median=978, 14d-median=980; carrying terms: panel, maverick, windshield, least, updating, yongning, huawei, measures, stressed, climate, assistant, outbreak
- chinese_internal: today=296, 7d-median=280, 14d-median=270; carrying terms: cbmixkfvx, color, cbmiaefvx, china, cbmiyefvx, cbmickfvx, cbmia, cbmiw, google, blank, chinese, cbmibefvx
- russian_internal: today=1115, 7d-median=1040, 14d-median=1040; carrying terms: novaya, istories, found, reuters, telegram, journal, title, politico, client, media, world, bloomberg
- ukrainian_internal: today=115, 7d-median=107, 14d-median=107; carrying terms: least, another, security, fighting, western, systems, odesa, several, troops, general, missile, remains
- ukraine_theater: today=631, 7d-median=887, 14d-median=887; carrying terms: fhulffc, tbeuz, lxzrd, dvnht, approved, least, hvymd, cuxps, ownvwaejqetbqwdnjsdgwzkrodhvuou, demining, mlczuvbwyk, digitalization
- paper_bets: today=137, 7d-median=141, 14d-median=137; carrying terms: james, supreme, achieved, party, colonize, least, georgia, mamdani, celsius, koivun, manifold, rippling
- weather: today=185, 7d-median=177, 14d-median=177; carrying terms: pontiac, phoenix, return, arkansas, scattered, excessive, western, below, america, little, degrees, index
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, payrolls, latest, openings, dcoilwtico, cpilfesl, total, rates, energy, money, growth, walcl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, yield, agriculture, range, crude, nasdaq, silver, credit, corporate, futures, natural, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=96, 7d-median=93, 14d-median=96; carrying terms: hybrid, imposed, agency, qaida, moldova, integrated, cbmiqkfvx, google, violations, schools, congo, security
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: error, unauthorized, quiver, httperror, https, quantitative, quiverquant, congresstrading, client
- billionaires: today=40, 7d-median=34, 14d-median=34; carrying terms: steve, gautam, canada, india, larrea, berkshire, gates, family, retail, brokerage, walton, thomas
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, state, company, appeals, group, international, trust, blanche, connecticut, trade, america
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, reporting, filed, accno, capital, holdings, michael, group, william
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, warner, trone, graham, booker, platner, filing, alexandria, senate, committee, talarico, johnson
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, korean
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, russian, themes, trump, spanish, strait, german, china, greek, arabic, italian, south
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=21, 7d-median=29, 14d-median=30; carrying terms: position, belgium, france, ground, kingdom, germany, bulgaria, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: analyzed, resurgence, notified, vaccine, recombination, municipalities, haemorrhage, continued, additi, sylvatic, local, among
- cisa_kev: today=12, 7d-median=9, 14d-median=9; carrying terms: remediation, injection, authentication, secure, progress, product, firewall, vulnerability, cisco, loadmaster, vendor, command
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=277, 14d-median=277; carrying terms: thailand, denmark, canada, solomon, dolphin, vietnam, southeast, herzegovina, depth, cyclone, france, congo
- usgs_quakes: today=21, 7d-median=21, 14d-median=18; carrying terms: indonesia, depth, islands, japan, ruteng, guinea, papua, south, levuka, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: interest, volume, donetsk, champions, resolves, price, rates, championship, winner, september, shakhtar, league
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversable, economist, marginal, class, revolution, https, marginalrevolution, social, seems, growth, wrote, write
- tech_news: today=56, 7d-median=56, 14d-median=56; carrying terms: google, vulnerabilities, security, techcrunch, researchers, systems, years, navigate, world, september, critical, found
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: casar, owens, scalise, emmer, sherman, markwayne, terri, elfreth, ronny, keating, tiffany, timmons
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, converges, today, identify, consensus, sufficient, paper, evidence, decision, module, unavailable, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-07] ECB press: ECB publishes consolidated banking data for end-March 2026
- [2026-08-11] ECB press: ECB and Frankfurt Radio Symphony invite the public to Europa Open Air concert on 20 August 2026
- [2026-08-13] ECB press: Cash remains most widely accepted payment method in euro area
- [2026-08-13] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Regions Bank
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*