# WORLDSCOPE morning brief — 2026-10-01

## Headline
3472 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (861) · Russian Internal News (state + in-exile) (643) · State-Level News (385) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (261) · Chinese Internal News (190) · Local News: St. Louis + Atlanta (182) · U.S. Weather + Severe / Climate Outlooks (162) · State Legislative Action (90) · Ukrainian Internal News (national + local Kyiv) (63) · IT, InfoSys & cybersecurity news (last 7 days) (42) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 861 new of 1046 total
  - (2026-10-01) [Global] AI boom could trigger market shocks, Bank of England boss warns
      Andrew Bailey says the central bank is watching the waves of cash being invested in artificial intelligence "very carefully".
  - (2026-10-01) [Global] Trump's AI rebrand causes 'unprecedented' demand for Slovenian website names
      The president wants AI to be called super intelligence - or SI - the same initials used by Slovenian domains.
  - (2026-10-01) [Global] Travelodge failed sex assault victim 'at every stage'
      Room intrusions were still being reported at one-in-10 Travelodge hotels this summer, a review finds.
  - (2026-09-30) [Global] Vape tax comes into effect - but prices won't rise yet
      Vaping is about to becoming more expensive due to a new tax on products.
  - (2026-10-01) [Global] Employers should teach primary-age children about work, says Milburn
      The author of a major report into youth activity in the UK says children as young as four should be learning about careers.
  - (2026-09-30) [Global] The AI telling farmers when to harvest
      Will farmers want AI tools to help judge when to pick fruit, or is their own intuition enough?

### Russian Internal News (state + in-exile) — 643 new of 1049 total
  - (2026-10-01) Война. 1681-й день. Российские войска впервые атаковали дронами Южный мост в Киеве. По нему в момент удара шел поезд метро | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-10-01) Обвиняемый в убийстве бывшего депутата Верховной рады Ирины Фарион получил пожизненное | LEDE: Шевченковский районный суд Львова приговорил жителя Днепра Вячеслава Зинченко к пожизненному за] (ru: Обв…
      Шевченковский районный суд Львова приговорил жителя Днепра Вячеслава Зинченко к пожизненному заключению по делу об убийстве политика Ирины Фарион.
  - (2026-10-01) Артем Дзюба объявил, что завершил карьеру | LEDE: Российский футболист Артем Дзюба объявил, что завершил профессиональную карьеру. ] (ru: Артем Дзюба объявил, что завершил карьеру)
      Российский футболист Артем Дзюба объявил, что завершил профессиональную карьеру.
  - (2026-10-01) Шеф-редактора The Voice Mag (бывший Cosmopolitan) оштрафовали за статью о том, что в Дубае на фоне обстрелов вырос спрос на секс-услуги | LEDE: Шеф-редактора издания The Voice Mag (ранее рос] (ru: Шеф…
      Шеф-редактора издания The Voice Mag (ранее российская версия Cosmopolitan) Екатерину Великину оштрафовали на 10 тысяч рублей из-за статьи, в которой упоминались слухи о том, что в Дубае на фоне обстрелов вырос спрос на с…
  - (2026-10-01) Пи Дидди, осужденный за сексуализированное насилие, очень хорошо устроился в тюрьме. Другие заключенные готовят ему еду и делают массаж, пока он пьет Hennessy. Когда это вскрылось, рэпера отпра] (ru:…
      Рэпер Пи Дидди (настоящее имя — Шон Комбс) тратит тысячи долларов в месяц, чтобы сохранить «привычный образ жизни» в тюрьме Форт-Дикс в штате Нью-Джерси. Об этом телеканалу NBC рассказали другие заключенные. Они также пр…
  - (2026-10-01) Власти России планируют в 2026 году получить от бизнеса почти полтриллиона рублей добровольных взносов в бюджет | LEDE: Российские власти ожидают, что в 2026 году в бюджет страны поступит 47] (ru: Вла…
      Российские власти ожидают, что в 2026 году в бюджет страны поступит 471,4 миллиарда рублей в виде добровольных взносов от бизнеса. Об этом говорится в пояснительной записке к проекту бюджета на 2027-2029 годы, с которой…

### State-Level News — 385 new of 833 total
  - (2026-09-30) [Alabama] Governor Ivey Announces Alabama Again Named Among Nation’s Top 10 States for Doing Business
      MONTGOMERY – Governor Kay Ivey on Wednesday announced Alabama has again been named among the nation’s top 10 states for doing business by Area Development magazine, continuing a streak of high rankings in the national pu…
  - (2026-09-30) [Alabama] Governor Ivey Urges Public Awareness of Potential Dangers Associated with Kratom Products
      MONTGOMERY – Governor Kay Ivey and the Alabama Law Enforcement Agency (ALEA) are urging parents, young people and consumers to be aware of the potential dangers associated with kratom and products that may contain the su…
  - (2026-09-30) [Alabama] Governor Ivey Keeps Rebuild Alabama Momentum Moving with $3.8 Million for Local Road Projects
      MONTGOMERY – Governor Kay Ivey on Wednesday announced that more than $3.8 million in state funding is being awarded to cities and counties for 13 road projects across Alabama, highlighting her ongoing commitment to enhan…
  - (2026-10-01) [California] At the top of the Golden Gate Bridge, Governor Newsom signs his final bill — investing in California’s next generation of innovation
      Source
  - (2026-10-01) [California] Governor Newsom announces appointments
      Source
  - (2026-10-01) [California] Governor Newsom issues legislative update 9.30.2026
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 261 new of 670 total
  - (2026-09-30) [FIRMS] thermal anomaly 44.080, 23.430 (FRP 5.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-30 1219Z, FRP 5.41 MW
  - (2026-09-30) [FIRMS] thermal anomaly 44.085, 23.429 (FRP 5.41 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-30 1219Z, FRP 5.41 MW
  - (2026-09-30) [FIRMS] thermal anomaly 44.085, 23.434 (FRP 5.41 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-30 1219Z, FRP 5.41 MW
  - (2026-09-30) [FIRMS] thermal anomaly 44.082, 23.430 (FRP 9.45 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-30 1219Z, FRP 9.45 MW
  - (2026-09-30) [FIRMS] thermal anomaly 44.081, 23.426 (FRP 5.17 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-30 1219Z, FRP 5.17 MW
  - (2026-09-30) [FIRMS] thermal anomaly 44.087, 23.434 (FRP 3.52 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-30 1219Z, FRP 3.52 MW

### Chinese Internal News — 190 new of 274 total
  - (2026-09-29) China’s Central Bank Cuts Policy Lending Rate in Targeted Growth Push - caixinglobal.com
      China’s Central Bank Cuts Policy Lending Rate in Targeted Growth Push caixinglobal.com
  - (2026-09-30) China’s Former Securities Regulator Chief Yi Huiman Charged With Bribery - caixinglobal.com
      China’s Former Securities Regulator Chief Yi Huiman Charged With Bribery caixinglobal.com
  - (2026-09-29) Southeast Asia Can Be More to China Than Just a Buyer, Malaysian Official Says - caixinglobal.com
      Southeast Asia Can Be More to China Than Just a Buyer, Malaysian Official Says caixinglobal.com
  - (2026-09-30) China’s Growing Cultural Tourism Draws Visitors Into the Countryside - caixinglobal.com
      China’s Growing Cultural Tourism Draws Visitors Into the Countryside caixinglobal.com
  - (2026-09-30) Business Brief (Sept. 30): China’s Generative AI Users Top 700 Million - caixinglobal.com
      Business Brief (Sept. 30): China’s Generative AI Users Top 700 Million caixinglobal.com
  - (2026-09-30) China’s Manufacturing Activity Returns to Expansion - caixinglobal.com
      China’s Manufacturing Activity Returns to Expansion caixinglobal.com

### Local News: St. Louis + Atlanta — 182 new of 212 total
  - (2026-10-01) [St. Louis] mindyKNOWS gives college students a local resource when their parents are far away
      Sending a kid hundreds or thousands of miles away to college comes with an uncomfortable parenting reality: Eventually, something is going to go wrong, and you won’t be there to fix it. Maybe it’s relatively minor. They…
  - (2026-10-01) [St. Louis] Where in Clayton 10/1/2026
      Let’s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” onc…
  - (2026-10-01) [St. Louis] Senate Square, Benton Park complex that drew neighbors’ concern, is set for auction
      The troubled Senate Square apartment complex in Benton Park—made up of 30 rowhouses in the northern part of the St. Louis neighborhood—is up for auction next month after its out-of-state owners defaulted on its mortgage.…
  - (2026-10-01) [St. Louis] St. Louis Public Library CEO knows libraries are ‘powerful places,’ now more than ever
      It is one week from today that Waller McGuire begins retirement after 22 years as CEO of the St. Louis Public Library, and McGuire will admit it’s made him a little emotional. The Kentucky native came to St. Louis right…
  - (2026-10-01) [St. Louis] Farmhand Ventures wants to solve agriculture’s big challenges from St. Louis
      The way Connie Bowen sees it, the most enduring and thorny challenge in the world of agriculture is labor. “We’ve yet to figure out how to actually affordably feed the world in a way that doesn’t exploit anyone and in a…
  - (2026-10-01) [St. Louis] Where in the Lou? – 10/1/2026
      Let’s see how well you know St. Louis. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you get. Submit your scores with your name and email to the leaderb…

### U.S. Weather + Severe / Climate Outlooks — 162 new of 163 total
  - (2026-10-01) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-01) [Severe] Flood Warning: Flood Warning issued October 1 at 9:03AM CDT until October 3 at 1:45AM CDT by NWS Kansas City/Pleasant Hill MO
      ...The Flood Warning continues for the following rivers in Missouri... 102 River at Rosendale affecting Andrew and Buchanan Counties. Platte River near Agency affecting Buchanan County. Platte River near Platte City affe…
  - (2026-10-01) [Severe] Flood Warning: Flood Warning issued October 1 at 9:03AM CDT until October 4 at 4:00AM CDT by NWS Kansas City/Pleasant Hill MO
      ...The Flood Warning continues for the following rivers in Missouri... 102 River at Rosendale affecting Andrew and Buchanan Counties. Platte River near Agency affecting Buchanan County. Platte River near Platte City affe…
  - (2026-10-01) [Severe] Flood Warning: Flood Warning issued October 1 at 9:03AM CDT until October 5 at 6:03PM CDT by NWS Kansas City/Pleasant Hill MO
      ...The Flood Warning continues for the following rivers in Missouri... 102 River at Rosendale affecting Andrew and Buchanan Counties. Platte River near Agency affecting Buchanan County. Platte River near Platte City affe…
  - (2026-10-01) [Severe] Flood Warning: Flood Warning issued October 1 at 9:03AM CDT until October 5 at 8:30AM CDT by NWS Kansas City/Pleasant Hill MO
      ...The Flood Warning continues for the following rivers in Missouri... 102 River at Rosendale affecting Andrew and Buchanan Counties. Platte River near Agency affecting Buchanan County. Platte River near Platte City affe…
  - (2026-10-01) [Severe] Flash Flood Warning: Flash Flood Warning issued October 1 at 9:02AM CDT until October 1 at 3:00PM CDT by NWS Kansas City/Pleasant Hill MO
      FFWEAX The National Weather Service in Pleasant Hill has issued a * Flash Flood Warning for... Western Carroll County in north central Missouri... East Central Ray County in west central Missouri... * Until 300 PM CDT. *…

### State Legislative Action — 90 new of 108 total
  - (2026-10-01) [Alaska HJR 39] Urging the federal government to waive the new H-1B Visa fees for teachers in the state.
      Urging the federal government to waive the new H-1B Visa fees for teachers in the state.
  - (2026-10-01) [California SB 947] Employment: automated decision systems.
      Existing law requires the Department of Technology to conduct, in coordination with other interagency bodies as it deems appropriate, a comprehensive inventory of all high-risk automated decision systems (ADS) that have…
  - (2026-10-01) [California AB 1663] Western Joshua Tree Conservation Act: removal: trimming.
      The Western Joshua Tree Conservation Act prohibits any person or public agency from importing into the state, exporting out of the state, or taking, possessing, purchasing, or selling within the state, a western Joshua t…
  - (2026-10-01) [California SB 677] Housing financing: joint powers agreements: bond approvals: subdivisions: tentative and final maps: appeals.
      Existing law, the Joint Exercise of Powers Act, authorizes 2 or more public agencies, by agreement, to form a joint powers authority to exercise any power common to the contracting parties, as specified. Existing law, fo…
  - (2026-10-01) [California SB 1056] Criminal procedure.
      Existing law requires a prosecuting attorney to disclose to the defendant or their attorney all relevant real evidence seized or obtained as a part of the investigation of the offenses charged that is in the possession o…
  - (2026-10-01) [California SB 957] Civil detention facilities.
      Existing law requires the operator of a private detention facility, as defined, to comply with, and adhere to, the detention standards of care and confinement agreed upon in the facility's contract for operations, as spe…

### Ukrainian Internal News (national + local Kyiv) — 63 new of 131 total
  - (2026-10-01) Найбільш задокументована війна: як фото з соцмереж може допомогти притягнути російського злочинця до відповідальності | LEDE: Застосування OSINT допомагає фіксувати понад 260 тисяч воєнних злоч] (uk:…
      Застосування OSINT допомагає фіксувати понад 260 тисяч воєнних злочинів РФ в Україні та підсилює роботу слідства. Як це працює на практиці.
  - (2026-10-01) На Київщині під колесами електропотяга загинув 17-річний хлопець | LEDE: Електропотяг Коростень – Борщагівка наїхав на 17-річного хлопця біля Бучі. Поліція розпочала розслідування порушення пра] (uk:…
      Електропотяг Коростень – Борщагівка наїхав на 17-річного хлопця біля Бучі. Поліція розпочала розслідування порушення правил безпеки.
  - (2026-10-01) Євросоюз і Україна визначили засоби для покриття потреб бюджету й армії у 2026 році | LEDE: Європейська комісія та Україна заявили, що визначили засоби для покриття бюджетних та оборонних потре] (uk:…
      Європейська комісія та Україна заявили, що визначили засоби для покриття бюджетних та оборонних потреб України у 2026 році, а також кроки для своєчасного надання відповідного фінансування.
  - (2026-10-01) "ЄС не потрапить в російську пастку": У Єврокомісії назвали ядерні погрози РФ тактикою залякування | LEDE: У Єврокомісії назвали ядерну риторику Москви безвідповідальною та підтримали позицію Н] (uk:…
      У Єврокомісії назвали ядерну риторику Москви безвідповідальною та підтримали позицію НАТО. ЄС заявив, що не сприятиме поширенню страху.
  - (2026-10-01) Тіні забутих предків. Як Вайдель, Трамп та інші борються з іноземцями попри власні історії | LEDE: ] (uk: Тіні забутих предків. Як Вайдель, Трамп та інші борються з іноземцями попри влас)
  - (2026-10-01) Зінченку дали довічне за вбивство Фаріон | LEDE: Шевченківський райсуд Львова призначив В'ячеславу Зінченку довічне ув'язнення за умисне вбивство громадської діячки Ірини Фаріон.] (uk: Зінченку дали д…
      Шевченківський райсуд Львова призначив В'ячеславу Зінченку довічне ув'язнення за умисне вбивство громадської діячки Ірини Фаріон.

### IT, InfoSys & cybersecurity news (last 7 days) — 42 new of 57 total
  - (2026-10-01) [BleepingComputer] The Day-One Hole in Zero Trust Architecture
      Zero Trust can verify users once they are established, but onboarding creates a gap where organizations must decide who to trust before strong authentication exists. Specops explains why identity verification should begi…
  - (2026-10-01) [BleepingComputer] Kiteworks patches max severity code injection vulnerability
      Secure file-sharing software company Kiteworks has released security updates to address 126 vulnerabilities, including a max-severity flaw affecting its Email Protection Gateway (EPG) security solution. [...]
  - (2026-10-01) [BleepingComputer] Microsoft enables Windows settings backup by default for orgs
      Microsoft announced that Windows settings backup and restore is now enabled by default on all Microsoft Entra-joined or Microsoft Entra hybrid-joined enterprise systems upgraded to Windows 11 26H2. [...]
  - (2026-10-01) [BleepingComputer] Hackers stole Pentagon personnel records of over 3 million people
      The Pentagon's Defense Manpower Data Center (DMDC) is notifying millions of military service members that hackers stole their data after breaching the Pentagon's human resources management system in October 2025. [...]
  - (2026-10-01) [BleepingComputer] Metamask discloses security incident affecting its infrastructure
      On Thursday, cryptocurrency wallet provider MetaMask has disclosed an ongoing infrastructure security incident affecting some of its infrastructure. [...]
  - (2026-10-01) [The Hacker News] How Financial Services Companies Can Modernize Their Software Supply Chain
      Every security leader at a bank, insurer, or asset manager has had a version of this conversation: Security wants to eliminate a class of vulnerabilities. Engineering explains what it would take to upgrade the platform w…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-10-01) [First Seacoast Bancorp, Inc.] Form 4 (Issuer)
      filed 2026-10-01 14:05 UTC · role: Issuer — Filed: 2026-10-01 AccNo: 0001437749-26-031673 Size: 11 KB
  - (2026-10-01) [Boulanger Mark P.] Form 4 (Reporting)
      filed 2026-10-01 14:05 UTC · role: Reporting — Filed: 2026-10-01 AccNo: 0001437749-26-031673 Size: 11 KB
  - (2026-10-01) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-10-01 14:04 UTC — Filed: 2026-10-01 AccNo: 0001839882-26-048542 Size: 825 KB
  - (2026-10-01) 497K - MORGAN STANLEY VARIABLE INSURANCE FUND INC. (0001011378) (Filer)
      filed 2026-10-01 14:04 UTC — Filed: 2026-10-01 AccNo: 0001104659-26-112665 Size: 9 KB
  - (2026-10-01) [Ji Ping] Form 4 (Reporting)
      filed 2026-10-01 14:04 UTC · role: Reporting — Filed: 2026-10-01 AccNo: 0002129331-26-000006 Size: 7 KB
  - (2026-10-01) [Adlai Nortye Group Ltd.] Form 4 (Issuer)
      filed 2026-10-01 14:04 UTC · role: Issuer — Filed: 2026-10-01 AccNo: 0002129331-26-000006 Size: 7 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-10-01) [Argentina] His courage saved untold lives : Former Israeli govt spokesperson Eylon Levy praises Indian pilot Machchhar after Flydubai attack
      domain: argentinastar.com · language: English · tone:
  - (2026-10-01) [United Kingdom] Slowest united kingdom population growth outside pandemic since 1998
      domain: romfordrecorder.co.uk · language: English · tone:
  - (2026-10-01) [United States] Fighting for his life , he managed to unlock cockpit : Netanyahu recalls Capt Machchhar bravery on Flydubai flight
      domain: texasguardian.com · language: English · tone:
  - (2026-10-01) [Kenya] Africa is building its AI future ; who is building it around the citizen ?
      domain: standardmedia.co.ke · language: English · tone:
  - (2026-10-01) [Iran] Netanyahu hails Indian pilot
      domain: iranherald.com · language: English · tone:
  - (2026-10-01) [Israel] Netanyahu hails Israeli hero as flydubai passengers return home safely
      domain: clevelandjewishnews.com · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### U.S. Federal Action — 29 new of 29 total
  - (2026-10-01) [WC Docket Nos. 25-208, 25-209; FCC 26-19; FR ID 370342] Reducing Barriers to Network Improvements and Service Changes, Accelerating Network Modernization
      In this document, the Wireline Competition Bureau (Bureau) announces that the Office of Management and Budget (OMB) has approved the information collection associated with the Commission's revised network change disclosu…
  - (2026-10-01) Administration of Cross-State Air Pollution Rule Trading Program Assurance Provisions for 2025 Control Period
      The U.S. Environmental Protection Agency (EPA) is providing notice of the availability of data on the administration of the assurance provisions of the Cross-State Air Pollution Rule (CSAPR) trading program for the 2025…
  - (2026-10-01) Unleashing American Energy and Economic Prosperity; Rural Energy for America Program (REAP)
      The Rural Business-Cooperative Service (RBCS or the Agency), an agency of the Rural Development (RD) mission area within the U.S. Department of Agriculture (USDA) is issuing a final rule with comment period. Implementati…
  - (2026-10-01) Fisheries of the Exclusive Economic Zone Off Alaska; Exchange of Flatfish in the Bering Sea and Aleutian Islands Management Area
      NMFS is exchanging unused yellowfin sole and flathead sole Community Development Quota (CDQ) for rock sole CDQ acceptable biological catch (ABC) reserves in the Bering Sea and Aleutian Islands (BSAI) management area. Thi…
  - (2026-10-01) Petition for Rulemaking; Notification of Petition for Rulemaking; Invalid Specimen Determinations
      This document announces receipt of a petition for rulemaking received by DOT on February 27, 2026, to initiate a rulemaking to amend 49 CFR part 40. The petitioner's proposed amendments seek to incorporate structured med…
  - (2026-10-01) Rule on Impersonation of Government and Businesses
      The Federal Trade Commission ("FTC" or "Commission") proposes to commence a rulemaking proceeding to prevent certain unfair or deceptive acts or practices by search engine, social media, and other digital marketplace pla…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-10-01) GAF623 (Germany)
      icao24: 3f6533 · position: (51.5603, 10.0574) · alt: 7315m · 816km/h
  - (2026-10-01) PAT776 (United States)
      icao24: adfede · position: (30.5472, -89.3899) · alt: 3337m · 466km/h
  - (2026-10-01) GAF261 (Germany)
      icao24: 3ea653 · position: (39.9078, -4.3895) · alt: 10355m · 799km/h
  - (2026-10-01) GAF390 (Germany)
      icao24: 3f505f · position: (47.191, 9.4588) · alt: 1318m · 220km/h
  - (2026-10-01) JEDI18 (United States)
      icao24: ae1ea9 · position: (30.2646, -87.7981) · alt: 1059m · 427km/h
  - (2026-10-01) JEDI07 (United States)
      icao24: ae1eab · position: (30.2253, -87.9638) · alt: 144m · 418km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 25 new of 117 total
  - (2026-09-30) [OFAC] Counter Terrorism and Transnational Criminal Organizations Designations; Belarus, Counter Narcotics, and Libya Designations Removals - Office of Foreign Assets Control (.gov)
      Counter Terrorism and Transnational Criminal Organizations Designations; Belarus, Counter Narcotics, and Libya Designations Removals Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 560 Iranian Transactions and Sancti - Office of Foreign Assets Control (.gov)
      BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 560 Iranian Transactions and Sancti Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] Federal Register/Vol. 91, No. 188/Wednesday, September 30, 2026/Rules and Regulations - Office of Foreign Assets Control (.gov)
      Federal Register/Vol. 91, No. 188/Wednesday, September 30, 2026/Rules and Regulations Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] 1273 - Office of Foreign Assets Control (.gov)
      1273 Office of Foreign Assets Control (.gov)
  - (2026-09-29) [OFAC] 1271 - Office of Foreign Assets Control (.gov)
      1271 Office of Foreign Assets Control (.gov)
  - (2026-10-01) [USASpending] $43,460,682,795 → NATIONAL TECHNOLOGY & ENGINEERING SOLUTIONS OF SANDIA, LLC: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL
      Agency: Department of Energy. Description: IGF::CL,CT::IGF CONTRACT AWARD DE-NA0003525 TO THE NATIONAL TECHNOLOGY&ENGINEERING SOLUTIONS OF SANDIA, LLC (NTESS) FOR THE MANAGEMENT AND OPERATION OF THE DEPARTMENT OF ENERGY,…

### Court opinions of consequence (federal & state) — 17 new of 60 total
  - (2026-09-30) U.S. Court of Appeals, 11th Cir.: Nicholas Tate v. Warden GDCP
  - (2026-09-30) U.S. Court of Appeals, 9th Cir.: Americans for Prosperity v. Meyer
  - (2026-09-30) U.S. Court of Appeals, 9th Cir.: Baker Ranches, Inc. v. Burgum
  - (2026-09-30) U.S. Court of Appeals, Federal Cir.: Teva Pharmaceuticals International Gmbh v. Eli Lilly and Company
  - (2026-09-30) U.S. Court of Appeals, Federal Cir.: Epic Tech, LLC v. Pen-Tech Associates, Inc.
  - (2026-09-30) U.S. Court of Appeals, Federal Cir.: Parkervision, Inc. v. Qualcomm Incorporated

### Paper Trading Scorecard — 16 new of 127 total
  - (2026-10-01) [Manifold] U.S. 10 Year TIPS yield exceeds 4% before 2028?
  - (2026-10-01) [Manifold] Will Marius Binner Win the ARC White-Box Estimation Challenge 2026
  - (2026-10-01) [Manifold] OpenAI completes an IPO in 2027 and has a market cap of $1.5trillion+?
  - (2026-10-01) [Manifold] Will 30-year treasury yields go above 7% at any point before 2028?
  - (2026-10-01) [Manifold] Will Qwen be the top small open model (4B-40B) on the Artificial Analysis Intelligence Index at the end of 2026?
  - (2026-10-01) [Manifold] Will a new Claude Haiku model be released in October 2026?

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-10-01) Dota 2: Team Yandex vs BetBoom Team - Game 1 Winner
      yes price: 100% · 24h volume: $606,976 · resolves 2026-10-01
  - (2026-10-01) Steelers vs. Browns
      yes price: 57% · 24h volume: $516,639 · resolves 2026-10-02
  - (2026-10-01) Map Handicap: NS (-1.5) vs XLG Gaming (+1.5)
      yes price: 38% · 24h volume: $508,586 · resolves 2026-10-01
  - (2026-10-01) Valorant: XLG Gaming vs Nongshim RedForce (BO3) - VCT Champions Group D
      yes price: 18% · 24h volume: $506,021 · resolves 2026-10-01
  - (2026-10-01) Will Norway win on 2026-10-01?
      yes price: 70% · 24h volume: $429,187 · resolves 2026-10-01
  - (2026-10-01) Will Geraldo Alckmin win the 2026 Brazilian presidential election?
      yes price: 0% · 24h volume: $374,893 · resolves 2026-10-05

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-09-30) M 5.6 - 94 km SW of Tamarindo, Costa Rica
      M5.6 · 94 km SW of Tamarindo, Costa Rica · depth 8 km
  - (2026-10-01) M 5.3 - 0 km NNE of Yōkaichiba, Japan
      M5.3 · 0 km NNE of Yōkaichiba, Japan · depth 41.649 km
  - (2026-10-01) M 5.2 - 7 km ESE of Baghlān, Afghanistan
      M5.2 · 7 km ESE of Baghlān, Afghanistan · depth 49.602 km
  - (2026-10-01) M 5.0 - 38 km WSW of Palimbang, Philippines
      M5.0 · 38 km WSW of Palimbang, Philippines · depth 10 km
  - (2026-09-30) M 5.0 - 142 km SE of Petropavlovsk-Kamchatsky, Russia
      M5.0 · 142 km SE of Petropavlovsk-Kamchatsky, Russia · depth 35 km
  - (2026-10-01) M 4.9 - 145 km ESE of Neiafu, Tonga
      M4.9 · 145 km ESE of Neiafu, Tonga · depth 10 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-10-01) [Ukraine] Almost three - quarters of Ukrainians favor peace talks with Russia , but even larger majority opposes concessions on Armed Forces – poll
      en.interfax.com.ua · English
  - (2026-10-01) [Ukraine] Ukrainian Red Cross Society volunteers hone mountain search and rescue skills
      en.interfax.com.ua · English
  - (2026-10-01) [Ukraine] Beskrestnov : detonator found on Russian Geran UAV is mechanical , contains no complex sensors
      en.interfax.com.ua · English
  - (2026-10-01) [Ukraine] Zelenskyy orders review of agreements on F - 16 ammunition , air defense missile supplies
      en.interfax.com.ua · English
  - (2026-10-01) [Ukraine] Ukraine - Türkiye free trade agreement takes effect
      en.interfax.com.ua · English
  - (2026-10-01) [Ukraine] Strike on Kyiv Nuclear Institute another Russian war crime – regulator
      en.interfax.com.ua · English

### Campaign finance (FEC: top fundraisers + recent filings) — 3 new of 27 total
  - () [F3] JOEL BALAM FOR CONGRESS COMMITTEE
      cycle 2012 · filing #783936 · receipts $0.00M
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-01) [Marginal Revolution] The top private sector employers of economics graduates
      Here is the link. The post The top private sector employers of economics graduates appeared first on Marginal REVOLUTION.
  - (2026-10-01) [Marginal Revolution] Merging LLMs and economics research
      We introduce an open-source workflow that enables an LLM to reproduce, improve, and extend an economics article using the article’s published replication package. First, the workflow attempts to reproduce the original ca…
  - (2026-09-30) [Marginal Revolution] The polity that is Singapore
      Police in Singapore have charged a man who is accused of posting an AI-generated image of a saltwater crocodile in a popular reservoir. Ye Lin was charged with communicating a false message and obstructing the course of…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 17 total
  - (2026-09-30) CVE-2026-76504 · Cisco Catalyst SD-WAN Manager: Cisco Catalyst SD-WAN Manager Hex Encoding Vulnerability
      vendor: Cisco · product: Catalyst SD-WAN Manager · CISA remediation by 2026-10-03

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-01) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=29, 7d-median=18, 14d-median=18; carrying terms: certain, program, action, proposed, final, state, proposes, procedures, provisions, regulatory, national, document
- state_bills: today=108, 7d-median=108, 14d-median=106; carrying terms: emergency, actions, duties, authority, provisions, registration, defined, projects, services, government, resources, resolution
- state_news: today=833, 7d-median=604, 14d-median=683; carrying terms: subscribe, today, challenging, river, opener, three, white, monday, working, nearly, allow, changes
- local_news: today=212, 7d-median=227, 14d-median=231; carrying terms: three, tuesday, atlanta, still, district, magazine, student, atlantamagazine, killed, county, following, according
- foreign_news: today=1046, 7d-median=1018, 14d-median=1019; carrying terms: today, rescue, scheme, finals, revenue, victory, emergency, beijing, brazilian, inenglish, cbspeeches, three
- chinese_internal: today=274, 7d-median=274, 14d-median=274; carrying terms: cbmibefvx, lxtfb, cbmia, cbmidefvx, cbmib, caixin, lxtfa, cbmigwfbvv, cbmiw, cbmix, color, people
- russian_internal: today=1049, 7d-median=1011, 14d-median=1029; carrying terms: forbidden, politico, street, https, novaya, istories, laquo, httperror, error, client, financial, openai
- ukrainian_internal: today=131, 7d-median=129, 14d-median=131; carrying terms: forbidden, ukrinform, three, launch, signed, border, drone, drones, military, later, httperror, client
- ukraine_theater: today=670, 7d-median=442, 14d-median=442; carrying terms: today, damage, mlrfm, extra, wxpetxjrsdayykzqtthpvlzyn, baghdad, posts, syrian, august, uzuptz, cbmif, oskxnounky
- paper_bets: today=127, 7d-median=120, 14d-median=125; carrying terms: break, hampshire, nebraska, general, georgia, chase, starts, presidential, prize, house, growth, kylian
- weather: today=163, 7d-median=144, 14d-median=127; carrying terms: today, thunderstorms, damage, afdhgx, advisory, river, service, watch, peachtree, located, monday, pontiac
- macro: today=20, 7d-median=21, 14d-median=21; carrying terms: dexuseu, labor, spread, treasury, dcoilwtico, implied, total, assets, jtsjol, payrolls, effective, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, nasdaq, commodities, credit, proxy, range, futures, treasury, natural, china, silver, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=117, 7d-median=104, 14d-median=104; carrying terms: mediterranean, mufswgh, herzegovina, concerning, extra, enable, rkiye, events, annexation, actions, paeez, ujgxrwtvbs
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, error, httperror, client, quiver, quantitative, quiverquant, https, congresstrading
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: corporation, appeals, court, supreme, state, connecticut, international, trade, arizona, bryant, delaware, company
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, issuer, filed, filer, trust, financial, group, finance, america, michael, chase
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: ocasio, alexandria, sherrod, james, filing, brown, cooper, committee, receipts, raised, graham, trone
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=0, 7d-median=52, 14d-median=50; carrying terms: english, sanctions, trump, themes, spanish, perimeter, chinese, russian, russia, german, ukrainian, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0; carrying terms: trump, india, state, domain, kingdom, iheart, language, english, philippines, security, election, years
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, ground, france, germany, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: bundibugyo, global, previous, intensive, workers, autochthonous, coinci, influenza, sequencing, geographic, infant, centers
- cisa_kev: today=17, 7d-median=18, 14d-median=19; carrying terms: vulnerability, bounds, buffer, vendor, based, write, improper, injection, overflow, product, products, cisco
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=14, 7d-median=17, 14d-median=15; carrying terms: indonesia, depth, japan, tonga, russia, philippines, atlantic, ridge
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, price, resolves, donetsk, champions, championship, shakhtar, league, group, october, rates, interest
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, basic, revolution, marginal, conversable, conversableeconomist, https, economist, wealth, economics, think, published
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: today, critical, spectrum, using, government, edition, hacker, newsletter, technica, artificial, going, weekly
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: rogers, commission, stauber, ambassador, weber, lutnick, fuller, langworthy, jason, fletcher, panetta, frederica
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, placed, market, sufficient, consensus, identify, placement, unavailable, paper, converges, claude, either

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-23] Fed speeches: Barr, A Long-Term View on the Costs of Shelter
- [2026-09-24] ECB press: Philip R. Lane: The outlook for the euro area economy
- [2026-09-24] ECB press: ECB Executive Board member Isabel Schnabel to resign to take senior role at IMF
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Sandy Spring Bank
- [2026-09-24] Fed press (events + announcements): Federal Reserve Board requests public comment on two proposals related to establishing a regulatory framework for Board-supervised payment stablecoin issuers under the GENIUS Act
- [2026-09-25] Fed press (events + announcements): Federal Reserve Board announces approval of application by Peoples Bancorp Inc.
- [2026-09-28] ECB press: Christine Lagarde: Hearing of the Committee on Economic and Monetary Affairs of the European Parliament
- [2026-09-28] Fed speeches: Cook, An Update on AI and the Economy
- [2026-09-29] ECB press: ECB amends monetary policy implementation guidelines as part of regular review
- [2026-09-29] Fed speeches: Bowman, Opening Remarks
- [2026-09-29] Fed speeches: Barr, Economic Conditions and Monetary Policy
- [2026-09-29] Fed speeches: Waller, Payments in the Age of AI Agents
- [2026-09-29] Fed press (events + announcements): Agencies publish resolution plan feedback letters for 15 banking organizations
- [2026-09-30] ECB press: Frank Elderson: Supervisory risk appetite, efficiency and effectiveness

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*