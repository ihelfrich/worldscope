# WORLDSCOPE morning brief — 2026-09-23

## Headline
3463 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (842) · Russian Internal News (state + in-exile) (721) · State-Level News (372) · World leaders & government officials (324) · Chinese Internal News (216) · Ukraine Theater (total-war monitoring) (188) · Local News: St. Louis + Atlanta (179) · U.S. Weather + Severe / Climate Outlooks (145) · State Legislative Action (93) · GDELT GKG — themes / entities / watch areas (70) · Ukrainian Internal News (national + local Kyiv) (66) · IT, InfoSys & cybersecurity news (last 7 days) (44)

## What changed today
### International News + Multilateral Institutions — 842 new of 1046 total
  - (2026-09-23) [India] Brics tax talks significant as global rules are renegotiated: Nirmala Sitharaman
  - (2026-09-23) [India] SC reserves order on Noida DM’s plea over ₹5 lakh compensation in NSA case
  - (2026-09-23) [India] PM's principal secretary PK Mishra inaugurates SBI conclave, outlines India's growth path
  - (2026-09-23) [India] BJP names state in-charges: Vinod Tawde gets UP, Smriti Irani given Haryana, Chhattisgarh
  - (2026-09-23) [India] IIT Bombay’s 10-member committee begins probe into student’s death
  - (2026-09-23) [India] Manipur violence: Electric lineman shot dead, 24 houses set ablaze

### Russian Internal News (state + in-exile) — 721 new of 1120 total
  - (2026-09-23) Война. 1673-й день. Трамп и Зеленский встретились в Нью-Йорке. После переговоров президент Украины сказал, что войну желательно закончить до зимы | LEDE: «Медуза» с 24 февраля 2022 года в пр] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-23) Сеть магазинов Leroy Merlin, переданную Путиным во временное управление, возглавил сын бывшего депутата-единоросса. У его отца изъяли активы на 18 миллиардов рублей | LEDE: Во всех четырех и] (ru: Сет…
      Во всех четырех иностранных компаниях, которые Владимир Путин своим указом передал во временное управление, сменилось руководство.
  - (2026-09-23) «Это Кирилл. Я был в тюрьме». Владелец фан-аккаунта Леди Гаги на полмиллиона подписчиков рассказал, почему не вел его два года | LEDE: Владелец фан-аккаунта Леди Гаги в соцсети X рассказал, ] (ru: «Эт…
      Владелец фан-аккаунта Леди Гаги в соцсети X рассказал, что его не было онлайн два года, потому что в начале 2024-го его арестовали «за протест против правительства» и приговорили к двум годам лишения свободы.
  - (2026-09-23) Телеграм-каналы утверждают, что рэпер Джиган несколько месяцев назад устроил стрельбу по персоналу в своем доме. Он это отрицает | LEDE: Телеграм-каналы Mash и Shot, а также Ксения Собчак ут] (ru: Тел…
      Телеграм-каналы Mash и Shot, а также Ксения Собчак утверждают, что рэпер Джиган (настоящее имя — Денис Устименко) в ночь на 4 июля открыл стрельбу по сотрудникам, работавшим в его доме в Московской области.
  - (2026-09-23) Росфинмониторинг предложил блокировать счета клиентов банков, если их данные совпадают с данными из реестра террористов и экстремистов | LEDE: Росфинмониторинг предлагает расширить основания] (ru: Рос…
      Росфинмониторинг предлагает расширить основания для блокировки банковских счетов: банки смогут останавливать операции, если данные клиента частично совпадают с данными человека, чьи средства подлежат заморозке.
  - (2026-09-23) «Marvel: Росомаха» — игра, которую всю неделю критикуют за то, что она слишком легкая (и за «повесточку»). Разбираемся, насколько состоятельны претензии | LEDE: 15 сентября Sony выпустила св] (ru: «Ma…
      15 сентября Sony выпустила свой главный эксклюзив осени — «Marvel: Росомаха» об одном из героев «Людей Икс». Сразу же после выхода соцсети заполонили видео, доказывающие, что игра не стоит своих денег. Критики обсуждали…

### State-Level News — 372 new of 754 total
  - (2026-09-23) [California] How do you get a housing permit in California? He can hook you up, for a fee
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/092126_Permit-Expeditors_AH_CM_03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-09-23) [California] Deal allowing Paramount-Warner Bros. merger may not cure Hollywood’s troubles
      <img width="1024" height="681" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/092026-Merger-Protest-PU-CM-05.jpg?fit=1024%2C681&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-09-23) [California] Insurers say they’re starting to write new California homeowner policies, but how many?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/092624_DRONE-Caldor-Fire-Lake-Tahoe_MG_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size…
  - (2026-09-23) [California] Charter school accused of misspending millions is seeking to open under new name
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/092126-Highlands-Charter-MG-CM-03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-09-23) [California] Yosemite land giveaway shows no place is safe from Trump’s assault on public lands
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/10/070723-Yosemite-National-Park-MG-CM-18.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…
  - (2026-09-22) [California] He said his election might have been stolen. Then the FBI came
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/091726_Clint_Curtis_SO_CM_03.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" a…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 216 new of 280 total
  - (2026-09-22) 本周，DeepSeek将向安理会通报 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTFA5V19laXkzUlYtdGM3d1F5QmZuenZ3a1ZMTU5PSmQ5ajh2SUpRTG9fcmNFcXAyLTFza0lrMGRwbmVVMnJmbjNYN2NDd3c2VEZyb] (zh:…
      本周，DeepSeek将向安理会通报 观察者网
  - (2026-09-21) 汉冶萍兴亡史 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE50dGl1eTlFRlE2LUJrVEUxemNtNFNyN0NrRkpFa1FVWmVLT0NyZ1N2RTFRczBVOFdpZUs2VmFHT2hLc29tMVlKeWhNMkF0dnFWOFUtVlhzbDRidw?] (zh:…
      汉冶萍兴亡史 风闻
  - (2026-09-23) 经费停拨，美军对华智库CASI将正式关闭 - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTFBYN2NNN2NnMVBaaFBnSnBGSExEYWloM3V2U3RaS1NJc0dvZ2NSSHhSMFFyc1hManh2OERDaF9UZWZ0VWl5d1FUV2hVT2xYb1V] (zh:…
      经费停拨，美军对华智库CASI将正式关闭 观察者网
  - (2026-09-23) 西贝的倒闭是大家都想看见的，不仅是顾客，也包括同行 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE9IU0RNeWdCVGxDdF9ZQ09VaWpsWnAyQ1FtMEVuR1hyc3llREQ3VU1GcVNtUHpnUS1XdWZFZDE5N2xwR05DSlVsNndaenhm] (zh:…
      西贝的倒闭是大家都想看见的，不仅是顾客，也包括同行 风闻
  - (2026-09-23) 反转了，闲鱼不涉黄！ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1nZDRtRGlFOVVQZ1pMUHJia191UTUxWC1vNUVDLVFGQW1JRWQxREF6bEZUQ3paeXdLWFdsUmVrRE5QZ2R5aDJlWC1fZDFCQmhDMTVqaE9BbEs] (zh:…
      反转了，闲鱼不涉黄！ 风闻
  - (2026-09-23) 美企中标中国移动千万信创项目，怎么回事？ - 观察者网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9TLXJxOGg1SnloZmlPd1MtUEc2d0h0YlQtLXY1QmZmcU1CdTd5YUtxZUVtRXQ3SHpER3NJRkpjNUFBSTJzT0xPaVZkMWRfVEw] (zh:…
      美企中标中国移动千万信创项目，怎么回事？ 观察者网

### Ukraine Theater (total-war monitoring) — 188 new of 427 total
  - (2026-09-23) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-22) [FIRMS] thermal anomaly 45.864, 29.549 (FRP 4.12 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-22 0949Z, FRP 4.12 MW
  - (2026-09-22) [FIRMS] thermal anomaly 46.505, 30.629 (FRP 54.34 MW, conf high)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-22 0949Z, FRP 54.34 MW
  - (2026-09-22) [FIRMS] thermal anomaly 44.136, 24.070 (FRP 6.53 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-22 1128Z, FRP 6.53 MW
  - (2026-09-22) [FIRMS] thermal anomaly 44.415, 22.172 (FRP 12.28 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-22 1128Z, FRP 12.28 MW
  - (2026-09-22) [FIRMS] thermal anomaly 44.419, 22.171 (FRP 9.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-22 1128Z, FRP 9.85 MW

### Local News: St. Louis + Atlanta — 179 new of 207 total
  - (2026-09-23) [St. Louis] St. Louis parking tickets are thrown out over Treasurer’s Office coding error
      If you have an unpaid parking ticket from the City of St. Louis, take a close look before you pay. You might not have to. Especially if the ticket you got was for parking “contrary to sign.” For years the parking enforce…
  - (2026-09-23) [St. Louis] Ask Veronica: What is a coverlet?
      An upcoming exhibit at Saint Louis Art Museum featuring a selection of 19th-century quilts and coverlets has me thinking about bedding and coverlets in particular. What exactly is a coverlet? Is a coverlet the same thing…
  - (2026-09-23) [St. Louis] A home in Chesterfield hits the market
      Architectural SplendorIn 1974, St. Louis architect Tom Hall designed and built this house as his personal residence. Light-Filled SpaceThis one-of-a-kind property, featuring walls of windows and a series of skylights, ha…
  - (2026-09-23) [St. Louis] St. Louis notches daily London flights next summer as the region marks its growing global connectivity
      A recent bright spot for the St. Louis business landscape is the growing number of direct international flights in and out of Lambert International Airport, with Lufthansa having added capacity since adding a route to Fr…
  - (2026-09-23) [St. Louis] Tim Ream’s USMNT legacy to take center stage in St. Louis
      St. Louis native Tim Ream, this summer’s U.S. Men’s National Team captain, was conspicuously absent from manager Mauricio Pochettino’s first post-World Cup roster ahead of a four-match slate of friendlies, including the…
  - (2026-09-22) [St. Louis] Where to find grief support in St. Louis
      Loss is a natural part of life, and as much as we try to avoid it, almost everyone experiences grief at some point. Working through this painful emotion can be easier with support, and St. Louisans are fortunate to have…

### U.S. Weather + Severe / Climate Outlooks — 145 new of 146 total
  - (2026-09-23) [Moderate] Wind Advisory: Wind Advisory issued September 23 at 8:29AM EDT until September 25 at 2:00AM EDT by NWS Newport/Morehead City NC
      * WHAT...Northeast winds 25 to 30 mph with gusts up to 40 to 50 mph expected. * WHERE...East Carteret and Mainland Dare Counties, and Hatteras Island, Northern Outer Banks, and Ocracoke Island. * WHEN...From 2 PM this af…
  - (2026-09-23) [Moderate] Gale Warning: Gale Warning issued September 23 at 4:27AM AKDT until September 24 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-23) [Severe] Storm Warning: Storm Warning issued September 23 at 4:27AM AKDT until September 24 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-23) [Moderate] Gale Warning: Gale Warning issued September 23 at 4:27AM AKDT until September 24 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-23) [Moderate] Gale Warning: Gale Warning issued September 23 at 4:27AM AKDT until September 24 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…
  - (2026-09-23) [Moderate] Gale Warning: Gale Warning issued September 23 at 4:27AM AKDT until September 24 at 5:00PM AKDT by NWS Anchorage AK
      Coastal Waters Forecast for Southwest Alaska+Bristol Bay+The Alaska Peninsula Waters and the Aleutian Islands up to 100 nm out. Wind forecasts reflect the predominant speed and direction expected. Sea forecasts represent…

### State Legislative Action — 93 new of 120 total
  - (2026-09-23) [Alaska HJR 46] Recognizing the sovereign decisions of the communities of Kipnuk and Kwigillingok to relocate in the wake of the devastation caused by Typhoon Halong; affirming the right of Alaska Nat…
      Recognizing the sovereign decisions of the communities of Kipnuk and Kwigillingok to relocate in the wake of the devastation caused by Typhoon Halong; affirming the right of Alaska Native communities to self-determinatio…
  - (2026-09-23) [Alaska HB 214] An Act relating to transportation network companies and delivery network companies; relating to proof of financial responsibility for suspension for nonpayment of judgments; relating t…
      An Act relating to transportation network companies and delivery network companies; relating to proof of financial responsibility for suspension for nonpayment of judgments; relating to insurance coverage for transportat…
  - (2026-09-23) [Alaska HB 152] An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on indiv…
      An Act establishing an education tax on the income of individuals, partners, shareholders in S corporations, trusts, and estates; repealing tax credits applied against the tax on individuals under the Alaska Net Income T…
  - (2026-09-23) [Alaska HB 189] An Act relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or dismissed; and relating to the calculation of the value of the permanent…
      An Act relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or dismissed; and relating to the calculation of the value of the permanent fund dividend by including payment t…
  - (2026-09-23) [Alaska HB 295] An Act relating to allowable absences for eligibility for a permanent fund dividend; and providing for an effective date.
      An Act relating to allowable absences for eligibility for a permanent fund dividend; and providing for an effective date.
  - (2026-09-23) [Alaska SCR 10] Suspending Rules 24(c), 35, 41(b), and 42(e), Uniform Rules of the Alaska State Legislature, concerning House Bill No. 36, relating to the placement of foster children in psychiatric h…
      Suspending Rules 24(c), 35, 41(b), and 42(e), Uniform Rules of the Alaska State Legislature, concerning House Bill No. 36, relating to the placement of foster children in psychiatric hospitals; relating to the care of ch…

### GDELT GKG — themes / entities / watch areas — 70 new of 70 total
  - (2026-09-23) [Russia oil sanctions perimeter · themes] В Хакасии за ночь убили трех медведей в результате выхода животных к городу Абаза
      gorod48.ru · Russian · tone NA
  - (2026-09-23) [Russia oil sanctions perimeter · themes] I spoke to the man suspected of burying the body of missing toddler Ben Needham with a JCB ... he laughed in my face , writes TOM PARRY
      dailymail.com · English · tone NA
  - (2026-09-23) [Russia oil sanctions perimeter · themes] Nerviraju vas NEPRIJATNI MIRISI U ORAMARU ? Ova TRI TRIKA ih brišu kao gumicom !
      prva.rs · Serbian · tone NA
  - (2026-09-23) [Russia oil sanctions perimeter · themes] 想走得更稳更远 ， 出海反而要 轻 一点 ？
      yicai.com · Chinese · tone NA
  - (2026-09-23) [Russia oil sanctions perimeter · themes] The aggro rocker Anderson who never faded to black
      nynganobserver.com.au · English · tone NA
  - (2026-09-23) [Russia oil sanctions perimeter · themes] Exercise of Share Options & Total Voting Rights | Company Announcement
      investegate.co.uk · English · tone NA

### Ukrainian Internal News (national + local Kyiv) — 66 new of 134 total
  - (2026-09-23) Окупанти вранці вдарили по Олександрівці: загинули 4 людини, під завалами можуть бути ще 8 | LEDE: Росія атакувала Олександрівку на Донеччині. Чотири загиблих, чотири поранених, зруйновано житл] (uk:…
      Росія атакувала Олександрівку на Донеччині. Чотири загиблих, чотири поранених, зруйновано житло, під завалами можуть бути ще 8 людей.
  - (2026-09-23) Підкидання наркотиків екскомбату "Маґури": затримали "ведмежатника", який допоміг підозрюваним військовим | LEDE: Повідомили про підозру ще одному фігуранту справи, причетному до підкидання нар] (uk:…
      Повідомили про підозру ще одному фігуранту справи, причетному до підкидання наркотиків колишньому командиру батальйону 47-ї окремої механізованої бригади "Магура" Олександру Ширшину.
  - (2026-09-23) Захист адвокатів як потенційний ризик: чому Люксембурзька конвенція може зашкодити шляху до ЄС | LEDE: ] (uk: Захист адвокатів як потенційний ризик: чому Люксембурзька конвенція може зашкоди)
  - (2026-09-23) Зеленський: Росія за рік захопила 890 км і втратила 270 тис. людей, Україна звільнила - 800 км | LEDE: У 2026 Росія окупувала 890 км території України, ЗСУ звільнили 800 км. Зеленський повідоми] (uk:…
      У 2026 Росія окупувала 890 км території України, ЗСУ звільнили 800 км. Зеленський повідомив про 270 тисяч загиблих росіян – подробиці інтерв'ю WSJ.
  - (2026-09-23) У Німеччині припускають, що виявлений біля авіабази дрон ніс вибухівку | LEDE: Німецькі слідчі підозрюють, що виявлений поблизу військової бази Бундесверу на півночі країни дрон міг нести вибух] (uk:…
      Німецькі слідчі підозрюють, що виявлений поблизу військової бази Бундесверу на півночі країни дрон міг нести вибухівку.
  - (2026-09-23) Прем’єр Латвії заявив, що вони єдині в ЄС виступали проти зняття санкцій з Усманова і Фрідмана | LEDE: Прем'єр Латвії Кулбергс заявив, що його країна була проти скасування санкцій для російськи] (uk:…
      Прем'єр Латвії Кулбергс заявив, що його країна була проти скасування санкцій для російських олігархів, тоді як інші держави ЄС погодилися.

### IT, InfoSys & cybersecurity news (last 7 days) — 44 new of 57 total
  - (2026-09-23) [BleepingComputer] Arista patches actively exploited VeloCloud Orchestrator zero-day
      Arista Networks has released security patches for a zero-day flaw that is being actively exploited and affects VeloCloud Orchestrator (VCO) On-Prem deployments. [...]
  - (2026-09-23) [BleepingComputer] Microsoft: September Windows updates break Always On VPN connections
      Microsoft warned that the September 2026 security updates may also break Always On VPN connections on some Windows 11 systems. [...]
  - (2026-09-23) [BleepingComputer] Ryuk ransomware member sentenced to 24 months in prison
      An Armenian man was sentenced to 24 months in prison and 3 years of supervised release for hacking U.S. companies and encrypting their systems in Ryuk ransomware attacks. [...]
  - (2026-09-23) [BleepingComputer] F5 patches BIG-IP APM zero-day flaw exploited in RCE attacks
      F5 has released security updates to address a critical BIG-IP APM zero-day vulnerability being exploited in remote code execution attacks. [...]
  - (2026-09-23) [The Hacker News] New cPanel Flaw Lets a Hosting Account Run Code as Root, Take Full Server Control
      A flaw in cPanel's CalDAV and CardDAV service lets anyone with a cPanel hosting account run code as root and take "full control of the server," the company said on September 22. A second bug in the WP Toolkit plugin, use…
  - (2026-09-23) [The Hacker News] 545 Hackers Tested It First. Now XRanges for AI Scores Your Security Agent
      Autonomous security agents are getting good at finding bugs. Nobody has a good way to measure how good. Point one at a realistic target and what comes back is a report the agent wrote about itself: confident prose, a lis…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-23) 485BXT - Tidal Trust V (0002081107) (Filer)
      filed 2026-09-23 12:29 UTC — Filed: 2026-09-23 AccNo: 0001999371-26-021093 Size: 23 KB
  - (2026-09-23) 485BXT - Tidal Trust V (0002081107) (Filer)
      filed 2026-09-23 12:29 UTC — Filed: 2026-09-23 AccNo: 0001999371-26-021093 Size: 23 KB
  - (2026-09-23) [On Holding AG] Form 4 (Issuer)
      filed 2026-09-23 12:28 UTC · role: Issuer — Filed: 2026-09-23 AccNo: 0001670477-26-000011 Size: 4 KB
  - (2026-09-23) [Miele Laura] Form 4 (Reporting)
      filed 2026-09-23 12:28 UTC · role: Reporting — Filed: 2026-09-23 AccNo: 0001670477-26-000011 Size: 4 KB
  - (2026-09-23) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-09-23 12:28 UTC — Filed: 2026-09-23 AccNo: 0001213900-26-102380 Size: 22 KB
  - (2026-09-23) 485BXT - Investment Managers Series Trust II (0001587982) (Filer)
      filed 2026-09-23 12:28 UTC — Filed: 2026-09-23 AccNo: 0001213900-26-102380 Size: 22 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-09-23) JAF50T (Bulgaria)
      icao24: 4520ce · position: (34.9863, -5.9033) · alt: 6606m · 799km/h
  - (2026-09-23) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (36.4666, -4.4299) · alt: 11887m · 844km/h
  - (2026-09-23) PAT936 (United States)
      icao24: adfe47 · position: (39.6344, -75.5047) · alt: 1432m · 309km/h
  - (2026-09-23) GAF134 (Germany)
      icao24: 3f7588 · position: (43.52, -1.7372) · alt: 10355m · 758km/h
  - (2026-09-23) PUMA78 (Slovenia)
      icao24: 506e18 · position: (45.9086, 15.4916) · alt: 304m · 159km/h
  - (2026-09-23) PUMA73 (Slovenia)
      icao24: 506e1d · position: (45.9408, 15.4305) · alt: 975m · 175km/h

### Court opinions of consequence (federal & state) — 20 new of 60 total
  - (2026-09-22) U.S. Court of Appeals, D.C. Cir.: Office of the Commissioner of Baseball v. LOC
  - (2026-09-22) U.S. Court of Appeals, D.C. Cir.: Patrick Mahoney v. United States Capitol Police Board
  - (2026-09-22) U.S. Court of Appeals, Federal Cir.: Oguntade v. MSPB
  - (2026-09-22) U.S. Court of Appeals, 11th Cir.: Chanda Callaway v. Mason Adcock
  - (2026-09-22) U.S. Court of Appeals, 5th Cir.: Marshall v. Guerrero
  - (2026-09-21) U.S. Court of Appeals, 8th Cir.: Congressman Robert Onder v. Richard von Glahn

### U.S. Federal Action — 18 new of 20 total
  - (2026-09-23) Enhancing Program Integrity and Interagency Coordination in the Administration of the H-1B Nonimmigrant Visa Program
  - (2026-09-23) Restriction on Entry of Certain Nonimmigrant Workers
  - (2026-09-23) Public Water System Supervision Program Revision for the State of Arkansas
      Notice is hereby given that the State of Arkansas is revising its approved Public Water System Supervision (PWSS) program. Arkansas has adopted the Environmental Protection Agency (EPA) drinking water rules for the Consu…
  - (2026-09-23) Air Plan Approval; North Carolina; Charlotte-Rock Hill Area Maintenance Plan for the 2008 8-Hour Ozone NAAQS
      On February 28, 2025, the State of North Carolina, through the North Carolina Department of Environmental Quality, Division of Air Quality (NCDAQ), submitted a request for the U.S. Environmental Protection Agency (EPA) t…
  - (2026-09-23) Patient Protection and Affordable Care Act; Temporary Moratoria on Certain Agent and Broker Registration To Participate in the Exchanges
      This interim final rule with comment period (IFC) codifies the Department of Health and Human Services' (HHS) authority to impose a temporary moratorium pausing the registration of agents and brokers that do not have a c…
  - (2026-09-23) Fisheries of the South Atlantic; 2026 South Atlantic Red Snapper Recreational Fishing Season
      For the 2026 fishing year, NMFS announces the red snapper recreational fishing season dates in the South Atlantic exclusive economic zone (EEZ). Announcing the opening and closing dates of the red snapper recreational se…

### Paper Trading Scorecard — 17 new of 119 total
  - (2026-09-23) [Manifold] If Democrats win the House or Senate in 2026, will officials try to block Democratic winners from being seated?
  - (2026-09-23) [Manifold] Will Russia publicly commit to an energy-infrastructure ceasefire with Ukraine before Nov 20, 2026?
  - (2026-09-23) [Manifold] Will Democrats win 53 seats or more in the 2026 Senate elections?
  - (2026-09-23) [Manifold] Will Alex Radu find a sponsor for Disposition (or any other YSWS) by the end of November 2026?
  - (2026-09-23) [Manifold] Will Tottenham Hotspur be relegated from the Premier League in the 2026/2027 season?
  - (2026-09-23) [Manifold] Will Texas experience blackouts this Winter?

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-09-23) Dota 2: Team Nemesis vs Conventus Stellarum (BO3) - PGL Wallachia Group Stage
      yes price: 51% · 24h volume: $923,899 · resolves 2026-09-23
  - (2026-09-23) Will Sarah Huckabee Sanders win the 2028 Republican presidential nomination?
      yes price: 0% · 24h volume: $484,440 · resolves 2028-11-07
  - (2026-09-23) Counter-Strike: QUAZAR vs Misa Esports (BO3) - European Pro League Series 9 Playoffs
      yes price: 0% · 24h volume: $340,580 · resolves 2026-09-23
  - (2026-09-23) Strait of Hormuz traffic returns to normal by December 31?
      yes price: 24% · 24h volume: $323,556 · resolves 2027-01-01
  - (2026-09-23) US announces end of Iranian blockade by September 30, 2026?
      yes price: 8% · 24h volume: $318,011 · resolves 2026-10-01
  - (2026-09-23) Will the US confirm that aliens exist before 2027?
      yes price: 4% · 24h volume: $294,170 · resolves 2027-01-01

### USGS earthquakes (M4.5+, past day) — 9 new of 9 total
  - (2026-09-23) M 5.3 - 51 km WSW of Arauco, Argentina
      M5.3 · 51 km WSW of Arauco, Argentina · depth 121.534 km
  - (2026-09-23) M 4.9 - Scotia Sea
      M4.9 · Scotia Sea · depth 10 km
  - (2026-09-22) M 4.8 - 26 km NW of Houma, Tonga
      M4.8 · 26 km NW of Houma, Tonga · depth 121.928 km
  - (2026-09-23) M 4.7 - 30 km SE of Khorugh, Tajikistan
      M4.7 · 30 km SE of Khorugh, Tajikistan · depth 141.19 km
  - (2026-09-22) M 4.6 - 46 km E of Union, Philippines
      M4.6 · 46 km E of Union, Philippines · depth 10 km
  - (2026-09-22) M 4.6 - 37 km SE of Severo-Kuril’sk, Russia
      M4.6 · 37 km SE of Severo-Kuril’sk, Russia · depth 83.948 km

### Government Action: Sanctions + Procurement + Foreign Agents — 8 new of 104 total
  - (2026-09-23) [USASpending] $3,549,243,793 → SPACE EXPLORATION TECHNOLOGIES CORP.: IGF::OT::IGF THE COMMERCIAL CREW PROGRAM (CCP) COMMERCIAL CR
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF THE COMMERCIAL CREW PROGRAM (CCP) COMMERCIAL CREW TRANSPORTATION CAPABILITY (CCTCAP) CONTRACT WILL PROVIDE COMPLETION OF THE DESIGN, DEVELO…
  - (2026-09-23) [USASpending] $2,201,533,469 → THE TRUSTEES OF PRINCETON UNIVERSITY: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE P
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE OPERATION OF THE PRINCETON PLASMA PHYSICS LABORATORY (PPPL)
  - (2026-09-23) [USASpending] $1,643,484,969 → BATTELLE SAVANNAH RIVER ALLIANCE, LLC: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING
      Agency: Department of Energy. Description: SAVANNAH RIVER NATIONAL LABORATORY MANAGEMENT AND OPERATING (M&O) CONTRACT
  - (2026-09-23) [USASpending] $1,205,937,998 → SCIENCE APPLICATIONS INTERNATIONAL CORPORATION: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR
      Agency: General Services Administration. Description: THE SCOPE OF THE TO IS TO PROVIDE ENTERPRISE IT SERVICES FOR THE USACE.
  - (2026-09-23) [USASpending] $1,082,206,149 → LEIDOS, INC.: RESEARCH SUPPORT SERVICES (RSS)
      Agency: Department of Energy. Description: RESEARCH SUPPORT SERVICES (RSS)
  - (2026-09-23) [USASpending] $942,639,630 → ACCENTURE FEDERAL SERVICES LLC: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOM
      Agency: Department of Education. Description: THIS TASK ORDER IS FOR AN ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE PLATFORMS AND SERVICES SOLUTION (ENTERPRISE-WIDE DIGITAL AND CUSTOMER CARE SOLUTION, AKA EWDCCPS, AKA DCC)…

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-23) [Japan] CHOUCHOU & FRIENDS Opens The First Global Flagship Store , Launching the One City , One Store Strategy with More Than 300 New Products
      jcnnewswire.com · English
  - (2026-09-23) [Japan] Japan First Overnight Shinkansen Runs From Osaka to Tokyo
      newsonjapan.com · English
  - (2026-09-23) [Japan] Escaped Emu Captured After Report of Wandering Ostrich
      newsonjapan.com · English
  - (2026-09-23) [Japan] Shooting at South African house party kills 11 , injures three
      japantoday.com · English
  - (2026-09-23) [Japan] Man arrested over fatal stabbing of common - law wife
      japantoday.com · English
  - (2026-09-23) [Japan] Takaichi voices support for ICC , rule of law in 1st U . N . speech
      japantoday.com · English

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] BUCK FOR COLORADO
      cycle 2012 · filing #768060 · receipts $0.00M
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 22 total
  - (2026-09-22) CVE-2026-93952 · Arista VeloCloud Orchestrator: Arista VeloCloud Orchestrator Improper Input Validation Vulnerability
      vendor: Arista · product: VeloCloud Orchestrator · CISA remediation by 2026-09-25
  - (2026-09-22) CVE-2026-94127 · F5 BIG-IP APM: F5 BIG-IP APM Heap-based Buffer Overflow Vulnerability
      vendor: F5 · product: BIG-IP APM · CISA remediation by 2026-09-25
  - (2026-09-22) CVE-2026-93616 · Check Point Multiple Products: Check Point Multiple Products Path Traversal Vulnerability
      vendor: Check Point · product: Multiple Products · CISA remediation by 2026-09-25
  - (2026-09-22) CVE-2026-85102 · Check Point Multiple Products: Check Point Multiple Products Improper Certificate Validation Vulnerability
      vendor: Check Point · product: Multiple Products · CISA remediation by 2026-09-25

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-23) [Marginal Revolution] The Price of Intelligence is Falling Rapidly
      An amazing Epoch AI report from Emberson and Roodman: Over the past three years, the cost of a given level of AI performance has fallen an average of some 47% per quarter. That is a 13-fold drop every year – a faster rat…
  - (2026-09-23) [Marginal Revolution] What I’ve been reading
      1. Constance Reid, Hilbert. We should all be reading more mathematics these days, right? Because the field is “on fire.” Hilbert is not a bad place to start, and I found this book clear and biographical in a good way. It…
  - (2026-09-22) [Marginal Revolution] The economics of late grandmotherhood
      We show how fertility delays compound across generations to raise age at first grandmotherhood. Under the 1960 first-birth schedule median grandmotherhood came at 44. Under the 2024 schedule it is 57, cutting the healthy…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-23) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=20, 7d-median=19, 14d-median=19; carrying terms: proposing, program, airplanes, model, proposes, final, directives, directive, certain, navigable, airworthiness, proposed
- state_bills: today=120, 7d-median=105, 14d-median=97; carrying terms: unless, california, statewide, emergency, water, entities, eligible, local, history, above, facility, related
- state_news: today=754, 7d-median=683, 14d-median=683; carrying terms: connecticut, began, spotlightdelaware, economy, hearing, async, statewide, permalink, releases, staff, local, based
- local_news: today=207, 7d-median=231, 14d-median=231; carrying terms: braves, event, north, blank, season, found, school, business, dekalb, stlmag, restaurant, court
- foreign_news: today=1046, 7d-median=1045, 14d-median=994; carrying terms: league, viral, korea, boxing, tells, seeks, medical, renewed, based, urging, finds, spending
- chinese_internal: today=280, 7d-median=280, 14d-median=284; carrying terms: cbmiw, lxtfa, blank, cbmiakfvx, caixin, cbmib, cbmix, cbmiykfvx, cbmibefvx, chinese, cbmiaefvx, cbmizkfvx
- russian_internal: today=1120, 7d-median=1067, 14d-median=1067; carrying terms: laquo, russian, found, httperror, politico, reuters, times, istories, https, media, forbidden, server
- ukrainian_internal: today=134, 7d-median=135, 14d-median=135; carrying terms: plans, infrastructure, western, ballistic, commercial, against, https, ukrinform, casualties, facility, shahed, operations
- ukraine_theater: today=427, 7d-median=450, 14d-median=427; carrying terms: oskxnounky, april, cbmioefvx, jouvqag, lahrolxnjv, kurdistan, defence, sbknoylhfr, cnvichb, txrjvniwtwtwmmj, zzhxufu, staff
- paper_bets: today=119, 7d-median=126, 14d-median=128; carrying terms: predictit, jinping, republicans, supreme, degrees, nominal, court, johnson, prize, rippling, succeed, experience
- weather: today=146, 7d-median=117, 14d-median=116; carrying terms: memphis, southwest, aviation, louis, level, boston, pontiac, oxnard, updated, southern, depth, western
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: latest, effective, nonfarm, inflation, openings, money, spread, walcl, growth, supply, dexjpus, energy
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: close, equities, russell, china, range, nasdaq, large, yield, natural, futures, proxy, agriculture
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=104, 7d-median=105, 14d-median=107; carrying terms: crimea, legislation, congo, hybrid, hamas, russian, violent, imposed, schools, transactions, bissau, guinea
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, quantitative, unauthorized, congresstrading, httperror, client, error, https, quiverquant
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, court, appeals, state, delaware, company, arizona, connecticut, blanche, international, district, trade
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, holdings, filer, trust, tidal, global, finance, scott, international
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: committee, cycle, david, ocasio, brown, sherrod, senate, angels, johnson, disbursements, graham, lindsey
- gdelt_regions: today=6, 7d-median=0, 14d-median=6; carrying terms: english
- gdelt_gkg: today=70, 7d-median=50, 14d-median=50; carrying terms: sanctions, english, chinese, russia, spanish, turkish, ukrainian, themes, trump, perimeter, russian, keywords
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, germany, ground, france, bulgaria, aabfa, slovenia, kuwait
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: congo, evolve, cvdpv, sites, october, mongbwalu, netherlands, ventilatory, awareness, zoonotic, being, april
- cisa_kev: today=22, 7d-median=21, 14d-median=22; carrying terms: authentication, vulnerability, citrix, remediation, missing, bounds, vendor, google, chromium, write, jfrog, function
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=9, 7d-median=15, 14d-median=13; carrying terms: depth, indonesia, ruteng, argentina, russia, tonga, china
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: resolves, volume, price, champions, league, rates, championship, donetsk, shakhtar, meeting, interest, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, economist, revolution, conversable, conversableeconomist, class, https, report, benefits, marginalrevolution, given, price
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: technology, infrastructure, access, hacker, against, https, artificial, vulnerability, cybersecurity, services, weekly, computer
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: ricketts, elizabeth, fulcher, samuel, huizenga, ogles, susie, louis, johnson, april, alsobrooks, warsh
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: consensus, placement, decision, identify, paper, either, today, placed, module, market, markets, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI
- [2026-09-16] ECB press: ECB wage tracker at 2.7% in H1 2027, pointing to a modest uptick in negotiated wage growth
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] ECB press: Boris Vujčić: Interview with Reuters
- [2026-09-18] ECB press: ECB Consumer Expectations Survey results – August 2026
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-21] ECB press: ECB to invest part of own funds in tokenised securities, with settlement via Pontes
- [2026-09-21] ECB press: Eurosystem brings central bank money to tokenised finance
- [2026-09-22] ECB press: Philip R. Lane: Interview with Le Temps
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-22] Fed press (events + announcements): Federal Reserve Board announces approval of application by BancFirst Corporation
- [2026-09-23] ECB press: Almost ten million people took part in ECB survey on new euro banknotes

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*