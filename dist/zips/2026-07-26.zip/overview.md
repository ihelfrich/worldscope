# WORLDSCOPE morning brief — 2026-07-26

## Headline
4348 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (860) · Russian Internal News (state + in-exile) (717) · Ukraine Theater (total-war monitoring) (476) · State-Level News (459) · World leaders & government officials (324) · Chinese Internal News (265) · GDACS — global disaster alerts (229) · Local News: St. Louis + Atlanta (214) · U.S. Weather + Severe / Climate Outlooks (182) · Ukrainian Internal News (national + local Kyiv) (129) · State Legislative Action (116) · Court opinions of consequence (federal & state) (60)

## What changed today
### International News + Multilateral Institutions — 860 new of 1005 total
  - (2026-07-26) [Global] Water returns to Gatwick Airport after major outage
      Gatwick Airport faced a day of disruptions with toilets and restaurants closed to passengers.
  - (2026-07-26) [Global] Would you choose £50,000 over the chance of £1m?
      The vast majority of people - particularly women - answer a survey saying they'd take the certainty over chance.
  - (2026-07-26) [Global] Rental searches for pet friendly properties drop after law change
      Agents say some renters wrongly believe permission to have a pet is guaranteed.
  - (2026-07-26) [Global] Primark's new 'supermarket tactic' to woo customers in online price war
      Competition from ultra-cheap Chinese retailers and the cost of living crisis could be putting some people off shopping at the store, analysts say.
  - (2026-07-24) [Global] ADHD has rewired the workplace. This is what it means for bosses and workers
      As ADHD diagnoses have risen, have workplaces caught up with the needs of the workforce?
  - (2026-07-25) [Global] Warning shot or publicity stunt - how worried should we be about the OpenAI hack?
      Hugging Face said the hack was done at superhuman speed by an AI with little or no human guidance.

### Russian Internal News (state + in-exile) — 717 new of 720 total
  - (2026-07-26) Подозреваемый в совершении теракта на ЛГБТ-прайде в Берлине убит | LEDE: Предполагаемый преступник, совершивший теракт во время ЛГБТ-прайда в Берлине, вероятно, застрелен, сообщают телерадио] (ru: Под…
      Предполагаемый преступник, совершивший теракт во время ЛГБТ-прайда в Берлине, вероятно, застрелен, сообщают телерадиокомпания rbb и газета Bild.
  - (2026-07-26) Зеленский заявил, что украинские военные обновили список целей для ударов вглубь России | LEDE: Украина обновила список приоритетных целей для дальнобойных ударов в глубине России, заявил Вл] (ru: Зел…
      Украина обновила список приоритетных целей для дальнобойных ударов в глубине России, заявил Владимир Зеленский по итогам совещания с военными.
  - (2026-07-26) Глава LVMH Бернар Арно скупает французские СМИ — чтобы давить на журналистов, продвигать правую повестку, унижать своих конкурентов и, конечно, богатеть. Вот как работает его медиаимперия | LED] (ru:…
      Бернар Арно — владелец конгломерата LVMH, куда входят такие люксовые бренды, как Louis Vuitton, Christian Dior, Bulgari и Hennessy. Он — один из богатейших и влиятельнейших людей не только Франции, но и мира. Влияние Арн…
  - (2026-07-26) Фридман подал иск к Нидерландам. Это уже третья страна, от которой он хочет компенсаций из-за заморозки своих инвестиций | LEDE: Сооснователь «Альфа-Групп» и российский миллиардер Михаил Фри] (ru: Фри…
      Сооснователь «Альфа-Групп» и российский миллиардер Михаил Фридман подал арбитражный иск к Нидерландам, обвинив страну в экспроприации его инвестиций, пишут «Ведомости» со ссылкой на карточку дела.
  - (2026-07-26) «Мегамаркет» освободил себя от ответственности перед продавцами в случае атак беспилотников. Так же сделали раньше Ozon, Wildberries и «Яндекс Маркет» | LEDE: Маркетплейс «Мегамаркет», котор] (ru: «Ме…
      Маркетплейс «Мегамаркет», который принадлежит Сберу, изменил оферту для продавцов и снял с себя ответственность за неисполнение обязательств в случае атак беспилотников, обратил внимание телеграм-канал «Можем объяснить».
  - (2026-07-26) Во Внуково сломались ленты приема багажа. Задерживаются более 30 рейсов | LEDE: В московском аэропорту Внуково возникли задержки из-за сбоя в системе обработки багажа. ] (ru: Во Внуково сломались лент…
      В московском аэропорту Внуково возникли задержки из-за сбоя в системе обработки багажа.

### Ukraine Theater (total-war monitoring) — 476 new of 586 total
  - (2026-07-26) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-26) [ISW] Russian Offensive Campaign Assessment 2026-07-26
      Key Takeaways The Russian Navy is forming unmanned systems regiments, likely in part to protect Russian vessels from intensified Ukrainian strikes against Russian naval assets in the Black and Azov seas. Russian Presiden…
  - (2026-07-25) [Liveuamap] Tokayev, at a meeting with Putin, proposed freezing the war in Ukraine. The meeting of the presidents of Kazakhstan and Russia is taking place in Omsk, Russia. Tokayev stressed that his co…
      Tokayev, at a meeting with Putin, proposed freezing the war in Ukraine. The meeting of the presidents of Kazakhstan and Russia
  - (2026-07-26) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2026-07-24) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap

### State-Level News — 459 new of 472 total
  - (2026-07-24) [Alabama] Alabama Health Literacy Month
      Download
  - (2026-07-24) [California] California’s economy isn’t just bigger than Texas and Florida — it’s growing faster, too
      Source
  - (2026-07-24) [California] California landlord fights law meant to help low-income renters
      Should California landlords be required to rent to tenants with federal housing vouchers? They are under state law, but a Sacramento-based property manager is contest
  - (2026-07-24) [California] Public funding cuts, lost grants, stagnant wages: How economic woes are dimming a vibrant art scene
      <img width="1024" height="681" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072226-SD-Arts-AP-CM.jpg?fit=1024%2C681&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="An a…
  - (2026-07-24) [California] Aging oil refineries don’t need more public dollars. California should let them retire
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092925-Refinery-Workers-SK-10-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-24) [California] California can’t replant its forests fast enough to keep up with wildfires
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526_Reforestation_AHK_CM_75.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 265 new of 265 total
  - (2026-07-24) PRO专享/数据深度专题 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMie0FVX3lxTE90c3JhX2dHajhDTXJlZWlVamFKTUd4cGEwOE9aUVowZVZCcWVuN0pBRjFRRDhWOUlSM2JjMGdFYzgxdlNoUGlvOURQ] (zh:…
      PRO专享/数据深度专题 deepview.caixin.com
  - (2026-07-26) 一周天下｜西班牙2026世界杯夺冠、中国数学家邓煜王虹同获2026 年菲尔兹奖 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1feW5NbEpGY2tZMW1hVlRUc1l2NzJNT2x4RWtqUGxwVVBIRFRQMDExcWRHMThUZ01vNWhSRDFOVHlGVD] (zh:…
      一周天下｜西班牙2026世界杯夺冠、中国数学家邓煜王虹同获2026 年菲尔兹奖 财新
  - (2026-07-26) 财经早知道｜两部门明确离岸信托个税事项 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9FTkYxSUl2aUN2Z1Fmb1U4RXQ0bmwySE1uQW1ISm1GVUZMN0hpYnJFaUlfTm9wQ1hfMGtjc3ZVMmpVWHRnMUxXM1FMR09uTG4wMl] (zh:…
      财经早知道｜两部门明确离岸信托个税事项 财新
  - (2026-07-24) 今日开盘：两市双双低开 沪指跌幅0.60% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBwSTQtSXF6WURFeGh4aG1rMXNpRXdWTE1zSmROLWNsR1B4Z2dPRFJxQkNsaS1obmpFYWUxeDg0NUNYSWh1Zkk3SXZqbi1uaXM5] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.60% 财新
  - (2026-07-26) 造访齐国古都｜黄河两岸④ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoNlZQYVFFTmltcDZGYzhRZFJUeFdnRDdvN2QzY1FSazFZNG1JSk5taUtLQkMzZjZnNktxUVZxcXJBMU9LZERPVzk0aTF2R0hLd1hNRG4za] (zh:…
      造访齐国古都｜黄河两岸④ 财新
  - (2026-07-24) 伊朗被曝已拒绝美方停火提议 特朗普“接近”决定是否扩大对伊行动 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE53eDJHMnNnWTBjblQ2Y2RINFBCdF94d0lHX0ZYeGJNOHBLMDVTZTk4V2hwemRfZjFPWDFHQ2pha2t6VG9vVXNtVF] (zh:…
      伊朗被曝已拒绝美方停火提议 特朗普“接近”决定是否扩大对伊行动 财新

### GDACS — global disaster alerts — 229 new of 257 total
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)

### Local News: St. Louis + Atlanta — 214 new of 215 total
  - (2026-07-26) [St. Louis] He stopped dreaming for years. Then doctors found out why
      A breakthrough epilepsy surgery at St. Louis Children's Hospital helped Gray Douglass dream again — and inspired his future in medicine.
  - (2026-07-26) [St. Louis] US and Iran pause their attacks after days of escalation
      The U.S. has not attacked Iran for a second day. Iran says it also halted attacks. The pause comes amid efforts to resume negotiations on an interim ceasefire deal.
  - (2026-07-26) [St. Louis] Sweltering heat wave grips central and southern US for a second straight day
      A scorching heat wave continues across the central and southern United States, leaving tens of millions under extreme heat warnings.
  - (2026-07-26) [St. Louis] Suspect in deadly Berlin Pride attack is killed in a confrontation with police
      German authorities say the suspect in the deadly Berlin Pride attack that killed one person and left 29 injured was shot and killed by police during a confrontation.
  - (2026-07-26) [St. Louis] Freddy Cannon, 'Palisades Park' singer, dies after cancer battle
      Freddy "Boom Boom" Cannon sang hits like "Tallahassee Lassie" and "Way Down Yonder in New Orleans" in the late 50s and early 60s.
  - (2026-07-26) [St. Louis] Deadly shooting in Pontoon Beach prompts Major Case Squad activation
      A 34-year-old was shot multiple times and killed Sunday on Pontoon Road. The Major Case Squad is asking anyone with information to come forward.

### U.S. Weather + Severe / Climate Outlooks — 182 new of 184 total
  - (2026-07-26) [Moderate] Special Weather Statement: Special Weather Statement issued July 26 at 5:32PM MDT by NWS Albuquerque NM
      At 532 PM MDT, Doppler radar was tracking a strong thunderstorm 7 miles southeast of Magdalena, or 16 miles west of Socorro, moving north at 10 mph. HAZARD...Wind gusts of 50 to 55 mph and half inch size hail. SOURCE...R…
  - (2026-07-26) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 26 at 6:29PM CDT until July 26 at 7:15PM CDT by NWS Paducah KY
      SVRPAH The National Weather Service in Paducah has issued a * Severe Thunderstorm Warning for... Southwestern Henderson County in northwestern Kentucky... Northeastern Crittenden County in western Kentucky... Northern Ca…
  - (2026-07-26) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 26 at 6:27PM CDT until July 26 at 7:15PM CDT by NWS Paducah KY
      SVRPAH The National Weather Service in Paducah has issued a * Severe Thunderstorm Warning for... Northwestern White County in southeastern Illinois... Southeastern Wayne County in south central Illinois... Eastern Hamilt…
  - (2026-07-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-26) [Moderate] Special Weather Statement: Special Weather Statement issued July 26 at 5:24PM MDT by NWS Albuquerque NM
      At 524 PM MDT, Doppler radar was tracking a strong thunderstorm 13 miles southeast of Sugarite, or 14 miles east of Raton, and is stationary. HAZARD...Wind gusts of 50 to 55 mph. SOURCE...Radar indicated. IMPACT...Gusty…
  - (2026-07-26) [Severe] Flash Flood Warning: Flash Flood Warning issued July 26 at 7:17PM EDT until July 26 at 10:15PM EDT by NWS Binghamton NY
      FFWBGM The National Weather Service in Binghamton has issued a * Flash Flood Warning for... East Central Onondaga County in central New York... * Until 1015 PM EDT. * At 717 PM EDT, Doppler radar indicated thunderstorms…

### Ukrainian Internal News (national + local Kyiv) — 129 new of 137 total
  - (2026-07-27) У Німеччині поліція застрелила підозрюваного у смертельному наїзді на учасників прайду | LEDE: Поліцейські Німеччини застрелили підозрюваного у смертельному наїзді на учасників прайду.] (uk: У Німеччи…
      Поліцейські Німеччини застрелили підозрюваного у смертельному наїзді на учасників прайду.
  - (2026-07-27) У військовому командуванні США вважають, що удари в районі Ормузу вичерпали ефективність – Axios | LEDE: Axios пише, що американські військові вважають, що удари по Ормузу вичерпали ефективніст] (uk:…
      Axios пише, що американські військові вважають, що удари по Ормузу вичерпали ефективність.
  - (2026-07-27) У Краматорську ворожий FPV-дрон атакував екіпаж поліцейських, поранений патрульний | LEDE: У Нацполіції повідомили, що в Краматорську російський дрон атакував екіпаж патрульних.] (uk: У Краматорську в…
      У Нацполіції повідомили, що в Краматорську російський дрон атакував екіпаж патрульних.
  - (2026-07-26) Росіяни атакували заклад торгівлі на Миколаївщині: двоє поранених | LEDE: У Снігурівській громаді на Миколаївщині дрон атакував заклад торгівлі, двоє поранених.] (uk: Росіяни атакували заклад торгівлі…
      У Снігурівській громаді на Миколаївщині дрон атакував заклад торгівлі, двоє поранених.
  - (2026-07-26) На Вінниччині чоловік поранив військовослужбовця під час доставлення до ТЦК | LEDE: На Вінниччині порушник військового обліку напав на військовослужбовців групи оповіщення ТЦК і поранив одного ] (uk:…
      На Вінниччині порушник військового обліку напав на військовослужбовців групи оповіщення ТЦК і поранив одного з них.
  - (2026-07-26) Росіяни вдарили по Сумській громаді: 5 постраждалих, пошкоджено будинки й інфраструктуру | LEDE: У Сумській громаді після авіаударів КАБами поранено п'ятеро людей, пошкоджено будинки та інфраст] (uk:…
      У Сумській громаді після авіаударів КАБами поранено п'ятеро людей, пошкоджено будинки та інфраструктуру.

### State Legislative Action — 116 new of 117 total
  - (2026-07-24) [Alabama HB 42] Motor vehicles; reporting requirements for towed and unclaimed motor vehicles, further provided
      Motor Vehicles & Traffic
  - (2026-07-24) [Alabama HB 159] Retirement benefits, circuit clerks authorized to participate in supernumerary program and Employees' Retirement System based on separate years of service
      Retirement
  - (2026-07-24) [Alabama HB 7] Crimes and offenses, credible threat defined; penalties for crimes of making a terrorist threat in the first or second degree provided further for; principal to immediately contact law…
      Crimes & Offenses
  - (2026-07-24) [Alabama HB 8] Campus chaplains; public K-12 schools authorized to accept as volunteers, local boards of education and governing bodies authorized to vote on whether to allow, limitations provided
      Education
  - (2026-07-24) [Alabama HB 311] Retirement benefits; participation of qualifying sheriffs in supernumerary program and Employees' Retirement System based on separate years of service authorized
      Retirement
  - (2026-07-24) [Alabama HB 155] Homestead Exemptions; removing the annual verification requirement for qualifying permanently and totally disabled veterans
      Military

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-24) U.S. Court of Appeals, 5th Cir.: Students Engaged in Advancing Texas v. Ken Paxton
  - (2026-07-24) U.S. Court of Appeals, 4th Cir.: Josue Fuentes v. United States Citizenship and Immigration Services
  - (2026-07-24) Arizona Supreme Court: A & P RANCH LTD v. COCHISE COUNTY
  - (2026-07-24) U.S. Court of Appeals, 8th Cir.: Becky Joseph v. Thomas-Grace Const. Inc.
  - (2026-07-24) U.S. Court of Appeals, 8th Cir.: Jennifer Audette v. Lake of the Woods County
  - (2026-07-24) U.S. Court of Appeals, 6th Cir.: Christopher Hemwall v. Adam Douglas

### IT, InfoSys & cybersecurity news (last 7 days) — 57 new of 57 total
  - (2026-07-26) [BleepingComputer] GitHub, PyPI add time-based defenses against supply chain attacks
      GitHub and PyPI (Python Package Index) have introduced a time-based mechanism in the Dependabot dependency management tool to protect against supply-chain attacks and to limit their impact. [...]
  - (2026-07-26) [The Register] Trump expands voluntary pledge to keep datacenter costs off household power bills
      Pinkie promise gains 200-plus new participants and precisely zero enforcement
  - (2026-07-26) [The Register] The last Space Shuttle returned to Earth 15 years ago
      So, how are those commercial replacements working out for you, NASA?
  - (2026-07-26) [Ars Technica] First teaser for Apple TV's Neuromancer debuts at SDCC
      Plus Mike Flanagan's Carrie teaser, trailers for Dark Matter S2 and Matchbox the Movie, and Marvel news.
  - (2026-07-26) [TechCrunch] Can Apple make smart glasses that aren’t a constant privacy threat?
      As Apple prepares to launch its first smart glasses, the company may also be wrestling with how to address consumer privacy concerns.
  - (2026-07-26) [TechCrunch] Making sense of the panic over Chinese AI
      On the latest episode of Equity, we discussed why Moonshot AI's Kimi seemed to panic Silicon Valley and Wall Street.

### GDELT GKG — themes / entities / watch areas — 47 new of 47 total
  - (2026-07-26) [Russia oil sanctions perimeter · themes] Rusia godet portet e Ukrainës ! Mbytet anija e mallrave , humbin jetën 9 persona – Press Online
      pressonline.al · Albanian · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] Rusia godet portet e Ukrainës ! Mbytet anija e mallrave , humbin jetën 9 persona
      vizionplus.tv · Albanian · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] Why is India ethanol - blended fuel policy facing consumer backlash ?
      channelnewsasia.com · English · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] 藍營 「 AI仿賴清德聲音當旁白 」 遭查 他驚毫無下限 ： 違法還敢這麼大聲 ？ | 政治
      setn.com · Chinese · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] Радбез ООН збереться на екстрене засідання через обстріли суден у Чорному морі на запит України
      unn.ua · Ukrainian · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] AEW Collision Review : Ciampa Paints Up , Champions Cheat to Win
      bleedingcool.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-25) [Tangney Jeffrey] Form 4 (Reporting)
      filed 2026-07-25 01:59 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Doximity, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:59 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Sams Louise S] Form 4 (Reporting)
      filed 2026-07-25 01:51 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:51 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Auguste Laurent] Form 4 (Reporting)
      filed 2026-07-25 01:49 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:49 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB

### Government Action: Sanctions + Procurement + Foreign Agents — 38 new of 119 total
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses - Office of Foreign Assets Cont…
      Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses Office of Foreign Assets Control (.gov)
  - (2026-07-20) [OFAC] Russia-related Designations Updates - Office of Foreign Assets Control (.gov)
      Russia-related Designations Updates Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] CJNG-Linked Networks - Office of Foreign Assets Control (.gov)
      CJNG-Linked Networks Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] CJNG Leadership - Office of Foreign Assets Control (.gov)
      CJNG Leadership Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 36 new of 138 total
  - (2026-07-26) [Polymarket] Will Vinícius Júnior win the 2026 Ballon d'Or?
      This market will resolve according to the winner of the 2026 Ballon d’Or. If no 2026 Ballon d’Or winner is declared by December 31, 2026, 11:59 PM ET, this market will resolve to "Other". The primary resolution source fo…
  - (2026-07-26) [Polymarket] Will Marco Rubio win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-26) [Polymarket] Will Elon Musk post 400-419 tweets from July 21 to July 28, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 21 12:00 PM ET to July 28, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and re…
  - (2026-07-26) [Polymarket] Will Anthropic have the best AI model at the end of July 2026?
      This market will resolve according to the company which owns the model which has the highest arena rank based off the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is chec…
  - (2026-07-26) [Polymarket] Will Sabrina Carpenter be the top artist for 2026?
      Spotify releases an annual report of its most streamed artist (see: https://newsroom.spotify.com/2025-12-03/wrapped-top-artists-songs-albums-podcasts-audiobooks/). This market refers to the most streamed Spotify artist f…
  - (2026-07-26) [Polymarket] Will Daniil Medvedev win the 2026 Men's US Open?
      The 2026 U.S. Open tennis tournament is scheduled for August 23 - September 13, 2026. This market will resolve to the player that wins the 2026 U.S. Open Men’s Singles Tournament. If at any point it becomes impossible fo…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Prediction Markets — most-traded (Polymarket) — 20 new of 20 total
  - (2026-07-26) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,990,107 · resolves 2026-06-01
  - (2026-07-26) New York Yankees vs. Philadelphia Phillies
      yes price: 26% · 24h volume: $971,905 · resolves 2026-08-02
  - (2026-07-26) Will the U.S. invade Iran before 2027?
      yes price: 20% · 24h volume: $802,978 · resolves 2026-12-31
  - (2026-07-26) Will there be no change in Fed interest rates after the July 2026 meeting?
      yes price: 78% · 24h volume: $787,208 · resolves 2026-07-29
  - (2026-07-26) Will the Fed decrease interest rates by 50+ bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $699,951 · resolves 2026-07-29
  - (2026-07-26) LoL: Shopify Rebellion vs Disguised - Game 1 Winner
      yes price: 100% · 24h volume: $536,727 · resolves 2026-07-27

### U.S. Federal Action — 12 new of 12 total
  - (2026-07-27) Modernizing Reactor Licensing, Safety Oversight, and Siting Practices; Correction
      The U.S. Nuclear Regulatory Commission (NRC) is correcting a notice published in the Federal Register on July 16, 2026, regarding the modernization of reactor licensing, safety oversight, and siting practices to address…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Report and Order that promotes the deployment of submarine cables while strengthening national security interests in connection…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Further Notice of Proposed Rulemaking (Second FNPRM) that seeks to further prevent evolving national security risks associated…
  - (2026-07-27) Modernizing Package Certification Requirements
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its regulations governing the packaging and transportation of radioactive material. This proposed action is responsive to several executive orders and th…
  - (2026-07-27) Updating Website and Contact Information, and Authorizations for Payments for Legal Services
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is adopting a final rule to update website and contact information in certain parts of the Code of Federal Regulations (CFR). Additionally, OFAC is…
  - (2026-07-27) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action
      NMFS announces an inseason action for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds fishing dates in August and September in the Co…

### Government & military aircraft airborne (OpenSky) — 11 new of 11 total
  - (2026-07-26) CFC0516 (Canada)
      icao24: c2b067 · position: (51.248, -114.1625) · alt: 1844m · 373km/h
  - (2026-07-26) PAT820 (United States)
      icao24: adfe4b · position: (61.0502, -149.7088) · alt: 2484m · 429km/h
  - (2026-07-26) CFC515 (Canada)
      icao24: c2b099 · position: (51.1853, -113.9903) · alt: 1318m · 379km/h
  - (2026-07-26) FAF (Australia)
      icao24: 7c1955 · position: (-35.522, 138.1997) · alt: 1181m · 254km/h
  - (2026-07-26) JAF2EV (Belgium)
      icao24: 44d1ba · position: (50.8158, 5.3886) · alt: 4686m · 495km/h
  - (2026-07-26) SAMU42 (France)
      icao24: 39ac4d · position: (45.5133, 4.3519) · alt: 838m · 259km/h

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-07-26) M 5.8 - 99 km SE of Atka, Alaska
      M5.8 · 99 km SE of Atka, Alaska · depth 10 km
  - (2026-07-26) M 5.4 - northern Mid-Atlantic Ridge
      M5.4 · northern Mid-Atlantic Ridge · depth 10 km
  - (2026-07-26) M 5.3 - 25 km NW of Kupang, Indonesia
      M5.3 · 25 km NW of Kupang, Indonesia · depth 10 km
  - (2026-07-26) M 5.1 - Tristan da Cunha region
      M5.1 · Tristan da Cunha region · depth 10 km
  - (2026-07-26) M 5.0 - South Atlantic Ocean
      M5.0 · South Atlantic Ocean · depth 10 km
  - (2026-07-26) M 4.7 - 15 km ESE of Pinglin, Taiwan
      M4.7 · 15 km ESE of Pinglin, Taiwan · depth 93.836 km

### CISA Known Exploited Vulnerabilities (last 14d) — 6 new of 16 total
  - (2026-07-22) CVE-2026-16232 · Check Point SmartConsole: Check Point SmartConsole Improper Authentication Vulnerability
      vendor: Check Point · product: SmartConsole · CISA remediation by 2026-07-25
  - (2026-07-22) CVE-2026-50522 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-25
  - (2026-07-21) CVE-2026-60137 · WordPress Core: WordPress Core SQL Injection Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-08-04
  - (2026-07-21) CVE-2026-63030 · WordPress Core: WordPress Core Interpretation Conflict Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-07-24
  - (2026-07-21) CVE-2026-0770 · Langflow Langflow: Langflow Inclusion of Functionality from Untrusted Control Sphere Vulnerability
      vendor: Langflow · product: Langflow · CISA remediation by 2026-07-24
  - (2026-07-21) CVE-2021-27137 · DD-WRT DD-WRT: DD-WRT Stack-Based Buffer Overflow Vulnerability
      vendor: DD-WRT · product: DD-WRT · CISA remediation by 2026-07-24

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-26) [Marginal Revolution] In relative terms, maybe children do not cost more than before?
      Despite rapid inflation in childcare and tuition prices, the goods-and-services CCI closely tracks adult prices, as these increases are offset by children’s lower exposure to shelter and by slower price growth elsewhere…
  - (2026-07-26) [Marginal Revolution] Further progress in South America
      The share of people who are hungry has been decreasing faster in South America than anywhere else in the world. It is down by one-third since 2020, according to a report published on July 21st by the UN’s Food and Agricu…
  - (2026-07-26) [Marginal Revolution] Sunday assorted links
      1. Deirdre economics reading list. 2. The 1878 entrance exam for the British India civil service. 3. How good is Opus 5 on biology? 4. “A linguistic “golden age” flourished between 1,000 to 3,000 years ago when tens of t…
  - (2026-07-24) [Conversable Economist] Occupational Licensing: US and International
      The potential benefit of having the government require that certain jobs require an official license is quality control and protection. Personally, I rather like knowing that my nurse or doctor or dentist has gone throug…
  - (2026-07-23) [Conversable Economist] The Job Market for Recent College Graduates
      When I talk with college students, and even high school students, a number of them have a profound sense that it is tremendously hard to find a job coming out of college. The level fear seems to me exaggerated, but some…
  - (2026-07-22) [Conversable Economist] Chokepoints for Ocean Trade: Strait of Hormuz, and What Else?
      For those who can be fuzzy on global geography, like me, it’s perhaps useful to say that the Persian Gulf is a body of water bordered by eight countries: Bahrain, Iran, Iraq, Kuwait, Qatar, Saudi Arabia, the United Arab…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=17, 14d-median=17
- state_bills: today=117, 7d-median=117, 14d-median=117
- state_news: today=472, 7d-median=711, 14d-median=711
- local_news: today=215, 7d-median=246, 14d-median=246
- foreign_news: today=1005, 7d-median=1024, 14d-median=1024
- chinese_internal: today=265, 7d-median=299, 14d-median=299
- russian_internal: today=720, 7d-median=833, 14d-median=833
- ukrainian_internal: today=137, 7d-median=138, 14d-median=138
- ukraine_theater: today=586, 7d-median=586, 14d-median=586
- paper_bets: today=138, 7d-median=143, 14d-median=143
- weather: today=184, 7d-median=177, 14d-median=177
- macro: today=21, 7d-median=21, 14d-median=21
- markets: today=21, 7d-median=21, 14d-median=21
- markets_global: today=47, 7d-median=47, 14d-median=47
- sanctions_procurement: today=119, 7d-median=119, 14d-median=119
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=12, 7d-median=12, 14d-median=12
- gdelt_gkg: today=47, 7d-median=47, 14d-median=47
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=11, 7d-median=11, 14d-median=11
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=257, 7d-median=101, 14d-median=101
- usgs_quakes: today=11, 7d-median=23, 14d-median=23
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- tech_news: today=57, 7d-median=57, 14d-median=57
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*