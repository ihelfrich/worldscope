# WORLDSCOPE morning brief — 2026-07-26

## Headline
4111 new items across 26 active section(s) (of 42 tracked).

## Top movers today
Russian Internal News (state + in-exile) (853) · International News + Multilateral Institutions (806) · State-Level News (433) · Ukraine Theater (total-war monitoring) (345) · World leaders & government officials (324) · Chinese Internal News (251) · GDACS — global disaster alerts (221) · Local News: St. Louis + Atlanta (213) · U.S. Weather + Severe / Climate Outlooks (185) · Ukrainian Internal News (national + local Kyiv) (115) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (57)

## What changed today
### Russian Internal News (state + in-exile) — 853 new of 856 total
  - (2026-07-26) Wildberries перестал показывать военные товары по запросу «все для СВО» (но найти их можно по другим запросам) | LEDE: Wildberries больше не отображает военные товары по запросам «все для СВ] (ru: Wil…
      Wildberries больше не отображает военные товары по запросам «все для СВО» или «СВО», обратили внимание украинские телеграм-каналы.
  - (2026-07-26) Пройти сотни километров пешком по тропам пилигримов — такой вариант отдыха выбирает все больше людей по всему миру. Почему Камино-де-Сантьяго и другие маршруты так популярны? И как стать паломн] (ru:…
      Паломнические маршруты вроде Камино-де-Сантьяго становятся все популярнее, хотя большинство людей отправляются в путь не ради религии. Научный журналист и автор телеграм-канала «Лайфлонг муки» Илья Кабанов — он сам проше…
  - (2026-07-26) В Ростовской области прошел ураган с ливнями и грозами. Один человек погиб, еще 13 пострадали. Задерживаются около 90 поездов | LEDE: В Ростовской области в субботу, 25 июля, прошел мощный у] (ru: В Р…
      В Ростовской области в субботу, 25 июля, прошел мощный ураган с ливнями и грозами, затронувший областной центр и другие крупные города.
  - (2026-07-26) The New York Times: Трамп отказался от дальнейших ударов по Ирану. Его команда опасается истощения американской ПВО на Ближнем Востоке | LEDE: Дональд Трамп отложил планы по резкой эскалации] (ru: The…
      Дональд Трамп отложил планы по резкой эскалации американского военного давления на Иран, пишет The New York Times со ссылкой на источники.
  - (2026-07-26) МИД Ирана обвинил Украину в атаке на иранское торговое судно в Каспийском море | LEDE: МИД Ирана заявил, что украинские военные утром 25 июля атаковали иранское торговое судно в Каспийском м] (ru: МИД…
      МИД Ирана заявил, что украинские военные утром 25 июля атаковали иранское торговое судно в Каспийском море.
  - (2026-07-26) Россия атаковала Киев ракетами, пострадали три человека. В Харькове — один погибший в результате удара беспилотников | LEDE: Российские войска атаковали Киев. Повреждения есть в Шевченковско] (ru: Рос…
      Российские войска атаковали Киев. Повреждения есть в Шевченковском, Соломенском и Деснянском районе, сообщил мэр Виталий Кличко.

### International News + Multilateral Institutions — 806 new of 951 total
  - (2026-07-24) [Global] Cover Story newsletter: Should you be afraid of Elon Musk?
      An exclusive look at how we designed our cover
  - (2026-07-26) [Global] Rental searches for pet friendly properties drop after law change
      Agents say some renters wrongly believe permission to have a pet is guaranteed.
  - (2026-07-26) [Global] Primark's new 'supermarket tactic' to woo customers in online price war
      Competition from ultra-cheap Chinese retailers and the cost of living crisis could be putting some people off shopping at the store, analysts say.
  - (2026-07-24) [Global] ADHD has rewired the workplace. This is what it means for bosses and workers
      As ADHD diagnoses have risen, have workplaces caught up with the needs of the workforce?
  - (2026-07-25) [Global] Warning shot or publicity stunt - how worried should we be about the OpenAI hack?
      Hugging Face said the hack was done at superhuman speed by an AI with little or no human guidance.
  - (2026-07-24) [Global] Trump vows to investigate EU over fining of US tech companies
      The US president says fines against Google, as well as Apple, Meta and Amazon, should be "entirely reversed."

### State-Level News — 433 new of 446 total
  - (2026-07-24) [California] California landlord fights law meant to help low-income renters
      Should California landlords be required to rent to tenants with federal housing vouchers? They are under state law, but a Sacramento-based property manager is contest
  - (2026-07-24) [California] Public funding cuts, lost grants, stagnant wages: How economic woes are dimming a vibrant art scene
      <img width="1024" height="681" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072226-SD-Arts-AP-CM.jpg?fit=1024%2C681&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="An a…
  - (2026-07-24) [California] Aging oil refineries don’t need more public dollars. California should let them retire
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092925-Refinery-Workers-SK-10-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-24) [California] California can’t replant its forests fast enough to keep up with wildfires
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526_Reforestation_AHK_CM_75.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-07-24) [California] Newsom appointed a close ally to this state board. Environmental groups say he has a conflict of interest
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072326-CalEPA-BES-Meeting-MG-CM-23.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-07-24) [Alabama] Alabama Health Literacy Month
      Download

### Ukraine Theater (total-war monitoring) — 345 new of 457 total
  - (2026-07-26) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-25) [FIRMS] thermal anomaly 52.848, 29.991 (FRP 3.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 0005Z, FRP 3.39 MW
  - (2026-07-25) [FIRMS] thermal anomaly 52.372, 33.341 (FRP 1.64 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 0005Z, FRP 1.64 MW
  - (2026-07-25) [FIRMS] thermal anomaly 52.369, 33.345 (FRP 1.3 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 0005Z, FRP 1.3 MW
  - (2026-07-25) [FIRMS] thermal anomaly 51.889, 34.389 (FRP 0.62 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 0005Z, FRP 0.62 MW
  - (2026-07-25) [FIRMS] thermal anomaly 51.787, 34.117 (FRP 3.82 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 0007Z, FRP 3.82 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 251 new of 251 total
  - (2026-07-24) Chart of the Day: China’s New Solar Build Out Plunges - Caixin Global
      Chart of the Day: China’s New Solar Build Out Plunges Caixin Global
  - (2026-07-24) 美国为何不停电救救电线杆上的狗熊？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1fc25wdG95cGJVS25vWFhiLVkzWXJzaS1PNUt4bGs5Tnp1SjRic3VydE1MQmoyRHhtU3R1RkZVX1d6U0V6aUZ2d090alZ0aDVnbzli] (zh:…
      美国为何不停电救救电线杆上的狗熊？ 风闻
  - (2026-07-25) 一个美国青年，为什么能进入敦煌市媒体中心，背调如何开展？相关程序是否规范透明？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1oT1VXNGZ0WTdxeGZhSm1xU1ltZWFsQ2JtQlVUb2liNUJOSG0wTmpuSFZVeG1DYnY3ZUt4aVpURl9YQk] (zh:…
      一个美国青年，为什么能进入敦煌市媒体中心，背调如何开展？相关程序是否规范透明？ 风闻
  - (2026-07-26) 恶毒！曲婉婷竟主动认领了“冰雪女王”的称呼，这是羞辱东北下岗工人的梗啊 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBZWmZUUk8xcmNablRhY0dubmJnd0szQzFXc3hDdkZSTEM5MG5kbGVtdERpUjNFdm1lQ01aNVZHXzJBbzRSTX] (zh:…
      恶毒！曲婉婷竟主动认领了“冰雪女王”的称呼，这是羞辱东北下岗工人的梗啊 风闻
  - (2026-07-26) 马斯克对话经济学人主编，探讨AI对于人类社会未来的影响 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE12ZVE3QUJ0U0JhSEpRWEFhUEVRc3hlSUp3eFRubnRPUkp6NUJsSVI5ZW92aHYwQzZ4SDNOYkhYTEFtN3YxY1FNdkt6MU] (zh:…
      马斯克对话经济学人主编，探讨AI对于人类社会未来的影响 风闻
  - (2026-07-26) 国家防减救灾委工作组，赶赴广东 - 观察 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE82VS1CenQ2eUkyaE05U3RzX3hLbEtYOGlmZUlKdGlOeVV4RlgyU085bGpRNG5zRC1BbEswNE95SFJGcXR0bnRlMXZ6VFJVQjl3WktpZ2] (zh:…
      国家防减救灾委工作组，赶赴广东 观察

### GDACS — global disaster alerts — 221 new of 249 total
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)

### Local News: St. Louis + Atlanta — 213 new of 213 total
  - (2026-07-24) [St. Louis] The Boom Boom Room moves to Buddy’s in downtown St. Louis
      Two major players in the downtown food and entertainment scene are joining forces for a new collaboration. Buddy’s Local Grill & Bar (1001 Washington) is teaming up with The Boom Boom Room as the new resident entertainme…
  - (2026-07-24) [St. Louis] Photos: St. Louis Family Playdate at TotSpot Social
      On July 23, St. Louis Magazine celebrated one year of Family Playdates with a special birthday celebration at TotSpot Social, presented by Royal Banks of Missouri and sponsored by Ryan Lawn & Tree. Returning to the venue…
  - (2026-07-24) [St. Louis] Ask George: What summertime dish would you drive across St. Louis for?
      This may be a first: When I asked SLM’s dining team to weigh in, two people picked the same dish—and make that three if you include me. Denise Mueller-Peterson, Madi Lee, and I all chose Louie‘s prosciutto and shaved Par…
  - (2026-07-24) [St. Louis] St. Louis’ 70 Grand bus route is letting riders down, transit group says
      The 70 Grand bus route running from Broadway to Loughborough Commons services an average of 5,000 riders each weekday. However, the route boasting the highest ridership in the city is also frequently plagued by reliabili…
  - (2026-07-24) [St. Louis] Union Pacific’s Big Boy tour fun concealed a serious purpose
      This past weekend, thousands of St. Louisans sweated it out at Union Station to see the 1.2-million pound steam locomotive Big Boy stop by on its cross-country tour. It was a surprisingly emotional experience: Wherever t…
  - (2026-07-24) [St. Louis] Assault case against bedridden 85-year-old gets dismissed—for now
      Last November, 85-year-old Norman Fishel of Olivette suffered a massive hemorrhagic stroke, which left his entire left side paralyzed. Three days after that stroke, while in the intensive care unit at Mercy Hospital, the…

### U.S. Weather + Severe / Climate Outlooks — 185 new of 187 total
  - (2026-07-26) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued July 26 at 5:36AM EDT until July 26 at 8:00PM EDT by NWS Caribou ME
      * WHAT...The warm air temperatures in the 70s to low 80s may cause people to underestimate the dangers of the cold water temperatures which are currently in the 50 to 55 degree range. * WHERE...Coastal Hancock and Coasta…
  - (2026-07-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-26) [Moderate] Special Weather Statement: Special Weather Statement issued July 26 at 5:32AM EDT by NWS Wakefield VA
      Areas of fog may reduce visibility to less than a mile early this morning. If driving, slow down, use your low beam headlights, and leave plenty of distance ahead of you.
  - (2026-07-26) [Severe] Extreme Heat Watch: Extreme Heat Watch issued July 26 at 4:30AM CDT until July 27 at 10:00PM CDT by NWS Omaha/Valley NE
      * WHAT...For the Extreme Heat Warning, dangerously hot conditions with heat index values up to 116. For the Extreme Heat Watch, dangerously hot conditions with heat index values up to 110 possible. * WHERE...In Iowa, Fre…
  - (2026-07-26) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 26 at 4:30AM CDT until July 27 at 7:00AM CDT by NWS Omaha/Valley NE
      * WHAT...Dangerously hot conditions with heat index values up to 115 expected. * WHERE...Portions of west central Iowa and east central and northeast Nebraska. * WHEN...Until 7 AM CDT Monday. * IMPACTS...Heat related ill…
  - (2026-07-26) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 26 at 4:30AM CDT until July 26 at 9:00PM CDT by NWS Omaha/Valley NE
      * WHAT...For the Extreme Heat Warning, dangerously hot conditions with heat index values up to 112. For the Heat Advisory, heat index values up to 108 expected. * WHERE...Portions of east central and southeast Nebraska.…

### Ukrainian Internal News (national + local Kyiv) — 115 new of 123 total
  - (2026-07-26) Росіяни атакували Запоріжжя КАБами, одна людина загинула – ОВА | LEDE: Авіаудар по цивільній інфраструктурі Запоріжжя 26 липня: один загиблий, один поранений.] (uk: Росіяни атакували Запоріжжя КАБами,…
      Авіаудар по цивільній інфраструктурі Запоріжжя 26 липня: один загиблий, один поранений.
  - (2026-07-26) Три дрони за три дні: у Румунії повідомили про третє поспіль збиття БпЛА | LEDE: Румунія втретє збила дрон над своїми водами. Президент Дан підтвердив використання "Шахеду", розслідування трива] (uk:…
      Румунія втретє збила дрон над своїми водами. Президент Дан підтвердив використання "Шахеду", розслідування триває.
  - (2026-07-26) Росіяни вранці атакували Кривий Ріг: зайнявся єдиний у місті "Епіцентр" | LEDE: 26 липня у Кривому Розі через атаку РФ загорівся торговельний центр. Інформація про постраждалих уточнюється.] (uk: Росі…
      26 липня у Кривому Розі через атаку РФ загорівся торговельний центр. Інформація про постраждалих уточнюється.
  - (2026-07-26) Орбан вважає, що Євросоюз не існуватиме через 25 років, бо "нездатний пристосуватися" | LEDE: Віктор Орбан вважає, що ЄС може зникнути без радикальних змін та обмеження влади Єврокомісії.] (uk: Орбан…
      Віктор Орбан вважає, що ЄС може зникнути без радикальних змін та обмеження влади Єврокомісії.
  - (2026-07-26) Сили оборони уразили об’єкт "Чорноморнафтогазу" та ретранслятор у Криму, а також міст на Донеччині | LEDE: У ніч на 26 липня Сили оборони завдали ураження низці важливих воєнних і воєнно-економ] (uk:…
      У ніч на 26 липня Сили оборони завдали ураження низці важливих воєнних і воєнно-економічних цілей противника, серед яких об'єкт "Чорноморнафтогазу", ретранслятор управління ударними БпЛА, а також міст на окупованій части…
  - (2026-07-26) У Латвії наполягають на відмові від дорожніх знаків, що вказують на Росію і Білорусь | LEDE: ] (uk: У Латвії наполягають на відмові від дорожніх знаків, що вказують на Росію і Біло)

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-24) Arizona Supreme Court: A & P RANCH LTD v. COCHISE COUNTY
  - (2026-07-24) U.S. Court of Appeals, 11th Cir.: Bay United Holdings, LLC. v. INXS VII, LLC
  - (2026-07-24) U.S. Court of Appeals, 10th Cir.: Horocofsky v. City of Lawrence, Kansas
  - (2026-07-24) Alaska Supreme Court: Darren M. v. Destiny D
  - (2026-07-24) U.S. Court of Appeals, 6th Cir.: Christopher Hemwall v. Adam Douglas
  - (2026-07-24) U.S. Court of Appeals, 6th Cir.: United States v. Rishad Williams

### IT, InfoSys & cybersecurity news (last 7 days) — 57 new of 57 total
  - (2026-07-26) [The Register] The last Space Shuttle returned to Earth 15 years ago
      So, how are those commercial replacements working out for you, NASA?
  - (2026-07-26) [TechCrunch] Monday.com is the latest tech company to blame AI for layoffs — here are 20 others
      A running look — in reverse chronological order — at the bigger tech companies that have announced significant layoffs this year with AI as a stated factor.
  - (2026-07-25) [BleepingComputer] Steam forum ClickFix attacks infect gamers with XMRig cryptominers
      Steam discussion forums are being abused in ClickFix attacks that pretend to be fixes for game and computer problems but actually infect devices with cryptominers. [...]
  - (2026-07-25) [BleepingComputer] Malicious sites use JavaScript to build malware in browser memory
      A massive malvertising campaign is using fake Solana, Luno, and TradingView webpages with malicious JavaScript that instructs browsers to assemble malware directly in memory. [...]
  - (2026-07-25) [BleepingComputer] ShinyHunters data leaks fuel $2,000 sextortion email scam
      Threat actors are using email addresses exposed in data breaches leaked by the ShinyHunters extortion group to send sextortion emails demanding $2,000 in Bitcoin. [...]
  - (2026-07-25) [BleepingComputer] OpenAI confirms ChatGPT is down worldwide
      ChatGPT, the famous artificial intelligence chatbot that allows users to converse with various personalities and topics, has connectivity issues worldwide. [...]

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-25) [Tangney Jeffrey] Form 4 (Reporting)
      filed 2026-07-25 01:59 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Doximity, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:59 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Sams Louise S] Form 4 (Reporting)
      filed 2026-07-25 01:51 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:51 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Auguste Laurent] Form 4 (Reporting)
      filed 2026-07-25 01:49 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:49 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB

### Government Action: Sanctions + Procurement + Foreign Agents — 37 new of 120 total
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses - Office of Foreign Assets Cont…
      Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses Office of Foreign Assets Control (.gov)
  - (2026-07-20) [OFAC] Russia-related Designations Updates - Office of Foreign Assets Control (.gov)
      Russia-related Designations Updates Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] CJNG-Linked Networks - Office of Foreign Assets Control (.gov)
      CJNG-Linked Networks Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] CJNG Leadership - Office of Foreign Assets Control (.gov)
      CJNG Leadership Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 31 new of 131 total
  - (2026-07-26) [Polymarket] Will Bitcoin reach $75,000 by December 31, 2026?
      This market will resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between the creation of this market through 11:59 PM ET on the last day of the year specified in the title has a final "High" price…
  - (2026-07-26) [Polymarket] Will Marco Rubio win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-26) [Polymarket] UNSC Resolution Endorsing Final U.S.-Iran Deal by December 31?
      On June 14, 2026, the United States and Iran announced a written diplomatic agreement, which stated in Clause 14 that it would culminate in a “final deal” to be endorsed by a binding United Nations Security Council resol…
  - (2026-07-26) [Polymarket] Will Lewis Hamilton win the 2026 F1 Hungarian Grand Prix?
      This is a polymarket on the winner of the 2026 F1 Hungarian Grand Prix, scheduled for Jul 26, 2026. If the 2026 F1 Hungarian Grand Prix is canceled or rescheduled to a date after Aug 2, 2026, this market will resolve to…
  - (2026-07-26) [Polymarket] Will Sabrina Carpenter be the top artist for 2026?
      Spotify releases an annual report of its most streamed artist (see: https://newsroom.spotify.com/2025-12-03/wrapped-top-artists-songs-albums-podcasts-audiobooks/). This market refers to the most streamed Spotify artist f…
  - (2026-07-26) [Polymarket] Will Eric Trump win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-26) [Russia oil sanctions perimeter · keywords] How America Sanctions are Building a Post - Dollar World
      juancole.com · English · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · keywords] Britain and its NATO allies face direct challenge from Putin within month to test Burnham and probe for cracks in the alliance while Trump distracted with I…
      dailymail.com · English · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · keywords] Caucasian Knot | The private house was damaged during a UAV attack in Kuban .
      eng.kavkaz-uzel.eu · English · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · keywords] EU targets Georgian refinery with delayed ban over processing of Russian crude
      weeklyblitz.net · English · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · keywords] Putin next move ? Five Russian attack scenarios NATO must prepare for
      ynetnews.com · English · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · keywords] Oil back at $100 : Time to worry
      japanherald.com · English · tone NA

### Government & military aircraft airborne (OpenSky) — 20 new of 20 total
  - (2026-07-26) RFF07 (Portugal)
      icao24: 496ca7 · position: (37.0137, -7.97) · on ground · 37km/h
  - (2026-07-26) JAF3LV (Belgium)
      icao24: 44d1ba · position: (42.7431, 7.411) · alt: 11582m · 871km/h
  - (2026-07-26) JAF63N (Belgium)
      icao24: 44d1a6 · position: (50.9026, 4.4852) · on ground
  - (2026-07-26) JAF9CK (Belgium)
      icao24: 44d1a7 · position: (50.9267, 3.1114) · alt: 2743m · 591km/h
  - (2026-07-26) JAF99Y (Belgium)
      icao24: 44d1a5 · position: (46.4339, -1.7462) · alt: 11582m · 770km/h
  - (2026-07-26) JAF7CB (Belgium)
      icao24: 44d1b3 · position: (45.7978, -0.299) · alt: 11582m · 751km/h

### Prediction Markets — most-traded (Polymarket) — 19 new of 20 total
  - (2026-07-26) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,714,033 · resolves 2026-06-01
  - (2026-07-26) Israel x Iran ceasefire continues through July 25?
      yes price: 100% · 24h volume: $914,939 · resolves 2026-07-25
  - (2026-07-26) LoL: LNG Esports vs Ninjas in Pyjamas - Game 2 Winner
      yes price: 0% · 24h volume: $755,399 · resolves 2026-07-26
  - (2026-07-26) Will the U.S. invade Iran before 2027?
      yes price: 22% · 24h volume: $658,653 · resolves 2026-12-31
  - (2026-07-26) Will the Fed decrease interest rates by 50+ bps after the July 2026 meeting?
      yes price: 0% · 24h volume: $625,479 · resolves 2026-07-29
  - (2026-07-26) Strait of Hormuz traffic returns to normal by August 31?
      yes price: 16% · 24h volume: $614,958 · resolves 2026-08-31

### U.S. Federal Action — 12 new of 12 total
  - (2026-07-27) Modernizing Reactor Licensing, Safety Oversight, and Siting Practices; Correction
      The U.S. Nuclear Regulatory Commission (NRC) is correcting a notice published in the Federal Register on July 16, 2026, regarding the modernization of reactor licensing, safety oversight, and siting practices to address…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Report and Order that promotes the deployment of submarine cables while strengthening national security interests in connection…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Further Notice of Proposed Rulemaking (Second FNPRM) that seeks to further prevent evolving national security risks associated…
  - (2026-07-27) Modernizing Package Certification Requirements
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its regulations governing the packaging and transportation of radioactive material. This proposed action is responsive to several executive orders and th…
  - (2026-07-27) Updating Website and Contact Information, and Authorizations for Payments for Legal Services
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is adopting a final rule to update website and contact information in certain parts of the Code of Federal Regulations (CFR). Additionally, OFAC is…
  - (2026-07-27) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action
      NMFS announces an inseason action for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds fishing dates in August and September in the Co…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 10 new of 40 total
  - (2026-07-26) MOVER ▼ Elon Musk — $725.12B ($-72.47B since yesterday)
      United States · Technology · source: Tesla, SpaceX
  - (2026-07-26) MOVER ▼ Larry Page — $263.19B ($-21.14B since yesterday)
      United States · Technology · source: Google
  - (2026-07-26) MOVER ▼ Sergey Brin — $242.85B ($-19.43B since yesterday)
      United States · Technology · source: Google
  - (2026-07-26) MOVER ▼ Mark Zuckerberg — $204.33B ($-17.23B since yesterday)
      United States · Technology · source: Facebook
  - (2026-07-26) MOVER ▼ Larry Ellison — $151.89B ($-15.15B since yesterday)
      United States · Technology · source: Oracle
  - (2026-07-26) MOVER ▲ Michael Dell — $237.33B (+$14.16B since yesterday)
      United States · Technology · source: Dell Technologies

### USGS earthquakes (M4.5+, past day) — 7 new of 7 total
  - (2026-07-26) M 5.8 - 99 km SE of Atka, Alaska
      M5.8 · 99 km SE of Atka, Alaska · depth 10 km
  - (2026-07-26) M 5.1 - Tristan da Cunha region
      M5.1 · Tristan da Cunha region · depth 10 km
  - (2026-07-25) M 5.0 - 91 km SE of Atka, Alaska
      M5.0 · 91 km SE of Atka, Alaska · depth 40.779 km
  - (2026-07-25) M 4.9 - Kermadec Islands, New Zealand
      M4.9 · Kermadec Islands, New Zealand · depth 55.602 km
  - (2026-07-26) M 4.7 - 18 km ESE of Monterrey, Colombia
      M4.7 · 18 km ESE of Monterrey, Colombia · depth 12.362 km
  - (2026-07-25) M 4.5 - 72 km SE of Severo-Kuril’sk, Russia
      M4.5 · 72 km SE of Severo-Kuril’sk, Russia · depth 50.022 km

### CISA Known Exploited Vulnerabilities (last 14d) — 6 new of 16 total
  - (2026-07-22) CVE-2026-16232 · Check Point SmartConsole: Check Point SmartConsole Improper Authentication Vulnerability
      vendor: Check Point · product: SmartConsole · CISA remediation by 2026-07-25
  - (2026-07-22) CVE-2026-50522 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-25
  - (2026-07-21) CVE-2026-60137 · WordPress Core: WordPress Core SQL Injection Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-08-04
  - (2026-07-21) CVE-2026-63030 · WordPress Core: WordPress Core Interpretation Conflict Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-07-24
  - (2026-07-21) CVE-2026-0770 · Langflow Langflow: Langflow Inclusion of Functionality from Untrusted Control Sphere Vulnerability
      vendor: Langflow · product: Langflow · CISA remediation by 2026-07-24
  - (2026-07-21) CVE-2021-27137 · DD-WRT DD-WRT: DD-WRT Stack-Based Buffer Overflow Vulnerability
      vendor: DD-WRT · product: DD-WRT · CISA remediation by 2026-07-24

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-26) [Marginal Revolution] The demand for human enhancement technologies
      When a new technology promises large private benefits but may impose social costs that markets do not price, demand need not reveal how citizens want it governed. We examine this using a nationally representative U.S. su…
  - (2026-07-26) [Marginal Revolution] The common sense of Fareed Zakaria
      This is one of the best Op-Eds you will read this year, though it deliberately deemphasizes the personal (no one is attacked) in a manner that will result in less attention. Better to write the truth! Excerpt: Why has th…
  - (2026-07-25) [Marginal Revolution] Odysseus notes
      The subsection of the Georgi Gospodinov novel runs like this: The Shortest Novel About Odysseus After His Return Home One night, now old and flabby and starting to forget, he leaves his home secretly. He’s sick of everyt…
  - (2026-07-24) [Conversable Economist] Occupational Licensing: US and International
      The potential benefit of having the government require that certain jobs require an official license is quality control and protection. Personally, I rather like knowing that my nurse or doctor or dentist has gone throug…
  - (2026-07-23) [Conversable Economist] The Job Market for Recent College Graduates
      When I talk with college students, and even high school students, a number of them have a profound sense that it is tremendously hard to find a job coming out of college. The level fear seems to me exaggerated, but some…
  - (2026-07-22) [Conversable Economist] Chokepoints for Ocean Trade: Strait of Hormuz, and What Else?
      For those who can be fuzzy on global geography, like me, it’s perhaps useful to say that the Persian Gulf is a body of water bordered by eight countries: Bahrain, Iran, Iraq, Kuwait, Qatar, Saudi Arabia, the United Arab…

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=17, 14d-median=17
- state_bills: today=0, 7d-median=70, 14d-median=70
- state_news: today=446, 7d-median=711, 14d-median=711
- local_news: today=213, 7d-median=246, 14d-median=246
- foreign_news: today=951, 7d-median=1024, 14d-median=1024
- chinese_internal: today=251, 7d-median=299, 14d-median=299
- russian_internal: today=856, 7d-median=856, 14d-median=856
- ukrainian_internal: today=123, 7d-median=138, 14d-median=138
- ukraine_theater: today=457, 7d-median=457, 14d-median=457
- paper_bets: today=131, 7d-median=143, 14d-median=143
- weather: today=187, 7d-median=177, 14d-median=177
- macro: today=21, 7d-median=21, 14d-median=21
- markets: today=21, 7d-median=21, 14d-median=21
- markets_global: today=47, 7d-median=47, 14d-median=47
- sanctions_procurement: today=120, 7d-median=119, 14d-median=119
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=40, 7d-median=34, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=0, 7d-median=9, 14d-median=9
- gdelt_gkg: today=25, 7d-median=47, 14d-median=47
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=20, 7d-median=20, 14d-median=20
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=249, 7d-median=101, 14d-median=101
- usgs_quakes: today=7, 7d-median=23, 14d-median=23
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- tech_news: today=57, 7d-median=57, 14d-median=57
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*