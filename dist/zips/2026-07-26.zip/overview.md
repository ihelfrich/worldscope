# WORLDSCOPE morning brief — 2026-07-26

## Headline
1664 new items across 21 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (364) · World leaders & government officials (324) · Russian Internal News (state + in-exile) (262) · U.S. Weather + Severe / Climate Outlooks (179) · Chinese Internal News (159) · Ukraine Theater (total-war monitoring) (128) · State-Level News (56) · Local News: St. Louis + Atlanta (37) · Ukrainian Internal News (national + local Kyiv) (32) · Sanctions & Designations (recent) (30) · GDELT GKG — themes / entities / watch areas (25) · Government & military aircraft airborne (OpenSky) (19)

## What changed today
### International News + Multilateral Institutions — 364 new of 952 total
  - (2026-07-26) [Global] What we know so far about the Berlin Pride ramming attack
      A police manhunt is underway after a suspect rammed a car into a crowd at a Pride event in the German capital on Saturday night.
  - (2026-07-26) [Global] France battles fire 'whirlwinds' as another 55,000 evacuated
      More than 340,000 people have now been evacuated from wildfires in France and Spain.
  - (2026-07-26) [Global] Left-wing Democrats are on a winning run - but can they lure back crucial swing voters?
      They have seen a flurry of recent wins, but Michigan will test their ability to win back working-class voters in crucial states.
  - (2026-07-26) [Global] The notorious Cameroonian prison with its own record label
      New Bell's inmates have become mini stars, recording songs and music videos from the confines of the jail.
  - (2026-07-26) [Global] Would you pay $58.5m to live in this iconic New York building?
      With its renovation nearly complete, the Flatiron is ready for its next - and most extravagant - phase of life.
  - (2026-07-25) [Global] What Love Island tells us about the changing face of dating
      From women making the first move to shifting relationship dynamics, Love Island has become a window into Britain's evolving dating culture

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Russian Internal News (state + in-exile) — 262 new of 806 total
  - (2026-07-26) В Ростовской области прошел ураган с ливнями и грозами. Один человек погиб, еще 13 пострадали. Задерживаются около 90 поездов | LEDE: В Ростовской области в субботу, 25 июля, прошел мощный у] (ru: В Р…
      В Ростовской области в субботу, 25 июля, прошел мощный ураган с ливнями и грозами, затронувший областной центр и другие крупные города.
  - (2026-07-26) The New York Times: Трамп отказался от дальнейших ударов по Ирану. Его команда опасается истощения американской ПВО на Ближнем Востоке | LEDE: Дональд Трамп отложил планы по резкой эскалации] (ru: The…
      Дональд Трамп отложил планы по резкой эскалации американского военного давления на Иран, пишет The New York Times со ссылкой на источники.
  - (2026-07-26) МИД Ирана обвинил Украину в атаке на иранское торговое судно в Каспийском море | LEDE: МИД Ирана заявил, что украинские военные утром 25 июля атаковали иранское торговое судно в Каспийском м] (ru: МИД…
      МИД Ирана заявил, что украинские военные утром 25 июля атаковали иранское торговое судно в Каспийском море.
  - (2026-07-26) Россия атаковала Киев ракетами, пострадали три человека. В Харькове — один погибший в результате удара беспилотников | LEDE: Российские войска атаковали Киев. Повреждения есть в Шевченковско] (ru: Рос…
      Российские войска атаковали Киев. Повреждения есть в Шевченковском, Соломенском и Деснянском районе, сообщил мэр Виталий Кличко.
  - (2026-07-26) В Берлине во время ЛГБТ-прайда автомобиль въехал в толпу. Один человек погиб, 16 ранены. Террориста ищут. Главное | LEDE: В Берлине во время ЛГБТ-прайда автомобиль въехал в толпу людей. Один] (ru: В Б…
      В Берлине во время ЛГБТ-прайда автомобиль въехал в толпу людей. Один человек погиб, еще 16 пострадали. Часть из них получила тяжелые травмы.
  - (2026-07-26) В Запорожье прогремел взрыв | LEDE: ] (ru: В Запорожье прогремел взрыв)

### U.S. Weather + Severe / Climate Outlooks — 179 new of 183 total
  - (2026-07-26) [Moderate] Special Weather Statement: Special Weather Statement issued July 26 at 5:07AM EDT by NWS Wilmington NC
      At 507 AM EDT, Doppler radar was tracking a cluster of strong thunderstorms near Cades, or near Lake City, moving southeast at 30 mph. HAZARD...Wind gusts up to 40 mph. SOURCE...Radar indicated. IMPACT...Gusty winds coul…
  - (2026-07-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-26) [Moderate] Special Weather Statement: Special Weather Statement issued July 26 at 3:58AM CDT by NWS Paducah KY
      Expect patchy fog to perhaps be locally dense at times early this morning. In some locations, the fog may be light but there could be a low hanging overcast cloud. In any case, be prepared for the chance of encountering…
  - (2026-07-26) [Moderate] Heat Advisory: Heat Advisory issued July 26 at 3:58AM CDT until July 26 at 9:00PM CDT by NWS Lubbock TX
      * WHAT...Heat index values up to 108 expected. * WHERE...Childress, Cottle, Motley, and Hall Counties. * WHEN...From 1 PM this afternoon to 9 PM CDT this evening. * IMPACTS...Hot temperatures and high humidity may cause…
  - (2026-07-26) [Moderate] Rip Current Statement: Rip Current Statement issued July 26 at 4:56AM EDT until July 27 at 8:00AM EDT by NWS Boston/Norton MA
      * WHAT...Dangerous rip currents. * WHERE...Nantucket MA County. * WHEN...Through Monday morning. * IMPACTS...Rip currents can sweep even the best swimmers away from shore into deeper water.
  - (2026-07-26) [Moderate] Rip Current Statement: Rip Current Statement issued July 26 at 4:56AM EDT until July 27 at 8:00AM EDT by NWS Boston/Norton MA
      * WHAT...Dangerous rip currents. * WHERE...Barnstable MA County. * WHEN...Through Monday morning. * IMPACTS...Rip currents can sweep even the best swimmers away from shore into deeper water.

### Chinese Internal News — 159 new of 250 total
  - (2026-07-26) 恶毒！曲婉婷竟主动认领了“冰雪女王”的称呼，这是羞辱东北下岗工人的梗啊 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTFBZWmZUUk8xcmNablRhY0dubmJnd0szQzFXc3hDdkZSTEM5MG5kbGVtdERpUjNFdm1lQ01aNVZHXzJBbzRSTX] (zh:…
      恶毒！曲婉婷竟主动认领了“冰雪女王”的称呼，这是羞辱东北下岗工人的梗啊 风闻
  - (2026-07-26) 马斯克对话经济学人主编，探讨AI对于人类社会未来的影响 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE12ZVE3QUJ0U0JhSEpRWEFhUEVRc3hlSUp3eFRubnRPUkp6NUJsSVI5ZW92aHYwQzZ4SDNOYkhYTEFtN3YxY1FNdkt6MU] (zh:…
      马斯克对话经济学人主编，探讨AI对于人类社会未来的影响 风闻
  - (2026-07-26) 我高三时，妈妈每周给我50的伙食费，舅舅再给个10块20块的 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE5BamZUcGQxUjlvSUNiX1FaSTlNRGUxd1BrLUpwM243UUk3SGYwSFVjbWhEQnFocjhwUTRHWWo2QmVnRjNYUFpTNWZ] (zh:…
      我高三时，妈妈每周给我50的伙食费，舅舅再给个10块20块的 风闻
  - (2026-07-26) 托卡耶夫当面提议“冻结俄乌冲突”，普京默不作声 - 观察 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9SSkpkeFBZQWdIdkVfSk9QQ3FkTW9iRHVGYVluVVhiaW9zeUpMUko2YmZCZVF2bkZHUzRJdHkwUVBvZ3ZNclRyakN2S1FSSF] (zh:…
      托卡耶夫当面提议“冻结俄乌冲突”，普京默不作声 观察
  - (2026-07-26) 对海外华人一定要阶级分析！ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE5waC1TTm5WN0doVnFIQjZzcFRhcG1XYXY0RE5VeWdvU0w1TlNJcUZ3UWRxZDNxT1ZWZDBKOTJFS1VtNmhydE04UGpQNloydnFoZlBPeEli] (zh:…
      对海外华人一定要阶级分析！ 风闻
  - (2026-07-25) 从“欧洲穷亲戚”到“全村最靓的仔”，这个国家只用了短短一代人 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1MRFlCcGV5ekRuY2prMjJGVkxILVhQVDhNckhwT0JSU25RSXhuSGdVNXUxNG5wem5RSmdnbDRnT2RSMmtOLXVVd29] (zh:…
      从“欧洲穷亲戚”到“全村最靓的仔”，这个国家只用了短短一代人 风闻

### Ukraine Theater (total-war monitoring) — 128 new of 457 total
  - (2026-07-26) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-25) [FIRMS] thermal anomaly 52.767, 33.205 (FRP 4.03 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 2348Z, FRP 4.03 MW
  - (2026-07-25) [FIRMS] thermal anomaly 52.768, 33.198 (FRP 3.32 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 2348Z, FRP 3.32 MW
  - (2026-07-25) [FIRMS] thermal anomaly 52.808, 32.223 (FRP 1 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 2348Z, FRP 1 MW
  - (2026-07-25) [FIRMS] thermal anomaly 52.804, 32.222 (FRP 0.6 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 2348Z, FRP 0.6 MW
  - (2026-07-25) [FIRMS] thermal anomaly 52.849, 29.987 (FRP 1.32 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-25 2348Z, FRP 1.32 MW

### State-Level News — 56 new of 446 total
  - (2026-07-26) [Connecticut] How a CT filmmaker’s first feature won at Sundance
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/06/RICKY-FILM-0510-0624-SG-05-Edit-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async…
  - (2026-07-26) [Connecticut] P.T. Barnum’s Bridgeport was no circus
      <img width="675" height="426" src="https://ctmirror.org/wp-content/uploads/2026/07/bridgeport-connecticut-railroad-station.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-07-26) [Maine] How do Mainers love heat pumps? Let me count the ways … | Opinion
      <img width="1024" height="768" src="https://www.pressherald.com/wp-content/uploads/sites/4/2025/11/IMG_20220510_123621389_HDR-Large.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" d…
  - (2026-07-26) [Maine] An incomplete portrait of Sen. Collins on A1 | Letter
      The Sunday Telegram’s recent front-page coverage of Sen. Susan Collins has been a more effective endorsement of her than any editorial or op-ed you could print. Any fair discussion of Collins’ earmarks and influence over…
  - (2026-07-26) [Maine] Embrace the sounds of summer in Maine | Opinion
      <img width="1024" height="683" src="https://w2pcms.com/wp-content/uploads/sites/10/2022/04/Birdwatching13.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" sizes="(ma…
  - (2026-07-26) [Maine] Sonny’s first summer has been full of firsts | Victoria Hugo-Vidal
      <img width="1024" height="724" src="https://www.pressherald.com/wp-content/uploads/sites/4/2026/07/25160637_sj.CITheatP0629319.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decodi…

### Local News: St. Louis + Atlanta — 37 new of 202 total
  - (2026-07-26) [St. Louis] Heat advisory begins Sunday around St. Louis - How hot will it get?
      A heat advisory begins Sunday in the St. Louis region with dangerous heat expected over the next few days.
  - (2026-07-26) [St. Louis] World Naked Bike Ride rolls through St. Louis
      Hundreds of cyclists took to the streets of St. Louis on Saturday for the 18th annual World Naked Bike Ride.
  - (2026-07-25) [St. Louis] Woman shot Saturday in Ferguson during neighborhood event
      One woman was shot and suffered serious injuries Saturday afternoon during a neighborhood event in Ferguson, police say.
  - (2026-07-26) [St. Louis] Pallante matches season high with 8 Ks, to lead Cardinals to a 7-0 win over the Reds
      T. LOUIS (AP) — Andre Pallante matched his season high with eight strikeouts in seven strong innings, and the St. Louis Cardinals scored six runs in the bottom of the sixth in a 7-0 win over the Cincinnati Reds on Saturd…
  - (2026-07-26) [St. Louis] St. Louis City beat short-handed Rapids 1-0 for 4th straight win
      Tomas Ostrak scored his first goal this season in the 83rd minute to help St. Louis City beat the short-handed Colorado Rapids 1-0 on Saturday night for their fourth win in a row.
  - (2026-07-26) [St. Louis] Comic-Con 2026: David Jonsson is new Black Panther, Ryan Gosling joins Marvel as Ghost Rider
      Here's the latest from Comic-Con 2026.

### Ukrainian Internal News (national + local Kyiv) — 32 new of 121 total
  - (2026-07-26) Три дрони за три дні: у Румунії повідомили про третє поспіль збиття БпЛА | LEDE: Президент Румунії Нікушор Дан заявив про нове збиття румунськими ВПС безпілотника над територією країни – це тре] (uk:…
      Президент Румунії Нікушор Дан заявив про нове збиття румунськими ВПС безпілотника над територією країни – це третій такий інцидент за останні три дні.
  - (2026-07-26) Росіяни вранці атакували Кривий Ріг: зайнявся єдиний у місті "Епіцентр" | LEDE: 26 липня у Кривому Розі через атаку РФ загорівся торговельний центр. Інформація про постраждалих уточнюється.] (uk: Росі…
      26 липня у Кривому Розі через атаку РФ загорівся торговельний центр. Інформація про постраждалих уточнюється.
  - (2026-07-26) Орбан вважає, що Євросоюз не існуватиме через 25 років, бо "нездатний пристосуватися" | LEDE: Колишній прем'єр Угорщини Віктор Орбан у програмному виступі у літньому таборі Тушваньош у Румунії ] (uk:…
      Колишній прем'єр Угорщини Віктор Орбан у програмному виступі у літньому таборі Тушваньош у Румунії спрогнозував зникнення Євросоюзу, якщо він не реформується.
  - (2026-07-26) Сили оборони уразили об’єкт "Чорноморнафтогазу" та ретранслятор у Криму, а також міст на Донеччині | LEDE: У ніч на 26 липня Сили оборони завдали ураження низці важливих воєнних і воєнно-економ] (uk:…
      У ніч на 26 липня Сили оборони завдали ураження низці важливих воєнних і воєнно-економічних цілей противника, серед яких об'єкт "Чорноморнафтогазу", ретранслятор управління ударними БпЛА, а також міст на окупованій части…
  - (2026-07-26) У Латвії наполягають на відмові від дорожніх знаків, що вказують на Росію і Білорусь | LEDE: ] (uk: У Латвії наполягають на відмові від дорожніх знаків, що вказують на Росію і Біло)
  - (2026-07-26) Зеленський: Більше половини запущених Росією ракет по Україні за тиждень – це балістика | LEDE: Президент Володимир Зеленський повідомив, що протягом тижня російські загарбники застосували прот] (uk:…
      Президент Володимир Зеленський повідомив, що протягом тижня російські загарбники застосували проти України майже 1700 дронів, понад 1630 авіабомб та 95 ракет різних типів, серед них більше половини – балістика.

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-26) [Russia oil sanctions perimeter · themes] La gestión de catástrofes en España , atrapada en la guerra política
      ideal.es · Spanish · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] Hobart :: A Trip to the Desert by
      hobartpulp.com · English · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] Μέση Ανατολή : Μετατόπιση της έντασης στην Ερυθρά Θάλασσα με Χούθι κατά ...
      capital.gr · Greek · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] K . Budrys lankysis Pietryčių Azijoje : stiprins ekonominius ryšius su Tailandu ir Vietnamu
      lrytas.lt · Lithuanian · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] Iran sanoo myyneensä öljyä 18 miljardilla dollarilla sodan aikana
      hameensanomat.fi · Finnish · tone NA
  - (2026-07-26) [Russia oil sanctions perimeter · themes] 和众汇富研究手记 ： 花旗上调中国股市至超配 _ 产业资讯 _ 行业 _ 中金在线
      hy.stock.cnfol.com · Chinese · tone NA

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-07-26) JAF76T (Bulgaria)
      icao24: 4520aa · position: (48.7269, 2.3717) · on ground · 13km/h
  - (2026-07-26) JAF3LV (Belgium)
      icao24: 44d1ba · position: (39.4868, 7.8275) · alt: 11582m · 860km/h
  - (2026-07-26) JAF63N (Belgium)
      icao24: 44d1a6 · position: (50.2592, 5.6665) · alt: 6431m · 723km/h
  - (2026-07-26) JAF9CK (Belgium)
      icao24: 44d1a7 · position: (48.269, 3.3143) · alt: 10965m · 755km/h
  - (2026-07-26) JAF99Y (Belgium)
      icao24: 44d1a5 · position: (44.1536, -4.0991) · alt: 11582m · 750km/h
  - (2026-07-26) JAF7CB (Belgium)
      icao24: 44d1b3 · position: (43.3582, -2.0943) · alt: 11582m · 738km/h

### Court opinions of consequence (federal & state) — 13 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Jenkins v. Prime Insurance
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Miller v. CNH Industrial America
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: United States v. Threatt
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Spiehs v. Morgan
  - (2026-07-21) U.S. Court of Appeals, 4th Cir.: United States v. Bisheem Jones
  - (2026-07-21) Connecticut Supreme Court: Campelli v. Mansfield

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-07-26) LoL: LNG Esports vs Ninjas in Pyjamas - Game 2 Winner
      yes price: 0% · 24h volume: $745,895 · resolves 2026-07-26
  - (2026-07-26) Strait of Hormuz traffic returns to normal by July 31?
      yes price: 1% · 24h volume: $456,768 · resolves 2026-07-31
  - (2026-07-26) Israel x Iran ceasefire continues through July 31?
      yes price: 86% · 24h volume: $453,090 · resolves 2026-07-31
  - (2026-07-26) Bab el-Mandeb Strait effectively closed by July 31?
      yes price: 0% · 24h volume: $412,988 · resolves 2026-07-31
  - (2026-07-26) LoL: LNG Esports vs Ninjas in Pyjamas - Game 1 Winner
      yes price: 0% · 24h volume: $407,076 · resolves 2026-07-26
  - (2026-07-26) LoL: ThunderTalk Gaming vs EDward Gaming (BO3) - LPL Group Ascend
      yes price: 50% · 24h volume: $380,823 · resolves 2026-07-26

### Paper Trading Scorecard — 6 new of 132 total
  - (2026-07-26) [Polymarket] Will Sabrina Carpenter be the top artist for 2026?
      Spotify releases an annual report of its most streamed artist (see: https://newsroom.spotify.com/2025-12-03/wrapped-top-artists-songs-albums-podcasts-audiobooks/). This market refers to the most streamed Spotify artist f…
  - (2026-07-26) [Manifold] Will Asahifuji (Ochirsaikhan/Ochiru) go undefeated through the end of 2026?
  - (2026-07-26) [Manifold] Will "Duane Arnold" make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-07-26) [Manifold] Will the perpetrator of the attack on CSD Berlin 2026 be caught within two weeks?
  - (2026-07-26) [Manifold] Will Trump announce he is running for President in the 2028 election?
  - (2026-07-26) [Manifold] Netanyahu hugs/embraces Trump and/or Zelenskyy in July 2026?

### GDACS — global disaster alerts — 6 new of 217 total
  - (2026-07-26) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.8M, Depth:10km
  - (2026-07-26) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 5.8M, Depth:10km
  - (2026-07-23) [Green] Forest fires in France
      Wildfire · Green alert · France · Green impact for forestfire in 6126 ha
  - (2026-07-23) [Green] Forest fires in France
      Wildfire · Green alert · France · Green impact for forestfire in 6126 ha
  - (2026-07-18) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 31628 ha
  - (2026-07-18) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 31628 ha

### USGS earthquakes (M4.5+, past day) — 5 new of 7 total
  - (2026-07-26) M 5.8 - 99 km SE of Atka, Alaska
      M5.8 · 99 km SE of Atka, Alaska · depth 10 km
  - (2026-07-26) M 5.1 - Tristan da Cunha region
      M5.1 · Tristan da Cunha region · depth 10 km
  - (2026-07-26) M 4.7 - 18 km ESE of Monterrey, Colombia
      M4.7 · 18 km ESE of Monterrey, Colombia · depth 12.362 km
  - (2026-07-25) M 4.5 - 72 km SE of Severo-Kuril’sk, Russia
      M4.5 · 72 km SE of Severo-Kuril’sk, Russia · depth 50.022 km
  - (2026-07-25) M 4.5 - 56 km SE of Tuensang, India
      M4.5 · 56 km SE of Tuensang, India · depth 92.961 km

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 120 total
  - (2026-07-26) [USASpending] $10,793,073,671 → ALLIANCE FOR ENERGY INNOVATION, LLC: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWAB
      Agency: Department of Energy. Description: AWARD OF CONTRACT TO MANAGE AND OPERATE THE NATIONAL RENEWABLE ENERGY LABORATORY
  - (2026-07-26) [USASpending] $10,521,604,426 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration. Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF…
  - (2026-07-26) [USASpending] $1,150,643,464 → LEIDOS, INC.: MILITARY AND FAMILY LIFE COUNSELING. REQUIREMENT FOR WORLDWI
      Agency: General Services Administration. Description: MILITARY AND FAMILY LIFE COUNSELING. REQUIREMENT FOR WORLDWIDE NON MEDICAL CONFIDENTIAL COUNSELING SERVICES.
  - (2026-07-26) [USASpending] $912,901,574 → REED TECHNOLOGY AND INFORMATION SERVICES LLC: PATENT DATA AND DOCUMENT MANAGEMENT (PD&DM)
      Agency: Department of Commerce. Description: PATENT DATA AND DOCUMENT MANAGEMENT (PD&DM)

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-26) [Marginal Revolution] The demand for human enhancement technologies
      When a new technology promises large private benefits but may impose social costs that markets do not price, demand need not reveal how citizens want it governed. We examine this using a nationally representative U.S. su…
  - (2026-07-26) [Marginal Revolution] The common sense of Fareed Zakaria
      This is one of the best Op-Eds you will read this year, though it deliberately deemphasizes the personal (no one is attacked) in a manner that will result in less attention. Better to write the truth! Excerpt: Why has th…

### IT, InfoSys & cybersecurity news (last 7 days) — 1 new of 47 total
  - (2026-07-26) [TechCrunch] Monday.com is the latest tech company to blame AI for layoffs — here are 20 others
      A running look — in reverse chronological order — at the bigger tech companies that have announced significant layoffs this year with AI as a stated factor.

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=22, 14d-median=20; carrying terms: final, special, amendments, provide, action, safety, coast, regulatory, amendment, proposing, certain, published
- state_bills: today=0, 7d-median=124, 14d-median=124; carrying terms: institution, creates, years, commission, further, members, course, prescribed, committee, school, identify, contact
- state_news: today=446, 7d-median=765, 14d-median=756; carrying terms: rural, found, biddeford, scrutiny, members, committee, reached, costs, businesses, seats, effort, across
- local_news: today=202, 7d-median=227, 14d-median=236; carrying terms: found, charles, width, years, shooting, school, watch, uploads, final, family, across, deadly
- foreign_news: today=952, 7d-median=1036, 14d-median=1030; carrying terms: found, rural, demands, suffered, further, london, xianghe, heavy, members, alleged, review, threats
- chinese_internal: today=250, 7d-median=303, 14d-median=301; carrying terms: chinese, cbmiykfvx, politics, cbmickfvx, cbmicefvx, market, cbmib, cbmiw, caixin, cbmiyefvx, google, lxtfb
- russian_internal: today=806, 7d-median=982, 14d-median=893; carrying terms: found, istories, reuters, bloomberg, journal, httperror, wildberries, error, gazeta, social, europe, novayagazeta
- ukrainian_internal: today=121, 7d-median=125, 14d-median=132; carrying terms: found, civilian, sanctions, volodymyr, syrsky, nationwide, oleksandr, babel, across, ships, hromadske, continue
- ukraine_theater: today=457, 7d-median=443, 14d-median=424; carrying terms: aytvmbmfoalmynwfxafk, prisoners, lnynjon, suvzbc, vzxhjdxppbzdwegdz, enterprises, mjvowflbuw, members, fnvjlcxzwetletjbhuv, fqzvzdk, zocum, robots
- paper_bets: today=132, 7d-median=141, 14d-median=144; carrying terms: sachs, votes, eliminated, retirement, senate, succeed, fusion, playoffs, price, georgia, brazilian, determined
- weather: today=183, 7d-median=183, 14d-median=174; carrying terms: valley, hurricane, showers, moderate, producing, weather, strong, hazard, lower, heavy, lincoln, water
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: dexchus, implied, unemployment, headline, unrate, consumption, sheet, money, supply, treasury, growth, payrolls
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: futures, nasdaq, corporate, range, commodities, credit, treasury, proxy, crude, equities, crypto, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=120, 7d-median=120, 14d-median=120; carrying terms: policies, american, haitian, chemical, destabilising, accellerator, transactions, review, sanctions, active, schools, related
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, https, unauthorized, quiverquant, quantitative, httperror, client, error, congresstrading
- billionaires: today=30, 7d-median=37, 14d-median=35; carrying terms: yiming, buffett, euronext, walmart, changpeng, paris, india, mukesh, retail, hathaway, charles, bloomberg
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: trade, blanche, supreme, district, appeals, international, state, court, school, board, delaware, alaska
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, holdings, amended, therapeutics, david, peter
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, brown, jonathan, graham, michael, senate, lindsey, krishnamoorthi, receipts, cortez, johnson, angels
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, japan, japanherald
- gdelt_gkg: today=25, 7d-median=25, 14d-median=35; carrying terms: english, trump, chinese, themes, spanish, russia, sanctions, arabic, perimeter, iheart, russian, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=9, 14d-median=9; carrying terms: position, belgium, ground, kingdom
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: found, includ, disease, aboard, divisions, britain, valley, remaining, jinka, kozhikode, reference, multi
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: forgery, langflow, sonicwall, improper, privilege, association, critical, granularity, business, deserialization, command, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=217, 7d-median=217, 14d-median=200; carrying terms: slovakia, maximum, indonesia, germany, vietnam, minor, montenegro, honduras, belarus, panama, somalia, hungary
- usgs_quakes: today=7, 7d-median=17, 14d-median=18; carrying terms: depth, islands, kermadec, region, russia, alaska, zealand
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, prime, price, ethiopia, minister, rates, meeting, interest, change, strait, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, revolution, conversable, class, economist, useful, perhaps, https, marginalrevolution, benefit, economic, global
- tech_news: today=47, 7d-median=57, 14d-median=57; carrying terms: intelligence, review, initiative, computer, request, human, bleepingcomputer, company, daily, exploitation, vulnerability, military
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: adrian, ciscomani, sheehy, schmitt, stanton, kavanaugh, treasury, charles, hinds, shomari, ronny, bryan
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, consensus, claude, placed, markets, unavailable, market, identify, today, decision, sufficient, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*