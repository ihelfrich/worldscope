# WORLDSCOPE morning brief — 2026-07-26

## Headline
4372 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (835) · Russian Internal News (state + in-exile) (821) · State-Level News (441) · Ukraine Theater (total-war monitoring) (346) · World leaders & government officials (324) · Chinese Internal News (255) · GDACS — global disaster alerts (221) · Local News: St. Louis + Atlanta (205) · U.S. Weather + Severe / Climate Outlooks (183) · State Legislative Action (181) · Ukrainian Internal News (national + local Kyiv) (123) · Court opinions of consequence (federal & state) (60)

## What changed today
### International News + Multilateral Institutions — 835 new of 980 total
  - (2026-07-26) [Global] What we know so far about the Berlin Pride ramming attack
      A police manhunt is underway after a suspect rammed a car into a crowd at a Pride event in the German capital on Saturday night.
  - (2026-07-26) [Global] Firefighters battle wildfire as tens of thousands evacuated near Bordeaux
      More than 330,000 people have now been evacuated from wildfires across France and Spain.
  - (2026-07-25) [Global] Trump takes swipes at press during White House Correspondents' Dinner
      The event celebrated press freedom after the first dinner was cancelled by a shooting in April.
  - (2026-07-26) [Global] Israeli settlers set fire to mosques, cars and farm land in West Bank, Palestinians say
      The latest attacks come two days after a clash between settlers and Palestinians near the village of Tell, which left four Palestinians and two Israelis dead.
  - (2026-07-25) [Global] India's 'cockroach' protest called off after education minister quits
      The CJP protest has been the most visible expression of public anger against PM Narendra Modi's government in recent years.
  - (2026-07-25) [Global] Ten killed in Russian attack on drone exhibition near Kyiv
      The event, attended by prominent members of the Ukrainian defence industry, was hit by ballistic missiles in the middle of the day.

### Russian Internal News (state + in-exile) — 821 new of 824 total
  - (2026-07-26) В Берлине задержали пассажира машины, въехавшей в толпу во время ЛГБТ-прайда | LEDE: Полиция еще в ночь на 26 июля задержала пассажира автомобиля, наехавшего на толпу во время ЛГБТ-прайда в ] (ru: В Б…
      Полиция еще в ночь на 26 июля задержала пассажира автомобиля, наехавшего на толпу во время ЛГБТ-прайда в Берлине, сообщает телерадиокомпания rbb.
  - (2026-07-26) Война. 1614-й день. Украина и США хотят предложить России перемирие в воздухе | LEDE: «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно п] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-26) В космосе становится тесно из-за спутников: SpaceX уже вывела туда тысячи Starlink, а в будущем число аппаратов на орбите может перевалить за миллион. Чем это опасно? | LEDE: За семь лет ком] (ru: В к…
      За семь лет компания SpaceX Илона Маска вывела на орбиту больше 10 тысяч спутников Starlink. А в ближайшие годы в космосе станет еще теснее. Частные компании уже заявили проекты, подразумевающие вывод на орбиту 1,7 милли…
  - (2026-07-26) Из-за сильнейшего шторма в Ростовской области погиб один человек, около 30 пострадали. Улицы городов — в воде, поваленных деревьях и разбитых автомобилях. Фотографии и видео | LEDE: 25 июня ] (ru: Из-…
      25 июня через Ростовскую область прошел сильнейший ураган с ливнями и грозами. Во время шторма погиб один человек, еще 28, по последним данным пострадали, как заявил 26 июля, мэр Ростова-на-Дону Александр Скрябин. Из-за…
  - (2026-07-26) Wildberries перестал показывать военные товары по запросу «все для СВО» (но найти их можно по другим запросам) | LEDE: Wildberries больше не отображает военные товары по запросам «все для СВ] (ru: Wil…
      Wildberries больше не отображает военные товары по запросам «все для СВО» или «СВО», обратили внимание украинские телеграм-каналы.
  - (2026-07-26) Пройти сотни километров пешком по тропам пилигримов — такой вариант отдыха выбирает все больше людей по всему миру. Почему Камино-де-Сантьяго и другие маршруты так популярны? И как стать паломн] (ru:…
      Паломнические маршруты вроде Камино-де-Сантьяго становятся все популярнее, хотя большинство людей отправляются в путь не ради религии. Научный журналист и автор телеграм-канала «Лайфлонг муки» Илья Кабанов — он сам проше…

### State-Level News — 441 new of 454 total
  - (2026-07-24) [California] California’s economy isn’t just bigger than Texas and Florida — it’s growing faster, too
      Source
  - (2026-07-24) [California] California landlord fights law meant to help low-income renters
      Should California landlords be required to rent to tenants with federal housing vouchers? They are under state law, but a Sacramento-based property manager is contest
  - (2026-07-24) [California] Public funding cuts, lost grants, stagnant wages: How economic woes are dimming a vibrant art scene
      <img width="1024" height="681" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072226-SD-Arts-AP-CM.jpg?fit=1024%2C681&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="An a…
  - (2026-07-24) [California] Aging oil refineries don’t need more public dollars. California should let them retire
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092925-Refinery-Workers-SK-10-CM.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-24) [California] California can’t replant its forests fast enough to keep up with wildfires
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/071526_Reforestation_AHK_CM_75.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-07-24) [California] Newsom appointed a close ally to this state board. Environmental groups say he has a conflict of interest
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/072326-CalEPA-BES-Meeting-MG-CM-23.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…

### Ukraine Theater (total-war monitoring) — 346 new of 457 total
  - (2026-07-26) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-25) [Liveuamap] Tokayev, at a meeting with Putin, proposed freezing the war in Ukraine. The meeting of the presidents of Kazakhstan and Russia is taking place in Omsk, Russia. Tokayev stressed that his co…
      Tokayev, at a meeting with Putin, proposed freezing the war in Ukraine. The meeting of the presidents of Kazakhstan and Russia
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com Liveuamap
  - (2026-07-24) [Liveuamap] Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com - Liveuamap
      Map of Syrian Civil War - Syria news and incidents today - syria.liveuamap.com Liveuamap
  - (2026-07-25) [Liveuamap] Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com - iraq.liveuamap.com
      Iraq news map in English - News from Baghdad, Anbar, Kirkuk, Nineveh, Kurdistan regions - iraq.liveuamap.com iraq.liveuamap.com
  - (2016-04-29) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 255 new of 255 total
  - (2026-07-24) Chart of the Day: China’s New Solar Build Out Plunges - Caixin Global
      Chart of the Day: China’s New Solar Build Out Plunges Caixin Global
  - (2026-07-24) PRO专享/数据深度专题 - deepview.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMie0FVX3lxTE90c3JhX2dHajhDTXJlZWlVamFKTUd4cGEwOE9aUVowZVZCcWVuN0pBRjFRRDhWOUlSM2JjMGdFYzgxdlNoUGlvOURQ] (zh:…
      PRO专享/数据深度专题 deepview.caixin.com
  - (2026-07-26) 造访齐国古都｜黄河两岸④ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBoNlZQYVFFTmltcDZGYzhRZFJUeFdnRDdvN2QzY1FSazFZNG1JSk5taUtLQkMzZjZnNktxUVZxcXJBMU9LZERPVzk0aTF2R0hLd1hNRG4za] (zh:…
      造访齐国古都｜黄河两岸④ 财新
  - (2026-07-25) 人类失去“秘密”，世界将会怎样？｜影视 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5xZkxMc21EdG1IaGZSMUMxcDBfRjBKQUZHVUFlQ3RYUmJyS2VQdy03QThfRFgyZlBfYmlERjFkVFE3bTNaOURxblFENF9KU005S3] (zh:…
      人类失去“秘密”，世界将会怎样？｜影视 财新
  - (2026-07-25) 求生在罗马｜猎读 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBOOTZiMW9FN2kyOUZpcUhkU2dEZzl3YmlCX1hyVFN2SDVmSG4td0FTTkI1SVlpY2Y4bTVXa0Q2aEYxWmszcFdWQV9tYkxIYVgybm5sRU5jaHdrT] (zh:…
      求生在罗马｜猎读 财新
  - (2026-07-24) 今日开盘：两市双双低开 沪指跌幅0.60% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBwSTQtSXF6WURFeGh4aG1rMXNpRXdWTE1zSmROLWNsR1B4Z2dPRFJxQkNsaS1obmpFYWUxeDg0NUNYSWh1Zkk3SXZqbi1uaXM5] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.60% 财新

### GDACS — global disaster alerts — 221 new of 249 total
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)
  - (2026-07-23) [Orange] Tropical Cyclone NOUL-26
      Tropical Cyclone · Orange alert · China, Philippines · Hurricane/Typhoon > 74 mph (maximum wind speed of 157 km/h)

### Local News: St. Louis + Atlanta — 205 new of 205 total
  - (2026-07-26) [St. Louis] 'They're gonna jump' | Video captures moment two men parachute off Seattle's Space Needle
      Witnesses said the men sprinted to the observation deck, climbed over a barrier and parachuted from the landmark before disappearing.
  - (2026-07-26) [St. Louis] Man killed, another injured in Cedar Hill shooting; suspect remains at large
      The two men were found shot outside a home on Lakeshore Drive in Cedar Hill, deputies said.
  - (2026-07-26) [St. Louis] $600M Powerball: Winning numbers for Saturday, July 25, 2026
      Saturday's $600 million grand prize has a $262.8 million lump sum cash option.
  - (2026-07-26) [St. Louis] 3 critically injured, including suspected shooter, in House Springs shooting
      Two women were shot before the suspected gunman shot himself Saturday night in House Springs, according to the Jefferson County Sheriff's Office.
  - (2026-07-26) [St. Louis] Tropical Storm Genevieve strengthens into a hurricane in the Pacific southwest of Mexico
      Tropical Storm Genevieve has strengthened into a hurricane in the Pacific Ocean southwest of Mexico.
  - (2026-07-26) [St. Louis] Community honors 3 family members killed in East St. Louis mass shooting
      Hundreds turned out for Patricia, Cherie and Devon May's celebration of life Saturday at the House of Prayer to All Nations church.

### U.S. Weather + Severe / Climate Outlooks — 183 new of 185 total
  - (2026-07-26) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-26) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 26 at 5:23AM PDT until July 27 at 8:00PM PDT by NWS San Diego CA
      * WHAT...Dangerously hot conditions with high temperatures in the upper 90s to 105 and low temperatures in the low 70s. * WHERE...San Bernardino and Riverside County Valleys-The Inland Empire. * WHEN...Until 8 PM PDT Mon…
  - (2026-07-26) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 26 at 5:23AM PDT until July 27 at 8:00PM PDT by NWS San Diego CA
      * WHAT...Dangerously hot conditions with high temperatures of 100 to 110 and low temperatures in the low 70s to low 80s. * WHERE...Apple and Lucerne Valleys. * WHEN...Until 8 PM PDT Monday. * IMPACTS...Heat related illne…
  - (2026-07-26) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 26 at 5:23AM PDT until July 27 at 8:00PM PDT by NWS San Diego CA
      * WHAT...Dangerously hot conditions with high temperatures 110 to 115 and lows in the mid 80s to low 90s. * WHERE...Coachella Valley, San Diego County Deserts, and San Gorgonio Pass near Banning. * WHEN...Until 8 PM PDT…
  - (2026-07-26) [Moderate] Heat Advisory: Heat Advisory issued July 26 at 5:23AM PDT until July 27 at 8:00PM PDT by NWS San Diego CA
      * WHAT...High temperatures in the upper 80s to upper 90s and low temperatures in the upper 60s to low 70s. * WHERE...San Diego County Valleys. * WHEN...Until 8 PM PDT Monday. * IMPACTS...Hot temperatures may cause heat i…
  - (2026-07-26) [Moderate] Heat Advisory: Heat Advisory issued July 26 at 5:23AM PDT until July 27 at 8:00PM PDT by NWS San Diego CA
      * WHAT...Temperatures in the mid to upper 90s with low temperatures in the upper 60s to low 70s. * WHERE...San Diego County Mountains. * WHEN...Until 8 PM PDT Monday. * IMPACTS...Hot temperatures may cause heat illnesses…

### State Legislative Action — 181 new of 182 total
  - (2026-07-25) [Alaska HB 324] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
  - (2026-07-25) [Alaska HB 316] An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
      An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
  - (2026-07-25) [California SB 822] Unclaimed property: digital financial assets.
      The Unclaimed Property Law (UPL) prescribes the circumstances under which intangible property escheats to the state, including how and when apparent owners must be notified that their property is at risk of escheating an…
  - (2026-07-25) [California SB 838] Housing Accountability Act: housing development projects.
      Existing law, the Housing Accountability Act, among other things, prohibits a local agency from disapproving, or conditioning approval in a manner that renders infeasible, a housing development project for very low, low-…
  - (2026-07-25) [California SB 848] Pupil safety: school employee misconduct: child abuse prevention.
      (1) Under existing law, each school district and county office of education is responsible for the overall development, as specified, of a comprehensive school safety plan for each of its schools operating kindergarten o…
  - (2026-07-25) [California SB 839] Oil spills: fishing: water closure: grants: liability.
      (1) Existing law requires the Director of Fish and Wildlife, within 24 hours of notification of a spill or discharge, as described, to close certain waters to the take of all fish and shellfish. Existing law provides tha…

### Ukrainian Internal News (national + local Kyiv) — 123 new of 131 total
  - (2026-07-26) Стубб вважає, що позиції України зараз найміцніші з початку війни | LEDE: Стубб заявив, що позиції України найсильніші, а підтримка партнерів важлива для миру.] (uk: Стубб вважає, що позиції України з…
      Стубб заявив, що позиції України найсильніші, а підтримка партнерів важлива для миру.
  - (2026-07-26) Драпатий розпочав аудит у Збройних силах: Жодних "недоторканних" не буде (новина анулюється) | LEDE: Головнокомандувач ЗСУ Михайло Драпатий повідомив про аудит армії для оцінки боєготовності та] (uk:…
      Головнокомандувач ЗСУ Михайло Драпатий повідомив про аудит армії для оцінки боєготовності та управління.
  - (2026-07-26) Тепло та грози: синоптики розповіли, з чого почнеться погодний тиждень | LEDE: Детальний прогноз погоди в Україні на 27-28 липня: дощі, грози, температура до +32°.] (uk: Тепло та грози: синоптики розп…
      Детальний прогноз погоди в Україні на 27-28 липня: дощі, грози, температура до +32°.
  - (2026-07-26) До МЗС Румунії викликали російського посла через дрони | LEDE: МЗС Румунії викликало посла РФ через збиття третього російського дрона, що порушив повітряний простір НАТО.] (uk: До МЗС Румунії викликал…
      МЗС Румунії викликало посла РФ через збиття третього російського дрона, що порушив повітряний простір НАТО.
  - (2026-07-26) Синдром білки в колесі: чому лінь – це єдиний спосіб не збожеволіти на роботі | LEDE: Дізнайтеся, чому хронічна зайнятість руйнує креативність і як лінь стимулює проривні ідеї згідно з дослідже] (uk:…
      Дізнайтеся, чому хронічна зайнятість руйнує креативність і як лінь стимулює проривні ідеї згідно з дослідженнями нейрофізіології.
  - (2026-07-26) Міністр оборони Польщі про удар РФ по Києву: втома від війни не може бути відповіддю | LEDE: ] (uk: Міністр оборони Польщі про удар РФ по Києву: втома від війни не може бути відпов)

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-24) U.S. Court of Appeals, 11th Cir.: Bay United Holdings, LLC. v. INXS VII, LLC
  - (2026-07-24) Delaware Supreme Court: Arif Ahmed v. JPMorgan Chase & Co.
  - (2026-07-24) U.S. Court of Appeals, D.C. Cir.: Adsync Technologies, Inc. v. FAA
  - (2026-07-24) U.S. Court of Appeals, D.C. Cir.: American Whitewater v. FERC
  - (2026-07-24) U.S. Court of Appeals, D.C. Cir.: Fairholme Funds, Inc v. FHFA
  - (2026-07-24) U.S. Court of Appeals, D.C. Cir.: Jannease Johnson v. DC

### IT, InfoSys & cybersecurity news (last 7 days) — 57 new of 57 total
  - (2026-07-26) [The Register] Trump expands voluntary pledge to keep datacenter costs off household power bills
      Pinkie promise gains 200-plus new participants and precisely zero enforcement
  - (2026-07-26) [The Register] The last Space Shuttle returned to Earth 15 years ago
      So, how are those commercial replacements working out for you, NASA?
  - (2026-07-26) [TechCrunch] Monday.com is the latest tech company to blame AI for layoffs — here are 20 others
      A running look — in reverse chronological order — at the bigger tech companies that have announced significant layoffs this year with AI as a stated factor.
  - (2026-07-25) [BleepingComputer] Steam forum ClickFix attacks infect gamers with XMRig cryptominers
      Steam discussion forums are being abused in ClickFix attacks that pretend to be fixes for game and computer problems but actually infect devices with cryptominers. [...]
  - (2026-07-25) [BleepingComputer] Malicious sites use JavaScript to build malware in browser memory
      A massive malvertising campaign is using fake Solana, Luno, and TradingView webpages with malicious JavaScript that instructs browsers to assemble malware directly in memory. [...]
  - (2026-07-25) [BleepingComputer] ShinyHunters data leaks fuel $2,000 sextortion email scam
      Threat actors are using email addresses exposed in data breaches leaked by the ShinyHunters extortion group to send sextortion emails demanding $2,000 in Bitcoin. [...]

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-07-26) [Israel-Iran-Hezbollah axis · keywords] US pauses attacks on Iran for a second day as peace talks continue
      theguardian.com · English · tone NA
  - (2026-07-26) [Israel-Iran-Hezbollah axis · keywords] Lebanese displaced by war turn to satellites to check their homes
      wemu.org · English · tone NA
  - (2026-07-26) [Israel-Iran-Hezbollah axis · keywords] Lebanese displaced by war turn to satellites to check their homes
      kunm.org · English · tone NA
  - (2026-07-26) [Israel-Iran-Hezbollah axis · keywords] Israeli settlers set fire to West Bank mosques after deadly clash
      al-monitor.com · English · tone NA
  - (2026-07-26) [Israel-Iran-Hezbollah axis · keywords] Michigan , Missouri primaries show Democratic divide over Israel
      cnn.com · English · tone NA
  - (2026-07-26) [Israel-Iran-Hezbollah axis · keywords] US pauses attacks on Iran for a second day as peace talks continue
      aol.co.uk · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-25) [Tangney Jeffrey] Form 4 (Reporting)
      filed 2026-07-25 01:59 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Doximity, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:59 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Sams Louise S] Form 4 (Reporting)
      filed 2026-07-25 01:51 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:51 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Auguste Laurent] Form 4 (Reporting)
      filed 2026-07-25 01:49 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:49 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-26) [India] India reaching new heights in defence production , defence exports : PM Modi in Mann ki Baat
      domain: news.webindia123.com · language: English · tone:
  - (2026-07-26) [Armenia] Armenia Marriott Launches Internal Investigation Following Cases of Illness at French Embassy Reception
      domain: arka.am · language: English · tone:
  - (2026-07-26) [United Kingdom] Sinfonia of London / Wilson review – night of Technicolor masterpieces from one of the finest orchestras on the planet
      domain: theguardian.com · language: English · tone:
  - (2026-07-26) [Israel] Main land crossing between Kuwait and Iraq reopens , Iraq state news agency says
      domain: al-monitor.com · language: English · tone:
  - (2026-07-26) [India] Putin preparing to send more Russians to war : Zelenskyy claims losses now exceed recruitment
      domain: timesofindia.indiatimes.com · language: English · tone:
  - (2026-07-26) [United Kingdom] US pauses attacks on Iran for a second day as peace talks continue
      domain: theguardian.com · language: English · tone:

### Government Action: Sanctions + Procurement + Foreign Agents — 38 new of 120 total
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses - Office of Foreign Assets Cont…
      Counter Terrorism Designations; Counter Narcotics Designations; Cuba Designations; Belarus-related Designation Removal; Issuance of Cuba-related General Licenses Office of Foreign Assets Control (.gov)
  - (2026-07-20) [OFAC] Russia-related Designations Updates - Office of Foreign Assets Control (.gov)
      Russia-related Designations Updates Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] CJNG-Linked Networks - Office of Foreign Assets Control (.gov)
      CJNG-Linked Networks Office of Foreign Assets Control (.gov)
  - (2026-07-24) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Russian Harmful Foreign Activities Sanctions Regulations 31 CFR part 587 GENERAL LICENSE NO. 1 Office of Foreign Assets Control (.gov)
  - (2026-07-23) [OFAC] CJNG Leadership - Office of Foreign Assets Control (.gov)
      CJNG Leadership Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 32 new of 132 total
  - (2026-07-26) [Polymarket] Will Bitcoin reach $75,000 by December 31, 2026?
      This market will resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between the creation of this market through 11:59 PM ET on the last day of the year specified in the title has a final "High" price…
  - (2026-07-26) [Polymarket] Yunnan Yukun FC vs. Shenzhen Xinpengcheng FC: O/U 3.5
      In the upcoming Chinese Super League game between Yunnan Yukun FC and Shenzhen Xinpengcheng FC, scheduled for July 26 at 7:00 AM ET: This market will resolve to "Over" if Yunnan Yukun FC and Shenzhen Xinpengcheng FC comb…
  - (2026-07-26) [Polymarket] Will Marco Rubio win the 2028 Republican presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Republican Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-26) [Polymarket] LoL: ThunderTalk Gaming vs EDward Gaming - Game 1 Winner
      This market refers to the LoL match between ThunderTalk Gaming and EDward Gaming in the LPL Group Ascend, initially scheduled for July 26 at 5:00AM ET. This market will resolve to "ThunderTalk Gaming" if ThunderTalk Gami…
  - (2026-07-26) [Polymarket] UNSC Resolution Endorsing Final U.S.-Iran Deal by December 31?
      On June 14, 2026, the United States and Iran announced a written diplomatic agreement, which stated in Clause 14 that it would culminate in a “final deal” to be endorsed by a binding United Nations Security Council resol…
  - (2026-07-26) [Polymarket] Will Sabrina Carpenter be the top artist for 2026?
      Spotify releases an annual report of its most streamed artist (see: https://newsroom.spotify.com/2025-12-03/wrapped-top-artists-songs-albums-podcasts-audiobooks/). This market refers to the most streamed Spotify artist f…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 22 new of 23 total
  - (2026-07-26) GAF601 (Germany)
      icao24: 3f6533 · position: (51.5114, 7.5912) · alt: 571m · 296km/h
  - (2026-07-26) JAF94H (Bulgaria)
      icao24: 4520aa · position: (38.9011, -8.0039) · alt: 11285m · 877km/h
  - (2026-07-26) RCH5093 (United States)
      icao24: ae63c6 · position: (48.4482, 18.6147) · alt: 11582m · 820km/h
  - (2026-07-26) JAF6JG (Belgium)
      icao24: 44d1ba · position: (50.9028, 4.4914) · on ground · 25km/h
  - (2026-07-26) JAF7HW (Belgium)
      icao24: 44d1a6 · position: (42.3646, -6.7471) · alt: 11277m · 908km/h
  - (2026-07-26) JAF95N (Belgium)
      icao24: 44d1a7 · position: (43.577, -6.1813) · alt: 11277m · 916km/h

### Prediction Markets — most-traded (Polymarket) — 20 new of 20 total
  - (2026-07-26) LoL: ThunderTalk Gaming vs EDward Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $1,477,589 · resolves 2026-07-26
  - (2026-07-26) Will Adanech Abiebie be the next Prime Minister of Ethiopia?
      yes price: 0% · 24h volume: $1,341,735 · resolves 2026-06-01
  - (2026-07-26) LoL: Anyone's Legend vs Bilibili Gaming - Game 1 Winner
      yes price: 0% · 24h volume: $1,259,401 · resolves 2026-07-26
  - (2026-07-26) Will the U.S. invade Iran before 2027?
      yes price: 20% · 24h volume: $1,000,447 · resolves 2026-12-31
  - (2026-07-26) LoL: ThunderTalk Gaming vs EDward Gaming - Game 1 Winner
      yes price: 100% · 24h volume: $996,710 · resolves 2026-07-26
  - (2026-07-26) LoL: ThunderTalk Gaming vs EDward Gaming (BO3) - LPL Group Ascend
      yes price: 100% · 24h volume: $809,391 · resolves 2026-07-26

### U.S. Federal Action — 12 new of 12 total
  - (2026-07-27) Modernizing Reactor Licensing, Safety Oversight, and Siting Practices; Correction
      The U.S. Nuclear Regulatory Commission (NRC) is correcting a notice published in the Federal Register on July 16, 2026, regarding the modernization of reactor licensing, safety oversight, and siting practices to address…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Report and Order that promotes the deployment of submarine cables while strengthening national security interests in connection…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Further Notice of Proposed Rulemaking (Second FNPRM) that seeks to further prevent evolving national security risks associated…
  - (2026-07-27) Modernizing Package Certification Requirements
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its regulations governing the packaging and transportation of radioactive material. This proposed action is responsive to several executive orders and th…
  - (2026-07-27) Updating Website and Contact Information, and Authorizations for Payments for Legal Services
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is adopting a final rule to update website and contact information in certain parts of the Code of Federal Regulations (CFR). Additionally, OFAC is…
  - (2026-07-27) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action
      NMFS announces an inseason action for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds fishing dates in August and September in the Co…

### World News (by country, top stories) — 12 new of 12 total
  - (2026-07-26) [China] Chile Consul General in Chengdu calls for deeper China - Chile cooperation in AI and digital economy
      sxdaily.com.cn · English
  - (2026-07-26) [China] KB Kookmin Bank to Launch JPMorgan Kinexys Cross - Border Payment Service
      cointelegraph.com · English
  - (2026-07-26) [China] Canadian artist Philip Read : Ceramic heritage knows no borders
      sxdaily.com.cn · English
  - (2026-07-26) [China] Fuuta greets world as APEC forestry meeting opens in Shenzhen
      sxdaily.com.cn · English
  - (2026-07-26) [China] Drone seeding brings new greenery to Taklamakan Desert
      sxdaily.com.cn · English
  - (2026-07-26) [China] China COVID - 19 rises to moderate level activity , overtakes flu as top respiratory pathogen in past week : CDC data
      globaltimes.cn · English

### USGS earthquakes (M4.5+, past day) — 9 new of 9 total
  - (2026-07-26) M 5.8 - 99 km SE of Atka, Alaska
      M5.8 · 99 km SE of Atka, Alaska · depth 10 km
  - (2026-07-26) M 5.3 - 25 km NW of Kupang, Indonesia
      M5.3 · 25 km NW of Kupang, Indonesia · depth 10 km
  - (2026-07-26) M 5.1 - Tristan da Cunha region
      M5.1 · Tristan da Cunha region · depth 10 km
  - (2026-07-25) M 5.0 - 91 km SE of Atka, Alaska
      M5.0 · 91 km SE of Atka, Alaska · depth 40.779 km
  - (2026-07-25) M 4.9 - Kermadec Islands, New Zealand
      M4.9 · Kermadec Islands, New Zealand · depth 55.602 km
  - (2026-07-26) M 4.7 - 18 km ESE of Monterrey, Colombia
      M4.7 · 18 km ESE of Monterrey, Colombia · depth 12.362 km

### CISA Known Exploited Vulnerabilities (last 14d) — 6 new of 16 total
  - (2026-07-22) CVE-2026-16232 · Check Point SmartConsole: Check Point SmartConsole Improper Authentication Vulnerability
      vendor: Check Point · product: SmartConsole · CISA remediation by 2026-07-25
  - (2026-07-22) CVE-2026-50522 · Microsoft SharePoint: Microsoft SharePoint Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint · CISA remediation by 2026-07-25
  - (2026-07-21) CVE-2026-60137 · WordPress Core: WordPress Core SQL Injection Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-08-04
  - (2026-07-21) CVE-2026-63030 · WordPress Core: WordPress Core Interpretation Conflict Vulnerability
      vendor: WordPress · product: Core · CISA remediation by 2026-07-24
  - (2026-07-21) CVE-2026-0770 · Langflow Langflow: Langflow Inclusion of Functionality from Untrusted Control Sphere Vulnerability
      vendor: Langflow · product: Langflow · CISA remediation by 2026-07-24
  - (2026-07-21) CVE-2021-27137 · DD-WRT DD-WRT: DD-WRT Stack-Based Buffer Overflow Vulnerability
      vendor: DD-WRT · product: DD-WRT · CISA remediation by 2026-07-24

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-26) [Marginal Revolution] The Rug Belt Atlas and Quiz
      I have an amateur interest in Oriental rugs but my eye is untrained. Thus, for fun and learning I created with Fable an Rug Atlas and quiz. The Rug Belt Atlas Check it out. Constructive comments welcome. The post The Rug…
  - (2026-07-26) [Marginal Revolution] The demand for human enhancement technologies
      When a new technology promises large private benefits but may impose social costs that markets do not price, demand need not reveal how citizens want it governed. We examine this using a nationally representative U.S. su…
  - (2026-07-26) [Marginal Revolution] The common sense of Fareed Zakaria
      This is one of the best Op-Eds you will read this year, though it deliberately deemphasizes the personal (no one is attacked) in a manner that will result in less attention. Better to write the truth! Excerpt: Why has th…
  - (2026-07-24) [Conversable Economist] Occupational Licensing: US and International
      The potential benefit of having the government require that certain jobs require an official license is quality control and protection. Personally, I rather like knowing that my nurse or doctor or dentist has gone throug…
  - (2026-07-23) [Conversable Economist] The Job Market for Recent College Graduates
      When I talk with college students, and even high school students, a number of them have a profound sense that it is tremendously hard to find a job coming out of college. The level fear seems to me exaggerated, but some…
  - (2026-07-22) [Conversable Economist] Chokepoints for Ocean Trade: Strait of Hormuz, and What Else?
      For those who can be fuzzy on global geography, like me, it’s perhaps useful to say that the Persian Gulf is a body of water bordered by eight countries: Bahrain, Iran, Iraq, Kuwait, Qatar, Saudi Arabia, the United Arab…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] ANGELS FOR JOHN GAY
      cycle 2010 · filing #720559
  - () [F3] FRIENDS OF SCOTT ROBINSON
      cycle 2014 · filing #870444 · receipts $0.00M

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-26) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=17, 14d-median=17
- state_bills: today=182, 7d-median=138, 14d-median=138
- state_news: today=454, 7d-median=711, 14d-median=711
- local_news: today=205, 7d-median=246, 14d-median=246
- foreign_news: today=980, 7d-median=1024, 14d-median=1024
- chinese_internal: today=255, 7d-median=299, 14d-median=299
- russian_internal: today=824, 7d-median=833, 14d-median=833
- ukrainian_internal: today=131, 7d-median=138, 14d-median=138
- ukraine_theater: today=457, 7d-median=457, 14d-median=457
- paper_bets: today=132, 7d-median=143, 14d-median=143
- weather: today=185, 7d-median=177, 14d-median=177
- macro: today=21, 7d-median=21, 14d-median=21
- markets: today=21, 7d-median=21, 14d-median=21
- markets_global: today=47, 7d-median=47, 14d-median=47
- sanctions_procurement: today=120, 7d-median=119, 14d-median=119
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=12, 7d-median=12, 14d-median=12
- gdelt_gkg: today=50, 7d-median=50, 14d-median=50
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=23, 7d-median=23, 14d-median=23
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- epss: today=40, 7d-median=40, 14d-median=40
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=249, 7d-median=101, 14d-median=101
- usgs_quakes: today=9, 7d-median=23, 14d-median=23
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- tech_news: today=57, 7d-median=57, 14d-median=57
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*