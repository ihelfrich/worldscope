# WORLDSCOPE morning brief — 2026-09-22

## Headline
3457 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (804) · Russian Internal News (state + in-exile) (671) · State-Level News (344) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (265) · Chinese Internal News (228) · Local News: St. Louis + Atlanta (220) · U.S. Weather + Severe / Climate Outlooks (125) · State Legislative Action (90) · Ukrainian Internal News (national + local Kyiv) (63) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40)

## What changed today
### International News + Multilateral Institutions — 804 new of 994 total
  - (2026-09-22) [Global] Major US outlets boycott shared Trump coverage in protest at media ban
      Regular coverage of the president has been disrupted after he banned CNN, MS NOW and Politico from the White House.
  - (2026-09-22) [Global] Lithuania ready to 'fight back' but has evacuation plans in face of Russia threats, PM tells BBC
      Sinkevičius told BBC Newsnight Lithuanians feel "constantly threatened" by Moscow, but the nation was prepared to "fight back" if attacked.
  - (2026-09-22) [Global] Iran must stop arming Houthis in Yemen, G7 says ahead of UN General Assembly
      The G7 also condemns "in the strongest terms" Houthi attacks on Saudi Arabia, saying that the escalation in fighting in Yemen jeopardises global energy security.
  - (2026-09-22) [Global] Eleven injured in shooting outside Turkish school
      Footage appears to show a male in the area carrying a firearm, while officials say the attacker has been captured.
  - (2026-09-22) [Global] Sri Lankan court to deliver verdict on deadly Easter bombings
      Co-ordinated suicide attacks killed 270 people across several churches and hotels in Colombo in 2019.
  - (2026-09-22) [Global] Outrage in India over viral video of teen molested and her friend beaten
      Three minors were arrested after videos capturing the assault went viral in India, sparking anger.

### Russian Internal News (state + in-exile) — 671 new of 1029 total
  - (2026-09-22) Война. 1672-й день. Украина и Россия продолжают атаковать энергетические объекты друг друга. Трамп и Зеленский лично обсудят отказ от таких ударов | LEDE: «Медуза» с 24 февраля 2022 года в п] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-09-22) Парламент Литвы поддержал отказ от запрета на размещение в стране ядерного оружия | LEDE: Парламент Литвы поддержал законопроект, исключающий из Конституции статью о запрете на размещение на] (ru: Пар…
      Парламент Литвы поддержал законопроект, исключающий из Конституции статью о запрете на размещение на территории страны ядерного оружия. «За», как сообщает LRT, проголосовали 99 депутатов, «против» — 13, а пять воздержали…
  - (2026-09-22) Украинский дрон попал в один и тот же многоквартирный дом в Подмосковье уже второй раз. Фотографии | LEDE: В Московской области в городе Котельники есть высотка, в которую уже дважды попадал] (ru: Укр…
      В Московской области в городе Котельники есть высотка, в которую уже дважды попадали украинские беспилотники. ЖК «Русич» в квартале Новые Котельники получил повреждения в результате массированной атаки на московский реги…
  - (2026-09-22) В Стерлитамаке — пожар в торговом центре. Есть погибшие. Люди выпрыгивали из окон, спасаясь от огня | LEDE: В Стерлитамаке произошел пожар на популярном среди местных жителей рынке — ТСК «Со] (ru: В С…
      В Стерлитамаке произошел пожар на популярном среди местных жителей рынке — ТСК «Солнечный», сообщает Ufa1.ru.
  - (2026-09-22) Реальная явка на выборах в Госдуму, по мнению экспертов, была около 40%. ЦИК заявлял о явке 59% | LEDE: Явка на выборах в Госдуму, прошедших в России 18-20 сентября, была около 40%. Так, соо] (ru: Реа…
      Явка на выборах в Госдуму, прошедших в России 18-20 сентября, была около 40%. Так, сообщает «Дождь», считают математик Борис Овчинников и эксперт по наблюдению за выборами Роман Удот. ЦИК объявлял о явке более 59%.
  - (2026-09-22) «Трудно быть богом» — беззубый сериал по политической книге братьев Стругацких. С Ярмольником, Безруковым и рекламой «Росатома», но без образа будущего | LEDE: В онлайн-кинотеатре Wink выход] (ru: «Тр…
      В онлайн-кинотеатре Wink выходит сериал «Трудно быть богом» по мотивам повести братьев Стругацких. Авторы проекта заметно изменили сюжет книги: теперь мы следим за посланцем Земли доном Руматой с первых дней его работы в…

### State-Level News — 344 new of 505 total
  - (2026-09-21) [Alaska] Falls Prevention Awareness Week 2026
      WHEREAS, it is estimated that 14 percent of Alaskans are 65 years of age or older, and this population has more than doubled from 54,938 in 2010 to 107,444 in 2024; and live longer, and remain in better health than their…
  - (2026-09-21) [California] What they are saying: Strong support for California’s new laws to expand EV access, consumer choice, and cut dependence on oil
      Source
  - (2026-09-21) [California] Ahead of Climate Week NYC, Governor Newsom announces California cut climate pollution again as economy keeps growing
      Source
  - (2026-09-21) [California] Governor Newsom proclaims state of emergency to bolster statewide El Nino preparedness, protect California
      Source
  - (2026-09-21) [California] Governor Newsom signs most comprehensive data center laws in the nation, providing communities more control on water, electricity, and land use
      Source
  - (2026-09-22) [California] Gavin Newsom paddles to the political right with 3 notable vetoes
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/091026_Newsom-Kids-Tech_AHK_CM_33.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 265 new of 426 total
  - (2026-09-22) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-21) [FIRMS] thermal anomaly 44.361, 28.326 (FRP 5.83 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-21 1009Z, FRP 5.83 MW
  - (2026-09-21) [FIRMS] thermal anomaly 46.130, 34.305 (FRP 6.93 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-21 1009Z, FRP 6.93 MW
  - (2026-09-21) [FIRMS] thermal anomaly 46.134, 34.303 (FRP 7.47 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-21 1009Z, FRP 7.47 MW
  - (2026-09-21) [FIRMS] thermal anomaly 46.323, 32.829 (FRP 3.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-21 1009Z, FRP 3.7 MW
  - (2026-09-21) [FIRMS] thermal anomaly 46.337, 32.822 (FRP 23.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-21 1009Z, FRP 23.98 MW

### Chinese Internal News — 228 new of 286 total
  - (2026-09-20) Cover Story: Jeju Missing Persons Scandal Tests Seoul’s Criminal Justice Overhaul - Caixin Global
      Cover Story: Jeju Missing Persons Scandal Tests Seoul’s Criminal Justice Overhaul Caixin Global
  - (2026-09-22) Former Shenzhen Mayor Investigated Weeks After Job Transfer - Caixin Global
      Former Shenzhen Mayor Investigated Weeks After Job Transfer Caixin Global
  - (2026-09-22) Z.AI Open-Sources Coding Tool After Backlash Over Silent Data Uploads - Caixin Global
      Z.AI Open-Sources Coding Tool After Backlash Over Silent Data Uploads Caixin Global
  - (2026-09-21) China Sentences Two Former IPO Review Veterans for Bribery - Caixin Global
      China Sentences Two Former IPO Review Veterans for Bribery Caixin Global
  - (2026-09-21) 贝森特称美方提议建立中美AI安全通报机制 将提请峰会考虑 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE14ZkZKOWRmalIzcHZQSUduSG9tTDVwVnJYNmN2OVZ6SmQxNm5xc1dDUjhCeGxzanQ5aXBHSXFVWmhBWWVlc2ZyVG4yW] (zh:…
      贝森特称美方提议建立中美AI安全通报机制 将提请峰会考虑 财新
  - (2026-09-21) 财新闻｜事关“幽灵外卖” 市场监管总局出手整治 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBjNlVDbUJXVmtDQmlKOUtnQVRJaUFVcTFaM3FWemVRYkxmdUFVUU5YVHAwQjlLVkYyZkQ4YnJyekI5TVZlbDh0b2w4MUpRT3] (zh:…
      财新闻｜事关“幽灵外卖” 市场监管总局出手整治 财新

### Local News: St. Louis + Atlanta — 220 new of 238 total
  - (2026-09-22) [St. Louis] Prop B asks voters to increase St. Louis’ sales tax to fund early childhood education
      A half-cent sales tax increase to generate funding for early childhood education in the City of St. Louis will be on the ballot this November. Proposition B, backed by the Best Start for Kids STL campaign, would generate…
  - (2026-09-22) [St. Louis] Spearhead Bio raises $1.62M to continue building new gene editing tools for crops
      A St. Louis-based agtech company developing a new way to execute broad gene edits in plants has secured another $1.62 million in funding to develop its technology. Spearhead Bio, which spun out of the Donald Danforth Pla…
  - (2026-09-22) [St. Louis] Impossible Mart & Variety Store opens its doors on Cherokee Street
      Nestled in the vibrant mid-section of Cherokee Street, Impossible Mart & Variety Store breathes new life into a previously vacant historic commercial building. After living in the neighborhood for the past 20 years, the…
  - (2026-09-22) [St. Louis] Where Art Thou 9/22/2026
      Recognize this St. Louis art? Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess” once you’r…
  - (2026-09-21) [St. Louis] DD Mau celebrates Mid-Autumn Festival with a special dumpling menu
      This Friday marks Mid-Autumn Festival, a traditional Asian celebration centered on the fall harvest. The date of the festival changes each year and is determined according to the lunar calendar—the 15th day of the eighth…
  - (2026-09-21) [St. Louis] Where to find the best gooey butter cake in St. Louis
      Britt’s Bakehouse Britt Royal began her baked goods business with an inclusive vision: Everyone deserves great desserts, even if they are gluten-free. That philosophy animated her operation at the Kirkwood Farmer’s Marke…

### U.S. Weather + Severe / Climate Outlooks — 125 new of 127 total
  - (2026-09-22) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-22) [Severe] Flood Warning: Flood Warning issued September 22 at 8:07AM EDT until September 22 at 9:00PM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Central Athens County in southeastern Ohio... Southwestern Morgan County in southeastern Ohio... Northeastern Vinton County in southeastern Ohio... West…
  - (2026-09-22) [Severe] Flood Warning: Flood Warning issued September 22 at 8:06AM EDT until September 22 at 9:00PM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Southeastern Athens County in southeastern Ohio... Northeastern Gallia County in southeastern Ohio... Meigs County in southeastern Ohio... Southwestern…
  - (2026-09-22) [Severe] Flood Warning: Flood Warning issued September 22 at 8:05AM EDT until September 22 at 9:00PM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Southwestern Athens County in southeastern Ohio... Northwestern Meigs County in southeastern Ohio... Northeastern Vinton County in southeastern Ohio...…
  - (2026-09-22) [Severe] Flood Warning: Flood Warning issued September 22 at 8:04AM EDT until September 22 at 9:00PM EDT by NWS Charleston WV
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Northern Jackson County in southeastern Ohio... Northwestern Meigs County in southeastern Ohio... Northern Vinton County in southeastern Ohio... * WHEN.…
  - (2026-09-22) [Moderate] Coastal Flood Watch: Coastal Flood Watch issued September 22 at 7:50AM EDT until September 24 at 11:00AM EDT by NWS Baltimore MD/Washington DC
      * WHAT...For the Coastal Flood Advisory, up to one and a half feet of inundation above ground level expected in low lying areas due to tidal flooding. For the Coastal Flood Watch, up to two feet of inundation above groun…

### State Legislative Action — 90 new of 106 total
  - (2026-09-22) [Alaska HCR 9] Honoring the 250th anniversary of the signing of the Declaration of Independence and celebrating the 250th birthday of the United States of America.
      Honoring the 250th anniversary of the signing of the Declaration of Independence and celebrating the 250th birthday of the United States of America.
  - (2026-09-22) [Alaska SB 282] An Act relating to the Joint Armed Services Committee; and providing for an effective date.
      An Act relating to the Joint Armed Services Committee; and providing for an effective date.
  - (2026-09-22) [Alaska SB 195] An Act relating to slow onset disasters; and relating to the Alaska Disaster Act.
      An Act relating to slow onset disasters; and relating to the Alaska Disaster Act.
  - (2026-09-21) [Alaska SB 245] An Act establishing June 21 as Alaska Arts and Culture Day; and providing for an effective date.
      An Act establishing June 21 as Alaska Arts and Culture Day; and providing for an effective date.
  - (2026-09-21) [Alaska SB 239] An Act relating to commercial motor vehicle licensing examinations; relating to the registration and titling of legally imported motor vehicles; relating to proof of financial responsi…
      An Act relating to commercial motor vehicle licensing examinations; relating to the registration and titling of legally imported motor vehicles; relating to proof of financial responsibility for suspension for nonpayment…
  - (2026-09-21) [Alaska SJR 30] Expressing gratitude for the United States military and supporting increased defense readiness through infrastructure development and public-military partnerships.
      Expressing gratitude for the United States military and supporting increased defense readiness through infrastructure development and public-military partnerships.

### Ukrainian Internal News (national + local Kyiv) — 63 new of 130 total
  - (2026-09-22) Лукашенко заявив, що Білорусь не має калію для США, попри обіцянку Трампу | LEDE: Самопроголошений президент Білорусі Олександр Лукашенко заявив, що в країні немає вільних обсягів калійних добр] (uk:…
      Самопроголошений президент Білорусі Олександр Лукашенко заявив, що в країні немає вільних обсягів калійних добрив, які можна було б відправити до США.
  - (2026-09-22) Під Полтавою стався землетрус | LEDE: 22 вересня на Полтавщині зареєстрували землетрус з параметрами магнітудою 4,2.] (uk: Під Полтавою стався землетрус)
      22 вересня на Полтавщині зареєстрували землетрус з параметрами магнітудою 4,2.
  - (2026-09-22) Циклон принесе в Україну значні дощі і грози – прогноз погоди на найближчі дні | LEDE: До кінця тижня в Україні очікується прохолодна і дощова погода, місцями значні дощі та грози.] (uk: Циклон принес…
      До кінця тижня в Україні очікується прохолодна і дощова погода, місцями значні дощі та грози.
  - (2026-09-22) Науседа розкритикував нову карту світу ООН, де Крим зображений окремо від України | LEDE: Президент Литви Гітанас Науседа розкритикував нову політичну карту світу, опубліковану Організацією Об'] (uk:…
      Президент Литви Гітанас Науседа розкритикував нову політичну карту світу, опубліковану Організацією Об'єднаних Націй, у зв'язку з тим, що окупований Росією Крим було зображено окремо від України.
  - (2026-09-22) У Києві жінка готувала замах на ексвійськового ЗСУ, президента федерації з кікбоксингу "К-1" | LEDE: Жительці Запорізької області оголосили підозру в підготовці вбивства ексвійськовослужбовця З] (uk:…
      Жительці Запорізької області оголосили підозру в підготовці вбивства ексвійськовослужбовця ЗСУ, президента федерації з кікбоксингу "К-1", на замовлення спецслужб РФ.
  - (2026-09-22) У ДТП на Вінниччині загинули двоє дітей, ще троє людей поранено | LEDE: Поліція Вінницької області розслідує обставини смертельної ДТП у Гайсинському районі, внаслідок якої загинули двоє дітей,] (uk:…
      Поліція Вінницької області розслідує обставини смертельної ДТП у Гайсинському районі, внаслідок якої загинули двоє дітей, ще троє людей дістали поранення.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-22) [Elsztain Alejandro Gustavo] Form 4 (Reporting)
      filed 2026-09-22 12:10 UTC · role: Reporting — Filed: 2026-09-22 AccNo: 0002119764-26-000024 Size: 4 KB
  - (2026-09-22) [CRESUD INC] Form 4 (Issuer)
      filed 2026-09-22 12:10 UTC · role: Issuer — Filed: 2026-09-22 AccNo: 0002119764-26-000024 Size: 4 KB
  - (2026-09-22) 424B5 - Host Digital Inc. (0001948864) (Filer)
      filed 2026-09-22 12:06 UTC — Filed: 2026-09-22 AccNo: 0001493152-26-043648 Size: 56 KB
  - (2026-09-22) 424B3 - KAZIA THERAPEUTICS LTD (0001075880) (Filer)
      filed 2026-09-22 12:04 UTC — Filed: 2026-09-22 AccNo: 0001213900-26-101975 Size: 39 KB
  - (2026-09-22) [MasterCraft Boat Holdings, Inc.] Form 4 (Issuer)
      filed 2026-09-22 12:04 UTC · role: Issuer — Filed: 2026-09-22 AccNo: 0001193125-26-397254 Size: 5 KB
  - (2026-09-22) [LEEMPUTTE PETER G] Form 4 (Reporting)
      filed 2026-09-22 12:04 UTC · role: Reporting — Filed: 2026-09-22 AccNo: 0001193125-26-397254 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-09-22) [Brazil] Health Shock Plan Targets 1 . 07 Million Colombian Patients
      domain: riotimesonline.com · language: English · tone:
  - (2026-09-22) [Canada] Walhalla Gold Appoints Vice President of Exploration to Advance District Scale Exploration Strategy
      domain: juniorminingnetwork.com · language: English · tone:
  - (2026-09-22) [United States] Police , fire , EMT and mental health : How one city is leading the charge to reshape 911
      domain: houstonpublicmedia.org · language: English · tone:
  - (2026-09-22) [India] Patrick Clancy , new wife Rachel Danis expecting first child together : Cant wait to tell them about …
      domain: hindustantimes.com · language: English · tone:
  - (2026-09-22) [United States] Kansas reports two measles cases associated with travel within the US
      domain: kcur.org · language: English · tone:
  - (2026-09-22) [Canada] From ER to chasing world powerlifting records
      domain: therecord.com · language: English · tone:

### IT, InfoSys & cybersecurity news (last 7 days) — 36 new of 52 total
  - (2026-09-22) [BleepingComputer] New Windows Defender zero-day blocks Microsoft antivirus updates
      Over the weekend, security researcher Abdelhamid Naceri (also known as Nightmare Eclipse) released another Microsoft Defender zero-day exploit that blocks antivirus updates. [...]
  - (2026-09-22) [BleepingComputer] CISA orders feds to patch Zyxel flaw exploited for data theft
      ​Attackers are now actively exploiting a high-severity vulnerability in Zyxel GS1900 series switches, according to the U.S. Cybersecurity and Infrastructure Security Agency (CISA). [...]
  - (2026-09-22) [The Hacker News] DORA Year Two: Can Your SOC Actually See the Attack?
      When the Digital Operational Resilience Act (DORA) became enforceable across the European Union in January 2025, it triggered an administrative sprint. Financial entities spent the first year establishing risk governance…
  - (2026-09-22) [The Hacker News] New Linux Kernel Flaw Gives ARM64 KVM Guests Read-Write Access to Host Memory
      A new flaw in the Linux kernel's KVM virtualization code for ARM64 processors can leave a freed piece of host memory exposed to a guest virtual machine on hosts with nested virtualization enabled. The bug, tracked as CVE…
  - (2026-09-22) [The Hacker News] SharePoint Flaw Initially Listed as Spoofing by Microsoft Enables Authenticated RCE
      A SharePoint Server vulnerability that Microsoft initially classified as a spoofing flaw with a CVSS score of 6.5 actually enables authenticated remote code execution, according to full technical details published today…
  - (2026-09-22) [The Hacker News] Malicious npm Package indexed-btree Hid Its Loader in Runtime Code Before Removal
      A malicious npm package named "indexed-btree" has been observed hiding its malicious behavior within application code rather than using lifecycle scripts, indicating that threat actors are likely shifting tactics in resp…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-22) JAF9BV (Bulgaria)
      icao24: 4520ce · position: (37.428, -5.7579) · alt: 10972m · 848km/h
  - (2026-09-22) PAT085 (United States)
      icao24: adfedb · position: (4.2971, -74.8214) · alt: 5638m · 469km/h
  - (2026-09-22) JAF94H (Bulgaria)
      icao24: 4520aa · position: (34.9641, -8.5363) · alt: 11269m · 820km/h
  - (2026-09-22) SAMU71 (France)
      icao24: 398c4e · position: (46.3286, 4.8687) · alt: 457m · 203km/h
  - (2026-09-22) PAT348 (United States)
      icao24: adfe4c · position: (37.934, -86.0044) · alt: 662m · 316km/h
  - (2026-09-22) JEDI07 (United States)
      icao24: adff0b · position: (30.3534, -87.3103) · alt: 160m · 281km/h

### Court opinions of consequence (federal & state) — 26 new of 60 total
  - (2026-09-21) U.S. Court of Appeals, 2nd Cir.: In Re: IIG Structured Trade Fin. Fund, Ltd.
  - (2026-09-21) U.S. Court of Appeals, 2nd Cir.: Newton v. LVMH Moët Hennessy Louis Vuitton Inc.
  - (2026-09-21) U.S. Court of Appeals, 1st Cir.: DiFronzo v. City of Somerville
  - (2026-09-21) U.S. Court of Appeals, 1st Cir.: United States v. Kinrys
  - (2026-09-21) Hawaii Supreme Court: Patrickson v. DOW Chemical Company and Del Monte Fresh Produce N.A
  - (2026-09-21) Hawaii Supreme Court: Fevella v. Nago

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-09-22) [Russia oil sanctions perimeter · themes] Скільки суден тіньового флоту РФ вдалося знищити бійцям СБС - Мадяр відповів - новини України
      zn.ua · Ukrainian · tone NA
  - (2026-09-22) [Russia oil sanctions perimeter · themes] Aramco Poised to Resume Oil Exports at Red Sea Port
      rigzone.com · English · tone NA
  - (2026-09-22) [Russia oil sanctions perimeter · themes] Rusija izvela masovni udar na vojnu industriju Ukrajine : Pogođeni Fire Point , rafinerija , metalurgija i logistički centri
      informer.rs · Serbian · tone NA
  - (2026-09-22) [Russia oil sanctions perimeter · themes] Noruega debate si recuperar o sellar un submarino nazi con 67 toneladas de mercurio hundido en 1945
      es.euronews.com · Spanish · tone NA
  - (2026-09-22) [Russia oil sanctions perimeter · themes] Зеленський відповів Трампу щодо умов деескалації війни з РФ
      bagnet.org · Ukrainian · tone NA
  - (2026-09-22) [Russia oil sanctions perimeter · themes] Українські удари обмежили перекидання техніки РФ на запорізькому напрямку – ISW
      glavcom.ua · Ukrainian · tone NA

### U.S. Federal Action — 24 new of 24 total
  - (2026-09-22) Restoring American Saltwater Angling and Recreation
  - (2026-09-22) Reinvigorating America's Hunting Heritage
  - (2026-09-22) Establishment of Class E Airspace; Ottawa, IL
      This action establishes Class E airspace at OSF St Francis Medical Center Heliport, Ottawa, IL. This action supports new instrument procedures and instrument flight rule (IFR) operations.
  - (2026-09-22) Fisheries of the Exclusive Economic Zone Off Alaska; “Other Rockfish” in the Aleutian Islands Subarea of the Bering Sea and Aleutian Islands Management Area
      NMFS is prohibiting retention of "other rockfish" in the Aleutian Islands subarea of the Bering Sea and Aleutian Islands management area (BSAI). This action is necessary because the 2026 "other rockfish" total allowable…
  - (2026-09-22) Softwood Lumber Board Assessment Rate Clarification and Changes to Membership
      This final rule implements changes to the Softwood Lumber Research, Promotion, Consumer Education and Industry Information Order (Order). The changes include clarifying the assessment rate for softwood lumber imported in…
  - (2026-09-22) Part 572; Anthropomorphic Test Devices; Test Device for Human Occupant Restraint 50th Percentile Adult Male Dummy (THOR-50M)
      This document supplements NHTSA's September 2023 notice of proposed rulemaking to amend NHTSA's regulations to include an advanced crash test dummy (the Test Device for Human Occupant Restraint (THOR) 50th percentile adu…

### Paper Trading Scorecard — 23 new of 132 total
  - (2026-09-22) [Polymarket] Will FC Dallas win the 2026 MLS Cup?
      This market will resolve according to the team that wins the 2026 MLS Cup. If at any point it becomes impossible for a listed team to win the 2026 MLS Cup per the rules of MLS (e.g. they are mathematically eliminated), t…
  - (2026-09-22) [Manifold] GPT 6 Sol released today?
  - (2026-09-22) [Manifold] Will Trump's approval rating hit 38% or lower before Dec 1st 2026
  - (2026-09-22) [Manifold] Will bluelinfish1 reach Celestial before bluelinfish reaches Master?
  - (2026-09-22) [Manifold] Will a hurricane make landfall in a US state (Pacific)?
  - (2026-09-22) [Manifold] Is the Susan Collins Polling Rumour true?

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-09-22) Will Glenn Youngkin win the 2028 US Presidential Election?
      yes price: 0% · 24h volume: $681,841 · resolves 2029-01-21
  - (2026-09-22) Dota 2: Natus Vincere vs 1win - Game 2 Winner
      yes price: 100% · 24h volume: $666,050 · resolves 2026-09-22
  - (2026-09-22) Ankara: Elena Pridankina vs Daria Egorova
      yes price: 100% · 24h volume: $421,936 · resolves 2026-09-29
  - (2026-09-22) Will there be no change in Fed interest rates after the October 2026 meeting?
      yes price: 50% · 24h volume: $344,117 · resolves 2026-10-29
  - (2026-09-22) 2026 Balance of Power: R Senate, R House
      yes price: 6% · 24h volume: $328,179 · resolves 2026-11-03
  - (2026-09-22) Korea Open: Alina Charaeva vs Sofia Kenin
      yes price: 100% · 24h volume: $311,489 · resolves 2026-09-28

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-09-21) M 5.3 - 97 km S of Sarangani, Philippines
      M5.3 · 97 km S of Sarangani, Philippines · depth 10 km
  - (2026-09-22) M 5.1 - 88 km NNW of Uken, Japan
      M5.1 · 88 km NNW of Uken, Japan · depth 10 km
  - (2026-09-22) M 5.0 - Volcano Islands, Japan region
      M5.0 · Volcano Islands, Japan region · depth 10 km
  - (2026-09-21) M 5.0 - South Sandwich Islands region
      M5.0 · South Sandwich Islands region · depth 10 km
  - (2026-09-21) M 5.0 - 38 km E of Nobeoka, Japan
      M5.0 · 38 km E of Nobeoka, Japan · depth 42.736 km
  - (2026-09-22) M 4.9 - Volcano Islands, Japan region
      M4.9 · Volcano Islands, Japan region · depth 10 km

### Government Action: Sanctions + Procurement + Foreign Agents — 7 new of 106 total
  - (2026-09-18) [OFAC] Russian Harmful Foreign Activities Sanctions - Office of Foreign Assets Control (.gov)
      Russian Harmful Foreign Activities Sanctions Office of Foreign Assets Control (.gov)
  - (2026-09-22) [USASpending] $2,605,576,613 → SAVANNAH RIVER MISSION COMPLETION, LLC: THIS AWARD IS FOR THE SAVANNAH RIVER INTEGRATED MISSION COMP
      Agency: Department of Energy. Description: THIS AWARD IS FOR THE SAVANNAH RIVER INTEGRATED MISSION COMPLETION CONTRACT - TASK ORDER 6 (LIQUID WASTE OPERATIONS).
  - (2026-09-22) [USASpending] $2,010,277,191 → BLUE ORIGIN MANUFACTURING, LLC: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING
      Agency: National Aeronautics and Space Administration. Description: RAPID DDT&E AND DEMONSTRATION OF S SUSTAINABLE HUMAN LANDING SYSTEM INTEGRATED LANDER.
  - (2026-09-22) [USASpending] $1,288,723,797 → CALIFORNIA INSTITUTE OF TECHNOLOGY: M2020 MARS SCIENCE ROVER PROJECT-PHASE A-D 60-19107 THE CON
      Agency: National Aeronautics and Space Administration. Description: M2020 MARS SCIENCE ROVER PROJECT-PHASE A-D 60-19107 THE CONTRACT IS THE SPONSORING AGREEMENT BETWEEN THE NATIONAL AERONAUTICS AND SPACE ADMINISTRATION N…
  - (2026-09-22) [USASpending] $822,520,664 → TECHFLOW, INC.: EXPLOSIVE DETECTION SYSTEM (EDS) PERFORMANCE BASED LOGISTICS
      Agency: Department of Homeland Security. Description: EXPLOSIVE DETECTION SYSTEM (EDS) PERFORMANCE BASED LOGISTICS (PBL)
  - (2026-09-22) [USASpending] $817,360,385 → SYNCOM SPACE SERVICES LLC: IGF::OT::IGF SYNERGY-ACHIEVING CONSOLIDATED OPERATIONS AND M
      Agency: National Aeronautics and Space Administration. Description: IGF::OT::IGF SYNERGY-ACHIEVING CONSOLIDATED OPERATIONS AND MAINTENANCE, COST PLUS INCENTIVE FEE - INDEFINITE DELIVERY INDEFINITE QUANTITY

### World News (by country, top stories) — 6 new of 6 total
  - (2026-09-22) [China] 亚运男子4×100混接中国四连冠 _ 百度搜索
      baidu.com · English
  - (2026-09-22) [China] China Daily Website - Connecting China Connecting the World
      chinadaily.com.cn · English
  - (2026-09-22) [China] John Smedley launches The Original Muse
      knittingindustry.com · English
  - (2026-09-22) [China] EURATEX urges competitiveness action
      knittingindustry.com · English
  - (2026-09-22) [China] vivo launches X500 Pro series with Dimensity 9600 Pro , starting at RMB 6 , 499 · TechNode
      technode.com · English
  - (2026-09-22) [China] China active AI agents could reach 197 million by 2030 , report says · TechNode
      technode.com · English

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-09-22) [Marginal Revolution] Dartmouth Provost okie-dokie
      On Aug. 26, a Semafor investigation using Pangram to determine whether recent guest columns in major newspapers were written using artificial intelligence identified a column by Schnell as “100% AI-written.” Schnell’s co…
  - (2026-09-22) [Marginal Revolution] Banning self-recursive improvement in AI models?
      Some people are suggesting this, including Ezra Klein. I do not understand how it is supposed to work. Put aside the issue of foregone innovations, let us say I seek to access an AI from overseas. Am I allowed to visit t…
  - (2026-09-21) [Marginal Revolution] Further results on AI and labor market reallocation
      This paper documents how artificial intelligence has affected stocks and flows in the U.S. labor market. Combining CPS and JOLTS data with AI exposure and adoption measures from OpenAI and Lightcast, respectively, we con…
  - (2026-09-21) [Conversable Economist] US Manufacturing Jobs: The Long Transition
      The basic patterns of US manufacturing jobs are fairly well-known. Here’s a figure showing total US manufacturing jobs over the last half-century or so: more-or-less flat from the 1970s up through 2000, then a decline fr…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 22 total
  - (2026-09-21) CVE-2026-7273 · Zyxel GS1900 Series Switches: Zyxel GS1900 Series Switches Stack-Based Buffer Overflow Vulnerability
      vendor: Zyxel · product: GS1900 Series Switches · CISA remediation by 2026-09-24

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-22) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=24, 7d-median=18, 14d-median=19; carrying terms: proposing, management, proposes, navigable, proposed, program, final, certain, provisions, prompted, address, needed
- state_bills: today=106, 7d-median=81, 14d-median=90; carrying terms: instead, employees, college, history, information, develop, crime, various, appropriation, management, submit, environmental
- state_news: today=505, 7d-median=683, 14d-median=549; carrying terms: toward, committee, employees, redirects, began, concerns, hawaii, history, several, analysis, front, information
- local_news: today=238, 7d-median=238, 14d-median=231; carrying terms: shooting, blank, according, games, target, community, culture, atlantamagazine, https, crash, injured, police
- foreign_news: today=994, 7d-median=1045, 14d-median=994; carrying terms: language, australia, driver, toward, committee, platform, fears, concerns, history, front, african, islands
- chinese_internal: today=286, 7d-median=284, 14d-median=284; carrying terms: cbmidefvx, cbmiakfvx, blank, cbmizkfvx, cbmib, target, cbmibkfvx, https, cbmickfvx, lxtfb, global, articles
- russian_internal: today=1029, 7d-median=1067, 14d-median=1059; carrying terms: anthropic, europe, server, httperror, novayagazeta, raquo, found, media, russian, https, times, istories
- ukrainian_internal: today=130, 7d-median=136, 14d-median=135; carrying terms: industry, toward, drones, donetsk, europe, concerns, shahed, intelligence, attacked, political, world, report
- ukraine_theater: today=426, 7d-median=450, 14d-median=426; carrying terms: cbmixefvx, donetsk, drones, vzxhjdxppbzdwegdz, cuxnzghps, polygon, zkywukptvuvnm, history, information, zzhxufu, rhaybw, mobile
- paper_bets: today=132, 7d-median=126, 14d-median=128; carrying terms: washington, arizona, nominee, humanoid, special, levels, chuck, hampshire, kalshi, president, anthropic, performing
- weather: today=127, 7d-median=116, 14d-median=116; carrying terms: worth, above, islands, baltimore, continues, discussion, outlook, dangerous, mountains, especially, persist, evening
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, effective, personal, dcoilwtico, money, vixcls, total, jtsjol, unemployment, assets, rates, labor
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: nasdaq, russell, large, china, equities, close, range, crude, crypto, agriculture, commodities, yield
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=106, 7d-median=106, 14d-median=107; carrying terms: haitian, measures, google, integrity, democratic, state, sudan, concerning, african, violations, daesh, russian
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiver, quiverquant, unauthorized, error, congresstrading, https, quantitative, httperror, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, supreme, appeals, court, company, delaware, arizona, blanche, international, connecticut, trade, services
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting, holdings, trust, filer, tidal, subject, group, therapeutics, financial
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: senate, ossoff, sherrod, johnson, filing, alexandria, raised, congress, committee, angels, receipts, lindsey
- gdelt_regions: today=6, 7d-median=0, 14d-median=6; carrying terms: english
- gdelt_gkg: today=25, 7d-median=50, 14d-median=50; carrying terms: english, minister, sanctions, ukrainian, perimeter, themes, russia, chinese, world, spanish, turkish, polish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, germany, kingdom, france, ground, bulgaria, canada, slovenia
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: countries, probable, institute, fourth, passengers, previous, response, disease, ingredient, announcing, different, focal
- cisa_kev: today=22, 7d-median=21, 14d-median=21; carrying terms: function, netscaler, vendor, authentication, bounds, google, jfrog, missing, microsoft, artifactory, command, write
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=14, 7d-median=15, 14d-median=13; carrying terms: depth, indonesia, islands, japan, colombia, region, south, sandwich
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, resolves, donetsk, interest, league, shakhtar, champions, meeting, rates, championship, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, class, economist, revolution, conversableeconomist, conversable, marginal, report, benefits, marginalrevolution, recent, current
- tech_news: today=52, 7d-median=57, 14d-median=57; carrying terms: latest, score, intelligence, world, companies, security, according, infrastructure, speed, today, openai, cybersecurity
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: wicker, ayanna, elfreth, schakowsky, sykes, castro, tammy, frank, budzinski, menendez, griffith, meeks
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placed, evidence, sufficient, markets, unavailable, consensus, paper, today, converges, decision, placement, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-10] Fed press (events + announcements): Agencies reduce regulatory burden for community banks, increase eligibility for 18-month exam cycle
- [2026-09-11] Fed press (events + announcements): Agencies seek comment on proposed third-party risk management guidance and issue statement on community bank engagement with core service providers
- [2026-09-14] ECB press: Piero Cipollone: The future of euro cash: trusted today, designed for tomorrow
- [2026-09-14] ECB press: Christine Lagarde: A new age of capital: growth, sovereignty and AI
- [2026-09-16] ECB press: ECB wage tracker at 2.7% in H1 2027, pointing to a modest uptick in negotiated wage growth
- [2026-09-16] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-09-16] Fed press (events + announcements): Federal Reserve Board and Federal Open Market Committee release economic projections from the September 15-16 FOMC meeting
- [2026-09-18] ECB press: Boris Vujčić: Interview with Reuters
- [2026-09-18] ECB press: ECB Consumer Expectations Survey results – August 2026
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with SNB Bancshares and Bank of Eufaula
- [2026-09-18] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Northstar Bank, former employee of American Express Travel Related Services Company, Inc., and former employee of Regions Bank
- [2026-09-21] ECB press: ECB to invest part of own funds in tokenised securities, with settlement via Pontes
- [2026-09-21] ECB press: Eurosystem brings central bank money to tokenised finance
- [2026-09-22] ECB press: Philip R. Lane: Interview with Le Temps

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*