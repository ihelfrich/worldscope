# WORLDSCOPE morning brief — 2026-05-27

## Headline
3692 new items across 35 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 583 new of 583 total
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-27) [feed error] AZ Governor (Arizona): HTTPError
      404 Client Error: Not Found for url: https://azgovernor.gov/feed
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] The form asked my permission to share my health data. Then it wouldn’t let me say no.
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052226-OPT-OUT-MAZES-GH-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos
  - (2026-05-27) [California] Our house burned down but our mortgage didn’t. California fire survivors need time
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/02/011425-Palisades-Aftermath-TS-08.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 133 new of 133 total
  - (2026-05-27) [St. Louis] Chemical tank implosion at Washington paper mill kills 1. Here's the latest on the search for 9 others.
      One worker was killed and nine others were unaccounted for with no hope for rescue, authorities said. Nine others were injured.
  - (2026-05-27) [St. Louis] Downtown St. Louis tower scheduled to be auctioned
      An online auction of the 30-story Bank of America Plaza at 800 Market St. is scheduled to open at noon on June 22, with a $2 million starting bid.
  - (2026-05-27) [St. Louis] Five decades later, families still fighting to add 74 sailors to Vietnam Veterans Memorial Wall
      More than 50 years after the deadly USS Frank E. Evans collision, survivors and lawmakers say the sailors deserve recognition on the memorial wall.
  - (2026-05-27) [St. Louis] President Trump gathers Cabinet as he looks to seal deal to end the war with Iran
      President Donald Trump meets with his Cabinet at a precarious moment for talks aimed at ending the war with Iran.
  - (2026-05-27) [St. Louis] Israel says strikes killed Hamas military leader just days after his predecessor died
      At least five people were killed and 12 injured in Tuesday's strike on the eve of Eid al-Adha, a major Muslim holiday, according to local hospitals.
  - (2026-05-27) [St. Louis] 'I have so much love for this city' | Travis Kelce buys minority stake in Cleveland Guardians
      Curtis Danburg, vice president of communications and community impact for the Guardians, told Ohio TV station 3News early Wednesday morning.
  - (2026-05-27) [St. Louis] Matthew Perry assistant who injected him with ketamine faces final sentencing in overdose case
      Matthew Perry’s longtime assistant faces sentencing Wednesday for supplying and injecting the ketamine that caused the “Friends” star’s death.
  - (2026-05-27) [St. Louis] Teen charged with killing stepsister on Carnival Cruise could be jailed until trial
      Hudson has pleaded not guilty to charges of first-degree murder and aggravated sexual abuse in relation to his stepsister's killing last year.

### International News + Multilateral Institutions — 887 new of 887 total
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [feed error] AP Top News (RSSHub): HTTPError
      403 Client Error: Forbidden for url: https://rsshub.app/ap/topics/apf-topnews
  - (2026-05-27) [Global] Ebola-hit DR Congo faces 'catastrophic collision' of disease and conflict, WHO warns
      Tedros Adhanom Ghebreyesus said fighting in DR Congo was hampering efforts to stop spread
  - (2026-05-27) [Global] Israeli strike in Gaza City kills new head of Hamas's military wing
      Hamas says Mohammed Odeh was killed alongside his wife and two children in a strike on a residential building.
  - (2026-05-27) [Global] Five people found alive after week trapped in flooded Laos cave
      The search is continuing for a further two villagers who are still missing, rescuers say.
  - (2026-05-27) [Global] Dozens killed in Lebanon as Israel intensifies strikes
      Israel says it struck 100 Hezbollah infrastructure sites and fighters in Lebanon, after PM Benjamin Netanyahu vows to "crush" the Iran-backed group.

### Chinese Internal News — 4 new of 4 total
  - (2026-05-27) [feed error] Caixin Global: HTTPError
      404 Client Error: Not Found for url: https://www.caixinglobal.com/rss/news.xml
  - (2026-05-27) [feed error] Sixth Tone: HTTPError
      404 Client Error: Not Found for url: https://www.sixthtone.com/feed
  - (2026-05-27) [feed error] Caijing 财经: HTTPError
      404 Client Error: Not Found for url: https://www.caijing.com.cn/rss/topnews.xml
  - (2026-05-27) [feed error] People's Daily 人民日报: ConnectTimeout
      HTTPConnectionPool(host='rss.people.com.cn', port=80): Max retries exceeded with url: /rss/politics.xml (Caused by ConnectTimeoutError(<HTTPConnection(host='rss.people.com.cn', port=80) at 0x7fe964ba3710>, 'Connection to

### Russian Internal News (state + in-exile) — 1124 new of 1124 total
  - (2026-05-27) [TITLE: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. Там она воспроизводит тезисы российской пропаганды | LEDE: <p>Бывший главный редактор RT France Ксения Федорова у] (ru: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. )
      <p>Бывший главный редактор RT France Ксения Федорова устроилась на работу на французском правоконсервативном телеканале CNews, рассказывается в публикациях Politico и русской службы RFI. <p>
  - (2026-05-27) [TITLE: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за пределы Украины и объявит новую мобилизацию | LEDE: <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает] (ru: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за п)
      <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. К
  - (2026-05-27) [TITLE: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли более 20 студентов колледжа. Вот что о них и об этой атаке рассказывают однокурсники и друзья | LEDE: <p>В ночь на ] (ru: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли бо)
      <p>В ночь на 22 мая украинские войска нанесли удар беспилотниками по Старобельску в аннексированной ЛНР. Под обстрел попали педагогический колледж и профессиональный колледж Луганского педагогического университета. По оф
  - (2026-05-27) [TITLE: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской области объяснили, зачем запретили иностранные надписи на школьной одежде | LEDE: <p>Департамент образования Томской] (ru: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской обл)
      <p>Департамент образования Томской области заявил, что запрет носить одежду с иностранными надписями, принятый в нескольких школах региона, призван уберечь детей от «чуждых и опасных» смыслов.<p>
  - (2026-05-27) [TITLE: Парламент Венгрии остановил выход страны из Международного уголовного суда, начатый предыдущим премьером Виктором Орбаном | LEDE: <p>Парламент Венгрии одобрил отзыв решения о выходе страны из М] (ru: Парламент Венгрии остановил выход страны из Международного уголовного суда, нача)
      <p>Парламент Венгрии одобрил отзыв решения о выходе страны из Международного уголовного суда (МУС).<p>
  - (2026-05-27) [TITLE: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей или до пяти лет лишения свободы | LEDE: <p>Госдума приняла в первом чтении законопроект о наказании за незаконный] (ru: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей )
      <p>Госдума приняла в первом чтении законопроект о наказании за незаконный майнинг. Документ вводит в Уголовный кодекс новую статью 171.6.<p>
  - (2026-05-27) [TITLE: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Германии | LEDE: <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит дейст] (ru: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Ге)
      <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит действующий канцлер Германии Фридрих Мерц, обсуждаются варианты его замены, пишут таблоиды Stern и Bild.<p>
  - (2026-05-27) [TITLE: The Economist: власти Украины готовятся еще к двум-трем годам войны. Советник Зеленского: это — «старый вброс» | LEDE: <p>Президент Украины Владимир Зеленский «приказал готовиться к еще двум-тр] (ru: The Economist: власти Украины готовятся еще к двум-трем годам войны. Советник Зе)
      <p>Президент Украины Владимир Зеленский «приказал готовиться к еще двум-трем годам войны», пишет The Economist со ссылкой на правительственные источники.<p>

### Ukrainian Internal News (national + local Kyiv) — 133 new of 133 total
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-27) [TITLE: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув пес | LEDE: Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них гос] (uk: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув п)
      Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них госпіталізовано.
  - (2026-05-27) [TITLE: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали на боці РФ | LEDE: Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зус] (uk: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали н)
      Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зустріч із лідеркою білоруської опозиції Світланою Тихановською та її командою. Вони мали змогу поспілкуватися з військовополоне
  - (2026-05-27) [TITLE: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз РФ | LEDE: Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для зах] (uk: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз )
      Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для захисту від російських ракет.
  - (2026-05-27) [TITLE: Елітний підрозділ ССО отримав найменування на честь Героїв УПА | LEDE: Президент Володимир Зеленський присвоїв почесне найменування "імені Героїв УПА" Окремому центру спеціальних операцій "Півн] (uk: Елітний підрозділ ССО отримав найменування на честь Героїв УПА)
      Президент Володимир Зеленський присвоїв почесне найменування "імені Героїв УПА" Окремому центру спеціальних операцій "Північ" Сил спеціальних операцій ЗСУ.
  - (2026-05-27) [TITLE: 200 тисяч за "мовчання": командира та старшину підозрюють у вимаганні грошей з військового | LEDE: Командиру роти та старшині однієї з бригад Дніпропетровщини оголосили підозру у вимаганні грош] (uk: 200 тисяч за "мовчання": командира та старшину підозрюють у вимаганні грошей з в)
      Командиру роти та старшині однієї з бригад Дніпропетровщини оголосили підозру у вимаганні грошей з військового.
  - (2026-05-27) [TITLE: У ЗСУ спростовують заяву росіян про окупацію села на Харківщині біля кордону з РФ | LEDE: Село Гранів Харківської області перебуває під контролем ЗСУ — заявили у Збройних силах, спростувавши фе] (uk: У ЗСУ спростовують заяву росіян про окупацію села на Харківщині біля кордону з Р)
      Село Гранів Харківської області перебуває під контролем ЗСУ — заявили у Збройних силах, спростувавши фейки армії РФ.
  - (2026-05-27) [TITLE: Кличко назвав фонтан "найбільш нейтральним рішенням" для місця, де раніше стояв пам’ятник Леніну | LEDE: Мер Києва Віталій Кличко заявив, що фонтан є "найбільш нейтральним рішенням" для громадс] (uk: Кличко назвав фонтан "найбільш нейтральним рішенням" для місця, де раніше стояв )
      Мер Києва Віталій Кличко заявив, що фонтан є "найбільш нейтральним рішенням" для громадського простору на місці колишнього пам'ятника Леніну навпроти Бессарабського ринку, оскільки встановлення будь-якої скульптури викли

### Paper Trading Scorecard — 139 new of 139 total
  - (2026-05-27) [Polymarket] Will OpenAI have the best AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is checked
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Monte win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Aurora win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso

### U.S. Weather + Severe / Climate Outlooks — 120 new of 120 total
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 9:13AM CDT by NWS Brownsville TX
      At 913 AM CDT, Doppler radar was tracking a cluster of strong
thunderstorms over Cameron County moving east at 65 mph.

HAZARD...Wind gusts up to 50 mph.

SOURCE...Radar indicated.

IMPACT...Gusty winds could knock down 
  - (2026-05-27) [Severe] Flash Flood Warning: Flash Flood Warning issued May 27 at 10:12AM EDT until May 27 at 1:15PM EDT by NWS Wilmington OH
      FFWILN

The National Weather Service in Wilmington has issued a

* Flash Flood Warning for...
Northwestern Fairfield County in central Ohio...
Central Franklin County in central Ohio...
Southwestern Licking County in cen
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 10:06AM EDT until May 29 at 5:18AM EDT by NWS Columbia SC
      ...The Flood Warning is extended for the following rivers in South
Carolina...

Saluda River At Saluda River at Chappells affecting Greenwood,
Saluda and Newberry Counties.

* WHAT...Minor flooding is occurring and minor
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 10:05AM EDT until May 27 at 8:00PM EDT by NWS Newport/Morehead City NC
      * WHAT...Dangerous rip currents.

* WHERE...The beaches from Cape Hatteras to Surf City.

* WHEN...Until 8 PM EDT this evening.

* IMPACTS...Rip currents can sweep even the best swimmers away
from shore into deeper water
  - (2026-05-27) [Severe] Special Marine Warning: Special Marine Warning issued May 27 at 8:56AM CDT until May 27 at 11:00AM CDT by NWS Houston/Galveston TX
      SMWHGX

The National Weather Service in League City has issued a

* Special Marine Warning for...
Coastal waters from Freeport to Matagorda Ship Channel TX out 20
NM...
Matagorda Bay...
Waters from Freeport to Matagorda 
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 8:56AM CDT by NWS Brownsville TX
      At 856 AM CDT, Doppler radar was tracking a cluster of strong
thunderstorms over Rio Hondo Elementary School, or near Rio Hondo,
moving northeast at 85 mph.

HAZARD...Wind gusts of 50 to 55 mph.

SOURCE...Radar indicated
  - (2026-05-27) [Moderate] Wind Advisory: Wind Advisory issued May 27 at 6:42AM PDT until May 27 at 8:00PM PDT by NWS Elko NV
      * WHAT...Sustained southeast to south winds 25 to 35 mph, with gusts
near 55 mph expected.

* WHERE...White Pine, Northern Elko, Ruby Mountains and East
Humboldt Range in Elko, South Central Elko, and Southeastern Elko
C

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 29 new of 29 total
  - (2026-05-27) [crypto] BTC: $74,895.0000  (24h: -3.32%)
      price=$74895  mcap=$1,502,274,846,729  vol24=$39,852,365,964  chg24=-3.3236712920094154%
  - (2026-05-27) [crypto] ETH: $2,059.2900  (24h: -3.37%)
      price=$2059.29  mcap=$249,173,209,641  vol24=$15,187,097,362  chg24=-3.374425333534128%
  - (2026-05-27) [crypto] USDT: $0.9983  (24h: -0.06%)
      price=$0.998275  mcap=$189,248,408,713  vol24=$66,836,208,224  chg24=-0.060913926651445655%
  - (2026-05-27) [crypto] USDC: $0.9998  (24h: -0.01%)
      price=$0.999825  mcap=$76,322,757,765  vol24=$18,588,686,221  chg24=-0.008470983513128137%
  - (2026-05-27) [crypto] BNB: $651.9500  (24h: -1.93%)
      price=$651.95  mcap=$87,887,515,704  vol24=$963,648,119  chg24=-1.9322094571095956%
  - (2026-05-27) [crypto] SOL: $83.6500  (24h: -2.22%)
      price=$83.65  mcap=$48,378,751,035  vol24=$2,562,937,876  chg24=-2.222637550990644%
  - (2026-05-27) [crypto] XRP: $1.3200  (24h: -2.75%)
      price=$1.32  mcap=$81,845,248,113  vol24=$1,638,443,739  chg24=-2.7535336256362295%
  - (2026-05-27) [crypto] DOGE: $0.1012  (24h: -1.63%)
      price=$0.10116  mcap=$15,677,129,910  vol24=$735,417,270  chg24=-1.629046842274326%

### Government Action: Sanctions + Procurement + Foreign Agents — 33 new of 33 total
  - (2026-05-27) [ofac_recent error] HTTPError
      404 Client Error: Not Found for url: https://ofac.treasury.gov/recent-actions/feed
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [dcsca error] HTTPError
      403 Client Error: Forbidden for url: https://www.dsca.mil/press-media/major-arms-sales
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR
  - (2026-05-27) [USASpending] $10,494,204,426 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration.  Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF

### Congressional STOCK Act Trades (House + Senate) — 2 new of 2 total
  - (2026-05-27) [STOCK Act senate error] HTTPError
      403 Client Error: Forbidden for url: https://senate-stock-watcher-data.s3-us-west-2.amazonaws.com/aggregate/all_transactions.json
  - (2026-05-27) [STOCK Act house error] HTTPError
      403 Client Error: Forbidden for url: https://house-stock-watcher-data.s3-us-west-2.amazonaws.com/data/all_transactions.json

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 3 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-05-27 14:15 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014102 Size: 1 MB
  - (2026-05-27) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-05-27 14:15 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014102 Size: 1 MB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 14:14 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014101 Size: 1 MB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 14:14 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014101 Size: 1 MB
  - (2026-05-27) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-05-27 14:14 UTC — Filed: 2026-05-27 AccNo: 0000950103-26-007763 Size: 268 KB
  - (2026-05-27) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-05-27 14:14 UTC — Filed: 2026-05-27 AccNo: 0000950103-26-007763 Size: 268 KB
  - (2026-05-27) 424B2 - BofA Finance LLC (0001682472) (Filer)
      filed 2026-05-27 14:13 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014100 Size: 1 MB
  - (2026-05-27) 424B2 - BANK OF AMERICA CORP /DE/ (0000070858) (Filer)
      filed 2026-05-27 14:13 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014100 Size: 1 MB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [United Kingdom] Minister rejects Blair triple lock warning as ex - PM calls for  coherent plan  
      domain: redditchadvertiser.co.uk · language: English · tone: 
  - (2026-05-27) [Ireland] (no title)
      domain: dublinpeople.com · language: English · tone: 
  - (2026-05-27) [India] Woman sarpanch killed in road accident in Punjab Hoshiarpur
      domain: tribuneindia.com · language: English · tone: 
  - (2026-05-27) [China] Column : The Tokyo Trials at 80 : A warning bell that still rings
      domain: chinanationalnews.com · language: English · tone: 
  - (2026-05-27) [Canada] New fire chief in Lambton Shores greeted by large fire in Grand Bend
      domain: chathamdailynews.ca · language: English · tone: 
  - (2026-05-27) [United States] Trump gathers Cabinet as he looks to seal deal to end Iran war
      domain: dailypress.com · language: English · tone: 
  - (2026-05-27) [United States] San Quentin prisoners convicted in Contra Costa crimes try to make amends from behind bars
      domain: eastbaytimes.com · language: English · tone: 
  - (2026-05-27) [United Kingdom] Stark warning not to kill flies coming into your house this week
      domain: express.co.uk · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-05-27) PAT914 (United States)
      icao24: adfeda · position: (42.8119, -73.7972) · alt: 335m · 202km/h
  - (2026-05-27) PAT828 (United States)
      icao24: adfe4a · position: (32.6424, -88.3958) · alt: 8229m · 520km/h
  - (2026-05-27) NCR327 (United States)
      icao24: ab4ec6 · position: (33.4583, -89.1795) · alt: 11582m · 822km/h
  - (2026-05-27) RFF04 (Portugal)
      on ground · 19km/h
  - (2026-05-27) CFC2931 (Canada)
      icao24: c2b585 · position: (47.1694, 13.8185) · alt: 10370m · 605km/h
  - (2026-05-27) FNY5566 (France)
      icao24: 39a407 · position: (48.5085, -3.6743) · alt: 1638m · 554km/h
  - (2026-05-27) PAT090 (United States)
      icao24: ae08fa · position: (39.115, -81.2175) · alt: 3596m · 425km/h
  - (2026-05-27) JAF7TJ (Belgium)
      icao24: 44d1ba · position: (38.6464, 25.4072) · alt: 11887m · 822km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,067,679 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,958,958 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,802,840 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 100% · 24h volume: $1,722,964 · resolves 2026-05-27
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,694,134 · resolves 2026-07-20
  - (2026-05-27) Will Barack Obama win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $1,144,916 · resolves 2028-11-07
  - (2026-05-27) Dota 2: OG vs Tundra Esports (BO1) - BLAST Slam Group Stage
      yes price: 100% · 24h volume: $932,204 · resolves 2026-05-27
  - (2026-05-27) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $924,794 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-26) [Marginal Revolution] *How to Win a Trade War: An Optimistic Guide to an Anxious Global Economy*
      That is the new Soumaya Keynes book, out today.  I was happy to have blurbed this book, and here is an essay, on export restrictions, based on the book.
The post *How to Win a Trade War: An Optimistic Guide to an Anxious
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=583, 7d-median=583, 14d-median=583
- local_news: today=133, 7d-median=133, 14d-median=133
- foreign_news: today=887, 7d-median=887, 14d-median=887
- chinese_internal: today=4, 7d-median=4, 14d-median=4
- russian_internal: today=1124, 7d-median=1124, 14d-median=1124
- ukrainian_internal: today=133, 7d-median=133, 14d-median=133
- paper_bets: today=139, 7d-median=139, 14d-median=139
- weather: today=120, 7d-median=120, 14d-median=120
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=29, 7d-median=29, 14d-median=29
- sanctions_procurement: today=33, 7d-median=33, 14d-median=33
- congressional_trades: today=2, 7d-median=2, 14d-median=2
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*