# WORLDSCOPE morning brief — 2026-05-27

## Headline
2196 new items across 29 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 579 new of 579 total
  - (2026-05-27) [feed error] AZ Governor (Arizona): HTTPError
      404 Client Error: Not Found for url: https://azgovernor.gov/feed
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-27) [feed error] CO Governor (Colorado): HTTPError
      403 Client Error: Forbidden for url: https://www.colorado.gov/governor/news/feed
  - (2026-05-27) [Connecticut] CT expanding cannabis use will make roads more dangerous
      <figure><img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/05/pexels-lighting-weed-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" f
  - (2026-05-27) [Connecticut] CT talks housing, but doesn’t walk it
      <figure><img width="855" height="572" src="https://ctmirror.org/wp-content/uploads/2025/03/housing-construction.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="la
  - (2026-05-27) [Connecticut] Why I’m biking 100 miles: to end fossil fuels
      <figure><img width="1024" height="620" src="https://ctmirror.org/wp-content/uploads/2026/05/sierra-club-ride-poster-1024x620.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async
  - (2026-05-27) [Connecticut] Larson tries to shift narrative to ideologies, not generations
      <figure><img width="1024" height="932" src="https://ctmirror.org/wp-content/uploads/2026/05/IMG_0742-1024x932.jpeg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="laz
  - (2026-05-27) [Connecticut] Josh Elliott endorsed for House reelection as he runs for governor
      <figure><img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/05/9F6833C7-657E-4762-A371-595F9DBF8FB7-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" de

### Local News: St. Louis + Atlanta — 133 new of 133 total
  - (2026-05-27) [feed error] Riverfront Times (St. Louis): HTTPError
      403 Client Error: Forbidden for url: https://www.riverfronttimes.com/category/news/feed/
  - (2026-05-27) [St. Louis] Chemical tank implosion at Washington paper mill kills 1. Here's the latest on the search for 9 others.
      One worker was killed and nine others were unaccounted for with no hope for rescue, authorities said. Nine others were injured.
  - (2026-05-27) [St. Louis] Downtown St. Louis tower scheduled to be auctioned
      An online auction of the 30-story Bank of America Plaza at 800 Market St. is scheduled to open at noon on June 22, with a $2 million starting bid.
  - (2026-05-27) [St. Louis] Five decades later, families still fighting to add 74 sailors to Vietnam Veterans Memorial Wall
      More than 50 years after the deadly USS Frank E. Evans collision, survivors and lawmakers say the sailors deserve recognition on the memorial wall.
  - (2026-05-27) [St. Louis] President Trump gathers Cabinet as he looks to seal deal to end the war with Iran
      President Donald Trump meets with his Cabinet at a precarious moment for talks aimed at ending the war with Iran.
  - (2026-05-27) [St. Louis] Israel says strikes killed Hamas military leader just days after his predecessor died
      At least five people were killed and 12 injured in Tuesday's strike on the eve of Eid al-Adha, a major Muslim holiday, according to local hospitals.
  - (2026-05-27) [St. Louis] 'I have so much love for this city' | Travis Kelce buys minority stake in Cleveland Guardians
      Curtis Danburg, vice president of communications and community impact for the Guardians, told Ohio TV station 3News early Wednesday morning.
  - (2026-05-27) [St. Louis] Matthew Perry assistant who injected him with ketamine faces final sentencing in overdose case
      Matthew Perry’s longtime assistant faces sentencing Wednesday for supplying and injecting the ketamine that caused the “Friends” star’s death.

### International News + Multilateral Institutions — 865 new of 865 total
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-27) [Global] Energy bills to rise for millions as impact of Iran war hits
      A household using a typical amount of energy will pay £221 a year more, under the regulator's new price cap.
  - (2026-05-27) [Global] What will the energy cap changes mean for my bills?
      Typical annual household bills will rise by 13% when the new energy cap takes effect on 1 July.
  - (2026-05-27) [Global] 'Bullying' and 'overbearing' behaviour behind abrupt BP chairman removal
      BP declined to comment on whether bullying behaviour was part of the reason for his immediate dismissal.
  - (2026-05-27) [Global] Booming AI chip demand helps create two new $1tn club members
      SK Hynix and Micron are the latest tech firms to join the growing list of stocks with mega valuations.
  - (2026-05-27) [Global] Ferrari shares slump after it unveils first fully electric car
      The new Luce model has divided opinion on social media, and comes despite intense pressure from Chinese EV makers.

### Chinese Internal News — 4 new of 4 total
  - (2026-05-27) [feed error] Caixin Global: HTTPError
      404 Client Error: Not Found for url: https://www.caixinglobal.com/rss/news.xml
  - (2026-05-27) [feed error] Sixth Tone: HTTPError
      404 Client Error: Not Found for url: https://www.sixthtone.com/feed
  - (2026-05-27) [feed error] Caijing 财经: HTTPError
      404 Client Error: Not Found for url: https://www.caijing.com.cn/rss/topnews.xml
  - (2026-05-27) [feed error] People's Daily 人民日报: ConnectTimeout
      HTTPConnectionPool(host='rss.people.com.cn', port=80): Max retries exceeded with url: /rss/politics.xml (Caused by ConnectTimeoutError(<HTTPConnection(host='rss.people.com.cn', port=80) at 0x7ff82e6e1410>, 'Connection to

### Paper Trading Scorecard — 140 new of 140 total
  - (2026-05-27) [Polymarket] Will OpenAI have the best AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is checked
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Monte win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Aurora win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 13 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA5] United States v. Hackney
  - (2026-05-22) [CA5] Naoise Ryan v. United States
  - (2026-05-22) [CA5] Plaquemines Parish v. BP America Prod
  - (2026-05-21) [CA5] Megatel v. Mansfield
  - (2026-05-20) [CA5] United States v. Cordova
  - (2026-05-19) [CA5] Olivier v. City of Brandon, MS

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 424B2 - BANK OF NOVA SCOTIA (0000009631) (Filer)
      filed 2026-05-27 13:51 UTC — Filed: 2026-05-27 AccNo: 0001839882-26-025625 Size: 803 KB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 13:51 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014089 Size: 669 KB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 13:51 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014089 Size: 669 KB
  - (2026-05-27) [Hofmeister Brandon J.] Form 4 (Reporting)
      filed 2026-05-27 13:50 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001710651-26-000013 Size: 5 KB
  - (2026-05-27) [CMS ENERGY CORP] Form 4 (Issuer)
      filed 2026-05-27 13:50 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001710651-26-000013 Size: 5 KB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 13:50 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014088 Size: 585 KB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 13:50 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014088 Size: 585 KB
  - (2026-05-27) [Japan Post Holdings Co., Ltd.] Form 4 (Reporting)
      filed 2026-05-27 13:49 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001104659-26-066653 Size: 8 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-05-27) GAF633 (Germany)
      icao24: 3f6533 · position: (50.7741, 7.2825) · alt: 670m · 334km/h
  - (2026-05-27) PAT914 (United States)
      icao24: adfeda · position: (42.78, -73.8062) · alt: 236m · 183km/h
  - (2026-05-27) NCR327 (United States)
      icao24: ab4ec6 · position: (33.0182, -85.8327) · alt: 11582m · 823km/h
  - (2026-05-27) SAMU13 (France)
      icao24: 39c902 · position: (43.3416, 5.4622) · alt: 601m · 232km/h
  - (2026-05-27) CFC2931 (Canada)
      icao24: c2b585 · position: (46.293, 10.9757) · alt: 10363m · 628km/h
  - (2026-05-27) FNY5566 (France)
      icao24: 39a407 · position: (46.8578, -1.5274) · alt: 6964m · 646km/h
  - (2026-05-27) PAT090 (United States)
      icao24: ae08fa · position: (39.8264, -79.9743) · alt: 7299m · 424km/h
  - (2026-05-27) JAF7TJ (Belgium)
      icao24: 44d1ba · position: (40.6888, 22.7466) · alt: 11887m · 853km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,106,178 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,958,865 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,839,301 · resolves 2026-07-20
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,686,915 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 71% · 24h volume: $1,492,112 · resolves 2026-05-27
  - (2026-05-27) Will Barack Obama win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $1,142,035 · resolves 2028-11-07
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX - Game 1 Winner
      yes price: 100% · 24h volume: $989,363 · resolves 2026-05-27
  - (2026-05-27) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $904,558 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-26) [Marginal Revolution] *How to Win a Trade War: An Optimistic Guide to an Anxious Global Economy*
      That is the new Soumaya Keynes book, out today.  I was happy to have blurbed this book, and here is an essay, on export restrictions, based on the book.
The post *How to Win a Trade War: An Optimistic Guide to an Anxious
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=579, 7d-median=579, 14d-median=579
- local_news: today=133, 7d-median=133, 14d-median=133
- foreign_news: today=865, 7d-median=865, 14d-median=865
- chinese_internal: today=4, 7d-median=4, 14d-median=4
- paper_bets: today=140, 7d-median=140, 14d-median=140
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*