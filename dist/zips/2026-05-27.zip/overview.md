# WORLDSCOPE morning brief — 2026-05-27

## Headline
4191 new items across 35 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 591 new of 591 total
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-27) [feed error] AZ Governor (Arizona): HTTPError
      404 Client Error: Not Found for url: https://azgovernor.gov/feed
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] The form asked my permission to share my health data. Then it wouldn’t let me say no.
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052226-OPT-OUT-MAZES-GH-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos
  - (2026-05-27) [California] Our house burned down but our mortgage didn’t. California fire survivors need time
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/02/011425-Palisades-Aftermath-TS-08.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 247 new of 247 total
  - (2026-05-27) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/search/?f=rss
  - (2026-05-27) [St. Louis] Wentzville families push back against land redevelopment plans
      Families that own farmland along Highway N in Wentzville are pushing back against conceptual redevelopment renderings that show dense mixed-use development on their properties.
  - (2026-05-26) [St. Louis] Son sees break in mother’s 1993 murder case; 70-year-old man charged
      Wes Sperino said he will always remember waking up as a child and seeing that his mother was watching him sleep. He’s held onto that memory for decades after his mom was murdered when he was a teen.
  - (2026-05-27) [St. Louis] Scattered showers Wednesday with warm temperatures
      Overcast skies overnight have yielded some showers and storms, mostly over our Illinois counties as expected.
  - (2026-05-26) [St. Louis] Ex-boyfriend used revenge porn to sabotage woman’s business: Prosecutors
      Prosecutors say a St. Louis man attempted to sabotage his ex-girlfriend’s business using revenge porn.
  - (2026-05-27) [St. Louis] Major Case Squad activated in Berkeley, Missouri over man's death
      A man was found shot to death Tuesday evening inside a vehicle in the 8300 block of Airport Road.
  - (2026-05-26) [St. Louis] Four Missouri amendments set for August ballots - What would they do?
      Missouri voters will decide on four statewide constitutional amendments in the August 2026 primary election, headlined by a proposal to gradually eliminate the state's income tax.
  - (2026-05-26) [St. Louis] FBI announces results of violent crime crackdown in St. Louis region
      Federal officials announced the results of a large-scale violent crime crackdown across the St. Louis region that led to dozens of arrests, weapons recovered and drugs seized.

### International News + Multilateral Institutions — 889 new of 889 total
  - (2026-05-27) [Global] Muslims worldwide celebrate Eid al-Adha, the Festival of Sacrifice
      The sacred holiday coincides with Hajj, drawing over 1.7 million pilgrims seeking spiritual fulfilment in Saudi Arabia.
  - (2026-05-27) [Global] Why is Israel attacking Lebanon’s Nabatieh, the major southern city?
      Israel issued forced displacement for Lebanon&#039;s southern city of Nabatieh on Tuesday. Why is it focused on this city?
  - (2026-05-27) [Global] Bangladesh seeks IMF aid: How badly has Iran war hit its economy?
      The International Monetary Fund warns that Iran war could trigger a spike in global debt levels.
  - (2026-05-27) [Global] What is the Lobito Corridor, cited by US Africa envoy as model for ties?
      Washington is set on a trade-focused shift in Africa, but critics say it facilitates further plundering of resources.
  - (2026-05-27) [Global] Rescue teams celebrate as survivors found in Laos cave
      Rescue teams celebrate as survivors found in Laos cave
  - (2026-05-27) [Global] Who is Moise Kouame, the youngest French Open match winner since 1991?
      World no 318&#039;s victory over Marin Cilic also made him the youngest man to claim a Grand Slam victory in 17 years.
  - (2026-05-27) [Global] The Baltics urgently need a de-escalation mechanism; Belarus can help
      Amid growing risk of spillover from the Ukraine war, the Baltic states could seek de-escalation channels through Minsk.
  - (2026-05-27) [Global] Nigeria’s Eid Crisis: When a ram becomes a luxury
      At a Nigerian sheep market, human rights advocate Sadaatu Madaki says that rising prices make Eid difficult for families

### Chinese Internal News — 283 new of 283 total
  - (2026-05-25) Analysis: Dollar’s Pain Is Yuan’s Gain - Caixin Global
      <a href="https://news.google.com/rss/articles/CBMilAFBVV95cUxPV3dBYVFiQWQ2ZWZlVEkxXzRVZ0ZTWjZLcVNPYmpsZTNhX0V5ZXdXUXB5dUVlTUZMcEszWFJKbW52cnplb3lHR3JKVmlzWjdfZ0E4Y1ZYbFZFSXlVRUFUa1lNVTVNY2pyMWVTSlZhNUFrMFlkem1jekxPZ0tzNF
  - (2026-05-26) [TITLE: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxNbVd3eEF4eWdWdHNJMWM0akJ5Z2xpMU5vc3NvbW5wbUJNekVFZ1hnak5lWFRLMGRFRXI3c0IzVTNpWjMwc0l1c] (zh: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报)
      <a href="https://news.google.com/rss/articles/CBMigwFBVV95cUxNbVd3eEF4eWdWdHNJMWM0akJ5Z2xpMU5vc3NvbW5wbUJNekVFZ1hnak5lWFRLMGRFRXI3c0IzVTNpWjMwc0l1cWVyS0NVckx4QVowZFpFeVRtU01FdlNqR2xUMEV1N3J5VEVUNVlNd21kazdEQkpURUpWQmJUUE
  - (2026-05-26) [TITLE: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxQbW40MlpHRlFXQXZQeE1YODFDSzU4VF80Y2wyUkFxMzlqRG1IeVRCbUxpd19jbzlCUVpQVlV3bDNTbXpDUkNkc] (zh: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报)
      <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxQbW40MlpHRlFXQXZQeE1YODFDSzU4VF80Y2wyUkFxMzlqRG1IeVRCbUxpd19jbzlCUVpQVlV3bDNTbXpDUkNkcVJIWThyZ1J5Y0h6WlczWjMtY25NUGRrWWNDX1VoSDFjc1U4Vlk1RmRyX05BNC1jOXhXT1hXTk
  - (2026-05-25) [TITLE: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxQYThWV2FpbHpTMjI0U0o4NlhwRVh2WFcxYkt2RmVIM0RNY0J6dnZjZTlMeG8wOElhX1JXbUFjalRqdGZGUEZrW] (zh: 责编：王 平 柴逸扉 邮箱：gtbhwb@people.cn - 人民日报)
      <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxQYThWV2FpbHpTMjI0U0o4NlhwRVh2WFcxYkt2RmVIM0RNY0J6dnZjZTlMeG8wOElhX1JXbUFjalRqdGZGUEZrWjRyQVdrV1FINFN0UXZmSkJPSExhMnZxLXQ3QVRZY09nd0JhU2NQaWJ0Y0swUFhaZmJUSWF1cn
  - (2026-05-25) [TITLE: 理论·评论 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE8yOC1pRklfSDRBRHV4djNUeGFUOFgtV2tJOW9iTWxQbWRXZ2w4dUtXVElEcm9fRHVnRVlzbkEtbFlqNFdHX1FTZVNxMXhuNk84T3VKS0FNNV] (zh: 理论·评论 - 中国共产党新闻网)
      <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE8yOC1pRklfSDRBRHV4djNUeGFUOFgtV2tJOW9iTWxQbWRXZ2w4dUtXVElEcm9fRHVnRVlzbkEtbFlqNFdHX1FTZVNxMXhuNk84T3VKS0FNNVhyR0tjSHN1SGJ0alZhSERsdF9J?oc=5" target="_blank">理论·
  - (2026-05-25) [TITLE: 2026“缤纷悉尼”灯光音乐节开幕 中国学生作品亮相悉尼港【7】 - 人民网澳新频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMid0FVX3lxTFBqaHEtVVZwRHFjLUpEX1lsZ0FYWkhScDJyUFVoTEtKYmJCanluT1ZjNEZ0TGdKbnhqYTluMXRFMEROb1F0] (zh: 2026“缤纷悉尼”灯光音乐节开幕 中国学生作品亮相悉尼港【7】 - 人民网澳新频道)
      <a href="https://news.google.com/rss/articles/CBMid0FVX3lxTFBqaHEtVVZwRHFjLUpEX1lsZ0FYWkhScDJyUFVoTEtKYmJCanluT1ZjNEZ0TGdKbnhqYTluMXRFMEROb1F0alIwMjBVNTlEbEQ5M1J6cndCZmJvWDVpNG1scUxORVpQNlcwZzRxM1J2SExrM2prdE5r?oc=5" tar
  - (2026-05-27) [TITLE: 日本国会通过法案设立“国家情报会议”--国际 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1fWUNqdU9NU29WUGttR2hyVDdTejdJemVPOUo5THZiUnNhdGc2UF84N1V3NkkzcWRCU092dTdMX3J1NHgyVzVtZjh2MFA3b2] (zh: 日本国会通过法案设立“国家情报会议”--国际 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMia0FVX3lxTE1fWUNqdU9NU29WUGttR2hyVDdTejdJemVPOUo5THZiUnNhdGc2UF84N1V3NkkzcWRCU092dTdMX3J1NHgyVzVtZjh2MFA3b2M0MXVPMjlhcVpRRGxKVG5tempOaUY2X3hTN1Rr?oc=5" target="_blank">日本国
  - (2026-05-27) [TITLE: 江西省委常委、统战部部长李伟接受审查调查 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFBtRjR6R3ZBMkZ0d2J3YmpsSjcxSXp1ak1WSHNuZ3d3Zngydl92dnhjVWlsclRfc3dKSHRsek1tQ0NyOHI2WTJnX200NUZPRmJN] (zh: 江西省委常委、统战部部长李伟接受审查调查 - 人民网)
      <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTFBtRjR6R3ZBMkZ0d2J3YmpsSjcxSXp1ak1WSHNuZ3d3Zngydl92dnhjVWlsclRfc3dKSHRsek1tQ0NyOHI2WTJnX200NUZPRmJNMWdFZjZyeVNlVDU2NG8wYTJhOUVCTkIxZ1V0aEhR?oc=5" target="_blank"

### Russian Internal News (state + in-exile) — 1132 new of 1132 total
  - (2026-05-27) [TITLE: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. Там она воспроизводит тезисы российской пропаганды | LEDE: <p>Бывший главный редактор RT France Ксения Федорова у] (ru: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. )
      <p>Бывший главный редактор RT France Ксения Федорова устроилась на работу на французском правоконсервативном телеканале CNews, рассказывается в публикациях Politico и русской службы RFI. <p>
  - (2026-05-27) [TITLE: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за пределы Украины и объявит новую мобилизацию | LEDE: <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает] (ru: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за п)
      <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. К
  - (2026-05-27) [TITLE: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли более 20 студентов колледжа. Вот что о них и об этой атаке рассказывают однокурсники и друзья | LEDE: <p>В ночь на ] (ru: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли бо)
      <p>В ночь на 22 мая украинские войска нанесли удар беспилотниками по Старобельску в аннексированной ЛНР. Под обстрел попали педагогический колледж и профессиональный колледж Луганского педагогического университета. По оф
  - (2026-05-27) [TITLE: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской области объяснили, зачем запретили иностранные надписи на школьной одежде | LEDE: <p>Департамент образования Томской] (ru: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской обл)
      <p>Департамент образования Томской области заявил, что запрет носить одежду с иностранными надписями, принятый в нескольких школах региона, призван уберечь детей от «чуждых и опасных» смыслов.<p>
  - (2026-05-27) [TITLE: Парламент Венгрии остановил выход страны из Международного уголовного суда, начатый предыдущим премьером Виктором Орбаном | LEDE: <p>Парламент Венгрии одобрил отзыв решения о выходе страны из М] (ru: Парламент Венгрии остановил выход страны из Международного уголовного суда, нача)
      <p>Парламент Венгрии одобрил отзыв решения о выходе страны из Международного уголовного суда (МУС).<p>
  - (2026-05-27) [TITLE: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей или до пяти лет лишения свободы | LEDE: <p>Госдума приняла в первом чтении законопроект о наказании за незаконный] (ru: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей )
      <p>Госдума приняла в первом чтении законопроект о наказании за незаконный майнинг. Документ вводит в Уголовный кодекс новую статью 171.6.<p>
  - (2026-05-27) [TITLE: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Германии | LEDE: <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит дейст] (ru: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Ге)
      <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит действующий канцлер Германии Фридрих Мерц, обсуждаются варианты его замены, пишут таблоиды Stern и Bild.<p>
  - (2026-05-27) [TITLE: The Economist: власти Украины готовятся еще к двум-трем годам войны. Советник Зеленского: это — «старый вброс» | LEDE: <p>Президент Украины Владимир Зеленский «приказал готовиться к еще двум-тр] (ru: The Economist: власти Украины готовятся еще к двум-трем годам войны. Советник Зе)
      <p>Президент Украины Владимир Зеленский «приказал готовиться к еще двум-трем годам войны», пишет The Economist со ссылкой на правительственные источники.<p>

### Ukrainian Internal News (national + local Kyiv) — 135 new of 135 total
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-27) [TITLE: Шлях із перешкодами: рух України до членства ускладнюють і в ЄС, і в Києві | LEDE: ] (uk: Шлях із перешкодами: рух України до членства ускладнюють і в ЄС, і в Києві)
  - (2026-05-27) [TITLE: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув пес | LEDE: Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них гос] (uk: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув п)
      Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них госпіталізовано.
  - (2026-05-27) [TITLE: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали на боці РФ | LEDE: Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зус] (uk: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали н)
      Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зустріч із лідеркою білоруської опозиції Світланою Тихановською та її командою. Вони мали змогу поспілкуватися з військовополоне
  - (2026-05-27) [TITLE: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз РФ | LEDE: Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для зах] (uk: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз )
      Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для захисту від російських ракет.
  - (2026-05-27) [TITLE: Елітний підрозділ ССО отримав найменування на честь Героїв УПА | LEDE: Президент Володимир Зеленський присвоїв почесне найменування "імені Героїв УПА" Окремому центру спеціальних операцій "Півн] (uk: Елітний підрозділ ССО отримав найменування на честь Героїв УПА)
      Президент Володимир Зеленський присвоїв почесне найменування "імені Героїв УПА" Окремому центру спеціальних операцій "Північ" Сил спеціальних операцій ЗСУ.
  - (2026-05-27) [TITLE: 200 тисяч за "мовчання": командира та старшину підозрюють у вимаганні грошей з військового | LEDE: Командиру роти та старшині однієї з бригад Дніпропетровщини оголосили підозру у вимаганні грош] (uk: 200 тисяч за "мовчання": командира та старшину підозрюють у вимаганні грошей з в)
      Командиру роти та старшині однієї з бригад Дніпропетровщини оголосили підозру у вимаганні грошей з військового.
  - (2026-05-27) [TITLE: У ЗСУ спростовують заяву росіян про окупацію села на Харківщині біля кордону з РФ | LEDE: Село Гранів Харківської області перебуває під контролем ЗСУ — заявили у Збройних силах, спростувавши фе] (uk: У ЗСУ спростовують заяву росіян про окупацію села на Харківщині біля кордону з Р)
      Село Гранів Харківської області перебуває під контролем ЗСУ — заявили у Збройних силах, спростувавши фейки армії РФ.

### Paper Trading Scorecard — 140 new of 140 total
  - (2026-05-27) [Polymarket] Will OpenAI have the best AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is checked
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will the price of Ethereum be above $2,000 on May 27?
      This market will resolve to "Yes" if the Binance 1 minute candle for ETH/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Monte win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Aurora win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w

### U.S. Weather + Severe / Climate Outlooks — 121 new of 121 total
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 9:55AM CDT until May 27 at 10:00AM CDT by NWS Brownsville TX
      The storm which prompted the warning has weakened below severe
limits, and has exited the warned area. Therefore, the warning will
be allowed to expire.  However, gusty winds and heavy rain are still
possible with this t
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 9:54AM CDT until May 28 at 3:00AM CDT by NWS Green Bay WI
      * WHAT...Dangerous swimming conditions are expected due to high
waves and strong rip currents.

* WHERE...Beaches along Lake Michigan in Manitowoc County.

* WHEN...From 9 PM CDT this evening through late tonight.

* IMP
  - (2026-05-27) [Severe] Special Marine Warning: Special Marine Warning issued May 27 at 9:53AM CDT until May 27 at 11:00AM CDT by NWS Brownsville TX
      SMWBRO

The National Weather Service in Brownsville has issued a

* Special Marine Warning for...
Coastal waters from Port Mansfield TX to the Rio Grande River out
20 NM...
Laguna Madre From the Port Of Brownsville to th
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 9:51AM CDT until May 27 at 7:00PM CDT by NWS Fort Worth TX
      ...The National Weather Service in Fort Worth TX has issued a Flood
Warning for the following rivers in Texas...

Little River Near Little River affecting Bell County.

* WHAT...Minor flooding is forecast.

* WHERE...Lit
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued May 27 at 9:50AM CDT until May 27 at 10:00AM CDT by NWS Memphis TN
      Observations indicate that the dense fog threat has ended.
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 10:41AM EDT until May 28 at 8:00AM EDT by NWS Wilmington OH
      ...The National Weather Service in Wilmington has issued a Flood
Warning for the following rivers...

South Fork Licking River Near I 70 near Buckeye Lake.

* WHAT...Minor flooding is forecast.

* WHERE...South Fork Lick
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 9:40AM CDT until May 27 at 10:15AM CDT by NWS Brownsville TX
      SVRBRO

The National Weather Service in Brownsville has issued a

* Severe Thunderstorm Warning for...
Southeastern Cameron County in Deep South Texas...

* Until 1015 AM CDT.

* At 940 AM CDT, a severe thunderstorm was 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 79 new of 79 total
  - (2026-05-27) [fx] USD/EUR: 0.859651
      1 USD = 0.859651 EUR
  - (2026-05-27) [fx] USD/GBP: 0.743251
      1 USD = 0.743251 GBP
  - (2026-05-27) [fx] USD/JPY: 159.232868
      1 USD = 159.232868 JPY
  - (2026-05-27) [fx] USD/CHF: 0.785427
      1 USD = 0.785427 CHF
  - (2026-05-27) [fx] USD/CAD: 1.380782
      1 USD = 1.380782 CAD
  - (2026-05-27) [fx] USD/AUD: 1.394958
      1 USD = 1.394958 AUD
  - (2026-05-27) [fx] USD/NZD: 1.712118
      1 USD = 1.712118 NZD
  - (2026-05-27) [fx] USD/CNY: 6.798706
      1 USD = 6.798706 CNY

### Government Action: Sanctions + Procurement + Foreign Agents — 96 new of 96 total
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-20) [OFAC] International Criminal Court-related Designation Removal - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9Ea293ZzJIMldMbWM4QndMbk5YVFZDX1B1RXQ5UmM0blB5YmR6THJHa3NLeHI3bVFrNmJya0VCcUpSMlp5dFM1T1lldWZ4MlBEMXpISkREbXNYWFNMRFY3bWlR?oc=5" target="_blank">International C
  - (2026-05-20) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE00SUEzZjlGVDZYWVJCUWlDSWhpSzBUbzRKUE9pUkNDaUFJR1hDb1ppNHNISjJESjU2Vy1vSmVXOExZeUxCMnpJWVpMYnc0WEd2em0zeG9jTFMzYVJXTWc?oc=5" target="_blank">Counter Narcotics an
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-05-27) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 3 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-05-27 14:56 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014114 Size: 462 KB
  - (2026-05-27) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-05-27 14:55 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014113 Size: 396 KB
  - (2026-05-27) 424B2 - TORONTO DOMINION BANK (0000947263) (Filer)
      filed 2026-05-27 14:55 UTC — Filed: 2026-05-27 AccNo: 0001140361-26-022943 Size: 369 KB
  - (2026-05-27) [Imura Takahiro] Form 4 (Reporting)
      filed 2026-05-27 14:55 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0000947871-26-000574 Size: 6 KB
  - (2026-05-27) [TOYOTA MOTOR CORP/] Form 4 (Issuer)
      filed 2026-05-27 14:55 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0000947871-26-000574 Size: 6 KB
  - (2026-05-27) [Fujisawa Kumi] Form 4 (Reporting)
      filed 2026-05-27 14:51 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0000947871-26-000573 Size: 5 KB
  - (2026-05-27) [TOYOTA MOTOR CORP/] Form 4 (Issuer)
      filed 2026-05-27 14:51 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0000947871-26-000573 Size: 5 KB
  - (2026-05-27) [Asakura Masashi] Form 4 (Reporting)
      filed 2026-05-27 14:49 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0000947871-26-000572 Size: 6 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [United States] California Revisits HVACR Sales Reporting
      domain: achrnews.com · language: English · tone: 
  - (2026-05-27) [United States] ICE is spending millions of dollars on iris scanners , expanding its arsenal of tech tools
      domain: wvik.org · language: English · tone: 
  - (2026-05-27) [United Kingdom] UV toothbrush kills bathroom bacteria in 3 minutes and it only £29 . 99
      domain: mirror.co.uk · language: English · tone: 
  - (2026-05-27) [Pakistan] Iran war divides world markets into winners , losers
      domain: arynews.tv · language: English · tone: 
  - (2026-05-27) [United Kingdom] Minister rejects Blair triple lock warning as ex - PM calls for  coherent plan  
      domain: hamhigh.co.uk · language: English · tone: 
  - (2026-05-27) [United States] Police : 18 - year - old seriously injured in scooter crash in Bridgeport
      domain: courant.com · language: English · tone: 
  - (2026-05-27) [United States] Around the Room : Scotty B Gets Triggered by a Banana | Elvis Duran and the Morning Show
      domain: elvisduran.iheart.com · language: English · tone: 
  - (2026-05-27) [United States] Israel claims killing new Hamas military chief in Gaza strike
      domain: article.wn.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,058,225 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,958,956 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,806,332 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 100% · 24h volume: $1,733,511 · resolves 2026-05-27
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,687,484 · resolves 2026-07-20
  - (2026-05-27) Will Barack Obama win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $1,146,942 · resolves 2028-11-07
  - (2026-05-27) Roland Garros ATP: Mariano Navone vs Jakub Mensik
      yes price: 52% · 24h volume: $1,084,062 · resolves 2026-06-03
  - (2026-05-27) Roland Garros ATP: Ugo Humbert vs Quentin Halys
      yes price: 46% · 24h volume: $949,194 · resolves 2026-06-03

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-26) [Marginal Revolution] *How to Win a Trade War: An Optimistic Guide to an Anxious Global Economy*
      That is the new Soumaya Keynes book, out today.  I was happy to have blurbed this book, and here is an essay, on export restrictions, based on the book.
The post *How to Win a Trade War: An Optimistic Guide to an Anxious
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=591, 7d-median=591, 14d-median=591
- local_news: today=247, 7d-median=247, 14d-median=247
- foreign_news: today=889, 7d-median=889, 14d-median=889
- chinese_internal: today=283, 7d-median=283, 14d-median=283
- russian_internal: today=1132, 7d-median=1132, 14d-median=1132
- ukrainian_internal: today=135, 7d-median=135, 14d-median=135
- paper_bets: today=140, 7d-median=140, 14d-median=140
- weather: today=121, 7d-median=121, 14d-median=121
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=96, 7d-median=96, 14d-median=96
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*