# WORLDSCOPE morning brief — 2026-05-27

## Headline
5290 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 722 new of 722 total
  - (2026-05-27) [Alabama] World Trade Month
      Download
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-25) [Alaska] Memorial Day 2026
      WHEREAS, America was founded on the principles of liberty and justice for all, and we recognize the generations of brave, patriotic men and women who have served in the military and have given their lives to protect and 
  - (2026-05-27) [feed error] CalMatters (California): HTTPError
      429 Client Error: Too Many Requests for url: https://calmatters.org/feed/
  - (2026-05-27) [feed error] AZ Governor (Arizona): HTTPError
      404 Client Error: Not Found for url: https://azgovernor.gov/feed
  - (2026-05-27) [California] Governor Newsom signs legislation to further protect California elections from interference and intimidation
  - (2026-05-27) [California] Governor Newsom proclaims Small Business Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-26) [California] Governor Newsom signs legislation 5.26.2026
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2024/05/6C94C750-0DF8-46C6-A8E3-00EA4F1B1ADD-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async" />

### Local News: St. Louis + Atlanta — 265 new of 265 total
  - (2026-05-27) [St. Louis] Missouri Supreme Court rejects challenge to governor’s power to call special sessions
  - (2026-05-27) [St. Louis] St. Louis economic development panel takes aim at data center critics, calls many concerns ‘myths’
  - (2026-05-27) [St. Louis] St. Louis police promise transparency as oversight board approves drone program
  - (2026-05-27) [St. Louis] Abortion-rights coalition launches campaign against Missouri’s Amendment 3
  - (2026-05-27) [St. Louis] Immigrants held by ICE are neglected at the Ste. Genevieve County jail, lawmakers say
  - (2026-05-27) [St. Louis] Plan to redevelop downtown St. Louis riverfront moves ahead despite fire that destroyed key buildings
  - (2026-05-26) [St. Louis] Tornado recovery advocates and downtown investors are divided on Rams settlement spending
  - (2026-05-26) [St. Louis] Missouri lawmakers likely will try property tax reform again after failing this year

### International News + Multilateral Institutions — 906 new of 906 total
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [Global] Israel issues evacuation order for swathes of southern Lebanon
      The military says areas south of the Zahrani River are now "combat zones" as it threatens Hezbollah with fresh strikes.
  - (2026-05-27) [Global] Ebola-hit DR Congo faces 'catastrophic collision' of disease and conflict, WHO warns
      Tedros Adhanom Ghebreyesus said fighting in DR Congo was hampering efforts to stop spread
  - (2026-05-27) [Global] Trump says US 'not satisfied' with Iran deal yet
      The US president says he believes Iran wants to reach a deal but there is still no agreement on its terms.
  - (2026-05-27) [Global] Five people found alive after week trapped in flooded Laos cave
      The search is continuing for a further two villagers who are still missing, rescuers say.
  - (2026-05-27) [Global] Israeli strike in Gaza City kills new head of Hamas's military wing
      Hamas says Mohammed Odeh was killed alongside his wife and two children in a strike on a residential building.

### Chinese Internal News — 289 new of 289 total
  - (2026-05-27) [TITLE: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlD] (zh: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlDRUx5b1ZMbmc3TmFqQVpGd1YyVk1NTm9R?oc=5" target="_blank">香港银行同步加强内地客监管 有
  - (2026-05-27) [TITLE: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3OD] (zh: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3ODJlTk9Hc1N4VEUxUEdRUzM4NzBDMThV?oc=5" target="_blank">电信诈骗版图南迁 自柬埔寨转向印尼</
  - (2026-05-27) [TITLE: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q] (zh: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q0t2MlR5Z0hQX2pYTl90ZWl0R3BBbXVFUE1r?oc=5" target="_blank">跨省履新仅8个月 “70后”高官李伟江
  - (2026-05-27) [TITLE: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNk] (zh: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNkd4djhVSzQ2dV96bmZwVzhvLUc3TW1ZTEQ0?oc=5" target="_blank">深圳一快速路段发生火灾 警方称无人受伤
  - (2026-05-26) [TITLE: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGh] (zh: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGhBenBsLXFZOVJxRl9xSmVnZHJHMUNB?oc=5" target="_blank">财经早知道｜深圳常住人口首破1
  - (2026-05-27) [TITLE: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHd] (zh: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHdyandPQXJnQW5YN2RmdU03U1FhOVFYV1Zn?oc=5" target="_blank">AI、石化产业链带动4月工业利
  - (2026-05-25) [TITLE: 最新封面报道｜争夺估值王 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjl] (zh: 最新封面报道｜争夺估值王 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjlCYlZvR05ONEE2Mg?oc=5" target="_blank">最新封面报道｜争夺估值王</a>&
  - (2026-05-26) [TITLE: 宇树科技科创板IPO将于6月1日上会 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE12bDdQa3Q4SVRSMlEtcWI1QXZSNWpvY0xSS3hrTnFaLXhCakRjeVBYVS1jWDEyYU1aLU16UWpESFdITXJDR0VKaWJOZk02OFNZT0I] (zh: 宇树科技科创板IPO将于6月1日上会 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE12bDdQa3Q4SVRSMlEtcWI1QXZSNWpvY0xSS3hrTnFaLXhCakRjeVBYVS1jWDEyYU1aLU16UWpESFdITXJDR0VKaWJOZk02OFNZT0I4b1M3WGJkYjhMWFE?oc=5" target="_blank">宇树科技科创板IPO将于6月1日上会</

### Russian Internal News (state + in-exile) — 1021 new of 1021 total
  - (2026-05-27) [TITLE: Детская площадка в Херсоне попала под обстрел России. Погиб мужчина, его жена и две дочери ранены | LEDE: <p>Вооруженные силы РФ обстреляли Корабельный район Херсона из реактивных систем залпов] (ru: Детская площадка в Херсоне попала под обстрел России. Погиб мужчина, его жена и )
      <p>Вооруженные силы РФ обстреляли Корабельный район Херсона из реактивных систем залпового огня, сообщает 27 мая «Суспiльне», ссылаясь на местные власти.<p>
  - (2026-05-27) [TITLE: Замглавы «Уралвагонзавода» арестован по делу о растрате при выполнении гособоронзаказа | LEDE: <p>Басманный районный суд Москвы отправил под стражу на два месяца заместителя гендиректора концер] (ru: Замглавы «Уралвагонзавода» арестован по делу о растрате при выполнении гособорон)
      <p>Басманный районный суд Москвы отправил под стражу на два месяца заместителя гендиректора концерна «Уралвагонзавод» по спецтехнике Дмитрия Семизорова, которого обвиняют в растрате при выполнении государственного оборон
  - (2026-05-27) [TITLE: Судебные приставы взыскали 300 тысяч рублей с Артемия Лебедева, назвавшего Лигу безопасного интернета «****** [фигней] на палке» | LEDE: <p>Руководитель Лиги безопасного интернета Екатерина Миз] (ru: Судебные приставы взыскали 300 тысяч рублей с Артемия Лебедева, назвавшего Лигу )
      <p>Руководитель Лиги безопасного интернета Екатерина Мизулина сообщила в телеграме 27 мая, что судебные приставы взыскали с блогера Артемия Лебедева 300 тысяч рублей компенсации по иску Мизулиной о защите чести и достоин
  - (2026-05-27) [TITLE: Руслана Кутаева (он оправдывал «убийства чести») оставили в платформе российской оппозиции при ПАСЕ | LEDE: <p>Бюро Парламентской ассамблеи Совета Европы решило оставить в составе платформы рос] (ru: Руслана Кутаева (он оправдывал «убийства чести») оставили в платформе российской)
      <p>Бюро Парламентской ассамблеи Совета Европы решило оставить в составе платформы российской оппозиции при ПАСЕ общественного деятеля из Чечни Руслана Кутаева, который оскорблял ЛГБТК-людей и оправдывал «убийства чести» 
  - (2026-05-27) [TITLE: «Вы пользуетесь Wi-Fi, который я создал, VPN, который я создал. Вы пользуетесь экстремистскими вещами?». Из России уехал пионер IT-индустрии Александр Галицкий, у которого отобрали все имуществ] (ru: «Вы пользуетесь Wi-Fi, который я создал, VPN, который я создал. Вы пользуетесь э)
      <p>71-летний Александр Галицкий — советский конструктор, который стал одним из первых успешных технопредпринимателей и венчурных инвесторов России. Он много лет вел бизнес в США, Восточной Европе и России. Но на фоне кон
  - (2026-05-27) [TITLE: Росстат сообщил, что долг по зарплатам в России за месяц вырос на треть. Государственным СМИ рекомендовали «максимально игнорировать» эти данные | LEDE: <p>Суммарная задолженность по зарплате в] (ru: Росстат сообщил, что долг по зарплатам в России за месяц вырос на треть. Государ)
      <p>Суммарная задолженность по зарплате в России на конец апреля составила 2,9 миллиарда рублей, что на 750 миллионов рублей больше (+35,2%), чем в марте, следует из данных Росстата, представленных 27 мая.<p>
  - (2026-05-27) [TITLE: Участница «Фракции Красной армии» Даниэла Клетте получила 13 лет тюрьмы за грабежи. Она больше 30 лет скрывалась от полиции — и жила в центре Берлина | LEDE: <p>Суд в Вердене приговорил бывшую ] (ru: Участница «Фракции Красной армии» Даниэла Клетте получила 13 лет тюрьмы за грабе)
      <p>Суд в Вердене приговорил бывшую участницу немецкой леворадикальной террористической организации «Фракция Красной армии» (RAF) Даниэлу Клетте к 13 годам лишения свободы за участие в серии вооруженных ограблений суперма
  - (2026-05-27) [TITLE: В России массово задерживают муфтиев — по обвинениям от подкупа до терроризма. Это кампания против главы Духовного управления мусульман Равиля Гайнутдина, считают эксперты | LEDE: <p>В мае из р] (ru: В России массово задерживают муфтиев — по обвинениям от подкупа до терроризма. Э)
      <p>В мае из разных регионов России поступили сообщения о задержаниях и арестах муфтиев и других мусульманских религиозных и общественных деятелей. Некоторых из них обвиняют по террористической статье — в сотрудничестве с

### Ukrainian Internal News (national + local Kyiv) — 138 new of 138 total
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-28) [TITLE: Сибіга: Саме зараз Європа повинна діяти рішуче для наближення миру в Україні | LEDE: Глава МЗС закликав Європу діяти рішуче на тлі зміни динаміки війни.] (uk: Сибіга: Саме зараз Європа повинна діяти рішуче для наближення миру в Україні)
      Глава МЗС закликав Європу діяти рішуче на тлі зміни динаміки війни.
  - (2026-05-28) [TITLE: Розбирали знайдений БпЛА: на Чернігівщині загинули двоє фермерів | LEDE: Радник міністра оборони Сергій Бескрестнов ("Флеш") повідомив, що в Чернігівській області загинули двоє фермерів, які зн] (uk: Розбирали знайдений БпЛА: на Чернігівщині загинули двоє фермерів)
      Радник міністра оборони Сергій Бескрестнов ("Флеш") повідомив, що в Чернігівській області загинули двоє фермерів, які знайшли в полі ударний БпЛА і вирішили його розібрати.
  - (2026-05-28) [TITLE: Трамп зробив ще одну заяву про угоду з Іраном | LEDE: Трамп натякнув на "Авраамові угоди", коли говорив про перемир'я з Іраном.] (uk: Трамп зробив ще одну заяву про угоду з Іраном)
      Трамп натякнув на "Авраамові угоди", коли говорив про перемир'я з Іраном.
  - (2026-05-27) [TITLE: Україна перед "Рамштайном" узгодила з партнерами пріоритети: ППО, снаряди та дрони | LEDE: Міністр оборони Михайло Федоров провів розмову зі своїми колегами з Німеччини та Великої Британії Бори] (uk: Україна перед "Рамштайном" узгодила з партнерами пріоритети: ППО, снаряди та дро)
      Міністр оборони Михайло Федоров провів розмову зі своїми колегами з Німеччини та Великої Британії Борисом Пісторіусом і Джоном Гілі, а також із генсекретарем НАТО Марком Рютте, в ході якої йшлося про ключові пріоритети У
  - (2026-05-27) [TITLE: Понад 250 бойових зіткнень відбулось на фронті з початку доби — Генштаб | LEDE: Від початку доби 27 травня на фронті відбулось 256 бойових зіткнень.] (uk: Понад 250 бойових зіткнень відбулось на фронті з початку доби — Генштаб)
      Від початку доби 27 травня на фронті відбулось 256 бойових зіткнень.
  - (2026-05-27) [TITLE: Трамп: США слідкуватимуть за Ормузькою протокою | LEDE: ] (uk: Трамп: США слідкуватимуть за Ормузькою протокою)
  - (2026-05-27) [TITLE: По всій Україні оголошували повітряну тривогу через зліт МіГ-31К | LEDE: Увечері 27 травня по всій території України оголосили повітряну тривогу через зліт МіГ-31К.] (uk: По всій Україні оголошували повітряну тривогу через зліт МіГ-31К)
      Увечері 27 травня по всій території України оголосили повітряну тривогу через зліт МіГ-31К.

### Ukraine Theater (total-war monitoring) — 394 new of 394 total
  - (2026-05-27) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [Air alerts error] HTTPError (set ALERTS_IN_UA_TOKEN for v2)
      401 Client Error: Unauthorized for url: https://api.alerts.in.ua/v1/alerts/active.json
  - (2026-05-26) [FIRMS] thermal anomaly 51.499, 31.703 (FRP 1.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 1.7 MW
  - (2026-05-26) [FIRMS] thermal anomaly 51.893, 29.339 (FRP 3.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 3.25 MW
  - (2026-05-26) [FIRMS] thermal anomaly 50.454, 34.113 (FRP 1.46 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 1.46 MW
  - (2026-05-26) [FIRMS] thermal anomaly 51.853, 26.552 (FRP 3.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 3.35 MW
  - (2026-05-26) [FIRMS] thermal anomaly 50.888, 28.479 (FRP 3.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 3.19 MW
  - (2026-05-26) [FIRMS] thermal anomaly 50.887, 28.484 (FRP 3.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 3.19 MW

### Paper Trading Scorecard — 136 new of 136 total
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Raphaël Glucksmann win the 2027 French presidential election?
      The next French presidential election is currently expected to be held around April 2027.  This market pertains to the outcome of the next French presidential election, regardless of whether it follows the scheduled end 
  - (2026-05-27) [Polymarket] Israeli parliament dissolved by May 31?
      This market will resolve to "Yes" if the sitting Israeli Knesset (Israel's parliament), as of this market's inception, is dissolved between market creation and May 31, 2026, 11:59 PM ET. Otherwise, this market will resol
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso
  - (2026-05-27) [Polymarket] Will Solana dip to $10 in May?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for SOL/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa
  - (2026-05-27) [Polymarket] Xi Jinping divorce before 2027?
      This market will resolve to "Yes" if Xi Jinping and/or Peng Liyuan announce their intention to divorce between the date of market creation and December 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".


### U.S. Weather + Severe / Climate Outlooks — 149 new of 149 total
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 7:24PM EDT by NWS Greenville-Spartanburg SC
      At 724 PM EDT, Doppler radar was tracking a strong thunderstorm 9
miles east of Gastonia, or near Belmont, moving east at 20 mph.

HAZARD...Wind gusts up to 40 mph.

SOURCE...Radar indicated.

IMPACT...Gusty winds could 
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 6:21PM CDT until May 27 at 6:45PM CDT by NWS La Crosse WI
      At 619 PM CDT, a severe thunderstorm was located 7 miles northeast of
Shortville, or 10 miles east of Neillsville, moving south at 20 mph.

HAZARD...Quarter size hail.

SOURCE...Radar indicated.

IMPACT...Damage to vehic
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 7:20PM EDT by NWS Blacksburg VA
      At 720 PM EDT, Doppler radar was tracking strong thunderstorms along
a line extending from Bramwell to near Tiptop to near Claypool Hill.
Movement was east at 20 mph.

HAZARD...Wind gusts up to 40 mph.

SOURCE...Radar in
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 7:19PM EDT until May 27 at 7:30PM EDT by NWS Wakefield VA
      At 719 PM EDT, a severe thunderstorm was located near Virginia
Commonwealth University, moving east at 35 mph.

HAZARD...60 mph wind gusts.

SOURCE...Radar indicated.

IMPACT...Expect damage to trees and powerlines.

Loc
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 7:18PM EDT until May 27 at 8:15PM EDT by NWS Blacksburg VA
      At 718 PM EDT, severe thunderstorms were located along a line
extending from near Pleasant View to near Sedalia to Peaks Of Otter
Recreation Area, moving southeast at 25 mph.

HAZARD...60 mph wind gusts and half dollar s
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 7:16PM EDT by NWS Jackson KY
      At 716 PM EDT, Doppler radar was tracking a cluster of strong
thunderstorms near Olive Hill, moving southeast at 30 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IMPACT...Gusty win
  - (2026-05-27) [Severe] Flash Flood Warning: Flash Flood Warning issued May 27 at 7:15PM EDT until May 27 at 8:30PM EDT by NWS Charleston WV
      At 715 PM EDT, Doppler radar and automated rain gauges indicated
thunderstorms produced  heavy rain across the warned area. Between 1
and 4 inches of rain have fallen today. Flooding impacts will
continue, but the heavie

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 79 new of 79 total
  - (2026-05-27) [fx] USD/EUR: 0.859651
      1 USD = 0.859651 EUR
  - (2026-05-27) [fx] USD/GBP: 0.743251
      1 USD = 0.743251 GBP
  - (2026-05-27) [fx] USD/JPY: 159.232868
      1 USD = 159.232868 JPY
  - (2026-05-27) [fx] USD/CHF: 0.785427
      1 USD = 0.785427 CHF
  - (2026-05-27) [fx] USD/CAD: 1.380782
      1 USD = 1.380782 CAD
  - (2026-05-27) [fx] USD/AUD: 1.394958
      1 USD = 1.394958 AUD
  - (2026-05-27) [fx] USD/NZD: 1.712118
      1 USD = 1.712118 NZD
  - (2026-05-27) [fx] USD/CNY: 6.798706
      1 USD = 6.798706 CNY

### Government Action: Sanctions + Procurement + Foreign Agents — 95 new of 95 total
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-20) [OFAC] International Criminal Court-related Designation Removal - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9Ea293ZzJIMldMbWM4QndMbk5YVFZDX1B1RXQ5UmM0blB5YmR6THJHa3NLeHI3bVFrNmJya0VCcUpSMlp5dFM1T1lldWZ4MlBEMXpISkREbXNYWFNMRFY3bWlR?oc=5" target="_blank">International C
  - (2026-05-20) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE00SUEzZjlGVDZYWVJCUWlDSWhpSzBUbzRKUE9pUkNDaUFJR1hDb1ppNHNISjJESjU2Vy1vSmVXOExZeUxCMnpJWVpMYnc0WEd2em0zeG9jTFMzYVJXTWc?oc=5" target="_blank">Counter Narcotics an
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-05-27) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 5 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-27) [CA1] Argueta Castillo v. Blanche
  - (2026-05-26) [CA3] United States v. Paul Girard
  - (2026-05-26) [CA4] Tony Messer v. Garrison Investment Group, LP

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) [HCW Biologics Inc.] Form 4 (Issuer)
      filed 2026-05-27 23:25 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025476 Size: 7 KB
  - (2026-05-27) [GARRETT SCOTT T] Form 4 (Reporting)
      filed 2026-05-27 23:25 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025476 Size: 7 KB
  - (2026-05-27) [Arista Networks, Inc.] Form 4 (Issuer)
      filed 2026-05-27 23:23 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001596532-26-000109 Size: 16 KB
  - (2026-05-27) [BECHTOLSHEIM ANDREAS] Form 4 (Reporting)
      filed 2026-05-27 23:23 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001596532-26-000109 Size: 16 KB
  - (2026-05-27) [Byam Rebecca] Form 4 (Reporting)
      filed 2026-05-27 23:23 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025474 Size: 7 KB
  - (2026-05-27) [HCW Biologics Inc.] Form 4 (Issuer)
      filed 2026-05-27 23:23 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025474 Size: 7 KB
  - (2026-05-27) [Stack Fergal] Form 4 (Reporting)
      filed 2026-05-27 23:22 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001409970-26-000077 Size: 16 KB
  - (2026-05-27) [LendingClub Corp] Form 4 (Issuer)
      filed 2026-05-27 23:22 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001409970-26-000077 Size: 16 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [United States] Shooting outside Saline County club leaves 1 teen dead , 2 injured | The Arkansas Democrat - Gazette
      domain: arkansasonline.com · language: English · tone: 
  - (2026-05-27) [United States] Matthew Perry assistant sentenced to 41 months in prison | HOT 96 | The Tri State # 1 Hit Music Station
      domain: hot96.com · language: English · tone: 
  - (2026-05-27) [United States] Former assistant to TV star Matthew Perry sentenced to 41 months in prison
      domain: aljazeera.com · language: English · tone: 
  - (2026-05-27) [United Kingdom] Matthew Perry personal assistant jailed for his role in star ketamine death
      domain: bordertelegraph.com · language: English · tone: 
  - (2026-05-27) [Canada] Hamilton man charged after overnight vehicle theft at Grimsby home
      domain: chch.com · language: English · tone: 
  - (2026-05-27) [Nigeria] June 1 Showdown : TIB Movement Declares Mass Protest In Oyo Over Escalating Kidnappings , Insecurity
      domain: saharareporters.com · language: English · tone: 
  - (2026-05-27) [Canada] Pilot error blamed for 2023 northwest B . C . fatal helicopter incident | Tofino / Ucluelet Westerly News
      domain: westerlynews.ca · language: English · tone: 
  - (2026-05-27) [United States] Three Arrested , One Dead in Cocaine Bust at Mundra Port
      domain: maritime-executive.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 16 total
  - (2026-05-27) CVE-2026-48027 · Nx Nx Console: Nx Console Embedded Malicious Code Vulnerability
      vendor: Nx · product: Nx Console · CISA remediation by 2026-06-10
  - (2026-05-27) CVE-2026-45321 · TanStack TanStack: TanStack Unspecified Vulnerability
      vendor: TanStack · product: TanStack · CISA remediation by 2026-06-10
  - (2026-05-27) CVE-2026-8398 · Daemon Daemon Tools Lite: Daemon Tools Lite Embedded Malicious Code Vulnerability
      vendor: Daemon · product: Daemon Tools Lite · CISA remediation by 2026-05-30
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $3,769,612 · resolves 2026-07-20
  - (2026-05-27) Tampa Bay Rays vs. Baltimore Orioles
      yes price: 12% · 24h volume: $1,968,554 · resolves 2026-06-03
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,961,917 · resolves 2026-12-31
  - (2026-05-27) US announces new Iran agreement/ceasefire extension by May 27?
      yes price: 1% · 24h volume: $1,842,554 · resolves 2026-05-27
  - (2026-05-27) Hurricanes vs. Canadiens
      yes price: 58% · 24h volume: $1,380,184 · resolves 2026-05-28
  - (2026-05-27) Will Tom Brady win the 2028 Republican presidential nomination?
      yes price: 1% · 24h volume: $1,185,104 · resolves 2028-11-07
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,142,261 · resolves 2026-07-20
  - (2026-05-27) Will Turkiye win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,133,383 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-05-27) [Marginal Revolution] What should I ask Richard Hanania?
      Yes, I will be doing a Conversation with him.  Richard does have a new book coming out, Kakistocracy: Why Populism Ends in Disaster.  While I liked the book (and blurbed it), I do not feel our conversation about the book
  - (2026-05-27) [Marginal Revolution] Wednesday assorted links
      1. As meat prices rise, the economics of Texas barbecue. 2. Economic historian Eric Jones has passed away. 3. Claims about the Pope and Claude.  If true, further evidence for my Straussian hypothesis. 4. Koyama reviews T
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Conversable Economist] Lessons for Central Banks: Interview with Kristin Forbes
      Thomas Chow poses the questions in &#8220;Kristin Forbes on &#8216;wargaming&#8217; for thenext crisis,&#8221; subtitled &#8220;The MIT professor and former BoE MPC member speaks about QE, scenario analysis and the ar of
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### U.S. Political Figures (per-figure anomaly tracking) — 613 new of 613 total
  - (2026-05-27) Senator: Angela D Alsobrooks (anomaly 0.00)
      Angela D Alsobrooks (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ
  - (2026-05-27) Senator: Alan Armstrong (anomaly 0.00)
      Alan Armstrong (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ ment
  - (2026-05-27) Senator: Tammy Baldwin (anomaly 0.00)
      Tammy Baldwin (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Jim Banks (anomaly 0.10)
      Jim Banks (Senator). Composite anomaly score 0.100. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.50. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ mentions:
  - (2026-05-27) Senator: John Barrasso (anomaly 0.00)
      John Barrasso (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Michael F Bennet (anomaly 0.00)
      Michael F Bennet (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Marsha Blackburn (anomaly 0.20)
      Marsha Blackburn (Senator). Composite anomaly score 0.200. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 1.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Richard Blumenthal (anomaly 0.00)
      Richard Blumenthal (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ 

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=722, 7d-median=722, 14d-median=722
- local_news: today=265, 7d-median=265, 14d-median=265
- foreign_news: today=906, 7d-median=906, 14d-median=906
- chinese_internal: today=289, 7d-median=289, 14d-median=289
- russian_internal: today=1021, 7d-median=1021, 14d-median=1021
- ukrainian_internal: today=138, 7d-median=138, 14d-median=138
- ukraine_theater: today=394, 7d-median=394, 14d-median=394
- paper_bets: today=136, 7d-median=136, 14d-median=136
- weather: today=149, 7d-median=149, 14d-median=149
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*