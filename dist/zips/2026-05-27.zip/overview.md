# WORLDSCOPE morning brief — 2026-05-27

## Headline
2228 new items across 27 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 155 new of 155 total
  - (2026-05-27) [Alaska HB 381] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of revenue from the alternative volumetric tax; and providing for an 
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re
  - (2026-05-27) [Alaska HB 239] An Act relating to crime and criminal procedure; relating to civil claims by victims of sexual abuse of a minor; relating to homicide; relating to assault; relating to sexual assault; relating to stalking; relating to sexual abuse of a minor; relating to enticement and unlawful explo
      An Act relating to crime and criminal procedure; relating to civil claims by victims of sexual abuse of a minor; relating to homicide; relating to assault; relating to sexual assault; relating to stalking; relating to se
  - (2026-05-27) [Alaska HB 148] An Act relating to insurance; and providing for an effective date.
      An Act relating to insurance; and providing for an effective date.
  - (2026-05-27) [Alaska HB 156] An Act relating to disclosure of information regarding employee compensation by employers, employees, and applicants for employment.
      An Act relating to disclosure of information regarding employee compensation by employers, employees, and applicants for employment.
  - (2026-05-27) [Alaska HB 96] An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
      An Act establishing the Home Care Employment Standards Advisory Board; relating to payment for personal care services; and providing for an effective date.
  - (2026-05-27) [Alaska HB 171] An Act relating to interchange fees on tax and gratuity; and relating to the Alaska Unfair Trade Practices and Consumer Protection Act.
      An Act relating to interchange fees on tax and gratuity; and relating to the Alaska Unfair Trade Practices and Consumer Protection Act.
  - (2026-05-27) [Alaska SB 280] An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of revenue from the alternative volumetric tax; and providing for an 
      An Act relating to the taxation of certain natural gas pipeline property; relating to municipal taxation limitations; establishing an alternative volumetric tax on natural gas throughput; relating to the allocation of re
  - (2026-05-27) [Alaska HB 192] An Act relating to the payment of unemployment compensation benefits; relating to a penalty for late unemployment benefit payments; relating to inflation adjustments to unemployment benefit amounts; relating to an insured worker's availability for work; and providing for an effective
      An Act relating to the payment of unemployment compensation benefits; relating to a penalty for late unemployment benefit payments; relating to inflation adjustments to unemployment benefit amounts; relating to an insure

### State-Level News — 577 new of 577 total
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] The form asked my permission to share my health data. Then it wouldn’t let me say no.
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052226-OPT-OUT-MAZES-GH-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos
  - (2026-05-27) [California] Our house burned down but our mortgage didn’t. California fire survivors need time
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/02/011425-Palisades-Aftermath-TS-08.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-26) [California] No shame: A last-minute election guide for undecided CA voters
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/042826_Pomona-Gov-Debate_JAH_CM_01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-siz

### Local News: St. Louis + Atlanta — 132 new of 132 total
  - (2026-05-27) [feed error] Riverfront Times (St. Louis): HTTPError
      403 Client Error: Forbidden for url: https://www.riverfronttimes.com/category/news/feed/
  - (2026-05-27) [feed error] St. Louis Public Radio (St. Louis): HTTPError
      404 Client Error: Not Found for url: https://www.stlpr.org/rss.xml
  - (2026-05-27) [St. Louis] Downtown St. Louis tower scheduled to be auctioned
      An online auction of the 30-story Bank of America Plaza at 800 Market St. is scheduled to open at noon on June 22, with a $2 million starting bid.
  - (2026-05-27) [St. Louis] Five decades later, families still fighting to add 74 sailors to Vietnam Veterans Memorial Wall
      More than 50 years after the deadly USS Frank E. Evans collision, survivors and lawmakers say the sailors deserve recognition on the memorial wall.
  - (2026-05-27) [St. Louis] President Trump gathers Cabinet as he looks to seal deal to end the war with Iran
      President Donald Trump meets with his Cabinet at a precarious moment for talks aimed at ending the war with Iran.
  - (2026-05-27) [St. Louis] Israel says strikes killed Hamas military leader just days after his predecessor died
      At least five people were killed and 12 injured in Tuesday's strike on the eve of Eid al-Adha, a major Muslim holiday, according to local hospitals.
  - (2026-05-27) [St. Louis] 'I have so much love for this city' | Travis Kelce buys minority stake in Cleveland Guardians
      Curtis Danburg, vice president of communications and community impact for the Guardians, told Ohio TV station 3News early Wednesday morning.
  - (2026-05-27) [St. Louis] Matthew Perry assistant who injected him with ketamine faces final sentencing in overdose case
      Matthew Perry’s longtime assistant faces sentencing Wednesday for supplying and injecting the ketamine that caused the “Friends” star’s death.

### International News + Multilateral Institutions — 884 new of 884 total
  - (2026-05-27) [Global] Nigeria’s Eid Crisis: When a ram becomes a luxury
      At a Nigerian sheep market, human rights advocate Sadaatu Madaki says that rising prices make Eid difficult for families
  - (2026-05-27) [Global] DRC facing ‘catastrophic collision’ of Ebola and war, WHO chief warns
      &#039;Stopping this Ebola transmission depends entirely on humanitarian access,&#039; said Tedros, the WHO chief.
  - (2026-05-27) [Global] ‘Eid does not enter tents’: Palestinians in Gaza face grim holiday
      Rising costs and displacement erase Eid traditions, leaving Gaza residents struggling with sorrow and economic hardship.
  - (2026-05-27) [Global] Israeli authorities filmed treating Palestinians with aggression on Eid
      Israeli authorities have been filmed acting aggressively against Palestinians under occupation during Eid al-Adha.
  - (2026-05-27) [Global] UFC fighting cage rises on White House lawn for US and Trump celebrations
      The UFC bout at the White House marks the 250th anniversary of the US and President Donald Trump&#039;s 80th birthday.
  - (2026-05-27) [Global] Spain police enter PM Sanchez’s Socialist Party HQ in corruption probe
      Spanish police enter governing party&#039;s headquarters in Madrid as the corruption cases circle PM Sanchez&#039;s government.
  - (2026-05-27) [Global] Pochettino raises expectations as he reveals USMNT 2026 World Cup roster
      Instead of playing down his side&#039;s chances, Mauricio Pochettino implies that US can win the World Cup on home soil.
  - (2026-05-27) [Global] The West only discovers property rights when the landowners are white
      Zimbabwe is compensating European farmers. The original dispossession goes unrecognised.

### Chinese Internal News — 4 new of 4 total
  - (2026-05-27) [feed error] Sixth Tone: HTTPError
      404 Client Error: Not Found for url: https://www.sixthtone.com/feed
  - (2026-05-27) [feed error] Caijing 财经: HTTPError
      404 Client Error: Not Found for url: https://www.caijing.com.cn/rss/topnews.xml
  - (2026-05-27) [feed error] Caixin Global: HTTPError
      404 Client Error: Not Found for url: https://www.caixinglobal.com/rss/news.xml
  - (2026-05-27) [feed error] People's Daily 人民日报: ConnectTimeout
      HTTPConnectionPool(host='rss.people.com.cn', port=80): Max retries exceeded with url: /rss/politics.xml (Caused by ConnectTimeoutError(<HTTPConnection(host='rss.people.com.cn', port=80) at 0x7fbd4410f090>, 'Connection to

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 3 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-05-27 13:35 UTC — Filed: 2026-05-27 AccNo: 0000950103-26-007761 Size: 460 KB
  - (2026-05-27) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-05-27 13:35 UTC — Filed: 2026-05-27 AccNo: 0000950103-26-007761 Size: 460 KB
  - (2026-05-27) 485APOS - Tidal Trust II (0001924868) (Filer)
      filed 2026-05-27 13:31 UTC — Filed: 2026-05-27 AccNo: 0001999371-26-011500 Size: 1 MB
  - (2026-05-27) 485APOS - Tidal Trust II (0001924868) (Filer)
      filed 2026-05-27 13:31 UTC — Filed: 2026-05-27 AccNo: 0001999371-26-011500 Size: 1 MB
  - (2026-05-27) 424B3 - BRINKS CO (0000078890) (Filer)
      filed 2026-05-27 13:31 UTC — Filed: 2026-05-27 AccNo: 0001140361-26-022935 Size: 3 MB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 13:28 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014085 Size: 641 KB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 13:28 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014085 Size: 641 KB
  - (2026-05-27) 424B5 - CONSTELLATION ENERGY GENERATION LLC (0001168165) (Filer)
      filed 2026-05-27 13:28 UTC — Filed: 2026-05-27 AccNo: 0001104659-26-066643 Size: 354 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [Australia] RMIT ; Macquarie Group ; Market Forces , Australian Ethical ; BHP ; UN on built environment ; David Chandler on NCC and Foster & Partners
      domain: thefifthestate.com.au · language: English · tone: 
  - (2026-05-27) [Greece] Germany Growth Forecast Cut to 0 . 5 % 
      domain: athens-times.com · language: English · tone: 
  - (2026-05-27) [United States] Teen charged with killing stepsister on Carnival Cruise could be jailed until trial
      domain: kagstv.com · language: English · tone: 
  - (2026-05-27) [United Kingdom] Minister rejects Blair triple lock warning as ex - PM calls for  coherent plan  
      domain: surreycomet.co.uk · language: English · tone: 
  - (2026-05-27) [South Africa] ANALYSIS | Will the US - Nigeria targeting of ISWAP deputy weaken terrorism ? 
      domain: news24.com · language: English · tone: 
  - (2026-05-27) [United States] Bronze statues installed at DC Freedom Plaza include controversial historical figure
      domain: keprtv.com · language: English · tone: 
  - (2026-05-27) [Canada] Farewell to New England
      domain: thepeterboroughexaminer.com · language: English · tone: 
  - (2026-05-27) [United States] AARP 10 Favorite TV Shows of 2026 ( So Far ) 
      domain: aarp.org · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,116,337 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,958,806 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,838,847 · resolves 2026-07-20
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,659,347 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 30% · 24h volume: $1,319,369 · resolves 2026-05-27
  - (2026-05-27) Will Barack Obama win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $1,141,591 · resolves 2028-11-07
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX - Game 1 Winner
      yes price: 100% · 24h volume: $988,649 · resolves 2026-05-27
  - (2026-05-27) Dota 2: BetBoom Team vs Team Liquid (BO1) - BLAST Slam Group Stage
      yes price: 0% · 24h volume: $958,520 · resolves 2026-05-27

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-26) [Marginal Revolution] *How to Win a Trade War: An Optimistic Guide to an Anxious Global Economy*
      That is the new Soumaya Keynes book, out today.  I was happy to have blurbed this book, and here is an essay, on export restrictions, based on the book.
The post *How to Win a Trade War: An Optimistic Guide to an Anxious
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=155, 7d-median=155, 14d-median=155
- state_news: today=577, 7d-median=577, 14d-median=577
- local_news: today=132, 7d-median=132, 14d-median=132
- foreign_news: today=884, 7d-median=884, 14d-median=884
- chinese_internal: today=4, 7d-median=4, 14d-median=4
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*