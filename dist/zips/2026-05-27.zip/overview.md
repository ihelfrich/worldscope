# WORLDSCOPE morning brief — 2026-05-27

## Headline
5265 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 603 new of 603 total
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-25) [Alaska] Memorial Day 2026
      WHEREAS, America was founded on the principles of liberty and justice for all, and we recognize the generations of brave, patriotic men and women who have served in the military and have given their lives to protect and 
  - (2026-05-26) [California] Governor Newsom signs legislation 5.26.2026
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2024/05/6C94C750-0DF8-46C6-A8E3-00EA4F1B1ADD-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async" />
  - (2026-05-26) [California] Governor Newsom proclaims Older Californians Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-25) [California] Governor Newsom secures Presidential Emergency Declaration approval for Orange County hazmat response
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Governor-Newsom-secures-Presidential-Emergency-Declaration-approval-for-Orange-County-hazmat-response-SEO-GFX-v2-150x150.png" class="at
  - (2026-05-25) [California] Governor Newsom proclaims Memorial Day
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-25) [California] California mobilizes 785+ emergency personnel in Orange County hazmat response
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Orange-County-Whole-Government-Response-2-150x150.png" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 

### Local News: St. Louis + Atlanta — 256 new of 256 total
  - (2026-05-27) [St. Louis] Public pools, splash pads, and water parks in the St. Louis region
      <p>St. Louis summers are famously hot and sticky. What better way to cool down than by visiting one of the region&#8217;s many pools, swim clubs, or water parks? Even without owning a seasonal membership, families can ta
  - (2026-05-27) [St. Louis] Drive-in movie theaters within driving distance from St. Louis
      <p>Skyview Drive-In &#124; Belleville, Illinois 30 minutes east of St. Louis Whether it be a routine family night out or a special celebration, pop into the Skyview for showings of new and old favorites alike. Adult tick
  - (2026-05-27) [St. Louis] Ask Veronica: How to style a room with plants, according to design experts
      <p>A few weeks ago, I interviewed Laura Dooley, owner of LoKey Designs, and Nicole Walter, greenhouse buyer for Garden Heights Nursery, for the latest episode of my podcast House of Lou. Naturally, we talked about plants
  - (2026-05-27) [St. Louis] Every St. Louis parent eventually ends up shopping at Dierbergs for the car carts alone
      <p>As someone who works almost exclusively from home, I’m always looking for any excuse to leave the house. This often translates into frequent trips to the grocery store. Are we out of butter? I’m going to the grocery s
  - (2026-05-27) [St. Louis] A house in Tower Grove East hits the market
      <p>Custom-BuiltStep into summer in this custom-built, Palm Springs-inspired modernist home in the heart of Tower Grove. Built less than ten years ago, it maximizes functional space and natural light, while offering the d
  - (2026-05-27) [St. Louis] SLDC relaunches loan program for first-time homebuyers
      <p>St. Louis’ development agency, the St. Louis Development Corporation, relaunched its HomeSTL loan program on Tuesday, offering up to $50,000 to first-time homebuyers in the city. That loan can make the difference in s
  - (2026-05-27) [St. Louis] Maryville University Partners with NTEN for a unique cybersecurity program
      <p>Students at Maryville University have partnered up with a nonprofit tech organization to create a one-of-a-kind cybersecurity consulting program for nonprofits.&#160; It’s a partnership between the student-led consult
  - (2026-05-27) [St. Louis] A centennial celebration of Miles Davis and John Coltrane heads to Powell Hall
      <p>St. Louis has always stood at the intersection of the great modern musical genres, whether that’s the blues, jazz, rock and roll, or hip-hop. So it only makes sense that Terence Blanchard and Ravi Coltrane’s centennia

### International News + Multilateral Institutions — 869 new of 869 total
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [Global] Family mourn ‘Hamas leader’ killed in Israeli attack
      A funeral has been held for Mohammed Odeh, believed to be the leader of Hamas’s military wing.
  - (2026-05-27) [Global] Mogadishu gathers for Eid with prayers, family meals and outings
      Mogadishu has been tentatively emerging from the waves of violence that have rocked the city over recent decades.
  - (2026-05-27) [Global] Muslims worldwide celebrate Eid al-Adha, the Festival of Sacrifice
      The sacred holiday coincides with Hajj, drawing over 1.7 million pilgrims seeking spiritual fulfilment in Saudi Arabia.
  - (2026-05-27) [Global] Why is Israel attacking Lebanon’s Nabatieh, the major southern city?
      Israel issued forced displacement for Lebanon&#039;s southern city of Nabatieh on Tuesday. Why is it focused on this city?
  - (2026-05-27) [Global] Bangladesh seeks IMF aid: How badly has Iran war hit its economy?
      The International Monetary Fund warns that Iran war could trigger a spike in global debt levels.

### Chinese Internal News — 284 new of 284 total
  - (2026-05-25) [TITLE: 最新封面报道｜争夺估值王 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjl] (zh: 最新封面报道｜争夺估值王 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjlCYlZvR05ONEE2Mg?oc=5" target="_blank">最新封面报道｜争夺估值王</a>&
  - (2026-05-27) [TITLE: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlD] (zh: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlDRUx5b1ZMbmc3TmFqQVpGd1YyVk1NTm9R?oc=5" target="_blank">香港银行同步加强内地客监管 有
  - (2026-05-25) [TITLE: 最新财新周刊｜楼市新动向 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9VdlNQT0g4TUdGS3diemwyYWpfY29KZHlJeTE5eGhDeWFvSlBhR28zT1ljWEZGcDJPZnVhcEhjU3lKXzVpeGVwQ0VWajQyZFRtbmJ0SjZ] (zh: 最新财新周刊｜楼市新动向 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE9VdlNQT0g4TUdGS3diemwyYWpfY29KZHlJeTE5eGhDeWFvSlBhR28zT1ljWEZGcDJPZnVhcEhjU3lKXzVpeGVwQ0VWajQyZFRtbmJ0SjZGTHBxYm9rTlZxUQ?oc=5" target="_blank">最新财新周刊｜楼市新动向</a>&
  - (2026-05-26) [TITLE: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGh] (zh: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGhBenBsLXFZOVJxRl9xSmVnZHJHMUNB?oc=5" target="_blank">财经早知道｜深圳常住人口首破1
  - (2026-05-27) [TITLE: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHd] (zh: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHdyandPQXJnQW5YN2RmdU03U1FhOVFYV1Zn?oc=5" target="_blank">AI、石化产业链带动4月工业利
  - (2026-05-26) [TITLE: 宇树科技科创板IPO将于6月1日上会 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE12bDdQa3Q4SVRSMlEtcWI1QXZSNWpvY0xSS3hrTnFaLXhCakRjeVBYVS1jWDEyYU1aLU16UWpESFdITXJDR0VKaWJOZk02OFNZT0I] (zh: 宇树科技科创板IPO将于6月1日上会 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE12bDdQa3Q4SVRSMlEtcWI1QXZSNWpvY0xSS3hrTnFaLXhCakRjeVBYVS1jWDEyYU1aLU16UWpESFdITXJDR0VKaWJOZk02OFNZT0I4b1M3WGJkYjhMWFE?oc=5" target="_blank">宇树科技科创板IPO将于6月1日上会</
  - (2026-05-26) [TITLE: 香港医生夫妇超市盗窃 定罪后遭医委会停牌4个月 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9qM0ZiclpQdmw5RnIzcVZZUHdUNVo4RDdpUWdHWGFuZ0ZUNUZaZ2lfUjhGV0VnSWt2ZVUzcE1tWXlnNWM0] (zh: 香港医生夫妇超市盗窃 定罪后遭医委会停牌4个月 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9qM0ZiclpQdmw5RnIzcVZZUHdUNVo4RDdpUWdHWGFuZ0ZUNUZaZ2lfUjhGV0VnSWt2ZVUzcE1tWXlnNWM0VlZwTWxVaDlrNkQ5VG5nT29hWHVhNC1Yc1Zn?oc=5" target="_blank">香港医生夫妇超市盗窃 定罪后遭医委会停
  - (2026-05-26) [TITLE: 火线评论｜再谈高校校园开放：争论归争论，先做起来 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0xLTMyQzdtcDNtYUFoWHh1aDNyRmc3VGZ3dUZMeEpLQmxmNlNXR3dUUHRXdWticE5ja0NHUC11c2JDbkg3ZzlOY2tCRi1jd] (zh: 火线评论｜再谈高校校园开放：争论归争论，先做起来 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE0xLTMyQzdtcDNtYUFoWHh1aDNyRmc3VGZ3dUZMeEpLQmxmNlNXR3dUUHRXdWticE5ja0NHUC11c2JDbkg3ZzlOY2tCRi1jdUxLNXk5Qi0zOHRHNklCLTF3NXF3?oc=5" target="_blank">火线评论｜再谈高校校园开放：争

### Russian Internal News (state + in-exile) — 1144 new of 1144 total
  - (2026-05-27) [TITLE: Зеленский написал письмо Трампу и попросил защитить Украину от российских ракет | LEDE: <p>Владимир Зеленский направил Дональду Трампу и конгрессу США письмо, в котором заявил о нехватке систем] (ru: Зеленский написал письмо Трампу и попросил защитить Украину от российских ракет)
      <p>Владимир Зеленский направил Дональду Трампу и конгрессу США письмо, в котором заявил о нехватке систем противовоздушной обороны в Украине, сообщает Kyiv Independent. Текст письма опубликовал журналист Axios Барак Рави
  - (2026-05-27) [TITLE: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. Там она воспроизводит тезисы российской пропаганды | LEDE: <p>Бывший главный редактор RT France Ксения Федорова у] (ru: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. )
      <p>Бывший главный редактор RT France Ксения Федорова устроилась на работу на французском правоконсервативном телеканале CNews, рассказывается в публикациях Politico и русской службы RFI. <p>
  - (2026-05-27) [TITLE: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за пределы Украины и объявит новую мобилизацию | LEDE: <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает] (ru: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за п)
      <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. К
  - (2026-05-27) [TITLE: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли более 20 студентов колледжа. Вот что о них и об этой атаке рассказывают однокурсники и друзья | LEDE: <p>В ночь на ] (ru: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли бо)
      <p>В ночь на 22 мая украинские войска нанесли удар беспилотниками по Старобельску в аннексированной ЛНР. Под обстрел попали педагогический колледж и профессиональный колледж Луганского педагогического университета. По оф
  - (2026-05-27) [TITLE: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской области объяснили, зачем запретили иностранные надписи на школьной одежде | LEDE: <p>Департамент образования Томской] (ru: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской обл)
      <p>Департамент образования Томской области заявил, что запрет носить одежду с иностранными надписями, принятый в нескольких школах региона, призван уберечь детей от «чуждых и опасных» смыслов.<p>
  - (2026-05-27) [TITLE: Парламент Венгрии остановил выход страны из Международного уголовного суда, начатый предыдущим премьером Виктором Орбаном | LEDE: <p>Парламент Венгрии одобрил отзыв решения о выходе страны из М] (ru: Парламент Венгрии остановил выход страны из Международного уголовного суда, нача)
      <p>Парламент Венгрии одобрил отзыв решения о выходе страны из Международного уголовного суда (МУС).<p>
  - (2026-05-27) [TITLE: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей или до пяти лет лишения свободы | LEDE: <p>Госдума приняла в первом чтении законопроект о наказании за незаконный] (ru: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей )
      <p>Госдума приняла в первом чтении законопроект о наказании за незаконный майнинг. Документ вводит в Уголовный кодекс новую статью 171.6.<p>
  - (2026-05-27) [TITLE: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Германии | LEDE: <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит дейст] (ru: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Ге)
      <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит действующий канцлер Германии Фридрих Мерц, обсуждаются варианты его замены, пишут таблоиды Stern и Bild.<p>

### Ukrainian Internal News (national + local Kyiv) — 136 new of 136 total
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-27) [TITLE: У листі Трампу й конгресменам Зеленський згадав атаку РФ двома "Орєшніками" на Україну | LEDE: У листі президента Володимира Зеленського до американського лідера Дональда Трампа й членів Конгре] (uk: У листі Трампу й конгресменам Зеленський згадав атаку РФ двома "Орєшніками" на У)
      У листі президента Володимира Зеленського до американського лідера Дональда Трампа й членів Конгресу США йшлося про атаку РФ із використанням балістичних ракет середньої дальності "Орєшнік".
  - (2026-05-27) [TITLE: Прем'єр Болгарії вважає, що ЄС має очолити переговори з РФ щодо війни в Україні | LEDE: ] (uk: Прем'єр Болгарії вважає, що ЄС має очолити переговори з РФ щодо війни в Україні)
  - (2026-05-27) [TITLE: Зеленський: Росія готує додаткову мобілізацію | LEDE: Режим Володимира Путіна поставив завдання збільшити контингент російської окупаційної армії, це свідчить, що Москва не планує по-справжньом] (uk: Зеленський: Росія готує додаткову мобілізацію)
      Режим Володимира Путіна поставив завдання збільшити контингент російської окупаційної армії, це свідчить, що Москва не планує по-справжньому вести мирні переговори.
  - (2026-05-27) [TITLE: Шлях із перешкодами: рух України до членства ускладнюють і в ЄС, і в Києві | LEDE: ] (uk: Шлях із перешкодами: рух України до членства ускладнюють і в ЄС, і в Києві)
  - (2026-05-27) [TITLE: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув пес | LEDE: Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них гос] (uk: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув п)
      Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них госпіталізовано.
  - (2026-05-27) [TITLE: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали на боці РФ | LEDE: Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зус] (uk: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали н)
      Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зустріч із лідеркою білоруської опозиції Світланою Тихановською та її командою. Вони мали змогу поспілкуватися з військовополоне
  - (2026-05-27) [TITLE: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз РФ | LEDE: Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для зах] (uk: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз )
      Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для захисту від російських ракет.

### Ukraine Theater (total-war monitoring) — 394 new of 394 total
  - (2026-05-27) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [Air alerts error] HTTPError (set ALERTS_IN_UA_TOKEN for v2)
      401 Client Error: Unauthorized for url: https://api.alerts.in.ua/v1/alerts/active.json
  - (2026-05-25) [Liveuamap] Russian FM Lavrov informed State Secretary Rubio that Russia will intensify strikes on Kyiv. Lavrov urged Rubio to evacuate U.S. citizens and diplomatic staff from Kyiv Moskva, Moscow - Ukraine Interactive map - Ukraine Latest news on live 
      <a href="https://news.google.com/rss/articles/CBMikgFBVV95cUxQTkE1MmhVLXlxWmVTMW45QlppeVlWOVFva1ZNbUpRdU85eksxb0U3dS1qdW52bFlOWlhLNTQ3aHdKMWdzUFRfbXBwRzF5YW1rdklmQXpoRE5qQ2x1eHk0MVl4YWtTQmhnVEcxcmpGUF9xb0JuOXllcDY5UDNsXz
  - (2026-05-26) [Liveuamap] The U.S. Navy has resumed escorting ships through the Strait of Hormuz under a renewed “Project Freedom” mission. A Greek supertanker carrying two million barrels of crude was recently guided through the route after being stranded in the Gu
      <a href="https://news.google.com/rss/articles/CBMilwFBVV95cUxPaW5lLXY3NUJLY0ItLUJxZThHc2M4c1ExQjFYVzNrQUlUZENnZlppel9mc3dMUTRoem1LUllkT3liOTFCeGgwX0JZbTVvdjRrWUJrRUh2cnBWS1ZhOEpzZGFHX3M4UWFvdUdkLV9ERU1vcjFnYmVVd0Zza1VaRz
  - (2026-05-24) [Liveuamap] Fire reported at the fuel depot in Unecha of Bryansk region - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilwFBVV95cUxNSGt2V0tVVjJwelo3ejUxdjhORXhPb1NvX2xnWkF3ZjlYREhLMFpPTTliZTR2MWRzRjFfVlVpeHJBMzR3bm9tSFQ1U0FhRXlnNGNMRUd3TWNUMGdBcmdMVGlqTVJibjl5Qlo1RE9DRDFjOVNXaWdEVjBqdTlfc2
  - (2026-05-27) [Liveuamap] Explosions were reported in Taganrog, possible missile strike - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMimAFBVV95cUxNNkM3eUZzd1ExXzhSRTlGbE8zbFBJZWNJcHBoZ3I3TXBBYUdqaU1oTHlFZjFlenBLUlhMUkNza0JYc3VCRHU1allIMDBwZGo1WldiV1M5aHh4M1ptMy15UWVPeXBlX3ZHbnhPeU42NmNjcjFOTkFMbkt4dVpjNU
  - (2026-05-26) [Liveuamap] Amal Shehadeh: The Israeli army is operating north of the yellow line and making extensive preparations to pursue field commanders in Nabatieh. - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMingFBVV95cUxPNzhSWEFycm1vYjVqREFsUHhpWXdwc3Z2ck1STzBOZmRlVDZ5MUwyYmdmRmlWMHFOUkh5THNmVjRCX1NWQzVPSkJDNzh1S2NtUTlibnlqc0hPRU0zZlhZUHR4Y2FEZ1pqSjNmd2tSY0hpZDA4ckFsZUhmYy1aem
  - (2026-05-26) [Liveuamap] Mayor of Pyatykhatky in Dnipropetrovsk region was wounded in a stabbing attack - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMikwFBVV95cUxOc05paml5Q3FuRGJXbkVvLWhYZ2EwRG9GTmF0YmdvZXpXN0xlb2NJTVlzMUpoWnhvcDdJUENieGxFV2Nfb191Q3pidllIVUZOWUxnS09UckRHQnpoNndwcDdPdGUxUG81TDZfTG0yMElvWnFvN2trU3FCQmdUTT

### Paper Trading Scorecard — 137 new of 137 total
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] Roland Garros ATP: Ugo Humbert vs Quentin Halys
      This market refers to the tennis match between Ugo Humbert and Quentin Halys in the Roland Garros ATP, originally scheduled for May 27, 2026 at 5:00AM ET.

This market will resolve to 'Ugo Humbert' if Ugo Humbert advance
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Monte win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Aurora win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso

### U.S. Weather + Severe / Climate Outlooks — 124 new of 124 total
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 11:49AM EDT until May 27 at 12:30PM EDT by NWS Wilmington OH
      SVRILN

The National Weather Service in Wilmington has issued a

* Severe Thunderstorm Warning for...
Central Fairfield County in central Ohio...
North central Hocking County in central Ohio...

* Until 1230 PM EDT.

* A
  - (2026-05-27) [Severe] Flash Flood Warning: Flash Flood Warning issued May 27 at 10:49AM CDT until May 27 at 1:00PM CDT by NWS Fort Worth TX
      FFWFWD

The National Weather Service in Fort Worth has issued a

* Flash Flood Warning for...
Collin County in north central Texas...

* Until 100 PM CDT.

* At 1049 AM CDT, Doppler radar reported thunderstorms producing
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 11:44AM EDT until May 28 at 5:00AM EDT by NWS Pittsburgh PA
      ...The Flood Warning is extended for the following rivers in Ohio...

Stillwater Creek At Uhrichsville affecting Tuscarawas County.

* WHAT...Minor flooding is occurring and minor flooding is forecast.

* WHERE...Stillwa
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 8:43AM PDT until May 27 at 9:00AM PDT by NWS San Francisco CA
      The Beach Hazards Statement will be allowed to expire at 9 am this
morning.
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 11:41AM EDT until May 27 at 12:00PM EDT by NWS Mount Holly NJ
      At 1141 AM EDT, a severe thunderstorm was located over Cheswold, or
near Dover, moving east at 40 mph.

HAZARD...60 mph wind gusts.

SOURCE...Radar indicated.

IMPACT...Damage to roofs, siding, trees, and power lines is

  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 10:32AM CDT by NWS Grand Forks ND
      Relative humidity values will drop to 25| percent or less along
with east winds 10 to 15 mph gusting around 20 mph at times
across northwest MN. Near critical fire weather conditions are
expected for the afternoon and ea
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 11:31AM EDT by NWS Wilmington OH
      At 1131 AM EDT, a strong thunderstorm was located near Baltimore,
moving east at 15 mph.

HAZARD...Wind gusts up to 45 mph and very heavy rain.

SOURCE...Radar indicated.

IMPACT...Gusty winds could knock down tree limbs

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 79 new of 79 total
  - (2026-05-27) [fx] USD/EUR: 0.859651
      1 USD = 0.859651 EUR
  - (2026-05-27) [fx] USD/GBP: 0.743251
      1 USD = 0.743251 GBP
  - (2026-05-27) [fx] USD/JPY: 159.232868
      1 USD = 159.232868 JPY
  - (2026-05-27) [fx] USD/CHF: 0.785427
      1 USD = 0.785427 CHF
  - (2026-05-27) [fx] USD/CAD: 1.380782
      1 USD = 1.380782 CAD
  - (2026-05-27) [fx] USD/AUD: 1.394958
      1 USD = 1.394958 AUD
  - (2026-05-27) [fx] USD/NZD: 1.712118
      1 USD = 1.712118 NZD
  - (2026-05-27) [fx] USD/CNY: 6.798706
      1 USD = 6.798706 CNY

### Government Action: Sanctions + Procurement + Foreign Agents — 96 new of 96 total
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-20) [OFAC] International Criminal Court-related Designation Removal - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9Ea293ZzJIMldMbWM4QndMbk5YVFZDX1B1RXQ5UmM0blB5YmR6THJHa3NLeHI3bVFrNmJya0VCcUpSMlp5dFM1T1lldWZ4MlBEMXpISkREbXNYWFNMRFY3bWlR?oc=5" target="_blank">International C
  - (2026-05-20) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE00SUEzZjlGVDZYWVJCUWlDSWhpSzBUbzRKUE9pUkNDaUFJR1hDb1ppNHNISjJESjU2Vy1vSmVXOExZeUxCMnpJWVpMYnc0WEd2em0zeG9jTFMzYVJXTWc?oc=5" target="_blank">Counter Narcotics an
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR

### Congressional STOCK Act Trades (House + Senate) — 66 new of 66 total
  - (2026-05-06) [Senate] Bernardo Moreno (R): Sale (Full) ETOR ($100,001 - $250,000) (excess -0.4% vs SPY)
      Member: Bernardo Moreno (R, senate).  BioGuide: M001242.  Asset: ETOR (Stock).  Type: Sale (Full).  Amount range: $100,001 - $250,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-22.  Excess return vs SPY si
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.5% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.5% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-04-29) [House] Thomas H. Kean Jr (R): Sale ADI ($1,001 - $15,000) (excess +2.4% vs SPY)
      Member: Thomas H. Kean Jr (R, house).  BioGuide: K000398.  Asset: ADI (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-04-29.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-07) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +20.2% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-06) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +26.9% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Tim Moore (R): Purchase T ($15,001 - $50,000) (excess +0.8% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: T (ST).  Type: Purchase.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure: +0
  - (2026-05-07) [House] Tim Moore (R): Purchase RYCEY ($1,001 - $15,000) (excess -2.2% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: RYCEY (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure:

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 3 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 497 - Tidal Trust III (0001722388) (Filer)
      filed 2026-05-27 15:49 UTC — Filed: 2026-05-27 AccNo: 0001999371-26-011516 Size: 12 KB
  - (2026-05-27) [Scannapieco Alejandro Raul] Form 4 (Reporting)
      filed 2026-05-27 15:49 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-240994 Size: 8 KB
  - (2026-05-27) [VTEX] Form 4 (Issuer)
      filed 2026-05-27 15:49 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001193125-26-240994 Size: 8 KB
  - (2026-05-27) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-05-27 15:48 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014123 Size: 802 KB
  - (2026-05-27) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-05-27 15:48 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014123 Size: 802 KB
  - (2026-05-27) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-05-27 15:47 UTC — Filed: 2026-05-27 AccNo: 0001839882-26-025693 Size: 1 MB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 15:45 UTC — Filed: 2026-05-27 AccNo: 0001213900-26-061362 Size: 2 MB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 15:45 UTC — Filed: 2026-05-27 AccNo: 0001213900-26-061362 Size: 2 MB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 0 new of 0 total
  (no new items today)

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 27 new of 30 total
  - (2026-05-27) JAF8LY (Bulgaria)
      icao24: 4520ce · position: (44.5433, -2.6191) · alt: 10980m · 867km/h
  - (2026-05-27) CFC3274 (Canada)
      icao24: c2b35f · position: (46.5178, -82.8857) · alt: 10363m · 767km/h
  - (2026-05-27) PAT828 (United States)
      icao24: adfe4a · position: (37.2325, -80.4575) · alt: 8229m · 580km/h
  - (2026-05-27) PAT090 (United States)
      icao24: adfe8f · position: (43.5807, -116.2737) · alt: 1036m · 226km/h
  - (2026-05-27) PAT261 (United States)
      icao24: adfe99 · position: (36.4643, -84.992) · alt: 7924m · 563km/h
  - (2026-05-27) PAT060 (United States)
      icao24: adfebe · position: (33.7451, -100.6892) · alt: 8244m · 706km/h
  - (2026-05-27) NCR327 (United States)
      icao24: ab4ec6 · position: (34.3313, -103.6539) · alt: 12169m · 833km/h
  - (2026-05-27) CFC3848 (Canada)
      icao24: c2b57b · position: (52.7534, -102.7618) · alt: 8839m · 608km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,079,244 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,959,030 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,815,648 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 100% · 24h volume: $1,742,648 · resolves 2026-05-27
  - (2026-05-27) Roland Garros ATP: Mariano Navone vs Jakub Mensik
      yes price: 48% · 24h volume: $1,541,629 · resolves 2026-06-03
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,457,123 · resolves 2026-07-20
  - (2026-05-27) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,035,335 · resolves 2026-07-20
  - (2026-05-27) US announces new Iran agreement/ceasefire extension by May 27?
      yes price: 12% · 24h volume: $1,035,235 · resolves 2026-05-27

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-05-27) [Marginal Revolution] Wednesday assorted links
      1. As meat prices rise, the economics of Texas barbecue. 2. Economic historian Eric Jones has passed away. 3. Claims about the Pope and Claude.  If true, further evidence for my Straussian hypothesis. 4. Koyama reviews T
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-27) [Conversable Economist] Lessons for Central Banks: Interview with Kristin Forbes
      Thomas Chow poses the questions in &#8220;Kristin Forbes on &#8216;wargaming&#8217; for thenext crisis,&#8221; subtitled &#8220;The MIT professor and former BoE MPC member speaks about QE, scenario analysis and the ar of
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### U.S. Political Figures (per-figure anomaly tracking) — 613 new of 613 total
  - (2026-05-27) Senator: Angela D Alsobrooks (anomaly 0.00)
      Angela D Alsobrooks (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ
  - (2026-05-27) Senator: Alan Armstrong (anomaly 0.00)
      Alan Armstrong (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ ment
  - (2026-05-27) Senator: Tammy Baldwin (anomaly 0.00)
      Tammy Baldwin (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Jim Banks (anomaly 0.10)
      Jim Banks (Senator). Composite anomaly score 0.100. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.50. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ mentions:
  - (2026-05-27) Senator: John Barrasso (anomaly 0.00)
      John Barrasso (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Michael F Bennet (anomaly 0.00)
      Michael F Bennet (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Marsha Blackburn (anomaly 0.00)
      Marsha Blackburn (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Richard Blumenthal (anomaly 0.00)
      Richard Blumenthal (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ 

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=603, 7d-median=603, 14d-median=603
- local_news: today=256, 7d-median=256, 14d-median=256
- foreign_news: today=869, 7d-median=869, 14d-median=869
- chinese_internal: today=284, 7d-median=284, 14d-median=284
- russian_internal: today=1144, 7d-median=1144, 14d-median=1144
- ukrainian_internal: today=136, 7d-median=136, 14d-median=136
- ukraine_theater: today=394, 7d-median=394, 14d-median=394
- paper_bets: today=137, 7d-median=137, 14d-median=137
- weather: today=124, 7d-median=124, 14d-median=124
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=96, 7d-median=96, 14d-median=96
- congressional_trades: today=66, 7d-median=66, 14d-median=66
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*