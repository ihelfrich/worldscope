# WORLDSCOPE morning brief — 2026-05-27

## Headline
5269 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 615 new of 615 total
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-26) [California] Governor Newsom signs legislation 5.26.2026
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2024/05/6C94C750-0DF8-46C6-A8E3-00EA4F1B1ADD-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async" />
  - (2026-05-26) [California] Governor Newsom proclaims Older Californians Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-25) [California] Governor Newsom secures Presidential Emergency Declaration approval for Orange County hazmat response
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Governor-Newsom-secures-Presidential-Emergency-Declaration-approval-for-Orange-County-hazmat-response-SEO-GFX-v2-150x150.png" class="at
  - (2026-05-25) [California] Governor Newsom proclaims Memorial Day
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-25) [California] California mobilizes 785+ emergency personnel in Orange County hazmat response
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Orange-County-Whole-Government-Response-2-150x150.png" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async
  - (2026-05-25) [Alaska] Memorial Day 2026
      WHEREAS, America was founded on the principles of liberty and justice for all, and we recognize the generations of brave, patriotic men and women who have served in the military and have given their lives to protect and 
  - (2026-05-27) [feed error] CO Governor (Colorado): HTTPError
      403 Client Error: Forbidden for url: https://www.colorado.gov/governor/news/feed

### Local News: St. Louis + Atlanta — 246 new of 246 total
  - (2026-05-27) [St. Louis] Public pools, splash pads, and water parks in the St. Louis region
      <p>St. Louis summers are famously hot and sticky. What better way to cool down than by visiting one of the region&#8217;s many pools, swim clubs, or water parks? Even without owning a seasonal membership, families can ta
  - (2026-05-27) [St. Louis] Drive-in movie theaters within driving distance from St. Louis
      <p>Skyview Drive-In &#124; Belleville, Illinois 30 minutes east of St. Louis Whether it be a routine family night out or a special celebration, pop into the Skyview for showings of new and old favorites alike. Adult tick
  - (2026-05-27) [St. Louis] Ask Veronica: How to style a room with plants, according to design experts
      <p>A few weeks ago, I interviewed Laura Dooley, owner of LoKey Designs, and Nicole Walter, greenhouse buyer for Garden Heights Nursery, for the latest episode of my podcast House of Lou. Naturally, we talked about plants
  - (2026-05-27) [St. Louis] Every St. Louis parent eventually ends up shopping at Dierbergs for the car carts alone
      <p>As someone who works almost exclusively from home, I’m always looking for any excuse to leave the house. This often translates into frequent trips to the grocery store. Are we out of butter? I’m going to the grocery s
  - (2026-05-27) [St. Louis] A house in Tower Grove East hits the market
      <p>Custom-BuiltStep into summer in this custom-built, Palm Springs-inspired modernist home in the heart of Tower Grove. Built less than ten years ago, it maximizes functional space and natural light, while offering the d
  - (2026-05-27) [St. Louis] SLDC relaunches loan program for first-time homebuyers
      <p>St. Louis’ development agency, the St. Louis Development Corporation, relaunched its HomeSTL loan program on Tuesday, offering up to $50,000 to first-time homebuyers in the city. That loan can make the difference in s
  - (2026-05-27) [St. Louis] Maryville University Partners with NTEN for a unique cybersecurity program
      <p>Students at Maryville University have partnered up with a nonprofit tech organization to create a one-of-a-kind cybersecurity consulting program for nonprofits.&#160; It’s a partnership between the student-led consult
  - (2026-05-27) [St. Louis] A centennial celebration of Miles Davis and John Coltrane heads to Powell Hall
      <p>St. Louis has always stood at the intersection of the great modern musical genres, whether that’s the blues, jazz, rock and roll, or hip-hop. So it only makes sense that Terence Blanchard and Ravi Coltrane’s centennia

### International News + Multilateral Institutions — 890 new of 890 total
  - (2026-05-27) [feed error] AP Top News (RSSHub): HTTPError
      403 Client Error: Forbidden for url: https://rsshub.app/ap/topics/apf-topnews
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [Global] Film show: French WWII epic 'De Gaulle: Resistance' hits screens
      Ben Croll takes us through four films from the Cannes Film Festival which are being released in cinemas this week. One of France's biggest film events of the year is Antonin Baudry's "De Gaulle: Resistance", the first of
  - (2026-05-27) [Global] Trump Board of Peace's official Gaza fund is empty despite billions pledged, source says
      Four months after its creation, the Gaza reconstruction fund of US President Donald Trump's so-called Board of Peace has yet to receive any of the billions of dollars pledged by donor countries. Israel has continued to c
  - (2026-05-27) [Global] New Zealand sees brain drain to Australia amid stagnating economy
      New Zealand is facing a major brain drain. Even former prime minister Jacinda Ardern has chosen to relocate to Australia. Her decision has reignited a debate over the country's persistent struggle to retain its talent, a
  - (2026-05-27) [Global] Witnesses accuse the Israeli army of arbitrary arrests in Syria
      The Israeli army has arrested at least 197 men in southern Syria since late 2024. A lawyer confirmed that 43 of them are still being held in what he says is arbitrary detention in Israeli prisons. The Israeli army, for i

### Chinese Internal News — 283 new of 283 total
  - (2026-05-25) Analysis: Dollar’s Pain Is Yuan’s Gain - Caixin Global
      <a href="https://news.google.com/rss/articles/CBMilAFBVV95cUxPV3dBYVFiQWQ2ZWZlVEkxXzRVZ0ZTWjZLcVNPYmpsZTNhX0V5ZXdXUXB5dUVlTUZMcEszWFJKbW52cnplb3lHR3JKVmlzWjdfZ0E4Y1ZYbFZFSXlVRUFUa1lNVTVNY2pyMWVTSlZhNUFrMFlkem1jekxPZ0tzNF
  - (2026-05-27) [TITLE: “印尼如此配合美国，中国肯定不满”-观察者网 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBfT1hwRVVjVlZIV1ZiUVhfa09FbmFTaVZsNmF2Yk91ZEM4M1hvVDJHcUZySHlRbUdFcXRVeXp5ekstTjUzMURyd3N1MUc1R2] (zh: “印尼如此配合美国，中国肯定不满”-观察者网 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBfT1hwRVVjVlZIV1ZiUVhfa09FbmFTaVZsNmF2Yk91ZEM4M1hvVDJHcUZySHlRbUdFcXRVeXp5ekstTjUzMURyd3N1MUc1R2VkMlgzMXNtZm9tNUp2TUltcU96djAzZmxRTUE?oc=5" target="_blank">“印尼如
  - (2026-05-26) [TITLE: “猛攻在即”！俄罗斯建议各国从基辅撤人，乌克兰称这是“讹诈” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9zMUxqLWxlcVE4Z0JHWXducVNLOFRxUmFKeEhSSFM0NEdEMmJWTkl4Q0lmcGphNG5mZmJ3UnBWY09IcGNYQnFHZF] (zh: “猛攻在即”！俄罗斯建议各国从基辅撤人，乌克兰称这是“讹诈” - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9zMUxqLWxlcVE4Z0JHWXducVNLOFRxUmFKeEhSSFM0NEdEMmJWTkl4Q0lmcGphNG5mZmJ3UnBWY09IcGNYQnFHZFY0d201NmtrWDhudEJlNEx0Yl9FR3V3LTZnNmtPUUtObUE?oc=5" target="_blank">“猛攻在
  - (2026-05-27) [TITLE: 当英国无赖抢救最后一座高炉：不要紧张，时代真的变了 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1EQjJid3RqcXF3emlMVEYwMDJPLVNnQUJhaVVMSURYcUxiVDBuS3VxbUdVMnZEdlp5cVNIR3oxR21yNjhLT3FHdGd1SXN] (zh: 当英国无赖抢救最后一座高炉：不要紧张，时代真的变了 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1EQjJid3RqcXF3emlMVEYwMDJPLVNnQUJhaVVMSURYcUxiVDBuS3VxbUdVMnZEdlp5cVNIR3oxR21yNjhLT3FHdGd1SXNvdEY3NHQzTV80ZkRhRTlCUWhSeC1fYzc?oc=5" target="_blank">当英国无赖抢救最后一座高
  - (2026-05-27) [TITLE: 武契奇叮嘱塞尔维亚年轻人：“要同中国人学习” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBPVnpES0VENzJJcXpMcEEteUx3WGFJTEVyVDhfb3BqTkVVUkdqdURRMGZwVVRjYUstWmtYSC1DeHNyRkRaNnhSV0hHSnc5dD] (zh: 武契奇叮嘱塞尔维亚年轻人：“要同中国人学习” - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBPVnpES0VENzJJcXpMcEEteUx3WGFJTEVyVDhfb3BqTkVVUkdqdURRMGZwVVRjYUstWmtYSC1DeHNyRkRaNnhSV0hHSnc5dDdYUkdhVWVGaXpvN1FkQ0dpYlh0VVhfUFZ2a0E?oc=5" target="_blank">武契奇叮
  - (2026-05-26) [TITLE: 央视曝光：境外间谍入侵联网设备偷录窃听，预先掌握谈判底线 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1FUG5mdDN6WGVobmdxdEd5ZWcyU214V094YlQ2VlhPSTNkeFIyMmxuRV9hUi1wdkVlMTEzU1BReUg0aWNGTGdtM05w] (zh: 央视曝光：境外间谍入侵联网设备偷录窃听，预先掌握谈判底线 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1FUG5mdDN6WGVobmdxdEd5ZWcyU214V094YlQ2VlhPSTNkeFIyMmxuRV9hUi1wdkVlMTEzU1BReUg0aWNGTGdtM05wMlB5dDFRYWdvWS1xLXdjTEV3WVlkZl9WN19WQQ?oc=5" target="_blank">央视曝光：境外间谍
  - (2026-05-27) [TITLE: 礼赞社科大师｜彭康：在国家利益前提下，考虑学校、个人利益 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5keHdTU1BqS0hZRzdTQ2FkeUF5QWFScHdwQ0dCLXJoenRqeF9YTDNMQ3lRSzZtWnM5OUMxLTFORUhjYmItTVljX0I5] (zh: 礼赞社科大师｜彭康：在国家利益前提下，考虑学校、个人利益 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5keHdTU1BqS0hZRzdTQ2FkeUF5QWFScHdwQ0dCLXJoenRqeF9YTDNMQ3lRSzZtWnM5OUMxLTFORUhjYmItTVljX0I5aXc4VzNBZDhEYl9TQmE5dDYwZXVwdHRQQ09LZw?oc=5" target="_blank">礼赞社科大师｜彭康
  - (2026-05-27) [TITLE: 扎哈罗娃怒斥日本记者：你们大错特错，把这句话带给你们的政府 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1PbEJuZG5pMnZhMDZOemVjQWhtSG9QaUVvMUs1UUs4akdNbVNoM3BueFhhU1RJc21SN08tcmhjVld0TURzNnhudEt] (zh: 扎哈罗娃怒斥日本记者：你们大错特错，把这句话带给你们的政府 - 观察者)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1PbEJuZG5pMnZhMDZOemVjQWhtSG9QaUVvMUs1UUs4akdNbVNoM3BueFhhU1RJc21SN08tcmhjVld0TURzNnhudEtCSERkeXpBYVpHVVBjVWFHc0ZneXlTTHZ3SkRqSHNHSmc?oc=5" target="_blank">扎哈罗娃

### Russian Internal News (state + in-exile) — 1148 new of 1148 total
  - (2026-05-27) [TITLE: «Сосновский маньяк» Андрей Кийко, вероятно, погиб на войне. Накануне СМИ сообщали, что он сбежал из госпиталя и его разыскивают в Ленинградской области | LEDE: <p>Андрей Кийко, известный как «с] (ru: «Сосновский маньяк» Андрей Кийко, вероятно, погиб на войне. Накануне СМИ сообщал)
      <p>Андрей Кийко, известный как «сосновский маньяк», пропал без вести на фронте, считают его родственники и сослуживцы. Петербургское издание «Фонтанка», накануне сообщившее о том, что Кийко разыскивают в Ленинградской об
  - (2026-05-27) [TITLE: Зеленский написал письмо Трампу и попросил защитить Украину от российских ракет | LEDE: <p>Владимир Зеленский направил Дональду Трампу и конгрессу США письмо, в котором заявил о нехватке систем] (ru: Зеленский написал письмо Трампу и попросил защитить Украину от российских ракет)
      <p>Владимир Зеленский направил Дональду Трампу и конгрессу США письмо, в котором заявил о нехватке систем противовоздушной обороны в Украине, сообщает Kyiv Independent. Текст письма опубликовал журналист Axios Барак Рави
  - (2026-05-27) [TITLE: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. Там она воспроизводит тезисы российской пропаганды | LEDE: <p>Бывший главный редактор RT France Ксения Федорова у] (ru: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. )
      <p>Бывший главный редактор RT France Ксения Федорова устроилась на работу на французском правоконсервативном телеканале CNews, рассказывается в публикациях Politico и русской службы RFI. <p>
  - (2026-05-27) [TITLE: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за пределы Украины и объявит новую мобилизацию | LEDE: <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает] (ru: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за п)
      <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. К
  - (2026-05-27) [TITLE: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли более 20 студентов колледжа. Вот что о них и об этой атаке рассказывают однокурсники и друзья | LEDE: <p>В ночь на ] (ru: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли бо)
      <p>В ночь на 22 мая украинские войска нанесли удар беспилотниками по Старобельску в аннексированной ЛНР. Под обстрел попали педагогический колледж и профессиональный колледж Луганского педагогического университета. По оф
  - (2026-05-27) [TITLE: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской области объяснили, зачем запретили иностранные надписи на школьной одежде | LEDE: <p>Департамент образования Томской] (ru: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской обл)
      <p>Департамент образования Томской области заявил, что запрет носить одежду с иностранными надписями, принятый в нескольких школах региона, призван уберечь детей от «чуждых и опасных» смыслов.<p>
  - (2026-05-27) [TITLE: Парламент Венгрии остановил выход страны из Международного уголовного суда, начатый предыдущим премьером Виктором Орбаном | LEDE: <p>Парламент Венгрии одобрил отзыв решения о выходе страны из М] (ru: Парламент Венгрии остановил выход страны из Международного уголовного суда, нача)
      <p>Парламент Венгрии одобрил отзыв решения о выходе страны из Международного уголовного суда (МУС).<p>
  - (2026-05-27) [TITLE: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей или до пяти лет лишения свободы | LEDE: <p>Госдума приняла в первом чтении законопроект о наказании за незаконный] (ru: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей )
      <p>Госдума приняла в первом чтении законопроект о наказании за незаконный майнинг. Документ вводит в Уголовный кодекс новую статью 171.6.<p>

### Ukrainian Internal News (national + local Kyiv) — 136 new of 136 total
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-27) [feed error] Kyiv Independent: HTTPError
      404 Client Error: Not Found for url: https://kyivindependent.com/rss/
  - (2026-05-27) [feed error] President of Ukraine: HTTPError
      403 Client Error: Forbidden for url: https://www.president.gov.ua/en/news/rss/2027
  - (2026-05-27) [feed error] Babel: HTTPError
      404 Client Error: Not Found for url: https://babel.ua/rss
  - (2026-05-27) [feed error] Censor.NET: HTTPError
      404 Client Error: Not Found for url: https://censor.net/news/rss
  - (2026-05-27) [TITLE: У листі Трампу й конгресменам Зеленський згадав атаку РФ двома "Орєшніками" на Україну | LEDE: У листі президента Володимира Зеленського до американського лідера Дональда Трампа й членів Конгре] (uk: У листі Трампу й конгресменам Зеленський згадав атаку РФ двома "Орєшніками" на У)
      У листі президента Володимира Зеленського до американського лідера Дональда Трампа й членів Конгресу США йшлося про атаку РФ із використанням балістичних ракет середньої дальності "Орєшнік".
  - (2026-05-27) [TITLE: Прем'єр Болгарії вважає, що ЄС має очолити переговори з РФ щодо війни в Україні | LEDE: ] (uk: Прем'єр Болгарії вважає, що ЄС має очолити переговори з РФ щодо війни в Україні)
  - (2026-05-27) [TITLE: Зеленський: Росія готує додаткову мобілізацію | LEDE: Режим Володимира Путіна поставив завдання збільшити контингент російської окупаційної армії, це свідчить, що Москва не планує по-справжньом] (uk: Зеленський: Росія готує додаткову мобілізацію)
      Режим Володимира Путіна поставив завдання збільшити контингент російської окупаційної армії, це свідчить, що Москва не планує по-справжньому вести мирні переговори.

### Ukraine Theater (total-war monitoring) — 394 new of 394 total
  - (2026-05-27) [Air alerts error] HTTPError (set ALERTS_IN_UA_TOKEN for v2)
      401 Client Error: Unauthorized for url: https://api.alerts.in.ua/v1/alerts/active.json
  - (2026-05-27) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-25) [Liveuamap] Russian FM Lavrov informed State Secretary Rubio that Russia will intensify strikes on Kyiv. Lavrov urged Rubio to evacuate U.S. citizens and diplomatic staff from Kyiv Moskva, Moscow - Ukraine Interactive map - Ukraine Latest news on live 
      <a href="https://news.google.com/rss/articles/CBMikgFBVV95cUxQTkE1MmhVLXlxWmVTMW45QlppeVlWOVFva1ZNbUpRdU85eksxb0U3dS1qdW52bFlOWlhLNTQ3aHdKMWdzUFRfbXBwRzF5YW1rdklmQXpoRE5qQ2x1eHk0MVl4YWtTQmhnVEcxcmpGUF9xb0JuOXllcDY5UDNsXz
  - (2026-05-26) [Liveuamap] The U.S. Navy has resumed escorting ships through the Strait of Hormuz under a renewed “Project Freedom” mission. A Greek supertanker carrying two million barrels of crude was recently guided through the route after being stranded in the Gu
      <a href="https://news.google.com/rss/articles/CBMilwFBVV95cUxPaW5lLXY3NUJLY0ItLUJxZThHc2M4c1ExQjFYVzNrQUlUZENnZlppel9mc3dMUTRoem1LUllkT3liOTFCeGgwX0JZbTVvdjRrWUJrRUh2cnBWS1ZhOEpzZGFHX3M4UWFvdUdkLV9ERU1vcjFnYmVVd0Zza1VaRz
  - (2026-05-24) [Liveuamap] Fire reported at the fuel depot in Unecha of Bryansk region - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilwFBVV95cUxNSGt2V0tVVjJwelo3ejUxdjhORXhPb1NvX2xnWkF3ZjlYREhLMFpPTTliZTR2MWRzRjFfVlVpeHJBMzR3bm9tSFQ1U0FhRXlnNGNMRUd3TWNUMGdBcmdMVGlqTVJibjl5Qlo1RE9DRDFjOVNXaWdEVjBqdTlfc2
  - (2026-05-27) [Liveuamap] Explosions were reported in Taganrog, possible missile strike - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMimAFBVV95cUxNNkM3eUZzd1ExXzhSRTlGbE8zbFBJZWNJcHBoZ3I3TXBBYUdqaU1oTHlFZjFlenBLUlhMUkNza0JYc3VCRHU1allIMDBwZGo1WldiV1M5aHh4M1ptMy15UWVPeXBlX3ZHbnhPeU42NmNjcjFOTkFMbkt4dVpjNU
  - (2026-05-26) [Liveuamap] Amal Shehadeh: The Israeli army is operating north of the yellow line and making extensive preparations to pursue field commanders in Nabatieh. - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMingFBVV95cUxPNzhSWEFycm1vYjVqREFsUHhpWXdwc3Z2ck1STzBOZmRlVDZ5MUwyYmdmRmlWMHFOUkh5THNmVjRCX1NWQzVPSkJDNzh1S2NtUTlibnlqc0hPRU0zZlhZUHR4Y2FEZ1pqSjNmd2tSY0hpZDA4ckFsZUhmYy1aem
  - (2026-05-26) [Liveuamap] Mayor of Pyatykhatky in Dnipropetrovsk region was wounded in a stabbing attack - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMikwFBVV95cUxOc05paml5Q3FuRGJXbkVvLWhYZ2EwRG9GTmF0YmdvZXpXN0xlb2NJTVlzMUpoWnhvcDdJUENieGxFV2Nfb191Q3pidllIVUZOWUxnS09UckRHQnpoNndwcDdPdGUxUG81TDZfTG0yMElvWnFvN2trU3FCQmdUTT

### Paper Trading Scorecard — 136 new of 136 total
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Monte win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Aurora win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso
  - (2026-05-27) [Polymarket] Will Hyperliquid dip to $20 by December 31, 2026?
      This market will immediately resolve to “Yes” if any Binance 1-minute candle for Hyperliquid (HYPEUSDT) between November 24, 2025, 15:45 and December 31, 2026, 23:59 in the ET timezone has a final “Low” price equal to or

### U.S. Weather + Severe / Climate Outlooks — 128 new of 128 total
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 9:02AM PDT until May 28 at 11:00PM PDT by NWS Eureka CA
      * WHAT...Increased threat of sneaker waves expected.

* WHERE...Beaches in Del Norte, Humboldt, and Mendocino counties
that are exposed to the northwest.

* WHEN...From Wednesday afternoon through Thursday evening. .

* 
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 11:01AM CDT by NWS Duluth MN
      Dry conditions are forecast this afternoon for portions areas of
northeast Minnesota north of a line from Walker to Hibbing to Ely.
Relative humidity values between 20 and 30 percent will lead to
near-critical fire weath
  - (2026-05-27) [Moderate] Gale Warning: Gale Warning issued May 27 at 9:01AM PDT until May 27 at 11:00PM PDT by NWS Eureka CA
      * WHAT...For the Gale Warning, north winds 20 to 30 kt with
gusts up to 40 kt and seas 11 to 14 feet expected. For the
Small Craft Advisory, north winds 25 to 30 kt with gusts up to
40 kt and seas 11 to 14 feet.

* WHERE
  - (2026-05-27) [Moderate] Gale Warning: Gale Warning issued May 27 at 9:01AM PDT until May 27 at 12:00PM PDT by NWS Eureka CA
      * WHAT...Northwest winds 25 to 30 kt with gusts up to 35 kt and
seas 12 to 16 feet.

* WHERE...Waters from Cape Mendocino to Pt. Arena CA from 10 to
60 nm.

* WHEN...Until noon PDT today.

* IMPACTS...Strong winds will c
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 11:58AM EDT until May 27 at 1:00PM EDT by NWS Mount Holly NJ
      SVRPHI

The National Weather Service in Mount Holly NJ has issued a

* Severe Thunderstorm Warning for...
Central Kent County in central Delaware...
Southwestern Atlantic County in southern New Jersey...
Southern Cumberl
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 11:58AM EDT until May 27 at 12:30PM EDT by NWS Wilmington OH
      At 1158 AM EDT, a severe thunderstorm was located over Pleasantville,
moving southeast at 25 mph.

HAZARD...60 mph wind gusts and penny size hail.

SOURCE...Radar indicated.

IMPACT...Expect damage to trees and power lin
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 11:56AM EDT until May 27 at 12:30PM EDT by NWS Charleston WV
      SVRRLX

The National Weather Service in Charleston West Virginia has issued a

* Severe Thunderstorm Warning for...
Central Perry County in southeastern Ohio...

* Until 1230 PM EDT.

* At 1156 AM EDT, a severe thunderst

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 79 new of 79 total
  - (2026-05-27) [fx] USD/EUR: 0.859651
      1 USD = 0.859651 EUR
  - (2026-05-27) [fx] USD/GBP: 0.743251
      1 USD = 0.743251 GBP
  - (2026-05-27) [fx] USD/JPY: 159.232868
      1 USD = 159.232868 JPY
  - (2026-05-27) [fx] USD/CHF: 0.785427
      1 USD = 0.785427 CHF
  - (2026-05-27) [fx] USD/CAD: 1.380782
      1 USD = 1.380782 CAD
  - (2026-05-27) [fx] USD/AUD: 1.394958
      1 USD = 1.394958 AUD
  - (2026-05-27) [fx] USD/NZD: 1.712118
      1 USD = 1.712118 NZD
  - (2026-05-27) [fx] USD/CNY: 6.798706
      1 USD = 6.798706 CNY

### Government Action: Sanctions + Procurement + Foreign Agents — 96 new of 96 total
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-20) [OFAC] International Criminal Court-related Designation Removal - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9Ea293ZzJIMldMbWM4QndMbk5YVFZDX1B1RXQ5UmM0blB5YmR6THJHa3NLeHI3bVFrNmJya0VCcUpSMlp5dFM1T1lldWZ4MlBEMXpISkREbXNYWFNMRFY3bWlR?oc=5" target="_blank">International C
  - (2026-05-20) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE00SUEzZjlGVDZYWVJCUWlDSWhpSzBUbzRKUE9pUkNDaUFJR1hDb1ppNHNISjJESjU2Vy1vSmVXOExZeUxCMnpJWVpMYnc0WEd2em0zeG9jTFMzYVJXTWc?oc=5" target="_blank">Counter Narcotics an
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-05-27) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 3 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 16:08 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014131 Size: 790 KB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 16:08 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014131 Size: 790 KB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 16:08 UTC — Filed: 2026-05-27 AccNo: 0001213900-26-061372 Size: 2 MB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 16:08 UTC — Filed: 2026-05-27 AccNo: 0001213900-26-061372 Size: 2 MB
  - (2026-05-27) 497 - PGIM ETF TRUST (0001727074) (Filer)
      filed 2026-05-27 16:06 UTC — Filed: 2026-05-27 AccNo: 0001727074-26-000073 Size: 1 MB
  - (2026-05-27) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-05-27 16:05 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014130 Size: 808 KB
  - (2026-05-27) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-05-27 16:05 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014130 Size: 808 KB
  - (2026-05-27) 424B2 - UBS AG (0001114446) (Filer)
      filed 2026-05-27 16:05 UTC — Filed: 2026-05-27 AccNo: 0001839882-26-025700 Size: 649 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [India] Suvendu Adhikari 3D Policy To Deal With Illegal Migrants
      domain: freepressjournal.in · language: English · tone: 
  - (2026-05-27) [India] Hezbollah says clashed with Israeli troops in south Lebanon beyond  yellow line  
      domain: thehindu.com · language: English · tone: 
  - (2026-05-27) [Israel] What could have been and what could be
      domain: israelnationalnews.com · language: English · tone: 
  - (2026-05-27) [United States] Deadly shooting in Tampa under investigation : HCSO
      domain: fox13news.com · language: English · tone: 
  - (2026-05-27) [United Kingdom] Teenagers jailed after boy stabbed in Peterborough underpass
      domain: cambstimes.co.uk · language: English · tone: 
  - (2026-05-27) [South Africa] DJ Warras murder case moved to high court , pre - trial set for June
      domain: timeslive.co.za · language: English · tone: 
  - (2026-05-27) [United States] Trump cabinet meets as fragile Iran peace talks reach critical stage
      domain: fox13now.com · language: English · tone: 
  - (2026-05-27) [United States] Panel Saw Market to Reach USD 3 . 2 Billion by 2035 as Smart
      domain: openpr.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 27 new of 30 total
  - (2026-05-27) JAF8LY (Bulgaria)
      icao24: 4520ce · position: (46.5415, -1.5786) · alt: 10363m · 868km/h
  - (2026-05-27) PAT315 (United States)
      on ground
  - (2026-05-27) PAT131 (United States)
      icao24: adfe53 · position: (46.807, -97.4749) · alt: 3055m · 391km/h
  - (2026-05-27) PAT828 (United States)
      icao24: adfe4a · position: (37.8149, -78.7767) · alt: 3931m · 515km/h
  - (2026-05-27) PAT261 (United States)
      icao24: adfe99 · position: (37.8215, -84.5588) · alt: 7924m · 559km/h
  - (2026-05-27) PAT060 (United States)
      icao24: adfebe · position: (32.87, -99.9006) · alt: 3048m · 561km/h
  - (2026-05-27) NCR327 (United States)
      icao24: ab4ec6 · position: (34.3546, -106.1074) · alt: 12192m · 798km/h
  - (2026-05-27) CFC4046 (Canada)
      icao24: c2b3ff · position: (44.4246, -76.4264) · alt: 4884m · 804km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,115,204 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,958,996 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,852,269 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 100% · 24h volume: $1,744,256 · resolves 2026-05-27
  - (2026-05-27) Roland Garros ATP: Mariano Navone vs Jakub Mensik
      yes price: 14% · 24h volume: $1,729,331 · resolves 2026-06-03
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,461,663 · resolves 2026-07-20
  - (2026-05-27) US announces new Iran agreement/ceasefire extension by May 27?
      yes price: 10% · 24h volume: $1,050,607 · resolves 2026-05-27
  - (2026-05-27) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $1,043,912 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-05-27) [Marginal Revolution] Wednesday assorted links
      1. As meat prices rise, the economics of Texas barbecue. 2. Economic historian Eric Jones has passed away. 3. Claims about the Pope and Claude.  If true, further evidence for my Straussian hypothesis. 4. Koyama reviews T
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-27) [Conversable Economist] Lessons for Central Banks: Interview with Kristin Forbes
      Thomas Chow poses the questions in &#8220;Kristin Forbes on &#8216;wargaming&#8217; for thenext crisis,&#8221; subtitled &#8220;The MIT professor and former BoE MPC member speaks about QE, scenario analysis and the ar of
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### U.S. Political Figures (per-figure anomaly tracking) — 613 new of 613 total
  - (2026-05-27) Senator: Angela D Alsobrooks (anomaly 0.00)
      Angela D Alsobrooks (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ
  - (2026-05-27) Senator: Alan Armstrong (anomaly 0.00)
      Alan Armstrong (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ ment
  - (2026-05-27) Senator: Tammy Baldwin (anomaly 0.00)
      Tammy Baldwin (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Jim Banks (anomaly 0.10)
      Jim Banks (Senator). Composite anomaly score 0.100. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.50. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ mentions:
  - (2026-05-27) Senator: John Barrasso (anomaly 0.00)
      John Barrasso (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Michael F Bennet (anomaly 0.00)
      Michael F Bennet (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Marsha Blackburn (anomaly 0.00)
      Marsha Blackburn (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Richard Blumenthal (anomaly 0.00)
      Richard Blumenthal (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ 

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=615, 7d-median=615, 14d-median=615
- local_news: today=246, 7d-median=246, 14d-median=246
- foreign_news: today=890, 7d-median=890, 14d-median=890
- chinese_internal: today=283, 7d-median=283, 14d-median=283
- russian_internal: today=1148, 7d-median=1148, 14d-median=1148
- ukrainian_internal: today=136, 7d-median=136, 14d-median=136
- ukraine_theater: today=394, 7d-median=394, 14d-median=394
- paper_bets: today=136, 7d-median=136, 14d-median=136
- weather: today=128, 7d-median=128, 14d-median=128
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=96, 7d-median=96, 14d-median=96
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*