# WORLDSCOPE morning brief — 2026-05-27

## Headline
5250 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 724 new of 724 total
  - (2026-05-27) [Alabama] World Trade Month
      Download
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-27) [California] Jueces de California están probando un nuevo asistente judicial con inteligencia artificial, y no sabrás si está revisando tu caso
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Los demócratas dijeron que se mantendrían al margen de esta contienda en California. Luego tomaron partido
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052026-Villegas-V-Bains-Split-CM-01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si
  - (2026-05-27) [California] Una pequeña solución podría marcar una gran diferencia en la contaminación del río Tijuana: ¿Cuándo se implementará?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp

### Local News: St. Louis + Atlanta — 253 new of 253 total
  - (2026-05-27) [St. Louis] Police Board blows off aldermen, fast-tracks drone approval
      <p>It was a wild Wednesday in the ongoing battle between St. Louis city leaders and the state-appointed Board of Police Commissioners, with the board approving a drone program over the mayor’s strenuous objections, board
  - (2026-05-27) [St. Louis] Missouri History Museum’s Summer Family Fun Series returns with crafts, music, and free activities on Fridays
      <p>For parents looking to fill long summer mornings without draining the entertainment budget, the Missouri History Museum is bringing back a familiar favorite. The museum’s free Summer Family Fun Series returns this sum
  - (2026-05-27) [St. Louis] Where in Clayton? – 5/27/2026
      <p>Let&#8217;s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click &#8220;lock i
  - (2026-05-27) [St. Louis] Katie’s grows footprint at Target with new pasta bake entrées and sauces
      <p>What began with frozen pizza has evolved into a much larger retail push for Katie&#8217;s at Target stores. Last fall, the retailer introduced Katie&#8217;s frozen pizzas in all 1,800 stores nationwide, a move that ca
  - (2026-05-27) [St. Louis] Cool caves to explore within driving distance of St. Louis
      <p>Cliff Cave Park &#124; Oakville, Missouri &#124; 30 minutes from downtown St. Louis This beautiful 525-acre public park is home to biking and hiking trails, fishing spots, shelters, and more. The cave&#8217;s history 
  - (2026-05-27) [St. Louis] ‘The Tempest’ rolls into Shakespeare Glen
      <p>As evening falls on Forest Park, the music of guitars, accordion, and hand drum fills the tree-lined bowl of Shakespeare Glen. A fitting drizzle falls on the final dress rehearsal for St. Louis Shakespeare Festival’s 
  - (2026-05-27) [St. Louis] Public pools, splash pads, and water parks in the St. Louis region
      <p>St. Louis summers are famously hot and sticky. What better way to cool down than by visiting one of the region&#8217;s many pools, swim clubs, or water parks? Even without owning a seasonal membership, families can ta
  - (2026-05-27) [St. Louis] Drive-in movie theaters within driving distance from St. Louis
      <p>Skyview Drive-In &#124; Belleville, Illinois 30 minutes east of St. Louis Whether it be a routine family night out or a special celebration, pop into the Skyview for showings of new and old favorites alike. Adult tick

### International News + Multilateral Institutions — 886 new of 886 total
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [Global] US building Ebola quarantine center in Kenya for Americans amid outbreak
  - (2026-05-27) [Global] WHO chief calls for DRC ceasefire to tackle Ebola outbreak
  - (2026-05-25) [Global] Spread of Ebola in DRC ‘outpacing’ response efforts, warns WHO
  - (2026-05-25) [Global] ‘She does not back down’: the couple seeking to legalise same-sex marriage in Botswana
  - (2026-05-27) [Global] Canada to order military plane fleet from Sweden in shift from US suppliers
  - (2026-05-26) [Global] President Sheinbaum allows Iran team to stay in Mexico during World Cup after US refusal

### Chinese Internal News — 290 new of 290 total
  - (2026-05-25) Analysis: Dollar’s Pain Is Yuan’s Gain - Caixin Global
      <a href="https://news.google.com/rss/articles/CBMilAFBVV95cUxPV3dBYVFiQWQ2ZWZlVEkxXzRVZ0ZTWjZLcVNPYmpsZTNhX0V5ZXdXUXB5dUVlTUZMcEszWFJKbW52cnplb3lHR3JKVmlzWjdfZ0E4Y1ZYbFZFSXlVRUFUa1lNVTVNY2pyMWVTSlZhNUFrMFlkem1jekxPZ0tzNF
  - (2026-05-26) China’s Fiscal Revenue Improves but Spending Momentum Fades - Caixin Global
      <a href="https://news.google.com/rss/articles/CBMiswFBVV95cUxPNm9UZmo0bTVfTTgzWjZYeVRsRTdNQU9QYXdSdG4zTEhhc1psRk5iTnpFOHN2NWNKWXhlbnNLVU9SaXdHWWp6dlRXQmNCdzBOSEtqVDg5ZEhrSnNGUmlDZzVMWEdYVkxSbjZUd1pUOEZydGZYRlFUUWktWjNNcT
  - (2026-05-27) [TITLE: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3OD] (zh: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3ODJlTk9Hc1N4VEUxUEdRUzM4NzBDMThV?oc=5" target="_blank">电信诈骗版图南迁 自柬埔寨转向印尼</
  - (2026-05-27) [TITLE: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q] (zh: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q0t2MlR5Z0hQX2pYTl90ZWl0R3BBbXVFUE1r?oc=5" target="_blank">跨省履新仅8个月 “70后”高官李伟江
  - (2026-05-27) [TITLE: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNk] (zh: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNkd4djhVSzQ2dV96bmZwVzhvLUc3TW1ZTEQ0?oc=5" target="_blank">深圳一快速路段发生火灾 警方称无人受伤
  - (2026-05-26) [TITLE: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGh] (zh: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGhBenBsLXFZOVJxRl9xSmVnZHJHMUNB?oc=5" target="_blank">财经早知道｜深圳常住人口首破1
  - (2026-05-25) [TITLE: 最新封面报道｜争夺估值王 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjl] (zh: 最新封面报道｜争夺估值王 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjlCYlZvR05ONEE2Mg?oc=5" target="_blank">最新封面报道｜争夺估值王</a>&
  - (2026-05-27) [TITLE: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHd] (zh: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHdyandPQXJnQW5YN2RmdU03U1FhOVFYV1Zn?oc=5" target="_blank">AI、石化产业链带动4月工业利

### Russian Internal News (state + in-exile) — 990 new of 990 total
  - (2026-05-27) [feed error] Meduza: ConnectionError
      ('Connection aborted.', ConnectionResetError(104, 'Connection reset by peer'))
  - (2026-05-28) [TITLE: Источник: ВВС Израиля нанесли удары по крупнейшему городу на юге Ливана | LEDE: ] (ru: Источник: ВВС Израиля нанесли удары по крупнейшему городу на юге Ливана)
  - (2026-05-28) [TITLE: Опрос показал, сколько россиян имеет подработку | LEDE: ] (ru: Опрос показал, сколько россиян имеет подработку)
  - (2026-05-28) [TITLE: СМИ: поток украинских мигрантов в ФРГ может вырасти из-за пособий в Польше | LEDE: ] (ru: СМИ: поток украинских мигрантов в ФРГ может вырасти из-за пособий в Польше)
  - (2026-05-28) [TITLE: Онищенко назвал главные симптомы лихорадки Эбола | LEDE: ] (ru: Онищенко назвал главные симптомы лихорадки Эбола)
  - (2026-05-28) [TITLE: Глава минздрава США поймал гремучую змею с помощью сачка | LEDE: ] (ru: Глава минздрава США поймал гремучую змею с помощью сачка)
  - (2026-05-28) [TITLE: Украинцы в день свадьбы Кулебы напомнили ему о конфликте | LEDE: ] (ru: Украинцы в день свадьбы Кулебы напомнили ему о конфликте)
  - (2026-05-28) [TITLE: Дерматолог рассказала, как определить опасную родинку | LEDE: ] (ru: Дерматолог рассказала, как определить опасную родинку)

### Ukrainian Internal News (national + local Kyiv) — 138 new of 138 total
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-27) [feed error] Kyiv Independent: HTTPError
      404 Client Error: Not Found for url: https://kyivindependent.com/rss/
  - (2026-05-27) [feed error] Hromadske: ConnectionError
      ('Connection aborted.', ConnectionResetError(104, 'Connection reset by peer'))
  - (2026-05-27) [feed error] President of Ukraine: HTTPError
      403 Client Error: Forbidden for url: https://www.president.gov.ua/en/news/rss/2027
  - (2026-05-27) Northolt Treaty Deepens UK-Poland Defense Ties Amid Fears for NATO’s Future
      UK Prime Minister Sir Keir Starmer and Polish Prime Minister Donald Tusk have signed the Northolt Treaty, a defense and security pact that will strengthen air defense cooperation and joint efforts against Russian hybrid 
  - (2026-05-27) Trump’s Gaza Peace Board Raises Zero Dollars, Reports Say
      Trump’s Board of Peace for Gaza has raised no money into its official World Bank fund four months after launch and multibillion-dollar pledges, the Financial Times reported. Instead, donors have sent limited contribution
  - (2026-05-27) Ukraine Ready to Buy Patriots as Zelensky Warns Russia Prepares New Wave of ‘Terror Strikes’
      President Zelensky appealed to US President Trump and Congress for expanded air defense support, warning that Russia is escalating missile and drone attacks on Ukraine. He said a recent strike included hundreds of drones
  - (2026-05-27) Zelensky Says Russia’s Mobilization Push Is Proof Moscow ‘Not Preparing for Real Diplomacy’
      President Zelensky said that Ukraine has growing intelligence indicating Russia is preparing for an additional mobilization wave to compensate for high casualties, with Moscow’s alleged order to increase its forces by te

### Ukraine Theater (total-war monitoring) — 394 new of 394 total
  - (2026-05-27) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [Air alerts error] HTTPError (set ALERTS_IN_UA_TOKEN for v2)
      401 Client Error: Unauthorized for url: https://api.alerts.in.ua/v1/alerts/active.json
  - (2026-05-26) [FIRMS] thermal anomaly 51.499, 31.703 (FRP 1.7 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 1.7 MW
  - (2026-05-26) [FIRMS] thermal anomaly 51.893, 29.339 (FRP 3.25 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 3.25 MW
  - (2026-05-26) [FIRMS] thermal anomaly 50.454, 34.113 (FRP 1.46 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 1.46 MW
  - (2026-05-26) [FIRMS] thermal anomaly 51.853, 26.552 (FRP 3.35 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 3.35 MW
  - (2026-05-26) [FIRMS] thermal anomaly 50.888, 28.479 (FRP 3.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 3.19 MW
  - (2026-05-26) [FIRMS] thermal anomaly 50.887, 28.484 (FRP 3.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-05-26 0030Z, FRP 3.19 MW

### Paper Trading Scorecard — 135 new of 135 total
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Raphaël Glucksmann win the 2027 French presidential election?
      The next French presidential election is currently expected to be held around April 2027.  This market pertains to the outcome of the next French presidential election, regardless of whether it follows the scheduled end 
  - (2026-05-27) [Polymarket] Israeli parliament dissolved by May 31?
      This market will resolve to "Yes" if the sitting Israeli Knesset (Israel's parliament), as of this market's inception, is dissolved between market creation and May 31, 2026, 11:59 PM ET. Otherwise, this market will resol
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso
  - (2026-05-27) [Polymarket] Will Solana dip to $10 in May?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for SOL/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa

### U.S. Weather + Severe / Climate Outlooks — 147 new of 147 total
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 6:37PM EDT by NWS Charleston WV
      At 637 PM EDT, Doppler radar was tracking a strong thunderstorm near
Head of Grassy, or 11 miles northwest of Olive Hill, moving southeast
at 20 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar i
  - (2026-05-27) [Moderate] Beach Hazards Statement: Beach Hazards Statement issued May 27 at 5:37PM CDT until May 28 at 1:00PM CDT by NWS Milwaukee/Sullivan WI
      * WHAT...Life threatening waves of 3 to 6 feet and dangerous
currents are expected.

* WHERE...Sheboygan, Ozaukee, Milwaukee, Racine and Kenosha
Counties.

* WHEN...From 7 PM CDT this evening through Thursday afternoon.

  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 6:32PM EDT by NWS Jackson KY
      At 632 PM EDT, Doppler radar was tracking a strong thunderstorm over
Waltz, or 11 miles north of Morehead, moving southeast at 30 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IMPA
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 6:32PM EDT by NWS Blacksburg VA
      At 632 PM EDT, Doppler radar was tracking a strong thunderstorm over
Ruffin, or near Bethel, moving southeast at 20 mph.

HAZARD...Wind gusts up to 40 mph and half inch hail.

SOURCE...Radar indicated.

IMPACT...Gusty wi
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Severe] Special Marine Warning: Special Marine Warning issued May 27 at 6:29PM EDT until May 27 at 7:00PM EDT by NWS Key West FL
      For the following areas...
Straits of Florida from west end of Seven Mile Bridge to Halfmoon
Shoal out 60 nm...

At 629 PM EDT, fast moving showers were located along a line
extending from 22 nm south of Twenty-Eight Foo
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 5:28PM CDT until May 27 at 5:45PM CDT by NWS Green Bay WI
      At 528 PM CDT, a severe thunderstorm was located 12 miles east of
Marshfield, or 20 miles north of Wisconsin Rapids, moving southeast
at 30 mph.

HAZARD...60 mph wind gusts and quarter size hail.

SOURCE...Radar indicate
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 6:26PM EDT by NWS Blacksburg VA
      At 626 PM EDT, Doppler radar was tracking a strong thunderstorm near
Pilot, moving east at 40 mph.

HAZARD...Wind gusts up to 40 mph.

SOURCE...Radar indicated.

IMPACT...Gusty winds could knock down tree limbs and blow 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 79 new of 79 total
  - (2026-05-27) [fx] USD/EUR: 0.859651
      1 USD = 0.859651 EUR
  - (2026-05-27) [fx] USD/GBP: 0.743251
      1 USD = 0.743251 GBP
  - (2026-05-27) [fx] USD/JPY: 159.232868
      1 USD = 159.232868 JPY
  - (2026-05-27) [fx] USD/CHF: 0.785427
      1 USD = 0.785427 CHF
  - (2026-05-27) [fx] USD/CAD: 1.380782
      1 USD = 1.380782 CAD
  - (2026-05-27) [fx] USD/AUD: 1.394958
      1 USD = 1.394958 AUD
  - (2026-05-27) [fx] USD/NZD: 1.712118
      1 USD = 1.712118 NZD
  - (2026-05-27) [fx] USD/CNY: 6.798706
      1 USD = 6.798706 CNY

### Government Action: Sanctions + Procurement + Foreign Agents — 95 new of 95 total
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-20) [OFAC] International Criminal Court-related Designation Removal - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9Ea293ZzJIMldMbWM4QndMbk5YVFZDX1B1RXQ5UmM0blB5YmR6THJHa3NLeHI3bVFrNmJya0VCcUpSMlp5dFM1T1lldWZ4MlBEMXpISkREbXNYWFNMRFY3bWlR?oc=5" target="_blank">International C
  - (2026-05-20) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE00SUEzZjlGVDZYWVJCUWlDSWhpSzBUbzRKUE9pUkNDaUFJR1hDb1ppNHNISjJESjU2Vy1vSmVXOExZeUxCMnpJWVpMYnc0WEd2em0zeG9jTFMzYVJXTWc?oc=5" target="_blank">Counter Narcotics an
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-05-27) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 5 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-27) [CA1] Argueta Castillo v. Blanche
  - (2026-05-26) [CA3] United States v. Paul Girard
  - (2026-05-26) [CA4] Tony Messer v. Garrison Investment Group, LP

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) [COMPTON SEAN] Form 4 (Reporting)
      filed 2026-05-27 22:38 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242342 Size: 8 KB
  - (2026-05-27) [NEXSTAR MEDIA GROUP, INC.] Form 4 (Issuer)
      filed 2026-05-27 22:38 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001193125-26-242342 Size: 8 KB
  - (2026-05-27) [Haveli Investment Management LLC] Form 4 (Reporting)
      filed 2026-05-27 22:38 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242341 Size: 22 KB
  - (2026-05-27) [Haveli Investments, L.P.] Form 4 (Reporting)
      filed 2026-05-27 22:38 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242341 Size: 22 KB
  - (2026-05-27) [Haveli Investments Software Fund I GP, LLC] Form 4 (Reporting)
      filed 2026-05-27 22:38 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242341 Size: 22 KB
  - (2026-05-27) [Haveli Brooks Aggregator, L.P.] Form 4 (Reporting)
      filed 2026-05-27 22:38 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242341 Size: 22 KB
  - (2026-05-27) [Whanau Interests LLC] Form 4 (Reporting)
      filed 2026-05-27 22:38 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242341 Size: 22 KB
  - (2026-05-27) [Haveli Software Management LLC] Form 4 (Reporting)
      filed 2026-05-27 22:38 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242341 Size: 22 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [Germany] New Horizon Aircraft Ltd . Announces Closing of $25 Million Offering of Common Shares
      domain: finanznachrichten.de · language: English · tone: 
  - (2026-05-27) [Turkey] Coming weeks  important  for Ukraine EU accession process : European Commission chief
      domain: aa.com.tr · language: English · tone: 
  - (2026-05-27) [United States] UBS Flips GE HealthCare ( GEHC ) From Sell to Neutral After a 30 % Stock Decline
      domain: insidermonkey.com · language: English · tone: 
  - (2026-05-27) [United States] Shooting at Shakopee prayer service leaves one dead
      domain: kfgo.com · language: English · tone: 
  - (2026-05-27) [United States] William Blair Initiates on Insulet ( PODD ) With Outperform and Says the Valuation Gap Is Hard to Justify
      domain: insidermonkey.com · language: English · tone: 
  - (2026-05-27) [United States] Several dogs kept in a large trailer spark concern
      domain: krtv.com · language: English · tone: 
  - (2026-05-27) [United States] Kalamazoo County issues health advisory for Austin Lake
      domain: wmuk.org · language: English · tone: 
  - (2026-05-27) [United States] Analysis : US will need years to restock weapons used in Iran War
      domain: koat.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 22 new of 23 total
  - (2026-05-27) CFC3274 (Canada)
      icao24: c2b35f · position: (46.4181, -81.3481) · alt: 10668m · 970km/h
  - (2026-05-27) PAT085 (United States)
      icao24: adfe54 · position: (39.6991, -76.1067) · alt: 1097m · 433km/h
  - (2026-05-27) GAF197 (Germany)
      icao24: 3f7588 · position: (52.513, 9.9905) · alt: 502m · 468km/h
  - (2026-05-27) NCR327 (United States)
      icao24: ab4ec6 · position: (35.1324, -97.1932) · alt: 12496m · 886km/h
  - (2026-05-27) CFC4042 (Canada)
      icao24: c2b3f5 · position: (43.2544, -101.1887) · alt: 11277m · 817km/h
  - (2026-05-27) JEDI1 (United States)
      icao24: a0f98c · position: (35.3278, -75.7205) · alt: 6522m · 868km/h
  - (2026-05-27) JAF55M (Belgium)
      icao24: 44d1a2 · position: (49.6273, 1.8496) · alt: 10972m · 821km/h
  - (2026-05-27) NCR897 (United States)
      on ground · 24km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 16 total
  - (2026-05-27) CVE-2026-48027 · Nx Nx Console: Nx Console Embedded Malicious Code Vulnerability
      vendor: Nx · product: Nx Console · CISA remediation by 2026-06-10
  - (2026-05-27) CVE-2026-45321 · TanStack TanStack: TanStack Unspecified Vulnerability
      vendor: TanStack · product: TanStack · CISA remediation by 2026-06-10
  - (2026-05-27) CVE-2026-8398 · Daemon Daemon Tools Lite: Daemon Tools Lite Embedded Malicious Code Vulnerability
      vendor: Daemon · product: Daemon Tools Lite · CISA remediation by 2026-05-30
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $3,769,323 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,961,871 · resolves 2026-12-31
  - (2026-05-27) US announces new Iran agreement/ceasefire extension by May 27?
      yes price: 1% · 24h volume: $1,819,686 · resolves 2026-05-27
  - (2026-05-27) Tampa Bay Rays vs. Baltimore Orioles
      yes price: 52% · 24h volume: $1,648,712 · resolves 2026-06-03
  - (2026-05-27) Philadelphia Phillies vs. San Diego Padres
      yes price: 99% · 24h volume: $1,492,769 · resolves 2026-06-03
  - (2026-05-27) Hurricanes vs. Canadiens
      yes price: 58% · 24h volume: $1,330,951 · resolves 2026-05-28
  - (2026-05-27) Will Crystal Palace FC win on 2026-05-27?
      yes price: 100% · 24h volume: $1,264,936 · resolves 2026-05-27
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,245,596 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-05-27) [Marginal Revolution] Wednesday assorted links
      1. As meat prices rise, the economics of Texas barbecue. 2. Economic historian Eric Jones has passed away. 3. Claims about the Pope and Claude.  If true, further evidence for my Straussian hypothesis. 4. Koyama reviews T
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-27) [Conversable Economist] Lessons for Central Banks: Interview with Kristin Forbes
      Thomas Chow poses the questions in &#8220;Kristin Forbes on &#8216;wargaming&#8217; for thenext crisis,&#8221; subtitled &#8220;The MIT professor and former BoE MPC member speaks about QE, scenario analysis and the ar of
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### U.S. Political Figures (per-figure anomaly tracking) — 613 new of 613 total
  - (2026-05-27) Senator: Angela D Alsobrooks (anomaly 0.00)
      Angela D Alsobrooks (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ
  - (2026-05-27) Senator: Alan Armstrong (anomaly 0.00)
      Alan Armstrong (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ ment
  - (2026-05-27) Senator: Tammy Baldwin (anomaly 0.00)
      Tammy Baldwin (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Jim Banks (anomaly 0.10)
      Jim Banks (Senator). Composite anomaly score 0.100. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.50. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ mentions:
  - (2026-05-27) Senator: John Barrasso (anomaly 0.00)
      John Barrasso (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Michael F Bennet (anomaly 0.00)
      Michael F Bennet (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Marsha Blackburn (anomaly 0.20)
      Marsha Blackburn (Senator). Composite anomaly score 0.200. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 1.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Richard Blumenthal (anomaly 0.00)
      Richard Blumenthal (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ 

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=724, 7d-median=724, 14d-median=724
- local_news: today=253, 7d-median=253, 14d-median=253
- foreign_news: today=886, 7d-median=886, 14d-median=886
- chinese_internal: today=290, 7d-median=290, 14d-median=290
- russian_internal: today=990, 7d-median=990, 14d-median=990
- ukrainian_internal: today=138, 7d-median=138, 14d-median=138
- ukraine_theater: today=394, 7d-median=394, 14d-median=394
- paper_bets: today=135, 7d-median=135, 14d-median=135
- weather: today=147, 7d-median=147, 14d-median=147
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=23, 7d-median=23, 14d-median=23
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*