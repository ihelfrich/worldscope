# WORLDSCOPE morning brief — 2026-05-27

## Headline
3597 new items across 35 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 583 new of 583 total
  - (2026-05-27) [California] CA colleges try to improve online classes
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-11-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] Newsom’s unbalanced budget faces strong pushback for spending cuts. Will lawmakers back him?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/051426_Newsom-Budget_MG_CM_06.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-
  - (2026-05-27) [California] A small fix could make a big difference in Tijuana River pollution: When will it happen?
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/112125_Paloma-Aguirre_AH_CM-05.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp
  - (2026-05-27) [California] ‘I felt like I wasn’t learning’: Community college students struggle with online education
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-Online-Education-LV-16-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-27) [California] The form asked my permission to share my health data. Then it wouldn’t let me say no.
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/052226-OPT-OUT-MAZES-GH-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos
  - (2026-05-27) [California] Our house burned down but our mortgage didn’t. California fire survivors need time
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2025/02/011425-Palisades-Aftermath-TS-08.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-size 
  - (2026-05-26) [California] No shame: A last-minute election guide for undecided CA voters
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/042826_Pomona-Gov-Debate_JAH_CM_01.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-siz
  - (2026-05-26) [California] California judges are testing a new AI clerk, and you won’t know if it’s looking at your case
      <figure><img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/05/050826-LA-Courthouse-ES-Getty-01-CM.jpg?fit=1024%2C682&amp;ssl=1" class="attachment-rss-image-size size-rss-image-si

### Local News: St. Louis + Atlanta — 133 new of 133 total
  - (2026-05-27) [St. Louis] First responders injured during Idaho brush fire that forced residents to evacuate
      Officials say several first responders were injured by the fire, and residents may have been hurt as well.
  - (2026-05-27) [St. Louis] Chemical tank implosion at Washington paper mill kills 1. Here's the latest on the search for 9 others.
      One worker was killed and nine others were unaccounted for with no hope for rescue, authorities said. Nine others were injured.
  - (2026-05-27) [St. Louis] Downtown St. Louis tower scheduled to be auctioned
      An online auction of the 30-story Bank of America Plaza at 800 Market St. is scheduled to open at noon on June 22, with a $2 million starting bid.
  - (2026-05-27) [St. Louis] Five decades later, families still fighting to add 74 sailors to Vietnam Veterans Memorial Wall
      More than 50 years after the deadly USS Frank E. Evans collision, survivors and lawmakers say the sailors deserve recognition on the memorial wall.
  - (2026-05-27) [St. Louis] President Trump gathers Cabinet as he looks to seal deal to end the war with Iran
      President Donald Trump meets with his Cabinet at a precarious moment for talks aimed at ending the war with Iran.
  - (2026-05-27) [St. Louis] Israel says strikes killed Hamas military leader just days after his predecessor died
      At least five people were killed and 12 injured in Tuesday's strike on the eve of Eid al-Adha, a major Muslim holiday, according to local hospitals.
  - (2026-05-27) [St. Louis] 'I have so much love for this city' | Travis Kelce buys minority stake in Cleveland Guardians
      Curtis Danburg, vice president of communications and community impact for the Guardians, told Ohio TV station 3News early Wednesday morning.
  - (2026-05-27) [St. Louis] Matthew Perry assistant who injected him with ketamine faces final sentencing in overdose case
      Matthew Perry’s longtime assistant faces sentencing Wednesday for supplying and injecting the ketamine that caused the “Friends” star’s death.

### International News + Multilateral Institutions — 888 new of 888 total
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-27) [feed error] AP Top News (RSSHub): HTTPError
      403 Client Error: Forbidden for url: https://rsshub.app/ap/topics/apf-topnews
  - (2026-05-27) [Global] Ebola-hit DR Congo faces 'catastrophic collision' of disease and conflict, WHO warns
      Tedros Adhanom Ghebreyesus said fighting in DR Congo was hampering efforts to stop spread
  - (2026-05-27) [Global] Israeli strike in Gaza City kills new head of Hamas's military wing
      Hamas says Mohammed Odeh was killed alongside his wife and two children in a strike on a residential building.
  - (2026-05-27) [Global] Five people found alive after week trapped in flooded Laos cave
      The search is continuing for a further two villagers who are still missing, rescuers say.
  - (2026-05-27) [Global] Dozens killed in Lebanon as Israel intensifies strikes
      Israel says it struck 100 Hezbollah infrastructure sites and fighters in Lebanon, after PM Benjamin Netanyahu vows to "crush" the Iran-backed group.

### Chinese Internal News — 4 new of 4 total
  - (2026-05-27) [feed error] Caixin Global: HTTPError
      404 Client Error: Not Found for url: https://www.caixinglobal.com/rss/news.xml
  - (2026-05-27) [feed error] Sixth Tone: HTTPError
      404 Client Error: Not Found for url: https://www.sixthtone.com/feed
  - (2026-05-27) [feed error] Caijing 财经: HTTPError
      404 Client Error: Not Found for url: https://www.caijing.com.cn/rss/topnews.xml
  - (2026-05-27) [feed error] People's Daily 人民日报: ConnectTimeout
      HTTPConnectionPool(host='rss.people.com.cn', port=80): Max retries exceeded with url: /rss/politics.xml (Caused by ConnectTimeoutError(<HTTPConnection(host='rss.people.com.cn', port=80) at 0x7f5e404aca50>, 'Connection to

### Russian Internal News (state + in-exile) — 1030 new of 1030 total
  - (2026-05-27) [TITLE: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. Там она воспроизводит тезисы российской пропаганды | LEDE: <p>Бывший главный редактор RT France Ксения Федорова у] (ru: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. )
      <p>Бывший главный редактор RT France Ксения Федорова устроилась на работу на французском правоконсервативном телеканале CNews, рассказывается в публикациях Politico и русской службы RFI. <p>
  - (2026-05-27) [TITLE: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за пределы Украины и объявит новую мобилизацию | LEDE: <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает] (ru: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за п)
      <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. К
  - (2026-05-27) [TITLE: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли более 20 студентов колледжа. Вот что о них и об этой атаке рассказывают однокурсники и друзья | LEDE: <p>В ночь на ] (ru: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли бо)
      <p>В ночь на 22 мая украинские войска нанесли удар беспилотниками по Старобельску в аннексированной ЛНР. Под обстрел попали педагогический колледж и профессиональный колледж Луганского педагогического университета. По оф
  - (2026-05-27) [TITLE: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской области объяснили, зачем запретили иностранные надписи на школьной одежде | LEDE: <p>Департамент образования Томской] (ru: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской обл)
      <p>Департамент образования Томской области заявил, что запрет носить одежду с иностранными надписями, принятый в нескольких школах региона, призван уберечь детей от «чуждых и опасных» смыслов.<p>
  - (2026-05-27) [TITLE: Парламент Венгрии остановил выход страны из Международного уголовного суда, начатый предыдущим премьером Виктором Орбаном | LEDE: <p>Парламент Венгрии одобрил отзыв решения о выходе страны из М] (ru: Парламент Венгрии остановил выход страны из Международного уголовного суда, нача)
      <p>Парламент Венгрии одобрил отзыв решения о выходе страны из Международного уголовного суда (МУС).<p>
  - (2026-05-27) [TITLE: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей или до пяти лет лишения свободы | LEDE: <p>Госдума приняла в первом чтении законопроект о наказании за незаконный] (ru: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей )
      <p>Госдума приняла в первом чтении законопроект о наказании за незаконный майнинг. Документ вводит в Уголовный кодекс новую статью 171.6.<p>
  - (2026-05-27) [TITLE: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Германии | LEDE: <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит дейст] (ru: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Ге)
      <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит действующий канцлер Германии Фридрих Мерц, обсуждаются варианты его замены, пишут таблоиды Stern и Bild.<p>
  - (2026-05-27) [TITLE: The Economist: власти Украины готовятся еще к двум-трем годам войны. Советник Зеленского: это — «старый вброс» | LEDE: <p>Президент Украины Владимир Зеленский «приказал готовиться к еще двум-тр] (ru: The Economist: власти Украины готовятся еще к двум-трем годам войны. Советник Зе)
      <p>Президент Украины Владимир Зеленский «приказал готовиться к еще двум-трем годам войны», пишет The Economist со ссылкой на правительственные источники.<p>

### Ukrainian Internal News (national + local Kyiv) — 133 new of 133 total
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-27) [feed error] Kyiv Independent: HTTPError
      404 Client Error: Not Found for url: https://kyivindependent.com/rss/
  - (2026-05-27) [TITLE: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув пес | LEDE: Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них гос] (uk: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув п)
      Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них госпіталізовано.
  - (2026-05-27) [TITLE: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали на боці РФ | LEDE: Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зус] (uk: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали н)
      Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зустріч із лідеркою білоруської опозиції Світланою Тихановською та її командою. Вони мали змогу поспілкуватися з військовополоне
  - (2026-05-27) [TITLE: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз РФ | LEDE: Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для зах] (uk: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз )
      Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для захисту від російських ракет.
  - (2026-05-27) [TITLE: Елітний підрозділ ССО отримав найменування на честь Героїв УПА | LEDE: Президент Володимир Зеленський присвоїв почесне найменування "імені Героїв УПА" Окремому центру спеціальних операцій "Півн] (uk: Елітний підрозділ ССО отримав найменування на честь Героїв УПА)
      Президент Володимир Зеленський присвоїв почесне найменування "імені Героїв УПА" Окремому центру спеціальних операцій "Північ" Сил спеціальних операцій ЗСУ.
  - (2026-05-27) [TITLE: 200 тисяч за "мовчання": командира та старшину підозрюють у вимаганні грошей з військового | LEDE: Командиру роти та старшині однієї з бригад Дніпропетровщини оголосили підозру у вимаганні грош] (uk: 200 тисяч за "мовчання": командира та старшину підозрюють у вимаганні грошей з в)
      Командиру роти та старшині однієї з бригад Дніпропетровщини оголосили підозру у вимаганні грошей з військового.
  - (2026-05-27) [TITLE: У ЗСУ спростовують заяву росіян про окупацію села на Харківщині біля кордону з РФ | LEDE: Село Гранів Харківської області перебуває під контролем ЗСУ — заявили у Збройних силах, спростувавши фе] (uk: У ЗСУ спростовують заяву росіян про окупацію села на Харківщині біля кордону з Р)
      Село Гранів Харківської області перебуває під контролем ЗСУ — заявили у Збройних силах, спростувавши фейки армії РФ.

### Paper Trading Scorecard — 137 new of 137 total
  - (2026-05-27) [Polymarket] Will OpenAI have the best AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is checked
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Monte win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Aurora win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso

### U.S. Weather + Severe / Climate Outlooks — 121 new of 121 total
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 9:31AM CDT until May 27 at 10:00AM CDT by NWS Brownsville TX
      SVRBRO

The National Weather Service in Brownsville has issued a

* Severe Thunderstorm Warning for...
East central Cameron County in Deep South Texas...

* Until 1000 AM CDT.

* At 930 AM CDT, a severe thunderstorm was 
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 9:31AM CDT until May 31 at 7:00PM CDT by NWS Lake Charles LA
      ...The National Weather Service in Lake Charles LA has issued a
Flood Warning for the following rivers in Louisiana...

Calcasieu River near White Oak Park

Additional information is available at www.weather.gov.

* WHAT
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Severe] Flash Flood Warning: Flash Flood Warning issued May 27 at 9:24AM CDT until May 27 at 12:30PM CDT by NWS Fort Worth TX
      FFWFWD

The National Weather Service in Fort Worth has issued a

* Flash Flood Warning for...
Eastern Dallas County in north central Texas...
Western Kaufman County in north central Texas...
Rockwall County in north cent
  - (2026-05-27) [Severe] Flash Flood Warning: Flash Flood Warning issued May 27 at 10:21AM EDT until May 27 at 11:45AM EDT by NWS Pittsburgh PA
      At 1021 AM EDT, Doppler radar indicated thunderstorms producing heavy
rain across the warned area. Between 1 and 2 inches of rain have
fallen. Additional rainfall amounts up to 0.75 inches are possible in
the warned area
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 9:20AM CDT until May 27 at 10:30AM CDT by NWS Corpus Christi TX
      * WHAT...Urban areas and small streams flooding caused by excessive
rainfall continues.

* WHERE...Aransas County in south central Texas...
Southeastern Bee County in south central Texas...
Northeastern Jim Wells County 
  - (2026-05-27) [Severe] Flood Watch: Flood Watch issued May 27 at 10:18AM EDT until May 27 at 10:00PM EDT by NWS Pittsburgh PA
      * WHAT...Flooding caused by excessive rainfall continues to be
possible.

* WHERE...Portions of east central Ohio, including the following
areas, Belmont, Guernsey, Monroe, Muskingum and Noble, southwest
Pennsylvania, in
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 9:13AM CDT by NWS Brownsville TX
      At 913 AM CDT, Doppler radar was tracking a cluster of strong
thunderstorms over Cameron County moving east at 65 mph.

HAZARD...Wind gusts up to 50 mph.

SOURCE...Radar indicated.

IMPACT...Gusty winds could knock down 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 29 new of 29 total
  - (2026-05-27) [crypto] BTC: $74,826.0000  (24h: -3.47%)
      price=$74826  mcap=$1,499,937,886,523  vol24=$39,999,666,541  chg24=-3.4675607271575384%
  - (2026-05-27) [crypto] ETH: $2,056.4400  (24h: -3.46%)
      price=$2056.44  mcap=$248,204,952,779  vol24=$15,058,698,905  chg24=-3.4615994274047135%
  - (2026-05-27) [crypto] USDT: $0.9984  (24h: -0.05%)
      price=$0.998406  mcap=$189,279,129,044  vol24=$66,382,471,556  chg24=-0.0480207541618827%
  - (2026-05-27) [crypto] USDC: $0.9997  (24h: -0.01%)
      price=$0.999739  mcap=$76,373,266,934  vol24=$18,505,299,887  chg24=-0.013585970327771908%
  - (2026-05-27) [crypto] BNB: $651.7100  (24h: -2.14%)
      price=$651.71  mcap=$87,841,156,271  vol24=$940,284,021  chg24=-2.1351238987933825%
  - (2026-05-27) [crypto] SOL: $83.4600  (24h: -2.87%)
      price=$83.46  mcap=$48,144,398,152  vol24=$2,553,741,539  chg24=-2.8658266113629693%
  - (2026-05-27) [crypto] XRP: $1.3200  (24h: -2.97%)
      price=$1.32  mcap=$81,741,315,602  vol24=$1,644,201,773  chg24=-2.974344555381293%
  - (2026-05-27) [crypto] DOGE: $0.1010  (24h: -2.27%)
      price=$0.100972  mcap=$15,593,879,792  vol24=$729,373,313  chg24=-2.266348589416066%

### Government Action: Sanctions + Procurement + Foreign Agents — 33 new of 33 total
  - (2026-05-27) [ofac_recent error] HTTPError
      404 Client Error: Not Found for url: https://ofac.treasury.gov/recent-actions/feed
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [dcsca error] HTTPError
      403 Client Error: Forbidden for url: https://www.dsca.mil/press-media/major-arms-sales
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR
  - (2026-05-27) [USASpending] $10,494,204,426 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration.  Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-05-27) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 3 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 424B2 - TORONTO DOMINION BANK (0000947263) (Filer)
      filed 2026-05-27 14:32 UTC — Filed: 2026-05-27 AccNo: 0001140361-26-022941 Size: 450 KB
  - (2026-05-27) 424B2 - TORONTO DOMINION BANK (0000947263) (Filer)
      filed 2026-05-27 14:31 UTC — Filed: 2026-05-27 AccNo: 0001140361-26-022940 Size: 2 MB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 14:28 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014112 Size: 700 KB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 14:28 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014112 Size: 700 KB
  - (2026-05-27) 497 - WILLIAMSBURG INVESTMENT TRUST (0000842512) (Filer)
      filed 2026-05-27 14:28 UTC — Filed: 2026-05-27 AccNo: 0001580642-26-003298 Size: 34 KB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 14:27 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014111 Size: 559 KB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 14:27 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014111 Size: 559 KB
  - (2026-05-27) 424B2 - Nomura America Finance, LLC (0001383951) (Filer)
      filed 2026-05-27 14:27 UTC — Filed: 2026-05-27 AccNo: 0001104659-26-066681 Size: 896 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [United States] Bicyclist Seriously Injured in Motor Vehicle Crash
      domain: longisland.com · language: English · tone: 
  - (2026-05-27) [Canada] Ontario auto theft investigation leads to arrest of 9 : Niagara police
      domain: cp24.com · language: English · tone: 
  - (2026-05-27) [United States] The Latest : Trump will meet with his Cabinet as talks to end war in Iran remain in flux
      domain: harrisondaily.com · language: English · tone: 
  - (2026-05-27) [United States] Trump convenes Cabinet while seeking breakthrough in ending Iran war
      domain: abc6onyourside.com · language: English · tone: 
  - (2026-05-27) [United States] Avery Detten , Texas A & M student car crash victim organ donor to save 65 people
      domain: scallywagandvagabond.com · language: English · tone: 
  - (2026-05-27) [United States] MarineSolar Advances Clean Energy Trial at Sea
      domain: azocleantech.com · language: English · tone: 
  - (2026-05-27) [United States] Blue Cross Blue Shield , Michigan Medicine reach tentative contract agreement
      domain: clickondetroit.com · language: English · tone: 
  - (2026-05-27) [United States] Milestones Soroptimists , OMC , Footprinters May 27 , 2026
      domain: sequimgazette.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-05-27) JAF8LY (Bulgaria)
      icao24: 4520ce · position: (35.2202, -6.485) · alt: 7299m · 808km/h
  - (2026-05-27) PAT914 (United States)
      icao24: adfeda · position: (42.7669, -73.8055) · alt: 160m · 196km/h
  - (2026-05-27) PAT828 (United States)
      icao24: adfe4a · position: (33.4728, -87.0815) · alt: 8229m · 536km/h
  - (2026-05-27) NCR327 (United States)
      icao24: ab4ec6 · position: (33.7181, -91.6004) · alt: 11582m · 814km/h
  - (2026-05-27) CFC2931 (Canada)
      icao24: c2b585 · position: (47.841, 15.8469) · alt: 10355m · 609km/h
  - (2026-05-27) FNY5566 (France)
      on ground
  - (2026-05-27) JAF7TJ (Belgium)
      icao24: 44d1ba · position: (36.9435, 26.8487) · alt: 8542m · 761km/h
  - (2026-05-27) JAF35D (Belgium)
      icao24: 44d1a5 · position: (34.8626, -8.4026) · alt: 11277m · 835km/h

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,068,674 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,958,955 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,804,812 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 100% · 24h volume: $1,725,226 · resolves 2026-05-27
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,683,456 · resolves 2026-07-20
  - (2026-05-27) Will Barack Obama win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $1,146,086 · resolves 2028-11-07
  - (2026-05-27) Dota 2: OG vs Tundra Esports (BO1) - BLAST Slam Group Stage
      yes price: 100% · 24h volume: $936,269 · resolves 2026-05-27
  - (2026-05-27) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $925,591 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-26) [Marginal Revolution] *How to Win a Trade War: An Optimistic Guide to an Anxious Global Economy*
      That is the new Soumaya Keynes book, out today.  I was happy to have blurbed this book, and here is an essay, on export restrictions, based on the book.
The post *How to Win a Trade War: An Optimistic Guide to an Anxious
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=583, 7d-median=583, 14d-median=583
- local_news: today=133, 7d-median=133, 14d-median=133
- foreign_news: today=888, 7d-median=888, 14d-median=888
- chinese_internal: today=4, 7d-median=4, 14d-median=4
- russian_internal: today=1030, 7d-median=1030, 14d-median=1030
- ukrainian_internal: today=133, 7d-median=133, 14d-median=133
- paper_bets: today=137, 7d-median=137, 14d-median=137
- weather: today=121, 7d-median=121, 14d-median=121
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=29, 7d-median=29, 14d-median=29
- sanctions_procurement: today=33, 7d-median=33, 14d-median=33
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*