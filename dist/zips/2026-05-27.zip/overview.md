# WORLDSCOPE morning brief — 2026-05-27

## Headline
4177 new items across 35 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 590 new of 590 total
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-27) [Alaska] Solar power expected to soon be cheaper than natural gas power in Anchorage
      Alaska’s largest planned solar farm, expected to break ground west of Anchorage this summer, is likely to deliver cheaper electricity than possible with imported natural gas, according to information the state’s largest 
  - (2026-05-26) [Alaska] Governor failed Alaska gasline legislation homework
      Legislators are being held after school this month and the state is paying for the extra time because the governor did not do his homework. If that seems backward, you’re right. Gov. Mike Dunleavy ordered lawmakers to st
  - (2026-05-26) [Alaska] Trump administration will make green card hopefuls return to home countries before applying
      Immigrants seeking green cards will have to return first to their home countries and wait despite years of potential backlogs, the Trump administration announced Friday.  “An alien who is in the U.S. temporarily and want
  - (2026-05-26) [Alaska] Land named for colorful character ‘Herring Pete’ added to Alaska’s Kachemak Bay State Park
      A century ago, a Norwegian-born mariner nicknamed “Herring Pete” and his Austrian-born wife operated a fox farm on a scenic, remote and mountainous Kenai Peninsula island. Now that 24-acre island parcel is part of 400,00
  - (2026-05-26) [Alaska] North Slope Borough employee crashes fuel truck while allegedly drunk
      State prosecutors in Utqiagvik have charged a North Slope Borough employee with allegedly crashing a fuel truck while drunk. According to court documents filed May 13 in Utqiagvik, James Brown was driving on April 9 in P
  - (2026-05-25) [Alaska] Alaska’s burnout problem is bigger than stress
      Alaskans pride themselves on resilience. We work long hours, adapt to difficult conditions, raise families through dark winters and carry a culture that values toughness and independence. But resilience without recovery 
  - (2026-05-27) [feed error] AZ Governor (Arizona): HTTPError
      404 Client Error: Not Found for url: https://azgovernor.gov/feed

### Local News: St. Louis + Atlanta — 255 new of 255 total
  - (2026-05-27) [St. Louis] Trump declares himself in perfect health after physical exam
      Recent photographs showing a blotchy neck rash have added to questions about Trump's health, following images in July 2025 of swollen ankles and a bruised hand concealed with makeup.
  - (2026-05-27) [St. Louis] St. Louis City SC continues to open roster space, lets Cordova go back to Switzerland
      St. Louis City SC is letting Sergio Cordova go back to Switzerland, opening another spot at the forward position for the team
  - (2026-05-27) [St. Louis] The end is where we begin: A year of milestones at Confluence Academies
      Content by Confluence Academies. As the school year draws to a close, it is worth celebrating what scholars have accomplished — in classrooms, on stages, on the track and beyond.
  - (2026-05-27) [St. Louis] Asters
      New England aster, Symphyotrichum novae-angliae 'Purple Pixie'
  - (2026-05-27) [St. Louis] May 27
      Prop patrol
  - (2026-05-27) [St. Louis] sunburned leaves
      Cast iron plant with sunburned leaves
  - (2026-05-27) [St. Louis] OPED-HEALTH-SLEEP-APNEA-COMMENTARY-FILEPIC-DMT
      Poor sleep can wreak havoc on health and longevity over time.
  - (2026-05-27) [St. Louis] Las Vegas shows why rent control isn’t needed | Las Vegas Review-Journal
      Building more apartments, not government intervention, has lowered cost of housing

### International News + Multilateral Institutions — 869 new of 869 total
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-26) [Global] Cover Story newsletter: A Starship enterprise
      How we chose this week’s images
  - (2026-05-25) [Global] Spread of Ebola in DRC ‘outpacing’ response efforts, warns WHO
  - (2026-05-25) [Global] ‘She does not back down’: the couple seeking to legalise same-sex marriage in Botswana
  - (2026-05-26) [Global] President Sheinbaum allows Iran team to stay in Mexico during World Cup after US refusal
  - (2026-05-25) [Global] Venezuela inmates occupy prison roof and set fire to mattresses to highlight alleged abuse

### Chinese Internal News — 283 new of 283 total
  - (2026-05-25) Analysis: Dollar’s Pain Is Yuan’s Gain - Caixin Global
      <a href="https://news.google.com/rss/articles/CBMilAFBVV95cUxPV3dBYVFiQWQ2ZWZlVEkxXzRVZ0ZTWjZLcVNPYmpsZTNhX0V5ZXdXUXB5dUVlTUZMcEszWFJKbW52cnplb3lHR3JKVmlzWjdfZ0E4Y1ZYbFZFSXlVRUFUa1lNVTVNY2pyMWVTSlZhNUFrMFlkem1jekxPZ0tzNF
  - (2026-05-27) [TITLE: “印尼如此配合美国，中国肯定不满”-观察者网 - 观察 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBfT1hwRVVjVlZIV1ZiUVhfa09FbmFTaVZsNmF2Yk91ZEM4M1hvVDJHcUZySHlRbUdFcXRVeXp5ekstTjUzMURyd3N1MUc1R2V] (zh: “印尼如此配合美国，中国肯定不满”-观察者网 - 观察)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBfT1hwRVVjVlZIV1ZiUVhfa09FbmFTaVZsNmF2Yk91ZEM4M1hvVDJHcUZySHlRbUdFcXRVeXp5ekstTjUzMURyd3N1MUc1R2VkMlgzMXNtZm9tNUp2TUltcU96djAzZmxRTUE?oc=5" target="_blank">“印尼如
  - (2026-05-27) [TITLE: 当英国无赖抢救最后一座高炉：不要紧张，时代真的变了-观察者网 - 观察 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1EQjJid3RqcXF3emlMVEYwMDJPLVNnQUJhaVVMSURYcUxiVDBuS3VxbUdVMnZEdlp5cVNIR3oxR21yNjhLT3FHdGd] (zh: 当英国无赖抢救最后一座高炉：不要紧张，时代真的变了-观察者网 - 观察)
      <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1EQjJid3RqcXF3emlMVEYwMDJPLVNnQUJhaVVMSURYcUxiVDBuS3VxbUdVMnZEdlp5cVNIR3oxR21yNjhLT3FHdGd1SXNvdEY3NHQzTV80ZkRhRTlCUWhSeC1fYzc?oc=5" target="_blank">当英国无赖抢救最后一座高
  - (2026-05-27) [TITLE: 扎哈罗娃怒斥日本记者：你们大错特错，把这句话带给你们的政府-观察者网 - 观察 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1PbEJuZG5pMnZhMDZOemVjQWhtSG9QaUVvMUs1UUs4akdNbVNoM3BueFhhU1RJc21SN08tcmhjVld0TURzNnh] (zh: 扎哈罗娃怒斥日本记者：你们大错特错，把这句话带给你们的政府-观察者网 - 观察)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1PbEJuZG5pMnZhMDZOemVjQWhtSG9QaUVvMUs1UUs4akdNbVNoM3BueFhhU1RJc21SN08tcmhjVld0TURzNnhudEtCSERkeXpBYVpHVVBjVWFHc0ZneXlTTHZ3SkRqSHNHSmc?oc=5" target="_blank">扎哈罗娃
  - (2026-05-26) [TITLE: 央视曝光：境外间谍入侵联网设备偷录窃听，预先掌握谈判底线 - 观察 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1FUG5mdDN6WGVobmdxdEd5ZWcyU214V094YlQ2VlhPSTNkeFIyMmxuRV9hUi1wdkVlMTEzU1BReUg0aWNGTGdtM05wM] (zh: 央视曝光：境外间谍入侵联网设备偷录窃听，预先掌握谈判底线 - 观察)
      <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE1FUG5mdDN6WGVobmdxdEd5ZWcyU214V094YlQ2VlhPSTNkeFIyMmxuRV9hUi1wdkVlMTEzU1BReUg0aWNGTGdtM05wMlB5dDFRYWdvWS1xLXdjTEV3WVlkZl9WN19WQQ?oc=5" target="_blank">央视曝光：境外间谍
  - (2026-05-27) [TITLE: 礼赞社科大师｜彭康：在国家利益前提下，考虑学校、个人利益 - 观察 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5keHdTU1BqS0hZRzdTQ2FkeUF5QWFScHdwQ0dCLXJoenRqeF9YTDNMQ3lRSzZtWnM5OUMxLTFORUhjYmItTVljX0I5a] (zh: 礼赞社科大师｜彭康：在国家利益前提下，考虑学校、个人利益 - 观察)
      <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTE5keHdTU1BqS0hZRzdTQ2FkeUF5QWFScHdwQ0dCLXJoenRqeF9YTDNMQ3lRSzZtWnM5OUMxLTFORUhjYmItTVljX0I5aXc4VzNBZDhEYl9TQmE5dDYwZXVwdHRQQ09LZw?oc=5" target="_blank">礼赞社科大师｜彭康
  - (2026-05-27) [TITLE: 网友在高铁偶遇易中天，看来是他的毛驴去休假了 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE84RENubS1pVGVWTGpiWHpFMzJDOUR2bU11ZXZGdVprQllBTXBkYnBlRXhTclBEZmZpY0I2UWJRUnhzajl1OE0xbGZLNVRXYVl] (zh: 网友在高铁偶遇易中天，看来是他的毛驴去休假了 - 风闻)
      <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE84RENubS1pVGVWTGpiWHpFMzJDOUR2bU11ZXZGdVprQllBTXBkYnBlRXhTclBEZmZpY0I2UWJRUnhzajl1OE0xbGZLNVRXYVlkT29fTFpmRUhMR2M?oc=5" target="_blank">网友在高铁偶遇易中天，看来是他的毛驴去休假了</
  - (2026-05-27) [TITLE: 父母都哭了，我反问自己，我配得上吗？ - 观察 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5lbVdfaGh2OTlLRHFuSlhiR3VaMGNEUi1jQml6MVI5cW5Ha0puUmR6VGZ3Qm9fUDlOM2FZX2M4M1R2d2tMMl81YWg2akRtUWZ5Nlp] (zh: 父母都哭了，我反问自己，我配得上吗？ - 观察)
      <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5lbVdfaGh2OTlLRHFuSlhiR3VaMGNEUi1jQml6MVI5cW5Ha0puUmR6VGZ3Qm9fUDlOM2FZX2M4M1R2d2tMMl81YWg2akRtUWZ5NlpUcnpJQ1JGc2Y2R1ZkUFloUjlPUnB6dXc?oc=5" target="_blank">父母都哭

### Russian Internal News (state + in-exile) — 1132 new of 1132 total
  - (2026-05-27) [TITLE: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. Там она воспроизводит тезисы российской пропаганды | LEDE: <p>Бывший главный редактор RT France Ксения Федорова у] (ru: Бывший главред RT France Ксения Федорова устроилась на французское телевидение. )
      <p>Бывший главный редактор RT France Ксения Федорова устроилась на работу на французском правоконсервативном телеканале CNews, рассказывается в публикациях Politico и русской службы RFI. <p>
  - (2026-05-27) [TITLE: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за пределы Украины и объявит новую мобилизацию | LEDE: <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает] (ru: Война. 1554-й день. В Европе опасаются, что Путин перенесет боевые действия за п)
      <p>«Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. К
  - (2026-05-27) [TITLE: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли более 20 студентов колледжа. Вот что о них и об этой атаке рассказывают однокурсники и друзья | LEDE: <p>В ночь на ] (ru: «Я подняла голову: над нами летел беспилотник». В аннексированной ЛНР погибли бо)
      <p>В ночь на 22 мая украинские войска нанесли удар беспилотниками по Старобельску в аннексированной ЛНР. Под обстрел попали педагогический колледж и профессиональный колледж Луганского педагогического университета. По оф
  - (2026-05-27) [TITLE: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской области объяснили, зачем запретили иностранные надписи на школьной одежде | LEDE: <p>Департамент образования Томской] (ru: «Под видом моды ребенку могут транслироваться чуждые смыслы». Власти Томской обл)
      <p>Департамент образования Томской области заявил, что запрет носить одежду с иностранными надписями, принятый в нескольких школах региона, призван уберечь детей от «чуждых и опасных» смыслов.<p>
  - (2026-05-27) [TITLE: Парламент Венгрии остановил выход страны из Международного уголовного суда, начатый предыдущим премьером Виктором Орбаном | LEDE: <p>Парламент Венгрии одобрил отзыв решения о выходе страны из М] (ru: Парламент Венгрии остановил выход страны из Международного уголовного суда, нача)
      <p>Парламент Венгрии одобрил отзыв решения о выходе страны из Международного уголовного суда (МУС).<p>
  - (2026-05-27) [TITLE: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей или до пяти лет лишения свободы | LEDE: <p>Госдума приняла в первом чтении законопроект о наказании за незаконный] (ru: Госдума одобрила наказание за незаконный майнинг — штраф до 2,5 миллиона рублей )
      <p>Госдума приняла в первом чтении законопроект о наказании за незаконный майнинг. Документ вводит в Уголовный кодекс новую статью 171.6.<p>
  - (2026-05-27) [TITLE: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Германии | LEDE: <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит дейст] (ru: Bild: в руководстве партии Мерца обсуждают, как сместить его с поста канцлера Ге)
      <p>В руководящих кругах партии Христианско-демократический союз (ХДС), к которой принадлежит действующий канцлер Германии Фридрих Мерц, обсуждаются варианты его замены, пишут таблоиды Stern и Bild.<p>
  - (2026-05-27) [TITLE: The Economist: власти Украины готовятся еще к двум-трем годам войны. Советник Зеленского: это — «старый вброс» | LEDE: <p>Президент Украины Владимир Зеленский «приказал готовиться к еще двум-тр] (ru: The Economist: власти Украины готовятся еще к двум-трем годам войны. Советник Зе)
      <p>Президент Украины Владимир Зеленский «приказал готовиться к еще двум-трем годам войны», пишет The Economist со ссылкой на правительственные источники.<p>

### Ukrainian Internal News (national + local Kyiv) — 134 new of 134 total
  - (2026-05-27) [feed error] President of Ukraine: HTTPError
      403 Client Error: Forbidden for url: https://www.president.gov.ua/en/news/rss/2027
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-27) [TITLE: Шлях із перешкодами: рух України до членства ускладнюють і в ЄС, і в Києві | LEDE: ] (uk: Шлях із перешкодами: рух України до членства ускладнюють і в ЄС, і в Києві)
  - (2026-05-27) [TITLE: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув пес | LEDE: Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них гос] (uk: Зросла кількість потерпілих від удару РФ по Одещині: постраждали діти, загинув п)
      Внаслідок ворожої атаки по Одеському району кількість потерпілих збільшилася до 11, восьмеро з них госпіталізовано.
  - (2026-05-27) [TITLE: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали на боці РФ | LEDE: Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зус] (uk: Коордштаб влаштував Тихановській зустріч із полоненими білорусами, які воювали н)
      Секретар Координаційного штабу з питань поводження з військовополоненими Дмитро Усов провів зустріч із лідеркою білоруської опозиції Світланою Тихановською та її командою. Вони мали змогу поспілкуватися з військовополоне
  - (2026-05-27) [TITLE: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз РФ | LEDE: Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для зах] (uk: Зеленський надіслав листа Трампу щодо критичної нестачі ППО на тлі нових погроз )
      Президент Зеленський звернувся до Трампа та Конгресу через нестачу ППО і просить Patriot PAC-3 для захисту від російських ракет.
  - (2026-05-27) [TITLE: Елітний підрозділ ССО отримав найменування на честь Героїв УПА | LEDE: Президент Володимир Зеленський присвоїв почесне найменування "імені Героїв УПА" Окремому центру спеціальних операцій "Півн] (uk: Елітний підрозділ ССО отримав найменування на честь Героїв УПА)
      Президент Володимир Зеленський присвоїв почесне найменування "імені Героїв УПА" Окремому центру спеціальних операцій "Північ" Сил спеціальних операцій ЗСУ.
  - (2026-05-27) [TITLE: 200 тисяч за "мовчання": командира та старшину підозрюють у вимаганні грошей з військового | LEDE: Командиру роти та старшині однієї з бригад Дніпропетровщини оголосили підозру у вимаганні грош] (uk: 200 тисяч за "мовчання": командира та старшину підозрюють у вимаганні грошей з в)
      Командиру роти та старшині однієї з бригад Дніпропетровщини оголосили підозру у вимаганні грошей з військового.

### Paper Trading Scorecard — 137 new of 137 total
  - (2026-05-27) [Polymarket] Will OpenAI have the best AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is checked
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Monte win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Aurora win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso

### U.S. Weather + Severe / Climate Outlooks — 122 new of 122 total
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 9:42AM CDT until May 27 at 10:00AM CDT by NWS Brownsville TX
      At 941 AM CDT, a severe thunderstorm was located over Holly Beach,
or 8 miles west of South Padre Island, moving east at 20 mph. Port
Isabel airport reported a wind gust of 61 mph at 932 AM CDT.

HAZARD...70 mph wind gus
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 10:41AM EDT until May 28 at 8:00AM EDT by NWS Wilmington OH
      ...The National Weather Service in Wilmington has issued a Flood
Warning for the following rivers...

South Fork Licking River Near I 70 near Buckeye Lake.

* WHAT...Minor flooding is forecast.

* WHERE...South Fork Lick
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 9:40AM CDT until May 27 at 10:15AM CDT by NWS Brownsville TX
      SVRBRO

The National Weather Service in Brownsville has issued a

* Severe Thunderstorm Warning for...
Southeastern Cameron County in Deep South Texas...

* Until 1015 AM CDT.

* At 940 AM CDT, a severe thunderstorm was 
  - (2026-05-27) [Severe] Special Marine Warning: Special Marine Warning issued May 27 at 9:35AM CDT until May 27 at 10:00AM CDT by NWS Brownsville TX
      SMWBRO

The National Weather Service in Brownsville has issued a

* Special Marine Warning for...
Coastal waters from Port Mansfield TX to the Rio Grande River out
20 NM...
Laguna Madre From the Port Of Brownsville to th
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 9:31AM CDT until May 31 at 7:00PM CDT by NWS Lake Charles LA
      ...The National Weather Service in Lake Charles LA has issued a
Flood Warning for the following rivers in Louisiana...

Calcasieu River near White Oak Park

Additional information is available at www.weather.gov.

* WHAT
  - (2026-05-27) [Severe] Flash Flood Warning: Flash Flood Warning issued May 27 at 9:24AM CDT until May 27 at 12:30PM CDT by NWS Fort Worth TX
      FFWFWD

The National Weather Service in Fort Worth has issued a

* Flash Flood Warning for...
Eastern Dallas County in north central Texas...
Western Kaufman County in north central Texas...
Rockwall County in north cent
  - (2026-05-27) [Severe] Flash Flood Warning: Flash Flood Warning issued May 27 at 10:21AM EDT until May 27 at 11:45AM EDT by NWS Pittsburgh PA
      At 1021 AM EDT, Doppler radar indicated thunderstorms producing heavy
rain across the warned area. Between 1 and 2 inches of rain have
fallen. Additional rainfall amounts up to 0.75 inches are possible in
the warned area

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 79 new of 79 total
  - (2026-05-27) [fx] USD/EUR: 0.859651
      1 USD = 0.859651 EUR
  - (2026-05-27) [fx] USD/GBP: 0.743251
      1 USD = 0.743251 GBP
  - (2026-05-27) [fx] USD/JPY: 159.232868
      1 USD = 159.232868 JPY
  - (2026-05-27) [fx] USD/CHF: 0.785427
      1 USD = 0.785427 CHF
  - (2026-05-27) [fx] USD/CAD: 1.380782
      1 USD = 1.380782 CAD
  - (2026-05-27) [fx] USD/AUD: 1.394958
      1 USD = 1.394958 AUD
  - (2026-05-27) [fx] USD/NZD: 1.712118
      1 USD = 1.712118 NZD
  - (2026-05-27) [fx] USD/CNY: 6.798706
      1 USD = 6.798706 CNY

### Government Action: Sanctions + Procurement + Foreign Agents — 33 new of 33 total
  - (2026-05-27) [ofac_recent error] HTTPError
      404 Client Error: Not Found for url: https://ofac.treasury.gov/recent-actions/feed
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [dcsca error] HTTPError
      403 Client Error: Forbidden for url: https://www.dsca.mil/press-media/major-arms-sales
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR
  - (2026-05-27) [USASpending] $10,494,204,426 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration.  Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF

### Congressional STOCK Act Trades (House + Senate) — 66 new of 66 total
  - (2026-05-06) [Senate] Bernardo Moreno (R): Sale (Full) ETOR ($100,001 - $250,000) (excess -0.4% vs SPY)
      Member: Bernardo Moreno (R, senate).  BioGuide: M001242.  Asset: ETOR (Stock).  Type: Sale (Full).  Amount range: $100,001 - $250,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-22.  Excess return vs SPY si
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.5% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Jake Auchincloss (D): Sale STT ($15,001 - $50,000) (excess +1.5% vs SPY)
      Member: Jake Auchincloss (D, house).  BioGuide: A000148.  Asset: STT (ST).  Type: Sale.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-04-29) [House] Thomas H. Kean Jr (R): Sale ADI ($1,001 - $15,000) (excess +2.4% vs SPY)
      Member: Thomas H. Kean Jr (R, house).  BioGuide: K000398.  Asset: ADI (ST).  Type: Sale.  Amount range: $1,001 - $15,000.  Transaction date: 2026-04-29.  Disclosure date: 2026-05-22.  Excess return vs SPY since disclosur
  - (2026-05-07) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +20.2% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-06) [House] Sara Jacobs (D): Sale QCOM ($500,001 - $1,000,000) (excess +26.9% vs SPY)
      Member: Sara Jacobs (D, house).  BioGuide: J000305.  Asset: QCOM (ST).  Type: Sale.  Amount range: $500,001 - $1,000,000.  Transaction date: 2026-05-06.  Disclosure date: 2026-05-20.  Excess return vs SPY since disclosur
  - (2026-05-18) [House] Tim Moore (R): Purchase T ($15,001 - $50,000) (excess +0.8% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: T (ST).  Type: Purchase.  Amount range: $15,001 - $50,000.  Transaction date: 2026-05-18.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure: +0
  - (2026-05-07) [House] Tim Moore (R): Purchase RYCEY ($1,001 - $15,000) (excess -2.2% vs SPY)
      Member: Tim Moore (R, house).  BioGuide: M001236.  Asset: RYCEY (ST).  Type: Purchase.  Amount range: $1,001 - $15,000.  Transaction date: 2026-05-07.  Disclosure date: 2026-05-19.  Excess return vs SPY since disclosure:

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 3 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 497K - ARBITRAGE FUNDS (0001105076) (Filer)
      filed 2026-05-27 14:45 UTC — Filed: 2026-05-27 AccNo: 0001104659-26-066685 Size: 8 KB
  - (2026-05-27) [Cascadia Holdings Ltd] Form 4 (Reporting)
      filed 2026-05-27 14:45 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001753926-26-000938 Size: 8 KB
  - (2026-05-27) [High Roller Technologies, Inc.] Form 4 (Issuer)
      filed 2026-05-27 14:45 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001753926-26-000938 Size: 8 KB
  - (2026-05-27) 424B2 - ROYAL BANK OF CANADA (0001000275) (Filer)
      filed 2026-05-27 14:43 UTC — Filed: 2026-05-27 AccNo: 0000950103-26-007766 Size: 365 KB
  - (2026-05-27) 424B2 - CITIGROUP INC (0000831001) (Filer)
      filed 2026-05-27 14:42 UTC — Filed: 2026-05-27 AccNo: 0000950103-26-007765 Size: 62 KB
  - (2026-05-27) 424B2 - Citigroup Global Markets Holdings Inc. (0000200245) (Filer)
      filed 2026-05-27 14:42 UTC — Filed: 2026-05-27 AccNo: 0000950103-26-007765 Size: 62 KB
  - (2026-05-27) 497 - ARBITRAGE FUNDS (0001105076) (Filer)
      filed 2026-05-27 14:42 UTC — Filed: 2026-05-27 AccNo: 0001104659-26-066684 Size: 311 KB
  - (2026-05-27) [Barrington Colm] Form 4 (Reporting)
      filed 2026-05-27 14:40 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0002030132-26-000002 Size: 4 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [United States] Bicyclist Seriously Injured in Motor Vehicle Crash
      domain: longisland.com · language: English · tone: 
  - (2026-05-27) [Canada] Ontario auto theft investigation leads to arrest of 9 : Niagara police
      domain: cp24.com · language: English · tone: 
  - (2026-05-27) [United States] The Latest : Trump will meet with his Cabinet as talks to end war in Iran remain in flux
      domain: harrisondaily.com · language: English · tone: 
  - (2026-05-27) [United States] Trump convenes Cabinet while seeking breakthrough in ending Iran war
      domain: abc6onyourside.com · language: English · tone: 
  - (2026-05-27) [United States] Avery Detten , Texas A & M student car crash victim organ donor to save 65 people
      domain: scallywagandvagabond.com · language: English · tone: 
  - (2026-05-27) [United States] MarineSolar Advances Clean Energy Trial at Sea
      domain: azocleantech.com · language: English · tone: 
  - (2026-05-27) [United States] Blue Cross Blue Shield , Michigan Medicine reach tentative contract agreement
      domain: clickondetroit.com · language: English · tone: 
  - (2026-05-27) [United States] Milestones Soroptimists , OMC , Footprinters May 27 , 2026
      domain: sequimgazette.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,058,454 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,958,983 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,805,817 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 100% · 24h volume: $1,726,817 · resolves 2026-05-27
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,683,639 · resolves 2026-07-20
  - (2026-05-27) Will Barack Obama win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $1,146,107 · resolves 2028-11-07
  - (2026-05-27) Roland Garros ATP: Mariano Navone vs Jakub Mensik
      yes price: 64% · 24h volume: $949,180 · resolves 2026-06-03
  - (2026-05-27) Dota 2: OG vs Tundra Esports (BO1) - BLAST Slam Group Stage
      yes price: 100% · 24h volume: $936,547 · resolves 2026-05-27

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-26) [Marginal Revolution] *How to Win a Trade War: An Optimistic Guide to an Anxious Global Economy*
      That is the new Soumaya Keynes book, out today.  I was happy to have blurbed this book, and here is an essay, on export restrictions, based on the book.
The post *How to Win a Trade War: An Optimistic Guide to an Anxious
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=590, 7d-median=590, 14d-median=590
- local_news: today=255, 7d-median=255, 14d-median=255
- foreign_news: today=869, 7d-median=869, 14d-median=869
- chinese_internal: today=283, 7d-median=283, 14d-median=283
- russian_internal: today=1132, 7d-median=1132, 14d-median=1132
- ukrainian_internal: today=134, 7d-median=134, 14d-median=134
- paper_bets: today=137, 7d-median=137, 14d-median=137
- weather: today=122, 7d-median=122, 14d-median=122
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=33, 7d-median=33, 14d-median=33
- congressional_trades: today=66, 7d-median=66, 14d-median=66
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*