# WORLDSCOPE morning brief — 2026-05-27

## Headline
5214 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 698 new of 698 total
  - (2026-05-27) [Alabama] World Trade Month
      Download
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-27) [Arizona] States could purge voter rolls close to elections if Supreme Court takes Trump’s side in Arizona case
      The Trump administration wants the U.S. Supreme Court to empower states to review their voter rolls for noncitizens just days before elections, a change that voting rights advocates say would risk disenfranchising Americ
  - (2026-05-27) [Arizona] Hobbs launches multi-million-dollar reelection ad campaign touting working-class background
      In her first campaign ads in her reelection bid, Gov. Katie Hobbs is touting her efforts to lower costs for Arizonans and fight for working families across the Grand Canyon State. Hobbs’ campaign said the two ads — one i
  - (2026-05-27) [Arizona] Trump struck a deal for China to buy $17B a year in US ag products. Farmers are skeptical.
      By Rebecka Pieder/Medill News Service WASHINGTON &#8211; In a deal that could provide a major trade boost for American farmers, the White House said that during the recent summit, China committed to buying at least $17 b
  - (2026-05-26) [Arizona] Democratic state AGs say their staff excluded from Vance anti-fraud meeting
      WASHINGTON — A handful of Democratic state attorneys general said Tuesday that expert officials from their offices were denied access to a major White House anti-fraud meeting convened by Vice President JD Vance and atte
  - (2026-05-26) [Arizona] Arizona added jobs in April, but its employment rate has been stuck at 2024 levels for 2 years
      After seven months of lower employment rates than last year, Arizona’s job market finally saw positive growth in April, according to the latest data from the Bureau of Labor Statistics.  A recent report from the Common S
  - (2026-05-26) [Arizona] Justin Heap refers alleged noncitizen voters to AG’s office after strongly worded letters
      After weeks of sparring with state prosecutors, Maricopa County Recorder Justin Heap referred potential noncitizens that he claims to have found on the county’s voter roll to the Arizona Attorney General’s Office on Frid

### Local News: St. Louis + Atlanta — 253 new of 253 total
  - (2026-05-27) [St. Louis] Where in Clayton? – 5/27/2026
      <p>Let&#8217;s see how well you know Clayton. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click &#8220;lock i
  - (2026-05-27) [St. Louis] Katie’s grows footprint at Target with new pasta bake entrées and sauces
      <p>What began with frozen pizza has evolved into a much larger retail push for Katie&#8217;s at Target stores. Last fall, the retailer introduced Katie&#8217;s frozen pizzas in all 1,800 stores nationwide, a move that ca
  - (2026-05-27) [St. Louis] Cool caves to explore within driving distance of St. Louis
      <p>Cliff Cave Park &#124; Oakville, Missouri &#124; 30 minutes from downtown St. Louis This beautiful 525-acre public park is home to biking and hiking trails, fishing spots, shelters, and more. The cave&#8217;s history 
  - (2026-05-27) [St. Louis] ‘The Tempest’ rolls into Shakespeare Glen
      <p>As evening falls on Forest Park, the music of guitars, accordion, and hand drum fills the tree-lined bowl of Shakespeare Glen. A fitting drizzle falls on the final dress rehearsal for St. Louis Shakespeare Festival’s 
  - (2026-05-27) [St. Louis] Public pools, splash pads, and water parks in the St. Louis region
      <p>St. Louis summers are famously hot and sticky. What better way to cool down than by visiting one of the region&#8217;s many pools, swim clubs, or water parks? Even without owning a seasonal membership, families can ta
  - (2026-05-27) [St. Louis] Drive-in movie theaters within driving distance from St. Louis
      <p>Skyview Drive-In &#124; Belleville, Illinois 30 minutes east of St. Louis Whether it be a routine family night out or a special celebration, pop into the Skyview for showings of new and old favorites alike. Adult tick
  - (2026-05-27) [St. Louis] Ask Veronica: How to style a room with plants, according to design experts
      <p>A few weeks ago, I interviewed Laura Dooley, owner of LoKey Designs, and Nicole Walter, greenhouse buyer for Garden Heights Nursery, for the latest episode of my podcast House of Lou. Naturally, we talked about plants
  - (2026-05-27) [St. Louis] Every St. Louis parent eventually ends up shopping at Dierbergs for the car carts alone
      <p>As someone who works almost exclusively from home, I’m always looking for any excuse to leave the house. This often translates into frequent trips to the grocery store. Are we out of butter? I’m going to the grocery s

### International News + Multilateral Institutions — 884 new of 884 total
  - (2026-05-27) [feed error] AP Top News (RSSHub): HTTPError
      403 Client Error: Forbidden for url: https://rsshub.app/ap/topics/apf-topnews
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [Global] Markets rally amid hopes of US-Iran deal
      Markets betting a deal will reopen the Strait of Hormuz and soothe the deep global economic uncertainty.
  - (2026-05-27) [Global] Former assistant to TV star Matthew Perry sentenced to 41 months in prison
      Sentencing of Kenneth Iwamasa concludes prosecution of five people in connection with Perry&#039;s death from drug ketamine.
  - (2026-05-27) [Global] Why is Israel ramping up attacks in Lebanon despite a ceasefire?
      Intensification comes while US-Iran indirect talks continue.
  - (2026-05-27) [Global] Trump says no one will control Strait of Hormuz
      Donald Trump says he won’t allow Iran to control ⁠the Strait of ⁠Hormuz under the terms of any deal reached with Tehran.

### Chinese Internal News — 284 new of 284 total
  - (2026-05-25) [TITLE: 李昕 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTFBZdlVzLS1fQlpQOUo5REtmTTEyUzdfejZxcVZVaFZoWEs4VE9aVTgyUUVFd2dUQkR6UHhlOUpnNmdVSXVMSEVCOHNtY1VBMkNNaG5HcmlQMmNuZw?oc=5] (zh: 李昕 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTFBZdlVzLS1fQlpQOUo5REtmTTEyUzdfejZxcVZVaFZoWEs4VE9aVTgyUUVFd2dUQkR6UHhlOUpnNmdVSXVMSEVCOHNtY1VBMkNNaG5HcmlQMmNuZw?oc=5" target="_blank">李昕</a>&nbsp;&nbsp;<font c
  - (2026-05-27) [TITLE: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlD] (zh: 香港银行同步加强内地客监管 有中资行已暂停新用户开投资账户 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE5NVHlPMHFzTi1BRkhFNjV0YVBiVEZHZDhrdEhJTFAyNlllTWhRTjByV21SVzN0eFl2MUpVaW0yZDRRUjVQMHlkTGlDRUx5b1ZMbmc3TmFqQVpGd1YyVk1NTm9R?oc=5" target="_blank">香港银行同步加强内地客监管 有
  - (2026-05-27) [TITLE: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3OD] (zh: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3ODJlTk9Hc1N4VEUxUEdRUzM4NzBDMThV?oc=5" target="_blank">电信诈骗版图南迁 自柬埔寨转向印尼</
  - (2026-05-25) [TITLE: 最新封面报道｜争夺估值王 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjl] (zh: 最新封面报道｜争夺估值王 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjlCYlZvR05ONEE2Mg?oc=5" target="_blank">最新封面报道｜争夺估值王</a>&
  - (2026-05-26) [TITLE: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGh] (zh: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGhBenBsLXFZOVJxRl9xSmVnZHJHMUNB?oc=5" target="_blank">财经早知道｜深圳常住人口首破1
  - (2026-05-27) [TITLE: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNk] (zh: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNkd4djhVSzQ2dV96bmZwVzhvLUc3TW1ZTEQ0?oc=5" target="_blank">深圳一快速路段发生火灾 警方称无人受伤
  - (2026-05-27) [TITLE: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHd] (zh: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHdyandPQXJnQW5YN2RmdU03U1FhOVFYV1Zn?oc=5" target="_blank">AI、石化产业链带动4月工业利
  - (2026-05-26) [TITLE: 宇树科技科创板IPO将于6月1日上会 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE12bDdQa3Q4SVRSMlEtcWI1QXZSNWpvY0xSS3hrTnFaLXhCakRjeVBYVS1jWDEyYU1aLU16UWpESFdITXJDR0VKaWJOZk02OFNZT0I] (zh: 宇树科技科创板IPO将于6月1日上会 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE12bDdQa3Q4SVRSMlEtcWI1QXZSNWpvY0xSS3hrTnFaLXhCakRjeVBYVS1jWDEyYU1aLU16UWpESFdITXJDR0VKaWJOZk02OFNZT0I4b1M3WGJkYjhMWFE?oc=5" target="_blank">宇树科技科创板IPO将于6月1日上会</

### Russian Internal News (state + in-exile) — 1011 new of 1011 total
  - (2026-05-27) [TITLE: Детская площадка в Херсоне попала под обстрел России. Погиб мужчина, его жена и две дочери ранены | LEDE: <p>Вооруженные силы РФ обстреляли Корабельный район Херсона из реактивных систем залпов] (ru: Детская площадка в Херсоне попала под обстрел России. Погиб мужчина, его жена и )
      <p>Вооруженные силы РФ обстреляли Корабельный район Херсона из реактивных систем залпового огня, сообщает 27 мая «Суспiльне», ссылаясь на местные власти.<p>
  - (2026-05-27) [TITLE: Замглавы «Уралвагонзавода» арестован по делу о растрате при выполнении гособоронзаказа | LEDE: <p>Басманный районный суд Москвы отправил под стражу на два месяца заместителя гендиректора концер] (ru: Замглавы «Уралвагонзавода» арестован по делу о растрате при выполнении гособорон)
      <p>Басманный районный суд Москвы отправил под стражу на два месяца заместителя гендиректора концерна «Уралвагонзавод» по спецтехнике Дмитрия Семизорова, которого обвиняют в растрате при выполнении государственного оборон
  - (2026-05-27) [TITLE: Судебные приставы взыскали 300 тысяч рублей с Артемия Лебедева, назвавшего Лигу безопасного интернета «****** [фигней] на палке» | LEDE: <p>Руководитель Лиги безопасного интернета Екатерина Миз] (ru: Судебные приставы взыскали 300 тысяч рублей с Артемия Лебедева, назвавшего Лигу )
      <p>Руководитель Лиги безопасного интернета Екатерина Мизулина сообщила в телеграме 27 мая, что судебные приставы взыскали с блогера Артемия Лебедева 300 тысяч рублей компенсации по иску Мизулиной о защите чести и достоин
  - (2026-05-27) [TITLE: Руслана Кутаева (он оправдывал «убийства чести») оставили в платформе российской оппозиции при ПАСЕ | LEDE: <p>Бюро Парламентской ассамблеи Совета Европы решило оставить в составе платформы рос] (ru: Руслана Кутаева (он оправдывал «убийства чести») оставили в платформе российской)
      <p>Бюро Парламентской ассамблеи Совета Европы решило оставить в составе платформы российской оппозиции при ПАСЕ общественного деятеля из Чечни Руслана Кутаева, который оскорблял ЛГБТК-людей и оправдывал «убийства чести» 
  - (2026-05-27) [TITLE: «Вы пользуетесь Wi-Fi, который я создал, VPN, который я создал. Вы пользуетесь экстремистскими вещами?». Из России уехал пионер IT-индустрии Александр Галицкий, у которого отобрали все имуществ] (ru: «Вы пользуетесь Wi-Fi, который я создал, VPN, который я создал. Вы пользуетесь э)
      <p>71-летний Александр Галицкий — советский конструктор, который стал одним из первых успешных технопредпринимателей и венчурных инвесторов России. Он много лет вел бизнес в США, Восточной Европе и России. Но на фоне кон
  - (2026-05-27) [TITLE: Росстат сообщил, что долг по зарплатам в России за месяц вырос на треть. Государственным СМИ рекомендовали «максимально игнорировать» эти данные | LEDE: <p>Суммарная задолженность по зарплате в] (ru: Росстат сообщил, что долг по зарплатам в России за месяц вырос на треть. Государ)
      <p>Суммарная задолженность по зарплате в России на конец апреля составила 2,9 миллиарда рублей, что на 750 миллионов рублей больше (+35,2%), чем в марте, следует из данных Росстата, представленных 27 мая.<p>
  - (2026-05-27) [TITLE: Участница «Фракции Красной армии» Даниэла Клетте получила 13 лет тюрьмы за грабежи. Она больше 30 лет скрывалась от полиции — и жила в центре Берлина | LEDE: <p>Суд в Вердене приговорил бывшую ] (ru: Участница «Фракции Красной армии» Даниэла Клетте получила 13 лет тюрьмы за грабе)
      <p>Суд в Вердене приговорил бывшую участницу немецкой леворадикальной террористической организации «Фракция Красной армии» (RAF) Даниэлу Клетте к 13 годам лишения свободы за участие в серии вооруженных ограблений суперма
  - (2026-05-27) [TITLE: В России массово задерживают муфтиев — по обвинениям от подкупа до терроризма. Это кампания против главы Духовного управления мусульман Равиля Гайнутдина, считают эксперты | LEDE: <p>В мае из р] (ru: В России массово задерживают муфтиев — по обвинениям от подкупа до терроризма. Э)
      <p>В мае из разных регионов России поступили сообщения о задержаниях и арестах муфтиев и других мусульманских религиозных и общественных деятелей. Некоторых из них обвиняют по террористической статье — в сотрудничестве с

### Ukrainian Internal News (national + local Kyiv) — 138 new of 138 total
  - (2026-05-28) [TITLE: Трамп зробив ще одну заяву про угоду з Іраном | LEDE: Трамп натякнув на "Авраамові угоди", коли говорив про перемир'я з Іраном.] (uk: Трамп зробив ще одну заяву про угоду з Іраном)
      Трамп натякнув на "Авраамові угоди", коли говорив про перемир'я з Іраном.
  - (2026-05-27) [TITLE: Україна перед "Рамштайном" узгодила з партнерами пріоритети: ППО, снаряди та дрони | LEDE: Міністр оборони Михайло Федоров провів розмову зі своїми колегами з Німеччини та Великої Британії Бори] (uk: Україна перед "Рамштайном" узгодила з партнерами пріоритети: ППО, снаряди та дро)
      Міністр оборони Михайло Федоров провів розмову зі своїми колегами з Німеччини та Великої Британії Борисом Пісторіусом і Джоном Гілі, а також із генсекретарем НАТО Марком Рютте, в ході якої йшлося про ключові пріоритети У
  - (2026-05-27) [TITLE: Понад 250 бойових зіткнень відбулось на фронті з початку доби — Генштаб | LEDE: Від початку доби 27 травня на фронті відбулось 256 бойових зіткнень.] (uk: Понад 250 бойових зіткнень відбулось на фронті з початку доби — Генштаб)
      Від початку доби 27 травня на фронті відбулось 256 бойових зіткнень.
  - (2026-05-27) [TITLE: Трамп: США слідкуватимуть за Ормузькою протокою | LEDE: ] (uk: Трамп: США слідкуватимуть за Ормузькою протокою)
  - (2026-05-27) [TITLE: По всій Україні оголошували повітряну тривогу через зліт МіГ-31К | LEDE: Увечері 27 травня по всій території України оголосили повітряну тривогу через зліт МіГ-31К.] (uk: По всій Україні оголошували повітряну тривогу через зліт МіГ-31К)
      Увечері 27 травня по всій території України оголосили повітряну тривогу через зліт МіГ-31К.
  - (2026-05-27) [TITLE: Затримали майора поліції, який зґвалтував неповнолітню дівчинку – прокуратура | LEDE: Керівник Запорізької обласної прокуратури повідомив про підозру поліцейському, який, за даними слідства, зг] (uk: Затримали майора поліції, який зґвалтував неповнолітню дівчинку – прокуратура)
      Керівник Запорізької обласної прокуратури повідомив про підозру поліцейському, який, за даними слідства, згвалтував 14-річну жительку Запоріжжя.
  - (2026-05-27) [TITLE: Норвегія приєднається до французької ядерної "парасольки" | LEDE: ] (uk: Норвегія приєднається до французької ядерної "парасольки")
  - (2026-05-27) [TITLE: Зеленський про свій лист до Трампа: Важливо, щоб Америка почула Україну | LEDE: Президент Володимир Зеленський прокоментував свій лист до американського колеги Дональда Трампа і членів Конгресу] (uk: Зеленський про свій лист до Трампа: Важливо, щоб Америка почула Україну)
      Президент Володимир Зеленський прокоментував свій лист до американського колеги Дональда Трампа і членів Конгресу США, в якому йшлося про дефіцит засобів ППО в України.

### Ukraine Theater (total-war monitoring) — 394 new of 394 total
  - (2026-05-27) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [Air alerts error] HTTPError (set ALERTS_IN_UA_TOKEN for v2)
      401 Client Error: Unauthorized for url: https://api.alerts.in.ua/v1/alerts/active.json
  - (2026-05-25) [Liveuamap] Russian FM Lavrov informed State Secretary Rubio that Russia will intensify strikes on Kyiv. Lavrov urged Rubio to evacuate U.S. citizens and diplomatic staff from Kyiv Moskva, Moscow - Ukraine Interactive map - Ukraine Latest news on live 
      <a href="https://news.google.com/rss/articles/CBMikgFBVV95cUxQTkE1MmhVLXlxWmVTMW45QlppeVlWOVFva1ZNbUpRdU85eksxb0U3dS1qdW52bFlOWlhLNTQ3aHdKMWdzUFRfbXBwRzF5YW1rdklmQXpoRE5qQ2x1eHk0MVl4YWtTQmhnVEcxcmpGUF9xb0JuOXllcDY5UDNsXz
  - (2014-11-14) [Liveuamap] Ukraine Interactive map - Ukraine Latest news on live map - liveuamap.com - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMiOkFVX3lxTFBsdGdBOUMtUGIzaWpMRVRwa0x4VWY3SlRTTVdTYW83Y01rR0xpSWpXd2xNOWFkV0lWNUE?oc=5" target="_blank">Ukraine Interactive map - Ukraine Latest news on live map - liveuama
  - (2026-05-26) [Liveuamap] The U.S. Navy has resumed escorting ships through the Strait of Hormuz under a renewed “Project Freedom” mission. A Greek supertanker carrying two million barrels of crude was recently guided through the route after being stranded in the Gu
      <a href="https://news.google.com/rss/articles/CBMilwFBVV95cUxPaW5lLXY3NUJLY0ItLUJxZThHc2M4c1ExQjFYVzNrQUlUZENnZlppel9mc3dMUTRoem1LUllkT3liOTFCeGgwX0JZbTVvdjRrWUJrRUh2cnBWS1ZhOEpzZGFHX3M4UWFvdUdkLV9ERU1vcjFnYmVVd0Zza1VaRz
  - (2026-05-27) [Liveuamap] Explosions were reported at the airbase in Voronezh - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxNZHgyQi1oNThuX1BJa2lEdHRaTERPWVREQkF1RE5MUTQ5WUhRQjJha0RYRDhTeFQyOWJoU1k4aW42V0RZNXpRRTdUUUdzYWdnUXRzRThhTkNkUkdZRm1BbE9qVWhNeFVORGh4Z2tQcENGajlqSWxwbVltZ1N0V1
  - (2026-05-26) [Liveuamap] Amal Shehadeh: The Israeli army is operating north of the yellow line and making extensive preparations to pursue field commanders in Nabatieh. - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMingFBVV95cUxPNzhSWEFycm1vYjVqREFsUHhpWXdwc3Z2ck1STzBOZmRlVDZ5MUwyYmdmRmlWMHFOUkh5THNmVjRCX1NWQzVPSkJDNzh1S2NtUTlibnlqc0hPRU0zZlhZUHR4Y2FEZ1pqSjNmd2tSY0hpZDA4ckFsZUhmYy1aem
  - (2026-05-27) [Liveuamap] President Zelensky sent a letter to President Trump and to Congress asking for urgent supply of Patriot interceptors - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxQaDZhbTFQc0FlTzNaSWxIa1k0R0g2LWFIZnN0REZieU9IRUNIRmswNXRqMEV6OVJTTHdWWFR6Q2k5T3dpTjVfb2JjQk44eGJsaWRXV3RhWmdFM1RxZ1VVdDhmajg2ZDlBVnNQREFYSW1uSG42YUp6VUwyeGFhT0

### Paper Trading Scorecard — 136 new of 136 total
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Washington Mystics vs. Seattle Storm
      In the upcoming WNBA game, scheduled for May 27 at 10:00PM ET:
If the Washington Mystics win, the market will resolve to "Washington Mystics".
If the Seattle Storm win, the market will resolve to "Seattle Storm".
If the 
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Raphaël Glucksmann win the 2027 French presidential election?
      The next French presidential election is currently expected to be held around April 2027.  This market pertains to the outcome of the next French presidential election, regardless of whether it follows the scheduled end 
  - (2026-05-27) [Polymarket] Israeli parliament dissolved by May 31?
      This market will resolve to "Yes" if the sitting Israeli Knesset (Israel's parliament), as of this market's inception, is dissolved between market creation and May 31, 2026, 11:59 PM ET. Otherwise, this market will resol
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso

### U.S. Weather + Severe / Climate Outlooks — 145 new of 145 total
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 5:36PM EDT by NWS Tallahassee FL
      At 535 PM EDT, Doppler radar was tracking strong thunderstorms along
a line extending from near Leary to 13 miles east of Morgan to near
Albany to near Marine Corps Logistics Base to near Putney. Movement
was north at 25
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 4:36PM CDT until May 27 at 5:15PM CDT by NWS Green Bay WI
      SVRGRB

The National Weather Service in Green Bay has issued a

* Severe Thunderstorm Warning for...
South central Marathon County in central Wisconsin...

* Until 515 PM CDT.

* At 435 PM CDT, a severe thunderstorm was 
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 5:36PM EDT by NWS Jackson KY
      At 536 PM EDT, Doppler radar was tracking a strong thunderstorm over
Vale, or 8 miles southwest of Olive Hill, moving east at 20 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IMPAC
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 5:36PM EDT by NWS Blacksburg VA
      At 536 PM EDT, Doppler radar was tracking a strong thunderstorm over
Dunns, or near Pipestem, moving east at 30 mph.

HAZARD...Wind gusts up to 40 mph.

SOURCE...Radar indicated.

IMPACT...Gusty winds could knock down tr
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 4:35PM CDT until May 27 at 7:00PM CDT by NWS Fort Worth TX
      * WHAT...Urban area and small stream flooding caused by excessive
rainfall continues.

* WHERE...A portion of north central Texas, including the following
counties, Fannin and Grayson.

* WHEN...Until 700 PM CDT.

* IMPA
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 5:32PM EDT until May 27 at 9:00PM EDT by NWS Wilmington OH
      * WHAT...Flooding caused by excessive rainfall continues.

* WHERE...The following counties, in west central Ohio, Clark,
Greene, Miami, Montgomery and Preble.

* WHEN...Until 900 PM EDT.

* IMPACTS...Flooding of rivers,
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 5:32PM EDT by NWS Blacksburg VA
      At 532 PM EDT, Doppler radar was tracking a strong thunderstorm near
Centenary, or 15 miles west of Fork Union, moving east at 35 mph.

HAZARD...Wind gusts of 50 to 55 mph and nickel size hail.

SOURCE...Radar indicated.
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 4:31PM CDT until May 27 at 4:45PM CDT by NWS Green Bay WI
      At 431 PM CDT, a severe thunderstorm was located near Weston, or 12
miles southeast of Wausau, moving southeast at 35 mph.

HAZARD...Golf ball size hail and 60 mph wind gusts.

SOURCE...Public report of golf ball sized h

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 79 new of 79 total
  - (2026-05-27) [fx] USD/EUR: 0.859651
      1 USD = 0.859651 EUR
  - (2026-05-27) [fx] USD/GBP: 0.743251
      1 USD = 0.743251 GBP
  - (2026-05-27) [fx] USD/JPY: 159.232868
      1 USD = 159.232868 JPY
  - (2026-05-27) [fx] USD/CHF: 0.785427
      1 USD = 0.785427 CHF
  - (2026-05-27) [fx] USD/CAD: 1.380782
      1 USD = 1.380782 CAD
  - (2026-05-27) [fx] USD/AUD: 1.394958
      1 USD = 1.394958 AUD
  - (2026-05-27) [fx] USD/NZD: 1.712118
      1 USD = 1.712118 NZD
  - (2026-05-27) [fx] USD/CNY: 6.798706
      1 USD = 6.798706 CNY

### Government Action: Sanctions + Procurement + Foreign Agents — 96 new of 96 total
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-20) [OFAC] International Criminal Court-related Designation Removal - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9Ea293ZzJIMldMbWM4QndMbk5YVFZDX1B1RXQ5UmM0blB5YmR6THJHa3NLeHI3bVFrNmJya0VCcUpSMlp5dFM1T1lldWZ4MlBEMXpISkREbXNYWFNMRFY3bWlR?oc=5" target="_blank">International C
  - (2026-05-20) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE00SUEzZjlGVDZYWVJCUWlDSWhpSzBUbzRKUE9pUkNDaUFJR1hDb1ppNHNISjJESjU2Vy1vSmVXOExZeUxCMnpJWVpMYnc0WEd2em0zeG9jTFMzYVJXTWc?oc=5" target="_blank">Counter Narcotics an
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-05-27) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 4 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard
  - (2026-05-26) [CA4] Tony Messer v. Garrison Investment Group, LP

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) [Hooper Joan S] Form 4 (Reporting)
      filed 2026-05-27 21:36 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0000780571-26-000143 Size: 4 KB
  - (2026-05-27) [ITRON, INC.] Form 4 (Issuer)
      filed 2026-05-27 21:36 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0000780571-26-000143 Size: 4 KB
  - (2026-05-27) [Sotera Health Co] Form 4 (Issuer)
      filed 2026-05-27 21:36 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001193125-26-242231 Size: 5 KB
  - (2026-05-27) [Flynn Karen] Form 4 (Reporting)
      filed 2026-05-27 21:36 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242231 Size: 5 KB
  - (2026-05-27) [Bradshaw Wayne-Kent A.] Form 4 (Reporting)
      filed 2026-05-27 21:34 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001140361-26-023017 Size: 12 KB
  - (2026-05-27) [BROADWAY FINANCIAL CORP \DE\] Form 4 (Issuer)
      filed 2026-05-27 21:34 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001140361-26-023017 Size: 12 KB
  - (2026-05-27) [Briggs Andrew J] Form 4 (Reporting)
      filed 2026-05-27 21:34 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-242224 Size: 5 KB
  - (2026-05-27) [FARMERS & MERCHANTS BANCORP INC] Form 4 (Issuer)
      filed 2026-05-27 21:34 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001193125-26-242224 Size: 5 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [United States] Wall Street climbs , major indices gain ground Wednesday
      domain: newjerseytelegraph.com · language: English · tone: 
  - (2026-05-27) [United States] ACS adds blood test to colon , rectal cancer screening recommendations
      domain: kcra.com · language: English · tone: 
  - (2026-05-27) [United States] SPR Oil Heads to California for First Time Amid Iran War Disruptions
      domain: gcaptain.com · language: English · tone: 
  - (2026-05-27) [] Parrott Foundation gives $750K to Loyalist medical radiation tech lab
      domain: pembrokeobserver.com · language: English · tone: 
  - (2026-05-27) [United Kingdom] Matthew Perry personal assistant jailed for his role in star ketamine death
      domain: gazetteherald.co.uk · language: English · tone: 
  - (2026-05-27) [United States] Typical CEO pay climbs nearly 6 % in 2025 as median reaches $17 . 7 million
      domain: wptv.com · language: English · tone: 
  - (2026-05-27) [Philippines] CTO Realty Growth Declares Dividends for the Second Quarter 2026
      domain: manilatimes.net · language: English · tone: 
  - (2026-05-27) [United States] Samsung Galaxy S26 Ultra Buyers : The Wait Has Finally Paid Off
      domain: forbes.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 16 total
  - (2026-05-27) CVE-2026-48027 · Nx Nx Console: Nx Console Embedded Malicious Code Vulnerability
      vendor: Nx · product: Nx Console · CISA remediation by 2026-06-10
  - (2026-05-27) CVE-2026-45321 · TanStack TanStack: TanStack Unspecified Vulnerability
      vendor: TanStack · product: TanStack · CISA remediation by 2026-06-10
  - (2026-05-27) CVE-2026-8398 · Daemon Daemon Tools Lite: Daemon Tools Lite Embedded Malicious Code Vulnerability
      vendor: Daemon · product: Daemon Tools Lite · CISA remediation by 2026-05-30
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $3,795,048 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,961,973 · resolves 2026-12-31
  - (2026-05-27) US announces new Iran agreement/ceasefire extension by May 27?
      yes price: 1% · 24h volume: $1,809,293 · resolves 2026-05-27
  - (2026-05-27) Philadelphia Phillies vs. San Diego Padres
      yes price: 50% · 24h volume: $1,268,058 · resolves 2026-06-03
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,254,177 · resolves 2026-07-20
  - (2026-05-27) Will Crystal Palace FC win on 2026-05-27?
      yes price: 100% · 24h volume: $1,248,219 · resolves 2026-05-27
  - (2026-05-27) Will Tom Brady win the 2028 Republican presidential nomination?
      yes price: 1% · 24h volume: $1,185,621 · resolves 2028-11-07
  - (2026-05-27) Will Turkiye win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,182,733 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-05-27) [Marginal Revolution] Wednesday assorted links
      1. As meat prices rise, the economics of Texas barbecue. 2. Economic historian Eric Jones has passed away. 3. Claims about the Pope and Claude.  If true, further evidence for my Straussian hypothesis. 4. Koyama reviews T
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-27) [Conversable Economist] Lessons for Central Banks: Interview with Kristin Forbes
      Thomas Chow poses the questions in &#8220;Kristin Forbes on &#8216;wargaming&#8217; for thenext crisis,&#8221; subtitled &#8220;The MIT professor and former BoE MPC member speaks about QE, scenario analysis and the ar of
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### U.S. Political Figures (per-figure anomaly tracking) — 613 new of 613 total
  - (2026-05-27) Senator: Angela D Alsobrooks (anomaly 0.00)
      Angela D Alsobrooks (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ
  - (2026-05-27) Senator: Alan Armstrong (anomaly 0.00)
      Alan Armstrong (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ ment
  - (2026-05-27) Senator: Tammy Baldwin (anomaly 0.00)
      Tammy Baldwin (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Jim Banks (anomaly 0.10)
      Jim Banks (Senator). Composite anomaly score 0.100. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.50. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ mentions:
  - (2026-05-27) Senator: John Barrasso (anomaly 0.00)
      John Barrasso (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Michael F Bennet (anomaly 0.00)
      Michael F Bennet (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Marsha Blackburn (anomaly 0.20)
      Marsha Blackburn (Senator). Composite anomaly score 0.200. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 1.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Richard Blumenthal (anomaly 0.00)
      Richard Blumenthal (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ 

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=698, 7d-median=698, 14d-median=698
- local_news: today=253, 7d-median=253, 14d-median=253
- foreign_news: today=884, 7d-median=884, 14d-median=884
- chinese_internal: today=284, 7d-median=284, 14d-median=284
- russian_internal: today=1011, 7d-median=1011, 14d-median=1011
- ukrainian_internal: today=138, 7d-median=138, 14d-median=138
- ukraine_theater: today=394, 7d-median=394, 14d-median=394
- paper_bets: today=136, 7d-median=136, 14d-median=136
- weather: today=145, 7d-median=145, 14d-median=145
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=96, 7d-median=96, 14d-median=96
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*