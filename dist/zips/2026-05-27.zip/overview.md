# WORLDSCOPE morning brief — 2026-05-27

## Headline
2405 new items across 32 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 0 new of 0 total
  (no new items today)

### State-Level News — 581 new of 581 total
  - (2026-05-27) [feed error] AZ Governor (Arizona): HTTPError
      404 Client Error: Not Found for url: https://azgovernor.gov/feed
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-26) [California] Governor Newsom signs legislation 5.26.2026
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2024/05/6C94C750-0DF8-46C6-A8E3-00EA4F1B1ADD-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async" />
  - (2026-05-26) [California] Governor Newsom proclaims Older Californians Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-25) [California] Governor Newsom secures Presidential Emergency Declaration approval for Orange County hazmat response
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Governor-Newsom-secures-Presidential-Emergency-Declaration-approval-for-Orange-County-hazmat-response-SEO-GFX-v2-150x150.png" class="at
  - (2026-05-25) [California] Governor Newsom proclaims Memorial Day
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-25) [California] California mobilizes 785+ emergency personnel in Orange County hazmat response
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Orange-County-Whole-Government-Response-2-150x150.png" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async
  - (2026-05-27) [Connecticut] CT expanding cannabis use will make roads more dangerous
      <figure><img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/05/pexels-lighting-weed-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" f

### Local News: St. Louis + Atlanta — 133 new of 133 total
  - (2026-05-27) [feed error] Riverfront Times (St. Louis): HTTPError
      403 Client Error: Forbidden for url: https://www.riverfronttimes.com/category/news/feed/
  - (2026-05-27) [feed error] St. Louis Post-Dispatch (St. Louis): HTTPError
      429 Client Error: Too Many Requests for url: https://www.stltoday.com/feeds/news/rss/
  - (2026-05-27) [St. Louis] Chemical tank implosion at Washington paper mill kills 1. Here's the latest on the search for 9 others.
      One worker was killed and nine others were unaccounted for with no hope for rescue, authorities said. Nine others were injured.
  - (2026-05-27) [St. Louis] Downtown St. Louis tower scheduled to be auctioned
      An online auction of the 30-story Bank of America Plaza at 800 Market St. is scheduled to open at noon on June 22, with a $2 million starting bid.
  - (2026-05-27) [St. Louis] Five decades later, families still fighting to add 74 sailors to Vietnam Veterans Memorial Wall
      More than 50 years after the deadly USS Frank E. Evans collision, survivors and lawmakers say the sailors deserve recognition on the memorial wall.
  - (2026-05-27) [St. Louis] President Trump gathers Cabinet as he looks to seal deal to end the war with Iran
      President Donald Trump meets with his Cabinet at a precarious moment for talks aimed at ending the war with Iran.
  - (2026-05-27) [St. Louis] Israel says strikes killed Hamas military leader just days after his predecessor died
      At least five people were killed and 12 injured in Tuesday's strike on the eve of Eid al-Adha, a major Muslim holiday, according to local hospitals.
  - (2026-05-27) [St. Louis] 'I have so much love for this city' | Travis Kelce buys minority stake in Cleveland Guardians
      Curtis Danburg, vice president of communications and community impact for the Guardians, told Ohio TV station 3News early Wednesday morning.

### International News + Multilateral Institutions — 885 new of 885 total
  - (2026-05-27) [feed error] Reuters World: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /Reuters/worldNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reu
  - (2026-05-27) [feed error] Reuters Business: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/businessNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.
  - (2026-05-27) [feed error] Reuters Top News: ConnectionError
      HTTPSConnectionPool(host='feeds.reuters.com', port=443): Max retries exceeded with url: /reuters/topNews (Caused by NameResolutionError("HTTPSConnection(host='feeds.reuters.com', port=443): Failed to resolve 'feeds.reute
  - (2026-05-27) [Global] DR Congo facing 'catastrophic collision' of Ebola and war, WHO chief warns
      The ongoing conflict between armed groups in the eastern Democratic Republic of Congo has made it harder for health workers to contain the worsening Ebola outbreak, World Health Organization Secretary-General Tedros Adha
  - (2026-05-27) [Global] Israeli defence ministry says it killed new Hamas military leader in Gaza
      Israel's defence ministry said Wednesday they had targeted and killed the new leader of Hamas's military wing, Mohammed Odeh, during air strikes in Gaza City, less than two weeks after killing his predecessor. Defence Mi
  - (2026-05-27) [Global] NASA lays out moon base plans including buggies, landers and drones
      NASA on Tuesday outlined the first phase of a sprawling moon base plans on Tuesday, less than two months after the Artemis II's record-breaking lunar flyaround, with visualisations of landers, rovers and drones. The spac
  - (2026-05-27) [Global] USAID was shut down 'to soothe ego' of Musk, whistleblower says
      In an interview with FRANCE 24, Nicolas Enrich, a former senior USAID official-turned-whistleblower, said the US agency was dismantled not to cut waste but "to soothe the ego of the world's richest man", then DOGE head E
  - (2026-05-27) [Global] FRANCE 24's live streams are temporarily unavailable on its digital platforms
      A technical incident is preventing FRANCE 24 from offering its live broadcast on digital platforms.

### Chinese Internal News — 4 new of 4 total
  - (2026-05-27) [feed error] Caixin Global: HTTPError
      404 Client Error: Not Found for url: https://www.caixinglobal.com/rss/news.xml
  - (2026-05-27) [feed error] Sixth Tone: HTTPError
      404 Client Error: Not Found for url: https://www.sixthtone.com/feed
  - (2026-05-27) [feed error] Caijing 财经: HTTPError
      404 Client Error: Not Found for url: https://www.caijing.com.cn/rss/topnews.xml
  - (2026-05-27) [feed error] People's Daily 人民日报: ConnectTimeout
      HTTPConnectionPool(host='rss.people.com.cn', port=80): Max retries exceeded with url: /rss/politics.xml (Caused by ConnectTimeoutError(<HTTPConnection(host='rss.people.com.cn', port=80) at 0x7fc6d06d4690>, 'Connection to

### Paper Trading Scorecard — 140 new of 140 total
  - (2026-05-27) [Polymarket] Will OpenAI have the best AI model at the end of May 2026?
      This market will resolve according to the company that owns the model that has the highest arena rank based on the Chatbot Arena LLM Leaderboard (https://lmarena.ai/) when the table under the "Leaderboard" tab is checked
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Monte win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Aurora win IEM Cologne Major 2026?
      This market will resolve according to the winner of the IEM Cologne 2026 tournament, currently scheduled for June 2nd - June 21st, 2026.

If this tournament is cancelled, postponed after July 1, 2026, 11:59 PM ET, or a w
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso

### U.S. Weather + Severe / Climate Outlooks — 123 new of 123 total
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Severe] Special Marine Warning: Special Marine Warning issued May 27 at 8:56AM CDT until May 27 at 11:00AM CDT by NWS Houston/Galveston TX
      SMWHGX

The National Weather Service in League City has issued a

* Special Marine Warning for...
Coastal waters from Freeport to Matagorda Ship Channel TX out 20
NM...
Matagorda Bay...
Waters from Freeport to Matagorda 
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 8:56AM CDT by NWS Brownsville TX
      At 856 AM CDT, Doppler radar was tracking a cluster of strong
thunderstorms over Rio Hondo Elementary School, or near Rio Hondo,
moving northeast at 85 mph.

HAZARD...Wind gusts of 50 to 55 mph.

SOURCE...Radar indicated
  - (2026-05-27) [Moderate] Wind Advisory: Wind Advisory issued May 27 at 6:42AM PDT until May 27 at 8:00PM PDT by NWS Elko NV
      * WHAT...Sustained southeast to south winds 25 to 35 mph, with gusts
near 55 mph expected.

* WHERE...White Pine, Northern Elko, Ruby Mountains and East
Humboldt Range in Elko, South Central Elko, and Southeastern Elko
C
  - (2026-05-27) [Severe] Flood Watch: Flood Watch issued May 27 at 9:42AM EDT until May 28 at 2:00AM EDT by NWS Wilmington OH
      * WHAT...Flash flooding caused by excessive rainfall continues to be
possible.

* WHERE...The following counties, in Indiana, Dearborn, Fayette,
Franklin, Ohio, Ripley, Switzerland, Union and Wayne, the
following countie
  - (2026-05-27) [Severe] Special Marine Warning: Special Marine Warning issued May 27 at 8:41AM CDT until May 27 at 9:45AM CDT by NWS Brownsville TX
      SMWBRO

The National Weather Service in Brownsville has issued a

* Special Marine Warning for...
Coastal waters from Baffin Bay to Port Mansfield TX out 20 NM...
Coastal waters from Port Mansfield TX to the Rio Grande R
  - (2026-05-27) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued May 27 at 8:38AM CDT until May 27 at 10:00AM CDT by NWS Memphis TN
      * WHAT...Visibility one-quarter mile or less in dense fog.

* WHERE...Dunklin, Clay, Greene, Pemiscot, and Lake.

* WHEN...Until 10 AM CDT this morning.

* IMPACTS...Low visibility could make driving conditions hazardous
  - (2026-05-27) [Severe] Flood Warning: Flood Warning issued May 27 at 8:37AM CDT until May 28 at 6:30PM CDT by NWS Corpus Christi TX
      ...The Flood Warning is extended for the following rivers in Texas...

Aransas River Near Skidmore affecting Bee County.

For the Aransas River...including Skidmore...Minor flooding is
forecast.

* WHAT...Minor flooding 

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 29 new of 29 total
  - (2026-05-27) [crypto] BTC: $75,004.0000  (24h: -2.78%)
      price=$75004  mcap=$1,500,730,298,868  vol24=$39,901,853,213  chg24=-2.7758905992592764%
  - (2026-05-27) [crypto] ETH: $2,063.3300  (24h: -2.90%)
      price=$2063.33  mcap=$248,536,271,166  vol24=$15,264,668,207  chg24=-2.898448730738242%
  - (2026-05-27) [crypto] USDT: $0.9983  (24h: -0.06%)
      price=$0.998271  mcap=$189,258,500,105  vol24=$66,355,634,701  chg24=-0.0581893178842186%
  - (2026-05-27) [crypto] USDC: $0.9997  (24h: -0.01%)
      price=$0.999727  mcap=$76,342,680,047  vol24=$18,550,507,940  chg24=-0.00888500031778332%
  - (2026-05-27) [crypto] BNB: $651.6500  (24h: -1.70%)
      price=$651.65  mcap=$87,718,065,950  vol24=$965,810,525  chg24=-1.7036920847424666%
  - (2026-05-27) [crypto] SOL: $83.5700  (24h: -2.21%)
      price=$83.57  mcap=$48,331,425,186  vol24=$2,564,046,938  chg24=-2.211157868011714%
  - (2026-05-27) [crypto] XRP: $1.3200  (24h: -2.45%)
      price=$1.32  mcap=$81,717,489,569  vol24=$1,642,147,413  chg24=-2.4455391645771094%
  - (2026-05-27) [crypto] DOGE: $0.1012  (24h: -1.44%)
      price=$0.101162  mcap=$15,613,183,076  vol24=$732,116,725  chg24=-1.4435499879893567%

### Government Action: Sanctions + Procurement + Foreign Agents — 33 new of 33 total
  - (2026-05-27) [ofac_recent error] HTTPError
      404 Client Error: Not Found for url: https://ofac.treasury.gov/recent-actions/feed
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [dcsca error] HTTPError
      403 Client Error: Forbidden for url: https://www.dsca.mil/press-media/major-arms-sales
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR
  - (2026-05-27) [USASpending] $10,494,204,426 → THE BOEING COMPANY: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFA
      Agency: National Aeronautics and Space Administration.  Description: PROVIDE DEVELOPMENTAL HARDWARE AND TEST ARTICLES, AND MANUFACTURE AND ASSEMBLE ARES I UPPER STAGES. THE UPPER STAGE (US) ELEMENT IS AN INTEGRAL PART OF

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 3 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-26) [CA3] United States v. Paul Girard

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) 497J - FT 12960 (0002112763) (Filer)
      filed 2026-05-27 14:01 UTC — Filed: 2026-05-27 AccNo: 0001445546-26-003985 Size: 2 KB
  - (2026-05-27) 497J - FT 12949 (0002111260) (Filer)
      filed 2026-05-27 14:00 UTC — Filed: 2026-05-27 AccNo: 0001445546-26-003984 Size: 2 KB
  - (2026-05-27) 497J - FT 12948 (0002111257) (Filer)
      filed 2026-05-27 14:00 UTC — Filed: 2026-05-27 AccNo: 0001445546-26-003983 Size: 2 KB
  - (2026-05-27) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-05-27 14:00 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014094 Size: 665 KB
  - (2026-05-27) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-05-27 14:00 UTC — Filed: 2026-05-27 AccNo: 0001918704-26-014094 Size: 665 KB
  - (2026-05-27) 497J - FT 12916 (0002109427) (Filer)
      filed 2026-05-27 13:59 UTC — Filed: 2026-05-27 AccNo: 0001445546-26-003982 Size: 2 KB
  - (2026-05-27) [Dove Nicholas Kirk] Form 4 (Reporting)
      filed 2026-05-27 13:59 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001193125-26-240757 Size: 4 KB
  - (2026-05-27) [Heritage Global Inc.] Form 4 (Issuer)
      filed 2026-05-27 13:59 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001193125-26-240757 Size: 4 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [United Arab Emirates] Trump Under Pressure to End Costly Iran War as Ceasefire Strains and US Public Doubts Grow
      domain: gulfnews.com · language: English · tone: 
  - (2026-05-27) [United States] Man dead after getting hit by a truck and a VIA bus after running into highway
      domain: news4sanantonio.com · language: English · tone: 
  - (2026-05-27) [Canada] Lululemon reaches agreement with founder to appoint some of his board nominees
      domain: niagarafallsreview.ca · language: English · tone: 
  - (2026-05-27) [United Kingdom] Minister rejects Blair triple lock warning as ex - PM calls for  coherent plan  
      domain: yourlocalguardian.co.uk · language: English · tone: 
  - (2026-05-27) [Cambodia] Good points : Rewilding of Angkor expands with reintroduction of porcupines
      domain: phnompenhpost.com · language: English · tone: 
  - (2026-05-27) [Australia] Why Hollywood rejected star :  Lost everything  
      domain: geelongadvertiser.com.au · language: English · tone: 
  - (2026-05-27) [United States] Prenatal forever chemical exposure may affect puberty timing in children
      domain: news-medical.net · language: English · tone: 
  - (2026-05-27) [United States] For far - right extremists , the rise of a new enemy : women
      domain: kbia.org · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 0 new of 0 total
  (no new items today)

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 13 total
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 14 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $2,106,820 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,958,878 · resolves 2026-12-31
  - (2026-05-27) Will Senegal win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,841,506 · resolves 2026-07-20
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,687,143 · resolves 2026-07-20
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX (BO3) - LCK Rounds 1-2
      yes price: 100% · 24h volume: $1,670,283 · resolves 2026-05-27
  - (2026-05-27) Will Barack Obama win the 2028 Democratic presidential nomination?
      yes price: 1% · 24h volume: $1,143,369 · resolves 2028-11-07
  - (2026-05-27) LoL: BNK FEARX vs Kiwoom DRX - Game 1 Winner
      yes price: 100% · 24h volume: $990,777 · resolves 2026-05-27
  - (2026-05-27) Will Belgium win the 2026 FIFA World Cup?
      yes price: 2% · 24h volume: $905,264 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Marginal Revolution] Can liberals be pacifists?
      This is mostly a podcast about Benjamin Britten, and in particular his War Requiem, with Rebecca Lowe (former singer and conductor, in addition to philosopher and also her current role at Mercatus). Here is the YouTube, 
  - (2026-05-26) [Marginal Revolution] *How to Win a Trade War: An Optimistic Guide to an Anxious Global Economy*
      That is the new Soumaya Keynes book, out today.  I was happy to have blurbed this book, and here is an essay, on export restrictions, based on the book.
The post *How to Win a Trade War: An Optimistic Guide to an Anxious
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=0, 7d-median=0, 14d-median=0
- state_news: today=581, 7d-median=581, 14d-median=581
- local_news: today=133, 7d-median=133, 14d-median=133
- foreign_news: today=885, 7d-median=885, 14d-median=885
- chinese_internal: today=4, 7d-median=4, 14d-median=4
- paper_bets: today=140, 7d-median=140, 14d-median=140
- weather: today=123, 7d-median=123, 14d-median=123
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=29, 7d-median=29, 14d-median=29
- sanctions_procurement: today=33, 7d-median=33, 14d-median=33
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=0, 7d-median=8, 14d-median=8
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=13, 7d-median=13, 14d-median=13
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*