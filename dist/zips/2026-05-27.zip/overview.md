# WORLDSCOPE morning brief — 2026-05-27

## Headline
5264 new items across 37 section(s).

## What changed today
### U.S. Federal Action — 19 new of 21 total
  - (2026-05-27) Event Data Recorders
  - (2026-05-27) Emergency Presidential Determination on Refugee Admissions for Fiscal Year 2026
  - (2026-05-27) Control of Communicable Diseases; Foreign Quarantine
      The Centers for Disease Control and Prevention (CDC) within the U.S. Department of Health and Human Services (HHS) issues this interim final rule with request for comments to amend its Foreign Quarantine Regulations. Thi
  - (2026-05-27) Regulatory Program Fees and Water Charges Rates
      Notice is provided of the Commission's regulatory program fees and schedule of water charges for the fiscal year beginning July 1, 2026.
  - (2026-05-27) Revisions to the Blanket Certificate Program
      The Federal Energy Regulatory Commission (Commission) proposes to revise its blanket certificate regulations to expand the scope and scale of projects that interstate natural gas pipelines may construct without a case-sp
  - (2026-05-27) Security Zones; Vessels Carrying Dangerous Cargo, Corpus Christi and La Quinta Ship Channels, Corpus Christi, TX
      The Coast Guard is establishing a security zone around vessels carrying Certain Dangerous Cargos (CDCs), for which the Captain of the Port, Corpus Christi deems enhanced security measures are necessary on a case-by-case 
  - (2026-05-27) Airworthiness Directives; Airbus Canada Limited Partnership (Type Certificate Previously Held by C Series Aircraft Limited Partnership (CSALP); Bombardier, Inc.) Airplanes
      The FAA is superseding Airworthiness Directive (AD) 2024-04- 06, which applied to certain Airbus Canada Limited Partnership Model BD-500-1A10 and BD-500-1A11 airplanes. AD 2024-04-06 required repetitive operational check
  - (2026-05-27) Airworthiness Directives; Airbus SAS Airplanes
      The FAA is adopting a new airworthiness directive (AD) for certain Airbus SAS Model A320-251N, -252N, -253N, -271N, -272N, and - 273N airplanes. This AD was prompted by a detected deviation to the manufacturing process o

### State Legislative Action — 1 new of 1 total
  - (2026-05-27) [ingest error] Oklahoma: ReadTimeout
      HTTPSConnectionPool(host='v3.openstates.org', port=443): Read timed out. (read timeout=45)

### State-Level News — 728 new of 728 total
  - (2026-05-27) [Alabama] World Trade Month
      Download
  - (2026-05-25) [Alabama] Governor Kay Ivey’s Memorial Day Message
      Governor Ivey released a video message for Memorial Day ahead of the holiday weekend, honoring America&#8217;s fallen service members and calling on Alabamians to live worthy of their sacrifice. (Governor&#8217;s Office,
  - (2026-05-27) [California] Governor Newsom signs legislation to further protect California elections from interference and intimidation
  - (2026-05-27) [California] Governor Newsom proclaims Small Business Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-26) [California] Governor Newsom signs legislation 5.26.2026
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2024/05/6C94C750-0DF8-46C6-A8E3-00EA4F1B1ADD-150x150.jpeg" class="attachment-thumbnail size-thumbnail wp-post-image" alt="" decoding="async" />
  - (2026-05-26) [California] Governor Newsom proclaims Older Californians Month
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn
  - (2026-05-25) [California] Governor Newsom secures Presidential Emergency Declaration approval for Orange County hazmat response
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2026/05/Governor-Newsom-secures-Presidential-Emergency-Declaration-approval-for-Orange-County-hazmat-response-SEO-GFX-v2-150x150.png" class="at
  - (2026-05-25) [California] Governor Newsom proclaims Memorial Day
      <img width="150" height="150" src="https://www.gov.ca.gov/wp-content/uploads/2019/02/GovernorSeal-Blue.png?resize=150,150" class="attachment-thumbnail size-thumbnail wp-post-image" alt="GovernorSeal-Blue." decoding="asyn

### Local News: St. Louis + Atlanta — 225 new of 225 total
  - (2026-05-27) [St. Louis] Missouri Supreme Court rejects challenge to governor’s power to call special sessions
  - (2026-05-27) [St. Louis] St. Louis economic development panel takes aim at data center critics, calls many concerns ‘myths’
  - (2026-05-27) [St. Louis] St. Louis police promise transparency as oversight board approves drone program
  - (2026-05-27) [St. Louis] Abortion-rights coalition launches campaign against Missouri’s Amendment 3
  - (2026-05-27) [St. Louis] Plan to redevelop downtown St. Louis riverfront moves ahead despite fire that destroyed key buildings
  - (2026-05-27) [St. Louis] Immigrants held by ICE are neglected at the Ste. Genevieve County jail, lawmakers say
  - (2026-05-26) [St. Louis] Tornado recovery advocates and downtown investors are divided on Rams settlement spending
  - (2026-05-26) [St. Louis] Missouri lawmakers likely will try property tax reform again after failing this year

### International News + Multilateral Institutions — 886 new of 886 total
  - (2026-05-27) [Global] One in six young people will not be in work or training in five years without action, report warns
      A major review examining the causes of rising youth unemployment says getting on the career ladder is now "out of reach" for many.
  - (2026-05-27) [Global] Energy bills to rise for millions as impact of Iran war hits
      A household using a typical amount of energy will pay £221 a year more, under the regulator's new price cap.
  - (2026-05-27) [Global] How you can save money on your energy bill
      Experts say action now can save money when the pinch comes this winter.
  - (2026-05-27) [Global] 'Bullying' and 'overbearing' behaviour behind abrupt BP chairman removal
      BP declined to comment on whether bullying behaviour was part of the reason for his immediate dismissal.
  - (2026-05-27) [Global] Booming AI chip demand helps create two new $1tn club members
      SK Hynix and Micron are the latest tech firms to join the growing list of stocks with mega valuations.
  - (2026-05-27) [Global] Ferrari shares slump after it unveils first fully electric car
      The new Luce model has divided opinion on social media, and comes despite intense pressure from Chinese EV makers.
  - (2026-05-26) [Global] Instagram betting ads featuring Kane and Haaland banned
      The advertising watchdog said the adverts featuring top footballers had a strong appeal to under-18s.
  - (2026-05-27) [Global] Champion ethical hacker warns AI tools like Mythos will make competing harder
      Chompie, one of the world's tops ethical hackers, says AI like Claude Mythos will make it harder for people like her to compete.

### Chinese Internal News — 288 new of 288 total
  - (2026-05-27) [TITLE: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3OD] (zh: 电信诈骗版图南迁 自柬埔寨转向印尼 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBCMkxteGRYR0RfX3h5ZWpia3kwZDRhQTVuQ3lWWGYwRHB6YkFiYWFXcTJraVY0a25EQTQ4YUxLQ3pJcUF6ZFl3ODJlTk9Hc1N4VEUxUEdRUzM4NzBDMThV?oc=5" target="_blank">电信诈骗版图南迁 自柬埔寨转向印尼</
  - (2026-05-27) [TITLE: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q] (zh: 跨省履新仅8个月 “70后”高官李伟江西落马 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFBEUGZ5enRtQTg4UnlzM1dhRDhSUHlRdEw2dUUwN0VLYjI5NDVRN1EtMjNFWGt5el9MOERpbVg1aFA4SmM4Q0t2MlR5Z0hQX2pYTl90ZWl0R3BBbXVFUE1r?oc=5" target="_blank">跨省履新仅8个月 “70后”高官李伟江
  - (2026-05-27) [TITLE: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNk] (zh: 深圳一快速路段发生火灾 警方称无人受伤被困 - china.caixin.com)
      <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9kZmswZUJSb1A5dUJqUHJRQTRjREEyQmxXVFJGeHkxLUJOUTgtT1M4eXdHRGpWeW4yV2NaSkUyV2pHS1pTNkd4djhVSzQ2dV96bmZwVzhvLUc3TW1ZTEQ0?oc=5" target="_blank">深圳一快速路段发生火灾 警方称无人受伤
  - (2026-05-26) [TITLE: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGh] (zh: 财经早知道｜深圳常住人口首破1800万，增量领跑全国 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBadGE0eHB4eXJ4YVhFQkd6NXNxcmZXQ2RDbUN1M2tMaUhXbnYxSUl1MEVGU1duSjNpTWEySHhKXzFkc0pDUU5lU0xyUGhBenBsLXFZOVJxRl9xSmVnZHJHMUNB?oc=5" target="_blank">财经早知道｜深圳常住人口首破1
  - (2026-05-27) [TITLE: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHd] (zh: AI、石化产业链带动4月工业利润高增24.7% 创两年多新高 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1VcXl0OFV6VzdVNE5ha25yTk5WRFdORUl6OHJaYmZJSDVKNVhacFdGT1dFSUJKLWNuZHd4VDR2Wkl1bW9PTndMNHdyandPQXJnQW5YN2RmdU03U1FhOVFYV1Zn?oc=5" target="_blank">AI、石化产业链带动4月工业利
  - (2026-05-25) [TITLE: 最新封面报道｜争夺估值王 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjl] (zh: 最新封面报道｜争夺估值王 - 财新周刊)
      <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE80c0Y2MzRfeHVCRUJzWVR5ck1peHRxdXNXZnpsQUlxRzVDeGdoSjc1dDFMVjZybFdORHZwbTd2M25JYlB5aHhVNjl0UjhrdElnYmJXVjlCYlZvR05ONEE2Mg?oc=5" target="_blank">最新封面报道｜争夺估值王</a>&
  - (2026-05-26) [TITLE: 宇树科技科创板IPO将于6月1日上会 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE12bDdQa3Q4SVRSMlEtcWI1QXZSNWpvY0xSS3hrTnFaLXhCakRjeVBYVS1jWDEyYU1aLU16UWpESFdITXJDR0VKaWJOZk02OFNZT0I] (zh: 宇树科技科创板IPO将于6月1日上会 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE12bDdQa3Q4SVRSMlEtcWI1QXZSNWpvY0xSS3hrTnFaLXhCakRjeVBYVS1jWDEyYU1aLU16UWpESFdITXJDR0VKaWJOZk02OFNZT0I4b1M3WGJkYjhMWFE?oc=5" target="_blank">宇树科技科创板IPO将于6月1日上会</
  - (2026-05-27) [TITLE: 全国31省份“十五五”规划纲要全部发布 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9WMXVXTjZnR1BidGRCMVlGelR6QnVJVnF1TU9ldkVELVJjLVgtMVhBQ0lpZllCV0xrZW9GNUNHQlVqMElxLS1KWVhkTXJWZ2RmWE] (zh: 全国31省份“十五五”规划纲要全部发布 - 财新)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9WMXVXTjZnR1BidGRCMVlGelR6QnVJVnF1TU9ldkVELVJjLVgtMVhBQ0lpZllCV0xrZW9GNUNHQlVqMElxLS1KWVhkTXJWZ2RmWE1YMzNEeU9lWVJSZ0E?oc=5" target="_blank">全国31省份“十五五”规划纲要全部发布<

### Russian Internal News (state + in-exile) — 1020 new of 1020 total
  - (2026-05-27) [TITLE: Детская площадка в Херсоне попала под обстрел России. Погиб мужчина, его жена и две дочери ранены | LEDE: <p>Вооруженные силы РФ обстреляли Корабельный район Херсона из реактивных систем залпов] (ru: Детская площадка в Херсоне попала под обстрел России. Погиб мужчина, его жена и )
      <p>Вооруженные силы РФ обстреляли Корабельный район Херсона из реактивных систем залпового огня, сообщает 27 мая «Суспiльне», ссылаясь на местные власти.<p>
  - (2026-05-27) [TITLE: Замглавы «Уралвагонзавода» арестован по делу о растрате при выполнении гособоронзаказа | LEDE: <p>Басманный районный суд Москвы отправил под стражу на два месяца заместителя гендиректора концер] (ru: Замглавы «Уралвагонзавода» арестован по делу о растрате при выполнении гособорон)
      <p>Басманный районный суд Москвы отправил под стражу на два месяца заместителя гендиректора концерна «Уралвагонзавод» по спецтехнике Дмитрия Семизорова, которого обвиняют в растрате при выполнении государственного оборон
  - (2026-05-27) [TITLE: Судебные приставы взыскали 300 тысяч рублей с Артемия Лебедева, назвавшего Лигу безопасного интернета «****** [фигней] на палке» | LEDE: <p>Руководитель Лиги безопасного интернета Екатерина Миз] (ru: Судебные приставы взыскали 300 тысяч рублей с Артемия Лебедева, назвавшего Лигу )
      <p>Руководитель Лиги безопасного интернета Екатерина Мизулина сообщила в телеграме 27 мая, что судебные приставы взыскали с блогера Артемия Лебедева 300 тысяч рублей компенсации по иску Мизулиной о защите чести и достоин
  - (2026-05-27) [TITLE: Руслана Кутаева (он оправдывал «убийства чести») оставили в платформе российской оппозиции при ПАСЕ | LEDE: <p>Бюро Парламентской ассамблеи Совета Европы решило оставить в составе платформы рос] (ru: Руслана Кутаева (он оправдывал «убийства чести») оставили в платформе российской)
      <p>Бюро Парламентской ассамблеи Совета Европы решило оставить в составе платформы российской оппозиции при ПАСЕ общественного деятеля из Чечни Руслана Кутаева, который оскорблял ЛГБТК-людей и оправдывал «убийства чести» 
  - (2026-05-27) [TITLE: «Вы пользуетесь Wi-Fi, который я создал, VPN, который я создал. Вы пользуетесь экстремистскими вещами?». Из России уехал пионер IT-индустрии Александр Галицкий, у которого отобрали все имуществ] (ru: «Вы пользуетесь Wi-Fi, который я создал, VPN, который я создал. Вы пользуетесь э)
      <p>71-летний Александр Галицкий — советский конструктор, который стал одним из первых успешных технопредпринимателей и венчурных инвесторов России. Он много лет вел бизнес в США, Восточной Европе и России. Но на фоне кон
  - (2026-05-27) [TITLE: Росстат сообщил, что долг по зарплатам в России за месяц вырос на треть. Государственным СМИ рекомендовали «максимально игнорировать» эти данные | LEDE: <p>Суммарная задолженность по зарплате в] (ru: Росстат сообщил, что долг по зарплатам в России за месяц вырос на треть. Государ)
      <p>Суммарная задолженность по зарплате в России на конец апреля составила 2,9 миллиарда рублей, что на 750 миллионов рублей больше (+35,2%), чем в марте, следует из данных Росстата, представленных 27 мая.<p>
  - (2026-05-27) [TITLE: Участница «Фракции Красной армии» Даниэла Клетте получила 13 лет тюрьмы за грабежи. Она больше 30 лет скрывалась от полиции — и жила в центре Берлина | LEDE: <p>Суд в Вердене приговорил бывшую ] (ru: Участница «Фракции Красной армии» Даниэла Клетте получила 13 лет тюрьмы за грабе)
      <p>Суд в Вердене приговорил бывшую участницу немецкой леворадикальной террористической организации «Фракция Красной армии» (RAF) Даниэлу Клетте к 13 годам лишения свободы за участие в серии вооруженных ограблений суперма
  - (2026-05-27) [TITLE: В России массово задерживают муфтиев — по обвинениям от подкупа до терроризма. Это кампания против главы Духовного управления мусульман Равиля Гайнутдина, считают эксперты | LEDE: <p>В мае из р] (ru: В России массово задерживают муфтиев — по обвинениям от подкупа до терроризма. Э)
      <p>В мае из разных регионов России поступили сообщения о задержаниях и арестах муфтиев и других мусульманских религиозных и общественных деятелей. Некоторых из них обвиняют по террористической статье — в сотрудничестве с

### Ukrainian Internal News (national + local Kyiv) — 138 new of 138 total
  - (2026-05-27) [feed error] LIGA.net: HTTPError
      403 Client Error: Forbidden for url: https://www.liga.net/news/rss.xml
  - (2026-05-28) [TITLE: Сибіга: Саме зараз Європа повинна діяти рішуче для наближення миру в Україні | LEDE: Глава МЗС закликав Європу діяти рішуче на тлі зміни динаміки війни.] (uk: Сибіга: Саме зараз Європа повинна діяти рішуче для наближення миру в Україні)
      Глава МЗС закликав Європу діяти рішуче на тлі зміни динаміки війни.
  - (2026-05-28) [TITLE: Розбирали знайдений БпЛА: на Чернігівщині загинули двоє фермерів | LEDE: Радник міністра оборони Сергій Бескрестнов ("Флеш") повідомив, що в Чернігівській області загинули двоє фермерів, які зн] (uk: Розбирали знайдений БпЛА: на Чернігівщині загинули двоє фермерів)
      Радник міністра оборони Сергій Бескрестнов ("Флеш") повідомив, що в Чернігівській області загинули двоє фермерів, які знайшли в полі ударний БпЛА і вирішили його розібрати.
  - (2026-05-28) [TITLE: Трамп зробив ще одну заяву про угоду з Іраном | LEDE: Трамп натякнув на "Авраамові угоди", коли говорив про перемир'я з Іраном.] (uk: Трамп зробив ще одну заяву про угоду з Іраном)
      Трамп натякнув на "Авраамові угоди", коли говорив про перемир'я з Іраном.
  - (2026-05-27) [TITLE: Україна перед "Рамштайном" узгодила з партнерами пріоритети: ППО, снаряди та дрони | LEDE: Міністр оборони Михайло Федоров провів розмову зі своїми колегами з Німеччини та Великої Британії Бори] (uk: Україна перед "Рамштайном" узгодила з партнерами пріоритети: ППО, снаряди та дро)
      Міністр оборони Михайло Федоров провів розмову зі своїми колегами з Німеччини та Великої Британії Борисом Пісторіусом і Джоном Гілі, а також із генсекретарем НАТО Марком Рютте, в ході якої йшлося про ключові пріоритети У
  - (2026-05-27) [TITLE: Понад 250 бойових зіткнень відбулось на фронті з початку доби — Генштаб | LEDE: Від початку доби 27 травня на фронті відбулось 256 бойових зіткнень.] (uk: Понад 250 бойових зіткнень відбулось на фронті з початку доби — Генштаб)
      Від початку доби 27 травня на фронті відбулось 256 бойових зіткнень.
  - (2026-05-27) [TITLE: Трамп: США слідкуватимуть за Ормузькою протокою | LEDE: ] (uk: Трамп: США слідкуватимуть за Ормузькою протокою)
  - (2026-05-27) [TITLE: По всій Україні оголошували повітряну тривогу через зліт МіГ-31К | LEDE: Увечері 27 травня по всій території України оголосили повітряну тривогу через зліт МіГ-31К.] (uk: По всій Україні оголошували повітряну тривогу через зліт МіГ-31К)
      Увечері 27 травня по всій території України оголосили повітряну тривогу через зліт МіГ-31К.

### Ukraine Theater (total-war monitoring) — 394 new of 394 total
  - (2026-05-27) [DeepStateMap] frontline snapshot, 524 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-05-27) [Air alerts error] HTTPError (set ALERTS_IN_UA_TOKEN for v2)
      401 Client Error: Unauthorized for url: https://api.alerts.in.ua/v1/alerts/active.json
  - (2026-05-25) [Liveuamap] Russian FM Lavrov informed State Secretary Rubio that Russia will intensify strikes on Kyiv. Lavrov urged Rubio to evacuate U.S. citizens and diplomatic staff from Kyiv Moskva, Moscow - Ukraine Interactive map - Ukraine Latest news on live 
      <a href="https://news.google.com/rss/articles/CBMikgFBVV95cUxQTkE1MmhVLXlxWmVTMW45QlppeVlWOVFva1ZNbUpRdU85eksxb0U3dS1qdW52bFlOWlhLNTQ3aHdKMWdzUFRfbXBwRzF5YW1rdklmQXpoRE5qQ2x1eHk0MVl4YWtTQmhnVEcxcmpGUF9xb0JuOXllcDY5UDNsXz
  - (2026-05-26) [Liveuamap] The U.S. Navy has resumed escorting ships through the Strait of Hormuz under a renewed “Project Freedom” mission. A Greek supertanker carrying two million barrels of crude was recently guided through the route after being stranded in the Gu
      <a href="https://news.google.com/rss/articles/CBMilwFBVV95cUxPaW5lLXY3NUJLY0ItLUJxZThHc2M4c1ExQjFYVzNrQUlUZENnZlppel9mc3dMUTRoem1LUllkT3liOTFCeGgwX0JZbTVvdjRrWUJrRUh2cnBWS1ZhOEpzZGFHX3M4UWFvdUdkLV9ERU1vcjFnYmVVd0Zza1VaRz
  - (2026-05-27) [Liveuamap] Explosions were reported at the airbase in Voronezh - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxNZHgyQi1oNThuX1BJa2lEdHRaTERPWVREQkF1RE5MUTQ5WUhRQjJha0RYRDhTeFQyOWJoU1k4aW42V0RZNXpRRTdUUUdzYWdnUXRzRThhTkNkUkdZRm1BbE9qVWhNeFVORGh4Z2tQcENGajlqSWxwbVltZ1N0V1
  - (2026-05-26) [Liveuamap] Amal Shehadeh: The Israeli army is operating north of the yellow line and making extensive preparations to pursue field commanders in Nabatieh. - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMingFBVV95cUxPNzhSWEFycm1vYjVqREFsUHhpWXdwc3Z2ck1STzBOZmRlVDZ5MUwyYmdmRmlWMHFOUkh5THNmVjRCX1NWQzVPSkJDNzh1S2NtUTlibnlqc0hPRU0zZlhZUHR4Y2FEZ1pqSjNmd2tSY0hpZDA4ckFsZUhmYy1aem
  - (2026-05-27) [Liveuamap] President Zelensky sent a letter to President Trump and to Congress asking for urgent supply of Patriot interceptors - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMilgFBVV95cUxQaDZhbTFQc0FlTzNaSWxIa1k0R0g2LWFIZnN0REZieU9IRUNIRmswNXRqMEV6OVJTTHdWWFR6Q2k5T3dpTjVfb2JjQk44eGJsaWRXV3RhWmdFM1RxZ1VVdDhmajg2ZDlBVnNQREFYSW1uSG42YUp6VUwyeGFhT0
  - (2026-05-27) [Liveuamap] The Israelis notified the Trump administration that they escalate their attacks on Lebanon following a drone attack by Hezbollah tonight Tel Aviv-Yafo, Tel Aviv District - Lebanon news on live map - Liveuamap
      <a href="https://news.google.com/rss/articles/CBMimgFBVV95cUxPbkJMUHd6ak9uQzR0T1hwQzNvbzZFZDF2SHlQTVdKVFdKMy1vUjBLYXJ0YnJmWU9hS3haNC1MNF9NUlZnbkZzaDg2N3c2R1N1TVd5ODRkZ3BycDBMOW55cXpWU2d0ZC1aRTZYT1ZWY1l0YjdyS0libjJ2ajFZQW

### Paper Trading Scorecard — 136 new of 136 total
  - (2026-05-27) [Polymarket] Fed rate cut by September 2026 meeting?
      This market will resolve to “Yes” if the upper bound of the target federal funds rate is decreased at any point between December 16, 2025 and the completion of the Federal Open Market Committee (FOMC) meeting for Septemb
  - (2026-05-27) [Polymarket] US strike on Colombia by December 31?
      This market will resolve to "Yes" if a US-initiated drone, missile, or air strike on the soil of Colombia is announced or credibly reported to have occurred by the listed date ET. Otherwise, this market will resolve to "
  - (2026-05-27) [Polymarket] Will Anže Logar be the next Prime Minister of Slovenia?
      Parliamentary elections are scheduled to be held in Slovenia on March 22, 2026.

This market will resolve to the next individual who is officially elected by the National Assembly (Državni zbor) and sworn in as Prime Min
  - (2026-05-27) [Polymarket] Will Microsoft be the second-largest company in the world by market cap on May 31?
      This market will resolve to the second-largest company in the world by market cap on May 31, 2026, as of market close.

The resolution source for this market will be a consensus of credible reporting.
  - (2026-05-27) [Polymarket] Will Raphaël Glucksmann win the 2027 French presidential election?
      The next French presidential election is currently expected to be held around April 2027.  This market pertains to the outcome of the next French presidential election, regardless of whether it follows the scheduled end 
  - (2026-05-27) [Polymarket] Israeli parliament dissolved by May 31?
      This market will resolve to "Yes" if the sitting Israeli Knesset (Israel's parliament), as of this market's inception, is dissolved between market creation and May 31, 2026, 11:59 PM ET. Otherwise, this market will resol
  - (2026-05-27) [Polymarket] Will Jared Hudson be the Republican nominee for Senate in Alabama?
      This market will resolve according to the winner of the Republican Primary for United States Senator from Alabama.

If no 2026 Alabama Republican Senate Primary takes place, this market will resolve to "Other".

The reso
  - (2026-05-27) [Polymarket] Will Solana dip to $10 in May?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for SOL/USDT during the month specified in the title (from 00:00 AM ET on the first day to 11:59 PM ET on the last), has a final Low price equa

### U.S. Weather + Severe / Climate Outlooks — 155 new of 155 total
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 7:13PM EDT until May 27 at 8:15PM EDT by NWS Blacksburg VA
      SVRRNK

The National Weather Service in BLACKSBURG has issued a

* Severe Thunderstorm Warning for...
Northwestern Appomattox County in central Virginia...
Northern Campbell County in central Virginia...
Central Bedford 
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 6:12PM CDT until May 27 at 6:45PM CDT by NWS La Crosse WI
      At 612 PM CDT, a severe thunderstorm was located 8 miles northeast of
Shortville, or 9 miles east of Neillsville, moving south at 20 mph.

HAZARD...Quarter size hail.

SOURCE...Radar indicated.

IMPACT...Damage to vehicl
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 7:12PM EDT by NWS Charleston WV
      At 712 PM EDT, Doppler radar was tracking a strong thunderstorm near
Grayson, moving southeast at 25 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IMPACT...Gusty winds could knock 
  - (2026-05-27) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-05-27) [Moderate] Special Weather Statement: Special Weather Statement issued May 27 at 4:07PM PDT by NWS San Francisco CA
      At 407 PM PDT, Doppler radar was tracking a strong thunderstorm 7
miles north of Jamesburg, moving south at 15 mph.

HAZARD...Wind gusts up to 40 mph and pea size hail.

SOURCE...Radar indicated.

IMPACT...Gusty winds co
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 7:06PM EDT until May 27 at 7:30PM EDT by NWS Tampa Bay Ruskin FL
      SVRTBW

The National Weather Service in Ruskin has issued a

* Severe Thunderstorm Warning for...
Southern Sumter County in central Florida...
Eastern Pasco County in west central Florida...
Southeastern Hernando County 
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 7:05PM EDT until May 27 at 7:15PM EDT by NWS Blacksburg VA
      The storm which prompted the warning has weakened below severe
limits, and no longer poses an immediate threat to life or property.
Therefore, the warning will be allowed to expire.  However, gusty
winds are still possib
  - (2026-05-27) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued May 27 at 7:04PM EDT until May 27 at 7:45PM EDT by NWS Raleigh NC
      At 703 PM EDT, a severe thunderstorm was located near Halifax, moving
southeast at 30 mph.

HAZARD...60 mph wind gusts and quarter size hail.

SOURCE...Radar indicated.

IMPACT...Hail damage to vehicles is expected. Expe

### Macro indicators — latest values (FRED) — 0 new of 0 total
  (no new items today)

### Markets snapshot (Finnhub) — 0 new of 0 total
  (no new items today)

### Global Markets: FX + Bonds + Commodities + Equities + Crypto — 79 new of 79 total
  - (2026-05-27) [fx] USD/EUR: 0.859651
      1 USD = 0.859651 EUR
  - (2026-05-27) [fx] USD/GBP: 0.743251
      1 USD = 0.743251 GBP
  - (2026-05-27) [fx] USD/JPY: 159.232868
      1 USD = 159.232868 JPY
  - (2026-05-27) [fx] USD/CHF: 0.785427
      1 USD = 0.785427 CHF
  - (2026-05-27) [fx] USD/CAD: 1.380782
      1 USD = 1.380782 CAD
  - (2026-05-27) [fx] USD/AUD: 1.394958
      1 USD = 1.394958 AUD
  - (2026-05-27) [fx] USD/NZD: 1.712118
      1 USD = 1.712118 NZD
  - (2026-05-27) [fx] USD/CNY: 6.798706
      1 USD = 6.798706 CNY

### Government Action: Sanctions + Procurement + Foreign Agents — 95 new of 95 total
  - (2026-05-21) [OFAC] Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE8yRW9QLWNVZXY3bkpqY0dhYkVidUNEYXVIbkw2Ukc2ZW82NXAtZmU3b2xiTGltalVEWnFGeUZYRzhiSU44MGl3QTVwWTRsaWNNQnFOTXBYSXFuQ3ZnY3c?oc=5" target="_blank">Counter Terrorism De
  - (2026-05-20) [OFAC] International Criminal Court-related Designation Removal - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9Ea293ZzJIMldMbWM4QndMbk5YVFZDX1B1RXQ5UmM0blB5YmR6THJHa3NLeHI3bVFrNmJya0VCcUpSMlp5dFM1T1lldWZ4MlBEMXpISkREbXNYWFNMRFY3bWlR?oc=5" target="_blank">International C
  - (2026-05-20) [OFAC] Counter Narcotics and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE00SUEzZjlGVDZYWVJCUWlDSWhpSzBUbzRKUE9pUkNDaUFJR1hDb1ppNHNISjJESjU2Vy1vSmVXOExZeUxCMnpJWVpMYnc0WEd2em0zeG9jTFMzYVJXTWc?oc=5" target="_blank">Counter Narcotics an
  - (2026-05-27) [BIS Entity List] page checksum 9b92c4bcb0d5
      Page content hash: 9b92c4bcb0d5. Compare with prior day's hash to detect updates.
  - (2026-05-27) [USASpending] $22,428,256,009 → THE BOEING COMPANY: INTERNATIONAL SPACE STATION
      Agency: National Aeronautics and Space Administration.  Description: INTERNATIONAL SPACE STATION
  - (2026-05-27) [USASpending] $17,305,145,475 → UCHICAGO ARGONNE, LLC: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF A
      Agency: Department of Energy.  Description: PERFORMANCE-BASED CONTRACT FOR MANAGEMENT AND OPERATION OF ARGONNE NATIONAL LABORATORY
  - (2026-05-27) [USASpending] $17,244,586,106 → BECHTEL NATIONAL, INC.: 
      Agency: Department of Energy.  Description: 
  - (2026-05-27) [USASpending] $14,860,934,880 → THE LELAND STANFORD JUNIOR UNIVERSITY: OPERATION AND MAINTENANCE                                   
      Agency: Department of Energy.  Description: OPERATION AND MAINTENANCE                                   LINEAR ACCELLERATOR

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-05-27) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 0 new of 30 total
  (no new items today)

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state
  - () [Antigua and Barbuda] head of state: Charles III
      position: Head of state · head of govt: Gaston Browne
  - () [Argentina] head of state: Javier Milei
      position: Head of state

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus
  - (2026-05-04) JOINT STOCK COMPANY GUTA-BANK (Company)
      source: au_dfat_sanctions, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: debarment, fin, fin.bank
  - (2026-05-04) ROYAL CARIBBEAN CRUISES LTD. (Company)
      source: us_sam_exclusions · country: us · topics: debarment, corp.public

### Court opinions of consequence (federal) — 5 new of 30 total
  - (2026-05-26) [SCOTUS] Margolin v. NAIJ
  - (2026-05-26) [CIT] ICON EV LLC v. United States
  - (2026-05-27) [CA1] Argueta Castillo v. Blanche
  - (2026-05-26) [CA3] United States v. Paul Girard
  - (2026-05-26) [CA4] Tony Messer v. Garrison Investment Group, LP

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-05-27) [Harrington Robert Arthur] Form 4 (Reporting)
      filed 2026-05-27 23:13 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001061983-26-000060 Size: 6 KB
  - (2026-05-27) [CYTOKINETICS INC] Form 4 (Issuer)
      filed 2026-05-27 23:13 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001061983-26-000060 Size: 6 KB
  - (2026-05-27) [HENDERSON JOHN T] Form 4 (Reporting)
      filed 2026-05-27 23:12 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001061983-26-000059 Size: 7 KB
  - (2026-05-27) [CYTOKINETICS INC] Form 4 (Issuer)
      filed 2026-05-27 23:12 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001061983-26-000059 Size: 7 KB
  - (2026-05-27) [Wisniewski Scott] Form 4 (Reporting)
      filed 2026-05-27 23:12 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001493152-26-025471 Size: 5 KB
  - (2026-05-27) [AST SpaceMobile, Inc.] Form 4 (Issuer)
      filed 2026-05-27 23:12 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001493152-26-025471 Size: 5 KB
  - (2026-05-27) [Kaye Edward M. MD] Form 4 (Reporting)
      filed 2026-05-27 23:11 UTC · role: Reporting — Filed: 2026-05-27 AccNo: 0001061983-26-000058 Size: 6 KB
  - (2026-05-27) [CYTOKINETICS INC] Form 4 (Issuer)
      filed 2026-05-27 23:11 UTC · role: Issuer — Filed: 2026-05-27 AccNo: 0001061983-26-000058 Size: 6 KB

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909

### World News (by country, top stories) — 0 new of 80 total
  (no new items today)

### GDELT GKG — themes / entities / watch areas — 0 new of 0 total
  (no new items today)

### MediaCloud — global news index (watch-area filtered) — 0 new of 0 total
  (no new items today)

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-05-27) [United States] Atour ( ATAT ) Q1 2026 Earnings Call Transcript
      domain: fool.com · language: English · tone: 
  - (2026-05-27) [United States] Monica Mourns Death of Father M . C . Arnold Jr . 
      domain: wbls.com · language: English · tone: 
  - (2026-05-27) [United States] California residents evacuated due to chemical tank threat return home but fears remain
      domain: clickondetroit.com · language: English · tone: 
  - (2026-05-27) [Canada] London test pilot school expands to North Bay , buys training jets
      domain: lfpress.com · language: English · tone: 
  - (2026-05-27) [United States] Teen Accused Of Killing Stepsister On Cruise Ship Avoids Jail During Trial
      domain: newsradio967.iheart.com · language: English · tone: 
  - (2026-05-27) [United States] 9 missing after Washington paper mill tank rupture and officials say there no hope of survivors
      domain: reflector.com · language: English · tone: 
  - (2026-05-27) [United States] The Young and the Restless Spoilers Friday , May 29 : Diane Disappearance – Kyle Scary News – Troublemaker Patty
      domain: celebdirtylaundry.com · language: English · tone: 
  - (2026-05-27) [Canada] Pilot error blamed for 2023 northwest B . C . fatal helicopter incident
      domain: hopestandard.com · language: English · tone: 

### ACLED conflict events — 0 new of 0 total
  (no new items today)

### Active fires near conflict zones (NASA FIRMS / VIIRS) — 0 new of 0 total
  (no new items today)

### Government & military aircraft airborne (OpenSky) — 23 new of 24 total
  - (2026-05-27) PAT087 (United States)
      icao24: adfedd · position: (21.3756, -157.9716) · alt: 2125m · 299km/h
  - (2026-05-27) CFC3274 (Canada)
      icao24: c2b35f · position: (44.1692, -77.4394) · alt: 693m · 264km/h
  - (2026-05-27) GAF197 (Germany)
      icao24: 3f7588 · position: (52.729, 10.259) · alt: 350m · 278km/h
  - (2026-05-27) NCR327 (United States)
      icao24: ab4ec6 · position: (34.5775, -91.4827) · alt: 12496m · 864km/h
  - (2026-05-27) CFC4046 (Canada)
      on ground · 68km/h
  - (2026-05-27) CFC4042 (Canada)
      icao24: c2b3f5 · position: (43.7428, -94.9292) · alt: 11277m · 843km/h
  - (2026-05-27) RCH466 (United States)
      on ground · 31km/h
  - (2026-05-27) NCR805 (United States)
      on ground

### ProMED-mail outbreak feed — 0 new of 0 total
  (no new items today)

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 16 total
  - (2026-05-27) CVE-2026-48027 · Nx Nx Console: Nx Console Embedded Malicious Code Vulnerability
      vendor: Nx · product: Nx Console · CISA remediation by 2026-06-10
  - (2026-05-27) CVE-2026-45321 · TanStack TanStack: TanStack Unspecified Vulnerability
      vendor: TanStack · product: TanStack · CISA remediation by 2026-06-10
  - (2026-05-27) CVE-2026-8398 · Daemon Daemon Tools Lite: Daemon Tools Lite Embedded Malicious Code Vulnerability
      vendor: Daemon · product: Daemon Tools Lite · CISA remediation by 2026-05-30
  - (2026-05-26) CVE-2026-48172 · LiteSpeed cPanel Plugin: LiteSpeed cPanel Plugin Privilege Escalation Vulnerability
      vendor: LiteSpeed · product: cPanel Plugin · CISA remediation by 2026-05-29

### Wikidata leader-roster changes (48h) — 0 new of 0 total
  (no new items today)

### ReliefWeb — humanitarian situation reports — 0 new of 0 total
  (no new items today)

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-05-27) Will Scotland win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $3,769,237 · resolves 2026-07-20
  - (2026-05-27) Will Reza Pahlavi lead Iran in 2026?
      yes price: 6% · 24h volume: $1,961,867 · resolves 2026-12-31
  - (2026-05-27) Tampa Bay Rays vs. Baltimore Orioles
      yes price: 12% · 24h volume: $1,939,786 · resolves 2026-06-03
  - (2026-05-27) US announces new Iran agreement/ceasefire extension by May 27?
      yes price: 1% · 24h volume: $1,833,177 · resolves 2026-05-27
  - (2026-05-27) Hurricanes vs. Canadiens
      yes price: 58% · 24h volume: $1,370,936 · resolves 2026-05-28
  - (2026-05-27) Will Tom Brady win the 2028 Republican presidential nomination?
      yes price: 1% · 24h volume: $1,184,995 · resolves 2028-11-07
  - (2026-05-27) Will Netherlands win the 2026 FIFA World Cup?
      yes price: 4% · 24h volume: $1,141,799 · resolves 2026-07-20
  - (2026-05-27) Will Turkiye win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $1,133,229 · resolves 2026-07-20

### Commentary & analysis (last 7 days) — 5 new of 6 total
  - (2026-05-27) [Marginal Revolution] What should I ask Richard Hanania?
      Yes, I will be doing a Conversation with him.  Richard does have a new book coming out, Kakistocracy: Why Populism Ends in Disaster.  While I liked the book (and blurbed it), I do not feel our conversation about the book
  - (2026-05-27) [Marginal Revolution] Wednesday assorted links
      1. As meat prices rise, the economics of Texas barbecue. 2. Economic historian Eric Jones has passed away. 3. Claims about the Pope and Claude.  If true, further evidence for my Straussian hypothesis. 4. Koyama reviews T
  - (2026-05-27) [Marginal Revolution] Seven ways to avoid losing your job to AI
      That is the theme of my latest Free Press column, here is one excerpt: Principle five: Run experiments. This is a more general version of the healthcare point. AI will generate so many new ideas and hypotheses, including
  - (2026-05-27) [Conversable Economist] Lessons for Central Banks: Interview with Kristin Forbes
      Thomas Chow poses the questions in &#8220;Kristin Forbes on &#8216;wargaming&#8217; for thenext crisis,&#8221; subtitled &#8220;The MIT professor and former BoE MPC member speaks about QE, scenario analysis and the ar of
  - (2026-05-26) [Conversable Economist] How Medicare and Medicaid Rely on Private Health Insurance
      For a majority of Medicare and Medicaid recipients, the government program is paying a private health insurance company to provide the service from a private firm. In the Spring 2026 issue of the Journal of Economic Pers

### U.S. Political Figures (per-figure anomaly tracking) — 613 new of 613 total
  - (2026-05-27) Senator: Angela D Alsobrooks (anomaly 0.00)
      Angela D Alsobrooks (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ
  - (2026-05-27) Senator: Alan Armstrong (anomaly 0.00)
      Alan Armstrong (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ ment
  - (2026-05-27) Senator: Tammy Baldwin (anomaly 0.00)
      Tammy Baldwin (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Jim Banks (anomaly 0.10)
      Jim Banks (Senator). Composite anomaly score 0.100. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.50. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ mentions:
  - (2026-05-27) Senator: John Barrasso (anomaly 0.00)
      John Barrasso (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ menti
  - (2026-05-27) Senator: Michael F Bennet (anomaly 0.00)
      Michael F Bennet (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Marsha Blackburn (anomaly 0.20)
      Marsha Blackburn (Senator). Composite anomaly score 0.200. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 1.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ me
  - (2026-05-27) Senator: Richard Blumenthal (anomaly 0.00)
      Richard Blumenthal (Senator). Composite anomaly score 0.000. Components: stock 0.00, speech-volume 0.00, topic-drift 0.00, gdelt-tone 0.00, filings 0.00, enforcement 0.00. PTRs: 0. GDELT mentions: 0. Form 4 hits: 0. DOJ 

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-05-27) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=21, 7d-median=25, 14d-median=25
- state_bills: today=1, 7d-median=1, 14d-median=1
- state_news: today=728, 7d-median=728, 14d-median=728
- local_news: today=225, 7d-median=225, 14d-median=225
- foreign_news: today=886, 7d-median=886, 14d-median=886
- chinese_internal: today=288, 7d-median=288, 14d-median=288
- russian_internal: today=1020, 7d-median=1020, 14d-median=1020
- ukrainian_internal: today=138, 7d-median=138, 14d-median=138
- ukraine_theater: today=394, 7d-median=394, 14d-median=394
- paper_bets: today=136, 7d-median=136, 14d-median=136
- weather: today=155, 7d-median=155, 14d-median=155
- macro: today=0, 7d-median=0, 14d-median=0
- markets: today=0, 7d-median=0, 14d-median=0
- markets_global: today=79, 7d-median=79, 14d-median=79
- sanctions_procurement: today=95, 7d-median=95, 14d-median=95
- congressional_trades: today=1, 7d-median=1, 14d-median=1
- billionaires: today=30, 7d-median=30, 14d-median=30
- people: today=324, 7d-median=324, 14d-median=324
- sanctions: today=30, 7d-median=30, 14d-median=30
- courtlistener: today=30, 7d-median=30, 14d-median=30
- form4: today=40, 7d-median=40, 14d-median=40
- fec: today=27, 7d-median=27, 14d-median=27
- gdelt_regions: today=80, 7d-median=80, 14d-median=80
- gdelt_gkg: today=0, 7d-median=0, 14d-median=0
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=24, 7d-median=24, 14d-median=24
- promed: today=0, 7d-median=0, 14d-median=0
- cisa_kev: today=16, 7d-median=16, 14d-median=16
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- forecasts: today=20, 7d-median=20, 14d-median=20
- commentary: today=6, 7d-median=6, 14d-median=6
- political_figures: today=613, 7d-median=613, 14d-median=613
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1

## What to watch (recent + forthcoming, ±14 days)
- [2026-05-14] Fed speeches: Bowman, Opening Remarks
- [2026-05-14] Fed speeches: Barr, Efficient and Effective Central Banking: Beyond the Balance Sheet
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board announces approval of application by the Stephen M. Calk 2025 Trust
- [2026-05-15] Fed press (events + announcements): Federal Reserve Board names Jerome H. Powell as chair pro tempore; Powell will serve as chair pro tempore until Kevin M. Warsh is sworn in as the new chair
- [2026-05-20] ECB press: Results of the March 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-05-20] Fed speeches: Barr, Measuring Financial Health
- [2026-05-20] Fed press (events + announcements): Minutes of the Federal Open Market Committee, April 28-29, 2026
- [2026-05-20] Fed press (events + announcements): Federal Reserve Board requests public comment on a proposal to establish a "payment account," which legally eligible financial institutions could use for the specific purpose of clearing and settling their payments
- [2026-05-21] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Commerce Bank
- [2026-05-21] ECB press: Frank Elderson: A central banker’s perspective on climate change and nature degradation
- [2026-05-22] ECB press: Philip R. Lane: Europe and the world economy
- [2026-05-22] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-05-22] Fed speeches: Waller, Policy Risks Have Changed
- [2026-05-22] Fed press (events + announcements): Agencies publish resolution plan feedback letters for certain domestic and foreign banking organizations
- [2026-05-22] Fed press (events + announcements): Kevin Warsh takes oath of office as chairman and a member of the Board of Governors of the Federal Reserve System, and the Federal Open Market Committee unanimously selects Warsh as its chairman
- [2026-05-26] ECB press: Isabel Schnabel: Interview with Reuters
- [2026-05-26] ECB press: Philip R. Lane: Interview with Nikkei
- [2026-05-26] Fed press (events + announcements): Minutes of the Board's discount rate meeting on April 20 and 29, 2026

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*