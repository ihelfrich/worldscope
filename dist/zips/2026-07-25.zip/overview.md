# WORLDSCOPE morning brief — 2026-07-25

## Headline
2095 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (532) · Russian Internal News (state + in-exile) (393) · World leaders & government officials (324) · Chinese Internal News (157) · U.S. Weather + Severe / Climate Outlooks (156) · Ukraine Theater (total-war monitoring) (91) · Local News: St. Louis + Atlanta (90) · Ukrainian Internal News (national + local Kyiv) (55) · State Legislative Action (53) · State-Level News (48) · GDELT GKG — themes / entities / watch areas (46) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 532 new of 1026 total
  - (2026-07-25) [Global] Herbicide banned in 70 countries to be pulled from sale in Australia by chemical maker
  - (2026-07-25) [Global] France and Spain race to control wildfires as more than 250,000 evacuated – live
  - (2026-07-25) [Global] What’s behind Maga influencer Laura Loomer’s about-face on Ukraine?
  - (2026-07-25) [Global] ‘No time to waste’: Greece bids for Mount Olympus to be included on Unesco list of world heritage sites
  - (2026-07-25) [Global] Treasure as trinkets: Zendaya’s earrings renew debate on ownership of ancient artefacts
  - (2026-07-25) [Global] Reclaiming stolen childhoods: swimming classes resume in Gaza after three years of war

### Russian Internal News (state + in-exile) — 393 new of 1013 total
  - (2026-07-25) Министр образования Индии ушел в отставку после многотысячных студенческих протестов | LEDE: Министр образования Индии Дхармендра Прадхан подал в отставку после нескольких недель масштабных ] (ru: Мин…
      Министр образования Индии Дхармендра Прадхан подал в отставку после нескольких недель масштабных студенческих протестов в стране. Об этом сообщает The Guardian.
  - (2026-07-25) Война. 1613-й день. Задержан организатор военной выставки под Киевом, по которой ударила Россия. В результате атаки погибли 10 человек, около 100 пострадали | LEDE: «Медуза» с 24 февраля 202] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-25) Украинские дроны атаковали НПЗ в Тюмени. Там начался пожар | LEDE: Украинские беспилотники днем 25 июля атаковали нефтеперерабатывающий завод в Тюмени, сообщил губернатор Тюменской области А] (ru: Укр…
      Украинские беспилотники днем 25 июля атаковали нефтеперерабатывающий завод в Тюмени, сообщил губернатор Тюменской области Александр Моор.
  - (2026-07-25) Странам Евросоюза разрешили продавать нефть, изъятую с танкеров российского «теневого флота» | LEDE: Евросоюз в рамках 21-го пакета санкций против России разрешил государствам-членам альянса] (ru: Стр…
      Евросоюз в рамках 21-го пакета санкций против России разрешил государствам-членам альянса продавать российскую нефть и нефтепродукты, которые они изъяли с танкеров «теневого флота» РФ. Об этом сообщает Euractiv.
  - (2026-07-25) Бывшему министру обороны Украины Михаилу Федорову предложили должность советника главы Минобороны Италии | LEDE: Министр обороны Италии Гвидо Крозетто заявил, что предложил Михаилу Федорову,] (ru: Быв…
      Министр обороны Италии Гвидо Крозетто заявил, что предложил Михаилу Федорову, уволенному с поста министра обороны Украины, должность своего советника. Об этом он рассказал газете La Repubblica (публикация доступна по под…
  - (2026-07-25) Все говорят, что «Одиссею» нужно смотреть только в IMAX. А чем на самом деле отличается этот формат от других? И насколько хуже картинка в обычном зале? | LEDE: Одна их многих претензий крит] (ru: Все…
      Одна их многих претензий критиков к «Одиссее» Кристофера Нолана — классовая. Ведь чтобы посмотреть фильм в том виде, каким его задумал режиссер, нужно выложить внушительную сумму (в среднем 25 долларов в США и до 30 евро…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 157 new of 285 total
  - (2026-07-24) Chart of the Day: China’s New Solar Build Out Plunges - Caixin Global
      Chart of the Day: China’s New Solar Build Out Plunges Caixin Global
  - (2026-07-23) “俄版亚马逊”仓库遭袭背后，“是信息战” - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE80MnlvNGEyX0NoV3dFNVB2NldiNG9JNUxVU2o3R1doQ2xKU1p2NXE4LTUxTmJOTmpyRkw0aGR1WDRzQUpTdzY4dy01MVI1Qzcz] (zh:…
      “俄版亚马逊”仓库遭袭背后，“是信息战” 观察者
  - (2026-07-25) 一个美国青年，为什么能进入敦煌市媒体中心，背调如何开展？相关程序是否规范透明？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE1oT1VXNGZ0WTdxeGZhSm1xU1ltZWFsQ2JtQlVUb2liNUJOSG0wTmpuSFZVeG1DYnY3ZUt4aVpURl9YQk] (zh:…
      一个美国青年，为什么能进入敦煌市媒体中心，背调如何开展？相关程序是否规范透明？ 风闻
  - (2026-07-25) 中国追星女的“高光”时刻 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE9BSDdLc0tQanVBTjd1R1NIOUdwSjZxelJSVlhHWnNGSWRlNlp1VHdBeXh2RlJNV2lDVGdqRTlvZ1VXdzltekhHOHlPbGRDWUx0LURCTkd1S] (zh:…
      中国追星女的“高光”时刻 风闻
  - (2026-07-25) 如果真有能力，偶尔给自己买点品牌溢价，是对自己努力的一种奖赏和激励吧 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE0xYjRSUmxEYkpVVExJcFN1eXdMQ05kdDRYajg5TEJkWVpNR1ZPMUxkZ3dVXy12bk5GR2xmVno3a1lTVVV4aTR] (zh:…
      如果真有能力，偶尔给自己买点品牌溢价，是对自己努力的一种奖赏和激励吧 风闻
  - (2026-07-25) 携程回应：诚恳接受、坚决服从 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBPUHBrcl9yVzBKdXVyUlk2MjVIN0xKazhmdmQ5MEF5Z2dNWjhrbTdhVkFrdVZKc1E5aVBaWU4xUXljSW5TRUFOUlU2UGYxdkgzbTJhaU] (zh:…
      携程回应：诚恳接受、坚决服从 观察者

### U.S. Weather + Severe / Climate Outlooks — 156 new of 171 total
  - (2026-07-25) [Moderate] Heat Advisory: Heat Advisory issued July 25 at 7:29AM CDT until July 26 at 9:00PM CDT by NWS Aberdeen SD
      * WHAT...Heat index values up to 100 expected. * WHERE...Portions of west central Minnesota and northeast South Dakota. * WHEN...From 1 PM this afternoon to 9 PM CDT Sunday. * IMPACTS...Hot temperatures and high humidity…
  - (2026-07-25) [Moderate] Heat Advisory: Heat Advisory issued July 25 at 7:29AM CDT until July 26 at 9:00PM CDT by NWS Aberdeen SD
      * WHAT...Heat index values from 100 to 107 expected. * WHERE...Portions of central and north central South Dakota. * WHEN...From 1 PM CDT /noon MDT/ this afternoon to 9 PM CDT /8 PM MDT/ Sunday. * IMPACTS...Hot temperatu…
  - (2026-07-25) [Moderate] Heat Advisory: Heat Advisory issued July 25 at 7:29AM CDT until July 26 at 9:00PM CDT by NWS Aberdeen SD
      * WHAT...For the Dense Fog Advisory, visibility one quarter mile or less in dense fog. For the Heat Advisory, heat index values up to 100 expected. * WHERE...Brown County. * WHEN...For the Dense Fog Advisory, until 9 AM…
  - (2026-07-25) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 25 at 7:29AM CDT until July 25 at 9:00AM CDT by NWS Aberdeen SD
      * WHAT...For the Dense Fog Advisory, visibility one quarter mile or less in dense fog. For the Heat Advisory, heat index values up to 100 expected. * WHERE...Brown County. * WHEN...For the Dense Fog Advisory, until 9 AM…
  - (2026-07-25) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 25 at 7:22AM CDT until July 25 at 9:00AM CDT by NWS Des Moines IA
      * WHAT...For the Dense Fog Advisory, visibility one quarter or less in dense fog. For the Heat Advisory, heat index values up to 105 expected. For the Extreme Heat Warning, dangerously hot conditions with heat index valu…
  - (2026-07-25) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 25 at 7:22AM CDT until July 26 at 9:00PM CDT by NWS Des Moines IA
      * WHAT...For the Dense Fog Advisory, visibility one quarter or less in dense fog. For the Heat Advisory, heat index values up to 105 expected. For the Extreme Heat Warning, dangerously hot conditions with heat index valu…

### Ukraine Theater (total-war monitoring) — 91 new of 347 total
  - (2026-07-25) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-25) [Liveuamap] Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com - Liveuamap
      Interactive map of Yemen war - Yemen news live map- yemen.liveuamap.com Liveuamap
  - (2026-07-25) [Liveuamap] Explosions were also reported in Luhansk - Liveuamap
      Explosions were also reported in Luhansk Liveuamap
  - (2026-07-24) [Liveuamap] Drones strikes have been reported in St.Petersburg - Liveuamap
      Drones strikes have been reported in St.Petersburg Liveuamap
  - (2026-07-24) [Liveuamap] The Revolutionary Guard reports shooting down an American cruise missile in the skies of Kahnuj city last night. - Liveuamap
      The Revolutionary Guard reports shooting down an American cruise missile in the skies of Kahnuj city last night. &n
  - (2026-07-20) [Liveuamap] The Jordanian Armed Forces: We will not tolerate any threat to the security of the Kingdom. - Liveuamap
      The Jordanian Armed Forces: We will not tolerate any threat to the security of the Kingdom. <font color="#

### Local News: St. Louis + Atlanta — 90 new of 237 total
  - (2026-07-25) [St. Louis] New St. Louis film shows the painstaking effort to conserve the plant monarch butterflies eat
  - (2026-07-25) [St. Louis] Record attendance at NABJ St. Louis Student Journalism Workshop after format change
      Students from across the St. Louis region spent the week producing original stories on community recovery while learning from Black journalists and media leaders.
  - (2026-07-25) [St. Louis] Iran reports no new US strikes overnight as tensions remain high
      Iran reports no strikes overnight into Saturday, an apparent break in nearly two weeks of U.S. attacks. Tensions remain high over control of the Strait of Hormuz.
  - (2026-07-25) [St. Louis] Local bakery buys former St. Louis doughnut shop property
      O’Fashion Donuts, located in the Southwest Garden neighborhood, closed earlier this year.
  - (2026-07-25) [St. Louis] Applebee's closes St. Louis County location
      After 30 years in business, the location closed permanently due to a 30% rent increase, an employee said.
  - (2026-07-25) [St. Louis] Tropical Storm Genevieve forms in the Pacific as Hurricane Fausto strengthens to Category 2
      The hurricane center said swells generated by Fausto could cause life-threatening surf and rip tides in parts of southern California.

### Ukrainian Internal News (national + local Kyiv) — 55 new of 134 total
  - (2026-07-25) В Грузії назвали причину масштабного блекауту | LEDE: Причиною масштабного відключення електроенергії в Грузії стало відключення лінії електропередачі "Імереті" напругою 500 кВ.] (uk: В Грузії назвали…
      Причиною масштабного відключення електроенергії в Грузії стало відключення лінії електропередачі "Імереті" напругою 500 кВ.
  - (2026-07-25) РЛС, склад боєприпасів і пункти управління БпЛА – Генштаб розповів про уражені цілі на ТОТ | LEDE: ЗСУ атакували російські військові об’єкти на окупованих територіях: склади, РЛС, пункти управл] (uk:…
      ЗСУ атакували російські військові об’єкти на окупованих територіях: склади, РЛС, пункти управління БпЛА. Деталі – від Генштабу.
  - (2026-07-25) В ЄС відреагували на новий інцидент з вторгненням дрона в Румунію | LEDE: Глава Європейської ради Антоніу Кошта прокоментував інцидент з дроном, який порушив повітряний простір Румунії і який д] (uk:…
      Глава Європейської ради Антоніу Кошта прокоментував інцидент з дроном, який порушив повітряний простір Румунії і який довелось збити ВПС країни.
  - (2026-07-25) Не врятували і антидронові сітки – ССО розповіли деталі удару по російському НПЗ за 2000 км | LEDE: Українські дрони ССО вдруге атакували Тюменський НПЗ за 2000 км від кордону. Не врятували і а] (uk:…
      Українські дрони ССО вдруге атакували Тюменський НПЗ за 2000 км від кордону. Не врятували і антидронові сітки
  - (2026-07-25) Грузія продовжила надання фінансової та медичної допомоги для українців | LEDE: Грузинський уряд продовжив до 1 жовтня 2026 року дію програми фінансової підтримки для громадян України та осіб, ] (uk:…
      Грузинський уряд продовжив до 1 жовтня 2026 року дію програми фінансової підтримки для громадян України та осіб, які мають право на постійне проживання там, і прибули до Грузії через війну.
  - (2026-07-25) Тепло і дощі з грозами – прогноз погоди на 26-28 липня | LEDE: Найближчими днями в Україні очікується тепла погода, у низці областей дощі та грози.] (uk: Тепло і дощі з грозами – прогноз погоди на 26-…
      Найближчими днями в Україні очікується тепла погода, у низці областей дощі та грози.

### State Legislative Action — 53 new of 151 total
  - (2026-07-25) [Alaska HB 324] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
  - (2026-07-25) [Alaska HB 316] An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
      An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
  - (2026-07-25) [California SB 822] Unclaimed property: digital financial assets.
      The Unclaimed Property Law (UPL) prescribes the circumstances under which intangible property escheats to the state, including how and when apparent owners must be notified that their property is at risk of escheating an…
  - (2026-07-25) [California SB 838] Housing Accountability Act: housing development projects.
      Existing law, the Housing Accountability Act, among other things, prohibits a local agency from disapproving, or conditioning approval in a manner that renders infeasible, a housing development project for very low, low-…
  - (2026-07-25) [California SB 848] Pupil safety: school employee misconduct: child abuse prevention.
      (1) Under existing law, each school district and county office of education is responsible for the overall development, as specified, of a comprehensive school safety plan for each of its schools operating kindergarten o…
  - (2026-07-25) [California SB 839] Oil spills: fishing: water closure: grants: liability.
      (1) Existing law requires the Director of Fish and Wildlife, within 24 hours of notification of a spill or discharge, as described, to close certain waters to the take of all fish and shellfish. Existing law provides tha…

### State-Level News — 48 new of 753 total
  - (2026-07-25) [Arkansas] After a man dies in police custody, residents in a Missouri town demand answers
      SIKESTON — Not everyone at Lloyd Gilmore’s funeral knew him well. One woman, who had ironed her clothes two days in advance, said she just wanted to be there for his family. School-age children, guided by their parents,…
  - (2026-07-25) [Arkansas] What to know about Ford’s BlueOval City plant, 5 years later
      Nearly five years after Ford Motor Company announced a massive electric vehicle and battery manufacturing campus poised to change the economic landscape of rural West Tennessee, the plant has yet to start production. The…
  - (2026-07-25) [Arizona] Election deniers and conspiracy theorists top Arizona’s Republican nominees this year
      Republican voters in Arizona sent a litany of election deniers to the November ballot, chief among them the nominees for the top three statewide offices. But they’re far from the only ones who advanced to the general ele…
  - (2026-07-25) [Colorado] Flood of poll watchers, observers, monitors to descend on midterm voters
      WASHINGTON — Political party poll watchers are showing up more and more, usually outside polling places. They have a different mission than the nonpartisan election observers long regarded as bulwarks of credibility, and…
  - (2026-07-24) [Colorado] USDA union leaders rally against proposed DC downsizing
      A group of current and former U.S. Department of Agriculture employees are calling on the Trump administration to halt the mandated relocation of more than 2,500 employees from its Washington, D.C., headquarters to five…
  - (2026-07-25) [Florida] ‘E pluribus unum’ is not a slogan. It’s a choice.
      Like two sides of a coin imprinted with the nation’s motto, “e pluribus unum” — out of many, one — America’s political factions are cast in opposition, but they are intrinsically bound together as parts of a larger whole…

### GDELT GKG — themes / entities / watch areas — 46 new of 46 total
  - (2026-07-25) [Russia oil sanctions perimeter · themes] Donald Trump Iran Statement : क्या ईरान पर सबसे बड़े हमले की तैयारी में अमेरिका ? ट्रंप बोले : हम लॉक्ड एंड लोडेड , पर बातचीत भी जारी - us iran conflict escal…
      hindi.business-standard.com · Hindi · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] Golpe de calor financiero
      laopinion.co · Spanish · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] 25 de Xullo
      elprogreso.es · Galician · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] Zonguldaklı gemici toprağa verildi - Zonguldak Haberleri - Habertürk Yerel Haberler
      yerel-haberler.haberturk.com · Turkish · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] Muere un joven de 21 años ahogado en un canal de Amposta
      20minutos.es · Spanish · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] উত্তাল সমুদ্রে ইলিশের দেখা মিলছে না , লোকসানের মুখে মৎস্যজীবীরা
      bartamanpatrika.com · Bengali · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-25) [Tangney Jeffrey] Form 4 (Reporting)
      filed 2026-07-25 01:59 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Doximity, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:59 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Sams Louise S] Form 4 (Reporting)
      filed 2026-07-25 01:51 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:51 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Auguste Laurent] Form 4 (Reporting)
      filed 2026-07-25 01:49 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:49 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 19 new of 19 total
  - (2026-07-25) JAF95J (Bulgaria)
      icao24: 4520aa · position: (36.5353, -8.152) · alt: 11277m · 781km/h
  - (2026-07-25) CFC3499 (Canada)
      icao24: c2c363 · position: (51.892, 10.4651) · alt: 11277m · 902km/h
  - (2026-07-25) INDIA1 (India)
      icao24: 800585 · position: (35.7306, 27.5823) · alt: 10058m · 936km/h
  - (2026-07-25) JAF2XD (Belgium)
      icao24: 44d1ba · position: (47.6139, 11.126) · alt: 11277m · 862km/h
  - (2026-07-25) JAF5HJ (Belgium)
      icao24: 44d1b4 · position: (46.7124, -2.3253) · alt: 10058m · 938km/h
  - (2026-07-25) JAF35D (Belgium)
      icao24: 44d1c2 · position: (42.8334, -7.668) · alt: 10058m · 965km/h

### IT, InfoSys & cybersecurity news (last 7 days) — 12 new of 57 total
  - (2026-07-25) [BleepingComputer] OpenAI confirms ChatGPT is down worldwide
      ChatGPT, the famous artificial intelligence chatbot that allows users to converse with various personalities and topics, has connectivity issues worldwide. [...]
  - (2026-07-25) [The Hacker News] Researcher Publishes GitLab RCE PoC Letting Authenticated Users Run Commands as Git
      Security researchers at depthfirst published working exploit code on July 24 for a GitLab flaw that GitLab patched six weeks earlier, on June 10. It runs commands as git on any self-managed 18.11.3 server that has not ta…
  - (2026-07-25) [The Hacker News] CTM360 Research Reveals How Insurance Phishing Has Evolved Into Real-Time Account Hijacking
      For years, phishing campaigns targeting financial institutions followed the same playbook. Victims were tricked into entering usernames and passwords, attackers collected the credentials, and accounts were compromised la…
  - (2026-07-25) [The Hacker News] Cl0p Affiliates Target Internet-Exposed PTC Windchill and FlexPLM with Unauthenticated RCE
      Threat actors linked to the Cl0p (aka Chubby Scorpius, FIN11, Graceful Spider, and Lace Tempest) ransomware campaign are exploiting flaws in internet-exposed PTC Windmill and FlexPLM deployments as part of a new data ext…
  - (2026-07-25) [The Hacker News] DevMan RaaS Portal Centralizes Payload Builds, Victim Management, and Affiliate Payouts
      The operators of the DevMan ransomware-as-a-service (RaaS) scheme are maintaining a dedicated web platform that offers affiliates the ability to build payloads, oversee earnings, and manage various aspects related to vic…
  - (2026-07-25) [The Register] Anti-AI open source has an enemy in common, but almost nothing else
      Building bot-free alternatives may require lefties, libertarians, and culture warriors to share code

### U.S. Federal Action — 11 new of 12 total
  - (2026-07-27) Modernizing Reactor Licensing, Safety Oversight, and Siting Practices; Correction
      The U.S. Nuclear Regulatory Commission (NRC) is correcting a notice published in the Federal Register on July 16, 2026, regarding the modernization of reactor licensing, safety oversight, and siting practices to address…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Report and Order that promotes the deployment of submarine cables while strengthening national security interests in connection…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Further Notice of Proposed Rulemaking (Second FNPRM) that seeks to further prevent evolving national security risks associated…
  - (2026-07-27) Modernizing Package Certification Requirements
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its regulations governing the packaging and transportation of radioactive material. This proposed action is responsive to several executive orders and th…
  - (2026-07-27) Updating Website and Contact Information, and Authorizations for Payments for Legal Services
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is adopting a final rule to update website and contact information in certain parts of the Code of Federal Regulations (CFR). Additionally, OFAC is…
  - (2026-07-27) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action
      NMFS announces an inseason action for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds fishing dates in August and September in the Co…

### Paper Trading Scorecard — 9 new of 139 total
  - (2026-07-25) [Polymarket] Will any presidential candidate win outright in the first round of the Brazil election?
      Presidential elections are scheduled to be held in Brazil on October 4, 2026. A second round will be held if no candidate secures more than 50% of the valid votes in the first round. This market will resolve to "Yes" if…
  - (2026-07-25) [Polymarket] Toronto Blue Jays vs. Boston Red Sox
      In the upcoming MLB game between the Toronto Blue Jays and Boston Red Sox, scheduled for July 25 at 4:10PM ET: This market will resolve to "Toronto Blue Jays" if the Toronto Blue Jays win the game. This market will resol…
  - (2026-07-25) [Manifold] AOC will be first female POTUS?
  - (2026-07-25) [Manifold] Will Gavin Newsom be the favorite for Democratic Nominee on Dec. 31, 2026? [Per Polymarket Data]
  - (2026-07-25) [Manifold] Will Gavin Newsom cease to be the favorite Democratic Nominee before the end of 2026? [Per Polymarket Data]
  - (2026-07-25) [Manifold] Will my sister be at sleepaway camp on August 1?

### Prediction Markets — most-traded (Polymarket) — 9 new of 20 total
  - (2026-07-25) LoL: Invictus Gaming vs Weibo Gaming (BO3) - LPL Group Nirvana
      yes price: 100% · 24h volume: $1,876,409 · resolves 2026-07-25
  - (2026-07-25) LoL: Invictus Gaming vs Weibo Gaming - Game 2 Winner
      yes price: 100% · 24h volume: $1,296,573 · resolves 2026-07-25
  - (2026-07-25) LoL: Invictus Gaming vs Weibo Gaming - Game 1 Winner
      yes price: 0% · 24h volume: $1,280,178 · resolves 2026-07-25
  - (2026-07-25) Generali Open: Alexander Bublik vs Quentin Halys
      yes price: 38% · 24h volume: $1,226,791 · resolves 2026-08-01
  - (2026-07-25) LoL: LGD Gaming vs Team WE - Game 2 Winner
      yes price: 0% · 24h volume: $1,163,321 · resolves 2026-07-25
  - (2026-07-25) LoL: LGD Gaming vs Team WE (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $880,120 · resolves 2026-07-25

### Government Action: Sanctions + Procurement + Foreign Agents — 5 new of 121 total
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-25) [USASpending] $819,751,946 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-25) [USASpending] $733,516,127 → BL HARBERT INTERNATIONAL LLC: BEIRUT, LEBANON NEW EMBASSY CONSTRUCTIONIGF::CL::IGF
      Agency: Department of State. Description: BEIRUT, LEBANON NEW EMBASSY CONSTRUCTIONIGF::CL::IGF
  - (2026-07-25) [USASpending] $665,616,978 → HII MISSION TECHNOLOGIES CORP: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE
      Agency: General Services Administration. Description: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE ISR AND NEXTGEN TECHNOLOGY (LOGIX)
  - (2026-07-25) [USASpending] $614,391,052 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…

### GDACS — global disaster alerts — 5 new of 228 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-07-23) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 11415 ha
  - (2026-07-23) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 11415 ha

### Court opinions of consequence (federal & state) — 3 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, 3rd Cir.: In re: Avandia Marketing v.
  - (2026-07-21) U.S. Court of Appeals, 3rd Cir.: John Doe v. Princeton University Trustees
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Jenkins v. Prime Insurance

### USGS earthquakes (M4.5+, past day) — 3 new of 16 total
  - (2026-07-25) M 5.1 - 43 km SW of Puerto Madero, Mexico
      M5.1 · 43 km SW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-25) M 5.0 - 57 km S of Sarangani, Philippines
      M5.0 · 57 km S of Sarangani, Philippines · depth 52.163 km
  - (2026-07-24) M 5.0 - 96 km NNW of Port-Olry, Vanuatu
      M5.0 · 96 km NNW of Port-Olry, Vanuatu · depth 10 km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-25) [Marginal Revolution] A natural experiment in economics
      To study whether and how academics respond to political pressure, we exploit a natural experiment: the publication in early 2025 of a “blacklist” of words flagged by the U.S. government. We find that the release of this…
  - (2026-07-25) [Marginal Revolution] Crypto markets in everything? (moo)
      Farmers in Parana, Brazil, struggling to get banks to loan them cash, became the first to tokenize livestock and place 10 dairy milk cows’ tokens for trade on the country’s B3 national stock exchange. They generated near…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=22, 14d-median=20; carrying terms: provide, safety, regulatory, special, action, published, amendment, proposing, certain, final, amendments, coast
- state_bills: today=151, 7d-median=124, 14d-median=124; carrying terms: contact, identify, vehicle, assembly, financial, report, years, transportation, changes, family, services, establishment
- state_news: today=753, 7d-median=753, 14d-median=753; carrying terms: announcement, lower, grand, cellphone, really, assembly, patients, canada, governing, lands, financial, report
- local_news: today=237, 7d-median=227, 14d-median=237; carrying terms: vehicle, report, injured, family, loading, nearly, building, residents, atlanta, cbmirafbvv, games, content
- foreign_news: today=1026, 7d-median=1026, 14d-median=1026; carrying terms: shunxin, announcement, grand, title, vehicle, canada, going, thejakartapost, ecosystem, flight, exhibition, bilateral
- chinese_internal: today=285, 7d-median=303, 14d-median=303; carrying terms: title, cbmiykfvx, cbmiy, articles, lxtfa, cbmiyefvx, cbmia, cbmiaefvx, cbmix, people, cbmizkfvx, cbmibefvx
- russian_internal: today=1013, 7d-median=1008, 14d-median=982; carrying terms: title, telegram, novaya, times, financial, europe, httperror, error, wildberries, laquo, found, truth
- ukrainian_internal: today=134, 7d-median=128, 14d-median=134; carrying terms: european, title, chief, campaign, injured, httperror, supply, zelensky, focused, pressure, invasion, forbidden
- ukraine_theater: today=347, 7d-median=377, 14d-median=400; carrying terms: wktmrfd, nxztnk, conducted, zgdkbdjbrv, cuxnv, jvowd, rletztdwddhhzedzmnzwevjhugrizvl, branch, vugxoyuzqrfzpcnjsd, wlpuehloedfat, iqtvos, fmdjfqcgjsne
- paper_bets: today=139, 7d-median=144, 14d-median=144; carrying terms: eliminated, goals, brazilian, announcement, romania, above, october, title, market, presidential, lackey, winner
- weather: today=171, 7d-median=171, 14d-median=171; carrying terms: baltimore, lower, grand, ridge, holly, chances, additional, north, twoat, morning, texas, continues
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: jtsjol, spread, indicator, dexjpus, headline, latest, funds, payems, energy, openings, pcepilfe, dexuseu
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: natural, yield, equities, nasdaq, crypto, agriculture, commodities, russell, silver, futures, china, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=121, 7d-median=121, 14d-median=119; carrying terms: agency, wfbvv, oblasts, nicaragua, transportation, campaign, response, ranchers, cbmiqkfvx, uchicago, council, embargo
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: httperror, quiver, error, https, quiverquant, quantitative, client, congresstrading, unauthorized
- billionaires: today=30, 7d-median=36, 14d-median=34; carrying terms: changpeng, discount, julia, retail, tokyo, madrid, exchange, semiconductors, arnault, investments, masayoshi, amazon
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, state, trade, court, international, appeals, supreme, district, board, delaware, insurance, school
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: filed, reporting, accno, issuer, holdings, amended, therapeutics, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: brown, sherrod, johnson, raised, congress, booker, james, committee, ocasio, ossoff, robert, angels
- gdelt_regions: today=18, 7d-median=6, 14d-median=6; carrying terms: english, japan
- gdelt_gkg: today=46, 7d-median=45, 14d-median=46; carrying terms: israel, english, hezbollah, trump, russia, themes, spanish, chinese, sanctions, arabic, perimeter, russian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=19, 7d-median=11, 14d-median=11; carrying terms: position, kingdom, belgium, canada, ground, china
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: proportion, influenza, evolve, cruise, previously, followed, consuming, contact, derived, reference, driving, elements
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: vulnerability, federation, injection, fortisandbox, untrusted, cross, sonicwall, improper, mechanism, account, business, remediation
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=228, 7d-median=205, 14d-median=196; carrying terms: czech, bosnia, minor, maximum, costa, romania, flood, gabon, panama, green, germany, speed
- usgs_quakes: today=16, 7d-median=17, 14d-median=18; carrying terms: puerto, depth, mexico, indonesia, islands, philippines, russia, madero, region, vanuatu, ushuaia, argentina
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: minister, resolves, volume, rates, interest, ethiopia, prime, price, meeting, change, increase, decrease
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: economist, class, conversable, https, marginal, revolution, perhaps, useful, marginalrevolution, benefit, paper, among
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: exploitation, record, squid, spectrum, attack, going, report, malware, until, initiative, against, policy
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: cleaver, crockett, latimer, harshbarger, langworthy, board, kevin, houlahan, escobar, moolenaar, lynch, stefanik
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: markets, either, module, placed, today, claude, decision, paper, evidence, unavailable, converges, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*