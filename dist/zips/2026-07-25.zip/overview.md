# WORLDSCOPE morning brief — 2026-07-25

## Headline
2610 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (652) · Russian Internal News (state + in-exile) (538) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (188) · Chinese Internal News (184) · Ukraine Theater (total-war monitoring) (171) · Local News: St. Louis + Atlanta (166) · State-Level News (75) · Ukrainian Internal News (national + local Kyiv) (65) · SEC Form 4 insider transactions (recent) (40) · Conflict & unrest (GDELT, last 48h) (40) · Sanctions & Designations (recent) (30)

## What changed today
### International News + Multilateral Institutions — 652 new of 1036 total
  - (2026-07-25) [Global] Iran accuses Ukraine of deadly attack on Caspian commercial vessel
      Iran accuses Ukraine of attacking a Caspian vessel, killing one sailor and injuring another, calling it a criminal act.
  - (2026-07-25) [Global] Fire tears through Indonesian village in West Java
      A fire has torn through a traditional village in the Sukabumi Regency of Indonesia's West Java province.
  - (2026-07-25) [Global] One dead, 17 injured as car reportedly strikes crowd at Berlin LGBTQ event
      German police say they believe car drove into Tiergarten park, near the route of a Pride march, hitting several people.
  - (2026-07-25) [Global] Israeli forces target Gaza’s Al-Aqsa hospital
      At least one person was killed and several injured when Israeli drones hit a group of Palestinians near Al-Aqsa hospital
  - (2026-07-25) [Global] What’s next for Venezuela’s path to recovery from devastating earthquakes?
      The cost of reconstruction is expected to run into the tens of billions, even as the country faces numerous obstacles.
  - (2026-07-25) [Global] Israeli forces tear gas journalists reporting Nablus shootout
      Israeli troops fired tear gas at Palestinians and journalists in Tal a day after a deadly shootout

### Russian Internal News (state + in-exile) — 538 new of 862 total
  - (2026-07-26) В Берлине автомобиль въехал в толпу людей во время ЛГБТ-прайда. Один человек погиб, 14 ранены | LEDE: В Берлине в районе парка Тиргартен автомобиль въехал в толпу людей, несколько человек по] (ru: В Б…
      В Берлине в районе парка Тиргартен автомобиль въехал в толпу людей, несколько человек получили ранения, сообщает Tagesschau.
  - (2026-07-25) На сайте Минюста РФ появилась выставка о тех, кто пытался «нарушить суверенитет» России. Туда включили людей и организации из реестра «иноагентов» | LEDE: На сайте министерства юстиции РФ по] (ru: На…
      На сайте министерства юстиции РФ появился раздел с выставкой «Защита суверенитета Российского государства. История и современность», в котором рассказывается о попытках «нарушения суверенитета» России.
  - (2026-07-25) Исследователи нашли самолет Pan American на дне океана. Он потерпел крушение 74 года назад. Именно из-за этой авиакатастрофы сегодня бортпроводники проводят инструктаж пассажиров перед каждым п] (ru:…
      Исследователи из фонда Air/Sea Heritage, компании Deep Sea Vision и документального сериала «Экспедиция неизвестна» телеканала Discovery сделали первые снимки рухнувшего в Атлантический океан самолета Clipper Endeavor (м…
  - (2026-07-25) В Испании и Франции горят леса, эвакуированы больше 250 тысяч человек. Власти Мадрида говорят о «самом страшном» пожаре в истории региона. Фотографии | LEDE: В Европе на фоне рекордной жары ] (ru: В И…
      В Европе на фоне рекордной жары и засухи продолжаются масштабные лесные пожары. Самая тяжелая ситуация — во Франции и Испании. Министерство внутренних дел Испании сообщило, что порядка 70 тысяч человек эвакуированы из св…
  - (2026-07-25) Запрет на экспорт бензина из России продлят до конца года | LEDE: Вице-премьер Александр Новак объявил, что запрет на экспорт бензина из России будет продлен до конца 2026 года. Его слова пр] (ru: Зап…
      Вице-премьер Александр Новак объявил, что запрет на экспорт бензина из России будет продлен до конца 2026 года. Его слова приводит ТАСС.
  - (2026-07-25) В Тюмени гибнет рыба, а из-под крана идет вода со странным запахом. Местные службы говорят, что качество воды в норме, но рекомендуют ее не пить | LEDE: Жители Тюмени уже больше недели пишут] (ru: В Т…
      Жители Тюмени уже больше недели пишут в соцсетях о состоянии реки Туры, пересекающей город. Тюменцы жалуются на резкий неприятный запах возле реки, фотографируют погибшую рыбу, которой завалены берега. Они также рассказы…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 188 new of 190 total
  - (2026-07-25) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 25 at 6:33PM CDT until July 25 at 7:00PM CDT by NWS Aberdeen SD
      At 633 PM CDT, severe thunderstorms were located along a line from near St. Lawrence to 21 miles southeast of Rosehill Dam, or along a line from near Miller to 39 miles southeast of Miller, moving east at 35 mph. HAZARD.…
  - (2026-07-25) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 25 at 7:32PM EDT until July 25 at 8:00PM EDT by NWS Jacksonville FL
      At 732 PM EDT, a severe thunderstorm was located near Oakleaf Plantation, or near Middleburg, moving south at 10 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect damage to roofs, siding, and tre…
  - (2026-07-25) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 25 at 5:28PM MDT until July 25 at 6:00PM MDT by NWS Glasgow MT
      At 527 PM MDT, a severe thunderstorm was located 8 miles north of Sand Springs, or 27 miles west of Jordan, moving east at 35 mph. HAZARD...70 mph wind gusts and nickel size hail. SOURCE...At 5:15 PM, a 67 mph wind gust…
  - (2026-07-25) [Moderate] Special Weather Statement: Special Weather Statement issued July 25 at 4:28PM PDT by NWS Elko NV
      At 428 PM PDT, Doppler radar was tracking a strong thunderstorm 12 miles southeast of Pine Valley, moving north at 5 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty winds…
  - (2026-07-25) [Moderate] Special Weather Statement: Special Weather Statement issued July 25 at 7:27PM EDT by NWS Peachtree City GA
      At 727 PM EDT, a line of strong thunderstorms was along a line extending from Sandy Point to near Howard to Phenix City, and moving southeast at 15 mph. HAZARD...Up to 40 mph wind, frequent cloud to ground lightning and…
  - (2026-07-25) [Severe] Flash Flood Warning: Flash Flood Warning issued July 25 at 4:26PM MST until July 25 at 7:30PM MST by NWS Flagstaff AZ
      FFWFGZ The National Weather Service in Flagstaff has issued a * Flash Flood Warning for... Yavapai County in west central Arizona... * Until 730 PM MST. * At 426 PM MST, Doppler radar indicated thunderstorms producing he…

### Chinese Internal News — 184 new of 285 total
  - (2026-07-25) 人类失去“秘密”，世界将会怎样？｜影视 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5xZkxMc21EdG1IaGZSMUMxcDBfRjBKQUZHVUFlQ3RYUmJyS2VQdy03QThfRFgyZlBfYmlERjFkVFE3bTNaOURxblFENF9KU005S3] (zh:…
      人类失去“秘密”，世界将会怎样？｜影视 财新
  - (2026-07-25) 求生在罗马｜猎读 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBOOTZiMW9FN2kyOUZpcUhkU2dEZzl3YmlCX1hyVFN2SDVmSG4td0FTTkI1SVlpY2Y4bTVXa0Q2aEYxWmszcFdWQV9tYkxIYVgybm5sRU5jaHdrT] (zh:…
      求生在罗马｜猎读 财新
  - (2026-07-25) 最新封面报道之二｜AI疾速落地 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTFA5SUxwWlJWWUxYYTZ3Vm5XOVp1dXRmQkstWGNDS0dHaFIyaUVyME1JNmdCWHpNcVNFbVNUQzQtb3JxN2hFSkFGeFM1UW9vSEl0Nmw2] (zh:…
      最新封面报道之二｜AI疾速落地 财新周刊
  - (2026-07-25) 聚焦“一把手”腐败 海南高官肖杰被指利用职权插手工程项目 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5XNjBqQWRyYWtLMGc4bGJxTTlxZHhJWWJCQjVwOXVGcmxoVDE3MWJXb3NZNU1qM2w1WHV6ZmZGR3B] (zh:…
      聚焦“一把手”腐败 海南高官肖杰被指利用职权插手工程项目 china.caixin.com
  - (2026-07-25) 最新财新周刊｜拿什么提振汽车消费 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE03SGZIMUYyUmlUUkR1XzBoRkVuMDRmMHJiTlpidVUzVzdRQnNtM3VWSzliV3A2ejA3R1U0Qno0MXlvMzcyQlVUeHRuQ0pSQVlHdkI] (zh:…
      最新财新周刊｜拿什么提振汽车消费 财新周刊
  - (2026-07-25) 最新财新周刊｜断案股权交易型腐败 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE5HZV9wcEQ4VWZIQTRRVkFJZVJvclFyamMyQ3hTcVhtTWRvRWIyWjhRQVIwMjUxenY4a213Tnp5T3VjMktMSy1maE5jVzNWZ05Dckd] (zh:…
      最新财新周刊｜断案股权交易型腐败 财新周刊

### Ukraine Theater (total-war monitoring) — 171 new of 406 total
  - (2026-07-25) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-24) [Liveuamap] Tokayev, at a meeting with Putin, proposed freezing the war in Ukraine. The meeting of the presidents of Kazakhstan and Russia is taking place in Omsk, Russia. Tokayev stressed that his co…
      Tokayev, at a meeting with Putin, proposed freezing the war in Ukraine. The meeting of the presidents of Kazakhstan and Russia
  - (2026-07-25) [Liveuamap] Explosions were also reported in Luhansk - Liveuamap
      Explosions were also reported in Luhansk Liveuamap
  - (2026-07-24) [Liveuamap] Explosions and fire reported in Simferopol - Liveuamap
      Explosions and fire reported in Simferopol Liveuamap
  - (2026-07-25) [Liveuamap] Smoke plumes rise in Jazan, Saudi Arabia - Liveuamap
      Smoke plumes rise in Jazan, Saudi Arabia Liveuamap
  - (2026-07-24) [Liveuamap] 3 people killed, 10 wounded as result of Russian strike in Pavlohrad - Liveuamap
      3 people killed, 10 wounded as result of Russian strike in Pavlohrad Liveuamap

### Local News: St. Louis + Atlanta — 166 new of 252 total
  - (2026-07-25) [St. Louis] MLB MVP and 'Survivor' contestant, Jeff Kent gets Hall of Fame idol in Cooperstown
      The trio comes from Curaçao, Puerto Rico and California. They played center field and second base. They played for 18 different teams.
  - (2026-07-25) [St. Louis] ATHLETICS/
      Taryn Parks, Nikki Hiltz and Gracie Morris run in a women's 1,500-meter heat during the USA Track and Field Championships at Icahn Stadium on Thursday in New York.
  - (2026-07-25) [St. Louis] ATHLETICS/
      Dalilah Muhammad runs during a training session prior to the USA Track and Field Championships at Icahn Stadium on Wednesday in New York.
  - (2026-07-25) [St. Louis] Feb 11, 2026; Denver, Colorado, USA; Memphis Grizzlies guard Kentavious Caldwell-Pope (3) in the second quarter against the Denver Nuggets at Ball Arena. Mandatory Credit: Isaiah J. Downin…
      The Philadelphia 76ers are reportedly signing Kentavious Caldwell-Pope to a one-year, $3.9 million deal.
  - (2026-07-25) [St. Louis] BOXING/JOSHUA-PRENGA
      Anthony Joshua walks down to the ring before his heavyweight fight against Kristian Prenga on Saturday at Jeddah Superdome in Saudi Arabia.
  - (2026-07-25) [St. Louis] MOTOR-NASCAR/
      Roush Fenway Keselowski driver Ryan Preece runs a qualification lap at Sonoma Raceway on June 27 in Sonoma, Calif.

### State-Level News — 75 new of 765 total
  - (2026-07-24) [California] California landlord fights law meant to help low-income renters
      Should California landlords be required to rent to tenants with federal housing vouchers? They are under state law, but a Sacramento-based property manager is contest
  - (2026-07-25) [Arkansas] After a man dies in police custody, residents in a Missouri town demand answers
      SIKESTON — Not everyone at Lloyd Gilmore’s funeral knew him well. One woman, who had ironed her clothes two days in advance, said she just wanted to be there for his family. School-age children, guided by their parents,…
  - (2026-07-25) [Arkansas] What to know about Ford’s BlueOval City plant, 5 years later
      Nearly five years after Ford Motor Company announced a massive electric vehicle and battery manufacturing campus poised to change the economic landscape of rural West Tennessee, the plant has yet to start production. The…
  - (2026-07-25) [Colorado] Flood of poll watchers, observers, monitors to descend on midterm voters
      WASHINGTON — Political party poll watchers are showing up more and more, usually outside polling places. They have a different mission than the nonpartisan election observers long regarded as bulwarks of credibility, and…
  - (2026-07-24) [Colorado] USDA union leaders rally against proposed DC downsizing
      A group of current and former U.S. Department of Agriculture employees are calling on the Trump administration to halt the mandated relocation of more than 2,500 employees from its Washington, D.C., headquarters to five…
  - (2026-07-25) [Arizona] Election deniers and conspiracy theorists top Arizona’s Republican nominees this year
      Republican voters in Arizona sent a litany of election deniers to the November ballot, chief among them the nominees for the top three statewide offices. But they’re far from the only ones who advanced to the general ele…

### Ukrainian Internal News (national + local Kyiv) — 65 new of 139 total
  - (2026-07-26) Ukraine War News Today - Top Stories and Breaking Updates from Kyiv Post
      Stay informed with the most important Ukraine breaking news today. This page compiles the top headlines and critical updates from across Ukraine, offering a real-time snapshot of key developments. Whether it’s military u…
  - (2026-07-25) Ukraine Strikes Siberia Refinery as Kazakh Leader Tells Putin War Should End
      Ukrainian drones struck a Siberian oil refinery Saturday and disrupted an Urals athletics competition, as Kazakhstan’s president told Russia’s Vladimir Putin the Ukraine war should end during a forum in Siberia’s Omsk.
  - (2026-07-25) Russia’s Return to Olympics Exposes IOC’s Moral Collapse
      The International Olympic Committee’s decision to readmit Russia to the 2028 LA Olympics is a profound betrayal of its mission to promote peace. Russia’s invasions, propaganda and devastation of Ukrainian sport should ha…
  - (2026-07-25) Russia Cuts Funding for Putin’s Flagship Technology Projects
      Russia has cut funding for eight of its key “technological leadership” projects for 2025. Total allocations were reduced by 37.8% to 201.9 billion rubles ($2.6 billion). The most significant cuts impacted the space techn…
  - (2026-07-25) Kazakhstan’s Tokayev Urges Putin to Freeze Ukraine War
      During the 22nd Russia-Kazakhstan Interregional Cooperation Forum in Omsk on July 25, Kazakh President Kassym-Jomart Tokayev urged Russian President Vladimir Putin to freeze the war in Ukraine and return to the “Istanbul…
  - (2026-07-25) Ukraine Trains Police for War and Democracy
      The legitimacy of the state depends not only on its ability to punish crime, but also on its ability to protect the vulnerable and respect the dignity of citizens. Ukraine’s police are being trained in extraordinary circ…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-25) [Tangney Jeffrey] Form 4 (Reporting)
      filed 2026-07-25 01:59 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Doximity, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:59 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Sams Louise S] Form 4 (Reporting)
      filed 2026-07-25 01:51 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:51 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Auguste Laurent] Form 4 (Reporting)
      filed 2026-07-25 01:49 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:49 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-25) [United States] Trump new immigration strategy revealed in purchase of two ICE detention centers in California
      domain: timesofsandiego.com · language: English · tone:
  - (2026-07-25) [United States] Modi education minister quits as jubilant Indian youth protesters claim victory , end protest
      domain: channelnewsasia.com · language: English · tone:
  - (2026-07-25) [United States] Triad teacher and mother of 5 speaks on living with breast cancer
      domain: wbaltv.com · language: English · tone:
  - (2026-07-25) [United States] Kansas Secretary of State warns voters : Dont count on mail - in ballot grace period
      domain: kwch.com · language: English · tone:
  - (2026-07-25) [Australia] One Nation rise in new heartland a warning to majors
      domain: greatlakesadvocate.com.au · language: English · tone:
  - (2026-07-25) [Australia] Farm hand first plane ride after run - in with a roo
      domain: areanews.com.au · language: English · tone:

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-07-25) [Taiwan Strait + South China Sea · keywords] SONA in 2026 | The Manila Times
      manilatimes.net · English · tone NA
  - (2026-07-25) [Taiwan Strait + South China Sea · keywords] He says , he said ; the bitter path to diplomacy
      manilatimes.net · English · tone NA
  - (2026-07-25) [Taiwan Strait + South China Sea · keywords] PH troublemaker of region – China | The Manila Times
      manilatimes.net · English · tone NA
  - (2026-07-25) [Taiwan Strait + South China Sea · keywords] DPP lawmakers speak on war resilience in US
      taipeitimes.com · English · tone NA
  - (2026-07-25) [Taiwan Strait + South China Sea · keywords] Kinmen and the law that says no - Taipei Times
      taipeitimes.com · English · tone NA
  - (2026-07-25) [Taiwan Strait + South China Sea · keywords] Carpio reiterates proposal to return to Arbitral Tribunal to draft common fishing rules in Scarborough Shoal
      verafiles.org · English · tone NA

### IT, InfoSys & cybersecurity news (last 7 days) — 24 new of 57 total
  - (2026-07-25) [BleepingComputer] Steam forum ClickFix attacks infect gamers with XMRig cryptominers
      Steam discussion forums are being abused in ClickFix attacks that pretend to be fixes for game and computer problems but actually infect devices with cryptominers. [...]
  - (2026-07-25) [BleepingComputer] Malicious sites use JavaScript to build malware in browser memory
      A massive malvertising campaign is using fake Solana, Luno, and TradingView webpages with malicious JavaScript that instructs browsers to assemble malware directly in memory. [...]
  - (2026-07-25) [BleepingComputer] ShinyHunters data leaks fuel $2,000 sextortion email scam
      Threat actors are using email addresses exposed in data breaches leaked by the ShinyHunters extortion group to send sextortion emails demanding $2,000 in Bitcoin. [...]
  - (2026-07-25) [BleepingComputer] OpenAI confirms ChatGPT is down worldwide
      ChatGPT, the famous artificial intelligence chatbot that allows users to converse with various personalities and topics, has connectivity issues worldwide. [...]
  - (2026-07-25) [The Hacker News] Malvertising Sends Malware in Pieces, Then Makes the Browser Build the Executable
      A malvertising operation dubbed SourTrade is making victims' browsers build the final Windows executable themselves, using a legitimate Bun runtime as its base instead of serving one complete malicious file from a fixed…
  - (2026-07-25) [The Hacker News] Fastjson 1.x RCE Vulnerability Targeted in Attacks With No Patched Available
      Security firms ThreatBook and Imperva say attackers are targeting a critical flaw in Fastjson, Alibaba's JSON library for Java. In affected Spring Boot applications, a malicious JSON request can execute code without auth…

### Paper Trading Scorecard — 16 new of 128 total
  - (2026-07-25) [Polymarket] UNSC Resolution Endorsing Final U.S.-Iran Deal by December 31?
      On June 14, 2026, the United States and Iran announced a written diplomatic agreement, which stated in Clause 14 that it would culminate in a “final deal” to be endorsed by a binding United Nations Security Council resol…
  - (2026-07-25) [Manifold] Will Tim Hua concede his bet?
  - (2026-07-25) [Manifold] Will twitter / x.com be open source before September?
  - (2026-07-25) [Manifold] Will "LLMs are (still) mostly powered by imitative ..." make the top fifty posts in LessWrong's 2026 Annual Review?
  - (2026-07-25) [Manifold] Will the US Government halt training or deployment of an AI model by EOY 2028?
  - (2026-07-25) [Manifold] Will Stripe acquire Openrouter in 2026?

### Prediction Markets — most-traded (Polymarket) — 13 new of 20 total
  - (2026-07-25) Will Inter Miami CF win on 2026-07-25?
      yes price: 50% · 24h volume: $1,014,243 · resolves 2026-07-25
  - (2026-07-25) Will Philadelphia Union win on 2026-07-25?
      yes price: 56% · 24h volume: $894,520 · resolves 2026-07-25
  - (2026-07-25) San Diego Padres vs. Miami Marlins
      yes price: 100% · 24h volume: $758,664 · resolves 2026-08-01
  - (2026-07-25) LoL: FlyQuest vs LYON - Game 2 Winner
      yes price: 0% · 24h volume: $669,592 · resolves 2026-07-26
  - (2026-07-25) Cleveland Guardians vs. Tampa Bay Rays
      yes price: 18% · 24h volume: $635,056 · resolves 2026-08-01
  - (2026-07-25) Houston Astros vs. Chicago White Sox
      yes price: 45% · 24h volume: $613,051 · resolves 2026-08-01

### U.S. Federal Action — 11 new of 12 total
  - (2026-07-27) Modernizing Reactor Licensing, Safety Oversight, and Siting Practices; Correction
      The U.S. Nuclear Regulatory Commission (NRC) is correcting a notice published in the Federal Register on July 16, 2026, regarding the modernization of reactor licensing, safety oversight, and siting practices to address…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Report and Order that promotes the deployment of submarine cables while strengthening national security interests in connection…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Further Notice of Proposed Rulemaking (Second FNPRM) that seeks to further prevent evolving national security risks associated…
  - (2026-07-27) Modernizing Package Certification Requirements
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its regulations governing the packaging and transportation of radioactive material. This proposed action is responsive to several executive orders and th…
  - (2026-07-27) Updating Website and Contact Information, and Authorizations for Payments for Legal Services
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is adopting a final rule to update website and contact information in certain parts of the Code of Federal Regulations (CFR). Additionally, OFAC is…
  - (2026-07-27) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action
      NMFS announces an inseason action for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds fishing dates in August and September in the Co…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 7 new of 37 total
  - (2026-07-25) MOVER ▲ Carlos Slim Helu & family — $125.36B (+$0.16B since yesterday)
      Mexico · Telecom · source: Telecom
  - (2026-07-25) MOVER ▲ Bernard Arnault & family — $141.20B (+$0.10B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-25) MOVER ▲ Amancio Ortega — $137.70B (+$0.09B since yesterday)
      Spain · Fashion & Retail · source: Zara
  - (2026-07-25) MOVER ▲ Masayoshi Son — $64.28B (+$0.07B since yesterday)
      Japan · Finance & Investments · source: Telecom, Investments
  - (2026-07-25) MOVER ▲ Tadashi Yanai & family — $63.64B (+$0.07B since yesterday)
      Japan · Fashion & Retail · source: Fashion retail
  - (2026-07-25) MOVER ▲ Francoise Bettencourt Meyers & family — $91.72B (+$0.06B since yesterday)
      France · Fashion & Retail · source: L'Oréal

### Court opinions of consequence (federal & state) — 7 new of 60 total
  - (2026-07-24) U.S. Court of Appeals, 4th Cir.: Josue Fuentes v. United States Citizenship and Immigration Services
  - (2026-07-24) Supreme Court of Maryland: In re: Frederick Cnty. Data Center Referendum
  - (2026-07-24) Supreme Court of Maryland: In re: K.B.
  - (2026-07-23) Massachusetts Supreme Judicial Court: Gilardi v. Board of Health of Pittsfield
  - (2026-07-23) Supreme Court of Maryland: State v. Palmer
  - (2026-07-23) Supreme Court of Maryland: Eritrean Orth. Tweahdo Diocese v. Sinoda

### GDACS — global disaster alerts — 7 new of 240 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-07-23) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 11676 ha
  - (2026-07-23) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 11676 ha
  - (2026-07-18) [Green] Forest fires in The Democratic Republic of Congo
      Wildfire · Green alert · The Democratic Republic of Congo · Green impact for forestfire in 23949 ha

### Government Action: Sanctions + Procurement + Foreign Agents — 6 new of 120 total
  - (2026-07-24) [OFAC] Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Iran-related Designations; Issuance of Amended Russia-related General License and Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-07-25) [USASpending] $819,751,946 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-25) [USASpending] $733,516,127 → BL HARBERT INTERNATIONAL LLC: BEIRUT, LEBANON NEW EMBASSY CONSTRUCTIONIGF::CL::IGF
      Agency: Department of State. Description: BEIRUT, LEBANON NEW EMBASSY CONSTRUCTIONIGF::CL::IGF
  - (2026-07-25) [USASpending] $665,616,978 → HII MISSION TECHNOLOGIES CORP: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE
      Agency: General Services Administration. Description: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE ISR AND NEXTGEN TECHNOLOGY (LOGIX)
  - (2026-07-25) [USASpending] $614,391,052 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…
  - (2026-07-25) [UN Sanctions] page checksum 9de38bb8052e
      Active UN Security Council sanctions committees page snapshot

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-25) [Japan] Capcom explains why it putting out so many Resident Evil remakes and why there arent a lot of spin - offs
      nintendoeverything.com · English
  - (2026-07-25) [Japan] Shigeru Miyamoto believes that people are no longer just looking for specs with gaming systems
      nintendoeverything.com · English
  - (2026-07-25) [Japan] Marvel Tokon : Fighting Souls PC performance issues being investigated , community - suggested troubleshooting steps shared
      eventhubs.com · English
  - (2026-07-25) [Japan] Avatar Legends : The Fighting Game - Game
      nintendoworldreport.com · English
  - (2026-07-25) [Japan] Armadillo Racing - Game
      nintendoworldreport.com · English
  - (2026-07-25) [Japan] US lawmakers propose AI kill switch after OpenAI test
      japanherald.com · English

### Government & military aircraft airborne (OpenSky) — 5 new of 5 total
  - (2026-07-25) RCH5093 (United States)
      icao24: ae63c6 · position: (41.9958, -69.3727) · alt: 10675m · 914km/h
  - (2026-07-25) NCR401 (United States)
      icao24: a7488c · position: (33.3127, 135.9031) · alt: 12192m · 880km/h
  - (2026-07-25) JAF9EG (Belgium)
      icao24: 449681 · position: (36.1809, -6.1569) · alt: 11178m · 898km/h
  - (2026-07-25) NCR315 (United States)
      icao24: ac01ae · position: (30.0858, -90.6722) · alt: 1348m · 523km/h
  - (2026-07-25) JAF7XM (Belgium)
      icao24: 44a831 · position: (35.1091, -2.3493) · alt: 4198m · 655km/h

### USGS earthquakes (M4.5+, past day) — 5 new of 5 total
  - (2026-07-25) M 5.1 - 43 km SW of Puerto Madero, Mexico
      M5.1 · 43 km SW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-25) M 5.0 - 91 km SE of Atka, Alaska
      M5.0 · 91 km SE of Atka, Alaska · depth 40.779 km
  - (2026-07-25) M 5.0 - 57 km S of Sarangani, Philippines
      M5.0 · 57 km S of Sarangani, Philippines · depth 52.163 km
  - (2026-07-24) M 5.0 - 96 km NNW of Port-Olry, Vanuatu
      M5.0 · 96 km NNW of Port-Olry, Vanuatu · depth 10 km
  - (2026-07-25) M 4.9 - Kermadec Islands, New Zealand
      M4.9 · Kermadec Islands, New Zealand · depth 55.602 km

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-07-25) [Marginal Revolution] Odysseus notes
      The subsection of the Georgi Gospodinov novel runs like this: The Shortest Novel About Odysseus After His Return Home One night, now old and flabby and starting to forget, he leaves his home secretly. He’s sick of everyt…
  - (2026-07-25) [Marginal Revolution] Saturday assorted links
      1. The 1991 Project’s oral history collection (led by Shreyas Narla and Shruti) with ~50 hours of interviews with policy reformers and witnesses to India’s market liberalization, is now available. 2. Mini Cities. 3. The…
  - (2026-07-25) [Marginal Revolution] A natural experiment in economics
      To study whether and how academics respond to political pressure, we exploit a natural experiment: the publication in early 2025 of a “blacklist” of words flagged by the U.S. government. We find that the release of this…

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=22, 14d-median=20; carrying terms: amendment, safety, special, regulatory, proposing, coast, amendments, published, certain, final, provide, action
- state_bills: today=151, 7d-median=124, 14d-median=124; carrying terms: ombudsman, development, things, enter, transfer, amending, duties, establish, commission, generally, identify, regarding
- state_news: today=765, 7d-median=765, 14d-median=765; carrying terms: circuit, decision, pushed, alabama, illinois, pillen, challenger, photo, development, cover, things, agriculture
- local_news: today=252, 7d-median=227, 14d-median=246; carrying terms: region, google, afternoon, decoding, traffic, again, magazine, scaled, vehicle, school, woman, report
- foreign_news: today=1036, 7d-median=1036, 14d-median=1036; carrying terms: decision, wooden, measures, match, videos, medium, bruce, survivors, strike, better, march, broke
- chinese_internal: today=285, 7d-median=303, 14d-median=303; carrying terms: google, cbmia, china, lxtfb, cbmibefvx, caixin, cbmickfvx, chinese, cbmib, global, target, cbmizefvx
- russian_internal: today=862, 7d-median=982, 14d-median=908; carrying terms: wildberries, russian, financial, error, forbidden, google, https, client, httperror, bloomberg, title, europe
- ukrainian_internal: today=139, 7d-median=128, 14d-median=137; carrying terms: mykhailo, crimea, civilians, offered, strike, removal, region, broke, ministry, launched, title, institute
- ukraine_theater: today=406, 7d-median=406, 14d-median=406; carrying terms: viirs, assurance, havlsbkzqyzzlt, tmudbzdlmu, development, qzbkvme, zawtku, mlzqv, dbnlnv, ugvhdvpumzz, klvfkyvpsslfydwkzbvdmdgltqxf, wytfuzhp
- paper_bets: today=128, 7d-median=144, 14d-median=144; carrying terms: texas, artist, market, approve, current, matthew, trillionaire, emerson, officially, nominee, resolve, manifold
- weather: today=190, 7d-median=171, 14d-median=171; carrying terms: upper, national, oxnard, twoat, sensitive, additional, northeastern, afdfwd, warned, index, marine, coastal
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: headline, vixcls, money, assets, spread, jtsjol, recession, energy, dcoilwtico, latest, jolts, supply
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, rates, close, yield, crypto, futures, bitcoin, proxy, treasury, credit, crude, china
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=120, 7d-median=120, 14d-median=119; carrying terms: national, haiti, measures, crimea, islamic, development, description, agreement, detect, effects, cyber, concerning
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, client, https, error, httperror, quantitative, quiver, quiverquant, unauthorized
- billionaires: today=37, 7d-median=37, 14d-median=36; carrying terms: ambani, warren, spacex, charles, huang, devasini, amazon, buffett, microsoft, julia, yanai, brokerage
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: international, supreme, blanche, trade, state, appeals, district, court, school, delaware, board, california
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, filed, issuer, accno, therapeutics, holdings, amended, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: cooper, senate, raised, congress, sherrod, disbursements, robert, committee, alexandria, pinkston, talarico, michael
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english, japan, japanherald
- gdelt_gkg: today=25, 7d-median=25, 14d-median=45; carrying terms: english, chinese, latest, global, hormuz, major, attack, strait
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: english, domain, police, australia, language, kingdom, trump, crash, dailymail, caused, bignewsnetwork, found
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=5, 7d-median=9, 14d-median=9; carrying terms: position, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: mongbwalu, healthcare, algeria, samples, national, barisal, critically, incubation, current, clades, including, ituri
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: insufficient, fortisandbox, federation, directory, lockout, critical, management, microsoft, untrusted, association, forgery, option
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=240, 7d-median=205, 14d-median=196; carrying terms: ethiopia, flood, storm, minor, north, romania, honduras, panama, bosnia, austria, indonesia, gabon
- usgs_quakes: today=5, 7d-median=17, 14d-median=18; carrying terms: puerto, depth, islands, mexico, kermadec, philippines, madero, vanuatu
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ethiopia, resolves, price, minister, interest, meeting, volume, rates, prime, change, increase, hormuz
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, https, useful, perhaps, conversable, marginal, revolution, economist, assorted, benefit, links, marginalrevolution
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: computer, cyber, models, giant, malware, provides, available, weekly, accessed, policy, spectrum, security
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: ketanji, desaulnier, shomari, warren, national, ratcliffe, yassamin, beatty, robert, crawford, patty, sheri
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: decision, today, market, placement, placed, consensus, unavailable, module, markets, either, paper, identify

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*