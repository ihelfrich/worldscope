# WORLDSCOPE morning brief — 2026-07-25

## Headline
1794 new items across 25 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (429) · Russian Internal News (state + in-exile) (325) · World leaders & government officials (324) · U.S. Weather + Severe / Climate Outlooks (195) · Chinese Internal News (149) · Local News: St. Louis + Atlanta (71) · GDELT GKG — themes / entities / watch areas (50) · Ukrainian Internal News (national + local Kyiv) (44) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30) · Ukraine Theater (total-war monitoring) (24) · State-Level News (22)

## What changed today
### International News + Multilateral Institutions — 429 new of 1023 total
  - (2026-07-24) [Global] Long overdue, life-changing or frivolous? Your thoughts on wedding rule changes
      The government wants to relax wedding laws so couples can get married almost anywhere.
  - (2026-07-25) [Global] What does the South make of the King of the North?
      BBC South has been hearing from people about new PM Andy Burnham's first week in the top job.
  - (2026-07-25) [Global] 'We feel the pressure juggling holiday logistics'
      Parents say childcare costs, unpaid leave and SEND support gaps make summer holidays harder
  - (2026-07-24) [Global] Students tell us how to keep graduation outfit costs down
      Four newly graduated students tell us how they kept the cost of their dresses and suits down.
  - (2026-07-25) [Global] More than 220,000 evacuated in France and Spain due to wildfires
      French firefighters battle a blaze heading towards Bordeaux while officials in Madrid say they face the "worst fire in the history of the region".
  - (2026-07-25) [Global] Texts reveal 14-year-old allegedly murdered by singer D4vd had pregnancy and abortion
      Prosecutors allege D4vd started abusing the girl when she was 13 and she had threatened to expose him.

### Russian Internal News (state + in-exile) — 325 new of 997 total
  - (2026-07-25) Бывшему министру обороны Украины Михаилу Федорову предложили должность советника главы Минобороны Италии | LEDE: Министр обороны Италии Гвидо Крозетто заявил, что предложил Михаилу Федорову,] (ru: Быв…
      Министр обороны Италии Гвидо Крозетто заявил, что предложил Михаилу Федорову, уволенному с поста министра обороны Украины, должность своего советника. Об этом он рассказал газете La Repubblica (публикация доступна по под…
  - (2026-07-25) Все говорят, что «Одиссею» нужно смотреть только в IMAX. А чем на самом деле отличается этот формат от других? И насколько хуже картинка в обычном зале? | LEDE: Одна их многих претензий крит] (ru: Все…
      Одна их многих претензий критиков к «Одиссее» Кристофера Нолана — классовая. Ведь чтобы посмотреть фильм в том виде, каким его задумал режиссер, нужно выложить внушительную сумму (в среднем 25 долларов в США и до 30 евро…
  - (2026-07-25) В Грузии снова произошел масштабный блэкаут | LEDE: В Грузии второй раз за двое суток произошло масштабное отключение электроэнергии, сообщают Newsgeorgia и Paper Kartuli. ] (ru: В Грузии снова произо…
      В Грузии второй раз за двое суток произошло масштабное отключение электроэнергии, сообщают Newsgeorgia и Paper Kartuli.
  - (2026-07-25) В России становится все сложнее защищать краснокнижных животных. Кто под угрозой вымирания? И есть ли вообще польза от того, что их заносят в Красную книгу? | LEDE: Проект «Если быть точным»] (ru: В Р…
      Проект «Если быть точным» в новой статье рассказывает, как создается Красная книга России, зачем она нужна и почему вокруг нее периодически возникают скандалы. Мы решили пересказать этот материал, дополнив его некоторыми…
  - (2026-07-25) В Екатеринбурге произошел пожар около склада Wildberries. Его атаковали украинские беспилотники | LEDE: Рядом со складом Wildberries в Екатеринбурге произошел пожар. Местное издание E1.ru пу] (ru: В Е…
      Рядом со складом Wildberries в Екатеринбурге произошел пожар. Местное издание E1.ru публикует фотографии и видео густого дыма, который поднимается в районе склада.
  - (2026-07-25) Более 300 украинских дронов атаковали регионы России и Крым. В Ростовской области пострадали пять человек | LEDE: Украинские беспилотники в ночь на 25 июля атаковали Ростовскую область, сооб] (ru: Бол…
      Украинские беспилотники в ночь на 25 июля атаковали Ростовскую область, сообщил глава региона Юрий Слюсарь. В Ростове-на-Дону пострадали четыре человека, еще один человек пострадал в Красносулинском районе.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### U.S. Weather + Severe / Climate Outlooks — 195 new of 213 total
  - (2026-07-25) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-25) [Moderate] Gale Warning: Gale Warning issued July 25 at 2:25AM PDT until July 26 at 3:00AM PDT by NWS Los Angeles/Oxnard CA
      * WHAT...Northwest winds 20 to 30 kt with gusts up to 35 kt and combined seas 7 to 9 ft expected when conditions are worst. * WHERE...Point Piedras Blancas to Point Sal from 10 to 60 NM and Waters from Pt. Sal to Santa C…
  - (2026-07-25) [Severe] Flood Warning: Flood Warning issued July 25 at 5:25AM EDT until July 25 at 9:00PM EDT by NWS Peachtree City GA
      ...The Flood Warning continues for the following rivers in Georgia... Big Creek near Alpharetta affecting Fulton and Forsyth Counties. * WHAT...Minor flooding is occurring and minor flooding is forecast. * WHERE...Big Cr…
  - (2026-07-25) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 25 at 4:22AM CDT until July 25 at 10:00AM CDT by NWS Hastings NE
      * WHAT...For the Dense Fog Advisory this morning, visibility of one quarter mile or less in dense fog. For the Heat Advisory, heat index values mainly as high as 105 to 110 degrees during the afternoon and early evening…
  - (2026-07-25) [Moderate] Heat Advisory: Heat Advisory issued July 25 at 4:22AM CDT until July 27 at 10:00PM CDT by NWS Hastings NE
      * WHAT...Heat index values mainly as high as 105 to 110 degrees during the afternoon and early evening hours. The overall-highest readings are currently forecast to occur on Sunday. * WHERE...Mitchell, Osborne, and Rooks…
  - (2026-07-25) [Moderate] Heat Advisory: Heat Advisory issued July 25 at 4:22AM CDT until July 27 at 10:00PM CDT by NWS Hastings NE
      * WHAT...For the Dense Fog Advisory this morning, visibility of one quarter mile or less in dense fog. For the Heat Advisory, heat index values mainly as high as 105 to 110 degrees during the afternoon and early evening…

### Chinese Internal News — 149 new of 280 total
  - (2026-07-25) 求生在罗马｜猎读 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBOOTZiMW9FN2kyOUZpcUhkU2dEZzl3YmlCX1hyVFN2SDVmSG4td0FTTkI1SVlpY2Y4bTVXa0Q2aEYxWmszcFdWQV9tYkxIYVgybm5sRU5jaHdrT] (zh:…
      求生在罗马｜猎读 财新
  - (2026-07-25) NBA球星詹姆斯宣布加盟费城76人，将在第四支球队开启第24个赛季 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE5teFFsaDliOW8zYzdRYUxCOUJtS0dwUkVhWkJ5ZHlkYUxfWnhIb0MtSERIYnY4QTdvRGFzcjhGSm1tN0JPNW4x] (zh:…
      NBA球星詹姆斯宣布加盟费城76人，将在第四支球队开启第24个赛季 财新
  - (2026-07-25) Anthropic发新模型Opus 5 性能接近Fable 5价格砍半 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE01WXVTalQzcTFqZ0RRX3VFNnpZVlkwQmhCc0hKQS1LNmtQU2xvUHlQN0RpTTgwMHgtRVp2XzM5ZUFpenpYSn] (zh:…
      Anthropic发新模型Opus 5 性能接近Fable 5价格砍半 财新
  - (2026-07-25) 聚焦“一把手”腐败 海南高官肖杰被指利用职权插手工程项目 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE5XNjBqQWRyYWtLMGc4bGJxTTlxZHhJWWJCQjVwOXVGcmxoVDE3MWJXb3NZNU1qM2w1WHV6ZmZGR3B] (zh:…
      聚焦“一把手”腐败 海南高官肖杰被指利用职权插手工程项目 china.caixin.com
  - (2026-07-25) 官方公布上半年“伏虎”成绩单 立案50人、处分74人再创新高 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTE9WNi1URjRtOUhvdTFla1R4MU9CczNETjZtNU80SnU3NjhzdWcyRkNUMVNSc1YwZEFjalVXeG1yc] (zh:…
      官方公布上半年“伏虎”成绩单 立案50人、处分74人再创新高 china.caixin.com
  - (2026-07-24) 作为反制措施 中国商务部将14家欧盟企业纳入出口管控名单 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTFA2M3FsMFpYZmMxcGRnd1dGOWxYNGlDUTZneE9pM2xKaWtObDdIRk5haFdrT1pZcF9aYVlpdFpYWGlYY0Y5NjU4dU8xe] (zh:…
      作为反制措施 中国商务部将14家欧盟企业纳入出口管控名单 财新

### Local News: St. Louis + Atlanta — 71 new of 239 total
  - (2026-07-23) [St. Louis] Bethalto man charged after police say he threatened school district, officers - KMOV
      Bethalto man charged after police say he threatened school district, officers KMOV
  - (2026-07-23) [St. Louis] Nearly 100 dogs rescued from Metro East hoarding case - KMOV
      Nearly 100 dogs rescued from Metro East hoarding case KMOV
  - (2026-07-24) [St. Louis] KMOV Channel 32.1 to be the new home of the ABC Television Network, expanding local news coverage in St. Louis - KMOV
      <a href="https://news.google.com/rss/articles/CBMiyAFBVV95cUxNU2JDVVVjSmZrd056Y3k3RGpzZm5IN19RSkVrQzNGNFZNUkNneXRKREFrcmoyZHJfQkdvWXhyeWxWWkNXSDZvOG4zbl9GM21LaWlBMFEzaXRMR19PUUxmY3pxdHRzQUIwaDhlcnFwU1dFSUZvQnVHbDJaaFM0Mm…
  - (2026-07-25) [St. Louis] Investigation underway in Jefferson County after shooting leaves 1 dead, another injured Friday night - KMOV
      <a href="https://news.google.com/rss/articles/CBMi0wFBVV95cUxPZk5oeGNvcFZaYzI5MDEwLXBpS2RxR1B3TzVZRHNrcVlqVTJpRzU0LUt4cHViVnJjQjlIY2FVOS14MG9BUGdpZlNmRl9jYV8zOWZzV1A0VXoxYXJ4Mi1na0dqRTRkN2I4Vm5VR3RQRnk0djVTLVZ5aWtYTXRJZU…
  - (2026-07-23) [St. Louis] The Millennium Hotel is coming down, its iconic rotating restaurant will live on at the City Museum - KMOV
      <a href="https://news.google.com/rss/articles/CBMiwgFBVV95cUxQdTc2UDFUbGtqY3UxdUtFdmRXd3duVzNia0xLd1J4UGhlYnNPWWRCZndPTGk5SXNXeS1ZWWZxd3dHR3Jwdll1ZFNRZ0VjTlRJWF9sUzdtU2JBWktVa1ppZ2s0bVlpbTlNNXdMN0RJS3UwZ0pqV01OZXVHakhVRG…
  - (2026-07-23) [St. Louis] Why not have the NBA in St. Louis? - KMOV
      Why not have the NBA in St. Louis? KMOV

### GDELT GKG — themes / entities / watch areas — 50 new of 50 total
  - (2026-07-25) [Russia oil sanctions perimeter · themes] ¿ Qué esperamos de Estados Unidos los demócratas y liberales del continente ?
      infobae.com · Spanish · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] موقع بكرا - ترامب : إيران تُدار حاليًا من قبل ديكتاتور متطرف ولن نسمح لها بامتلاك سلاح نووي
      bokra.net · Arabic · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] SpaceX星舰第13次试飞圆满收官 首次投放V3星链 助推器与星舰均受控溅落 - 业界动态 - ITBear科技资讯
      itbear.com.cn · Chinese · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] Дрони атакували Ростов , Енгельс та Луганськ : у містах виникли пожежі , горить казарма
      uainfo.org · Ukrainian · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] 자기 손길 뿌리쳤다고 8살 아이 때려 실신시킨 50대 … 출동한 경찰까지 폭행
      munhwa.com · Korean · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] Yolcu otobüsü otomobile çarptı : 2 si ağır 30 yaralı
      kocaeligazetesi.com.tr · Turkish · tone NA

### Ukrainian Internal News (national + local Kyiv) — 44 new of 124 total
  - (2026-07-25) Російський удар по виставці озброєння на Київщині: організатору заходу оголосили підозру | LEDE: Організатора виставки озброєння на Київщині, де внаслідок російського удару 24 липня загинули 10] (uk:…
      Організатора виставки озброєння на Київщині, де внаслідок російського удару 24 липня загинули 10 людей та ще близько 100 дістали поранення, затримали та оголосили йому про підозру.
  - (2026-07-25) В Міноборони Румунії розповіли подробиці про нове збиття дрона | LEDE: У Міністерстві оборони Румунії розповіли подробиці інциденту з порушенням повітряного простору країни невідомим дроном і й] (uk:…
      У Міністерстві оборони Румунії розповіли подробиці інциденту з порушенням повітряного простору країни невідомим дроном і його подальше збиття.
  - (2026-07-25) Трамп жартома допустив, що балотуватиметься на третій президентський термін | LEDE: Президент США Дональд Трамп жартома заговорив про можливість балотування третій термін, що прямо заборонено а] (uk:…
      Президент США Дональд Трамп жартома заговорив про можливість балотування третій термін, що прямо заборонено американською конституцією.
  - (2026-07-25) Від розмінування до результатів: переосмислення протимінної діяльності в Україні | LEDE: Ефективне розмінування: як Україна може швидше та безпечніше відновити території, спираючись на досвід ] (uk: В…
      Ефективне розмінування: як Україна може швидше та безпечніше відновити території, спираючись на досвід Zone Rouge.
  - (2026-07-25) Росіяни вночі вдарили по території терміналу "Нової пошти" в Сумах – убили 3 водіїв | LEDE: У Сумах внаслідок російської атаки загинули троє водіїв "Нової пошти".] (uk: Росіяни вночі вдарили по терито…
      У Сумах внаслідок російської атаки загинули троє водіїв "Нової пошти".
  - (2026-07-25) Єкатеринбург атакували дрони: на території складу Wildberries вирує пожежа | LEDE: Атака дронами на Wildberries у Єкатеринбурзі: вирує пожежа біля складу] (uk: Єкатеринбург атакували дрони: на територ…
      Атака дронами на Wildberries у Єкатеринбурзі: вирує пожежа біля складу

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-25) [Tangney Jeffrey] Form 4 (Reporting)
      filed 2026-07-25 01:59 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Doximity, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:59 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Sams Louise S] Form 4 (Reporting)
      filed 2026-07-25 01:51 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:51 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Auguste Laurent] Form 4 (Reporting)
      filed 2026-07-25 01:49 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:49 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Ukraine Theater (total-war monitoring) — 24 new of 240 total
  - (2026-07-25) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-25) [Liveuamap] Explosions were also reported in Luhansk - Liveuamap
      Explosions were also reported in Luhansk Liveuamap
  - (2026-07-25) [Liveuamap] Explosions were reported in Belgorod - Liveuamap
      Explosions were reported in Belgorod Liveuamap
  - (2026-07-25) [Liveuamap] Fires burning at the logistics warehouses near St.Petersburg - Liveuamap
      Fires burning at the logistics warehouses near St.Petersburg Liveuamap
  - (2026-07-24) [Liveuamap] The Revolutionary Guard reports shooting down an American cruise missile in the skies of Kahnuj city last night. - Liveuamap
      The Revolutionary Guard reports shooting down an American cruise missile in the skies of Kahnuj city last night. &n
  - (2026-07-24) [Liveuamap] Lufthansa Group carriers Austrian Airlines and ITA Airways have canceled their morning flights to Israel amid growing concerns over a possible escalation with Iran, Israel&039;s Channel 12…
      Lufthansa Group carriers Austrian Airlines and ITA Airways have canceled their morning flights to Israel amid growing conce

### State-Level News — 22 new of 727 total
  - (2026-07-25) [Arizona] Election deniers and conspiracy theorists top Arizona’s Republican nominees this year
      Republican voters in Arizona sent a litany of election deniers to the November ballot, chief among them the nominees for the top three statewide offices. But they’re far from the only ones who advanced to the general ele…
  - (2026-07-24) [Colorado] USDA union leaders rally against proposed DC downsizing
      A group of current and former U.S. Department of Agriculture employees are calling on the Trump administration to halt the mandated relocation of more than 2,500 employees from its Washington, D.C., headquarters to five…
  - (2026-07-25) [Florida] ‘E pluribus unum’ is not a slogan. It’s a choice.
      Like two sides of a coin imprinted with the nation’s motto, “e pluribus unum” — out of many, one — America’s political factions are cast in opposition, but they are intrinsically bound together as parts of a larger whole…
  - (2026-07-25) [Maine] It’s too late to rebrand Bobby Charles | Letter
      The gubernatorial candidate is not remotely close to the center.
  - (2026-07-25) [Maine] Kudos to Maine Dems for a job well done | Letter
      Hats off to party chairman Charlie Dingman and the Maine Democrats. As has been recently reported, never in modern American political history has a state party managed a competitive nominating contest on such a short tim…
  - (2026-07-25) [Maine] Dunlap will deliver a ‘people’s agenda’ for Maine’s 2nd District | Opinion
      <img width="1024" height="650" src="https://www.pressherald.com/wp-content/uploads/sites/4/2026/02/43307327_20251208_dunlap_9.jpg?w=1024" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decodin…

### World News (by country, top stories) — 18 new of 18 total
  - (2026-07-25) [China] चीन बना विदेशी पर्यटकों की पसंद
      hindi.cri.cn · English
  - (2026-07-25) [China] यीवू में विकास का अनुभव
      hindi.cri.cn · English
  - (2026-07-25) [China] Trump says US locked and loaded , vows more Iran strikes while hinting at talks
      scmp.com · English
  - (2026-07-25) [China] Poster | China Jingdezhen Handicraft Porcelain Industry Sites added to UNESCO World Heritage List
      beijingbulletin.com · English
  - (2026-07-25) [China] Will not bow to US bullying : Araghchi rejects Washington pressure tactics at SCO summit
      beijingbulletin.com · English
  - (2026-07-25) [China] From factory floor to innovation hub : how foreign firms deepen China presence
      beijingbulletin.com · English

### Government & military aircraft airborne (OpenSky) — 16 new of 16 total
  - (2026-07-25) SAMU691 (France)
      icao24: 39c994 · position: (45.9425, 4.7488) · alt: 487m · 258km/h
  - (2026-07-25) JAF3NE (Belgium)
      icao24: 44d1ba · position: (46.7278, 0.057) · alt: 10972m · 842km/h
  - (2026-07-25) JAF5KH (Belgium)
      icao24: 44d1a6 · position: (39.3435, 24.809) · alt: 11582m · 763km/h
  - (2026-07-25) JAF9WL (Belgium)
      icao24: 44d1a7 · position: (38.3086, -0.7496) · alt: 2057m · 421km/h
  - (2026-07-25) JAF74C (Belgium)
      icao24: 44d1b3 · position: (38.9967, 24.9828) · alt: 11582m · 779km/h
  - (2026-07-25) JAF3MJ (Belgium)
      icao24: 44d1b4 · position: (47.847, 1.3031) · alt: 10637m · 820km/h

### U.S. Federal Action — 11 new of 12 total
  - (2026-07-27) Modernizing Reactor Licensing, Safety Oversight, and Siting Practices; Correction
      The U.S. Nuclear Regulatory Commission (NRC) is correcting a notice published in the Federal Register on July 16, 2026, regarding the modernization of reactor licensing, safety oversight, and siting practices to address…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Report and Order that promotes the deployment of submarine cables while strengthening national security interests in connection…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Further Notice of Proposed Rulemaking (Second FNPRM) that seeks to further prevent evolving national security risks associated…
  - (2026-07-27) Modernizing Package Certification Requirements
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its regulations governing the packaging and transportation of radioactive material. This proposed action is responsive to several executive orders and th…
  - (2026-07-27) Updating Website and Contact Information, and Authorizations for Payments for Legal Services
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is adopting a final rule to update website and contact information in certain parts of the Code of Federal Regulations (CFR). Additionally, OFAC is…
  - (2026-07-27) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action
      NMFS announces an inseason action for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds fishing dates in August and September in the Co…

### IT, InfoSys & cybersecurity news (last 7 days) — 8 new of 57 total
  - (2026-07-25) [BleepingComputer] OpenAI confirms ChatGPT is down worldwide
      ChatGPT, the famous artificial intelligence chatbot that allows users to converse with various personalities and topics, has connectivity issues worldwide. [...]
  - (2026-07-25) [The Hacker News] Researcher Publishes GitLab RCE PoC Letting Authenticated Users Run Commands as Git
      Security researcher Yuhang Wu at depthfirst has published a working proof-of-concept (PoC) exploit that executes commands as git on an unpatched self-managed GitLab 18.11.3 server. An ordinary authenticated user triggers…
  - (2026-07-25) [The Register] BOFH: This printer engineer knows every trick in the book
      But so does this customer
  - (2026-07-25) [TechCrunch] I tried out OpenAI’s new AI keypad — which will be fun for some coders and slightly mystifying to everyone else
      OpenAI's fancy new AI keypad will be a lot of fun for some, while many others are probably not going to touch it.
  - (2026-07-24) [The Register] Anthropic debuts Opus 5 at half the price of its Fable sibling
      And as a bonus, it doesn't require data retention
  - (2026-07-24) [Ars Technica] Wildfire forces evacuation of NASA's Deep Space Network complex in Spain
      "Any potential damage will be assessed when it is safe to do so."

### Court opinions of consequence (federal & state) — 7 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, 9th Cir.: Theis v. Intermountain Education Service District - Board of Directors
  - (2026-07-21) U.S. Court of Appeals, 9th Cir.: Seagraves v. Washington State Department of Children Youth and Families
  - (2026-07-21) U.S. Court of Appeals, 9th Cir.: United States v. Colar
  - (2026-07-21) U.S. Court of Appeals, 3rd Cir.: In re: Avandia Marketing v.
  - (2026-07-21) U.S. Court of Appeals, 3rd Cir.: John Doe v. Princeton University Trustees
  - (2026-07-21) U.S. Court of Appeals, 2nd Cir.: Hayden v. Koons

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-07-25) LoL: LGD Gaming vs Team WE - Game 2 Winner
      yes price: 0% · 24h volume: $1,053,909 · resolves 2026-07-25
  - (2026-07-25) LoL: LGD Gaming vs Team WE (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $824,522 · resolves 2026-07-25
  - (2026-07-25) LoL: LGD Gaming vs Team WE - Game 1 Winner
      yes price: 0% · 24h volume: $571,191 · resolves 2026-07-25
  - (2026-07-25) LoL: Invictus Gaming vs Weibo Gaming - Game 1 Winner
      yes price: 48% · 24h volume: $463,692 · resolves 2026-07-25
  - (2026-07-25) Will Trump meet with Netanyahu by July 31, 2026?
      yes price: 97% · 24h volume: $304,058 · resolves 2026-07-31
  - (2026-07-25) Will LeBron James play for the Cleveland Cavaliers in 2026-27?
      yes price: 0% · 24h volume: $269,435 · resolves 2026-10-31

### Paper Trading Scorecard — 5 new of 141 total
  - (2026-07-25) [Polymarket] Will any presidential candidate win outright in the first round of the Brazil election?
      Presidential elections are scheduled to be held in Brazil on October 4, 2026. A second round will be held if no candidate secures more than 50% of the valid votes in the first round. This market will resolve to "Yes" if…
  - (2026-07-25) [Manifold] Will Gavin Newsom be the favorite for Democratic Nominee on Dec. 31, 2026? [Per Polymarket Data]
  - (2026-07-25) [Manifold] Will Gavin Newsom cease to be the favorite Democratic Nominee before the end of 2026? [Per Polymarket Data]
  - (2026-07-25) [Manifold] Will Ronaldo score in his final match for Portugal?
  - (2026-07-25) [Manifold] Will "Mathematicians are Feeling the Doom" make the top fifty posts in LessWrong's 2026 Annual Review?

### GDACS — global disaster alerts — 5 new of 228 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-07-23) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 10455 ha
  - (2026-07-23) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 10455 ha

### State Legislative Action — 4 new of 107 total
  - (2026-07-25) [Alaska HB 324] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
  - (2026-07-25) [Alaska HB 316] An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
      An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
  - (2026-07-25) [Colorado SB 5] Rights Violation in Immigration Enforcement Remedy
      The act creates a statutory cause of action for a person who has their federal constitutional rights violated by another person who, acting under color of law, is participating in civil immigration enforcement. A person…
  - (2026-07-25) [Colorado HB 1429] County Administration Public Assistance Programs
      The act requires the department of health care policy and financing, in coordination with the department of human services and the department of early childhood (state departments), to contract with a single county depar…

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 120 total
  - (2026-07-25) [USASpending] $819,751,946 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-25) [USASpending] $733,516,127 → BL HARBERT INTERNATIONAL LLC: BEIRUT, LEBANON NEW EMBASSY CONSTRUCTIONIGF::CL::IGF
      Agency: Department of State. Description: BEIRUT, LEBANON NEW EMBASSY CONSTRUCTIONIGF::CL::IGF
  - (2026-07-25) [USASpending] $665,616,978 → HII MISSION TECHNOLOGIES CORP: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE
      Agency: General Services Administration. Description: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE ISR AND NEXTGEN TECHNOLOGY (LOGIX)
  - (2026-07-25) [USASpending] $614,391,052 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…

### USGS earthquakes (M4.5+, past day) — 3 new of 19 total
  - (2026-07-25) M 5.1 - 43 km SW of Puerto Madero, Mexico
      M5.1 · 43 km SW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-25) M 5.0 - 57 km S of Sarangani, Philippines
      M5.0 · 57 km S of Sarangani, Philippines · depth 52.163 km
  - (2026-07-24) M 5.0 - 96 km NNW of Port-Olry, Vanuatu
      M5.0 · 96 km NNW of Port-Olry, Vanuatu · depth 10 km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-25) [Marginal Revolution] A natural experiment in economics
      To study whether and how academics respond to political pressure, we exploit a natural experiment: the publication in early 2025 of a “blacklist” of words flagged by the U.S. government. We find that the release of this…
  - (2026-07-25) [Marginal Revolution] Crypto markets in everything? (moo)
      Farmers in Parana, Brazil, struggling to get banks to loan them cash, became the first to tokenize livestock and place 10 dairy milk cows’ tokens for trade on the country’s B3 national stock exchange. They generated near…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=22, 14d-median=20; carrying terms: safety, amendment, proposing, regulatory, action, published, amendments, final, certain, special, coast, provide
- state_bills: today=107, 7d-median=121, 14d-median=121; carrying terms: application, generally, whether, annual, except, appropriation, interests, necessary, supplemental, funds, consent, employees
- state_news: today=727, 7d-median=747, 14d-median=747; carrying terms: brief, whitmer, courts, rights, billionaire, month, whether, politics, route, waiver, waters, annual
- local_news: today=239, 7d-median=227, 14d-median=239; carrying terms: dispatch, august, figure, lettuce, saportareport, region, police, srcset, async, resize, uploads, night
- foreign_news: today=1023, 7d-median=1023, 14d-median=1024; carrying terms: readtimeout, brief, rights, zhejiang, jiulong, china, month, politics, recommendation, august, return, constitutional
- chinese_internal: today=280, 7d-median=303, 14d-median=303; carrying terms: china, politics, cbmib, title, capital, chinese, blank, cbmiw, cbmix, articles, cbmixkfvx, cbmiykfvx
- russian_internal: today=997, 7d-median=997, 14d-median=982; carrying terms: journal, google, social, found, russian, gazeta, times, bloomberg, https, reuters, httperror, media
- ukrainian_internal: today=124, 7d-median=125, 14d-median=128; carrying terms: month, whether, position, syrsky, continued, toward, technology, tankers, security, fires, region, supply
- ukraine_theater: today=240, 7d-median=377, 14d-median=400; carrying terms: ncvnxytjjumnndgxhb, iwvbkadftvgjnwmzpemzdefn, edzscg, extra, suvzbc, cxvpvtv, rtazlu, cdbirwrtef, exhnznffove, nwgtmkwttlnioe, fvytbldg, fzehjre
- paper_bets: today=141, 7d-median=144, 14d-median=144; carrying terms: tradable, finish, rippling, manifold, earthquake, minnesota, magnitude, anthropic, midterms, nuclear, israel, standard
- weather: today=213, 7d-median=171, 14d-median=171; carrying terms: damage, basin, galveston, texas, gusts, discussion, waters, warning, return, issued, drier, southwest
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, dexchus, inflation, supply, dexjpus, cpiaucsl, rates, walcl, crude, unrate, jtsjol, total
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, large, yield, agriculture, bitcoin, crypto, rates, crude, close, natural, proxy, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=120, 7d-median=120, 14d-median=119; carrying terms: misappropriation, campaign, joint, svewsgvsuthdntnoyjntexgxalveltdpmhrirulprkm, leland, application, paeez, mtjwwxz, rights, award, extra, ambassador
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: unauthorized, error, https, congresstrading, quantitative, quiver, client, quiverquant, httperror
- billionaires: today=30, 7d-median=36, 14d-median=34; carrying terms: bernard, peterffy, diversified, changpeng, commodities, oracle, spain, google, francoise, finance, investments, larry
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: district, court, blanche, trade, supreme, international, state, appeals, children, school, board, delaware
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, reporting, filed, holdings, therapeutics, amended, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: booker, pinkston, brown, elect, house, receipts, cycle, david, lindsey, committee, shawn, filing
- gdelt_regions: today=18, 7d-median=6, 14d-median=6; carrying terms: english, japan
- gdelt_gkg: today=50, 7d-median=45, 14d-median=46; carrying terms: english, trump, russia, chinese, themes, spanish, russian, arabic, sanctions, perimeter, italian, against
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=16, 7d-median=11, 14d-median=11; carrying terms: position, france, ground, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: notified, pacific, support, discontinued, health, safety, distributed, elements, spain, multiple, workers, seven
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: remediation, option, restrictive, suite, services, langflow, oracle, connection, cisco, fortinet, mechanism, account
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, probability, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=228, 7d-median=205, 14d-median=196; carrying terms: equatorial, cambodia, spain, earthquake, agricultural, magnitude, indonesia, russia, honduras, green, north, hungary
- usgs_quakes: today=19, 7d-median=18, 14d-median=19; carrying terms: depth, puerto, mexico, indonesia, islands, madero, philippines, russia, abepura, region, vanuatu, tonga
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: ethiopia, interest, rates, prime, meeting, volume, minister, resolves, price, change, decrease, increase
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, class, https, economist, perhaps, useful, conversable, revolution, paper, benefit, marginalrevolution, among
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: blogging, friday, cybersecurity, weekly, schneier, available, artificial, almost, download, technology, microsoft, attack
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: brown, health, rogers, pallone, ronny, abraham, maria, elissa, david, frankel, nadler, ratcliffe
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, module, consensus, identify, decision, claude, markets, market, today, evidence, placement, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*