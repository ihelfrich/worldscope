# WORLDSCOPE morning brief — 2026-07-25

## Headline
1834 new items across 24 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (390) · World leaders & government officials (324) · Russian Internal News (state + in-exile) (314) · U.S. Weather + Severe / Climate Outlooks (191) · Chinese Internal News (147) · GDELT GKG — themes / entities / watch areas (118) · Ukraine Theater (total-war monitoring) (85) · Local News: St. Louis + Atlanta (66) · Ukrainian Internal News (national + local Kyiv) (43) · SEC Form 4 insider transactions (recent) (40) · Sanctions & Designations (recent) (30) · State-Level News (21)

## What changed today
### International News + Multilateral Institutions — 390 new of 996 total
  - (2026-07-25) [Global] Dodging snipers, housing crisis forces Yemenis to live on front line
      Living near Taiz's front line forces families to make difficult choices amid sniper threats and economic hardships.
  - (2026-07-25) [Global] Wildfires in Spain and France force evacuation of 200,000 people
      France has appealed for international help, while Spain has declared a national emergency.
  - (2026-07-25) [Global] Born too soon: Premature babies fight for survival in Gaza
      Israel's genocidal war on Gaza is causing a surge in premature births and endangering mothers' health.
  - (2026-07-25) [Global] Guterres arrives in Syria in first official visit by a UN chief in 17 years
      The UN chief will meet Syrian President Ahmed al-Sharaa, who was under UN Security Council sanctions until last year.
  - (2026-07-25) [Global] Trump: ‘I’m running for a fourth term as President of the United States’
      During the White House Correspondents' Association dinner, Trump joked about running for a fourth presidential term.
  - (2026-07-25) [Global] Commonwealth Games: Gymnast Langton’s headfirst crash leads to concussion
      Gabriel Langton suffers concussion after headfirst crash off horizontal bar in the ⁠final rotation of the competition.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Russian Internal News (state + in-exile) — 314 new of 995 total
  - (2026-07-25) В Грузии снова произошел масштабный блэкаут | LEDE: В Грузии второй раз за двое суток произошло масштабное отключение электроэнергии, сообщают Newsgeorgia и Paper Kartuli. ] (ru: В Грузии снова произо…
      В Грузии второй раз за двое суток произошло масштабное отключение электроэнергии, сообщают Newsgeorgia и Paper Kartuli.
  - (2026-07-25) В России становится все сложнее защищать краснокнижных животных. Кто под угрозой вымирания? И есть ли вообще польза от того, что их заносят в Красную книгу? | LEDE: Проект «Если быть точным»] (ru: В Р…
      Проект «Если быть точным» в новой статье рассказывает, как создается Красная книга России, зачем она нужна и почему вокруг нее периодически возникают скандалы. Мы решили пересказать этот материал, дополнив его некоторыми…
  - (2026-07-25) В Екатеринбурге произошел пожар около склада Wildberries. Его атаковали украинские беспилотники | LEDE: Рядом со складом Wildberries в Екатеринбурге произошел пожар. Местное издание E1.ru пу] (ru: В Е…
      Рядом со складом Wildberries в Екатеринбурге произошел пожар. Местное издание E1.ru публикует фотографии и видео густого дыма, который поднимается в районе склада.
  - (2026-07-25) Более 300 украинских дронов атаковали регионы России и Крым. В Ростовской области пострадали пять человек | LEDE: Украинские беспилотники в ночь на 25 июля атаковали Ростовскую область, сооб] (ru: Бол…
      Украинские беспилотники в ночь на 25 июля атаковали Ростовскую область, сообщил глава региона Юрий Слюсарь. В Ростове-на-Дону пострадали четыре человека, еще один человек пострадал в Красносулинском районе.
  - (2026-07-25) «Умом понимаем, сердцем — никогда не простим». Что думают читатели «Медузы» об атаках ВСУ на склады Wildberries | LEDE: Украинские военные в последние дни начали целенаправленно и регулярно ] (ru: «Ум…
      Украинские военные в последние дни начали целенаправленно и регулярно бить по складам Wildberries. Эти удары напрямую затронули десятки тысяч россиян — как работников самого маркетплейса, так и малых предпринимателей, ко…
  - (2026-07-25) СК возбудил дело о теракте из-за атаки ВСУ на турбазы в Запорожской области | LEDE: ] (ru: СК возбудил дело о теракте из-за атаки ВСУ на турбазы в Запорожской области)

### U.S. Weather + Severe / Climate Outlooks — 191 new of 209 total
  - (2026-07-25) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-25) [Moderate] Rip Current Statement: Rip Current Statement issued July 25 at 4:45AM EDT until July 26 at 12:00AM EDT by NWS Tallahassee FL
      * WHAT...Dangerous rip currents expected. * WHERE...Gulf County Beaches. * WHEN...From 1 PM EDT /noon CDT/ this afternoon through this evening. * IMPACTS...Rip currents can sweep even the best swimmers away from shore in…
  - (2026-07-25) [Moderate] Rip Current Statement: Rip Current Statement issued July 25 at 4:45AM EDT until July 25 at 5:00AM EDT by NWS Tallahassee FL
      * WHAT...Dangerous rip currents expected. * WHERE...Gulf County Beaches. * WHEN...From 1 PM EDT /noon CDT/ this afternoon through this evening. * IMPACTS...Rip currents can sweep even the best swimmers away from shore in…
  - (2026-07-25) [Moderate] Rip Current Statement: Rip Current Statement issued July 25 at 4:45AM EDT until July 25 at 5:00AM EDT by NWS Tallahassee FL
  - (2026-07-25) [Moderate] Heat Advisory: Heat Advisory issued July 25 at 2:26AM MDT until July 26 at 9:00PM MDT by NWS Billings MT
      * WHAT...Hot conditions with high temperatures of 90 to 100. Today is expected to be the hottest day. * WHERE...Portions of central and south central Montana. * WHEN...Until 9 PM MDT Sunday. * IMPACTS...Hot temperatures…
  - (2026-07-25) [Severe] Extreme Heat Warning: Extreme Heat Warning issued July 25 at 2:26AM MDT until July 26 at 9:00PM MDT by NWS Billings MT
      * WHAT...Dangerously hot conditions with high temperatures of 98 to 108, hottest over eastern Montana. Today is expected to be the hottest day. * WHERE...Portions of central, south central, and southeast Montana and nort…

### Chinese Internal News — 147 new of 280 total
  - (2026-07-25) 斯洛伐克总统佩列格里尼将对中国进行国事访问 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE02RXBrNGRqMG5vTnFERjUzMVFUYXQ1bzhVNkRfeGJ1MjYzVWZvMmVKaW5DZUJzNjBPamdLb2c2Q2RvekdvVmJXVl9lSn] (zh:…
      斯洛伐克总统佩列格里尼将对中国进行国事访问 中国共产党新闻网
  - (2026-07-25) 中国援助的超算中心项目推动突尼斯数字化转型 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9YWlFDZ2FDNGpRSld3cTJsczlJT09BUFFlYXIwdVFwNGRIM2ZuRU9KdzNXd0FiRXpiSHhDTUFYWTZIZnNjTDVsRXdORT] (zh:…
      中国援助的超算中心项目推动突尼斯数字化转型 中国共产党新闻网
  - (2026-07-25) 习近平主席特使阴和俊将出席秘鲁总统权力交接仪式 - 中国共产党新闻网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1tRHJsYk5oWW1pZXNhM2labkF2R0dycVNYR3FKWDQzd0ZEMnNOdy1YV1dEc2NqbXVvQVpSOG1kODZWemhFYnl2dTBF] (zh:…
      习近平主席特使阴和俊将出席秘鲁总统权力交接仪式 中国共产党新闻网
  - (2026-07-25) “景德镇手工瓷业遗存”成功列入《世界遗产名录》 - 人民网－江西频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9kRzRuc2FOSEhqbVNZdUgyVGw3WC1yTVdYV0Y1NWRyX2lBaEhDV2ZrUWNCQU40UmpRUTh3amxkZEd2eEwwbVhEcG00] (zh:…
      “景德镇手工瓷业遗存”成功列入《世界遗产名录》 人民网－江西频道
  - (2026-07-25) 万山磅礴看主峰｜习近平谈亚太合作 - politics.people.com.cn | LEDE: <a href="https://news.google.com/rss/articles/CBMickFVX3lxTE1ndXR4ZTM0SFJla0lVVVBzMXJCNHozaVljaDltMUlrVWk1M044MWVCaUpPWm5PUE16UldJYWxJby1hVTZkY] (zh:…
      万山磅礴看主峰｜习近平谈亚太合作 politics.people.com.cn
  - (2026-07-25) 安徽省人民代表大会常务委员会任命人员名单 - 人民网－安徽频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1CRHFKek02amZ5VmpVbi1FeTRmTk9MaWdDT3JQdTk3Sl92RV9LeDBUTVFPLWtlaTk2U1E1c1NpS1BndmRqQ3lLcUFxdmJ] (zh:…
      安徽省人民代表大会常务委员会任命人员名单 人民网－安徽频道

### GDELT GKG — themes / entities / watch areas — 118 new of 118 total
  - (2026-07-25) [Russia oil sanctions perimeter · themes] בובי דרס פרה , ניקי עשתה טוורקינג : בדיחות טראמפ בנשף הנוצץ
      ynet.co.il · Hebrew · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] Saudijska Arabija napala Jemen nakon novih incidenata u Crvenom moru
      avaz.ba · Serbian · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] Черные или зеленые : врачи объяснили , какие оливки действительно полезнее для сердца и сосудов
      pravda.ru · Russian · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] 全国每人吃5斤才能吃完 ， 昔日网红食物价格腰斩
      163.com · Chinese · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] 领克林杰 ： 燃油车下滑幅度超预期
      yicai.com · Chinese · tone NA
  - (2026-07-25) [Russia oil sanctions perimeter · themes] La Cina prepara la guerra senza sparare : pescherecci - milizia e isole artificiali nel Mar Cinese Meridionale
      panorama.it · Italian · tone NA

### Ukraine Theater (total-war monitoring) — 85 new of 347 total
  - (2026-07-25) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-25) [Liveuamap] Explosions were also reported in Luhansk - Liveuamap
      Explosions were also reported in Luhansk Liveuamap
  - (2026-07-25) [Liveuamap] Explosions were reported in Belgorod - Liveuamap
      Explosions were reported in Belgorod Liveuamap
  - (2026-07-25) [Liveuamap] Fires burning at the logistics warehouses near St.Petersburg - Liveuamap
      Fires burning at the logistics warehouses near St.Petersburg Liveuamap
  - (2026-07-24) [Liveuamap] The Revolutionary Guard reports shooting down an American cruise missile in the skies of Kahnuj city last night. - Liveuamap
      The Revolutionary Guard reports shooting down an American cruise missile in the skies of Kahnuj city last night. &n
  - (2026-07-24) [Liveuamap] Lufthansa Group carriers Austrian Airlines and ITA Airways have canceled their morning flights to Israel amid growing concerns over a possible escalation with Iran, Israel&039;s Channel 12…
      Lufthansa Group carriers Austrian Airlines and ITA Airways have canceled their morning flights to Israel amid growing conce

### Local News: St. Louis + Atlanta — 66 new of 217 total
  - (2026-07-25) [St. Louis] Mega Millions winning numbers for Friday, July 24: Did anyone win the $743M jackpot?
      The Mega Millions jackpot soared to $743 million on Friday, making it the ninth largest in history while continuing to climb. Did you win?
  - (2026-07-25) [St. Louis] 'The show must go on,' Trump says in rambling speech at rescheduled correspondents' dinner
      Three months after a gunman foiled the White House Correspondents’ Association dinner, guests at the rescheduled event arrived to a different picture.
  - (2026-07-25) [St. Louis] Rick Moranis met with standing ovation at 'Spaceballs' sequel Comic-Con panel
      A crowd at the expo's massive Hall H stood to cheer and applaud as the 73-year-old actor — long absent from Hollywood.
  - (2026-07-25) [St. Louis] Community groups host space for St. Louis youth following regional safety concerns
      Event planner and Gateway Social partner with church to give teenagers a secure venue as local leaders seek long-term solutions to youth violence.
  - (2026-07-25) [St. Louis] FDA approves over-the-counter Tylenol with naproxen combination
      The first-of-its kind tablet will combine the popular pain relievers into one.
  - (2026-07-25) [St. Louis] Biden drops lawsuit seeking to block release of recordings of his interviews with a ghostwriter
      Biden’s attorneys filed the notice of voluntary dismissal in federal court less than a week after a divided appeals court rejected his bid to block the release.

### Ukrainian Internal News (national + local Kyiv) — 43 new of 123 total
  - (2026-07-25) В Міноборони Румунії розповіли подробиці про нове збиття дрона | LEDE: У Міністерстві оборони Румунії розповіли подробиці інциденту з порушенням повітряного простору країни невідомим дроном і й] (uk:…
      У Міністерстві оборони Румунії розповіли подробиці інциденту з порушенням повітряного простору країни невідомим дроном і його подальше збиття.
  - (2026-07-25) Трамп жартома допустив, що балотуватиметься на третій президентський термін | LEDE: Президент США Дональд Трамп жартома заговорив про можливість балотування третій термін, що прямо заборонено а] (uk:…
      Президент США Дональд Трамп жартома заговорив про можливість балотування третій термін, що прямо заборонено американською конституцією.
  - (2026-07-25) Від розмінування до результатів: переосмислення протимінної діяльності в Україні | LEDE: Ефективне розмінування: як Україна може швидше та безпечніше відновити території, спираючись на досвід ] (uk: В…
      Ефективне розмінування: як Україна може швидше та безпечніше відновити території, спираючись на досвід Zone Rouge.
  - (2026-07-25) Росіяни вночі вдарили по території терміналу "Нової пошти" в Сумах – убили 3 водіїв | LEDE: У Сумах внаслідок російської атаки загинули троє водіїв "Нової пошти".] (uk: Росіяни вночі вдарили по терито…
      У Сумах внаслідок російської атаки загинули троє водіїв "Нової пошти".
  - (2026-07-25) Єкатеринбург атакували дрони: на території складу Wildberries вирує пожежа | LEDE: Атака дронами на Wildberries у Єкатеринбурзі: вирує пожежа біля складу] (uk: Єкатеринбург атакували дрони: на територ…
      Атака дронами на Wildberries у Єкатеринбурзі: вирує пожежа біля складу
  - (2026-07-25) У Німеччині кількість випадків незаконного перевезення людей скоротилася майже на 42% | LEDE: У 2025 році в Німеччині різко скоротилася кількість виявлених випадків незаконного ввезення людей, ] (uk:…
      У 2025 році в Німеччині різко скоротилася кількість виявлених випадків незаконного ввезення людей, що збіглося із загальним зменшенням масштабів нелегальної міграції.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-25) [Tangney Jeffrey] Form 4 (Reporting)
      filed 2026-07-25 01:59 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Doximity, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:59 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001863328-26-000002 Size: 5 KB
  - (2026-07-25) [Sams Louise S] Form 4 (Reporting)
      filed 2026-07-25 01:51 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:51 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024451 Size: 5 KB
  - (2026-07-25) [Auguste Laurent] Form 4 (Reporting)
      filed 2026-07-25 01:49 UTC · role: Reporting — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB
  - (2026-07-25) [Loop Industries, Inc.] Form 4 (Issuer)
      filed 2026-07-25 01:49 UTC · role: Issuer — Filed: 2026-07-24 AccNo: 0001437749-26-024449 Size: 6 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### State-Level News — 21 new of 727 total
  - (2026-07-25) [Arizona] Election deniers and conspiracy theorists top Arizona’s Republican nominees this year
      Republican voters in Arizona sent a litany of election deniers to the November ballot, chief among them the nominees for the top three statewide offices. But they’re far from the only ones who advanced to the general ele…
  - (2026-07-24) [Colorado] USDA union leaders rally against proposed DC downsizing
      A group of current and former U.S. Department of Agriculture employees are calling on the Trump administration to halt the mandated relocation of more than 2,500 employees from its Washington, D.C., headquarters to five…
  - (2026-07-25) [Florida] ‘E pluribus unum’ is not a slogan. It’s a choice.
      Like two sides of a coin imprinted with the nation’s motto, “e pluribus unum” — out of many, one — America’s political factions are cast in opposition, but they are intrinsically bound together as parts of a larger whole…
  - (2026-07-25) [Kansas] ‘E pluribus unum’ is not a slogan. It’s a choice.
      Like two sides of a coin imprinted with the nation’s motto, “e pluribus unum” — out of many, one — America’s political factions are cast in opposition, but they are intrinsically bound together as parts of a larger whole…
  - (2026-07-24) [Kansas] Federal judge says certain abortion drug restrictions are unlawful
      A federal judge in Virginia ruled Thursday that the U.S. Food and Drug Administration did not sufficiently justify restrictions imposed in 2023 on a drug used to terminate early pregnancies, adding another layer of compl…
  - (2026-07-25) [Maine] Kudos to Maine Dems for a job well done | Letter
      Hats off to party chairman Charlie Dingman and the Maine Democrats. As has been recently reported, never in modern American political history has a state party managed a competitive nominating contest on such a short tim…

### Government & military aircraft airborne (OpenSky) — 13 new of 13 total
  - (2026-07-25) JAF3NE (Belgium)
      icao24: 44d1ba · position: (43.0701, -2.2562) · alt: 10972m · 914km/h
  - (2026-07-25) JAF5KH (Belgium)
      icao24: 44d1a6 · position: (36.8929, 27.0448) · alt: 1143m · 439km/h
  - (2026-07-25) JAF74C (Belgium)
      icao24: 44d1b3 · position: (36.4303, 27.3031) · alt: 5814m · 574km/h
  - (2026-07-25) JAF3MJ (Belgium)
      icao24: 44d1b4 · position: (43.9742, 1.0708) · alt: 10972m · 871km/h
  - (2026-07-25) JAF3LV (Belgium)
      icao24: 44d1a2 · position: (36.126, 9.6597) · alt: 12192m · 775km/h
  - (2026-07-25) SAMU63 (France)
      icao24: 39cd48 · position: (45.7005, 3.275) · alt: 990m · 250km/h

### U.S. Federal Action — 11 new of 12 total
  - (2026-07-27) Modernizing Reactor Licensing, Safety Oversight, and Siting Practices; Correction
      The U.S. Nuclear Regulatory Commission (NRC) is correcting a notice published in the Federal Register on July 16, 2026, regarding the modernization of reactor licensing, safety oversight, and siting practices to address…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Report and Order that promotes the deployment of submarine cables while strengthening national security interests in connection…
  - (2026-07-27) Review of Submarine Cable Landing License Rules and Procedures To Assess Evolving National Security, Law Enforcement, Foreign Policy, and Trade Policy Risks
      In this document, the Federal Communications Commission (Commission or FCC) adopted a Second Further Notice of Proposed Rulemaking (Second FNPRM) that seeks to further prevent evolving national security risks associated…
  - (2026-07-27) Modernizing Package Certification Requirements
      The U.S. Nuclear Regulatory Commission (NRC) is proposing to amend its regulations governing the packaging and transportation of radioactive material. This proposed action is responsive to several executive orders and th…
  - (2026-07-27) Updating Website and Contact Information, and Authorizations for Payments for Legal Services
      The Department of the Treasury's Office of Foreign Assets Control (OFAC) is adopting a final rule to update website and contact information in certain parts of the Code of Federal Regulations (CFR). Additionally, OFAC is…
  - (2026-07-27) Pacific Halibut Fisheries of the West Coast; 2026 Catch Sharing Plan; Inseason Action
      NMFS announces an inseason action for the Pacific halibut recreational fishery in the International Pacific Halibut Commission's (IPHC) regulatory Area 2A. This action adds fishing dates in August and September in the Co…

### Prediction Markets — most-traded (Polymarket) — 7 new of 20 total
  - (2026-07-25) LoL: LGD Gaming vs Team WE - Game 2 Winner
      yes price: 0% · 24h volume: $1,024,580 · resolves 2026-07-25
  - (2026-07-25) LoL: LGD Gaming vs Team WE (BO3) - LPL Group Ascend
      yes price: 0% · 24h volume: $787,655 · resolves 2026-07-25
  - (2026-07-25) LoL: LGD Gaming vs Team WE - Game 1 Winner
      yes price: 0% · 24h volume: $569,571 · resolves 2026-07-25
  - (2026-07-25) Will Trump meet with Netanyahu by July 31, 2026?
      yes price: 94% · 24h volume: $296,323 · resolves 2026-07-31
  - (2026-07-25) Will LeBron James play for the Cleveland Cavaliers in 2026-27?
      yes price: 0% · 24h volume: $269,830 · resolves 2026-10-31
  - (2026-07-25) Will LeBron James play for the Washington Wizards in 2026-27?
      yes price: 0% · 24h volume: $269,279 · resolves 2026-11-01

### IT, InfoSys & cybersecurity news (last 7 days) — 7 new of 57 total
  - (2026-07-25) [The Hacker News] Researcher Publishes GitLab RCE PoC Letting Authenticated Users Run Commands as Git
      Security researcher Yuhang Wu at depthfirst has published a working proof-of-concept (PoC) exploit that executes commands as git on an unpatched self-managed GitLab 18.11.3 server. An ordinary authenticated user triggers…
  - (2026-07-25) [The Register] BOFH: This printer engineer knows every trick in the book
      But so does this customer
  - (2026-07-25) [TechCrunch] I tried out OpenAI’s new AI keypad — which will be fun for some coders and slightly mystifying to everyone else
      OpenAI's fancy new AI keypad will be a lot of fun for some, while many others are probably not going to touch it.
  - (2026-07-24) [The Register] Anthropic debuts Opus 5 at half the price of its Fable sibling
      And as a bonus, it doesn't require data retention
  - (2026-07-24) [Ars Technica] Wildfire forces evacuation of NASA's Deep Space Network complex in Spain
      "Any potential damage will be assessed when it is safe to do so."
  - (2026-07-24) [Ars Technica] Paramount/WBD merger delayed for months as states' lawsuit moves toward trial
      “Halting this merger while our case proceeds is a critical victory," NY AG said.

### Paper Trading Scorecard — 5 new of 140 total
  - (2026-07-25) [Polymarket] Will any presidential candidate win outright in the first round of the Brazil election?
      Presidential elections are scheduled to be held in Brazil on October 4, 2026. A second round will be held if no candidate secures more than 50% of the valid votes in the first round. This market will resolve to "Yes" if…
  - (2026-07-25) [Manifold] Will Gavin Newsom be the favorite for Democratic Nominee on Dec. 31, 2026? [Per Polymarket Data]
  - (2026-07-25) [Manifold] Will Gavin Newsom cease to be the favorite Democratic Nominee before the end of 2026? [Per Polymarket Data]
  - (2026-07-25) [Manifold] Will Ronaldo score in his final match for Portugal?
  - (2026-07-25) [Manifold] Will "Mathematicians are Feeling the Doom" make the top fifty posts in LessWrong's 2026 Annual Review?

### GDACS — global disaster alerts — 5 new of 226 total
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-06-23) [Green] Flood in India
      Flood · Green alert · India · Magnitude 0
  - (2026-07-23) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 10455 ha
  - (2026-07-23) [Green] Forest fires in Spain
      Wildfire · Green alert · Spain · Green impact for forestfire in 10455 ha

### State Legislative Action — 4 new of 107 total
  - (2026-07-25) [Alaska HB 324] An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
      An Act relating to virtual currency kiosks; relating to transactions involving virtual currency; and relating to unfair trade or deceptive acts or practices.
  - (2026-07-25) [Alaska HB 316] An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
      An Act adjusting for inflation the limit for damages for losses that may be awarded for a personal injury or wrongful death.
  - (2026-07-25) [Colorado SB 5] Rights Violation in Immigration Enforcement Remedy
      The act creates a statutory cause of action for a person who has their federal constitutional rights violated by another person who, acting under color of law, is participating in civil immigration enforcement. A person…
  - (2026-07-25) [Colorado HB 1429] County Administration Public Assistance Programs
      The act requires the department of health care policy and financing, in coordination with the department of human services and the department of early childhood (state departments), to contract with a single county depar…

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 121 total
  - (2026-07-25) [USASpending] $819,751,946 → CACI, INC. - FEDERAL: CDM DEFEND GROUP A BRIDGE TASK ORDER
      Agency: General Services Administration. Description: CDM DEFEND GROUP A BRIDGE TASK ORDER
  - (2026-07-25) [USASpending] $733,516,127 → BL HARBERT INTERNATIONAL LLC: BEIRUT, LEBANON NEW EMBASSY CONSTRUCTIONIGF::CL::IGF
      Agency: Department of State. Description: BEIRUT, LEBANON NEW EMBASSY CONSTRUCTIONIGF::CL::IGF
  - (2026-07-25) [USASpending] $665,616,978 → HII MISSION TECHNOLOGIES CORP: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE
      Agency: General Services Administration. Description: AWARD LOGISTICS INTELLIGENCE SURVEILLANCE AND RECONNAISSANCE ISR AND NEXTGEN TECHNOLOGY (LOGIX)
  - (2026-07-25) [USASpending] $614,391,052 → PTSI MANAGED SERVICES INC: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL A
      Agency: Department of Transportation. Description: THE T5 CONTRACT WILL SUPPORT IMPLEMENTATION OF THE FEDERAL AVIATION ADMINISTRATION AVIATION CIP AND CERTAIN REIMBURSABLE PROGRAMS INCLUDING THOSE ARISING FROM AIP APPROP…

### Court opinions of consequence (federal & state) — 3 new of 60 total
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Jenkins v. Prime Insurance
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: Miller v. CNH Industrial America
  - (2026-07-21) U.S. Court of Appeals, 10th Cir.: United States v. Threatt

### USGS earthquakes (M4.5+, past day) — 3 new of 19 total
  - (2026-07-25) M 5.1 - 43 km SW of Puerto Madero, Mexico
      M5.1 · 43 km SW of Puerto Madero, Mexico · depth 35 km
  - (2026-07-25) M 5.0 - 57 km S of Sarangani, Philippines
      M5.0 · 57 km S of Sarangani, Philippines · depth 52.163 km
  - (2026-07-24) M 5.0 - 96 km NNW of Port-Olry, Vanuatu
      M5.0 · 96 km NNW of Port-Olry, Vanuatu · depth 10 km

### Commentary & analysis (last 7 days) — 2 new of 6 total
  - (2026-07-25) [Marginal Revolution] A natural experiment in economics
      To study whether and how academics respond to political pressure, we exploit a natural experiment: the publication in early 2025 of a “blacklist” of words flagged by the U.S. government. We find that the release of this…
  - (2026-07-25) [Marginal Revolution] Crypto markets in everything? (moo)
      Farmers in Parana, Brazil, struggling to get banks to loan them cash, became the first to tokenize livestock and place 10 dairy milk cows’ tokens for trade on the country’s B3 national stock exchange. They generated near…

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-25) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=12, 7d-median=22, 14d-median=20; carrying terms: special, action, proposing, regulatory, provide, certain, amendment, amendments, published, coast, safety, final
- state_bills: today=107, 7d-median=121, 14d-median=121; carrying terms: supplemental, comply, violence, according, relating, financial, participation, include, benefits, promote, government, resources
- state_news: today=727, 7d-median=747, 14d-median=747; carrying terms: border, facing, supplemental, enrolled, sizes, world, companies, include, relief, record, legislatures, follow
- local_news: today=217, 7d-median=227, 14d-median=227; carrying terms: arrest, world, uploads, voters, loading, child, decoding, families, morning, class, suspect, color
- foreign_news: today=996, 7d-median=1019, 14d-median=1024; carrying terms: border, cooperate, facing, attacks, arrest, violence, world, survivor, korea, profile, include, promote
- chinese_internal: today=280, 7d-median=303, 14d-median=303; carrying terms: chinese, cbmix, color, china, cbmiaefvx, cbmickfvx, people, https, title, cbmiyefvx, cbmiy, lxtfa
- russian_internal: today=995, 7d-median=995, 14d-median=982; carrying terms: wildberries, novaya, gazeta, telegram, financial, times, reuters, journal, russian, europe, media, street
- ukrainian_internal: today=123, 7d-median=125, 14d-median=128; carrying terms: september, sparked, bombs, attacks, commander, according, companies, damaged, foreign, government, russian, several
- ukraine_theater: today=347, 7d-median=377, 14d-median=400; carrying terms: attacks, commander, aujva, rmejkmdnas, owiyxzfczzrjrmhcqmwwmknbamdrrfc, dthxmtq, bvplvvo, qtlerufhuq, uzaepktlmzulbyrmvdbuz, nfdytul, companies, zvlfoss
- paper_bets: today=140, 7d-median=144, 14d-median=144; carrying terms: standard, grady, actively, party, event, koivun, miami, according, court, valid, johnny, nomination
- weather: today=209, 7d-median=171, 14d-median=171; carrying terms: damage, depth, middle, affected, caribbean, monitoring, jefferson, warning, messages, south, boston, afdmeg
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: cpiaucsl, spread, recession, implied, nonfarm, balance, walcl, unemployment, unrate, jolts, headline, consumption
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, proxy, yield, silver, nasdaq, commodities, close, crude, rates, large, agriculture, bitcoin
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=121, 7d-median=121, 14d-median=119; carrying terms: target, chemical, attacks, ranchers, transactions, trump, member, abuses, group, hamilton, middle, uchicago
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quiverquant, quantitative, unauthorized, error, https, httperror, congresstrading, quiver, client
- billionaires: today=0, 7d-median=36, 14d-median=34
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, district, supreme, trade, state, international, appeals, blanche, delaware, insurance, board, school
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, accno, filed, issuer, holdings, therapeutics, amended, david
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: james, trone, platner, krishnamoorthi, raised, jonathan, disbursements, house, shawn, ocasio, cooper, michael
- gdelt_regions: today=0, 7d-median=6, 14d-median=6; carrying terms: english, japan, japanherald
- gdelt_gkg: today=118, 7d-median=45, 14d-median=46; carrying terms: israel, english, hezbollah, trump, spanish, chinese, themes, russia, russian, sanctions, perimeter, arabic
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=13, 7d-median=11, 14d-median=11; carrying terms: position, france, belgium
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: border, mechanical, september, experiencing, seasonal, event, implicated, ventilatory, followed, according, valley, derived
- cisa_kev: today=16, 7d-median=16, 14d-median=16; carrying terms: critical, restrictive, protocol, forgery, cross, active, function, privilege, control, fortisandbox, insufficient, association
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, percentile, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=226, 7d-median=205, 14d-median=196; carrying terms: agricultural, drought, congo, impact, kenya, montenegro, depth, maximum, bulgaria, austria, storm, alert
- usgs_quakes: today=19, 7d-median=18, 14d-median=19; carrying terms: puerto, depth, indonesia, islands, mexico, philippines, abepura, madero, russia, region, vanuatu, ushuaia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: meeting, resolves, ethiopia, volume, price, prime, rates, interest, minister, change, increase, decrease
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, conversable, revolution, perhaps, economist, https, marginal, useful, marginalrevolution, benefit, paper, among
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: world, companies, months, government, record, against, surveillance, haven, international, accessed, phishing, today
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jeanne, banks, kweisi, commodity, hickenlooper, beatty, sonderling, fetterman, stacey, amata, abraham, tokuda
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, identify, converges, decision, market, markets, module, evidence, either, consensus, unavailable, sufficient

## What to watch (recent + forthcoming, ±14 days)
- [2026-07-13] Fed speeches: Bowman, Modernizing Financial Regulation
- [2026-07-13] Fed speeches: Waller, Monetary Policy at a Crossroads
- [2026-07-14] Fed speeches: Barr, Will Artificial Intelligence Broadly Raise Living Standards or Drive Income and Wealth Inequality?
- [2026-07-14] Fed press (events + announcements): Minutes of the Board's discount rate meetings on June 8 and June 17, 2026
- [2026-07-14] Fed speeches: Bowman, Responsible Innovation and Financial Inclusion
- [2026-07-15] Fed speeches: Cook, Economic Outlook
- [2026-07-16] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former chief lending officer of Heritage State Bank
- [2026-07-16] Fed press (events + announcements): Agencies issue joint statement on handling of highly sensitive information during bank examinations
- [2026-07-16] Fed speeches: Jefferson, Navigating Economic Shocks: A Monetary Policymaker’s Perspective
- [2026-07-23] ECB press: ECB reveals shortlisted designs for new banknotes and launches public survey
- [2026-07-24] ECB press: Results of the ECB Survey of Professional Forecasters for the third quarter of 2026
- [2026-07-24] ECB press: ECB Consumer Expectations Survey results – June 2026
- [2026-07-24] ECB press: ECB to start implementing enhanced repo facility for central banks
- [2026-07-24] ECB press: Results of the June 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-07-24] ECB press: ECB to extend use of climate factors in Eurosystem collateral framework to non-financial corporate credit claims
- [2026-07-24] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-07-24] ECB press: Philip R. Lane: Outlook for the euro area economy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*