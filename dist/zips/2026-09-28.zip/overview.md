# WORLDSCOPE morning brief — 2026-09-28

## Headline
3111 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (813) · Russian Internal News (state + in-exile) (707) · World leaders & government officials (324) · Chinese Internal News (238) · State-Level News (176) · Local News: St. Louis + Atlanta (171) · Ukraine Theater (total-war monitoring) (142) · U.S. Weather + Severe / Climate Outlooks (113) · Ukrainian Internal News (national + local Kyiv) (58) · State Legislative Action (53) · GDELT GKG — themes / entities / watch areas (52) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 813 new of 963 total
  - (2026-09-28) [Global] Best thing we can offer young people is a job, not benefits, says chancellor
      John Healey's speech comes ahead of next month's Budget, as he faces pressure to bring down government borrowing costs.
  - (2026-09-28) [Global] What is the Budget and what could be in it?
      Chancellor John Healey will set out his plans for UK taxes in October.
  - (2026-09-28) [Global] UK diesel price hits all-time high, the RAC says
      The US-Israel war with Iran has caused fuel prices to soar due to disruption of global oil supplies.
  - (2026-09-28) [Global] Apple ordered to pay $5.7bn after losing vibration tech patent suit
      Audio firm Taction Technology claimed Apple infringed its patents for tech used to power device vibrations.
  - (2026-09-28) [Global] Why UK diesel prices have hit an all-time high
      The average price of a litre of diesel at the pump stands at 198.32p, according to the RAC motoring body.
  - (2026-09-28) [Global] Why the PM could finally drop the triple lock pension pledge
      Andy Burnham said that he would make tough decisions to fund a new national care service.

### Russian Internal News (state + in-exile) — 707 new of 882 total
  - (2026-09-28) Путин передал во временное управление активы немецкой сети Metro | LEDE: Владимир Путин подписал указ о передаче во временное управление активов немецкой торговой сети Metro, остававшейся в ] (ru: Пут…
      Владимир Путин подписал указ о передаче во временное управление активов немецкой торговой сети Metro, остававшейся в России после начала полномасштабной войны.
  - (2026-09-28) SpaceX впервые запустила корабль «Старшип» на орбиту | LEDE: Компания SpaceX успешно запустила на орбиту космический корабль «Старшип». ] (ru: SpaceX впервые запустила корабль «Старшип» на орбиту)
      Компания SpaceX успешно запустила на орбиту космический корабль «Старшип».
  - (2026-09-28) Ирландские футболисты вышли на игру с Израилем в траурных повязках в память о погибших в секторе Газа и отказались пожать руки соперникам. Матч едва не сорвался | LEDE: Матч сборных Израиля ] (ru: Ирл…
      Матч сборных Израиля и Ирландии в Лиге наций, который состоялся в венгерском Дебрецене, едва не сорвался из-за позиции ирландских футболистов — они даже устроили голосование внутри команды, чтобы определить, выходить им…
  - (2026-09-28) Издательство Individuum закрыто. За 11 лет своего существования оно выпустило множество важнейших книг — от «Всем Иран» до «Табии 32». Вот десятка наших любимых | LEDE: 28 сентября главный р] (ru: Изд…
      28 сентября главный редактор издательства Individuum Алексей Киселев объявил о его закрытии. Он не назвал причин, сообщив, что книги, над которыми издательство работало в последнее время, обязательно выйдут — уже в други…
  - (2026-09-28) В Бангкоке — режим бедствия из-за наводнения. В городе затоплены дороги. Тысячи жителей перебрались в убежища. Фотографии | LEDE: Несколько районов Бангкока затопило после того, как в городе] (ru: В Б…
      Несколько районов Бангкока затопило после того, как в городе за несколько дней выпало почти столько же осадков, сколько обычно бывает за весь сентябрь. Основные каналы столицы Таиланда переполнились, а городская система…
  - (2026-09-28) Евросоюз ввел санкции против судей и прокуроров, снявших «Яблоко» с выборов. Также в санкционный список попал детский лагерь в Северной Корее | LEDE: Европейский союз включил в санкционный с] (ru: Евр…
      Европейский союз включил в санкционный список российских судей и сотрудников прокуратуры, причастных к снятию федерального списка партии «Яблоко» с выборов в Госдуму.

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 238 new of 267 total
  - (2026-09-27) Asia New Vision Forum 亚洲愿景论坛-财新网-CAIXIN.COM - topics.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE5mRHJiR2xIbW83TWJ6bFRRZHFwVGd1WkZ6eGZVX2xSTGhjTU85Z1Jtd2FWck5] (zh:…
      Asia New Vision Forum 亚洲愿景论坛-财新网-CAIXIN.COM topics.caixin.com
  - (2026-09-27) Asia New Vision Forum 亚洲愿景论坛-财新网-CAIXIN.COM - topics.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE5RbmV6UmRESHkxcmJBckxpbVZJNVUzYW04U0NjaTIyeDVHTng3WkppYm5xcUx] (zh:…
      Asia New Vision Forum 亚洲愿景论坛-财新网-CAIXIN.COM topics.caixin.com
  - (2026-09-28) 【华尔街原声】分析人士：AI支出已成为美国经济主要驱动力 - database.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiY0FVX3lxTE9jcjJOWlJ2VTRpRFZqYXhJSlNFMm1ORzdZQXVkOWxjdG1tZVB0WGJOR1J6SUpVY19qX2JvbDN0] (zh:…
      【华尔街原声】分析人士：AI支出已成为美国经济主要驱动力 database.caixin.com
  - (2026-09-28) 今日开盘：两市双双低开 沪指跌幅0.26% - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFBJaEFETFJrOTRQTjZrR1VWaWFGWWhkSDBnZE1aajhjMnhrSHQyVEQ4ckJpT25XbExDX1RIYVpnWFpnU21BR05mRXFPeEcxT1dD] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.26% 财新
  - (2026-09-28) 陈燕妮：北京烤鸭直奔哪里？｜饮食 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBydmFwN1h6TDU4cWRXN2lOMjgyU01jZWtBOVhlRmpRSEtFd1FlMTBlT0ZNZEJ5SEIycjlIdUxINGF5eDZjVlF2UHJfeE15d3RvUkhkb] (zh:…
      陈燕妮：北京烤鸭直奔哪里？｜饮食 财新
  - (2026-09-27) 一眼千年的东方微笑｜千年麦积山石窟② - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE10X1JkcnlyVEU3UjI4R3lTUXA2Ti1jS0RJSS1WeVVDejQ3akhZenVjREFmNG5JYlhBWUZ4R0QxSUNtWldwU1BhNkpRZklyRWJqNGV] (zh:…
      一眼千年的东方微笑｜千年麦积山石窟② 财新

### State-Level News — 176 new of 270 total
  - (2026-09-28) [California] How to decide on your 14 CA ballot measures? Take our quizzes
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/091726-Shelly-Tan-Illustrations-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-im…
  - (2026-09-28) [California] Other states are rolling out free childcare for all families. Why not California?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/091526_Kidango-Childcare_LA_CM_31.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-09-28) [California] What will California’s next governor do about healthcare? Here are Becerra and Hilton’s plans
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/092526-Xavier-Becerra-GP-GETTY-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-…
  - (2026-09-28) [California] Undercover jailhouse stings have value. California shouldn’t abandon them
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2024/04/111815-SD-County-Jail-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-09-27) [California] Newsom signs new gun control laws, including one requiring owners to take a 4-hour class
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/102923-Gun-Safety-Training-GETTY-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-09-27) [California] New California law targets expensive ‘ghost tickets’ to concerts and sporting events
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/09/051226-RAYE-Concert-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt=…

### Local News: St. Louis + Atlanta — 171 new of 198 total
  - (2026-09-28) [St. Louis] Mary Meachum’s fight for freedom will take center stage near the Gateway Arch
      Most people walk past the Mississippi River without realizing one of Missouri’s most extraordinary stories changed history along its banks. It was here, under the cover of darkness in 1855, that nine enslaved people atte…
  - (2026-09-28) [St. Louis] Top family-friendly events this week in St. Louis
      See Also: Fall Family Fun Guide Fright at the Museum | September 30–November 1Spooky season takes over City Museum with Halloween decorations and seasonal surprises throughout the building. Families can explore the museu…
  - (2026-09-28) [St. Louis] The Fountain on Locust team to open Conefection at Wash Ave Food Hall
      The team behind The Fountain on Locust is bringing a new ice cream concept to Wash Ave Food Hall (1122 Washington). Conefection will join the lineup of founding vendors when the downtown food hall opens next month. Here’…
  - (2026-09-28) [St. Louis] South Grand grapples with the needs of homeless residents IRL after online backlash
      Outreach is ramping up along South Grand Boulevard after a now-retracted letter from a local taxing district instructed businesses not to give water and call 911 on unhoused people—but one local restaurant owner says the…
  - (2026-09-28) [St. Louis] Recycle With Me aims to do what the City of St. Louis won’t: pick up recycling
      In August 2025, the City of St. Louis ended alleyway recycling. “People were throwing stuff in bins, it was dirtying the recycling, and the city was losing money,” says Erik Kozlowski. While some advocates are still push…
  - (2026-09-28) [St. Louis] Lou’s Clues – 9/28/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…

### Ukraine Theater (total-war monitoring) — 142 new of 442 total
  - (2026-09-28) [DeepStateMap] frontline snapshot, 525 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-09-27) [FIRMS] thermal anomaly 44.208, 28.436 (FRP 8.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-27 0956Z, FRP 8.19 MW
  - (2026-09-27) [FIRMS] thermal anomaly 45.261, 31.675 (FRP 7.46 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-27 0956Z, FRP 7.46 MW
  - (2026-09-27) [FIRMS] thermal anomaly 45.259, 31.670 (FRP 5.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-27 0956Z, FRP 5.85 MW
  - (2026-09-27) [FIRMS] thermal anomaly 44.205, 28.438 (FRP 7.37 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-27 0956Z, FRP 7.37 MW
  - (2026-09-27) [FIRMS] thermal anomaly 46.199, 32.423 (FRP 6.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-09-27 0956Z, FRP 6.55 MW

### U.S. Weather + Severe / Climate Outlooks — 113 new of 114 total
  - (2026-09-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-09-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 28 at 9:43AM CDT until September 28 at 11:00AM CDT by NWS Dodge City KS
      * WHAT...Visibility less than one mile in dense fog. * WHERE...Portions of southwest and west central Kansas. * WHEN...Until 11 AM CDT /10 AM MDT/ this morning. * IMPACTS...Low visibility could make driving conditions ha…
  - (2026-09-28) [Moderate] Special Weather Statement: Special Weather Statement issued September 28 at 10:40AM EDT by NWS Newport/Morehead City NC
      Higher than normal tides combined with lingering high water from the wind event late last week are leading to some elevated water levels across the Morehead City, Beaufort, and Downeast Carteret County areas. The high wa…
  - (2026-09-28) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued September 28 at 9:36AM CDT until September 28 at 10:00AM CDT by NWS Chicago IL
      The fog continues to dissipate this morning.
  - (2026-09-28) [Severe] Flood Warning: Flood Warning issued September 28 at 9:34AM CDT until September 28 at 3:30PM CDT by NWS Aberdeen SD
      * WHAT...Flooding caused by excessive rainfall is expected. * WHERE...Northwestern Campbell County in north central South Dakota... Northeastern Corson County in north central South Dakota... * WHEN...Until 330 PM CDT /2…
  - (2026-09-28) [Moderate] Special Weather Statement: Special Weather Statement issued September 28 at 9:24AM CDT by NWS Aberdeen SD
      At 924 AM CDT /824 AM MDT/, Doppler radar was tracking a strong thunderstorm 7 miles southeast of Kenel, or 11 miles northeast of Wakpala, moving northeast at 30 mph. HAZARD...Wind gusts up to 50 mph and half inch size h…

### Ukrainian Internal News (national + local Kyiv) — 58 new of 108 total
  - (2026-09-28) У Литві почали діяти національні санкції проти Усманова і Фрідмана | LEDE: З 25 вересня Литва почала застосовувати національні санкції проти російських олігархів Алішера Усманова і Михаїла Фрід] (uk:…
      З 25 вересня Литва почала застосовувати національні санкції проти російських олігархів Алішера Усманова і Михаїла Фрідмана.
  - (2026-09-28) Росіяни вдарили по житловому будинку в Одесі: 4 постраждалих, серед них дитина | LEDE: Внаслідок удару по житловому будинку в Одесі 28 вересня травмовані троє дорослих і дитина. Пошкоджено фаса] (uk:…
      Внаслідок удару по житловому будинку в Одесі 28 вересня травмовані троє дорослих і дитина. Пошкоджено фасад і квартири – дані МВА й ОВА.
  - (2026-09-28) Україна на засіданні ПАРЄ порушить питання російських компенсацій у справах ЄСПЛ | LEDE: Підтримка українських ветеранів, виконання Росією рішень Європейського суду з прав людини та захист журн] (uk:…
      Підтримка українських ветеранів, виконання Росією рішень Європейського суду з прав людини та захист журналістів стануть ключовими для української делегації темами осінньої сесії Парламентської асамблеї Ради Європи (ПАРЄ)…
  - (2026-09-28) Південна Корея викликала посла України через заяви щодо полонених з КНДР | LEDE: Міністерство закордонних справ Південної Кореї викликало виконуючого обов'язки посла України Андрія Вешкіна післ] (uk:…
      Міністерство закордонних справ Південної Кореї викликало виконуючого обов'язки посла України Андрія Вешкіна після того, як Київ повідомив про передачу Сеулу двох північнокорейських військовополонених.
  - (2026-09-28) Папа Римський закликає "поступитися деякими позиціями" заради миру в Європі | LEDE: Папа Римський Лев XIV закликав "проявити мужність у переговорах" та "бути готовими поступитися деякими позиці] (uk:…
      Папа Римський Лев XIV закликав "проявити мужність у переговорах" та "бути готовими поступитися деякими позиціями заради вищого блага – миру" в Європі.
  - (2026-09-28) ДМС тимчасово не оформлює паспорти: технічна несправність | LEDE: Державна міграційна служба повідомила, що тимчасово до кінця вересня не надаватиме послуги з оформлення паспортних документів ч] (uk:…
      Державна міграційна служба повідомила, що тимчасово до кінця вересня не надаватиме послуги з оформлення паспортних документів через технічну несправність.

### State Legislative Action — 53 new of 62 total
  - (2026-09-28) [California AB 2402] Health studio contracts: fee limits: multiservice health club studio.
      Existing law generally regulates contracts for health studio services, as defined, including prohibiting those contracts, beginning January 1, 2010, from requiring payment in excess of $4,400, inclusive of initiation or…
  - (2026-09-28) [California AB 1099] Developmental services: initial intake.
      Existing law, the Lanterman Developmental Disabilities Services Act, requires the State Department of Developmental Services (department) to contract with regional centers to provide services and supports to persons with…
  - (2026-09-28) [California AB 1542] Sensitive personal information.
      The California Consumer Privacy Act of 2018 (CCPA) grants a consumer various rights with respect to personal information, as defined, that is collected or sold by a business, as defined, including the right to direct a b…
  - (2026-09-28) [California AB 1039] State-funded assistance grants and contracts: advance payments.
      Existing law authorizes a state agency administering a grant program or contract to advance a payment to a recipient entity, subject to specified requirements. Existing law defines "recipient entity" for these purposes t…
  - (2026-09-28) [California AB 2717] Outdoor advertising displays: arenas: exemptions.
      The Outdoor Advertising Act provides for the regulation by the Department of Transportation of advertising displays, as defined, within view of public highways. The act exempts from most of its provisions an advertising…
  - (2026-09-28) [California AB 464] Sexual assault in prison.
      (1) Existing law tolls the periods of limitation to bring specific civil actions for up to 2 years, if during that time that the claimant is imprisoned on a criminal charge, as specified. However, under existing law thes…

### GDELT GKG — themes / entities / watch areas — 52 new of 52 total
  - (2026-09-28) [Russia oil sanctions perimeter · keywords] The Blockade Has Done What Sanctions Could Not | Armstrong Economics
      armstrongeconomics.com · English · tone NA
  - (2026-09-28) [Israel-Iran-Hezbollah axis · keywords] Netanyahu meets Emirati leader in secret trip , other Mideast news
      journal-advocate.com · English · tone NA
  - (2026-09-28) [Israel-Iran-Hezbollah axis · keywords] Australian court rejects bid to prosecute Britain King Charles for genocide
      abcnews.com · English · tone NA
  - (2026-09-28) [Israel-Iran-Hezbollah axis · keywords] Did Netanyahu ask Al Nahyan to deny Oct 7 warning in secret UAE visit ? Here what happened behind closed doors
      moneycontrol.com · English · tone NA
  - (2026-09-28) [Israel-Iran-Hezbollah axis · keywords] Iran : Endless Wars in Iran and Ukraine
      strategypage.com · English · tone NA
  - (2026-09-28) [Israel-Iran-Hezbollah axis · keywords] Netanyahu orders legal case against Erdogan focusing on Kurds , Hamas
      middleeastmonitor.com · English · tone NA

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-09-28) 424B2 - ROYAL BANK OF CANADA (0001000275) (Filer)
      filed 2026-09-28 14:46 UTC — Filed: 2026-09-28 AccNo: 0000950103-26-014561 Size: 165 KB
  - (2026-09-28) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-09-28 14:44 UTC — Filed: 2026-09-28 AccNo: 0001918704-26-028942 Size: 918 KB
  - (2026-09-28) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-09-28 14:44 UTC — Filed: 2026-09-28 AccNo: 0001918704-26-028942 Size: 918 KB
  - (2026-09-28) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-09-28 14:41 UTC — Filed: 2026-09-28 AccNo: 0001918704-26-028941 Size: 593 KB
  - (2026-09-28) 424B2 - JPMORGAN CHASE & CO (0000019617) (Filer)
      filed 2026-09-28 14:41 UTC — Filed: 2026-09-28 AccNo: 0001918704-26-028941 Size: 593 KB
  - (2026-09-28) 424B2 - JPMorgan Chase Financial Co. LLC (0001665650) (Filer)
      filed 2026-09-28 14:41 UTC — Filed: 2026-09-28 AccNo: 0001918704-26-028940 Size: 936 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 37 new of 57 total
  - (2026-09-28) [BleepingComputer] 80,000+ Organizations Had AI Logins Stolen: From Shadow AI to LLMjacking
      Infostealer logs exposed AI account credentials and sessions tied to more than 80,000 corporate domains, creating risks ranging from stolen conversations to LLMjacking. SOCRadar examines the growing market for stolen AI…
  - (2026-09-28) [BleepingComputer] Bitget resumes Bitcoin withdrawals after $387.5 million crypto heist
      Cryptocurrency exchange Bitget has resumed Bitcoin withdrawals suspended after suspected North Korean hackers breached its systems last week and stole over $350 million. [...]
  - (2026-09-28) [BleepingComputer] US soldier gets 70 months in prison for extorting 10 tech, telecom firms
      A former U.S. Army soldier has been sentenced to 70 months in prison for hacking and extorting at least 10 U.S. technology and telecommunications companies between April 2023 and December 2024. [...]
  - (2026-09-28) [BleepingComputer] CISA orders feds to patch exploited Citrix flaws by Wednesday
      The Cybersecurity and Infrastructure Security Agency (CISA) has ordered U.S. government agencies over the weekend to secure their systems against attacks exploiting two critical Citrix NetScaler vulnerabilities. [...]
  - (2026-09-28) [The Hacker News] ⚡ Weekly Recap: $387M Crypto Hack, Citrix Exploits, AI Agents Go Off-Script, and More Threats
      A domain used as harmless placeholder text showed up in roughly 1,700 repositories. Then somebody registered it and started serving malicious lures. That is the kind of week this was: forgotten assumptions turning into l…
  - (2026-09-28) [The Hacker News] Webinar: How to Govern AI Agents, Reduce Excessive Access, and Control Shadow AI
      AI agents are moving into production faster than security teams can govern them. They are connecting to apps, handling data, calling APIs, and acting across business systems—often without the same controls applied to hum…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 30 new of 30 total
  - (2026-09-28) #1 Elon Musk — $917.74B
      United States · Technology · source: Tesla, SpaceX · holdings: SPCX-US(NASDAQ), SPCX-US(NASDAQ), TSLA-US(NASDAQ)
  - (2026-09-28) #2 Jeff Bezos — $367.10B
      United States · Technology · source: Amazon · holdings: AMZN-US(NASDAQ)
  - (2026-09-28) #3 Larry Page — $279.96B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-28) #4 Michael Dell — $267.54B
      United States · Technology · source: Dell Technologies · holdings: AVGO-US(NASDAQ), DELL-US(NYSE), VMW-US(NYSE)
  - (2026-09-28) #5 Sergey Brin — $257.65B
      United States · Technology · source: Google · holdings: GOOGL-US(NASDAQ), GOOG-US(NASDAQ)
  - (2026-09-28) #6 Mark Zuckerberg — $247.74B
      United States · Technology · source: Facebook · holdings: META-US(NASDAQ)

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 29 new of 30 total
  - (2026-09-28) CFC3444 (Canada)
      icao24: c2c377 · position: (45.8698, -72.7438) · alt: 10363m · 837km/h
  - (2026-09-28) PAT496 (United States)
      icao24: adfe94 · position: (32.7018, -117.1994) · on ground
  - (2026-09-28) PAT958 (United States)
      icao24: adfec1 · position: (39.1913, -95.2714) · alt: 1775m · 462km/h
  - (2026-09-28) PAT448 (United States)
      icao24: adfec0 · position: (29.6551, -93.2485) · alt: 9448m · 761km/h
  - (2026-09-28) FAF7811 (France)
      icao24: 39a858 · position: (46.9391, 3.8976) · alt: 2133m · 306km/h
  - (2026-09-28) SAMU13 (France)
      icao24: 39c902 · position: (43.6079, 6.9771) · alt: 281m · 206km/h

### USGS earthquakes (M4.5+, past day) — 25 new of 25 total
  - (2026-09-28) M 5.4 - north of Svalbard
      M5.4 · north of Svalbard · depth 10 km
  - (2026-09-28) M 5.4 - 231 km WSW of Port McNeill, Canada
      M5.4 · 231 km WSW of Port McNeill, Canada · depth 10 km · TSUNAMI
  - (2026-09-28) M 5.3 - 60 km NE of Tadine, New Caledonia
      M5.3 · 60 km NE of Tadine, New Caledonia · depth 10 km
  - (2026-09-28) M 5.2 - 190 km WSW of Port McNeill, Canada
      M5.2 · 190 km WSW of Port McNeill, Canada · depth 10 km · TSUNAMI
  - (2026-09-28) M 5.2 - 67 km ENE of Tadine, New Caledonia
      M5.2 · 67 km ENE of Tadine, New Caledonia · depth 10 km
  - (2026-09-28) M 5.1 - 78 km ENE of Tadine, New Caledonia
      M5.1 · 78 km ENE of Tadine, New Caledonia · depth 10 km

### Prediction Markets — most-traded (Polymarket) — 18 new of 20 total
  - (2026-09-28) Eagles vs. Bears
      yes price: 64% · 24h volume: $1,099,049 · resolves 2026-09-29
  - (2026-09-28) Spread: Eagles (-3.5)
      yes price: 50% · 24h volume: $403,094 · resolves 2026-09-29
  - (2026-09-28) Spread: Eagles (-4.5)
      yes price: 46% · 24h volume: $355,967 · resolves 2026-09-29
  - (2026-09-28) Will New York Red Bulls win the 2026 MLS Cup?
      yes price: 0% · 24h volume: $320,888 · resolves 2027-01-01
  - (2026-09-28) Counter-Strike: NIP vs GamerLegion (BO5) - 1win Private Club #1 Playoffs
      yes price: 30% · 24h volume: $312,683 · resolves 2026-09-28
  - (2026-09-28) Will Portland Timbers win the 2026 MLS Cup?
      yes price: 0% · 24h volume: $294,163 · resolves 2027-01-01

### Court opinions of consequence (federal & state) — 17 new of 60 total
  - (2026-09-29) Connecticut Supreme Court: State v. Jose T.
  - (2026-09-25) Alaska Supreme Court: Dickerson v. Dickerson
  - (2026-09-24) U.S. Court of Appeals, 4th Cir.: Kerron Andrews v. Baltimore City Police Department
  - (2026-09-24) D.C. Court of Appeals: Faltz v. United States
  - (2026-09-24) D.C. Court of Appeals: In re Toliver
  - (2026-09-24) D.C. Court of Appeals: Rezene v. United States

### World News (by country, top stories) — 12 new of 12 total
  - (2026-09-28) [Japan] Pokémon Happy Meals Are Returning To McDonald , So Prepare To Wait In Line
      kotaku.com · English
  - (2026-09-28) [Japan] Garmin new Fenix 9 Pro gives me a reason to leave my phone at home
      zdnet.com · English
  - (2026-09-28) [Japan] Anker 160W Prime Docking Station Is Back at Its Lowest Price , Putting 14 Ports and Dual 4K HDMI on Your Desk for Nearly 40 % Less
      kotaku.com · English
  - (2026-09-28) [Japan] AEON Credit Records 10 . 8 % Increase in Net Profit for 1HFY2026 / 27
      jcnnewswire.com · English
  - (2026-09-28) [Japan] Digital Foundry News | Nintendo Life
      nintendolife.com · English
  - (2026-09-28) [Japan] PSA : The Witcher 3 Remastered File Size And Release Time Confirmed , Separate Purchase Required
      nintendolife.com · English

### Paper Trading Scorecard — 11 new of 117 total
  - (2026-09-28) [Manifold] Will the Philadelphia Eagles defeat the Los Angeles Rams by 3 or more points in Week 4?
  - (2026-09-28) [Manifold] Will Nicola Willis get back to Parliament after the 2026 NZ election?
  - (2026-09-28) [Manifold] Daily Coinflip
  - (2026-09-28) [Manifold] 9984 9984?
  - (2026-09-28) [Manifold] [SHORT FUSE] Will GOOG close higher than AAPL?
  - (2026-09-28) [Manifold] Bitcoin price reaches 100k USD at any point before EOY

### Government Action: Sanctions + Procurement + Foreign Agents — 4 new of 99 total
  - (2026-09-23) [OFAC] Democratic Republic of the Congo-related Designations Removals - ofac.treasury.gov
      Democratic Republic of the Congo-related Designations Removals ofac.treasury.gov
  - (2026-09-24) [OFAC] BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 505 Sanctions Penalties Regulations - ofac.treasury.gov
      BILLING CODE 4810-AL DEPARTMENT OF THE TREASURY Office of Foreign Assets Control 31 CFR Part 505 Sanctions Penalties Regulations ofac.treasury.gov
  - (2026-09-25) [OFAC] Recent Actions - ofac.treasury.gov
      Recent Actions ofac.treasury.gov
  - (2026-09-24) [OFAC] Publication of Regulatory Amendments; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) - ofac.treasury.gov
      Publication of Regulatory Amendments; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) ofac.treasury.gov

### EPSS — highest exploit-probability CVEs — 3 new of 40 total
  - (2026-09-28) CVE-2017-7921: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-09-28) CVE-2013-2251: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000
  - (2026-09-28) CVE-2012-1823: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-09-28) [Marginal Revolution] Mighty Sparrow, RIP
      Here is the NYT obituary. The post Mighty Sparrow, RIP appeared first on Marginal REVOLUTION.
  - (2026-09-28) [Marginal Revolution] Defining the Unemployment Rate
      An updated version of our Marginal Revolution University (MRU) video on defining the unemployment rate. Free to use for anyone but goes best, of course, with Modern Principles of Economics, the best principles of economi…
  - (2026-09-28) [Marginal Revolution] Bundesrepublik Deutschland
      At times we forget what an amazing wonder the Bundesrepublik Deutschland was. At the end of the World War II, Germany was one of the sickest and cruelest human societies in history, ever. Not too many years later, it was…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] FRIENDS OF LEE FERRELL
      cycle 2014 · filing #870438
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977

### CISA Known Exploited Vulnerabilities (last 14d) — 2 new of 19 total
  - (2026-09-27) CVE-2026-88772 · Citrix NetScaler: Citrix NetScaler Improper Restriction of Operations within the Bounds of a Memory Buffer Vulnerability
      vendor: Citrix · product: NetScaler · CISA remediation by 2026-09-30
  - (2026-09-27) CVE-2026-88771 · Citrix NetScaler: Citrix NetScaler Improper Input Validation Vulnerability
      vendor: Citrix · product: NetScaler · CISA remediation by 2026-09-30

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-09-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=18, 7d-median=18, 14d-median=18; carrying terms: proposed, state, final, proposes, certain, program, airworthiness, provisions, model, directives, office, management
- state_bills: today=62, 7d-median=120, 14d-median=105; carrying terms: authorizes, training, comprehensive, within, vests, districts, programs, required, energy, except, devices, projects
- state_news: today=270, 7d-median=604, 14d-median=604; carrying terms: being, higher, looking, carolina, billion, meeting, known, agriculture, according, total, official, trump
- local_news: today=198, 7d-median=227, 14d-median=231; carrying terms: killed, being, crash, according, trump, death, injured, stlmag, cbmirafbvv, season, three, missouri
- foreign_news: today=963, 7d-median=994, 14d-median=994; carrying terms: financial, zeitung, known, according, deliberations, energy, saying, capital, trust, berlin, rsshub, leader
- chinese_internal: today=267, 7d-median=270, 14d-median=271; carrying terms: cbmic, cbmibkfvx, cbmib, chinese, cbmixkfvx, cbmiakfvx, cbmizkfvx, color, cbmigwfbvv, people, cbmiykfvx, lxtfb
- russian_internal: today=882, 7d-median=1029, 14d-median=1042; carrying terms: forbidden, target, financial, gazeta, novayagazeta, httperror, politico, russian, times, novaya, found, https
- ukrainian_internal: today=108, 7d-median=130, 14d-median=134; carrying terms: killed, assessment, httperror, black, according, trump, vladimir, kyivindependent, ahead, region, planned, energy
- ukraine_theater: today=442, 7d-median=379, 14d-median=417; carrying terms: cbmijgfbvv, qtrolu, thermal, sudan, yalrmrnnvyxfkeghqvw, known, exchange, total, cuxqqxpqsnjnwe, syria, jvzte, ntuejdulfxr
- paper_bets: today=117, 7d-median=120, 14d-median=125; carrying terms: colorado, russell, special, nominee, leaders, party, district, nominal, carolina, jinping, magnitude, israel
- weather: today=114, 7d-median=146, 14d-median=117; carrying terms: thursday, magnitude, mount, normal, rainfall, around, francisco, detroit, depth, pressure, tonight, especially
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: recession, jolts, consumption, dcoilwtico, dexuseu, implied, energy, money, rates, dexjpus, commodities, effective
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: range, proxy, equities, russell, treasury, crude, silver, rates, credit, large, commodities, natural
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=99, 7d-median=103, 14d-median=104; carrying terms: amended, target, sudan, violent, syria, detect, destruction, funds, libya, nicaragua, resolution, measures
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, https, unauthorized, congresstrading, quiverquant, quiver, error, client, httperror
- billionaires: today=30, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: company, appeals, supreme, court, trade, arizona, international, commissioner, state, robert, delaware, colorado
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, filer, trust, financial, group, finance, investment, series
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: house, ossoff, lindsey, trone, angels, robert, disbursements, congress, james, warner, michael, raised
- gdelt_regions: today=12, 7d-median=6, 14d-median=6; carrying terms: english, japan, south
- gdelt_gkg: today=52, 7d-median=50, 14d-median=50; carrying terms: english, sanctions, spanish, themes, perimeter, chinese, trump, russian, vietnamese, russia, german, ukraine
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: position, belgium, ground, kingdom, germany, france, canada, adfec
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: intensive, fatal, recalls, recombination, related, hygiene, generation, being, country, district, genetic, countries
- cisa_kev: today=19, 7d-median=18, 14d-median=21; carrying terms: vendor, remediation, bounds, based, cisco, google, traversal, vulnerability, incorrect, improper, multiple, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=25, 7d-median=14, 14d-median=14; carrying terms: depth, indonesia, islands, colombia, south, region, china, zealand, russia, tadine, caledonia
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, resolves, donetsk, league, shakhtar, championship, champions, september, rates, meeting, interest
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: conversableeconomist, revolution, conversable, marginal, economist, class, https, basic, showing, decline, patterns, known
- tech_news: today=57, 7d-median=56, 14d-median=57; carrying terms: download, according, spectrum, total, computerweekly, computer, technology, infrastructure, intelligence, review, vulnerability, models
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: bernard, tillis, rounds, mcconnell, murkowski, stock, russell, monica, katie, pfluger, cuellar, brooke
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, placement, consensus, today, unavailable, identify, placed, decision, evidence, either, market, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-09-18] Fed speeches: Bowman, The Final Chapter on Modernizing Bank Regulatory Stress Testing
- [2026-09-18] Fed speeches: Bowman, Initial Findings from Independent Review of Silicon Valley Bank
- [2026-09-21] ECB press: ECB to invest part of own funds in tokenised securities, with settlement via Pontes
- [2026-09-22] ECB press: Philip R. Lane: Interview with Le Temps
- [2026-09-22] Fed speeches: Jefferson, Discount Window Modernization and Treasury Market Functioning
- [2026-09-23] ECB press: Almost ten million people took part in ECB survey on new euro banknotes
- [2026-09-23] Fed speeches: Barr, A Long-Term View on the Costs of Shelter
- [2026-09-23] ECB press: The digitalisation of money, payments and finance
- [2026-09-23] ECB press: Philip R. Lane: The Outlook for the Euro Area Economy
- [2026-09-24] ECB press: Philip R. Lane: The outlook for the euro area economy
- [2026-09-24] ECB press: ECB Executive Board member Isabel Schnabel to resign to take senior role at IMF
- [2026-09-28] ECB press: Christine Lagarde: Hearing of the Committee on Economic and Monetary Affairs of the European Parliament

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*