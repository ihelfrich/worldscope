# WORLDSCOPE morning brief — 2026-08-28

## Headline
3381 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (789) · Russian Internal News (state + in-exile) (684) · State-Level News (399) · World leaders & government officials (324) · Chinese Internal News (259) · Local News: St. Louis + Atlanta (229) · U.S. Weather + Severe / Climate Outlooks (132) · State Legislative Action (128) · Ukraine Theater (total-war monitoring) (72) · Court opinions of consequence (federal & state) (60) · Ukrainian Internal News (national + local Kyiv) (57) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 789 new of 1064 total
  - (2026-08-27) [Global] I was spending £700 a month: How I beat my late-night shopping addiction
      Younger generations are thought to be more susceptible to impulse spending. The BBC looks at ways to get it under control.
  - (2026-08-28) [Global] Fed has 'work to do' if price rises don't ease for Americans, Warsh says
      Kevin Warsh remarks suggest interest rates could be increased if policymakers think inflation is running too high.
  - (2026-08-28) [Global] Trump administration illegally retaliated against Anthropic, judge rules
      The AI startup has been at loggerheads with the Pentagon over the use of AI by the US military.
  - (2026-08-28) [Global] Selena Gomez pushes back against 'frivolous' fraud claims
      Selena Gomez's lawyer says the fraud case is "absurd" - but it is far from unusual for celebrity family business relationships to go wrong.
  - (2026-08-27) [Global] Military veterans told they owe thousands of pounds over clerical error
      Hundreds of former UK service personnel have had their pensions cut after being overpaid.
  - (2026-08-27) [Global] Overcooked? Why robotic pizza makers are failing
      A string of failures has sapped confidence that robots will take over production at pizza restaurants.

### Russian Internal News (state + in-exile) — 684 new of 1218 total
  - (2026-08-28) Bloomberg: европейские чиновники не увидели доказательств подготовки России к нападению на НАТО | LEDE: Европейские чиновники уверены, что нет никаких доказательств, указывающих на подготовк] (ru: Blo…
      Европейские чиновники уверены, что нет никаких доказательств, указывающих на подготовку России к нападению на НАТО или страны Балтии, утверждают источники Bloomberg.
  - (2026-08-28) «ВКонтакте» отключил трансляцию эфира «Яблока», во время которого партия собирала деньги на избирательную кампанию | LEDE: Сервис «VK Видео» отключил трансляцию эфира партии «Яблоко» под наз] (ru: «ВК…
      Сервис «VK Видео» отключил трансляцию эфира партии «Яблоко» под названием «Мирный стрим».
  - (2026-08-28) «Русал» планирует законсервировать часть мощностей — в том числе, в Пикалево. В 2009 году там вспыхнули протесты из-за закрытия градообразующих предприятий | LEDE: Производитель алюминия «Ру] (ru: «Ру…
      Производитель алюминия «Русал» планирует временно законсервировать часть мощностей по производству сырья в России, пишет «Коммерсант». Об этом говорится в обращении компании к премьер-министру России Михаилу Мишустину, с…
  - (2026-08-28) Жену акциониста Павла Крисевича задержали в России. Она временно вернулась в страну из Франции, куда уехала с мужем | LEDE: Жену художника и акциониста Павла Крисевича Елену Моргунову задерж] (ru: Жен…
      Жену художника и акциониста Павла Крисевича Елену Моргунову задержали, а затем назначили ей административный арест на 10 суток по обвинению в неповиновении требованиям силовиков, сообщают проекты «Зона свободы» и «Слово…
  - (2026-08-28) Бывший глава Минобороны Украины Михаил Федоров согласился стать советником министра обороны Италии. Но работу в Украине тоже продолжит | LEDE: Бывший министр обороны Украины Михаил Федоров в] (ru: Быв…
      Бывший министр обороны Украины Михаил Федоров встретился с главой Минобороны Италии Гвидо Крозетто и поблагодарил его за поддержку и предложение стать советником по оборонным инновациям.
  - (2026-08-28) Зеленский заявил, что поставил задачу запускать по России тысячу дронов в день | LEDE: Владимир Зеленский заявил, что поставил украинским военным задачу запускать по тысяче дронов в день по ] (ru: Зел…
      Владимир Зеленский заявил, что поставил украинским военным задачу запускать по тысяче дронов в день по России.

### State-Level News — 399 new of 804 total
  - (2026-08-28) [feed error] CalMatters (California): HTTPError
      429 Client Error: Too Many Requests for url: https://calmatters.org/feed/
  - (2026-08-28) [California] Governor Newsom announces $44 million for tribal stewardship, salmon recovery and desert protection projects
      Source
  - (2026-08-28) [California] Governor Newsom signs bipartisan measure to strengthen suicide prevention efforts for boys, young men
      Source
  - (2026-08-28) [California] Governor Newsom announces $2.7 billion for 150+ projects to expand and make California’s transportation system more resilient
      Source
  - (2026-08-28) [California] BUY CALIFORNIAN: Governor Newsom launches new campaign to help consumers identify California-made products
      Source
  - (2026-08-28) [California] Governor Newsom signs legislation 8.27.2026
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 259 new of 312 total
  - (2026-08-27) Analysis: China’s Next Infrastructure Push Is Bigger — and More Complicated - Caixin Global
      Analysis: China’s Next Infrastructure Push Is Bigger — and More Complicated Caixin Global
  - (2026-08-28) China Business Uncovered Podcast: Inside Italy’s Chinese Underground Banking Rings - Caixin Global
      China Business Uncovered Podcast: Inside Italy’s Chinese Underground Banking Rings Caixin Global
  - (2026-08-28) 景甜发声：不会为钱出卖爱情与灵魂 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE1ldDZUaDdqUUFTMFVxRnFFSGpENGFhMWE1RFRRMmtzSnUxQnBJQTJib2lJWnlKU0tBSEN6YXh2UHFIelZJb2VTRFhMWmpfdEpTcXZk] (zh:…
      景甜发声：不会为钱出卖爱情与灵魂 观察者
  - (2026-08-28) 孙宇晨写万字小作文谈景甜，虚伪利己 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiWkFVX3lxTE9SdmI3ckZzdzg4WlFiYWcwT0hXN3ptbVJKLUdNeHJwOWRQb2ZCTjlKUi0xWUk4RFdJSHM0aWgwRFBCeHlxVG5aQ2NzMmNzVG1oYWtV] (zh:…
      孙宇晨写万字小作文谈景甜，虚伪利己 风闻
  - (2026-08-28) 为何不能回北京？孙宇晨长文控诉景甜，意外扯出8年前“边控”旧闻 - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE9GcUZ6aDJiaHoxT1BXc2U5YjR3Z245dFd0b1hKTjFkNmFCM05Cc2ZxRWdTdU92LU1BcG5NTmFIY2NfWERrTjVpR] (zh:…
      为何不能回北京？孙宇晨长文控诉景甜，意外扯出8年前“边控”旧闻 观察者
  - (2026-08-27) 女子为独享空调冷气，用椅子卡死电梯门致全楼无法使用，谁在为“巨婴”买单？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiZkFVX3lxTFBCb3lJX1E0eTRXekdhVHpGUlFWUUkxWUpQZG9qc3ViQWtMTm42Q1B6enZBOVNsYXVFSTJMY0tBcVFnOENP] (zh:…
      女子为独享空调冷气，用椅子卡死电梯门致全楼无法使用，谁在为“巨婴”买单？ 观察者

### Local News: St. Louis + Atlanta — 229 new of 272 total
  - (2026-08-28) [St. Louis] St. Louis planning director now says he never heard from an ‘elected official’ after all
      For two weeks now, the city’s executive director of planning and urban design Don Roe has remained silent regarding which “elected official” allegedly reached out to him with concerns during an August 12 St. Louis Planni…
  - (2026-08-28) [St. Louis] Why some St. Louis restaurants don’t accept prepaid Visa gift cards
      Do some restaurants not accept pre-paid Visa gift cards? —Bill K., St. Louis I have to admit that this was a new one for me. I thought Visa gift cards were as good as cash—often better—and could be used everywhere that p…
  - (2026-08-28) [St. Louis] Lawsuit challenging WashU police ‘wanteds’ suffers big setback
      A big chunk of the lawsuit against Washington University that challenged area police departments’ use of wanteds was dismissed by a federal judge Wednesday. The suit had its origins in a climactic April 2024 pro-Palestia…
  - (2026-08-28) [St. Louis] What’s True in the Lou? – 8/28/2026
      How closely do you follow St. Louis news? We’re testing your knowledge of the stories we covered this week in the St. Louis Daily newsletter—the good, the bad, and the goofy. Submit your name at the end for a chance to b…
  - (2026-08-27) [St. Louis] Top cannabis events across St. Louis
      August 29: Brunch and Blunts August 30: Breathwork, Ice Bath & Sauna Workshop August 30: Puff N Paint Pottery September 1, 8, 15, 22, 29: Puff & Pose Yoga at the Church September 1, 15: Tabletop Tuesday – DnD and Ice Cre…
  - (2026-08-27) [St. Louis] Where in St. Charles? – 8/28/2026
      Let’s see how well you know St. Charles. Put a pin on the map based on where you think the photograph above was taken; the closer you are, the more points you earn. Enter your email to begin, and click “lock in my guess”…

### U.S. Weather + Severe / Climate Outlooks — 132 new of 133 total
  - (2026-08-28) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued August 28 at 4:17PM EDT until August 28 at 5:15PM EDT by NWS Greenville-Spartanburg SC
      SVRGSP The National Weather Service in Greenville-Spartanburg has issued a * Severe Thunderstorm Warning for... Northwestern Laurens County in Upstate South Carolina... Southeastern Greenville County in Upstate South Car…
  - (2026-08-28) [Severe] Special Marine Warning: Special Marine Warning issued August 28 at 4:16PM EDT until August 28 at 5:15PM EDT by NWS Boston/Norton MA
      SMWBOX The National Weather Service in Boston/Norton has issued a * Special Marine Warning for... Coastal waters east of Ipswich Bay and the Stellwagen Bank National Marine Sanctuary... Massachusetts Bay and Ipswich Bay.…
  - (2026-08-28) [Moderate] Special Weather Statement: Special Weather Statement issued August 28 at 4:16PM EDT by NWS Greenville-Spartanburg SC
      At 416 PM EDT, Doppler radar was tracking a strong thunderstorm 8 miles south of Statesville, or near Troutman, moving southeast at 20 mph. HAZARD...Wind gusts of 50 to 55 mph and half inch hail. SOURCE...Radar indicated…
  - (2026-08-28) [Moderate] Special Weather Statement: Special Weather Statement issued August 28 at 2:15PM MDT by NWS Salt Lake City UT
      At 215 PM MDT, Doppler radar was tracking a strong thunderstorm 15 miles southwest of Hatch, or 25 miles northeast of Zion National Park, moving northeast at 30 mph. HAZARD...Wind gusts of 50 to 55 mph and half inch hail…
  - (2026-08-28) [Moderate] Special Weather Statement: Special Weather Statement issued August 28 at 3:14PM CDT by NWS Jackson MS
      At 314 PM CDT, Doppler radar was tracking a strong thunderstorm over Le Tourneau, or 9 miles southwest of Vicksburg, moving southeast at 25 mph. HAZARD...Wind gusts up to 40 mph and pea size hail. SOURCE...Radar indicate…
  - (2026-08-28) [Moderate] Special Weather Statement: Special Weather Statement issued August 28 at 4:12PM EDT by NWS Peachtree City GA
      At 412 PM EDT, a strong thunderstorm was over LaGrange, moving southeast at 5 mph. HAZARD...Up to 40 mph wind, frequent cloud to ground lightning and heavy rain. SOURCE...Radar indicated. IMPACT...Expect minor damage to…

### State Legislative Action — 128 new of 174 total
  - (2026-08-27) [Alaska HB 10] An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
      An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
  - (2026-08-27) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…
  - (2026-08-28) [California SB 1207] California Conservation Corps.
      (1) Existing law establishes the California Conservation Corps in the Natural Resources Agency. Existing law requires the Governor to appoint the director of the corps to act as the administrative officer of the corps an…
  - (2026-08-28) [California AB 1832] 2-1-1 information and referral response system.
      Existing law, the California Emergency Services Act, creates, within the office of the Governor, the Office of Emergency Services (Cal OES) under the supervision of the Director of Emergency Services. Under existing law,…
  - (2026-08-28) [California AB 2080] Investment of funds: delegation to county treasurer.
      Existing law generally authorizes local agencies to invest or reinvest public funds and prescribes rules for that investing or reinvesting. Existing law authorizes a legislative body of a local agency to delegate this au…
  - (2026-08-28) [California AB 2058] California Factory-Built Housing Law.
      (1) Existing law, the California Factory-Built Housing Law, generally regulates the design, manufacture, and installation of factory-built housing and defines terms for its purposes. The law authorizes the Department of…

### Ukraine Theater (total-war monitoring) — 72 new of 233 total
  - (2026-08-27) [Liveuamap] Zelensky arrived in Chisinau to celebrate Moldova&039;s Independence Day. As part of the visit, the President of Ukraine will have a bilateral meeting with Moldovan President Maia Sandu Ch…
      Zelensky arrived in Chisinau to celebrate Moldova&039;s Independence Day. As part of the visit, the President of Ukraine
  - (2026-08-28) [Liveuamap] At least 5 Russian drones have violated the air space of Moldova overnight - Liveuamap
      At least 5 Russian drones have violated the air space of Moldova overnight Liveuamap
  - (2026-08-28) [Liveuamap] At Sloviansk direction clashes yesterday near Kryva Luka, Ray-Oleksandrivka, - General Staff of Armed Forces of Ukraine reports Donetsk Oblast, Ukraine - Ukraine Interactive map - Ukraine…
      At Sloviansk direction clashes yesterday near Kryva Luka, Ray-Oleksandrivka, - General Staff of Armed Forces of Ukraine reports D
  - (2026-08-25) [Liveuamap] Violent clashes and confrontations erupted between Houthis and Yemeni armed forces on the Kalaba front, northeast of Taiz. Taizz, Taizz Governorate - Interactive map of Yemen war - Liveuam…
      Violent clashes and confrontations erupted between Houthis and Yemeni armed forces on the Kalaba front, northea
  - (2026-08-25) [Liveuamap] Israeli forces fire tear gas canisters in the vicinity of Qalandiya camp and the UNRWA training institute in Jerusalem - Liveuamap
      Israeli forces fire tear gas canisters in the vicinity of Qalandiya camp and the UNRWA training insti
  - (2026-08-26) [Liveuamap] 1 person killed, 5 wounded as result of Russian airstrikes in Sloviansk - Liveuamap
      1 person killed, 5 wounded as result of Russian airstrikes in Sloviansk Liveuamap

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-09-01) Connecticut Supreme Court: Order on Motion - Aldin Associates Ltd. Partnership v. State
  - (2026-08-28) U.S. Court of Appeals, Federal Cir.: T-Mobile US, Inc. v. Kaifi LLC
  - (2026-08-28) U.S. Court of Appeals, Federal Cir.: Aml Ip, LLC v. Bath & Body Works Direct, Inc.
  - (2026-08-28) U.S. Court of Appeals, 6th Cir.: Diamond Williams v. Mastronardi Produce-USA, Inc.
  - (2026-08-28) U.S. Court of Appeals, 6th Cir.: Luis Gomez-Echeverria v. Purpose Point Harvesting, LLC
  - (2026-08-28) U.S. Court of Appeals, 6th Cir.: NetChoice, LLC v. Jonathan Skrmetti

### Ukrainian Internal News (national + local Kyiv) — 57 new of 127 total
  - (2026-08-28) У 16-му армійському корпусі закликають утриматись від передчасних висновків щодо інциденту з Ширшиним | LEDE: У 16-му армійському корпусі зазначили, що знають Олександра Ширшина, у якого раніше] (uk:…
      У 16-му армійському корпусі зазначили, що знають Олександра Ширшина, у якого раніше правоохоронці вилучили "пакети з речовиною рослинного походження", як офіцера, відданого справі захисту України, водночас у корпусі пров…
  - (2026-08-28) У Бучанському районі горять склади, лунають вибухи: перекрили рух житомирською трасою | LEDE: Рух транспорту на М-06 Київ – Чоп припинено на ділянці 15–32 км. Вказано об'їзди, причину перекритт] (uk:…
      Рух транспорту на М-06 Київ – Чоп припинено на ділянці 15–32 км. Вказано об'їзди, причину перекриття офіційно не названо.
  - (2026-08-28) РФ атакує Київ та Київщину другу добу поспіль: є постраждалі | LEDE: Унаслідок російських атак ударними БпЛА є поранений чоловік у Бориспільському районі на Київщині. Також, попередньо, відомо ] (uk:…
      Унаслідок російських атак ударними БпЛА є поранений чоловік у Бориспільському районі на Київщині. Також, попередньо, відомо про постраждалого в Києві.
  - (2026-08-28) Брехали, що для військових: у Чернівцях викрили схему торгівлі тканинами померлих | LEDE: Правоохоронці розкрили схему торгівлі анатомічними матеріалами померлих у Чернівцях. Посадовців бюро за] (uk:…
      Правоохоронці розкрили схему торгівлі анатомічними матеріалами померлих у Чернівцях. Посадовців бюро затримано, проведено обшуки, вилучено біоматеріали.
  - (2026-08-28) Труну короля Норвегії Гаральда привезли до палацу, процесію зустрічали тисячі людей | LEDE: ] (uk: Труну короля Норвегії Гаральда привезли до палацу, процесію зустрічали тисячі лю)
  - (2026-08-28) РФ увечері знову атакувала Запоріжжя: четверо людей постраждали | LEDE: Російські війська ввечері 28 серпня атакували приватний сектор у Запоріжжі: четверо людей звернулись за допомогою медиків] (uk:…
      Російські війська ввечері 28 серпня атакували приватний сектор у Запоріжжі: четверо людей звернулись за допомогою медиків.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-28) 497K - EXCHANGE TRADED CONCEPTS TRUST (0001452937) (Filer)
      filed 2026-08-28 20:16 UTC — Filed: 2026-08-28 AccNo: 0001213900-26-095058 Size: 65 KB
  - (2026-08-28) 424B2 - GS Finance Corp. (0001419828) (Filer)
      filed 2026-08-28 20:16 UTC — Filed: 2026-08-28 AccNo: 0001193125-26-374386 Size: 428 KB
  - (2026-08-28) 424B2 - GOLDMAN SACHS GROUP INC (0000886982) (Filer)
      filed 2026-08-28 20:16 UTC — Filed: 2026-08-28 AccNo: 0001193125-26-374386 Size: 428 KB
  - (2026-08-28) [GRAE SETH] Form 4 (Reporting)
      filed 2026-08-28 20:16 UTC · role: Reporting — Filed: 2026-08-28 AccNo: 0000891839-26-000378 Size: 7 KB
  - (2026-08-28) [LIGHTBRIDGE Corp] Form 4 (Issuer)
      filed 2026-08-28 20:16 UTC · role: Issuer — Filed: 2026-08-28 AccNo: 0000891839-26-000378 Size: 7 KB
  - (2026-08-28) 424B2 - ROYAL BANK OF CANADA (0001000275) (Filer)
      filed 2026-08-28 20:16 UTC — Filed: 2026-08-28 AccNo: 0000950103-26-013110 Size: 320 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 37 new of 56 total
  - (2026-08-28) [BleepingComputer] PaperCut releases second emergency patch for exploited flaws
      PaperCut has released a second emergency security update for two actively exploited vulnerabilities in its PaperCut NG and MF print management software after researchers discovered multiple ways to bypass the initial fix…
  - (2026-08-28) [BleepingComputer] GiveWP WordPress donation plugin flaw lets hackers execute server commands
      A maximum-severity vulnerability in the GiveWP plugin for WordPress allows an unauthenticated attacker to execute arbitrary commands on the hosting server. [...]
  - (2026-08-28) [BleepingComputer] 68-year-old imprisoned after making $1.3 million by pirating IPTV services
      A 68-year-old has been sentenced in the U.K. to more than six years in prison for operating an illegal IPTV (Internet Protocol Television) service that generated £980,812 ($1.3 million) over three years. [...]
  - (2026-08-28) [BleepingComputer] AI Is Accelerating Vulnerability Discovery. Can Defenders Keep Up?
      AI is accelerating vulnerability discovery, putting pressure on systems built to enrich, prioritize, and remediate flaws at a slower pace. Action1 explains why defenders increasingly need to correlate multiple intelligen…
  - (2026-08-28) [BleepingComputer] Over 8,300 Gitea servers vulnerable to code execution attacks
      Over 8,300 Internet-exposed Gitea instances are still unpatched against a critical security flaw exploited in ongoing remote code execution attacks, according to cybersecurity watchdog Shadowserver. [...]
  - (2026-08-28) [The Hacker News] Attackers Chain Two PaperCut Flaws to Execute Code Without Authentication
      Malicious actors are exploiting a newly patched security flaw in PaperCut NG and MF to execute arbitrary code on susceptible instances, as the company released a fresh emergency fix with additional hardening. "This vulne…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-08-28) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (38.9161, 0.7919) · alt: 11277m · 762km/h
  - (2026-08-28) PAT384 (United States)
      icao24: adfe8f · position: (41.4966, -111.0485) · alt: 4907m · 563km/h
  - (2026-08-28) PAT314 (United States)
      icao24: adfdd1 · position: (40.056, -77.252) · alt: 4610m · 513km/h
  - (2026-08-28) AF1 (United States)
      icao24: af83f3 · position: (37.3564, -77.9727) · alt: 7208m · 856km/h
  - (2026-08-28) JAF8WB (Belgium)
      icao24: 44d1ba · position: (49.6415, 8.1311) · alt: 10363m · 853km/h
  - (2026-08-28) JAF9WL (Belgium)
      icao24: 44d1a6 · position: (45.3238, 1.0139) · alt: 11582m · 789km/h

### Government Action: Sanctions + Procurement + Foreign Agents — 27 new of 113 total
  - (2026-08-28) [OFAC] Iran-related and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Iran-related and Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] Issuance of Amended Venezuela-related General Licenses and Associated Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Issuance of Amended Venezuela-related General Licenses and Associated Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 50C Authorizing Transactio - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 50C Authorizing Transactio Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 52B Authorizing Certain Tr - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 52B Authorizing Certain Tr Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54B Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54B Authorizing the Supply Office of Foreign Assets Control (.gov)

### U.S. Federal Action — 25 new of 25 total
  - (2026-08-28) Streamlining Export Controls for Drone Exports
  - (2026-08-28) Honoring the Memory of Dolly Parton
  - (2026-08-28) Special Conditions: Skyryse, Robinson Helicopter Company Model R66 Helicopter; Control Margin Awareness
      This action proposes special conditions for the Robinson Helicopter Company (Robinson) Model R66 helicopter. This helicopter, as modified by Skyryse, will have a novel or unusual design feature when compared to the state…
  - (2026-08-28) International Traffic in Arms Regulations: Modification of Civil Aircraft To Incorporate Aircraft Survivability Equipment
      The Department of State (the Department) amends the International Traffic in Arms Regulations (ITAR) to remove from the U.S. Munitions List (USML) certain aircraft that have been modified to incorporate aircraft survivab…
  - (2026-08-28) Passports: Expanding Online Passport Renewal Overseas
      The Department proposes to amend 22 CFR 51.21 by consolidating requirements for persons applying by mail and online in the United States and overseas. This proposed change includes expanding online passport application a…
  - (2026-08-28) Requests for Arbitration Panels
      The Federal Mediation and Conciliation Service (FMCS) is issuing an interim final rule with requests for comments to amend its arbitration services regulations. The interim final rule clarifies the circumstances in which…

### Paper Trading Scorecard — 16 new of 125 total
  - (2026-08-28) [Polymarket] Will the price of Bitcoin be above $72,000 on August 29?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…
  - (2026-08-28) [Polymarket] Will Ethereum reach $3,100 in August?
      This market will resolve to "Yes" if any Binance 1 minute candle for ETH/USDT from the creation of this market through 11:59 PM ET on the last day of the month specified in the title has a final High price equal to or gr…
  - (2026-08-28) [Manifold] Will @jim publish an article on his AI timelines by end-of-month?
  - (2026-08-28) [Manifold] Will the WTI Crude Oil Spot Price be above $83 on September 10, 2026?
  - (2026-08-28) [Manifold] Do you like 82% odds?
  - (2026-08-28) [Manifold] Will 0x53a125F03c90B8E07BA50356B312F4b7b9bA47A7 REACH more than 210.30 USDC on Base by the end of August

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-08-28) Will Manchester City FC win on 2026-08-28?
      yes price: 80% · 24h volume: $2,835,176 · resolves 2026-08-28
  - (2026-08-28) Will Real Racing Club win on 2026-08-28?
      yes price: 100% · 24h volume: $2,489,829 · resolves 2026-08-28
  - (2026-08-28) Will FC Bayern München win on 2026-08-28?
      yes price: 100% · 24h volume: $1,619,353 · resolves 2026-08-28
  - (2026-08-28) Will the Fed increase interest rates by 50+ bps after the September 2026 meeting?
      yes price: 0% · 24h volume: $1,076,722 · resolves 2026-09-16
  - (2026-08-28) Will AC Milan win on 2026-08-28?
      yes price: 48% · 24h volume: $858,933 · resolves 2026-08-28
  - (2026-08-28) Crystal Palace FC vs. Manchester City FC: O/U 0.5
      yes price: 100% · 24h volume: $663,302 · resolves 2026-08-28

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-08-27) M 6.0 - 145 km N of Caluula, Somalia
      M6.0 · 145 km N of Caluula, Somalia · depth 10 km
  - (2026-08-28) M 5.2 - southeast Indian Ridge
      M5.2 · southeast Indian Ridge · depth 10 km
  - (2026-08-28) M 5.0 - 172 km SE of Petropavlovsk-Kamchatsky, Russia
      M5.0 · 172 km SE of Petropavlovsk-Kamchatsky, Russia · depth 10 km
  - (2026-08-28) M 5.0 - 109 km WNW of Isangel, Vanuatu
      M5.0 · 109 km WNW of Isangel, Vanuatu · depth 10 km
  - (2026-08-28) M 5.0 - 19 km NW of Fuji, China
      M5.0 · 19 km NW of Fuji, China · depth 10 km
  - (2026-08-28) M 5.0 - northern East Pacific Rise
      M5.0 · northern East Pacific Rise · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 40 total
  - (2026-08-28) #30 Zhong Shanshan — $63.67B
      China · Food & Beverage · source: Beverages, pharmaceuticals · holdings: 603392-CN(SHANGHAI), 9633-HK(HONG KONG)
  - (2026-08-28) MOVER ▼ Larry Page — $282.94B ($-0.38B since yesterday)
      United States · Technology · source: Google
  - (2026-08-28) MOVER ▼ Sergey Brin — $261.00B ($-0.35B since yesterday)
      United States · Technology · source: Google
  - (2026-08-28) MOVER ▲ Germán Larrea Mota Velasco & family — $71.10B (+$0.25B since yesterday)
      Mexico · Metals & Mining · source: Mining
  - (2026-08-28) MOVER ▼ Thomas Peterffy — $110.62B ($-0.25B since yesterday)
      United States · Finance & Investments · source: Discount brokerage

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-28) [Marginal Revolution] Tysons Corner (Alaska) fact of the day
      The centerpiece is Tysons Corner Center, today the eighth largest mall in the country, and one of the largest sub-city-sized markets for office space. It is half-owned by the Alaska Permanent Fund, which is the state-own…
  - (2026-08-28) [Marginal Revolution] Friday assorted links
      1. “With homicides up 50% since 2020—putting the country’s murder rate on par with Mexico’s—Costa Rican President Laura Fernández and her ruling party are blaming the independent judiciary.” (WSJ) 2. The Monterrey spirit…
  - (2026-08-28) [Marginal Revolution] A Big Bet on Explosive AI-Driven Growth
      Wow! The excellent Ben Moll has put together a high-stakes bet on US economic growth. A bet on near-term explosive AI-driven growth: whether U.S. real GDP per capita will grow by at least 15% within a single year (measur…
  - (2026-08-28) [Conversable Economist] GAO: One More Warning on US Federal Debt
      The Government Accountability Office (GAO) offers a blunt title for its most recent review of US fiscal policy: “The Nation’s Fiscal Health — Urgent and Sustained Action Needed to Improve the Fiscal Outlook (June 2026).…

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-08-28) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo
      Since the last Disease Outbreak News was published on 14 August 2026, the outbreak has spread from 54 to 60 health zones. The number of affected provinces stands at six out of 26 provinces of the country: Bas-Uélé, Haut-…

### EPSS — highest exploit-probability CVEs — 1 new of 40 total
  - (2026-08-28) CVE-2025-53770: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=19, 14d-median=20; carrying terms: navigable, certain, establish, national, management, establishing, proposes, action, proposed, within, public, representative
- state_bills: today=174, 7d-median=134, 14d-median=134; carrying terms: funds, resources, emergency, offense, generally, board, certain, california, division, authority, contact, required
- state_news: today=804, 7d-median=597, 14d-median=597; carrying terms: seeking, funds, longer, height, though, effort, analysis, board, largest, black, california, counties
- local_news: today=272, 7d-median=254, 14d-median=238; carrying terms: flock, another, child, trial, charges, officials, faces, crash, alert, public, following, falcons
- foreign_news: today=1064, 7d-median=1023, 14d-median=1002; carrying terms: seeking, drought, overnight, japan, brainpower, remain, beijing, watchdog, height, ahead, reached, xuejun
- chinese_internal: today=312, 7d-median=284, 14d-median=284; carrying terms: cbmiaefvx, cbmibefvx, cbmibkfvx, target, cbmizefvx, https, caixin, cbmiw, lxtfb, cbmib, blank, cbmix
- russian_internal: today=1218, 7d-median=1030, 14d-median=1030; carrying terms: https, forbidden, gazeta, error, reuters, journal, media, europe, client, bloomberg, found, times
- ukrainian_internal: today=127, 7d-median=115, 14d-median=112; carrying terms: overnight, missile, secure, ahead, germany, babel, energy, bring, launched, offering, elections, expected
- ukraine_theater: today=233, 7d-median=841, 14d-median=880; carrying terms: tnrrrg, cuxoa, vugxoyuzqrfzpcnjsd, zlvdum, allocates, coverage, jjdulknenemdgwoxzyx, nczblbulyxzu, skies, ndbxohayttristhstnrdwkdewurjcel, qzbkvme, yunjamotn
- paper_bets: today=125, 7d-median=131, 14d-median=133; carrying terms: funds, drought, seats, washington, celsius, romania, experience, remain, industrial, leave, office, committed
- weather: today=133, 7d-median=143, 14d-median=145; carrying terms: overnight, remain, afdokx, afdfwd, occurring, portions, below, gusts, north, western, flood, forecast
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: indicator, funds, rates, sheet, walcl, headline, money, inflation, payems, consumption, nonfarm, treasury
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: crypto, natural, rates, corporate, russell, nasdaq, agriculture, treasury, bitcoin, equities, range, commodities
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=113, 7d-median=102, 14d-median=100; carrying terms: funds, legislation, islamic, office, imposed, mediterranean, satisfying, energy, compare, guatemala, enable, nonprofit
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, quiver, quiverquant, client, error, unauthorized, quantitative, httperror, congresstrading
- billionaires: today=40, 7d-median=30, 14d-median=34; carrying terms: fashion, gmexicob, tesla, charles, telecom, bernard, mining, discount, google, finance, julia, gcarsoa
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: court, supreme, state, appeals, california, connecticut, center, company, america, delaware, county, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, holdings, management, capital, group, scott, trust
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: warner, robert, platner, talarico, krishnamoorthi, johnson, pinkston, graham, angels, elect, booker, senate
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: japan, english, defense, china
- gdelt_gkg: today=0, 7d-median=25, 14d-median=45; carrying terms: english, trump, keywords, sanctions, perimeter, russian, themes, russia, spanish, ukrainian, chinese, attack
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: france, position, belgium, kingdom, canada, bulgaria, netherlands
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: monkeypox, according, transmitted, individuals, index, surges, centers, ongoing, regions, expanded, cross, mainly
- cisa_kev: today=20, 7d-median=12, 14d-median=12; carrying terms: injection, authentication, command, function, vulnerability, vendor, product, microsoft, remediation, project, missing, double
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=14, 7d-median=14, 14d-median=18; carrying terms: indonesia, depth, japan, russia, tonga, papua, guinea, vanuatu, chile, ridge, northern
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: champions, price, august, rates, resolves, meeting, volume, interest, september, shakhtar, donetsk, league
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: https, class, conversable, economist, revolution, marginal, demand, assorted, links, number, together, marginalrevolution
- tech_news: today=56, 7d-median=55, 14d-median=55; carrying terms: computer, report, agents, companies, researchers, disclosed, attacks, weekly, breach, critical, services, across
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: durbin, roger, mrvan, charles, mariannette, warnock, ricketts, peter, nikki, reschenthaler, alford, advisers
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: placement, identify, markets, sufficient, consensus, unavailable, placed, paper, module, either, decision, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*