# WORLDSCOPE morning brief — 2026-08-28

## Headline
3496 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (780) · Russian Internal News (state + in-exile) (726) · State-Level News (385) · World leaders & government officials (324) · Ukraine Theater (total-war monitoring) (269) · Chinese Internal News (249) · Local News: St. Louis + Atlanta (215) · U.S. Weather + Severe / Climate Outlooks (125) · State Legislative Action (61) · Court opinions of consequence (federal & state) (60) · Ukrainian Internal News (national + local Kyiv) (57) · SEC Form 4 insider transactions (recent) (40)

## What changed today
### International News + Multilateral Institutions — 780 new of 1060 total
  - (2026-08-28) [Global] Israel army carries out rare West Bank air strike, killing 'three terrorists'
      Israel's military said it carried out an air strike in the Jenin area in the West Bank on Friday that killed a ​Palestinian it described as a Hamas militant operative as well as two of his accomplices, in a rare use of d…
  - (2026-08-28) [Global] 🔴Nepal-Tibet floods live: Death toll passes 580, nearly 2,500 people missing
  - (2026-08-28) [Global] Nepal: 'Region has hundreds of high-altitude lakes prone to unleashing enormous volumes of water'
      William Hilderbrandt is pleased to welcome David Fisher, Head of Delegation, Nepal International Federation of Red Cross. The scale of Nepal’s disaster cannot yet be fully measured. Entire communities remain difficult to…
  - (2026-08-28) [Global] Nepal: Families cling to hope as nearly 1,000 remain missing
      Nepal's confirmed death toll has risen to at least 538, but families are still searching hospitals and disaster zones in the hope their loved ones will be found alive, with nearly 1,000 people still missing. More than 3,…
  - (2026-08-28) [Global] Norway mourns King Harald as Haakon prepares to take the throne
      Norway is mourning King Harald V after the country's longest-serving monarch died at the age of 89, with tributes pouring in from across Europe. His death paves the way for Crown Prince Haakon to become king, as the roya…
  - (2026-08-28) [Global] Nepal: Relief camp shelters grieving families
      Around 500 people are sheltering at a monastery-turned-relief camp in northern Kathmandu, where many families are still in shock after losing their homes and loved ones in the devastating Nepal floods. FRANCE 24's Shahza…

### Russian Internal News (state + in-exile) — 726 new of 1261 total
  - (2026-08-28) «ВКонтакте» отключил трансляцию эфира «Яблока», во время которого партия собирала деньги на избирательную кампанию | LEDE: Сервис «VK Видео» отключил трансляцию эфира партии «Яблоко» под наз] (ru: «ВК…
      Сервис «VK Видео» отключил трансляцию эфира партии «Яблоко» под названием «Мирный стрим».
  - (2026-08-28) «Русал» планирует законсервировать часть мощностей — в том числе, в Пикалево. В 2009 году там вспыхнули протесты из-за закрытия градообразующих предприятий | LEDE: Производитель алюминия «Ру] (ru: «Ру…
      Производитель алюминия «Русал» планирует временно законсервировать часть мощностей по производству сырья в России, пишет «Коммерсант». Об этом говорится в обращении компании к премьер-министру России Михаилу Мишустину, с…
  - (2026-08-28) Жену акциониста Павла Крисевича задержали в России. Она временно вернулась в страну из Франции, куда уехала с мужем | LEDE: Жену художника и акциониста Павла Крисевича Елену Моргунову задерж] (ru: Жен…
      Жену художника и акциониста Павла Крисевича Елену Моргунову задержали, а затем назначили ей административный арест на 10 суток по обвинению в неповиновении требованиям силовиков, сообщают проекты «Зона свободы» и «Слово…
  - (2026-08-28) Бывший глава Минобороны Украины Михаил Федоров согласился стать советником министра обороны Италии. Но работу в Украине тоже продолжит | LEDE: Бывший министр обороны Украины Михаил Федоров в] (ru: Быв…
      Бывший министр обороны Украины Михаил Федоров встретился с главой Минобороны Италии Гвидо Крозетто и поблагодарил его за поддержку и предложение стать советником по оборонным инновациям.
  - (2026-08-28) Зеленский заявил, что поставил задачу запускать по России тысячу дронов в день | LEDE: Владимир Зеленский заявил, что поставил украинским военным задачу запускать по тысяче дронов в день по ] (ru: Зел…
      Владимир Зеленский заявил, что поставил украинским военным задачу запускать по тысяче дронов в день по России.
  - (2026-08-28) «Я увидела, как непальский повар из нашей команды выпрыгивает в окно. Повернула голову и увидела несущуюся на нас черную грязь». Рассказ двух россиянок, которые спаслись при наводнении в Непале] (ru:…
      В Непале 26 августа произошла одна из крупнейших катастроф в современной истории страны. На семитысячнике Лангтанг-Лирунг недалеко от непало-китайской границы часть скальной породы и ледника обрушилась в речную долину, о…

### State-Level News — 385 new of 795 total
  - (2026-08-27) [Alabama] Flags Lowered Honoring American Patriot Roy Henry Drinkard
      Download
  - (2026-08-28) [California] Governor Newsom announces $44 million for tribal stewardship, salmon recovery and desert protection projects
      Source
  - (2026-08-28) [California] Governor Newsom signs bipartisan measure to strengthen suicide prevention efforts for boys, young men
      Source
  - (2026-08-28) [California] Governor Newsom announces $2.7 billion for 150+ projects to expand and make California’s transportation system more resilient
      Source
  - (2026-08-28) [California] BUY CALIFORNIAN: Governor Newsom launches new campaign to help consumers identify California-made products
      Source
  - (2026-08-28) [California] Governor Newsom signs legislation 8.27.2026
      Source

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Ukraine Theater (total-war monitoring) — 269 new of 432 total
  - (2026-08-27) [FIRMS] thermal anomaly 45.957, 22.866 (FRP 0.55 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-27 0132Z, FRP 0.55 MW
  - (2026-08-27) [FIRMS] thermal anomaly 44.244, 22.902 (FRP 1.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-27 0132Z, FRP 1.18 MW
  - (2026-08-27) [FIRMS] thermal anomaly 44.243, 22.907 (FRP 1.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-27 0132Z, FRP 1.18 MW
  - (2026-08-27) [FIRMS] thermal anomaly 44.242, 22.911 (FRP 0.97 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-27 0132Z, FRP 0.97 MW
  - (2026-08-27) [FIRMS] thermal anomaly 51.891, 34.383 (FRP 1.08 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-27 0128Z, FRP 1.08 MW
  - (2026-08-27) [FIRMS] thermal anomaly 51.891, 34.387 (FRP 1.27 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-08-27 0128Z, FRP 1.27 MW

### Chinese Internal News — 249 new of 313 total
  - (2026-08-28) 今日开盘：两市双双低开 沪指跌幅0.16% - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTFA4SDZSR3dnRzFuLTBOaHNoWkdaM2dfdGFfaW9OVlhzWHlYV1Jqb1hUM3hPUjI2THpkU3ZDVnI4TG5XQy1SV2liR] (zh:…
      今日开盘：两市双双低开 沪指跌幅0.16% Caixin Global
  - (2026-08-27) 王毅会见美驻华大使：为两国高层交往排除干扰 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9EM2JQMjZja0FIU1RzTHo2Uk5Pek1wdlJEYmtsSm5kZEFqb1h4RUpLSWRFWEJqT1JzMlNEWVBVbzlNY01GMF9yX] (zh:…
      王毅会见美驻华大使：为两国高层交往排除干扰 Caixin Global
  - (2026-08-27) 61岁江西省长叶建春任上落马 - china.caixin.com | LEDE: <a href="https://news.google.com/rss/articles/CBMiX0FVX3lxTFAxR2M1VDF4endlWFo3elN4cThQaF93Nm9oUjdHQ29QUldKRlVUOHR2ZVluYVJidG5XNlJqZ0JSb25xQTBiWVZGOTNpY] (zh:…
      61岁江西省长叶建春任上落马 china.caixin.com
  - (2026-08-28) 唐师曾十趣｜纪念 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBla1pVQXEyVldyeklVTXUyc0FwbGh2d0NOSG11b3FDRV9yRlF5Q3Y0RjZqc2x6MllJdGIwdGFTTEdKLU1XYlhsNF93VVJ4OVFMQ3] (zh:…
      唐师曾十趣｜纪念 Caixin Global
  - (2026-08-28) 魏应彪升任中航工业“一把手” 总经理一职暂时悬空 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiZEFVX3lxTE5IdkhwTW42aTBTbFZGMFNoTjNUYldKSUNLSV9FMkxXZDEwZGxydUVpWWljWlJZUHdLUUVIeU9PdkhWZXBmbn] (zh:…
      魏应彪升任中航工业“一把手” 总经理一职暂时悬空 Caixin Global
  - (2026-08-28) 走向东盟：出海3.0，告别旧地图｜播客《探路东盟》 - Caixin Global | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1mRDVidlVCYVZtQTdHb0JqNUMzbnM1MG1hSnlpbmVXUS1QX1R0N3JrWjJnZmR4TWJLUF8wSF9tM204S2dFM] (zh:…
      走向东盟：出海3.0，告别旧地图｜播客《探路东盟》 Caixin Global

### Local News: St. Louis + Atlanta — 215 new of 260 total
  - (2026-08-28) [St. Louis] Death toll rises to more than 550 after catastrophic floods near Nepal-China border as lake poses new flood threat
      China's state media previously said 558 people were missing, and Nepal’s disaster management authority said Friday that 1,924 people are unaccounted for.
  - (2026-08-28) [St. Louis] Downtown St. Louis sandwich shop closed
      It is unclear exactly when the restaurant shut its doors. Writing on the storefront's door seen Thursday read "This location is closed!"
  - (2026-08-28) [St. Louis] Researchers find rare eel in Mississippi River
      “Eels are one of the few species that make me jump up and down in the back of the boat,” larger river scientist Jason DeBoer said.
  - (2026-08-28) [St. Louis] What did the Artemis II crew give to President Trump?
      President Trump honors the Artemis II crew, unveils a US Space Academy, and receives a NASA flight jacket.
  - (2026-08-28) [St. Louis] President Trump signs executive order to create US Space Academy
      Trump said he would soon decide a location for the academy, which he said will match the rigor of West Point, the Air Force Academy and other military academies.
  - (2026-08-28) [St. Louis] Daily Dose: New autism research, Lindsay Clancy trial and postpartum psychosis and a breakthrough for heart failure patients
      Groundbreaking new map of autism's biology, what a high-profile trial is teaching us about postpartum psychosis, plus a new at-home option for heart failure.

### U.S. Weather + Severe / Climate Outlooks — 125 new of 126 total
  - (2026-08-28) [Moderate] Special Weather Statement: Special Weather Statement issued August 28 at 3:10PM EDT by NWS Peachtree City GA
      At 310 PM EDT, a strong thunderstorm was over Williamson, or near Griffin, moving southeast at 5 mph. HAZARD...40 to 50 mph wind, pea sized hail and frequent cloud to ground lightning. SOURCE...Radar indicated. IMPACT...…
  - (2026-08-28) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-08-28) [Moderate] Special Weather Statement: Special Weather Statement issued August 28 at 3:04PM EDT by NWS Raleigh NC
      At 304 PM EDT, Doppler radar was tracking a strong thunderstorm over Southern Pines, moving southeast at 10 mph. HAZARD...Wind gusts up to 50 mph and pea size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could kn…
  - (2026-08-28) [Severe] Special Marine Warning: Special Marine Warning issued August 28 at 3:03PM EDT until August 28 at 4:00PM EDT by NWS Tampa Bay Ruskin FL
      SMWTBW The National Weather Service in Ruskin has issued a * Special Marine Warning for... Coastal waters from Englewood to Tarpon Springs FL out 20 NM... Tampa Bay waters... Waters from Englewood to Tarpon Springs FL ou…
  - (2026-08-28) [Moderate] Special Weather Statement: Special Weather Statement issued August 28 at 3:01PM EDT by NWS Peachtree City GA
      At 301 PM EDT, a strong thunderstorm was over Gillsville, or 8 miles west of Homer, moving southeast at 5 mph. HAZARD...Up to 40 mph wind, pea sized hail and frequent cloud to ground lightning. SOURCE...Radar indicated.…
  - (2026-08-28) [Moderate] Special Weather Statement: Special Weather Statement issued August 28 at 2:01PM CDT by NWS Birmingham AL
      At 201 PM CDT, Doppler radar was tracking a strong thunderstorm near Notasulga, moving west at 10 mph. HAZARD...Wind gusts up to 40 mph and nickel size hail. SOURCE...Radar indicated. IMPACT...Gusty winds could knock dow…

### State Legislative Action — 61 new of 107 total
  - (2026-08-27) [Alaska HB 10] An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
      An Act relating to the Board of Regents of the University of Alaska; and providing for an effective date.
  - (2026-08-27) [Alaska SB 2001] An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for pu…
      An Act relating to the taxation of certain natural gas project property and related facilities; relating to the determination of the value of taxable real and personal property for purposes of calculating local contribut…
  - (2026-08-28) [California SB 1207] California Conservation Corps.
      (1) Existing law establishes the California Conservation Corps in the Natural Resources Agency. Existing law requires the Governor to appoint the director of the corps to act as the administrative officer of the corps an…
  - (2026-08-28) [California AB 1832] 2-1-1 information and referral response system.
      Existing law, the California Emergency Services Act, creates, within the office of the Governor, the Office of Emergency Services (Cal OES) under the supervision of the Director of Emergency Services. Under existing law,…
  - (2026-08-28) [California AB 2080] Investment of funds: delegation to county treasurer.
      Existing law generally authorizes local agencies to invest or reinvest public funds and prescribes rules for that investing or reinvesting. Existing law authorizes a legislative body of a local agency to delegate this au…
  - (2026-08-28) [California AB 2058] California Factory-Built Housing Law.
      (1) Existing law, the California Factory-Built Housing Law, generally regulates the design, manufacture, and installation of factory-built housing and defines terms for its purposes. The law authorizes the Department of…

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-09-01) Connecticut Supreme Court: Order on Motion - Aldin Associates Ltd. Partnership v. State
  - (2026-08-28) U.S. Court of Appeals, D.C. Cir.: Cheryl Walker v. Uber Technologies, Inc.
  - (2026-08-28) U.S. Court of Appeals, D.C. Cir.: East Tennessee Group v. FERC
  - (2026-08-28) U.S. Court of Appeals, D.C. Cir.: United States v. Cesar Almonte
  - (2026-08-28) U.S. Court of Appeals, Federal Cir.: T-Mobile US, Inc. v. Kaifi LLC
  - (2026-08-28) U.S. Court of Appeals, Federal Cir.: Aml Ip, LLC v. Bath & Body Works Direct, Inc.

### Ukrainian Internal News (national + local Kyiv) — 57 new of 127 total
  - (2026-08-28) Вибухи в Бучанському районі. Перекрито рух усього транспорту житомирською трасою | LEDE: Рух транспорту на М-06 Київ – Чоп припинено на ділянці 15–32 км. Вказано об'їзди, причину перекриття офі] (uk:…
      Рух транспорту на М-06 Київ – Чоп припинено на ділянці 15–32 км. Вказано об'їзди, причину перекриття офіційно не названо.
  - (2026-08-28) РФ атакує Київ та Київщину другу добу поспіль: є постраждалі | LEDE: Унаслідок російських атак ударними БпЛА є поранений чоловік у Бориспільському районі на Київщині. Також, попередньо, відомо ] (uk:…
      Унаслідок російських атак ударними БпЛА є поранений чоловік у Бориспільському районі на Київщині. Також, попередньо, відомо про постраждалого в Києві.
  - (2026-08-28) Брехали, що для військових: у Чернівцях викрили схему торгівлі тканинами померлих | LEDE: Правоохоронці розкрили схему торгівлі анатомічними матеріалами померлих у Чернівцях. Посадовців бюро за] (uk:…
      Правоохоронці розкрили схему торгівлі анатомічними матеріалами померлих у Чернівцях. Посадовців бюро затримано, проведено обшуки, вилучено біоматеріали.
  - (2026-08-28) Труну короля Норвегії Гаральда привезли до палацу, процесію зустрічали тисячі людей | LEDE: ] (uk: Труну короля Норвегії Гаральда привезли до палацу, процесію зустрічали тисячі лю)
  - (2026-08-28) РФ увечері знову атакувала Запоріжжя: четверо людей постраждали | LEDE: Російські війська ввечері 28 серпня атакували приватний сектор у Запоріжжі: четверо людей звернулись за допомогою медиків] (uk:…
      Російські війська ввечері 28 серпня атакували приватний сектор у Запоріжжі: четверо людей звернулись за допомогою медиків.
  - (2026-08-28) Операція "Форест Гамп": підозру оголосили бізнесмену Василю Астіону – джерела | LEDE: Бізнесмен Василь Астіон, ексдепутат Дніпропетровської облради, підозрюється у рейдерстві та відмиванні кошт] (uk:…
      Бізнесмен Василь Астіон, ексдепутат Дніпропетровської облради, підозрюється у рейдерстві та відмиванні коштів у межах справи НАБУ і САП.

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-08-28) 424B2 - BARCLAYS BANK PLC (0000312070) (Filer)
      filed 2026-08-28 19:02 UTC — Filed: 2026-08-28 AccNo: 0001918704-26-025434 Size: 423 KB
  - (2026-08-28) 424B2 - Morgan Stanley Finance LLC (0001666268) (Filer)
      filed 2026-08-28 19:01 UTC — Filed: 2026-08-28 AccNo: 0001839882-26-042309 Size: 493 KB
  - (2026-08-28) 424B2 - MORGAN STANLEY (0000895421) (Filer)
      filed 2026-08-28 19:01 UTC — Filed: 2026-08-28 AccNo: 0001839882-26-042309 Size: 493 KB
  - (2026-08-28) [Crescent Capital BDC, Inc.] Form 4 (Issuer)
      filed 2026-08-28 19:01 UTC · role: Issuer — Filed: 2026-08-28 AccNo: 0000854241-26-000003 Size: 7 KB
  - (2026-08-28) [FIDELITY & GUARANTY LIFE INSURANCE CO] Form 4 (Reporting)
      filed 2026-08-28 19:01 UTC · role: Reporting — Filed: 2026-08-28 AccNo: 0000854241-26-000003 Size: 7 KB
  - (2026-08-28) 424B2 - GS Finance Corp. (0001419828) (Filer)
      filed 2026-08-28 19:01 UTC — Filed: 2026-08-28 AccNo: 0001193125-26-374029 Size: 853 KB

### IT, InfoSys & cybersecurity news (last 7 days) — 37 new of 56 total
  - (2026-08-28) [BleepingComputer] PaperCut releases second emergency patch for exploited flaws
      PaperCut has released a second emergency security update for two actively exploited vulnerabilities in its PaperCut NG and MF print management software after researchers discovered multiple ways to bypass the initial fix…
  - (2026-08-28) [BleepingComputer] GiveWP WordPress donation plugin flaw lets hackers execute server commands
      A maximum-severity vulnerability in the GiveWP plugin for WordPress allows an unauthenticated attacker to execute arbitrary commands on the hosting server. [...]
  - (2026-08-28) [BleepingComputer] 68-year-old imprisoned after making $1.3 million by pirating IPTV services
      A 68-year-old has been sentenced in the U.K. to more than six years in prison for operating an illegal IPTV (Internet Protocol Television) service that generated £980,812 ($1.3 million) over three years. [...]
  - (2026-08-28) [BleepingComputer] AI Is Accelerating Vulnerability Discovery. Can Defenders Keep Up?
      AI is accelerating vulnerability discovery, putting pressure on systems built to enrich, prioritize, and remediate flaws at a slower pace. Action1 explains why defenders increasingly need to correlate multiple intelligen…
  - (2026-08-28) [BleepingComputer] Over 8,300 Gitea servers vulnerable to code execution attacks
      Over 8,300 Internet-exposed Gitea instances are still unpatched against a critical security flaw exploited in ongoing remote code execution attacks, according to cybersecurity watchdog Shadowserver. [...]
  - (2026-08-28) [The Hacker News] Attackers Chain Two PaperCut Flaws to Execute Code Without Authentication
      Malicious actors are exploiting a newly patched security flaw in PaperCut NG and MF to execute arbitrary code on susceptible instances, as the company released a fresh emergency fix with additional hardening. "This vulne…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 28 new of 30 total
  - (2026-08-28) JAF2XB (Bulgaria)
      icao24: 4520aa · position: (42.5703, 7.5998) · alt: 10866m · 695km/h
  - (2026-08-28) RCH5050 (United States)
      icao24: adfe5f · position: (41.7108, -90.0514) · alt: 6096m · 566km/h
  - (2026-08-28) PAT384 (United States)
      icao24: adfe8f · position: (43.4451, -116.0441) · alt: 4023m · 356km/h
  - (2026-08-28) PAT302 (United States)
      icao24: adfe8d · position: (42.4645, -71.2173) · alt: 304m · 224km/h
  - (2026-08-28) SAMU44 (France)
      icao24: 39ca84 · position: (47.2122, -1.5329) · alt: 144m · 141km/h
  - (2026-08-28) PAT314 (United States)
      icao24: adfdd1 · position: (38.8679, -83.4108) · alt: 7620m · 532km/h

### U.S. Federal Action — 25 new of 25 total
  - (2026-08-28) Streamlining Export Controls for Drone Exports
  - (2026-08-28) Honoring the Memory of Dolly Parton
  - (2026-08-28) Special Conditions: Skyryse, Robinson Helicopter Company Model R66 Helicopter; Control Margin Awareness
      This action proposes special conditions for the Robinson Helicopter Company (Robinson) Model R66 helicopter. This helicopter, as modified by Skyryse, will have a novel or unusual design feature when compared to the state…
  - (2026-08-28) International Traffic in Arms Regulations: Modification of Civil Aircraft To Incorporate Aircraft Survivability Equipment
      The Department of State (the Department) amends the International Traffic in Arms Regulations (ITAR) to remove from the U.S. Munitions List (USML) certain aircraft that have been modified to incorporate aircraft survivab…
  - (2026-08-28) Passports: Expanding Online Passport Renewal Overseas
      The Department proposes to amend 22 CFR 51.21 by consolidating requirements for persons applying by mail and online in the United States and overseas. This proposed change includes expanding online passport application a…
  - (2026-08-28) Requests for Arbitration Panels
      The Federal Mediation and Conciliation Service (FMCS) is issuing an interim final rule with requests for comments to amend its arbitration services regulations. The interim final rule clarifies the circumstances in which…

### Government Action: Sanctions + Procurement + Foreign Agents — 25 new of 113 total
  - (2026-08-28) [OFAC] Iran-related and Counter Terrorism Designations - Office of Foreign Assets Control (.gov)
      Iran-related and Counter Terrorism Designations Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] Issuance of Amended Venezuela-related General Licenses and Associated Frequently Asked Questions - Office of Foreign Assets Control (.gov)
      Issuance of Amended Venezuela-related General Licenses and Associated Frequently Asked Questions Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] Frequently Asked Questions - Newly Added - Office of Foreign Assets Control (.gov)
      Frequently Asked Questions - Newly Added Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 50C Authorizing Transactio - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 50C Authorizing Transactio Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 52B Authorizing Certain Tr - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 52B Authorizing Certain Tr Office of Foreign Assets Control (.gov)
  - (2026-08-27) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54B Authorizing the Supply - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR part 591 GENERAL LICENSE NO. 54B Authorizing the Supply Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 15 new of 124 total
  - (2026-08-28) [Polymarket] Will Min Woo Lee win the 2026 TOUR Championship?
      This market will resolve according to the listed player who wins the 2026 TOUR Championship tournament. If a listed player withdraws, is disqualified, does not participate or is eliminated from contention for the 2026 TO…
  - (2026-08-28) [Manifold] Will @jim publish an article on his AI timelines by end-of-month?
  - (2026-08-28) [Manifold] Will the WTI Crude Oil Spot Price be above $83 on September 10, 2026?
  - (2026-08-28) [Manifold] Do you like 82% odds?
  - (2026-08-28) [Manifold] Will 0x53a125F03c90B8E07BA50356B312F4b7b9bA47A7 REACH more than 210.30 USDC on Base by the end of August
  - (2026-08-28) [Manifold] Will China intervene and offer Iran nuclear power plants, ending the war, in 2026?

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-08-28) Will Real Racing Club win on 2026-08-28?
      yes price: 100% · 24h volume: $2,484,113 · resolves 2026-08-28
  - (2026-08-28) Will Manchester City FC win on 2026-08-28?
      yes price: 57% · 24h volume: $2,468,630 · resolves 2026-08-28
  - (2026-08-28) Will the Fed increase interest rates by 50+ bps after the September 2026 meeting?
      yes price: 0% · 24h volume: $1,071,797 · resolves 2026-09-16
  - (2026-08-28) Will FC Bayern München win on 2026-08-28?
      yes price: 88% · 24h volume: $992,007 · resolves 2026-08-28
  - (2026-08-28) LoL: Team Vitality vs Fnatic (BO3) - LEC Regular Season
      yes price: 100% · 24h volume: $814,106 · resolves 2026-08-28
  - (2026-08-28) LoL: Team Vitality vs Fnatic - Game 2 Winner
      yes price: 100% · 24h volume: $622,893 · resolves 2026-08-28

### USGS earthquakes (M4.5+, past day) — 14 new of 14 total
  - (2026-08-27) M 6.0 - 145 km N of Caluula, Somalia
      M6.0 · 145 km N of Caluula, Somalia · depth 10 km
  - (2026-08-28) M 5.2 - southeast Indian Ridge
      M5.2 · southeast Indian Ridge · depth 10 km
  - (2026-08-28) M 5.0 - 172 km SE of Petropavlovsk-Kamchatsky, Russia
      M5.0 · 172 km SE of Petropavlovsk-Kamchatsky, Russia · depth 10 km
  - (2026-08-28) M 5.0 - 109 km WNW of Isangel, Vanuatu
      M5.0 · 109 km WNW of Isangel, Vanuatu · depth 10 km
  - (2026-08-28) M 5.0 - 19 km NW of Fuji, China
      M5.0 · 19 km NW of Fuji, China · depth 10 km
  - (2026-08-28) M 5.0 - northern East Pacific Rise
      M5.0 · northern East Pacific Rise · depth 10 km

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 5 new of 40 total
  - (2026-08-28) #30 Zhong Shanshan — $63.67B
      China · Food & Beverage · source: Beverages, pharmaceuticals · holdings: 603392-CN(SHANGHAI), 9633-HK(HONG KONG)
  - (2026-08-28) MOVER ▲ Larry Page — $283.32B (+$4.21B since yesterday)
      United States · Technology · source: Google
  - (2026-08-28) MOVER ▲ Sergey Brin — $261.35B (+$3.87B since yesterday)
      United States · Technology · source: Google
  - (2026-08-28) MOVER ▲ Bernard Arnault & family — $143.32B (+$3.13B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-08-28) MOVER ▼ Germán Larrea Mota Velasco & family — $70.85B ($-1.33B since yesterday)
      Mexico · Metals & Mining · source: Mining

### Campaign finance (FEC: top fundraisers + recent filings) — 4 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M
  - () [F7] CALIFORNIA TEACHERS ASSOCIATION
      cycle 2016 · filing #1081800
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-08-28) [Marginal Revolution] Tysons Corner (Alaska) fact of the day
      The centerpiece is Tysons Corner Center, today the eighth largest mall in the country, and one of the largest sub-city-sized markets for office space. It is half-owned by the Alaska Permanent Fund, which is the state-own…
  - (2026-08-28) [Marginal Revolution] Friday assorted links
      1. “With homicides up 50% since 2020—putting the country’s murder rate on par with Mexico’s—Costa Rican President Laura Fernández and her ruling party are blaming the independent judiciary.” (WSJ) 2. The Monterrey spirit…
  - (2026-08-28) [Marginal Revolution] A Big Bet on Explosive AI-Driven Growth
      Wow! The excellent Ben Moll has put together a high-stakes bet on US economic growth. A bet on near-term explosive AI-driven growth: whether U.S. real GDP per capita will grow by at least 15% within a single year (measur…
  - (2026-08-28) [Conversable Economist] GAO: One More Warning on US Federal Debt
      The Government Accountability Office (GAO) offers a blunt title for its most recent review of US fiscal policy: “The Nation’s Fiscal Health — Urgent and Sustained Action Needed to Improve the Fiscal Outlook (June 2026).…

### WHO Disease Outbreak News — 1 new of 40 total
  - (2026-08-28) Ebola disease caused by Bundibugyo virus - Democratic Republic of the Congo
      Since the last Disease Outbreak News was published on 14 August 2026, the outbreak has spread from 54 to 60 health zones. The number of affected provinces stands at six out of 26 provinces of the country: Bas-Uélé, Haut-…

### EPSS — highest exploit-probability CVEs — 1 new of 40 total
  - (2026-08-28) CVE-2025-53770: 100% exploit probability (p100.0)
      EPSS 1.000 · percentile 1.000

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-08-28) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=19, 14d-median=20; carrying terms: proposes, navigable, proposed, action, certain, management, establishing, establish, public, national, within, coast
- state_bills: today=107, 7d-median=107, 14d-median=124; carrying terms: issue, division, corporation, adopt, grant, practice, provided, request, state, prescribed, certain, licensure
- state_news: today=795, 7d-median=597, 14d-median=591; carrying terms: issue, oregon, second, license, centers, police, reported, narrow, request, talking, state, return
- local_news: today=260, 7d-median=254, 14d-median=236; carrying terms: police, reported, murder, state, flock, woman, google, family, cases, atlanta, morning, center
- foreign_news: today=1060, 7d-median=1023, 14d-median=1004; carrying terms: issue, crisis, recognizing, operation, strategy, nigeria, vollansky, powerful, fatal, worldwide, engines, formalism
- chinese_internal: today=313, 7d-median=284, 14d-median=282; carrying terms: lxtfa, cbmiykfvx, google, cbmickfvx, chinese, cbmiaefvx, cbmix, china, cbmib, market, cbmiw, politics
- russian_internal: today=1261, 7d-median=1030, 14d-median=1035; carrying terms: httperror, europe, novaya, telegraph, target, wildberries, client, journal, politico, russian, times, found
- ukrainian_internal: today=127, 7d-median=115, 14d-median=110; carrying terms: killed, nearly, injures, kremlin, putin, overnight, reported, civilian, hromadske, according, attack, systems
- ukraine_theater: today=432, 7d-median=841, 14d-median=884; carrying terms: vnzequlxafdjtms, byrkf, wkrxnjzud, mxbnlvhwem, rujpwthxdthzri, repairs, pluvovf, vfbmz, judkdnz, qqmxjbuvetfrec, cnbfufllb, kwwuxj
- paper_bets: today=124, 7d-median=131, 14d-median=134; carrying terms: decrease, party, mamdani, control, florida, supreme, chuck, arizona, inflation, speed, mbappe, supervolcano
- weather: today=126, 7d-median=143, 14d-median=148; carrying terms: indiana, likely, outlook, inland, following, creek, advisory, oregon, weekend, memphis, southwest, moisture
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: energy, nonfarm, pcepilfe, assets, jtsjol, cpiaucsl, money, payems, dcoilwtico, unrate, inflation, crude
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: agriculture, credit, range, large, corporate, bitcoin, nasdaq, natural, futures, yield, china, crude
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=113, 7d-median=102, 14d-median=98; carrying terms: integrated, recognition, aeronautics, abuses, syria, usaspending, taliban, corporation, transnistria, operation, btdyc, situation
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: quantitative, client, unauthorized, https, httperror, quiverquant, congresstrading, error, quiver
- billionaires: today=40, 7d-median=30, 14d-median=34; carrying terms: spacex, jensen, metals, alice, spain, finance, family, trading, warren, walton, peterffy, bettencourt
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, state, court, appeals, america, california, connecticut, center, brown, delaware, international, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, reporting, issuer, filed, holdings, capital, david, financial, richard, group, trust
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: angels, booker, filing, ocasio, receipts, shawn, david, alexandria, ossoff, graham, sherrod, robert
- gdelt_regions: today=0, 7d-median=12, 14d-median=12; carrying terms: english, japan, defense, china
- gdelt_gkg: today=0, 7d-median=25, 14d-median=41; carrying terms: english, trump, keywords, russian, themes, ukrainian, spanish, perimeter, sanctions, russia, chinese, china
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, france, position, kingdom, bulgaria, aabfa
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: regional, formula, arachidonic, senegal, alert, remained, healthcare, increases, hemorrhagic, however, bengal, virology
- cisa_kev: today=20, 7d-median=12, 14d-median=12; carrying terms: injection, product, command, microsoft, vendor, authentication, vulnerability, remediation, function, missing, project, extensions
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=0, 7d-median=0, 14d-median=0
- usgs_quakes: today=14, 7d-median=14, 14d-median=18; carrying terms: depth, indonesia, japan, russia, tonga, vanuatu, ridge, papua, guinea, chile, northern
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: shakhtar, price, resolves, championship, meeting, champions, interest, donetsk, august, september, volume, rates
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: marginal, economist, class, https, revolution, conversable, links, assorted, demand, marginalrevolution, number, future
- tech_news: today=56, 7d-median=55, 14d-median=56; carrying terms: hacker, patch, hackers, computer, spectrum, companies, review, openai, according, schneier, report, going
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: jared, credit, jason, bacon, gallego, rashida, wiles, smucker, mullin, chicago, senator, peters
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, placement, placed, today, identify, claude, market, unavailable, either, module, markets, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-08-17] ECB press: Philip R. Lane: The rise in defence spending and the euro area economy
- [2026-08-19] ECB press: Christine Lagarde: Panel remarks about the European economy during a discussion on the global economic outlook at the World Economic Forum
- [2026-08-19] Fed press (events + announcements): Minutes of the Federal Open Market Committee, July 28–29, 2026
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement actions with former employee of Regions Bank and former employee of United Community Bank
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board issues enforcement action with SouthPoint Bancshares, Inc. and announces termination of enforcement action with Deutsche Bank AG, DB USA Corporation, and Deutsche Bank AG New York Branch
- [2026-08-20] Fed press (events + announcements): Federal Reserve Board announces approval of application by National Westminster Bank Plc
- [2026-08-21] ECB press: ECB Consumer Expectations Survey results – July 2026
- [2026-08-24] ECB press: Piero Cipollone: Interview with ilsussidiario.net
- [2026-08-25] Fed press (events + announcements): Minutes of the Board's discount rate meetings on July 20 and July 29, 2026
- [2026-08-26] ECB press: Piero Cipollone: From vision to delivery: building Europe’s tokenised financial market
- [2026-08-27] ECB press: Meeting of 22-23 July 2026
- [2026-08-27] Fed press (events + announcements): Federal Reserve Board issues enforcement action with former employee of Banco Popular de Puerto Rico
- [2026-08-28] Fed speeches: Warsh, In Our Time
- [2026-08-28] ECB press: Isabel Schnabel: Central banks on-chain

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*