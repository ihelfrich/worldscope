# WORLDSCOPE morning brief — 2026-07-06

## Headline
3840 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (862) · Russian Internal News (state + in-exile) (792) · Ukraine Theater (total-war monitoring) (441) · World leaders & government officials (324) · Chinese Internal News (235) · State-Level News (210) · Local News: St. Louis + Atlanta (188) · GDACS — global disaster alerts (154) · U.S. Weather + Severe / Climate Outlooks (129) · Ukrainian Internal News (national + local Kyiv) (102) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (57)

## What changed today
### International News + Multilateral Institutions — 862 new of 1004 total
  - (2026-07-06) [Global] ITV sells media and entertainment arm to Sky for £1.6bn
      The two broadcasters say the deal will create a strong rival to global streaming giants.
  - (2026-07-05) [Global] Three things you can do to stop EU border checks at the airport costing you
      Queues are expected at airports this summer owing to EU's new digital border control system.
  - (2026-07-06) [Global] Wegovy weight loss pill now available in UK - here's what you need to know
      The once-a-day pill, from the makers of the Wegovy weight-loss jab, can now be bought privately in UK pharmacies.
  - (2026-07-06) [Global] Backlash after China bubble tea firm ordered to pay Louis Vuitton $1.5m
      A court in China ruled that Molly Tea had infringed on the luxury brand's four-petal flower design.
  - (2026-07-06) [Global] EasyJet agrees 'in principle' to £5.2bn takeover deal
      The low-cost airline had previously rejected four takeover offers from US investment firm Castlelake.
  - (2026-07-06) [Global] What Sky buying ITV could mean for your favourite shows
      Sky is set to buy ITV's TV and streaming channels for up to £1.6bn, the companies announced on Monday.

### Russian Internal News (state + in-exile) — 792 new of 795 total
  - (2026-07-06) В Мали повстанцы сбили вертолет «Африканского корпуса» Минобороны РФ | LEDE: Повстанцы-туареги в Мали заявили, что сбили вертолет «Африканского корпуса» Минобороны РФ, сообщает «Аль-Джазира»] (ru: В М…
      Повстанцы-туареги в Мали заявили, что сбили вертолет «Африканского корпуса» Минобороны РФ, сообщает «Аль-Джазира».
  - (2026-07-06) ФАС завела дело на шестерых операторов заправок в Москве и Подмосковье из-за одновременного повышения цен на топливо | LEDE: Федеральная антимонопольная служба (ФАС) возбудила административн] (ru: ФАС…
      Федеральная антимонопольная служба (ФАС) возбудила административное дело в отношении шестерых операторов автомобильных заправок, которые работают в Москве и Подмосковье. Ведомство пришло к выводу, что они одновременно по…
  - (2026-07-06) Война . 1594-й день. Россия опять ударила по Киеву. Ракеты и дроны попали в жилые дома, более 10 погибших и десятки раненых. Под Петербургом поврежден порт. В Крыму отключения света | LEDE: ] (ru: Вой…
      «Медуза» с 24 февраля 2022 года в прямом эфире рассказывает о российско-украинской войне. Мы ежедневно публикуем ваши письма, потому что уверены: о войне нужно продолжать говорить. Поделитесь с нами мыслями о войне. Каки…
  - (2026-07-06) В Иркутской области водитель пытался заправиться вне очереди. Остановить его смог только полицейский, достав оружие | LEDE: Полицейский был вынужден вмешаться в конфликт в очереди на заправк] (ru: В И…
      Полицейский был вынужден вмешаться в конфликт в очереди на заправку в Иркутской области и доставать оружие. В соцсетях, пишут «Люди Байкала», разошлось видео, снятое на АЗС в поселке Усть-Ордынский Иркутской области.
  - (2026-07-06) Россия второй раз за неделю нанесла удар по Киеву. Более 10 человек погибли, десятки ранены. Фотографии последствий атаки | LEDE: Российские войска в ночь на 6 июля нанесли удар по Киеву бал] (ru: Рос…
      Российские войска в ночь на 6 июля нанесли удар по Киеву баллистическими ракетами и дронами. Всего, по данным командования Воздушных сил ВСУ, по территории Украины было выпущено 68 ракет разных типов и более 350 беспилот…
  - (2026-07-06) Госдума собирается добавить в перечень оснований для депортации мигрантов неповиновение пограничникам и дискриминацию | LEDE: Госдума собирается расширить перечень оснований для выдворения и] (ru: Гос…
      Госдума собирается расширить перечень оснований для выдворения из России мигрантов, объявил спикер нижней палаты парламента Вячеслав Володин.

### Ukraine Theater (total-war monitoring) — 441 new of 497 total
  - (2026-07-06) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-05) [FIRMS] thermal anomaly 51.413, 34.536 (FRP 2.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 2.8 MW
  - (2026-07-05) [FIRMS] thermal anomaly 51.410, 34.538 (FRP 3.22 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 3.22 MW
  - (2026-07-05) [FIRMS] thermal anomaly 51.376, 24.877 (FRP 1.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 1.72 MW
  - (2026-07-05) [FIRMS] thermal anomaly 49.922, 24.065 (FRP 3.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 3.18 MW
  - (2026-07-05) [FIRMS] thermal anomaly 49.920, 24.071 (FRP 0.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 0.71 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 235 new of 235 total
  - (2026-07-04) Caixin Global – Latest China News & Headlines - Caixin Global
      Caixin Global – Latest China News & Headlines Caixin Global
  - (2026-07-04) 责编：金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxNTEJuZ0lEb2xuU0FhVlp5RElvT284dGhBY0M5eEdtWk1rUHUwaWZqYkwtZDZXTUkxd1BRS1VFbTF2UFlKTDBHb3lqa] (zh:…
      责编：金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-07-05) 矢志追求真理，始终把准前进方向（评论员观察） - 人民网观点 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTFBYaFpqY2VaMktsMU16ZTJ4T2ZWaFh0SmFNd2pLTHNiVUhHcG9rZDRiUmxRT3lhcjdaSW94cnRVdEU0Wi1oX2dMRHJkOEt5] (zh:…
      矢志追求真理，始终把准前进方向（评论员观察） 人民网观点
  - (2026-07-06) 公交站点设在绿化带里（身边事） - 人民网“领导留言板” | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5JR2JjM2E2VlFmUXhTTTQ4cVoyWkFnWjh5Qk1NamhCLWRhcHpURXp2QzhsekZRTFhETnBneHZzS1FMdWpZMU5md1ZNcjNpaj] (zh:…
      公交站点设在绿化带里（身边事） 人民网“领导留言板”
  - (2026-07-06) 人民网“人民投诉”发布6月消费维权数据报告 - 人民网健康 | LEDE: <a href="https://news.google.com/rss/articles/CBMibkFVX3lxTE9FbFlsbUQ2NTZNQnZhcy1wUXRBbmk0Y0EwRVV1akVnT2RZS3JGSDJ3d0FlNDZyQ0d0c0loSGJka1RlUFBIMFEtTm5sZUN0O] (zh:…
      人民网“人民投诉”发布6月消费维权数据报告 人民网健康
  - (2026-07-06) “草书第一神品”来了！赵佶《草书千字文》数字笔墨上线 - 灵境·人民艺术馆 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1ZdUo3a1VRRGgwQmxTV0NXNmwwNEJIUUFlU1NveWRvMDBKNXVMSmZDNWJldlZCNU5ETmxrdkpMUnRKbnVZY282Z] (zh:…
      “草书第一神品”来了！赵佶《草书千字文》数字笔墨上线 灵境·人民艺术馆

### State-Level News — 210 new of 223 total
  - (2026-07-04) [California] Estos estudiantes universitarios de Los Ángeles usan el transporte público para ahorrar dinero. Así son sus viajes.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/042826-Student-Transit-MR-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-07-04) [California] Governor Newsom announces deployment of California firefighters and equipment to Colorado, as sister state battles wildfires
      Source
  - (2026-07-04) [California] Gobernador Gavin Newsom conmemora el Día de la Independencia con una llamada a renovar la lucha por defender la democracia
      Source
  - (2026-07-04) [California] Governor Gavin Newsom marks Fourth of July with a call for a renewed fight to defend democracy
      Source
  - (2026-07-05) [Arkansas] Don’t fight Arkansas school vouchers by governing like Trump
      Fred Love isn’t the first elected official promising to use his executive power to circumvent the legislative process. The Democratic state senator is running for governor in Arkansas, where voters have three times backe…
  - (2026-07-05) [Arkansas] Chief Tom Schultz details, defends largest Forest Service reorganization in a century
      This story was first published by WyoFile on July 2, 2026. PARK CITY, UTAH — The U.S. Forest Service received roughly 300 applications for the 15 new state director jobs created during a major agency reorganization that’…

### Local News: St. Louis + Atlanta — 188 new of 189 total
  - (2026-07-06) [St. Louis] Lou’s Clues – 7/6/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-07-06) [St. Louis] 41 minors detained on Fourth of July as St. Louis enforces new downtown curfew
      More than 40 minors were detained as St. Louis police enforced the city's new downtown curfew during the Fourth of July weekend.
  - (2026-07-06) [St. Louis] Bridgeton plans September fireworks show after flooding
      An overflowing pond flooded Bridgeton's fireworks launch site, leaving the city to assess damaged fireworks and plan a September show.
  - (2026-07-06) [St. Louis] England defeats Mexico to head into World Cup quarterfinals
      The Brits will verse Norway on July 11 in Florida.
  - (2026-07-06) [St. Louis] Who has moved on in the World Cup? See the quarterfinal bracket
      Only a handful of teams remain in the 2026 World Cup after the first knockout round of 32.
  - (2026-07-06) [St. Louis] 'God told me to come': Bystander saves 2-year-old with CPR after near-drowning in Michigan
      A 2-year-old girl was pulled from the water unconscious and not breathing. That's when Mariza Mojica stepped in.

### GDACS — global disaster alerts — 154 new of 166 total
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)

### U.S. Weather + Severe / Climate Outlooks — 129 new of 131 total
  - (2026-07-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-06) [Severe] Special Marine Warning: Special Marine Warning issued July 6 at 4:25AM CDT until July 6 at 5:15AM CDT by NWS Mobile AL
      SMWMOB The National Weather Service in Mobile has issued a * Special Marine Warning for... Coastal waters from Okaloosa-Walton County Line to Pensacola FL out 20 NM... Eastern Choctawhatchee Bay... Western Choctawhatchee…
  - (2026-07-06) [Moderate] Special Weather Statement: Special Weather Statement issued July 6 at 5:17AM EDT by NWS Wilmington OH
      The combination of a moist airmass and calm winds is resulting in patchy dense fog this morning, especially across rural areas and valleys. Rapidly changing visibilities will be possible through the early morning hours b…
  - (2026-07-06) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 6 at 4:00AM CDT until July 6 at 9:00AM CDT by NWS Paducah KY
      * WHAT...Visibility of 1/4 mile or less in dense fog. * WHERE...A portion of western Kentucky. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-07-06) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 6 at 3:55AM CDT until July 6 at 9:00AM CDT by NWS Memphis TN
      * WHAT...Visibility of 1/4 mile or less in dense fog. * WHERE...Portions of North Mississippi and West Tennessee. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility could make driving conditions hazardous.
  - (2026-07-06) [Moderate] Dense Fog Advisory: Dense Fog Advisory issued July 6 at 3:55AM CDT until July 6 at 9:00AM CDT by NWS Huntsville AL
      * WHAT...Visibility of 1/4 mile or less in dense fog. * WHERE...Portions of north central, northeast, and northwest Alabama and southern middle Tennessee. * WHEN...Until 9 AM CDT this morning. * IMPACTS...Low visibility…

### Ukrainian Internal News (national + local Kyiv) — 102 new of 110 total
  - (2026-07-06) Сікорський відреагував на слова Пєскова, що потенційна провокація проти Польщі – "західна пропаганда" | LEDE: Польський міністр закордонних справ Радослав Сікорський відкинув заяви речника Крем] (uk:…
      Польський міністр закордонних справ Радослав Сікорський відкинув заяви речника Кремля Дмитра Пєскова про те, що попередження про можливість російських провокацій у Польщі є "західною пропагандою" та "залякуванням".
  - (2026-07-06) Намагалися продати вантажівку зброї: затримано трьох військових | LEDE: Працівники Державного бюро розслідувань повідомили про підозру трьом військовослужбовцям, які, за даними слідства, намага] (uk:…
      Працівники Державного бюро розслідувань повідомили про підозру трьом військовослужбовцям, які, за даними слідства, намагалися продати великий арсенал зброї та вибухівку.
  - (2026-07-06) Федоров переконуватиме партнерів передати Україні ракет до Patriot з їхніх запасів | LEDE: Міністр оборони Михайло Федоров анонсував серію переговорів із колегами з країн, які мають ракети до P] (uk:…
      Міністр оборони Михайло Федоров анонсував серію переговорів із колегами з країн, які мають ракети до Patriot на своїх складах.
  - (2026-07-06) Лукашенко заявив, що не пошле білоруських військових воювати в Україну, але є одне "але" | LEDE: Самопроголошений президент Білорусі Олександр Лукашенко заявив, що білоруси – мирні люди, не хоч] (uk:…
      Самопроголошений президент Білорусі Олександр Лукашенко заявив, що білоруси – мирні люди, не хочуть воювати, але й перед ворогом голови схиляти не мають наміру.
  - (2026-07-06) Фон дер Ляєн після масованої атаки РФ закликала терміново посилити ППО України | LEDE: Президентка Єврокомісії Урсула фон дер Ляєн після чергової масованої російської атаки заявила, що Україна ] (uk:…
      Президентка Єврокомісії Урсула фон дер Ляєн після чергової масованої російської атаки заявила, що Україна потребує додаткових систем ППО, і це питання розглянуть на саміті НАТО, який у вівторок стартує в Анкарі.
  - (2026-07-06) Санчес переконуватиме Трампа, що Іспанія достатньо витрачає на оборону | LEDE: Прем’єр-міністр Іспанії Педро Санчес під час саміту НАТО в Анкарі відстоюватиме свою позицію щодо видатків на обор] (uk:…
      Прем’єр-міністр Іспанії Педро Санчес під час саміту НАТО в Анкарі відстоюватиме свою позицію щодо видатків на оборону, які, на його думку, є достатніми для виконання зобов’язань перед Альянсом.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-02) D.C. Court of Appeals: D.W. v. United States (en banc)
  - (2026-07-02) D.C. Court of Appeals: In re Tucker, Jr.
  - (2026-07-02) D.C. Court of Appeals: Perry v. United States
  - (2026-07-02) Alaska Supreme Court: Viva G. v. Department of Family and Community Services, Office of Children's Services
  - (2026-07-02) U.S. Court of Appeals, 9th Cir.: Rinnai America Corporation v. South Coast Air Quality Management District
  - (2026-07-02) U.S. Court of Appeals, 9th Cir.: United States v. Shi

### IT, InfoSys & cybersecurity news (last 7 days) — 57 new of 57 total
  - (2026-07-06) [The Hacker News] New TrojPix Attack Leaks Data From Air-Gapped Systems via Video Cable Emissions
      Researchers at Shandong University have shown a fast new way to pull data off computers that are cut off from every network. The technique, called TrojPix, tweaks on-screen pixels in ways the eye cannot see, so that the…
  - (2026-07-06) [The Hacker News] New Java-Based QuimaRAT MaaS Built to Run on Windows, Linux, and macOS
      Cybersecurity researchers have flagged a novel Java-based remote access trojan (RAT) called QuimaRAT that's capable of targeting Windows, Linux, and macOS environments. According to LevelBlue, the cross-platform malware…
  - (2026-07-06) [The Hacker News] Opera GX Flaw Let Malicious Sites Auto-Install Mods to Steal Data From Visited Pages
      Researchers found a flaw in Opera GX, the gaming-focused version of the Opera browser, that let a malicious website silently install a browser add-on and use it to lift specific data from the pages a victim visits. In a…
  - (2026-07-06) [The Hacker News] SkillCloak Lets Malicious AI Agent Skills Evade Static Scanners with Self-Extracting Packing
      Scanners meant to catch malicious add-on "skills" for AI coding agents can be fooled by a few simple changes that leave the malware working, according to a new study from researchers at the Hong Kong University of Scienc…
  - (2026-07-06) [Cybersecurity Dive] The security leaders defining the next decade aren’t in CISO seats yet
      The first recognition program for the security leaders who will define the future of cybersecurity.
  - (2026-07-06) [The Register] Secure Unix ancestor KSOS did type safety before Rust made it cool
      Modula-based source code resurfaces after nearly four decades

### GDELT GKG — themes / entities / watch areas — 51 new of 51 total
  - (2026-07-06) [Russia oil sanctions perimeter · keywords] Drone debris damages Russia Ust - Luga , Vysotsk ports , other regions report attacks
      whbl.com · English · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · keywords] Drone debris damages Russia Ust - Luga , Vysotsk ports , other regions report attacks
      straitstimes.com · English · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · keywords] Alyona joined the line for petrol at 11pm . She didnt get served until 5pm the next day
      brisbanetimes.com.au · English · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · keywords] BPCL prepares for return of Iranian crude , starts supplier talks
      moneycontrol.com · English · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · keywords] Minister calls on Burnham to show path to 3 . 5 % target on united kingdom defence spending
      theguardian.com · English · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · keywords] Iran To Grant China , Friendly Countries Special Consideration On Hormuz Fees
      zerohedge.com · English · tone NA

### Government Action: Sanctions + Procurement + Foreign Agents — 46 new of 108 total
  - (2026-07-01) [OFAC] Counter Narcotics Designations; Counter Terrorism Designations and Designation Update - Office of Foreign Assets Control (.gov)
      Counter Narcotics Designations; Counter Terrorism Designations and Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-01) [OFAC] Reminder to File the 2026 Annual Report of Blocked Property - Office of Foreign Assets Control (.gov)
      Reminder to File the 2026 Annual Report of Blocked Property Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act…
      Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) Office of Foreign A…
  - (2026-06-29) [OFAC] Launch of OFAC Reconsideration Portal - Office of Foreign Assets Control (.gov)
      Launch of OFAC Reconsideration Portal Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Mexican Cartel Fuel Smuggling Schemes - Office of Foreign Assets Control (.gov)
      Mexican Cartel Fuel Smuggling Schemes Office of Foreign Assets Control (.gov)
  - (2026-06-29) [OFAC] 1261 - Office of Foreign Assets Control (.gov)
      1261 Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 40 new of 141 total
  - (2026-07-06) [Polymarket] Will the Green Bay Packers win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-06) [Polymarket] Will James Talarico win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-06) [Polymarket] Will Austin Reaves play for the Cleveland Cavaliers in 2026-27?
      This market will resolve to the next team Austin Reaves officially joins by October 31, 2026, 11:59 PM ET. If Austin Reaves does not officially join a new team by October 31, 2026, 11:59 PM ET, this market will resolve t…
  - (2026-07-06) [Polymarket] Will Elon Musk post 40-64 tweets from July 4 to July 6, 2026?
      This market will resolve according to the number of times Elon Musk (@elonmusk), posts on X from July 4 12:00 PM ET to July 6, 2026 12:00 PM ET. For the purposes of this market, only main feed posts, quote posts and repo…
  - (2026-07-06) [Polymarket] Will Bitcoin reach $120,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "High" price equal to or gr…
  - (2026-07-06) [Polymarket] Opensea FDV above $100M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Opensea's token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token must be activ…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-03) [Richard Christian M] Form 4 (Reporting)
      filed 2026-07-03 01:59 UTC · role: Reporting — Filed: 2026-07-02 AccNo: 0001104659-26-080497 Size: 6 KB
  - (2026-07-03) [CYPHERPUNK TECHNOLOGIES INC.] Form 4 (Issuer)
      filed 2026-07-03 01:59 UTC · role: Issuer — Filed: 2026-07-02 AccNo: 0001104659-26-080497 Size: 6 KB
  - (2026-07-03) [Oei Khing Djien] Form 4 (Reporting)
      filed 2026-07-03 01:58 UTC · role: Reporting — Filed: 2026-07-02 AccNo: 0001104659-26-080496 Size: 6 KB
  - (2026-07-03) [CYPHERPUNK TECHNOLOGIES INC.] Form 4 (Issuer)
      filed 2026-07-03 01:58 UTC · role: Issuer — Filed: 2026-07-02 AccNo: 0001104659-26-080496 Size: 6 KB
  - (2026-07-03) [Corvex, Inc.] Form 4 (Issuer)
      filed 2026-07-03 01:58 UTC · role: Issuer — Filed: 2026-07-02 AccNo: 0001193125-26-295228 Size: 10 KB
  - (2026-07-03) [FAIRBAIRN EMILY] Form 4 (Reporting)
      filed 2026-07-03 01:58 UTC · role: Reporting — Filed: 2026-07-02 AccNo: 0001193125-26-295228 Size: 10 KB

### U.S. Federal Action — 30 new of 30 total
  - (2026-07-06) Improvements to Rules on Recoupment of Benefit Overpayments
      The Pension Benefit Guaranty Corporation (PBGC) is proposing to improve its rules on recoupment of benefit overpayments under PBGC's insurance program for single-employer terminated plans trusteed by PBGC. These proposed…
  - (2026-07-06) Rescission of Guidelines on Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964, as Amended
      The Equal Employment Opportunity Commission ("EEOC" or "Commission") is rescinding its regulations regarding Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964 ("Guidelines"), and removing it…
  - (2026-07-06) Presidential Determination on Assistance to Venezuela Consistent With the Trafficking Victims Protection Act of 2000
  - (2026-07-06) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Angling Category Southern New England Area Trophy Fishery for 2026
      NMFS closes the Angling category Southern New England area fishery for large medium and giant ("trophy" (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length or greater)) Atlantic bluefin tuna (BFT). This…
  - (2026-07-06) Nondiscrimination in Federally Assisted Programs of NASA-Effectuation of Title VI of the Civil Rights Act of 1964
      NASA is amending its regulation implementing Title VI of the Civil Rights Act of 1964 (Title VI) for federally assisted programs to conform more closely to the statutory text and recent revisions by the Department of Jus…
  - (2026-07-06) Amendment of Using Agency and Controlling Agency for Restricted Areas R-5301, R-5302A, R-5302B, and R-5302C; NC
      This action amends the using agency and controlling agency descriptions listed for restricted areas R-5301, R-5302A, R-5302B, and R-5302C, NC. This action does not change any boundaries, altitudes, times of designation,…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-07-06) Will Norway win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $11,020,580 · resolves 2026-07-20
  - (2026-07-06) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $5,116,007 · resolves 2026-07-20
  - (2026-07-06) Will England win the 2026 FIFA World Cup?
      yes price: 14% · 24h volume: $4,874,495 · resolves 2026-07-20
  - (2026-07-06) Will USA win the 2026 FIFA World Cup?
      yes price: 3% · 24h volume: $4,818,760 · resolves 2026-07-20
  - (2026-07-06) Will Portugal win the 2026 FIFA World Cup?
      yes price: 6% · 24h volume: $3,494,508 · resolves 2026-07-20
  - (2026-07-06) Will Belgium win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $3,185,582 · resolves 2026-07-20

### USGS earthquakes (M4.5+, past day) — 12 new of 12 total
  - (2026-07-06) M 5.8 - 48 km SSW of Sarangani, Philippines
      M5.8 · 48 km SSW of Sarangani, Philippines · depth 35 km
  - (2026-07-05) M 5.8 - 274 km SE of Levuka, Fiji
      M5.8 · 274 km SE of Levuka, Fiji · depth 685.692 km
  - (2026-07-06) M 5.4 - 65 km SSW of Sarangani, Philippines
      M5.4 · 65 km SSW of Sarangani, Philippines · depth 35 km
  - (2026-07-05) M 5.0 - 106 km NW of Coquimbo, Chile
      M5.0 · 106 km NW of Coquimbo, Chile · depth 10 km
  - (2026-07-05) M 5.0 - 26 km NNW of Mianzhu, Deyang, Sichuan, China
      M5.0 · 26 km NNW of Mianzhu, Deyang, Sichuan, China · depth 10 km
  - (2026-07-05) M 5.0 - 23 km NNW of Mianzhu, Deyang, Sichuan, China
      M5.0 · 23 km NNW of Mianzhu, Deyang, Sichuan, China · depth 10 km

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-06) [Marginal Revolution] The Troubled History of Government Equity in Technology
      Even though Germany privatized Deutsche Telekom in 1996, the federal government retained a substantial ownership stake. This partial state ownership status, which remains to this day, presents a textbook example of how t…
  - (2026-07-06) [Marginal Revolution] The history of heat deaths in Europe (from my email)
      I will not double indent, all of what follows is from economic historian Daniel Gallardo Albarrán of the Netherlands: “…you posted a link to an article on how Europe became the world champion of heat deaths. Something th…
  - (2026-07-05) [Marginal Revolution] *What Makes a Great Composer?: A Data-Driven Exploration of Music History*
      A very good book, forthcoming, by Karol J. Borowiecki and Marc Lawx, here is the Amazon link, here is the Princeton University Press page. The post *What Makes a Great Composer?: A Data-Driven Exploration of Music Histor…
  - (2026-07-04) [Conversable Economist] Declaration of Independence: Track Changes Version
      Thomas Jefferson wrote out the first draft of the Declaration of Independence, but he did not do so alone and without guidance. After all, he had been a member of the Continental Congress that summer, listening to the di…
  - (2026-07-03) [Conversable Economist] What Does the Declaration Mean by Pursuit of Happiness?
      I wrote this short essay about the “pursuit of happiness” for the editorial page of the StarTribune newspaper, where it was published on July 3. _____ Opinion | What did the founders mean by the pursuit of happiness? The…
  - (2026-07-02) [Conversable Economist] US Exports, Imports, and Tariffs: The 250-Year Perspective
      Douglas A. Irwin offers a brisk overview of a great American tradition–specifically, “America’s been arguing over trade for more than 250 years” (Peterson Institute for International Economics, July 1, 2026). I won’t reh…

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 8 total
  - (2026-07-01) CVE-2026-45659 · Microsoft SharePoint Server: Microsoft SharePoint Server Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint Server · CISA remediation by 2026-07-04
  - (2026-06-29) CVE-2026-48558 · SimpleHelp SimpleHelp: SimpleHelp Authentication Bypass Vulnerability
      vendor: SimpleHelp · product: SimpleHelp · CISA remediation by 2026-07-02
  - (2026-06-25) CVE-2026-12569 · PTC Windchill and FlexPLM: PTC Windchill and FlexPLM Improper Input Validation Vulnerability
      vendor: PTC · product: Windchill and FlexPLM · CISA remediation by 2026-06-28
  - (2026-06-25) CVE-2026-20230 · Cisco Unified Communications Manager: Cisco Unified Communications Manager Server-Side Request Forgery (SSRF) Vulnerability
      vendor: Cisco · product: Unified Communications Manager · CISA remediation by 2026-06-28

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 37 total
  - (2026-07-06) MOVER ▲ Bernard Arnault & family — $153.36B (+$1.85B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-06) MOVER ▲ Mukesh Ambani — $90.18B (+$0.92B since yesterday)
      India · Diversified · source: Diversified
  - (2026-07-06) MOVER ▲ Gautam Adani — $91.01B (+$0.67B since yesterday)
      India · Diversified · source: Infrastructure, commodities

### WHO Disease Outbreak News — 3 new of 40 total
  - (2026-07-03) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with sustained transmission and increasing numbers of reported cases. As of 1 July, a cumulative of 1460 co…
  - (2026-07-02) Hantavirus outbreak linked to cruise ship travel, Multi-locations
      This is the fifth Disease Outbreak News posting on the Andes hantavirus (ANDV) outbreak linked to the cruise ship M/V Hondius. The outbreak identification followed the notification to the World Health Organization (WHO)…
  - (2026-06-25) Nipah virus disease - India
      On 11 June 2026, the Kerala State Health Department confirmed one laboratory confirmed case of Nipah virus (NiV) infection in Kozhikode district, Kerala State, India. The case is an adult male who developed symptoms on 3…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-07-06) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=26, 14d-median=26; carrying terms: being, temporary, associated, administration, navigable, amend, information, river, final, comments, update, unless
- state_bills: today=0, 7d-median=152, 14d-median=152; carrying terms: relating, being, affairs, project, voluntary, highway, every, political, jurisdictions, qualifications, within, names
- state_news: today=223, 7d-median=452, 14d-median=452; carrying terms: being, lines, beloved, project, defender, hearing, political, every, limits, nationwide, detention, trends
- local_news: today=189, 7d-median=221, 14d-median=221; carrying terms: being, reported, project, political, woman, breaks, mother, shows, central, community, season, cbmirwfbvv
- foreign_news: today=1004, 7d-median=1034, 14d-median=1034; carrying terms: warns, shares, project, specializing, bruce, hearing, startup, political, every, escape, monetary, zeitung
- chinese_internal: today=235, 7d-median=281, 14d-median=281; carrying terms: cbmizkfvx, caixin, color, cbmidefvx, cbmixkfvx, global, cbmiyefvx, cbmib, cbmiw, investors, europe, cbmiykfvx
- russian_internal: today=795, 7d-median=915, 14d-median=915; carrying terms: novaya, client, httperror, press, novayagazeta, gazeta, found, associated, europe, truth, telegram, patriot
- ukrainian_internal: today=110, 7d-median=111, 14d-median=111; carrying terms: lines, project, reported, political, woman, meeting, poland, central, gasoline, media, strike, saying
- ukraine_theater: today=497, 7d-median=557, 14d-median=557; carrying terms: sddisg, cuxnumjista, cbmimwfbvv, uvufranrsa, avbicgw, bxbxaydmjddjblwlpkakpses, xfvnnism, trophylab, uthdahlyrulkyulbukrmaupewfhgyth, flash, oddhvvfyrzjzt, incidents
- paper_bets: today=141, 7d-median=139, 14d-median=139; carrying terms: withdraw, another, african, reported, public, anysphere, successor, democratic, lifetime, colorado, ceases, israel
- weather: today=131, 7d-median=173, 14d-median=173; carrying terms: isolated, widespread, reported, highway, scottsdale, boston, union, portions, eastern, lying, atlantic, warning
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: assets, treasury, payems, rates, personal, money, dexjpus, jolts, commodities, cpilfesl, crude, balance
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: equities, corporate, futures, russell, proxy, treasury, agriculture, crypto, china, rates, commodities, close
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=104, 14d-median=104; carrying terms: lebanon, sevastopol, latinscript, integrity, political, union, eastern, funds, cyber, aggression, counter, middle
- congressional_trades: today=1, 7d-median=68, 14d-median=68
- billionaires: today=37, 7d-median=40, 14d-median=40; carrying terms: ballmer, spacex, telecom, madrid, commodities, spain, yiming, retail, googl, facebook, semiconductors, francoise
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, hernandez, supreme, corporation, court, services, alabama, james, association, international, appeals, american
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: trone, cooper, senate, brown, filing, scott, robinson, david, congress, lindsey, elect, graham
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=51, 7d-median=25, 14d-median=25; carrying terms: trump, english, russian, israel, chinese, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=4, 7d-median=28, 14d-median=28; carrying terms: ground, bulgaria, position
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: ministry, illness, rwampara, being, strain, african, kasai, haemorrhage, districts, reported, summarizes, public
- cisa_kev: today=8, 7d-median=9, 14d-median=9; carrying terms: remediation, vendor, control, vulnerability, traversal, access, cisco, authentication, injection, manager, improper, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, exploit, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=166, 7d-median=120, 14d-median=120; carrying terms: speed, congo, orange, wildfire, forest, russia, ukraine, drought, estonia, indonesia, poland, serbia
- usgs_quakes: today=12, 7d-median=14, 14d-median=14; carrying terms: depth, indonesia, philippines
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, argentina, world, volume, resolves, colombia, belgium
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: world, years, conversableeconomist, https, revolution, marginal, economist, conversable, class, state
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: every, called, cyber, mythos, organizations, spyware, version, london, malicious, boxes, bleepingcomputer, hacker
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: vince, pelosi, lloyd, bacon, affairs, haridopolos, bruce, guest, pocan, boozman, katherine, chrissy
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, paper, decision, today, placed, markets, either, converges, consensus, evidence, market, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-22] Fed press (events + announcements): Federal Reserve notes with deep sadness the passing of Alan Greenspan
- [2026-06-22] Fed speeches: Waller, Welcoming Remarks on the International Role of the U.S. Dollar
- [2026-06-24] Fed speeches: Cook, Welcome Remarks
- [2026-06-24] Fed press (events + announcements): Federal Reserve Board's annual bank stress test confirms that large banks are well positioned to weather a severe recession and able to continue to lend to households and businesses
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board issues enforcement action with employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Jiko Group, Inc.
- [2026-06-26] ECB press: ECB Consumer Expectations Survey results – May 2026
- [2026-06-27] ECB press: Isabel Schnabel: Is inflation back?
- [2026-06-29] ECB press: Christine Lagarde: Back to basics in an uncertain environment
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2028
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2027
- [2026-06-30] Fed press (events + announcements): Agencies release list of distressed or underserved nonmetropolitan middle-income geographies
- [2026-07-01] Fed press (events + announcements): Federal Reserve issues initial findings from its 2025 triennial payments study
- [2026-07-02] ECB press: Frank Elderson: The green transition – benefits and barriers
- [2026-07-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Small Business Bank and announces termination enforcement actions with BNP Paribas S.A., BNP Paribas USA, Inc., BNP Paribas Securities Corp., and Community Bankshares, Inc.
- [2026-07-02] ECB press: Piero Cipollone: The digital transformation of money, payments and finance
- [2026-07-02] ECB press: Christine Lagarde: Interview with Les Échos

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*