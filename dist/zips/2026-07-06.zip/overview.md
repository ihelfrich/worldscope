# WORLDSCOPE morning brief — 2026-07-06

## Headline
3795 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (780) · Russian Internal News (state + in-exile) (670) · Ukraine Theater (total-war monitoring) (618) · World leaders & government officials (324) · Chinese Internal News (222) · Local News: St. Louis + Atlanta (183) · State-Level News (172) · GDACS — global disaster alerts (146) · U.S. Weather + Severe / Climate Outlooks (141) · Ukrainian Internal News (national + local Kyiv) (94) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (57)

## What changed today
### International News + Multilateral Institutions — 780 new of 922 total
  - (2026-07-04) [Global] Archaeologists uncover ancient Byzantine city in Egypt’s western desert
  - (2026-07-04) [Global] ‘The situation is terrible’: aid workers on life in Sudanese city pummelled by drone strikes
  - (2026-07-04) [Global] Overseas education project for women and girls axed by UK after two years
  - (2026-07-05) [Global] Rodríguez defends Venezuela’s emergency earthquake response as number of bodies expected to soar
  - (2026-07-05) [Global] Florida Republican says deporting Haitians with TPS would be ‘huge mistake’
  - (2026-07-04) [Global] How the 1986 Mexico World Cup was almost cancelled after a devastating earthquake

### Russian Internal News (state + in-exile) — 670 new of 674 total
  - (2026-07-05) Биологи создали «с нуля» искусственную клетку, которая начала самостоятельно расти и размножаться. Можно ли считать ее живой? И значит ли это, что «секрет жизни» разгадан? | LEDE: Биологи из] (ru: Био…
      Биологи из Университета Миннесоты создали из химически чистых компонентов искусственную клетку, которая оказалась способна самостоятельно питаться, расти и даже (некоторое время) делиться. Описание открытия пока не прошл…
  - (2026-07-05) В центре Москвы полицейские задержали и избили стримера, помахавшего рукой автозаку | LEDE: Полиция Москвы задержала и избила стримера, который помахал рукой автозаку. Стример Виталий (ник y] (ru: В ц…
      Полиция Москвы задержала и избила стримера, который помахал рукой автозаку. Стример Виталий (ник ya__dalbaeb, 120 подписчиков), 3 июля вел прямую трансляцию прогулки с друзьями по Китай-городу на платформе Twitch.
  - (2026-07-05) Песков заявил, что «специальная военная операция» превратилась в «настоящую войну» и в этом виноваты страны Запада | LEDE: Пресс-секретарь президента РФ Дмитрий Песков заявил, что «специальн] (ru: Пес…
      Пресс-секретарь президента РФ Дмитрий Песков заявил, что «специальная военная операция» (СВО) превратилась в «настоящую войну». Виноваты в этом, по его словам, западные страны, поддержавшие Украину.
  - (2026-07-05) В Нижегородской области на канатной дороге застряли 16 человек. Им пришлось по тросу спускаться из кабинок на землю | LEDE: В Нижегородской области остановилась канатная дорога, проходящая н] (ru: В Н…
      В Нижегородской области остановилась канатная дорога, проходящая над Волгой. В остановившихся на высоте кабинках находились 16 человек, в том числе четверо детей, сообщило ГУ МЧС по региону.
  - (2026-07-05) «Газпром» заключил с Минобороны РФ соглашение о создании мобильных огневых групп для защиты своих объектов. В них наберут резервистов | LEDE: «Газпром» заключил контракт с Минобороны о созда] (ru: «Га…
      «Газпром» заключил контракт с Минобороны о создании мобильных огневых групп для патрулирования и защиты объектов газоснабжения. Информацию о соглашении «Эхо» обнаружило во внутренних документах компании.
  - (2026-07-05) Турция депортировала в Россию активистку Ариадну Литвинову. В РФ ее обвиняют в «дискредитации» армии за антивоенную надпись | LEDE: Турция депортировала россиянку Ариадну Литвинову, объявлен] (ru: Тур…
      Турция депортировала россиянку Ариадну Литвинову, объявленную в розыск по обвинению в «дискредитации» армии за антивоенные надписи. По данным телеграм-канала «Тюремный адвокат», Литвинову отправили в Россию 4 июля с тех…

### Ukraine Theater (total-war monitoring) — 618 new of 675 total
  - (2026-07-06) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-04) [FIRMS] thermal anomaly 49.919, 24.058 (FRP 3.19 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-04 0001Z, FRP 3.19 MW
  - (2026-07-04) [FIRMS] thermal anomaly 49.919, 24.065 (FRP 1.98 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-04 0001Z, FRP 1.98 MW
  - (2026-07-04) [FIRMS] thermal anomaly 48.534, 34.642 (FRP 1.88 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-04 0001Z, FRP 1.88 MW
  - (2026-07-04) [FIRMS] thermal anomaly 48.535, 34.621 (FRP 0.87 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-04 0001Z, FRP 0.87 MW
  - (2026-07-04) [FIRMS] thermal anomaly 48.525, 34.617 (FRP 0.85 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-04 0001Z, FRP 0.85 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 222 new of 222 total
  - (2026-07-05) 重要调整，明起，A股交易规则变了 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBSUUxGNS03aEVwQ1ZuMUt6RDhKY01vUjRQS21UR2kyRlgzVVRWYjMyTnZNaUpPQmhDdy1obWI3czZvd3llVHZPdEF1cEw1cVY1S3FYT] (zh:…
      重要调整，明起，A股交易规则变了 财新
  - (2026-07-04) 中融信托因资不抵债获准破产清算 向中植集团申报多少债权？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8zQXlHUDJoTGhfU08wbG5NVlZEelJtTzc5MlE4SVh6eEtiWmhCMmhjM21uOW9yN0NRN1BZbnhpbHBWY2NWUjdtd2hwV] (zh:…
      中融信托因资不抵债获准破产清算 向中植集团申报多少债权？ 财新
  - (2026-07-04) 再融资规则全面调整 便利公司、终结套利 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9mWFh1NDUzdFkxdFBRbXJEelZabnVlc2pYZlMzZTA3UjM0bzdDc0Y2ZnVGWnByclU0b3R1dHd4aEpHaDNPMl9TTlZLYU50MEsyYm] (zh:…
      再融资规则全面调整 便利公司、终结套利 财新
  - (2026-07-04) 佛得角，踢出了草根英雄的胆｜体坛 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1OdXJuQjl5VS01YTFpU01hYW1mVW85a0J3dmtham0wU2M1alhDelpyQWEtWmx3Rnk4bnlOdHdMelNLbzBtNmpRUXpzVkhmUHJxcjI2b] (zh:…
      佛得角，踢出了草根英雄的胆｜体坛 财新
  - (2026-07-04) 下周一A股交易制度生变：ST股涨跌幅扩大至10%、盘后增加交易时段 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1QN1RpRnMwWnFZSkhmMFl3enhaUWREc2luYTFDN2JjV0J3U0dkckU5NDFpX1JTWWI3VzQtVzNsc3g2ME95eUh0] (zh:…
      下周一A股交易制度生变：ST股涨跌幅扩大至10%、盘后增加交易时段 财新
  - (2026-07-05) 最新封面报道｜Token经济已来 - 财新周刊 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYEFVX3lxTE1rU3N2bzVmTWxoY2I1QlZRVlIyRnlUTDB5RG1wdVJDRXMwT2I1a1poc285Tk5NMGp4aGRaRm9zOVNaaGhrZkQyanhmV2FhcVRkX2d] (zh:…
      最新封面报道｜Token经济已来 财新周刊

### Local News: St. Louis + Atlanta — 183 new of 184 total
  - (2026-07-06) [St. Louis] Lou’s Clues – 7/6/2026
      Put your emoji-decoding skills to the test with Lou’s Clues—the weekly family puzzle game inspired by all things STL! Each puzzle challenges kids and grown-ups to work together to crack the clue. Whether you solve it in…
  - (2026-07-06) [St. Louis] England defeats Mexico to head into World Cup quarterfinals
      The Brits will verse Norway on July 11 in Florida.
  - (2026-07-06) [St. Louis] Who has moved on in the World Cup? See the quarterfinal bracket
      Only a handful of teams remain in the 2026 World Cup after the first knockout round of 32.
  - (2026-07-06) [St. Louis] 'God told me to come': Bystander saves 2-year-old with CPR after near-drowning in Michigan
      A 2-year-old girl was pulled from the water unconscious and not breathing. That's when Mariza Mojica stepped in.
  - (2026-07-05) [St. Louis] 8 rescued after seaplane makes 'hard landing' in New York City river
      The sea plane carrying eight people made a “hard landing” around noon, according to the New York City Fire Department.
  - (2026-07-05) [St. Louis] Khamenei's other sons appear at his funeral in Iran as new supreme leader remains in hiding
      Several senior officials made rare public appearances after the war, while Iran's new supreme leader remained out of public view.

### State-Level News — 172 new of 185 total
  - (2026-07-04) [California] Governor Newsom announces deployment of California firefighters and equipment to Colorado, as sister state battles wildfires
      Source
  - (2026-07-04) [California] Gobernador Gavin Newsom conmemora el Día de la Independencia con una llamada a renovar la lucha por defender la democracia
      Source
  - (2026-07-04) [California] Governor Gavin Newsom marks Fourth of July with a call for a renewed fight to defend democracy
      Source
  - (2026-07-04) [California] Estos estudiantes universitarios de Los Ángeles usan el transporte público para ahorrar dinero. Así son sus viajes.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/042826-Student-Transit-MR-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-07-05) [Connecticut] Muskets and pickling: Fifth Regiment brings CT’s Revolutionary War era to life
      <img width="1024" height="683" src="https://ctmirror.org/wp-content/uploads/2026/07/FIFTH-REGIMENT-0628-JL-05-1024x683.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetc…
  - (2026-07-05) [Connecticut] Reflections upon the Reflecting Pool
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/07/ap-reflecting-pool.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading="lazy" srcse…

### GDACS — global disaster alerts — 146 new of 158 total
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)

### U.S. Weather + Severe / Climate Outlooks — 141 new of 143 total
  - (2026-07-05) [Moderate] Special Weather Statement: Special Weather Statement issued July 5 at 10:46PM CDT by NWS Amarillo TX
      At 1046 PM CDT, Doppler radar was tracking a strong thunderstorm 4 miles southeast of Borger, moving east at 10 mph. HAZARD...Wind gusts up to 50 mph and half inch hail. SOURCE...Radar indicated. IMPACT...Gusty winds cou…
  - (2026-07-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-05) [Severe] Flood Warning: Flood Warning issued July 5 at 10:43PM CDT until July 6 at 6:00AM CDT by NWS Kansas City/Pleasant Hill MO
      * WHAT...Flooding caused by excessive rainfall continues. * WHERE...Central Cooper County in central Missouri... * WHEN...Until 600 AM CDT Monday. * IMPACTS...Flooding of rivers, creeks, streams, and other low-lying and…
  - (2026-07-05) [Moderate] Special Weather Statement: Special Weather Statement issued July 5 at 10:42PM CDT by NWS Austin/San Antonio TX
      At 1042 PM CDT, Doppler radar was tracking strong thunderstorms along a line extending from 11 miles east of Sheffield to 13 miles southwest of Sonora to 31 miles west of Telegraph to near Roosevelt to 7 miles southwest…
  - (2026-07-05) [Severe] Dust Storm Warning: Dust Storm Warning issued July 5 at 10:41PM CDT until July 6 at 12:15AM CDT by NWS Midland/Odessa TX
      The National Weather Service in Midland has issued a * Dust Storm Warning for... Southeastern Eddy County in southeastern New Mexico... Southern Lea County in southeastern New Mexico... Pecos County in southwestern Texas…
  - (2026-07-05) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 5 at 10:41PM CDT until July 5 at 11:15PM CDT by NWS Midland/Odessa TX
      At 1041 PM CDT, a severe thunderstorm was located 10 miles southeast of Greenwood, moving southeast at 20 mph. HAZARD...60 mph wind gusts and half dollar size hail. SOURCE...Radar indicated. IMPACT...Hail damage to vehic…

### Ukrainian Internal News (national + local Kyiv) — 94 new of 102 total
  - (2026-07-06) На Київщині з міркувань безпеки обмежили рух поїздів: очікуються затримки – УЗ | LEDE: На деяких ділянках залізниці у Київській області з безпекових міркувань обмежили рух поїздів, через що низ] (uk:…
      На деяких ділянках залізниці у Київській області з безпекових міркувань обмежили рух поїздів, через що низка рейсів прямуватиме із затримкою за резервними маршрутами.
  - (2026-07-06) "Батальйон Монако 4": Як УП знайшла фігурантів операції "Мідас" на Лазуровому березі | LEDE: Чотири роки тому у липні 2022-ого "Українська правда" опублікувала першу частину серіалу "Батальйон ] (uk:…
      Чотири роки тому у липні 2022-ого "Українська правда" опублікувала першу частину серіалу "Батальйон Монако" про українські еліти, які втекли за кордон під час великої війни. За вікном вже середина 2026-ого і можна смілив…
  - (2026-07-06) Російська ракета влучила в девʼятиповерхівку на Подолі: в Києві вже 7 загиблих та 24 поранених | LEDE: У ніч на 6 липня російська ракета влучила в дев'ятиповерховий житловий будинок у Подільськ] (uk:…
      У ніч на 6 липня російська ракета влучила в дев'ятиповерховий житловий будинок у Подільському районі Києва, внаслідок чого сталося його часткове руйнування. Загалом в столиці вже семеро загиблих і 24 поранених.
  - (2026-07-06) Окупований Севастополь залишився без світла після атаки дронів | LEDE: Севастополь залишилося без електропостачання внаслідок атаки безпілотників на об'єкти енергетичної інфраструктури.] (uk: Окупован…
      Севастополь залишилося без електропостачання внаслідок атаки безпілотників на об'єкти енергетичної інфраструктури.
  - (2026-07-06) Внаслідок російської атаки на Київщину загинула одна людина, ще 10 дістали поранення | LEDE: Внаслідок нічної масованої російської атаки у Бучанському районі Київської області загинула людина, ] (uk:…
      Внаслідок нічної масованої російської атаки у Бучанському районі Київської області загинула людина, ще десять жителів регіону отримали травми та поранення різного ступеня тяжкості.
  - (2026-07-06) У Малі туареги збили вертоліт російського "Африканського корпусу" та штурмують стратегічне місто – ЗМІ | LEDE: Повстанці-туареги в Малі збили військовий гелікоптер, який, імовірно, належить "Аф] (uk:…
      Повстанці-туареги в Малі збили військовий гелікоптер, який, імовірно, належить "Африканському корпусу" Міністерства оборони РФ, та розпочали масштабний штурм стратегічно важливого міста Анефіс на півночі країни.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-02) Supreme Court of Alabama: Col. Alan Spencer, in his official capacity as Chairman of the Alabama Alcoholic Beverage Control Board; Melissa Morrissette, in her official capacity as a member of the Alab…
  - (2026-07-02) Supreme Court of Alabama: In re: Amanda Busby v. City of Tuskegee
  - (2026-07-02) Supreme Court of Alabama: In re: Amanda Busby v. City of Tuskegee
  - (2026-07-02) Supreme Court of Alabama: In re: Demarco Stoudmire v. City of Birmingham
  - (2026-07-02) Alaska Supreme Court: Viva G. v. Department of Family and Community Services, Office of Children's Services
  - (2026-07-02) D.C. Court of Appeals: D.W. v. United States (en banc)

### IT, InfoSys & cybersecurity news (last 7 days) — 57 new of 57 total
  - (2026-07-05) [BleepingComputer] Flipper Zero firmware development continues with community help
      Flipper Devices says development of the Flipper Zero firmware will continue, albeit with a smaller internal team and greater reliance on community contributions. [...]
  - (2026-07-05) [The Register] MFA-optional banks leave safe doors (and accounts) wide open for thieves to pillage
      Financial institutions are putting their clients at risk in the name of convenience.
  - (2026-07-05) [The Register] C programmers commit fresh crimes against readability
      Prepare to be befuddled and bamboozled – and probably bewitched
  - (2026-07-05) [Ars Technica] Chemical accidents rise as Trump administration proposes weakening safety rules
      Chemicals from accidents that injured or killed people increased by nearly 50 percent in recent years.
  - (2026-07-05) [Ars Technica] The missing 500 million: Cosmic bombardment melted Earth's first crust
      The heat of the Hadean may have come from impacts as well as the interior.
  - (2026-07-05) [TechCrunch] Uber’s European expansion plans may have hit a speed bump
      Back in February, Uber announced ambitious plans to launch in seven new European markets in 2026 — but now five of those launches are reportedly on hold.

### GDELT GKG — themes / entities / watch areas — 49 new of 49 total
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] 拚毒駕績效爭議 南港警分局 ： 已取消偵查隊協助勤務 | 社會
      cna.com.tw · Chinese · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Man dies after being pulled from water at Lake St . Croix Beach
      fox9.com · English · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Footprints : Blame poverty , not the people - Newspaper
      dawn.com · English · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Así cambió la relación entre Wanda Nara y Maxi López con el paso de los años
      elintransigente.com · Spanish · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Justiz - Anti - Folter - Stelle kritisiert Zustände in Gefängnissen
      unternehmen-heute.de · German · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Dogs of the World : Epic photo series celebrates canines across continents
      nzherald.co.nz · English · tone NA

### Government Action: Sanctions + Procurement + Foreign Agents — 46 new of 108 total
  - (2026-07-01) [OFAC] Counter Narcotics Designations; Counter Terrorism Designations and Designation Update - Office of Foreign Assets Control (.gov)
      Counter Narcotics Designations; Counter Terrorism Designations and Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-01) [OFAC] Reminder to File the 2026 Annual Report of Blocked Property - Office of Foreign Assets Control (.gov)
      Reminder to File the 2026 Annual Report of Blocked Property Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act…
      Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) Office of Foreign A…
  - (2026-06-29) [OFAC] Launch of OFAC Reconsideration Portal - Office of Foreign Assets Control (.gov)
      Launch of OFAC Reconsideration Portal Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Mexican Cartel Fuel Smuggling Schemes - Office of Foreign Assets Control (.gov)
      Mexican Cartel Fuel Smuggling Schemes Office of Foreign Assets Control (.gov)
  - (2026-06-29) [OFAC] 1261 - Office of Foreign Assets Control (.gov)
      1261 Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 43 new of 144 total
  - (2026-07-06) [Polymarket] Will the Green Bay Packers win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-06) [Polymarket] Will James Talarico win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-06) [Polymarket] Will Joao Fonseca win the 2026 Men's US Open?
      The 2026 U.S. Open tennis tournament is scheduled for August 23 - September 13, 2026. This market will resolve to the player that wins the 2026 U.S. Open Men’s Singles Tournament. If at any point it becomes impossible fo…
  - (2026-07-06) [Polymarket] Will Austin Reaves play for the Cleveland Cavaliers in 2026-27?
      This market will resolve to the next team Austin Reaves officially joins by October 31, 2026, 11:59 PM ET. If Austin Reaves does not officially join a new team by October 31, 2026, 11:59 PM ET, this market will resolve t…
  - (2026-07-06) [Polymarket] Opensea FDV above $100M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Opensea's token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token must be activ…
  - (2026-07-06) [Polymarket] Will the price of Bitcoin be above $70,000 on July 6?
      This market will resolve to "Yes" if the Binance 1 minute candle for BTC/USDT 12:00 in the ET timezone (noon) on the date specified in the title has a final "Close" price higher than the price specified in the title. Oth…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-03) [Richard Christian M] Form 4 (Reporting)
      filed 2026-07-03 01:59 UTC · role: Reporting — Filed: 2026-07-02 AccNo: 0001104659-26-080497 Size: 6 KB
  - (2026-07-03) [CYPHERPUNK TECHNOLOGIES INC.] Form 4 (Issuer)
      filed 2026-07-03 01:59 UTC · role: Issuer — Filed: 2026-07-02 AccNo: 0001104659-26-080497 Size: 6 KB
  - (2026-07-03) [Oei Khing Djien] Form 4 (Reporting)
      filed 2026-07-03 01:58 UTC · role: Reporting — Filed: 2026-07-02 AccNo: 0001104659-26-080496 Size: 6 KB
  - (2026-07-03) [CYPHERPUNK TECHNOLOGIES INC.] Form 4 (Issuer)
      filed 2026-07-03 01:58 UTC · role: Issuer — Filed: 2026-07-02 AccNo: 0001104659-26-080496 Size: 6 KB
  - (2026-07-03) [Corvex, Inc.] Form 4 (Issuer)
      filed 2026-07-03 01:58 UTC · role: Issuer — Filed: 2026-07-02 AccNo: 0001193125-26-295228 Size: 10 KB
  - (2026-07-03) [FAIRBAIRN EMILY] Form 4 (Reporting)
      filed 2026-07-03 01:58 UTC · role: Reporting — Filed: 2026-07-02 AccNo: 0001193125-26-295228 Size: 10 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-06) [United States] Man dies after being pulled from water at Lake St . Croix Beach
      domain: fox9.com · language: English · tone:
  - (2026-07-06) [] Lionel Richie issues major health update for fans after axing shows
      domain: castanetkamloops.net · language: English · tone:
  - (2026-07-06) [Pakistan] Footprints : Blame poverty , not the people - Newspaper
      domain: dawn.com · language: English · tone:
  - (2026-07-06) [New Zealand] Dogs of the World : Epic photo series celebrates canines across continents
      domain: nzherald.co.nz · language: English · tone:
  - (2026-07-06) [United States] Allergies show a small but significant link to later cancer risk
      domain: news-medical.net · language: English · tone:
  - (2026-07-06) [India] Mumbai shanty collapse : Many residents left risky building , returned hours later before it killed 5 kids , woman
      domain: timesofindia.indiatimes.com · language: English · tone:

### U.S. Federal Action — 30 new of 30 total
  - (2026-07-06) Improvements to Rules on Recoupment of Benefit Overpayments
      The Pension Benefit Guaranty Corporation (PBGC) is proposing to improve its rules on recoupment of benefit overpayments under PBGC's insurance program for single-employer terminated plans trusteed by PBGC. These proposed…
  - (2026-07-06) Rescission of Guidelines on Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964, as Amended
      The Equal Employment Opportunity Commission ("EEOC" or "Commission") is rescinding its regulations regarding Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964 ("Guidelines"), and removing it…
  - (2026-07-06) Presidential Determination on Assistance to Venezuela Consistent With the Trafficking Victims Protection Act of 2000
  - (2026-07-06) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Angling Category Southern New England Area Trophy Fishery for 2026
      NMFS closes the Angling category Southern New England area fishery for large medium and giant ("trophy" (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length or greater)) Atlantic bluefin tuna (BFT). This…
  - (2026-07-06) Nondiscrimination in Federally Assisted Programs of NASA-Effectuation of Title VI of the Civil Rights Act of 1964
      NASA is amending its regulation implementing Title VI of the Civil Rights Act of 1964 (Title VI) for federally assisted programs to conform more closely to the statutory text and recent revisions by the Department of Jus…
  - (2026-07-06) Amendment of Using Agency and Controlling Agency for Restricted Areas R-5301, R-5302A, R-5302B, and R-5302C; NC
      This action amends the using agency and controlling agency descriptions listed for restricted areas R-5301, R-5302A, R-5302B, and R-5302C, NC. This action does not change any boundaries, altitudes, times of designation,…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Prediction Markets — most-traded (Polymarket) — 16 new of 20 total
  - (2026-07-06) Will Norway win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $10,011,517 · resolves 2026-07-20
  - (2026-07-06) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $5,389,053 · resolves 2026-07-20
  - (2026-07-06) Will England win the 2026 FIFA World Cup?
      yes price: 14% · 24h volume: $4,759,443 · resolves 2026-07-20
  - (2026-07-06) Will USA win the 2026 FIFA World Cup?
      yes price: 3% · 24h volume: $4,346,365 · resolves 2026-07-20
  - (2026-07-06) Will Volodymyr Zelenskyy be the next leader out before 2027?
      yes price: 0% · 24h volume: $3,314,503 · resolves 2026-12-31
  - (2026-07-06) Will Portugal win the 2026 FIFA World Cup?
      yes price: 6% · 24h volume: $2,611,912 · resolves 2026-07-20

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-07-05) M 5.8 - 274 km SE of Levuka, Fiji
      M5.8 · 274 km SE of Levuka, Fiji · depth 685.692 km
  - (2026-07-05) M 5.3 - 71 km S of Severo-Kuril’sk, Russia
      M5.3 · 71 km S of Severo-Kuril’sk, Russia · depth 82.936 km
  - (2026-07-05) M 5.0 - 106 km NW of Coquimbo, Chile
      M5.0 · 106 km NW of Coquimbo, Chile · depth 10 km
  - (2026-07-05) M 5.0 - 26 km NNW of Mianzhu, Deyang, Sichuan, China
      M5.0 · 26 km NNW of Mianzhu, Deyang, Sichuan, China · depth 10 km
  - (2026-07-05) M 5.0 - 23 km NNW of Mianzhu, Deyang, Sichuan, China
      M5.0 · 23 km NNW of Mianzhu, Deyang, Sichuan, China · depth 10 km
  - (2026-07-05) M 5.0 - 98 km NW of Coquimbo, Chile
      M5.0 · 98 km NW of Coquimbo, Chile · depth 10 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-06) [China] China , Finland agree to strengthen cooperation , jointly address challenges
      globaltimes.cn · English
  - (2026-07-06) [China] ByteDance Doubao and Alibaba Qwen to shut down AI agent features on July 15 · TechNode
      technode.com · English
  - (2026-07-06) [China] Neymar signals Brazil farewell after World Cup exit
      china.org.cn · English
  - (2026-07-06) [China] China Long March - 8A rocket launches new satellite group
      china.org.cn · English
  - (2026-07-06) [China] China , Finland agree to strengthen cooperation , jointly address challenges
      china.org.cn · English
  - (2026-07-06) [China] Cristiano Ronaldo : This will be my last World Cup
      china.org.cn · English

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-05) [Marginal Revolution] *What Makes a Great Composer?: A Data-Driven Exploration of Music History*
      A very good book, forthcoming, by Karol J. Borowiecki and Marc Lawx, here is the Amazon link, here is the Princeton University Press page. The post *What Makes a Great Composer?: A Data-Driven Exploration of Music Histor…
  - (2026-07-05) [Marginal Revolution] Sunday assorted links
      1. The family keeping watch over a 52-year-old pot of soup (WSJ). I guessed the country wrong. 2. The rise of grocery tourism. 3. PEPFAR interview. Much of this is substantive, and interesting. But some of Mike’s claims…
  - (2026-07-05) [Marginal Revolution] What should I ask Michael Moritz?
      Yes I will be doing a Conversation with him, based around his new book Ausländer: One Family’s Story of Escape and Exile. Mike of course was a pioneering venture capitalist through Sequoia, and before that had a distingu…
  - (2026-07-04) [Conversable Economist] Declaration of Independence: Track Changes Version
      Thomas Jefferson wrote out the first draft of the Declaration of Independence, but he did not do so alone and without guidance. After all, he had been a member of the Continental Congress that summer, listening to the di…
  - (2026-07-03) [Conversable Economist] What Does the Declaration Mean by Pursuit of Happiness?
      I wrote this short essay about the “pursuit of happiness” for the editorial page of the StarTribune newspaper, where it was published on July 3. _____ Opinion | What did the founders mean by the pursuit of happiness? The…
  - (2026-07-02) [Conversable Economist] US Exports, Imports, and Tariffs: The 250-Year Perspective
      Douglas A. Irwin offers a brisk overview of a great American tradition–specifically, “America’s been arguing over trade for more than 250 years” (Peterson Institute for International Economics, July 1, 2026). I won’t reh…

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 8 total
  - (2026-07-01) CVE-2026-45659 · Microsoft SharePoint Server: Microsoft SharePoint Server Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint Server · CISA remediation by 2026-07-04
  - (2026-06-29) CVE-2026-48558 · SimpleHelp SimpleHelp: SimpleHelp Authentication Bypass Vulnerability
      vendor: SimpleHelp · product: SimpleHelp · CISA remediation by 2026-07-02
  - (2026-06-25) CVE-2026-12569 · PTC Windchill and FlexPLM: PTC Windchill and FlexPLM Improper Input Validation Vulnerability
      vendor: PTC · product: Windchill and FlexPLM · CISA remediation by 2026-06-28
  - (2026-06-25) CVE-2026-20230 · Cisco Unified Communications Manager: Cisco Unified Communications Manager Server-Side Request Forgery (SSRF) Vulnerability
      vendor: Cisco · product: Unified Communications Manager · CISA remediation by 2026-06-28

### WHO Disease Outbreak News — 3 new of 40 total
  - (2026-07-03) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with sustained transmission and increasing numbers of reported cases. As of 1 July, a cumulative of 1460 co…
  - (2026-07-02) Hantavirus outbreak linked to cruise ship travel, Multi-locations
      This is the fifth Disease Outbreak News posting on the Andes hantavirus (ANDV) outbreak linked to the cruise ship M/V Hondius. The outbreak identification followed the notification to the World Health Organization (WHO)…
  - (2026-06-25) Nipah virus disease - India
      On 11 June 2026, the Kerala State Health Department confirmed one laboratory confirmed case of Nipah virus (NiV) infection in Kozhikode district, Kerala State, India. The case is an adult male who developed symptoms on 3…

### Campaign finance (FEC: top fundraisers + recent filings) — 2 new of 27 total
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-07-06) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=26, 14d-median=26; carrying terms: captain, authorized, coast, regulatory, entry, rulemaking, financial, proposing, waters, establishing, protect, issuing
- state_bills: today=0, 7d-median=152, 14d-median=152; carrying terms: administrator, month, local, duties, gross, registration, wildlife, ballot, requiring, guilty, economic, communications
- state_news: today=185, 7d-median=452, 14d-median=452; carrying terms: collins, voting, raising, month, university, beautiful, firefighters, border, focus, multiple, ballot, light
- local_news: today=184, 7d-median=221, 14d-median=221; carrying terms: month, local, multiple, ballot, happened, stlmag, three, construction, concerns, blank, neighborhood, carolina
- foreign_news: today=922, 7d-median=1034, 14d-median=1034; carrying terms: richest, winning, winner, crore, vollansky, firms, month, university, local, imperial, sichuan, spirit
- chinese_internal: today=222, 7d-median=281, 14d-median=281; carrying terms: lxtfa, cbmib, cbmiyefvx, blank, cbmickfvx, cbmizkfvx, people, cbmiy, color, articles, cbmiakfvx, cbmiykfvx
- russian_internal: today=674, 7d-median=915, 14d-median=915; carrying terms: russian, media, telegram, https, laquo, europe, httperror, istories, novaya, forbidden, group, politico
- ukrainian_internal: today=102, 7d-median=111, 14d-median=111; carrying terms: refining, france, border, multiple, saying, regional, leader, economic, false, prompting, media, estimated
- ukraine_theater: today=675, 7d-median=616, 14d-median=616; carrying terms: dxnwrkhrb, firms, xmgvpcwxmsvpnrefwmfbztwnkbw, spetstechnoexport, local, cuxqujnqbzlunk, bzvzpogy, cuxpunlqexfkudb, cbmilwfbvv, vywjjjdjnodvj, dxzyvwyymunuvfltx, exrvbeddhuexllejnvyg
- paper_bets: today=144, 7d-median=139, 14d-median=139; carrying terms: evans, anthropic, winner, longer, texas, statement, humans, drought, california, anysphere, georgia, goldman
- weather: today=143, 7d-median=173, 14d-median=173; carrying terms: cyclone, inches, norton, local, quality, amounts, changed, queen, light, streets, though, layer
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, inflation, dexuseu, personal, labor, latest, walcl, dexchus, headline, spread, supply, jolts
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: proxy, futures, large, natural, agriculture, close, yield, bitcoin, crude, nasdaq, range, credit
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=108, 7d-median=104, 14d-median=104; carrying terms: unauthorised, herzegovina, acronym, docket, station, designations, science, attacks, updates, cbmib, economic, mufswgh
- congressional_trades: today=1, 7d-median=68, 14d-median=68
- billionaires: today=31, 7d-median=40, 14d-median=40; carrying terms: tokyo, gates, walton, yanai, france, tadashi, italy, canada, technologies, nasdaq, microsoft, cryptocurrency
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: supreme, blanche, court, hernandez, revisions, corporation, international, association, michael, alabama, academy, american
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: accno, issuer, filed, reporting
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: talarico, receipts, sherrod, scott, congress, pinkston, brown, filing, platner, ossoff, shawn, graham
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=49, 7d-median=25, 14d-median=25; carrying terms: russian, spanish, themes, english, trump, hezbollah, israel, indonesian, tribunnews, chinese, greek
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: kingdom, south, language, india, domain, english, australia, trump
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=4, 7d-median=28, 14d-median=28; carrying terms: ground, position, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: detection, virus, sentinel, valley, posing, france, haemorrhage, hygiene, accordance, covid, recombinant, humans
- cisa_kev: today=8, 7d-median=9, 14d-median=9; carrying terms: manager, control, remediation, product, cisco, access, vendor, injection, traversal, improper, vulnerability, authentication
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=158, 7d-median=120, 14d-median=120; carrying terms: alert, denmark, ukraine, serbia, republic, cyclone, finland, poland, drought, medium, austria, japan
- usgs_quakes: today=11, 7d-median=14, 14d-median=14; carrying terms: indonesia, depth
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, world, resolves, argentina, price, colombia, belgium
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: revolution, class, economist, https, years, conversable, country, world, conversableeconomist, marginal
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: firms, boxes, attacks, multiple, greater, policy, strategic, execution, organizations, account, inside, source
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: evans, simon, herbert, escobar, collins, biggs, schiff, salud, franklin, menendez, michelle, budzinski
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: converges, today, sufficient, consensus, paper, placement, either, markets, decision, module, evidence, unavailable

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-22] Fed press (events + announcements): Federal Reserve notes with deep sadness the passing of Alan Greenspan
- [2026-06-22] Fed speeches: Waller, Welcoming Remarks on the International Role of the U.S. Dollar
- [2026-06-24] Fed speeches: Cook, Welcome Remarks
- [2026-06-24] Fed press (events + announcements): Federal Reserve Board's annual bank stress test confirms that large banks are well positioned to weather a severe recession and able to continue to lend to households and businesses
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board issues enforcement action with employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Jiko Group, Inc.
- [2026-06-26] ECB press: ECB Consumer Expectations Survey results – May 2026
- [2026-06-27] ECB press: Isabel Schnabel: Is inflation back?
- [2026-06-29] ECB press: Christine Lagarde: Back to basics in an uncertain environment
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2028
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2027
- [2026-06-30] Fed press (events + announcements): Agencies release list of distressed or underserved nonmetropolitan middle-income geographies
- [2026-07-01] Fed press (events + announcements): Federal Reserve issues initial findings from its 2025 triennial payments study
- [2026-07-02] ECB press: Frank Elderson: The green transition – benefits and barriers
- [2026-07-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Small Business Bank and announces termination enforcement actions with BNP Paribas S.A., BNP Paribas USA, Inc., BNP Paribas Securities Corp., and Community Bankshares, Inc.
- [2026-07-02] ECB press: Piero Cipollone: The digital transformation of money, payments and finance
- [2026-07-02] ECB press: Christine Lagarde: Interview with Les Échos

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*