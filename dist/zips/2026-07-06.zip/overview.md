# WORLDSCOPE morning brief — 2026-07-06

## Headline
4389 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (896) · Russian Internal News (state + in-exile) (879) · Ukraine Theater (total-war monitoring) (525) · State-Level News (406) · World leaders & government officials (324) · Chinese Internal News (252) · Local News: St. Louis + Atlanta (236) · GDACS — global disaster alerts (162) · U.S. Weather + Severe / Climate Outlooks (145) · Ukrainian Internal News (national + local Kyiv) (127) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (57)

## What changed today
### International News + Multilateral Institutions — 896 new of 1038 total
  - (2026-07-06) [Global] Banks accused of failing most vulnerable customers
      Homeless people or those in financial hardship have been pushed to online applications and away from basic bank accounts.
  - (2026-07-06) [Global] Amazon bars breastfeeding boss from business course
      Rachel Bews says she told on the way her child would not be allowed on site. Amazon has apologised for not communicating its policy clearly.
  - (2026-07-06) [Global] 'I wear it on my middle finger': The rise of the defiant divorce ring
      Around the world women are marking their split with new - or repurposed engagement - rings.
  - (2026-07-06) [Global] Can China repeat its EV success with robotaxis?
      China's self-driving car firms have been given a headstart by the country's EV supply chain as they expand globally.
  - (2026-07-06) [Global] Microsoft cuts 4,800 jobs and shrinks Xbox in 'significant restructure'
      The sweeping layoffs equate to 2.1% of Microsoft's workforce, with 1,600 immediate job losses at Xbox.
  - (2026-07-06) [Global] ITV hits such as I'm a Celebrity to stay free to watch after Sky takeover
      Sky boss Dana Strong's comments came as the channel announces it is buying ITV's media and entertainment divisions in a £1.6bn deal.

### Russian Internal News (state + in-exile) — 879 new of 882 total
  - (2026-07-07) Компании-оператору «Северных потоков» отказали в компенсации за подрыв газопроводов | LEDE: Высокий суд Лондона постановил, что западные страховые компании не должны покрывать ущерб, причине] (ru: Ком…
      Высокий суд Лондона постановил, что западные страховые компании не должны покрывать ущерб, причиненный подрывом обеих веток газопровода «Северный поток». Об этом пишет Financial Times со ссылкой на решение суда.
  - (2026-07-06) На Кубе блэкаут — уже третий за полгода | LEDE: На Кубе полностью отключилось электричество. Причины пока неизвестны, сообщил государственный электроэнергетический оператор Union Electrica d] (ru: На…
      На Кубе полностью отключилось электричество. Причины пока неизвестны, сообщил государственный электроэнергетический оператор Union Electrica de Cuba (UNE).
  - (2026-07-06) Зеленский заявил, что исход войны определит «битва в небе»: «Когда в сторону Москвы полетит уже не сто дронов, а тысяча, он поймет» | LEDE: Президент Украины Владимир Зеленский сказал в инте] (ru: Зел…
      Президент Украины Владимир Зеленский сказал в интервью Financial Times, что ключевая фаза российско-украинской войны сместилась с суши и моря в воздух. По его мнению, именно «битва в небе» определит исход конфликта.
  - (2026-07-06) Губернатор призвал жителей Вологодской области не запасаться топливом. А вскоре сам остался на трассе без бензина: «Бак на нуле» | LEDE: Глава Вологодской области Георгий Филимонов рассказал] (ru: Губ…
      Глава Вологодской области Георгий Филимонов рассказал в своем телеграм-канале, что застрял на трассе, так как в его служебном автомобиле закончился бензин.
  - (2026-07-06) В 1944 году Леонид Брежнев (уроженец Украины) освобождал ее от нацистов. Теперь его правнук принял участие в российском вторжении — и попал в плен | LEDE: Приемный правнук генсека СССР Леони] (ru: В 1…
      Приемный правнук генсека СССР Леонида Брежнева Антон Милаев принял участие в российском вторжении в Украину и весной 2026 года попал в плен. Проект «Хочу жить», с помощью которого власти Украины пропагандируют сдачу в пл…
  - (2026-07-06) Бывший член «Альтернативы для Германии», уроженец Чечни Ноа Кригер (он же Мурад Дадаев) приехал в Донбасс | LEDE: Уроженец Чечни и бывший член ультраправой немецкой партии «Альтернатива для ] (ru: Быв…
      Уроженец Чечни и бывший член ультраправой немецкой партии «Альтернатива для Германии» Ноа Кригер (настоящее имя — Мурад Дадаев) заявил, что отправился в зону боевых действий в Украине, чтобы участвовать в войне на сторон…

### Ukraine Theater (total-war monitoring) — 525 new of 578 total
  - (2026-07-06) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2016-04-27) [Liveuamap] News Live - Liveuamap
      News Live Liveuamap
  - (2026-07-04) [Liveuamap] 1 person wounded as result of drone strike in Kyivskyi district of Kharkiv - Liveuamap
      1 person wounded as result of drone strike in Kyivskyi district of Kharkiv Liveuam
  - (2026-07-05) [Liveuamap] Power blackout in Sevastopol, - local authorities - Liveuamap
      Power blackout in Sevastopol, - local authorities Liveuamap
  - (2026-07-04) [Liveuamap] Russian aviation launching glide bombs towards Zaporizhzhia - Liveuamap
      Russian aviation launching glide bombs towards Zaporizhzhia Liveuamap
  - (2026-07-03) [Liveuamap] Fires in Bilenke as result of Russian strikes - Liveuamap
      Fires in Bilenke as result of Russian strikes Liveuamap

### State-Level News — 406 new of 419 total
  - (2026-07-06) [California] Governor Newsom announces $12.5 million in community emergency preparedness to help Californians get “Ready” for the next disaster
      Source
  - (2026-07-04) [California] Governor Newsom announces deployment of California firefighters and equipment to Colorado, as sister state battles wildfires
      Source
  - (2026-07-04) [California] Gobernador Gavin Newsom conmemora el Día de la Independencia con una llamada a renovar la lucha por defender la democracia
      Source
  - (2026-07-04) [California] Governor Gavin Newsom marks Fourth of July with a call for a renewed fight to defend democracy
      Source
  - (2026-07-06) [California] Private prison company sells two of California’s immigrant detention centers to the feds
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/092225-CalCity-Detention-MV-CM-13.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-ima…
  - (2026-07-06) [California] Las escuelas de California son las más segregadas del país, a pesar de los programas voluntarios de transporte escolar
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2023/07/072023-EV-School-Bus-MG-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 252 new of 252 total
  - (2026-07-04) Caixin Global – Latest China News & Headlines - Caixin Global
      Caixin Global – Latest China News & Headlines Caixin Global
  - (2026-07-05) 美日紧盯：韩国32年来首次重启，能赢中国？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE5SdUtCMmxxUUl2Y1JObmdhOEpzd05JVXRSTV9xMVpoVXpsQ1RwWmJRMkVHTFNQV0NNVnB2SmRwMlNtempQZ2tUcVpETjl6Y2p] (zh:…
      美日紧盯：韩国32年来首次重启，能赢中国？ 观察者
  - (2026-07-06) 狂发6亿股权激励，MinMax图啥？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTFA4ODB0OU0zVFhZSmJDZU5iUWhpV0d1ZHIxdUpOa3B0ZFZfUHlvSWhIbThnc3VNQ3d4d1NvV09IWHRHNTdmdVNZVXJ3b1FoeVN5dlY] (zh:…
      狂发6亿股权激励，MinMax图啥？ 风闻
  - (2026-07-06) 高市淫X，赖桑乱X，东亚政治这么不严肃了吗？【乌鸦校尉】 - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMidEFVX3lxTE12NkYzWmNhMlJwbkJBaURyOG5jUDltUWZ2X0NLRWttV0NHMDJ6bURxWnB3cEtZb3U3VFlnZ094cmQ1Q2hLd1BTLXM2S] (zh:…
      高市淫X，赖桑乱X，东亚政治这么不严肃了吗？【乌鸦校尉】 风闻
  - (2026-07-06) 印太改亚太，美国重回正道？ - 观察者 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE03aWFHOWFvcEdydUtZTGlnR3pDbHV6TDBnVnczQVRhbk8tbXBIeE8tbGx5eldDdHc2RzMwS0NqZzZocXNSbjg1ZzEzdklES0dMZDBHUXN] (zh:…
      印太改亚太，美国重回正道？ 观察者
  - (2026-07-06) 如何看待女子高德打到臭车想开窗被反怼：你只是打个车而已，我们怎么舒服怎么来？ - 风闻 | LEDE: <a href="https://news.google.com/rss/articles/CBMiW0FVX3lxTE9pT2pjZHlhdy10VWlSNXpveWtWX0ZZXzlDUTJETjV2Wk9BZUtsWWwtQ1RvdkF2X1pRcFlyR1dpYlNuS0k] (zh:…
      如何看待女子高德打到臭车想开窗被反怼：你只是打个车而已，我们怎么舒服怎么来？ 风闻

### Local News: St. Louis + Atlanta — 236 new of 236 total
  - (2026-07-06) [St. Louis] Trump says Walmart cut prices at his request, but Walmart statement omits administration's role
      The company, in a statement issued Monday, said its price rollbacks at Walmart and Sam's Club will help customers “make the most” of the summer season.
  - (2026-07-06) [St. Louis] Is Folarin Balogun starting against Belgium after his suspension was lifted?
      The USMNT is taking on Belgium in the World Cup round of 16 game Monday night in Seattle.
  - (2026-07-06) [St. Louis] Democrats begin pulling Graham Platner endorsements after Maine candidate faces sexual assault allegation
      Maine Senate candidate Graham Platner denied the sexual assault allegation and said he would be considering next steps for his campaign.
  - (2026-07-06) [St. Louis] If the US wins in the round of 16, who would they play next?
      A win against Belgium on Monday night will secure the Americans a spot in the quarterfinals, a feat not achieved since the 2002 World Cup.
  - (2026-07-06) [St. Louis] Powerball jackpot expands to UK later this month. Here's what to know.
      Powerball is expanding to the U.K., allowing British lottery players a chance to win the jackpot and the move could lead to bigger prizes for everyone.
  - (2026-07-06) [St. Louis] Who has moved on in the World Cup? See the quarterfinal bracket
      Only a handful of teams remain in the 2026 World Cup after the first knockout round of 32.

### GDACS — global disaster alerts — 162 new of 177 total
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)

### U.S. Weather + Severe / Climate Outlooks — 145 new of 147 total
  - (2026-07-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-06) [Moderate] Special Weather Statement: Special Weather Statement issued July 6 at 6:34PM CDT by NWS Little Rock AR
      At 633 PM CDT, Doppler radar was tracking a strong thunderstorm over Dogwood, or 8 miles southwest of Sheridan, moving southeast at 10 mph. HAZARD...Wind gusts up to 50 mph and nickel size hail. SOURCE...Radar indicated.…
  - (2026-07-06) [Severe] Flash Flood Warning: Flash Flood Warning issued July 6 at 7:34PM EDT until July 6 at 10:30PM EDT by NWS Raleigh NC
      FFWRAH The National Weather Service in Raleigh has issued a * Flash Flood Warning for... North Central Johnston County in central North Carolina... Wake County in central North Carolina... * Until 1030 PM EDT. * At 734 P…
  - (2026-07-06) [Extreme] Tornado Warning: Tornado Warning issued July 6 at 6:32PM CDT until July 6 at 7:00PM CDT by NWS Grand Forks ND
      At 631 PM CDT, a severe thunderstorm capable of producing a tornado was located over Syre, or 31 miles northwest of Detroit Lakes, moving east at 45 mph. HAZARD...Tornado and quarter size hail. SOURCE...Radar indicated r…
  - (2026-07-06) [Severe] Severe Thunderstorm Warning: Severe Thunderstorm Warning issued July 6 at 7:32PM EDT until July 6 at 8:15PM EDT by NWS Greenville-Spartanburg SC
      At 732 PM EDT, a severe thunderstorm was located 8 miles southeast of Downtown Concord, or 4 miles southwest of Mt Pleasant, moving east at 5 mph. HAZARD...60 mph wind gusts. SOURCE...Radar indicated. IMPACT...Expect dam…
  - (2026-07-06) [Severe] Flood Warning: Flood Warning issued July 6 at 7:31PM EDT until July 7 at 7:30AM EDT by NWS Buffalo NY
      * WHAT...Small stream flooding caused by excessive rainfall is expected. * WHERE...A portion of western New York, including the following county, Allegany. * WHEN...Until 730 AM EDT Tuesday. * IMPACTS...Flooding of river…

### Ukrainian Internal News (national + local Kyiv) — 127 new of 135 total
  - (2026-07-07) На Дніпропетровщині через російський удар по місту Самар виникла масштабна пожежа | LEDE: У Самарі через атаку РФ виникла пожежа на складах з технікою, обійшлось без постраждалих.] (uk: На Дніпропетро…
      У Самарі через атаку РФ виникла пожежа на складах з технікою, обійшлось без постраждалих.
  - (2026-07-07) У Києві до 18 зросла кількість загиблих через російський удар – ДСНС | LEDE: В Дарницькому районі Києва рятувальники дістали ще 2 тіла з-під завалів після атаки РФ. Загиблих — 18. Тривають ряту] (uk:…
      В Дарницькому районі Києва рятувальники дістали ще 2 тіла з-під завалів після атаки РФ. Загиблих — 18. Тривають рятувальні роботи.
  - (2026-07-07) На Сумщині двоє людей загинули через російські удари дронами | LEDE: У Сумській області через атаки дронів РФ загинули двоє цивільних, ще один важко поранений помер у лікарні.] (uk: На Сумщині двоє лю…
      У Сумській області через атаки дронів РФ загинули двоє цивільних, ще один важко поранений помер у лікарні.
  - (2026-07-06) Четверо людей отримали поранення в Запоріжжі через атаку безпілотників | LEDE: Російська армія 6 липня атакувала безпілотниками Запоріжжя, четверо людей поранені.] (uk: Четверо людей отримали пораненн…
      Російська армія 6 липня атакувала безпілотниками Запоріжжя, четверо людей поранені.
  - (2026-07-06) У Міноборони Польщі прокоментували передачу Україні ракет для Patriot | LEDE: ] (uk: У Міноборони Польщі прокоментували передачу Україні ракет для Patriot)
  - (2026-07-06) Генштаб назвав три найгарячіших напрямки на фронті | LEDE: Від початку доби 6 липня на Слов'янському, Костянтинівському та Покровському напрямках відбулось найбільше бойових зіткнень.] (uk: Генштаб на…
      Від початку доби 6 липня на Слов'янському, Костянтинівському та Покровському напрямках відбулось найбільше бойових зіткнень.

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-06) U.S. Court of Appeals, 11th Cir.: State of Florida v. Secretary, US Department of Education
  - (2026-07-06) U.S. Court of Appeals, 11th Cir.: Bruce Henry v. Sheriff of Tuscaloosa County, Alabama
  - (2026-07-06) U.S. Court of Appeals, 11th Cir.: United States v. Emory Austin Carter
  - (2026-07-06) Arizona Supreme Court: State Farm v. Balzan
  - (2026-07-06) U.S. Court of Appeals, 1st Cir.: Rhode Island Truck Ctr v. Daimler Trucks North America
  - (2026-07-06) U.S. Court of Appeals, 1st Cir.: United States v. Fulcar

### IT, InfoSys & cybersecurity news (last 7 days) — 57 new of 57 total
  - (2026-07-06) [BleepingComputer] Phishing poses as big-brand job interview to steal Google accounts
      A phishing campaign is impersonating more than 30 well-known brands, including Adobe, Netflix, Coca-Cola, and OpenAI, in fake job interviews to steal Google account credentials from marketing professionals. [...]
  - (2026-07-06) [BleepingComputer] Fake IT support calls on Microsoft Teams push EtherRAT malware
      Threat actors are abusing Microsoft Teams voice calls by impersonating corporate IT support staff to trick employees into installing the EtherRAT malware, giving attackers initial access to corporate networks. [...]
  - (2026-07-06) [BleepingComputer] Vietnam arrests suspects behind HiAnime anime piracy service
      ​Vietnamese authorities have arrested and are prosecuting seven suspects believed to have run HiAnime, the largest anime piracy streaming service before its shutdown in June. [...]
  - (2026-07-06) [BleepingComputer] Software Is Now Written at the Speed of Thought. Security Isn't.
      Every evolution in software development has reduced the friction between an idea and a deployable application. AI may remove the final barrier, but it also removes many of the moments where security decisions have tradit…
  - (2026-07-06) [BleepingComputer] Max severity Adobe ColdFusion flaw now exploited in attacks
      Attackers are now exploiting a maximum-severity Adobe ColdFusion vulnerability tracked as CVE-2026-48282, according to vulnerability intelligence company KEVIntel. [...]
  - (2026-07-06) [The Hacker News] Iran-Linked Hackers Use New Cavern C2 Framework to Target Israeli Organizations
      An Iranian hacking group affiliated with Iran's Ministry of Intelligence and Security (MOIS) has been wielding a previously undocumented modular command-and-control (C2) framework dubbed Cavern (aka Cav3rn) targeting Isr…

### GDELT GKG — themes / entities / watch areas — 48 new of 48 total
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Donald Trump power grab mirrors King George III today | Crookwell Gazette
      crookwellgazette.com.au · English · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Invisible organisation boosts economy by $2m a day
      bluemountainsgazette.com.au · English · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Kuolleeksi julistettu taapero löytyi hengissä ruumishuoneelta Yhdysvalloissa
      kymensanomat.fi · Finnish · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Guatemala : Arévalo ratificó como prioridad protección medioambiental
      prensa-latina.cu · Spanish · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] Dems Rescind Backing After Platner Sexual Assault Allegation
      wflaorlando.iheart.com · English · tone NA
  - (2026-07-06) [Israel-Iran-Hezbollah axis · themes] 热议知名借名买房律师推荐 ， 哪家性价比高值得选择
      163.com · Chinese · tone NA

### Government Action: Sanctions + Procurement + Foreign Agents — 46 new of 114 total
  - (2026-07-01) [OFAC] Counter Narcotics Designations; Counter Terrorism Designations and Designation Update - Office of Foreign Assets Control (.gov)
      Counter Narcotics Designations; Counter Terrorism Designations and Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-01) [OFAC] Reminder to File the 2026 Annual Report of Blocked Property - Office of Foreign Assets Control (.gov)
      Reminder to File the 2026 Annual Report of Blocked Property Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act…
      Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) Office of Foreign A…
  - (2026-06-29) [OFAC] Launch of OFAC Reconsideration Portal - Office of Foreign Assets Control (.gov)
      Launch of OFAC Reconsideration Portal Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Mexican Cartel Fuel Smuggling Schemes - Office of Foreign Assets Control (.gov)
      Mexican Cartel Fuel Smuggling Schemes Office of Foreign Assets Control (.gov)
  - (2026-06-29) [OFAC] OFAC Quick-Reference Guide: Delisting Petitions- Best Practices - Office of Foreign Assets Control (.gov)
      OFAC Quick-Reference Guide: Delisting Petitions- Best Practices Office of Foreign Assets Control (.gov)

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-06) [Badawi David] Form 4 (Reporting)
      filed 2026-07-06 23:34 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0001193125-26-296594 Size: 5 KB
  - (2026-07-06) [Sight Sciences, Inc.] Form 4 (Issuer)
      filed 2026-07-06 23:34 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0001193125-26-296594 Size: 5 KB
  - (2026-07-06) [Douglas William W III] Form 4 (Reporting)
      filed 2026-07-06 23:34 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0000935703-26-000084 Size: 5 KB
  - (2026-07-06) [DOLLAR TREE, INC.] Form 4 (Issuer)
      filed 2026-07-06 23:34 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0000935703-26-000084 Size: 5 KB
  - (2026-07-06) [Taylor Brenton] Form 4 (Reporting)
      filed 2026-07-06 23:33 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0001193125-26-296593 Size: 5 KB
  - (2026-07-06) [Sight Sciences, Inc.] Form 4 (Issuer)
      filed 2026-07-06 23:33 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0001193125-26-296593 Size: 5 KB

### Conflict & unrest (GDELT, last 48h) — 40 new of 40 total
  - (2026-07-06) [United States] CSP seeks information in reported fight with tow truck driver
      domain: canoncitydailyrecord.com · language: English · tone:
  - (2026-07-06) [Australia] Donald Trump power grab mirrors King George III today | Crookwell Gazette
      domain: crookwellgazette.com.au · language: English · tone:
  - (2026-07-06) [Australia] Invisible organisation boosts economy by $2m a day
      domain: bluemountainsgazette.com.au · language: English · tone:
  - (2026-07-06) [United States] Dems Rescind Backing After Platner Sexual Assault Allegation
      domain: wflaorlando.iheart.com · language: English · tone:
  - (2026-07-06) [Canada] CUPE slams school board over cuts as administrative salaries climb
      domain: timminspress.com · language: English · tone:
  - (2026-07-06) [Australia] Death toll from Venezuela quakes passes 3500
      domain: thecourier.com.au · language: English · tone:

### Paper Trading Scorecard — 38 new of 138 total
  - (2026-07-06) [Polymarket] Strait of Hormuz traffic returns to normal by August 31?
      This market will resolve to “Yes” if IMF Portwatch publishes a 7-day moving average of transit calls (“Arrivals of Ships”) for the Strait of Hormuz equal to or above 60 for any date between market creation and August 31,…
  - (2026-07-06) [Polymarket] Will James Talarico win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-06) [Polymarket] Will Austin Reaves play for the Cleveland Cavaliers in 2026-27?
      This market will resolve to the next team Austin Reaves officially joins by October 31, 2026, 11:59 PM ET. If Austin Reaves does not officially join a new team by October 31, 2026, 11:59 PM ET, this market will resolve t…
  - (2026-07-06) [Polymarket] Will Switzerland win the 2026 FIFA World Cup?
      This market will resolve according to the national team that wins the 2026 FIFA World Cup. If at any point it becomes impossible for this team to win the FIFA World Cup based on the rules of FIFA (e.g., they are eliminat…
  - (2026-07-06) [Polymarket] Opensea FDV above $100M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Opensea's token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token must be activ…
  - (2026-07-06) [Polymarket] Will USA be eliminated in the Round of 16 of the World Cup?
      This market will resolve according to the stage of the 2026 FIFA World Cup at which USA is eliminated. If USA wins the tournament, this market will resolve to 'Champion'. If USA is disqualified, withdraws, is removed fro…

### U.S. Federal Action — 30 new of 30 total
  - (2026-07-06) Improvements to Rules on Recoupment of Benefit Overpayments
      The Pension Benefit Guaranty Corporation (PBGC) is proposing to improve its rules on recoupment of benefit overpayments under PBGC's insurance program for single-employer terminated plans trusteed by PBGC. These proposed…
  - (2026-07-06) Rescission of Guidelines on Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964, as Amended
      The Equal Employment Opportunity Commission ("EEOC" or "Commission") is rescinding its regulations regarding Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964 ("Guidelines"), and removing it…
  - (2026-07-06) Presidential Determination on Assistance to Venezuela Consistent With the Trafficking Victims Protection Act of 2000
  - (2026-07-06) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Angling Category Southern New England Area Trophy Fishery for 2026
      NMFS closes the Angling category Southern New England area fishery for large medium and giant ("trophy" (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length or greater)) Atlantic bluefin tuna (BFT). This…
  - (2026-07-06) Nondiscrimination in Federally Assisted Programs of NASA-Effectuation of Title VI of the Civil Rights Act of 1964
      NASA is amending its regulation implementing Title VI of the Civil Rights Act of 1964 (Title VI) for federally assisted programs to conform more closely to the statutory text and recent revisions by the Department of Jus…
  - (2026-07-06) Amendment of Using Agency and Controlling Agency for Restricted Areas R-5301, R-5302A, R-5302B, and R-5302C; NC
      This action amends the using agency and controlling agency descriptions listed for restricted areas R-5301, R-5302A, R-5302B, and R-5302C, NC. This action does not change any boundaries, altitudes, times of designation,…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-07-06) Will United States win on 2026-07-06?
      yes price: 36% · 24h volume: $10,789,922 · resolves 2026-07-07
  - (2026-07-06) United States vs. Belgium: Team to Advance
      yes price: 54% · 24h volume: $10,303,208 · resolves 2026-07-07
  - (2026-07-06) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $9,687,880 · resolves 2026-07-20
  - (2026-07-06) Will Portugal win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $9,658,597 · resolves 2026-07-20
  - (2026-07-06) Will USA win the 2026 FIFA World Cup?
      yes price: 3% · 24h volume: $6,881,622 · resolves 2026-07-20
  - (2026-07-06) Will Norway win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $6,400,911 · resolves 2026-07-20

### USGS earthquakes (M4.5+, past day) — 11 new of 11 total
  - (2026-07-06) M 5.8 - 48 km SSW of Sarangani, Philippines
      M5.8 · 48 km SSW of Sarangani, Philippines · depth 35 km
  - (2026-07-06) M 5.4 - 65 km SSW of Sarangani, Philippines
      M5.4 · 65 km SSW of Sarangani, Philippines · depth 35 km
  - (2026-07-06) M 5.1 - 56 km W of La Ligua, Chile
      M5.1 · 56 km W of La Ligua, Chile · depth 20.998 km
  - (2026-07-06) M 5.1 - 211 km ESE of Hihifo, Tonga
      M5.1 · 211 km ESE of Hihifo, Tonga · depth 10 km
  - (2026-07-06) M 4.9 - 216 km NE of Port Mathurin, Mauritius
      M4.9 · 216 km NE of Port Mathurin, Mauritius · depth 10 km
  - (2026-07-06) M 4.9 - Southwest Indian Ridge
      M4.9 · Southwest Indian Ridge · depth 10 km

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-06) [Marginal Revolution] Ilya Somin defends the American Revolution
      1. Far from retarding the abolition of slavery, the Revolution actually accelerated it. Its triumph gave a big boost to Enlightenment liberalism, which inspired the First Emancipation in the US (the abolition of slavery…
  - (2026-07-06) [Marginal Revolution] Monday assorted links
      1. Advice for aspiring policy analysts. 2. Ten underrated history books. 3. AI superforecasters. 4. Fable makes a movie out of Last and First Men. 5. A lot of them should have been fired anyway. 6. The world’s first full…
  - (2026-07-06) [Marginal Revolution] Capital Gains Can Be Labor Income
      Zwick and Zidar argue that a substantial share of the decline in labor share can be accounted for by changing forms of pay, including pass-throughs and equtiy compensation. In particular, if an employee is paid in stock…
  - (2026-07-06) [Conversable Economist] Shifts in Non-Cash Payments
      The most recent Federal Reserve Payment Study has published data for 2024 on “core noncash payment methods used in the United States by consumers, businesses, and governments, including payments by general-purpose and pr…
  - (2026-07-04) [Conversable Economist] Declaration of Independence: Track Changes Version
      Thomas Jefferson wrote out the first draft of the Declaration of Independence, but he did not do so alone and without guidance. After all, he had been a member of the Continental Congress that summer, listening to the di…
  - (2026-07-03) [Conversable Economist] What Does the Declaration Mean by Pursuit of Happiness?
      I wrote this short essay about the “pursuit of happiness” for the editorial page of the StarTribune newspaper, where it was published on July 3. _____ Opinion | What did the founders mean by the pursuit of happiness? The…

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 4 new of 40 total
  - (2026-07-06) MOVER ▲ Larry Page — $299.37B (+$5.97B since yesterday)
      United States · Technology · source: Google
  - (2026-07-06) MOVER ▲ Sergey Brin — $276.11B (+$5.49B since yesterday)
      United States · Technology · source: Google
  - (2026-07-06) MOVER ▼ Bernard Arnault & family — $150.28B ($-1.82B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-06) MOVER ▲ Carlos Slim Helu & family — $124.68B (+$1.60B since yesterday)
      Mexico · Telecom · source: Telecom

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 8 total
  - (2026-07-01) CVE-2026-45659 · Microsoft SharePoint Server: Microsoft SharePoint Server Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint Server · CISA remediation by 2026-07-04
  - (2026-06-29) CVE-2026-48558 · SimpleHelp SimpleHelp: SimpleHelp Authentication Bypass Vulnerability
      vendor: SimpleHelp · product: SimpleHelp · CISA remediation by 2026-07-02
  - (2026-06-25) CVE-2026-12569 · PTC Windchill and FlexPLM: PTC Windchill and FlexPLM Improper Input Validation Vulnerability
      vendor: PTC · product: Windchill and FlexPLM · CISA remediation by 2026-06-28
  - (2026-06-25) CVE-2026-20230 · Cisco Unified Communications Manager: Cisco Unified Communications Manager Server-Side Request Forgery (SSRF) Vulnerability
      vendor: Cisco · product: Unified Communications Manager · CISA remediation by 2026-06-28

### WHO Disease Outbreak News — 3 new of 40 total
  - (2026-07-03) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with sustained transmission and increasing numbers of reported cases. As of 1 July, a cumulative of 1460 co…
  - (2026-07-02) Hantavirus outbreak linked to cruise ship travel, Multi-locations
      This is the fifth Disease Outbreak News posting on the Andes hantavirus (ANDV) outbreak linked to the cruise ship M/V Hondius. The outbreak identification followed the notification to the World Health Organization (WHO)…
  - (2026-06-25) Nipah virus disease - India
      On 11 June 2026, the Kerala State Health Department confirmed one laboratory confirmed case of Nipah virus (NiV) infection in Kozhikode district, Kerala State, India. The case is an adult male who developed symptoms on 3…

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-07-06) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=26, 14d-median=26; carrying terms: proposing, proposes, amend, comments, unless, safety, needed, program, associated, document, fireworks, guard
- state_bills: today=0, 7d-median=152, 14d-median=152; carrying terms: personal, improve, things, water, medical, employees, service, amending, unless, process, awareness, safety
- state_news: today=419, 7d-median=452, 14d-median=452; carrying terms: gives, proposing, chris, personal, large, signing, improve, grown, water, medical, force, means
- local_news: today=236, 7d-median=222, 14d-median=222; carrying terms: voters, working, assault, network, springs, story, missing, airport, later, scene, every, georgia
- foreign_news: today=1038, 7d-median=1038, 14d-median=1038; carrying terms: supporting, large, personal, improve, concern, force, voters, massive, legislate, share, default, billow
- chinese_internal: today=252, 7d-median=281, 14d-median=281; carrying terms: blank, cbmiyefvx, cbmizefvx, europe, global, title, people, cbmiy, cbmizkfvx, cbmiw, market, cbmiykfvx
- russian_internal: today=882, 7d-median=915, 14d-median=915; carrying terms: novayagazeta, istories, bloomberg, times, street, politico, found, gazeta, russian, journal, error, client
- ukrainian_internal: today=135, 7d-median=122, 14d-median=122; carrying terms: railway, destroyed, operation, saying, battlefield, service, conference, working, httperror, prime, meeting, program
- ukraine_theater: today=578, 7d-median=578, 14d-median=578; carrying terms: mqnotrm, qtzzsf, wklwy, klwrysnfib, large, grvdztjbnx, wreytvuz, bmzmz, dovelxcxvuakftmtjqohrfde, dovepmvtnqexl, force, cbmilgfbvv
- paper_bets: today=138, 7d-median=139, 14d-median=139; carrying terms: decrease, resolve, theme, listed, openai, officially, mayfield, control, stafford, speaker, anthropic, henry
- weather: today=147, 7d-median=173, 14d-median=173; carrying terms: morgan, houston, water, rainfall, afdhgx, detroit, service, tulsa, forecast, northwest, pinal, evening
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, implied, rates, total, supply, money, payrolls, personal, vixcls, latest, dexchus, payems
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: commodities, china, crypto, rates, large, yield, range, natural, silver, crude, nasdaq, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=114, 7d-median=104, 14d-median=104; carrying terms: ridge, prohibiting, restrictive, mufswgh, billing, health, transnistria, embargo, comments, blank, operation, control
- congressional_trades: today=1, 7d-median=68, 14d-median=68
- billionaires: today=40, 7d-median=40, 14d-median=40; carrying terms: oracle, exchange, yanai, devasini, diversified, family, bloomberg, mexico, steve, holdings, zuckerberg, yesterday
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: blanche, court, supreme, hernandez, corporation, association, company, appeals, trade, services, state, american
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: holdings, accno, filed, issuer, reporting
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: raised, house, robinson, group, committee, pinkston, sherrod, ocasio, disbursements, alexandria, jonathan, chartered
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=48, 7d-median=25, 14d-median=25; carrying terms: spanish, english, russian, themes, trump, hezbollah, greek, italian, chinese, israel
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=40, 7d-median=40, 14d-median=40; carrying terms: kingdom, domain, australia, india, english, language, trump, canada
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=4, 7d-median=28, 14d-median=28; carrying terms: ground, position, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: infections, unknown, cambodia, august, districts, organs, ethiopian, discharged, healthy, total, anthrax, kinshasa
- cisa_kev: today=8, 7d-median=9, 14d-median=9; carrying terms: control, improper, vulnerability, traversal, manager, cisco, vendor, authentication, access, remediation, injection, product
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=177, 7d-median=120, 14d-median=120; carrying terms: cambodia, hungary, finland, mexico, tropical, gabon, speed, philippines, minor, estonia, serbia, republic
- usgs_quakes: today=11, 7d-median=14, 14d-median=14; carrying terms: depth, japan, philippines
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, resolves, argentina, world, volume, colombia, minister, ethiopia, prime, belgium
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: economist, revolution, https, income, conversable, marginal, class, world, conversableeconomist
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: models, large, krebs, netnut, control, bleepingcomputer, problem, company, malware, multiple, policy, field
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: bradley, biggs, morgan, rosen, george, laura, chris, brian, janice, nicholas, bergman, health
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: today, either, decision, market, placed, identify, module, converges, placement, paper, markets, evidence

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-24] Fed speeches: Cook, Welcome Remarks
- [2026-06-24] Fed press (events + announcements): Federal Reserve Board's annual bank stress test confirms that large banks are well positioned to weather a severe recession and able to continue to lend to households and businesses
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board issues enforcement action with employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Jiko Group, Inc.
- [2026-06-27] ECB press: Isabel Schnabel: Is inflation back?
- [2026-06-29] ECB press: Christine Lagarde: Back to basics in an uncertain environment
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2028
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2027
- [2026-06-30] Fed press (events + announcements): Agencies release list of distressed or underserved nonmetropolitan middle-income geographies
- [2026-07-01] Fed press (events + announcements): Federal Reserve issues initial findings from its 2025 triennial payments study
- [2026-07-02] ECB press: Frank Elderson: The green transition – benefits and barriers
- [2026-07-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Small Business Bank and announces termination enforcement actions with BNP Paribas S.A., BNP Paribas USA, Inc., BNP Paribas Securities Corp., and Community Bankshares, Inc.
- [2026-07-02] ECB press: Piero Cipollone: The digital transformation of money, payments and finance
- [2026-07-02] ECB press: Christine Lagarde: Interview with Les Échos
- [2026-07-06] Fed speeches: Waller, Two Thoughts on the Transmission of Monetary Policy
- [2026-07-06] ECB press: Philip R. Lane: AI and monetary policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*