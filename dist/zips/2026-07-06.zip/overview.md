# WORLDSCOPE morning brief — 2026-07-06

## Headline
3979 new items across 28 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (865) · Russian Internal News (state + in-exile) (843) · Ukraine Theater (total-war monitoring) (441) · World leaders & government officials (324) · State-Level News (267) · Chinese Internal News (242) · Local News: St. Louis + Atlanta (201) · GDACS — global disaster alerts (156) · U.S. Weather + Severe / Climate Outlooks (112) · Ukrainian Internal News (national + local Kyiv) (109) · GDELT GKG — themes / entities / watch areas (61) · Court opinions of consequence (federal & state) (60)

## What changed today
### International News + Multilateral Institutions — 865 new of 1008 total
  - (2026-07-06) [Global] Ukraine warns of interceptor missile shortage as 19 killed in Kyiv region
      President Zelensky says Sunday's "massive Russian attack" on Kyiv consisted of 68 missiles and 351 strike drones.
  - (2026-07-06) [Global] Huge crowds fill Tehran streets for Khamenei's funeral procession
      Many people were waving Iranian flags and red banners symbolising vengeance for the former supreme leader's war death.
  - (2026-07-06) [Global] 'I ate ketchup and cheese,' says Venezuelan girl trapped under quake rubble for 32 hours
      Fabiana was trapped in the rubble of a 10-storey residential building after two earthquakes rocked Venezuela in June.
  - (2026-07-06) [Global] Australian PM apologises for 'inappropriate' comments about Kylie Minogue
      Albanese has apologised 'unequivocally' after his remarks prompted a backlash.
  - (2026-07-05) [Global] Marine Le Pen appeal verdict: Why this moment matters for France
      The leader of France's National Rally leads the opinion polls ahead of the 2027 presidential election and will now find out if she can stand.
  - (2026-07-05) [Global] A global hub for fake luxury goods, Vietnam cracks down on its black market
      The Trump administration wants Vietnam to stamp out its booming counterfeit industry. Locals are divided.

### Russian Internal News (state + in-exile) — 843 new of 846 total
  - (2026-07-06) Украинские телеграм-каналы сообщили о первом ударе дронов по Омскому НПЗ — крупнейшему в России | LEDE: По данным украинских мониторинговых телеграм-каналов Exilenova+ и Supernova+, дроны вп] (ru: Укр…
      По данным украинских мониторинговых телеграм-каналов Exilenova+ и Supernova+, дроны впервые атаковали Омский нефтеперерабатывающий завод.
  - (2026-07-06) В Туве пять дней ищут двух пропавших 12-летних девочек. Основная версия — они могли утонуть в реке. Местные жители пытались ворваться в дом, где, по их мнению, находились девочки. На это им ука] (ru:…
      В Кызыле две 12-летние девочки вечером 1 июля ушли из дома и и не вернулись. Судя по камерам видеонаблюдения, они направлялись в сторону набережной, расположенной на берегу Енисея, и дамбы. Дальнейший их маршрут неизвест…
  - (2026-07-06) Хакеры из России взломали электронную почту чиновников и дипломатов Великобритании. Полученные данные выставили на продажу в даркнете | LEDE: Хакеры из России взломали электронные почтовые я] (ru: Хак…
      Хакеры из России взломали электронные почтовые ящики правительственных и региональных чиновников Великобритании, включая сотрудников министерства иностранных дел, которые работают за пределами страны, пишет The Telegraph…
  - (2026-07-06) Российские авиакомпании будут менять иностранные двигатели на SSJ-100 за свой счет. Привлекать бюджетные средства не планируется | LEDE: Замену двигателей французского производства на россий] (ru: Рос…
      Замену двигателей французского производства на российские на самолетах SSJ-100 оплатят сами авиакомпании, заявил глава Объединенной авиастроительной корпорации (ОАК, входит в «Ростех») Вадим Бадеха. Выделять на это бюдже…
  - (2026-07-06) Бразилия вылетает, Неймар плачет. ФИФА отменяет дисквалификацию американского футболиста — после звонка Дональда Трампа. Что там на ЧМ? Суперкоротко | LEDE: Кто как с кем сыграл. Норвегия об] (ru: Бра…
      Кто как с кем сыграл. Норвегия обыграла Бразилию 2:1, Холанд забил оба гола норвежцев, его голевая серия в турнирных матчах за сборную продолжается уже 14 матчей. Единственный гол у бразильцев забил Неймар (с пенальти) —…
  - (2026-07-06) Рамзан Кадыров в начале войны опубликовал видео совещания «в семи километрах от Киева». Этот ролик записали в подвале секретной тюрьмы в Чечне, выяснила «Новая газета Европа» | LEDE: Видео с] (ru: Рам…
      Видео совещания главы Чечни Рамзана Кадырова с чеченскими командирами «под Киевом», которое распространили чеченские СМИ в начале большой войны России с Украиной, снимали в Чечне. Об этом говорится в большом исследовании…

### Ukraine Theater (total-war monitoring) — 441 new of 497 total
  - (2026-07-06) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-05) [FIRMS] thermal anomaly 51.413, 34.536 (FRP 2.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 2.8 MW
  - (2026-07-05) [FIRMS] thermal anomaly 51.410, 34.538 (FRP 3.22 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 3.22 MW
  - (2026-07-05) [FIRMS] thermal anomaly 51.376, 24.877 (FRP 1.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 1.72 MW
  - (2026-07-05) [FIRMS] thermal anomaly 49.922, 24.065 (FRP 3.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 3.18 MW
  - (2026-07-05) [FIRMS] thermal anomaly 49.920, 24.071 (FRP 0.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 0.71 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 267 new of 280 total
  - (2026-07-04) [California] Governor Newsom announces deployment of California firefighters and equipment to Colorado, as sister state battles wildfires
      Source
  - (2026-07-04) [California] Gobernador Gavin Newsom conmemora el Día de la Independencia con una llamada a renovar la lucha por defender la democracia
      Source
  - (2026-07-04) [California] Governor Gavin Newsom marks Fourth of July with a call for a renewed fight to defend democracy
      Source
  - (2026-07-06) [California] California schools are the nation’s most segregated, despite voluntary busing programs
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2023/07/072023-EV-School-Bus-MG-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt…
  - (2026-07-06) [California] Judge rejects California tribes’ latest attempt to kill blackjack at cardrooms
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/07/052126-Cardroom-Protest-MG-CM-02.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-imag…
  - (2026-07-04) [California] Estos estudiantes universitarios de Los Ángeles usan el transporte público para ahorrar dinero. Así son sus viajes.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/042826-Student-Transit-MR-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…

### Chinese Internal News — 242 new of 242 total
  - (2026-07-04) Caixin Global – Latest China News & Headlines - Caixin Global
      Caixin Global – Latest China News & Headlines Caixin Global
  - (2026-07-04) 责编：金 晨 邮箱：gtbhwb@people.cn - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMihAFBVV95cUxNTEJuZ0lEb2xuU0FhVlp5RElvT284dGhBY0M5eEdtWk1rUHUwaWZqYkwtZDZXTUkxd1BRS1VFbTF2UFlKTDBHb3lqa] (zh:…
      责编：金 晨 邮箱：gtbhwb@people.cn 人民日报
  - (2026-07-05) 矢志追求真理，始终把准前进方向（评论员观察） - 人民网观点 | LEDE: <a href="https://news.google.com/rss/articles/CBMicEFVX3lxTFBYaFpqY2VaMktsMU16ZTJ4T2ZWaFh0SmFNd2pLTHNiVUhHcG9rZDRiUmxRT3lhcjdaSW94cnRVdEU0Wi1oX2dMRHJkOEt5] (zh:…
      矢志追求真理，始终把准前进方向（评论员观察） 人民网观点
  - (2026-07-06) 公交站点设在绿化带里（身边事） - 人民网“领导留言板” | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE5JR2JjM2E2VlFmUXhTTTQ4cVoyWkFnWjh5Qk1NamhCLWRhcHpURXp2QzhsekZRTFhETnBneHZzS1FMdWpZMU5md1ZNcjNpaj] (zh:…
      公交站点设在绿化带里（身边事） 人民网“领导留言板”
  - (2026-07-06) 提升港口生产效率 天津海事升级“十项措施”赋能港产城融合 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTFBieE1FaFV1RlRkQmt6Mld3SHhLendOQ1R6eE8xRHdUX3YxbllkMmh0Ul9LanJtaElWUzVrR1JyNUc2Ymo0d2VDWmY0] (zh:…
      提升港口生产效率 天津海事升级“十项措施”赋能港产城融合 人民网
  - (2026-07-06) “草书第一神品”来了！赵佶《草书千字文》数字笔墨上线 - 灵境·人民艺术馆 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1ZdUo3a1VRRGgwQmxTV0NXNmwwNEJIUUFlU1NveWRvMDBKNXVMSmZDNWJldlZCNU5ETmxrdkpMUnRKbnVZY282Z] (zh:…
      “草书第一神品”来了！赵佶《草书千字文》数字笔墨上线 灵境·人民艺术馆

### Local News: St. Louis + Atlanta — 201 new of 202 total
  - (2026-07-06) [St. Louis] Mourners throng funeral procession in Tehran for Iran's Supreme Leader Ayatollah Ali Khamenei
      Khamenei's flag-draped coffin sat on board a truck decorated to resemble the ornamental grating that surrounds the shrine of an imam as mourners flocked the streets.
  - (2026-07-06) [St. Louis] North county teen gathering ends with police shooting 2; 9 arrested
      Police said an officer shot two teens after perceiving a threat while responding to a large gathering of teens in north St. Louis County.
  - (2026-07-06) [St. Louis] Man dies, 3 others injured in lightning strike on Florida beach
      A lightning strike at Fort Myers Beach killed a man and injured three of his family members Friday, officials said.
  - (2026-07-06) [St. Louis] Paul McCartney sang a Beatles hit at Taylor Swift's wedding that he hadn't performed in 62 years
      As The Beatles ventured into different sounds and eventually stopped touring altogether, the song was scrapped from the setlist.
  - (2026-07-06) [St. Louis] 2 killed in quadruple shooting near MetroLink in north St. Louis County
      A late-night altercation near the North Hanley MetroLink Station ended in gunfire, leaving two people dead and two others injured, police said.
  - (2026-07-06) [St. Louis] 41 minors detained on Fourth of July as St. Louis enforces new downtown curfew
      More than 40 minors were detained as St. Louis police enforced the city's new downtown curfew during the Fourth of July weekend.

### GDACS — global disaster alerts — 156 new of 171 total
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)

### U.S. Weather + Severe / Climate Outlooks — 112 new of 114 total
  - (2026-07-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-06) [Moderate] Special Weather Statement: Special Weather Statement issued July 6 at 8:22AM EDT by NWS Wakefield VA
      At 822 AM EDT, Doppler radar was tracking a cluster of strong thunderstorms over Secretary, or near Hurlock, moving east at 10 mph. HAZARD...Wind gusts up to 40 mph, pea size hail, heavy rain, and frequent lightning. SOU…
  - (2026-07-06) [Moderate] Heat Advisory: Heat Advisory issued July 6 at 8:22AM EDT until July 6 at 8:00PM EDT by NWS Peachtree City GA
      * WHAT...Heat index values up to 107 expected. * WHERE...Laurens, Montgomery, Wheeler, Wilkinson, Emanuel, Jefferson, Johnson, Treutlen, Washington, and Toombs Counties. * WHEN...From noon today to 8 PM EDT this evening.…
  - (2026-07-06) [Severe] Flash Flood Warning: Flash Flood Warning issued July 6 at 7:56AM EDT until July 6 at 2:00PM EDT by NWS Cleveland OH
      FFWCLE The National Weather Service in Cleveland has issued a * Flash Flood Warning for... Northeastern Lucas County in northwestern Ohio... Ottawa County in northwestern Ohio... * Until 200 PM EDT Monday. * At 756 AM ED…
  - (2026-07-06) [Moderate] High Surf Warning: High Surf Warning issued July 6 at 9:49PM ChST until July 9 at 4:00PM ChST by NWS Tiyan GU
      * WHAT...Dangerously large breaking waves up to 25 feet in the surf zone with significant coastal flooding. * WHERE...Guam, Rota, Tinian and Saipan. * WHEN...For the Coastal Flood Warning, until 4 PM ChST Wednesday. For…
  - (2026-07-06) [Severe] Coastal Flood Warning: Coastal Flood Warning issued July 6 at 9:49PM ChST until July 8 at 4:00PM ChST by NWS Tiyan GU
      * WHAT...Dangerously large breaking waves up to 25 feet in the surf zone with significant coastal flooding. * WHERE...Guam, Rota, Tinian and Saipan. * WHEN...For the Coastal Flood Warning, until 4 PM ChST Wednesday. For…

### Ukrainian Internal News (national + local Kyiv) — 109 new of 117 total
  - (2026-07-06) В Ryanair назвали аеропорти, які найбільше страждають від затримок через нову систему в’їзду ЄС | LEDE: Ірландська бюджетна авіакомпанія Ryanair назвала європейські аеропорти, де пасажири стика] (uk:…
      Ірландська бюджетна авіакомпанія Ryanair назвала європейські аеропорти, де пасажири стикаються з тривалими затримками через нову цифрову систему в’їзду/виїзду ЄС.
  - (2026-07-06) Міноборони: У липні військові отримають додаткові 10 тисяч за роботу в тилу | LEDE: В Міноборони повідомили, що у липні військовослужбовці отримають або уже отримали додаткові 10 000 грн за роб] (uk:…
      В Міноборони повідомили, що у липні військовослужбовці отримають або уже отримали додаткові 10 000 грн за роботу в тилу за червень.
  - (2026-07-06) У Києві з-під завалів деблокували тіло чоловіка: загиблих уже 13, поранених – 56 | LEDE: У Києві рятувальники деблокували тіло чоловіка після атаки РФ: 13 загиблих, 56 поранених, серед них 7 ді] (uk:…
      У Києві рятувальники деблокували тіло чоловіка після атаки РФ: 13 загиблих, 56 поранених, серед них 7 дітей.
  - (2026-07-06) Туск звернувся до опозиції: Не грайтеся з вогнем. Допомога Україні – в інтересах Польщі | LEDE: Прем'єр-міністр Польщі Дональд Туск на тлі скандалу з нібито таємною передачею його урядом ракет ] (uk:…
      Прем'єр-міністр Польщі Дональд Туск на тлі скандалу з нібито таємною передачею його урядом ракет до Patriot Україні нагадав, що військова допомога Києву є консенсусною політикою Варшави.
  - (2026-07-06) Іспанія очікує 100 мільйонів туристів цьогоріч | LEDE: В Іспанії очікують, що цього року країну відвідають 100 мільйонів іноземних туристів.] (uk: Іспанія очікує 100 мільйонів туристів цьогоріч)
      В Іспанії очікують, що цього року країну відвідають 100 мільйонів іноземних туристів.
  - (2026-07-06) Уряд Італії не хоче загострювати відносини зі США попри нові випади Трампа в бік Мелоні | LEDE: Глава МЗС Італії Антоніо Таяні та міністр оборони Гвідо Крозетто заявили, що Рим має зберігати ст] (uk:…
      Глава МЗС Італії Антоніо Таяні та міністр оборони Гвідо Крозетто заявили, що Рим має зберігати стабільні відносини зі США попри нові нападки президента Дональда Трампа на прем'єрку Джорджу Мелоні.

### GDELT GKG — themes / entities / watch areas — 61 new of 61 total
  - (2026-07-06) [Russia oil sanctions perimeter · themes] НПЗ у Ярославлі і Слободці уразили дрони СБУ 6 липня
      rbc.ua · Ukrainian · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · themes] في يوم واحد .. رفع 126 طن مخلفات وإزالة 328 إشغالًا و17 حالة تعدٍ ببني سويف
      dostor.org · Arabic · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · themes] Brent petrolün varili 72 dolardan işlem görüyor
      f5haber.com · Turkish · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · themes] Today . Az - Black Sea Petroleum announces end to Russian crude refining
      today.az · English · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · themes] OPEC+ agrees another modest output rise as oil prices fall back to pre - war levels
      euronews.com · English · tone NA
  - (2026-07-06) [Russia oil sanctions perimeter · themes] Study finds social media reveals users are queer before they know | Gloucester Advocate
      gloucesteradvocate.com.au · English · tone NA

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-02) U.S. Court of Appeals, Federal Cir.: Tracktime, LLC v. amazon.com Services LLC
  - (2026-07-02) U.S. Court of Appeals, 1st Cir.: Crosspoint Church v. Makin
  - (2026-07-02) U.S. Court of Appeals, 1st Cir.: St. Dominic Academy v. Makin
  - (2026-07-02) Supreme Court of Alabama: Col. Alan Spencer, in his official capacity as Chairman of the Alabama Alcoholic Beverage Control Board; Melissa Morrissette, in her official capacity as a member of the Alab…
  - (2026-07-02) Supreme Court of Alabama: In re: Amanda Busby v. City of Tuskegee
  - (2026-07-02) Supreme Court of Alabama: In re: Amanda Busby v. City of Tuskegee

### IT, InfoSys & cybersecurity news (last 7 days) — 57 new of 57 total
  - (2026-07-06) [The Hacker News] How to Evaluate an AI SOC Platform in 2026: 6 Capabilities That Separate Leaders from Bolt-On AI solutions
      Building a shortlist for an AI SOC evaluation can be tough. SIEM, SOAR, and pureplay AI SOC vendors are all saying the same thing. But behind the identical label sit very different products, from chat assistants bolted o…
  - (2026-07-06) [The Hacker News] Suspected China-Nexus Hackers Use Fake Indian Tax Filing Utility to Deploy DcRAT
      A suspected China-nexus threat activity cluster has been observed targeting Indian taxpayers, tax professionals, and corporate finance teams to deliver a remote access trojan designed to steal sensitive data from comprom…
  - (2026-07-06) [The Hacker News] New TrojPix Attack Leaks Data From Air-Gapped Systems via Video Cable Emissions
      Researchers at Shandong University have shown a fast new way to pull data off computers that are cut off from every network. The technique, called TrojPix, tweaks on-screen pixels in ways the eye cannot see, so that the…
  - (2026-07-06) [The Hacker News] New Java-Based QuimaRAT MaaS Built to Run on Windows, Linux, and macOS
      Cybersecurity researchers have flagged a novel Java-based remote access trojan (RAT) called QuimaRAT that's capable of targeting Windows, Linux, and macOS environments. According to LevelBlue, the cross-platform malware…
  - (2026-07-06) [The Hacker News] Opera GX Flaw Let Malicious Sites Auto-Install Mods to Steal Data From Visited Pages
      Researchers found a flaw in Opera GX, the gaming-focused version of the Opera browser, that let a malicious website silently install a browser add-on and use it to lift specific data from the pages a victim visits. In a…
  - (2026-07-06) [Cybersecurity Dive] Why schools are easy prey for hackers — and why they struggle to fight back
      Power plants and gas pipelines might receive more attention, but schools are arguably more vulnerable.

### Government Action: Sanctions + Procurement + Foreign Agents — 47 new of 108 total
  - (2026-07-01) [OFAC] Counter Narcotics Designations; Counter Terrorism Designations and Designation Update - Office of Foreign Assets Control (.gov)
      Counter Narcotics Designations; Counter Terrorism Designations and Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-01) [OFAC] Reminder to File the 2026 Annual Report of Blocked Property - Office of Foreign Assets Control (.gov)
      Reminder to File the 2026 Annual Report of Blocked Property Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act…
      Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) Office of Foreign A…
  - (2026-06-29) [OFAC] Launch of OFAC Reconsideration Portal - Office of Foreign Assets Control (.gov)
      Launch of OFAC Reconsideration Portal Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Mexican Cartel Fuel Smuggling Schemes - Office of Foreign Assets Control (.gov)
      Mexican Cartel Fuel Smuggling Schemes Office of Foreign Assets Control (.gov)
  - (2026-06-29) [OFAC] 1261 - Office of Foreign Assets Control (.gov)
      1261 Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 41 new of 142 total
  - (2026-07-06) [Polymarket] Will the Green Bay Packers win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-06) [Polymarket] Will James Talarico win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-06) [Polymarket] Will Austin Reaves play for the Cleveland Cavaliers in 2026-27?
      This market will resolve to the next team Austin Reaves officially joins by October 31, 2026, 11:59 PM ET. If Austin Reaves does not officially join a new team by October 31, 2026, 11:59 PM ET, this market will resolve t…
  - (2026-07-06) [Polymarket] Will Israeli forces withdraw from beyond the Litani River by December 31
      This market will resolve to "Yes" if Israel announces it has withdrawn all ground forces from Lebanese territory beyond the Litani River by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No". Fo…
  - (2026-07-06) [Polymarket] Will Bitcoin reach $120,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "High" price equal to or gr…
  - (2026-07-06) [Polymarket] Opensea FDV above $100M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Opensea's token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token must be activ…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-06) [Trevino de Vega Blanca] Form 4 (Reporting)
      filed 2026-07-06 12:22 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0000950103-26-010227 Size: 6 KB
  - (2026-07-06) [MILLICOM INTERNATIONAL CELLULAR SA] Form 4 (Issuer)
      filed 2026-07-06 12:22 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0000950103-26-010227 Size: 6 KB
  - (2026-07-06) [Lee Angela B] Form 4 (Reporting)
      filed 2026-07-06 12:20 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0001005817-26-000084 Size: 4 KB
  - (2026-07-06) [TOMPKINS FINANCIAL CORP] Form 4 (Issuer)
      filed 2026-07-06 12:20 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0001005817-26-000084 Size: 4 KB
  - (2026-07-06) [Dimovic Justine] Form 4 (Reporting)
      filed 2026-07-06 12:19 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0000950103-26-010226 Size: 6 KB
  - (2026-07-06) [MILLICOM INTERNATIONAL CELLULAR SA] Form 4 (Issuer)
      filed 2026-07-06 12:19 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0000950103-26-010226 Size: 6 KB

### U.S. Federal Action — 30 new of 30 total
  - (2026-07-06) Improvements to Rules on Recoupment of Benefit Overpayments
      The Pension Benefit Guaranty Corporation (PBGC) is proposing to improve its rules on recoupment of benefit overpayments under PBGC's insurance program for single-employer terminated plans trusteed by PBGC. These proposed…
  - (2026-07-06) Rescission of Guidelines on Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964, as Amended
      The Equal Employment Opportunity Commission ("EEOC" or "Commission") is rescinding its regulations regarding Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964 ("Guidelines"), and removing it…
  - (2026-07-06) Presidential Determination on Assistance to Venezuela Consistent With the Trafficking Victims Protection Act of 2000
  - (2026-07-06) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Angling Category Southern New England Area Trophy Fishery for 2026
      NMFS closes the Angling category Southern New England area fishery for large medium and giant ("trophy" (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length or greater)) Atlantic bluefin tuna (BFT). This…
  - (2026-07-06) Nondiscrimination in Federally Assisted Programs of NASA-Effectuation of Title VI of the Civil Rights Act of 1964
      NASA is amending its regulation implementing Title VI of the Civil Rights Act of 1964 (Title VI) for federally assisted programs to conform more closely to the statutory text and recent revisions by the Department of Jus…
  - (2026-07-06) Amendment of Using Agency and Controlling Agency for Restricted Areas R-5301, R-5302A, R-5302B, and R-5302C; NC
      This action amends the using agency and controlling agency descriptions listed for restricted areas R-5301, R-5302A, R-5302B, and R-5302C, NC. This action does not change any boundaries, altitudes, times of designation,…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-07-06) Will Norway win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $11,566,656 · resolves 2026-07-20
  - (2026-07-06) Will USA win the 2026 FIFA World Cup?
      yes price: 3% · 24h volume: $5,072,923 · resolves 2026-07-20
  - (2026-07-06) Will England win the 2026 FIFA World Cup?
      yes price: 14% · 24h volume: $4,722,277 · resolves 2026-07-20
  - (2026-07-06) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $4,289,503 · resolves 2026-07-20
  - (2026-07-06) Will Portugal win the 2026 FIFA World Cup?
      yes price: 6% · 24h volume: $3,602,197 · resolves 2026-07-20
  - (2026-07-06) Will Belgium win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $3,220,085 · resolves 2026-07-20

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-07-06) M 5.8 - 48 km SSW of Sarangani, Philippines
      M5.8 · 48 km SSW of Sarangani, Philippines · depth 35 km
  - (2026-07-05) M 5.8 - 274 km SE of Levuka, Fiji
      M5.8 · 274 km SE of Levuka, Fiji · depth 685.692 km
  - (2026-07-06) M 5.4 - 65 km SSW of Sarangani, Philippines
      M5.4 · 65 km SSW of Sarangani, Philippines · depth 35 km
  - (2026-07-05) M 5.0 - 106 km NW of Coquimbo, Chile
      M5.0 · 106 km NW of Coquimbo, Chile · depth 10 km
  - (2026-07-05) M 5.0 - 26 km NNW of Mianzhu, Deyang, Sichuan, China
      M5.0 · 26 km NNW of Mianzhu, Deyang, Sichuan, China · depth 10 km
  - (2026-07-05) M 5.0 - 23 km NNW of Mianzhu, Deyang, Sichuan, China
      M5.0 · 23 km NNW of Mianzhu, Deyang, Sichuan, China · depth 10 km

### World News (by country, top stories) — 6 new of 6 total
  - (2026-07-06) [South Korea] DAY6 Member Dowoon Breaks Silence on Dating and Marriage Rumors During Concert
      kpopstarz.com · English
  - (2026-07-06) [South Korea] Blogs | Koreabridge
      koreabridge.net · English
  - (2026-07-06) [South Korea] [ Deep dive ] Korea Democrats soul - search after losing the youth vote
      english.hani.co.kr · English
  - (2026-07-06) [South Korea] Blue House pushes back against US claims about Coupang after White House says it deeply concerned
      english.hani.co.kr · English
  - (2026-07-06) [South Korea] [ Column ] The Tumen is the new Yalu , the Yalu is the new Pearl River
      english.hani.co.kr · English
  - (2026-07-06) [South Korea] [ Editorial ] Seoul must respond firmly to U biased claims about Coupang
      english.hani.co.kr · English

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-06) [Marginal Revolution] Capital Gains Can Be Labor Income
      Zwick and Zidar argue that a substantial share of the decline in labor share can be accounted for by changing forms of pay, including pass-throughs and equtiy compensation. In particular, if an employee is paid in stock…
  - (2026-07-06) [Marginal Revolution] The Troubled History of Government Equity in Technology
      Even though Germany privatized Deutsche Telekom in 1996, the federal government retained a substantial ownership stake. This partial state ownership status, which remains to this day, presents a textbook example of how t…
  - (2026-07-06) [Marginal Revolution] The history of heat deaths in Europe (from my email)
      I will not double indent, all of what follows is from economic historian Daniel Gallardo Albarrán of the Netherlands: “…you posted a link to an article on how Europe became the world champion of heat deaths. Something th…
  - (2026-07-04) [Conversable Economist] Declaration of Independence: Track Changes Version
      Thomas Jefferson wrote out the first draft of the Declaration of Independence, but he did not do so alone and without guidance. After all, he had been a member of the Continental Congress that summer, listening to the di…
  - (2026-07-03) [Conversable Economist] What Does the Declaration Mean by Pursuit of Happiness?
      I wrote this short essay about the “pursuit of happiness” for the editorial page of the StarTribune newspaper, where it was published on July 3. _____ Opinion | What did the founders mean by the pursuit of happiness? The…
  - (2026-07-02) [Conversable Economist] US Exports, Imports, and Tariffs: The 250-Year Perspective
      Douglas A. Irwin offers a brisk overview of a great American tradition–specifically, “America’s been arguing over trade for more than 250 years” (Peterson Institute for International Economics, July 1, 2026). I won’t reh…

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 8 total
  - (2026-07-01) CVE-2026-45659 · Microsoft SharePoint Server: Microsoft SharePoint Server Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint Server · CISA remediation by 2026-07-04
  - (2026-06-29) CVE-2026-48558 · SimpleHelp SimpleHelp: SimpleHelp Authentication Bypass Vulnerability
      vendor: SimpleHelp · product: SimpleHelp · CISA remediation by 2026-07-02
  - (2026-06-25) CVE-2026-12569 · PTC Windchill and FlexPLM: PTC Windchill and FlexPLM Improper Input Validation Vulnerability
      vendor: PTC · product: Windchill and FlexPLM · CISA remediation by 2026-06-28
  - (2026-06-25) CVE-2026-20230 · Cisco Unified Communications Manager: Cisco Unified Communications Manager Server-Side Request Forgery (SSRF) Vulnerability
      vendor: Cisco · product: Unified Communications Manager · CISA remediation by 2026-06-28

### WHO Disease Outbreak News — 3 new of 40 total
  - (2026-07-03) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with sustained transmission and increasing numbers of reported cases. As of 1 July, a cumulative of 1460 co…
  - (2026-07-02) Hantavirus outbreak linked to cruise ship travel, Multi-locations
      This is the fifth Disease Outbreak News posting on the Andes hantavirus (ANDV) outbreak linked to the cruise ship M/V Hondius. The outbreak identification followed the notification to the World Health Organization (WHO)…
  - (2026-06-25) Nipah virus disease - India
      On 11 June 2026, the Kerala State Health Department confirmed one laboratory confirmed case of Nipah virus (NiV) infection in Kozhikode district, Kerala State, India. The case is an adult male who developed symptoms on 3…

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-07-06) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 1 new of 32 total
  - (2026-07-06) MOVER ▼ Bernard Arnault & family — $152.10B ($-0.43B since yesterday)
      France · Fashion & Retail · source: LVMH

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=26, 14d-median=26; carrying terms: program, final, marine, hazards, proposing, designated, special, amend, establish, national, environment, persons
- state_bills: today=0, 7d-median=152, 14d-median=152; carrying terms: election, mobile, program, clear, hours, avoid, final, presence, ethics, legally, impose, relative
- state_news: today=280, 7d-median=452, 14d-median=452; carrying terms: election, wearing, reading, program, april, affected, clear, hours, online, overhaul, final, independent
- local_news: today=202, 7d-median=221, 14d-median=221; carrying terms: cbmisafbvv, dozens, dekalb, target, mother, project, arrest, tuesday, cbmiygfbvv, missing, child, reported
- foreign_news: today=1008, 7d-median=1034, 14d-median=1034; carrying terms: figcaption, clear, route, leader, point, suicidal, gender, calling, bridge, httpsconnection, round, easyjet
- chinese_internal: today=242, 7d-median=281, 14d-median=281; carrying terms: investors, cbmixkfvx, target, cbmiakfvx, cbmibefvx, https, market, cbmizkfvx, title, people, cbmizefvx, blank
- russian_internal: today=846, 7d-median=915, 14d-median=915; carrying terms: media, group, europe, forex, politico, https, telegraph, istories, google, title, forbidden, financial
- ukrainian_internal: today=117, 7d-median=117, 14d-median=117; carrying terms: program, warned, kyivindependent, leader, independent, discussions, sites, broader, calling, bridge, squeeze, joint
- ukraine_theater: today=497, 7d-median=557, 14d-median=557; carrying terms: nvgotrwfizetpcg, txdvzvnobeplugc, tnvinuzjb, iqlbuq, nzetdeyxljcnbbqurvn, cuxpunlqexfkudb, juzelzwmjlemtwrvhwtfbkvxrhqutgtmzuegf, vunyqs, cuxoqnfnunjotkxec, nxpuodi, eodjka, pqwezfzty
- paper_bets: today=142, 7d-median=139, 14d-median=139; carrying terms: officially, eliminated, election, released, fusion, depleted, leader, payable, source, announcements, point, davante
- weather: today=114, 7d-median=173, 14d-median=173; carrying terms: please, ottawa, tidal, illnesses, warned, limbs, affected, hours, maximum, forecast, ongoing, junction
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: payrolls, dcoilwtico, personal, supply, dexchus, growth, payems, nonfarm, consumption, unrate, implied, cpiaucsl
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: corporate, commodities, russell, crypto, agriculture, range, equities, rates, nasdaq, silver, treasury, large
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=108, 7d-median=104, 14d-median=104; carrying terms: tunisia, prohibiting, program, involvement, protests, myanmar, armed, sovereignty, cbmixkfvx, counter, russia, manufacture
- congressional_trades: today=1, 7d-median=68, 14d-median=68
- billionaires: today=32, 7d-median=40, 14d-median=40; carrying terms: yesterday, semiconductors, canada, fashion, steve, arnault, yanai, berkshire, buffett, family, bezos, holdings
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: hernandez, court, revisions, supreme, corporation, blanche, university, alabama, state, national, trade, appeals
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed, filer, financial
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: elect, booker, michael, house, action, ossoff, disbursements, lindsey, chartered, james, talarico, group
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=61, 7d-median=25, 14d-median=25; carrying terms: themes, spanish, english, russian, trump, ukrainian, greek, chinese, israel, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=4, 7d-median=28, 14d-median=28; carrying terms: position, bulgaria, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: cross, canada, mechanical, mainly, countries, reaching, formula, suspected, april, fatality, affected, cholera
- cisa_kev: today=8, 7d-median=9, 14d-median=9; carrying terms: control, vulnerability, remediation, access, injection, traversal, improper, vendor, product, authentication, cisco, manager
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: percentile, probability, exploit
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=171, 7d-median=120, 14d-median=120; carrying terms: malaysia, vietnam, congo, austria, romania, maximum, alert, madagascar, czech, impact, finland, ukraine
- usgs_quakes: today=13, 7d-median=14, 14d-median=14; carrying terms: indonesia, depth, philippines, japan
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: argentina, world, price, volume, resolves, minister, ethiopia, colombia, prime, belgium
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: economist, marginal, https, income, years, conversableeconomist, conversable, world, revolution, class, state
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: operated, professional, because, organizations, greater, account, companies, analysis, large, years, malicious, artificial
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: booker, sanders, raskin, bishop, grothman, haridopolos, simon, filings, acting, lateefah, april, boyle
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: module, consensus, unavailable, converges, decision, paper, placed, either, claude, sufficient, placement, market

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-22] Fed press (events + announcements): Federal Reserve notes with deep sadness the passing of Alan Greenspan
- [2026-06-22] Fed speeches: Waller, Welcoming Remarks on the International Role of the U.S. Dollar
- [2026-06-24] Fed speeches: Cook, Welcome Remarks
- [2026-06-24] Fed press (events + announcements): Federal Reserve Board's annual bank stress test confirms that large banks are well positioned to weather a severe recession and able to continue to lend to households and businesses
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board issues enforcement action with employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Jiko Group, Inc.
- [2026-06-26] ECB press: ECB Consumer Expectations Survey results – May 2026
- [2026-06-27] ECB press: Isabel Schnabel: Is inflation back?
- [2026-06-29] ECB press: Christine Lagarde: Back to basics in an uncertain environment
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2028
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2027
- [2026-06-30] Fed press (events + announcements): Agencies release list of distressed or underserved nonmetropolitan middle-income geographies
- [2026-07-01] Fed press (events + announcements): Federal Reserve issues initial findings from its 2025 triennial payments study
- [2026-07-02] ECB press: Frank Elderson: The green transition – benefits and barriers
- [2026-07-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Small Business Bank and announces termination enforcement actions with BNP Paribas S.A., BNP Paribas USA, Inc., BNP Paribas Securities Corp., and Community Bankshares, Inc.
- [2026-07-02] ECB press: Piero Cipollone: The digital transformation of money, payments and finance
- [2026-07-02] ECB press: Christine Lagarde: Interview with Les Échos

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*