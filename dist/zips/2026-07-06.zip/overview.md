# WORLDSCOPE morning brief — 2026-07-06

## Headline
3899 new items across 27 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (843) · Russian Internal News (state + in-exile) (821) · Ukraine Theater (total-war monitoring) (440) · World leaders & government officials (324) · State-Level News (258) · Chinese Internal News (240) · Local News: St. Louis + Atlanta (198) · GDACS — global disaster alerts (156) · U.S. Weather + Severe / Climate Outlooks (124) · Ukrainian Internal News (national + local Kyiv) (106) · Court opinions of consequence (federal & state) (60) · IT, InfoSys & cybersecurity news (last 7 days) (57)

## What changed today
### International News + Multilateral Institutions — 843 new of 985 total
  - (2026-07-06) [Global] Ukraine warns of interceptor missile shortage as 18 killed in Kyiv region
      President Zelensky says Sunday's "massive Russian attack" on Kyiv consisted of 68 missiles and 351 strike drones.
  - (2026-07-06) [Global] 'I ate ketchup and cheese,' says Venezuelan girl trapped under quake rubble for 32 hours
      Fabiana was trapped in the rubble of a 10-storey residential building after two earthquakes rocked Venezuela in June.
  - (2026-07-06) [Global] Australian PM apologises for 'inappropriate' comments about Kylie Minogue
      Albanese has apologised 'unequivocally' after his remarks prompted a backlash.
  - (2026-07-05) [Global] Marine Le Pen appeal verdict: Why this moment matters for France
      The leader of France's National Rally leads the opinion polls ahead of the 2027 presidential election and will now find out if she can stand.
  - (2026-07-05) [Global] A global hub for fake luxury goods, Vietnam cracks down on its black market
      The Trump administration wants Vietnam to stamp out its booming counterfeit industry. Locals are divided.
  - (2026-07-06) [Global] Super Typhoon Bavi makes landfall on US Pacific islands with huge wind gusts
      The storm, with winds of nearly 290km/h (180mph) and gusts of 350km/h, is lashing the island of Rota.

### Russian Internal News (state + in-exile) — 821 new of 824 total
  - (2026-07-06) Бразилия вылетает, Неймар плачет. ФИФА отменяет дисквалификацию американского футболиста — после звонка Дональда Трампа. Что там на ЧМ? Суперкоротко | LEDE: Кто как с кем сыграл. Норвегия об] (ru: Бра…
      Кто как с кем сыграл. Норвегия обыграла Бразилию 2:1, Холанд забил оба гола норвежцев, его голевая серия в турнирных матчах за сборную продолжается уже 14 матчей. Единственный гол у бразильцев забил Неймар (с пенальти) —…
  - (2026-07-06) Рамзан Кадыров в начале войны опубликовал видео совещания «в семи километрах от Киева». Этот ролик записали в подвале секретной тюрьмы в Чечне, выяснила «Новая газета Европа» | LEDE: Видео с] (ru: Рам…
      Видео совещания главы Чечни Рамзана Кадырова с чеченскими командирами «под Киевом», которое распространили чеченские СМИ в начале большой войны России с Украиной, снимали в Чечне. Об этом говорится в большом исследовании…
  - (2026-07-06) Во Франции из музея Lalique украли экспонаты стоимостью в несколько миллионов евро. Сигнализация сработала, но о краже жандармам сообщила уборщица | LEDE: Воры проникли в музей Lalique и уне] (ru: Во…
      Воры проникли в музей Lalique и унесли около 20 экспонатов, общая стоимость которых может достигать четырех миллионов евро.
  - (2026-07-06) К лидеру оппозиционной партии «Процветающая Армения» Гагику Царукяну пришли с обыском | LEDE: В Армении силовики с утра 6 июля проводят обыски в доме лидера партии «Процветающая Армения» и б] (ru: К л…
      В Армении силовики с утра 6 июля проводят обыски в доме лидера партии «Процветающая Армения» и бизнесмена Гагика Царукяна, а также в связанных с ним компаниях. Об этом заявила пресс-секретарь партии Ивета Тоноян, сообщае…
  - (2026-07-06) Мэрия Екатеринбурга назвала установку табличек «Последнего адреса» «несогласованной» — они нарушают облик зданий и размещаются «случайно» | LEDE: Департамент архитектуры, градостроительства ] (ru: Мэр…
      Департамент архитектуры, градостроительства и регулирования земельных отношений мэрии Екатеринбурга (Главархитектура) выпустил методические рекомендации по разработке и размещению мемориальных досок на фасадах зданий, пи…
  - (2026-07-06) В Подмосковье задержали 16-летнюю девушку, которая по указанию мошенников подожгла АЗС | LEDE: Сотрудники МВД задержали 16-летнюю девушку, которая, выполняя указания мошенников, устроила пож] (ru: В П…
      Сотрудники МВД задержали 16-летнюю девушку, которая, выполняя указания мошенников, устроила пожар на АЗС в городе Щелково Московской области.

### Ukraine Theater (total-war monitoring) — 440 new of 497 total
  - (2026-07-06) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-07-05) [FIRMS] thermal anomaly 51.413, 34.536 (FRP 2.8 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 2.8 MW
  - (2026-07-05) [FIRMS] thermal anomaly 51.410, 34.538 (FRP 3.22 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 3.22 MW
  - (2026-07-05) [FIRMS] thermal anomaly 51.376, 24.877 (FRP 1.72 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 1.72 MW
  - (2026-07-05) [FIRMS] thermal anomaly 49.922, 24.065 (FRP 3.18 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 3.18 MW
  - (2026-07-05) [FIRMS] thermal anomaly 49.920, 24.071 (FRP 0.71 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-07-05 0122Z, FRP 0.71 MW

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### State-Level News — 258 new of 271 total
  - (2026-07-04) [California] Estos estudiantes universitarios de Los Ángeles usan el transporte público para ahorrar dinero. Así son sus viajes.
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/06/042826-Student-Transit-MR-CM-01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image…
  - (2026-07-04) [California] Governor Newsom announces deployment of California firefighters and equipment to Colorado, as sister state battles wildfires
      Source
  - (2026-07-04) [California] Gobernador Gavin Newsom conmemora el Día de la Independencia con una llamada a renovar la lucha por defender la democracia
      Source
  - (2026-07-04) [California] Governor Gavin Newsom marks Fourth of July with a call for a renewed fight to defend democracy
      Source
  - (2026-07-06) [Connecticut] The irony of celebrating America
      <img width="1024" height="682" src="https://ctmirror.org/wp-content/uploads/2026/07/ap-dc-fireworks-july-4.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" fetchpriority="h…
  - (2026-07-06) [Connecticut] Erosion of the common good in our national health care system
      <img width="1024" height="741" src="https://ctmirror.org/wp-content/uploads/2026/06/work-requirement-chart-kff-1-1024x741.png" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" l…

### Chinese Internal News — 240 new of 240 total
  - (2026-07-06) 重要调整，明起，A股交易规则变了 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTFBSUUxGNS03aEVwQ1ZuMUt6RDhKY01vUjRQS21UR2kyRlgzVVRWYjMyTnZNaUpPQmhDdy1obWI3czZvd3llVHZPdEF1cEw1cVY1S3FYT] (zh:…
      重要调整，明起，A股交易规则变了 财新
  - (2026-07-04) 中融信托因资不抵债获准破产清算 向中植集团申报多少债权？ - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE8zQXlHUDJoTGhfU08wbG5NVlZEelJtTzc5MlE4SVh6eEtiWmhCMmhjM21uOW9yN0NRN1BZbnhpbHBWY2NWUjdtd2hwV] (zh:…
      中融信托因资不抵债获准破产清算 向中植集团申报多少债权？ 财新
  - (2026-07-04) 再融资规则全面调整 便利公司、终结套利 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE9mWFh1NDUzdFkxdFBRbXJEelZabnVlc2pYZlMzZTA3UjM0bzdDc0Y2ZnVGWnByclU0b3R1dHd4aEpHaDNPMl9TTlZLYU50MEsyYm] (zh:…
      再融资规则全面调整 便利公司、终结套利 财新
  - (2026-07-05) 所有战争的史诗，最终始于一场告别｜画志·2026年第二季 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE9UTWRSN2IzdmZucU1IRXVYQ3YxREJOSmZnSFlZVG9GOXBSb1M0RkJqY2padkxvbmNrMU5xeHNRYjEtVHdpVHJfa0Vqc] (zh:…
      所有战争的史诗，最终始于一场告别｜画志·2026年第二季 财新
  - (2026-07-04) 佛得角，踢出了草根英雄的胆｜体坛 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiXkFVX3lxTE1OdXJuQjl5VS01YTFpU01hYW1mVW85a0J3dmtham0wU2M1alhDelpyQWEtWmx3Rnk4bnlOdHdMelNLbzBtNmpRUXpzVkhmUHJxcjI2b] (zh:…
      佛得角，踢出了草根英雄的胆｜体坛 财新
  - (2026-07-04) 下周一A股交易制度生变：ST股涨跌幅扩大至10%、盘后增加交易时段 - 财新 | LEDE: <a href="https://news.google.com/rss/articles/CBMiYkFVX3lxTE1QN1RpRnMwWnFZSkhmMFl3enhaUWREc2luYTFDN2JjV0J3U0dkckU5NDFpX1JTWWI3VzQtVzNsc3g2ME95eUh0] (zh:…
      下周一A股交易制度生变：ST股涨跌幅扩大至10%、盘后增加交易时段 财新

### Local News: St. Louis + Atlanta — 198 new of 199 total
  - (2026-07-06) [St. Louis] The Bosnian soccer team lost. Bosnians in St. Louis won anyway
  - (2026-07-06) [St. Louis] St. Louis Public Schools is getting ready to close schools. Here’s what you need to know
  - (2026-07-06) [St. Louis] Rep. Steve Butz stands by his vote to place St. Louis police under state control
  - (2026-07-06) [St. Louis] Collinsville has half the money needed to renovate water plant for 'forever chemicals'
  - (2026-07-06) [St. Louis] Outgoing WashU scholar says support for humanities is vital for students in the AI age
  - (2026-07-04) [St. Louis] Red, white and boom: St. Louis metro celebrates America's 250th Independence Day

### GDACS — global disaster alerts — 156 new of 168 total
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)
  - (2026-07-01) [Red] Tropical Cyclone BAVI-26
      Tropical Cyclone · Red alert · Guam, Northern Mariana Islands, Japan, Taiwan, China · Hurricane/Typhoon > 74 mph (maximum wind speed of 287 km/h)

### U.S. Weather + Severe / Climate Outlooks — 124 new of 126 total
  - (2026-07-06) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-07-06) [Moderate] Special Weather Statement: Special Weather Statement issued July 6 at 7:16AM EDT by NWS Wakefield VA
      At 716 AM EDT, Doppler radar was tracking a strong thunderstorm over Choptank, or 7 miles northwest of Hurlock, moving northeast at 20 mph. HAZARD...Wind gusts up to 40 mph, heavy rain, and frequent lightning. SOURCE...R…
  - (2026-07-06) [Severe] Fire Weather Watch: Fire Weather Watch issued July 6 at 4:13AM PDT until July 7 at 10:00PM PDT by NWS Pendleton OR
      ...DRY AND WINDY CONDITIONS WILL LEAD TO CRITICAL FIRE WEATHER... * AFFECTED AREA...Fire Weather Zones 690 Kittitas Valley, 691 Lower Columbia Basin of Oregon, 691 Lower Columbia Basin of Washington and 703 Warm Springs…
  - (2026-07-06) [Severe] Special Marine Warning: Special Marine Warning issued July 6 at 6:08AM CDT until July 6 at 7:15AM CDT by NWS Tallahassee FL
      SMWTAE The National Weather Service in Tallahassee has issued a * Special Marine Warning for... Coastal Waters from Mexico Beach to Apalachicola out 20 NM... Coastal waters from Okaloosa-Walton County Line to Mexico Beac…
  - (2026-07-06) [Moderate] Heat Advisory: Heat Advisory issued July 6 at 7:07AM EDT until July 6 at 7:00PM EDT by NWS Charleston SC
      * WHAT...Heat index values up to 110 expected. * WHERE...Beaufort, Charleston, Coastal Colleton, Coastal Jasper, Inland Berkeley, and Tidal Berkeley Counties. * WHEN...From 11 AM this morning to 7 PM EDT this evening. *…
  - (2026-07-06) [Moderate] Heat Advisory: Heat Advisory issued July 6 at 7:06AM EDT until July 6 at 8:00PM EDT by NWS Wilmington NC
      * WHAT...Heat index values around 105 expected. * WHERE...Portions of southeast North Carolina and northeast South Carolina. * WHEN...From 11 AM this morning to 8 PM EDT this evening. * IMPACTS...Hot temperatures and hig…

### Ukrainian Internal News (national + local Kyiv) — 106 new of 114 total
  - (2026-07-06) Ukraine Seeks Emergency UN Security Council Meeting After Russian Attack
      Ukraine has requested an emergency meeting of the UN Security Council following Russia's second large-scale missile and drone attack within days. Kyiv urged council members to back the request, warning that delayed or we…
  - (2026-07-06) British Defence Intelligence Update Ukraine July 3, 2026
      British Defence Intelligence.
  - (2026-07-06) Ukraine Tells Allies Patriots Due in 2027: Save Lives – Send Stockpiled Patriots
      Ukraine has proposed that allies temporarily transfer Patriot interceptor missiles from their own stockpiles and replenish them later with future deliveries already on order, arguing the move could save lives as Russia i…
  - (2026-07-06) ‘Putin Will Keep Aiming Missiles at Sleeping Children’ – Sybiha Urges More Air Defense Ahead of NATO Summit
      Foreign Minister Andrii Sybiha called on NATO leaders gathering in Ankara to urgently boost Ukraine's air defenses after Russia launched a major missile and drone attack on Kyiv. He said delays in supplying Patriot inter…
  - (2026-07-06) Ukraine Strikes Major Russian Refinery, Baltic Oil Ports, Drones Trigger First Air Raid in Chelyabinsk
      Ukraine reportedly targeted one of Russia’s largest oil refineries, two major Baltic export ports, and an industrial facility in an overnight drone campaign, according to Russian officials and media. The attacks also rep…
  - (2026-07-06) Zelensky After Deadly Russian Attack: ‘Patriot Missiles Belong in Ukraine, Not in Warehouses’
      Zelensky urged Ukraine’s allies to provide more Patriot interceptor missiles after Russia launched a massive overnight attack involving 68 missiles and 351 drones. He said Ukraine successfully intercepted drones and crui…

### Court opinions of consequence (federal & state) — 60 new of 60 total
  - (2026-07-02) U.S. Court of Appeals, 6th Cir.: United States v. Jeremy Wayne Harrell
  - (2026-07-02) U.S. Court of Appeals, Federal Cir.: Tracktime, LLC v. amazon.com Services LLC
  - (2026-07-02) Alaska Supreme Court: Viva G. v. Department of Family and Community Services, Office of Children's Services
  - (2026-07-02) Supreme Court of Alabama: Col. Alan Spencer, in his official capacity as Chairman of the Alabama Alcoholic Beverage Control Board; Melissa Morrissette, in her official capacity as a member of the Alab…
  - (2026-07-02) Supreme Court of Alabama: In re: Amanda Busby v. City of Tuskegee
  - (2026-07-02) Supreme Court of Alabama: In re: Amanda Busby v. City of Tuskegee

### IT, InfoSys & cybersecurity news (last 7 days) — 57 new of 57 total
  - (2026-07-06) [The Hacker News] New TrojPix Attack Leaks Data From Air-Gapped Systems via Video Cable Emissions
      Researchers at Shandong University have shown a fast new way to pull data off computers that are cut off from every network. The technique, called TrojPix, tweaks on-screen pixels in ways the eye cannot see, so that the…
  - (2026-07-06) [The Hacker News] New Java-Based QuimaRAT MaaS Built to Run on Windows, Linux, and macOS
      Cybersecurity researchers have flagged a novel Java-based remote access trojan (RAT) called QuimaRAT that's capable of targeting Windows, Linux, and macOS environments. According to LevelBlue, the cross-platform malware…
  - (2026-07-06) [The Hacker News] Opera GX Flaw Let Malicious Sites Auto-Install Mods to Steal Data From Visited Pages
      Researchers found a flaw in Opera GX, the gaming-focused version of the Opera browser, that let a malicious website silently install a browser add-on and use it to lift specific data from the pages a victim visits. In a…
  - (2026-07-06) [The Hacker News] SkillCloak Lets Malicious AI Agent Skills Evade Static Scanners with Self-Extracting Packing
      Scanners meant to catch malicious add-on "skills" for AI coding agents can be fooled by a few simple changes that leave the malware working, according to a new study from researchers at the Hong Kong University of Scienc…
  - (2026-07-06) [Cybersecurity Dive] The security leaders defining the next decade aren’t in CISO seats yet
      The first recognition program for the security leaders who will define the future of cybersecurity.
  - (2026-07-06) [Schneier on Security] France to Stop Certifying Non-Quantum-Safe Encryption
      France is accelerating its transition to post-quantum encryption: France’s cybersecurity agency ANSSI said on Tuesday it would stop certifying security products that lack quantum-resistant encryption, a move that will fo…

### Government Action: Sanctions + Procurement + Foreign Agents — 47 new of 108 total
  - (2026-07-01) [OFAC] Counter Narcotics Designations; Counter Terrorism Designations and Designation Update - Office of Foreign Assets Control (.gov)
      Counter Narcotics Designations; Counter Terrorism Designations and Designation Update Office of Foreign Assets Control (.gov)
  - (2026-07-01) [OFAC] Reminder to File the 2026 Annual Report of Blocked Property - Office of Foreign Assets Control (.gov)
      Reminder to File the 2026 Annual Report of Blocked Property Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act…
      Counter Narcotics Designations; Russia-related Designations Removals; Publication of Report for Licensing Activities Undertaken Pursuant to the Trade Sanctions Reform and Export Enhancement Act (TSRA) Office of Foreign A…
  - (2026-06-29) [OFAC] Launch of OFAC Reconsideration Portal - Office of Foreign Assets Control (.gov)
      Launch of OFAC Reconsideration Portal Office of Foreign Assets Control (.gov)
  - (2026-06-30) [OFAC] Mexican Cartel Fuel Smuggling Schemes - Office of Foreign Assets Control (.gov)
      Mexican Cartel Fuel Smuggling Schemes Office of Foreign Assets Control (.gov)
  - (2026-06-29) [OFAC] 1261 - Office of Foreign Assets Control (.gov)
      1261 Office of Foreign Assets Control (.gov)

### Paper Trading Scorecard — 40 new of 141 total
  - (2026-07-06) [Polymarket] Will the Green Bay Packers win the 2027 NFL league championship?
      This market will resolve according to the team that wins the 2027 NFL league championship. If at any point it becomes impossible for a listed team to win the 2027 NFL league championship per the rules of the NFL (e.g., t…
  - (2026-07-06) [Polymarket] Will James Talarico win the 2028 Democratic presidential nomination?
      This market will resolve to “Yes” if the named individual wins and accepts the 2028 nomination of the Democratic Party for U.S. president. Otherwise, this market will resolve to “No”. The resolution source for this marke…
  - (2026-07-06) [Polymarket] Will Austin Reaves play for the Cleveland Cavaliers in 2026-27?
      This market will resolve to the next team Austin Reaves officially joins by October 31, 2026, 11:59 PM ET. If Austin Reaves does not officially join a new team by October 31, 2026, 11:59 PM ET, this market will resolve t…
  - (2026-07-06) [Polymarket] Will Bitcoin reach $120,000 by December 31, 2026?
      This market will immediately resolve to "Yes" if any Binance 1 minute candle for Bitcoin (BTC/USDT) between November 24, 2025, 14:00 and December 31, 2026, 23:59 in the ET timezone has a final "High" price equal to or gr…
  - (2026-07-06) [Polymarket] Opensea FDV above $100M one day after launch?
      This market will resolve to "Yes" if the Fully Diluted Valuation of Opensea's token is greater than the value specified in the title 1 day after launch. Otherwise, the market will resolve to "No." The token must be activ…
  - (2026-07-06) [Polymarket] Will there be no Head of State in Iran end of 2026?
      This market will resolve to the individual who de facto holds and exercises the powers of the head of state of the Islamic Republic of Iran on December 31, 2026 at 12:00 PM ET. For the purposes of this market, “de facto…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-07-06) [Shan Su] Form 4 (Reporting)
      filed 2026-07-06 11:06 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0001104659-26-080565 Size: 9 KB
  - (2026-07-06) [JD.com, Inc.] Form 4 (Issuer)
      filed 2026-07-06 11:06 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0001104659-26-080565 Size: 9 KB
  - (2026-07-06) [Xu Ran] Form 4 (Reporting)
      filed 2026-07-06 11:04 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0001104659-26-080564 Size: 9 KB
  - (2026-07-06) [JD.com, Inc.] Form 4 (Issuer)
      filed 2026-07-06 11:04 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0001104659-26-080564 Size: 9 KB
  - (2026-07-06) [Yaacobi Tal] Form 4 (Reporting)
      filed 2026-07-06 11:00 UTC · role: Reporting — Filed: 2026-07-06 AccNo: 0001976408-26-000626 Size: 4 KB
  - (2026-07-06) [Valens Semiconductor Ltd.] Form 4 (Issuer)
      filed 2026-07-06 11:00 UTC · role: Issuer — Filed: 2026-07-06 AccNo: 0001976408-26-000626 Size: 4 KB

### GDELT GKG — themes / entities / watch areas — 36 new of 36 total
  - (2026-07-06) [Taiwan Strait + South China Sea · themes] Shoniyin Blames Bassa Poverty on Bad Governance , Media Silence - Liberia news The New Dawn Liberia , premier resource for latest news
      thenewdawnliberia.com · English · tone NA
  - (2026-07-06) [Taiwan Strait + South China Sea · themes] Flet për Telegraf , Anna Kohen : Populli shqiptar , vuri jetën e vet në rrezik , për të shpëtuar hebrejtë dhe familja ime mbeti gjallë falë vlonjatëve
      telegraf.al · Albanian · tone NA
  - (2026-07-06) [Taiwan Strait + South China Sea · themes] A Cena con la Scienza : Tullia Iori incanta spiegando i ponti come specchio dellItalia che cambia
      ilpiacenza.it · Italian · tone NA
  - (2026-07-06) [Taiwan Strait + South China Sea · themes] رئيس « الوطنية للانتخابات »: مصر نجحت فى منح أبنائها بالخارج حق التصويت فى جميع الاستحقاقات الانتخابية
      almasryalyoum.com · Arabic · tone NA
  - (2026-07-06) [Taiwan Strait + South China Sea · themes] Сигнал за бомба опразни Съдебната палата в Смолян
      actualno.com · Bulgarian · tone NA
  - (2026-07-06) [Taiwan Strait + South China Sea · themes] Как да предпазим сърцето в жегите
      novini.bg · Bulgarian · tone NA

### U.S. Federal Action — 30 new of 30 total
  - (2026-07-06) Improvements to Rules on Recoupment of Benefit Overpayments
      The Pension Benefit Guaranty Corporation (PBGC) is proposing to improve its rules on recoupment of benefit overpayments under PBGC's insurance program for single-employer terminated plans trusteed by PBGC. These proposed…
  - (2026-07-06) Rescission of Guidelines on Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964, as Amended
      The Equal Employment Opportunity Commission ("EEOC" or "Commission") is rescinding its regulations regarding Affirmative Action Appropriate Under Title VII of the Civil Rights Act of 1964 ("Guidelines"), and removing it…
  - (2026-07-06) Presidential Determination on Assistance to Venezuela Consistent With the Trafficking Victims Protection Act of 2000
  - (2026-07-06) Atlantic Highly Migratory Species; Atlantic Bluefin Tuna Fisheries; Closure of the Angling Category Southern New England Area Trophy Fishery for 2026
      NMFS closes the Angling category Southern New England area fishery for large medium and giant ("trophy" (i.e., measuring 73 inches (185 centimeters (cm)) curved fork length or greater)) Atlantic bluefin tuna (BFT). This…
  - (2026-07-06) Nondiscrimination in Federally Assisted Programs of NASA-Effectuation of Title VI of the Civil Rights Act of 1964
      NASA is amending its regulation implementing Title VI of the Civil Rights Act of 1964 (Title VI) for federally assisted programs to conform more closely to the statutory text and recent revisions by the Department of Jus…
  - (2026-07-06) Amendment of Using Agency and Controlling Agency for Restricted Areas R-5301, R-5302A, R-5302B, and R-5302C; NC
      This action amends the using agency and controlling agency descriptions listed for restricted areas R-5301, R-5302A, R-5302B, and R-5302C, NC. This action does not change any boundaries, altitudes, times of designation,…

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Prediction Markets — most-traded (Polymarket) — 17 new of 20 total
  - (2026-07-06) Will Norway win the 2026 FIFA World Cup?
      yes price: 5% · 24h volume: $11,368,458 · resolves 2026-07-20
  - (2026-07-06) Will Egypt win the 2026 FIFA World Cup?
      yes price: 0% · 24h volume: $5,230,450 · resolves 2026-07-20
  - (2026-07-06) Will USA win the 2026 FIFA World Cup?
      yes price: 3% · 24h volume: $4,896,000 · resolves 2026-07-20
  - (2026-07-06) Will England win the 2026 FIFA World Cup?
      yes price: 14% · 24h volume: $4,870,381 · resolves 2026-07-20
  - (2026-07-06) Will Portugal win the 2026 FIFA World Cup?
      yes price: 6% · 24h volume: $3,634,494 · resolves 2026-07-20
  - (2026-07-06) Will Belgium win the 2026 FIFA World Cup?
      yes price: 1% · 24h volume: $3,230,161 · resolves 2026-07-20

### USGS earthquakes (M4.5+, past day) — 13 new of 13 total
  - (2026-07-06) M 5.8 - 48 km SSW of Sarangani, Philippines
      M5.8 · 48 km SSW of Sarangani, Philippines · depth 35 km
  - (2026-07-05) M 5.8 - 274 km SE of Levuka, Fiji
      M5.8 · 274 km SE of Levuka, Fiji · depth 685.692 km
  - (2026-07-06) M 5.4 - 65 km SSW of Sarangani, Philippines
      M5.4 · 65 km SSW of Sarangani, Philippines · depth 35 km
  - (2026-07-05) M 5.0 - 106 km NW of Coquimbo, Chile
      M5.0 · 106 km NW of Coquimbo, Chile · depth 10 km
  - (2026-07-05) M 5.0 - 26 km NNW of Mianzhu, Deyang, Sichuan, China
      M5.0 · 26 km NNW of Mianzhu, Deyang, Sichuan, China · depth 10 km
  - (2026-07-05) M 5.0 - 23 km NNW of Mianzhu, Deyang, Sichuan, China
      M5.0 · 23 km NNW of Mianzhu, Deyang, Sichuan, China · depth 10 km

### Commentary & analysis (last 7 days) — 6 new of 6 total
  - (2026-07-06) [Marginal Revolution] Capital Gains Can Be Labor Income
      Zwick and Zidar argue that a substantial share of the decline in labor share can be accounted for by changing forms of pay, including pass-throughs and equtiy compensation. In particular, if an employee is paid in stock…
  - (2026-07-06) [Marginal Revolution] The Troubled History of Government Equity in Technology
      Even though Germany privatized Deutsche Telekom in 1996, the federal government retained a substantial ownership stake. This partial state ownership status, which remains to this day, presents a textbook example of how t…
  - (2026-07-06) [Marginal Revolution] The history of heat deaths in Europe (from my email)
      I will not double indent, all of what follows is from economic historian Daniel Gallardo Albarrán of the Netherlands: “…you posted a link to an article on how Europe became the world champion of heat deaths. Something th…
  - (2026-07-04) [Conversable Economist] Declaration of Independence: Track Changes Version
      Thomas Jefferson wrote out the first draft of the Declaration of Independence, but he did not do so alone and without guidance. After all, he had been a member of the Continental Congress that summer, listening to the di…
  - (2026-07-03) [Conversable Economist] What Does the Declaration Mean by Pursuit of Happiness?
      I wrote this short essay about the “pursuit of happiness” for the editorial page of the StarTribune newspaper, where it was published on July 3. _____ Opinion | What did the founders mean by the pursuit of happiness? The…
  - (2026-07-02) [Conversable Economist] US Exports, Imports, and Tariffs: The 250-Year Perspective
      Douglas A. Irwin offers a brisk overview of a great American tradition–specifically, “America’s been arguing over trade for more than 250 years” (Peterson Institute for International Economics, July 1, 2026). I won’t reh…

### CISA Known Exploited Vulnerabilities (last 14d) — 4 new of 8 total
  - (2026-07-01) CVE-2026-45659 · Microsoft SharePoint Server: Microsoft SharePoint Server Deserialization of Untrusted Data Vulnerability
      vendor: Microsoft · product: SharePoint Server · CISA remediation by 2026-07-04
  - (2026-06-29) CVE-2026-48558 · SimpleHelp SimpleHelp: SimpleHelp Authentication Bypass Vulnerability
      vendor: SimpleHelp · product: SimpleHelp · CISA remediation by 2026-07-02
  - (2026-06-25) CVE-2026-12569 · PTC Windchill and FlexPLM: PTC Windchill and FlexPLM Improper Input Validation Vulnerability
      vendor: PTC · product: Windchill and FlexPLM · CISA remediation by 2026-06-28
  - (2026-06-25) CVE-2026-20230 · Cisco Unified Communications Manager: Cisco Unified Communications Manager Server-Side Request Forgery (SSRF) Vulnerability
      vendor: Cisco · product: Unified Communications Manager · CISA remediation by 2026-06-28

### Forbes Real-Time Billionaires (top 30 + biggest movers) — 3 new of 35 total
  - (2026-07-06) MOVER ▼ Bernard Arnault & family — $152.54B ($-0.82B since yesterday)
      France · Fashion & Retail · source: LVMH
  - (2026-07-06) MOVER ▼ Gautam Adani — $90.37B ($-0.64B since yesterday)
      India · Diversified · source: Infrastructure, commodities
  - (2026-07-06) MOVER ▲ Mukesh Ambani — $90.31B (+$0.13B since yesterday)
      India · Diversified · source: Diversified

### WHO Disease Outbreak News — 3 new of 40 total
  - (2026-07-03) Ebola disease caused by Bundibugyo virus, Democratic Republic of the Congo & Uganda
      The Bundibugyo virus disease (BVD) outbreak in the Democratic Republic of the Congo continues to evolve rapidly, with sustained transmission and increasing numbers of reported cases. As of 1 July, a cumulative of 1460 co…
  - (2026-07-02) Hantavirus outbreak linked to cruise ship travel, Multi-locations
      This is the fifth Disease Outbreak News posting on the Andes hantavirus (ANDV) outbreak linked to the cruise ship M/V Hondius. The outbreak identification followed the notification to the World Health Organization (WHO)…
  - (2026-06-25) Nipah virus disease - India
      On 11 June 2026, the Kerala State Health Department confirmed one laboratory confirmed case of Nipah virus (NiV) infection in Kozhikode district, Kerala State, India. The case is an adult male who developed symptoms on 3…

### Congressional STOCK Act Trades (House + Senate) — 1 new of 1 total
  - (2026-07-06) [Quiver Quantitative error] HTTPError
      401 Client Error: Unauthorized for url: https://api.quiverquant.com/beta/live/congresstrading

### Campaign finance (FEC: top fundraisers + recent filings) — 1 new of 27 total
  - () [F3] SUE LOWDEN FOR U S SENATE
      cycle 2010 · filing #732522

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-07-06) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=30, 7d-median=26, 14d-median=26; carrying terms: reporting, vessels, environment, agency, comments, waters, captain, special, authorized, specifically, issuing, potential
- state_bills: today=0, 7d-median=152, 14d-median=152; carrying terms: driving, permanent, member, administrator, knowingly, criminal, taxation, thereafter, agency, economic, impact, misleading
- state_news: today=271, 7d-median=452, 14d-median=452; carrying terms: communities, university, vtdigger, traffic, threatens, subject, thanks, published, journal, member, failed, moratorium
- local_news: today=199, 7d-median=221, 14d-median=221; carrying terms: louis, three, central, health, decoding, blank, including, county, charges, leaving, house, third
- foreign_news: today=985, 7d-median=1034, 14d-median=1034; carrying terms: driving, treasury, depict, zhongdian, winning, movement, failed, backing, teachers, immediately, middle, submitted
- chinese_internal: today=240, 7d-median=281, 14d-median=281; carrying terms: caixin, cbmibefvx, cbmizkfvx, title, blank, cbmiykfvx, lxtfa, color, cbmiyefvx, europe, google, cbmiw
- russian_internal: today=824, 7d-median=915, 14d-median=915; carrying terms: telegraph, guardian, httperror, novayagazeta, client, title, error, telegram, truth, bloomberg, media, europe
- ukrainian_internal: today=114, 7d-median=114, 14d-median=114; carrying terms: scheduled, track, title, conflict, error, three, central, economic, territories, defense, nations, possible
- ukraine_theater: today=497, 7d-median=557, 14d-median=557; carrying terms: shyzuvztugu, acquisition, thermal, yxdmuejtwhl, zlewhfcmlua, movement, svnyve, cuxnbjdkzvnoatvoz, sudan, qlvfrb, cuxoa, conflict
- paper_bets: today=141, 7d-median=139, 14d-median=139; carrying terms: eliminated, official, kansas, initial, decrease, scheduled, cursor, sources, polymarket, washington, andrew, flacco
- weather: today=126, 7d-median=173, 14d-median=173; carrying terms: tucson, afdmfl, weekend, occurring, louis, timing, oregon, middle, afdilx, gunnison, burning, mainly
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: jtsjol, growth, consumption, treasury, dcoilwtico, cpiaucsl, nonfarm, funds, indicator, commodities, unemployment, assets
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: bitcoin, crude, treasury, equities, yield, commodities, range, silver, china, rates, close, russell
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=108, 7d-median=104, 14d-median=104; carrying terms: terrorism, snapshot, sovereignty, harris, guatemala, member, sudan, middle, haiti, flight, specific, entities
- congressional_trades: today=1, 7d-median=68, 14d-median=68
- billionaires: today=35, 7d-median=40, 14d-median=40; carrying terms: semiconductors, tadashi, telecom, gautam, carlos, spacex, discount, bettencourt, yesterday, paris, changpeng, amazon
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: hernandez, revisions, corporation, court, supreme, blanche, trump, james, general, international, alabama, state
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, filed, accno, filer, jpmorgan, chase, financial
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: house, warner, shawn, johnson, congress, trone, receipts, group, sherrod, committee, disbursements, ossoff
- gdelt_regions: today=6, 7d-median=6, 14d-median=6; carrying terms: english
- gdelt_gkg: today=36, 7d-median=25, 14d-median=25; carrying terms: english, themes, spanish, russian, chinese, italian, indonesian
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=40, 14d-median=40
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=4, 7d-median=28, 14d-median=28; carrying terms: position, bulgaria, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: probable, official, periods, returning, analyzed, history, process, burial, evolve, published, reporting, member
- cisa_kev: today=8, 7d-median=9, 14d-median=9; carrying terms: remediation, traversal, access, manager, vendor, improper, vulnerability, product, authentication, cisco, injection, control
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=168, 7d-median=120, 14d-median=120; carrying terms: philippines, thailand, vietnam, fires, republic, congo, czech, cyclone, gabon, malaysia, estonia, maximum
- usgs_quakes: today=13, 7d-median=14, 14d-median=14; carrying terms: indonesia, depth, philippines
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, volume, world, resolves, argentina, belgium, colombia
- commentary: today=6, 7d-median=5, 14d-median=5; carrying terms: class, income, marginal, conversable, economist, revolution, conversableeconomist, years, world, https, state
- tech_news: today=57, 7d-median=57, 14d-median=57; carrying terms: developer, published, fleets, designed, greater, hacker, policy, including, international, powered, launch, business
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: maxwell, neguse, suozzi, treasury, wicker, thune, morelle, louis, goodlander, harris, maxine, fuller
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: claude, converges, paper, market, either, decision, sufficient, identify, today, placed, markets, placement

## What to watch (recent + forthcoming, ±14 days)
- [2026-06-22] Fed press (events + announcements): Federal Reserve notes with deep sadness the passing of Alan Greenspan
- [2026-06-22] Fed speeches: Waller, Welcoming Remarks on the International Role of the U.S. Dollar
- [2026-06-24] Fed speeches: Cook, Welcome Remarks
- [2026-06-24] Fed press (events + announcements): Federal Reserve Board's annual bank stress test confirms that large banks are well positioned to weather a severe recession and able to continue to lend to households and businesses
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board issues enforcement action with employee of Bank of Eufaula and S N B Bancshares, Inc.
- [2026-06-25] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement action with Jiko Group, Inc.
- [2026-06-26] ECB press: ECB Consumer Expectations Survey results – May 2026
- [2026-06-27] ECB press: Isabel Schnabel: Is inflation back?
- [2026-06-29] ECB press: Christine Lagarde: Back to basics in an uncertain environment
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2028
- [2026-06-30] ECB press: ECB publishes indicative operational calendars for 2027
- [2026-06-30] Fed press (events + announcements): Agencies release list of distressed or underserved nonmetropolitan middle-income geographies
- [2026-07-01] Fed press (events + announcements): Federal Reserve issues initial findings from its 2025 triennial payments study
- [2026-07-02] ECB press: Frank Elderson: The green transition – benefits and barriers
- [2026-07-02] Fed press (events + announcements): Federal Reserve Board issues enforcement action with Small Business Bank and announces termination enforcement actions with BNP Paribas S.A., BNP Paribas USA, Inc., BNP Paribas Securities Corp., and Community Bankshares, Inc.
- [2026-07-02] ECB press: Piero Cipollone: The digital transformation of money, payments and finance
- [2026-07-02] ECB press: Christine Lagarde: Interview with Les Échos

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*