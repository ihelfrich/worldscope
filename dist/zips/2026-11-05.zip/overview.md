# WORLDSCOPE morning brief — 2026-11-05

## Headline
3548 new items across 26 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (846) · Russian Internal News (state + in-exile) (632) · State-Level News (515) · World leaders & government officials (324) · Chinese Internal News (292) · Local News: St. Louis + Atlanta (241) · U.S. Weather + Severe / Climate Outlooks (128) · Ukraine Theater (total-war monitoring) (96) · State Legislative Action (88) · Ukrainian Internal News (national + local Kyiv) (74) · GDACS — global disaster alerts (49) · IT, InfoSys & cybersecurity news (last 7 days) (45)

## What changed today
### International News + Multilateral Institutions — 846 new of 1044 total
  - (2026-11-05) [Australia] Raiders 'couldn't have offered any more' to want-away Hudson Young
      Ricky Stuart said he understands why backrower Hudson Young may want to leave the Canberra Raiders, but it didn't make him take it any less personally.
  - (2026-11-05) [Australia] NAS weighs in more than 33kg heavier than Paul Gallen
      Nelson Asofa-Solomona has continued his verbal attack on Paul Gallen, setting the scene for an explosive heavyweight bout between the NRL premiership winners.
  - (2026-11-05) [Australia] Netball blindsided by leak of likely inclusion at Brisbane Olympics
      Reports that netball's once in a generation Brisbane 2032 bid is backed by high sources within the Olympic ranks is a very positive sign, but the sport is holding off from celebrating until the official vote takes place…
  - (2026-11-05) [Australia] Swans 'need to be better' as club launches investigation in culture
      Sydney chief executive Matthew Pavlich expresses "bitter disappointment" after Tom Papley's drug test result hurls the AFL club back into the spotlight.
  - (2026-11-05) [Australia] Australian racing icon and F1 world champion Alan Jones dies
      Alan Jones dies a few days after turning 80, after a short illness. He won the 1980 Formula 1 world championship and 12 grands prix.
  - (2026-11-05) [Australia] Brazil soccer match sets world record for most red cards after mass brawl
      An under-20s soccer match in Brazil is making headlines for all the wrong reasons, with more than 50 red cards handed out after a mass brawl.

### Russian Internal News (state + in-exile) — 632 new of 938 total
  - (2026-11-05) В Крыму в СИЗО погибла преподавательница из Харькова. Ее арестовали, когда она приехала к родителям | LEDE: В аннексированном Россией Крыму погибла соосновательница харьковской языковой школ] (ru: В К…
      В аннексированном Россией Крыму погибла соосновательница харьковской языковой школы «Профессионал» Александра Казаровицкая (Колесникова), сообщается в фейсбуке школы. В посте говорится, что Казаровицкую «убила Россия».
  - (2026-11-05) Бывший совладелец национализированного Соликамского магниевого завода попросил убежище во Франции | LEDE: Бывший совладелец Соликамского магниевого завода (СМЗ) Игорь Пестриков запросил поли] (ru: Быв…
      Бывший совладелец Соликамского магниевого завода (СМЗ) Игорь Пестриков запросил политическое убежище во Франции. Об этом пишут «Ведомости», ссылаясь на документы Высокого суда Англии и Уэльса.
  - (2026-11-05) В Финляндии двух моряков судна, повредившего кабели в Финском заливе, приговорили к реальным срокам. Один из них — россиянин | LEDE: Суд в Хельсинки вынес приговор двум морякам судна «Фитбур] (ru: В Ф…
      Суд в Хельсинки вынес приговор двум морякам судна «Фитбург», повредившего кабели в Финском заливе, сообщают Yle и Reuters.
  - (2026-11-05) Умер основатель бренда «Экспедиция» Александр Кравцов | LEDE: Основатель группы компаний «Руян» и бренда товаров для путешествий «Экспедиция» Александр Кравцов умер в возрасте 58 лет, сообщи] (ru: Уме…
      Основатель группы компаний «Руян» и бренда товаров для путешествий «Экспедиция» Александр Кравцов умер в возрасте 58 лет, сообщил телеграм-канал бренда.
  - (2026-11-05) Демократы в США выиграли промежуточные выборы в конгресс. Получается, теперь Трамп не сможет принимать без них никакие законы? | LEDE: Первую половину своего второго президентского срока Дон] (ru: Дем…
      Первую половину своего второго президентского срока Дональд Трамп работал в комфортных условиях республиканского большинства в обеих палатах конгресса США. По итогам промежуточных выборов 3 ноября этот контроль утрачен.…
  - (2026-11-05) В Европе более 10 самолетов получили предупреждения о бомбах на борту. Это второй такой массовый случай за неделю | LEDE: Как минимум 12 пассажирских самолетов, выполнявших рейсы в Европе, п] (ru: В Е…
      Как минимум 12 пассажирских самолетов, выполнявших рейсы в Европе, получили в четверг, 5 ноября, предупреждения о заложенных на бортах бомбах.

### State-Level News — 515 new of 1105 total
  - (2026-11-05) [California] How did California’s gerrymander work out? Better than Texas’
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/110125-Newsom-Prop-50-AP-CM.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image" al…
  - (2026-11-05) [California] California’s election featured a big showdown over taxes. Wealth tax defeat was the biggest
      <img width="1024" height="683" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/100326_Ballots-Billionaire_MO_CM_14.jpg?fit=1024%2C683&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-11-05) [California] California billionaires faced down a tax and won new protections for their wealth
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/100526_No-Prop-40_GETTY_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-image"…
  - (2026-11-05) [California] Democrats’ blue wave beat Texas’ GOP gerrymanders. Did California even need Prop. 50?
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/110326_Marni-von-Wilpert_SDUT_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-11-05) [California] New deadline for phaseout of gas water heaters gives Bay Area homeowners one more year
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/051925_Water-Heaters-Lowes_LV_CM_06.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-post-i…
  - (2026-11-04) [California] California has one ballot-counting trouble spot. It’s the one run by an election denier
      <img width="1024" height="682" src="https://i0.wp.com/calmatters.org/wp-content/uploads/2026/11/110326_Shasta-County-Election_SO_CM_01.jpg?fit=1024%2C682&ssl=1" class="attachment-rss-image-size size-rss-image-size wp-pos…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 292 new of 342 total
  - (2026-11-04) Tencent Launches Upgraded Hy4 AI Model With Visual Understanding - Caixin Global
      Tencent Launches Upgraded Hy4 AI Model With Visual Understanding Caixin Global
  - (2026-11-05) Commentary: After the Midterms, a Case for Realism in U.S.-China Relations - Caixin Global
      Commentary: After the Midterms, a Case for Realism in U.S.-China Relations Caixin Global
  - (2026-11-05) In Depth: Envision Tests New Model for Green AI Data Centers - Caixin Global
      In Depth: Envision Tests New Model for Green AI Data Centers Caixin Global
  - (2026-11-04) Nexperia’s Dutch Entity Seeks $2 Billion From Wingtech - Caixin Global
      Nexperia’s Dutch Entity Seeks $2 Billion From Wingtech Caixin Global
  - (2026-11-04) Taiwan Weighs Tighter Controls on Chip Exports to Chinese Mainland - Caixin Global
      Taiwan Weighs Tighter Controls on Chip Exports to Chinese Mainland Caixin Global
  - (2026-11-05) Heat Waves Linked to Nearly 20,000 Deaths in China in 2025 - Caixin Global
      Heat Waves Linked to Nearly 20,000 Deaths in China in 2025 Caixin Global

### Local News: St. Louis + Atlanta — 241 new of 289 total
  - (2026-11-05) [St. Louis] London jury convicts actor Russell Brand of rape, sexual assault
      ​A jury convicted actor and comedian Russell Brand on one count of rape and three counts of sexual assault.
  - (2026-11-05) [St. Louis] GM recalls 67,000 Cadillac, Chevy vehicles that can lose the ability to brake while driving
      More than 67,000 electric vehicles sold by GM are being recalled because of a faulty brake system.
  - (2026-11-05) [St. Louis] Who won the Powerball jackpot? What we know about Wednesday night's $847 million winner
      Where was the winning Powerball ticket sold?
  - (2026-11-05) [St. Louis] Actress Hailee Steinfeld shares photos from Wonderland-themed Halloween party with Bills QB Josh Allen
      Hailee Steinfeld shared a behind-the-scenes look at a Halloween party she hosted with her husband, Josh Allen.
  - (2026-11-05) [St. Louis] Wrong-way crash on Interstate 64 kills 2, closes highway for hours
      The crash was reported shortly after 9:30 p.m. Wednesday evening.
  - (2026-11-05) [St. Louis] When will Alaska's US Senate race be called? Here are the latest numbers
      The outcome of Alaska's Senate race could depend on voters who did not have Mary Peltola or Sen. Dan Sullivan as their first choice.

### U.S. Weather + Severe / Climate Outlooks — 128 new of 130 total
  - (2026-11-05) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-11-05) [Severe] Flood Warning: Flood Warning issued November 5 at 9:29AM EST by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Astor affecting Lake and Volusia Counties. .Heavy rainfall that has occurred upstream will maintain river levels within Moderate f…
  - (2026-11-05) [Severe] Flood Warning: Flood Warning issued November 5 at 9:26AM EST by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Deland affecting Lake and Volusia Counties. .Heavy rainfall has caused the St. Johns River near Deland to rise into Minor flood st…
  - (2026-11-05) [Severe] Flood Warning: Flood Warning issued November 5 at 9:22AM EST by NWS Melbourne FL
      ...The Flood Warning continues for the following rivers in Florida... St Johns River Near Sanford affecting Seminole County. .Heavy rainfall has caused river levels on the St. Johns near Sanford to rise in Action Stage.…
  - (2026-11-05) [Severe] Flood Warning: Flood Warning issued November 5 at 8:20AM CST until November 7 at 5:24PM CST by NWS Kansas City/Pleasant Hill MO
      ...The Flood Warning continues for the following rivers in Missouri... Platte River near Platte City affecting Platte County. Platte River At Sharps Station affecting Platte County. Platte River near Agency affecting Buc…
  - (2026-11-05) [Severe] Flood Warning: Flood Warning issued November 5 at 8:20AM CST until November 8 at 7:32PM CST by NWS Kansas City/Pleasant Hill MO
      ...The Flood Warning continues for the following rivers in Missouri... Platte River near Platte City affecting Platte County. Platte River At Sharps Station affecting Platte County. Platte River near Agency affecting Buc…

### Ukraine Theater (total-war monitoring) — 96 new of 266 total
  - (2026-11-05) [DeepStateMap] frontline snapshot, 522 polygons
      Daily community-maintained frontline cartography. Polygon coverage in extra.
  - (2026-11-03) [Liveuamap] A fire at the Samara oil pumping and dispatch station (LPDS), one of Europe&039;s largest fuel storage facilities, is continuing for a second day following a drone attack – Samara Oblast,…
      A fire at the Samara oil pumping and dispatch station (LPDS), one of Europe&039;s largest fuel storage facilities, is continuing for a second day following a drone attack – Samara Oblast, Russia &
  - (2026-11-04) [Liveuamap] Ukraine&039;s National Anti-Corruption Bureau (NABU) detained Serhii Duka, first deputy head of the Security Service of Ukraine&039;s (SBU) Department for the Protection of National Stateh…
      Ukraine&039;s National Anti-Corruption Bureau (NABU) detained Serhii Duka, first deputy head of the Security Service of Ukraine&0
  - (2026-11-05) [Liveuamap] At Pokrovsk direction clashes yesterday near Serhiyivka, Molodetske, Novopavlivka, Toretske, Vilne, Novyi Donbas, Chernihivka, Dobropillya, - General Staff of Armed Forces of Ukraine repor…
      At Pokrovsk direction clashes yesterday near Serhiyivka, Molodetske, Novopavlivka, Toretske, Vilne, Novyi Donbas, Chernihivka, Do
  - (2026-11-02) [Liveuamap] One dead and five injured in an Israeli airstrike targeting a vehicle in the Tel al-Hawa neighborhood, southwest of Gaza City - Liveuamap
      One dead and five injured in an Israeli airstrike targeting a vehicle in the Tel al-Hawa nei
  - (2026-11-04) [Liveuamap] US Embassy in Saudi Arabia raises possibility of new attacks on country&039;s airports, urges citizens to exercise extreme caution. The embassy identified Houthi forces, backed by the Iran…
      US Embassy in Saudi Arabia raises possibility of new attacks on country&039;s airports, urges citizens to e

### State Legislative Action — 88 new of 158 total
  - (2026-11-05) [Alaska SB 210] An Act relating to the recognition of Indigenous cultures in public education.
      An Act relating to the recognition of Indigenous cultures in public education.
  - (2026-11-05) [Alaska HB 278] An Act establishing the Alaska-Ireland Trade Commission; and providing for an effective date.
      An Act establishing the Alaska-Ireland Trade Commission; and providing for an effective date.
  - (2026-11-05) [Alaska HB 295] An Act relating to allowable absences for eligibility for a permanent fund dividend; and providing for an effective date.
      An Act relating to allowable absences for eligibility for a permanent fund dividend; and providing for an effective date.
  - (2026-11-05) [Alaska HB 221] An Act establishing the first Friday of every October as Alaska Arts and Culture Day; and providing for an effective date.
      An Act establishing the first Friday of every October as Alaska Arts and Culture Day; and providing for an effective date.
  - (2026-11-05) [Alaska HB 189] An Act relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or dismissed; and relating to the calculation of the value of the permanent…
      An Act relating to a permanent fund dividend for an individual whose conviction has been vacated, reversed, or dismissed; and relating to the calculation of the value of the permanent fund dividend by including payment t…
  - (2026-11-05) [Alaska SB 209] An Act relating to high school graduation requirements and proficiency confirmation tools.
      An Act relating to high school graduation requirements and proficiency confirmation tools.

### Ukrainian Internal News (national + local Kyiv) — 74 new of 139 total
  - (2026-11-05) ВАКС арештував заступника начальника ДСР Нацполіції із заставою 15 млн | LEDE: Вищий антикорупційний суд відправив під варту з правом на заставу фігуранта справи "Карфаген" першого заступника н] (uk:…
      Вищий антикорупційний суд відправив під варту з правом на заставу фігуранта справи "Карфаген" першого заступника начальника Департаменту стратегічних розслідувань Нацполіції Володимира Ценова.
  - (2026-11-05) У СІЗО окупованого Криму загинула викладачка з Харкова Олександра Казаровицька | LEDE: У слідчому ізоляторі в тимчасово окупованому Сімферополі загинула співзасновниця та директорка з навчання ] (uk:…
      У слідчому ізоляторі в тимчасово окупованому Сімферополі загинула співзасновниця та директорка з навчання харківської мовної школи "Професіонал" Олександра Казаровицька.
  - (2026-11-05) Буданов про гучні викриття корупції серед правоохоронців: Потрібні сильні дії | LEDE: Керівник Офісу президента генерал-лейтенант розвідки Кирило Буданов, коментуючи нові резонансі викриття ант] (uk:…
      Керівник Офісу президента генерал-лейтенант розвідки Кирило Буданов, коментуючи нові резонансі викриття антикорупційних органів у рамках спецоперації "Карфаген" наголосив, що "ситуація потребує вчасних сильних дій".
  - (2026-11-05) Politico: У ЄС сперечаються щодо "асоційованого членства" для України, Мерц наполягає на такому форматі | LEDE: Берлін і Брюссель перебувають у суперечці щодо пропозиції президентки Єврокомісії] (uk:…
      Берлін і Брюссель перебувають у суперечці щодо пропозиції президентки Єврокомісії Урсули фон дер Ляєн надати Канаді статус "асоційованого члена" ЄС, причому напруженість посилилася після того, як голова Комісії висунула…
  - (2026-11-05) У 15 країнах Європи активісти проведуть акції протесту проти дата-центрів | LEDE: Активісти з понад 100 громадських та екологічних організацій у 15 країнах Європи проведуть дводенну спільну акц] (uk:…
      Активісти з понад 100 громадських та екологічних організацій у 15 країнах Європи проведуть дводенну спільну акцію протесту проти центрів обробки даних, вимагаючи зупинити великі проєкти у сфері штучного інтелекту.
  - (2026-11-05) У Комишувасі з-під завалів зруйнованої ударом РФ школи дістали тіла вже 43 загиблих | LEDE: У селищі Комишуваха на четверту добу рятувальних робіт з-під завалів деблокували 43 загиблих людей. П] (uk:…
      У селищі Комишуваха на четверту добу рятувальних робіт з-під завалів деблокували 43 загиблих людей. Під уламками ще можуть перебувати 33 людини.

### GDACS — global disaster alerts — 49 new of 100 total
  - (2026-11-05) [Green] Earthquake in Sea Of Okhotsk
      Earthquake · Green alert · Sea Of Okhotsk · Magnitude 4.8M, Depth:554.419km
  - (2026-11-05) [Green] Earthquake in Tanzania
      Earthquake · Green alert · Tanzania · Magnitude 5.1M, Depth:10km
  - (2026-11-05) [Green] Earthquake in United States
      Earthquake · Green alert · United States · Magnitude 4.96M, Depth:10km
  - (2026-11-04) [Green] Forest fires in Botswana
      Wildfire · Green alert · Botswana · Green impact for forestfire in 6306 ha
  - (2026-10-29) [Green] Forest fires in Brazil, Guyana
      Wildfire · Green alert · Brazil, Guyana · Green impact for forestfire in 5273 ha
  - (2026-10-28) [Green] Forest fires in Suriname, Brazil
      Wildfire · Green alert · Suriname, Brazil · Green impact for forestfire in 5198 ha

### IT, InfoSys & cybersecurity news (last 7 days) — 45 new of 56 total
  - (2026-11-05) [Krebs on Security] Want to Rent an Internet Address at the White House?
      Several staffers at the White House are using computers or mobile devices equipped with residential proxy services that render their internet address available for others to rent, security experts warned today. One of th…
  - (2026-11-05) [BleepingComputer] GhostMap Android flaw lets malicious app trigger persistent boot loop
      Attackers can force Android devices into a continuous boot loop using a specially crafted app that requires no permissions and only needs to be installed. [...]
  - (2026-11-05) [The Hacker News] Is Your Exposure Management Platform Leaving You Exposed? Five Tests to Find Out
      A critical finding can move through several security tools and still leave the organization exposed. The vulnerability has a severity score, and a ticket has reached the queue. Progress then depends on information the fi…
  - (2026-11-05) [The Hacker News] OpenAI AI Pipeline Generates 948 Linux Root Escalation Exploits in 30-Hour Run
      OpenAI on Wednesday detailed a pipeline that employed an upcoming cyber-focused artificial intelligence (AI) model to validate and patch 948 local privilege escalation vulnerabilities in Linux for $1.2 million in API cos…
  - (2026-11-05) [The Hacker News] 5 Active Cyber Threats That Put US Enterprises at Risk in October 2026
      October 2026 brought another wave of cyber threats targeting US businesses, with attackers exploiting trusted platforms, legitimate authentication processes, and everyday business workflows. For enterprises, these campai…
  - (2026-11-05) [The Hacker News] Apple to Start Scanning Publicly Shared iCloud Photos and Files for Harmful Content
      Apple has revealed that it plans to start checking public iCloud links for harmful content starting with iOS 27.3, iPadOS 27.3, macOS 27.3, and visionOS 27.3. The change specifically applies to scenarios where users shar…

### SEC Form 4 insider transactions (recent) — 40 new of 40 total
  - (2026-11-05) 485BXT - PROSHARES TRUST (0001174610) (Filer)
      filed 2026-11-05 14:42 UTC — Filed: 2026-11-05 AccNo: 0001174610-26-001211 Size: 289 KB
  - (2026-11-05) 485BXT - PROSHARES TRUST (0001174610) (Filer)
      filed 2026-11-05 14:42 UTC — Filed: 2026-11-05 AccNo: 0001174610-26-001211 Size: 289 KB
  - (2026-11-05) 424B2 - DEUTSCHE BANK AKTIENGESELLSCHAFT (0001159508) (Filer)
      filed 2026-11-05 14:41 UTC — Filed: 2026-11-05 AccNo: 0000950103-26-016996 Size: 203 KB
  - (2026-11-05) 424B2 - BANK OF NOVA SCOTIA (0000009631) (Filer)
      filed 2026-11-05 14:40 UTC — Filed: 2026-11-05 AccNo: 0001839882-26-055139 Size: 330 KB
  - (2026-11-05) 497J - FT 13366 (0002153618) (Filer)
      filed 2026-11-05 14:40 UTC — Filed: 2026-11-05 AccNo: 0001445546-26-008376 Size: 2 KB
  - (2026-11-05) 497J - FT 13315 (0002148664) (Filer)
      filed 2026-11-05 14:39 UTC — Filed: 2026-11-05 AccNo: 0001445546-26-008375 Size: 2 KB

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### Government & military aircraft airborne (OpenSky) — 27 new of 30 total
  - (2026-11-05) PAT085 (United States)
      icao24: adfedb · position: (4.2839, -74.8937) · alt: 7315m · 478km/h
  - (2026-11-05) PAT322 (United States)
      icao24: adfe48 · position: (39.0178, -77.3358) · alt: 6096m · 432km/h
  - (2026-11-05) PAT194 (United States)
      icao24: adfe8d · position: (38.1671, -89.2798) · alt: 4480m · 387km/h
  - (2026-11-05) JEDI43 (United States)
      icao24: ae1ead · position: (32.9781, -79.9901) · alt: 2834m · 349km/h
  - (2026-11-05) RRR4185 (Turkey)
      icao24: 4bc5e9 · position: (50.1128, 22.0284) · on ground
  - (2026-11-05) GAF160 (Germany)
      icao24: 3f6219 · position: (49.2983, 6.6879) · alt: 640m · 218km/h

### U.S. Federal Action — 25 new of 25 total
  - (2026-11-05) Continuation of the National Emergency With Respect to the Threat From Securities Investments That Finance Certain Companies of the People's Republic of China
  - (2026-11-05) Continuation of the National Emergency With Respect to the Situation in Nicaragua
  - (2026-11-05) Continuation of the National Emergency With Respect to the Proliferation of Weapons of Mass Destruction
  - (2026-11-05) Continuation of the National Emergency With Respect to Iran
  - (2026-11-05) Purchasing and Property Management
      This proposed rule revises the Legal Services Corporation's (LSC) definition of "capital improvement" by removing the threshold amount of LSC funds that must be expended on an improvement to real estate for the expenditu…
  - (2026-11-05) Cost Standards and Procedures; Purchasing and Property Management
      This final rule revises the Legal Services Corporation's (LSC or Corporation) regulations governing cost allowability, prior approval requirements, and property and procurement standards applicable to LSC recipients. The…

### Paper Trading Scorecard — 19 new of 69 total
  - (2026-11-05) [Manifold] Will this resolve yes?
  - (2026-11-05) [Manifold] Will AI whipe out humanity in 2029?
  - (2026-11-05) [Manifold] James Talarico (D) will win against J D Vance (R) in 2028.
  - (2026-11-05) [Manifold] Will United States become a Nazi-scale like totalitarian dictatorship before 2050?
  - (2026-11-05) [Manifold] Will Lauren Boebert be re-elected to the House in 2026? [Colorado 4]
  - (2026-11-05) [Manifold] Will 0x7055d60F50D98578d8C18DBCc84872B11862feCc receive more than $250.00 USDC Base by November 11th 11:59pm PST

### Campaign finance (FEC: top fundraisers + recent filings) — 15 new of 27 total
  - (2026-11-04) [F2] WAHAB, AISHA
      cycle 2026 · filing #2046281
  - (2026-11-04) [F24] INVEST IN TOMORROW COALITION PAC
      cycle 2026 · filing #2046240
  - (2026-11-04) [F24] CLEAN WAVE
      cycle 2026 · filing #2046288
  - (2026-11-04) [F99] KIA MARIE, A CANDIDATE FOR PRESIDENT
      cycle 2026 · filing #2046249
  - (2026-11-04) [F24] FORWARD BLUE
      cycle 2026 · filing #2046289
  - (2026-11-04) [F5] ASIAN AMERICANS FOR CIVIL RIGHTS AND EQUALITY ACTION FUND
      cycle 2026 · filing #2046215

### GDELT GKG — themes / entities / watch areas — 15 new of 15 total
  - (2026-11-05) [Russia oil sanctions perimeter · themes] 敢彈劾我就摧毀 ! 川普開嗆民主黨 共和黨帶頭 眾院最快下周彈劾 「 這戰犯 」 | 國際
      newtalk.tw · Chinese · tone NA
  - (2026-11-05) [Russia oil sanctions perimeter · themes] Gold Silver Price Today : अमेरिका में ट्रंप को लगा बड़ा झटका तो सोने - चांदी ने बदला अपना रास्ता , सिर्फ 2 दिन में आ गई भारी - भरकम तेजी | Gold Silver Shifted…
      patrika.com · Hindi · tone NA
  - (2026-11-05) [Russia oil sanctions perimeter · themes] Ryazan Valisi Malkov , İHA saldırısında sanayi tesislerinde yangın , 1 yaralı bildirdi
      haberler.com · Turkish · tone NA
  - (2026-11-05) [Russia oil sanctions perimeter · themes] Trapianto di rene , a Bologna limpossibile diventa realtà . Un nuovo percorso terapeutico apre un orizzonte di speranza per chi ha un elevato problema di rige…
      vanityfair.it · Italian · tone NA
  - (2026-11-05) [Russia oil sanctions perimeter · themes] José Ángel Hierro Garate : Memoria necesaria , rigor ausente
      eldiariomontanes.es · Spanish · tone NA
  - (2026-11-05) [Russia oil sanctions perimeter · themes] 130 אלף ש לאישה שהחליקה על כתם שמן בקניון
      ynet.co.il · Hebrew · tone NA

### Court opinions of consequence (federal & state) — 14 new of 60 total
  - (2026-11-05) Delaware Supreme Court: Miller v. State
  - (2026-11-04) U.S. Court of Appeals, 2nd Cir.: Madden v. Herbert
  - (2026-11-04) U.S. Court of Appeals, 11th Cir.: Chianne D. v. Secretary, Florida Agency for Health Care Administ
  - (2026-11-04) U.S. Court of Appeals, 8th Cir.: Logan Riffenburg v. Mark Rice
  - (2026-11-04) U.S. Court of Appeals, 8th Cir.: United States v. Eric Gaten
  - (2026-11-04) U.S. Court of Appeals, 8th Cir.: United States v. Rico Dixon

### Government Action: Sanctions + Procurement + Foreign Agents — 11 new of 96 total
  - (2026-11-04) [OFAC] Iran-related Designations; Updates to Certain Iran-related Listings; Publication of Iran-related OFAC Alert; Issuance of Amended Venezuela-related General License and Frequently Asked Question…
      Iran-related Designations; Updates to Certain Iran-related Listings; Publication of Iran-related OFAC Alert; Issuance of Amended Venezuela-related General License and Frequently Asked Question Office of Foreign Assets Co…
  - (2026-11-04) [OFAC] OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5AA Authorizing Certain Tr - Office of Foreign Assets Control (.gov)
      OFFICE OF FOREIGN ASSETS CONTROL Venezuela Sanctions Regulations 31 CFR Part 591 GENERAL LICENSE NO. 5AA Authorizing Certain Tr Office of Foreign Assets Control (.gov)
  - (2026-11-04) [OFAC] OFAC Alert: Iranian Shadow Fleet Reliance on False Flags for Sanctions Evasion - Office of Foreign Assets Control (.gov)
      OFAC Alert: Iranian Shadow Fleet Reliance on False Flags for Sanctions Evasion Office of Foreign Assets Control (.gov)
  - (2026-11-05) [USASpending] $42,157,425,910 → LAWRENCE LIVERMORE NATIONAL SECURITY, LLC: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT
      Agency: Department of Energy. Description: TAS::89 0240::TAS THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE LAWRENCE LIVERMORE NATIONAL LABORATORY (LLNL). THE CONTRACTOR SHAL…
  - (2026-11-05) [USASpending] $27,995,864,149 → SAVANNAH RIVER NUCLEAR SOLUTIONS LLC: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SIT
      Agency: Department of Energy. Description: MANAGEMENT AND OPERATING CONTRACT FOR THE SAVANNAH RIVER SITE.
  - (2026-11-05) [USASpending] $20,172,696,403 → THE REGENTS OF THE UNIVERSITY OF CALIFORNIA: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE
      Agency: Department of Energy. Description: THIS PERFORMANCE-BASED MANAGEMENT CONTRACT (PBMC) IS FOR THE MANAGEMENT AND OPERATION OF THE ERNEST ORLANDO LAWRENCE BERKELEY NATIONAL LABORATORY (LBNL). THE CONTRACTOR SHALL, I…

### Prediction Markets — most-traded (Polymarket) — 11 new of 20 total
  - (2026-11-05) Rolex Paris Masters: Ben Shelton vs Arthur Rinderknech
      yes price: 100% · 24h volume: $718,105 · resolves 2026-11-12
  - (2026-11-05) US x Iran ceasefire continues through November 2?
      yes price: 100% · 24h volume: $682,851 · resolves 2026-11-03
  - (2026-11-05) Will Joe Kent win the 2028 Republican presidential nomination?
      yes price: 1% · 24h volume: $627,558 · resolves 2028-11-08
  - (2026-11-05) Will Jon Ossoff win the 2028 Democratic presidential nomination?
      yes price: 28% · 24h volume: $448,372 · resolves 2028-11-08
  - (2026-11-05) Will Shakhtar Donetsk win the 2026-27 UEFA Champions League Championship?
      yes price: 0% · 24h volume: $434,861 · resolves 2027-05-30
  - (2026-11-05) Pete Hegseth out as Secretary of Defense by December 31?
      yes price: 52% · 24h volume: $356,440 · resolves 2027-01-01

### USGS earthquakes (M4.5+, past day) — 5 new of 5 total
  - (2026-11-05) M 5.1 - 19 km NNW of Masumbwe, Tanzania
      M5.1 · 19 km NNW of Masumbwe, Tanzania · depth 10 km
  - (2026-11-05) M 5.0 - 111 km W of Petrolia, CA
      M4.96 · 111 km W of Petrolia, CA · depth 10 km
  - (2026-11-05) M 4.8 - Sea of Okhotsk
      M4.8 · Sea of Okhotsk · depth 554.419 km
  - (2026-11-04) M 4.6 - south of the Fiji Islands
      M4.6 · south of the Fiji Islands · depth 502.294 km
  - (2026-11-04) M 4.5 - 2 km W of Chinandega, Nicaragua
      M4.5 · 2 km W of Chinandega, Nicaragua · depth 159.022 km

### Commentary & analysis (last 7 days) — 4 new of 6 total
  - (2026-11-05) [Marginal Revolution] Pollution as Growth Killer
      India’s Outlook Business has an excellent issue focusing on pollution not just as a people killer but as a growth killer (as I have emphasized pollution reduces wealth and health, see especially this video). I am intervi…
  - (2026-11-05) [Marginal Revolution] Social media and political radicalization
      For a while now, we have been hearing claims that social media radicalize the American electorate, and that social media damage teen mental health. Well, we just held a major set of elections that produced resoundingly m…
  - (2026-11-05) [Marginal Revolution] My very good Conversation with Richard Hanania
      Here is the video, audio, and transcript. Here is part of the episode summary: The first half of the conversation stays close to the text [Conrad’s Nostromo], covering the novel’s political backdrop, its deliberately scr…
  - (2026-11-04) [Conversable Economist] Social Security Reform Looms Ahead
      I graduated from college in 1982. Social Security was broke at that point, with promised payments exceeding incoming revenues. Since the system was “fixed” in 1983, the trajectory has been clear to me. I would pay into t…

### CISA Known Exploited Vulnerabilities (last 14d) — 1 new of 14 total
  - (2026-11-04) CVE-2024-27834 · Apple Multiple Products: Apple Multiple Products Improper Authentication Vulnerability
      vendor: Apple · product: Multiple Products · CISA remediation by 2026-11-18

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-11-05) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=25, 7d-median=15, 14d-median=15; carrying terms: safety, certain, final, regulatory, action, commission, document, proposed, proposing, published, rulemaking, persons
- state_bills: today=158, 7d-median=100, 14d-median=100; carrying terms: relating, alaska, providing, emergency, vehicle, review, insurance, transportation, commission, students, financial, taxes
- state_news: today=1105, 7d-median=757, 14d-median=724; carrying terms: outside, uploads, tennessee, oregon, nofollow, expect, georgia, httperror, newsom, press, based, permalink
- local_news: today=289, 7d-median=256, 14d-median=252; carrying terms: georgia, north, voters, shooting, atlantamagazine, board, across, weekend, google, stlmag, crash, magazine
- foreign_news: today=1044, 7d-median=1013, 14d-median=1006; carrying terms: heads, moving, diplomatic, kingdom, recover, httperror, block, based, short, factors, record, vietnamese
- chinese_internal: today=342, 7d-median=281, 14d-median=278; carrying terms: cbmiw, google, cbmib, lxtfa, cbmia, articles, chinese, title, https, cbmiykfvx, market, cbmiy
- russian_internal: today=938, 7d-median=938, 14d-median=990; carrying terms: journal, group, client, novaya, title, httperror, financial, europe, telegram, media, found, laquo
- ukrainian_internal: today=139, 7d-median=134, 14d-median=131; carrying terms: intelligence, production, diplomatic, httperror, alongside, provide, center, deliveries, patriot, defense, missile, kharkiv
- ukraine_theater: today=266, 7d-median=342, 14d-median=377; carrying terms: radar, jaefjwfjozmzrv, nytnrxwfrqmmrfttbmow, npakluvxfjbe, cxruwmqyoxnkatnydhvomtm, cbmivefvx, cbmilafbvv, lzaunkrlf, cartography, hvymd, cldynmltnwrzrzbvtxjnvlbkcu, depots
- paper_bets: today=69, 7d-median=69, 14d-median=67; carrying terms: successor, secretary, fuentes, general, human, participation, celsius, mamdani, lifetime, fusion, resolved, netanyahu
- weather: today=130, 7d-median=132, 14d-median=134; carrying terms: remain, until, expected, locations, difficult, weather, county, boston, widespread, tonight, western, updated
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: funds, growth, sheet, dexchus, headline, walcl, dexjpus, consumption, cpilfesl, supply, jolts, money
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, proxy, close, corporate, futures, treasury, large, agriculture, yield, china, natural, silver
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: price, crypto
- sanctions_procurement: today=96, 7d-median=99, 14d-median=102; carrying terms: checksum, general, active, space, management, operations, xskfisuh, assets, hybrid, articles, award, university
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: https, client, quiverquant, httperror, unauthorized, error, quantitative, congresstrading, quiver
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: state, international, supreme, court, appeals, blanche, trade, services, secretary, company, board, thomas
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: reporting, issuer, accno, filed, filer, financial, subject, trust, michael, finance, group, jpmorgan
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: filing, cycle, david, sherrod, robert, james, sayed, krishnamoorthi, ossoff, receipts, trone, jonathan
- gdelt_regions: today=0, 7d-median=6, 14d-median=6
- gdelt_gkg: today=15, 7d-median=38, 14d-median=38; carrying terms: english, sanctions, perimeter, chinese, themes, russia, trump, spanish
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=30, 7d-median=30, 14d-median=30; carrying terms: belgium, position, france, kingdom, germany, ground
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: disease, kayna, fifth, india, divisions, general, complete, active, seasonal, noted, organs, discharged
- cisa_kev: today=14, 7d-median=18, 14d-median=18; carrying terms: vendor, authentication, command, remediation, product, secure, software, server, vulnerability, edition, request, injection
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: probability, exploit, percentile
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: fires, guinea, japan, maximum, nigeria, magnitude, speed, depth, green, impact, tropical, australia
- usgs_quakes: today=5, 7d-median=12, 14d-median=18; carrying terms: depth, islands, south
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: volume, resolves, price, october, presidential, seats, senate, republican, democratic, prime, benjamin, israel
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: revolution, class, conversable, marginal, https, economist, world, being, activity, economists, growth, thoughts
- tech_news: today=56, 7d-median=56, 14d-median=57; carrying terms: technica, intelligence, group, investigation, schneier, state, systems, friday, record, vulnerability, today, company
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: salinas, general, valerie, intelligence, julie, sonderling, blanche, babin, mfume, ossoff, figures, transportation
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: either, claude, identify, market, today, markets, sufficient, converges, evidence, consensus, placed, module

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-28] Fed press (events + announcements): Federal Reserve issues FOMC statement
- [2026-10-29] ECB press: Piero Cipollone: Next-day securities settlement, tokenisation and the transformation of Europe’s financial infrastructure
- [2026-10-29] Fed press (events + announcements): Federal Reserve Board announces approval of application by The Bank of Nova Scotia
- [2026-10-30] ECB press: Results of the ECB Survey of Professional Forecasters for the fourth quarter of 2026
- [2026-10-30] ECB press: Decisions taken by the Governing Council of the ECB (in addition to decisions setting interest rates)
- [2026-10-30] ECB press: Philip R. Lane: AI adoption in Europe
- [2026-11-02] ECB press: Boris Vujčić: Integrated, open and resilient: Europe’s strengths in a fragmenting world
- [2026-11-04] ECB press: ECB wage tracker suggests slightly higher wage growth in first three quarters of 2027 compared with the full year of 2026
- [2026-11-05] ECB press: Piero Cipollone: Shaping the future of money
- [2026-11-05] ECB press: Isabel Schnabel: Navigating stormy waters: reflections on monetary policy

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*