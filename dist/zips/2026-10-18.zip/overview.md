# WORLDSCOPE morning brief — 2026-10-18

## Headline
2508 new items across 22 active section(s) (of 42 tracked).

## Top movers today
International News + Multilateral Institutions (686) · Russian Internal News (state + in-exile) (547) · World leaders & government officials (324) · Chinese Internal News (206) · State-Level News (146) · U.S. Weather + Severe / Climate Outlooks (122) · Local News: St. Louis + Atlanta (104) · Ukraine Theater (total-war monitoring) (103) · Ukrainian Internal News (national + local Kyiv) (65) · GDACS — global disaster alerts (61) · Sanctions & Designations (recent) (30) · GDELT GKG — themes / entities / watch areas (25)

## What changed today
### International News + Multilateral Institutions — 686 new of 946 total
  - (2026-10-18) [Global] Burnt out cars and shattered glass on Paris streets after protests turn to riots and looting
      Around 1,800 people were arrested after nationwide protests saw outbreaks of violence and vandalism.
  - (2026-10-17) [Global] Photos show luxury boat with 50m pool and water slides near Kim Jong Un's summer retreat
      Satellite images give clues about how Kim spends his holidays - something far out of reach for most North Koreans.
  - (2026-10-18) [Global] A wave of homemade, synthetic drugs sweeps US and deepens crisis
      BBC News hears from users, dealers, prison and recovery workers as the country battles with a deadly new drug epidemic.
  - (2026-10-17) [Global] European diplomats attacked by Israeli settlers in West Bank
      The Israeli military condemns the violence but the prime minister's office says it is part of a "smear" campaign.
  - (2026-10-18) [Global] Several dead or injured in major fire at Canada military base
      Officials have not given a cause or death toll, citing the "very active and delicate" situation at Canadian Forces Base Wainwright.
  - (2026-10-17) [Global] Anti-government protesters battle with police in Albania
      There were violent clashes between demonstrators and riot police throughout Saturday in the capital Tirana.

### Russian Internal News (state + in-exile) — 547 new of 878 total
  - (2026-10-18) «Я пыталась сказать, что в любом случае ее заберу». С началом большой войны тысячи украинских детей оказались в России — без возможности вернуться домой. Вот история семьи из Харьковской област] (ru:…
      В октябре в издательстве «Медузы» вышла книга «Краденое детство. Как Россия похищает украинских детей — и как украинцы возвращают их домой». Ее написали журналисты Нина Назарова (Россия) и Святослав Хоменко (Украина) и п…
  - (2026-10-18) Тиктокера Ивана Золо задержали на концерте в Донецке. Силовики в масках увели его прямо со сцены из-за футболки с «символикой сатанизма» | LEDE: Блогера и музыканта Ивана Золо (настоящее имя] (ru: Тик…
      Блогера и музыканта Ивана Золо (настоящее имя Иван Золочевский) задержали на концерте в аннексированном Донецке вечером 17 октября. В телеграм-каналах распространилось видео, на котором силовики в шлемах и масках уводят…
  - (2026-10-18) Самая масштабная атака ВСУ на Петербург и Ленинградскую область. Один погибший, 15 раненых и множество пожаров. Фотографии и видео последствий | LEDE: В ночь на 18 октября Украина ударила бе] (ru: Сам…
      В ночь на 18 октября Украина ударила беспилотниками по Санкт-Петербургу и Ленинградской области. По всей видимости, эта атака стала самой масштабной для региона с начала войны. В Петербурге повреждены нефтяной терминал в…
  - (2026-10-18) Зеленский: с тех пор, как Трамп объявил энергетическое перемирие, Россия 76 раз ударила по украинским объектам энергетики | LEDE: Президент Украины Владимир Зеленский заявил, что Россия не с] (ru: Зел…
      Президент Украины Владимир Зеленский заявил, что Россия не соблюдала энергетическое перемирие, о заключении которого неделю назад заявил президент США Дональд Трамп.
  - (2026-10-18) Во Франции участники протестов подожгли ратушу в Лиможе. Здание XIX века практически уничтожено | LEDE: В городе Лимож на юго-западе Франции участники протестов 17 октября подожгли историчес] (ru: Во…
      В городе Лимож на юго-западе Франции участники протестов 17 октября подожгли историческую ратушу XIX века, сообщили местные власти.
  - (2026-10-18) The Wall Street Journal рассказал историю российского перебежчика Льва Ступникова. Его сотрудничество с ВСУ привело к гибели сотен его сослуживцев | LEDE: Имя Льва Ступникова стало известным] (ru: The…
      Имя Льва Ступникова стало известным в сентябре 2025 года. Тогда в интервью украинскому видеоблогеру Дмитрию Карпенко Ступников сделал признание: что он российский офицер, который оказался на войне в Украине, стал наводчи…

### World leaders & government officials — 324 new of 324 total
  - () [Afghanistan] head of state: Hibatullah Akhundzada
      position: Head of state · head of govt: Mohammad Hasan Akhund
  - () [Albania] head of state: Bajram Begaj
      position: Head of state · head of govt: Edi Rama
  - () [Algeria] head of state: Abdelmadjid Tebboune
      position: Head of state · head of govt: Sifi Ghrieb
  - () [Andorra] head of state: Emmanuel Macron
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Andorra] head of state: Josep-Lluís Serrano Pentinat
      position: Head of state · head of govt: Xavier Espot Zamora
  - () [Angola] head of state: João Lourenço
      position: Head of state

### Chinese Internal News — 206 new of 267 total
  - (2026-10-17) 甘肃天水幼儿园铅中毒案一审宣判 - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMif0FVX3lxTE01ZDFTZGlSZUlZYXpId2k2QkRPRElDdkJaVlc1NE4tT09XdDkybUVoY3lDbGlNZUEySDE0c1V1MktmYlFCcG5RNW5KSnJnZ1ZxUWxi] (zh:…
      甘肃天水幼儿园铅中毒案一审宣判 人民日报
  - (2026-10-17) 推动数字经济与实体经济深度融合（今日谈） - 人民日报 | LEDE: <a href="https://news.google.com/rss/articles/CBMigAFBVV95cUxPTG5aRUpwWjhTajlxS1FjVkhoYXdCVXdpRlF1S0I0Y1N5cnB1M2V3Y2dhbjYzRTJtamNhZ0c2ZUNvQ0dNQW85dXRjM1pZZkV] (zh:…
      推动数字经济与实体经济深度融合（今日谈） 人民日报
  - (2026-10-17) 视频直播直播简介 - 人民网-福建频道 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE9nQ2w2RlZ4NFNLdDBEV2tERnF1VkhsQ25SWWg1Nkdna1FwTXNiVGktTUJBbE5yOXI3WlB0WEJpNC1USEhvRUg1RFJqOC1wbkdzTkhhRmU] (zh:…
      视频直播直播简介 人民网-福建频道
  - (2026-10-18) 山西运城： 碱蓬铺红毯盐湖染秋韵 - 人民图片 | LEDE: <a href="https://news.google.com/rss/articles/CBMib0FVX3lxTE0zaTg2Rk9abEVMM1JodTFYZDdFTDFHU2psV1pQNzdTa1AxMTRUN3RWWEYyT01NZjh0Y2I0bldmMWJrT1hJQnFxX2NHVHFrdXdoeFM] (zh:…
      山西运城： 碱蓬铺红毯盐湖染秋韵 人民图片
  - (2026-10-18) 六盘山下 长征启新程 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE1TUHd2SFVKNVVnWENKT0VRd0luSHlIUXEzbHBvUEtPX1p5V2lKTFFxa2xsZGZHV1pnVWFnZ3VWRGw5NjhrNWNzeGZOOXpESVJ2UlZKXzZIYS] (zh:…
      六盘山下 长征启新程 人民网
  - (2026-10-18) 前三季度陕西进出口保持倍增态势 - 人民网 | LEDE: <a href="https://news.google.com/rss/articles/CBMiakFVX3lxTE82V052b3hPSGlId2FpTHY0Mk9qTi1oYzZGaDA1RFl0aGFrYVF6WG1BRFRrMy1KU3hQZTAxdndFV05mam1aYmFITi1JbElpYWZVZFZnT] (zh:…
      前三季度陕西进出口保持倍增态势 人民网

### State-Level News — 146 new of 481 total
  - (2026-10-17) [California] Governor Newsom highlights mental health support for USS Abraham Lincoln sailors returning to San Diego after 321-day deployment
      Source
  - (2026-10-18) [Alaska] Alaska Territorial Guard Day 2026
      WHEREAS, the service of the Alaska Territorial Guard (ATG) in the protection of Alaska during World War II, represents service above self that is a hallmark of the Alaskan spirit; and WHEREAS, following the attack on Pea…
  - (2026-10-18) [Alaska] Alaska Day 2026
      WHEREAS, the United States purchased Alaska from Russia for $7.2 million in March of 1867, and on October 18, 1867, Alaska was formally transferred from Russia and officially became a United States Territory; and WHEREAS…
  - (2026-10-18) [Connecticut] CT kids with Medicaid coverage can face long waits for eye care
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/09/MEDICAID-EYE-CARE-0929-SG-06-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" f…
  - (2026-10-18) [Connecticut] The ups and downs of Amazon drone deliveries
      <img width="1024" height="576" src="https://ctmirror.org/wp-content/uploads/2026/10/Amazon-drone-2-Amazon-dot-com-1024x576.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async"…
  - (2026-10-17) [Connecticut] ‘No Kings’ protests across CT focus on voting, democracy
      <img width="1024" height="768" src="https://ctmirror.org/wp-content/uploads/2026/10/NH-NO-KINGS-1017-SG-01-1024x768.jpg" class="attachment-rss-image-size size-rss-image-size wp-post-image" alt="" decoding="async" loading…

### U.S. Weather + Severe / Climate Outlooks — 122 new of 124 total
  - (2026-10-18) [Unknown] Test Message: Montgomery
      Monitoring message only. Please disregard.
  - (2026-10-18) [Moderate] Gale Warning: Gale Warning issued October 18 at 6:52AM EDT until October 21 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...North to northeast winds 25 to 30 kt with gusts up to 45 kt and waves 2 to 3 ft. * WHERE...Currituck Sound. * WHEN...Until 7 AM EDT Wednesday. * IMPACTS...Strong winds will cause hazardous waves which could caps…
  - (2026-10-18) [Moderate] Gale Warning: Gale Warning issued October 18 at 6:52AM EDT until October 21 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...North to northeast winds 25 to 35 kt with gusts up to 45 kt and seas 10 to 15 ft. * WHERE...Coastal Waters from Cape Charles Light to Virginia- North Carolina border out 20 NM and Coastal waters from NC VA borde…
  - (2026-10-18) [Moderate] Gale Warning: Gale Warning issued October 18 at 6:52AM EDT until October 21 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...North to northeast winds 25 to 35 kt with gusts up to 45 kt and seas 15 to 20 ft. * WHERE...Waters from Parramore Island VA to Cape Charles Light VA from 20 to 60 NM, Waters from Cape Charles Light to Virginia -…
  - (2026-10-18) [Moderate] Gale Warning: Gale Warning issued October 18 at 6:52AM EDT until October 21 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...For the Small Craft Advisory, northeast winds 15 to 25 kt with gusts up to 30 kt and waves 2 to 4 ft. For the Gale Warning, north winds 20 to 25 kt with gusts up to 35 kt and waves 2 to 4 ft expected. * WHERE...…
  - (2026-10-18) [Moderate] Gale Warning: Gale Warning issued October 18 at 6:52AM EDT until October 21 at 7:00AM EDT by NWS Wakefield VA
      * WHAT...North to northeast winds 25 to 35 kt with gusts up to 45 kt and seas 9 to 14 ft. * WHERE...Coastal waters from Chincoteague to Parramore Island VA out 20 NM and Coastal waters from Parramore Island to Cape Charl…

### Local News: St. Louis + Atlanta — 104 new of 205 total
  - (2026-10-18) [St. Louis] Crash closes westbound I-70 in Foristell
      Westbound I-70 and the ramp to Route T/W in Foristell are closed after an early Sunday morning crash.
  - (2026-10-18) [St. Louis] Faithful gather to welcome Pope Leo back for Sunday blessing after cancer surgery
      Pope Leo XIV delivered his first public blessing since lung cancer surgery, returning to St. Peter’s Square four days after the operation.
  - (2026-10-18) [St. Louis] 'We missed death today': Passengers recount terrifying emergency landing at St. Louis Lambert Airport
      After minutes in the air, an American Airlines flight from St. Louis to Philadelphia turned around Saturday due to possible engine problems.
  - (2026-10-18) [St. Louis] Andrew Bailey sides with police union against the board Gov. Kehoe appointed, blasting chief's closed-door contract
      The former attorney general questioned the cost and the secrecy, without naming the governor whose appointees approved the deal.
  - (2026-10-18) [St. Louis] Did anyone win Powerball's $600M jackpot? Here are the winning numbers for Oct. 17
      A $600 million jackpot was up for grabs in Saturday's Powerball drawing. Here are the winning numbers.
  - (2026-10-18) [St. Louis] St. Louis police board held an emergency meeting to give its chief a new contract. The deadline was his own.
      Chief Tracy gets $295,000 plus a $24,500 retirement fund. He was already under contract. The mayor calls it a manufactured emergency.

### Ukraine Theater (total-war monitoring) — 103 new of 398 total
  - (2026-10-17) [FIRMS] thermal anomaly 52.814, 34.344 (FRP 4.56 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-17 0035Z, FRP 4.56 MW
  - (2026-10-17) [FIRMS] thermal anomaly 52.539, 32.077 (FRP 1.49 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-17 0035Z, FRP 1.49 MW
  - (2026-10-17) [FIRMS] thermal anomaly 45.259, 31.674 (FRP 7.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-17 0037Z, FRP 7.15 MW
  - (2026-10-17) [FIRMS] thermal anomaly 45.255, 31.672 (FRP 7.15 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-17 0037Z, FRP 7.15 MW
  - (2026-10-17) [FIRMS] thermal anomaly 52.193, 34.032 (FRP 13.38 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-17 1021Z, FRP 13.38 MW
  - (2026-10-17) [FIRMS] thermal anomaly 52.359, 34.096 (FRP 3.39 MW, conf nominal)
      VIIRS S-NPP NRT, sat N, acquired 2026-10-17 1021Z, FRP 3.39 MW

### Ukrainian Internal News (national + local Kyiv) — 65 new of 134 total
  - (2026-10-18) В Литві розповіли про наслідки падіння невідомого дрона | LEDE: Деталі інциденту з дрона, що впав у Литві: пошкоджено цивільний автомобіль, постраждалих немає. Триває розслідування походження а] (uk:…
      Деталі інциденту з дрона, що впав у Литві: пошкоджено цивільний автомобіль, постраждалих немає. Триває розслідування походження апарата.
  - (2026-10-18) Повітряні сили показали бойову роботу винищувача під час збиття російської "Герані" | LEDE: Льотчик із позивним Denfix збив безпілотник "Герань" росіян. Момент знищення дрона оприлюднили Повітр] (uk:…
      Льотчик із позивним Denfix збив безпілотник "Герань" росіян. Момент знищення дрона оприлюднили Повітряні сили Збройних сил України.
  - (2026-10-18) Польща задіяла авіацію та призупинила роботу двох аеропортів через атаки РФ на Україну | LEDE: ] (uk: Польща задіяла авіацію та призупинила роботу двох аеропортів через атаки РФ на У)
  - (2026-10-18) РФ влучила по багатоповерхівці в Одесі: спалахнула пожежа, постраждала дитина | LEDE: Після ворожого обстрілу в Одесі постраждали дві особи, серед них 14-річна дівчинка. Пошкоджено дах і кварти] (uk:…
      Після ворожого обстрілу в Одесі постраждали дві особи, серед них 14-річна дівчинка. Пошкоджено дах і квартири багатоповерхового будинку.
  - (2026-10-18) Після авіаударів РФ по Слов’янську загинули 6 містян, є поранені, під завалами люди | LEDE: Російські авіаудари та дронові атаки по Слов'янську призвели до загибелі 6 людей, 15 поранень і руйну] (uk:…
      Російські авіаудари та дронові атаки по Слов'янську призвели до загибелі 6 людей, 15 поранень і руйнування понад 20 будинків 17 жовтня.
  - (2026-10-18) Протести у Франції: низка міст зазнали погромів, влада повідомляє про понад 1000 арештів | LEDE: Після масштабних протестів у Франції, які переросли у погроми, мародерство та насильницькі сутич] (uk:…
      Після масштабних протестів у Франції, які переросли у погроми, мародерство та насильницькі сутички, правоохоронці затримали близько 1200 осіб.

### GDACS — global disaster alerts — 61 new of 100 total
  - (2026-10-18) [Green] Earthquake in Indonesia
      Earthquake · Green alert · Indonesia · Magnitude 5.2M, Depth:10km
  - (2026-10-18) [Green] Earthquake in Papua New Guinea
      Earthquake · Green alert · Papua New Guinea · Magnitude 4.8M, Depth:124.07km
  - (2026-10-17) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 7068 ha
  - (2026-10-17) [Green] Forest fires in Australia
      Wildfire · Green alert · Australia · Green impact for forestfire in 5023 ha
  - (2026-10-12) [Green] Forest fires in Indonesia
      Wildfire · Green alert · Indonesia · Green impact for forestfire in 6773 ha
  - (2026-10-09) [Green] Forest fires in Papua New Guinea
      Wildfire · Green alert · Papua New Guinea · Green impact for forestfire in 5009 ha

### Sanctions & Designations (recent) — 30 new of 30 total
  - (2026-05-08) BELORUSSIAN- RUSSIAN BELGAZPROMBANK JOINT STOCK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, ua_nsdc_sanctions, ua_war_sanctions · country: by · topics: fin, fin.bank, sanction
  - (2026-05-08) JSC MIR BUSINESS BANK (Company)
      source: be_fod_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: fin, fin.bank, sanc…
  - (2026-05-06) Sberbank Europe AG (Company)
      source: ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: at · topics: fin.bank, corp.public, sanction
  - (2026-05-06) GPB GLOBAL RESOURCES BV (Company)
      source: ua_war_sanctions, us_ofac_cons, us_sam_exclusions, us_trade_csl · country: nl · topics: debarment, sanction
  - (2026-05-06) OJSC RUSSIAN REGIONAL DEVELOPMENT BANK (Company)
      source: ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_journal_sanctions, gb_fcdo_sanctions, ua_nsdc_sanctions, ua_war_sanctions, us_ofac_cons, us_ofac_sdn, us_sam_exclusions, us_trade_csl · country: ru · topics: corp.di…
  - (2026-05-05) JSC Tinkoff Bank (Company)
      source: be_fod_sanctions, ca_dfatd_sema_sanctions, ch_seco_sanctions, eu_fsf, eu_journal_sanctions, fr_tresor_gels_avoir, gb_fcdo_sanctions, jp_mof_sanctions, mc_fund_freezes, ua_war_sanctions, us_ofac_sdn, us_sam_exclus…

### GDELT GKG — themes / entities / watch areas — 25 new of 25 total
  - (2026-10-18) [Israel-Iran-Hezbollah axis · keywords] US ambassador to Israel condemns settler attack on US journalist , and other Mideast news
      thegazette.com · English · tone NA
  - (2026-10-18) [Israel-Iran-Hezbollah axis · keywords] US ambassador to Israel condemns settler attack on journalist
      midweekherald.co.uk · English · tone NA
  - (2026-10-18) [Israel-Iran-Hezbollah axis · keywords] Netanyahu : Only way to end Iran threat is to get rid of this regime
      clevelandjewishnews.com · English · tone NA
  - (2026-10-18) [Israel-Iran-Hezbollah axis · keywords] US ambassador to Israel condemns settler attack on journalist
      heraldseries.co.uk · English · tone NA
  - (2026-10-18) [Israel-Iran-Hezbollah axis · keywords] Herzog marks 40 years since IAF navigator Ron Arad was taken captive in Lebanon
      clevelandjewishnews.com · English · tone NA
  - (2026-10-18) [Israel-Iran-Hezbollah axis · keywords] US ambassador to Israel condemns settler attack on journalist
      watfordobserver.co.uk · English · tone NA

### Court opinions of consequence (federal & state) — 23 new of 60 total
  - (2026-10-16) U.S. Court of Appeals, 10th Cir.: Pawnee Nation of Oklahoma v. Zeldin
  - (2026-10-16) Iowa Supreme Court: In the Interest of E.S., Minor Child
  - (2026-10-16) Iowa Supreme Court: Joshua Davenport v. Nathanael K. Fuller
  - (2026-10-16) Iowa Supreme Court: Robert Teig v. Iowa Judicial Branch, Molly Weber, Robert Gast, Nicholas Critelli, Iowa Supreme Court Attorney Disciplinary Board, Iowa Office of Professional Regulation, and Tara v…
  - (2026-10-16) Kansas Supreme Court: State v. Riggins
  - (2026-10-16) Hawaii Supreme Court: Hasegawa v. Fang

### Government & military aircraft airborne (OpenSky) — 16 new of 16 total
  - (2026-10-18) JAF50T (Bulgaria)
      icao24: 4520ce · position: (41.8145, -3.0515) · alt: 11285m · 776km/h
  - (2026-10-18) JAF94H (Bulgaria)
      icao24: 4520aa · position: (41.8853, -4.2755) · alt: 11285m · 825km/h
  - (2026-10-18) CFC2906 (Canada)
      icao24: c2b5cb · position: (51.8396, 10.4333) · alt: 7924m · 590km/h
  - (2026-10-18) JAF4NV (Belgium)
      icao24: 44d1a5 · position: (39.2569, 0.428) · alt: 9753m · 846km/h
  - (2026-10-18) JAF95N (Belgium)
      icao24: 44d1b4 · position: (51.4291, 2.4478) · alt: 4572m · 561km/h
  - (2026-10-18) JAF7AK (Belgium)
      icao24: 44d1a1 · position: (45.6469, -0.6082) · alt: 10972m · 821km/h

### Prediction Markets — most-traded (Polymarket) — 15 new of 20 total
  - (2026-10-18) Shanghai Rolex Masters: Alejandro Davidovich Fokina vs Rafael Jodar
      yes price: 98% · 24h volume: $1,398,295 · resolves 2026-10-25
  - (2026-10-18) Spread: Jaguars (-2.5)
      yes price: 50% · 24h volume: $530,061 · resolves 2026-10-18
  - (2026-10-18) Will the US confirm that aliens exist before 2027?
      yes price: 5% · 24h volume: $396,393 · resolves 2027-01-01
  - (2026-10-18) Tampa Bay Rays vs. Cleveland Guardians
      yes price: 56% · 24h volume: $387,506 · resolves 2026-10-25
  - (2026-10-18) Will Udinese Calcio win on 2026-10-18?
      yes price: 8% · 24h volume: $380,530 · resolves 2026-10-18
  - (2026-10-18) Will Arsenal FC win on 2026-10-18?
      yes price: 60% · 24h volume: $352,238 · resolves 2026-10-18

### IT, InfoSys & cybersecurity news (last 7 days) — 14 new of 58 total
  - (2026-10-18) [The Hacker News] ConnectWise Suspends Cloud Backup After Attackers Compromise Microsoft 365 Tenants
      ConnectWise on Saturday said it has disabled seven ConnectWise application identities as it continues its investigation into an incident in which unknown threat actors obtained unauthorized access to the application iden…
  - (2026-10-18) [The Register] Oh no, what happened to my OOHPod? Windows command prompt puts in a surprise appearance
      Pop quiz: somebody left a command shell logged in. What do you do?
  - (2026-10-17) [BleepingComputer] Hackers breach Microsoft 365 tenants via ConnectWise supply-chain attack
      ConnectWise has shut down customer access to its Cloud Backup service (formerly SkyKick Cloud Backup) after hackers accessed application identities and compromised Microsoft 365 tenants. [...]
  - (2026-10-17) [BleepingComputer] Drupal patches critical RCE flaws, warns exploits may emerge soon
      Drupal has patched two critical vulnerabilities that could allow attackers to execute code remotely on websites running any supported version of the content management system. [...]
  - (2026-10-17) [The Hacker News] MALFEX npm Package 'imgdecode' Hides Shellcode Loader in Windows Native Addon
      Cybersecurity researchers have discovered a malicious npm package that's part of a recently disclosed software supply chain attack campaign dubbed MALFEX. The package, named "imgdecode," was uploaded to the package regis…
  - (2026-10-17) [The Register] Cybercrims go beyond stealing data to attack physical building systems
      'Hold my beer, have fun getting into your offices'

### Paper Trading Scorecard — 6 new of 62 total
  - (2026-10-18) [Polymarket] Chargers vs. Chiefs
      In the upcoming NFL football game between Chargers and Chiefs, scheduled for October 18 at 4:25PM ET: This market will resolve to "Chargers" if Chargers win the game. This market will resolve to "Chiefs" if Chiefs win th…
  - (2026-10-18) [Manifold] Will the OpenAI spy get bail?
  - (2026-10-18) [Manifold] "Avengers: Doomsday" breaks the record for the biggest opening weekend of all time?
  - (2026-10-18) [Manifold] Will a privately-held company ever become the most valuable in the world?
  - (2026-10-18) [Manifold] Will JerryRigEverything win his $10K bet against Palmer Luckey?
  - (2026-10-18) [Manifold] Will Andrea Kimi Antonelli Clinch the F1 World Championship at the United States GP?

### Campaign finance (FEC: top fundraisers + recent filings) — 5 new of 27 total
  - (2026-10-18) [Top] EL-SAYED, ABDUL (DEM, Senate MI): $45.18M raised
      cycle 2026 receipts $45.18M · disbursements $41.38M · net $+3.79M
  - () [F3X] GROOM LAW GROUP, CHARTERED POLITICAL ACTION COMMITTEE
      cycle 2026 · filing #-1000977
  - () [F3X] CHANGE FOR THE BETTER
      cycle 2012 · filing #758677
  - () [F3] DOUTHITT FOR CONGRESS
      cycle 2014 · filing #987909
  - () [F3] REDPATH FOR CONGRESS
      cycle 2014 · filing #993204 · receipts $0.00M

### USGS earthquakes (M4.5+, past day) — 5 new of 5 total
  - (2026-10-18) M 5.2 - 55 km NNW of Ruteng, Indonesia
      M5.2 · 55 km NNW of Ruteng, Indonesia · depth 10 km
  - (2026-10-17) M 5.2 - 86 km SW of Brisas Barra de Suchiate, Mexico
      M5.2 · 86 km SW of Brisas Barra de Suchiate, Mexico · depth 10 km
  - (2026-10-18) M 4.8 - 31 km SE of Kainantu, Papua New Guinea
      M4.8 · 31 km SE of Kainantu, Papua New Guinea · depth 124.07 km
  - (2026-10-17) M 4.6 - 88 km SSW of Uyuni, Bolivia
      M4.6 · 88 km SSW of Uyuni, Bolivia · depth 189.462 km
  - (2026-10-17) M 4.6 - 70 km W of Tambolaka, Indonesia
      M4.6 · 70 km W of Tambolaka, Indonesia · depth 68.927 km

### Commentary & analysis (last 7 days) — 3 new of 6 total
  - (2026-10-18) [Marginal Revolution] Our fascination with screens, demand curves slope downward installment #1637
      What we find here is that the quality-adjusted screen time price index is down 39 per cent since 2000, but that change is overwhelmingly a function of improvements in quality, not declines in prices paid for devices, sub…
  - (2026-10-18) [Marginal Revolution] The archaeology tranche of Emergent Ventures
      Björn Öste is building Arkhub, an AI-powered platform that analyzes remote-sensing and other archaeological data to identify potential ancient sites in the Amazon and enable further investigation by citizen scientists. J…
  - (2026-10-17) [Marginal Revolution] Saturday assorted links
      1. GLM-5.3 understands Bob Lucas (and then some). It amuses me how many basic principles of economics are being rediscovered in these new contexts. 2. Most famous book tied to every U.S. state. The NJ answer is crazy, ho…

### Government Action: Sanctions + Procurement + Foreign Agents — 1 new of 104 total
  - (2026-10-18) [UN Sanctions] page checksum 5bf218f2ca8b
      Active UN Security Council sanctions committees page snapshot

### Paper-Bet Placement (today's new positions) — 1 new of 1 total
  - (2026-10-18) [paper_bet_placement] No bets placed today
      The decision module did not identify any markets with sufficient edge today. Either evidence converges with market consensus, or Claude API was unavailable.

## How it fits the arc (last 14 days)
- federal_register: today=33, 7d-median=26, 14d-median=26; carrying terms: proposing, final, period, action, public, proposes, safety, require, certain, regulatory, national, proposed
- state_bills: today=120, 7d-median=118, 14d-median=111; carrying terms: relating, education, providing, alaska, administration, effective, school, powers, district, state, grants, coverage
- state_news: today=481, 7d-median=688, 14d-median=667; carrying terms: arizona, critical, person, research, debate, working, dakota, board, status, diesel, image, session
- local_news: today=205, 7d-median=235, 14d-median=233; carrying terms: decoding, person, north, according, officials, atlantamagazine, several, public, family, stlmag, struck, years
- foreign_news: today=946, 7d-median=1018, 14d-median=1018; carrying terms: holding, person, research, exchange, driver, debate, strategic, missile, interest, event, infrastructure, signs
- chinese_internal: today=267, 7d-median=296, 14d-median=284; carrying terms: china, cbmizefvx, cbmickfvx, cbmixkfvx, articles, cbmiy, cbmiw, cbmix, cbmizkfvx, lxtfb, blank, cbmibkfvx
- russian_internal: today=878, 7d-median=1029, 14d-median=1061; carrying terms: times, media, novaya, gazeta, raquo, istories, politico, error, europe, laquo, server, forbidden
- ukrainian_internal: today=134, 7d-median=130, 14d-median=133; carrying terms: critical, missile, civilians, bombs, buildings, officials, infrastructure, kremlin, western, takeaways, update, support
- ukraine_theater: today=398, 7d-median=393, 14d-median=433; carrying terms: critical, mjkxswttx, nsdnrr, zsfhhmesxtfpbanvpnuv, exchange, yyvrvel, vxzudnvfc, yvnywc, rwvgruc, ejvudzhwtw, wxvvbfbmcdvvaelaztrotwncylrmrnm, cbmiiwfbvv
- paper_bets: today=62, 7d-median=69, 14d-median=84; carrying terms: jinping, growth, general, celsius, sachs, drought, kalshi, funds, leaders, evans, career, israel
- weather: today=124, 7d-median=142, 14d-median=141; carrying terms: significant, miami, atlantic, northeast, above, north, pontiac, winds, houston, watch, thursday, rivers
- macro: today=21, 7d-median=21, 14d-median=21; carrying terms: unemployment, growth, openings, energy, payems, balance, cpilfesl, implied, spread, effective, inflation, money
- markets: today=21, 7d-median=21, 14d-median=21; carrying terms: russell, credit, bitcoin, agriculture, yield, close, corporate, crypto, futures, treasury, china, nasdaq
- markets_global: today=47, 7d-median=47, 14d-median=47; carrying terms: crypto, price
- sanctions_procurement: today=104, 7d-median=107, 14d-median=111; carrying terms: general, palestinian, sanctions, resolutions, acronym, detect, hybrid, violent, mediterranean, prohibiting, legislation, usaspending
- congressional_trades: today=1, 7d-median=1, 14d-median=1; carrying terms: congresstrading, quantitative, quiverquant, error, quiver, https, httperror, unauthorized, client
- billionaires: today=0, 7d-median=0, 14d-median=0
- people: today=0, 7d-median=0, 14d-median=0
- sanctions: today=0, 7d-median=0, 14d-median=0
- courtlistener: today=60, 7d-median=60, 14d-median=60; carrying terms: board, appeals, corporation, court, state, supreme, company, county, alabama, international, mullin, division
- form4: today=40, 7d-median=40, 14d-median=40; carrying terms: issuer, accno, filed, reporting, robert, holdings, natera, matthew, rabinowitz, jonathan, justin, management
- fec: today=27, 7d-median=27, 14d-median=27; carrying terms: robert, filing, receipts, krishnamoorthi, johnson, david, michael, elect, shawn, pinkston, jonathan, house
- gdelt_regions: today=0, 7d-median=1, 14d-median=1
- gdelt_gkg: today=25, 7d-median=25, 14d-median=25; carrying terms: english, israel, strait, hezbollah
- mediacloud: today=0, 7d-median=0, 14d-median=0
- conflict: today=0, 7d-median=0, 14d-median=0
- acled: today=0, 7d-median=0, 14d-median=0
- firms: today=0, 7d-median=0, 14d-median=0
- vip_flights: today=16, 7d-median=28, 14d-median=30; carrying terms: position, belgium, france, kingdom, ground, canada, bulgaria
- promed: today=0, 7d-median=0, 14d-median=0
- who_don: today=40, 7d-median=40, 14d-median=40; carrying terms: respiratory, accordance, france, ventilation, fourth, general, dicale, person, batch, tshopo, producing, investigations
- cisa_kev: today=15, 7d-median=15, 14d-median=15; carrying terms: product, injection, vulnerability, memory, within, buffer, traversal, improper, citrix, operations, remediation, bounds
- epss: today=40, 7d-median=40, 14d-median=40; carrying terms: exploit, percentile, probability
- wikidata_changes: today=0, 7d-median=0, 14d-median=0
- reliefweb: today=0, 7d-median=0, 14d-median=0
- gdacs: today=100, 7d-median=100, 14d-median=100; carrying terms: forestfire, guinea, brazil, magnitude, typhoon, hurricane, impact, maximum, indonesia, depth, alert, cyclone
- usgs_quakes: today=5, 7d-median=17, 14d-median=17; carrying terms: depth, indonesia, papua, guinea, tambolaka, mexico, ruteng
- forecasts: today=20, 7d-median=20, 14d-median=20; carrying terms: price, league, donetsk, october, volume, championship, champions, resolves, shakhtar, presidential, election, brazilian
- commentary: today=6, 7d-median=6, 14d-median=6; carrying terms: class, economist, revolution, https, conversable, marginal, conversableeconomist, remember, track, economic, years, marginalrevolution
- tech_news: today=58, 7d-median=58, 14d-median=58; carrying terms: download, bleepingcomputer, according, artificial, software, weekday, infrastructure, people, intelligence, ransomware, cybersecurity, vulnerability
- political_figures: today=613, 7d-median=613, 14d-median=613; carrying terms: mfume, obernolte, nydia, general, elise, ashley, veasey, valadao, elena, blake, exchange, chuck
- paper_bet_placement: today=1, 7d-median=1, 14d-median=1; carrying terms: paper, either, decision, today, sufficient, markets, module, converges, identify, unavailable, placement, claude

## What to watch (recent + forthcoming, ±14 days)
- [2026-10-05] Fed press (events + announcements): Federal Reserve Board announces approval of application by Isabella Bank Corporation
- [2026-10-06] ECB press: Frank Elderson: Effective supervision through timely remediation
- [2026-10-06] ECB press: Piero Cipollone: Money in the digital age: digital euro, tokenisation and the role of central banks
- [2026-10-06] Fed speeches: Bowman, Modernizing the Regulatory and Supervisory Landscape
- [2026-10-07] ECB press: Results of the September 2026 survey on credit terms and conditions in euro-denominated securities financing and OTC derivatives markets (SESFOD)
- [2026-10-07] Fed press (events + announcements): Minutes of the Federal Open Market Committee, September 15-16, 2026
- [2026-10-08] ECB press: Piero Cipollone: Interview with Corriere della Sera
- [2026-10-08] Fed speeches: Waller, The Signaling Value of the Summary of Economic Projections
- [2026-10-08] ECB press: Meeting of 9-10 September 2026
- [2026-10-08] Fed press (events + announcements): Federal Reserve Board announces enforcement action against American Express Company to address, among other things, the firm’s failure to sufficiently detect and report certain suspicious activity related to money laundering
- [2026-10-09] Fed press (events + announcements): Federal Reserve Board releases results of the 2025 Survey of Consumer Finances, which provides the public and policymakers with detailed insights into the economic condition of American families
- [2026-10-13] Fed press (events + announcements): Minutes of the Board's discount rate meetings on August 17, September 9, and September 16, 2026
- [2026-10-13] ECB press: Philip R. Lane: The AI opportunity for Europe
- [2026-10-14] ECB press: Frank Elderson: Ensuring resilience in the face of uncertainty
- [2026-10-15] Fed speeches: Bowman, Supervisory Modernization After Silicon Valley Bank
- [2026-10-16] Fed press (events + announcements): Federal Reserve Board announces termination of enforcement actions with Gardner Bancshares, Inc. and Small Business Bank
- [2026-10-17] ECB press: Christine Lagarde: IMFC Statement

*Calendar currently shows recent central-bank announcements (often forward-looking). Explicit forthcoming-event APIs — FRED release calendar, FOMC dates, Treasury auctions, SCOTUS oral argument calendar — land in a later sprint.*

*Note: this is the deterministic fallback. Set `ANTHROPIC_API_KEY` for synthesized prose.*